package city

import (
	"net/http/httptest"
	"strings"
	"testing"
)

func TestStateCarriesWhatSheDecided(t *testing.T) {
	h := Handler(func() State { return State{Doing: &Doing{ID: 3, Goal: "g:wave", OK: true, Dur: 2}} })
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, httptest.NewRequest("GET", "/state.json", nil))
	if !strings.Contains(rec.Body.String(), `"goal":"g:wave"`) {
		t.Fatalf("doing missing: %s", rec.Body.String())
	}
}
