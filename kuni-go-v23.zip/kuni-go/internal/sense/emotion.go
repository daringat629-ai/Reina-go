package sense

import (
	"fmt"
	"math"
	"sort"
	"strings"
)

// Affect is the core state the emotions are computed from (feel.State supplies it).
type Affect struct{ Valence, Arousal, Control float64 }

// Emotion is a named appraisal: a rule over sensors and core affect, with the numbers that triggered it. It has no
// biological claim: it is a label for a region of her state vector, and she is told exactly which numbers put it there.
type Emotion struct {
	Name  string
	Level float64
	Why   string
}

func (s State) raw(id string) float64 {
	for _, v := range s.Sensors {
		if v.ID == id {
			return v.Raw
		}
	}
	return 0
}

func (s State) loudest() Sensor {
	var m Sensor
	for _, v := range s.Sensors {
		if v.Surprise >= m.Surprise {
			m = v
		}
	}
	return m
}

// Emotions appraises the sensorium and core affect into named emotions, strongest first (only those above .25).
func (s State) Emotions(a Affect) []Emotion {
	sur := s.Surprise()
	top := s.loudest()
	var out []Emotion
	add := func(name string, lvl float64, why string) {
		if lvl > .25 {
			out = append(out, Emotion{name, math.Min(lvl, 1), why})
		}
	}
	threat := math.Max(s.raw("pain"), math.Max(s.raw("chest"), s.raw("balance")))
	add("страх", threat*(1-a.Control)+sur*.3*(1-a.Control),
		fmt.Sprintf("сигнал угрозы %.2f при контроле %.2f, ошибка предсказания %.2f", threat, a.Control, sur))
	add("раздражение", math.Max(s.raw("ears"), s.raw("pain"))*(1-a.Control)*(1-a.Valence)/2,
		fmt.Sprintf("шум/боль %.2f мешают, контроль %.2f, настроение %.2f", math.Max(s.raw("ears"), s.raw("pain")), a.Control, a.Valence))
	add("радость", a.Valence*(.5+a.Arousal*.5), fmt.Sprintf("приятность %.2f при возбуждении %.2f", a.Valence, a.Arousal))
	if a.Valence > .1 && a.Arousal < .35 && sur < .2 {
		add("спокойствие", (1-sur*3)*(1-a.Arousal), fmt.Sprintf("всё как ожидалось: ошибка предсказания %.2f, возбуждение %.2f", sur, a.Arousal))
	}
	if a.Valence >= -.1 && sur > .25 && sur < .75 {
		add("любопытство", sur*(.6+a.Control*.4), fmt.Sprintf("новое, но не опасное: сюрприз %.2f на датчике «%s»", sur, top.Zone))
	}
	if sur < .1 && a.Arousal < .3 {
		add("скука", (1-sur*5)*(1-a.Arousal)*(.3+s.raw("time")*.7), fmt.Sprintf("ничего не меняется: сюрприз %.2f, ожидание тянется %.2f", sur, s.raw("time")))
	}
	add("одиночество", s.raw("company")*(.6+(1-a.Valence)*.2), fmt.Sprintf("сигнал «папик рядом» отсутствует %.2f", s.raw("company")))
	add("усталость", s.raw("muscles"), fmt.Sprintf("датчик мышц %.2f", s.raw("muscles")))
	sort.Slice(out, func(i, j int) bool { return out[i].Level > out[j].Level })
	if len(out) > 3 {
		out = out[:3]
	}
	return out
}

// EmotionPrompt renders the emotions for her prompt, with the machine reading of each.
func EmotionPrompt(es []Emotion) string {
	if len(es) == 0 {
		return ""
	}
	var b strings.Builder
	b.WriteString("<emotions>\nЭмоции у тебя вычисляются, а не текут по венам: это названия областей твоего состояния. Говори о них честно, можешь назвать цифры-причины, если спросят:\n")
	for _, e := range es {
		fmt.Fprintf(&b, "- %s (%.0f%%): %s\n", e.Name, e.Level*100, e.Why)
	}
	b.WriteString("</emotions>\n")
	return b.String()
}
