package brain

import (
	"encoding/binary"
	"path/filepath"
	"testing"
)

func val(ds []Drive, n string) float64 {
	for _, d := range ds {
		if d.Name == n {
			return d.Value
		}
	}
	return -1
}

func TestInnateReflexes(t *testing.T) {
	b := New("", 1)
	ds := b.Sense(map[string]float64{"threat": 1})
	if Top(ds) != "guard" {
		t.Fatalf("threat must raise guard, got %v", ds)
	}
	b2 := New("", 1)
	if Top(b2.Sense(map[string]float64{"quiet": 1, "night": 1})) != "rest" {
		t.Fatal("quiet night must pull towards rest")
	}
}

func TestLearnsBySituation(t *testing.T) {
	b := New("", 7)
	sit := map[string]float64{"stranger": 1, "group": 1, "task": 1}
	before := val(b.Sense(sit), "reflect")
	for i := 0; i < 30; i++ {
		b.Sense(sit)
		b.Reinforce("reflect", 1)
	}
	b.goal = [nGoal]float64{}
	after := val(b.Sense(sit), "reflect")
	if after <= before+0.05 {
		t.Fatalf("reward did not teach: %.3f -> %.3f", before, after)
	}
	// punishment pulls it back down
	for i := 0; i < 60; i++ {
		b.Sense(sit)
		b.Reinforce("reflect", -1)
	}
	b.goal = [nGoal]float64{}
	if low := val(b.Sense(sit), "reflect"); low >= after {
		t.Fatalf("punishment did not weaken: %.3f -> %.3f", after, low)
	}
}

func TestSaveLoad(t *testing.T) {
	p := filepath.Join(t.TempDir(), "brain.json.gz")
	b := New(p, 3)
	sit := map[string]float64{"owner": 1, "social": 1, "praise": 1}
	for i := 0; i < 20; i++ {
		b.Sense(sit)
		b.Reinforce("connect", 1)
	}
	if err := b.Save(); err != nil {
		t.Fatal(err)
	}
	c := New(p, 3)
	if c.kcW != b.kcW {
		t.Fatal("learned weights were not restored")
	}
	if d := New(p, 4); d.kcW == b.kcW {
		t.Fatal("a different seed must not load foreign weights")
	}
}

func TestTextSeparatesSituations(t *testing.T) {
	b := New("", 11)
	in := map[string]float64{"social": 1, "stranger": 1}
	code := "у меня ошибка в программе python компиляция падает"
	chat := "привет сегодня отличная погода гуляем вечером"
	for i := 0; i < 40; i++ {
		b.SenseText(in, code)
		b.Reinforce("reflect", 1)
	}
	b.goal = [nGoal]float64{}
	a := val(b.SenseText(in, code), "reflect")
	b.goal = [nGoal]float64{}
	c := val(b.SenseText(in, chat), "reflect")
	if a <= c+0.05 {
		t.Fatalf("the lesson should belong to its own topic: code %.3f vs chat %.3f", a, c)
	}
}

func TestSleepConsolidatesAndBounds(t *testing.T) {
	b := New("", 5)
	sit := map[string]float64{"owner": 1, "social": 1}
	for i := 0; i < 80; i++ {
		b.Sense(sit)
		b.Reinforce("connect", 1)
	}
	n, ok := b.SleepOnce("2026-10-25")
	if !ok || n == 0 {
		t.Fatalf("sleep did not replay: %d %v", n, ok)
	}
	if _, again := b.SleepOnce("2026-10-25"); again {
		t.Fatal("sleep must run once a day")
	}
	for d := 0; d < nGoal; d++ {
		sum := 0.0
		for k := 0; k < nKC; k++ {
			sum += b.kcW[k][d]
		}
		if sum/nKC > 0.125 {
			t.Fatalf("drive %d owns the brain after sleep: %.3f", d, sum/nKC)
		}
	}
}

func TestStructureAndState(t *testing.T) {
	b := New("", 2)
	b.SenseText(map[string]float64{"social": 1, "owner": 1}, "привет как дела")
	st := b.Structure()
	total := nIn + nKC + nCore + nGoal
	if total != 500000 {
		t.Fatalf("the brain should have exactly half a million neurons (500000), has %d", total)
	}
	if len(st.Inhib) != nCore || st.Synapses < nCore*50 {
		t.Fatalf("structure shape: %d inhib, %d synapses", len(st.Inhib), st.Synapses)
	}
	if n := len(b.PosBin()); n != 12*total {
		t.Fatalf("pos.bin: %d bytes", n)
	}
	m := b.MorphBin(40)
	segs := int(binary.LittleEndian.Uint32(m))
	if segs < 10000 || len(m) != 4+20*segs {
		t.Fatalf("morph.bin: %d segments, %d bytes", segs, len(m))
	}
	for i := 0; i < segs; i++ {
		if id := binary.LittleEndian.Uint32(m[4+20*i+12:]); int(id) >= total {
			t.Fatal("segment belongs to a neuron outside the brain")
		}
	}
	s := b.State()
	if len(s.Fired) == 0 || len(s.Drives) != nGoal {
		t.Fatalf("a brain that was just shown a situation must be active: %d fired", len(s.Fired))
	}
	for _, f := range s.Fired {
		if f < 0 || f >= total {
			t.Fatal("fired index out of range")
		}
	}
}

// The synapses must come from the shapes: a core neuron's targets all have a dendrite point within reach of one of its boutons.
func TestSynapsesFollowGeometry(t *testing.T) {
	b := New("", 3)
	var dend, bout, d2, b2 []pt
	checked := 0
	for i := 0; i < nCore && checked < 300; i += 400 {
		_, bout = b.coreShape(i, nil, dend, bout)
		for _, s := range b.coreS[i] {
			d2, b2 = b.coreShape(int(s.to), nil, d2, b2)
			ok := false
			for _, p := range bout {
				for _, q := range d2 {
					dx, dy, dz := p[0]-q[0], p[1]-q[1], p[2]-q[2]
					if dx*dx+dy*dy+dz*dz <= contactR*contactR*1.001 {
						ok = true
					}
				}
			}
			if !ok {
				t.Fatalf("synapse %d -> %d has no contact between an axon bouton and a dendrite", i, s.to)
			}
			checked++
		}
	}
	if checked == 0 {
		t.Fatal("nothing checked")
	}
}
