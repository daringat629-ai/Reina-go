package brain

import (
	"math"
)

// Measures of how "integrated and differentiated" the dynamics are. They are the engineering cousins of two ideas from the
// science of consciousness, not proofs of anything:
//   - Perturbation complexity (PCI, Casali et al. 2013): poke the system once, record the spatio-temporal response, binarise
//     it and compress it with Lempel-Ziv. Rich but not random responses (high) vs stereotyped or dead ones (low).
//   - Integration (a crude relative of IIT's phi): how much information the two halves of the core share, taking the weakest
//     of several random bipartitions, so a system that falls apart into independent parts scores low.

// clone copies the dynamical state (the wiring and what was learned) so that an experiment cannot disturb the real brain.
func (b *Brain) clone() *Brain {
	c := &Brain{seed: b.seed}
	c.kcIn, c.kcW, c.kcCore, c.coreOut, c.pos, c.inhib, c.outNorm = b.kcIn, b.kcW, b.kcCore, b.coreOut, b.pos, b.inhib, b.outNorm
	c.coreS = append([][]syn(nil), b.coreS...) // the headers are copied so that an experiment may cut synapses without touching the real brain
	c.core = append([]float64(nil), b.core...)
	c.thr = make([]float64, nCore)
	c.refr = append([]int8(nil), b.refr...)
	c.fired = make([]bool, nCore)
	c.ctr = make([]float32, nCore)
	c.pool = b.pool
	c.goal, c.trace = b.goal, b.trace
	for i := range c.thr {
		c.thr[i] = 1
	}
	return c
}

// record runs ticks of steady input and returns the spike raster of the core as the list of neurons that fired on each tick.
func (b *Brain) record(x *[nIn]float64, ticks int, pulse []int) [][]int32 {
	out := make([][]int32, ticks)
	seed := uint64(12345)
	for t := 0; t < ticks; t++ {
		// the same fluctuating "weather" in every run (a deterministic jitter on the senses), so differences come from the poke only
		var xt [nIn]float64
		for i := range xt {
			seed = seed*6364136223846793005 + 1442695040888963407
			xt[i] = x[i] * (0.55 + 0.45*float64(seed>>40)/float64(1<<24))
		}
		if t == 5 { // the poke: a brief burst into some core neurons
			for _, i := range pulse {
				b.core[i] += 3
			}
		}
		b.tick(&xt)
		for i, f := range b.fired {
			if f {
				out[t] = append(out[t], int32(i))
			}
		}
	}
	return out
}

// lz76 is the Lempel-Ziv (1976) complexity of a binary sequence: how many distinct phrases it takes to write it.
func lz76(s []bool) int {
	n := len(s)
	if n == 0 {
		return 0
	}
	c, l := 1, 1
	i, k, kmax := 0, 1, 1
	for l+k <= n {
		if s[i+k-1] == s[l+k-1] {
			k++
			continue
		}
		if k > kmax {
			kmax = k
		}
		i++
		if i == l {
			c++
			l += kmax
			i, k, kmax = 0, 1, 1
		} else {
			k = 1
		}
	}
	if k != 1 {
		c++
	}
	return c
}

// Perturb pokes a copy of the brain and returns (pci, spread): pci is the normalised Lempel-Ziv complexity of the part of the
// response that the poke caused (perturbed raster XOR undisturbed raster), after Casali et al.; spread is the fraction of the
// core that changed its behaviour although it was not poked (how far the poke travelled). 0,0 = the poke changed nothing.
func (b *Brain) Perturb(situation map[string]float64) (pci, spread float64) {
	b.mu.Lock()
	a, p := b.clone(), b.clone()
	b.mu.Unlock()
	var x [nIn]float64
	for i, n := range Channels {
		x[i] = situation[n]
	}
	const ticks = 60
	pulse := []int{3, 117, 442, 888, 1203, 1511, 1999, 2301, 2750, 3333, 3901, 4444, 4906, 5230, 5599, 5873}
	poked := map[int]bool{}
	for _, i := range pulse {
		poked[i] = true
	}
	base := a.record(&x, ticks, nil)
	pert := p.record(&x, ticks, pulse)
	var seq []bool
	ones := 0
	touched := map[int32]bool{}
	mark := make([]int8, nCore) // 1 = fired in the undisturbed run, 2 = in the poked run
	for t := 5; t < ticks; t++ {
		for _, i := range base[t] {
			mark[i] |= 1
		}
		for _, i := range pert[t] {
			mark[i] |= 2
		}
		for i := 0; i < nCore; i++ {
			d := mark[i] == 1 || mark[i] == 2
			if d && !poked[i] {
				touched[int32(i)] = true
			}
			if i%(nCore/1100) == 0 || poked[i] { // the complexity is measured on a fixed sample of sources (as PCI does), not on every neuron
				seq = append(seq, d)
				if d {
					ones++
				}
			}
		}
		for _, i := range base[t] {
			mark[i] = 0
		}
		for _, i := range pert[t] {
			mark[i] = 0
		}
	}
	spread = float64(len(touched)) / float64(nCore-len(pulse))
	n := len(seq)
	if ones == 0 || ones == n {
		return 0, spread
	}
	q := float64(ones) / float64(n)
	h := -q*math.Log2(q) - (1-q)*math.Log2(1-q) // source entropy
	return float64(lz76(seq)) * math.Log2(float64(n)) / (float64(n) * h), spread
}

// PCI is the complexity part of Perturb.
func (b *Brain) PCI(situation map[string]float64) float64 { p, _ := b.Perturb(situation); return p }

// Integration returns the weakest mutual information (in bits) between the two halves of the core over several random
// bipartitions, using the 60 ticks of a steady-state recording; near zero means the core is effectively independent parts.
func (b *Brain) Integration(situation map[string]float64) float64 {
	b.mu.Lock()
	c := b.clone()
	b.mu.Unlock()
	var x [nIn]float64
	for i, n := range Channels {
		x[i] = situation[n]
	}
	const ticks = 200
	r := c.record(&x, ticks, nil)
	// per neuron activity words: count spikes in 5-tick bins -> activity level 0/1 (any spike)
	best := math.Inf(1)
	for trial := 0; trial < 6; trial++ {
		perm := permute(nCore, int64(trial+1))
		half := nCore / 2
		inA := make([]bool, nCore)
		for k, ni := range perm {
			inA[ni] = k < half
		}
		// activity of each half per 5-tick bin, quantised to 4 levels around its own mean (so only the co-fluctuation counts)
		const bins = 40
		var ca, cb [bins]float64
		for bn := 0; bn < bins; bn++ {
			for t := bn * 5; t < bn*5+5; t++ {
				for _, ni := range r[t] {
					if inA[ni] {
						ca[bn]++
					} else {
						cb[bn]++
					}
				}
			}
		}
		joint := [4][4]float64{}
		ma, mb := mean(ca[:]), mean(cb[:])
		for bn := 0; bn < bins; bn++ {
			joint[quant(ca[bn], ma)][quant(cb[bn], mb)]++
		}
		best = math.Min(best, mutualInfo(joint, bins))
	}
	if math.IsInf(best, 1) {
		return 0
	}
	return best
}

func quant(c, mean float64) int {
	switch {
	case c < 0.85*mean:
		return 0
	case c < mean:
		return 1
	case c < 1.15*mean:
		return 2
	}
	return 3
}

func mean(v []float64) float64 {
	s := 0.0
	for _, x := range v {
		s += x
	}
	return s / float64(len(v))
}

func mutualInfo(j [4][4]float64, n float64) float64 {
	var pa, pb [4]float64
	for a := 0; a < 4; a++ {
		for bb := 0; bb < 4; bb++ {
			pa[a] += j[a][bb] / n
			pb[bb] += j[a][bb] / n
		}
	}
	mi := 0.0
	for a := 0; a < 4; a++ {
		for bb := 0; bb < 4; bb++ {
			if p := j[a][bb] / n; p > 0 {
				mi += p * math.Log2(p/(pa[a]*pb[bb]))
			}
		}
	}
	return mi
}

func permute(n int, seed int64) []int {
	p := make([]int, n)
	for i := range p {
		p[i] = i
	}
	s := uint64(seed)*6364136223846793005 + 1442695040888963407
	for i := n - 1; i > 0; i-- {
		s = s*6364136223846793005 + 1442695040888963407
		j := int(s>>33) % (i + 1)
		p[i], p[j] = p[j], p[i]
	}
	return p
}

// Report runs the experiments on the real wiring and on ablated copies and returns a readable summary:
// the normal brain, a brain with the recurrent core cut (feed-forward only) and a brain with shuffled wiring.
func (b *Brain) Report(situation map[string]float64) string {
	s := func(name string, bb *Brain) string {
		p, sp := bb.Perturb(situation)
		return name + ": PCI " + f2(p) + ", spread " + f2(sp) + ", integration " + f2(bb.Integration(situation)) + " bits\n"
	}
	b.mu.Lock()
	cut := b.clone()
	b.mu.Unlock()
	for i := range cut.coreS {
		cut.coreS[i] = nil
	}
	return s("her brain", b) + s("recurrence cut (feed-forward only)", cut) +
		"How to read it: spread = how far one poke travels through the core (0 = it dies where it was made); integration = bits the two halves of the core share, " +
		"the weakest of 6 random splits (crude, shared input inflates it a little); PCI is entropy-normalised, so a response of a few lonely neurons can score high: look at spread first."
}

func f2(v float64) string { return trimFloat(v) }
