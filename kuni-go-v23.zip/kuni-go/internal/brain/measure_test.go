package brain

import (
	"fmt"
	"testing"
)

func TestMeasuresAndAblation(t *testing.T) {
	b := New("", 20201026)
	sit := map[string]float64{"social": 1, "owner": 1, "praise": 0.6}
	pci := b.PCI(sit)
	integ := b.Integration(sit)
	fmt.Println(b.Report(sit))
	if pci <= 0 {
		t.Fatalf("a poke must leave a trace: PCI %.3f", pci)
	}
	if pci != b.PCI(sit) {
		t.Fatal("the measure must be deterministic")
	}
	if integ <= 0 {
		t.Fatalf("a core driven by a living world must share information between its halves: %.3f", integ)
	}
	cut := b.clone()
	for i := range cut.coreS {
		cut.coreS[i] = nil
	}
	_, sp := b.Perturb(sit)
	_, cs := cut.Perturb(sit)
	if cs >= sp || sp <= 0 {
		t.Fatalf("cutting the recurrence must shorten the way a poke travels: whole %.3f, cut %.3f", sp, cs)
	}
}

func TestLZ76(t *testing.T) {
	if lz76([]bool{true, true, true, true, true, true, true, true}) >= lz76([]bool{true, false, false, true, true, false, true, false}) {
		t.Fatal("a constant sequence must be simpler than a varied one")
	}
}

func TestWorkspaceCompetition(t *testing.T) {
	w := NewWorkspace(2)
	bids := []Candidate{{"perception", "вопрос про код", 0.8}, {"emotion", "настроение низкое", 0.5}, {"bond", "мой человек здесь", 0.4}, {"memory", "ничего", 0}}
	win := w.Compete(bids)
	if len(win) != 2 || win[0].Source != "perception" || win[1].Source != "emotion" {
		t.Fatalf("limited bandwidth: only the two strongest get in: %+v", win)
	}
	// inertia: a slightly weaker bid that holds the floor beats a slightly stronger newcomer, until it tires
	w = NewWorkspace(1)
	w.Compete([]Candidate{{"a", "x", 0.5}})
	if win = w.Compete([]Candidate{{"a", "x", 0.5}, {"b", "y", 0.58}}); win[0].Source != "a" {
		t.Fatal("inertia should hold the floor")
	}
	for i := 0; i < 8; i++ {
		win = w.Compete([]Candidate{{"a", "x", 0.5}, {"b", "y", 0.58}})
	}
	if win[0].Source != "b" {
		t.Fatal("a thought that held the floor too long must tire")
	}
	if Render(nil) != "" || Render(win) == "" {
		t.Fatal("render")
	}
}
