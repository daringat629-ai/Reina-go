package brain

import (
	"bytes"
	"compress/gzip"
	_ "embed"
	"encoding/binary"
	"encoding/json"
	"math"
	"net/http"
	"strconv"
	"strings"
	"sync"
)

// Structure is the small description of the brain for the 3D viewer. The heavy parts (where every neuron sits, the drawn neurites) are
// binary: PosBin and MorphBin. Global neuron index: inputs, then Kenyon cells, then core neurons, then the output neurons.
type Structure struct {
	NIn, NKC, NCore, NOut int
	Inhib                 string   `json:"inhib"` // one char per core neuron: "1" inhibitory, "0" excitatory
	Names                 []string `json:"names"` // names of inputs and outputs (inputs first, then outputs)
	Seed                  int64    `json:"seed"`
	Synapses              int      `json:"synapses"`
}

// Structure returns the description.
func (b *Brain) Structure() Structure {
	b.mu.Lock()
	defer b.mu.Unlock()
	st := Structure{NIn: nIn, NKC: nKC, NCore: nCore, NOut: nGoal, Seed: b.seed}
	for i := 0; i < nIn; i++ {
		if i < len(Channels) {
			st.Names = append(st.Names, Channels[i])
		} else {
			st.Names = append(st.Names, "")
		}
	}
	for d := 0; d < nGoal; d++ {
		st.Names = append(st.Names, Drives[d])
	}
	sb := make([]byte, nCore)
	for i := range sb {
		sb[i] = '0'
		if b.inhib[i] {
			sb[i] = '1'
		}
		st.Synapses += len(b.coreS[i])
	}
	st.Inhib = string(sb)
	return st
}

// PosBin is the place of every neuron: float32 little-endian x,y,z, in the global order.
func (b *Brain) PosBin() []byte {
	b.mu.Lock()
	defer b.mu.Unlock()
	buf := make([]byte, 0, 12*(nIn+nKC+nCore+nGoal))
	put := func(p pt) {
		for _, v := range p {
			buf = binary.LittleEndian.AppendUint32(buf, math.Float32bits(v))
		}
	}
	for i := 0; i < nIn; i++ {
		put(b.inPos[i])
	}
	for k := 0; k < nKC; k++ {
		put(b.kcPos[k])
	}
	for i := 0; i < nCore; i++ {
		put(b.pos[i])
	}
	for d := 0; d < nGoal; d++ {
		put(dnPos(d))
	}
	return buf
}

// MorphBin draws the neurons as segments, 20 bytes each: six int16 (x0 y0 z0 x1 y1 z1, 1/8000 unit), uint32 global index, then t0, t1 (0..255 of
// the distance from the soma) and kind (0 dendrite, 1 axon, 2 sensory axon). One core neuron in lod is drawn (and one Kenyon cell in lod/4);
// all output neurons are. These are exactly the shapes the wiring was found from.
func (b *Brain) MorphBin(lod int) []byte {
	if lod < 1 {
		lod = 1
	}
	b.mu.Lock()
	defer b.mu.Unlock()
	var buf []byte
	buf = binary.LittleEndian.AppendUint32(buf, 0)
	n := 0
	q := func(v float32) int16 { return int16(math.Max(-32000, math.Min(32000, math.Round(float64(v)*8000)))) }
	seg := func(id int) emitFn {
		return func(a, c pt, kind uint8, t0, t1 float32) {
			for _, v := range a {
				buf = binary.LittleEndian.AppendUint16(buf, uint16(q(v)))
			}
			for _, v := range c {
				buf = binary.LittleEndian.AppendUint16(buf, uint16(q(v)))
			}
			buf = binary.LittleEndian.AppendUint32(buf, uint32(id))
			buf = append(buf, uint8(t0*255), uint8(t1*255), kind, 0)
			n++
		}
	}
	var dend, bout []pt
	for i := 0; i < nCore; i += lod {
		dend, bout = b.coreShape(i, seg(nIn+nKC+i), dend, bout)
	}
	klod := max(1, lod/4)
	for k := 0; k < nKC; k += klod {
		bout = b.kcShape(k, seg(nIn+k), bout)
		for _, c := range b.kcIn[k] {
			seg(int(c))(b.inPos[c], b.kcPos[k], 2, 0, 1)
		}
	}
	for d := 0; d < nGoal; d++ {
		b.dnShape(d, seg(nIn+nKC+nCore+d))
	}
	binary.LittleEndian.PutUint32(buf, uint32(n))
	return buf
}

// State is the live activity: who is firing now. Replayed from a copy of the brain so that watching never changes her.
type State struct {
	Fired  []int     `json:"fired"` // global indices that spiked
	Goal   []float64 `json:"goal"`
	Drives []Drive   `json:"drives"`
	Ticks  int64     `json:"ticks"`
}

// State runs one more tick of the last situation on a copy and reports which neurons spiked (the Kenyon cells of the last real tick included).
func (b *Brain) State() State {
	b.mu.Lock()
	c := b.clone()
	c.lastIn = b.lastIn
	st := State{Ticks: b.Ticks, Drives: b.drivesLocked(), Goal: append([]float64(nil), b.goal[:]...)}
	kc := append([]int(nil), b.lastKC...)
	b.mu.Unlock()
	x := c.lastIn
	c.tick(&x)
	for i := 0; i < nCore; i++ {
		if c.fired[i] {
			st.Fired = append(st.Fired, nIn+nKC+i)
		}
	}
	for _, k := range kc {
		st.Fired = append(st.Fired, nIn+k)
	}
	for i := 0; i < nIn; i++ {
		if x[i] > 0.25 {
			st.Fired = append(st.Fired, i)
		}
	}
	return st
}

var (
	morphMu    sync.Mutex
	morphCache = map[*Brain]map[int][]byte{}
)

func (b *Brain) morphCached(lod int) []byte {
	morphMu.Lock()
	defer morphMu.Unlock()
	m := morphCache[b]
	if m == nil {
		m = map[int][]byte{}
		morphCache[b] = m
	}
	if v, ok := m[lod]; ok {
		return v
	}
	if len(m) >= 3 {
		clear(m)
	}
	v := b.MorphBin(lod)
	m[lod] = v
	return v
}

func gz(w http.ResponseWriter, r *http.Request, ctype string, data []byte) {
	w.Header().Set("Content-Type", ctype)
	w.Header().Set("Cache-Control", "private, max-age=300")
	if strings.Contains(r.Header.Get("Accept-Encoding"), "gzip") {
		w.Header().Set("Content-Encoding", "gzip")
		zw, _ := gzip.NewWriterLevel(w, gzip.BestSpeed)
		_, _ = zw.Write(data)
		_ = zw.Close()
		return
	}
	_, _ = bytes.NewReader(data).WriteTo(w)
}

// Handler serves the 3D viewer: GET .../ is the page, structure.json the description, pos.bin and morph.bin?lod=N the shapes, state.json the live activity.
func (b *Brain) Handler() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("/structure.json", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("Cache-Control", "private, max-age=300")
		_ = json.NewEncoder(w).Encode(b.Structure())
	})
	mux.HandleFunc("/pos.bin", func(w http.ResponseWriter, r *http.Request) {
		gz(w, r, "application/octet-stream", b.PosBin())
	})
	mux.HandleFunc("/morph.bin", func(w http.ResponseWriter, r *http.Request) {
		lod, _ := strconv.Atoi(r.URL.Query().Get("lod"))
		if lod < 8 {
			lod = 8
		}
		if lod > 200 {
			lod = 200
		}
		gz(w, r, "application/octet-stream", b.morphCached(lod))
	})
	mux.HandleFunc("/state.json", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("Cache-Control", "no-store")
		_ = json.NewEncoder(w).Encode(b.State())
	})
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Header().Set("Cache-Control", "no-store")
		_, _ = w.Write(vizHTML)
	})
	return mux
}

//go:embed viz.html
var vizHTML []byte
