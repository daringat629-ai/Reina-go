package brain

import (
	"encoding/json"
	"fmt"
	"os"
	"sort"
	"strings"
	"sync"
	"time"
)

// Workspace is a global workspace in the sense of Baars / Dehaene and of Goyal et al. ("Coordination among neural modules
// through a shared global workspace", ICLR 2022): specialist modules (perception, emotion, memory, drives, self...) do not talk to
// each other directly; they COMPETE for a few slots of a bandwidth-limited workspace, and whatever wins is broadcast back to
// everybody, i.e. it becomes what she is "attending to" this very turn. Winners keep the floor for a while (inertia) and then tire,
// so attention moves on.
type Workspace struct {
	mu      sync.Mutex
	Slots   int
	streak  map[string]int // consecutive cycles in the focus, per source
	journal string
}

// Candidate is one specialist's bid for the workspace.
type Candidate struct {
	Source   string
	Text     string
	Salience float64 // 0..1
}

// NewWorkspace makes a workspace with the given number of slots (the bottleneck; 3 by default).
func NewWorkspace(slots int) *Workspace {
	if slots < 1 {
		slots = 3
	}
	return &Workspace{Slots: slots, streak: map[string]int{}}
}

// SetJournal appends every broadcast as a JSON line to path.
func (w *Workspace) SetJournal(path string) { w.mu.Lock(); w.journal = path; w.mu.Unlock() }

// Compete picks the winners among the bids and broadcasts them. The score is salience plus the inertia of a source that
// already holds the floor, minus its tiredness after a long hold.
func (w *Workspace) Compete(bids []Candidate) []Candidate {
	w.mu.Lock()
	defer w.mu.Unlock()
	type scored struct {
		c Candidate
		s float64
	}
	var all []scored
	for _, c := range bids {
		if c.Text == "" || c.Salience <= 0 {
			continue
		}
		s := c.Salience
		if n := w.streak[c.Source]; n > 0 {
			s += 0.15                        // inertia: the thought in focus keeps the floor
			s -= 0.07 * float64(max(0, n-2)) // ...but tires
		}
		all = append(all, scored{c, s})
	}
	sort.SliceStable(all, func(i, j int) bool { return all[i].s > all[j].s })
	var win []Candidate
	next := map[string]int{}
	for i := 0; i < len(all) && i < w.Slots; i++ {
		if all[i].s < 0.15 { // nothing is worth the bandwidth
			break
		}
		win = append(win, all[i].c)
		next[all[i].c.Source] = w.streak[all[i].c.Source] + 1
	}
	w.streak = next
	w.logLocked(win, len(all))
	return win
}

func (w *Workspace) logLocked(win []Candidate, bids int) {
	if w.journal == "" {
		return
	}
	f, err := os.OpenFile(w.journal, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o600)
	if err != nil {
		return
	}
	defer f.Close()
	type row struct {
		Source string  `json:"source"`
		Text   string  `json:"text"`
		S      float64 `json:"s"`
	}
	var rows []row
	for _, c := range win {
		t := c.Text
		if r := []rune(t); len(r) > 100 {
			t = string(r[:100])
		}
		rows = append(rows, row{c.Source, t, c.Salience})
	}
	_ = json.NewEncoder(f).Encode(map[string]any{"t": time.Now().Format(time.RFC3339), "bids": bids, "focus": rows})
}

// Render is the <focus> block: what holds her attention now.
func Render(win []Candidate) string {
	if len(win) == 0 {
		return ""
	}
	var parts []string
	for _, c := range win {
		parts = append(parts, fmt.Sprintf("[%s] %s", c.Source, c.Text))
	}
	return "<focus>What holds your attention right now (the rest stays in the background): " + strings.Join(parts, " | ") + "</focus>\n"
}
