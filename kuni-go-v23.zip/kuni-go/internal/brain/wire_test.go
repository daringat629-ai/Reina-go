package brain

import (
	"net/http"
	"os"
	"runtime"
	"testing"
)

func TestSizeAndActivity(t *testing.T) {
	var m0, m1 runtime.MemStats
	runtime.GC()
	runtime.ReadMemStats(&m0)
	b := New("", 7)
	runtime.GC()
	runtime.ReadMemStats(&m1)
	mb := (m1.HeapAlloc - m0.HeapAlloc) >> 20
	t.Logf("memory of the whole brain: %d MB", mb)
	if mb > uint64(pick1(dense, 2200, 800)) {
		t.Fatalf("the brain must fit a 2 GB laptop: %d MB", mb)
	}
	for _, loud := range []bool{false, true} { // a quiet chat and the loudest situation possible
		var x [nIn]float64
		x[idx2("social")], x[idx2("owner")] = 1, 0.8
		if loud {
			for i := range x {
				x[i] = 1
			}
		}
		peak, last := 0, 0
		for tk := 0; tk < 60; tk++ {
			b.tick(&x)
			n := 0
			for _, f := range b.fired {
				if f {
					n++
				}
			}
			peak, last = max(peak, n), n
		}
		// a living but not exploding brain: about a quarter of a percent to a few percent of the core is active, not all of it and not none
		if last < nCore/5000 || peak > nCore/10 {
			t.Fatalf("activity out of range (loud=%v): last %d, peak %d of %d", loud, last, peak, nCore)
		}
		t.Logf("loud=%v: last %d, peak %d", loud, last, peak)
	}
	if mo, silent, mk, os := b.Stats(); mo < 60 || mo > float64(degCap) || silent > nCore/10 || mk < 5 || os < 5000 {
		t.Fatalf("wiring: %.1f synapses per neuron, %d silent, %.1f per Kenyon cell, %d output synapses", mo, silent, mk, os)
	}
}

// BRAIN_SERVE=:8099 go test -run TestServe -timeout 1h ./internal/brain  opens the viewer for development.
func TestServe(t *testing.T) {
	addr := os.Getenv("BRAIN_SERVE")
	if addr == "" {
		t.Skip("set BRAIN_SERVE to serve the viewer")
	}
	b := New("", 20201026)
	b.SenseText(map[string]float64{"social": 1, "owner": 0.8, "praise": 0.6, "novelty": 0.4}, "привет как дела расскажи мне про море")
	t.Fatal(http.ListenAndServe(addr, b.Handler()))
}
