package life

import (
	"math"
	"strings"
	"testing"
	"time"
)

func TestSheStaysInHerRoomAndOnHerFeet(t *testing.T) {
	l := New(t.TempDir(), 5)
	now := time.Now()
	hurt := 0.0
	l.Hurt = func(p float64) { hurt += p }
	goals := map[string]int{}
	for i := 0; i < 80; i++ {
		now = now.Add(3 * time.Minute)
		a := l.Decide(now, Inputs{Fatigue: .4, Sleep: .3, Drives: map[string]float64{"explore": .3, "create": .4}})
		if a == nil {
			t.Fatal("she must decide something when she is free")
		}
		goals[a.Goal]++
		for _, f := range a.Frames {
			if math.Abs(f[1]) > l.Room.HalfX || math.Abs(f[3]) > l.Room.HalfZ {
				t.Fatalf("%s: she left the room: %.0f,%.0f", a.Goal, f[1], f[3])
			}
			if f[3] > 120 {
				t.Fatal("she went to the door")
			}
		}
		for k := 1; k < len(a.Frames); k++ {
			if a.Frames[k][0] < a.Frames[k-1][0] {
				t.Fatalf("%s: time goes back at frame %d", a.Goal, k)
			}
		}
		if a.Dur <= 0 || a.Outcome == "" || a.Reason == "" {
			t.Fatalf("%+v", a)
		}
	}
	if len(goals) < 4 {
		t.Fatalf("her choices must vary: %v", goals)
	}
	t.Logf("goals %v, hurt %.2f, sit %d trials %.0f%%", goals, hurt, l.Motor.Skill("sit").Trials, func() float64 { k := l.Motor.Skill("sit"); return k.Reliability() * 100 }())
}

func TestDecisionsAreNotAScheduleButFollowTheBody(t *testing.T) {
	count := func(in Inputs) map[string]int {
		l := New(t.TempDir(), 11)
		now := time.Now()
		out := map[string]int{}
		for i := 0; i < 150; i++ {
			now = now.Add(5 * time.Minute)
			if a := l.Decide(now, in); a != nil {
				out[a.Goal]++
			}
		}
		return out
	}
	sleepy := count(Inputs{Sleep: .95, Night: true, Drives: map[string]float64{}})
	awake := count(Inputs{Drives: map[string]float64{"explore": .8}})
	if sleepy["bed"] <= awake["bed"]+10 {
		t.Fatalf("at night when sleepy she goes to bed more: %v vs %v", sleepy, awake)
	}
	if len(awake) < 30 {
		t.Fatalf("curious she tries many different things: %v", awake)
	}
}

func TestPracticeMakesHerBetterAtSittingOnTheRealChair(t *testing.T) {
	l := New(t.TempDir(), 2)
	now := time.Now()
	l.Hurt = func(float64) {}
	sit := func() (ok, n int) {
		for i := 0; i < 60; i++ {
			now = now.Add(10 * time.Minute)
			l.next = time.Time{}
			a := l.plan("practice", "тренируюсь", now)
			n++
			if a.OK {
				ok++
			}
		}
		return
	}
	b, n := sit()
	for i := 0; i < 400; i++ {
		l.plan("practice", "тренируюсь", now)
	}
	a, _ := sit()
	t.Logf("before %d/%d, after %d/%d, hurt-free chair at %.0f,%.0f", b, n, a, n, l.Room.Get("chair").Pos[0], l.Room.Get("chair").Pos[2])
	if a <= b || float64(a)/float64(n) < .6 {
		t.Fatalf("she must get better: %d -> %d of %d", b, a, n)
	}
}

func TestPromptSaysItIsLearnedAndAtHome(t *testing.T) {
	l := New(t.TempDir(), 1)
	l.Decide(time.Now(), Inputs{Drives: map[string]float64{}})
	p := l.Prompt()
	for _, w := range []string{"сама решаешь", "пробами и ошибками", "дверь закрыта"} {
		if !strings.Contains(p, w) {
			t.Fatalf("%q missing: %s", w, p)
		}
	}
}
