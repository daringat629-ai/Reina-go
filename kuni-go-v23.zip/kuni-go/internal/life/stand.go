package life

import "math"

// StandLo/StandHi bound the stand-up skill: p = [leanMax°, duration s, preLean°] (how far the trunk goes forward over the feet,
// how long it takes, how far she already leans before the hips leave the seat).
var StandLo, StandHi = []float64{0, .5, 0, 0, 0}, []float64{70, 4, 50, 0, 0}

// StandResult is one attempt to get up from a seat.
type StandResult struct {
	OK     bool
	Seated bool // she did not manage to leave the seat and sits back (no fall)
	Fell   bool
	Reward float64
	Why    string
	Frames []Frame // in seat coordinates, like SitResult
}

// StandSim judges getting up from the pose in which she sits (sit = the sit parameters she used). The same planar body as sitting:
// the weight has to be over the feet at the moment the hips leave the seat and all the way up, or she stays put or falls.
func StandSim(sit, p [5]float64, env SitEnv) StandResult {
	zf := sit[0]
	kS, sS := sit[1]*deg, sit[2]*deg
	lean0, leanMax, T := p[2]*deg, p[0]*deg, math.Max(.5, math.Min(p[1], 5))
	lo, hi := zf-4, zf+9
	dt := .02
	steps := int(T/dt) + 1
	res := StandResult{}
	left := false
	var prevCZ, effort float64
	margin := 1e9
	var last pose
	for i := 0; i <= steps; i++ {
		t := float64(i) * dt
		u := math.Min(1, t/T)
		e := smooth(u)
		k, s := kS*(1-e), sS*(1-e)
		lean := lean0*(1-e) + leanMax*math.Sin(math.Pi*u)
		hz := zf + Ls*math.Sin(s) + Lt*math.Sin(s-k)
		hy := AnkleH + Ls*math.Cos(s) + Lt*math.Cos(s-k)
		cz, cy := centreOfMass(zf, hz, hy, s, k, lean)
		vcz := 0.0
		if i > 0 {
			vcz = (cz - prevCZ) / dt
		}
		prevCZ = cz
		last = pose{hz, hy, k - s, k, lean, lean * .6}
		res.Frames = append(res.Frames, Frame{t, 0, hy, hz, 0, k - s, k - s, k, k, lean, lean * .6, 0, lean * .6, 0})
		effort += math.Abs(cz - (zf + 2))
		cp := cz + vcz*math.Sqrt(math.Max(cy, 1)/Gravity)
		if !left && hy > env.SeatY+2.5 {
			left = true
			if cp < lo-3 { // the weight stays behind the feet: the legs cannot lift her
				res.Seated, res.Why = true, "не смогла встать: вес остался позади ног, нужно сильнее наклониться вперёд"
				res.Reward = -.3 - math.Min(1, (lo-cp)/40)*.3
				return res.seatedAgain(res.Frames[:1])
			}
		}
		if left {
			margin = math.Min(margin, math.Min(cp-lo, hi-cp))
			if cp < lo-3 {
				res.Fell, res.Why = true, "упала назад при вставании"
				res.Reward = -.55 + .3*u
				res.Frames = append(res.Frames, fallFrames(last, zf, t, true)...)
				return res
			}
			if cp > hi+3 {
				res.Fell, res.Why = true, "упала вперёд при вставании: слишком наклонилась"
				res.Reward = -.55 + .3*u
				res.Frames = append(res.Frames, fallFrames(last, zf, t, false)...)
				return res
			}
		}
	}
	res.OK, res.Why = true, "встала"
	// a safe margin over the feet is part of getting up well: the fastest rise that is only just not a fall is not good
	res.Reward = .75 + .35*math.Max(0, math.Min(1, (margin+3)/10)) - T/12 - math.Min(1, effort/float64(steps)/30)*.2
	return res
}

// seatedAgain is the failed attempt: she tries, stays on the seat and holds the sitting pose for a moment.
func (r StandResult) seatedAgain(f []Frame) StandResult {
	r.Frames = nil
	for i := 0; i < int(.8*FPS); i++ {
		g := f[0]
		g[0] = float64(i) / FPS
		r.Frames = append(r.Frames, g)
	}
	return r
}
