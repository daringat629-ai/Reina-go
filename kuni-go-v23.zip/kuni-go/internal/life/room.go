// Package life is her life in her own room: a room of independent objects with hitboxes and their own physics, a body
// that learns to move by trying (falling, missing the chair, tripping, and slowly getting it right), and a will that
// decides by itself what to do. Nothing here is a canned animation: a movement is the result of parameters she has learned,
// run through a small physical simulation, and it can fail.
//
// Units are the model's own: 1 unit is about 1/53 m (she is 90 units tall). x is right, y up, z forward at yaw 0.
package life

import (
	"container/heap"
	"math"
	"sort"
	"sync"

	"kuni/internal/store"
)

// Object is one thing in the room. Every object has its own hitbox(es), its own position and, when movable, its own physics:
// it can be pushed, knocked off the desk, and it stays where it ends up.
type Object struct {
	ID      string     `json:"id"`
	Name    string     `json:"name"`
	Kind    string     `json:"kind"`
	Pos     [3]float64 `json:"pos"`  // x, floor/bottom y, z of the centre of the base
	Size    [3]float64 `json:"size"` // full width (x), height (y), depth (z) of the main body
	Yaw     float64    `json:"yaw"`  // facing, radians (a chair's front); only quarter turns keep the hitboxes exact
	Solid   bool       `json:"solid"`
	Movable bool       `json:"movable"`
	Locked  bool       `json:"locked,omitempty"`
	Aff     []string   `json:"aff,omitempty"` // what can be done with it: sit, lie, use, look, read
	SeatY   float64    `json:"seat_y,omitempty"`
	VY      float64    `json:"vy,omitempty"`
}

// Box is an axis-aligned hitbox in world coordinates.
type Box struct {
	Min [3]float64 `json:"min"`
	Max [3]float64 `json:"max"`
	Of  string     `json:"of"`
}

func (o *Object) facing() [2]float64 { return [2]float64{math.Sin(o.Yaw), math.Cos(o.Yaw)} }

// Boxes are the hitboxes of the object right now (a chair has a seat and a back).
func (o *Object) Boxes() []Box {
	hx, hz := o.Size[0]/2, o.Size[2]/2
	if q := int(math.Round(o.Yaw/(math.Pi/2))) % 2; q != 0 {
		hx, hz = hz, hx
	}
	main := Box{Min: [3]float64{o.Pos[0] - hx, o.Pos[1], o.Pos[2] - hz}, Max: [3]float64{o.Pos[0] + hx, o.Pos[1] + o.Size[1], o.Pos[2] + hz}, Of: o.ID}
	if o.Kind != "chair" {
		return []Box{main}
	}
	f := o.facing()
	bx, bz := o.Pos[0]-f[0]*(o.Size[2]/2+1.5), o.Pos[2]-f[1]*(o.Size[2]/2+1.5)
	back := Box{Min: [3]float64{bx - math.Max(1.5, math.Abs(f[1])*hx), o.Pos[1] + o.Size[1], bz - math.Max(1.5, math.Abs(f[0])*hz)},
		Max: [3]float64{bx + math.Max(1.5, math.Abs(f[1])*hx), o.Pos[1] + o.Size[1] + 22, bz + math.Max(1.5, math.Abs(f[0])*hz)}, Of: o.ID}
	return []Box{main, back}
}

// Room is the room and everything in it. Safe for concurrent use.
type Room struct {
	mu      sync.Mutex
	path    string
	HalfX   float64   `json:"half_x"`
	HalfZ   float64   `json:"half_z"`
	Objects []*Object `json:"objects"`
	saver   store.Saver
}

// DefaultObjects is her room.
func DefaultObjects() []*Object {
	return []*Object{
		{ID: "bed", Name: "кровать", Kind: "bed", Pos: [3]float64{-110, 0, -70}, Size: [3]float64{60, 26, 112}, Solid: true, Aff: []string{"lie"}},
		{ID: "desk", Name: "стол", Kind: "desk", Pos: [3]float64{100, 0, -108}, Size: [3]float64{70, 40, 34}, Solid: true, Aff: []string{"use"}},
		{ID: "chair", Name: "стул", Kind: "chair", Pos: [3]float64{100, 0, -52}, Size: [3]float64{24, 26, 24}, Yaw: math.Pi, Solid: true, Movable: true, Aff: []string{"sit"}, SeatY: 26},
		{ID: "shelf", Name: "полка с книгами", Kind: "shelf", Pos: [3]float64{-150, 0, 50}, Size: [3]float64{16, 100, 70}, Solid: true, Aff: []string{"read"}},
		{ID: "lamp", Name: "лампа", Kind: "lamp", Pos: [3]float64{140, 0, -122}, Size: [3]float64{8, 62, 8}, Solid: true, Movable: true},
		{ID: "cup", Name: "кружка", Kind: "cup", Pos: [3]float64{84, 40, -104}, Size: [3]float64{5, 6, 5}, Solid: true, Movable: true},
		{ID: "book", Name: "книга", Kind: "book", Pos: [3]float64{116, 40, -108}, Size: [3]float64{12, 3, 16}, Solid: true, Movable: true},
		{ID: "window", Name: "окно", Kind: "window", Pos: [3]float64{-30, 38, -128}, Size: [3]float64{50, 44, 2}, Aff: []string{"look"}},
		{ID: "door", Name: "дверь", Kind: "door", Pos: [3]float64{0, 0, 128}, Size: [3]float64{34, 100, 4}, Solid: true, Locked: true},
	}
}

// NewRoom loads the room (objects keep the place they were left in) or builds her default one.
func NewRoom(path string) *Room {
	r := &Room{path: path, HalfX: 160, HalfZ: 130, saver: store.Saver{What: "room"}}
	var saved struct {
		Objects []*Object `json:"objects"`
	}
	store.Load("room", path, &saved)
	r.Objects = DefaultObjects()
	for _, s := range saved.Objects {
		for i, o := range r.Objects {
			if o.ID == s.ID && o.Movable {
				r.Objects[i].Pos, r.Objects[i].Yaw = s.Pos, s.Yaw
			}
		}
	}
	return r
}

func (r *Room) save() {
	_ = r.saver.Save(r.path, struct {
		Objects []*Object `json:"objects"`
	}{r.Objects})
}

// Get is one object by id (a pointer into the room: use the room's methods to change it).
func (r *Room) Get(id string) *Object {
	r.mu.Lock()
	defer r.mu.Unlock()
	return r.get(id)
}

func (r *Room) get(id string) *Object {
	for _, o := range r.Objects {
		if o.ID == id {
			return o
		}
	}
	return nil
}

// Snapshot is a copy of the objects.
func (r *Room) Snapshot() []Object {
	r.mu.Lock()
	defer r.mu.Unlock()
	out := make([]Object, len(r.Objects))
	for i, o := range r.Objects {
		out[i] = *o
	}
	return out
}

// Hitboxes are all the boxes in the room, for drawing.
func (r *Room) Hitboxes() []Box {
	r.mu.Lock()
	defer r.mu.Unlock()
	var out []Box
	for _, o := range r.Objects {
		out = append(out, o.Boxes()...)
	}
	return out
}

// ringHit reports whether a circle of radius rad at (x,z) overlaps the box in plan.
func ringHit(b Box, x, z, rad float64) bool {
	dx := math.Max(math.Max(b.Min[0]-x, 0), x-b.Max[0])
	dz := math.Max(math.Max(b.Min[2]-z, 0), z-b.Max[2])
	return dx*dx+dz*dz < rad*rad
}

// Collide is the solid object her body (a circle of radius rad, standing on the floor) touches at (x,z); the walls count as
// a nil object with ok=false.
func (r *Room) Collide(x, z, rad float64, ignore ...string) (hit *Object, ok bool) {
	r.mu.Lock()
	defer r.mu.Unlock()
	return r.collide(x, z, rad, ignore)
}

func (r *Room) collide(x, z, rad float64, ignore []string) (*Object, bool) {
	if math.Abs(x) > r.HalfX-rad || math.Abs(z) > r.HalfZ-rad {
		return nil, false
	}
skip:
	for _, o := range r.Objects {
		if !o.Solid {
			continue
		}
		for _, id := range ignore {
			if id == o.ID {
				continue skip
			}
		}
		for _, b := range o.Boxes() {
			if b.Max[1] < 6 || b.Min[1] > 85 { // too low to matter for her body, or above her head
				continue
			}
			if ringHit(b, x, z, rad) {
				return o, true
			}
		}
	}
	return nil, true
}

// Free is true when her body fits at (x,z).
func (r *Room) Free(x, z, rad float64, ignore ...string) bool {
	h, ok := r.Collide(x, z, rad, ignore...)
	return ok && h == nil
}

// Bump pushes whatever movable object a body at (x,z) touches away along (dx,dz), if it has room to go; it reports the
// first object touched.
func (r *Room) Bump(x, z, rad, dx, dz float64) *Object {
	r.mu.Lock()
	defer r.mu.Unlock()
	h, _ := r.collide(x, z, rad, nil)
	if h == nil || !h.Movable {
		return h
	}
	n := math.Hypot(dx, dz)
	if n == 0 {
		return h
	}
	nx, nz := h.Pos[0]+dx/n*2, h.Pos[2]+dz/n*2
	if math.Abs(nx) < r.HalfX-h.Size[0]/2 && math.Abs(nz) < r.HalfZ-h.Size[2]/2 && r.objectFits(h, nx, nz) {
		h.Pos[0], h.Pos[2] = nx, nz
		r.save()
	}
	return h
}

func (r *Room) objectFits(o *Object, x, z float64) bool {
	saveX, saveZ := o.Pos[0], o.Pos[2]
	o.Pos[0], o.Pos[2] = x, z
	defer func() { o.Pos[0], o.Pos[2] = saveX, saveZ }()
	for _, p := range r.Objects {
		if p == o || !p.Solid || p.Pos[1] > o.Pos[1]+o.Size[1]-1 && p.Pos[1] > 0 || o.Pos[1] > p.Pos[1]+p.Size[1]-.5 && o.Pos[1] > 0 && false {
			continue
		}
		for _, a := range o.Boxes() {
			for _, b := range p.Boxes() {
				if a.Min[0] < b.Max[0] && a.Max[0] > b.Min[0] && a.Min[2] < b.Max[2] && a.Max[2] > b.Min[2] && a.Min[1] < b.Max[1]-.5 && a.Max[1] > b.Min[1]+.5 {
					return false
				}
			}
		}
	}
	return true
}

// Push shoves an object by hand (a knock, a bump): a movable one slides; if it is left hanging over an edge it falls on the next Step.
func (r *Room) Push(id string, dx, dz float64) bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	o := r.get(id)
	if o == nil || !o.Movable {
		return false
	}
	if r.objectFits(o, o.Pos[0]+dx, o.Pos[2]+dz) {
		o.Pos[0] += dx
		o.Pos[2] += dz
		r.save()
		return true
	}
	return false
}

// Step lets every movable object obey gravity: it rests on the floor or on the top of whatever is under it, and falls
// when nothing is.
func (r *Room) Step(dt float64) {
	r.mu.Lock()
	defer r.mu.Unlock()
	moved := false
	for _, o := range r.Objects {
		if !o.Movable {
			continue
		}
		support := 0.0
		for _, p := range r.Objects {
			if p == o || !p.Solid {
				continue
			}
			for _, b := range p.Boxes() {
				if o.Pos[0] > b.Min[0] && o.Pos[0] < b.Max[0] && o.Pos[2] > b.Min[2] && o.Pos[2] < b.Max[2] && b.Max[1] <= o.Pos[1]+.6 {
					support = math.Max(support, b.Max[1])
				}
			}
		}
		if o.Pos[1] > support+.01 {
			o.VY -= 520 * dt
			o.Pos[1] = math.Max(support, o.Pos[1]+o.VY*dt)
			moved = true
			if o.Pos[1] == support {
				o.VY = 0
			}
		}
	}
	if moved {
		r.save()
	}
}

type node struct {
	i    int
	f, g float64
}
type pq []node

func (q pq) Len() int            { return len(q) }
func (q pq) Less(i, j int) bool  { return q[i].f < q[j].f }
func (q pq) Swap(i, j int)       { q[i], q[j] = q[j], q[i] }
func (q *pq) Push(x interface{}) { *q = append(*q, x.(node)) }
func (q *pq) Pop() interface{}   { o := *q; n := o[len(o)-1]; *q = o[:len(o)-1]; return n }

const cell = 6.0

// Path is a route for a body of radius rad from (fx,fz) to (tx,tz) that stays clear of every solid hitbox (objects named in
// ignore are not obstacles: the one she walks up to). It is nil when there is none.
func (r *Room) Path(fx, fz, tx, tz, rad float64, ignore ...string) [][2]float64 {
	r.mu.Lock()
	defer r.mu.Unlock()
	nx, nz := int(2*r.HalfX/cell)+1, int(2*r.HalfZ/cell)+1
	cx := func(i int) float64 { return -r.HalfX + float64(i%nx)*cell }
	cz := func(i int) float64 { return -r.HalfZ + float64(i/nx)*cell }
	idx := func(x, z float64) int {
		ix := int(math.Round((x + r.HalfX) / cell))
		iz := int(math.Round((z + r.HalfZ) / cell))
		ix, iz = int(math.Max(0, math.Min(float64(nx-1), float64(ix)))), int(math.Max(0, math.Min(float64(nz-1), float64(iz))))
		return iz*nx + ix
	}
	free := func(i int) bool { h, ok := r.collide(cx(i), cz(i), rad, ignore); return ok && h == nil }
	s, g := idx(fx, fz), idx(tx, tz)
	if h, ok := r.collide(tx, tz, rad, ignore); !ok || h != nil {
		return nil
	}
	if !free(g) { // the grid cell nearest the goal may be blocked while the goal itself is free: take a free neighbour
		best, bd := -1, 1e9
		for dz := -1; dz <= 1; dz++ {
			for dx := -1; dx <= 1; dx++ {
				x, z := g%nx+dx, g/nx+dz
				if x < 0 || z < 0 || x >= nx || z >= nz {
					continue
				}
				if j := z*nx + x; free(j) {
					if d := math.Hypot(cx(j)-tx, cz(j)-tz); d < bd {
						best, bd = j, d
					}
				}
			}
		}
		if best < 0 {
			return nil
		}
		g = best
	}
	if !free(s) { // she may stand right against something (just got up): start from the nearest free cell within a few steps
		best, bd := -1, 1e9
		for dz := -3; dz <= 3; dz++ {
			for dx := -3; dx <= 3; dx++ {
				x, z := s%nx+dx, s/nx+dz
				if x < 0 || z < 0 || x >= nx || z >= nz {
					continue
				}
				if j := z*nx + x; free(j) {
					if d := math.Hypot(cx(j)-fx, cz(j)-fz); d < bd {
						best, bd = j, d
					}
				}
			}
		}
		if best < 0 {
			return nil
		}
		s = best
	}
	cost := map[int]float64{s: 0}
	from := map[int]int{}
	q := &pq{{s, 0, 0}}
	for q.Len() > 0 {
		n := heap.Pop(q).(node)
		if n.i == g {
			break
		}
		if n.g > cost[n.i] {
			continue
		}
		for dz := -1; dz <= 1; dz++ {
			for dx := -1; dx <= 1; dx++ {
				if dx == 0 && dz == 0 {
					continue
				}
				x, z := n.i%nx+dx, n.i/nx+dz
				if x < 0 || z < 0 || x >= nx || z >= nz {
					continue
				}
				j := z*nx + x
				if !free(j) && j != s {
					continue
				}
				c := n.g + math.Hypot(float64(dx), float64(dz))*cell
				if old, ok := cost[j]; !ok || c < old {
					cost[j], from[j] = c, n.i
					heap.Push(q, node{j, c + math.Hypot(cx(j)-tx, cz(j)-tz), c})
				}
			}
		}
	}
	if _, ok := cost[g]; !ok {
		return nil
	}
	var pts [][2]float64
	for i := g; ; {
		pts = append([][2]float64{{cx(i), cz(i)}}, pts...)
		if i == s {
			break
		}
		i = from[i]
	}
	pts[0] = [2]float64{fx, fz}
	pts[len(pts)-1] = [2]float64{tx, tz}
	// pull the string tight: keep only the corners
	clear := func(a, b [2]float64) bool {
		d := math.Hypot(b[0]-a[0], b[1]-a[1])
		for t := 0.0; t <= d; t += 3 {
			k := t / math.Max(d, 1e-9)
			if h, ok := r.collide(a[0]+(b[0]-a[0])*k, a[1]+(b[1]-a[1])*k, rad, ignore); !ok || h != nil {
				return false
			}
		}
		return true
	}
	out := [][2]float64{pts[0]}
	for i := 0; i < len(pts)-1; {
		j := len(pts) - 1
		for j > i+1 && !clear(pts[i], pts[j]) {
			j--
		}
		out = append(out, pts[j])
		i = j
	}
	return out
}

// Nearest is the object with that affordance closest to (x,z), or nil.
func (r *Room) Nearest(aff string, x, z float64) *Object {
	r.mu.Lock()
	defer r.mu.Unlock()
	var best []*Object
	for _, o := range r.Objects {
		for _, a := range o.Aff {
			if a == aff {
				best = append(best, o)
			}
		}
	}
	sort.Slice(best, func(i, j int) bool {
		return math.Hypot(best[i].Pos[0]-x, best[i].Pos[2]-z) < math.Hypot(best[j].Pos[0]-x, best[j].Pos[2]-z)
	})
	if len(best) == 0 {
		return nil
	}
	return best[0]
}

// Place puts an object at (x,z) on whatever is under it (the floor or the top of another object): false if it does not fit there.
func (r *Room) Place(id string, x, z float64) bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	o := r.get(id)
	if o == nil || !o.Movable {
		return false
	}
	top := 0.0
	for _, p := range r.Objects {
		if p == o || !p.Solid {
			continue
		}
		for _, b := range p.Boxes() {
			if x > b.Min[0] && x < b.Max[0] && z > b.Min[2] && z < b.Max[2] && b.Max[1] <= 60 {
				top = math.Max(top, b.Max[1])
			}
		}
	}
	oy := o.Pos[1]
	o.Pos[1] = top
	if math.Abs(x) > r.HalfX-o.Size[0]/2 || math.Abs(z) > r.HalfZ-o.Size[2]/2 || !r.objectFits(o, x, z) {
		o.Pos[1] = oy
		return false
	}
	o.Pos[0], o.Pos[2], o.VY = x, z, 0
	r.save()
	return true
}

// CanMove is true when a movable object would fit after being pushed by (dx,dz).
func (r *Room) CanMove(id string, dx, dz float64) bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	o := r.get(id)
	return o != nil && o.Movable && math.Abs(o.Pos[0]+dx) < r.HalfX-o.Size[0]/2 && math.Abs(o.Pos[2]+dz) < r.HalfZ-o.Size[2]/2 && r.objectFits(o, o.Pos[0]+dx, o.Pos[2]+dz)
}

// Top is the surface of an object: the box of its main body.
func (r *Room) Top(id string) (Box, bool) {
	r.mu.Lock()
	defer r.mu.Unlock()
	o := r.get(id)
	if o == nil {
		return Box{}, false
	}
	return o.Boxes()[0], true
}

// Add puts a new object in the room (she, or you, can furnish it further); ids are unique.
func (r *Room) Add(o Object) bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.get(o.ID) != nil || o.ID == "" {
		return false
	}
	r.Objects = append(r.Objects, &o)
	r.save()
	return true
}
