package life

import (
	"fmt"
	"math"
	"sort"
	"strings"
	"time"
)

// What she can do is not a list. Goals are made from the room: every object offers what can be done with it (touch it, look at
// it, push it, pick it up and put it on any other object or the floor, sit on it...), gestures have continuous parameters and are
// each learned by trying, she can invent movements out of joint keyframes, and what she has not tried attracts her. A new
// object in the room means new things to do.

// Key is a pose in a movement, angles in degrees: lean (trunk forward), knee flexion, shin forward lean, each arm forward, both
// arms lifted sideways, and spin (turn around the vertical).
type Key struct {
	T, Lean, Knee, Shin, ArmL, ArmR, Lift, Spin float64
}

// GestureLo and GestureHi are the ranges of what she tries for a gesture: amplitude, speed, lean, knee/hip-back, duration.
var (
	GestureLo = []float64{.2, .5, 0, 0, 1}
	GestureHi = []float64{1.3, 2.5, 60, 100, 5}
)

type gesture func(u float64, p [5]float64) Key

func bump(u float64) float64 { return math.Sin(math.Pi * math.Min(1, math.Max(0, u))) }

// gestures are movements with free parameters: each is a function of time, so every draw of parameters is a different movement.
var gestures = map[string]gesture{
	"wave": func(u float64, p [5]float64) Key {
		return Key{Lift: p[0] * 100 * bump(u*1.0), ArmL: p[0] * 25 * math.Sin(2*math.Pi*p[1]*u*p[4]), ArmR: -p[0] * 25 * math.Sin(2*math.Pi*p[1]*u*p[4])}
	},
	"stretch": func(u float64, p [5]float64) Key {
		e := bump(u)
		return Key{Lift: math.Min(1, p[0]) * 170 * e, Lean: -p[2] * .25 * e, Shin: -p[3] * .05 * e}
	},
	"bow": func(u float64, p [5]float64) Key {
		e := bump(u)
		return Key{Lean: p[2] * e, Shin: -p[3] * .1 * e, ArmL: 10 * e, ArmR: 10 * e}
	},
	"spin": func(u float64, p [5]float64) Key {
		return Key{Spin: 360 * u, Lift: 50 * p[0] * bump(u)}
	},
	"dance": func(u float64, p [5]float64) Key {
		s := math.Sin(2 * math.Pi * p[1] * u * p[4])
		c := math.Cos(2 * math.Pi * p[1] * u * p[4])
		return Key{Lift: 40 * p[0] * (1 + s) * bump(u*1.2), ArmL: 35 * p[0] * s, ArmR: -35 * p[0] * c, Knee: p[3] * .3 * (1 + c) * bump(u), Shin: p[3] * .1 * (1 + c) * bump(u), Lean: p[2] * .2 * s, Spin: 90 * math.Sin(math.Pi*2*u)}
	},
	"squat": func(u float64, p [5]float64) Key {
		e := bump(u)
		return Key{Knee: p[3] * e, Shin: p[3] * .12 * e, Lean: p[2] * e, ArmL: 60 * e, ArmR: 60 * e}
	},
	"sway": func(u float64, p [5]float64) Key {
		s := math.Sin(2 * math.Pi * p[1] * u * p[4])
		return Key{Lean: p[0] * 8 * s * bump(u), Shin: 3 * s * bump(u), Spin: 12 * p[0] * s * bump(u)}
	},
	"lookaround": func(u float64, p [5]float64) Key {
		return Key{Spin: p[0] * 55 * math.Sin(2*math.Pi*p[1]*u) * bump(u)}
	},
	"clap": func(u float64, p [5]float64) Key {
		c := .5 + .5*math.Sin(2*math.Pi*p[1]*u*p[4])
		return Key{ArmL: 40 + 45*c*p[0], ArmR: 40 + 45*c*p[0], Lean: 4}
	},
	"curtsy": func(u float64, p [5]float64) Key {
		e := bump(u)
		return Key{Knee: p[3] * .6 * e, Shin: p[3] * .07 * e, Lean: 10 * e, ArmL: 20 * e, ArmR: 20 * e}
	},
}

// GestureNames are the gestures built in; the ones she invents are added to what she knows.
func GestureNames() []string {
	var n []string
	for k := range gestures {
		n = append(n, k)
	}
	sort.Strings(n)
	return n
}

// keyFrame is the body at a pose, standing on fixed feet at (x,z) facing yaw0, with its centre of mass for the balance check.
func keyFrame(t, x, z, yaw0 float64, k Key) (f Frame, cz, cy float64) {
	s, kn, ln := k.Shin*deg, k.Knee*deg, k.Lean*deg
	hz := Ls*math.Sin(s) + Lt*math.Sin(s-kn)
	hy := AnkleH + Ls*math.Cos(s) + Lt*math.Cos(s-kn)
	cz, cy = centreOfMass(0, hz, hy, s, kn, ln)
	cz += .1 * 20 * math.Sin(math.Max(k.ArmL, k.ArmR)*deg) // arms reaching forward shift the weight
	yaw := yaw0 + k.Spin*deg
	f = Frame{t, x + math.Sin(yaw0)*hz, hy, z + math.Cos(yaw0)*hz, yaw, kn - s, kn - s, kn, kn, ln, k.ArmL * deg, 0, k.ArmR * deg, k.Lift * deg}
	return
}

// interp is the pose at time t of keyframes (smooth between neighbours).
func interp(keys []Key, t float64) Key {
	if len(keys) == 0 {
		return Key{}
	}
	if t <= keys[0].T {
		return keys[0]
	}
	for i := 1; i < len(keys); i++ {
		if t <= keys[i].T {
			a, b := keys[i-1], keys[i]
			u := smooth((t - a.T) / math.Max(1e-6, b.T-a.T))
			l := func(x, y float64) float64 { return x + (y-x)*u }
			return Key{t, l(a.Lean, b.Lean), l(a.Knee, b.Knee), l(a.Shin, b.Shin), l(a.ArmL, b.ArmL), l(a.ArmR, b.ArmR), l(a.Lift, b.Lift), l(a.Spin, b.Spin)}
		}
	}
	return keys[len(keys)-1]
}

type bld struct {
	l  *Life
	a  *Action
	fr *[]Frame
	t  *float64
}

func (b bld) walk(tx, tz float64, ignore ...string) bool {
	l := b.l
	path := l.Room.Path(l.x, l.z, tx, tz, BodyRadius, ignore...)
	if path == nil {
		b.a.Outcome = "не нашла, как пройти"
		return false
	}
	g := l.Motor.Attempt("walk", .35)
	w, x, z, yaw, t2, res := walkFrames(path, g, *b.t, l.yaw)
	*b.fr = append(*b.fr, w...)
	*b.t, l.x, l.z, l.yaw = t2, x, z, yaw
	l.Motor.Learned("walk", g, res.Reward, res.OK, res.Why)
	if !res.OK {
		b.a.Outcome = res.Why
		l.hurt(.06)
		return false
	}
	return true
}

func (b bld) face(yaw float64) {
	tf, t2 := turn(*b.t, b.l.x, b.l.z, b.l.yaw, yaw)
	*b.fr, *b.t, b.l.yaw = append(*b.fr, tf...), t2, yaw
}

func (b bld) hold(sec float64) {
	for i := 0; i < int(sec*FPS); i++ {
		*b.t += 1 / FPS
		*b.fr = append(*b.fr, standFrame(*b.t, b.l.x, b.l.z, b.l.yaw))
	}
}

// do plays a movement given as a function of its own time, on fixed feet, and checks her balance in every frame: she can
// lose it and fall. It reports whether she stayed up.
func (b bld) do(key func(t float64) Key, dur float64) (ok bool, why string) {
	l := b.l
	x, z, yaw0 := l.x, l.z, l.yaw
	var prevCZ float64
	for i := 0; i <= int(dur*FPS); i++ {
		tt := float64(i) / FPS
		k := key(tt)
		f, cz, cy := keyFrame(*b.t+1/FPS, x, z, yaw0, k)
		v := 0.0
		if i > 0 {
			v = (cz - prevCZ) * FPS
		}
		prevCZ = cz
		if cp := cz + v*math.Sqrt(math.Max(cy, 1)/Gravity); cp < -5 || cp > 10 {
			back := cp < 0
			s, kn := k.Shin*deg, k.Knee*deg
			ff := fallFrames(pose{hz: Ls*math.Sin(s) + Lt*math.Sin(s-kn), hy: f[2], th: kn - s, kn: kn, lean: k.Lean * deg, arm: k.ArmL * deg}, 0, 0, back)
			*b.fr = append(*b.fr, place(ff, x, z, yaw0, *b.t)...)
			*b.t += ff[len(ff)-1][0]
			l.x, l.z, l.yaw = x, z, yaw0
			l.hurt(.08)
			if back {
				return false, "потеряла равновесие и упала назад"
			}
			return false, "потеряла равновесие и упала вперёд"
		}
		*b.t += 1 / FPS
		f[0] = *b.t
		*b.fr = append(*b.fr, f)
		l.yaw = f[4]
	}
	return true, ""
}

// reach is the pose of an arm stretched to a height in front of her, bending the body for low things.
func reach(h float64) (Key, bool) {
	c := (71 - h) / 29
	a := math.Acos(math.Max(-1, math.Min(1, c))) / deg
	k := Key{ArmL: math.Max(10, math.Min(110, a)), ArmR: math.Max(10, math.Min(110, a))}
	if h < 50 {
		k.Lean = math.Min(40, (50-h)*.8)
	}
	if h < 30 {
		k.Knee = math.Min(60, (30-h)*2.2)
		k.Shin = k.Knee * .3
	}
	return k, h > 3
}

func (b bld) reachTo(h, hold float64) (bool, string) {
	k, _ := reach(h)
	keys := []Key{{}, {T: .9, Lean: k.Lean, Knee: k.Knee, Shin: k.Shin, ArmL: k.ArmL, ArmR: k.ArmR}, {T: .9 + hold, Lean: k.Lean, Knee: k.Knee, Shin: k.Shin, ArmL: k.ArmL, ArmR: k.ArmR}, {T: 1.9 + hold}}
	return b.do(func(t float64) Key { return interp(keys, t) }, keys[3].T)
}

// approach is a place to stand next to an object, close enough to touch it, and the way to face it.
func (l *Life) approach(id string, gap float64) (x, z, yaw float64, ok bool) {
	obj := l.Room.Get(id)
	bx, found := l.Room.Top(id)
	if !found || obj == nil {
		return
	}
	target := [2]float64{obj.Pos[0], obj.Pos[2]}
	if obj.Pos[1] > 1 { // it lies on something: she stands next to what it lies on and reaches over
		for _, o := range l.Room.Snapshot() {
			if o.ID != id && o.Solid {
				if sb := o.Boxes()[0]; target[0] > sb.Min[0] && target[0] < sb.Max[0] && target[1] > sb.Min[2] && target[1] < sb.Max[2] && math.Abs(sb.Max[1]-obj.Pos[1]) < 1 {
					bx = sb
					break
				}
			}
		}
	}
	cx, cz := (bx.Min[0]+bx.Max[0])/2, (bx.Min[2]+bx.Max[2])/2
	best := 1e9
	for th := 0.0; th < 2*math.Pi; th += math.Pi / 12 {
		for r := 4.0; r < 120; r++ {
			px, pz := cx+r*math.Cos(th), cz+r*math.Sin(th)
			if ringHit(bx, px, pz, BodyRadius+gap) {
				continue
			}
			if l.Room.Free(px, pz, BodyRadius, id) {
				if d := math.Hypot(px-l.x, pz-l.z); d < best {
					best, x, z, ok = d, px, pz, true
				}
			}
			break
		}
	}
	yaw = math.Atan2(target[0]-x, target[1]-z) // she faces the thing itself
	return
}

func (l *Life) height(id string) float64 {
	o := l.Room.Get(id)
	if o == nil {
		return 40
	}
	return o.Pos[1] + o.Size[1]/2
}

type phase struct {
	t0, t1 float64
	mode   string // rest, grab, carry, put
	from   [3]float64
	to     [3]float64
}

// tracks turns the phases of a carried object into its position in every frame.
func tracks(id string, fr []Frame, ph []phase) Prop {
	p := Prop{ID: id}
	chest := func(f Frame) [3]float64 { return [3]float64{f[1] + math.Sin(f[4])*40, 50, f[3] + math.Cos(f[4])*40} }
	for _, f := range fr {
		pos := ph[len(ph)-1].to
		for _, q := range ph {
			if f[0] <= q.t1 {
				u := math.Min(1, math.Max(0, (f[0]-q.t0)/math.Max(1e-6, q.t1-q.t0)))
				switch q.mode {
				case "rest":
					pos = q.from
				case "grab":
					c := chest(f)
					for i := range pos {
						pos[i] = q.from[i] + (c[i]-q.from[i])*smooth(u)
					}
				case "carry":
					pos = chest(f)
				case "put":
					c := chest(f)
					for i := range pos {
						pos[i] = c[i] + (q.to[i]-c[i])*smooth(u)
					}
				case "slide":
					for i := range pos {
						pos[i] = q.from[i] + (q.to[i]-q.from[i])*u
					}
				}
				break
			}
		}
		p.Frames = append(p.Frames, [4]float64{f[0], pos[0], pos[1], pos[2]})
	}
	return p
}

// Prop is the path of an object that she carries or pushes, in the same time as the frames.
type Prop struct {
	ID     string       `json:"id"`
	Frames [][4]float64 `json:"frames"`
}

// open plans a goal of the open kind: verb:target, g:gesture, keys:name, visit:x,z. It reports whether the goal is one of those.
func (l *Life) open(goal string, a *Action, fr *[]Frame, t *float64, now time.Time) bool {
	b := bld{l, a, fr, t}
	verb, arg, _ := strings.Cut(goal, ":")
	switch verb {
	case "g":
		l.Motor.Ensure("g:"+arg, GestureLo, GestureHi)
		g, known := gestures[arg]
		var custom []Key
		if !known {
			custom = l.custom[arg]
			if custom == nil {
				a.Outcome = "не знаю такого движения"
				return true
			}
		}
		p := l.Motor.Attempt("g:"+arg, .5)
		dur := p[4]
		fn := func(tt float64) Key { return g(math.Min(1, tt/dur), p) }
		if !known {
			dur = custom[len(custom)-1].T / math.Max(.4, p[1]/1.5)
			fn = func(tt float64) Key {
				k := interp(custom, tt*math.Max(.4, p[1]/1.5))
				k.Lean, k.Knee, k.Shin, k.ArmL, k.ArmR, k.Lift = k.Lean*p[0], k.Knee*p[0], k.Shin*p[0], k.ArmL*p[0], k.ArmR*p[0], k.Lift*p[0]
				return k
			}
		}
		ok, why := b.do(fn, dur)
		rw := 1 - dur/12
		if !ok {
			rw = -.5
		} else {
			why = "получилось"
		}
		l.Motor.Learned("g:"+arg, p, rw, ok, why)
		a.OK, a.Outcome = ok, arg+": "+why
		// a wave does not leave a mark on the world, but she has done it once more
	case "visit":
		var x, z float64
		if _, err := fmt.Sscanf(arg, "%f,%f", &x, &z); err == nil && l.Room.Free(x, z, BodyRadius) {
			if b.walk(x, z) {
				a.OK, a.Outcome = true, "дошла до выбранного места"
			}
		} else {
			a.Outcome = "туда не встать"
		}
	case "look", "touch", "knock":
		gap := 8.0
		if verb == "look" {
			gap = 26
		}
		x, z, yaw, ok := l.approach(arg, gap)
		if !ok || !b.walk(x, z, append([]string{arg}, l.supports(arg)...)...) {
			if a.Outcome == "" {
				a.Outcome = "не подойти"
			}
			return true
		}
		b.face(yaw)
		if verb == "look" {
			b.hold(2.5 + l.rng.Float64()*3)
			a.OK, a.Outcome = true, "посмотрела на "+l.nameOf(arg)
			return true
		}
		ok2, why := b.reachTo(l.height(arg), .7)
		if !ok2 {
			a.Outcome = why
			return true
		}
		a.OK, a.Outcome = true, "потрогала "+l.nameOf(arg)
		if verb == "knock" {
			a.Outcome = "постучала в " + l.nameOf(arg) + ": заперто, мне туда нельзя"
		}
	case "push":
		o := l.Room.Get(arg)
		if o == nil {
			return true
		}
		dirs := [][2]float64{{1, 0}, {-1, 0}, {0, 1}, {0, -1}}
		d := dirs[l.rng.Intn(4)]
		dist := 10 + l.rng.Float64()*25
		r := math.Max(o.Size[0], o.Size[2])/2 + BodyRadius + 2
		px, pz := o.Pos[0]-d[0]*r, o.Pos[2]-d[1]*r
		if !l.Room.Free(px, pz, BodyRadius, arg) || !b.walk(px, pz, arg) {
			if a.Outcome == "" {
				a.Outcome = "не нашла, откуда толкать"
			}
			return true
		}
		yaw := math.Atan2(d[0], d[1])
		b.face(yaw)
		if !o.Movable || !l.Room.CanMove(arg, d[0]*dist, d[1]*dist) {
			ok2, _ := b.reachTo(l.height(arg), 1.5)
			if ok2 {
				a.Outcome = l.nameOf(arg) + " не сдвинулась: слишком тяжёлая или упирается"
			}
			return true
		}
		i0 := len(*fr)
		t0 := *t
		start := [3]float64{o.Pos[0], o.Pos[1] + o.Size[1]/2, o.Pos[2]}
		end := [3]float64{o.Pos[0] + d[0]*dist, start[1], o.Pos[2] + d[1]*dist}
		k := Key{ArmL: 70, ArmR: 70, Lean: 12}
		b.do(func(tt float64) Key { return interp([]Key{{}, {T: .6, ArmL: k.ArmL, ArmR: k.ArmR, Lean: k.Lean}}, tt) }, .6)
		// she walks forward with the object ahead of her, arms out
		steps := int(dist / 35 * FPS)
		x, z := l.x, l.z
		for i := 1; i <= steps; i++ {
			u := float64(i) / float64(steps)
			*t += 1 / FPS
			ph := 2 * math.Pi * 1.1 * u * dist / 35
			*fr = append(*fr, Frame{*t, x + d[0]*dist*u, 47 + .5*math.Cos(2*ph), z + d[1]*dist*u, yaw, .35 * math.Sin(ph), -.35 * math.Sin(ph), .4 * math.Max(0, math.Cos(ph)), .4 * math.Max(0, -math.Cos(ph)), 12 * deg, 70 * deg, 0, 70 * deg, 0})
		}
		l.x, l.z = x+d[0]*dist, z+d[1]*dist
		pr := tracks(arg, (*fr)[i0:], []phase{{t0, t0 + .6, "rest", start, start}, {t0 + .6, *t, "slide", start, end}, {*t, *t + 99, "rest", end, end}})
		a.Props = append(a.Props, pr)
		l.later = append(l.later, func() { l.Room.Push(arg, d[0]*dist, d[1]*dist) })
		b.hold(.5)
		a.OK, a.Outcome = true, "подвинула "+l.nameOf(arg)
	case "pick":
		id, dest, _ := strings.Cut(arg, ">")
		o := l.Room.Get(id)
		if o == nil || !o.Movable || math.Max(o.Size[0], o.Size[2]) > 16 || o.Size[1] > 16 {
			a.Outcome = "это не поднять"
			return true
		}
		x, z, yaw, ok := l.approach(id, 5)
		if !ok || !b.walk(x, z, append([]string{id}, l.supports(id)...)...) {
			if a.Outcome == "" {
				a.Outcome = "не подойти"
			}
			return true
		}
		b.face(yaw)
		start := [3]float64{o.Pos[0], o.Pos[1] + o.Size[1]/2, o.Pos[2]}
		iA := len(*fr)
		tA := *t
		if ok2, why := b.reachTo(start[1], .3); !ok2 {
			a.Outcome = why
			return true
		}
		tGrab := tA + .9
		// where to put it
		var tx, tz, ty float64
		var dx, dz, dyaw float64
		if strings.HasPrefix(dest, "@") {
			f := [2]float64{math.Sin(l.yaw), math.Cos(l.yaw)}
			var rx, rz float64
			if _, err := fmt.Sscanf(dest[1:], "%f,%f", &rx, &rz); err != nil || !l.Room.Free(rx, rz, BodyRadius) {
				a.Outcome = "некуда положить"
				return true
			}
			dx, dz, dyaw = rx, rz, math.Atan2(f[0], f[1])
			tx, tz, ty = rx+math.Sin(l.yaw)*20, rz+math.Cos(l.yaw)*20, o.Size[1]/2
			if !l.Room.Free(tx, tz, 3) {
				a.Outcome = "некуда положить"
				return true
			}
		} else {
			bx, okb := l.Room.Top(dest)
			if !okb {
				a.Outcome = "некуда положить"
				return true
			}
			var okp bool
			dx, dz, dyaw, okp = l.approach(dest, 4)
			if !okp {
				a.Outcome = "не подойти к " + l.nameOf(dest)
				return true
			}
			tx, tz = math.Max(bx.Min[0]+o.Size[0]/2+1, math.Min(bx.Max[0]-o.Size[0]/2-1, dx)), math.Max(bx.Min[2]+o.Size[2]/2+1, math.Min(bx.Max[2]-o.Size[2]/2-1, dz))
			ty = bx.Max[1] + o.Size[1]/2
		}
		if !b.walk(dx, dz, dest) {
			return true
		}
		b.face(dyaw)
		tR := *t
		iR := len(*fr)
		if ok2, why := b.reachTo(ty, .3); !ok2 {
			a.Outcome = why
			return true
		}
		tRel := tR + .9
		end := [3]float64{tx, ty, tz}
		pr := tracks(id, (*fr)[iA:], []phase{{tA, tGrab, "rest", start, start}, {tGrab, tGrab + .4, "grab", start, start}, {tGrab + .4, tRel - .01, "carry", start, start}, {tRel, tRel + .4, "put", start, end}, {tRel + .4, *t + 99, "rest", end, end}})
		_ = iR
		// both arms come forward and hold the thing in her hands while she carries it
		for i := iA; i < len(*fr); i++ {
			f := &(*fr)[i]
			w := math.Min(smooth(math.Min(1, math.Max(0, (f[0]-tGrab)/.4))), 1-smooth(math.Min(1, math.Max(0, (f[0]-tRel)/.4))))
			if w > 0 {
				f[10] = math.Max(f[10], 1.0*w)
				f[12] = math.Max(f[12], 1.0*w)
			}
		}
		a.Props = append(a.Props, pr)
		l.later = append(l.later, func() { l.Room.Place(id, tx, tz) })
		a.OK, a.Outcome = true, "взяла "+l.nameOf(id)+" и положила на "+l.nameOfDest(dest)
	default:
		return false
	}
	return true
}

func (l *Life) nameOf(id string) string {
	if o := l.Room.Get(id); o != nil {
		return o.Name
	}
	return id
}

func (l *Life) nameOfDest(d string) string {
	if strings.HasPrefix(d, "@") {
		return "пол"
	}
	return l.nameOf(d)
}

type choice struct {
	goal, why string
	u         float64
}

// candidates are the things she could do now: everything the room offers, the gestures, the movements she invented, and walking
// to any spot. A random handful is weighed each time, so the space is open-ended.
func (l *Life) candidates(in Inputs) []choice {
	d := func(n string) float64 { return in.Drives[n] }
	curious := .4 + d("explore") + .4*d("create")
	novel := func(key string) float64 { return 1.1 / math.Sqrt(1+float64(l.Motor.Times(key))) * curious }
	lazy := 1 - .6*in.Fatigue
	var cs []choice
	add := func(goal, why string, base float64) {
		cs = append(cs, choice{goal, why, (base + novel(goal)) * lazy})
	}
	objs := l.Room.Snapshot()
	for _, o := range objs {
		if o.Kind == "window" || o.Kind == "door" {
			add("look:"+o.ID, "хочу посмотреть на "+o.Name, .15+.4*d("explore"))
		}
		if o.Kind == "door" {
			add("knock:"+o.ID, "хочу постучать в "+o.Name+": что там?", .05)
			continue
		}
		if o.Solid {
			add("touch:"+o.ID, "хочу потрогать "+o.Name, .1)
			add("look:"+o.ID, "хочу рассмотреть "+o.Name, .15)
		}
		if o.Movable {
			add("push:"+o.ID, "хочу подвинуть "+o.Name, .1)
		}
		if o.Movable && math.Max(o.Size[0], o.Size[2]) <= 16 && o.Size[1] <= 16 {
			for _, dst := range objs {
				if dst.ID == o.ID || !dst.Solid || dst.Kind == "door" || dst.Pos[1]+dst.Size[1] > 45 {
					continue
				}
				add("pick:"+o.ID+">"+dst.ID, "хочу взять "+o.Name+" и положить на "+dst.Name, .08)
			}
			add(fmt.Sprintf("pick:%s>@%.0f,%.0f", o.ID, (l.rng.Float64()*2-1)*(l.Room.HalfX-40), (l.rng.Float64()*2-1)*(l.Room.HalfZ-40)), "хочу взять "+o.Name+" и положить на пол в другом месте", .05)
		}
	}
	names := GestureNames()
	for _, k := range l.Motor.Known() {
		if _, ok := gestures[k]; !ok {
			names = append(names, k)
		}
	}
	for _, g := range names {
		add("g:"+g, "хочу попробовать движение «"+g+"»", .1+.3*d("create")+.2*in.Valence)
	}
	add(fmt.Sprintf("visit:%.0f,%.0f", (l.rng.Float64()*2-1)*(l.Room.HalfX-30), (l.rng.Float64()*2-1)*(l.Room.HalfZ-30)), "хочу пройтись вон туда", .2+.3*d("explore"))
	l.rng.Shuffle(len(cs), func(i, j int) { cs[i], cs[j] = cs[j], cs[i] })
	if len(cs) > 24 {
		cs = cs[:24]
	}
	return cs
}

// Invent lets her (or you) give a movement a name and a list of keyframes; she then tries it like any other gesture, with her
// own balance deciding whether it works.
func (l *Life) Invent(name string, keys []Key) error {
	l.mu.Lock()
	defer l.mu.Unlock()
	name = strings.TrimSpace(name)
	if name == "" || len(name) > 30 || strings.ContainsAny(name, ":>,@") {
		return fmt.Errorf("bad name")
	}
	if len(keys) < 2 || len(keys) > 40 {
		return fmt.Errorf("a movement needs 2 to 40 keyframes")
	}
	sort.Slice(keys, func(i, j int) bool { return keys[i].T < keys[j].T })
	for i := range keys {
		k := &keys[i]
		k.Lean, k.Knee, k.Shin = math.Max(-60, math.Min(90, k.Lean)), math.Max(0, math.Min(130, k.Knee)), math.Max(-30, math.Min(45, k.Shin))
		k.ArmL, k.ArmR, k.Lift = math.Max(-60, math.Min(170, k.ArmL)), math.Max(-60, math.Min(170, k.ArmR)), math.Max(-20, math.Min(180, k.Lift))
		k.Spin = math.Max(-720, math.Min(720, k.Spin))
		k.T = math.Max(0, math.Min(20, k.T))
	}
	if keys[len(keys)-1].T < .5 {
		return fmt.Errorf("a movement should last at least half a second")
	}
	if l.custom == nil {
		l.custom = map[string][]Key{}
	}
	l.custom[name] = keys
	l.Motor.Ensure("g:"+name, GestureLo, GestureHi)
	return nil
}

// supports are the objects something lies on.
func (l *Life) supports(id string) []string {
	obj := l.Room.Get(id)
	if obj == nil || obj.Pos[1] <= 1 {
		return nil
	}
	var out []string
	for _, o := range l.Room.Snapshot() {
		if o.ID != id && o.Solid {
			if sb := o.Boxes()[0]; obj.Pos[0] > sb.Min[0] && obj.Pos[0] < sb.Max[0] && obj.Pos[2] > sb.Min[2] && obj.Pos[2] < sb.Max[2] && math.Abs(sb.Max[1]-obj.Pos[1]) < 1 {
				out = append(out, o.ID)
			}
		}
	}
	return out
}
