package life

import (
	"math"
	"path/filepath"
	"testing"
)

var chairEnv = SitEnv{SeatY: 26, SeatHalf: 12}

func TestPerfectSitWorksAndBadOnesFailInTheRightWay(t *testing.T) {
	good := SitSim([5]float64{10, 115, 25, 35, 2.2}, chairEnv)
	if !good.OK || good.Reward < .3 {
		t.Fatalf("a good sit must work: %+v", good.Why)
	}
	cases := map[string][5]float64{
		"назад":   {20, 90, 0, 0, .7},   // no lean, fast: the weight stays behind
		"вперёд":  {60, 100, 20, 55, 2}, // too far forward and leaning too much
		"мимо":    {45, 100, 10, 25, 2}, // stands far from the chair
		"не села": {10, 45, 0, 10, 2},   // knees do not bend enough
	}
	for name, p := range cases {
		if r := SitSim(p, chairEnv); r.OK {
			t.Errorf("%s: should not succeed (%s)", name, r.Why)
		}
	}
	if r := SitSim([5]float64{10, 115, 25, 0, .7}, chairEnv); !r.Fell || r.Frames[len(r.Frames)-1][2] != 48 {
		t.Fatal("a fall ends with her on her feet again")
	}
}

func TestSittingTooFastHurts(t *testing.T) {
	slow := SitSim([5]float64{10, 115, 25, 35, 3}, chairEnv)
	fast := SitSim([5]float64{10, 115, 25, 35, .9}, chairEnv)
	if fast.OK && fast.Impact <= slow.Impact {
		t.Fatalf("a fast sit lands harder: %.0f vs %.0f", fast.Impact, slow.Impact)
	}
}

func rate(m *Motor, name string, n int, explore float64, sit func([5]float64) (bool, float64, string)) float64 {
	ok := 0
	for i := 0; i < n; i++ {
		p := m.Attempt(name, explore)
		good, rw, why := sit(p)
		m.Learned(name, p, rw, good, why)
		if good {
			ok++
		}
	}
	return float64(ok) / float64(n)
}

func TestSheLearnsToSitByTrying(t *testing.T) {
	m := NewMotor(filepath.Join(t.TempDir(), "m.json"), 7)
	try := func(p [5]float64) (bool, float64, string) {
		r := SitSim(p, chairEnv)
		return r.OK, r.Reward, r.Why
	}
	before := rate(m, "sit", 12, 1, try)
	rate(m, "sit", 300, 1, try)
	after := rate(m, "sit", 40, .3, try)
	t.Logf("success: %.0f%% before, %.0f%% after, %d trials", before*100, after*100, m.Skill("sit").Trials)
	if after < .7 || after <= before {
		t.Fatalf("she must learn: %.2f -> %.2f", before, after)
	}
	s := m.Skill("sit")
	if s.Reliability() < .6 {
		t.Fatalf("reliability %.2f", s.Reliability())
	}
}

func TestSheLearnsToWalkWithoutTripping(t *testing.T) {
	m := NewMotor(filepath.Join(t.TempDir(), "m.json"), 3)
	try := func(p [5]float64) (bool, float64, string) {
		r := WalkSim(p)
		return r.OK, r.Reward, r.Why
	}
	rate(m, "walk", 200, 1, try)
	after := rate(m, "walk", 40, .3, try)
	if after < .7 {
		t.Fatalf("walk success %.2f", after)
	}
	mean := m.Skill("walk").Mean
	if math.Abs(mean[0]*mean[1]-70) > 30 {
		t.Fatalf("she should walk at a sensible speed, got %.0f", mean[0]*mean[1])
	}
}

func TestSkillsSurviveRestart(t *testing.T) {
	p := filepath.Join(t.TempDir(), "m.json")
	m := NewMotor(p, 1)
	m.Learned("sit", m.Attempt("sit", 1), .5, true, "села")
	if NewMotor(p, 2).Skill("sit").Trials != 1 {
		t.Fatal("what she learned must persist")
	}
}
