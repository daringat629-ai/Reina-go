package life

import (
	"math"
	"math/rand"
	"sort"
	"sync"

	"kuni/internal/store"
)

// A Frame is one 20 Hz sample of her body in the world, in the units the rig understands:
// t, x, y (hip height), z, yaw, thighL, thighR (forward, rad), kneeL, kneeR (flexion, rad), lean (trunk forward, rad), armL (forward, rad), lie (0..1),
// armR (forward, rad), lift (both arms raised sideways, rad).
type Frame [14]float64

const (
	// the leg of the model: hip joint at 48, knee at 28, ankle at 6
	Lt, Ls, AnkleH = 20.0, 22.0, 6.0
	Gravity        = 520.0 // units/s², 9.81 m/s² at 53 units per metre
	FPS            = 20.0
	deg            = math.Pi / 180
)

// ---------- sitting ----------

// SitEnv is the chair she tries to sit on, in the line along which she faces: z=0 is the middle of the seat, she stands in
// front of it at z=footZ with her back to it.
type SitEnv struct {
	SeatY    float64 // height of the seat
	SeatHalf float64 // half the length of the seat along that line
}

// SitResult is what happened in one attempt.
type SitResult struct {
	OK      bool
	Reward  float64
	Why     string  // what went wrong or right, in her words
	Impact  float64 // vertical speed at the moment she touched the seat
	Frames  []Frame // in chair coordinates: x=0, z along the facing line, yaw 0
	Fell    bool
	Reached float64 // 0..1 how far she got
}

func smooth(u float64) float64 {
	u = math.Max(0, math.Min(1, u))
	return u * u * (3 - 2*u)
}

type pose struct{ hz, hy, th, kn, lean, arm float64 }

// sitPose is her pose at time t of a sitting movement with parameters p: the knees bend, the shins lean, the trunk leans forward
// to keep the weight over the feet and then straightens.
func sitPose(p [5]float64, t float64) (hz, hy, s, k, lean float64) {
	u := math.Min(1, t/p[4])
	e := smooth(u)
	k, s = p[1]*deg*e, p[2]*deg*e
	lean = p[3] * deg * math.Sin(math.Pi*u)
	zf := p[0]
	hz = zf + Ls*math.Sin(s) + Lt*math.Sin(s-k)
	hy = AnkleH + Ls*math.Cos(s) + Lt*math.Cos(s-k)
	return
}

func centreOfMass(zf, hz, hy, s, k, lean float64) (cz, cy float64) {
	kz, ky := zf+Ls*math.Sin(s), AnkleH+Ls*math.Cos(s)
	parts := [][3]float64{
		{.60, hz + 20*math.Sin(lean), hy + 20*math.Cos(lean)}, // trunk, head and arms
		{.20, (hz + kz) / 2, (hy + ky) / 2},                   // both thighs
		{.12, (kz + zf) / 2, (ky + AnkleH) / 2},               // both shins
		{.08, zf + 2, 3},                                      // both feet
	}
	for _, q := range parts {
		cz += q[0] * q[1]
		cy += q[0] * q[2]
	}
	return
}

// SitSim runs one attempt to sit down. p = [footZ, kneeEnd°, shinEnd°, leanMax°, duration s].
// The physics is a planar body on fixed feet: the centre of mass has to stay over the feet (the capture point is checked, so
// speed counts), the hip has to arrive on the seat, and arriving fast hurts.
func SitSim(p [5]float64, env SitEnv) SitResult {
	zf := p[0]
	lo, hi := zf-4, zf+9 // heel .. toe
	dt := .02
	res := SitResult{}
	var prevZ, prevY, prevCZ float64
	first := true
	contact := false
	var last pose
	steps := int(math.Min(p[4], 5)/dt) + 1
	effort := 0.0
	for i := 0; i <= steps; i++ {
		t := float64(i) * dt
		hz, hy, s, k, lean := sitPose(p, t)
		cz, cy := centreOfMass(zf, hz, hy, s, k, lean)
		var vy, vcz float64
		if !first {
			vy, vcz = (hy-prevY)/dt, (cz-prevCZ)/dt
		}
		_ = prevZ
		prevZ, prevY, prevCZ, first = hz, hy, cz, false
		last = pose{hz, hy, k - s, k, lean, lean * .6}
		res.Frames = append(res.Frames, Frame{t, 0, hy, hz, 0, k - s, k - s, k, k, lean, lean * .6, 0, lean * .6, 0})
		effort += math.Abs(cz - (zf + 2))
		onSeat := math.Abs(hz) <= env.SeatHalf+3
		if hy <= env.SeatY+2.5 {
			if onSeat {
				res.Impact = math.Abs(vy)
				contact = true
				res.Reached = 1
				break
			}
			res.Fell, res.Why = true, "промахнулась мимо сиденья и села на пол"
			res.Reached = .3
			break
		}
		cp := cz + vcz*math.Sqrt(math.Max(cy, 1)/Gravity)
		if cp < lo-3 {
			res.Fell, res.Why = true, "упала назад: центр масс ушёл за пятки"
			res.Reached = .5
			break
		}
		if cp > hi+3 {
			res.Fell, res.Why = true, "упала вперёд: слишком наклонилась, центр масс ушёл за носки"
			res.Reached = .5
			break
		}
	}
	switch {
	case res.Fell:
		// falling later and nearer the seat is a better failure: that is what shows her the way
		progress := res.Frames[len(res.Frames)-1][0] / math.Min(p[4], 5)
		res.Reward = -.55 + .3*math.Min(1, progress) + .1*math.Max(0, 1-math.Abs(last.hz)/40)
		res.Frames = append(res.Frames, fallFrames(last, zf, res.Frames[len(res.Frames)-1][0], last.hz < zf-20)...)
	case !contact:
		res.Why = "не села: не хватило сгибания коленей, бёдра не дошли до сиденья"
		res.Reached = math.Max(0, 1-(last.hy-env.SeatY)/25)
		res.Reward = -.2 - (last.hy-env.SeatY)/60
	default:
		res.OK = true
		res.Why = "села"
		if res.Impact > 140 {
			res.Why = "плюхнулась на сиденье слишком резко"
		}
		res.Reward = 1 - math.Min(1, res.Impact/220)*.45 - math.Min(1, effort/float64(steps)/30)*.2 - p[4]/12
	}
	return res
}

// fallFrames is the fall itself, a pause on the floor and getting up again onto the same feet.
func fallFrames(from pose, zf, t0 float64, backward bool) []Frame {
	var out []Frame
	n := int(.7 * FPS)
	to := pose{hz: zf + 18, hy: 12, th: 70 * deg, kn: 40 * deg, lean: 65 * deg, arm: 60 * deg}
	if backward {
		to = pose{hz: zf - 30, hy: 14, th: 85 * deg, kn: 50 * deg, lean: -40 * deg, arm: 50 * deg}
	}
	mix := func(a, b pose, u float64) pose {
		u = smooth(u)
		l := func(x, y float64) float64 { return x + (y-x)*u }
		return pose{l(a.hz, b.hz), l(a.hy, b.hy), l(a.th, b.th), l(a.kn, b.kn), l(a.lean, b.lean), l(a.arm, b.arm)}
	}
	t := t0
	emit := func(q pose) {
		t += 1 / FPS
		out = append(out, Frame{t, 0, q.hy, q.hz, 0, q.th, q.th, q.kn, q.kn, q.lean, q.arm, 0, q.arm, 0})
	}
	for i := 1; i <= n; i++ {
		emit(mix(from, to, float64(i)/float64(n)))
	}
	for i := 0; i < int(1.2*FPS); i++ {
		emit(to)
	}
	stand := pose{hz: zf, hy: 48}
	for i := 1; i <= int(1.4*FPS); i++ {
		emit(mix(to, stand, float64(i)/(1.4*FPS)))
	}
	return out
}

// ---------- walking ----------

// WalkResult is what a gait does over a short test walk.
type WalkResult struct {
	OK     bool
	Reward float64
	Why    string
	Speed  float64 // units/s
	// StepsOK is how many steps she makes before she trips or falls (a stable gait gets all of them).
	StepsOK int
	Forward bool // a failure that throws her forward (else backward)
}

const walkSteps = 8

// WalkSim judges a gait p = [stepLength, frequency Hz, lean°, kneeLift°, armSwing°]. The model: a leg of 42 units, the lean that
// balances the speed, the knee lift that clears the floor for that step length, and the stride her legs can keep up with.
func WalkSim(p [5]float64) WalkResult {
	stepLen, freq, lean, lift := p[0], p[1], p[2], p[3]
	v := stepLen * freq
	r := WalkResult{Speed: v, StepsOK: walkSteps}
	leanOpt := 3 + v/14
	liftNeed := 6 + stepLen*.9
	fail := func(at int, why string, fwd bool) {
		r.StepsOK, r.Why, r.Forward = at, why, fwd
		r.Reward = -.4 - math.Min(1, math.Abs(v-70)/70)*.3 + float64(at)/walkSteps*.2
	}
	switch {
	case lift < liftNeed-12:
		fail(3, "споткнулась: ступня не оторвалась от пола при таком шаге", true)
	case math.Abs(lean-leanOpt) > 10:
		fail(2, "потеряла равновесие: наклон корпуса не подходит к скорости", lean > leanOpt)
	case stepLen > 52 && freq > 1.8:
		fail(4, "ноги не успевают за корпусом, перешагнула и упала", true)
	default:
		r.OK, r.Why = true, "шла ровно"
		energy := freq*freq*stepLen/1500 + lift/400
		r.Reward = 1 - math.Abs(v-70)/70*.4 - math.Min(1, energy)*.15
	}
	return r
}

// ---------- learning ----------

// Skill is one learned movement: a distribution over its parameters that narrows toward what worked (the cross-entropy
// method), her record of trials and how reliable she is at it now.
type Skill struct {
	Name       string    `json:"name"`
	Lo         []float64 `json:"lo"`
	Hi         []float64 `json:"hi"`
	Mean       []float64 `json:"mean"`
	Std        []float64 `json:"std"`
	Trials     int       `json:"trials"`
	Successes  int       `json:"successes"`
	Recent     []bool    `json:"recent"`
	Batch      []Sample  `json:"batch"`
	Gen        int       `json:"gen"`
	Best       []float64 `json:"best"`
	BestReward float64   `json:"best_reward"`
	Log        []string  `json:"log"` // the last things that happened, in her words
}

// Sample is one trial.
type Sample struct {
	P      []float64 `json:"p"`
	Reward float64   `json:"r"`
}

// BatchSize is how many trials she makes before she adjusts what she does.
const BatchSize = 6

func newSkill(name string, lo, hi []float64, rng *rand.Rand) *Skill {
	s := &Skill{Name: name, Lo: lo, Hi: hi, BestReward: -9}
	for i := range lo {
		s.Mean = append(s.Mean, lo[i]+rng.Float64()*(hi[i]-lo[i])) // she starts with no idea
		s.Std = append(s.Std, (hi[i]-lo[i])/3)
	}
	return s
}

// Try draws parameters for the next attempt: around what she believes works, with the noise of her uncertainty
// (scaled by explore: 1 when practising, less when she just wants to do it well).
func (s *Skill) Try(rng *rand.Rand, explore float64) []float64 {
	p := make([]float64, len(s.Mean))
	for i := range p {
		p[i] = math.Max(s.Lo[i], math.Min(s.Hi[i], s.Mean[i]+rng.NormFloat64()*s.Std[i]*explore))
	}
	return p
}

// Learn records the result of an attempt; after a batch she moves her beliefs toward the best attempts.
func (s *Skill) Learn(p []float64, reward float64, ok bool, why string) {
	s.Trials++
	if ok {
		s.Successes++
	}
	s.Recent = append(s.Recent, ok)
	if len(s.Recent) > 20 {
		s.Recent = s.Recent[1:]
	}
	if reward > s.BestReward {
		s.BestReward, s.Best = reward, append([]float64(nil), p...)
	}
	s.Log = append(s.Log, why)
	if len(s.Log) > 8 {
		s.Log = s.Log[1:]
	}
	s.Batch = append(s.Batch, Sample{append([]float64(nil), p...), reward})
	if len(s.Batch) < BatchSize {
		return
	}
	sort.Slice(s.Batch, func(i, j int) bool { return s.Batch[i].Reward > s.Batch[j].Reward })
	elite := s.Batch[:2]
	for i := range s.Mean {
		em := (elite[0].P[i] + elite[1].P[i]) / 2
		ed := math.Abs(elite[0].P[i]-elite[1].P[i]) / 2
		s.Mean[i] = .4*s.Mean[i] + .6*em
		floor := (s.Hi[i] - s.Lo[i]) * .02
		s.Std[i] = math.Max(floor, .8*s.Std[i]+.2*ed)
		if len(s.Recent) >= 18 && s.Reliability() == 0 { // nothing works: she is stuck, so she gets bolder again
			s.Std[i] = math.Min((s.Hi[i]-s.Lo[i])/3, s.Std[i]*1.6)
		}
	}
	s.Batch, s.Gen = nil, s.Gen+1
}

// Reliability is the share of her last attempts that worked (0 when she has not tried).
func (s *Skill) Reliability() float64 {
	if len(s.Recent) == 0 {
		return 0
	}
	n := 0
	for _, r := range s.Recent {
		if r {
			n++
		}
	}
	return float64(n) / float64(len(s.Recent))
}

// Motor holds her skills. Safe for concurrent use.
type Motor struct {
	mu     sync.Mutex
	path   string
	Skills map[string]*Skill `json:"skills"`
	Seen   map[string]int    `json:"seen"` // how many times she has done each thing: what she has not tried attracts her
	saver  store.Saver
	rng    *rand.Rand
}

// SitBounds and WalkBounds are the ranges of what she can try.
var (
	SitLo, SitHi   = []float64{-30, 30, -15, 0, .6}, []float64{70, 125, 35, 60, 4.5}
	WalkLo, WalkHi = []float64{10, .6, -5, 0, 0}, []float64{60, 3, 25, 80, 35}
)

// NewMotor loads her skills or starts with none learned.
func NewMotor(path string, seed int64) *Motor {
	m := &Motor{path: path, saver: store.Saver{What: "motor"}, rng: rand.New(rand.NewSource(seed))}
	store.Load("motor", path, m)
	if m.Skills == nil {
		m.Skills = map[string]*Skill{}
	}
	if m.Seen == nil {
		m.Seen = map[string]int{}
	}
	if m.Skills["sit"] == nil {
		m.Skills["sit"] = newSkill("sit", SitLo, SitHi, m.rng)
	}
	if m.Skills["stand"] == nil {
		m.Skills["stand"] = newSkill("stand", StandLo, StandHi, m.rng)
	}
	if m.Skills["walk"] == nil {
		m.Skills["walk"] = newSkill("walk", WalkLo, WalkHi, m.rng)
	}
	return m
}

// Save writes her skills.
func (m *Motor) Save() { _ = m.saver.Save(m.path, m) }

// Skill is a copy of one skill.
func (m *Motor) Skill(name string) Skill {
	m.mu.Lock()
	defer m.mu.Unlock()
	s := *m.Skills[name]
	s.Log = append([]string(nil), s.Log...)
	return s
}

// Attempt draws parameters for a skill; explore 1 practises, .3 performs.
func (m *Motor) Attempt(name string, explore float64) [5]float64 {
	m.mu.Lock()
	defer m.mu.Unlock()
	p := m.Skills[name].Try(m.rng, explore)
	var out [5]float64
	copy(out[:], p)
	return out
}

// Learned records what an attempt came to.
func (m *Motor) Learned(name string, p [5]float64, reward float64, ok bool, why string) {
	m.mu.Lock()
	m.Skills[name].Learn(p[:], reward, ok, why)
	m.mu.Unlock()
	m.Save()
}

// Rand is the motor system's own source of chance (guarded).
func (m *Motor) Rand() float64 {
	m.mu.Lock()
	defer m.mu.Unlock()
	return m.rng.Float64()
}

// Ensure makes a skill that she has never practised (a new gesture, a movement she invented): no idea yet, wide guesses.
func (m *Motor) Ensure(name string, lo, hi []float64) {
	m.mu.Lock()
	defer m.mu.Unlock()
	if m.Skills[name] == nil {
		m.Skills[name] = newSkill(name, lo, hi, m.rng)
	}
}

// Saw counts one more time she did something and says how many times before.
func (m *Motor) Saw(what string) int {
	m.mu.Lock()
	n := m.Seen[what]
	m.Seen[what]++
	m.mu.Unlock()
	return n
}

// Times is how many times she has done something.
func (m *Motor) Times(what string) int {
	m.mu.Lock()
	defer m.mu.Unlock()
	return m.Seen[what]
}

// Names of the gestures and invented movements she knows (by trying).
func (m *Motor) Known() []string {
	m.mu.Lock()
	defer m.mu.Unlock()
	var out []string
	for k := range m.Skills {
		if len(k) > 2 && k[:2] == "g:" {
			out = append(out, k[2:])
		}
	}
	sort.Strings(out)
	return out
}
