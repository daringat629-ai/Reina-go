package life

import (
	"testing"
	"time"
)

func TestStandingUpIsLearnedAndCanFail(t *testing.T) {
	l := New(t.TempDir(), 5)
	_, _, _, env, ok := l.seatFor("chair")
	if !ok {
		t.Fatal("no chair")
	}
	sit := [5]float64{20, 95, 12, 30, 2}
	fails := func(n int, explore float64) int {
		c := 0
		for i := 0; i < n; i++ {
			g := l.Motor.Attempt("stand", explore)
			r := StandSim(sit, g, env)
			l.Motor.Learned("stand", g, r.Reward, r.OK, r.Why)
			if !r.OK {
				c++
			}
		}
		return c
	}
	early := fails(30, .9)
	fails(250, .6)
	late := fails(30, .1)
	t.Logf("early failures %d/30, late %d/30", early, late)
	if early < 3 {
		t.Fatalf("an unlearned body must fail sometimes: %d", early)
	}
	if late > 6 {
		t.Fatalf("after practice she must mostly get up: %d failures", late)
	}
}

func TestGettingUpFromSeatInTheAction(t *testing.T) {
	l := New(t.TempDir(), 9)
	l.WarmUp(time.Now())
	for i := 0; i < 600 && l.Posture() != "sit"; i++ {
		l.Do("practice", "t", time.Now())
	}
	if l.Posture() != "sit" {
		t.Fatal("she never managed to sit in 600 tries")
	}
	a := l.Do("window", "t", time.Now())
	if l.Posture() == "sit" && a.Outcome == "" {
		t.Fatal("must say why she is still seated")
	}
	if l.Posture() == "stand" && len(a.Frames) < 40 {
		t.Fatal("standing up must be recorded")
	}
	if l.Motor.Skill("stand").Trials < 120 {
		t.Fatal("standing must have been practised")
	}
}
