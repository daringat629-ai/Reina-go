package life

import (
	"math"
	"time"
)

func round2(v float64) float64 { return math.Round(v*100) / 100 }

// View is what the live page needs of her will: the current action (its frames only when the page does not have it yet,
// have = its id), where she is in it, and what she has learned of moving.
func (l *Life) View(have int64) map[string]any {

	out := map[string]any{"posture": l.Posture()}
	skill := func(n string) map[string]any {
		s := l.Motor.Skill(n)
		return map[string]any{"trials": s.Trials, "successes": s.Successes, "reliability": round2(s.Reliability()), "gen": s.Gen, "log": s.Log}
	}
	out["skills"] = map[string]any{"sit": skill("sit"), "walk": skill("walk")}
	out["history"] = l.History()
	a, el := l.Current(time.Now())
	if a == nil {
		return out
	}
	cur := map[string]any{"id": a.ID, "goal": a.Goal, "reason": a.Reason, "outcome": a.Outcome, "ok": a.OK, "dur": round2(a.Dur), "elapsed": round2(el)}
	if a.ID != have && have >= 0 {
		fr := make([][]float64, len(a.Frames))
		for i, f := range a.Frames {
			row := make([]float64, len(f))
			for j, v := range f {
				row[j] = round2(v)
			}
			fr[i] = row
		}
		cur["frames"] = fr
		var props []map[string]any
		for _, p := range a.Props {
			pf := make([][]float64, len(p.Frames))
			for i, f := range p.Frames {
				pf[i] = []float64{round2(f[0]), round2(f[1]), round2(f[2]), round2(f[3])}
			}
			props = append(props, map[string]any{"id": p.ID, "frames": pf})
		}
		cur["props"] = props
	}
	out["action"] = cur
	return out
}
