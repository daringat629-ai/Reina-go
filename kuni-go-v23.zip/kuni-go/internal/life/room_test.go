package life

import (
	"math"
	"path/filepath"
	"testing"
)

func newRoom(t *testing.T) *Room { return NewRoom(filepath.Join(t.TempDir(), "room.json")) }

func TestEveryObjectHasItsOwnHitbox(t *testing.T) {
	r := newRoom(t)
	seen := map[string]bool{}
	for _, b := range r.Hitboxes() {
		seen[b.Of] = true
		if b.Max[0] <= b.Min[0] || b.Max[1] <= b.Min[1] || b.Max[2] <= b.Min[2] {
			t.Fatalf("empty box %+v", b)
		}
	}
	for _, o := range r.Snapshot() {
		if !seen[o.ID] {
			t.Errorf("%s has no hitbox", o.ID)
		}
	}
	if n := len(r.get("chair").Boxes()); n != 2 {
		t.Fatalf("a chair has a seat and a back, got %d boxes", n)
	}
}

func TestBodyCannotWalkThroughThingsOrWalls(t *testing.T) {
	r := newRoom(t)
	if r.Free(100, -108, 11) {
		t.Fatal("she walked into the desk")
	}
	if r.Free(0, 128, 11) {
		t.Fatal("the door is locked: she cannot leave the room")
	}
	if r.Free(300, 0, 11) {
		t.Fatal("the wall")
	}
	if !r.Free(0, 0, 11) {
		t.Fatal("the middle of the room is free")
	}
}

func TestPathGoesAroundFurnitureAndNeverThroughIt(t *testing.T) {
	r := newRoom(t)
	p := r.Path(0, 0, 100, -80, 11, "chair")
	if len(p) < 2 {
		t.Fatal("no path to the desk side")
	}
	for i := 0; i < len(p)-1; i++ {
		for k := 0.0; k <= 1; k += .05 {
			x, z := p[i][0]+(p[i+1][0]-p[i][0])*k, p[i][1]+(p[i+1][1]-p[i][1])*k
			if h, ok := r.Collide(x, z, 11, "chair"); !ok || h != nil {
				t.Fatalf("path crosses a hitbox at %.0f,%.0f", x, z)
			}
		}
	}
	if r.Path(0, 0, 100, -108, 11) != nil {
		t.Fatal("a goal inside the desk has no path")
	}
	// behind the bed and the shelf the way is longer than straight
	if q := r.Path(-30, -100, -110, 20, 11); q == nil {
		t.Fatal("round the bed")
	}
}

func TestObjectsAreIndependentAndObeyGravity(t *testing.T) {
	r := newRoom(t)
	cup := r.get("cup")
	if cup.Pos[1] != 40 {
		t.Fatal("the cup stands on the desk")
	}
	if !r.Push("cup", -40, 0) { // slide it off the desk edge
		t.Fatal("a cup can be pushed")
	}
	for i := 0; i < 40; i++ {
		r.Step(.05)
	}
	if cup.Pos[1] != 0 {
		t.Fatalf("the cup must fall to the floor, y=%.1f", cup.Pos[1])
	}
	book := r.get("book")
	for i := 0; i < 40; i++ {
		r.Step(.05)
	}
	if book.Pos[1] != 40 || r.get("desk").Pos[1] != 0 {
		t.Fatal("the book stays on the desk; the desk never moves")
	}
	if r.Push("desk", 10, 0) {
		t.Fatal("a desk is not movable")
	}
	// bumping the chair moves the chair and nothing else
	d := math.Hypot(0, 0)
	_ = d
	x0 := r.get("chair").Pos[0]
	r.Bump(100, -52, 14, 1, 0)
	if r.get("chair").Pos[0] <= x0 || r.get("lamp").Pos[0] != 140 {
		t.Fatal("bumping must move only what is touched")
	}
}

func TestObjectsKeepWhereTheyWereLeft(t *testing.T) {
	p := filepath.Join(t.TempDir(), "room.json")
	r := NewRoom(p)
	r.Push("chair", 0, 15)
	z := r.get("chair").Pos[2]
	if NewRoom(p).get("chair").Pos[2] != z {
		t.Fatal("the chair must stay where she left it")
	}
}
