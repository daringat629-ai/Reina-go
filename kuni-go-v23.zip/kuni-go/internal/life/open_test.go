package life

import (
	"math"
	"strings"
	"testing"
	"time"
)

func TestTheSpaceOfActionsIsOpen(t *testing.T) {
	l := New(t.TempDir(), 9)
	l.Hurt = func(float64) {}
	seen := map[string]bool{}
	now := time.Now()
	for i := 0; i < 400; i++ {
		now = now.Add(5 * time.Minute)
		if a := l.Decide(now, Inputs{Fatigue: .2, Drives: map[string]float64{"explore": .6, "create": .5}}); a != nil {
			seen[a.Goal] = true
			for _, f := range a.Frames {
				if math.Abs(f[1]) > l.Room.HalfX || math.Abs(f[3]) > l.Room.HalfZ {
					t.Fatalf("%s left the room", a.Goal)
				}
			}
		}
	}
	verbs := map[string]bool{}
	for g := range seen {
		verbs[strings.SplitN(g, ":", 2)[0]] = true
	}
	t.Logf("%d different goals, kinds %v", len(seen), verbs)
	if len(seen) < 40 {
		t.Fatalf("only %d different things in 400 decisions", len(seen))
	}
	for _, v := range []string{"touch", "look", "push", "pick", "g", "visit"} {
		if !verbs[v] {
			t.Errorf("she never did a %q", v)
		}
	}
}

func TestSheMovesObjectsAndTheyStayMoved(t *testing.T) {
	l := New(t.TempDir(), 3)
	l.Hurt = func(float64) {}
	now := time.Now()
	l.WarmUp(now)
	a := l.Do("pick:cup>bed", "тест", now)
	for i := 0; i < 5 && len(a.Props) == 0; i++ {
		a = l.Do("pick:cup>bed", "тест", now)
	}
	_ = a
	// the cup is on the shelf only after the action has ended
	if l.Room.Get("cup").Pos[0] != 84 {
		t.Fatal("the cup stays where it was until she puts it down")
	}
	if len(a.Props) == 0 || a.Props[0].ID != "cup" {
		t.Fatalf("a carried object has a track: %+v", a.Outcome)
	}
	l.Decide(now.Add(time.Duration(a.Dur+1)*time.Second), Inputs{})
	t.Logf("outcome: %s; cup at %v", a.Outcome, l.Room.Get("cup").Pos)
	cup := l.Room.Get("cup").Pos
	if a.OK && cup == [3]float64{84, 40, -104} {
		t.Fatal("she put the cup down but it did not move")
	}
	// push the chair
	x0, z0 := l.Room.Get("chair").Pos[0], l.Room.Get("chair").Pos[2]
	b := l.Do("push:chair", "тест", now.Add(time.Hour))
	l.Decide(now.Add(time.Hour+time.Duration(b.Dur+1)*time.Second), Inputs{})
	t.Logf("push: %s", b.Outcome)
	if b.OK && l.Room.Get("chair").Pos[0] == x0 && l.Room.Get("chair").Pos[2] == z0 {
		t.Fatal("pushed chair must have moved")
	}
	if c := l.Do("push:desk", "тест", now.Add(2*time.Hour)); c.OK || !strings.Contains(c.Outcome, "не сдвинулась") && !strings.Contains(c.Outcome, "не нашла") {
		t.Fatalf("a desk cannot be pushed: %s", c.Outcome)
	}
}

func TestGesturesAreLearnedAndCanFail(t *testing.T) {
	l := New(t.TempDir(), 5)
	l.Hurt = func(float64) {}
	now := time.Now()
	run := func(n int) (ok int) {
		for i := 0; i < n; i++ {
			now = now.Add(time.Hour)
			if a := l.Do("g:dance", "тест", now); a.OK {
				ok++
			}
		}
		return
	}
	before := run(15)
	run(250)
	after := run(30)
	t.Logf("dance: %d/15 before, %d/30 after", before, after)
	if after < 15 || after*15 <= before*30 {
		t.Fatalf("a dance must be learned: %d/15 -> %d/30", before, after)
	}
}

func TestSheCanInventAMovement(t *testing.T) {
	l := New(t.TempDir(), 1)
	l.Hurt = func(float64) {}
	if err := l.Invent("a:b", []Key{{}, {T: 1}}); err == nil {
		t.Fatal("bad name")
	}
	if err := l.Invent("приветствие", []Key{{T: 0}, {T: 1, Lift: 90, ArmL: 20}, {T: 2}}); err != nil {
		t.Fatal(err)
	}
	a := l.Do("g:приветствие", "придумала сама", time.Now())
	if a.Outcome == "не знаю такого движения" || len(a.Frames) < 10 {
		t.Fatalf("an invented movement runs: %+v", a.Outcome)
	}
	found := false
	for _, k := range l.Motor.Known() {
		found = found || k == "приветствие"
	}
	if !found {
		t.Fatal("she knows it now")
	}
	// something impossible: leaning right over cannot be held
	l.Invent("падение", []Key{{}, {T: .6, Lean: 85, Shin: 0}, {T: 2, Lean: 85}})
	fell := false
	for i := 0; i < 5 && !fell; i++ {
		fell = !l.Do("g:падение", "", time.Now()).OK
	}
	if !fell {
		t.Fatal("balance must decide: a deep bend from straight legs falls")
	}
}

func TestNewObjectMeansNewThingsToDo(t *testing.T) {
	l := New(t.TempDir(), 2)
	if !l.Room.Add(Object{ID: "ball", Name: "мячик", Kind: "ball", Pos: [3]float64{0, 0, 40}, Size: [3]float64{8, 8, 8}, Solid: true, Movable: true}) {
		t.Fatal("add")
	}
	n := 0
	for i := 0; i < 20; i++ {
		for _, c := range l.candidates(Inputs{Drives: map[string]float64{}}) {
			if strings.Contains(c.goal, "ball") {
				n++
			}
		}
	}
	if n < 10 {
		t.Fatalf("a new object must open new actions, got %d", n)
	}
}

func TestWarmUpTeachesWalkingBeforeCarrying(t *testing.T) {
	l := New(t.TempDir(), 3)
	l.WarmUp(time.Now())
	if l.Motor.Skill("walk").Trials < 40 || len(l.History_) != 0 {
		t.Fatalf("warm-up must practise walking and leave no fake history: %d %v", l.Motor.Skill("walk").Trials, l.History_)
	}
	ok := 0
	for i := 0; i < 10; i++ {
		if a := l.Do("pick:cup>bed", "t", time.Now()); strings.Contains(a.Outcome, "положила") {
			ok++
		}
	}
	if ok < 3 {
		t.Fatalf("after warm-up carrying should often work: %d/10", ok)
	}
}
