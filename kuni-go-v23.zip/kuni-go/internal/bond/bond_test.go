package bond

import (
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestChooseOnlyOnce(t *testing.T) {
	p := filepath.Join(t.TempDir(), "bond.json")
	b := New(p)
	if _, ok := b.Chosen(); ok {
		t.Fatal("nobody should be chosen at the start")
	}
	if err := b.Choose(0, "x", ""); err == nil {
		t.Fatal("id 0 must be refused")
	}
	if err := b.Choose(42, "Вася", "потому что"); err != nil {
		t.Fatal(err)
	}
	if err := b.Choose(7, "Петя", ""); err == nil {
		t.Fatal("a second choice must be refused")
	}
	b2 := New(p) // survives a restart
	if s, ok := b2.Chosen(); !ok || s.UserID != 42 {
		t.Fatalf("not persisted: %+v", s)
	}
}

func TestStageAndPrompt(t *testing.T) {
	b := New(filepath.Join(t.TempDir(), "bond.json"))
	if !strings.Contains(b.Prompt(1, ""), "have not chosen") {
		t.Fatal("unchosen prompt wrong")
	}
	_ = b.Choose(42, "Вася", "")
	if b.Stage() != 0 {
		t.Fatal("fresh bond is early")
	}
	b.now = func() time.Time { return time.Now().Add(20 * 24 * time.Hour) }
	if b.Stage() != 2 {
		t.Fatal("20 days later it is deep")
	}
	here, away := b.Prompt(42, ""), b.Prompt(5, "")
	if !strings.Contains(here, "talking to now") || strings.Contains(away, "talking to now") {
		t.Fatal("prompt must tell whether the chosen one is present")
	}
	for _, p := range []string{here, away} {
		if !strings.Contains(p, "never stalk") {
			t.Fatal("the safety rules must always be in the block")
		}
	}
}
