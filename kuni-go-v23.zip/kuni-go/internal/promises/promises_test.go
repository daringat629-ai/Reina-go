package promises

import (
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestBook(t *testing.T) {
	p := filepath.Join(t.TempDir(), "p.json")
	s := New(p)
	now := time.Date(2026, 10, 26, 12, 0, 0, 0, time.UTC)
	if _, err := s.Add(" ", time.Time{}, now); err == nil {
		t.Fatal("empty promise")
	}
	a, _ := s.Add("починить зрение", now.Add(-time.Hour), now)
	s.Add("кофемашина", now.Add(48*time.Hour), now)
	s.Add("когда-нибудь пицца", time.Time{}, now)
	if k, o, od := s.Stats(now); k != 0 || o != 3 || od != 1 {
		t.Fatal(k, o, od)
	}
	pr := s.Prompt(now, time.UTC, true)
	if !strings.Contains(pr, "СРОК ПРОШЁЛ") || !strings.Contains(pr, "кофемашина") {
		t.Fatal(pr)
	}
	if s.Prompt(now, time.UTC, false) != "" {
		t.Fatal("promises are for his chat only")
	}
	if !s.Done(a.ID, now) || s.Done(a.ID, now) {
		t.Fatal("close exactly once")
	}
	if k, _, od := s.Stats(now); k != 1 || od != 0 {
		t.Fatal(k, od)
	}
	if New(p).Open()[0].Text != "кофемашина" {
		t.Fatal("not saved")
	}
}

func TestAbsence(t *testing.T) {
	s := New(filepath.Join(t.TempDir(), "p.json"))
	now := time.Date(2026, 10, 26, 12, 0, 0, 0, time.UTC)
	if s.Absence(now) != "" {
		t.Fatal("never seen: nothing to miss")
	}
	s.Seen(now.Add(-30 * time.Hour))
	if s.Absence(now) == "" {
		t.Fatal("expected a block")
	}
	s.Seen(now.Add(-3 * time.Hour))
	if s.Absence(now) != "" {
		t.Fatal("3 hours is not long")
	}
}
