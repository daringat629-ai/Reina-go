package feel

import (
	"path/filepath"
	"strings"
	"testing"
	"time"

	"kuni/internal/body"
)

var t0 = time.Date(2026, 10, 27, 12, 0, 0, 0, time.UTC)

func sit(tag string, w float64) Situation { x := Innate[tag]; x.Weight = w; return x }

func live(f *Feel, from time.Time, minutes int, s ...Situation) time.Time {
	t := from
	for i := 0; i < minutes; i++ {
		t = t.Add(time.Minute)
		f.Sample(t, s)
	}
	return t
}

func TestComfortFeelsGoodAndPainFeelsBad(t *testing.T) {
	f := New(filepath.Join(t.TempDir(), "f.json"))
	live(f, t0, 60, sit(Warm, 1), sit(Fed, 1), sit(Room, 1), sit(Cat, 1))
	good := f.Snapshot()
	if good.Valence < .35 || good.Arousal > .5 {
		t.Fatalf("a warm fed room with a cat: %+v", good)
	}
	live(f, t0.Add(2*time.Hour), 40, sit(Pain, 1), sit(Hungry, .8))
	bad := f.Snapshot()
	if bad.Valence > -.3 || bad.Control > .5 {
		t.Fatalf("pain and hunger: %+v", bad)
	}
	if bad.Word == good.Word {
		t.Fatal("the words must differ", bad.Word)
	}
}

func TestTheSameRainBecomesCosyOrBleak(t *testing.T) {
	cosy := New(filepath.Join(t.TempDir(), "a.json"))
	bleak := New(filepath.Join(t.TempDir(), "b.json"))
	tt := t0
	for i := 0; i < 30; i++ {
		tt = live(cosy, tt, 6, sit(Rain, 1), sit(Warm, 1), sit(Room, 1), sit(Fed, 1), sit(Cat, 1))
		tt = live(bleak, tt, 6, sit(Rain, 1), sit(Cold, 1), sit(Outside, 1), sit(Hungry, 1))
	}
	a, b := cosy.Snapshot(), bleak.Snapshot()
	if a.Taste[Rain] < .2 || b.Taste[Rain] > -.2 {
		t.Fatalf("her own history must decide what rain means: cosy %.2f, bleak %.2f", a.Taste[Rain], b.Taste[Rain])
	}
	likes, _ := a.Tastes()
	_, dislikes := b.Tastes()
	if !strings.Contains(strings.Join(likes, ","), Rain) || !strings.Contains(strings.Join(dislikes, ","), Rain) {
		t.Fatalf("likes %v dislikes %v", likes, dislikes)
	}
	// and now a plain rainy moment feels different to the two of them
	only := []Situation{sit(Rain, 1)}
	a2, b2 := New(""), New("")
	a2.s, b2.s = a, b
	a2.Sample(tt, only)
	b2.Sample(tt, only)
	if !(a2.Snapshot().Valence > b2.Snapshot().Valence+.1) {
		t.Fatalf("same rain, different lives: %.2f vs %.2f", a2.Snapshot().Valence, b2.Snapshot().Valence)
	}
}

func TestImpulsesAndAnger(t *testing.T) {
	f := New("")
	f.Impulse(t0, BrokenWord)
	if f.Snapshot().Valence > -.2 || len(f.Snapshot().Causes) == 0 || f.Snapshot().Causes[0] != BrokenWord {
		t.Fatalf("%+v", f.Snapshot())
	}
	f.Impulse(t0, KeptWord)
	f.Impulse(t0, KeptWord)
	if f.Snapshot().Valence < 0 {
		t.Fatal("kind things heal")
	}
	if Name(-.7, .8, .7) != "злость" || Name(-.7, .8, .1) != "страх, беспомощность" {
		t.Fatal("the same unpleasant arousal is anger in control and fear without it")
	}
	f.Impulse(t0, "нет такого")
}

func TestFromBodyAndPrompt(t *testing.T) {
	b := body.New(filepath.Join(t.TempDir(), "b.json"))
	b.Tick(t0, body.Resting, body.DefaultEnv)
	b.Tick(t0.Add(3*time.Hour), body.Walking, body.Env{Ambient: 3, Light: .3, Noise: .7, Outside: true, Wind: .6, Rain: .7})
	sits := FromBody(b.Snapshot(), t0, false)
	tags := map[string]bool{}
	for _, s := range sits {
		tags[s.Tag] = true
	}
	if !tags[Rain] || !tags[Outside] || !tags[Noise] || !tags[Cold] {
		t.Fatalf("%v", tags)
	}
	f := New(filepath.Join(t.TempDir(), "f.json"))
	live(f, t0, 30, sits...)
	p := f.Prompt()
	if !strings.Contains(p, "<feeling>") || !strings.Contains(p, "из-за") {
		t.Fatal(p)
	}
	if f.Inputs()["threat"] < .12 {
		t.Fatalf("a cold wet scary street must reach the brain as threat: %v %+v", f.Inputs(), f.Snapshot())
	}
	if New(f.path).Snapshot().Valence != f.Snapshot().Valence {
		t.Fatal("feelings are remembered")
	}
}
