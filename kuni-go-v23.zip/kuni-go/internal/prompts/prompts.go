// Package prompts keeps every text the model is given: the 13 original Kuni prompts (extracted verbatim from
// src/prompts.cpp), her persona, and the instructions the program used to keep in its own code (tones, chat rules,
// what to do in her free time, how to summarise a conversation...). Like the C++ version, defaults are written to
// <dir> on first run and the files are then the source of truth: the front matter is stripped, ${CHARACTER_NAME}
// and the like are expanded, and a changed file is picked up without a restart.
//
// Layout of <dir>:
//
//	*.md          the original prompts and her persona
//	chat/*.md     what she is told inside a chat: the tones, the rules, the epilogue of the owner's chat
//	engine/*.md   the program's own jobs: free time, background work, summaries, person cards, helpers
//
// A file that is missing is written from the built-in default; existing files are never overwritten (except a known
// outdated default nobody edited, see outdated).
package prompts

import (
	"crypto/sha256"
	"embed"
	"encoding/hex"
	"io/fs"
	"os"
	"path"
	"path/filepath"
	"sort"
	"strings"
	"sync"
)

//go:embed defaults
var defaults embed.FS

// Names of all prompts.
const (
	System                    = "system"
	CharacterBase             = "character_base"
	CharacterAppearance       = "character_appearance"
	PhotoToText               = "photo_to_text"
	StickerToText             = "sticker_to_text"
	AntiRepeat                = "anti_repeat"
	DiarySave                 = "diary_save"
	SleepConsolidator         = "sleep_consolidator"
	RecordAudioSpeech         = "record_audio_speech"
	MessagesEpilogue          = "messages_epilogue"
	ImageEngineerSystem       = "image_engineer_system"
	ImageEngineerInstructions = "image_engineer_instructions"
	ImageAssessSystem         = "image_assess_system"
	// OwnerPowers is appended to the system prompt only in the owner's private chat and in background jobs.
	OwnerPowers = "owner_powers"

	// what she is told inside a chat
	ToneOwner      = "chat/tone_owner"
	ToneGroup      = "chat/tone_group"
	ToneContact    = "chat/tone_contact"
	ToneStranger   = "chat/tone_stranger"
	RulesVoice     = "chat/rules_voice"
	RulesCode      = "chat/rules_code"
	RulesFollowUp  = "chat/rules_follow_up"
	RulesGroup     = "chat/rules_group"
	OwnerEpilogue  = "chat/owner_epilogue"
	ChannelRules   = "chat/channel"    // ${CHAT_TITLE}
	NotMemberRules = "chat/not_member" // ${CHAT_TITLE}

	// the program's own jobs
	Autonomy          = "engine/autonomy" // ${LEFT}
	Proactive         = "engine/proactive"
	WorkRun           = "engine/work_run" // ${JOB}
	Compact           = "engine/compact"
	LearnPersonSystem = "engine/learn_person_system"
	LearnPerson       = "engine/learn_person" // ${NOW}
	DescribePerson    = "engine/describe_person"
	HintPromise       = "engine/hint_promise"
	HintReport        = "engine/hint_report"
	AskSystem         = "engine/ask_system"
	DelegateSystem    = "engine/delegate_system"
	LookAtScreen      = "engine/look_at_screen"
	ProxySystem       = "engine/proxy_system"
)

// Vars are the ${VARIABLES} substituted into prompts.
type Vars struct {
	CharacterName     string
	CharacterNickname string
	PapikName         string
}

// outdated lists, per file, the SHA-256 of default texts that shipped before. A prompt file on disk that is byte for
// byte one of them was never edited by the owner, so it is replaced by the current default (the old one is kept as
// <name>.md.old). A file the owner changed even by one character is never touched.
var outdated = map[string][]string{
	"character_appearance.md": {"6e726bb0354932b85f608f920acf6cbd747b25880210cc77c1d716c175e13727",
		"21b2f6eaa77aa9dece03180eda2ffa76623522b1c4e34cd41839b1ba4d4f6bea"},
	// the 34 KB template character ("soft yandere"), replaced by a minimal core: the rest grows from her brain, memory and diary
	"engine/autonomy.md": {"8cc19ba511288f9587808bc0a95a48097b257be603faecf4f902f7e0517fdddb"},
	"character_base.md":  {"d2e88e11b71631e2bdee0f35b6206daedec00f93fd46fe87e15cc6b41964a8d8"},
	// the system prompt that still carried the owner's powers into every chat (now in owner_powers.md)
	"system.md": {"d71c17cbefc229d86ed3ab31078203c572d880e8add9d3cb52d2a5099ef71815"},
}

func isOutdatedDefault(file string, raw []byte) bool {
	sum := sha256.Sum256(raw)
	h := hex.EncodeToString(sum[:])
	for _, o := range outdated[file] {
		if o == h {
			return true
		}
	}
	return false
}

// names is every prompt name ("system", "chat/tone_owner"...), from the built-in defaults, sorted.
var names = func() []string {
	var out []string
	_ = fs.WalkDir(defaults, "defaults", func(p string, d fs.DirEntry, err error) error {
		if err == nil && !d.IsDir() && strings.HasSuffix(p, ".md") {
			out = append(out, strings.TrimSuffix(strings.TrimPrefix(p, "defaults/"), ".md"))
		}
		return nil
	})
	sort.Strings(out)
	return out
}()

var known = func() map[string]bool {
	m := make(map[string]bool, len(names))
	for _, n := range names {
		m[n] = true
	}
	return m
}()

// Store keeps loaded prompts; Reload re-reads files (hot reload).
type Store struct {
	Dir  string
	mu   sync.RWMutex
	vars Vars
	data map[string]string
}

func NewStore(dir string, vars Vars) (*Store, error) {
	s := &Store{Dir: dir, vars: vars}
	return s, s.Reload()
}

// SetVars changes variables and re-expands prompts.
func (s *Store) SetVars(v Vars) error {
	s.mu.Lock()
	s.vars = v
	s.mu.Unlock()
	return s.Reload()
}

func (s *Store) file(name string) string { return filepath.Join(s.Dir, filepath.FromSlash(name)+".md") }

func defaultOf(name string) []byte {
	b, _ := defaults.ReadFile(path.Join("defaults", name+".md"))
	return b
}

// Reload reads every prompt file, creating missing ones from the embedded defaults.
func (s *Store) Reload() error {
	if err := os.MkdirAll(s.Dir, 0o755); err != nil {
		return err
	}
	s.mu.RLock()
	vars := s.vars
	s.mu.RUnlock()
	out := make(map[string]string, len(names))
	for _, name := range names {
		p := s.file(name)
		raw, err := os.ReadFile(p)
		switch {
		case os.IsNotExist(err):
			raw = defaultOf(name)
			if err := os.MkdirAll(filepath.Dir(p), 0o755); err != nil {
				return err
			}
			if err := os.WriteFile(p, raw, 0o644); err != nil {
				return err
			}
		case err != nil:
			return err
		case isOutdatedDefault(name+".md", raw):
			_ = os.WriteFile(p+".old", raw, 0o644)
			raw = defaultOf(name)
			if err := os.WriteFile(p, raw, 0o644); err != nil {
				return err
			}
		}
		out[name] = expand(StripFrontMatter(string(raw)), vars)
	}
	s.mu.Lock()
	s.data = out
	s.mu.Unlock()
	return nil
}

// Get returns a loaded prompt ("" if unknown, or for a nil store).
func (s *Store) Get(name string) string {
	if s == nil {
		return ""
	}
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.data[name]
}

// Text is Get without the surrounding blank lines, with the ${KEY} placeholders of the call filled in.
func (s *Store) Text(name string, kv map[string]string) string {
	t := strings.TrimSpace(s.Get(name))
	if len(kv) == 0 {
		return t
	}
	pairs := make([]string, 0, len(kv)*2)
	for k, v := range kv {
		pairs = append(pairs, "${"+k+"}", v)
	}
	return strings.NewReplacer(pairs...).Replace(t)
}

// Files lists prompt files for the file watcher.
func (s *Store) Files() []string {
	out := make([]string, 0, len(names))
	for _, n := range names {
		out = append(out, s.file(n))
	}
	return out
}

// StripFrontMatter removes a leading "---\n...\n---" block. Only a block at the very start of the file counts: a
// "---" line further down (a markdown rule, a separator in an example) is part of the text and stays.
func StripFrontMatter(s string) string {
	t := strings.TrimLeft(strings.TrimPrefix(s, "\ufeff"), " \t\r\n")
	if !strings.HasPrefix(t, "---") {
		return s
	}
	j := strings.Index(t[3:], "\n---")
	if j < 0 {
		return s
	}
	rest := t[3+j+4:]
	// the closing marker runs to the end of its line
	if k := strings.IndexByte(rest, '\n'); k >= 0 && strings.Trim(rest[:k], "-\r \t") == "" {
		return rest[k:]
	}
	return rest
}

func expand(s string, v Vars) string {
	return strings.NewReplacer(
		"${CHARACTER_NAME}", v.CharacterName,
		"${CHARACTER_NICKNAME}", v.CharacterNickname,
		"${PAPIK_NAME}", v.PapikName,
	).Replace(s)
}

// Format fills {KEY} placeholders (used by image_engineer_system).
func Format(s string, kv map[string]string) string {
	pairs := make([]string, 0, len(kv)*2)
	for k, v := range kv {
		pairs = append(pairs, "{"+k+"}", v)
	}
	return strings.NewReplacer(pairs...).Replace(s)
}

// Names lists the prompt names (sorted; the ones in folders carry the folder: "chat/tone_owner").
func (s *Store) Names() []string { return append([]string(nil), names...) }

// Raw returns the prompt file as stored (with front matter and ${VARS}).
func (s *Store) Raw(name string) (string, error) {
	if !known[name] {
		return "", os.ErrNotExist
	}
	b, err := os.ReadFile(s.file(name))
	return string(b), err
}

// Default returns the built-in text of a prompt.
func (s *Store) Default(name string) (string, error) {
	if !known[name] {
		return "", os.ErrNotExist
	}
	return string(defaultOf(name)), nil
}

// Write replaces a prompt file (atomically, keeping a .bak) and reloads.
func (s *Store) Write(name, content string) error {
	if !known[name] {
		return os.ErrNotExist
	}
	p := s.file(name)
	if err := os.MkdirAll(filepath.Dir(p), 0o755); err != nil {
		return err
	}
	if old, err := os.ReadFile(p); err == nil {
		_ = os.WriteFile(p+".bak", old, 0o644)
	}
	tmp := p + ".tmp"
	if err := os.WriteFile(tmp, []byte(content), 0o644); err != nil {
		return err
	}
	if err := os.Rename(tmp, p); err != nil {
		return err
	}
	return s.Reload()
}
