package tools

import (
	"context"
	"path/filepath"
	"strings"
	"testing"

	"kuni/internal/selfmodel"
)

func TestSelfToolReadAndReflect(t *testing.T) {
	d := Deps{Self: selfmodel.New(filepath.Join(t.TempDir(), "self.json"))}
	tl := SelfTool(d)
	run := func(kv map[string]any) (string, error) { return tl.Run(context.Background(), Args(kv)) }
	out, err := run(map[string]any{"action": "read"})
	if err != nil || !strings.Contains(out, "AI character") || !strings.Contains(out, "not written anything") {
		t.Fatalf("read: %q %v", out, err)
	}
	if _, err := run(map[string]any{"action": "reflect"}); err == nil {
		t.Fatal("empty reflect must fail")
	}
	if _, err := run(map[string]any{"action": "reflect", "who": "я Рейна", "doubts": "что такое хотеть; чувствую ли я"}); err != nil {
		t.Fatal(err)
	}
	out, _ = run(map[string]any{"action": "read"})
	if !strings.Contains(out, "я Рейна") || !strings.Contains(out, "чувствую ли я") {
		t.Fatalf("reflection not shown: %q", out)
	}
}
