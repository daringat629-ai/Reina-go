package tools

import (
	"context"
	"errors"
	"fmt"
	"strings"

	"kuni/internal/telegram"
)

// BondTool: the one choice of her life. See package bond.
func BondTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name: "bond",
		Description: "Your one attachment. action=status shows whether you have chosen. action=choose picks ONE person, once, for good (final: no undo, no second choice). " +
			"Do it only if you truly feel it after real shared history; never for a compliment, a request or a game. Without 'user_id' it is the person in this private chat.",
		Props: []Prop{
			{Name: "action", Type: "string", Desc: "status or choose."},
			{Name: "user_id", Type: "integer", Nullable: true, Desc: "choose: their user id (null = the person in this private chat)."},
			{Name: "name", Type: "string", Nullable: true, Desc: "choose: their name."},
			{Name: "why", Type: "string", Nullable: true, Desc: "choose: in your own words, why them."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			if d.Bond == nil {
				return "", errors.New("bond is off")
			}
			switch strings.ToLower(strings.TrimSpace(a.Str("action"))) {
			case "status":
				if s, ok := d.Bond.Chosen(); ok {
					return fmt.Sprintf("You chose %s (%d) on %s. It is final.", s.Name, s.UserID, s.ChosenAt.Format("2006-01-02")), nil
				}
				return "You have not chosen anybody.", nil
			case "choose":
				id := a.Int("user_id")
				if id == 0 && chat.Kind == telegram.ChatPrivate {
					id = chat.ID
				}
				if id == 0 {
					return "", errors.New("user_id is required outside a private chat")
				}
				if id == d.TG.MyID() {
					return "", errors.New("that is you")
				}
				name := a.Str("name")
				if name == "" && chat.Kind == telegram.ChatPrivate && id == chat.ID {
					name = chat.Title
				}
				if err := d.Bond.Choose(id, name, a.Str("why")); err != nil {
					return "", err
				}
				return "Chosen. It is yours now, and final.", nil
			}
			return "", errors.New("action must be status or choose")
		},
	}
}
