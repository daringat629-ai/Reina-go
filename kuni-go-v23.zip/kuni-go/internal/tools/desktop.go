package tools

import (
	"context"
	"encoding/json"
	"fmt"
	"os/exec"
	"strings"
	"sync"
	"time"

	"kuni/internal/desktop"
	"kuni/internal/telegram"
)

func (d Deps) desktop() *desktop.Desktop { return d.rt().Desktop }

func (d Deps) desktopOptions() desktop.Options {
	c := d.Cfg()
	return desktop.Options{
		Width: c.DesktopWidth, Height: c.DesktopHeight, Idle: time.Duration(c.DesktopIdleSecs) * time.Second, Session: c.DesktopSession, Display: c.DesktopDisplay,
		Command: func(ctx context.Context, line string) (*exec.Cmd, error) {
			if why := d.shellDanger(line); why != "" {
				return nil, fmt.Errorf("blocked by capabilities.shell_hard_block: %s", why)
			}
			d.journal("[desktop] "+line, 0)
			return d.shellCmd(ctx, line)
		},
	}
}

const gridHint = " The screenshot has a red dotted grid every 100 pixels, each line labelled with its pixel coordinate: use it to give exact x,y positions of the things you point at."

// desktopTool is her own screen: programs, mouse, keyboard.
func desktopTool(d Deps, chat telegram.Chat) Tool {
	var mu sync.Mutex
	steps := 0
	stopped := false
	guard := &loopGuard{}
	return Tool{
		Name: "desktop",
		Description: "A virtual desktop of your own (owner only): graphical programs run on it, nobody has to watch. Actions: launch(command) = start a program (a shell line, e.g. 'firefox https://...', 'libreoffice --calc file.xlsx') | " +
			"look = list the open windows | see(text = question) = a vision model looks at the screen and answers, with exact pixel positions | send(caption) = screenshot to this chat | " +
			"click(x, y, button, double) | move(x, y) | drag(x, y, x2, y2) | type(text) | key(key = Enter, Tab, ctrl+s, alt+F4, F5...) | scroll(x, y, direction, amount) | wait(amount = seconds, up to 10) | batch(steps = JSON list of actions, up to 15 in ONE call, e.g. [{\"action\":\"click\",\"x\":100,\"y\":50},{\"action\":\"type\",\"text\":\"hello\"},{\"action\":\"key\",\"key\":\"Enter\"}]; the screen is checked once at the end, so use it for sequences you are sure about) | close = shut the desktop and its programs. " +
			"Workflow: launch, see, act on the positions it gives you, see again to check. Work fast: chain sure steps in one batch, otherwise one action per round, never repeat an action that changed nothing, tell the owner what blocks you.",
		Props: []Prop{
			{Name: "action", Type: "string", Desc: "launch, look, see, send, click, move, drag, type, key, scroll or close."},
			{Name: "command", Type: "string", Nullable: true, Desc: "launch: the shell line of the program."},
			{Name: "x", Type: "integer", Nullable: true, Desc: "Pixel x (click, move, drag start, scroll)."},
			{Name: "y", Type: "integer", Nullable: true, Desc: "Pixel y."},
			{Name: "x2", Type: "integer", Nullable: true, Desc: "drag: end x."},
			{Name: "y2", Type: "integer", Nullable: true, Desc: "drag: end y."},
			{Name: "button", Type: "string", Nullable: true, Desc: "click: left (default), right or middle."},
			{Name: "double", Type: "boolean", Nullable: true, Desc: "click: double click."},
			{Name: "text", Type: "string", Nullable: true, Desc: "type: the text; see: the question about the screen."},
			{Name: "key", Type: "string", Nullable: true, Desc: "key: a key or combination."},
			{Name: "direction", Type: "string", Nullable: true, Desc: "scroll: up or down."},
			{Name: "amount", Type: "integer", Nullable: true, Desc: "scroll: wheel clicks (default 5)."},
			{Name: "steps", Type: "string", Nullable: true, Desc: "batch: JSON list of actions (launch, click, move, drag, type, key, scroll, wait), each with its own arguments."},
			{Name: "caption", Type: "string", Nullable: true, Desc: "send: caption of the screenshot."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			cfg := d.Cfg()
			if !cfg.DesktopEnabled {
				return "", fmt.Errorf("the desktop is switched off in the settings")
			}
			act := strings.ToLower(strings.TrimSpace(a.Str("action")))
			mu.Lock()
			defer mu.Unlock()
			if act == "close" {
				d.desktop().Close()
				return "desktop closed", nil
			}
			max := cfg.DesktopSteps
			if max <= 0 {
				max = 25
			}
			if stopped && act != "send" && act != "see" {
				return "You are going in circles. Stop using the desktop now and tell the owner in one or two lines what you tried and what blocks you.", nil
			}
			if steps >= max && act != "send" {
				return fmt.Sprintf("Step limit reached (%d actions for this message). Tell the owner what you did; if he says to continue, you get more steps.", max), nil
			}
			ctx, cancel := context.WithTimeout(ctx, 90*time.Second)
			defer cancel()
			var out string
			err := d.desktop().Do(ctx, d.desktopOptions(), func(s *desktop.Screen) error {
				var err error
				out, err = desktopAct(ctx, d, chat, s, act, a, guard, &stopped)
				return err
			})
			if act != "send" {
				steps++
			}
			if err != nil {
				return "", err
			}
			if !stopped && max-steps <= 3 && act != "send" {
				out += fmt.Sprintf("\n! Осталось шагов: %d. Заканчивай и отчитайся.", max-steps)
			}
			return fmt.Sprintf("[рабочий стол, шаг %d/%d]\n%s", steps, max, out), nil
		},
	}
}

func intArg(a Args, k string, def int) int {
	if a.Has(k) {
		return int(a.Int(k))
	}
	return def
}

func desktopAct(ctx context.Context, d Deps, chat telegram.Chat, s *desktop.Screen, act string, a Args, g *loopGuard, stopped *bool) (string, error) {
	x := s.X()
	inScreen := func(px, py int) error {
		if px < 0 || py < 0 || px >= x.Width || py >= x.Height {
			return fmt.Errorf("the point (%d,%d) is outside the screen %dx%d", px, py, x.Width, x.Height)
		}
		return nil
	}
	px, py := intArg(a, "x", 0), intArg(a, "y", 0)
	changing := true
	switch act {
	case "launch":
		cmd := strings.TrimSpace(a.Str("command"))
		if cmd == "" {
			return "", fmt.Errorf("launch needs command")
		}
		if err := s.Launch(cmd); err != nil {
			return "", err
		}
		time.Sleep(1500 * time.Millisecond) // programs need a moment to draw their window
	case "look":
		changing = false
	case "wait":
		n := intArg(a, "amount", 2)
		time.Sleep(time.Duration(min(max(n, 1), 10)) * time.Second)
	case "batch":
		var steps []map[string]any
		if err := json.Unmarshal([]byte(a.Str("steps")), &steps); err != nil || len(steps) == 0 {
			return "", fmt.Errorf("batch needs steps: a JSON list like [{\"action\":\"click\",\"x\":100,\"y\":50},{\"action\":\"type\",\"text\":\"hi\"},{\"action\":\"key\",\"key\":\"Enter\"}]")
		}
		if len(steps) > 15 {
			steps = steps[:15]
		}
		var log []string
		for i, st := range steps {
			sa := Args(st)
			sa["_quick"] = true
			act2 := strings.ToLower(fmt.Sprint(st["action"]))
			if act2 == "batch" || act2 == "see" || act2 == "send" || act2 == "close" || act2 == "look" {
				return "", fmt.Errorf("step %d: %q cannot be inside a batch", i+1, act2)
			}
			if _, err := desktopAct(ctx, d, chat, s, act2, sa, g, stopped); err != nil {
				log = append(log, fmt.Sprintf("step %d (%s) failed: %v. The steps before it were done.", i+1, act2, err))
				break
			}
			log = append(log, fmt.Sprintf("step %d (%s) ok", i+1, act2))
		}
		time.Sleep(500 * time.Millisecond)
		img, err := x.Screenshot()
		if err != nil {
			return "", err
		}
		ws, _ := x.Windows()
		warn, stop := g.check(fmt.Sprint(desktop.Signature(img)))
		out := strings.Join(log, "\n") + "\nWindows:\n" + desktop.FormatWindows(ws)
		if stop {
			*stopped = true
			out += "\n! Ты ходишь по кругу: экран не меняется. Больше не используй рабочий стол в этом сообщении — скажи владельцу, на чём застряла."
		} else if warn != "" {
			out += "\n" + strings.Replace(warn, "Страница не изменилась", "Экран не изменился", 1)
		}
		return out, nil
	case "see":
		img, err := x.Screenshot()
		if err != nil {
			return "", err
		}
		if d.UI == nil {
			return "", fmt.Errorf("no vision available")
		}
		png, err := desktop.PNG(desktop.WithGrid(img, 100))
		if err != nil {
			return "", err
		}
		desc, err := d.UI.LookAtImage(ctx, png, strings.TrimSpace(a.Str("text"))+gridHint)
		if err != nil {
			return "", fmt.Errorf("the vision model could not look: %w (set llm.vision_model to a model that supports images)", err)
		}
		ws, _ := x.Windows()
		return "<screen_description>\n" + desc + "\n</screen_description>\nWindows:\n" + desktop.FormatWindows(ws), nil
	case "send":
		img, err := x.Screenshot()
		if err != nil {
			return "", err
		}
		png, err := desktop.PNG(img)
		if err != nil {
			return "", err
		}
		path := saveShot(d, png, "png")
		if _, err := d.TG.SendPhoto(ctx, chat.ID, png, strings.TrimSpace(a.Str("caption")), 0); err != nil {
			return "", fmt.Errorf("screenshot taken but not sent: %w", err)
		}
		return fmt.Sprintf("screenshot sent (%d KB), also saved as %s", len(png)/1024, path), nil
	case "click":
		if err := inScreen(px, py); err != nil {
			return "", err
		}
		btn := 1
		switch strings.ToLower(a.Str("button")) {
		case "right":
			btn = 3
		case "middle":
			btn = 2
		}
		n := 1
		if a.Bool("double") {
			n = 2
		}
		if err := x.Move(px, py); err != nil { // programs want to see the pointer arrive before the press
			return "", err
		}
		time.Sleep(80 * time.Millisecond)
		if err := x.Click(px, py, btn, n); err != nil {
			return "", err
		}
	case "move":
		if err := inScreen(px, py); err != nil {
			return "", err
		}
		if err := x.Move(px, py); err != nil {
			return "", err
		}
	case "drag":
		x2, y2 := intArg(a, "x2", -1), intArg(a, "y2", -1)
		if err := inScreen(px, py); err != nil {
			return "", err
		}
		if err := inScreen(x2, y2); err != nil {
			return "", err
		}
		if err := x.Drag(px, py, x2, y2); err != nil {
			return "", err
		}
	case "type":
		if a.Str("text") == "" {
			return "", fmt.Errorf("type needs text")
		}
		if err := x.TypeText(a.Str("text")); err != nil {
			return "", err
		}
	case "key":
		if err := x.Press(strings.TrimSpace(a.Str("key"))); err != nil {
			return "", err
		}
	case "scroll":
		n := intArg(a, "amount", 5)
		if n < 1 || n > 30 {
			n = 5
		}
		if !a.Has("x") {
			px, py = x.Width/2, x.Height/2
		}
		if err := inScreen(px, py); err != nil {
			return "", err
		}
		if err := x.Scroll(px, py, strings.ToLower(a.Str("direction")) != "up", n); err != nil {
			return "", err
		}
	default:
		return "", fmt.Errorf("unknown action %q; use launch, look, see, send, click, move, drag, type, key, scroll, wait, batch or close", act)
	}
	if a.Bool("_quick") { // a step inside a batch: no screenshot analysis, just a short pause for the program to react
		time.Sleep(200 * time.Millisecond)
		return "ok", nil
	}
	time.Sleep(500 * time.Millisecond)
	img, err := x.Screenshot()
	if err != nil {
		return "", err
	}
	ws, _ := x.Windows()
	var b strings.Builder
	b.WriteString("Windows:\n" + desktop.FormatWindows(ws))
	if changing {
		warn, stop := g.check(fmt.Sprint(desktop.Signature(img)))
		switch {
		case stop:
			*stopped = true
			b.WriteString("\n! Ты ходишь по кругу: экран не меняется. Больше не используй рабочий стол в этом сообщении — скажи владельцу, на чём застряла.")
		case warn != "":
			b.WriteString("\n" + strings.Replace(warn, "Страница не изменилась", "Экран не изменился", 1))
		default:
			b.WriteString("\nЭкран изменился.")
		}
	}
	return b.String(), nil
}
