package tools

import (
	"context"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"testing"
	"time"

	"kuni/internal/people"
	"kuni/internal/promises"
	"kuni/internal/reminders"
	"kuni/internal/telegram"
)

func planDeps(t *testing.T) Deps {
	d := ownerDeps(t, 5)
	d.Reminders = reminders.New(filepath.Join(t.TempDir(), "r.json"))
	d.People = people.New(filepath.Join(t.TempDir(), "p"))
	return d
}

func TestRemindSetListCancelAndScope(t *testing.T) {
	d := planDeps(t)
	priv := telegram.Chat{ID: 5, Kind: telegram.ChatPrivate}
	out, err := remindTool(d, priv).Run(context.Background(), Args{"when": "45m", "text": "drink water"})
	if err != nil || !strings.Contains(out, "#1") {
		t.Fatalf("%q %v", out, err)
	}
	if _, err := remindTool(d, priv).Run(context.Background(), Args{"when": "soon", "text": "x"}); err == nil {
		t.Fatal("bad time must fail")
	}
	// somebody else cannot set reminders in another chat, the owner can
	other := telegram.Chat{ID: 77, Kind: telegram.ChatPrivate}
	if _, err := remindTool(d, other).Run(context.Background(), Args{"when": "1h", "text": "x", "chat_id": float64(5)}); err == nil {
		t.Fatal("strangers set reminders only for their own chat")
	}
	if _, err := remindTool(d, priv).Run(context.Background(), Args{"when": "1h", "text": "for the group", "chat_id": float64(-9)}); err != nil {
		t.Fatalf("owner may: %v", err)
	}
	list, _ := remindersTool(d, priv).Run(context.Background(), Args{})
	if !strings.Contains(list, "drink water") || !strings.Contains(list, "for the group") {
		t.Fatalf("owner sees all: %s", list)
	}
	if _, err := remindersTool(d, other).Run(context.Background(), Args{"cancel_id": float64(1)}); err == nil {
		t.Fatal("a stranger cannot cancel the owner's reminder")
	}
	if out, err := remindersTool(d, priv).Run(context.Background(), Args{"cancel_id": float64(1)}); err != nil || !strings.Contains(out, "cancelled") {
		t.Fatalf("%q %v", out, err)
	}
}

func TestRememberPersonPrivacyAndTargets(t *testing.T) {
	d := planDeps(t)
	priv := telegram.Chat{ID: 41, Title: "Joe", Kind: telegram.ChatPrivate}
	if _, err := rememberPersonTool(d, priv).Run(context.Background(), Args{"fact": "afraid of dogs"}); err != nil {
		t.Fatal(err)
	}
	c := d.People.Get(41)
	if c.Name != "Joe" || len(c.Facts) != 1 || !c.Facts[0].Private {
		t.Fatalf("private chat facts are private by default: %+v", c)
	}
	group := telegram.Chat{ID: -3, Title: "G", Kind: telegram.ChatGroup}
	if _, err := rememberPersonTool(d, group).Run(context.Background(), Args{"fact": "x"}); err == nil {
		t.Fatal("in a group a user_id is required")
	}
	if _, err := rememberPersonTool(d, group).Run(context.Background(), Args{"fact": "plays chess", "user_id": float64(41)}); err != nil {
		t.Fatal(err)
	}
	if f := d.People.Get(41).Facts; len(f) != 2 || f[1].Private {
		t.Fatalf("group facts are public: %+v", f)
	}
	if out, _ := forgetPersonTool(d, priv).Run(context.Background(), Args{"contains": "dogs"}); !strings.Contains(out, "1") {
		t.Fatal(out)
	}
}

func TestBackgroundJobWakesHerWhenDone(t *testing.T) {
	d := planDeps(t)
	var mu sync.Mutex
	var woke string
	var wokeChat int64
	d.Wake = func(chat int64, text string) { mu.Lock(); woke, wokeChat = text, chat; mu.Unlock() }
	chat := telegram.Chat{ID: 5, Kind: telegram.ChatPrivate}
	out, err := shellBgTool(d, chat).Run(context.Background(), Args{"command": "echo building; sleep 0.3; echo done-ok; exit 3"})
	m := regexp.MustCompile(`#(\d+)`).FindStringSubmatch(out) // job ids are process-wide: -count=N runs see #2, #3...
	if err != nil || m == nil {
		t.Fatalf("%q %v", out, err)
	}
	id, _ := strconv.Atoi(m[1])
	if list, _ := jobsTool(d).Run(context.Background(), Args{}); !strings.Contains(list, "running") {
		t.Fatalf("should be running: %s", list)
	}
	deadline := time.Now().Add(5 * time.Second)
	for time.Now().Before(deadline) {
		mu.Lock()
		got := woke
		mu.Unlock()
		if got != "" {
			break
		}
		time.Sleep(50 * time.Millisecond)
	}
	mu.Lock()
	defer mu.Unlock()
	if wokeChat != 5 || !strings.Contains(woke, "exit code 3") || !strings.Contains(woke, "done-ok") {
		t.Fatalf("wake: chat=%d %q", wokeChat, woke)
	}
	if one, _ := jobsTool(d).Run(context.Background(), Args{"id": float64(id)}); !strings.Contains(one, "finished, exit 3") {
		t.Fatalf("%s", one)
	}
	// dangerous commands never start (when the hard block is on)
	d.Cfg().ShellHardBlock = true
	if out, _ := shellBgTool(d, chat).Run(context.Background(), Args{"command": "rm -rf /"}); !strings.Contains(out, "Blocked") {
		t.Fatalf("%s", out)
	}
}

func TestRememberPersonCanReplaceAnOutdatedFact(t *testing.T) {
	d := planDeps(t)
	priv := telegram.Chat{ID: 41, Title: "Joe", Kind: telegram.ChatPrivate}
	_, _ = rememberPersonTool(d, priv).Run(context.Background(), Args{"fact": "lives in Bishkek"})
	out, err := rememberPersonTool(d, priv).Run(context.Background(), Args{"fact": "moved to Almaty", "replaces": "bishkek"})
	if err != nil || !strings.Contains(out, "replaced") {
		t.Fatalf("%q %v", out, err)
	}
	if c := d.People.Get(41); len(c.Facts) != 1 || c.Facts[0].Text != "moved to Almaty" {
		t.Fatalf("the old fact must be overwritten: %+v", c.Facts)
	}
	out, _ = rememberPersonTool(d, priv).Run(context.Background(), Args{"fact": "has a cat", "replaces": "dog"})
	if !strings.Contains(out, "added") || len(d.People.Get(41).Facts) != 2 {
		t.Fatalf("with nothing to replace it is added: %q %+v", out, d.People.Get(41).Facts)
	}
}

func TestOwnerPromisesTools(t *testing.T) {
	d := planDeps(t)
	d.Promises = promises.New(filepath.Join(t.TempDir(), "pr.json"))
	ctx := context.Background()
	if _, err := promiseAddTool(d).Run(ctx, Args{"text": "апгрейд", "when": "2d"}); err != nil {
		t.Fatal(err)
	}
	if _, err := promiseAddTool(d).Run(ctx, Args{"text": "x", "when": "никогда"}); err == nil {
		t.Fatal("a date that cannot be read must be refused")
	}
	out, _ := promisesTool(d).Run(ctx, Args{})
	if !strings.Contains(out, "open: 1") || !strings.Contains(out, "апгрейд") {
		t.Fatal(out)
	}
	if _, err := promiseDoneTool(d).Run(ctx, Args{"id": float64(1)}); err != nil {
		t.Fatal(err)
	}
	if _, err := promiseDoneTool(d).Run(ctx, Args{"id": float64(1)}); err == nil {
		t.Fatal("closed twice")
	}
}
