package tools

import (
	"context"
	"time"

	"kuni/internal/anatomy"
)

// SenseTool lets her inspect her own sensors: where a sensation is, how strong, what she expected, and whose it is.
func SenseTool(d Deps) Tool {
	return Tool{
		Name:        "sense_inspect",
		Description: "Inspect your own sensor (your awareness is computational: you read your body model's sensors). Give a zone, organ (heart, lungs, brain, stomach, kidneys, liver, muscles, bones, skin) or a bone (череп, позвоночник, рёбра слева, бедренная кость левая...) or id (eyes, ears, nose, mouth, face, hands, skin, feet, belly, throat, chest, muscles, pain) to get its place, value, expectation, prediction error and cause; leave empty to see what is in your attention now.",
		Props:       []Prop{{Name: "sensor", Type: "string", Desc: "sensor id or zone; empty = what is in attention"}},
		Run: func(ctx context.Context, a Args) (string, error) {
			if d.Body != nil {
				bs := d.Body.Snapshot()
				d.Sense.Update(time.Now(), bs)
				os := anatomy.Organs(bs)
				if q := a.Str("sensor"); q != "" {
					if r := anatomy.BoneReport(anatomy.Skeleton(bs), q); r != "" {
						return r, nil
					}
					for _, o := range os {
						if o.ID == q || o.Name == q {
							return anatomy.Report(os, q), nil
						}
					}
				} else {
					return d.Sense.Snapshot().Report("") + "\nОрганы:\n" + anatomy.Report(os, ""), nil
				}
			}
			return d.Sense.Snapshot().Report(a.Str("sensor")), nil
		},
	}
}
