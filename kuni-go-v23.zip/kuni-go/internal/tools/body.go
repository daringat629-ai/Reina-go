package tools

import (
	"context"
)

// BodyTool lets her look after her body: eat, drink, coffee, pizza, shower.
func BodyTool(d Deps) Tool {
	return Tool{
		Name:        "body_do",
		Description: "Do something for your body: eat, drink, coffee, pizza or shower. The body answers (hunger goes away, you wake up a bit, stress drops). Use it when your <body> block says you are hungry, thirsty or tense, or just because you want it.",
		Props:       []Prop{{Name: "what", Type: "string", Desc: "eat | drink | coffee | pizza | shower"}},
		Run: func(ctx context.Context, a Args) (string, error) {
			return d.Body.Do(a.Str("what"), 0)
		},
	}
}
