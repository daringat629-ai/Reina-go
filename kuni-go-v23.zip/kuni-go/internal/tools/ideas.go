package tools

import (
	"context"
	"fmt"
	"time"
)

// IdeaTools: her box of wild ideas. She proposes, the owner answers yes or no in the panel; nothing happens without a yes.
func IdeaTools(d Deps) []Tool {
	return []Tool{{
		Name:        "idea",
		Description: "Put a wild idea into your idea box: about yourself, your world, your brain, your life, anything you really want. The owner will answer yes or no in the panel. Do not act on an idea before he says yes.",
		Props: []Prop{
			{Name: "title", Type: "string", Desc: "The idea in one sentence."},
			{Name: "why", Type: "string", Nullable: true, Desc: "Why you want it, in a few words."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			it, err := d.Ideas.Propose(a.Str("title"), a.Str("why"), time.Now())
			if err != nil {
				return "", err
			}
			return fmt.Sprintf("Idea #%d is in the box and waits for the owner's answer.", it.ID), nil
		},
	}, {
		Name:        "idea_done",
		Description: "Mark an idea the owner approved (yes) as carried out.",
		Props:       []Prop{{Name: "id", Type: "integer", Desc: "Idea number."}},
		Run: func(ctx context.Context, a Args) (string, error) {
			if !d.Ideas.MarkDone(int(a.Int("id"))) {
				return "", fmt.Errorf("idea #%d is not approved or already done", a.Int("id"))
			}
			return "Marked as done.", nil
		},
	}}
}
