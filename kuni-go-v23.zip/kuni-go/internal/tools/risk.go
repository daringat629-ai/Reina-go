package tools

import (
	"encoding/json"
	"regexp"
	"strings"
)

// A risky action is not forbidden (ShellDanger forbids the catastrophic ones): it needs the owner's "yes" first.
// RiskOf says why an action is risky, or "" when it is routine.

var reRisky = []struct {
	re  *regexp.Regexp
	why string
}{
	{regexp.MustCompile(`(?i)\brm\s+(-\w*[rf]\w*|--recursive|--force)\b`), "deleting files with rm -r / -f"},
	{regexp.MustCompile(`(?i)\b(kill|pkill|killall)\b`), "killing processes"},
	{regexp.MustCompile(`(?i)\b(reboot|shutdown|poweroff|halt)\b`), "rebooting or shutting the machine down"},
	{regexp.MustCompile(`(?i)\b(apk\s+(del|remove)|apt(-get)?\s+(remove|purge)|pip3?\s+uninstall|npm\s+(uninstall|rm)\b)`), "uninstalling software"},
	{regexp.MustCompile(`(?i)\b(chmod|chown)\s+(-\w*R\w*|--recursive)\b`), "changing permissions recursively"},
	{regexp.MustCompile(`(?i)\b(mkfs\S*|fdisk|parted|umount|mount)\b`), "touching disks and mounts"},
	{regexp.MustCompile(`(?i)(>>?|\btee\b)\s*/etc/`), "writing into /etc"},
	{regexp.MustCompile(`(?i)\bgit\s+(push|reset\s+--hard|clean\s+-\w*f)`), "a git operation that publishes or destroys work"},
	{regexp.MustCompile(`(?i)\b(curl|wget)\b[^|;&\n]*\|\s*(sudo\s+)?(sh|bash|zsh)\b`), "running a script straight from the internet"},
	{regexp.MustCompile(`(?i)\b(rc-service|service|systemctl)\b.*\b(stop|restart|disable|mask)\b|\brc-update\s+(del|add)\b`), "stopping or restarting a service"},
	{regexp.MustCompile(`(?i)((sed\s+-\w*i\w*|\btee\b|>>?|\bmv\b|\bcp\b|\bdd\b|perl\s+-\w*i)[^\n]*config\.toml|\breina(-tdlib)?\s+(set|max)\b)`), "changing her own settings file (models, keys, tokens)"},
	{regexp.MustCompile(`(?i)(\bssh\b[^\n]*\s-R\b|localhost\.run|\blhr\.life\b|\bngrok\b|\bcloudflared\b[^\n]*\btunnel\b|\bserveo\.net\b|\bbore\s+local\b|\blocaltunnel\b|\bpython3?\s+-m\s+http\.server\b)`), "opening a public tunnel or a web server to the internet"},
	{regexp.MustCompile(`(?i)\bcrontab\s+-r\b`), "wiping the crontab"},
	{regexp.MustCompile(`(?i)\b(iptables|ip6tables|nft|ufw)\b`), "changing the firewall"},
	{regexp.MustCompile(`(?i)\b(passwd|userdel|usermod|adduser|deluser)\b`), "changing user accounts"},
	{regexp.MustCompile(`(?i)\b(docker|podman|incus|lxc)\s+(rm|rmi|stop|kill|prune|delete|restart)\b`), "stopping or deleting containers"},
}

// shellRisk looks at a command line.
func shellRisk(cmd string) string {
	for _, r := range reRisky {
		if r.re.MatchString(cmd) {
			return r.why
		}
	}
	return ""
}

// RiskOf judges one tool call by its name and JSON arguments; ownerChat is the owner's chat id (0 = unknown).
func RiskOf(name, rawArgs string, ownerChat int64) string {
	var a map[string]any
	_ = json.Unmarshal([]byte(rawArgs), &a)
	str := func(k string) string {
		s, _ := a[k].(string)
		return strings.ToLower(strings.TrimSpace(s))
	}
	switch name {
	case "shell", "shell_bg":
		return shellRisk(str("command"))
	case "ssh":
		if why := shellRisk(str("command")); why != "" {
			return why + " on another machine"
		}
	case "files":
		if str("action") == "delete" {
			return "deleting files"
		}
	case "service":
		if act := str("action"); act == "stop" || act == "restart" {
			return "stopping or restarting a service"
		}
	case "proc":
		if str("action") == "kill" {
			return "killing a process"
		}
	case "git":
		if str("action") == "push" {
			return "pushing to a remote repository"
		}
	case "mail":
		if str("action") == "send" {
			return "sending an e-mail"
		}
	case "docker":
		if act := str("action"); act == "stop" || act == "restart" {
			return "stopping or restarting a container"
		}
	case "self_update":
		return "updating and restarting herself"
	case "send_file":
		if id, ok := a["chat_id"].(float64); ok && id != 0 && int64(id) != ownerChat {
			return "sending a file from the machine to another chat"
		}
	}
	return ""
}
