package tools

import (
	"context"
	"strings"

	"kuni/internal/learn"
)

// StudyTool lets her sit down and learn something in her room: a topic of her own, or the next one that explains her body.
func StudyTool(d Deps) Tool {
	return Tool{
		Name:        "study",
		Description: "Study something in your room: read the Wikipedia summary of a topic and keep what you learn. Give a topic (a Wikipedia page title in Russian, e.g. \"Сердце\", \"Гроза\"), or leave empty to study the next thing that explains your own body. What you learn comes back when the matching organ or sense is in your attention.",
		Props:       []Prop{{Name: "topic", Type: "string", Desc: "Wikipedia page title; empty = next topic about yourself"}},
		Run: func(ctx context.Context, a Args) (string, error) {
			t, ok := d.Learn.Next("")
			if q := strings.TrimSpace(a.Str("topic")); q != "" {
				t, ok = learnTopic(q), true
			}
			if !ok {
				return "Всё, что я наметила про себя, я уже выучила. Можно назвать свою тему.", nil
			}
			l, err := d.Learn.Study(ctx, t)
			if err != nil {
				return "", err
			}
			return "Выучила: " + l.Title + ". " + l.Summary, nil
		},
	}
}

func learnTopic(title string) learn.Topic { return learn.Topic{Title: title, Area: "mind"} }
