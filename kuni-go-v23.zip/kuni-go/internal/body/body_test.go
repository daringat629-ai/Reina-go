package body

import (
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func at(h int) time.Time { return time.Date(2026, 10, 27, h, 0, 0, 0, time.UTC) }

func TestRestingDayMakesHungryAndSleepy(t *testing.T) {
	b := New(filepath.Join(t.TempDir(), "b.json"))
	b.Tick(at(8), Resting, DefaultEnv)
	for h := 9; h <= 22; h++ {
		b.Tick(at(h), Working, DefaultEnv)
	}
	s := b.Snapshot()
	if s.Hunger() < .25 || s.Sleep < .7 || s.Thirst() < .1 {
		t.Fatalf("a long day must leave her hungry, thirsty and sleepy: %+v hunger=%.2f", s, s.Hunger())
	}
	if !strings.Contains(b.Prompt(), "хочется есть") || !strings.Contains(b.Prompt(), "клонит в сон") {
		t.Fatal(b.Prompt())
	}
	if b.Inputs()["night"] < .5 {
		t.Fatal("sleepiness must reach the brain")
	}
	b.Do("pizza", 0)
	b.Do("pizza", 0)
	b.Do("drink", 0)
	if b.Snapshot().Hunger() > .05 {
		t.Fatal("pizza must satisfy hunger")
	}
}

func TestRunningRaisesHeartAndFatigue(t *testing.T) {
	b := New(filepath.Join(t.TempDir(), "b.json"))
	b.Tick(at(8), Resting, DefaultEnv)
	rest := b.Snapshot().Heart
	b.Tick(at(8).Add(20*time.Minute), Running, DefaultEnv)
	s := b.Snapshot()
	if s.Heart < rest+40 || s.Fatigue < .4 || s.Temp <= 36.8 || s.Breath < 25 {
		t.Fatalf("%+v", s)
	}
	b.Tick(at(8).Add(20*time.Minute).Add(3*time.Hour), Resting, DefaultEnv)
	if b.Snapshot().Heart > rest+3 || b.Snapshot().Fatigue > .2 {
		t.Fatalf("rest must bring it back: %+v", b.Snapshot())
	}
}

func TestSleepPaysTheDebt(t *testing.T) {
	b := New(filepath.Join(t.TempDir(), "b.json"))
	b.Tick(at(6), Resting, DefaultEnv)
	b.Tick(at(22), Working, DefaultEnv)
	high := b.Snapshot().Sleep
	b.Tick(at(22).Add(8*time.Hour), Asleep, DefaultEnv)
	if b.Snapshot().Sleep > high-.4 {
		t.Fatal(high, b.Snapshot().Sleep)
	}
}

func TestPainFearAndSenses(t *testing.T) {
	b := New(filepath.Join(t.TempDir(), "b.json"))
	b.Tick(at(8), Resting, Env{Ambient: 10, Light: .05, Noise: .9, Scent: .5})
	sn := b.Snapshot().Senses()
	if sn.SightTxt != "темно" || sn.HearingTxt != "громко" || sn.TouchTxt != "холодно" || sn.SmellTxt != "ощутимый запах" {
		t.Fatalf("%+v", sn)
	}
	b.Do("hurt", .9)
	b.Do("scare", .8)
	s := b.Snapshot()
	if s.Pain < .8 || s.Bones >= 1 || b.Inputs()["threat"] < .7 || !strings.Contains(b.Prompt(), "болит") {
		t.Fatalf("%+v %s", s, b.Prompt())
	}
	if _, err := b.Do("fly", 0); err == nil {
		t.Fatal("unknown action")
	}
	if New(b.path).Snapshot().Bones != s.Bones {
		t.Fatal("the body is remembered")
	}
}

func TestRainAndColdOutside(t *testing.T) {
	b := New(filepath.Join(t.TempDir(), "b.json"))
	rain := Env{Ambient: 6, Light: .3, Noise: .6, Outside: true, Wind: .6, Rain: .8}
	b.Tick(at(12), Resting, DefaultEnv)
	b.Tick(at(14), Resting, rain)
	s := b.Snapshot()
	if s.Wet < .9 || s.Temp > 36.1 || !s.Outside || s.Feels > 0 {
		t.Fatalf("two hours still in cold rain: wet %.2f temp %.2f feels %.1f", s.Wet, s.Temp, s.Feels)
	}
	if !strings.Contains(b.Prompt(), "под дождём") || !strings.Contains(b.Prompt(), "мёрзнешь") {
		t.Fatal(b.Prompt())
	}
	if sn := s.Senses(); sn.TouchTxt != "промокла насквозь" || sn.SmellTxt != "пахнет дождём" {
		t.Fatalf("%+v", sn)
	}
	b.Tick(at(14).Add(90*time.Minute), Resting, DefaultEnv)
	if b.Snapshot().Wet > .2 || b.Snapshot().Temp < 36.3 {
		t.Fatalf("warm and dry again: %+v", b.Snapshot())
	}
	walk := New(filepath.Join(t.TempDir(), "w.json"))
	walk.Tick(at(12), Resting, DefaultEnv)
	walk.Tick(at(14), Walking, Env{Ambient: 6, Light: .5, Outside: true})
	if walk.Snapshot().Temp < 36.4 {
		t.Fatalf("walking keeps her warm in the cold: %.2f", walk.Snapshot().Temp)
	}
}
