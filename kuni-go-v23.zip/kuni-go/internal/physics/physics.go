// Package physics is the world's physics for her body: gravity, solid walls and floors, friction (slippery when wet),
// falling and what a fall does to a body, and the weather (temperature, wind, rain, wetness) that decides what the skin
// feels outside. It is a small, honest engine: capsule against boxes, semi-implicit Euler, no tricks. The same rules apply to
// her as to anyone: a wall stops her, a fall from three metres hurts, rain soaks and cools.
package physics

import (
	"math"
	"sync"
	"time"
)

const (
	Gravity   = 9.81
	Radius    = 0.3 // her body is a capsule 1.65 m tall, 0.3 m radius
	Height    = 1.65
	StepUp    = 0.35 // she can step onto a curb this high
	JumpSpeed = 3.6  // m/s: about 0.65 m up
)

// Vec is a point or a velocity (y is up).
type Vec struct{ X, Y, Z float64 }

func (a Vec) Add(b Vec) Vec       { return Vec{a.X + b.X, a.Y + b.Y, a.Z + b.Z} }
func (a Vec) Scale(k float64) Vec { return Vec{a.X * k, a.Y * k, a.Z * k} }
func (a Vec) Len() float64        { return math.Sqrt(a.X*a.X + a.Y*a.Y + a.Z*a.Z) }
func (a Vec) Horizontal() float64 { return math.Hypot(a.X, a.Z) }

// Box is a solid axis-aligned block (a wall, a building, a bed).
type Box struct{ Min, Max Vec }

// World is the solid things in it; the ground is the plane y = 0.
type World struct{ Solids []Box }

// Walker is her body in the world.
type Walker struct {
	Pos      Vec // feet
	Vel      Vec
	OnGround bool
	Wet      float64 // 0 dry .. 1 soaked: how slippery the ground is under her
}

// Wish is what she wants this step: a direction of travel and speed (m/s), and whether she jumps.
type Wish struct {
	DirX, DirZ float64
	Speed      float64
	Jump       bool
}

// Impact is what happened during a step that the body must feel.
type Impact struct {
	Fell   float64 // speed (m/s) at which she hit the ground or a ceiling, 0 if she did not
	Bumped float64 // speed (m/s) of walking into a wall, 0 if she did not
	Slip   bool    // her feet went out from under her
}

// Pain converts an impact into pain (0..1) and bone damage: about 0.2 for a 2 m drop, bones at risk from ~4 m.
func (i Impact) Pain() float64 {
	v := math.Max(i.Fell-3.5, 0)/6 + math.Max(i.Bumped-2.2, 0)/8
	if i.Slip {
		v += .12
	}
	return math.Min(1, v)
}

// support returns the height of the highest solid top under the capsule's footprint at (x, z) that is not above maxY.
func (w *World) support(x, z, maxY float64) float64 {
	h := 0.0
	for _, b := range w.Solids {
		if x+Radius > b.Min.X && x-Radius < b.Max.X && z+Radius > b.Min.Z && z-Radius < b.Max.Z && b.Max.Y <= maxY && b.Max.Y > h {
			h = b.Max.Y
		}
	}
	return h
}

// blocked reports whether the capsule body (from feet+StepUp to head) at (x, y, z) overlaps a solid.
func (w *World) blocked(x, y, z float64) bool {
	for _, b := range w.Solids {
		if x+Radius > b.Min.X && x-Radius < b.Max.X && z+Radius > b.Min.Z && z-Radius < b.Max.Z &&
			y+StepUp < b.Max.Y && y+Height > b.Min.Y {
			return true
		}
	}
	return false
}

// Step advances the walker by dt seconds.
func (w *World) Step(k *Walker, dt float64, wish Wish) Impact {
	var im Impact
	grip := 1 - 0.7*k.Wet // wet ground gives less grip
	if k.OnGround {
		// accelerate toward the wished velocity; less grip = slower response and more sliding
		want := Vec{wish.DirX * wish.Speed, 0, wish.DirZ * wish.Speed}
		a := math.Min(1, dt*10*grip)
		k.Vel.X += (want.X - k.Vel.X) * a
		k.Vel.Z += (want.Z - k.Vel.Z) * a
		if wish.Jump {
			k.Vel.Y, k.OnGround = JumpSpeed, false
		}
		// turning hard at speed on a wet surface: the feet go
		if k.Wet > .5 && wish.Speed > 2.5 && k.Vel.Horizontal() > 2.5 {
			dot := (k.Vel.X*wish.DirX + k.Vel.Z*wish.DirZ) / (k.Vel.Horizontal() + 1e-9)
			if dot < .2 {
				im.Slip = true
			}
		}
	} else {
		k.Vel.X += wish.DirX * wish.Speed * dt * 0.5 // a little air control
		k.Vel.Z += wish.DirZ * wish.Speed * dt * 0.5
	}
	k.Vel.Y -= Gravity * dt
	// horizontal move with wall collision (axis by axis, so she slides along walls)
	nx := k.Pos.X + k.Vel.X*dt
	if w.blocked(nx, k.Pos.Y, k.Pos.Z) {
		im.Bumped = math.Max(im.Bumped, math.Abs(k.Vel.X))
		k.Vel.X = 0
		nx = k.Pos.X
	}
	nz := k.Pos.Z + k.Vel.Z*dt
	if w.blocked(nx, k.Pos.Y, nz) {
		im.Bumped = math.Max(im.Bumped, math.Abs(k.Vel.Z))
		k.Vel.Z = 0
		nz = k.Pos.Z
	}
	k.Pos.X, k.Pos.Z = nx, nz
	// vertical move: land on the highest support, bump the head on a ceiling
	ny := k.Pos.Y + k.Vel.Y*dt
	floor := w.support(k.Pos.X, k.Pos.Z, k.Pos.Y+StepUp+1e-9)
	if k.Vel.Y <= 0 && ny <= floor {
		if !k.OnGround && -k.Vel.Y > 0 {
			im.Fell = -k.Vel.Y
		}
		ny, k.Vel.Y, k.OnGround = floor, 0, true
	} else if k.Vel.Y <= 0 && k.OnGround && ny > floor+0.02 {
		k.OnGround = false // walked off an edge
	} else if k.Vel.Y > 0 {
		k.OnGround = false
		for _, b := range w.Solids {
			if k.Pos.X+Radius > b.Min.X && k.Pos.X-Radius < b.Max.X && k.Pos.Z+Radius > b.Min.Z && k.Pos.Z-Radius < b.Max.Z &&
				k.Pos.Y+Height <= b.Min.Y && ny+Height > b.Min.Y {
				im.Fell = math.Max(im.Fell, k.Vel.Y)
				ny, k.Vel.Y = b.Min.Y-Height, 0
			}
		}
	}
	k.Pos.Y = ny
	return im
}

// Weather is the sky above the city right now.
type Weather struct {
	Temp   float64 // air temperature, °C
	Wind   float64 // 0 calm .. 1 storm
	Rain   float64 // 0 dry .. 1 downpour
	Cloud  float64 // 0 clear .. 1 overcast
	Light  float64 // 0 dark .. 1 bright sun
	Season string
}

func wave(t float64, period, phase float64) float64 {
	return math.Sin((t/period + phase) * 2 * math.Pi)
}

// At computes the weather for a moment. It is deterministic (the same city always has the same sky at the same time):
// the year sets the average temperature, the day swings it by about 8 degrees with the afternoon warmest, and slow
// slow waves of different length make fronts of cloud, wind and rain.
func At(t time.Time) Weather {
	doy := float64(t.YearDay())
	hour := float64(t.Hour()) + float64(t.Minute())/60
	year := wave(doy, 365, -0.22)         // coldest in January
	day := wave(hour, 24, -0.375)         // warmest at 15:00
	front := wave(doy*24+hour, 130, 0.13) // a front passes about every 5 days
	front2 := wave(doy*24+hour, 47, 0.61)
	cloud := clamp01(0.5 + 0.4*front + 0.15*front2)
	rain := clamp01((cloud-0.72)/0.28) * clamp01(0.5+0.5*front2)
	temp := 11 + 14*year + 4*day - 4*rain
	wind := clamp01(0.15 + 0.35*math.Abs(front) + 0.25*rain)
	sun := math.Max(0, math.Sin((hour-6)/12*math.Pi)) * (1 - 0.75*cloud)
	season := "зима"
	switch m := t.Month(); {
	case m >= 3 && m <= 5:
		season = "весна"
	case m >= 6 && m <= 8:
		season = "лето"
	case m >= 9 && m <= 11:
		season = "осень"
	}
	return Weather{Temp: temp, Wind: wind, Rain: rain, Cloud: cloud, Light: clamp01(0.06 + sun), Season: season}
}

func clamp01(v float64) float64 { return math.Max(0, math.Min(1, v)) }

// Skin is what the weather does to a body outside: the temperature that feels like it (wind chill and wet clothes included)
// and how fast clothes get wet or dry.
func (w Weather) Feels(wet float64) float64 {
	return w.Temp - w.Wind*7 - wet*5
}

// Dry advances the wetness of her clothes by dt seconds: rain soaks them in minutes, indoors they dry in an hour.
func Dry(wet float64, outside bool, w Weather, dt float64) float64 {
	if outside && w.Rain > .05 {
		wet += w.Rain * dt / 240
	} else if outside {
		wet -= dt / (2 * 3600) * (1 + w.Wind)
	} else {
		wet -= dt / 3600
	}
	return clamp01(wet)
}

// Presence is where she is, as last reported by her world (the city page): in her room or out in the city.
// A report older than three minutes is forgotten: nobody is watching her world, so she is in her room.
type Presence struct {
	mu      sync.Mutex
	outside bool
	act     string
	at      time.Time
}

// Report records where she is now.
func (p *Presence) Report(outside bool, act string, now time.Time) {
	p.mu.Lock()
	p.outside, p.act, p.at = outside, act, now
	p.mu.Unlock()
}

// Outside reports whether she is out in the city (false when unknown) and what she is doing.
func (p *Presence) Outside(now time.Time) (bool, string) {
	if p == nil {
		return false, ""
	}
	p.mu.Lock()
	defer p.mu.Unlock()
	if now.Sub(p.at) > 3*time.Minute {
		return false, ""
	}
	return p.outside, p.act
}
