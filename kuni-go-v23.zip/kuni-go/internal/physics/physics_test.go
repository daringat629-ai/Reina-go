package physics

import (
	"math"
	"testing"
	"time"
)

func settle(w *World, k *Walker, secs float64) Impact {
	var last Impact
	var acc Impact
	for t := 0.0; t < secs; t += 1.0 / 120 {
		last = w.Step(k, 1.0/120, Wish{})
		acc.Fell = math.Max(acc.Fell, last.Fell)
		acc.Bumped = math.Max(acc.Bumped, last.Bumped)
	}
	return acc
}

func TestFallingHurtsInProportionToHeight(t *testing.T) {
	w := &World{}
	low := &Walker{Pos: Vec{0, 0.5, 0}}
	if im := settle(w, low, 2); im.Pain() > 0.01 {
		t.Fatalf("a 0.5 m hop must not hurt: %+v pain %.2f", im, im.Pain())
	}
	mid := &Walker{Pos: Vec{0, 3, 0}}
	pm := settle(w, mid, 3).Pain()
	high := &Walker{Pos: Vec{0, 8, 0}}
	ph := settle(w, high, 4).Pain()
	if !(pm < ph) || ph < .3 || !high.OnGround || high.Pos.Y != 0 {
		t.Fatalf("falls: 3 m pain %.2f, 8 m pain %.2f, %+v", pm, ph, high)
	}
}

func TestWallsStopHerAndCurbsAreStepped(t *testing.T) {
	w := &World{Solids: []Box{{Vec{5, 0, -5}, Vec{6, 4, 5}}, {Vec{2, 0, -5}, Vec{3, 0.2, 5}}}}
	k := &Walker{Pos: Vec{0, 0, 0}, OnGround: true}
	var bumped float64
	for i := 0; i < 120*6; i++ {
		im := w.Step(k, 1.0/120, Wish{DirX: 1, Speed: 1.5})
		bumped = math.Max(bumped, im.Bumped)
	}
	if k.Pos.X > 5-Radius+0.02 || k.Pos.X < 4.5 {
		t.Fatalf("the wall must stop her at ~4.7, she is at %.2f", k.Pos.X)
	}
	if k.Pos.Y != 0.2-0.2 && k.Pos.Y > 0.01 {
		t.Fatalf("after the curb she is back on the ground, y=%.2f", k.Pos.Y)
	}
	if bumped < 1 {
		t.Fatal("walking into a wall must be felt")
	}
}

func TestStandingOnABoxAndJumping(t *testing.T) {
	w := &World{Solids: []Box{{Vec{-1, 0, -1}, Vec{1, 1, 1}}}}
	k := &Walker{Pos: Vec{0, 2.5, 0}}
	settle(w, k, 2)
	if math.Abs(k.Pos.Y-1) > 1e-6 || !k.OnGround {
		t.Fatalf("she must land on the box: %+v", k)
	}
	w.Step(k, 1.0/120, Wish{Jump: true})
	if k.OnGround || k.Vel.Y < 3 {
		t.Fatalf("jump: %+v", k)
	}
}

func TestWetGroundIsSlippery(t *testing.T) {
	w := &World{}
	dry := &Walker{Pos: Vec{}, OnGround: true}
	wet := &Walker{Pos: Vec{}, OnGround: true, Wet: 1}
	for i := 0; i < 30; i++ {
		w.Step(dry, 1.0/120, Wish{DirX: 1, Speed: 3})
		w.Step(wet, 1.0/120, Wish{DirX: 1, Speed: 3})
	}
	if !(wet.Vel.X < dry.Vel.X) {
		t.Fatalf("less grip when wet: %.2f vs %.2f", wet.Vel.X, dry.Vel.X)
	}
	for i := 0; i < 360; i++ {
		w.Step(wet, 1.0/120, Wish{DirX: 1, Speed: 3})
	}
	slip := false
	for i := 0; i < 200; i++ {
		im := w.Step(wet, 1.0/120, Wish{DirX: -1, Speed: 3})
		slip = slip || im.Slip
	}
	if !slip {
		t.Fatal("reversing hard on a wet street must be able to make her slip")
	}
}

func TestWeatherIsSeasonalAndDaily(t *testing.T) {
	jan := At(time.Date(2026, 1, 15, 15, 0, 0, 0, time.UTC))
	jul := At(time.Date(2026, 7, 15, 15, 0, 0, 0, time.UTC))
	if !(jul.Temp > jan.Temp+15) {
		t.Fatalf("summer must be much warmer: %.1f vs %.1f", jul.Temp, jan.Temp)
	}
	aft := At(time.Date(2026, 7, 15, 15, 0, 0, 0, time.UTC))
	night := At(time.Date(2026, 7, 15, 3, 0, 0, 0, time.UTC))
	if !(aft.Temp > night.Temp) || night.Light > .1 {
		t.Fatalf("afternoon warmer than night, dark at 3: %+v %+v", aft, night)
	}
	if At(time.Date(2026, 7, 15, 15, 0, 0, 0, time.UTC)) != jul {
		t.Fatal("deterministic")
	}
	wet := 0
	for d := 0; d < 365; d++ {
		if At(time.Date(2026, 1, 1, 12, 0, 0, 0, time.UTC).AddDate(0, 0, d)).Rain > .2 {
			wet++
		}
	}
	if wet < 15 || wet > 200 {
		t.Fatalf("rain days a year: %d", wet)
	}
}

func TestRainSoaksAndRoomsDry(t *testing.T) {
	rainy := Weather{Temp: 8, Wind: .5, Rain: .8}
	w := 0.0
	for i := 0; i < 10; i++ {
		w = Dry(w, true, rainy, 60)
	}
	if w < .8 {
		t.Fatalf("ten minutes of rain must soak her: %.2f", w)
	}
	if rainy.Feels(w) > 8-.5*7-3 {
		t.Fatal("wet in wind feels much colder than the thermometer")
	}
	for i := 0; i < 70; i++ {
		w = Dry(w, false, rainy, 60)
	}
	if w > .01 {
		t.Fatalf("an hour indoors dries her: %.2f", w)
	}
}
