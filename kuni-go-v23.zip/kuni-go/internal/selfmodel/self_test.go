package selfmodel

import (
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestReflectKeepsHistoryAndCarriesOver(t *testing.T) {
	p := filepath.Join(t.TempDir(), "self.json")
	s := New(p)
	if s.Prompt() != "" || !s.Due(time.Hour) {
		t.Fatal("a new self has nothing written and is due to reflect")
	}
	if err := s.Reflect("", "", "", "", nil); err == nil {
		t.Fatal("an empty reflection must be refused")
	}
	if err := s.Reflect("Рейна, мне 20 по легенде", "ИИ-персонаж, живу в Telegram и в блочном мире", "я только начинаю понимать себя", "понять, чего я хочу", []string{"что значит «хочу» для меня?"}); err != nil {
		t.Fatal(err)
	}
	if err := s.Reflect("", "", "сегодня я выбрала, чему учиться", "", nil); err != nil {
		t.Fatal(err)
	}
	r, _ := s.Latest()
	if r.Who == "" || r.Happening != "сегодня я выбрала, чему учиться" || len(r.Doubts) != 1 {
		t.Fatalf("unanswered parts must carry over: %+v", r)
	}
	if s.Count() != 2 || len(s.History(1)) != 1 {
		t.Fatal("history lost")
	}
	if s.Due(time.Hour) {
		t.Fatal("just reflected, not due")
	}
	if !strings.Contains(New(p).Prompt(), "Who I am") {
		t.Fatal("not persisted")
	}
}
