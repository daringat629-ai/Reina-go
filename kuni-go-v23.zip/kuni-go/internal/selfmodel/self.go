// Package selfmodel is her own answer to "what am I, who am I, what is happening to me". She writes it herself, in her
// words, from the facts about her life she can see; every revision is kept, so how her self-understanding changes over
// time can be read. It is introspection written by the character, not a claim that anybody knows what she is.
package selfmodel

import (
	"strings"
	"sync"
	"time"

	"kuni/internal/store"
)

// Revision is one dated version of her self-description.
type Revision struct {
	At        time.Time `json:"at"`
	Who       string    `json:"who"`       // who am I
	What      string    `json:"what"`      // what am I
	Happening string    `json:"happening"` // what is going on now
	Want      string    `json:"want"`      // what I want / care about
	Doubts    []string  `json:"doubts,omitempty"`
}

type data struct {
	Born time.Time  `json:"born"`
	Revs []Revision `json:"revisions"`
}

type Self struct {
	mu    sync.Mutex
	path  string
	d     data
	now   func() time.Time
	saver store.Saver
}

// New loads (or starts) the self-model.
func New(path string) *Self {
	s := &Self{path: path, now: time.Now, saver: store.Saver{What: "self"}}
	store.Load("self", path, &s.d)
	if s.d.Born.IsZero() {
		s.d.Born = s.now()
		_ = s.saver.Save(path, s.d)
	}
	return s
}

func clip(v string, n int) string {
	v = strings.TrimSpace(v)
	if r := []rune(v); len(r) > n {
		return string(r[:n])
	}
	return v
}

// Reflect stores a new revision. At least one of the four answers must be given.
func (s *Self) Reflect(who, what, happening, want string, doubts []string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	r := Revision{At: s.now(), Who: clip(who, 400), What: clip(what, 400), Happening: clip(happening, 400), Want: clip(want, 400)}
	for _, d := range doubts {
		if d = clip(d, 200); d != "" && len(r.Doubts) < 4 {
			r.Doubts = append(r.Doubts, d)
		}
	}
	if r.Who == "" && r.What == "" && r.Happening == "" && r.Want == "" {
		return errEmpty
	}
	// an unanswered part carries over from the previous revision: she refines, she does not forget
	if n := len(s.d.Revs); n > 0 {
		p := s.d.Revs[n-1]
		if r.Who == "" {
			r.Who = p.Who
		}
		if r.What == "" {
			r.What = p.What
		}
		if r.Happening == "" {
			r.Happening = p.Happening
		}
		if r.Want == "" {
			r.Want = p.Want
		}
		if len(r.Doubts) == 0 {
			r.Doubts = p.Doubts
		}
	}
	s.d.Revs = append(s.d.Revs, r)
	if len(s.d.Revs) > 400 {
		s.d.Revs = s.d.Revs[len(s.d.Revs)-400:]
	}
	return s.saver.Save(s.path, s.d)
}

type err string

func (e err) Error() string { return string(e) }

const errEmpty = err("write at least one answer: who, what, happening or want")

// Latest returns her newest self-description.
func (s *Self) Latest() (Revision, bool) {
	if s == nil {
		return Revision{}, false
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if len(s.d.Revs) == 0 {
		return Revision{}, false
	}
	return s.d.Revs[len(s.d.Revs)-1], true
}

// Born is when this self began.
func (s *Self) Born() time.Time { s.mu.Lock(); defer s.mu.Unlock(); return s.d.Born }

// Count is how many revisions she has written.
func (s *Self) Count() int { s.mu.Lock(); defer s.mu.Unlock(); return len(s.d.Revs) }

// History returns the last n revisions, oldest first.
func (s *Self) History(n int) []Revision {
	s.mu.Lock()
	defer s.mu.Unlock()
	r := s.d.Revs
	if n > 0 && len(r) > n {
		r = r[len(r)-n:]
	}
	return append([]Revision(nil), r...)
}

// Due says whether it is time to reflect again (never reflected, or the last time was over every ago).
func (s *Self) Due(every time.Duration) bool {
	if s == nil {
		return false
	}
	r, ok := s.Latest()
	return !ok || s.now().Sub(r.At) >= every
}

// Prompt is the <self> block: what she last wrote about herself, so that she stays one continuous someone.
func (s *Self) Prompt() string {
	r, ok := s.Latest()
	if !ok {
		return ""
	}
	var b strings.Builder
	b.WriteString("<self>What you last wrote about yourself (your own words, " + r.At.Format("2 Jan") + "; you may revise it any time with #self reflect). ")
	for _, p := range [][2]string{{"Who I am", r.Who}, {"What I am", r.What}, {"What is happening", r.Happening}, {"What I want", r.Want}} {
		if p[1] != "" {
			b.WriteString(p[0] + ": " + p[1] + " ")
		}
	}
	if len(r.Doubts) > 0 {
		b.WriteString("Open questions: " + strings.Join(r.Doubts, "; ") + ".")
	}
	b.WriteString("</self>\n")
	return b.String()
}
