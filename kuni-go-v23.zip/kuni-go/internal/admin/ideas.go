package admin

import (
	"encoding/json"
	"net/http"
	"time"

	"kuni/internal/feel"
)

// ideasAPI: GET lists her wild ideas, POST {id, yes} answers one.
func (p *Panel) ideasAPI(w http.ResponseWriter, r *http.Request) {
	if p.Ideas == nil {
		fail(w, http.StatusNotFound, "ящик идей выключен")
		return
	}
	switch r.Method {
	case http.MethodGet:
		writeJSON(w, map[string]any{"ideas": p.Ideas.List()})
	case http.MethodPost:
		var req struct {
			ID  int  `json:"id"`
			Yes bool `json:"yes"`
		}
		if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 4<<10)).Decode(&req); err != nil {
			fail(w, http.StatusBadRequest, "неверный запрос")
			return
		}
		if err := p.Ideas.Decide(req.ID, req.Yes, time.Now()); err != nil {
			fail(w, http.StatusConflict, err.Error())
			return
		}
		if p.Feel != nil && req.Yes {
			p.Feel.Impulse(time.Now(), feel.Idea)
		}
		if p.Feed != nil {
			ans := "нет"
			if req.Yes {
				ans = "да"
			}
			p.Feed.Add("ideas", "", "папик ответил на идею #"+itoa(int64(req.ID))+": "+ans)
		}
		writeJSON(w, map[string]any{"ok": "записано"})
	default:
		http.Error(w, "GET or POST", http.StatusMethodNotAllowed)
	}
}
