// Package ideas is her box of wild ideas: she proposes, the owner answers "да" or "нет". Nothing happens without a "да", and
// an approved idea is only a permission to try what her own tools can do (code changes are for the owner to carry out).
package ideas

import (
	"errors"
	"fmt"
	"strings"
	"sync"
	"time"

	"kuni/internal/store"
)

const (
	Waiting = "new"
	Yes     = "yes"
	No      = "no"
	Done    = "done"
)

// Item is one idea.
type Item struct {
	ID      int       `json:"id"`
	Title   string    `json:"title"`
	Why     string    `json:"why,omitempty"`
	Status  string    `json:"status"`
	Created time.Time `json:"created"`
	Decided time.Time `json:"decided,omitempty"`
}

type data struct {
	Items []Item `json:"items"`
	Next  int    `json:"next"`
}

// Store keeps the ideas in one JSON file.
type Store struct {
	mu    sync.Mutex
	path  string
	d     data
	saver store.Saver
}

const maxWaiting = 12 // she cannot flood the owner with ideas

// Open loads the box (missing = empty).
func Open(path string) *Store {
	s := &Store{path: path, saver: store.Saver{What: "ideas"}}
	store.Load("ideas", path, &s.d)
	if s.d.Next == 0 {
		s.d.Next = 1
	}
	return s
}

func (s *Store) save() { _ = s.saver.Save(s.path, s.d) }

// Propose adds an idea that waits for the owner's answer.
func (s *Store) Propose(title, why string, now time.Time) (Item, error) {
	title = strings.TrimSpace(title)
	if len([]rune(title)) < 4 {
		return Item{}, errors.New("опиши идею хотя бы одной фразой")
	}
	if r := []rune(title); len(r) > 200 {
		title = string(r[:200])
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	waiting := 0
	for _, it := range s.d.Items {
		if it.Status == Waiting {
			waiting++
			if strings.EqualFold(it.Title, title) {
				return Item{}, errors.New("такая идея уже ждёт ответа")
			}
		}
	}
	if waiting >= maxWaiting {
		return Item{}, fmt.Errorf("папик ещё не ответил на %d твоих идей: подожди", waiting)
	}
	it := Item{ID: s.d.Next, Title: title, Why: strings.TrimSpace(why), Status: Waiting, Created: now}
	s.d.Next++
	s.d.Items = append(s.d.Items, it)
	s.save()
	return it, nil
}

// Decide records the owner's answer to a waiting idea.
func (s *Store) Decide(id int, yes bool, now time.Time) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	for i := range s.d.Items {
		if s.d.Items[i].ID == id {
			if s.d.Items[i].Status != Waiting {
				return errors.New("на эту идею уже ответили")
			}
			s.d.Items[i].Status = No
			if yes {
				s.d.Items[i].Status = Yes
			}
			s.d.Items[i].Decided = now
			s.save()
			return nil
		}
	}
	return errors.New("нет такой идеи")
}

// MarkDone closes an approved idea she has carried out.
func (s *Store) MarkDone(id int) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	for i := range s.d.Items {
		if s.d.Items[i].ID == id && s.d.Items[i].Status == Yes {
			s.d.Items[i].Status = Done
			s.save()
			return true
		}
	}
	return false
}

// List returns all ideas, newest first.
func (s *Store) List() []Item {
	s.mu.Lock()
	defer s.mu.Unlock()
	out := make([]Item, len(s.d.Items))
	for i, it := range s.d.Items {
		out[len(out)-1-i] = it
	}
	return out
}

// Prompt tells her what the owner approved (to try with her own tools) and invites her to propose; nil-safe.
func (s *Store) Prompt() string {
	if s == nil {
		return ""
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	var b strings.Builder
	for _, it := range s.d.Items {
		if it.Status == Yes {
			fmt.Fprintf(&b, "#%d %s\n", it.ID, it.Title)
		}
	}
	out := "<ideas>У тебя есть ящик безумных идей: предложи через #idea то, что тебе правда хочется (про себя, мир, мозг, жизнь), папик ответит да или нет. Без его «да» ничего не делай.\n"
	if b.Len() > 0 {
		out += "Папик ответил ДА на это (можно пробовать своими инструментами, потом #idea_done):\n" + b.String()
	}
	return out + "</ideas>\n"
}
