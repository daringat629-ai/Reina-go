package ideas

import (
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestIdeasFlow(t *testing.T) {
	p := filepath.Join(t.TempDir(), "i.json")
	s := Open(p)
	now := time.Now()
	if _, err := s.Propose("ab", "", now); err == nil {
		t.Fatal("too short")
	}
	a, err := s.Propose("Построить в городе библиотеку снов", "хочу", now)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := s.Propose("построить в городе библиотеку снов", "", now); err == nil {
		t.Fatal("duplicate")
	}
	if strings.Contains(s.Prompt(), "ответил ДА") {
		t.Fatal("nothing approved yet")
	}
	if s.MarkDone(a.ID) {
		t.Fatal("cannot finish what is not approved")
	}
	if err := s.Decide(a.ID, true, now); err != nil {
		t.Fatal(err)
	}
	if s.Decide(a.ID, false, now) == nil {
		t.Fatal("answered twice")
	}
	if !strings.Contains(s.Prompt(), "библиотеку снов") {
		t.Fatal(s.Prompt())
	}
	if !s.MarkDone(a.ID) || strings.Contains(s.Prompt(), "библиотеку снов") {
		t.Fatal("done ideas leave her list")
	}
	if Open(p).List()[0].Status != Done {
		t.Fatal("not saved")
	}
	for i := 0; i < 20; i++ {
		s.Propose(strings.Repeat("x", 5)+string(rune('a'+i)), "", now)
	}
	if n := 0; len(s.List()) > maxWaiting+1 {
		t.Fatal("flood", n)
	}
}
