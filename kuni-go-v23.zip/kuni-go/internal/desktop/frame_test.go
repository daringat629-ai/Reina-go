package desktop

import (
	"bytes"
	"context"
	"image/jpeg"
	"os"
	"os/exec"
	"testing"
	"time"
)

func TestLiveFrameWorksWhileAnActionHoldsTheDesktop(t *testing.T) {
	need(t)
	d := New()
	defer d.Close()
	if _, ok, _ := d.Frame(); ok || d.Live() {
		t.Fatal("a stopped desktop has no picture")
	}
	inAction, release := make(chan struct{}), make(chan struct{})
	done := make(chan error, 1)
	go func() {
		done <- d.Do(context.Background(), Options{Width: 800, Height: 600}, func(s *Screen) error {
			if err := s.X().Move(321, 123); err != nil {
				return err
			}
			close(inAction)
			<-release // a long action: the desktop lock is held
			return nil
		})
	}()
	<-inAction
	got := make(chan []byte, 1)
	go func() {
		b, ok, err := d.Frame()
		if !ok || err != nil {
			t.Error("frame:", ok, err)
		}
		got <- b
	}()
	select {
	case b := <-got:
		img, err := jpeg.Decode(bytes.NewReader(b))
		if err != nil || img.Bounds().Dx() != 800 || img.Bounds().Dy() != 600 {
			t.Fatalf("not a screen-sized jpeg: %v", err)
		}
	case <-time.After(5 * time.Second):
		t.Fatal("the live view waited for the action")
	}
	if x, y, ok := d.Pointer(); !ok || x != 321 || y != 123 {
		t.Fatalf("pointer: %d,%d,%v", x, y, ok)
	}
	if !d.Live() {
		t.Fatal("Live must be true while running")
	}
	close(release)
	if err := <-done; err != nil {
		t.Fatal(err)
	}
	d.Close()
	if _, ok, _ := d.Frame(); ok || d.Live() {
		t.Fatal("after Close there is no picture")
	}
}

func TestOwnerControlMovesTheSamePointer(t *testing.T) {
	if _, err := exec.LookPath("Xvfb"); err != nil {
		t.Skip("no Xvfb")
	}
	d := New()
	defer d.Close()
	if err := d.Control(Control{Op: "click", X: 5, Y: 5}); err == nil {
		t.Fatal("a stopped desktop cannot be controlled")
	}
	if err := d.Do(context.Background(), Options{Width: 800, Height: 600, Session: "off"}, func(s *Screen) error { return nil }); err != nil {
		t.Fatal(err)
	}
	for _, c := range []Control{{Op: "move", X: 400, Y: 300}, {Op: "click", X: 410, Y: 310, Button: 1}, {Op: "scroll", X: 410, Y: 310, Down: true, N: 2}, {Op: "drag", X: 10, Y: 10, X2: 90, Y2: 60}, {Op: "type", Text: "привет abc"}, {Op: "key", Key: "ctrl+a"}} {
		if err := d.Control(c); err != nil {
			t.Fatalf("%+v: %v", c, err)
		}
	}
	if x, y, ok := d.Pointer(); !ok || x != 90 || y != 60 {
		t.Fatalf("pointer after the drag: %d,%d,%v", x, y, ok)
	}
	if d.Control(Control{Op: "dance"}) == nil {
		t.Fatal("an unknown action must be refused")
	}
	// out-of-screen points are pulled in, not an error
	if err := d.Control(Control{Op: "move", X: 99999, Y: -5}); err != nil {
		t.Fatal(err)
	}
	if x, y, _ := d.Pointer(); x != 799 || y != 0 {
		t.Fatalf("clamp: %d,%d", x, y)
	}
}

func TestWorksOnARealDisplay(t *testing.T) {
	bin, err := exec.LookPath("Xvfb")
	if err != nil {
		t.Skip("no Xvfb")
	}
	cmd := exec.Command(bin, ":77", "-screen", "0", "800x600x24", "-nolisten", "tcp", "-ac")
	if err := cmd.Start(); err != nil {
		t.Fatal(err)
	}
	defer func() { _ = cmd.Process.Kill(); _, _ = cmd.Process.Wait() }()
	if err := WaitForSocket(":77", 5*time.Second); err != nil {
		t.Fatal(err)
	}
	d := New()
	err = d.Do(context.Background(), Options{Display: ":77"}, func(s *Screen) error {
		if s.Display() != ":77" {
			t.Fatalf("display %q", s.Display())
		}
		return nil
	})
	if err != nil {
		t.Fatal(err)
	}
	if !d.Running() {
		t.Fatal("not running")
	}
	d.Close()
	if _, err := os.Stat("/tmp/.X11-unix/X77"); err != nil {
		t.Fatal("closing her desktop must not stop the real X server")
	}
}
