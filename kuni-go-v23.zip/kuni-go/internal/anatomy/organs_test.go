package anatomy

import (
	"net/http/httptest"
	"strings"
	"testing"

	"kuni/internal/body"
)

func calm() body.State {
	return body.State{Heart: 64, Breath: 14, Oxygen: .98, Glucose: .9, Water: .9, Bones: 1, Feels: 22, Light: .6, Noise: .15}
}

func TestCalmBodyHasNoStrainedOrgans(t *testing.T) {
	if p := Prompt(Organs(calm())); p != "" {
		t.Fatal(p)
	}
}

func TestRunningStrainsHeartAndLungs(t *testing.T) {
	b := calm()
	b.Heart, b.Breath, b.Oxygen, b.Fatigue = 160, 32, .9, .7
	p := Prompt(Organs(b))
	for _, w := range []string{"сердце", "лёгкие", "мышцы", "вычисление"} {
		if !strings.Contains(p, w) {
			t.Fatalf("%q missing in %s", w, p)
		}
	}
}

func TestEveryOrganHasAPlaceAndReport(t *testing.T) {
	for _, o := range Organs(calm()) {
		if len(o.Pts) == 0 || o.Text == "" || o.Does == "" {
			t.Fatalf("incomplete: %+v", o)
		}
		if !strings.Contains(Report(Organs(calm()), o.ID), "мой собственный") {
			t.Fatal("report must say whose signal it is")
		}
	}
}

func TestHandlerServesPageStateAndModel(t *testing.T) {
	h := Handler(func(int64) State { return State{Organs: Organs(calm()), Bones: Skeleton(calm())} })
	for path, want := range map[string]string{"/": "webgl2", "/state.json": "cranium0", "/model.obj": "Mesh_"} {
		rec := httptest.NewRecorder()
		h.ServeHTTP(rec, httptest.NewRequest("GET", path, nil))
		if rec.Code != 200 || !strings.Contains(rec.Body.String(), want) {
			t.Fatalf("%s: %d", path, rec.Code)
		}
	}
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, httptest.NewRequest("GET", "/assets/../x", nil))
	if rec.Code == 200 {
		t.Fatal("must not serve arbitrary paths")
	}
}

func TestSkeletonReactsToInjury(t *testing.T) {
	b := calm()
	b.Bones, b.Pain = .4, .7
	bs := Skeleton(b)
	if len(bs) != BoneCount || bs[0].Health != .4 || bs[0].Load < .4 {
		t.Fatalf("%+v", bs[0])
	}
	if !strings.Contains(BoneReport(bs, "лобная кость"), "серьёзно") {
		t.Fatal(BoneReport(bs, "лобная кость"))
	}
}

func TestSkeletonHasAllTwoHundredSixBones(t *testing.T) {
	bs := Skeleton(calm())
	if len(bs) != 206 {
		t.Fatalf("%d bones", len(bs))
	}
	ids := map[string]bool{}
	count := func(sub string) (n int) {
		for _, b := range bs {
			if strings.Contains(b.Name, sub) {
				n++
			}
		}
		return
	}
	for _, b := range bs {
		if ids[b.ID] {
			t.Fatal("duplicate id " + b.ID)
		}
		ids[b.ID] = true
	}
	for sub, want := range map[string]int{"позвонок": 24, "ребро": 24, "кость запястья": 16, "плюсневая": 10, "фаланга": 56, "пястная": 10, "ключица": 2, "лопатка": 2, "надколенник": 2, "бедренная": 2, "плечевая": 2} {
		if got := count(sub); got != want {
			t.Errorf("%s: %d, want %d", sub, got, want)
		}
	}
	if count("стопы") != 14+0 && count("кость стопы") != 14 {
		t.Errorf("tarsals: %d", count("кость стопы"))
	}
}

func TestActFollowsWhatSheDoes(t *testing.T) {
	for _, c := range []struct {
		d    body.Activity
		a    string
		st   bool
		want string
	}{{body.Asleep, "", false, "lie"}, {body.Working, "desk", false, "sit"}, {body.Working, "", true, "sit"}, {body.Working, "wander", false, "walk"}, {body.Working, "window", false, "stand"}} {
		if got := ActFor(c.d, c.a, c.st); got != c.want {
			t.Errorf("%v: %s want %s", c, got, c.want)
		}
	}
}
