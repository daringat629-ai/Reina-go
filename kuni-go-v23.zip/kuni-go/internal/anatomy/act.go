package anatomy

import "kuni/internal/body"

// ActFor says what her rigged body does now: asleep she lies, studying or working at the desk she sits, walking she walks,
// otherwise she stands. act is what her world page reports (desk, sleep, bed, wander, window, shelf...).
func ActFor(doing body.Activity, act string, studying bool) string {
	switch {
	case doing == body.Asleep || act == "sleep" || act == "bed":
		return "lie"
	case act == "desk" || studying:
		return "sit"
	case doing == body.Walking || act == "wander" || act == "out" || act == "back":
		return "walk"
	}
	return "stand"
}
