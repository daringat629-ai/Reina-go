#!/bin/sh
# Puts a real desktop on the laptop's own screen (Ubuntu/Debian), so that Reina's desktop is THE screen of the laptop:
# you sit at it like at an ordinary PC (mouse, keyboard, games, downloads) and watch her work on the same screen.
# Run once as your user (it asks for sudo):  sh deploy/screen.sh
set -e
sudo apt-get update
sudo apt-get install -y --no-install-recommends xserver-xorg xinit x11-xserver-utils openbox tint2 xterm
cat > "$HOME/.xinitrc" <<'X'
#!/bin/sh
xhost +local: >/dev/null 2>&1   # lets the container (Reina) use this screen
xset s off -dpms
tint2 &
exec openbox-session
X
chmod +x "$HOME/.xinitrc"
# after login on tty1 the desktop starts by itself
grep -q "reina-screen" "$HOME/.profile" 2>/dev/null || cat >> "$HOME/.profile" <<'P'

# reina-screen
if [ -z "$DISPLAY" ] && [ "$(tty)" = /dev/tty1 ]; then exec startx; fi
P
cat <<'T'

Готово. Дальше:
1) Контейнеру нужен доступ к экрану: добавь в запуск Reina
     docker run ... -v /tmp/.X11-unix:/tmp/.X11-unix ...
   или в docker-compose.yml, секция volumes сервиса Reina:
     - /tmp/.X11-unix:/tmp/.X11-unix
2) В настройках Reina (панель → Настройки, или config): desktop.display = :0
3) Перезапусти Reina и перелогинься на ноуте (или: startx). Появится рабочий стол;
   когда она работает на экране, ты видишь всё сам и можешь мышью/клавиатурой делать своё.
Вернуть как было: очисти desktop.display (она снова работает на невидимом экране).
T
