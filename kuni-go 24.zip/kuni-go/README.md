# kuni-go

Go-порт [Kuni](https://github.com/Alex2772/kuni) (C++). Только стандартная библиотека Go 1.24+, без внешних зависимостей.

Все модули из оригинала перенесены и **соединены в один рабочий цикл**:

```
Telegram ──updates──▶ agent ──▶ LLM ◀──tool calls──▶ tools ──▶ Telegram / diary / web / SD / TTS
                        │                                   ▲
                        ├─ RAG: diary (embeddings) ─────────┘
                        └─ idle → дамп сессии → diary + working memory
OpenAI-клиент ──▶ proxy (контекст, ask-tool, tool-loop) ──▶ upstream LLM
```

## Что есть

| C++ (`src/`) | Go (`internal/`) | |
|---|---|---|
| `config.cpp`, toml11, hot-reload | `config/` — свой парсер TOML-подмножества, опрос mtime | ✔ |
| `prompts.cpp` (13 промптов) | `prompts/` — **оригинальные тексты дословно** (`defaults/*.md`), `${VARS}`, hot-reload | ✔ |
| `OpenAIChatImpl`, streaming | `llm/` — chat, tool calls, vision-части, SSE, embeddings | ✔ |
| `Diary.cpp` | `diary/` — RAG, «сон» (консолидация) | ✔ |
| working memory, `diaryDumpMessages` | `memory/` — дамп сессии в дневник + обновление `working_memory.md`, антиплагиат | ✔ |
| `telegram/` (tdlib) | `telegram/` — интерфейс `Client`; **пользовательский аккаунт через tdlib** (`td.go`, как в оригинале), запасной Bot API-клиент, in-memory Fake | ⚠ tdlib не прогонялся с реальной библиотекой |
| `tools/*` (все 20) | `tools/` — реестр + все инструменты, наборы под тип чата (канал / не участник / группа / админ) | ✔ |
| `llmui/` | `llmui/` — `<message>`/`<chat>`, голосовые → STT, фото/стикеры → описание, видео → кадры+аудио, защита от инъекции `kuni_embedding` | ✔ |
| `ImageGenerator.cpp` | `imagegen/` — prompt-engineer → Stable Diffusion → LLM-критик, ретраи | ✔ (упрощён) |
| Whisper, TTS, ElevenLabs, web search, ffmpeg | `media/` | ✔ |
| `main.cpp`, `App`, `Worker` | `agent/` + `main.go` — сессии по чатам, дебаунс, lockdown, acting proactively, дамп при простое/выходе | ✔ |
| `proxy_server/` | `proxy/` — инъекция контекста, tool-loop для `ask`, SSE, passthrough, `MessageInjector`, `ContextBridge` | ✔ |
| `Prometheus.cpp`, Grafana | `metrics/` — `/metrics`, имена `llm_usage_*`, `tool_call_*` как в дашборде | ⚠ |
| AUI debug-окно | `debugui/` — веб-страница `/debug` | ✔ |
| `docker-compose.yml`, `ollama_setup.sh`, `grafana/` | скопированы как есть | ✔ |

## Запуск

```bash
go build -tags tdlib -o kuni .     # пользовательский режим (нужна libtdjson, см. ниже)
# или без tdlib — только режим bot и прокси:
go build -o kuni .
./kuni            # первый запуск создаёт config.toml и выходит
```

В `config.toml`: `[llm]` base_url/model; `[general] telegram_enabled = true`; `[telegram]`:
- `mode = "user"` (по умолчанию, как в оригинале) — `api_id`/`api_hash` с https://my.telegram.org, `phone_number`
  (или ввод в консоль). Код и облачный пароль запрашиваются в stdin при первом входе, сессия хранится в `tdlib_dir`.
- `mode = "bot"` — только `bot_token` от @BotFather.

### Установка libtdjson для режима user
```bash
git clone https://github.com/tdlib/td && cd td && mkdir build && cd build
cmake -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX=/usr/local .. && cmake --build . --target install -j4
# нужны: cmake, gperf, g++, libssl-dev, zlib1g-dev
cd /путь/к/kuni-go && go build -tags tdlib -o kuni .   # при нестандартном пути: CGO_LDFLAGS=-L<dir> CGO_CFLAGS=-I<dir>
```
Нужна версия tdlib с `setChatMemberTag` (свежий master, как в C++ проекте) и `td_send`/`td_receive` (1.8.0+).

```bash
go test ./... && go test -race ./...
```

Каталог `prompts/` создаётся при первом запуске; редактируйте файлы там — они подхватываются без перезапуска
(правка кода промптов не нужна, как и в оригинале). Прокси, `/metrics` и `/debug` слушают порт `[proxy] port` (10434).

## Честно о том, что отличается и что не проверено

**Проверено тестами с фейками** (фейковый LLM, фейковый Bot API, реальный ffmpeg): агент, инструменты, прокси, дневник,
конфиг, промпты, метрики, клиент Bot API, медиа-клиенты. **Не запускалось** против настоящих Telegram, Ollama/DeepSeek,
Stable Diffusion, Whisper и TTS — это первый шаг, который стоит сделать вам.

**Telegram: пользовательский аккаунт через tdlib.** `telegram.TDClient` говорит с tdlib по JSON-интерфейсу
(`td_json`), как C++ `TelegramClientImpl`: вход по телефону/коду/паролю, `getChats`/`getChatHistory`/`viewMessages`
с `force_read`, реакции, пересылка, правка текста и подписей, `setChatMemberTag`, `banChatMember`, блокировка и удаление
личного чата, контакты для `lockdown = contacts_only`, статус «онлайн» только пока идёт обработка, троттлинг до 20
запросов/с (Telegram банит агрессивных сторонних клиентов). Тонкая cgo-обёртка над `libtdjson` лежит в
`td_cgo.go` (тег `tdlib`); вся логика — в чистом Go поверх интерфейса `Transport`.

**Что проверено, а что нет:** логика клиента проверена 12 тестами на скриптованном фейковом tdlib (вход, преобразование
сообщений, **id > 2^53 и int64-как-строки**, формы всех запросов, смещения истории, права в группах, троттлинг), а cgo-слой
собран и прогнан со **стаб**-библиотекой. С *настоящей* libtdjson и аккаунтом Telegram он **не запускался** (в моей среде
нет сети для сборки tdlib). Названия полей tdlib написаны по памяти схемы `td_api` — на живом аккаунте возможны мелкие
расхождения (в первую очередь: `reply_to`, `topic`-поля, `setChatMemberTag`); ошибки tdlib возвращаются модели
как текст, так что их будет видно в логах.

**Режим bot (запасной).** Бот видит только адресованные ему сообщения и историю с момента запуска; не умеет вступать
в чаты, блокировать, управлять «онлайн»/«прочитано». `setChatMemberTag` в Bot API я не сверял.

**Упрощения относительно C++:**
- `imagegen`: 6 попыток вместо сложной схемы с галереей; нет повторного добавления откровенных слов в промпт
  (намеренно), «ребёнок» всегда в negative prompt.
- прокси: цикл tool-call'ов идёт в не-стримовом режиме, SSE для клиента синтезируется; `streaming_filter` не переносился.
- метрики: нет гистограммных bucket'ов (панели с `histogram_quantile` останутся пустыми); цель Prometheus —
  `host.docker.internal:10434`.
- стикеры в user-режиме: вместо «избранных» tdlib используется свой набор `data/stickers.json` (`sticker_save`);
- ключи `config.toml` другие и **не совместимы** со старым файлом.
- веб-поиск: SearXNG (`/search?format=json`) или Ollama web_search.

**Отличие поведения.** В C++ обработанная в «сне» запись-цель, судя по коду, не удалялась с диска (дубли копились);
в Go она удаляется, если `confidence < 1` (записи с `confidence = 1` — «факты» — неприкосновенны).

## Пресет персонажа: Reina Veil

Готовый пресет лежит в `examples/reina_veil/`. Чтобы включить: скопируйте оба файла в `prompts/`
(`cp examples/reina_veil/*.md prompts/`; там же компактные `system.md` и `character_base.md`, экономят ~40% токенов), в `config.toml` задайте `character_name = "Reina Veil"`.
Горячая перезагрузка подхватит файлы без перезапуска.

## Экономия токенов

- `[misc] lazy_tools = true` — редкие инструменты (медиа, правка/удаление, админка, поиск сообщений) скрыты за одним
  `more_tools`; список инструментов в приватном чате ~2,1k → ~1,1k токенов. Медиа открывается автоматически, если во
  входящем есть фото/голос/стикер или слова «фото, голос, стикер…».
- `[memory] history_keep = 24` — когда в сессии набирается вдвое больше сообщений, старая часть сжимается в краткую
  сводку (последние 24 остаются дословно). `0` — отключить.
- Продолжающаяся сессия не повторяет «earlier messages» целиком на каждом ходу.
- Метрика `kuni_llm_tokens_total{model,purpose,direction}` (purpose: reply / ask / diary / sleep / compact / image) и
  `kuni_llm_last_prompt_tokens{purpose}` — видно, на что уходят токены.

## Промпты по умолчанию

В сборку зашиты короткие промпты Рейны Вейл (`internal/prompts/defaults/`: system, character_base, character_appearance;
остальные 10 — оригинальные). При первом запуске они записываются в `prompts/`. Оригинальные промпты Куни лежат в
`examples/kuni_original/`. Если в `prompts/` уже есть старые файлы, программа их не перезаписывает: удалите нужные
(`rm prompts/system.md prompts/character_base.md prompts/character_appearance.md`) и перезапустите.

## Как она пишет

- `[telegram] max_message_chars = 60` — одно сообщение не длиннее 60 символов; длинный текст режется на несколько
  (по концу предложения или пробелу), число сообщений не ограничено. `0` — без нарезки.
- `typing_min_ms = 3000`, `typing_max_ms = 4000` — перед каждым сообщением показывается «печатает…» 3–4 секунды.
- В промпте: собственная воля (может согласиться, отказать, подразнить, проигнорировать), играет только когда сама захочет,
  не ведёт себя как ассистент.

## Автозапуск и логи (Alpine)

```
cp deploy/reina.openrc /etc/init.d/reina && chmod +x /etc/init.d/reina
rc-update add reina default
rc-service reina start     # логи: /var/log/reina.log
apk add logrotate && cp deploy/reina.logrotate /etc/logrotate.d/reina
```

Скорость: `stop_after_send` (не делать лишний вызов модели после ответа), `typing_while_thinking`
(«печатает» пока модель думает), `debounce_ms` (800). Запросы к модели автоматически повторяются
при 429/5xx и сетевых сбоях.

## Autonomous mode

`[autonomy] enabled = true` (or the switch on the panel's Status tab) lets her act on her own: every `min_interval_mins`..`max_interval_mins`
(random) she looks through her chats and decides to write first, speak her mind, `go_to_sleep`, or do nothing. Hard limits are enforced in
code, not in the prompt: no initiatives during `quiet_from`..`quiet_to` (in `timezone`, e.g. `Asia/Bishkek`) or while asleep, at most
`max_messages_per_day`, `chat_cooldown_mins` between messages to the same chat, and `lockdown` still decides which chats she may touch.
Your own chat is never limited. Everything she does on her own lands in `data/autonomy.log` (shown on the Status tab); "Разбудить" ends a sleep.

## Diary book

The panel's **Дневник** tab shows the diary as a 3D book: entries oldest to newest, one spread on wide screens and a single page on phones.
Turn pages by tapping the page edge, swiping, the ‹ › buttons, the slider or the arrow keys.

## Messages, people and groups

* Long messages are split like a person texts: per line, then per sentence, then at the best clause boundary; no dangling "и/в/to", no tiny
  tails, links and emoji stay whole (`telegram.max_message_chars`).
* `chat_members` (who is in a group, who is an admin, who is you/the owner) and `user_info` (profile by id) help her not to mix people up.
  In groups every message shows what it replies to and whether it is addressed to her (`addressed_to_you`).
* `llm.light_model` runs background thinking (`ask`, sleep, diary, history compaction) on a cheaper model; replies stay on `llm.model`.

## Server care: disk, spend, backups

* **Disk.** Every 10 minutes she checks the free space (`[maintenance]`): under `disk_warn_percent` (or under 500 MB) she clears cached image
  descriptions older than `cache_days` and, if it is still low, writes to you once a day.
* **Backups.** Daily `data/backups/reina-*.tar.gz` (diary, memory, prompts, mood, config; mode 0600 because the config holds your keys),
  newest `backup_keep` kept; "Сделать бэкап сейчас" on the Status tab makes one on demand.
* **Spend.** The Status tab shows tokens and dollars for today (set `llm.price_in_per_m` / `price_out_per_m`, and the light_* pair).
  `llm.daily_token_limit` > 0: past it she stops acting on her own and tells you; at 3x every LLM request is refused until tomorrow.

## Living presence and richer Telegram

**Presence** (`[presence]`, on by default). She does not answer instantly: she notices a message after a pause
(`read_delay_min_secs`..`read_delay_max_secs`; groups wait longer, a live conversation and your own chat are quick),
shows "online" only while she is busy (`offline_after_secs`), and types as long as the text takes
(`telegram.typing_per_char_ms`, capped by `typing_max_ms`). At night (autonomy quiet hours) `late_reply_percent` of
messages from other people are answered 5-40 minutes later; while she is asleep always. Your chat is never delayed.

**More content she understands.** Links: `read_link` opens public pages only (never localhost, LAN, Tailscale or
cloud metadata addresses; redirects and DNS tricks are checked at connect time), long pages are read in parts.
Documents from anyone up to `capabilities.document_max_mb`: txt, md, csv, json, docx, xlsx, odt and pdf
(`read_document`; PDF needs `pdftotext`: `apk add poppler-utils`). Images sent "as a file", round videos and gifs are
seen like photos/videos (`media_max_mb` limits the size). Reactions on her messages and edits of other people's messages
appear as short notes in her next turn (no extra paid model call); reactions nudge her mood a little.

**Groups.** Forum topics: messages show `topic_id` and her answers stay in the topic of the message she replies to.
`create_poll`, `vote_poll`, `pin_message`/`unpin_message` (pin only where she is admin). Tagging: `@username`, or
`[Name](tg://user?id=ID)` for people without a username. Voice message in, voice message out (when TTS is on) and a
sticker for a sticker (`telegram.mirror_modality`).

**Reliability.** Telegram flood waits (429) are waited out and the request repeated. The panel's Status tab shows who
is waiting for an answer and why, the flood-wait state and the last failed requests.

**Token budget.** Each request carries the session history, so it is kept small: instructions, mood, recalled
memories and the member roster are removed from every message except the newest, old tool results are cut
(`memory.old_tool_result_chars`), and the history is limited to `memory.context_chars` (default 24000 characters,
about 6k tokens). Old history is summarised (light model first, then the main one) and simply dropped if that keeps
failing. In groups she wakes the model only when she is addressed — a reply to her, her name or @nick, or the owner
(`telegram.group_reply_mode = "addressed"`, `group_chime_percent` lets her sometimes join anyway); other messages are
just read. `telegram.group_debounce_secs` batches group bursts. `llm.daily_token_limit` remains the hard stop.
