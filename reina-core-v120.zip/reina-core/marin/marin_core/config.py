"""
Config — единственное место в marin_core, которое читает переменные
окружения. Само ядро (engine/, state/, memory/, ...) ничего не знает про
.env — все настройки приходят конструкторами (EngineConfig, LLMProvider
и т.п.). Этот модуль — просто мост между .env-файлом старой v30-инфры
и конструкторами ядра.

Сознательно перенесены сюда ТОЛЬКО переменные, за которые сейчас отвечает
marin_core: подключение LLM (OpenRouter + локальный Ollama fallback) и
MARIN_OWNER_ID (см. engine/cycle.py owner detection). Всё остальное из
старого .env (Telegram-клиент, vision, voice, веб-панель, селфи, сторис,
"consciousness v28" и т.д.) — либо инфраструктура вокруг ядра, либо система,
которую заменяет сам marin_core, и здесь не читается. Подробности — в
README.md, раздел "Конфигурация (.env)".
"""

from __future__ import annotations

from dataclasses import dataclass
import os
from typing import Optional

from .llm.interface import LLMProvider
from .llm.providers import OpenAICompatConfig, OpenAICompatProvider, FallbackProvider, QualityGatedProvider
from .llm.local import EchoLocalProvider


from .env import env_bool as _get_bool  # noqa: E402  (единый надёжный разбор)
from .env import env_float as _get_float  # noqa: E402
from .env import env_int as _get_int  # noqa: E402


@dataclass
class MarinConfig:
    # владелец — используется инфраструктурой для is_owner=True в engine.tick(),
    # см. engine/cycle.py и social/social_model.py
    owner_id: Optional[str] = None

    # OpenRouter (основной провайдер)
    openrouter_api_key: Optional[str] = None
    openrouter_base_url: str = "https://openrouter.ai/api/v1"
    openrouter_model: str = "deepseek/deepseek-v4-pro-0813"
    openrouter_fallback_model: Optional[str] = None
    openrouter_timeout: float = 45.0
    openrouter_retry_attempts: int = 1
    enable_reasoning: bool = False

    # Ollama (локальный fallback, без API-ключа)
    ollama_base_url: str = "http://127.0.0.1:11434/v1"
    ollama_model: str = "qwen2.5:latest"
    ollama_timeout: float = 600.0
    ollama_retry_attempts: int = 1

    # Эмбеддинги (memory/*, belief/beliefs.py, perception/situation.py) —
    # см. llm/embeddings.py. По умолчанию — Ollama (тот же локальный сервер,
    # что и LLM fallback, без ключа), с опциональным OpenAI-совместимым
    # провайдером как приоритетным, если задан ключ. Если оба недоступны/не
    # настроены — HashEmbedder (см. build_embedder) как офлайн-фолбэк,
    # эквивалент прежней _hash_embed-заглушки.
    embedding_provider: str = "ollama"  # "ollama" | "openai_compat" | "hash"
    ollama_embedding_base_url: str = "http://127.0.0.1:11434"  # БЕЗ /v1 — нативный /api/embeddings
    ollama_embedding_model: str = "nomic-embed-text"
    ollama_embedding_timeout: float = 30.0
    embedding_api_key: Optional[str] = None
    embedding_base_url: str = "https://api.openai.com/v1"
    embedding_model: str = "text-embedding-3-small"
    embedding_timeout: float = 30.0
    embedding_cache_size: int = 4096

    # генерация
    max_output_tokens: int = 4000
    max_output_tokens_ceiling: int = 4000
    base_temperature: float = 0.85
    frequency_penalty: float = 0.4
    presence_penalty: float = 0.2

    # оценка стоимости — используется, если/когда появится usage_tracker
    # поверх learning/, само marin_core сейчас это не считает
    price_prompt_per_1m: float = 0.0
    price_completion_per_1m: float = 0.0

    # дневник (memory/diary.py) — имена переменных намеренно совпадают со
    # старым v30 (.env когда-то содержал MARIN_DATA_DIR/MARIN_DIARY_FILE как
    # мёртвые переменные "на будущее"; теперь они реально читаются)
    diary_file: Optional[str] = None      # None -> дневник только в памяти процесса
    diary_enabled: bool = True            # писать ли дневник автоматически на простое (ConsolidationScheduler)
    owner_name: str = "Жаабир"
    telegram_observer_file: str = "marin_telegram_activity.json"
    telegram_observer_max_events: int = 2500
    allow_emoji: bool = False


def _embedding_env() -> dict:
    """Собирает embedding_* поля MarinConfig с авто-детектом OpenRouter.

    OpenRouter отдаёт настоящий OpenAI-совместимый /embeddings эндпоинт
    (POST {base}/embeddings, модели вида "openai/text-embedding-3-small") —
    см. https://openrouter.ai/docs/api-reference/embeddings. Если у человека
    уже есть MARIN_OPENROUTER_API_KEY (обычный случай — тот же ключ уже
    используется для чата), эмбеддинги по умолчанию идут туда же, без
    отдельной настройки. Явный MARIN_EMBEDDING_* всегда имеет приоритет —
    это только дефолты для случая "ничего не задано вручную".

    Приоритет провайдера по умолчанию, если MARIN_EMBEDDING_PROVIDER не задан:
      1) MARIN_EMBEDDING_API_KEY задан явно -> openai_compat на MARIN_EMBEDDING_BASE_URL
         (по умолчанию api.openai.com, т.к. явный отдельный ключ обычно означает
         "у меня свой OpenAI/совместимый ключ, не путай с openrouter")
      2) иначе MARIN_OPENROUTER_API_KEY задан -> openai_compat на OpenRouter
      3) иначе -> ollama (локально, без ключа)
    """
    explicit_key = os.getenv("MARIN_EMBEDDING_API_KEY")
    openrouter_key = os.getenv("MARIN_OPENROUTER_API_KEY")
    openrouter_base = os.getenv("MARIN_OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1")

    if explicit_key:
        default_provider = "openai_compat"
        default_base = "https://api.openai.com/v1"
        default_model = "text-embedding-3-small"
        default_api_key = explicit_key
    elif openrouter_key:
        default_provider = "openai_compat"
        default_base = openrouter_base
        default_model = "openai/text-embedding-3-small"  # OpenRouter требует provider-префикс в имени модели
        default_api_key = openrouter_key
    else:
        default_provider = "ollama"
        default_base = "https://api.openai.com/v1"
        default_model = "text-embedding-3-small"
        default_api_key = None

    return dict(
        embedding_provider=os.getenv("MARIN_EMBEDDING_PROVIDER", default_provider),
        ollama_embedding_base_url=os.getenv("MARIN_OLLAMA_EMBEDDING_BASE_URL", "http://127.0.0.1:11434"),
        ollama_embedding_model=os.getenv("MARIN_OLLAMA_EMBEDDING_MODEL", "nomic-embed-text"),
        ollama_embedding_timeout=_get_float("MARIN_OLLAMA_EMBEDDING_TIMEOUT", 30.0),
        embedding_api_key=explicit_key or default_api_key,
        embedding_base_url=os.getenv("MARIN_EMBEDDING_BASE_URL", default_base),
        embedding_model=os.getenv("MARIN_EMBEDDING_MODEL", default_model),
        embedding_timeout=_get_float("MARIN_EMBEDDING_TIMEOUT", 30.0),
        embedding_cache_size=_get_int("MARIN_EMBEDDING_CACHE_SIZE", 4096),
    )


def load_config(env_path: Optional[str] = None) -> MarinConfig:
    """Читает .env (если найден python-dotenv и файл существует) и/или уже
    выставленные переменные окружения. env_path — необязательный явный путь
    к .env; если не передан, python-dotenv ищет .env в текущей директории
    (стандартное поведение find_dotenv), а если dotenv не установлен —
    используются только реальные переменные окружения процесса."""
    try:
        from dotenv import load_dotenv

        if env_path:
            load_dotenv(env_path)
        else:
            load_dotenv()
    except ImportError:
        pass  # python-dotenv не обязателен — просто читаем os.environ как есть

    owner_id = os.getenv("MARIN_OWNER_ID") or os.getenv("TELEGRAM_OWNER_ID")

    return MarinConfig(
        owner_id=owner_id,
        openrouter_api_key=os.getenv("MARIN_OPENROUTER_API_KEY") or None,
        openrouter_base_url=os.getenv("MARIN_OPENROUTER_BASE_URL") or "https://openrouter.ai/api/v1",
        openrouter_model=os.getenv("MARIN_OPENROUTER_MODEL", "deepseek/deepseek-v4-pro-0813"),
        openrouter_fallback_model=os.getenv("MARIN_OPENROUTER_FALLBACK_MODEL") or None,
        openrouter_timeout=_get_float("MARIN_OPENROUTER_TIMEOUT", 45.0),
        openrouter_retry_attempts=_get_int("MARIN_OPENROUTER_RETRY_ATTEMPTS", 1),
        enable_reasoning=_get_bool("MARIN_ENABLE_REASONING", False),
        ollama_base_url=os.getenv("MARIN_OLLAMA_BASE_URL", os.getenv("MARIN_OLLAMA_URL", "http://127.0.0.1:11434/v1")),
        ollama_model=os.getenv("MARIN_OLLAMA_MODEL", "qwen2.5:latest"),
        ollama_timeout=_get_float("MARIN_OLLAMA_TIMEOUT", 600.0),
        ollama_retry_attempts=_get_int("MARIN_OLLAMA_RETRY_ATTEMPTS", 1),
        **_embedding_env(),
        max_output_tokens=_get_int("MARIN_MAX_OUTPUT_TOKENS", 4000),
        max_output_tokens_ceiling=_get_int("MARIN_MAX_OUTPUT_TOKENS_CEILING", 4000),
        base_temperature=_get_float("MARIN_BASE_TEMPERATURE", 0.85),
        frequency_penalty=_get_float("MARIN_FREQUENCY_PENALTY", 0.4),
        presence_penalty=_get_float("MARIN_PRESENCE_PENALTY", 0.2),
        price_prompt_per_1m=_get_float("MARIN_LLM_PRICE_PROMPT_PER_1M", 0.0),
        price_completion_per_1m=_get_float("MARIN_LLM_PRICE_COMPLETION_PER_1M", 0.0),
        diary_file=os.getenv("MARIN_DIARY_FILE") or None,
        diary_enabled=_get_bool("MARIN_ENABLE_INNER_DIARY", True),
        owner_name=os.getenv("MARIN_OWNER_NAME", "Жаабир"),
        telegram_observer_file=os.getenv("MARIN_TELEGRAM_OBSERVER_FILE", "marin_telegram_activity.json"),
        telegram_observer_max_events=_get_int("MARIN_TELEGRAM_OBSERVER_MAX_EVENTS", 2500),
        allow_emoji=_get_bool("MARIN_ALLOW_EMOJI", False),
    )


def build_llm_provider(config: MarinConfig) -> LLMProvider:
    """OpenRouter (основной) -> Ollama (локальный, без ключа) -> Echo
    (офлайн-заглушка, чтобы движок всегда мог запуститься хоть как-то) —
    порядок соответствует MARIN_OPENROUTER_* / MARIN_OLLAMA_* из старого .env."""
    providers = []

    if config.openrouter_api_key:
        providers.append(
            OpenAICompatProvider(
                OpenAICompatConfig(
                    base_url=config.openrouter_base_url,
                    api_key=config.openrouter_api_key,
                    model=config.openrouter_model,
                    timeout=config.openrouter_timeout,
                    retry_attempts=config.openrouter_retry_attempts,
                    max_output_tokens=min(config.max_output_tokens, config.max_output_tokens_ceiling),
                    temperature=config.base_temperature,
                    frequency_penalty=config.frequency_penalty,
                    presence_penalty=config.presence_penalty,
                    enable_reasoning=config.enable_reasoning,
                )
            )
        )
        if config.openrouter_fallback_model:
            providers.append(
                OpenAICompatProvider(
                    OpenAICompatConfig(
                        base_url=config.openrouter_base_url,
                        api_key=config.openrouter_api_key,
                        model=config.openrouter_fallback_model,
                        timeout=config.openrouter_timeout,
                        retry_attempts=config.openrouter_retry_attempts,
                        max_output_tokens=min(config.max_output_tokens, config.max_output_tokens_ceiling),
                        temperature=config.base_temperature,
                        frequency_penalty=config.frequency_penalty,
                        presence_penalty=config.presence_penalty,
                        enable_reasoning=config.enable_reasoning,
                    )
                )
            )

    # локальный Ollama — не требует API-ключа, добавляется всегда как fallback
    providers.append(
        OpenAICompatProvider(
            OpenAICompatConfig(
                base_url=config.ollama_base_url,
                api_key=None,
                model=config.ollama_model,
                timeout=config.ollama_timeout,
                retry_attempts=config.ollama_retry_attempts,
                max_output_tokens=min(config.max_output_tokens, config.max_output_tokens_ceiling),
                temperature=config.base_temperature,
                frequency_penalty=config.frequency_penalty,
                presence_penalty=config.presence_penalty,
            )
        )
    )

    providers.append(EchoLocalProvider())  # последний рубеж — никогда не падает

    chain = providers[0] if len(providers) == 1 else FallbackProvider(providers)
    # Одна корректирующая попытка при изъянах реплики (см. QualityGatedProvider).
    if _get_bool("MARIN_QUALITY_GATE_ENABLED", True):
        return QualityGatedProvider(chain, retries=_get_int("MARIN_QUALITY_GATE_RETRIES", 1, minimum=0, maximum=2))
    return chain


def build_embedder(config: MarinConfig):
    """HashEmbedder (offline, детерминированный, §18 холодный старт) -> реальный
    провайдер (Ollama/OpenAI-совместимый, если настроен) -> обёрнут в
    ProjectingEmbedder (приводит родную размерность модели к общему EMBED_DIM)
    + CachingEmbedder (не бить в сеть на повторные фразы). Порядок в
    FallbackEmbedder: реальный провайдер первым (если сконфигурирован),
    HashEmbedder — всегда последним, чтобы embed() никогда не падал в
    real-time tick() даже при недоступной сети/модели.

    embedding_provider="hash" явно отключает сетевые эмбеддинги (напр. для
    тестов/офлайн-CI) — тогда возвращается голый HashEmbedder."""
    from .llm.embeddings import (
        CachingEmbedder,
        FallbackEmbedder,
        HashEmbedder,
        OllamaEmbeddingConfig,
        OllamaRawEmbedder,
        OpenAICompatEmbeddingConfig,
        OpenAICompatRawEmbedder,
        ProjectingEmbedder,
    )

    if config.embedding_provider == "hash":
        return HashEmbedder()

    chain = []
    if config.embedding_provider == "openai_compat" and config.embedding_api_key:
        raw = OpenAICompatRawEmbedder(
            OpenAICompatEmbeddingConfig(
                base_url=config.embedding_base_url,
                api_key=config.embedding_api_key,
                model=config.embedding_model,
                timeout=config.embedding_timeout,
            )
        )
        chain.append(CachingEmbedder(ProjectingEmbedder(raw), max_size=config.embedding_cache_size))
    else:
        # ollama (дефолт) — локально, без ключа; тот же сервер, что и LLM fallback
        raw = OllamaRawEmbedder(
            OllamaEmbeddingConfig(
                base_url=config.ollama_embedding_base_url,
                model=config.ollama_embedding_model,
                timeout=config.ollama_embedding_timeout,
            )
        )
        chain.append(CachingEmbedder(ProjectingEmbedder(raw), max_size=config.embedding_cache_size))

    chain.append(HashEmbedder())  # последний рубеж — никогда не падает
    return FallbackEmbedder(chain)


def build_engine(
    config: Optional[MarinConfig] = None, env_path: Optional[str] = None, **engine_kwargs
) -> "CognitiveEngine":  # noqa: F821
    """Удобная точка входа: load_config(env_path) + build_llm_provider() +
    CognitiveEngine(...). engine_kwargs пробрасываются в CognitiveEngine как
    есть (напр. identity=..., personality=..., чтобы переопределить пресет
    Marin). Если передан готовый config, env_path игнорируется."""
    from .engine.cognitive_engine import CognitiveEngine  # локальный импорт — избегаем цикла config<->engine

    cfg = config or load_config(env_path)
    provider = build_llm_provider(cfg)
    embedder = build_embedder(cfg)
    return CognitiveEngine(llm_provider=provider, embedder=embedder, diary_path=cfg.diary_file, **engine_kwargs)
