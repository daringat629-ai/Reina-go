//go:build windows

package app

import (
	"os"
	"os/exec"
	"time"
)

func ownGroupMC(*exec.Cmd) {}

func killGroupMC(p *os.Process) {
	if p != nil {
		_ = p.Kill()
	}
}

func stopGroupMC(p *os.Process, _ time.Duration, _ func() bool) { killGroupMC(p) }
