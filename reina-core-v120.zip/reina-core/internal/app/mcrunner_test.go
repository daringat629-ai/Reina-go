package app

import (
	"context"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"testing"
	"time"

	"orvi/internal/billing"
	"orvi/internal/config"
)

func TestMCRunnerLimitsAndStop(t *testing.T) {
	c := &config.Config{MCEnabled: true, MCMax: 1, MCMinutes: 1}
	r := newMCRunner(func() *config.Config { return c })
	r.command = func(ctx context.Context, w billing.World, c *config.Config) (*exec.Cmd, error) {
		return exec.CommandContext(ctx, "sleep", "30"), nil
	}
	w1 := billing.World{ID: 1, Host: "play.example.com", Port: 25565}
	if err := r.Start(w1); err != nil || !r.Running(1) {
		t.Fatalf("start: %v", err)
	}
	if r.Start(w1) == nil {
		t.Fatal("twice in the same world")
	}
	if r.Start(billing.World{ID: 2, Host: "b.example.com", Port: 25565}) == nil {
		t.Fatal("cap of visits")
	}
	if r.Start(billing.World{ID: 3, Host: "127.0.0.1", Port: 25565}) == nil {
		t.Fatal("closed address")
	}
	r.Stop(1)
	for i := 0; i < 50 && r.Running(1); i++ {
		time.Sleep(50 * time.Millisecond)
	}
	if r.Running(1) {
		t.Fatal("did not stop")
	}
	c.MCEnabled = false
	if r.Start(w1) == nil {
		t.Fatal("feature off")
	}
}

func TestMCAllowList(t *testing.T) {
	if !mcAllowed("", "any.example.com") || !mcAllowed("play.a.com, .b.net", "play.a.com") || !mcAllowed("play.a.com,.b.net", "mc.b.net") {
		t.Fatal("must allow")
	}
	if mcAllowed("play.a.com", "evil.a.com") || mcAllowed(".b.net", "b.net.evil.com") {
		t.Fatal("must refuse")
	}
}

// fakeNode writes a shell script that stands in for node; body runs with the connector's env.
func fakeNode(t *testing.T, body string) *config.Config {
	t.Helper()
	dir := t.TempDir()
	node := filepath.Join(dir, "node-run")
	if err := os.WriteFile(node, []byte("#!/bin/sh\nenv > \"$(dirname \"$0\")/env.txt\"\n"+body+"\n"), 0o755); err != nil {
		t.Fatal(err)
	}
	script := filepath.Join(dir, "mcbot", "mcbot.js")
	_ = os.MkdirAll(filepath.Join(dir, "mcbot", "node_modules"), 0o755)
	_ = os.WriteFile(script, []byte("//"), 0o644)
	return &config.Config{MCEnabled: true, MCMax: 2, MCMinutes: 1, MCJoinSecs: 10, MCNode: node, MCScript: script, MCName: "Reina",
		LLMAPIKey: "sk-secret-value-123456", LLMBaseURL: "https://api.example.com/v1"}
}

type evLog struct {
	mu sync.Mutex
	ev []billing.VisitEvent
}

func (l *evLog) add(e billing.VisitEvent) { l.mu.Lock(); l.ev = append(l.ev, e); l.mu.Unlock() }
func (l *evLog) get() []billing.VisitEvent {
	l.mu.Lock()
	defer l.mu.Unlock()
	return append([]billing.VisitEvent(nil), l.ev...)
}

func waitGone(t *testing.T, r *mcRunner, id int) {
	t.Helper()
	for i := 0; i < 200 && r.Running(id); i++ {
		time.Sleep(50 * time.Millisecond)
	}
	if r.Running(id) {
		t.Fatal("visit did not end")
	}
}

func TestMCVisitJoinThenStop(t *testing.T) {
	c := fakeNode(t, `echo 'MCBOT_STATUS {"state":"connecting","version":"auto"}'
echo 'MCBOT_STATUS {"state":"joined","version":"1.20.4","server_version":"1.20.4"}'
echo "talking to https://api.example.com/v1/chat?key=sk-secret-value-123456" >&2
sleep 300 &
echo $! > "$(dirname "$0")/child.pid"
trap 'echo "MCBOT_STATUS {\"state\":\"left\",\"reason\":\"sigterm\"}"; exit 0' TERM
while true; do sleep 1; done`)
	r := newMCRunner(func() *config.Config { return c })
	var l evLog
	w := billing.World{ID: 7, Owner: 5, Host: "play.example.com", Port: 25565}
	if err := r.StartVisit(w, l.add); err != nil {
		t.Fatal(err)
	}
	for i := 0; i < 100 && len(l.get()) == 0; i++ {
		time.Sleep(50 * time.Millisecond)
	}
	if err := r.StartVisit(billing.World{ID: 8, Owner: 5, Host: "b.example.com", Port: 25565}, nil); err == nil {
		t.Fatal("one visit per person")
	}
	r.Stop(7)
	waitGone(t, r, 7)
	ev := l.get()
	if len(ev) != 2 || ev[0].State != "joined" || ev[0].Version != "1.20.4" || ev[1].State != "left" {
		t.Fatalf("events: %+v", ev)
	}
	env, _ := os.ReadFile(filepath.Join(filepath.Dir(c.MCNode), "env.txt"))
	if !strings.Contains(string(env), "MC_VERSION=auto") || !strings.Contains(string(env), "MC_PORT=25565") || strings.Contains(string(env), "GOPATH=") {
		t.Fatalf("env: %s", env)
	}
	pid, _ := os.ReadFile(filepath.Join(filepath.Dir(c.MCNode), "child.pid"))
	n, _ := strconv.Atoi(strings.TrimSpace(string(pid)))
	time.Sleep(300 * time.Millisecond)
	if n > 0 && syscall.Kill(n, 0) == nil {
		st, _ := os.ReadFile("/proc/" + strconv.Itoa(n) + "/stat")
		if f := strings.Fields(string(st)); len(f) > 2 && f[2] != "Z" {
			t.Fatalf("child of the connector still runs: %s", st)
		}
	}
}

func TestMCVisitFailsOnce(t *testing.T) {
	c := fakeNode(t, `echo 'MCBOT_STATUS {"state":"failed","reason":"auth_required","detail":"online mode"}'
echo 'MCBOT_STATUS {"state":"failed","reason":"unknown"}'
exit 1`)
	r := newMCRunner(func() *config.Config { return c })
	var l evLog
	if err := r.StartVisit(billing.World{ID: 1, Owner: 5, Host: "play.example.com", Port: 25565}, l.add); err != nil {
		t.Fatal(err)
	}
	waitGone(t, r, 1)
	if ev := l.get(); len(ev) != 1 || ev[0].State != "failed" || ev[0].Reason != "auth_required" {
		t.Fatalf("events: %+v", ev)
	}
}

func TestMCVisitExitWithoutStatusIsAFailure(t *testing.T) {
	c := fakeNode(t, `exit 3`)
	r := newMCRunner(func() *config.Config { return c })
	var l evLog
	_ = r.StartVisit(billing.World{ID: 1, Host: "play.example.com", Port: 25565}, l.add)
	waitGone(t, r, 1)
	if ev := l.get(); len(ev) != 1 || ev[0].State != "failed" || ev[0].Reason != "unknown" {
		t.Fatalf("events: %+v", ev)
	}
}

func TestMCVisitJoinTimeout(t *testing.T) {
	c := fakeNode(t, `echo 'MCBOT_STATUS {"state":"connecting"}'
exec sleep 300`)
	c.MCJoinSecs = 1
	r := newMCRunner(func() *config.Config { return c })
	var l evLog
	start := time.Now()
	_ = r.StartVisit(billing.World{ID: 1, Host: "play.example.com", Port: 25565}, l.add)
	waitGone(t, r, 1)
	if ev := l.get(); len(ev) != 1 || ev[0].State != "failed" || ev[0].Reason != "timeout" || time.Since(start) > 8*time.Second {
		t.Fatalf("events: %+v after %v", ev, time.Since(start))
	}
}

func TestMCMissingNodeOrScript(t *testing.T) {
	c := fakeNode(t, `exit 0`)
	c.MCNode = filepath.Join(t.TempDir(), "nope")
	var alerts []string
	r := newMCRunner(func() *config.Config { return c })
	r.alert = func(s string) { alerts = append(alerts, s) }
	err := r.StartVisit(billing.World{ID: 1, Host: "play.example.com", Port: 25565}, nil)
	if err == nil || !strings.Contains(err.Error(), "не установлен") || r.Running(1) {
		t.Fatalf("missing node: %v", err)
	}
	c2 := fakeNode(t, `exit 0`)
	c2.MCScript = filepath.Join(t.TempDir(), "none.js")
	if _, err := realMCCommand(context.Background(), billing.World{}, c2); err == nil {
		t.Fatal("missing script")
	}
}

func TestMCShutdownEndsVisits(t *testing.T) {
	c := fakeNode(t, `echo 'MCBOT_STATUS {"state":"joined"}'
exec sleep 300`)
	r := newMCRunner(func() *config.Config { return c })
	var l evLog
	_ = r.StartVisit(billing.World{ID: 1, Host: "play.example.com", Port: 25565}, l.add)
	r.Close()
	if r.Running(1) || r.StartVisit(billing.World{ID: 2, Host: "play.example.com", Port: 25565}, nil) == nil {
		t.Fatal("after Close")
	}
	if ev := l.get(); len(ev) == 0 || ev[len(ev)-1].State != "left" && ev[len(ev)-1].State != "failed" {
		t.Fatalf("events: %+v", ev)
	}
}

func TestMCRedact(t *testing.T) {
	in := "err https://api.telegram.org/bot123456:AAbbccddeeffgghhiijjkkllmmnnooppqq/x key=abc sk-live_0123456789abc my-secret-key"
	out := redactMC(in, []string{"my-secret-key"})
	for _, bad := range []string{"telegram.org", "AAbbcc", "abc ", "sk-live", "my-secret-key"} {
		if strings.Contains(out, bad) {
			t.Fatalf("%q left in %q", bad, out)
		}
	}
	if e, ok := parseMCStatus(`MCBOT_STATUS {"state":"joined","server_version":"1.20.4"}`); !ok || e.Version != "1.20.4" {
		t.Fatal("parse")
	}
}
