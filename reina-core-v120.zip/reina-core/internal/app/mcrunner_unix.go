//go:build !windows

package app

import (
	"os"
	"os/exec"
	"syscall"
	"time"
)

// ownGroupMC puts the connector in its own process group, so it and anything it starts can be killed together.
func ownGroupMC(c *exec.Cmd) { c.SysProcAttr = &syscall.SysProcAttr{Setpgid: true} }

func killGroupMC(p *os.Process) {
	if p == nil {
		return
	}
	_ = syscall.Kill(-p.Pid, syscall.SIGKILL)
	_ = p.Kill()
}

// stopGroupMC asks the group to end (the connector says "left" on SIGTERM) and kills what is left after grace.
func stopGroupMC(p *os.Process, grace time.Duration, exited func() bool) {
	if p == nil {
		return
	}
	_ = syscall.Kill(-p.Pid, syscall.SIGTERM)
	time.AfterFunc(grace, func() {
		_ = syscall.Kill(-p.Pid, syscall.SIGKILL) // the group may outlive the leader: kill it in any case
		if !exited() {
			_ = p.Kill()
		}
	})
}
