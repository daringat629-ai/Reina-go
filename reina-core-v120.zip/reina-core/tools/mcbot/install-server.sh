#!/bin/sh
# Installs a portable Node.js into /work (no root, no apt) and the mcbot dependencies, then prints the reina-tdlib settings to run.
# Usage: sh tools/mcbot/install-server.sh            (from anywhere; idempotent: run again safely)
# Env:   PREFIX=/work/node  NODE_VER=v22.12.0  MUSL_LOADER=/work/alp/root/lib/ld-musl-x86_64.so.1
#        MUSL_LIBS=/work/alp/root/usr/lib:/work/alp/root/lib  FORCE_MUSL=1 (skip the glibc build)
set -eu

NODE_VER=${NODE_VER:-v22.12.0}
PREFIX=${PREFIX:-/work/node}
MUSL_LOADER=${MUSL_LOADER:-/work/alp/root/lib/ld-musl-x86_64.so.1}
MUSL_LIBS=${MUSL_LIBS:-/work/alp/root/usr/lib:/work/alp/root/lib}
HERE=$(cd "$(dirname "$0")" && pwd)
WRAP="$PREFIX/bin/node-run"   # what reina-tdlib calls: a tiny sh wrapper, works for both builds

say() { echo ">> $*"; }
die() { echo "ОШИБКА: $*" >&2; exit 1; }

[ "$(uname -m)" = "x86_64" ] || die "нужен x86_64, здесь $(uname -m)"
mkdir -p "$PREFIX" || die "нет записи в $PREFIX"

# Free space: tarball ~30 MB + unpacked ~180 MB + node_modules ~60 MB.
free_mb=$(df -Pm "$PREFIX" | awk 'NR==2{print $4}')
[ "${free_mb:-0}" -ge 400 ] || die "мало места в $PREFIX: ${free_mb} МБ, нужно 400"

fetch() { # url dest
  if command -v curl >/dev/null 2>&1; then curl -fL --retry 3 -o "$2" "$1"
  elif command -v wget >/dev/null 2>&1; then wget -O "$2" "$1"
  else python3 -c 'import sys,urllib.request;urllib.request.urlretrieve(sys.argv[1],sys.argv[2])' "$1" "$2"; fi
}
unpack() { # tarball dir
  if tar --version >/dev/null 2>&1 && tar -xJf "$1" -C "$2" --strip-components=1 2>/dev/null; then return 0; fi
  python3 -I - "$1" "$2" <<'PY'
import sys, tarfile, os
src, dst = sys.argv[1], sys.argv[2]
with tarfile.open(src) as t:
    for m in t.getmembers():
        parts = m.name.split('/', 1)
        if len(parts) < 2 or not parts[1]: continue
        m.name = parts[1]
        if m.name.startswith('/') or '..' in m.name.split('/'): continue
        try: t.extract(m, dst, filter='tar')
        except TypeError: t.extract(m, dst)
PY
}
sha_check() { # file sumsfile name
  want=$(grep " $3\$" "$2" | awk '{print $1}')
  [ -n "$want" ] || die "нет контрольной суммы для $3"
  if command -v sha256sum >/dev/null 2>&1; then got=$(sha256sum "$1" | awk '{print $1}')
  else got=$(python3 -c 'import sys,hashlib;print(hashlib.sha256(open(sys.argv[1],"rb").read()).hexdigest())' "$1"); fi
  [ "$want" = "$got" ] || die "контрольная сумма $3 не совпала"
}

install_build() { # flavor: glibc|musl
  if [ "$1" = glibc ]; then base="https://nodejs.org/dist/$NODE_VER"; name="node-$NODE_VER-linux-x64.tar.xz"
  else base="https://unofficial-builds.nodejs.org/download/release/$NODE_VER"; name="node-$NODE_VER-linux-x64-musl.tar.xz"; fi
  dir="$PREFIX/$NODE_VER-$1"
  if [ -x "$dir/bin/node" ] && [ -f "$dir/.ok" ]; then say "уже есть $dir"; return 0; fi
  tmp="$PREFIX/.dl"; rm -rf "$tmp" "$dir"; mkdir -p "$tmp" "$dir"
  say "качаю $base/$name"
  fetch "$base/$name" "$tmp/$name" || { rm -rf "$tmp" "$dir"; return 1; }
  fetch "$base/SHASUMS256.txt" "$tmp/SHASUMS256.txt" || { rm -rf "$tmp" "$dir"; return 1; }
  sha_check "$tmp/$name" "$tmp/SHASUMS256.txt" "$name"
  say "распаковываю в $dir"
  unpack "$tmp/$name" "$dir"
  rm -rf "$tmp"
  touch "$dir/.ok"
}

write_wrapper() { # flavor
  dir="$PREFIX/$NODE_VER-$1"; mkdir -p "$PREFIX/bin"
  if [ "$1" = glibc ]; then
    printf '#!/bin/sh\nexec "%s/bin/node" "$@"\n' "$dir" > "$WRAP.tmp"
  else
    printf '#!/bin/sh\nexec "%s" --library-path "%s" "%s/bin/node" "$@"\n' "$MUSL_LOADER" "$MUSL_LIBS:$dir/lib" "$dir" > "$WRAP.tmp"
  fi
  chmod +x "$WRAP.tmp"; mv "$WRAP.tmp" "$WRAP"
}

works() { "$WRAP" -e 'process.exit(process.versions.node ? 0 : 1)' >/dev/null 2>&1; }

flavor=""
if [ "${FORCE_MUSL:-0}" != 1 ] && [ -e /lib64/ld-linux-x86-64.so.2 ]; then
  if install_build glibc; then
    write_wrapper glibc
    if works; then flavor=glibc; else say "glibc-сборка не запускается (старый glibc?), пробую musl"; fi
  else say "не скачалось с nodejs.org, пробую musl"; fi
fi
if [ -z "$flavor" ]; then
  [ -e "$MUSL_LOADER" ] || die "glibc-сборка не подошла или не скачалась, а musl-загрузчика $MUSL_LOADER нет"
  install_build musl || die "не скачалась musl-сборка (unofficial-builds.nodejs.org недоступен?)"
  write_wrapper musl
  if ! works; then
    echo "musl-node не запускается. Частая причина: нет libstdc++.so.6 / libgcc_s.so.1 в $MUSL_LIBS." >&2
    echo "Их можно взять из пакетов Alpine libstdc++ и libgcc (apk-файлы это tar.gz: распаковать в /work/alp/root)." >&2
    "$WRAP" --version || true
    exit 1
  fi
  flavor=musl
fi
say "node $("$WRAP" --version) ($flavor) готов: $WRAP"

# Dependencies of the connector: npm through the same wrapper, so the musl loader is used for npm too.
NPM="$PREFIX/$NODE_VER-$flavor/lib/node_modules/npm/bin/npm-cli.js"
cd "$HERE"
if [ -f package-lock.json ]; then cmd=ci; else cmd=install; fi
say "npm $cmd --omit=dev в $HERE"
PATH="$PREFIX/bin:$PATH" "$WRAP" "$NPM" "$cmd" --omit=dev --no-audit --no-fund || die "npm $cmd не прошёл (нет доступа к registry.npmjs.org?)"
"$WRAP" -e "require('$HERE/node_modules/mineflayer')" || die "mineflayer не загружается"
say "зависимости на месте"

L="$MUSL_LOADER --library-path /work/alp/root/usr/lib:/work/alp/root/lib:/work/reina ./reina-tdlib"
cat <<EOF

Готово. Теперь в /work/reina выполнить (по одной):
  cd /work/reina
  $L set minecraft.node $WRAP
  $L set minecraft.script $HERE/mcbot.js
  $L set minecraft.enabled true
Потом перезапустить Рейну (run.sh). Проверка: $WRAP --version
EOF
