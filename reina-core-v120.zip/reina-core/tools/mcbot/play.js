'use strict';
// play.js: a fixed, safe set of in-game actions for the companion.
// The model never runs code: chat is parsed into one of ACTIONS, validated, then executed here.

const MAX_RANGE = 64;          // pathfinding cap, blocks
const SEARCH_RANGE = 32;       // block search radius for collect
const TASK_TIMEOUT_MS = 60000; // any single task gives up after this
const CMD_GAP_MS = 1500;       // min gap between accepted commands
const MAX_COLLECT = 16;
const MAX_GIVE = 64;

const ACTIONS = ['follow', 'come', 'stop', 'goto', 'look', 'jump', 'sneak', 'wave',
  'collect', 'give', 'eat', 'equip', 'sleep', 'guard', 'fight'];

// Only natural blocks may be broken. Logs, not planks; stone, not bricks.
const COLLECT = {
  wood: ['oak_log', 'birch_log', 'spruce_log', 'jungle_log', 'acacia_log', 'dark_oak_log', 'mangrove_log', 'cherry_log'],
  stone: ['stone', 'andesite', 'diorite', 'granite', 'deepslate'],
  dirt: ['dirt', 'grass_block'],
  sand: ['sand', 'red_sand'],
  gravel: ['gravel'],
  clay: ['clay'],
  coal: ['coal_ore', 'deepslate_coal_ore'],
  iron: ['iron_ore', 'deepslate_iron_ore'],
  copper: ['copper_ore', 'deepslate_copper_ore'],
  flowers: ['dandelion', 'poppy', 'cornflower', 'oxeye_daisy', 'azure_bluet'],
  leaves: ['oak_leaves', 'birch_leaves', 'spruce_leaves'],
};
const ALLOWED_BLOCKS = new Set(Object.values(COLLECT).flat());

const BLOCK_WORDS = [
  [/(дерев|древесин|бревн|брёвн|wood|log)/i, 'wood'],
  [/(камен|камн|булыж|stone|cobble)/i, 'stone'],
  [/(земл|грязь|dirt)/i, 'dirt'],
  [/(песо?к|песк|sand)/i, 'sand'],
  [/(гравий|gravel)/i, 'gravel'],
  [/(глин|clay)/i, 'clay'],
  [/(угол|угл|уголь|coal)/i, 'coal'],
  [/(желез|iron)/i, 'iron'],
  [/(мед[ьи]|copper)/i, 'copper'],
  [/(цвет|flower)/i, 'flowers'],
  [/(листв|листь|leaves|leaf)/i, 'leaves'],
];

const HOSTILE = new Set(['zombie', 'husk', 'drowned', 'skeleton', 'stray', 'spider', 'cave_spider', 'creeper',
  'witch', 'slime', 'magma_cube', 'phantom', 'pillager', 'vindicator', 'zombie_villager', 'silverfish',
  'blaze', 'wither_skeleton', 'hoglin', 'zoglin', 'piglin_brute', 'ravager', 'evoker', 'vex', 'guardian', 'bogged', 'breeze']);

function escapeRe(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }

// Addressed by name: name/alias as a whole word, or a Russian inflection of it (Рейна -> Рейну, Рейне).
function addressed(text, name, aliases) {
  const names = [name, ...(aliases || [])].filter(Boolean).map(String);
  const t = String(text || '').toLowerCase();
  for (const n0 of names) {
    const n = n0.toLowerCase();
    const stem = n.length >= 4 && /[аяоеиыуюaey]$/.test(n) ? n.slice(0, -1) : n;
    const re = new RegExp(`(^|[^\\p{L}\\p{N}_])${escapeRe(stem)}[\\p{L}]{0,2}(?=$|[^\\p{L}\\p{N}_])`, 'u');
    if (re.test(t)) return true;
  }
  return false;
}

function num(s, def) { const n = parseInt(s, 10); return Number.isFinite(n) ? n : def; }

// parse returns {action, ...args} or null. Pure, no I/O.
function parse(text, name, aliases) {
  if (!addressed(text, name, aliases)) return null;
  const t = String(text).toLowerCase().replace(/ё/g, 'е');
  const m3 = t.match(/(-?\d{1,7})[\s,;]+(-?\d{1,3})[\s,;]+(-?\d{1,7})/);
  if (m3 && /(иди|пойди|беги|go|goto|move|walk|координат|coords?)/.test(t)) {
    return { action: 'goto', x: +m3[1], y: +m3[2], z: +m3[3] };
  }
  if (/(^|\s)(стой|стоп|хватит|замри|останов|жди|stop|stay|wait|halt)/.test(t)) return { action: 'stop' };
  if (/(следуй|за мной|ходи за|follow)/.test(t)) return { action: 'follow' };
  if (/(иди|подойди|беги|давай)\s+(ко|к)\s+мне|сюда|come( here| to me)?\b/.test(t)) return { action: 'come' };
  if (/(посмотри|смотри|глянь)\s+на\s+меня|look at me/.test(t)) return { action: 'look' };
  if (/(прыгн|прыгай|jump)/.test(t)) return { action: 'jump' };
  if (/(присядь|присед|пригнись|sneak|crouch)/.test(t)) return { action: 'sneak' };
  if (/(помаши|помахай|привет\s*рукой|wave)/.test(t)) return { action: 'wave' };
  if (/(спать|поспи|ложись|кровать|sleep|bed)/.test(t)) return { action: 'sleep' };
  if (/(поешь|покушай|съешь|ешь\b|eat)/.test(t)) return { action: 'eat' };
  if (/(экипир|возьми (лучш|оруж|меч|кирк|топор)|вооруж|equip)/.test(t)) return { action: 'equip' };
  if (/(защищ|охраня|прикрой|guard|protect|defend)/.test(t)) return { action: 'guard' };
  if (/(атакуй|бей|убей|напади|сражайся|attack|kill|fight)\s*(мобов|монстров|зомби|mobs?|monsters?|zombies?)?/.test(t)) {
    return { action: 'fight' }; // hostile mobs only, never players
  }
  const giveM = t.match(/(дай|отдай|передай|брось|выкинь|give|drop|toss)\s+(мне\s+|me\s+)?(\d{1,3})?\s*([\p{L}_ ]+)?/u);
  if (giveM) {
    const item = (giveM[4] || '').trim().split(/\s+/).filter(w => !['мне', 'me', 'please', 'пожалуйста'].includes(w))[0] || '';
    return { action: 'give', item, count: Math.min(num(giveM[3], 1), MAX_GIVE) };
  }
  if (/(собери|добудь|накопай|выкопай|наруби|руби|копай|принеси|collect|mine|chop|gather|get)/.test(t)) {
    const cm = t.match(/(\d{1,3})/);
    for (const [re, kind] of BLOCK_WORDS) {
      if (re.test(t)) return { action: 'collect', block: kind, count: Math.max(1, Math.min(num(cm && cm[1], 1), MAX_COLLECT)) };
    }
    return { action: 'collect', block: '', count: 1 }; // unknown block: will refuse politely
  }
  return null;
}

function isCommand(text, name, aliases) { return parse(text, name, aliases) !== null; }

// Validate an action object from any source (e.g. an LLM): only known actions, bounded args.
function validateAction(a) {
  if (!a || typeof a !== 'object' || !ACTIONS.includes(a.action)) return null;
  const out = { action: a.action };
  if (a.action === 'goto') {
    for (const k of ['x', 'y', 'z']) { if (!Number.isFinite(+a[k])) return null; out[k] = Math.round(+a[k]); }
    if (out.y < -64 || out.y > 320) return null;
  }
  if (a.action === 'collect') {
    if (!Object.prototype.hasOwnProperty.call(COLLECT, a.block)) return null;
    out.block = a.block; out.count = Math.max(1, Math.min(num(a.count, 1), MAX_COLLECT));
  }
  if (a.action === 'give') {
    if (typeof a.item !== 'string' || !/^[\p{L}_]{0,32}$/u.test(a.item)) return null;
    out.item = a.item; out.count = Math.max(1, Math.min(num(a.count, 1), MAX_GIVE));
  }
  return out;
}

// Map Russian/English item words to item-name substrings for give.
const ITEM_WORDS = [
  [/^(дерев|бревн|wood|log)/, '_log'], [/^(доск|plank)/, '_planks'], [/^(камен|камн|булыж|stone|cobble)/, 'cobblestone'],
  [/^(земл|dirt)/, 'dirt'], [/^(песо?к|песк|sand)/, 'sand'], [/^(угол|угл|coal)/, 'coal'], [/^(желез|iron)/, 'iron'],
  [/^(ед|еду|хлеб|мяс|яблок|food|bread|apple|meat)/, '@food'], [/^(цвет|flower)/, '@flower'],
];
function itemMatcher(word) {
  const w = String(word || '').toLowerCase();
  if (!w || /^(все|всё|all|everything)$/.test(w)) return () => true;
  for (const [re, key] of ITEM_WORDS) if (re.test(w)) return key;
  return w.replace(/[^a-z_]/g, '') || null;
}

function attach(bot, opts = {}) {
  const say = opts.say || (() => {});
  const log = opts.log || (() => {});
  const name = opts.name || bot.username;
  const aliases = opts.aliases || [];
  let pf = null;
  try {
    pf = require('mineflayer-pathfinder');
    if (!bot.pathfinder) bot.loadPlugin(pf.pathfinder);
  } catch (e) { log('pathfinder unavailable', e.message); }
  const { goals, Movements } = pf || {};
  let movements = null;
  function moves() {
    if (movements || !Movements || !bot.registry) return movements;
    movements = new Movements(bot);
    movements.canDig = false;           // never dig through builds while walking
    movements.allow1by1towers = false;  // never pillar up with blocks
    movements.scafoldingBlocks = [];
    movements.allowParkour = true;
    movements.allowSprinting = true;
    movements.dontCreateFlow = true;
    if (movements.liquidCost !== undefined) movements.liquidCost = 3;
    return movements;
  }

  let stopped = false;
  let lastCmd = 0;
  let task = null;         // {kind, owner, timer}
  let guardOwner = null;   // username whose surroundings she protects
  let lastHit = 0;
  let eating = false;
  const timers = [];
  const listeners = [];
  function on(ev, fn) { bot.on(ev, fn); listeners.push([ev, fn]); }

  function inRange(pos) { return bot.entity && pos && bot.entity.position.distanceTo(pos) <= MAX_RANGE; }
  function playerEnt(user) { const p = bot.players && bot.players[user]; return p && p.entity; }
  function setGoal(goal, dynamic) {
    if (!bot.pathfinder) return false;
    const m = moves(); if (m) bot.pathfinder.setMovements(m);
    bot.pathfinder.setGoal(goal, !!dynamic); return true;
  }
  function clearTask() {
    if (task && task.timer) clearTimeout(task.timer);
    task = null;
    try { bot.pathfinder && bot.pathfinder.setGoal(null); } catch (_) {}
    try { bot.clearControlStates(); } catch (_) {}
    try { bot.stopDigging && bot.targetDigBlock && bot.stopDigging(); } catch (_) {}
  }
  function startTask(kind, owner, ms = TASK_TIMEOUT_MS) {
    clearTask();
    const t = { kind, owner, cancelled: false };
    t.timer = setTimeout(() => { if (task === t) { t.cancelled = true; clearTask(); say('не получилось, сдаюсь'); } }, ms);
    task = t; return t;
  }

  function bestItem(pred, score) {
    let best = null, bs = -1;
    for (const it of bot.inventory ? bot.inventory.items() : []) {
      if (!pred(it)) continue; const s = score(it); if (s > bs) { bs = s; best = it; }
    }
    return best;
  }
  const TIER = { wooden: 1, golden: 1, stone: 2, iron: 3, diamond: 4, netherite: 5 };
  const tier = it => TIER[it.name.split('_')[0]] || 0;
  async function equipFor(block) {
    let kind = 'pickaxe';
    if (block && /_log|leaves|planks/.test(block.name)) kind = 'axe';
    else if (block && /dirt|grass|sand|gravel|clay/.test(block.name)) kind = 'shovel';
    const tool = bestItem(it => it.name.endsWith('_' + kind), tier);
    if (tool) await bot.equip(tool, 'hand').catch(() => {});
  }
  async function equipWeapon() {
    const w = bestItem(it => /_sword$|_axe$/.test(it.name), it => tier(it) * 2 + (it.name.endsWith('_sword') ? 1 : 0));
    if (w) await bot.equip(w, 'hand').catch(() => {});
    return w;
  }
  const foods = () => (bot.registry && bot.registry.foodsByName) || {};
  function foodItem() {
    const f = foods();
    return bestItem(it => f[it.name] && !/rotten_flesh|spider_eye|pufferfish|poisonous|suspicious/.test(it.name),
      it => f[it.name].foodPoints || 0);
  }
  async function eat(quiet) {
    if (eating) return; const food = foodItem();
    if (!food) { if (!quiet) say('у меня нет еды'); return; }
    eating = true;
    try { await bot.equip(food, 'hand'); await bot.consume(); if (!quiet) say('ням'); }
    catch (e) { log('eat', e.message); } finally { eating = false; }
  }

  async function collect(owner, kind, count) {
    const names = COLLECT[kind];
    if (!names) { say('такое я не копаю: только дерево, камень, землю, песок, уголь, руду'); return; }
    const ids = names.map(n => bot.registry.blocksByName[n]).filter(Boolean).map(b => b.id);
    const t = startTask('collect', owner, TASK_TIMEOUT_MS * 2);
    say(`пойду добуду ${kind}`);
    let got = 0;
    while (got < count && task === t && !t.cancelled) {
      const block = bot.findBlock({ matching: ids, maxDistance: SEARCH_RANGE });
      if (!block || !ALLOWED_BLOCKS.has(block.name)) { say(got ? `больше не нашла, есть ${got}` : 'рядом такого не вижу'); break; }
      try {
        await bot.pathfinder.goto(new goals.GoalNear(block.position.x, block.position.y, block.position.z, 2));
        if (task !== t) break;
        const b2 = bot.blockAt(block.position);
        if (!b2 || !ALLOWED_BLOCKS.has(b2.name)) continue;
        await equipFor(b2);
        await bot.dig(b2, true);
        got++;
        await new Promise(r => setTimeout(r, 400)); // let drops get picked up
        const drop = bot.nearestEntity(e => e.name === 'item' && e.position.distanceTo(b2.position) < 4);
        if (drop) await bot.pathfinder.goto(new goals.GoalNear(drop.position.x, drop.position.y, drop.position.z, 0)).catch(() => {});
      } catch (e) { log('collect', e.message); break; }
    }
    if (task === t) { if (got >= count) say('готово!'); clearTask(); }
  }

  async function give(owner, word, count) {
    const p = playerEnt(owner);
    if (!p) { say('не вижу тебя'); return; }
    const m = itemMatcher(word);
    const f = foods();
    const pred = typeof m === 'function' ? m
      : m === '@food' ? it => !!f[it.name]
        : m === '@flower' ? it => COLLECT.flowers.includes(it.name)
          : m ? it => it.name.includes(m) : null;
    const items = pred ? (bot.inventory ? bot.inventory.items() : []).filter(pred) : [];
    if (!items.length) { say('у меня такого нет'); return; }
    const t = startTask('give', owner);
    try {
      await bot.pathfinder.goto(new goals.GoalNear(p.position.x, p.position.y, p.position.z, 2));
      await bot.lookAt(p.position.offset(0, 1.5, 0));
      let left = count;
      for (const it of items) {
        if (left <= 0 || task !== t) break;
        const n = Math.min(left, it.count);
        await bot.toss(it.type, it.metadata, n); left -= n;
      }
      say('держи!');
    } catch (e) { log('give', e.message); say('не дошла до тебя'); }
    if (task === t) clearTask();
  }

  async function sleep() {
    const bed = bot.findBlock({ matching: b => bot.isABed ? bot.isABed(b) : /_bed$/.test(b.name), maxDistance: SEARCH_RANGE });
    if (!bed) { say('кровати рядом нет'); return; }
    const t = startTask('sleep', null);
    try {
      await bot.pathfinder.goto(new goals.GoalNear(bed.position.x, bed.position.y, bed.position.z, 2));
      await bot.sleep(bed); say('спокойной ночи');
    } catch (e) { say(/day|night|time/i.test(e.message) ? 'сейчас не ночь' : 'не могу лечь'); }
    if (task === t) clearTask();
  }

  async function run(cmd, user) {
    const p = playerEnt(user);
    switch (cmd.action) {
      case 'stop': clearTask(); guardOwner = null; say('стою'); return;
      case 'follow': case 'come': {
        if (!p || !inRange(p.position)) { say('не вижу тебя'); return; }
        const t = startTask(cmd.action, user, cmd.action === 'follow' ? 30 * 60000 : TASK_TIMEOUT_MS);
        if (cmd.action === 'follow') { setGoal(new goals.GoalFollow(p, 2), true); say('иду за тобой'); }
        else {
          say('иду!');
          bot.pathfinder.goto(new goals.GoalNear(p.position.x, p.position.y, p.position.z, 2))
            .then(() => { if (task === t) clearTask(); }).catch(() => {});
        }
        return;
      }
      case 'goto': {
        const v = bot.entity.position;
        if (Math.hypot(cmd.x - v.x, cmd.z - v.z) > MAX_RANGE) { say(`далеко, я хожу не дальше ${MAX_RANGE} блоков`); return; }
        const t = startTask('goto', user); say('иду');
        bot.pathfinder.goto(new goals.GoalNear(cmd.x, cmd.y, cmd.z, 1))
          .then(() => { if (task === t) { clearTask(); say('пришла'); } })
          .catch(() => { if (task === t) { clearTask(); say('не могу туда пройти'); } });
        return;
      }
      case 'look': if (!p) { say('не вижу тебя'); return; } await bot.lookAt(p.position.offset(0, 1.6, 0)); return;
      case 'jump': bot.setControlState('jump', true); setTimeout(() => bot.setControlState('jump', false), 400); return;
      case 'sneak':
        for (let i = 0; i < 3; i++) setTimeout(() => bot.setControlState('sneak', i % 2 === 0), i * 400);
        setTimeout(() => bot.setControlState('sneak', false), 1400); return;
      case 'wave': if (p) await bot.lookAt(p.position.offset(0, 1.6, 0)).catch(() => {});
        for (let i = 0; i < 3; i++) setTimeout(() => { try { bot.swingArm('right'); } catch (_) {} }, i * 300); return;
      case 'eat': return eat(false);
      case 'equip': { const w = await equipWeapon(); say(w ? 'взяла ' + w.name : 'оружия нет'); return; }
      case 'guard': case 'fight': guardOwner = user; say('прикрою тебя'); return;
      case 'collect': return collect(user, cmd.block, cmd.count);
      case 'give': return give(user, cmd.item, cmd.count);
      case 'sleep': return sleep();
    }
  }

  function onChat(username, message) {
    if (stopped || !username || username === bot.username) return;
    const raw = parse(message, name, aliases);
    const cmd = validateAction(raw) || (raw && raw.action === 'collect' ? raw : null); // unknown block -> polite refusal
    if (!cmd) return;
    const now = Date.now();
    if (now - lastCmd < CMD_GAP_MS && cmd.action !== 'stop') return;
    lastCmd = now;
    log('play', username, cmd);
    Promise.resolve().then(() => run(cmd, username)).catch(e => log('play error', e.message));
  }
  on('chat', onChat);

  // Self-defense + guarding: only hostile mobs, never players.
  function tick() {
    if (stopped || !bot.entity) return;
    try {
      if (bot.food !== undefined && bot.food < 14 && !eating && !(task && task.kind === 'collect')) eat(true);
      const centre = (guardOwner && playerEnt(guardOwner)) || bot.entity;
      const mob = bot.nearestEntity(e => e.type !== 'player' && HOSTILE.has(e.name) &&
        (e.position.distanceTo(bot.entity.position) < 8 || e.position.distanceTo(centre.position) < 8));
      if (!mob) return;
      const d = mob.position.distanceTo(bot.entity.position);
      if (d <= 3.2 && Date.now() - lastHit > 650) {
        lastHit = Date.now();
        equipWeapon().then(() => bot.lookAt(mob.position.offset(0, mob.height * 0.8, 0), true))
          .then(() => { if (mob.isValid !== false) bot.attack(mob); }).catch(() => {});
      } else if (d < 8 && guardOwner && !task && bot.pathfinder) {
        setGoal(new goals.GoalFollow(mob, 2), true);
        setTimeout(() => { if (!task && guardOwner) { const o = playerEnt(guardOwner); if (o) setGoal(new goals.GoalFollow(o, 2), true); } }, 3000);
      }
    } catch (e) { log('tick', e.message); }
  }
  timers.push(setInterval(tick, 500));

  on('death', () => { clearTask(); });
  on('respawn', () => { if (!stopped) setTimeout(() => say('я вернулась!'), 1500); });
  on('path_update', r => { if (r && r.status === 'noPath' && task && task.kind !== 'follow') { clearTask(); say('не могу пройти'); } });

  return {
    stop() {
      stopped = true; clearTask(); guardOwner = null;
      for (const t of timers) clearInterval(t);
      for (const [ev, fn] of listeners) bot.removeListener(ev, fn);
    },
  };
}

module.exports = { attach, isCommand, parse, validateAction, addressed, ALLOWED_BLOCKS, COLLECT, HOSTILE, ACTIONS, MAX_RANGE };
