'use strict';
// Forge (FML2/FML3) handshake helpers and an end-to-end join into a fake "Forge" server.
// Run: node --test forge.test.js
const test = require('node:test');
const assert = require('node:assert');
const path = require('node:path');
const { spawn } = require('node:child_process');
const mc = require('minecraft-protocol');
const F = require('./forge');

function serverModList() {
  const p = [F.writeVarInt(1), F.writeVarInt(2), F.writeString('forge'), F.writeString('create'),
    F.writeVarInt(1), F.writeString('create:main'), F.writeString('1'),
    F.writeVarInt(2), F.writeString('minecraft:block'), F.writeString('minecraft:item'),
    F.writeVarInt(1), F.writeString('minecraft:worldgen/biome')];
  return Buffer.concat(p);
}

test('mod list is echoed back as C2SModListReply', () => {
  const req = { messageId: 7, channel: F.WRAPPER, data: F.wrap('fml:handshake', serverModList()) };
  const resp = F.answer(req);
  const { channel, inner } = F.unwrap(resp);
  assert.strictEqual(channel, 'fml:handshake');
  let [id, off] = F.readVarInt(inner, 0);
  assert.strictEqual(id, 2);
  let n; [n, off] = F.readVarInt(inner, off);
  const mods = []; for (let i = 0; i < n; i++) { let s; [s, off] = F.readString(inner, off); mods.push(s); }
  assert.deepStrictEqual(mods, ['forge', 'create']);
  [n, off] = F.readVarInt(inner, off); assert.strictEqual(n, 1);
  let a, b; [a, off] = F.readString(inner, off); [b, off] = F.readString(inner, off);
  assert.deepStrictEqual([a, b], ['create:main', '1']);
  [n, off] = F.readVarInt(inner, off); assert.strictEqual(n, 2);
  [a, off] = F.readString(inner, off); [b, off] = F.readString(inner, off);
  assert.deepStrictEqual([a, b], ['minecraft:block', '']);
});

test('registry, config and unknown handshake packets are acknowledged; other channels are not understood', () => {
  for (const id of [3, 4, 5, 42]) {
    const resp = F.answer({ messageId: 1, channel: F.WRAPPER, data: F.wrap('fml:handshake', Buffer.concat([F.writeVarInt(id), Buffer.from([1, 2, 3])])) });
    const { inner } = F.unwrap(resp);
    assert.strictEqual(F.readVarInt(inner, 0)[0], F.ACK);
  }
  assert.strictEqual(F.answer({ messageId: 1, channel: 'velocity:player_info', data: Buffer.from([1]) }), undefined);
});

test('detect and host tag', () => {
  assert.strictEqual(F.detect({ forgeData: { fmlNetworkVersion: 3 } }), 3);
  assert.strictEqual(F.detect({ forgeData: { fmlNetworkVersion: 2 } }), 2);
  assert.strictEqual(F.detect({ version: { name: '1.20.1' } }), 0);
  assert.strictEqual(F.detect(undefined), 0);
  assert.strictEqual(F.hostTag('play.x.ru', 3), 'play.x.ru\0FML3\0');
});

test('unknown (modded) block states read as stone, vanilla ones unchanged', () => {
  const registry = require('prismarine-registry')('1.20.1');
  const Block = require('prismarine-block')(registry);
  F.maskUnknownBlocks(registry);
  assert.strictEqual(Block.fromStateId(registry.blocksByName.oak_log.minStateId).name, 'oak_log');
  const modded = Block.fromStateId(999999);
  assert.strictEqual(modded.name, 'stone');
  assert.ok(Array.isArray(modded.shapes) && modded.shapes.length > 0, 'solid shape for physics');
  F.maskUnknownBlocks(registry); // twice is harmless
});

test('joins a server that announces Forge (FML3) and only lets tagged clients in', { timeout: 40000 }, async () => {
  const VERSION = '1.16.5';
  const mcData = require('minecraft-data')(VERSION);
  let sawTag = false;
  const server = mc.createServer({
    'online-mode': false, host: '127.0.0.1', port: 0, version: VERSION, motd: 'forge',
    beforePing: (resp) => { resp.forgeData = { channels: [], mods: [{ modId: 'forge', modmarker: '47.2.0' }], fmlNetworkVersion: 3, truncated: false }; return resp; },
    beforeLogin: (client) => {
      if (String(client.serverHost).includes('\0FML3\0')) sawTag = true;
      else client.end('This server has mods that require Forge to be installed on the client.');
    },
  });
  await new Promise((r) => server.on('listening', r));
  server.on('playerJoin', (client) => {
    client.write('login', {
      entityId: client.id, isHardcore: false, gameMode: 0, previousGameMode: 1,
      worldNames: mcData.loginPacket.worldNames, dimensionCodec: mcData.loginPacket.dimensionCodec,
      dimension: mcData.loginPacket.dimension, worldName: 'minecraft:overworld', hashedSeed: [0, 0],
      maxPlayers: 20, viewDistance: 10, reducedDebugInfo: false, enableRespawnScreen: true, isDebug: false, isFlat: false,
    });
    client.write('position', { x: 0, y: 64, z: 0, yaw: 0, pitch: 0, flags: 0, teleportId: 1 });
    client.write('update_health', { health: 20, food: 20, foodSaturation: 5 });
  });
  const port = server.socketServer.address().port;
  const lines = [];
  const child = spawn(process.execPath, [path.join(__dirname, 'mcbot.js')], {
    cwd: __dirname,
    env: { PATH: process.env.PATH, MC_HOST: '127.0.0.1', MC_PORT: String(port), MC_VERSION: 'auto', MC_USER: 'Reina', BOT_NAME: 'Reina',
      MC_AUTH: 'offline', MC_ALLOW_LOCAL: '1', MC_PASS_FILE: '/nonexistent', LLM_URL: 'http://127.0.0.1:9/v1/chat/completions', LLM_KEY: 'x', LLM_MODEL: 'x', MAX_MINUTES: '2' },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let buf = '';
  const onData = (d) => { buf += d; let i; while ((i = buf.indexOf('\n')) >= 0) { lines.push(buf.slice(0, i)); buf = buf.slice(i + 1); } };
  child.stdout.on('data', onData); child.stderr.on('data', onData);
  try {
    const end = Date.now() + 25000;
    const st = () => lines.filter((l) => l.startsWith('MCBOT_STATUS ')).map((l) => JSON.parse(l.slice(13)));
    while (Date.now() < end && !st().some((s) => s.state === 'joined' || s.state === 'failed')) await new Promise((r) => setTimeout(r, 100));
    const all = st();
    assert.ok(all.some((s) => s.state === 'connecting' && s.forge === 3), 'connecting status says forge 3\n' + lines.join('\n'));
    assert.ok(all.some((s) => s.state === 'joined'), 'joined\n' + lines.join('\n'));
    assert.ok(sawTag, 'handshake host carried the FML3 tag');
  } finally {
    child.kill('SIGTERM');
    await new Promise((r) => setTimeout(r, 500));
    child.kill('SIGKILL');
    server.close();
  }
});
