'use strict';
// End-to-end check of mcbot.js against a fake Minecraft server (minecraft-protocol createServer) and a fake LLM.
// Run: node --test tools/mcbot/e2e.test.js   (needs npm install in tools/mcbot; no network)
// Contract (from mcbot.js): one stdout line `MCBOT_STATUS {"state":"joined|failed|left","reason":...,"detail":...,"version":...}`.
const test = require('node:test');
const assert = require('node:assert');
const http = require('node:http');
const path = require('node:path');
const { spawn } = require('node:child_process');
const mc = require('minecraft-protocol');

const VERSION = '1.16.5';
const mcData = require('minecraft-data')(VERSION);
const REPLY = 'Привет, я тут!';

function fakeLLM() {
  return new Promise((resolve) => {
    const calls = [];
    const s = http.createServer((req, res) => {
      let body = '';
      req.on('data', (c) => { body += c; });
      req.on('end', () => {
        calls.push(body);
        res.setHeader('content-type', 'application/json');
        res.end(JSON.stringify({ id: 'x', object: 'chat.completion', choices: [{ index: 0, message: { role: 'assistant', content: REPLY }, finish_reason: 'stop' }] }));
      });
    });
    s.listen(0, '127.0.0.1', () => resolve({ s, calls, url: `http://127.0.0.1:${s.address().port}/v1/chat/completions` }));
  });
}

// mode 'join': lets the player in and says "Reina привет" in chat; mode 'kick': kicks during login as a whitelist plugin does.
function fakeMC(mode) {
  return new Promise((resolve) => {
    const said = [];
    const server = mc.createServer({ 'online-mode': false, host: '127.0.0.1', port: 0, version: VERSION, motd: 'e2e' });
    if (mode === 'kick') {
      server.on('login', (client) => client.end('You are not whitelisted on this server!'));
    } else {
      server.on('playerJoin', (client) => {
        client.write('login', {
          entityId: client.id, isHardcore: false, gameMode: 0, previousGameMode: 1,
          worldNames: mcData.loginPacket.worldNames, dimensionCodec: mcData.loginPacket.dimensionCodec,
          dimension: mcData.loginPacket.dimension, worldName: 'minecraft:overworld', hashedSeed: [0, 0],
          maxPlayers: 20, viewDistance: 10, reducedDebugInfo: false, enableRespawnScreen: true, isDebug: false, isFlat: false,
        });
        client.write('position', { x: 0, y: 64, z: 0, yaw: 0, pitch: 0, flags: 0, teleportId: 1 });
        client.write('update_health', { health: 20, food: 20, foodSaturation: 5 });
        client.on('chat', (p) => said.push(p.message));
        // The player "Steve" calls her after a short pause (vanilla chat format: chat.type.text with [name, message]).
        setTimeout(() => {
          client.write('chat', {
            message: JSON.stringify({ translate: 'chat.type.text', with: [{ text: 'Steve' }, 'Reina привет'] }),
            position: 0, sender: '00000000-0000-0000-0000-000000000001',
          });
        }, 2500);
      });
    }
    server.on('listening', () => resolve({ server, said, port: server.socketServer.address().port }));
  });
}

function runBot(port, llmURL) {
  const lines = [];
  const child = spawn(process.execPath, [path.join(__dirname, 'mcbot.js')], {
    cwd: __dirname,
    env: {
      PATH: process.env.PATH, MC_HOST: '127.0.0.1', MC_PORT: String(port), MC_VERSION: VERSION, MC_USER: 'Reina', BOT_NAME: 'Reina',
      MC_AUTH: 'offline', MC_ALLOW_LOCAL: '1', MC_PASS_FILE: '/nonexistent', LLM_URL: llmURL, LLM_KEY: 'test', LLM_MODEL: 'test', MAX_MINUTES: '2',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let buf = '';
  const onData = (d) => { buf += d; let i; while ((i = buf.indexOf('\n')) >= 0) { lines.push(buf.slice(0, i)); buf = buf.slice(i + 1); } };
  child.stdout.on('data', onData);
  child.stderr.on('data', onData);
  const exited = new Promise((r) => child.on('exit', (code) => r(code)));
  return { child, lines, exited };
}

function statuses(lines) {
  const out = [];
  for (const l of lines) {
    const i = l.indexOf('MCBOT_STATUS ');
    if (i < 0) continue;
    try { out.push(JSON.parse(l.slice(i + 'MCBOT_STATUS '.length))); } catch { out.push({ bad: l }); }
  }
  return out;
}

async function until(fn, ms, what, lines) {
  const end = Date.now() + ms;
  while (Date.now() < end) { const v = fn(); if (v) return v; await new Promise((r) => setTimeout(r, 100)); }
  throw new Error('timeout waiting for ' + what + '\n--- bot output ---\n' + lines.join('\n'));
}

test('joins, prints joined status and answers when called by name', { timeout: 40000 }, async () => {
  const llm = await fakeLLM();
  const srv = await fakeMC('join');
  const bot = runBot(srv.port, llm.url);
  try {
    const st = await until(() => statuses(bot.lines).find((s) => s.state === 'joined'), 20000, 'MCBOT_STATUS joined', bot.lines);
    assert.strictEqual(typeof st, 'object');
    await until(() => srv.said.some((m) => m.includes(REPLY)), 20000, 'her answer in chat', bot.lines);
    assert.ok(llm.calls.some((b) => b.includes('Reina привет')), 'the LLM got the player message');
  } finally {
    bot.child.kill('SIGTERM');
    await Promise.race([bot.exited, new Promise((r) => setTimeout(r, 3000))]);
    bot.child.kill('SIGKILL');
    srv.server.close(); llm.s.close();
  }
});

test('whitelist kick gives failed status with a reason', { timeout: 40000 }, async () => {
  const llm = await fakeLLM();
  const srv = await fakeMC('kick');
  const bot = runBot(srv.port, llm.url);
  try {
    const st = await until(() => statuses(bot.lines).find((s) => s.state === 'failed'), 20000, 'MCBOT_STATUS failed', bot.lines);
    assert.ok(st.reason, 'failed status has a reason: ' + JSON.stringify(st));
    assert.ok(!statuses(bot.lines).some((s) => s.state === 'joined'), 'never reported joined');
  } finally {
    bot.child.kill('SIGKILL');
    await Promise.race([bot.exited, new Promise((r) => setTimeout(r, 2000))]);
    srv.server.close(); llm.s.close();
  }
});
