# «Миры» на сервере DCC-NODE: установка Node и mcbot

Без root, всё ставится в `/work`. Нужно ~400 МБ свободного места и доступ к nodejs.org и registry.npmjs.org.

## 1. Поставить Node и зависимости

```
cd /work/reina
```

```
sh tools/mcbot/install-server.sh
```

Скрипт сам выберет сборку: обычную (glibc), если есть `/lib64/ld-linux-x86-64.so.2` и она запускается, иначе musl через `/work/alp/root/lib/ld-musl-x86_64.so.1`. Повторный запуск безопасен. В конце он печатает три команды `set`: выполните их как есть. Пример:

```
/work/alp/root/lib/ld-musl-x86_64.so.1 --library-path /work/alp/root/usr/lib:/work/alp/root/lib:/work/reina ./reina-tdlib set minecraft.node /work/node/bin/node-run
```

```
/work/alp/root/lib/ld-musl-x86_64.so.1 --library-path /work/alp/root/usr/lib:/work/alp/root/lib:/work/reina ./reina-tdlib set minecraft.script /work/reina/tools/mcbot/mcbot.js
```

```
/work/alp/root/lib/ld-musl-x86_64.so.1 --library-path /work/alp/root/usr/lib:/work/alp/root/lib:/work/reina ./reina-tdlib set minecraft.enabled true
```

Перезапустить Рейну:

```
sh /work/reina/run.sh
```

## 2. Проверить

```
/work/node/bin/node-run --version
```

Тестовый визит: в боте «Миры» добавить свой сервер (публичный адрес, `online-mode=false`) и отправить Рейну. Зайти самому и написать в чат `Reina привет`: она должна ответить.

## 3. Читать результат в run.log

```
grep MCBOT_STATUS /work/reina/run.log | tail -5
```

- `{"state":"joined",...}`: зашла.
- `{"state":"failed","reason":"...","detail":"..."}`: не пустили, причина в `reason`/`detail`.
- `{"state":"left",...}`: вышла (время вышло, попросили уйти, остановка).

## 4. Частые проблемы

- **Лицензионный сервер** (`online-mode=true`, в detail про authentication / Failed to verify username): бот заходит без лицензии. Нужен сервер с `online-mode=false` или купленный аккаунт Java.
- **Whitelist** (`You are not whitelisted`): владелец сервера пишет `/whitelist add Reina`.
- **Версия** (`Outdated client/server`, `unsupported protocol`): версия сервера не та, что в `minecraft.version`. Поменять: `... ./reina-tdlib set minecraft.version 1.20.1` (подставить версию сервера).
- **AuthMe** (просит `/register` или `/login`, потом кикает по таймауту): положить файл `tools/mcbot/pass.secret` с длинной случайной строкой, см. README.
- **Нет соединения** (`ECONNREFUSED`, `ETIMEDOUT`): сервер выключен, неверный порт или адрес закрыт (локальные адреса бот не трогает).
- **Скрипт: «musl-node не запускается»**: в `/work/alp/root` нет `libstdc++` и `libgcc`. Скачать apk-пакеты Alpine `libstdc++` и `libgcc` (это tar.gz) и распаковать в `/work/alp/root`, потом снова запустить скрипт.
- **Скрипт: «не скачалось» / npm не прошёл**: с сервера закрыт интернет до nodejs.org или npm. Поставить на другой машине с тем же типом системы и скопировать `/work/node` и `tools/mcbot/node_modules`.
- **«мало места»**: освободить `/work` (старые логи, архивы).
