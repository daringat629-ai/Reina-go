'use strict';
const test = require('node:test');
const assert = require('node:assert');
const { parse, isCommand, validateAction, ALLOWED_BLOCKS, attach } = require('./play');

const N = 'Reina', A = ['Рейна'];
const act = t => (parse(t, N, A) || {}).action;

test('addressing required', () => {
  assert.equal(isCommand('иди ко мне', N, A), false);
  assert.equal(isCommand('follow me', N, A), false);
  assert.equal(isCommand('Рейна, как дела?', N, A), false);
  assert.equal(isCommand('Рейну позови', N, A), false);
  assert.equal(isCommand('Рейна, иди ко мне', N, A), true);
  assert.equal(isCommand('reina come here', N, A), true);
  assert.equal(isCommand('Рейну стой', N, A), true);
  assert.equal(isCommand('reinastone stop', N, A), false);
});

test('ru/en parsing', () => {
  assert.equal(act('Рейна, иди ко мне'), 'come');
  assert.equal(act('reina come'), 'come');
  assert.equal(act('Рейна следуй за мной'), 'follow');
  assert.equal(act('Reina, follow me'), 'follow');
  assert.equal(act('Рейна стой'), 'stop');
  assert.equal(act('reina stop'), 'stop');
  assert.equal(act('Рейна посмотри на меня'), 'look');
  assert.equal(act('Рейна прыгни'), 'jump');
  assert.equal(act('reina wave'), 'wave');
  assert.equal(act('Рейна ложись спать'), 'sleep');
  assert.equal(act('Рейна поешь'), 'eat');
  assert.equal(act('reina protect me'), 'guard');
  assert.equal(act('Рейна убей зомби'), 'fight');
  assert.deepEqual(parse('Рейна иди на 100 64 -20', N, A), { action: 'goto', x: 100, y: 64, z: -20 });
  assert.deepEqual(parse('reina collect 5 wood', N, A), { action: 'collect', block: 'wood', count: 5 });
  assert.deepEqual(parse('Рейна наруби 3 дерева', N, A), { action: 'collect', block: 'wood', count: 3 });
  assert.deepEqual(parse('Рейна добудь камень', N, A), { action: 'collect', block: 'stone', count: 1 });
  assert.equal(parse('reina mine 999 stone', N, A).count, 16);
  assert.deepEqual(parse('Рейна дай мне 4 угля', N, A), { action: 'give', item: 'угля', count: 4 });
  assert.equal(parse('reina give me bread', N, A).item, 'bread');
});

test('validateAction rejects anything outside the set', () => {
  assert.equal(validateAction({ action: 'exec', code: 'x' }), null);
  assert.equal(validateAction({ action: 'place', block: 'tnt' }), null);
  assert.equal(validateAction({ action: 'collect', block: 'tnt' }), null);
  assert.equal(validateAction({ action: 'collect', block: '__proto__' }), null);
  assert.equal(validateAction({ action: 'goto', x: 1, y: 9999, z: 1 }), null);
  assert.deepEqual(validateAction({ action: 'collect', block: 'wood', count: 100 }), { action: 'collect', block: 'wood', count: 16 });
  assert.equal(validateAction(null), null);
});

test('allowlist has only natural blocks', () => {
  for (const b of ['tnt', 'lava', 'fire', 'oak_planks', 'cobblestone', 'chest', 'stone_bricks', 'glass', 'oak_door'])
    assert.equal(ALLOWED_BLOCKS.has(b), false, b);
  for (const b of ['oak_log', 'stone', 'dirt', 'iron_ore']) assert.equal(ALLOWED_BLOCKS.has(b), true, b);
});

test('smoke: attach after spawn on a fake server', { timeout: 20000 }, async () => {
  const mc = require('minecraft-protocol');
  const mineflayer = require('mineflayer');
  const version = '1.16.5';
  const server = mc.createServer({ 'online-mode': false, host: '127.0.0.1', port: 0, version });
  await new Promise(r => server.on('listening', r));
  const port = server.socketServer.address().port;
  const mcData = require('minecraft-data')(version);
  server.on('playerJoin', client => {
    const login = mcData.loginPacket;
    client.write('login', { ...login, entityId: 1, gameMode: 0, previousGameMode: 255,
      worldNames: ['minecraft:overworld'], worldName: 'minecraft:overworld', hashedSeed: [0, 0],
      maxPlayers: 20, viewDistance: 4, reducedDebugInfo: false, enableRespawnScreen: true, isDebug: false, isFlat: true });
    client.write('position', { x: 0, y: 64, z: 0, yaw: 0, pitch: 0, flags: 0, teleportId: 1 });
    client.write('update_health', { health: 20, food: 20, foodSaturation: 5 });
  });
  const bot = mineflayer.createBot({ host: '127.0.0.1', port, username: 'Reina', version, auth: 'offline' });
  const said = [];
  try {
    await new Promise((res, rej) => { bot.once('spawn', res); bot.once('error', rej); setTimeout(() => rej(new Error('no spawn')), 15000); });
    const h = attach(bot, { name: 'Reina', aliases: ['Рейна'], say: t => said.push(t), llm: async () => '{}', log: () => {} });
    bot.emit('chat', 'Steve', 'Рейна, иди ко мне');
    bot.emit('chat', 'Steve', 'reina jump');
    await new Promise(r => setTimeout(r, 1200));
    assert.ok(said.includes('не вижу тебя'), JSON.stringify(said));
    h.stop();
  } finally {
    bot.end(); server.close();
  }
});
