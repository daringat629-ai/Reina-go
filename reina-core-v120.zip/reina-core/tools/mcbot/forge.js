'use strict';
// Experimental: lets the plain (vanilla) mineflayer client into a Forge server (FML2 = Forge 1.13-1.17,
// FML3 = Forge 1.18-1.20.x). She does not have the mods: she answers the login handshake by echoing the
// server's own mod list, and every modded block is treated as stone so physics and pathfinding don't break.
// Modded blocks, items and mobs mean nothing to her; plain chat and vanilla actions work.

const WRAPPER = 'fml:loginwrapper';
const ACK = 99; // C2SAcknowledge

function writeVarInt(n) {
  const out = [];
  n >>>= 0;
  do {
    let b = n & 0x7f;
    n >>>= 7;
    if (n) b |= 0x80;
    out.push(b);
  } while (n);
  return Buffer.from(out);
}

function readVarInt(buf, off) {
  let n = 0, shift = 0, b;
  do {
    if (off >= buf.length) throw new Error('varint past end');
    b = buf[off++];
    n |= (b & 0x7f) << shift;
    shift += 7;
    if (shift > 35) throw new Error('varint too long');
  } while (b & 0x80);
  return [n >>> 0, off];
}

function writeString(s) {
  const b = Buffer.from(String(s), 'utf8');
  return Buffer.concat([writeVarInt(b.length), b]);
}

function readString(buf, off) {
  let len;
  [len, off] = readVarInt(buf, off);
  if (off + len > buf.length) throw new Error('string past end');
  return [buf.toString('utf8', off, off + len), off + len];
}

// fmlVersion from a status ping: 3 for Forge 1.18-1.20, 2 for 1.13-1.17, 0 = not Forge (or too old/new for us).
function detect(ping) {
  const v = Number(ping?.forgeData?.fmlNetworkVersion || 0);
  return v === 2 || v === 3 ? v : 0;
}

// The tag Forge looks for in the handshake host to know a Forge client is coming.
function hostTag(host, fmlVersion) {
  return String(host) + '\0FML' + fmlVersion + '\0';
}

function unwrap(data) {
  let off = 0, channel, len;
  [channel, off] = readString(data, off);
  [len, off] = readVarInt(data, off);
  return { channel, inner: data.subarray(off, off + len) };
}

function wrap(channel, inner) {
  return Buffer.concat([writeString(channel), writeVarInt(inner.length), inner]);
}

// S2CModList body (after the packet id): mods, channels (name -> version), registries, [datapack registries].
function parseModList(buf) {
  let off = 0, n;
  const mods = [], channels = [], registries = [];
  [n, off] = readVarInt(buf, off);
  for (let i = 0; i < n; i++) { let s; [s, off] = readString(buf, off); mods.push(s); }
  [n, off] = readVarInt(buf, off);
  for (let i = 0; i < n; i++) { let a, b; [a, off] = readString(buf, off); [b, off] = readString(buf, off); channels.push([a, b]); }
  [n, off] = readVarInt(buf, off);
  for (let i = 0; i < n; i++) { let s; [s, off] = readString(buf, off); registries.push(s); }
  return { mods, channels, registries };
}

// C2SModListReply: the same mods and channels back, each registry with an empty hash (= "same as yours").
function buildModListReply({ mods, channels, registries }) {
  const parts = [writeVarInt(2), writeVarInt(mods.length)];
  for (const m of mods) parts.push(writeString(m));
  parts.push(writeVarInt(channels.length));
  for (const [a, b] of channels) parts.push(writeString(a), writeString(b));
  parts.push(writeVarInt(registries.length));
  for (const r of registries) parts.push(writeString(r), writeString(''));
  return Buffer.concat(parts);
}

// The answer to one login plugin request (undefined = "not understood", like the vanilla client).
function answer(packet, log = () => {}) {
  if (packet.channel !== WRAPPER || !packet.data) return undefined;
  const { channel, inner } = unwrap(packet.data);
  const [id, off] = readVarInt(inner, 0);
  if (id === 1) {
    const ml = parseModList(inner.subarray(off));
    log(`forge: server has ${ml.mods.length} mods, ${ml.channels.length} channels; pretending to have them`);
    return wrap(channel, buildModListReply(ml));
  }
  return wrap(channel, writeVarInt(ACK)); // registries, configs, mod data: just acknowledge
}

// Take over the login plugin requests of a minecraft-protocol client.
function attachLogin(client, log = () => {}) {
  client.removeAllListeners('login_plugin_request'); // the default handler says "not understood"
  client.on('login_plugin_request', (p) => {
    let data;
    try { data = answer(p, log); } catch (e) { log('forge: bad handshake packet:', e.message); }
    client.write('login_plugin_response', data ? { messageId: p.messageId, data } : { messageId: p.messageId });
  });
}

// Every block state the vanilla registry doesn't know becomes plain stone: solid, so she won't walk into it.
function maskUnknownBlocks(registry) {
  if (!registry || registry.__forgeMasked) return;
  const stone = registry.blocksByName?.stone;
  const byState = registry.blocksByStateId;
  if (!stone || !byState) return;
  const stoneLike = { ...stone, minStateId: 0, maxStateId: 1 << 30, name: 'stone', displayName: 'Modded block' };
  registry.blocksByStateId = new Proxy(byState, {
    get(t, k) {
      const v = t[k];
      if (v !== undefined || typeof k !== 'string' || !/^\d+$/.test(k)) return v;
      return { ...stoneLike, minStateId: Number(k), maxStateId: Number(k) };
    },
  });
  Object.defineProperty(registry, '__forgeMasked', { value: true });
}

module.exports = { detect, hostTag, attachLogin, maskUnknownBlocks, answer, parseModList, buildModListReply, wrap, unwrap, writeVarInt, readVarInt, writeString, readString, WRAPPER, ACK };
