package main

import (
	"context"
	"encoding/json"
	"net"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"orvi/internal/config"
)

func TestDoctor(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Authorization") != "Bearer good" {
			w.WriteHeader(http.StatusUnauthorized)
			w.Write([]byte(`{"error":{"message":"invalid key"}}`))
			return
		}
		if strings.HasSuffix(r.URL.Path, "/embeddings") {
			json.NewEncoder(w).Encode(map[string]any{"data": []any{map[string]any{"embedding": []float64{0.1, 0.2, 0.3}}}})
			return
		}
		w.Write([]byte(`{"choices":[{"message":{"role":"assistant","content":"pong"}}]}`))
	}))
	defer srv.Close()
	path := filepath.Join(t.TempDir(), "config.toml")
	var out strings.Builder
	if err := runDoctor(path, &out); err == nil || !strings.Contains(out.String(), "создан") {
		t.Fatalf("a missing config must be reported: %v\n%s", err, out.String())
	}
	set := func(sec, key, val string) {
		if err := config.SetKey(path, sec, key, val); err != nil {
			t.Fatal(err)
		}
	}
	set("llm", "base_url", srv.URL+"/v1/")
	set("llm", "model", "m")
	set("llm", "api_key", "good")
	set("llm", "embedding_model", "e")
	set("misc", "data_dir", filepath.Join(t.TempDir(), "data"))
	out.Reset()
	if err := runDoctor(path, &out); err != nil {
		t.Fatalf("a working setup failed: %v\n%s", err, out.String())
	}
	for _, want := range []string{"✔ LLM m — отвечает", "✔ эмбеддинги e — вектор из 3 чисел", "Telegram — выключен"} {
		if !strings.Contains(out.String(), want) {
			t.Errorf("missing %q in:\n%s", want, out.String())
		}
	}
	set("llm", "api_key", "bad")
	out.Reset()
	if err := runDoctor(path, &out); err == nil || !strings.Contains(out.String(), "ключ не подходит") {
		t.Fatalf("a bad key must fail with a clear reason:\n%s", out.String())
	}
}

func TestDoctorLocalServersDataDirAndTimezone(t *testing.T) {
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Skip(err)
	}
	up := ln.Addr().String()
	ln.Close() // now nothing listens there: connection refused
	live, _ := net.Listen("tcp", "127.0.0.1:0")
	defer live.Close()
	go func() {
		for {
			c, err := live.Accept()
			if err != nil {
				return
			}
			c.Close()
		}
	}()
	cfg, _ := config.Parse("")
	cfg.EmbeddingBaseURL = "http://" + up + "/v1/"
	cfg.TTSBackend = "openai"
	cfg.TTSURL = "http://" + live.Addr().String() + "/v1/"
	cfg.DataDir = filepath.Join(t.TempDir(), "data")
	cfg.AutonomyTimezone = ""
	var out strings.Builder
	d := &doctor{out: &out}
	ctx := context.Background()
	d.checkEmbeddingServer(ctx, cfg)
	d.checkTTS(ctx, cfg)
	d.checkDataDir(cfg)
	d.checkDisk(cfg)
	d.checkTimezone(cfg)
	got := out.String()
	for _, want := range []string{"✘ эмбеддинг-сервер " + up, "✔ TTS-сервер", "✔ папка data", "⚠ часовой пояс"} {
		if !strings.Contains(got, want) {
			t.Errorf("missing %q in:\n%s", want, got)
		}
	}
	if !d.embedDown || !d.failed() {
		t.Error("a dead embedding server must be a failure")
	}
	// a read-only data dir is a failure with a hint
	ro := filepath.Join(t.TempDir(), "ro")
	os.MkdirAll(ro, 0o500)
	if os.Geteuid() != 0 {
		cfg.DataDir = ro
		out.Reset()
		d2 := &doctor{out: &out}
		d2.checkDataDir(cfg)
		if !d2.failed() || !strings.Contains(out.String(), "нельзя писать") {
			t.Errorf("read-only data dir: %s", out.String())
		}
	}
	// an open data dir is a warning
	open := filepath.Join(t.TempDir(), "open")
	os.MkdirAll(open, 0o755)
	os.Chmod(open, 0o777)
	cfg.DataDir = open
	out.Reset()
	d3 := &doctor{out: &out}
	d3.checkDataDir(cfg)
	if d3.failed() || !strings.Contains(out.String(), "⚠ папка data") {
		t.Errorf("open data dir: %s", out.String())
	}
}
