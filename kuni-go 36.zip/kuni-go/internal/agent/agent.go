// Package agent wires everything together: Telegram updates -> per-chat sessions
// -> LLM tool loop (tools act back on Telegram) -> diary + working memory dump
// when the conversation goes idle. It is the Go counterpart of App/Worker/AppBase.
package agent

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"math/rand"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"kuni/internal/autonomy"
	"kuni/internal/config"
	"kuni/internal/diary"
	livefeed "kuni/internal/live"
	"kuni/internal/llm"
	"kuni/internal/llmui"
	"kuni/internal/memory"
	"kuni/internal/metrics"
	"kuni/internal/prompts"
	"kuni/internal/telegram"
	"kuni/internal/tools"
	"kuni/internal/usage"
	"kuni/internal/util"
)

type Agent struct {
	Cfg        *config.Holder
	LLM        *llm.Client
	TG         telegram.Client
	Diary      *diary.Diary
	Prompts    *prompts.Store
	UI         *llmui.Env
	Dumper     *memory.Dumper
	Metrics    *metrics.Registry
	Deps       tools.Deps
	Auto       *autonomy.State                 // nil = autonomy unavailable
	Usage      *usage.Tracker                  // nil = no budget
	Price      func(model string) usage.Prices // nil = no prices known (the panel shows tokens only)
	ConfigPath string                          // config.toml, for /backup with backup.include_config
	Started    time.Time                       // for the uptime in /status

	active   atomic.Int32
	paused   atomic.Bool
	runCtx   context.Context
	mu       sync.Mutex
	sessions map[int64]*session
	carry    map[int64]carried // summaries of dumped sessions, for when the talk resumes
	timers   map[int64]*time.Timer
	later    map[int64]time.Time // chats held back by a late reply
	used     map[int64]bool      // a late reply just fired for the chat: do not postpone again
	noticing map[int64]bool      // chats in the "read pause" phase
	phases   map[int64]phaseInfo // what each waiting chat is doing, for the panel
}

type session struct {
	mu    sync.Mutex // serialises turns
	id    int64
	msgs  []llm.Message
	last  time.Time
	tools *tools.Registry
	chat  telegram.Chat
	fresh bool // true until the first turn (working memory is injected once)
	// unlocked lazy tool groups survive re-binding of the registry within a session.
	unlocked map[string]bool
	// thread is the forum topic the chat's latest unread message came from; sends without a reply go there.
	thread int64
	// notes are things that happened to old messages (reactions, edits); shown in the next turn, no LLM call of their own.
	nmu   sync.Mutex
	notes []note
	// quick: the latest incoming messages are short private talk, so the first round needs no long thinking.
	quick bool
	// rosterAt is when the member list of the chat was last put into the prompt.
	rosterAt time.Time
	// deskAt is when the overview of her whole Telegram was last put into the prompt.
	deskAt time.Time
}

// New initialises internal state of a (fill the exported fields first).
func New(a *Agent) *Agent {
	a.sessions = map[int64]*session{}
	a.carry = map[int64]carried{}
	a.timers = map[int64]*time.Timer{}
	a.later = map[int64]time.Time{}
	a.used = map[int64]bool{}
	a.noticing = map[int64]bool{}
	return a
}

// SystemPrompt is system + character_base + <your_appearance> (AppBase::getSystemPrompt).
func (a *Agent) SystemPrompt() string {
	return a.Prompts.Get(prompts.System) + "\n\n" + a.Prompts.Get(prompts.CharacterBase) +
		"\n\n<your_appearance>\n" + a.Prompts.Get(prompts.CharacterAppearance) + "\n</your_appearance>"
}

// Run processes Telegram updates until ctx ends, then dumps all open sessions.
func (a *Agent) Run(ctx context.Context) {
	a.runCtx = ctx
	var wg sync.WaitGroup
	wg.Add(5)
	go func() { defer wg.Done(); a.reminderLoop(ctx) }()
	go func() { defer wg.Done(); a.idleLoop(ctx) }()
	go func() { defer wg.Done(); a.proactiveLoop(ctx) }()
	go func() { defer wg.Done(); a.workLoop(ctx) }()
	go func() { defer wg.Done(); a.backupLoop(ctx) }()

	// handle messages that arrived while we were offline
	if chats, err := a.TG.Chats(ctx, 100); err == nil {
		for _, c := range chats {
			if c.Unread > 0 {
				a.schedule(ctx, c.ID)
			}
		}
	}

	updates := a.TG.Updates()
	var events <-chan telegram.Event // nil (blocks forever) when the client does not report them
	if es, ok := a.TG.(telegram.EventSource); ok {
		events = es.Events()
	}
loop:
	for {
		select {
		case <-ctx.Done():
			break loop
		case m, ok := <-updates:
			if !ok {
				break loop
			}
			a.Metrics.Inc("kuni_telegram_messages_received_total", 1, nil)
			log.Printf("agent: incoming message in chat %d from %q (%d chars)", m.ChatID, m.SenderName, len(m.Text))
			if !m.Outgoing {
				livefeed.Default.AddEvent(livefeed.Event{Kind: "chat", Chat: m.SenderName, Text: "← " + m.Text, ChatID: m.ChatID})
			}
			if a.command(ctx, m) {
				continue
			}
			a.schedule(ctx, m.ChatID)
		case ev := <-events:
			a.onEvent(ctx, ev)
		}
	}
	wg.Wait()

	// graceful shutdown: give the LLM time to dump the remaining context.
	dumpCtx, cancel := context.WithTimeout(context.Background(), 3*time.Minute)
	defer cancel()
	a.DumpAll(dumpCtx)
}

// schedule debounces bursts of messages, then handles the chat once.
func (a *Agent) schedule(ctx context.Context, chatID int64) {
	delay := a.Cfg.Get().DebounceWindow
	if c := a.Cfg.Get(); c.GroupDebounce > delay {
		if ch, err := a.TG.Chat(ctx, chatID); err == nil && ch.Kind != telegram.ChatPrivate {
			delay = c.GroupDebounce
		}
	}
	a.mu.Lock()
	defer a.mu.Unlock()
	if until, ok := a.later[chatID]; ok && time.Now().Before(until) {
		return // she is not looking at this chat yet; new messages just wait with the old ones
	}
	if t, ok := a.timers[chatID]; ok {
		t.Stop()
	}
	a.setPhaseLocked(chatID, "waiting", time.Time{})
	a.timers[chatID] = time.AfterFunc(delay, func() {
		if ctx.Err() != nil {
			return
		}
		defer a.endPhase(chatID)
		defer func() {
			if r := recover(); r != nil {
				log.Printf("agent: chat %d: PANIC recovered: %v", chatID, r)
			}
		}()
		if err := a.HandleChat(ctx, chatID); err != nil {
			log.Printf("agent: chat %d: %v", chatID, err)
		}
	})
}

func (a *Agent) getSession(id int64) *session {
	a.mu.Lock()
	defer a.mu.Unlock()
	s := a.sessions[id]
	if s == nil {
		s = &session{id: id, fresh: true}
		if c, ok := a.carry[id]; ok {
			delete(a.carry, id)
			if time.Since(c.at) < carryTTL {
				s.msgs = []llm.Message{c.head} // a talk that went quiet continues where it stopped
			}
		}
		a.sessions[id] = s
		a.Metrics.Set("kuni_sessions_active", float64(len(a.sessions)), nil)
	}
	return s
}

// HandleChat reads unread messages of a chat and lets the model act on them.
func (a *Agent) HandleChat(ctx context.Context, chatID int64) error {
	if a.paused.Load() {
		return nil // paused from the admin panel: messages stay unread and are handled on resume
	}
	cfg := a.Cfg.Get()
	if !tools.Accessible(cfg, chatID) {
		log.Printf("agent: chat %d ignored by lockdown=%q (owner chat id is %d)", chatID, cfg.Lockdown, cfg.PapikChatID)
		_ = a.TG.MarkRead(ctx, chatID)
		return nil
	}
	chat, err := a.TG.Chat(ctx, chatID)
	if err != nil {
		return err
	}
	unread, err := a.TG.Unread(ctx, chatID)
	if chatID == cfg.PapikChatID { // slash commands are the program's business, never the model's
		kept := unread[:0:0]
		for _, m := range unread {
			if m.Outgoing || !isCommand(m.Text) {
				kept = append(kept, m)
			}
		}
		if len(kept) == 0 && len(unread) > 0 {
			return a.TG.MarkRead(ctx, chatID)
		}
		unread = kept
	}
	if err != nil || len(unread) == 0 {
		log.Printf("agent: chat %d: nothing to handle (unread=%d, err=%v)", chatID, len(unread), err)
		return err
	}
	if !a.worthWaking(ctx, chat, unread) {
		// not meant for her: she reads it (marks read) but no paid model call is made
		_ = a.TG.MarkRead(ctx, chatID)
		a.Metrics.Inc("kuni_group_skipped_total", 1, nil)
		return nil
	}
	s := a.getSession(chatID)
	// living presence: she may only look at the chat later, and she needs a moment to notice it at all.
	if until, ok := a.postponedUntil(chatID); ok && time.Now().Before(until) {
		return nil
	}
	if !a.beginNoticing(chatID) {
		return nil // another call is already waiting to open this chat; it will see everything unread
	}
	plan := a.presenceFor(chat, s, time.Now())
	if plan.Late > 0 && !a.takeUsed(chatID) {
		a.endNoticing(chatID)
		a.postpone(ctx, chatID, plan.Late)
		return nil
	}
	a.setPhase(chatID, "noticing", time.Time{})
	ok := a.readPause(ctx, plan.Read)
	a.endNoticing(chatID)
	if !ok {
		return nil
	}
	if unread, err = a.TG.Unread(ctx, chatID); err != nil || len(unread) == 0 {
		return err
	}
	log.Printf("agent: handling chat %d %q: %d unread (noticed after %s)", chatID, chat.Title, len(unread), plan.Read.Round(100*time.Millisecond))
	s.mu.Lock()
	defer s.mu.Unlock()
	defer a.goOnline(ctx)()
	a.setPhase(chatID, "thinking", time.Time{})

	view, err := a.renderChat(ctx, s, chat, unread)
	if err != nil {
		return err
	}
	_ = a.TG.MarkRead(ctx, chatID)
	s.msgs = append(s.msgs, llm.Message{Role: "user", Content: view})
	return a.runTurn(ctx, s)
}

func (a *Agent) depsFor(s *session) tools.Deps {
	d := a.Deps
	d.Wake = func(chatID int64, text string) {
		go func() {
			if err := a.Wake(a.wakeCtx(), chatID, text); err != nil {
				log.Printf("agent: wake chat %d: %v", chatID, err)
			}
		}()
	}
	d.OpenChat = func(ctx context.Context, id int64) (string, error) { return a.openChat(ctx, s, id) }
	if a.Auto != nil && a.Cfg.Get().AutonomyEnabled {
		d.GoToSleep = a.goToSleep
	}
	return d
}

// openChat is the open_chat tool backend for proactive sessions.
func (a *Agent) openChat(ctx context.Context, s *session, chatID int64) (string, error) {
	chat, err := a.TG.Chat(ctx, chatID)
	if err != nil {
		return "", fmt.Errorf("chat %d not found", chatID)
	}
	unread, _ := a.TG.Unread(ctx, chatID)
	hist, _ := a.TG.History(ctx, chatID, 0, 20, 0)
	var b strings.Builder
	fmt.Fprintf(&b, "You switched to the chat %q in Telegram. You see last messages:\n", chat.Title)
	b.WriteString(a.UI.FormatMessages(ctx, hist, time.Now()))
	b.WriteString(a.chatInstructions(chat))
	d := a.depsFor(s)
	s.chat = chat
	s.tools = a.newRegistry(s, d, chat, true, unread)
	if len(unread) > 0 {
		_ = a.TG.MarkRead(ctx, chatID)
	}
	return b.String(), nil
}

// runTurn is the LLM <-> tools loop. The model's plain-text answer is its private
// "thought"; only tool calls have effects.
func (a *Agent) runTurn(ctx context.Context, s *session) error {
	cfg := a.Cfg.Get()
	a.Metrics.Inc("kuni_agent_turns_total", 1, nil)
	ctx = llm.WithChat(ctx, s.id) // so the panel can show what each chat costs
	system := a.SystemPrompt()
	a.compact(ctx, s)
	seen := map[string]bool{}
	maxRounds := cfg.MaxToolRounds
	browsing, afterBrowser := false, false
	for round := 0; round < maxRounds; round++ {
		rctx := llm.WithPurpose(ctx, "reply")
		// a browser step needs the next action, not a long think; so does any round after a tool result, and a short chat line
		fast := (cfg.BrowserFast && afterBrowser) || (cfg.FastRounds && (round > 0 || s.quick))
		if fast {
			rctx = llm.WithReasoning(rctx, "off")
		}
		forced := cfg.ForceTools // every round: plain-text answers are never delivered to Telegram
		if forced {
			rctx = llm.WithToolChoice(rctx, "required")
		}
		stopTyping := a.typeWhileThinking(ctx, s)
		reply, err := a.LLM.Complete(rctx, system, a.outgoing(s), s.tools.Defs())
		stopTyping()
		if err != nil && fast {
			log.Printf("agent: chat %d: fast round failed (%v), retrying with normal reasoning", s.id, err)
			retry := llm.WithPurpose(ctx, "reply")
			if forced {
				retry = llm.WithToolChoice(retry, "required")
			}
			reply, err = a.LLM.Complete(retry, system, a.outgoing(s), s.tools.Defs())
		} else if err != nil && forced {
			// the provider may not support tool_choice: retry without forcing
			log.Printf("agent: chat %d: forced tool call failed (%v), retrying without", s.id, err)
			reply, err = a.LLM.Complete(llm.WithPurpose(ctx, "reply"), system, a.outgoing(s), s.tools.Defs())
		}
		if err != nil {
			return err
		}
		if strings.TrimSpace(reply.Content) == "" && len(reply.ToolCalls) == 0 {
			log.Printf("agent: chat %d round %d: empty answer from the model, retrying", s.id, round)
			continue // blank answer from a local model: ask again
		}
		s.msgs = append(s.msgs, reply)
		s.last = time.Now()
		var names []string
		for _, c := range reply.ToolCalls {
			names = append(names, c.Function.Name)
		}
		log.Printf("agent: chat %d round %d: tools=%v thought=%q", s.id, round, names, util.Trunc(reply.Content, 160))
		if len(reply.ToolCalls) == 0 {
			return nil
		}
		onlyWait, hasWait := true, false
		afterBrowser = false
		for _, c := range reply.ToolCalls {
			if c.Function.Name == "browser" {
				afterBrowser = true
				if !browsing { // a browsing job needs many rounds: they are paid for by browser.max_steps, not by max_tool_rounds
					browsing = true
					maxRounds += cfg.BrowserSteps + 2
				}
			}
			switch c.Function.Name {
			case "wait", "pause":
				hasWait = true
			case "change_mood": // bookkeeping only, does not count as an action
			default:
				onlyWait = false
			}
		}
		onlyWait = onlyWait && hasWait
		chatLabel := s.chat.Title
		if s.id == 0 {
			chatLabel = "proactive"
		}
		if strings.TrimSpace(reply.Content) != "" {
			livefeed.Default.Add("thought", chatLabel, reply.Content)
		}
		for _, c := range reply.ToolCalls {
			start := time.Now()
			target, typing := liveTarget(c.Function.Name, c.Function.Arguments, s.chat.ID)
			livefeed.Default.AddEvent(livefeed.Event{Kind: "tool", Chat: chatLabel, Text: c.Function.Name + " " + string(c.Function.Arguments), ChatID: target, Typing: typing})
			key := c.Function.Name + "|" + string(c.Function.Arguments)
			var out string
			if c.Function.Name == "ask" && seen["ask"] {
				out = "You already consulted memory this turn. Answer now with send_telegram_message."
			} else if seen[key] && c.Function.Name != "browser" && c.Function.Name != "send_telegram_message" && c.Function.Name != "wait" && c.Function.Name != "pause" {
				out = "You already called this with the same arguments and have the result above. Do not repeat it: answer now with send_telegram_message."
			} else {
				out = s.tools.Call(telegram.WithThread(ctx, s.thread), c.Function.Name, c.Function.Arguments)
			}
			livefeed.Default.Add("result", chatLabel, out)
			log.Printf("agent: chat %d: %s -> %s", s.id, c.Function.Name, util.Trunc(strings.Join(strings.Fields(out), " "), 120))
			seen[key] = true
			if c.Function.Name == "ask" {
				seen["ask"] = true
			}
			s.msgs = append(s.msgs, llm.Message{Role: "tool", ToolCallID: c.ID, Content: out})
			a.Metrics.Inc("kuni_tool_calls_total", 1, map[string]string{"tool": c.Function.Name})
			// names used by the original Grafana dashboard
			labels := map[string]string{"tool": c.Function.Name, "function": c.Function.Name, "chat": chatLabel}
			a.Metrics.Inc("tool_call_total", 1, labels)
			a.Metrics.Set("tool_call_response_time_seconds_gauge", time.Since(start).Seconds(), labels)
		}
		if onlyWait {
			return nil // the model chose to stay silent
		}
		if cfg.StopAfterSend && sentOnly(reply.ToolCalls, s.msgs) {
			return nil // said what it wanted; no extra round just to hear "done"
		}
	}
	log.Printf("agent: chat %d: tool round limit (%d) reached", s.id, cfg.MaxToolRounds)
	return nil
}

// proactiveLoop periodically lets the model look through its chats on its own. With [autonomy] enabled the pause
// is random, nights and sleep are respected and the daily limits apply; otherwise telegram.proactive_interval_secs rules.
func (a *Agent) proactiveLoop(ctx context.Context) {
	for {
		cfg := a.Cfg.Get()
		wait := time.Minute // config may be enabled later via hot reload
		switch {
		case cfg.AutonomyEnabled && a.Auto != nil:
			lo, hi := cfg.AutonomyMinMins, cfg.AutonomyMaxMins
			if lo < 1 {
				lo = 1
			}
			if hi < lo {
				hi = lo
			}
			wait = time.Duration(lo+rand.Intn(hi-lo+1)) * time.Minute
		case cfg.Proactive > 0:
			wait = cfg.Proactive
		}
		select {
		case <-ctx.Done():
			return
		case <-time.After(wait):
		}
		cfg = a.Cfg.Get()
		switch {
		case cfg.AutonomyEnabled && a.Auto != nil:
			if err := a.ActAutonomously(ctx); err != nil {
				log.Printf("agent: autonomy: %v", err)
			}
		case cfg.Proactive > 0:
			if err := a.ActProactively(ctx); err != nil {
				log.Printf("agent: proactive: %v", err)
			}
		}
	}
}

// ActProactively runs a session in which the model decides whom to write to.
func (a *Agent) ActProactively(ctx context.Context) error {
	if a.paused.Load() || a.Usage.Over(a.Cfg.Get().DailyTokenLimit) {
		return nil
	}
	s := a.getSession(0)
	s.mu.Lock()
	defer s.mu.Unlock()
	d := a.depsFor(s)
	s.tools = tools.NewRegistry(a.baseTools(d, true)...)
	msg := "You have some free time and nobody is writing to you right now. Check your chats with #get_telegram_chats " +
		"(open one with #open_chat) and decide if there is somebody you would like to write to, or something to revisit " +
		"from <things_to_remember>. If there is nothing worth doing, just reflect briefly and do nothing."
	if s.fresh {
		s.fresh = false
		if wm, _ := (memory.WorkingMemory{Path: a.Cfg.Get().WorkingMemoryFile}).Load(); strings.TrimSpace(wm) != "" {
			msg = "<things_to_remember>\n" + wm + "\n</things_to_remember>\n\n" + msg
		}
	}
	msg = fmt.Sprintf("It is %s.\n%s%s", time.Now().Format("Mon Jan 2 15:04"), a.moodBlock(), msg)
	s.msgs = append(s.msgs, llm.Message{Role: "user", Content: msg})
	return a.runTurn(ctx, s)
}

var _ = util.TimeAgo

// goOnline shows the account as online while a turn runs (user mode only) and
// returns a func that schedules going offline again shortly after the last turn.
func (a *Agent) goOnline(ctx context.Context) func() {
	p, ok := a.TG.(interface {
		SetOnline(ctx context.Context, online bool)
	})
	if !ok {
		return func() {}
	}
	if a.active.Add(1) == 1 {
		p.SetOnline(ctx, true)
	}
	return func() {
		a.active.Add(-1)
		time.AfterFunc(a.offlineAfter(), func() {
			if a.active.Load() == 0 {
				c, cancel := context.WithTimeout(context.Background(), 10*time.Second)
				defer cancel()
				p.SetOnline(c, false)
			}
		})
	}
}

// typeWhileThinking keeps the "typing…" indicator on in private chats while a model call is running.
func (a *Agent) typeWhileThinking(ctx context.Context, s *session) func() {
	if !a.Cfg.Get().TypingThinking || s.id == 0 || s.chat.Kind != telegram.ChatPrivate {
		return func() {}
	}
	c, cancel := context.WithCancel(ctx)
	go func() {
		for {
			_ = a.TG.Typing(c, s.id)
			select {
			case <-c.Done():
				return
			case <-time.After(4 * time.Second):
			}
		}
	}()
	return cancel
}

// sentOnly: the round consisted of sent messages (and reactions) that all succeeded.
func sentOnly(calls []llm.ToolCall, msgs []llm.Message) bool {
	sent := false
	for _, c := range calls {
		switch c.Function.Name {
		case "send_telegram_message":
			sent = true
		case "react_with_emoji", "change_mood":
		default:
			return false
		}
	}
	if !sent {
		return false
	}
	for i := len(msgs) - 1; i >= 0 && len(msgs)-i <= len(calls); i-- {
		if msgs[i].Role == "tool" && strings.Contains(strings.ToLower(msgs[i].Content), "error") {
			return false
		}
	}
	return true
}

// Paused reports whether replies are paused.
func (a *Agent) Paused() bool { return a.paused.Load() }

// SetPaused pauses or resumes replying. Messages that arrive while paused stay unread
// and every chat with unread messages is handled right after resuming.
func (a *Agent) SetPaused(p bool) {
	was := a.paused.Swap(p)
	log.Printf("agent: paused=%v", p)
	if was && !p && a.runCtx != nil {
		ctx := a.runCtx
		go func() {
			chats, err := a.TG.Chats(ctx, 100)
			if err != nil {
				return
			}
			for _, c := range chats {
				if c.Unread > 0 {
					a.schedule(ctx, c.ID)
				}
			}
		}()
	}
}

// liveTarget finds the Telegram chat a tool call is about and the text it writes there, for the panel's Telegram view.
func liveTarget(name, args string, current int64) (chatID int64, typing string) {
	chatID = current
	if name == "telegram_ui" { // the screen reports where she looks itself; "chat" there may be a number from the list
		return 0, ""
	}
	var v map[string]any
	if json.Unmarshal([]byte(args), &v) != nil {
		return
	}
	if n, ok := v["chat_id"].(float64); ok && n != 0 {
		chatID = int64(n)
	} else if s, ok := v["chat"].(string); ok {
		if n, err := strconv.ParseInt(strings.TrimSpace(s), 10, 64); err == nil {
			chatID = n
		}
	}
	text, _ := v["text"].(string)
	switch name {
	case "send_telegram_message", "edit_message_text", "send_to_chat":
		typing = text
	case "tg_api":
		if act, _ := v["action"].(string); act == "send" || act == "edit" {
			typing = text
		}
	}
	return
}
