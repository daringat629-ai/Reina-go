package agent

import (
	"context"
	"fmt"
	"log"
	"strings"
	"time"

	"kuni/internal/llm"
	"kuni/internal/memory"
	"kuni/internal/util"
)

// trim keeps the last n messages, starting at a user message so tool-call pairs stay intact.
func trim(msgs []llm.Message, n int) []llm.Message {
	if len(msgs) <= n {
		return msgs
	}
	if len(msgs) > 0 && isSummary(msgs[0]) && n > 1 {
		// the rolling summary is the only memory of the start of a long talk: it never falls out
		return append([]llm.Message{msgs[0]}, trim(msgs[1:], n-1)...)
	}
	cut := len(msgs) - n
	for cut < len(msgs) && msgs[cut].Role != "user" {
		cut++
	}
	if cut >= len(msgs) {
		return msgs[len(msgs)-1:]
	}
	return msgs[cut:]
}

// idleLoop dumps sessions that have been silent for SessionIdle.
func (a *Agent) idleLoop(ctx context.Context) {
	t := time.NewTicker(30 * time.Second)
	defer t.Stop()
	type backoff struct {
		n    int
		next time.Time
	}
	fails := map[int64]backoff{} // a failing dump is retried with growing pauses, not every tick
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
			idle := a.Cfg.Get().SessionIdle
			var ids []int64
			a.mu.Lock()
			for id, s := range a.sessions {
				if !s.last.IsZero() && time.Since(s.last) >= idle && !time.Now().Before(fails[id].next) {
					ids = append(ids, id)
				}
			}
			for id := range fails {
				if a.sessions[id] == nil {
					delete(fails, id)
				}
			}
			a.mu.Unlock()
			for _, id := range ids {
				if err := a.dump(ctx, id); err != nil {
					b := fails[id]
					b.n++
					d := time.Minute << min(b.n-1, 4) // 1, 2, 4, 8, 16 min
					b.next = time.Now().Add(d)
					fails[id] = b
					log.Printf("agent: dump chat %d: %v (next try in %s)", id, err, d)
				} else {
					delete(fails, id)
				}
			}
		}
	}
}

// dump saves one session to the diary/working memory and forgets it.
func (a *Agent) dump(ctx context.Context, id int64) error {
	a.mu.Lock()
	s := a.sessions[id]
	a.mu.Unlock()
	if s == nil {
		return nil
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.last.IsZero() {
		// nothing happened since it was opened (only a carried summary): not worth a diary page
		a.mu.Lock()
		if len(s.msgs) > 0 && isSummary(s.msgs[0]) {
			a.carry[id] = carried{head: s.msgs[0], at: time.Now()}
		}
		delete(a.sessions, id)
		a.mu.Unlock()
		return nil
	}
	msgs := flatten(s.msgs)
	if len(msgs) > 0 && a.Dumper != nil {
		a.Dumper.WM = memory.WorkingMemory{Path: a.Cfg.Get().WorkingMemoryFile}
		if err := a.Dumper.DumpSession(ctx, a.SystemPrompt(), msgs); err != nil {
			return err // keep the session; retry on the next idle tick
		}
		a.learnPerson(ctx, s, msgs)
	}
	a.mu.Lock()
	if len(s.msgs) > 0 && isSummary(s.msgs[0]) {
		a.carry[id] = carried{head: s.msgs[0], at: time.Now()}
	}
	delete(a.sessions, id)
	a.Metrics.Set("kuni_sessions_active", float64(len(a.sessions)), nil)
	a.mu.Unlock()
	return nil
}

// DumpAll flushes every open session (shutdown).
func (a *Agent) DumpAll(ctx context.Context) {
	a.mu.Lock()
	ids := make([]int64, 0, len(a.sessions))
	for id := range a.sessions {
		ids = append(ids, id)
	}
	a.mu.Unlock()
	for _, id := range ids {
		if err := a.dump(ctx, id); err != nil {
			log.Printf("agent: dump chat %d: %v", id, err)
		}
	}
}

// flatten turns tool-calling history into a plain transcript: dump calls have no tools,
// and many servers reject tool messages without a tools parameter.
func flatten(msgs []llm.Message) []llm.Message {
	if len(msgs) == 0 {
		return nil
	}
	var b strings.Builder
	for _, m := range msgs {
		switch m.Role {
		case "user":
			b.WriteString(m.Content + "\n")
		case "assistant":
			if strings.TrimSpace(m.Content) != "" {
				b.WriteString("[your thoughts] " + m.Content + "\n")
			}
			for _, c := range m.ToolCalls {
				fmt.Fprintf(&b, "[you called #%s %s]\n", c.Function.Name, c.Function.Arguments)
			}
		case "tool":
			b.WriteString("[tool result] " + m.Content + "\n")
		}
	}
	text := b.String()
	if len(text) > 60000 {
		text = text[len(text)-60000:]
	}
	return []llm.Message{{Role: "user", Content: "<session_transcript>\n" + text + "\n</session_transcript>"}}
}

// SessionSummaries describes open sessions for the debug page.
func (a *Agent) SessionSummaries() []string {
	a.mu.Lock()
	defer a.mu.Unlock()
	var out []string
	for id, s := range a.sessions {
		title := "proactive"
		if id != 0 {
			title = s.chat.Title
		}
		out = append(out, fmt.Sprintf("%s (id %d): %d messages, last activity %s", title, id, len(s.msgs), util.TimeAgo(s.last, time.Now())))
	}
	return out
}

const compactSystem = `You compress an old part of a chat session of an AI character so that it can continue a long conversation.
Write a dense summary in the language of the conversation, in the character's first person.
If the text starts with a <conversation_so_far> block, that is the previous summary: carry over everything in it that still matters
(do not shorten old facts just to make room; drop only what is obsolete or already settled) and add what happened since.
Keep, grouped under short plain labels: FACTS about the people (names, jobs, preferences, what they told), PLANS and PROMISES
(who owes what, when), OPEN QUESTIONS, how the relationship and the tone are going, and what the character ALREADY said or
answered (so it does not repeat itself). Drop greetings, filler and tool mechanics. At most 350 words. Output only the summary.`

// compact replaces the old part of a long session with a short summary (history_keep verbatim messages stay).
// On any failure the history is left as is (trim still bounds it).
func (a *Agent) compact(ctx context.Context, s *session) {
	cfg := a.Cfg.Get()
	keep := cfg.HistoryKeep
	if keep <= 0 {
		return
	}
	size := 0
	for _, m := range s.msgs {
		size += msgSize(m)
	}
	if len(s.msgs) < 2*keep && (cfg.ContextChars <= 0 || size < 2*cfg.ContextChars) {
		return
	}
	cut := len(s.msgs) - keep
	if cut < 0 {
		cut = 0
	}
	for cut < len(s.msgs) && s.msgs[cut].Role != "user" {
		cut++
	}
	if cut <= 1 || cut >= len(s.msgs) {
		return
	}
	var sum string
	if old := flatten(slimHistory(s.msgs[:cut], cfg.ToolResultChars)); len(old) > 0 {
		sum = a.compactSummary(ctx, old)
	}
	if sum == "" {
		// summarising keeps failing: forget the old part rather than pay for it forever,
		// but keep the earlier summary, it is the only thing that remembers the start of the talk
		sum = "(older part of this conversation was dropped; rely on the diary and on the messages below)"
		if isSummary(s.msgs[0]) {
			prev := strings.TrimSuffix(strings.TrimPrefix(s.msgs[0].Content, summaryOpen+"\n"), "\n"+summaryClose)
			sum = prev + "\n(" + "messages after this were dropped without a summary)"
		}
	}
	head := llm.Message{Role: "user", Content: summaryOpen + "\n" + sum + "\n" + summaryClose}
	s.msgs = append([]llm.Message{head}, s.msgs[cut:]...)
}
