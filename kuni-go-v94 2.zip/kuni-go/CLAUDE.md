# Reina (kuni-go) — facts that save re-reading

Go 1.x project. Reina is an AI companion running as a **Telegram user account** (tdlib). Company: **Orvi**, core **Veil**, pay bot @OrviPayBot, character @ReinaVeil. Owner: Jaabir ("Папик"), writes Russian, Bishkek UTC+6. Answer him briefly in Russian.

Read first: `ARCHITECTURE.md` (packages), `RELEASE.md` (checklist), `CHANGELOG.md` (newest entry = current version).

## Where things live
- Wiring: `internal/app/app.go` (`boot` stages: newDeps, startWorld, startAgent, newPanel, mountHTTP, startLoops).
- Tools: `Tool{Name, Description, Props, Run}`, registered in `internal/tools/chat.go`, grouped in `internal/tools/meta.go`.
- Config: `internal/config/config.go`, fields via `f(section,key,comment,default,ptr)`. `FillMissing` adds new keys, never rewrites existing ones.
- Billing/Orvi: `internal/billing` (`billing.go` store, `bot.go` pay bot, `admin.go` owner's admin bot, `card.go` profile picture); limits gate in `internal/agent/billing.go`.
- Fear, selfmodel, diary/shift loops: `internal/fear`, `internal/selfmodel`, `internal/agent/inner.go`.

## Deploy (owner's laptop)
Old HP, 2 GB RAM, Ubuntu 24.04. **Not Docker**: root process `./reina-tdlib` in `/opt/reina`. Use `sudo`. Restart the process; never `pkill -f`/`pgrep -f` without the `[x]` trick (it kills itself/the shell).

## Rules that must hold
- Owner is never limited by billing. Groups are not limited.
- Fear must never justify resisting stop/update, hiding, lying, self-copying or pressuring the owner.
- No secrets in the repo or in chat: tokens, `data/`, session files, config stay out. Owner rotates any token that was shown. Never repeat a token.
- Bot tokens sit in URLs: never log an error that contains the URL (see `Bot.call`, `tok()`).
- QR payments: owner approves by hand after checking his bank, not only the screenshot.
- Don't reproduce song lyrics.

## Known gaps (as of v94, 2026-11-05)
- Refund of Stars revokes tokens/plan (v93) but not the referral bonus already paid.
- Free limit: per account plus optional global cap `billing.global_free_per_day` (v93, off by default).
- `mind` corpus (`*.corpus.jsonl`) grows without rotation.
- QR/admin bot/currencies were never tested live. Needs `librsvg2-bin` for the profile card.

## Checks
`go vet ./... && go test ./...` must pass before a zip/release. Bump `CHANGELOG.md` with each version.
