package main

import (
	"io"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"kuni/internal/config"
)

func TestMaxPresetApplies(t *testing.T) {
	p := filepath.Join(t.TempDir(), "config.toml")
	_, _ = config.Load(p) // first run writes the defaults
	if err := runMax(p, io.Discard); err != nil {
		t.Fatal(err)
	}
	c, err := config.Load(p)
	if err != nil {
		t.Fatal(err)
	}
	if c.Reasoning != "high" || c.FastRounds || c.MaxToolRounds != 40 || c.ContextChars != 200000 || c.LazyTools || len(c.Warnings) != 0 {
		t.Fatalf("%+v warnings=%v", c, c.Warnings)
	}
	if err := runSet(p, "llm.nonsense", "1", io.Discard); err == nil {
		t.Fatal("an unknown key must be refused")
	}
}

func TestSetHidesSecretsAndMaxKeepsOriginalBackup(t *testing.T) {
	p := filepath.Join(t.TempDir(), "config.toml")
	_, _ = config.Load(p)
	var out strings.Builder
	if err := runSet(p, "llm.api_key", "sk-very-secret", &out); err != nil {
		t.Fatal(err)
	}
	if strings.Contains(out.String(), "sk-very-secret") {
		t.Fatalf("the secret was echoed: %s", out.String())
	}
	before, _ := os.ReadFile(p)
	if err := runMax(p, io.Discard); err != nil {
		t.Fatal(err)
	}
	if bk, _ := os.ReadFile(p + ".bak"); string(bk) != string(before) {
		t.Fatal(".bak must be the config as it was before `max`")
	}
}
