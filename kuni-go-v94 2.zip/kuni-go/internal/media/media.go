// Package media wraps the external services from the C++ project:
// Stable Diffusion WebUI, Whisper (STT), TTS (OpenAI-compatible / ElevenLabs),
// web search and ffmpeg. Each service is an interface so the agent and tools can
// be tested with fakes and so unconfigured services fail with a clear message.
package media

import (
	"bytes"
	"context"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"mime/multipart"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"
)

// ErrDisabled is returned by services turned off in config.toml.
var ErrDisabled = errors.New("this capability is disabled in config.toml")

type Transcriber interface {
	Transcribe(ctx context.Context, audio []byte, filename string) (string, error)
}

type Synthesizer interface {
	// Speak returns audio (OGG/Opus or MP3 bytes) and a file extension.
	Speak(ctx context.Context, text string) ([]byte, string, error)
}

type ImageGenerator interface {
	Generate(ctx context.Context, prompt, negative string) ([]byte, error)
}

type WebResult struct {
	Title   string `json:"title"`
	URL     string `json:"url"`
	Content string `json:"content"`
}

type Searcher interface {
	Search(ctx context.Context, query string, max int) ([]WebResult, error)
}

type VideoProcessor interface {
	// Frames returns up to n JPEG frames evenly spaced; Audio extracts the audio track as WAV.
	Frames(ctx context.Context, video []byte, n int) ([][]byte, error)
	Audio(ctx context.Context, video []byte) ([]byte, error)
}

// Disabled implements every service by returning ErrDisabled.
type Disabled struct{}

func (Disabled) Transcribe(context.Context, []byte, string) (string, error) { return "", ErrDisabled }
func (Disabled) Speak(context.Context, string) ([]byte, string, error)      { return nil, "", ErrDisabled }
func (Disabled) Generate(context.Context, string, string) ([]byte, error)   { return nil, ErrDisabled }
func (Disabled) Search(context.Context, string, int) ([]WebResult, error)   { return nil, ErrDisabled }
func (Disabled) Frames(context.Context, []byte, int) ([][]byte, error)      { return nil, ErrDisabled }
func (Disabled) Audio(context.Context, []byte) ([]byte, error)              { return nil, ErrDisabled }

var httpc = &http.Client{Timeout: 5 * time.Minute}

func doJSON(ctx context.Context, method, u string, headers map[string]string, in any, out any) ([]byte, error) {
	var body io.Reader
	if in != nil {
		raw, err := json.Marshal(in)
		if err != nil {
			return nil, err
		}
		body = bytes.NewReader(raw)
	}
	req, err := http.NewRequestWithContext(ctx, method, u, body)
	if err != nil {
		return nil, err
	}
	if in != nil {
		req.Header.Set("Content-Type", "application/json")
	}
	for k, v := range headers {
		if v != "" {
			req.Header.Set(k, v)
		}
	}
	resp, err := httpc.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	raw, err := io.ReadAll(io.LimitReader(resp.Body, 64<<20))
	if err != nil {
		return nil, err
	}
	if resp.StatusCode/100 != 2 {
		return nil, fmt.Errorf("%s: HTTP %d: %.300s", u, resp.StatusCode, raw)
	}
	if out != nil {
		if err := json.Unmarshal(raw, out); err != nil {
			return nil, fmt.Errorf("%s: bad JSON: %w", u, err)
		}
	}
	return raw, nil
}

// --- Stable Diffusion WebUI (AUTOMATIC1111 --api) ---

type StableDiffusion struct {
	BaseURL string
	// Reference is her picture (base64 PNG, see LoadReference): when set, photos are made from it (img2img) and
	// Strength says how far they may move away from it. Empty = the text alone (txt2img).
	Reference string
	Strength  float64
}

func (s StableDiffusion) Generate(ctx context.Context, prompt, negative string) ([]byte, error) {
	if s.Reference != "" {
		img, err := s.generateFromReference(ctx, prompt, negative)
		if err == nil {
			return img, nil
		}
		if ctx.Err() != nil {
			return nil, err
		}
		logRefFallback(err) // the text alone beats no photo at all
	}
	var out struct {
		Images []string `json:"images"`
	}
	_, err := doJSON(ctx, http.MethodPost, strings.TrimRight(s.BaseURL, "/")+"/sdapi/v1/txt2img", nil, map[string]any{
		"prompt": prompt, "negative_prompt": negative, "steps": 25, "width": 512, "height": 768, "cfg_scale": 7,
	}, &out)
	if err != nil {
		return nil, err
	}
	if len(out.Images) == 0 {
		return nil, errors.New("stable diffusion returned no images")
	}
	return base64.StdEncoding.DecodeString(out.Images[0])
}

// --- Whisper (OpenAI-compatible /audio/transcriptions) ---

type Whisper struct{ BaseURL, Model, Key string }

func (w Whisper) Transcribe(ctx context.Context, audio []byte, filename string) (string, error) {
	buf := &bytes.Buffer{}
	mw := multipart.NewWriter(buf)
	_ = mw.WriteField("model", w.Model)
	fw, err := mw.CreateFormFile("file", filename)
	if err != nil {
		return "", err
	}
	fw.Write(audio)
	mw.Close()
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, strings.TrimRight(w.BaseURL, "/")+"/audio/transcriptions", buf)
	if err != nil {
		return "", err
	}
	req.Header.Set("Content-Type", mw.FormDataContentType())
	if w.Key != "" {
		req.Header.Set("Authorization", "Bearer "+w.Key)
	}
	resp, err := httpc.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(io.LimitReader(resp.Body, 8<<20))
	if resp.StatusCode/100 != 2 {
		return "", fmt.Errorf("whisper: HTTP %d: %.200s", resp.StatusCode, raw)
	}
	var out struct {
		Text string `json:"text"`
	}
	if err := json.Unmarshal(raw, &out); err != nil {
		return "", err
	}
	return strings.TrimSpace(out.Text), nil
}

// --- TTS ---

// OpenAITTS speaks to /audio/speech (OpenAI, OmniVoice and compatible servers).
type OpenAITTS struct{ BaseURL, Key, Model, Voice string }

func (t OpenAITTS) Speak(ctx context.Context, text string) ([]byte, string, error) {
	if strings.TrimSpace(text) == "" {
		return nil, "", errors.New("tts: empty text")
	}
	ctx, cancel := context.WithTimeout(ctx, ttsTimeout)
	defer cancel()
	raw, err := doJSON(ctx, http.MethodPost, strings.TrimRight(t.BaseURL, "/")+"/audio/speech",
		map[string]string{"Authorization": bearer(t.Key)},
		map[string]any{"model": t.Model, "input": text, "voice": t.Voice, "response_format": "opus"}, nil)
	if err != nil {
		return nil, "", err
	}
	if len(raw) == 0 {
		return nil, "", errors.New("tts: backend returned empty audio")
	}
	return raw, "ogg", nil
}

// ttsTimeout bounds one speech request so a hung backend lets the caller fall back to text.
const ttsTimeout = 90 * time.Second

// ElevenLabs speaks via the ElevenLabs text-to-speech API.
type ElevenLabs struct{ BaseURL, Key, VoiceID, Model string }

func (e ElevenLabs) Speak(ctx context.Context, text string) ([]byte, string, error) {
	if strings.TrimSpace(text) == "" {
		return nil, "", errors.New("tts: empty text")
	}
	ctx, cancel := context.WithTimeout(ctx, ttsTimeout)
	defer cancel()
	base := e.BaseURL
	if base == "" {
		base = "https://api.elevenlabs.io/v1"
	}
	model := e.Model
	if model == "" || model == "tts-1" {
		model = "eleven_multilingual_v2"
	}
	raw, err := doJSON(ctx, http.MethodPost, strings.TrimRight(base, "/")+"/text-to-speech/"+url.PathEscape(e.VoiceID),
		map[string]string{"xi-api-key": e.Key},
		map[string]any{"text": text, "model_id": model}, nil)
	if err != nil {
		return nil, "", err
	}
	if len(raw) == 0 {
		return nil, "", errors.New("tts: backend returned empty audio")
	}
	return raw, "mp3", nil
}

// --- Web search ---

// WebSearch supports SearXNG-style GET (?q=&format=json) and the Ollama
// web_search POST API (used by the C++ version) when URL contains "ollama.com".
type WebSearch struct{ URL, Key string }

func (w WebSearch) Search(ctx context.Context, query string, max int) ([]WebResult, error) {
	if strings.Contains(w.URL, "ollama.com") {
		var out struct {
			Results []WebResult `json:"results"`
		}
		_, err := doJSON(ctx, http.MethodPost, w.URL, map[string]string{"Authorization": "Bearer " + w.Key},
			map[string]any{"query": query, "max_results": max}, &out)
		return out.Results, err
	}
	u := w.URL + "?format=json&q=" + url.QueryEscape(query)
	var out struct {
		Results []WebResult `json:"results"`
	}
	if _, err := doJSON(ctx, http.MethodGet, u, map[string]string{"Authorization": bearer(w.Key)}, nil, &out); err != nil {
		return nil, err
	}
	if max > 0 && len(out.Results) > max {
		out.Results = out.Results[:max]
	}
	return out.Results, nil
}

func bearer(k string) string {
	if k == "" {
		return ""
	}
	return "Bearer " + k
}

// --- ffmpeg ---

type FFmpeg struct{ Path string }

func (f FFmpeg) bin() string {
	if f.Path == "" {
		return "ffmpeg"
	}
	return f.Path
}

func (f FFmpeg) withTemp(video []byte, fn func(in, dir string) error) error {
	dir, err := os.MkdirTemp("", "kuni-video-")
	if err != nil {
		return err
	}
	defer os.RemoveAll(dir)
	in := filepath.Join(dir, "in.mp4")
	if err := os.WriteFile(in, video, 0o600); err != nil {
		return err
	}
	return fn(in, dir)
}

func (f FFmpeg) Audio(ctx context.Context, video []byte) ([]byte, error) {
	var out []byte
	err := f.withTemp(video, func(in, dir string) error {
		dst := filepath.Join(dir, "a.wav")
		if b, err := exec.CommandContext(ctx, f.bin(), "-y", "-i", in, "-vn", "-ac", "1", "-ar", "16000", "-t", "1200", dst).CombinedOutput(); err != nil {
			return fmt.Errorf("ffmpeg: %w: %.300s", err, b)
		}
		var err error
		out, err = os.ReadFile(dst)
		return err
	})
	return out, err
}

func (f FFmpeg) Frames(ctx context.Context, video []byte, n int) ([][]byte, error) {
	if n < 1 {
		n = 4
	}
	var frames [][]byte
	err := f.withTemp(video, func(in, dir string) error {
		// fps=n/duration is unknown without ffprobe; sample one frame every 2s and keep n evenly.
		pattern := filepath.Join(dir, "f%03d.jpg")
		if b, err := exec.CommandContext(ctx, f.bin(), "-y", "-i", in, "-vf", "fps=1/2,scale=672:-1", "-frames:v", "64", pattern).CombinedOutput(); err != nil {
			return fmt.Errorf("ffmpeg: %w: %.300s", err, b)
		}
		files, _ := filepath.Glob(filepath.Join(dir, "f*.jpg"))
		if len(files) == 0 {
			return errors.New("ffmpeg produced no frames")
		}
		step := float64(len(files)) / float64(n)
		for i := 0; i < n && int(float64(i)*step) < len(files); i++ {
			b, err := os.ReadFile(files[int(float64(i)*step)])
			if err != nil {
				return err
			}
			frames = append(frames, b)
		}
		return nil
	})
	return frames, err
}

// Services bundles all media backends; unconfigured ones are Disabled{}.
type Services struct {
	STT    Transcriber
	TTS    Synthesizer
	Images ImageGenerator
	Web    Searcher
	Video  VideoProcessor
}

func NewDisabled() Services {
	d := Disabled{}
	return Services{STT: d, TTS: d, Images: d, Web: d, Video: d}
}
