package agent

import (
	"testing"

	"kuni/internal/telegram"
)

func TestUrgent(t *testing.T) {
	for _, c := range []struct {
		text string
		want bool
	}{
		{"мне плохо", true},
		{"Мне очень плохо, не знаю что делать", true},
		{"помоги пожалуйста срочно", true},
		{"я не хочу жить", true},
		{"не хочу жить ахах", true}, // a strong alarm is never a joke
		{"у меня паническая атака", true},
		{"мама в больнице", true},
		{"умерла бабушка", true},
		{"я умерла от смеха", false},
		{"я умерла ахахах", false},
		{"сдохла пхпх", false},
		{"мне плохо ахахах", false},
		{"ору, помогите", false},
		{"привет как дела", false},
		{"ну все я умерла", false},
		{"скинь кору дерева", false},
		{"", false},
	} {
		if got := urgent(c.text); got != c.want {
			t.Errorf("urgent(%q) = %v, want %v", c.text, got, c.want)
		}
	}
}

func TestAnyUrgentLooksOnlyAtTheirMessages(t *testing.T) {
	if anyUrgent([]telegram.Message{{Text: "мне плохо", Outgoing: true}, {Text: "ок"}}) {
		t.Fatal("her own message is not their alarm")
	}
	if !anyUrgent([]telegram.Message{{Text: "ок"}, {Text: "мне страшно"}}) {
		t.Fatal("missed")
	}
}
