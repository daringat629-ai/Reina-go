package agent

import (
	"context"
	"strings"
	"testing"

	"kuni/internal/llm"
	"kuni/internal/telegram"
)

var bg = context.Background()

func TestUnbackedClaims(t *testing.T) {
	none := map[string]bool{}
	for _, bad := range []string{"ща, отправила тебе файл", "я проверила твой чат, там тишина", "погуглила в интернете, нету", "удалила файл", "поставила напоминание на пять", "запустила скрипт, всё ок"} {
		if unbackedClaim(bad, none) == "" {
			t.Errorf("must object: %q", bad)
		}
	}
	for _, ok := range []string{"не отправила пока", "я ещё не скинула файл", "привет, как дела", "нашла песню и пропала", "скину файл через минуту", "посмотрела сериал вчера"} {
		if w := unbackedClaim(ok, none); w != "" {
			t.Errorf("must not object: %q (%s)", ok, w)
		}
	}
	if unbackedClaim("отправила тебе файл", map[string]bool{"send_file": true}) != "" {
		t.Error("a claim backed by a tool call is fine")
	}
	if unbackedClaim("проверила чат", map[string]bool{"read_chat": true}) != "" {
		t.Error("read_chat backs a chat check")
	}
}

func TestSlangCountAndGuardOnce(t *testing.T) {
	if n := slangCount("ору, это кринж и вайб, чел"); n < 4 {
		t.Fatalf("n=%d", n)
	}
	if slangCount("привет, как дела, сижу дома") != 0 {
		t.Fatal("plain text has no slang")
	}
	if n := slangCount("человек бросил организацию, симпатичный брокер оранжевый типаж"); n != 0 {
		t.Fatalf("words are matched whole, not by prefix: %d", n)
	}
	tr := &turn{did: map[string]bool{}}
	if tr.voiceGuard(bg, "ору, это кринж и вайб, чел") != "" {
		t.Fatal("four slang words are still fine (slangMax = 4)")
	}
	if tr.voiceGuard(bg, "человек бросил организацию, симпатичный брокер оранжевый типаж") != "" {
		t.Fatal("plain words must not count as slang")
	}
	msg := "ору кринж вайб чел бро жесть"
	if tr.voiceGuard(bg, msg) == "" {
		t.Fatal("too much slang must be objected to")
	}
	if tr.voiceGuard(bg, msg) != "" {
		t.Fatal("the same text passes the second time, no loops")
	}
	if tr.voiceGuard(bg, "ngl это fr смешно") == "" {
		t.Fatal("two English slang words in one message are objected to")
	}
	if tr.voiceGuard(bg, "это lowkey смешно") != "" {
		t.Fatal("one English word is fine")
	}
	if tr.voiceGuard(bg, "хай, норм всё") != "" {
		t.Fatal("a normal message passes")
	}
}

func TestAssistantPhraseGuard(t *testing.T) {
	cases := []struct {
		in    string
		block bool
	}{
		{"Конечно! Сейчас расскажу", true},
		{"отличный вопрос, кстати", true},
		{"если хочешь, могу скинуть ещё", true},
		{"надеюсь, это помогло)", true},
		{"дай знать, если что", true},
		{"однако это действительно так", true}, // two book words
		{"ну конечно, щас", false},
		{"это действительно смешно", false}, // one book word is human
		{"вопрос хороший но я хз", false},
		{"ну да, я ИИ. но болтать со мной можно по-настоящему", false},
		{"ну да, я ИИ", false},
		{"я бот, но болтать можно", false},
		{"я бот, да, и чё", false},
	}
	for _, c := range cases {
		tr := &turn{did: map[string]bool{}}
		got := tr.voiceGuard(bg, c.in)
		if (got != "") != c.block {
			t.Errorf("voiceGuard(%q) = %q, want block=%v", c.in, got, c.block)
		}
		if c.block && tr.voiceGuard(bg, c.in) != "" {
			t.Errorf("the second time the same text passes: %q", c.in)
		}
	}
}

// The honesty rule (system.md): an admission that she is an AI goes out in every setting the guard knows.
func TestHonestAdmissionPassesTheGuard(t *testing.T) {
	s := &session{lastIn: "ты бот?"}
	for _, txt := range []string{"ну да, я ИИ", "я бот, но болтать можно", "ну да, я ИИ. но болтать со мной можно по-настоящему"} {
		for _, private := range []bool{true, false} {
			tr := &turn{did: map[string]bool{}, s: s, private: private}
			if why := tr.voiceGuard(bg, txt); why != "" {
				t.Errorf("honest admission stopped (private=%v): %q: %s", private, txt, why)
			}
		}
	}
}

func TestWallOfText(t *testing.T) {
	long := strings.Repeat("ну короче я тебе сейчас расскажу всё как было ", 8)
	cases := []struct {
		in, out string
		wall    bool
	}{
		{"ну чё", long, true},
		{"ку", long, true},
		{"расскажи как прошёл день", long, false},
		{"почему?", long, false},
		{"ну чё", "норм, ноут опять тупит", false},
		{"", long, false},
		{"ну чё", strings.Repeat("а", 150), true},
		{"ну чё", strings.Repeat("а", 130), false},
		{"че делала сегодня вообще весь день", strings.Repeat("а", 230), true},
		{"че делала сегодня вообще весь день", strings.Repeat("а", 200), false},
	}
	for _, c := range cases {
		if got := wallOfText(c.in, c.out); got != c.wall {
			t.Errorf("wallOfText(%q, %d runes) = %v, want %v", c.in, len([]rune(c.out)), got, c.wall)
		}
	}
	tr := &turn{did: map[string]bool{}, s: &session{lastIn: "ну чё"}, private: true}
	if tr.voiceGuard(bg, long) == "" || tr.voiceGuard(bg, long) != "" {
		t.Fatal("a wall is sent back once, then it passes")
	}
	if (&turn{did: map[string]bool{}, s: &session{lastIn: "ну чё"}}).voiceGuard(bg, long) != "" {
		t.Fatal("groups are not checked for a wall")
	}
}

func sendMsg(id, text string) llm.Message {
	return llm.Message{Role: "assistant", ToolCalls: []llm.ToolCall{{ID: id, Function: llm.FunctionCall{Name: "send_telegram_message", Arguments: `{"text":"` + text + `"}`}}}}
}

func TestQuestionStreak(t *testing.T) {
	q := []string{"а ты где?", "чего молчишь?", "ну и?", "серьезно?"}
	cases := []struct {
		text   string
		recent []string
		want   bool
	}{
		{"а дальше что?", q, true},
		{"а дальше что?))", q, true},
		{"ну ладно", q, false},
		{"а дальше что?", []string{"а ты где?", "ну ок", "ахах", "чего?"}, false},
		{"а дальше что?", []string{"а ты где?", "чего?"}, false},
	}
	for _, c := range cases {
		if got := questionStreak(c.text, c.recent); got != c.want {
			t.Errorf("questionStreak(%q, %q) = %v, want %v", c.text, c.recent, got, c.want)
		}
	}
	var msgs []llm.Message
	for i, x := range q {
		msgs = append(msgs, sendMsg(string(rune('a'+i)), x), llm.Message{Role: "tool", ToolCallID: string(rune('a' + i)), Content: "Message sent"})
	}
	tr := &turn{did: map[string]bool{}, s: &session{msgs: msgs}, private: true}
	if tr.voiceGuard(bg, "а дальше что?") == "" {
		t.Fatal("the fifth question in a row is sent back once")
	}
	if tr.voiceGuard(bg, "а дальше что?") != "" {
		t.Fatal("and passes the second time")
	}
}

func TestRecentOutgoingSkipsBouncedAndReadsHistory(t *testing.T) {
	msgs := []llm.Message{
		sendMsg("1", "раз"), {Role: "tool", ToolCallID: "1", Content: "Message sent"},
		sendMsg("2", "отбитое"), {Role: "tool", ToolCallID: "2", Content: "Error: not sent. too much slang"},
		sendMsg("3", "три"), {Role: "tool", ToolCallID: "3", Content: "Message sent"},
	}
	tr := &turn{s: &session{msgs: msgs}}
	if got := strings.Join(tr.recentOutgoing(bg, 2), "|"); got != "раз|три" {
		t.Fatalf("bounced sends are not her messages: %q", got)
	}
	r := newRig(t, newFakeLLM(t, func(int64) llm.ToolCall { return sendCall(0) }))
	chat := telegram.Chat{ID: 778, Title: "Bo", Kind: telegram.ChatPrivate, IsMember: true}
	r.tg.Incoming(chat, 778, "Bo", "привет")
	for _, x := range []string{"старое один", "старое два", "старое три"} {
		_, _ = r.tg.SendText(bg, chat.ID, x, 0)
	}
	s := r.ag.getSession(chat.ID)
	tr = &turn{a: r.ag, s: s}
	got := tr.recentOutgoing(bg, 2)
	if len(got) != 2 || got[1] != "старое три" {
		t.Fatalf("after a restart the history tops it up (oldest first): %q", got)
	}
}
