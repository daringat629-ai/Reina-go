package agent

import (
	"context"
	"fmt"
	"log"
	"strings"
	"time"

	"kuni/internal/billing"
	"kuni/internal/config"
	"kuni/internal/prompts"
	"kuni/internal/telegram"
)

// billingAllows counts one conversation for a person in a private chat and says whether she may answer. The owner, groups and a
// switched-off billing are never limited. When the limit is over, the person is told once a day (a fixed text, no paid model call)
// where to get more, and the messages are marked read.
func (a *Agent) billingAllows(ctx context.Context, chat telegram.Chat) bool {
	cfg := a.cfg()
	if !cfg.BillingEnabled || a.Deps.Billing == nil || chat.Kind != telegram.ChatPrivate || cfg.IsOwner(chat.ID) {
		return true
	}
	d := a.Deps.Billing.Take(chat.ID, time.Now(), limitsOf(cfg))
	if d.OK {
		return true
	}
	if d.TellOnce {
		msg := "Бесплатные разговоры на сегодня закончились, а токенов на балансе нет. Завтра бесплатные обновятся."
		if cfg.BillingBotName != "" {
			msg += fmt.Sprintf(" Если хочешь говорить больше, пополнить баланс можно тут: @%s", cfg.BillingBotName)
		}
		if _, err := a.TG.SendText(ctx, chat.ID, msg, 0); err != nil {
			log.Printf("agent: billing: %v", err)
		}
	}
	_ = a.TG.MarkRead(ctx, chat.ID)
	a.Metrics.Inc("kuni_billing_limited_total", 1, map[string]string{"plan": d.Plan})
	return false
}

func limitsOf(cfg *config.Config) billing.Limits {
	return billing.Limits{Free: int(cfg.BillingFreePerDay), Plus: int(cfg.BillingPlusPerDay), Max: int(cfg.BillingMaxPerDay), FreeTokens: cfg.BillingFreeTokens, GlobalFree: int(cfg.BillingGlobalFree)}
}

// planNames are the old day plans as people saw them in the payment bot.
var planNames = map[string]string{billing.Free: "Старт (бесплатный)", billing.Plus: "Plus", billing.Max: "Max"}

// accountBlock tells her this person's balance and how much is left today, so she can answer "how many messages do I have left" or
// "did my payment go through" from the real account instead of guessing. Only in a private chat with someone other than the owner,
// and only when billing is on.
func (a *Agent) accountBlock(chat telegram.Chat, now time.Time) string {
	cfg := a.cfg()
	if !cfg.BillingEnabled || a.Deps.Billing == nil || chat.Kind != telegram.ChatPrivate || cfg.IsOwner(chat.ID) {
		return ""
	}
	acc := a.Deps.Billing.Account(chat.ID, now, limitsOf(cfg), cfg.BillingEstTokens)
	loc := cfg.Location()
	var b strings.Builder
	b.WriteString("\n<account>\n")
	if acc.Limit > 0 {
		kind := "free conversations"
		if acc.Plan != billing.Free {
			kind = "conversations on their old " + planNames[acc.Plan] + " plan"
		}
		fmt.Fprintf(&b, "today: %d of %d %s used, %d left; they reset at midnight (%s)\n", acc.Used, acc.Limit, kind, acc.Left, loc)
	} else {
		fmt.Fprintf(&b, "today: %d conversations, no daily cap\n", acc.Used)
	}
	if !acc.Until.IsZero() {
		left := acc.Until.Sub(now)
		days := int(left.Hours() / 24)
		fmt.Fprintf(&b, "old %s plan paid until %s (%d days %d hours left); it is no longer sold\n", planNames[acc.Plan], acc.Until.In(loc).Format("02.01.2006 15:04"), days, int(left.Hours())-days*24)
	}
	per := max(acc.PerConv, 1)
	fmt.Fprintf(&b, "token balance: %d tokens, about %d more conversations beyond the free ones (one conversation costs about %d tokens); tokens never expire\n", max(acc.Tokens, 0), max(acc.Tokens, 0)/per, per)
	if acc.FromBalance {
		b.WriteString("this conversation is paid from their balance\n")
	}
	if acc.PaidToday > 0 {
		fmt.Fprintf(&b, "conversations paid from the balance today: %d\n", acc.PaidToday)
	}
	if acc.Spent > 0 {
		fmt.Fprintf(&b, "tokens spent from the balance in all time: %d\n", acc.Spent)
	}
	if acc.Paid > 0 {
		fmt.Fprintf(&b, "purchases so far: %d\n", acc.Paid)
	}
	if acc.Invited > 0 {
		fmt.Fprintf(&b, "people they invited: %d\n", acc.Invited)
	}
	currency := cfg.BillingCurrency
	if currency == "" {
		currency = "RUB"
	}
	if r := acc.Pending; r != nil {
		state := "waiting for their receipt"
		if r.Status == "sent" {
			state = "receipt sent, the team is checking it"
		}
		what := fmt.Sprintf("%d tokens", r.Tokens)
		if r.Tokens == 0 {
			what = fmt.Sprintf("%s for %d days", planNames[r.Plan], r.Days)
		}
		fmt.Fprintf(&b, "QR payment in progress: %s, %d %s, %s\n", what, r.Som, currency, state)
	}
	b.WriteString("</account>\n")
	bot := "the payment bot"
	if cfg.BillingBotName != "" {
		bot = "@" + cfg.BillingBotName
	}
	if t := a.Prompts.Text(prompts.AccountRules, map[string]string{"BOT": bot}); t != "" {
		b.WriteString(t + "\n")
	}
	return b.String()
}
