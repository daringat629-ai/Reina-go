package agent

import (
	"strings"
	"unicode"

	"kuni/internal/telegram"
)

// Someone who is really not okay is never kept waiting by the "living" rhythm: no read pause, no late reply, no
// sleep, no "read, answered later". urgent is deliberately simple and errs on the side of answering: a false alarm
// only costs a quick reply. Laughter ("я умерла от смеха", "сдохла ахах") is not an alarm.

// strongMarks are alarms whatever the tone around them.
var strongMarks = []string{
	"хочу умереть", "не хочу жить", "не хочется жить", "покончить с собой", "покончу с собой", "суицид", "самоуби",
	"вскрыть вены", "вскрою вены", "режу себя", "порезала себя", "порезал себя", "наглоталась", "наглотался",
	"выпила таблетки", "выпил таблетки", "не могу дышать", "задыхаюсь", "паническая атака", "панич атака", "паничка",
	"вызови скорую", "вызовите скорую", "в реанимации", "меня бьют", "меня избили", "он меня бьет", "меня изнасиловал",
	"мне угрожают", "kill myself", "want to die", "suicide",
}

// softMarks are alarms unless the message laughs ("мне плохо ахахах" is a joke).
var softMarks = []string{
	"мне плохо", "мне очень плохо", "помоги", "помогите", "срочно", "sos", "мне страшно", "мне очень страшно",
	"я плачу", "плачу весь", "реву", "умер папа", "умерла мама", "умер мой", "умерла моя", "умерла бабушка", "умер дедушка",
	"умерла подруга", "умер друг", "в больнице", "попал в аварию", "попала в аварию", "авария", "не знаю что делать",
	"мне одиноко", "депресс", "я в беде", "help me",
}

// laughing reads a laugh or a joke in the text: a laughing word ("ахах", "ору", "лол") or "от смеха", "))", 😂.
func laughing(t string) bool {
	for _, m := range []string{"от смеха", "со смеху", "))", "😂", "🤣", "шучу", "прикол"} {
		if strings.Contains(t, m) {
			return true
		}
	}
	for _, w := range strings.FieldsFunc(t, func(r rune) bool { return !unicode.IsLetter(r) }) {
		switch w {
		case "ору", "ржу", "лол", "lol", "кек", "хд", "xd", "lmao":
			return true
		}
		for _, p := range []string{"ахах", "хаха", "ахпх", "пхпх", "ахв", "ахаз"} {
			if strings.HasPrefix(w, p) {
				return true
			}
		}
	}
	return false
}

// urgent tells whether the text sounds like the person is really not okay.
func urgent(text string) bool {
	t := strings.ToLower(strings.ReplaceAll(text, "ё", "е"))
	if strings.TrimSpace(t) == "" {
		return false
	}
	for _, m := range strongMarks {
		if strings.Contains(t, m) {
			return true
		}
	}
	if laughing(t) {
		return false
	}
	for _, m := range softMarks {
		if strings.Contains(t, m) {
			return true
		}
	}
	return false
}

// anyUrgent looks at what the person wrote (not her own messages).
func anyUrgent(msgs []telegram.Message) bool {
	for _, m := range msgs {
		if !m.Outgoing && urgent(m.Text) {
			return true
		}
	}
	return false
}
