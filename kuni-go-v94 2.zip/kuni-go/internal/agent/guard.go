package agent

import (
	"context"
	"encoding/json"
	"fmt"
	"regexp"
	"strings"
	"time"
	"unicode"

	"kuni/internal/llm"
	"kuni/internal/telegram"
	"kuni/internal/toneeval"
)

// The voice guard stops what gives an AI away before a message leaves: saying that she did something no tool did,
// assistant phrases and book words, a pile of slang (Russian or English), a wall of text in answer to two words and a
// question at the end of every message. Each is answered once with an explanation and let through on the repeat, so
// it can never trap her in a loop. An honest «я ИИ» is never stopped (system.md; see the tells table in toneeval).

type claim struct {
	re    *regexp.Regexp
	what  string
	tools []string // any of these succeeding in this turn backs the claim
}

const lb = `(?:^|[^\p{L}])` // Go's \b knows no Cyrillic

func cl(pat, what string, tools ...string) claim {
	return claim{re: regexp.MustCompile(`(?i)` + lb + pat), what: what, tools: tools}
}

var claims = []claim{
	cl(`(?:отправил|скинул|выслал|переслал)[аи]?\s+(?:тебе\s+|ему\s+|ей\s+|им\s+|вам\s+)?(?:файл|фот|картинк|ссылк|документ|видео|аудио|гс|голосов|таблиц|скрипт|архив)`, "sent a file or media",
		"send_file", "share_file", "send_to_chat", "forward_message", "record_audio", "take_photo", "make_document", "make_table", "make_chart", "qr_code", "image", "tg_api", "send_telegram_message_file"),
	cl(`(?:проверил|глянул|посмотрел|прочитал|открыл)[аи]?\s+(?:твой\s+|свой\s+|наш\s+|этот\s+|весь\s+)?(?:чат|список|лог|настройк|сервер|ноут|профиль|канал|диск|переписк)`, "looked at a chat, log or setting",
		"read_chat", "list_all_chats", "get_telegram_chats", "my_chats", "my_laptop", "my_profile_view", "my_settings_view", "tail_log", "sysinfo", "shell", "open_chat", "view_messages_around", "my_profile", "user_info", "search_chats", "settings", "telegram_ui", "digest", "search_messages", "read_file"),
	cl(`(?:погуглил|загуглил|поискал|искал|нашл|нашёл)[аи]?\s+(?:в\s+(?:интернет|инет|гугл|сети)|в\s+google)`, "searched the internet",
		"web_search", "read_link", "browser", "lookup", "http_request"),
	cl(`(?:удалил|стёр|стерл)[аи]?\s+(?:этот\s+|твой\s+|тот\s+)?(?:файл|сообщени|чат|папк)`, "deleted something",
		"files", "shell", "tg_api", "delete_message", "telegram_ui"),
	cl(`поставил[аи]?\s+(?:тебе\s+|себе\s+)?(?:напоминани|таймер|будильник)`, "set a reminder",
		"remind", "schedule", "send_later", "monitor", "reminders"),
	cl(`(?:запустил|перезапустил|установил|скачал|обновил)[аи]?\s+(?:этот\s+|твой\s+|тот\s+)?(?:скрипт|код|программ|бот|сервис|пакет|обновлени|файл|видео|музык)`, "ran or installed something",
		"run_code", "shell", "shell_bg", "service", "self_update", "download_telegram_file", "media_dl", "http_request", "vibe_code", "files", "docker"),
}

var reNeg = regexp.MustCompile(`(?i)(?:^|[^\p{L}])(?:не|ещё не|еще не|пока не|так и не|почти)\s*$`)

// unbackedClaim returns what she says she did when no tool of this turn did it ("" = nothing to object to).
func unbackedClaim(text string, did map[string]bool) string {
	for _, c := range claims {
		for _, loc := range c.re.FindAllStringIndex(text, -1) {
			if reNeg.MatchString(text[:min(loc[0]+1, len(text))]) {
				continue
			}
			backed := false
			for _, t := range c.tools {
				if did[t] {
					backed = true
					break
				}
			}
			if !backed {
				return c.what
			}
		}
	}
	return ""
}

// slangMax is the most trendy slang words one message may hold (every occurrence counts, mat does not): two or
// three is how she talks, a pile of them sounds forced. latinMax is the most English slang words («fr», «ngl»): a
// Russian girl drops one at most, more reads like a translation. Words are matched whole (toneeval.Slang), so
// «человек» or «организация» are never slang.
const (
	slangMax = 4
	latinMax = 1
)

// slangCount is how many trendy slang words a message holds.
func slangCount(text string) int {
	w, _ := toneeval.Slang(text)
	return len(w)
}

// assistantPhrase returns the first canonical assistant phrase of the text («конечно!», «отличный вопрос», «если
// хочешь, могу»...), or "" when there is none. The table lives in toneeval and never holds an honest «я ИИ».
func assistantPhrase(text string) string {
	if f := toneeval.FindTells(text, toneeval.Block); len(f) > 0 {
		return f[0]
	}
	return ""
}

// bookWords returns the book words of the text when there are two or more («однако», «действительно»...): one is
// human, a pair in one chat message is how a model writes.
func bookWords(text string) []string {
	if f := toneeval.FindTells(text, toneeval.Count); len(f) >= 2 {
		return f
	}
	return nil
}

// recentOutgoing returns up to n of her last messages in this chat (oldest first) that really went out: what she
// sent in this session (bounced sends are skipped), topped up from the chat history after a restart.
func (t *turn) recentOutgoing(ctx context.Context, n int) []string {
	if t.s == nil || n <= 0 {
		return nil
	}
	out := sentOK(t.s.msgs)
	if len(out) < n && t.a != nil && t.a.TG != nil && t.s.id != 0 {
		if hist, err := t.a.TG.History(ctx, t.s.id, 0, 3*n, 0); err == nil {
			var old []string
			for _, m := range hist { // oldest first, like repeatError reads it
				if m.Outgoing && strings.TrimSpace(m.Text) != "" {
					old = append(old, strings.TrimSpace(m.Text))
				}
			}
			if len(old) > len(out) { // the history already holds what the session sent
				out = old
			}
		}
	}
	if len(out) > n {
		out = out[len(out)-n:]
	}
	return out
}

// sentOK is like sentTexts but leaves out the sends that failed (the guard sent them back, or Telegram refused).
func sentOK(msgs []llm.Message) []string {
	failed := map[string]bool{}
	for _, m := range msgs {
		if m.Role == "tool" && strings.HasPrefix(strings.TrimSpace(m.Content), "Error") {
			failed[m.ToolCallID] = true
		}
	}
	var out []string
	for _, m := range msgs {
		if m.Role != "assistant" {
			continue
		}
		for _, c := range m.ToolCalls {
			if c.Function.Name != "send_telegram_message" || failed[c.ID] {
				continue
			}
			if txt := strings.TrimSpace(guardText(c.Function.Arguments)); txt != "" {
				out = append(out, txt)
			}
		}
	}
	return out
}

// endsWithQuestion: the message ends with «?» (closing brackets and spaces aside).
func endsWithQuestion(s string) bool {
	return strings.HasSuffix(strings.TrimRightFunc(s, func(r rune) bool { return unicode.IsSpace(r) || r == ')' || r == '(' }), "?")
}

// questionStreak: this message ends with a question and so did at least three of her last four.
func questionStreak(text string, recent []string) bool {
	if !endsWithQuestion(text) || len(recent) < 3 {
		return false
	}
	if len(recent) > 4 {
		recent = recent[len(recent)-4:]
	}
	n := 0
	for _, r := range recent {
		if endsWithQuestion(r) {
			n++
		}
	}
	return n >= 3
}

var askMore = regexp.MustCompile(`(?i)` + lb + `(расскажи|объясни|почему|зачем|как\s|что\s+такое|подробн|помоги)`)

// wallOfText: an answer much longer than what she answers. A person writes about as much as she got, a bit more at
// most: «ну чё» gets a line, a short question two lines, only a real story or a "расскажи/объясни" gets a pile.
// The usual shaping is done by the rhythm code (bubble caps), this is the backstop.
func wallOfText(lastIn, text string) bool {
	in := strings.TrimSpace(lastIn)
	n := len([]rune(in))
	if n == 0 || askMore.MatchString(in) {
		return false
	}
	return len([]rune(strings.TrimSpace(text))) > wallLimit(n)
}

// wallLimit is the most runes an answer to an incoming message of n runes may have before it reads as a wall.
func wallLimit(n int) int {
	switch {
	case n <= 20:
		return 140
	case n <= 60:
		return 220
	case n <= 150:
		return 330
	}
	return 520
}

// voiceGuard checks one outgoing message (the whole answer, before it is cut into bubbles); every objection is
// made once: the second time the same text comes it passes, so it can never trap her in a loop.
func (t *turn) voiceGuard(ctx context.Context, text string) string {
	if t.guarded == nil {
		t.guarded = map[string]bool{}
	}
	if t.guarded[text] || strings.TrimSpace(text) == "" {
		return ""
	}
	why := ""
	if what := unbackedClaim(text, t.did); what != "" {
		why = fmt.Sprintf("Error: not sent. The message says you %s, but no tool call in this turn did that. Never claim an action you did not do. Either do it now with the right tool and then say so, or write the message again honestly (say you have not done it, or that you will).", what)
	} else if p := assistantPhrase(text); p != "" {
		why = fmt.Sprintf("Error: not sent. «%s» sounds like an assistant, not a 20-year-old girl texting. Say the same thing the way you would to a friend, or drop that part.", p)
	} else if bw := bookWords(text); bw != nil {
		why = fmt.Sprintf("Error: not sent. Book words («%s») in one chat message: that is how a model writes. Say it in plain spoken words.", strings.Join(bw, "», «"))
	} else if n := slangCount(text); n > slangMax {
		why = fmt.Sprintf("Error: not sent. Too much slang (%d slang words in one message): it sounds forced. Rewrite it with fewer, a real person does not stack that many in one message.", n)
	} else if _, l := toneeval.Slang(text); l > latinMax {
		why = fmt.Sprintf("Error: not sent. %d English slang words in one message: from a Russian girl it reads like a translation. Keep one at most, or say it in Russian.", l)
	} else if t.private && !t.worked && t.s != nil && !strings.Contains(text, "```") && wallOfText(t.s.lastIn, text) { // a report after real work or code may be long
		why = "Error: not sent. This is much longer than what they wrote: a wall of text. Cut it to the main thing, one or two short lines like in a chat (about as much as they wrote, a bit more); say more only if they ask."
	} else if t.private && questionStreak(text, t.recentOutgoing(ctx, 4)) {
		why = "Error: not sent. Almost every message of yours ends with a question. End this one with a statement, a joke or a jab instead, or just react."
	}
	if why != "" {
		t.guarded[text] = true
		if t.a != nil && t.a.Metrics != nil {
			t.a.Metrics.Inc("kuni_guard_bounce_total", 1, map[string]string{"reason": bounceReason(why)})
		}
	}
	return why
}

// bounceReason is a short label of an objection for the metrics (so the panel shows which rule the prompt leans on).
func bounceReason(why string) string {
	for _, r := range []struct{ key, label string }{{"no tool call", "claim"}, {"assistant", "assistant"}, {"Book words", "book"},
		{"Too much slang", "slang"}, {"English slang", "latin"}, {"wall of text", "wall"}, {"ends with a question", "questions"}} {
		if strings.Contains(why, r.key) {
			return r.label
		}
	}
	return "other"
}

// guardText pulls the text out of a send_telegram_message call.
func guardText(args string) string {
	var v struct {
		Text string `json:"text"`
	}
	_ = json.Unmarshal([]byte(args), &v)
	return v.Text
}

// newArrivals stops an answer in a private chat when the person wrote more while she was thinking: she has to read
// those messages together with the earlier ones and answer everything at once, not reply to a stale half of the talk.
// Every new message is reported once (it is marked read and remembered), so it can never loop.
func (t *turn) newArrivals(ctx context.Context) string {
	s := t.s
	if !t.private || s.id == 0 || s.readIDs == nil {
		return ""
	}
	unread, err := t.a.readable(ctx, s.id)
	if err != nil {
		return ""
	}
	var fresh []telegram.Message
	for _, m := range unread {
		if !m.Outgoing && !s.readIDs[m.ID] {
			fresh = append(fresh, m)
		}
	}
	if len(fresh) == 0 {
		return ""
	}
	for _, m := range fresh {
		s.readIDs[m.ID] = true
	}
	_ = t.a.TG.MarkRead(ctx, s.id)
	return fmt.Sprintf("Error: not sent. %d more message(s) arrived while you were thinking. Read them together with the earlier ones (go through every message in order), then answer everything at once:\n%s",
		len(fresh), t.a.UI.FormatMessages(ctx, fresh, time.Now()))
}
