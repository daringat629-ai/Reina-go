package app

import (
	"context"
	"runtime"
	"time"

	"kuni/internal/config"
	"kuni/internal/maint"
	"kuni/internal/metrics"
	"kuni/internal/run"
)

// processMetrics refreshes the metrics about the program itself: how long it has been up, memory, goroutines, the
// loops that are running, the free space under data/ and how many warnings the config has. They answer "is she
// healthy" without opening the panel (alert on kuni_data_disk_free_bytes or kuni_config_warnings > 0).
func processMetrics(reg *metrics.Registry, sup *run.Supervisor, cfg *config.Config, started time.Time) {
	var m runtime.MemStats
	runtime.ReadMemStats(&m)
	reg.Set("kuni_process_start_time_seconds", float64(started.Unix()), nil)
	reg.Set("kuni_uptime_seconds", time.Since(started).Seconds(), nil)
	reg.Set("kuni_goroutines", float64(runtime.NumGoroutine()), nil)
	reg.Set("kuni_heap_bytes", float64(m.HeapAlloc), nil)
	reg.Set("kuni_loops_running", float64(len(sup.Running())), nil)
	reg.Set("kuni_config_warnings", float64(len(cfg.Warnings)), nil)
	if disk, err := maint.DiskOf(cfg.DataDir); err == nil {
		reg.Set("kuni_data_disk_free_bytes", float64(disk.Free), nil)
		reg.Set("kuni_data_disk_total_bytes", float64(disk.Total), nil)
	}
}

func processMetricsLoop(ctx context.Context, reg *metrics.Registry, sup *run.Supervisor, cfg func() *config.Config, started time.Time) {
	if started.IsZero() {
		started = time.Now()
	}
	for {
		processMetrics(reg, sup, cfg(), started)
		select {
		case <-ctx.Done():
			return
		case <-time.After(30 * time.Second):
		}
	}
}

func init() {
	helpTexts["kuni_process_start_time_seconds"] = "Unix time when the program started"
	helpTexts["kuni_uptime_seconds"] = "Seconds since the program started"
	helpTexts["kuni_goroutines"] = "Goroutines in the process"
	helpTexts["kuni_heap_bytes"] = "Heap in use, bytes"
	helpTexts["kuni_loops_running"] = "Supervised background loops that are running"
	helpTexts["kuni_config_warnings"] = "Warnings about config.toml (typos, values out of range); 0 is clean"
	helpTexts["kuni_data_disk_free_bytes"] = "Free space on the disk that holds data/"
	helpTexts["kuni_data_disk_total_bytes"] = "Size of the disk that holds data/"
}
