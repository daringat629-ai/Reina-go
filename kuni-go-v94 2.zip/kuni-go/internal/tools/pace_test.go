package tools

import (
	"context"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"kuni/internal/config"
	"kuni/internal/metrics"
	"kuni/internal/prompts"
	"kuni/internal/telegram"
)

func TestTypingSpeedIsHuman(t *testing.T) {
	mid := func() float64 { return 0.5 }
	// 130 characters at 6.5/s = 20 s of thumbs (+ a moment to start): capped at 20 s
	if d := typingSpeed(6.5, 0.35, 20000, strings.Repeat("я", 130), mid); d != 20*time.Second {
		t.Fatalf("cap: %v", d)
	}
	// 65 characters: about 10 s, nowhere near the old 4 s ceiling
	if d := typingSpeed(6.5, 0.35, 20000, strings.Repeat("я", 65), mid); d < 10*time.Second || d > 11*time.Second {
		t.Fatalf("65 chars: %v", d)
	}
	// a short "ага" is quick but never instant
	if d := typingSpeed(6.5, 0.35, 20000, "ага", mid); d < 800*time.Millisecond || d > 2*time.Second {
		t.Fatalf("ага: %v", d)
	}
	// +-35%: the same text is typed at different speeds
	lo := typingSpeed(6.5, 0.35, 0, strings.Repeat("я", 65), func() float64 { return 0 })
	hi := typingSpeed(6.5, 0.35, 0, strings.Repeat("я", 65), func() float64 { return 0.999 })
	if lo > 7500*time.Millisecond || hi < 14*time.Second {
		t.Fatalf("jitter too flat: %v .. %v", lo, hi)
	}
	if typingSpeed(0, 0.35, 20000, "x", mid) != 0 {
		t.Fatal("0 cps = the old model")
	}
}

func TestShowForRenewsTheStatus(t *testing.T) {
	old := actionRefresh
	actionRefresh = 20 * time.Millisecond
	defer func() { actionRefresh = old }()
	tg := telegram.NewFake()
	if err := showFor(context.Background(), tg, 1, telegram.ActTyping, 90*time.Millisecond); err != nil {
		t.Fatal(err)
	}
	if tg.Typings < 4 {
		t.Fatalf("typing shown %d times in 90 ms with a 20 ms refresh: Telegram would drop it", tg.Typings)
	}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if err := showFor(ctx, tg, 1, telegram.ActTyping, time.Hour); err == nil {
		t.Fatal("a cancelled context must stop at once")
	}
}

func TestMirrorBubbles(t *testing.T) {
	for _, c := range []struct{ max, in, want int }{
		{4, 0, 4}, {4, 5, 2}, {4, 20, 2}, {4, 21, 3}, {4, 60, 3}, {4, 61, 4}, {1, 5, 1}, {0, 5, 2}, {0, 200, 0},
	} {
		if got := mirrorBubbles(c.max, c.in); got != c.want {
			t.Errorf("mirrorBubbles(%d, %d) = %d, want %d", c.max, c.in, got, c.want)
		}
	}
}

func paceDeps(t *testing.T, cfg *config.Config) (Deps, *telegram.Fake) {
	ps, _ := prompts.NewStore(t.TempDir(), prompts.Vars{})
	tg := telegram.NewFake()
	if cfg.DataDir == "" {
		cfg.DataDir = t.TempDir()
	}
	return Deps{RT: NewRuntime(nil), TG: tg, Prompts: ps, Metrics: metrics.New(), Cfg: func() *config.Config { return cfg }}, tg
}

var paceChat = telegram.Chat{ID: 7, Title: "A", Kind: telegram.ChatPrivate, IsMember: true}

func TestShortMessageGetsFewBubbles(t *testing.T) {
	d, tg := paceDeps(t, &config.Config{MaxMessageChars: 40, MaxBubbles: 4, MirrorLength: true})
	text := "первая мысль тут\nвторая мысль тут\nтретья мысль тут\nчетвертая мысль тут\nпятая мысль тут"
	ctx := WithPace(context.Background(), &Pace{IncomingLen: 5}) // "ну че"
	if _, err := sendTool(d, paceChat).Run(ctx, Args{"text": text}); err != nil {
		t.Fatal(err)
	}
	if got := tg.SentTexts(); len(got) != 2 {
		t.Fatalf("after a 5-character message: %q", got)
	}
}

func TestSendStopsWhenTheyWriteMidAnswer(t *testing.T) {
	d, tg := paceDeps(t, &config.Config{MaxMessageChars: 40, MaxBubbles: 4})
	calls := 0
	p := &Pace{Fresh: func(context.Context) string {
		calls++
		if calls == 1 {
			return "Error: not sent. 1 more message(s) arrived"
		}
		return ""
	}}
	out, err := sendTool(d, paceChat).Run(WithPace(context.Background(), p), Args{"text": "раз два три\nчетыре пять\nшесть семь"})
	if err != nil {
		t.Fatal(err)
	}
	if got := tg.SentTexts(); len(got) != 1 {
		t.Fatalf("kept sending a stale answer: %q", got)
	}
	if !strings.Contains(out, "NOT sent") || !strings.Contains(out, "четыре пять") || !strings.Contains(out, "more message") {
		t.Fatalf("the model is not told what was left: %s", out)
	}
	// nothing new: everything goes
	d2, tg2 := paceDeps(t, &config.Config{MaxMessageChars: 40, MaxBubbles: 4})
	quiet := &Pace{Fresh: func(context.Context) string { return "" }}
	if _, err := sendTool(d2, paceChat).Run(WithPace(context.Background(), quiet), Args{"text": "раз два три\nчетыре пять\nшесть семь"}); err != nil {
		t.Fatal(err)
	}
	if got := tg2.SentTexts(); len(got) != 3 {
		t.Fatalf("%q", got)
	}
}

func TestThinkingTypingIsCreditedToTheFirstBubble(t *testing.T) {
	d, _ := paceDeps(t, &config.Config{TypingSpeedCPS: 6.5, TypingCapSecs: 20})
	p := &Pace{}
	p.AddShown(time.Hour) // she "typed" long enough while thinking
	start := time.Now()
	if _, err := sendTool(d, paceChat).Run(WithPace(context.Background(), p), Args{"text": "ну короче я вообще не поняла что он хотел"}); err != nil {
		t.Fatal(err)
	}
	if el := time.Since(start); el > 2*time.Second {
		t.Fatalf("typing counted twice: %v", el)
	}
}

func TestVoiceShowsRecordingNotTyping(t *testing.T) {
	cfg := &config.Config{}
	d, tg := paceDeps(t, cfg)
	if err := os.MkdirAll(filepath.Join(cfg.DataDir, "voice"), 0o700); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(cfg.DataDir, "voice", "v.ogg"), []byte("x"), 0o600); err != nil {
		t.Fatal(err)
	}
	if _, err := sendToolRaw(d, paceChat).Run(context.Background(), Args{"audio_filename": "v.ogg"}); err != nil {
		t.Fatal(err)
	}
	acts := tg.ActionsSeen()
	for _, a := range acts {
		if a == telegram.ActTyping {
			t.Fatalf("'typing' before a voice note: %v", acts)
		}
	}
	if len(acts) == 0 || acts[0] != telegram.ActVoice {
		t.Fatalf("no 'recording a voice note': %v", acts)
	}
	if voiceActionTime(1) != 2*time.Second || voiceActionTime(1<<20) != 20*time.Second || voiceActionTime(40000) != 10*time.Second {
		t.Fatal("voice action time")
	}
}
