package main

import (
	"context"
	"fmt"
	"net"
	"net/url"
	"os"
	"strings"
	"time"

	"kuni/internal/config"
	"kuni/internal/maint"
)

// Machine-level checks of `doctor`: the local servers she leans on (embeddings, speech), the data folder, the disk,
// the time zone. Each message says what is wrong and what to do about it.

// hostPort extracts "host:port" from a base URL (the default port of the scheme when none is written).
func hostPort(raw string) (host, addr string, ok bool) {
	u, err := url.Parse(strings.TrimSpace(raw))
	if err != nil || u.Hostname() == "" {
		return "", "", false
	}
	port := u.Port()
	if port == "" {
		port = "80"
		if u.Scheme == "https" {
			port = "443"
		}
	}
	return u.Hostname(), net.JoinHostPort(u.Hostname(), port), true
}

func isLoopback(host string) bool {
	if host == "localhost" {
		return true
	}
	ip := net.ParseIP(host)
	return ip != nil && ip.IsLoopback()
}

func dial(ctx context.Context, addr string) error {
	dctx, cancel := context.WithTimeout(ctx, 3*time.Second)
	defer cancel()
	var nd net.Dialer
	c, err := nd.DialContext(dctx, "tcp", addr)
	if err != nil {
		return err
	}
	return c.Close()
}

// checkEmbeddingServer: a local embedding server (llama-server on 127.0.0.1:8081, Ollama on :11434) is the usual
// reason why the diary does not work. A refused connection gets its own clear message; a remote service is checked
// by the real request in checkLLM.
func (d *doctor) checkEmbeddingServer(ctx context.Context, cfg *config.Config) {
	host, addr, ok := hostPort(cfg.EmbeddingBaseURL)
	if !ok || !isLoopback(host) {
		return
	}
	if err := dial(ctx, addr); err != nil {
		d.embedDown = true
		d.add("fail", "эмбеддинг-сервер "+addr, "не отвечает ("+short(err.Error())+"): без него не работает память. Запусти его (ollama_setup.sh или llama-server --embedding --port "+portOf(addr)+") или укажи другой llm.embedding_base_url")
		return
	}
	d.add("ok", "эмбеддинг-сервер "+addr, "порт открыт")
}

func portOf(addr string) string {
	_, p, err := net.SplitHostPort(addr)
	if err != nil {
		return ""
	}
	return p
}

// checkTTS: with a speech backend on, its server must be there; without it voice replies fail one by one.
func (d *doctor) checkTTS(ctx context.Context, cfg *config.Config) {
	if !cfg.TTSOn() {
		return
	}
	_, addr, ok := hostPort(cfg.TTSURL)
	if !ok {
		d.add("warn", "TTS", fmt.Sprintf("capabilities.tts_url = %q не похож на адрес: голосовые ответы не заработают", cfg.TTSURL))
		return
	}
	if err := dial(ctx, addr); err != nil {
		d.add("warn", "TTS-сервер "+addr, "не отвечает ("+short(err.Error())+"): голосовые ответы работать не будут. Запусти сервер речи или поставь capabilities.tts_backend = \"none\"")
		return
	}
	d.add("ok", "TTS-сервер "+addr, "порт открыт ("+cfg.TTSBackend+")")
}

// checkDataDir: the folder must exist, be writable, and not be open to other users (it holds the conversations).
func (d *doctor) checkDataDir(cfg *config.Config) {
	dir := cfg.DataDir
	if err := os.MkdirAll(dir, 0o700); err != nil {
		d.add("fail", "папка data", dir+": не создаётся ("+short(err.Error())+"): проверь права на родительскую папку и misc.data_dir")
		return
	}
	f, err := os.CreateTemp(dir, ".doctor-*")
	if err != nil {
		d.add("fail", "папка data", dir+": нельзя писать ("+short(err.Error())+"): запускай от того пользователя, кто владеет папкой, или chown -R")
		return
	}
	name := f.Name()
	f.Close()
	_ = os.Remove(name)
	if st, err := os.Stat(dir); err == nil && st.Mode().Perm()&0o007 != 0 {
		d.add("warn", "папка data", fmt.Sprintf("%s открыта всем (%o): там диалоги и ключи, лучше chmod 700 %s", dir, st.Mode().Perm(), dir))
		return
	}
	d.add("ok", "папка data", dir+": пишется")
}

// checkDisk: under 100 MB free she cannot even save the diary; under the configured share or 500 MB is a warning.
func (d *doctor) checkDisk(cfg *config.Config) {
	_ = os.MkdirAll(cfg.DataDir, 0o755)
	disk, err := maint.DiskOf(cfg.DataDir)
	if err != nil {
		return
	}
	note := fmt.Sprintf("свободно %s из %s", maint.Human(disk.Free), maint.Human(disk.Total))
	switch {
	case disk.Total > 0 && disk.Free < 100<<20:
		d.add("fail", "диск", note+": меньше 100 МБ, дневник и бэкапы не запишутся. Освободи место (журналы, старые бэкапы в data/)")
	case disk.Low(cfg.DiskWarnPercent):
		d.add("warn", "диск", note+": мало места")
	default:
		d.add("ok", "диск", note)
	}
}

// checkTimezone: quiet hours, the daily report and the usage day follow autonomy.timezone; a server in UTC with the
// field empty makes "night" start in the middle of the owner's day.
func (d *doctor) checkTimezone(cfg *config.Config) {
	if cfg.AutonomyTimezone == "" {
		z, off := time.Now().Zone()
		d.add("warn", "часовой пояс", fmt.Sprintf("autonomy.timezone пуст: тихие часы и отчёт идут по поясу сервера (%s, UTC%+d). Задай, например, \"Asia/Bishkek\"", z, off/3600))
		return
	}
	if _, err := time.LoadLocation(cfg.AutonomyTimezone); err != nil {
		d.add("warn", "часовой пояс", fmt.Sprintf("autonomy.timezone = %q неизвестен: используется пояс сервера. Нужно имя из IANA, например Europe/Moscow", cfg.AutonomyTimezone))
		return
	}
	d.add("ok", "часовой пояс", fmt.Sprintf("%s, сейчас там %s", cfg.AutonomyTimezone, time.Now().In(cfg.Location()).Format("15:04")))
}
