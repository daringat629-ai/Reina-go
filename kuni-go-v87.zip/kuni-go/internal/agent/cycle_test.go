package agent

import (
	"testing"
	"time"
)

func TestCyclePhasesCoverTheMonth(t *testing.T) {
	start := time.Date(2026, 10, 1, 0, 0, 0, 0, time.UTC)
	seen := map[string]bool{}
	for i := 0; i < 28; i++ {
		d := cycleDay(start.AddDate(0, 0, i), start, 28)
		if d != i+1 {
			t.Fatalf("day %d got %d", i+1, d)
		}
		seen[phaseOf(d, 28).name] = true
	}
	for _, n := range []string{"period-heavy", "period-end", "follicular", "ovulation", "luteal", "pms"} {
		if !seen[n] {
			t.Fatalf("phase %s never happens", n)
		}
	}
	if cycleDay(start.AddDate(0, 0, 28), start, 28) != 1 || cycleDay(start.AddDate(0, 0, -1), start, 28) != 28 {
		t.Fatal("the cycle must repeat in both directions")
	}
}
