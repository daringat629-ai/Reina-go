// Package maint keeps the machine she lives on healthy: free-space checks, cleaning her own cache, and daily
// backups of everything that makes her "her" (diary, memory, prompts, mood, config).
package maint

import (
	"archive/tar"
	"compress/gzip"
	"fmt"
	"io"
	"io/fs"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"
)

// Disk is the free space of the filesystem holding a path.
type Disk struct{ Free, Total uint64 }

// Percent is the free share, 0..100.
func (d Disk) Percent() float64 {
	if d.Total == 0 {
		return 100
	}
	return float64(d.Free) / float64(d.Total) * 100
}

// Low reports whether free space is under warnPercent or under 500 MB.
func (d Disk) Low(warnPercent int) bool {
	if d.Total == 0 {
		return false
	}
	return d.Percent() < float64(warnPercent) || d.Free < 500<<20
}

// Human formats bytes as MB/GB.
func Human(n uint64) string {
	switch {
	case n >= 1<<30:
		return fmt.Sprintf("%.1f ГБ", float64(n)/(1<<30))
	default:
		return fmt.Sprintf("%d МБ", n>>20)
	}
}

// CleanOld deletes regular files under dir not modified for maxAge and returns what it removed.
func CleanOld(dir string, maxAge time.Duration, now time.Time) (files int, bytes int64) {
	_ = filepath.WalkDir(dir, func(p string, e fs.DirEntry, err error) error {
		if err != nil || e.IsDir() {
			return nil
		}
		info, err := e.Info()
		if err != nil || !info.Mode().IsRegular() || now.Sub(info.ModTime()) < maxAge {
			return nil
		}
		if os.Remove(p) == nil {
			files++
			bytes += info.Size()
		}
		return nil
	})
	return files, bytes
}

// BackupInfo describes one archive on disk.
type BackupInfo struct {
	Name string    `json:"name"`
	Size int64     `json:"size"`
	Time time.Time `json:"time"`
}

// Backups lists archives in dir, newest first.
func Backups(dir string) []BackupInfo {
	es, _ := os.ReadDir(dir)
	var out []BackupInfo
	for _, e := range es {
		if e.IsDir() || !strings.HasPrefix(e.Name(), "reina-") || !strings.HasSuffix(e.Name(), ".tar.gz") {
			continue
		}
		if info, err := e.Info(); err == nil {
			out = append(out, BackupInfo{e.Name(), info.Size(), info.ModTime()})
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Time.After(out[j].Time) })
	return out
}

// Backup packs srcs (files or directories; missing ones are skipped) into dir/reina-YYYYMMDD-HHMMSS.tar.gz
// with mode 0600 and then keeps only the newest keep archives. Anything under dir itself is never packed.
func Backup(srcs []string, dir string, keep int, now time.Time) (string, error) {
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return "", err
	}
	absDir, _ := filepath.Abs(dir)
	name := "reina-" + now.Format("20060102-150405") + ".tar.gz"
	final := filepath.Join(dir, name)
	tmp := final + ".part"
	f, err := os.OpenFile(tmp, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o600)
	if err != nil {
		return "", err
	}
	gz := gzip.NewWriter(f)
	tw := tar.NewWriter(gz)
	fail := func(err error) (string, error) {
		_ = tw.Close()
		_ = gz.Close()
		_ = f.Close()
		_ = os.Remove(tmp)
		return "", err
	}
	for _, src := range srcs {
		src = filepath.Clean(src)
		if _, err := os.Stat(src); err != nil {
			continue
		}
		base := filepath.Dir(src)
		err := filepath.WalkDir(src, func(p string, e fs.DirEntry, err error) error {
			if err != nil {
				return nil
			}
			if abs, _ := filepath.Abs(p); strings.HasPrefix(abs, absDir+string(os.PathSeparator)) || abs == absDir {
				return filepath.SkipDir
			}
			info, err := e.Info()
			if err != nil || !(info.Mode().IsRegular() || info.IsDir()) {
				return nil
			}
			rel, err := filepath.Rel(base, p)
			if err != nil {
				return nil
			}
			hdr, err := tar.FileInfoHeader(info, "")
			if err != nil {
				return nil
			}
			hdr.Name = filepath.ToSlash(rel)
			if info.IsDir() {
				hdr.Name += "/"
			}
			if err := tw.WriteHeader(hdr); err != nil {
				return err
			}
			if info.Mode().IsRegular() {
				in, err := os.Open(p)
				if err != nil {
					return nil
				}
				defer in.Close()
				if _, err := io.CopyN(tw, in, info.Size()); err != nil && err != io.EOF {
					return err
				}
			}
			return nil
		})
		if err != nil {
			return fail(err)
		}
	}
	if err := tw.Close(); err != nil {
		return fail(err)
	}
	if err := gz.Close(); err != nil {
		return fail(err)
	}
	if err := f.Close(); err != nil {
		_ = os.Remove(tmp)
		return "", err
	}
	if err := os.Rename(tmp, final); err != nil {
		return "", err
	}
	if keep > 0 {
		for i, b := range Backups(dir) {
			if i >= keep {
				_ = os.Remove(filepath.Join(dir, b.Name))
			}
		}
	}
	return final, nil
}
