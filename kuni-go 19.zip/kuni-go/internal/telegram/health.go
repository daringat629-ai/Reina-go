package telegram

import (
	"sync"
	"time"
)

// ErrorRecord is one failed Telegram request, for the admin panel.
type ErrorRecord struct {
	At      time.Time `json:"at"`
	Method  string    `json:"method"`
	ChatID  int64     `json:"chat_id,omitempty"`
	Message string    `json:"message"`
}

// Health is what the panel shows about the Telegram connection.
type Health struct {
	FloodWaits int           `json:"flood_waits"`           // how many flood waits happened since start
	FloodUntil time.Time     `json:"flood_until,omitempty"` // zero or past: not waiting now
	Errors     []ErrorRecord `json:"errors"`                // newest last
}

// HealthSource is implemented by clients that track their request errors.
type HealthSource interface{ Health() Health }

const healthKeep = 30

type healthState struct {
	mu     sync.Mutex
	waits  int
	wait   time.Time
	errors []ErrorRecord
}

func (h *healthState) record(method string, chat int64, msg string) {
	h.mu.Lock()
	defer h.mu.Unlock()
	h.errors = append(h.errors, ErrorRecord{At: time.Now(), Method: method, ChatID: chat, Message: msg})
	if len(h.errors) > healthKeep {
		h.errors = h.errors[len(h.errors)-healthKeep:]
	}
}

// flood notes a flood wait of d; every request waits until it is over.
func (h *healthState) flood(d time.Duration) {
	h.mu.Lock()
	defer h.mu.Unlock()
	h.waits++
	if t := time.Now().Add(d); t.After(h.wait) {
		h.wait = t
	}
}

func (h *healthState) until() time.Time {
	h.mu.Lock()
	defer h.mu.Unlock()
	return h.wait
}

// Health returns a snapshot.
func (c *TDClient) Health() Health {
	c.hl.mu.Lock()
	defer c.hl.mu.Unlock()
	return Health{FloodWaits: c.hl.waits, FloodUntil: c.hl.wait, Errors: append([]ErrorRecord(nil), c.hl.errors...)}
}

var _ HealthSource = (*TDClient)(nil)
