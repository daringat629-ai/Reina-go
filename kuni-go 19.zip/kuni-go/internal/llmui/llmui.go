// Package llmui renders Telegram state into the XML-ish text the LLM reads
// (<chat>, <message>, <voice>, photo descriptions…). Port of src/llmui/.
package llmui

import (
	"context"
	"encoding/base64"
	"fmt"
	"html"
	"log"
	"os"
	"path/filepath"
	"strings"
	"time"

	"kuni/internal/config"
	"kuni/internal/docs"
	"kuni/internal/llm"
	"kuni/internal/media"
	"kuni/internal/prompts"
	"kuni/internal/telegram"
	"kuni/internal/util"
)

// EmbeddingTag mirrors IOpenAIChat::EMBEDDING_TAG; text containing it is neutralised
// so users can't smuggle fake image payloads into the prompt.
const EmbeddingTag = "kuni_embedding"

type Env struct {
	TG      telegram.Client
	LLM     *llm.Client
	Prompts *prompts.Store
	Media   func() media.Services
	Cfg     func() *config.Config
}

// Sanitize replaces text carrying the embedding tag with "malicious" (checkForMaliciousPayloads).
func Sanitize(s string) string {
	if strings.Contains(s, EmbeddingTag) {
		return "malicious"
	}
	return s
}

func attr(s string) string { return html.EscapeString(Sanitize(s)) }

// FormatChat renders one chat for get_telegram_chats.
func FormatChat(c telegram.Chat, now time.Time) string {
	preview := c.LastText
	if len(preview) > 80 {
		preview = preview[:80] + "…"
	}
	return fmt.Sprintf(`<chat chat_id="%d" title="%s" type="%s" unread="%d" last_message="%s" preview="%s"/>`,
		c.ID, attr(c.Title), c.Kind, c.Unread, util.TimeAgo(c.LastDate, now), attr(preview))
}

// FormatMessages renders a batch of messages, describing media on the way.
func (e *Env) FormatMessages(ctx context.Context, msgs []telegram.Message, now time.Time) string {
	var b strings.Builder
	for _, m := range msgs {
		b.WriteString(e.FormatMessage(ctx, m, now))
		b.WriteString("\n")
	}
	return b.String()
}

func (e *Env) FormatMessage(ctx context.Context, m telegram.Message, now time.Time) string {
	var attrs strings.Builder
	fmt.Fprintf(&attrs, `message_id="%d" sender="%s" time_ago="%s"`, m.ID, attr(m.SenderName), util.TimeAgo(m.Date, now))
	if m.Outgoing {
		attrs.WriteString(` you="true"`)
	} else if !m.Read {
		attrs.WriteString(` unread="true"`)
	}
	toYou := false
	if m.ReplyTo != 0 {
		fmt.Fprintf(&attrs, ` reply_to_message_id="%d"`, m.ReplyTo)
		if q, err := e.TG.Message(ctx, m.ChatID, m.ReplyTo); err == nil {
			snippet := strings.Join(strings.Fields(q.Text), " ")
			if r := []rune(snippet); len(r) > 80 {
				snippet = string(r[:80]) + "…"
			}
			if q.Media != telegram.MediaNone && snippet == "" {
				snippet = "[" + string(q.Media) + "]"
			}
			fmt.Fprintf(&attrs, ` reply_to_sender="%s" reply_to_text="%s"`, attr(q.SenderName), attr(snippet))
			if q.Outgoing || (q.SenderID != 0 && q.SenderID == e.TG.MyID()) {
				attrs.WriteString(` reply_to_you="true"`)
				toYou = true
			}
		}
	}
	if !m.Outgoing && (toYou || e.mentionsMe(m.Text)) {
		attrs.WriteString(` addressed_to_you="true"`)
	}
	if m.ForwardFrom != "" {
		fmt.Fprintf(&attrs, ` forwarded_from="%s"`, attr(m.ForwardFrom))
	}
	if m.ThreadID != 0 {
		fmt.Fprintf(&attrs, ` topic_id="%d"`, m.ThreadID)
	}
	if m.Edited {
		attrs.WriteString(` edited="true"`)
	}
	if len(m.Reactions) > 0 {
		fmt.Fprintf(&attrs, ` reactions="%s"`, attr(strings.Join(m.Reactions, "")))
	}

	body := Sanitize(m.Text)
	switch m.Media {
	case telegram.MediaVoice:
		body = e.transcribeVoice(ctx, m) + optionalCaption(body)
	case telegram.MediaPhoto:
		body = e.describe(ctx, m, "photo") + optionalCaption(body)
	case telegram.MediaSticker:
		body = e.describe(ctx, m, "sticker sticker_id=\""+attr(m.FileID)+"\" emoji=\""+attr(m.Text)+"\"")
	case telegram.MediaVideo:
		body = e.describeVideo(ctx, m) + optionalCaption(body)
	case telegram.MediaDocument:
		body = e.documentTag(m) + optionalCaption(body)
	case telegram.MediaPoll:
		body = pollTag(m)
	}
	return fmt.Sprintf("<message %s>\n%s\n</message>", attrs.String(), body)
}

// pollTag renders a poll with the vote counts and the option she chose.
func pollTag(m telegram.Message) string {
	p := m.Poll
	if p == nil {
		return "<poll>" + attr(m.Text) + "</poll>"
	}
	var b strings.Builder
	fmt.Fprintf(&b, `<poll question="%s" votes="%d"`, attr(p.Question), p.Total)
	if p.Closed {
		b.WriteString(` closed="true"`)
	}
	if p.Multiple {
		b.WriteString(` multiple_answers="true"`)
	}
	if p.Anonymous {
		b.WriteString(` anonymous="true"`)
	}
	b.WriteString(">\n")
	for i, o := range p.Options {
		fmt.Fprintf(&b, `<option n="%d" votes="%d"`, i+1, o.Votes)
		if o.Chosen {
			b.WriteString(` you_voted="true"`)
		}
		fmt.Fprintf(&b, ">%s</option>\n", attr(o.Text))
	}
	return b.String() + "</poll>"
}

// documentTag shows a file without opening it: the model decides whether to #read_document.
func (e *Env) documentTag(m telegram.Message) string {
	max := int64(10)
	if e.Cfg != nil && e.Cfg().DocMaxMB > 0 {
		max = int64(e.Cfg().DocMaxMB)
	}
	state := "readable"
	switch {
	case !docs.Readable(m.FileName):
		state = "unsupported type"
	case m.FileSize > max<<20:
		state = "too big to read"
	}
	return fmt.Sprintf(`<document name="%s" size="%s" %s/>`, attr(m.FileName), HumanSize(m.FileSize), "status=\""+state+"\"")
}

func optionalCaption(s string) string {
	if strings.TrimSpace(s) == "" {
		return ""
	}
	return "\n" + s
}

func (e *Env) transcribeVoice(ctx context.Context, m telegram.Message) string {
	data, err := e.TG.Download(ctx, m.FileID)
	if err != nil {
		return "<voice>(can't download: " + err.Error() + ")</voice>"
	}
	text, err := e.Media().STT.Transcribe(ctx, data, "voice.ogg")
	if err != nil {
		return "<voice>(transcription unavailable: " + err.Error() + ")</voice>"
	}
	return "<voice>\n" + Sanitize(text) + "\n</voice>"
}

func (e *Env) cachePath(key string) string {
	safe := strings.Map(func(r rune) rune {
		if r == '/' || r == '\\' || r == ':' {
			return '_'
		}
		return r
	}, key)
	return filepath.Join(e.Cfg().DataDir, "cache", "images", safe+".md")
}

// describe returns "<tag description>…</tag>" for an image-like message, with a disk cache keyed by file id.
func (e *Env) describe(ctx context.Context, m telegram.Message, tag string) string {
	closeTag := strings.Fields(tag)[0]
	wrap := func(s string) string { return "<" + tag + " description>\n" + s + "\n</" + closeTag + ">" }
	cache := e.cachePath(m.FileID)
	if b, err := os.ReadFile(cache); err == nil {
		return wrap(string(b))
	}
	data, err := e.TG.Download(ctx, m.FileID)
	if err != nil {
		return wrap("(can't download: " + err.Error() + ")")
	}
	desc, err := e.DescribeImage(ctx, data, strings.HasPrefix(tag, "sticker"))
	if err != nil {
		log.Printf("llmui: can't describe image: %v", err)
		return wrap("This media type is not supported")
	}
	_ = os.MkdirAll(filepath.Dir(cache), 0o755)
	_ = os.WriteFile(cache, []byte(desc), 0o644)
	return wrap(desc)
}

// DescribeImage asks the (vision) LLM to describe image bytes using photo_to_text / sticker_to_text.
func (e *Env) DescribeImage(ctx context.Context, data []byte, sticker bool) (string, error) {
	system := e.Prompts.Get(prompts.PhotoToText)
	if sticker {
		system = e.Prompts.Get(prompts.StickerToText)
	}
	ctxText := "<context>\n<character name=\"" + e.Cfg().CharacterName + "\">\n" +
		e.Prompts.Get(prompts.CharacterAppearance) + "\n</character>\n</context>\n\nPhoto:\n"
	msg := llm.Message{Role: "user", Parts: []llm.Part{
		{Type: "text", Text: ctxText},
		{Type: "image_url", ImageURL: DataURL(data)},
		{Type: "text", Text: "Describe the last photo."},
	}}
	for attempt := 0; attempt < 3; attempt++ {
		out, err := e.LLM.Chat(ctx, system, []llm.Message{msg})
		if err != nil {
			return "", err
		}
		if strings.TrimSpace(out) != "" { // empty = local model overflowed its reasoning, retry
			return strings.TrimSpace(out), nil
		}
	}
	return "", fmt.Errorf("model returned empty description")
}

func (e *Env) describeVideo(ctx context.Context, m telegram.Message) string {
	tag := "video"
	switch m.MediaDetail {
	case "round":
		tag = `video kind="round video message"`
	case "gif":
		tag = `video kind="gif"`
	}
	cache := e.cachePath("video_" + m.FileID)
	if b, err := os.ReadFile(cache); err == nil {
		return string(b)
	}
	if max := int64(25); e.Cfg != nil {
		if v := int64(e.Cfg().MediaMaxMB); v > 0 {
			max = v
		}
		if m.FileSize > max<<20 {
			return "<" + tag + ">(too big to watch: " + HumanSize(m.FileSize) + ")</video>"
		}
	}
	data, err := e.TG.Download(ctx, m.FileID)
	if err != nil {
		return "<" + tag + ">(can't download: " + err.Error() + ")</video>"
	}
	svc := e.Media()
	var out strings.Builder
	out.WriteString("<" + tag + ">\n")
	frames, ferr := svc.Video.Frames(ctx, data, 4)
	if ferr != nil {
		out.WriteString("(frames unavailable: " + ferr.Error() + ")\n")
	}
	for i, f := range frames {
		d, err := e.DescribeImage(ctx, f, false)
		if err == nil {
			fmt.Fprintf(&out, "<frame n=\"%d\">%s</frame>\n", i+1, d)
		}
	}
	if wav, err := svc.Video.Audio(ctx, data); err == nil {
		if text, err := svc.STT.Transcribe(ctx, wav, "audio.wav"); err == nil && text != "" {
			out.WriteString("<audio_transcript>" + Sanitize(text) + "</audio_transcript>\n")
		}
	}
	out.WriteString("</video>")
	if ferr == nil {
		_ = os.MkdirAll(filepath.Dir(cache), 0o755)
		_ = os.WriteFile(cache, []byte(out.String()), 0o644)
	}
	return out.String()
}

// DataURL encodes image bytes for vision input.
func DataURL(b []byte) string {
	mime := "image/jpeg"
	if len(b) > 8 && string(b[1:4]) == "PNG" {
		mime = "image/png"
	}
	return "data:" + mime + ";base64," + base64.StdEncoding.EncodeToString(b)
}

// who explains a user id in terms the model cares about: itself, or its owner.
func who(id, myID, ownerID int64) string {
	switch {
	case id != 0 && id == myID:
		return ` is_you="true"`
	case id != 0 && id == ownerID:
		return ` is_owner="true"`
	}
	return ""
}

// FormatMember renders one group participant for chat_members.
func FormatMember(m telegram.Member, myID, ownerID int64) string {
	s := fmt.Sprintf(`<member user_id="%d" name="%s"`, m.ID, attr(m.Name))
	if m.Username != "" {
		s += fmt.Sprintf(` username="@%s"`, attr(m.Username))
	}
	s += fmt.Sprintf(` role="%s"`, m.Role)
	if m.IsBot {
		s += ` bot="true"`
	}
	return s + who(m.ID, myID, ownerID) + "/>"
}

// FormatUser renders a profile for user_info.
func FormatUser(u telegram.User, myID, ownerID int64) string {
	s := fmt.Sprintf(`<user user_id="%d" name="%s"`, u.ID, attr(u.Name))
	if u.Username != "" {
		s += fmt.Sprintf(` username="@%s"`, attr(u.Username))
	}
	if u.IsBot {
		s += ` bot="true"`
	}
	if u.IsContact {
		s += ` in_your_contacts="true"`
	}
	s += who(u.ID, myID, ownerID) + ">"
	if u.Bio != "" {
		s += "\n" + Sanitize(u.Bio) + "\n"
	}
	return s + "</user>"
}

// mentionsMe reports whether text calls the character by name or @nickname.
func (e *Env) mentionsMe(text string) bool {
	if e.Cfg == nil {
		return false
	}
	c := e.Cfg()
	low := strings.ToLower(text)
	names := []string{c.CharacterName, strings.TrimPrefix(c.CharacterNick, "@")}
	if f := strings.Fields(c.CharacterName); len(f) > 0 {
		names = append(names, f[0])
	}
	for _, n := range names {
		n = strings.ToLower(strings.TrimSpace(n))
		if len([]rune(n)) >= 3 && strings.Contains(low, n) {
			return true
		}
	}
	return false
}

// HumanSize prints a byte count like "1.5 MB".
func HumanSize(n int64) string {
	switch {
	case n >= 1<<20:
		return fmt.Sprintf("%.1f MB", float64(n)/(1<<20))
	case n >= 1<<10:
		return fmt.Sprintf("%.0f KB", float64(n)/(1<<10))
	}
	return fmt.Sprintf("%d B", n)
}
