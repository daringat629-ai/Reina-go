// Package usage keeps a per-day, restart-proof tally of LLM tokens and what they cost, and enforces the optional
// daily token limit: past the soft limit the character stops acting on her own, past the hard limit (3x) every
// request is refused, which stops a runaway loop from burning money.
package usage

import (
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"sync"
	"time"
)

// HardFactor is how many times the soft limit the hard stop sits at.
const HardFactor = 3

type counts struct {
	In  int64 `json:"in"`
	Out int64 `json:"out"`
}

type data struct {
	Day    string            `json:"day"`
	Models map[string]counts `json:"models"`
	Warned bool              `json:"warned"` // the soft-limit warning went out today
}

// Prices are dollars per million tokens.
type Prices struct{ In, Out float64 }

// Tracker is safe for concurrent use. A nil *Tracker counts nothing and never blocks.
type Tracker struct {
	mu   sync.Mutex
	path string
	d    data
	now  func() time.Time
}

func New(path string) *Tracker {
	t := &Tracker{path: path, now: time.Now}
	if b, err := os.ReadFile(path); err == nil {
		_ = json.Unmarshal(b, &t.d)
	}
	return t
}

func (t *Tracker) roll() {
	if day := t.now().Format("2006-01-02"); t.d.Day != day {
		t.d = data{Day: day, Models: map[string]counts{}}
	}
	if t.d.Models == nil {
		t.d.Models = map[string]counts{}
	}
}

func (t *Tracker) save() {
	if t.path == "" {
		return
	}
	_ = os.MkdirAll(filepath.Dir(t.path), 0o755)
	b, _ := json.Marshal(t.d)
	tmp := t.path + ".tmp"
	if os.WriteFile(tmp, b, 0o644) == nil {
		_ = os.Rename(tmp, t.path)
	}
}

// Add counts one request. It reports true exactly once per day: when the soft limit is crossed for the first time.
func (t *Tracker) Add(model string, in, out int, softLimit int64) (crossed bool) {
	if t == nil {
		return false
	}
	t.mu.Lock()
	defer t.mu.Unlock()
	t.roll()
	c := t.d.Models[model]
	c.In += int64(in)
	c.Out += int64(out)
	t.d.Models[model] = c
	if softLimit > 0 && !t.d.Warned && t.totalLocked() >= softLimit {
		t.d.Warned, crossed = true, true
	}
	t.save()
	return crossed
}

func (t *Tracker) totalLocked() int64 {
	var n int64
	for _, c := range t.d.Models {
		n += c.In + c.Out
	}
	return n
}

// Today returns the tokens used today.
func (t *Tracker) Today() (in, out int64) {
	if t == nil {
		return 0, 0
	}
	t.mu.Lock()
	defer t.mu.Unlock()
	t.roll()
	for _, c := range t.d.Models {
		in += c.In
		out += c.Out
	}
	return in, out
}

// Cost is today's spend in dollars given per-model prices; ok is false when no used model has a price.
func (t *Tracker) Cost(price func(model string) Prices) (usd float64, ok bool) {
	if t == nil {
		return 0, false
	}
	t.mu.Lock()
	defer t.mu.Unlock()
	t.roll()
	for m, c := range t.d.Models {
		p := price(m)
		if p.In == 0 && p.Out == 0 {
			continue
		}
		ok = true
		usd += float64(c.In)/1e6*p.In + float64(c.Out)/1e6*p.Out
	}
	return usd, ok
}

// Over reports whether today's tokens reached limit (0 = no limit).
func (t *Tracker) Over(limit int64) bool {
	if t == nil || limit <= 0 {
		return false
	}
	in, out := t.Today()
	return in+out >= limit
}

// ErrHardLimit is returned by Guard once the hard limit is hit.
var ErrHardLimit = errors.New("daily token limit exceeded: the character is paused until tomorrow (llm.daily_token_limit)")

// Guard returns ErrHardLimit when today's tokens reached HardFactor x limit.
func (t *Tracker) Guard(limit int64) error {
	if t.Over(limit*HardFactor) && limit > 0 {
		return ErrHardLimit
	}
	return nil
}
