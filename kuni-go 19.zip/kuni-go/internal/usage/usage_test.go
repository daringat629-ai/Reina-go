package usage

import (
	"path/filepath"
	"testing"
	"time"
)

func TestTallyCostPersistenceAndDayRoll(t *testing.T) {
	path := filepath.Join(t.TempDir(), "u.json")
	u := New(path)
	now := time.Date(2026, 10, 19, 12, 0, 0, 0, time.UTC)
	u.now = func() time.Time { return now }
	u.Add("deepseek", 1_000_000, 100_000, 0)
	u.Add("qwen", 500_000, 0, 0)
	in, out := u.Today()
	if in != 1_500_000 || out != 100_000 {
		t.Fatalf("%d %d", in, out)
	}
	price := func(m string) Prices {
		if m == "deepseek" {
			return Prices{In: 0.02, Out: 0.64}
		}
		return Prices{}
	}
	usd, ok := u.Cost(price)
	if !ok || usd < 0.0839 || usd > 0.0841 { // 0.02 + 0.064; the unpriced model adds nothing
		t.Fatalf("cost %v %v", usd, ok)
	}
	if _, ok := u.Cost(func(string) Prices { return Prices{} }); ok {
		t.Fatal("no prices -> no cost shown")
	}
	u2 := New(path)
	u2.now = u.now
	if in2, _ := u2.Today(); in2 != 1_500_000 {
		t.Fatalf("not persisted: %d", in2)
	}
	now = now.Add(24 * time.Hour)
	if in3, out3 := u.Today(); in3 != 0 || out3 != 0 {
		t.Fatal("a new day starts from zero")
	}
}

func TestSoftWarnsOnceAndHardGuards(t *testing.T) {
	u := New("")
	if u.Add("m", 400, 0, 1000) || u.Over(1000) {
		t.Fatal("below the limit")
	}
	if !u.Add("m", 700, 0, 1000) {
		t.Fatal("crossing the soft limit must be reported")
	}
	if u.Add("m", 10, 0, 1000) {
		t.Fatal("only once per day")
	}
	if !u.Over(1000) || u.Guard(1000) != nil {
		t.Fatal("over soft but not hard")
	}
	u.Add("m", 2000, 0, 1000)
	if u.Guard(1000) != ErrHardLimit {
		t.Fatal("3x limit must hard-stop")
	}
	if u.Guard(0) != nil {
		t.Fatal("no limit configured, no guard")
	}
	var nilT *Tracker
	nilT.Add("m", 1, 1, 1)
	if nilT.Guard(1) != nil || nilT.Over(1) {
		t.Fatal("nil tracker never blocks")
	}
}
