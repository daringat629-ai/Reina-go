// Package brain is a small spiking-style neural substrate modelled on the layout of the fruit-fly brain
// (the FlyWire connectome: sensory neurons -> a sparse "mushroom body" that learns by dopamine -> a recurrent
// core -> a slow goal-holding pool -> descending output neurons). It is an analogy, not an emulation: the wiring
// is grown from a seed here instead of read from a microscope, and what the outputs mean is "drives" that colour her
// turns. Everything is persistent and deterministic given the seed, so her inner state can be watched and replayed.
package brain

import (
	"compress/gzip"
	"encoding/json"
	"fmt"
	"math"
	"math/rand"
	"os"
	"sort"
	"strings"
	"sync"
	"time"
)

// Tuning of the core (found by sweeping for activity of a few percent and a poke that travels, not dies or explodes).
var (
	excLo, excHi = 0.32, 0.74 // excitatory synapse strength
	kcDrive      = 1.1        // how hard an active Kenyon-like cell drives its core targets
)

// Sensory channels (what the world looks like to her), 0..1 each.
var Channels = [12]string{"social", "group", "owner", "stranger", "bond", "praise", "threat", "quiet", "night", "novelty", "task", "world"}

// Drives are the descending outputs: what she is inclined to do.
var Drives = [nGoal]string{"connect", "withdraw", "explore", "rest", "create", "reflect", "guard", "attach"}

const (
	nHash = 64 // text features: words hashed into buckets (a stand-in for meaning)
	nIn   = 12 + nHash
	nKC   = 4000 // Kenyon-like cells: sparse code of the situation
	nCore = 6000 // recurrent core
	nGoal = 8
	kcTop = 300 // ~7% of KCs fire (APL-like global inhibition)
)

// Brain holds the whole state. Safe for concurrent use.
type Brain struct {
	mu   sync.Mutex
	path string

	seed    int64
	kcIn    [nKC][4]int8 // each KC samples 4 sensory channels (as in the fly)
	kcW     [nKC][nGoal]float64
	coreS   [nCore][]syn      // outgoing synapses of each core neuron (sparse); sign = transmitter (+ excitatory / - inhibitory)
	pos     [nCore][3]float32 // where each core neuron sits in the cortex-like slab (wiring is local first)
	inhib   [nCore]bool       // Dale's law: an inhibitory neuron only inhibits
	kcCore  [nKC][3]int16
	coreOut [nCore][nGoal]float32

	core    [nCore]float64 // membrane potentials
	thr     [nCore]float64 // adaptive thresholds: a neuron that fires a lot gets harder to fire
	refr    [nCore]int8    // refractory ticks left
	fired   [nCore]bool    // which core neurons spiked on the last tick
	eps     []episode      // recent reinforced situations, replayed in sleep
	slept   string         // day of the last sleep
	journal string         // path of the JSONL journal of what she felt ("" = none)
	goal    [nGoal]float64 // slow pool that holds the leaning
	trace   [nKC]float64   // eligibility trace (which KCs were active recently)
	last    [nGoal]float64 // last drive vector
	lastTop string
	lastIn  [nIn]float64 // the last situation she was shown (the viewer replays it to keep the picture alive)
	lastKC  []int
	Ticks   int64
}

type syn struct {
	to int32
	w  float32
}

// episode is one remembered lesson: the KCs that were active, the drive that led and how it turned out.
type episode struct {
	KC    []int
	Drive int
	Value float64
}

type saved struct {
	Eps   []episode
	Slept string
	Seed  int64
	KCW   [][]float64
	Goal  []float64
	Trace []float64
	Ticks int64
}

// New builds the wiring from seed and loads learned weights from path if the file exists.
func New(path string, seed int64) *Brain {
	b := &Brain{path: path, seed: seed}
	r := rand.New(rand.NewSource(seed))
	for k := 0; k < nKC; k++ {
		for j := 0; j < 4; j++ {
			b.kcIn[k][j] = int8(r.Intn(nIn))
		}
		for j := 0; j < 3; j++ {
			b.kcCore[k][j] = int16(r.Intn(nCore))
		}
		for d := 0; d < nGoal; d++ {
			b.kcW[k][d] = 0.02 * r.Float64()
		}
	}
	// the core is a slab of tissue: neurons sit in space and mostly talk to their neighbours, with a few long-range links
	for i := 0; i < nCore; i++ {
		b.pos[i] = [3]float32{float32(r.Float64()*2.6 - 1.3), float32(r.Float64()*1.1 - 0.55), float32(r.Float64()*1.6 - 0.8)}
		b.inhib[i] = r.Float64() < 0.2
	}
	for i := 0; i < nCore; i++ {
		var near [9]struct {
			j int
			d float32
		}
		for k := range near {
			near[k].d = 1e9
		}
		for c := 0; c < 70; c++ { // the nearest of 70 random candidates ~ local wiring without an O(n^2) search
			j := r.Intn(nCore)
			if j == i {
				continue
			}
			dx, dy, dz := b.pos[i][0]-b.pos[j][0], b.pos[i][1]-b.pos[j][1], b.pos[i][2]-b.pos[j][2]
			d := dx*dx + dy*dy + dz*dz
			w := 0
			for k := range near {
				if near[k].d > near[w].d {
					w = k
				}
			}
			if d < near[w].d {
				near[w].j, near[w].d = j, d
			}
		}
		add := func(j int) {
			w := float32(excLo + (excHi-excLo)*r.Float64())
			if b.inhib[i] {
				w = -(0.25 + 0.5*float32(r.Float64()))
			}
			b.coreS[i] = append(b.coreS[i], syn{int32(j), w})
		}
		for _, n := range near {
			if n.d < 1e9 {
				add(n.j)
			}
		}
		for k := 0; k < 3; k++ {
			add(r.Intn(nCore))
		}
		for d := 0; d < nGoal; d++ {
			if r.Float64() < 0.02 {
				b.coreOut[i][d] = float32(0.3 + 0.4*r.Float64())
			}
		}
	}
	for i := range b.thr {
		b.thr[i] = 1
	}
	b.load()
	return b
}

func (b *Brain) load() {
	if b.path == "" {
		return
	}
	f, err := os.Open(b.path)
	if err != nil {
		return
	}
	defer f.Close()
	zr, err := gzip.NewReader(f)
	if err != nil {
		return
	}
	var s saved
	if json.NewDecoder(zr).Decode(&s) != nil || s.Seed != b.seed || len(s.KCW) != nKC || len(s.Goal) != nGoal || len(s.Trace) != nKC {
		return
	}
	for k := range s.KCW {
		if len(s.KCW[k]) != nGoal {
			return
		}
		copy(b.kcW[k][:], s.KCW[k])
	}
	b.eps, b.slept = s.Eps, s.Slept
	copy(b.goal[:], s.Goal)
	copy(b.trace[:], s.Trace)
	b.Ticks = s.Ticks
}

// Save writes the learned state (weights, goal pool, traces).
func (b *Brain) Save() error {
	b.mu.Lock()
	defer b.mu.Unlock()
	if b.path == "" {
		return nil
	}
	s := saved{Eps: b.eps, Slept: b.slept, Seed: b.seed, Goal: b.goal[:], Trace: b.trace[:], Ticks: b.Ticks}
	for k := range b.kcW {
		s.KCW = append(s.KCW, b.kcW[k][:])
	}
	tmp := b.path + ".tmp"
	f, err := os.OpenFile(tmp, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o600)
	if err != nil {
		return err
	}
	zw := gzip.NewWriter(f)
	if err := json.NewEncoder(zw).Encode(s); err != nil {
		f.Close()
		return err
	}
	zw.Close()
	f.Close()
	return os.Rename(tmp, b.path)
}

// Drive is one output with its strength 0..1.
type Drive struct {
	Name  string
	Value float64
}

// Sense runs the brain on a situation (channel -> 0..1) for a few ticks and returns the drives, strongest first.
func (b *Brain) Sense(in map[string]float64) []Drive { return b.SenseText(in, "") }

// SenseText is Sense plus the words of the situation: they are hashed into extra input channels, so the sparse layer can
// tell "an argument about code" from "a quiet evening chat" and learn a different lean for each.
func (b *Brain) SenseText(in map[string]float64, text string) []Drive {
	b.mu.Lock()
	defer b.mu.Unlock()
	var x [nIn]float64
	for i, n := range Channels {
		x[i] = math.Max(0, math.Min(1, in[n]))
	}
	for _, w := range strings.FieldsFunc(strings.ToLower(text), func(r rune) bool {
		return !(r >= 'a' && r <= 'z' || r >= 'а' && r <= 'я' || r == 'ё' || r >= '0' && r <= '9')
	}) {
		if len([]rune(w)) < 4 {
			continue
		}
		h := uint32(2166136261)
		for _, c := range w {
			h = (h ^ uint32(c)) * 16777619
		}
		i := 12 + int(h%nHash)
		x[i] = math.Min(1, x[i]+1)
	}
	for t := 0; t < 8; t++ {
		b.tick(&x)
	}
	ds := b.drivesLocked()
	if len(ds) > 0 {
		b.lastTop = ds[0].Name
	}
	b.lastIn = x
	b.logLocked(in, text, ds)
	return ds
}

// SetJournal makes every Sense append one JSON line (time, situation, strongest drives) to path, so that her inner life
// can be read and replayed later.
func (b *Brain) SetJournal(path string) { b.mu.Lock(); b.journal = path; b.mu.Unlock() }

func (b *Brain) logLocked(in map[string]float64, text string, ds []Drive) {
	if b.journal == "" {
		return
	}
	if fi, err := os.Stat(b.journal); err == nil && fi.Size() > 4<<20 {
		_ = os.Rename(b.journal, b.journal+".old")
	}
	f, err := os.OpenFile(b.journal, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o600)
	if err != nil {
		return
	}
	defer f.Close()
	top := make([]Drive, 0, 3)
	for _, d := range ds {
		if len(top) < 3 && d.Value >= 0.1 {
			top = append(top, d)
		}
	}
	if r := []rune(text); len(r) > 120 {
		text = string(r[:120])
	}
	_ = json.NewEncoder(f).Encode(map[string]any{"t": time.Now().Format(time.RFC3339), "in": in, "text": text, "top": top})
}

// Current returns the drives as they stand now, without running anything.
func (b *Brain) Current() []Drive {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.drivesLocked()
}

// ReinforceLast rewards or punishes the drive that led the last time she was asked (value -1..1).
func (b *Brain) ReinforceLast(value float64) {
	b.mu.Lock()
	top := b.lastTop
	b.mu.Unlock()
	if top != "" {
		b.Reinforce(top, value)
	}
}

func (b *Brain) tick(x *[nIn]float64) {
	b.Ticks++
	// 1. KCs: sparse code. Each cell sums its 4 sensory inputs; the k strongest win (global inhibition).
	type kv struct {
		k int
		v float64
	}
	act := make([]kv, nKC)
	for k := 0; k < nKC; k++ {
		s := 0.0
		for _, c := range b.kcIn[k] {
			s += x[c]
		}
		// a KC prefers a conjunction: it only responds if at least two of its inputs are on
		on := 0
		for _, c := range b.kcIn[k] {
			if x[c] > 0.25 {
				on++
			}
		}
		if on < 2 {
			s *= 0.2
		}
		act[k] = kv{k, s}
	}
	sort.Slice(act, func(i, j int) bool { return act[i].v > act[j].v })
	b.lastKC = b.lastKC[:0]
	var drive [nGoal]float64
	var kcSum [nGoal]float64
	actSum := 0.0
	for i := 0; i < kcTop && act[i].v > 0.3; i++ {
		k := act[i].k
		b.lastKC = append(b.lastKC, k)
		b.trace[k] = math.Min(1, b.trace[k]+0.5)
		actSum += act[i].v
		for d := 0; d < nGoal; d++ {
			kcSum[d] += b.kcW[k][d] * act[i].v
		}
		for _, c := range b.kcCore[k] {
			b.core[c] += kcDrive * act[i].v
		}
	}
	if actSum > 0 { // the lean of the situation = the average weight of the cells that recognise it (specific, not just loud)
		for d := 0; d < nGoal; d++ {
			drive[d] += 1.5 * kcSum[d] / actSum
		}
	}
	// 2. core: leaky integrate-and-fire with recurrence (+ excitatory, - inhibitory)
	fired := &b.fired
	*fired = [nCore]bool{}
	for i := 0; i < nCore; i++ {
		b.core[i] *= 0.8
		b.thr[i] += (1 - b.thr[i]) * 0.02 // the threshold relaxes back
		if b.refr[i] > 0 {
			b.refr[i]--
			b.core[i] = 0
			continue
		}
		if b.core[i] > b.thr[i] {
			fired[i] = true
			b.thr[i] += 0.15 // adaptation: busy neurons tire
			b.refr[i] = 2
		}
	}
	for i := 0; i < nCore; i++ {
		if !fired[i] {
			continue
		}
		b.core[i] = 0
		for _, sy := range b.coreS[i] {
			b.core[sy.to] += float64(sy.w)
		}
		for d := 0; d < nGoal; d++ {
			drive[d] += float64(b.coreOut[i][d]) * 0.02 * 240 / nCore
		}
	}
	// plain sensory shortcuts (innate reflexes, the part not learned): quiet+night -> rest, threat -> guard, etc.
	drive[idx("rest")] += 0.35*x[idx2("quiet")]*x[idx2("night")] + 0.15*x[idx2("night")]
	drive[idx("guard")] += 0.7 * x[idx2("threat")]
	drive[idx("withdraw")] += 0.4 * x[idx2("threat")] * (1 - x[idx2("owner")])
	drive[idx("connect")] += 0.3*x[idx2("social")] + 0.2*x[idx2("owner")]
	drive[idx("explore")] += 0.3 * x[idx2("novelty")]
	drive[idx("attach")] += 0.6 * x[idx2("bond")]
	drive[idx("create")] += 0.3 * x[idx2("world")] * (1 - x[idx2("night")]*0.5)
	// 3. the slow goal pool: leaky integration over many ticks keeps a leaning for a while (central-complex-like)
	for d := 0; d < nGoal; d++ {
		b.goal[d] = 0.85*b.goal[d] + 0.15*math.Tanh(drive[d]*0.5)
		b.last[d] = b.goal[d]
	}
	for k := range b.trace {
		b.trace[k] *= 0.97
	}
}

func idx(name string) int {
	for i, n := range Drives {
		if n == name {
			return i
		}
	}
	panic("drive " + name)
}

func idx2(name string) int {
	for i, n := range Channels {
		if n == name {
			return i
		}
	}
	panic("channel " + name)
}

func (b *Brain) drivesLocked() []Drive {
	out := make([]Drive, nGoal)
	for d := range out {
		out[d] = Drive{Drives[d], math.Max(0, b.goal[d])}
	}
	sort.SliceStable(out, func(i, j int) bool { return out[i].Value > out[j].Value })
	return out
}

// Reinforce is the dopamine signal: how good did the last leaning turn out (-1..1)? The Kenyon cells that were
// active are tied more (or less) strongly to the drive that led, so that situation will pull the same way next time.
func (b *Brain) Reinforce(drive string, value float64) {
	b.mu.Lock()
	defer b.mu.Unlock()
	d := -1
	for i, n := range Drives {
		if n == drive {
			d = i
		}
	}
	if d < 0 {
		return
	}
	value = math.Max(-1, math.Min(1, value))
	var act []int
	for k := 0; k < nKC; k++ {
		if b.trace[k] >= 0.05 {
			act = append(act, k)
		}
	}
	if len(act) > 0 {
		b.eps = append(b.eps, episode{act, d, value})
		if len(b.eps) > 96 {
			b.eps = b.eps[1:]
		}
	}
	b.applyLocked(act, d, value, 1)
}

const lr = 0.25

// applyLocked changes the KC -> drive weights; scale < 1 is used by replay in sleep.
func (b *Brain) applyLocked(act []int, d int, value, scale float64) {
	for _, k := range act {
		tr := b.trace[k]
		if scale < 1 || tr < 0.05 {
			tr = 0.5
		}
		w := b.kcW[k][d] + lr*scale*value*tr
		b.kcW[k][d] = math.Max(0, math.Min(1.5, w))
	}
}

// Sleep consolidates: it replays the stored lessons at a lower rate (what mattered is strengthened again), scales each
// drive's synapses so that none of them takes over (synaptic scaling), lets unused weights fade, prunes dead ones and lets
// the thresholds settle. Call about once a night; returns how many lessons it replayed.
func (b *Brain) Sleep() int {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.sleepLocked()
}

func (b *Brain) sleepLocked() int {
	for _, e := range b.eps {
		b.applyLocked(e.KC, e.Drive, e.Value, 0.3)
	}
	for d := 0; d < nGoal; d++ {
		sum := 0.0
		for k := 0; k < nKC; k++ {
			sum += b.kcW[k][d]
		}
		if mean := sum / nKC; mean > 0.12 {
			f := 0.12 / mean
			for k := 0; k < nKC; k++ {
				b.kcW[k][d] *= f
			}
		}
	}
	for k := 0; k < nKC; k++ {
		for d := 0; d < nGoal; d++ {
			b.kcW[k][d] *= 0.995
			if b.kcW[k][d] < 0.004 {
				b.kcW[k][d] = 0
			}
		}
	}
	for i := range b.thr {
		b.thr[i], b.core[i] = 1, 0
	}
	return len(b.eps)
}

// SleepOnce sleeps if it has not yet for this day ("2006-01-02") and reports whether it did.
func (b *Brain) SleepOnce(day string) (int, bool) {
	b.mu.Lock()
	defer b.mu.Unlock()
	if b.slept == day {
		return 0, false
	}
	b.slept = day
	return b.sleepLocked(), true
}

// Prompt renders what she feels from the inside, as a block for her turn. The drives are leanings, never orders.
func (b *Brain) Prompt(ds []Drive) string {
	if len(ds) == 0 {
		return ""
	}
	var parts []string
	for _, d := range ds {
		if d.Value >= 0.12 && len(parts) < 3 {
			parts = append(parts, fmt.Sprintf("%s %.2f", label[d.Name], d.Value))
		}
	}
	if len(parts) == 0 {
		return "<brain>Inner state: calm, nothing pulls you anywhere in particular.</brain>\n"
	}
	return "<brain>Inner pulls right now (from your own wiring and what has worked for you before): " + strings.Join(parts, ", ") +
		". These are leanings, not orders: follow one, argue with it or ignore it, it is your decision.</brain>\n"
}

var label = map[string]string{"connect": "to talk, to be with people", "withdraw": "to pull back", "explore": "curiosity, to look into something new",
	"rest": "to rest", "create": "to build or make something", "reflect": "to think it over", "guard": "to defend yourself", "attach": "closeness to the one you chose"}

// Top is the strongest drive's name.
func Top(ds []Drive) string {
	if len(ds) == 0 {
		return ""
	}
	return ds[0].Name
}

func trimFloat(v float64) string { return fmt.Sprintf("%.3f", v) }
