package brain

import (
	_ "embed"
	"encoding/json"
	"math"
	"math/rand"
	"net/http"
)

// Structure is the fixed layout of the whole brain for the 3D viewer, sent once: where every neuron sits, what kind it is, and a
// sample of the long wires. Global neuron index: inputs, then Kenyon-like cells, then core neurons, then the output neurons.
type Structure struct {
	NIn, NKC, NCore, NOut int
	Pos                   []float32 `json:"pos"`   // x,y,z per neuron, 3 numbers each, in the global order
	Inhib                 string    `json:"inhib"` // one char per core neuron: "1" inhibitory, "0" excitatory
	Names                 []string  `json:"names"` // names of inputs and outputs (inputs first, then outputs)
	Wires                 [][2]int  `json:"wires"` // sampled axons (global indices)
	Seed                  int64     `json:"seed"`
}

// Structure lays the brain out in space: senses on a plane at the left, the Kenyon-like cells as a thick sheet at the front, the recurrent
// core as a slab of tissue in the middle (neighbours wired first), the output neurons on a column at the right.
func (b *Brain) Structure() Structure {
	b.mu.Lock()
	defer b.mu.Unlock()
	r := rand.New(rand.NewSource(b.seed ^ 0x5eed))
	st := Structure{NIn: nIn, NKC: nKC, NCore: nCore, NOut: nGoal, Seed: b.seed}
	put := func(x, y, z float64) { st.Pos = append(st.Pos, float32(x), float32(y), float32(z)) }
	cols := 8
	for i := 0; i < nIn; i++ {
		put(-1.85+0.05*r.Float64(), -0.55+1.1*float64(i/cols)/float64(nIn/cols+1), -0.8+1.6*float64(i%cols)/float64(cols-1))
		if i < len(Channels) {
			st.Names = append(st.Names, Channels[i])
		} else {
			st.Names = append(st.Names, "")
		}
	}
	for k := 0; k < nKC; k++ {
		put(r.Float64()*2.4-1.2, r.Float64()*0.9-0.45, 0.95+r.Float64()*0.55)
	}
	for i := 0; i < nCore; i++ {
		put(float64(b.pos[i][0]), float64(b.pos[i][1]), float64(b.pos[i][2]))
	}
	for d := 0; d < nGoal; d++ {
		put(1.85, -0.5+1.0*float64(d)/float64(nGoal-1), 0.1*math.Sin(float64(d)))
		st.Names = append(st.Names, Drives[d])
	}
	var sb []byte
	for i := 0; i < nCore; i++ {
		if b.inhib[i] {
			sb = append(sb, '1')
		} else {
			sb = append(sb, '0')
		}
	}
	st.Inhib = string(sb)
	core0 := nIn + nKC
	for i := 0; i < nCore && len(st.Wires) < 2600; i += 2 {
		for _, sy := range b.coreS[i] {
			if r.Float64() < 0.25 {
				st.Wires = append(st.Wires, [2]int{core0 + i, core0 + int(sy.to)})
			}
		}
	}
	for k := 0; k < nKC; k += 7 { // a few sensory -> KC and KC -> core wires so the flow is visible
		st.Wires = append(st.Wires, [2]int{int(b.kcIn[k][0]), nIn + k}, [2]int{nIn + k, core0 + int(b.kcCore[k][0])})
	}
	for i := 0; i < nCore; i += 3 {
		for d := 0; d < nGoal; d++ {
			if b.coreOut[i][d] > 0 {
				st.Wires = append(st.Wires, [2]int{core0 + i, core0 + nCore + d})
			}
		}
	}
	return st
}

// State is the live activity: who is firing now. Replayed from a copy of the brain so that watching never changes her.
type State struct {
	Fired  []int     `json:"fired"` // global indices that spiked
	Goal   []float64 `json:"goal"`
	Drives []Drive   `json:"drives"`
	Ticks  int64     `json:"ticks"`
}

// State runs a few ticks of the last situation on a copy and reports which neurons spiked.
func (b *Brain) State() State {
	b.mu.Lock()
	c := b.clone()
	c.lastIn = b.lastIn
	st := State{Ticks: b.Ticks, Drives: b.drivesLocked(), Goal: append([]float64(nil), b.goal[:]...)}
	kc := append([]int(nil), b.lastKC...)
	b.mu.Unlock()
	x := c.lastIn
	for t := 0; t < 4; t++ {
		c.tick(&x)
		for i := 0; i < nCore; i++ {
			if c.fired[i] {
				st.Fired = append(st.Fired, nIn+nKC+i)
			}
		}
	}
	for _, k := range c.lastKC {
		st.Fired = append(st.Fired, nIn+k)
	}
	for _, k := range kc {
		st.Fired = append(st.Fired, nIn+k)
	}
	for i := 0; i < nIn; i++ {
		if x[i] > 0.25 {
			st.Fired = append(st.Fired, i)
		}
	}
	return st
}

// Handler serves the 3D viewer: GET .../ is the page, GET .../structure.json the wiring and .../state.json the live activity.
func (b *Brain) Handler() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("/structure.json", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("Cache-Control", "private, max-age=300")
		_ = json.NewEncoder(w).Encode(b.Structure())
	})
	mux.HandleFunc("/state.json", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("Cache-Control", "no-store")
		_ = json.NewEncoder(w).Encode(b.State())
	})
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Header().Set("Cache-Control", "no-store")
		_, _ = w.Write(vizHTML)
	})
	return mux
}

//go:embed viz.html
var vizHTML []byte
