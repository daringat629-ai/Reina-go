package mind

import (
	"bufio"
	"encoding/json"
	"io"
	"os"
	"time"
)

// The corpus is every chat answer the teacher has given, in order, kept for good (the memory of episodes forgets; this does not).
// It is the material for the real way out of the API: fine-tuning a model of her own on her own conversations.

type corpusLine struct {
	T     int64  `json:"t"`
	In    string `json:"in"`
	Out   string `json:"out"`
	Owner bool   `json:"owner"`
}

func (m *Mind) appendCorpus(in, out string, owner bool) {
	if m.path == "" {
		return
	}
	f, err := os.OpenFile(m.path+".corpus.jsonl", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o600)
	if err != nil {
		return
	}
	defer f.Close()
	b, _ := json.Marshal(corpusLine{time.Now().Unix(), in, out, owner})
	_, _ = f.Write(append(b, '\n'))
}

// Export writes the corpus as JSONL in the chat fine-tuning format ({"messages":[system,user,assistant]}), one line per answer.
// system is the character prompt (may be empty); ownerOnly keeps only the talks with the owner. It returns how many lines it wrote.
func (m *Mind) Export(w io.Writer, system string, ownerOnly bool) int {
	m.mu.Lock()
	path := m.path
	m.mu.Unlock()
	if path == "" {
		return 0
	}
	f, err := os.Open(path + ".corpus.jsonl")
	if err != nil {
		return 0
	}
	defer f.Close()
	sc := bufio.NewScanner(f)
	sc.Buffer(make([]byte, 1<<20), 1<<20)
	n := 0
	for sc.Scan() {
		var l corpusLine
		if json.Unmarshal(sc.Bytes(), &l) != nil || l.In == "" || l.Out == "" || (ownerOnly && !l.Owner) {
			continue
		}
		msgs := []map[string]string{}
		if system != "" {
			msgs = append(msgs, map[string]string{"role": "system", "content": system})
		}
		msgs = append(msgs, map[string]string{"role": "user", "content": l.In}, map[string]string{"role": "assistant", "content": l.Out})
		b, _ := json.Marshal(map[string]any{"messages": msgs})
		_, _ = w.Write(append(b, '\n'))
		n++
	}
	return n
}

// Demote is the owner's verdict "this answer is bad": the habit that gave it loses its right to answer alone and must pass its
// exams again, and the answer is never said alone again. in is the situation text; it returns whether a habit was found.
func (m *Mind) Demote(in string) bool {
	m.mu.Lock()
	defer m.mu.Unlock()
	v := vec(in)
	var best *episode
	bs := 0.0
	for _, e := range m.eps {
		if e.Tool {
			continue
		}
		if s := cos(v, e.vec); s > bs {
			bs, best = s, e
		}
	}
	if best == nil || bs < .5 {
		return false
	}
	if c := m.cl[best.Cl]; c != nil {
		c.Grad, c.Hit, c.N = false, .2, 0
	}
	m.banned = append(m.banned, best.Out)
	if len(m.banned) > 200 {
		m.banned = m.banned[1:]
	}
	return true
}
