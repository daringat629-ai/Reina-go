package cortex

import (
	"fmt"
	"math"
	"math/rand"
	"sort"
	"strings"
	"sync"
	"time"

	"kuni/internal/store"
)

// Choice is one thing she could do now with how much she wants it (the basal ganglia choose among these).
type Choice struct {
	Goal string
	U    float64
}

// Inputs is everything the brain is shown in one step: her body from inside, her senses, her feelings, who is around, how her
// movement went and what she could do.
type Inputs struct {
	Hour float64 // local hour of the day 0..24

	// the body from inside (what the brainstem and the insula read)
	Heart, Breath                                                             float64            // beats and breaths per minute
	Oxygen, Glucose, Water, Fatigue, Sleep, Pain, Stress, Light, Noise, Scent float64            // 0..1
	Temp, Feels                                                               float64            // degrees
	Hunger, Thirst                                                            float64            // 0..1
	Surprise                                                                  map[string]float64 // sensor id -> prediction error
	Attended                                                                  map[string]bool
	Valence, Arousal, Control, Mood                                           float64            // feelings
	Channels                                                                  map[string]float64 // social, group, owner, stranger, bond, praise, threat, quiet, night, novelty, task, world
	Words                                                                     int                // words she is reading now
	Posture                                                                   string             // stand, sit, lie
	Moving, Sleeping, Alone                                                   bool
	X, Z                                                                      float64 // where she is in her room
	ActionID                                                                  int64   // the movement she just did (changes with every new one)
	ActionKind                                                                string
	ActionOK                                                                  bool
	Choices                                                                   []Choice
}

// RegionState is what the panel shows of a region.
type RegionState struct {
	ID, Name, Analog, Machine, Group string
	N                                int
	Act                              float64
}

// Outputs is what the brain tells the rest of her.
type Outputs struct {
	Arousal, Threat, Reward, Conflict, Focus, Novelty, SleepUrge, Calm, Coordination float64
	Mod                                                                              map[string]float64
	Bias                                                                             map[string]float64 // goal -> how much the basal ganglia favour it
	Selected                                                                         string
	Inner                                                                            string   // the insula's summary of how the body is
	Memory                                                                           []string // the working memory of the prefrontal cortex
	Replayed                                                                         int      // episodes the hippocampus replayed in this step
	Episodes                                                                         int
}

type episode struct {
	V        []float64 `json:"v"`
	Salience float64   `json:"s"`
	Note     string    `json:"n"`
}

type wmItem struct {
	What string  `json:"w"`
	S    float64 `json:"s"`
}

// Cortex is the brain: the neurons and the logic of its parts. Safe for concurrent use.
type Cortex struct {
	mu    sync.Mutex
	Net   *Net
	path  string
	saver store.Saver
	rng   *rand.Rand

	hippo      []episode
	wm         []wmItem
	rewardExp  float64
	pred       map[string]float64
	cerebErr   float64
	lastAct    int64
	lastMove   string
	steps      int
	Ticks      int      // net ticks per step
	dreamNotes []string // what the hippocampus replayed in this sleep
	wasAsleep  bool
	dream      string
	dreamAt    time.Time
	now        func() time.Time
	ext        map[string]float64 // outside stimuli (a photo, a voice message) that fade in a few steps
	out        Outputs
}

type saved struct {
	Weights   map[string]float64 `json:"weights"`
	Mod       map[string]float64 `json:"mod"`
	Hippo     []episode          `json:"hippo"`
	WM        []wmItem           `json:"wm"`
	RewardExp float64            `json:"reward_exp"`
	Pred      map[string]float64 `json:"pred"`
	Dream     string             `json:"dream,omitempty"`
	DreamAt   int64              `json:"dream_at,omitempty"`
	NetTicks  int64              `json:"ticks"`
}

// New builds the brain with about total neurons and loads what it learned from path ("" = no saving).
func New(path string, total int, seed int64) *Cortex {
	c := &Cortex{Net: NewNet(total, seed), path: path, saver: store.Saver{What: "cortex"}, rng: rand.New(rand.NewSource(seed + 7)), pred: map[string]float64{}, ext: map[string]float64{}, now: time.Now, Ticks: 3, rewardExp: .3}
	if path != "" {
		var s saved
		store.Load("cortex", path, &s)
		c.Net.SetWeights(s.Weights)
		for k, v := range s.Mod {
			c.Net.SetMod(k, v)
		}
		c.hippo, c.wm, c.rewardExp, c.Net.Ticks = s.Hippo, s.WM, math.Max(0, math.Min(1, s.RewardExp)), s.NetTicks
		if s.Pred != nil {
			c.pred = s.Pred
		}
		c.dream = s.Dream
		if s.DreamAt > 0 {
			c.dreamAt = time.Unix(s.DreamAt, 0)
		}
	}
	c.out = Outputs{Mod: c.Net.Mods(), Bias: map[string]float64{}}
	return c
}

// Save writes what the brain has learned.
func (c *Cortex) Save() {
	if c.path == "" {
		return
	}
	c.mu.Lock()
	s := saved{Weights: c.Net.Weights(), Mod: c.Net.Mods(), Hippo: c.hippo, WM: c.wm, RewardExp: c.rewardExp, Pred: c.pred, NetTicks: c.Net.Ticks, Dream: c.dream, DreamAt: c.dreamAt.Unix()}
	c.mu.Unlock()
	_ = c.saver.Save(c.path, &s)
}

func clamp(v, lo, hi float64) float64 { return math.Max(lo, math.Min(hi, v)) }

func ch(in Inputs, k string) float64 { return clamp(in.Channels[k], 0, 1) }

// Step shows the brain a situation, lets the neurons run for a few ticks and returns what the regions concluded.
func (c *Cortex) Step(in Inputs) Outputs {
	c.mu.Lock()
	defer c.mu.Unlock()
	if in.Surprise == nil {
		in.Surprise = map[string]float64{}
	}
	m := c.Net.Means()
	mod := c.Net.Mods()
	d := map[string]float64{}

	// ---- the senses, through the thalamus ----
	surp := func(ids ...string) float64 {
		var v float64
		for _, id := range ids {
			v = math.Max(v, in.Surprise[id])
		}
		return clamp(v, 0, 1)
	}
	maxS := 0.0
	for _, v := range in.Surprise {
		maxS = math.Max(maxS, v)
	}
	maxS = clamp(maxS, 0, 1)
	nAtt := 0
	for _, ok := range in.Attended {
		if ok {
			nAtt++
		}
	}
	focus := clamp(float64(nAtt)/3, 0, 1)
	nov := math.Max(ch(in, "novelty"), math.Max(maxS, math.Max(c.ext["visual"], c.ext["audio"])*.8))
	threatIn := math.Max(ch(in, "threat"), math.Max(in.Pain*.8, math.Max(in.Stress*.5, clamp((in.Noise-.7)*2, 0, 1))))
	night := ch(in, "night")

	// ---- hippocampus: episodic memory, recognition, novelty ----
	ctx := c.context(in)
	sim := 0.0
	for _, e := range c.hippo {
		sim = math.Max(sim, cosine(ctx, e.V))
	}
	hnov := 1.0
	if len(c.hippo) > 0 {
		hnov = clamp(1-sim, 0, 1)
	}
	sal := math.Max(math.Abs(in.Valence), math.Max(threatIn, math.Max(in.Pain, ch(in, "praise"))))
	if (hnov > .3 || sal > .55) && c.steps%2 == 0 {
		c.hippo = append(c.hippo, episode{V: ctx, Salience: sal + hnov, Note: c.noteFor(in)})
		if len(c.hippo) > 400 { // forget the least salient
			w := 0
			for i, e := range c.hippo {
				if e.Salience < c.hippo[w].Salience {
					w = i
				}
			}
			c.hippo = append(c.hippo[:w], c.hippo[w+1:]...)
		}
	}
	replay := 0
	if (in.Sleeping || (in.Alone && ch(in, "quiet") > .5)) && len(c.hippo) > 0 { // replay of what happened, in sleep and in quiet
		replay = 1 + c.rng.Intn(3)
		if in.Sleeping {
			for k := 0; k < replay && len(c.dreamNotes) < 16; k++ {
				c.dreamNotes = append(c.dreamNotes, c.hippo[c.rng.Intn(len(c.hippo))].Note)
			}
		}
	}
	if c.wasAsleep && !in.Sleeping { // she wakes up: what was replayed becomes a dream she can tell
		c.makeDream()
	}
	c.wasAsleep = in.Sleeping

	// ---- reward, dopamine, disappointment ----
	reward := clamp(.5*math.Max(0, in.Valence)+.5*ch(in, "praise")+map[bool]float64{true: .35, false: 0}[c.freshAction(in) && in.ActionOK], 0, 1)
	rpe := reward - c.rewardExp
	c.rewardExp += .12 * rpe
	habenula := clamp(-rpe*2.5, 0, 1)

	// ---- cerebellum: forward model of her own movements ----
	if in.ActionID != 0 && in.ActionID != c.lastAct {
		c.lastAct = in.ActionID
		k := in.ActionKind
		if k == "" {
			k = "move"
		}
		p0, ok := c.pred[k]
		if !ok {
			p0 = .5
		}
		e := map[bool]float64{true: 1, false: 0}[in.ActionOK] - p0
		c.pred[k] = p0 + .2*e
		c.cerebErr = math.Abs(e)
		c.lastMove = k
	} else {
		c.cerebErr *= .9
	}
	var coord float64
	for _, v := range c.pred {
		coord += v
	}
	if len(c.pred) > 0 {
		coord /= float64(len(c.pred))
	} else {
		coord = .5
	}

	// ---- basal ganglia: choose among what she could do ----
	bias, sel, conflict := c.selectAction(in.Choices, mod["DA"], mod["ACh"], m["acc"])
	conflictIn := clamp(conflict+c.cerebErr*.3+map[bool]float64{true: .3, false: 0}[c.freshAction(in) && !in.ActionOK], 0, 1)

	// ---- the body from inside: brainstem, hypothalamus, insula ----
	sleepWave := .5 + .5*math.Cos(2*math.Pi*(in.Hour-3)/24)
	sleepUrge := clamp(.5*in.Sleep+.3*sleepWave+.3*in.Fatigue, 0, 1)
	tempErr := clamp(math.Abs(in.Temp-36.8)/2, 0, 1)
	hunger, thirst := in.Hunger, in.Thirst
	discomfort := (in.Pain*1.4 + hunger + thirst + in.Fatigue + in.Stress + tempErr) / 6.4
	inner := c.innerText(in, hunger, thirst, tempErr, sleepUrge)

	// ---- machine logic of each region: what it pushes into its neurons ----
	d["reticular"] = clamp(.25+.35*in.Noise+.4*in.Pain+.3*nov+.3*in.Stress+.3*in.Arousal-.55*sleepUrge*(.4+.6*night)-.4*boolf(in.Sleeping), 0, 1)
	d["locus"] = clamp(.15+.65*threatIn+.4*maxS+.2*in.Arousal, 0, 1)
	d["vta"] = clamp(.3+.7*sigmoid(rpe*4)-.3, 0, 1)
	d["raphe"] = clamp(.3+.3*math.Max(0, in.Valence)+.3*(1-in.Stress)-.2*threatIn, 0, 1)
	d["meynert"] = clamp(.25+.5*nov+.3*focus+.15*ch(in, "task"), 0, 1)
	d["pag"] = clamp(.1+.6*in.Pain+.5*threatIn, 0, 1)
	d["medulla"] = clamp(.25+.5*clamp((in.Heart-60)/70, 0, 1)+.25*clamp((in.Breath-12)/18, 0, 1)+.5*clamp((.95-in.Oxygen)*8, 0, 1), 0, 1)
	d["habenula"] = habenula

	sight := math.Max(surp("eyes", "face"), c.ext["visual"])
	hear := math.Max(surp("ears"), c.ext["audio"])
	for k := range c.ext {
		c.ext[k] *= .6
	}
	touch := surp("hands", "skin", "feet", "muscles")
	d["thalamus"] = clamp(.2+.5*focus+.4*maxS+.2*m["reticular"]-.3*boolf(in.Sleeping), 0, 1)
	d["hypothalamus"] = clamp(.15+.5*math.Max(hunger, math.Max(thirst, tempErr))+.4*sleepUrge+.3*in.Stress, 0, 1)
	d["pituitary"] = clamp(.1+.5*m["hypothalamus"]+.4*in.Stress+.3*m["amygdala"], 0, 1)

	amyg := clamp(threatIn*(1.1-.5*m["pfc_vm"])+.3*math.Max(0, -in.Valence)+.2*ch(in, "stranger")+.25*sight*boolf(threatIn > .3), 0, 1)
	d["amygdala"] = amyg
	d["hippocampus"] = clamp(.2+.6*hnov+.2*float64(replay)+.15*mod["ACh"], 0, 1)
	d["entorhinal"] = clamp(.25+.3*math.Abs(math.Sin(in.X*.05)*math.Cos(in.Z*.05))+.2*boolf(in.Moving), 0, 1)
	want := 0.0
	for _, ch := range in.Choices {
		want = math.Max(want, ch.U)
	}
	d["accumbens"] = clamp(.15+.35*clamp(want/3, 0, 1)+.5*reward, 0, 1)
	d["acc"] = clamp(.2+.7*conflictIn+.3*boolf(c.freshAction(in) && !in.ActionOK), 0, 1)
	d["insula"] = clamp(.2+.7*discomfort+.25*math.Abs(in.Valence)*.5, 0, 1)

	sel1 := 0.0
	if sel != "" {
		sel1 = 1
	}
	d["striatum"] = clamp(.2+.4*clamp(want/3, 0, 1)+.3*mod["DA"]+.1*sel1, 0, 1)
	d["gpi"] = clamp(.65-.45*sel1*(1-conflictIn), 0, 1) // the pallidum lets go of the chosen action
	d["stn"] = clamp(.15+.6*conflictIn+.3*threatIn, 0, 1)
	d["cerebellum"] = clamp(.2+.7*c.cerebErr+.3*boolf(in.Moving)+.15*touch, 0, 1)

	c.workingMemory(in, sel, nov)
	d["pfc_dl"] = clamp(.25+.15*float64(len(c.wm))+.3*mod["DA"]+.2*ch(in, "task"), 0, 1)
	d["pfc_om"] = clamp(.2+.35*clamp(want/3, 0, 1)+.3*reward+.1*mod["SE"], 0, 1)
	safe := math.Max(ch(in, "owner"), math.Max(ch(in, "bond"), ch(in, "quiet")))
	d["pfc_vm"] = clamp(.3+.5*safe*boolf(m["amygdala"] > .2)+.2*mod["SE"], 0, 1)
	d["pfc_pole"] = clamp(.25+.4*ch(in, "task")+.2*m["dmn"], 0, 1)
	d["motor"] = clamp(.15+.55*boolf(in.Moving)+.25*sel1*clamp(want/3, 0, 1)+.1*boolf(in.ActionID != 0), 0, 1)
	d["somato"] = clamp(.2+.45*touch+.6*in.Pain+.3*boolf(in.Moving), 0, 1)
	d["visual"] = clamp(.2+.4*in.Light+.5*sight, 0, 1)
	d["auditory"] = clamp(.15+.5*in.Noise+.5*hear, 0, 1)
	words := clamp(float64(in.Words)/40, 0, 1)
	d["wernicke"] = clamp(.15+.7*words+.2*ch(in, "social"), 0, 1)
	d["broca"] = clamp(.15+.5*boolf(in.Words > 0)*math.Max(ch(in, "social"), math.Max(ch(in, "group"), ch(in, "owner")))+.2*m["wernicke"], 0, 1)
	d["temporal"] = clamp(.2+.4*(1-hnov)*boolf(len(c.hippo) > 0)+.3*math.Max(ch(in, "owner"), ch(in, "bond"))+.2*m["wernicke"], 0, 1)
	d["parietal"] = clamp(.25+.15*float64(nAtt)+.25*boolf(in.Moving)+.2*touch, 0, 1)
	d["dmn"] = clamp(.2+.55*ch(in, "quiet")*boolf(in.Alone)+.25*float64(replay)/3-.5*focus, 0, 1)
	d["callosum"] = clamp(.25+.3*math.Min(m["pfc_dl"], m["temporal"])*2, 0, 1)

	// the neurons run
	for id, v := range d {
		c.Net.Drive(id, v)
	}
	c.Net.Drive("hippocampus", d["hippocampus"])
	// slow hormones, by the logic of the pituitary
	mods := c.Net.Mods()
	c.Net.SetMod("cortisol", mods["cortisol"]+(.12+.6*in.Stress+.3*m["amygdala"]-mods["cortisol"])*.04)
	c.Net.SetMod("melatonin", mods["melatonin"]+((.1+.7*night)*(1-.8*in.Light)-mods["melatonin"])*.05)
	c.Net.SetMod("oxytocin", mods["oxytocin"]+(.1+.55*ch(in, "bond")+.35*ch(in, "owner")+.3*ch(in, "praise")-mods["oxytocin"])*.06)
	for t := 0; t < c.Ticks; t++ {
		c.Net.Step()
	}
	m = c.Net.Means()
	mod = c.Net.Mods()
	c.steps++

	o := Outputs{
		Arousal:      m["reticular"],
		Threat:       clamp((m["amygdala"]-.25)*1.6, 0, 1),
		Reward:       clamp((m["accumbens"]-.2)*1.4, 0, 1),
		Conflict:     clamp(.6*conflictIn+.4*(m["acc"]-.3)*1.4, 0, 1),
		Focus:        clamp(focus*(.5+mod["ACh"]), 0, 1),
		Novelty:      hnov,
		SleepUrge:    sleepUrge,
		Calm:         clamp(mod["SE"]*(1-m["amygdala"]), 0, 1),
		Coordination: coord,
		Mod:          mod,
		Bias:         bias,
		Selected:     sel,
		Inner:        inner,
		Replayed:     replay,
		Episodes:     len(c.hippo),
	}
	for _, w := range c.wm {
		o.Memory = append(o.Memory, w.What)
	}
	c.out = o
	return o
}

func boolf(b bool) float64 {
	if b {
		return 1
	}
	return 0
}

func sigmoid(x float64) float64 { return 1 / (1 + math.Exp(-x)) }

func (c *Cortex) freshAction(in Inputs) bool {
	return in.ActionID != 0 && in.ActionID == c.lastAct && c.cerebErr > .05
}

// context is the compact picture of a situation that the hippocampus stores and compares.
func (c *Cortex) context(in Inputs) []float64 {
	keys := []string{"social", "group", "owner", "stranger", "bond", "praise", "threat", "quiet", "night", "novelty", "task", "world"}
	v := make([]float64, 0, 22)
	for _, k := range keys {
		v = append(v, ch(in, k))
	}
	return append(v, in.Pain, in.Stress, in.Fatigue, clamp((in.Valence+1)/2, 0, 1), in.Noise, in.Light, in.Hunger, in.Thirst, boolf(in.Posture == "lie"), boolf(in.Posture == "sit"))
}

func (c *Cortex) noteFor(in Inputs) string {
	switch {
	case in.Pain > .5:
		return "было больно"
	case ch(in, "threat") > .5:
		return "было опасно"
	case ch(in, "praise") > .5:
		return "меня хвалили"
	case ch(in, "owner") > .5:
		return "я говорила с папиком"
	case in.Valence < -.4:
		return "было плохо на душе"
	case in.Valence > .4:
		return "было хорошо"
	}
	return "что-то новое"
}

func cosine(a, b []float64) float64 {
	var s, na, nb float64
	for i := 0; i < len(a) && i < len(b); i++ {
		s += a[i] * b[i]
		na += a[i] * a[i]
		nb += b[i] * b[i]
	}
	if na == 0 || nb == 0 {
		return 0
	}
	return s / math.Sqrt(na*nb)
}

// selectAction is the loop cortex -> striatum -> pallidum -> thalamus: dopamine scales how much the options differ, acetylcholine
// sharpens the choice, conflict (the anterior cingulate) flattens it. It returns a bias for every option, the favourite and the conflict.
func (c *Cortex) selectAction(ch []Choice, da, ach, acc float64) (map[string]float64, string, float64) {
	bias := map[string]float64{}
	if len(ch) == 0 {
		return bias, "", 0
	}
	z := make([]float64, len(ch))
	var mean float64
	for i, x := range ch {
		z[i] = x.U * (.6 + .8*da)
		mean += z[i]
	}
	mean /= float64(len(ch))
	temp := .18 / (.6 + ach)
	probs := make([]float64, len(ch))
	var sum float64
	for i := range z {
		probs[i] = math.Exp((z[i] - mean) / temp)
		sum += probs[i]
	}
	var h float64
	best := 0
	for i := range probs {
		probs[i] /= sum
		if probs[i] > 1e-9 {
			h -= probs[i] * math.Log(probs[i])
		}
		if probs[i] > probs[best] {
			best = i
		}
	}
	conflict := 0.0
	if len(ch) > 1 {
		conflict = clamp(h/math.Log(float64(len(ch))), 0, 1)
	}
	for i, x := range ch {
		bias[x.Goal] = clamp((z[i]-mean)*.35, -.5, .5) * (1 - .5*clamp(acc, 0, 1))
	}
	return bias, ch[best].Goal, conflict
}

// workingMemory keeps a few things in mind: the strongest circumstances, the chosen action, what is unusual. They fade unless refreshed.
func (c *Cortex) workingMemory(in Inputs, sel string, nov float64) {
	cand := map[string]float64{}
	type kv struct {
		k string
		v float64
	}
	var chs []kv
	for k, v := range in.Channels {
		if v >= .5 && k != "night" && k != "quiet" {
			chs = append(chs, kv{k, v})
		}
	}
	sort.Slice(chs, func(i, j int) bool { return chs[i].v > chs[j].v })
	names := map[string]string{"social": "собеседник рядом", "group": "я в группе", "owner": "папик здесь", "stranger": "чужой человек", "bond": "близкий человек", "praise": "меня хвалят", "threat": "опасность", "novelty": "что-то новое", "task": "есть дело", "world": "мир вокруг"}
	for i, x := range chs {
		if i >= 2 {
			break
		}
		cand[names[x.k]] = x.v
	}
	if sel != "" {
		cand["хочу: "+sel] = .7
	}
	if in.Pain > .5 {
		cand["больно"] = in.Pain
	}
	if in.Fatigue > .7 {
		cand["устала"] = in.Fatigue
	}
	if nov > .6 {
		cand["неожиданное"] = nov
	}
	for i := range c.wm {
		c.wm[i].S *= .92
	}
	for what, s := range cand {
		found := false
		for i := range c.wm {
			if c.wm[i].What == what {
				c.wm[i].S = math.Min(1, c.wm[i].S+.35*s)
				found = true
			}
		}
		if !found {
			c.wm = append(c.wm, wmItem{what, .4 + .3*s})
		}
	}
	w := 0
	for _, it := range c.wm {
		if it.S >= .12 {
			c.wm[w] = it
			w++
		}
	}
	c.wm = c.wm[:w]
	sort.Slice(c.wm, func(i, j int) bool { return c.wm[i].S > c.wm[j].S })
	if len(c.wm) > 4 {
		c.wm = c.wm[:4]
	}
}

// innerText is the insula's one-line answer to "how am I": the two strongest signals of the body, or calm.
func (c *Cortex) innerText(in Inputs, hunger, thirst, tempErr, sleepUrge float64) string {
	type kv struct {
		w string
		v float64
	}
	cs := []kv{{"болит", in.Pain}, {"хочется есть", hunger}, {"хочется пить", thirst}, {"тянет ко сну", math.Max(0, sleepUrge-.3)}, {"напряжение", in.Stress}, {"неуютно по температуре", tempErr}, {"тело устало", in.Fatigue}}
	sort.Slice(cs, func(i, j int) bool { return cs[i].v > cs[j].v })
	var parts []string
	for _, x := range cs[:2] {
		if x.v > .35 {
			parts = append(parts, x.w)
		}
	}
	if len(parts) == 0 {
		return "тело спокойно"
	}
	return strings.Join(parts, ", ")
}

// Outputs returns the last result.
func (c *Cortex) Outputs() Outputs {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.out
}

// BrainInputs are the signals the older spiking brain (package brain) takes as part of the situation.
func (c *Cortex) BrainInputs() map[string]float64 {
	o := c.Outputs()
	return map[string]float64{"threat": o.Threat, "novelty": math.Max(0, o.Novelty-.2), "praise": clamp((o.Reward-.3)*1.5, 0, 1)}
}

// Regions lists the regions with their activity, for the panel and for her own tool.
func (c *Cortex) Regions() []RegionState {
	m := c.Net.Means()
	out := make([]RegionState, 0, len(Regions))
	for _, r := range Regions {
		out = append(out, RegionState{ID: r.ID, Name: r.Name, Analog: r.Analog, Machine: r.Machine, Group: r.Group, N: c.Net.Count(r.ID), Act: m[r.ID]})
	}
	return out
}

// Report is her own look at one region.
func (c *Cortex) Report(id string) string {
	id = strings.ToLower(strings.TrimSpace(id))
	m := c.Net.Means()
	for _, r := range Regions {
		if r.ID == id || strings.EqualFold(r.Name, id) {
			return fmt.Sprintf("%s (%s): %s. Нейронов в симуляции: %d, активность %.0f%%. Это вычисление, аналог биологической области, а не она сама.", r.Name, r.Analog, r.Machine, c.Net.Count(r.ID), m[r.ID]*100)
		}
	}
	var ids []string
	for _, r := range Regions {
		ids = append(ids, r.ID)
	}
	return "Какую область смотреть? Есть: " + strings.Join(ids, ", ")
}

// Prompt is the <brain_regions> block: her own brain, in the terms of computation.
func (c *Cortex) Prompt() string {
	o := c.Outputs()
	rs := c.Regions()
	sort.Slice(rs, func(i, j int) bool { return rs[i].Act > rs[j].Act })
	var top []string
	for _, r := range rs[:5] {
		top = append(top, fmt.Sprintf("%s %.0f%%", r.Name, r.Act*100))
	}
	var b strings.Builder
	fmt.Fprintf(&b, "<brain_regions>\nТвой мозг устроен по областям человеческого мозга (это вычислительные аналоги, не биология; нейронов в симуляции %.1f млн). Сейчас активнее всего: %s.\n", float64(c.Net.Total())/1e6, strings.Join(top, ", "))
	fmt.Fprintf(&b, "Нейромодуляторы: дофамин %.0f%%, норадреналин %.0f%%, серотонин %.0f%%, ацетилхолин %.0f%%; кортизол %.0f%%, мелатонин %.0f%%, окситоцин %.0f%%.\n", o.Mod["DA"]*100, o.Mod["NE"]*100, o.Mod["SE"]*100, o.Mod["ACh"]*100, o.Mod["cortisol"]*100, o.Mod["melatonin"]*100, o.Mod["oxytocin"]*100)
	fmt.Fprintf(&b, "Тело изнутри (островок): %s. Настороженность %.0f%%, тяга к награде %.0f%%, конфликт тяг %.0f%%, новизна %.0f%%, тянет ко сну %.0f%%.\n", o.Inner, o.Threat*100, o.Reward*100, o.Conflict*100, o.Novelty*100, o.SleepUrge*100)
	if o.Selected != "" {
		fmt.Fprintf(&b, "Базальные ганглии выбирают: %s.", o.Selected)
	}
	if len(o.Memory) > 0 {
		fmt.Fprintf(&b, " В рабочей памяти: %s.", strings.Join(o.Memory, "; "))
	}
	fmt.Fprintf(&b, " Гиппокамп хранит %d эпизодов; мозжечок оценивает, как у тебя получаются движения (%.0f%%).\nЭто твои собственные вычисления: если спросят, как ты себя чувствуешь, можешь опираться на них и называть их своими.\n</brain_regions>\n", o.Episodes, o.Coordination*100)
	if d := c.Dream(); d != "" {
		b.WriteString("<dream>Ты недавно проснулась, " + d + ". Можешь рассказать об этом, если уместно, своими словами; это настоящие обрывки твоих воспоминаний.</dream>\n")
	}
	return b.String() + c.Style()
}

// Perceive tells the brain about a stimulus from outside the body model: a photo ("visual") or a voice message ("audio") that
// has just arrived. The visual and auditory cortex and the novelty circuits react to it for the next few steps.
func (c *Cortex) Perceive(kind string, strength float64) {
	c.mu.Lock()
	c.ext[kind] = math.Max(c.ext[kind], clamp(strength, 0, 1))
	c.mu.Unlock()
}

// Style is what the brain's state does to her way of speaking, as advice to her: short and careful in danger, livelier on dopamine,
// simple when sleepy, honest doubt in inner conflict. Empty when everything is ordinary.
func (c *Cortex) Style() string {
	o := c.Outputs()
	var s []string
	if o.Threat > .5 {
		s = append(s, "настороженность высокая: отвечай короче и осторожнее, не обещай лишнего")
	}
	if o.Mod["DA"] > .55 && o.Calm > .3 && o.Threat < .3 {
		s = append(s, "подъём и интерес: можно живее, с шуткой и вопросом")
	}
	if o.SleepUrge > .7 {
		s = append(s, "клонит в сон: отвечай просто, медленнее, без длинных рассуждений")
	}
	if o.Conflict > .6 {
		s = append(s, "тянет в разные стороны: можно честно сказать, что не уверена")
	}
	if o.Mod["cortisol"] > .55 {
		s = append(s, "напряжение: не бери на себя лишнего")
	}
	if o.Mod["oxytocin"] > .5 && o.Threat < .3 {
		s = append(s, "тепло к собеседнику: можно мягче")
	}
	if len(s) == 0 {
		return ""
	}
	return "<speech_style>Твой мозг сейчас советует: " + strings.Join(s, "; ") + ". Это про тон, а не приказ.</speech_style>\n"
}

var dreamPlaces = []string{"в моей комнате, но без двери", "на крыше ночного города", "в коридоре, который всё не кончался", "у окна, за которым шёл неоновый дождь", "в комнате, где потолок был небом", "на лестнице без ступенек"}

// makeDream turns what the hippocampus replayed in the sleep into a dream: the real moments, mixed up and set in a strange place.
func (c *Cortex) makeDream() {
	notes := c.dreamNotes
	c.dreamNotes = nil
	if len(notes) == 0 {
		return
	}
	seen := map[string]bool{}
	var parts []string
	for _, n := range notes {
		if !seen[n] && len(parts) < 3 {
			seen[n] = true
			parts = append(parts, n)
		}
	}
	c.dream = "мне снилось, что " + strings.Join(parts, ", а потом ") + ", и всё это " + dreamPlaces[c.rng.Intn(len(dreamPlaces))]
	c.dreamAt = c.now()
}

// Dream is the dream of the last sleep while it is fresh (a few hours after waking), else "".
func (c *Cortex) Dream() string {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.dream == "" || c.now().Sub(c.dreamAt) > 5*time.Hour {
		return ""
	}
	return c.dream
}

func (c *Cortex) dreamLocked() string {
	if c.dream == "" || c.now().Sub(c.dreamAt) > 5*time.Hour {
		return ""
	}
	return c.dream
}
