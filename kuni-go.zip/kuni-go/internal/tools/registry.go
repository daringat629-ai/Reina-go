// Package tools is the registry of LLM-callable tools (port of OpenAITools and src/tools/).
package tools

import (
	"context"
	"encoding/json"
	"fmt"
	"sort"
	"strconv"
	"strings"
	"sync"

	"kuni/internal/llm"
)

// Prop describes one tool argument. Like the C++ version (OpenAI strict mode),
// every property is "required" and optional ones are Nullable.
type Prop struct {
	Name, Type, Desc string
	Nullable         bool
}

// Args are decoded tool arguments with lenient accessors (models send "123" for 123).
type Args map[string]any

func (a Args) Has(k string) bool { v, ok := a[k]; return ok && v != nil }

func (a Args) Str(k string) string {
	switch v := a[k].(type) {
	case string:
		return v
	case nil:
		return ""
	default:
		return fmt.Sprint(v)
	}
}

func (a Args) Int(k string) int64 {
	switch v := a[k].(type) {
	case float64:
		return int64(v)
	case string:
		n, _ := strconv.ParseInt(strings.TrimSpace(v), 10, 64)
		return n
	}
	return 0
}

func (a Args) Bool(k string) bool {
	switch v := a[k].(type) {
	case bool:
		return v
	case string:
		return v == "true"
	}
	return false
}

type Tool struct {
	Name        string
	Description string
	Props       []Prop
	Run         func(ctx context.Context, a Args) (string, error)
}

// Schema renders the JSON schema for the tool's parameters.
func (t Tool) Schema() map[string]any {
	props := map[string]any{}
	required := []string{}
	for _, p := range t.Props {
		var typ any = p.Type
		if p.Nullable {
			typ = []string{p.Type, "null"}
		}
		props[p.Name] = map[string]any{"type": typ, "description": p.Desc}
		required = append(required, p.Name)
	}
	return map[string]any{"type": "object", "properties": props, "required": required, "additionalProperties": false}
}

type Registry struct {
	mu    sync.RWMutex
	tools map[string]Tool
}

func NewRegistry(ts ...Tool) *Registry {
	r := &Registry{tools: map[string]Tool{}}
	r.Add(ts...)
	return r
}

func (r *Registry) Add(ts ...Tool) {
	r.mu.Lock()
	defer r.mu.Unlock()
	for _, t := range ts {
		r.tools[t.Name] = t
	}
}

func (r *Registry) Has(name string) bool {
	r.mu.RLock()
	defer r.mu.RUnlock()
	_, ok := r.tools[name]
	return ok
}

// Get returns a tool by name.
func (r *Registry) Get(name string) (Tool, bool) {
	r.mu.RLock()
	defer r.mu.RUnlock()
	t, ok := r.tools[name]
	return t, ok
}

func (r *Registry) Names() []string {
	r.mu.RLock()
	defer r.mu.RUnlock()
	var out []string
	for n := range r.tools {
		out = append(out, n)
	}
	sort.Strings(out)
	return out
}

// Defs returns OpenAI tool definitions sorted by name (stable prompts).
func (r *Registry) Defs() []llm.ToolDef {
	r.mu.RLock()
	defer r.mu.RUnlock()
	var out []llm.ToolDef
	for _, t := range r.tools {
		out = append(out, llm.ToolDef{Type: "function", Function: llm.ToolFunc{Name: t.Name, Description: t.Description, Parameters: t.Schema()}})
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Function.Name < out[j].Function.Name })
	return out
}

// Call runs a tool. Errors never escape: they are returned as "Error: …" text so
// the model can react to them (same contract as OpenAITools::handleToolCalls).
func (r *Registry) Call(ctx context.Context, name, rawArgs string) string {
	r.mu.RLock()
	t, ok := r.tools[name]
	r.mu.RUnlock()
	if !ok {
		return "Error: no such tool \"" + name + "\". Available: " + strings.Join(r.Names(), ", ")
	}
	args := Args{}
	if strings.TrimSpace(rawArgs) != "" {
		if err := json.Unmarshal([]byte(rawArgs), &args); err != nil {
			return "Error: arguments are not valid JSON: " + err.Error()
		}
	}
	out, err := t.Run(ctx, args)
	if err != nil {
		return "Error: " + err.Error()
	}
	return out
}

// HandleToolCalls executes calls and returns "tool" role messages.
func (r *Registry) HandleToolCalls(ctx context.Context, calls []llm.ToolCall) []llm.Message {
	out := make([]llm.Message, 0, len(calls))
	for _, c := range calls {
		out = append(out, llm.Message{Role: "tool", ToolCallID: c.ID, Content: r.Call(ctx, c.Function.Name, c.Function.Arguments)})
	}
	return out
}
