package admin

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"kuni/internal/brain"
	"kuni/internal/live"
)

func TestLiveViewIsGuardedAndServesFramesAndFeed(t *testing.T) {
	p, mux, c, _ := rig(t)
	// without a login nothing is served
	if w := do(mux, "GET", "/admin/api/live/frame?src=desktop", "", nil); w.Code != 401 {
		t.Fatalf("frame without auth: %d", w.Code)
	}
	if w := do(mux, "GET", "/admin/api/live/events", "", nil); w.Code != 401 {
		t.Fatalf("events without auth: %d", w.Code)
	}
	// the view is off until the program wires it
	if w := do(mux, "GET", "/admin/api/live/frame?src=desktop", "", auth); w.Code != 404 {
		t.Fatalf("no source: %d", w.Code)
	}
	running := true
	p.Frame = func(_ context.Context, src string) ([]byte, string, bool, error) {
		switch {
		case src == "browser":
			return nil, "", false, errors.New("boom")
		case !running:
			return nil, "", false, nil
		}
		return []byte{0xff, 0xd8, 0xff, 0xd9}, "321,123", true, nil
	}
	p.Screens = func() (bool, bool) { return false, running }
	p.Feed = &live.Feed{}
	p.Feed.Add("tool", "Alex", "browser open")
	p.Feed.Add("result", "Alex", "ok")
	c.paused = true

	w := do(mux, "GET", "/admin/api/live/frame?src=desktop", "", auth)
	if w.Code != 200 || w.Header().Get("Content-Type") != "image/jpeg" || w.Header().Get("X-Pointer") != "321,123" || !strings.Contains(w.Header().Get("Cache-Control"), "no-store") || w.Body.Len() != 4 {
		t.Fatalf("frame: %d %v", w.Code, w.Header())
	}
	running = false
	if w := do(mux, "GET", "/admin/api/live/frame?src=desktop", "", auth); w.Code != 204 {
		t.Fatalf("a stopped screen must be 204, got %d", w.Code)
	}
	if w := do(mux, "GET", "/admin/api/live/frame?src=browser", "", auth); w.Code != 502 {
		t.Fatalf("error: %d", w.Code)
	}
	if w := do(mux, "GET", "/admin/api/live/frame?src=../etc/passwd", "", auth); w.Code != 400 {
		t.Fatalf("bad src: %d", w.Code)
	}

	var j struct {
		Events  []live.Event `json:"events"`
		Last    int64        `json:"last"`
		Desktop bool         `json:"desktop"`
		Browser bool         `json:"browser"`
		Paused  bool         `json:"paused"`
	}
	w = do(mux, "GET", "/admin/api/live/events?since=0", "", auth)
	if err := json.Unmarshal(w.Body.Bytes(), &j); err != nil || len(j.Events) != 2 || j.Last != 2 || j.Desktop || !j.Paused {
		t.Fatalf("events: %s", w.Body.String())
	}
	w = do(mux, "GET", "/admin/api/live/events?since=1", "", auth)
	j.Events = nil
	json.Unmarshal(w.Body.Bytes(), &j)
	if len(j.Events) != 1 || j.Events[0].Kind != "result" {
		t.Fatalf("since: %s", w.Body.String())
	}
	// the tab is part of the page
	if w := do(mux, "GET", "/admin", "", map[string]string{"Authorization": "Bearer " + tok}); !strings.Contains(w.Body.String(), `["live","Эфир"]`) {
		t.Fatal("the Эфир tab is missing from the page")
	}
}

func TestLiveStreamSendsOnlyChangedPictures(t *testing.T) {
	p, mux, _, _ := rig(t)
	calls := 0
	p.Stream = func(ctx context.Context, src string, prev uint64) ([]byte, uint64, bool, bool, error) {
		calls++
		if prev == 7 {
			return nil, 7, false, true, nil
		}
		return []byte{0xff, 0xd8, 0xff, 0xd9}, 7, true, true, nil
	}
	p.Pointer = func(string) string { return "5,6" }
	if w := do(mux, "GET", "/admin/api/live/stream?src=desktop", "", nil); w.Code != 401 {
		t.Fatalf("no login: %d", w.Code)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 600*time.Millisecond)
	defer cancel()
	r := httptest.NewRequest("GET", "/admin/api/live/stream?src=desktop", nil).WithContext(ctx)
	r.RemoteAddr = "10.0.0.5:1234"
	r.Header.Set("Authorization", "Bearer "+tok)
	w := httptest.NewRecorder()
	mux.ServeHTTP(w, r)
	if ct := w.Header().Get("Content-Type"); !strings.HasPrefix(ct, "multipart/x-mixed-replace") {
		t.Fatalf("content type %q", ct)
	}
	if n := strings.Count(w.Body.String(), "Content-Type: image/jpeg"); n != 1 || calls < 3 {
		t.Fatalf("pictures sent = %d for %d looks, want 1", n, calls)
	}
	if w := do(mux, "GET", "/admin/api/live/pointer?src=desktop", "", auth); !strings.Contains(w.Body.String(), "5,6") {
		t.Fatalf("pointer: %s", w.Body.String())
	}
}

func TestDeskPageNeedsLoginAndSetsTheCookie(t *testing.T) {
	_, mux, _, _ := rig(t)
	if w := do(mux, "GET", "/admin/desk", "", nil); w.Code != 401 {
		t.Fatalf("no login: %d", w.Code)
	}
	if w := do(mux, "GET", "/admin/desk?token="+tok, "", nil); w.Code != 303 || !strings.Contains(w.Header().Get("Set-Cookie"), cookieName) {
		t.Fatalf("token login: %d %v", w.Code, w.Header())
	}
	w := do(mux, "GET", "/admin/desk", "", auth)
	if w.Code != 200 || !strings.Contains(w.Body.String(), "live/stream") {
		t.Fatalf("page: %d", w.Code)
	}
}

func TestBrainViewIsGuarded(t *testing.T) {
	p, _, _, _ := rig(t)
	p.Brain = brain.New("", 1)
	mux := http.NewServeMux()
	p.Mount(mux)
	if w := do(mux, "GET", "/admin/brain/", "", nil); w.Code != 401 {
		t.Fatalf("no login: %d", w.Code)
	}
	if w := do(mux, "GET", "/admin/brain/?token="+tok, "", nil); w.Code != 303 {
		t.Fatalf("token login: %d", w.Code)
	}
	if w := do(mux, "GET", "/admin/brain/", "", auth); w.Code != 200 || !strings.Contains(w.Body.String(), "Мозг Рейны") {
		t.Fatalf("page: %d", w.Code)
	}
	w := do(mux, "GET", "/admin/brain/structure.json", "", auth)
	if w.Code != 200 || !strings.Contains(w.Body.String(), `"inhib"`) {
		t.Fatalf("graph: %d", w.Code)
	}
}
