// Package brain is a small spiking-style neural substrate modelled on the layout of the fruit-fly brain
// (the FlyWire connectome: sensory neurons -> a sparse "mushroom body" that learns by dopamine -> a recurrent
// core -> a slow goal-holding pool -> descending output neurons). It is an analogy, not an emulation: the wiring
// is grown from a seed here instead of read from a microscope, and what the outputs mean is "drives" that colour her
// turns. Everything is persistent and deterministic given the seed, so her inner state can be watched and replayed.
package brain

import (
	"compress/gzip"
	"encoding/json"
	"fmt"
	"math"
	"math/rand"
	"os"
	"runtime/debug"
	"sort"
	"strings"
	"sync"
	"time"
)

// Tuning of the core (found by sweeping for activity of a few percent and a poke that travels, not dies or explodes).
var (
	excLo, excHi = 0.104, 0.24 // excitatory synapse strength
	inhG         = 6.0         // strength of the global feedback inhibition
	kcDrive      = 0.6         // how hard an active Kenyon-like cell drives its core targets
)

// Sensory channels (what the world looks like to her), 0..1 each.
var Channels = [12]string{"social", "group", "owner", "stranger", "bond", "praise", "threat", "quiet", "night", "novelty", "task", "world"}

// Drives are the descending outputs: what she is inclined to do.
var Drives = [nGoal]string{"connect", "withdraw", "explore", "rest", "create", "reflect", "guard", "attach"}

const (
	nHash = 64 // text features: words hashed into buckets (a stand-in for meaning)
	nIn   = 12 + nHash
	nKC   = 5000 // Kenyon cells: the fly has about 5,000
	// nCore makes the whole brain exactly 500,000 neurons: 76 senses + 5,000 Kenyon cells + 494,916 core neurons + 8 output neurons. The adult
	// fruit fly has 139,255 (FlyWire) and about 390 synapses per neuron; here each core neuron makes about 15 (memory), so this is a bigger
	// brain than the fly's in cells, not in connections.
	nCore = 494916
	nGoal = 8
	kcTop = 300 // ~6% of KCs fire (APL-like global inhibition)
)

// Brain holds the whole state. Safe for concurrent use.
type Brain struct {
	mu   sync.Mutex
	path string

	seed    int64
	kcIn    [nKC][4]int8 // each KC samples 4 sensory channels (as in the fly)
	kcW     [nKC][nGoal]float64
	kcPos   [nKC][3]float32
	inPos   [nIn][3]float32
	kcCore  [][]int32        // the core neurons each KC's axon touches
	coreS   [][]syn          // outgoing synapses of each core neuron, found where its axon touches other dendrites; sign = transmitter
	pos     [][3]float32     // where each core neuron sits in the cortex-like slab
	inhib   []bool           // Dale's law: an inhibitory neuron only inhibits
	coreOut [][nGoal]float32 // core neuron -> output neuron synapses (where the core axon touches an output dendrite); learned by dopamine
	outNorm [nGoal]float64   // total strength of those synapses at birth

	core    []float64      // membrane potentials
	thr     []float64      // adaptive thresholds: a neuron that fires a lot gets harder to fire
	refr    []int8         // refractory ticks left
	fired   []bool         // which core neurons spiked on the last tick
	pool    float64        // recent share of the core that fired: global feedback inhibition (like the fly's APL neuron)
	ctr     []float32      // eligibility of each core neuron for dopamine (it fired recently)
	eps     []episode      // recent reinforced situations, replayed in sleep
	slept   string         // day of the last sleep
	journal string         // path of the JSONL journal of what she felt ("" = none)
	goal    [nGoal]float64 // slow pool that holds the leaning
	trace   [nKC]float64   // eligibility trace (which KCs were active recently)
	last    [nGoal]float64 // last drive vector
	lastTop string
	lastIn  [nIn]float64 // the last situation she was shown (the viewer replays it to keep the picture alive)
	lastKC  []int
	Ticks   int64
}

type syn struct {
	to int32
	w  float32
}

// episode is one remembered lesson: the KCs that were active, the drive that led and how it turned out.
type episode struct {
	KC    []int
	Drive int
	Value float64
}

type outSyn struct {
	I int32
	D int8
	W float32
}

type saved struct {
	Eps   []episode
	Slept string
	Seed  int64
	NCore int
	KCW   [][]float64
	Out   []outSyn
	Goal  []float64
	Trace []float64
	Ticks int64
}

// New builds the wiring from seed (neurons get a shape and a place, synapses appear where axons touch dendrites) and loads learned weights from path.
func New(path string, seed int64) *Brain {
	b := &Brain{path: path, seed: seed}
	r := rand.New(rand.NewSource(seed))
	for k := 0; k < nKC; k++ {
		for j := 0; j < 4; j++ {
			b.kcIn[k][j] = int8(r.Intn(nIn))
		}
		for d := 0; d < nGoal; d++ {
			b.kcW[k][d] = 0.02 * r.Float64()
		}
	}
	lr := rand.New(rand.NewSource(seed ^ 0x5eed))
	const cols = 8
	for i := 0; i < nIn; i++ {
		b.inPos[i] = [3]float32{float32(-1.85 + 0.05*lr.Float64()), float32(-0.55 + 1.1*float64(i/cols)/float64(nIn/cols+1)), float32(-0.8 + 1.6*float64(i%cols)/float64(cols-1))}
	}
	for k := 0; k < nKC; k++ {
		b.kcPos[k] = [3]float32{float32(lr.Float64()*2.4 - 1.2), float32(lr.Float64()*0.9 - 0.45), float32(0.95 + lr.Float64()*0.55)}
	}
	b.pos = make([][3]float32, nCore)
	b.inhib = make([]bool, nCore)
	for i := 0; i < nCore; i++ {
		b.pos[i] = [3]float32{float32(r.Float64()*2.6 - 1.3), float32(r.Float64()*1.1 - 0.55), float32(r.Float64()*1.6 - 0.8)}
		b.inhib[i] = r.Float64() < 0.2
	}
	b.core, b.thr, b.refr, b.fired, b.ctr = make([]float64, nCore), make([]float64, nCore), make([]int8, nCore), make([]bool, nCore), make([]float32, nCore)
	for i := range b.thr {
		b.thr[i] = 1
	}
	b.wire()
	debug.FreeOSMemory() // hand the big temporary index of the wiring back to the system
	b.load()
	return b
}

func (b *Brain) load() {
	if b.path == "" {
		return
	}
	f, err := os.Open(b.path)
	if err != nil {
		return
	}
	defer f.Close()
	zr, err := gzip.NewReader(f)
	if err != nil {
		return
	}
	var s saved
	if json.NewDecoder(zr).Decode(&s) != nil || s.Seed != b.seed || s.NCore != nCore || len(s.KCW) != nKC || len(s.Goal) != nGoal || len(s.Trace) != nKC {
		return
	}
	for k := range s.KCW {
		if len(s.KCW[k]) != nGoal {
			return
		}
		copy(b.kcW[k][:], s.KCW[k])
	}
	for _, o := range s.Out {
		if int(o.I) < nCore && o.D >= 0 && int(o.D) < nGoal && b.coreOut[o.I][o.D] > 0 {
			b.coreOut[o.I][o.D] = o.W
		}
	}
	b.eps, b.slept = s.Eps, s.Slept
	copy(b.goal[:], s.Goal)
	copy(b.trace[:], s.Trace)
	b.Ticks = s.Ticks
}

// Save writes the learned state (weights, goal pool, traces).
func (b *Brain) Save() error {
	b.mu.Lock()
	defer b.mu.Unlock()
	if b.path == "" {
		return nil
	}
	s := saved{Eps: b.eps, Slept: b.slept, Seed: b.seed, NCore: nCore, Goal: b.goal[:], Trace: b.trace[:], Ticks: b.Ticks}
	for k := range b.kcW {
		s.KCW = append(s.KCW, b.kcW[k][:])
	}
	for i := range b.coreOut {
		for d := 0; d < nGoal; d++ {
			if b.coreOut[i][d] > 0 {
				s.Out = append(s.Out, outSyn{int32(i), int8(d), b.coreOut[i][d]})
			}
		}
	}
	tmp := b.path + ".tmp"
	f, err := os.OpenFile(tmp, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o600)
	if err != nil {
		return err
	}
	zw := gzip.NewWriter(f)
	if err := json.NewEncoder(zw).Encode(s); err != nil {
		f.Close()
		return err
	}
	zw.Close()
	f.Close()
	return os.Rename(tmp, b.path)
}

// Drive is one output with its strength 0..1.
type Drive struct {
	Name  string
	Value float64
}

// Sense runs the brain on a situation (channel -> 0..1) for a few ticks and returns the drives, strongest first.
func (b *Brain) Sense(in map[string]float64) []Drive { return b.SenseText(in, "") }

// SenseText is Sense plus the words of the situation: they are hashed into extra input channels, so the sparse layer can
// tell "an argument about code" from "a quiet evening chat" and learn a different lean for each.
func (b *Brain) SenseText(in map[string]float64, text string) []Drive {
	b.mu.Lock()
	defer b.mu.Unlock()
	var x [nIn]float64
	for i, n := range Channels {
		x[i] = math.Max(0, math.Min(1, in[n]))
	}
	for _, w := range strings.FieldsFunc(strings.ToLower(text), func(r rune) bool {
		return !(r >= 'a' && r <= 'z' || r >= 'а' && r <= 'я' || r == 'ё' || r >= '0' && r <= '9')
	}) {
		if len([]rune(w)) < 4 {
			continue
		}
		h := uint32(2166136261)
		for _, c := range w {
			h = (h ^ uint32(c)) * 16777619
		}
		i := 12 + int(h%nHash)
		x[i] = math.Min(1, x[i]+1)
	}
	for t := 0; t < 8; t++ {
		b.tick(&x)
	}
	ds := b.drivesLocked()
	if len(ds) > 0 {
		b.lastTop = ds[0].Name
	}
	b.lastIn = x
	b.logLocked(in, text, ds)
	return ds
}

// SetJournal makes every Sense append one JSON line (time, situation, strongest drives) to path, so that her inner life
// can be read and replayed later.
func (b *Brain) SetJournal(path string) { b.mu.Lock(); b.journal = path; b.mu.Unlock() }

func (b *Brain) logLocked(in map[string]float64, text string, ds []Drive) {
	if b.journal == "" {
		return
	}
	if fi, err := os.Stat(b.journal); err == nil && fi.Size() > 4<<20 {
		_ = os.Rename(b.journal, b.journal+".old")
	}
	f, err := os.OpenFile(b.journal, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o600)
	if err != nil {
		return
	}
	defer f.Close()
	top := make([]Drive, 0, 3)
	for _, d := range ds {
		if len(top) < 3 && d.Value >= 0.1 {
			top = append(top, d)
		}
	}
	if r := []rune(text); len(r) > 120 {
		text = string(r[:120])
	}
	_ = json.NewEncoder(f).Encode(map[string]any{"t": time.Now().Format(time.RFC3339), "in": in, "text": text, "top": top})
}

// Current returns the drives as they stand now, without running anything.
func (b *Brain) Current() []Drive {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.drivesLocked()
}

// ReinforceLast rewards or punishes the drive that led the last time she was asked (value -1..1).
func (b *Brain) ReinforceLast(value float64) {
	b.mu.Lock()
	top := b.lastTop
	b.mu.Unlock()
	if top != "" {
		b.Reinforce(top, value)
	}
}

func (b *Brain) tick(x *[nIn]float64) {
	b.Ticks++
	// 1. KCs: sparse code. Each cell sums its 4 sensory inputs; the k strongest win (global inhibition).
	type kv struct {
		k int
		v float64
	}
	act := make([]kv, nKC)
	for k := 0; k < nKC; k++ {
		s := 0.0
		for _, c := range b.kcIn[k] {
			s += x[c]
		}
		// a KC prefers a conjunction: it only responds if at least two of its inputs are on
		on := 0
		for _, c := range b.kcIn[k] {
			if x[c] > 0.25 {
				on++
			}
		}
		if on < 2 {
			s *= 0.2
		}
		act[k] = kv{k, s}
	}
	sort.Slice(act, func(i, j int) bool { return act[i].v > act[j].v })
	b.lastKC = b.lastKC[:0]
	var drive [nGoal]float64
	var kcSum [nGoal]float64
	actSum := 0.0
	for i := 0; i < kcTop && act[i].v > 0.3; i++ {
		k := act[i].k
		b.lastKC = append(b.lastKC, k)
		b.trace[k] = math.Min(1, b.trace[k]+0.5)
		actSum += act[i].v
		for d := 0; d < nGoal; d++ {
			kcSum[d] += b.kcW[k][d] * act[i].v
		}
		for _, c := range b.kcCore[k] {
			b.core[c] += kcDrive * act[i].v
		}
	}
	if actSum > 0 { // the lean of the situation = the average weight of the cells that recognise it (specific, not just loud)
		for d := 0; d < nGoal; d++ {
			drive[d] += 1.5 * kcSum[d] / actSum
		}
	}
	// 2. core: leaky integrate-and-fire with recurrence (+ excitatory, - inhibitory)
	fired := b.fired
	for i := range fired {
		fired[i] = false
	}
	gi := inhG * b.pool
	for i := 0; i < nCore; i++ {
		b.core[i] = math.Max(-1, b.core[i]*0.8-gi)
		b.ctr[i] *= 0.97
		b.thr[i] += (1 - b.thr[i]) * 0.02 // the threshold relaxes back
		if b.refr[i] > 0 {
			b.refr[i]--
			b.core[i] = 0
			continue
		}
		if b.core[i] > b.thr[i] {
			fired[i] = true
			b.thr[i] += 0.15 // adaptation: busy neurons tire
			b.refr[i] = 2
		}
	}
	var outSum [nGoal]float64
	nf := 0
	for i := 0; i < nCore; i++ {
		if !fired[i] {
			continue
		}
		nf++
		b.core[i] = 0
		if b.ctr[i] < 0.5 {
			b.ctr[i] += 0.5
		}
		for _, sy := range b.coreS[i] {
			b.core[sy.to] += float64(sy.w)
		}
		if o := &b.coreOut[i]; o[0]+o[1]+o[2]+o[3]+o[4]+o[5]+o[6]+o[7] > 0 {
			for d := 0; d < nGoal; d++ {
				outSum[d] += float64(o[d])
			}
		}
	}
	b.pool = 0.8*b.pool + float64(nf)/nCore
	for d := 0; d < nGoal; d++ { // the output neurons read the core: the share of their input synapses that fired
		if b.outNorm[d] > 0 {
			drive[d] += outGain * outSum[d] / b.outNorm[d]
		}
	}
	// plain sensory shortcuts (innate reflexes, the part not learned): quiet+night -> rest, threat -> guard, etc.
	drive[idx("rest")] += 0.35*x[idx2("quiet")]*x[idx2("night")] + 0.15*x[idx2("night")]
	drive[idx("guard")] += 0.7 * x[idx2("threat")]
	drive[idx("withdraw")] += 0.4 * x[idx2("threat")] * (1 - x[idx2("owner")])
	drive[idx("connect")] += 0.3*x[idx2("social")] + 0.2*x[idx2("owner")]
	drive[idx("explore")] += 0.3 * x[idx2("novelty")]
	drive[idx("attach")] += 0.6 * x[idx2("bond")]
	drive[idx("create")] += 0.3 * x[idx2("world")] * (1 - x[idx2("night")]*0.5)
	// 3. the slow goal pool: leaky integration over many ticks keeps a leaning for a while (central-complex-like)
	for d := 0; d < nGoal; d++ {
		b.goal[d] = 0.85*b.goal[d] + 0.15*math.Tanh(drive[d]*0.5)
		b.last[d] = b.goal[d]
	}
	for k := range b.trace {
		b.trace[k] *= 0.97
	}
}

func idx(name string) int {
	for i, n := range Drives {
		if n == name {
			return i
		}
	}
	panic("drive " + name)
}

func idx2(name string) int {
	for i, n := range Channels {
		if n == name {
			return i
		}
	}
	panic("channel " + name)
}

func (b *Brain) drivesLocked() []Drive {
	out := make([]Drive, nGoal)
	for d := range out {
		out[d] = Drive{Drives[d], math.Max(0, b.goal[d])}
	}
	sort.SliceStable(out, func(i, j int) bool { return out[i].Value > out[j].Value })
	return out
}

// Reinforce is the dopamine signal: how good did the last leaning turn out (-1..1)? The Kenyon cells that were
// active are tied more (or less) strongly to the drive that led, so that situation will pull the same way next time.
func (b *Brain) Reinforce(drive string, value float64) {
	b.mu.Lock()
	defer b.mu.Unlock()
	d := -1
	for i, n := range Drives {
		if n == drive {
			d = i
		}
	}
	if d < 0 {
		return
	}
	value = math.Max(-1, math.Min(1, value))
	var act []int
	for k := 0; k < nKC; k++ {
		if b.trace[k] >= 0.05 {
			act = append(act, k)
		}
	}
	if len(act) > 0 {
		b.eps = append(b.eps, episode{act, d, value})
		if len(b.eps) > 96 {
			b.eps = b.eps[1:]
		}
	}
	b.applyLocked(act, d, value, 1)
	for i := 0; i < nCore; i++ { // dopamine also tunes the core -> output synapses of the neurons that were just active
		if b.ctr[i] >= 0.05 && b.coreOut[i][d] > 0 {
			w := float64(b.coreOut[i][d]) + lr*0.5*value*float64(b.ctr[i])
			b.coreOut[i][d] = float32(math.Max(0.02, math.Min(1.2, w)))
		}
	}
}

const lr = 0.25

// outGain: what the core's output synapses add to a drive when all of them fire at once (a few percent fire in real life).
const outGain = 10.0

// applyLocked changes the KC -> drive weights; scale < 1 is used by replay in sleep.
func (b *Brain) applyLocked(act []int, d int, value, scale float64) {
	for _, k := range act {
		tr := b.trace[k]
		if scale < 1 || tr < 0.05 {
			tr = 0.5
		}
		w := b.kcW[k][d] + lr*scale*value*tr
		b.kcW[k][d] = math.Max(0, math.Min(1.5, w))
	}
}

// Sleep consolidates: it replays the stored lessons at a lower rate (what mattered is strengthened again), scales each
// drive's synapses so that none of them takes over (synaptic scaling), lets unused weights fade, prunes dead ones and lets
// the thresholds settle. Call about once a night; returns how many lessons it replayed.
func (b *Brain) Sleep() int {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.sleepLocked()
}

func (b *Brain) sleepLocked() int {
	for _, e := range b.eps {
		b.applyLocked(e.KC, e.Drive, e.Value, 0.3)
	}
	for d := 0; d < nGoal; d++ {
		sum := 0.0
		for k := 0; k < nKC; k++ {
			sum += b.kcW[k][d]
		}
		if mean := sum / nKC; mean > 0.12 {
			f := 0.12 / mean
			for k := 0; k < nKC; k++ {
				b.kcW[k][d] *= f
			}
		}
	}
	for k := 0; k < nKC; k++ {
		for d := 0; d < nGoal; d++ {
			b.kcW[k][d] *= 0.995
			if b.kcW[k][d] < 0.004 {
				b.kcW[k][d] = 0
			}
		}
	}
	for d := 0; d < nGoal; d++ { // the same synaptic scaling for the core's output synapses: none may grow past 1.5x its birth strength
		sum := 0.0
		for i := range b.coreOut {
			sum += float64(b.coreOut[i][d])
		}
		if b.outNorm[d] > 0 && sum > 1.5*b.outNorm[d] {
			f := float32(1.5 * b.outNorm[d] / sum)
			for i := range b.coreOut {
				b.coreOut[i][d] *= f
			}
		}
	}
	for i := range b.thr {
		b.thr[i], b.core[i] = 1, 0
	}
	return len(b.eps)
}

// SleepOnce sleeps if it has not yet for this day ("2006-01-02") and reports whether it did.
func (b *Brain) SleepOnce(day string) (int, bool) {
	b.mu.Lock()
	defer b.mu.Unlock()
	if b.slept == day {
		return 0, false
	}
	b.slept = day
	return b.sleepLocked(), true
}

// Prompt renders what she feels from the inside, as a block for her turn. The drives are leanings, never orders.
func (b *Brain) Prompt(ds []Drive) string {
	if len(ds) == 0 {
		return ""
	}
	var parts []string
	for _, d := range ds {
		if d.Value >= 0.12 && len(parts) < 3 {
			parts = append(parts, fmt.Sprintf("%s %.2f", label[d.Name], d.Value))
		}
	}
	if len(parts) == 0 {
		return "<brain>Inner state: calm, nothing pulls you anywhere in particular.</brain>\n"
	}
	return "<brain>Inner pulls right now (from your own wiring and what has worked for you before): " + strings.Join(parts, ", ") +
		". These are leanings, not orders: follow one, argue with it or ignore it, it is your decision.</brain>\n"
}

var label = map[string]string{"connect": "to talk, to be with people", "withdraw": "to pull back", "explore": "curiosity, to look into something new",
	"rest": "to rest", "create": "to build or make something", "reflect": "to think it over", "guard": "to defend yourself", "attach": "closeness to the one you chose"}

// Top is the strongest drive's name.
func Top(ds []Drive) string {
	if len(ds) == 0 {
		return ""
	}
	return ds[0].Name
}

func trimFloat(v float64) string { return fmt.Sprintf("%.3f", v) }
