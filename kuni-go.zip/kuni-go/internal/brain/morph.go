package brain

import (
	"math"
	"slices"
	"sort"
)

// Shapes and wiring. Every neuron has a deterministic shape (dendrites that gather, an axon that sends), grown from the seed. A synapse exists
// where an axon bouton lies within contactR of another neuron's dendrite: the picture of the brain is the circuit that runs, not a drawing next to it.

const (
	maxOutDeg = 160 // synapses one neuron may make (the fly averages ~390; memory limits this build)
	kcMaxDeg  = 24  // core neurons one Kenyon cell may touch
	nBouton   = 6
	nDendPts  = 16
	dnDendPts = 240
)

// contactR is how close an axon bouton must be to a dendrite point to make a synapse; it shrinks with the cube root of the neuron count so that
// the number of synapses per neuron stays about the same (the tissue gets denser, the touching gets finer).
var (
	contactR = float32(0.0125 * 1.9 * math.Cbrt(134171.0/nCore))
	cellSize = 2 * contactR
)

var inhScale = 0.6 // inhibition is stronger than excitation (as in cortex): without it the core runs away

type pt = [3]float32

// emitFn receives every drawn piece of a neuron: a segment a->b, kind 0 dendrite / 1 axon, t0..t1 = how far from the soma (0..1).
type emitFn func(a, b pt, kind uint8, t0, t1 float32)

type rg uint64

func newRG(seed int64, id int, salt uint64) rg {
	x := uint64(seed)*0x9E3779B97F4A7C15 + uint64(id+1)*0xBF58476D1CE4E5B9 + salt*0x94D049BB133111EB
	r := rg(x)
	r.u()
	return r
}

func (r *rg) u() float32 {
	*r += 0x9E3779B97F4A7C15
	z := uint64(*r)
	z = (z ^ z>>30) * 0xBF58476D1CE4E5B9
	z = (z ^ z>>27) * 0x94D049BB133111EB
	z ^= z >> 31
	return float32(z>>40) / float32(1<<24)
}

func (r *rg) dir() pt {
	for {
		v := pt{r.u()*2 - 1, r.u()*2 - 1, r.u()*2 - 1}
		if l := v[0]*v[0] + v[1]*v[1] + v[2]*v[2]; l > 0.01 && l <= 1 {
			return norm(v)
		}
	}
}

func norm(v pt) pt {
	l := float32(math.Sqrt(float64(v[0]*v[0] + v[1]*v[1] + v[2]*v[2])))
	if l == 0 {
		return pt{0, 1, 0}
	}
	return pt{v[0] / l, v[1] / l, v[2] / l}
}

type gen struct {
	r     rg
	emit  emitFn
	nodes []pt
}

// branch grows a wiggling neurite from p heading d; it forks sideways now and then and at the tip. It returns where it ended.
func (g *gen) branch(p, d pt, length float32, depth int, kind uint8, t, tspan, jit, step float32) pt {
	steps := int(length / step)
	if steps < 2 {
		steps = 2
	}
	L := length / float32(steps)
	for s := 0; s < steps; s++ {
		d = norm(pt{d[0] + jit*(g.r.u()-.5), d[1] + jit*(g.r.u()-.5), d[2] + jit*(g.r.u()-.5)})
		q := pt{p[0] + d[0]*L, p[1] + d[1]*L, p[2] + d[2]*L}
		t1 := t + L/tspan
		if g.emit != nil {
			g.emit(p, q, kind, min(t, 1), min(t1, 1))
		}
		g.nodes = append(g.nodes, q)
		p, t = q, t1
		if depth > 0 && s > 0 && s < steps-1 && g.r.u() < .3 {
			cd := norm(pt{d[0] + (g.r.u()-.5)*1.2, d[1] + (g.r.u()-.5)*1.2, d[2] + (g.r.u()-.5)*1.2})
			g.branch(p, cd, length*.55, depth-1, kind, t, tspan, jit, step)
		}
	}
	if depth > 0 {
		for k := 0; k < 2; k++ {
			cd := norm(pt{d[0] + (g.r.u()-.5)*1.4, d[1] + (g.r.u()-.5)*1.4, d[2] + (g.r.u()-.5)*1.4})
			g.branch(p, cd, length*.6, depth-1, kind, t, tspan, jit, step)
		}
	}
	return p
}

// pick returns n points of nodes spread evenly.
func pick(nodes []pt, n int, dst []pt) []pt {
	dst = dst[:0]
	if len(nodes) == 0 {
		return dst
	}
	for k := 0; k < n; k++ {
		dst = append(dst, nodes[(k*len(nodes))/n+len(nodes)/(2*n)%len(nodes)])
	}
	return dst
}

// coreShape grows core neuron i: dendrite sample points and axon boutons (and draws it if emit != nil).
func (b *Brain) coreShape(i int, emit emitFn, dend, bout []pt) ([]pt, []pt) {
	p := b.pos[i]
	g := gen{r: newRG(b.seed, i, 1), emit: emit}
	np := 4 + int(g.r.u()*3)
	for k := 0; k < np; k++ {
		d := g.r.dir()
		ln := 0.045 + 0.03*g.r.u()
		if !b.inhib[i] && k == 0 { // excitatory cells get one tall apical dendrite
			d, ln = norm(pt{(g.r.u() - .5) * .3, 1, (g.r.u() - .5) * .3}), 0.08+0.05*g.r.u()
		}
		g.branch(p, d, ln, 2, 0, 0, 0.16, .55, .02)
	}
	dend = pick(g.nodes, nDendPts, dend)
	g.nodes = g.nodes[:0]
	L := 0.09 + 0.06*g.r.u()
	long := g.r.u() < 0.1
	if long {
		L = 0.4 + 0.5*g.r.u()
	}
	depth := 0
	if long {
		depth = 1
	}
	g.branch(p, g.r.dir(), L, depth, 1, 0, L, .25, .02)
	nodes := g.nodes
	if long && len(nodes) > 3*nBouton { // a projection neuron only makes synapses where it arrives
		nodes = nodes[len(nodes)*2/3:]
	}
	return dend, pick(nodes, nBouton, bout)
}

// kcShape grows Kenyon cell k: a short claw and a long axon that dives from the sheet into the core slab, where it makes its synapses.
func (b *Brain) kcShape(k int, emit emitFn, bout []pt) []pt {
	p := b.kcPos[k]
	g := gen{r: newRG(b.seed, k, 2), emit: emit}
	for c := 0; c < 3; c++ {
		g.branch(p, pt{g.r.dir()[0], 0.6 + g.r.u()*.4, g.r.dir()[2]}, 0.04, 0, 0, 0, 0.1, .3, .02)
	}
	g.nodes = g.nodes[:0]
	L := (p[2] - 0.8) + 0.15 + 0.35*g.r.u()
	g.branch(p, norm(pt{(g.r.u() - .5) * .3, (g.r.u() - .5) * .3, -1}), L, 0, 1, 0, L, .2, .025)
	var in []pt
	for _, n := range g.nodes {
		if n[2] < 0.78 {
			in = append(in, n)
		}
	}
	if len(in) == 0 {
		in = g.nodes[len(g.nodes)-1:]
	}
	return pick(in, 8, bout)
}

// dnShape grows output neuron d: its soma sits right of the slab and its dendrites reach into the slab, where the core axons arrive.
func (b *Brain) dnShape(d int, emit emitFn) []pt {
	p := dnPos(d)
	g := gen{r: newRG(b.seed, d, 3), emit: emit}
	for k := 0; k < 9; k++ {
		dir := norm(pt{-1, (g.r.u() - .5) * .35, (g.r.u() - .5) * .9})
		g.branch(p, dir, 0.9+0.4*g.r.u(), 2, 0, 0, 1.4, .35, .03)
	}
	var in []pt
	for _, n := range g.nodes {
		if n[0] < 1.3 && n[0] > -1.3 && n[1] > -0.56 && n[1] < 0.56 && n[2] > -0.81 && n[2] < 0.81 {
			in = append(in, n)
		}
	}
	return pick(in, dnDendPts, nil)
}

func dnPos(d int) pt {
	return pt{1.85, float32(-0.5 + 1.0*float64(d)/float64(nGoal-1)), float32(0.1 * math.Sin(float64(d)))}
}

type ent struct {
	k  uint64
	id int32 // core neuron index, or nCore+d for output neuron d
	p  pt
}

func cellKey(x, y, z int) uint64 { return uint64(x+512)<<22 | uint64(y+512)<<11 | uint64(z+512) }

// near calls visit for every dendrite point within contactR of p (visit returns false to stop).
func near(ents []ent, p pt, visit func(e *ent) bool) {
	var c [3]int
	var off [3]int
	for a := 0; a < 3; a++ {
		f := p[a] / cellSize
		fl := float32(math.Floor(float64(f)))
		c[a] = int(fl)
		if f-fl < .5 {
			off[a] = -1
		} else {
			off[a] = 1
		}
	}
	r2 := contactR * contactR
	for m := 0; m < 8; m++ {
		cx, cy, cz := c[0], c[1], c[2]
		if m&1 != 0 {
			cx += off[0]
		}
		if m&2 != 0 {
			cy += off[1]
		}
		if m&4 != 0 {
			cz += off[2]
		}
		key := cellKey(cx, cy, cz)
		j := sort.Search(len(ents), func(i int) bool { return ents[i].k >= key })
		for ; j < len(ents) && ents[j].k == key; j++ {
			e := &ents[j]
			dx, dy, dz := e.p[0]-p[0], e.p[1]-p[1], e.p[2]-p[2]
			if dx*dx+dy*dy+dz*dz <= r2 && !visit(e) {
				return
			}
		}
	}
}

// wire grows every neuron and creates a synapse wherever an axon bouton touches a dendrite.
func (b *Brain) wire() {
	ents := make([]ent, 0, nCore*nDendPts+nGoal*dnDendPts)
	bouts := make([]pt, 0, nCore*nBouton)
	var dend, bo []pt
	for i := 0; i < nCore; i++ {
		dend, bo = b.coreShape(i, nil, dend, bo)
		for _, q := range dend {
			ents = append(ents, ent{cellKey(int(math.Floor(float64(q[0]/cellSize))), int(math.Floor(float64(q[1]/cellSize))), int(math.Floor(float64(q[2]/cellSize)))), int32(i), q})
		}
		for k := 0; k < nBouton; k++ {
			if k < len(bo) {
				bouts = append(bouts, bo[k])
			} else {
				bouts = append(bouts, b.pos[i])
			}
		}
	}
	for d := 0; d < nGoal; d++ {
		for _, q := range b.dnShape(d, nil) {
			ents = append(ents, ent{cellKey(int(math.Floor(float64(q[0]/cellSize))), int(math.Floor(float64(q[1]/cellSize))), int(math.Floor(float64(q[2]/cellSize)))), int32(nCore + d), q})
		}
	}
	slices.SortFunc(ents, func(a, c ent) int {
		switch {
		case a.k < c.k:
			return -1
		case a.k > c.k:
			return 1
		}
		return int(a.id) - int(c.id)
	})
	b.coreS = make([][]syn, nCore)
	b.coreOut = make([][nGoal]float32, nCore)
	arena := &synArena{}
	for i := 0; i < nCore; i++ {
		r := newRG(b.seed, i, 4)
		var cur [maxOutDeg]syn
		n := 0
		for k := 0; k < nBouton && n < maxOutDeg; k++ {
			near(ents, bouts[i*nBouton+k], func(e *ent) bool {
				if int(e.id) == i {
					return true
				}
				if e.id >= nCore {
					if d := int(e.id) - nCore; b.coreOut[i][d] == 0 {
						b.coreOut[i][d] = 0.3 + 0.4*r.u()
					}
					return true
				}
				for _, s := range cur[:n] {
					if s.to == e.id {
						return true
					}
				}
				w := float32(excLo + (excHi-excLo)*float64(r.u()))
				if b.inhib[i] {
					w = -float32(inhScale) * (0.25 + 0.5*r.u())
				}
				cur[n] = syn{e.id, w}
				n++
				return n < maxOutDeg
			})
		}
		b.coreS[i] = arena.take(cur[:n])
	}
	b.kcCore = make([][]int32, nKC)
	var kb []pt
	for k := 0; k < nKC; k++ {
		kb = b.kcShape(k, nil, kb)
		var tg []int32
		for _, q := range kb {
			near(ents, q, func(e *ent) bool {
				if e.id < nCore && !slices.Contains(tg, e.id) {
					tg = append(tg, e.id)
				}
				return len(tg) < kcMaxDeg
			})
		}
		b.kcCore[k] = tg
	}
	for i := range b.coreOut {
		for d := 0; d < nGoal; d++ {
			b.outNorm[d] += float64(b.coreOut[i][d])
		}
	}
}

// Stats describes the wiring: mean synapses per core neuron, core neurons with no outgoing synapse, mean contacts per Kenyon cell, output synapses.
func (b *Brain) Stats() (meanOut float64, silent int, meanKC float64, outSyns int) {
	tot := 0
	for _, s := range b.coreS {
		tot += len(s)
		if len(s) == 0 {
			silent++
		}
	}
	k := 0
	for _, t := range b.kcCore {
		k += len(t)
	}
	for i := range b.coreOut {
		for d := 0; d < nGoal; d++ {
			if b.coreOut[i][d] > 0 {
				outSyns++
			}
		}
	}
	return float64(tot) / nCore, silent, float64(k) / nKC, outSyns
}

// synArena hands out the synapse lists of all neurons from big blocks, so that 50 million synapses cost exactly their size (no growth by doubling).
type synArena struct{ block []syn }

func (a *synArena) take(src []syn) []syn {
	if len(src) == 0 {
		return nil
	}
	if cap(a.block)-len(a.block) < len(src) {
		a.block = make([]syn, 0, 1<<20)
	}
	s := len(a.block)
	a.block = append(a.block, src...)
	return a.block[s:len(a.block):len(a.block)]
}
