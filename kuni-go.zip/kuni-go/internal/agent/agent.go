// Package agent wires everything together: Telegram updates -> per-chat sessions
// -> LLM tool loop (tools act back on Telegram) -> diary + working memory dump
// when the conversation goes idle. It is the Go counterpart of App/Worker/AppBase.
package agent

import (
	"context"
	"fmt"
	"log"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"kuni/internal/config"
	"kuni/internal/diary"
	"kuni/internal/llm"
	"kuni/internal/llmui"
	"kuni/internal/memory"
	"kuni/internal/metrics"
	"kuni/internal/prompts"
	"kuni/internal/telegram"
	"kuni/internal/tools"
	"kuni/internal/util"
)

type Agent struct {
	Cfg     *config.Holder
	LLM     *llm.Client
	TG      telegram.Client
	Diary   *diary.Diary
	Prompts *prompts.Store
	UI      *llmui.Env
	Dumper  *memory.Dumper
	Metrics *metrics.Registry
	Deps    tools.Deps

	active   atomic.Int32
	mu       sync.Mutex
	sessions map[int64]*session
	timers   map[int64]*time.Timer
}

type session struct {
	mu    sync.Mutex // serialises turns
	id    int64
	msgs  []llm.Message
	last  time.Time
	tools *tools.Registry
	chat  telegram.Chat
	fresh bool // true until the first turn (working memory is injected once)
}

// New initialises internal state of a (fill the exported fields first).
func New(a *Agent) *Agent {
	a.sessions = map[int64]*session{}
	a.timers = map[int64]*time.Timer{}
	return a
}

// SystemPrompt is system + character_base + <your_appearance> (AppBase::getSystemPrompt).
func (a *Agent) SystemPrompt() string {
	return a.Prompts.Get(prompts.System) + "\n\n" + a.Prompts.Get(prompts.CharacterBase) +
		"\n\n<your_appearance>\n" + a.Prompts.Get(prompts.CharacterAppearance) + "\n</your_appearance>"
}

// Run processes Telegram updates until ctx ends, then dumps all open sessions.
func (a *Agent) Run(ctx context.Context) {
	var wg sync.WaitGroup
	wg.Add(2)
	go func() { defer wg.Done(); a.idleLoop(ctx) }()
	go func() { defer wg.Done(); a.proactiveLoop(ctx) }()

	// handle messages that arrived while we were offline
	if chats, err := a.TG.Chats(ctx, 100); err == nil {
		for _, c := range chats {
			if c.Unread > 0 {
				a.schedule(ctx, c.ID)
			}
		}
	}

	updates := a.TG.Updates()
loop:
	for {
		select {
		case <-ctx.Done():
			break loop
		case m, ok := <-updates:
			if !ok {
				break loop
			}
			a.Metrics.Inc("kuni_telegram_messages_received_total", 1, nil)
			a.schedule(ctx, m.ChatID)
		}
	}
	wg.Wait()

	// graceful shutdown: give the LLM time to dump the remaining context.
	dumpCtx, cancel := context.WithTimeout(context.Background(), 3*time.Minute)
	defer cancel()
	a.DumpAll(dumpCtx)
}

// schedule debounces bursts of messages, then handles the chat once.
func (a *Agent) schedule(ctx context.Context, chatID int64) {
	delay := a.Cfg.Get().DebounceWindow
	a.mu.Lock()
	defer a.mu.Unlock()
	if t, ok := a.timers[chatID]; ok {
		t.Stop()
	}
	a.timers[chatID] = time.AfterFunc(delay, func() {
		if ctx.Err() != nil {
			return
		}
		if err := a.HandleChat(ctx, chatID); err != nil {
			log.Printf("agent: chat %d: %v", chatID, err)
		}
	})
}

func (a *Agent) getSession(id int64) *session {
	a.mu.Lock()
	defer a.mu.Unlock()
	s := a.sessions[id]
	if s == nil {
		s = &session{id: id, fresh: true}
		a.sessions[id] = s
		a.Metrics.Set("kuni_sessions_active", float64(len(a.sessions)), nil)
	}
	return s
}

func (a *Agent) baseTools(d tools.Deps, proactive bool) []tools.Tool {
	ts := tools.GlobalTools(d, proactive)
	return append(ts, tools.AskTool(d))
}

// HandleChat reads unread messages of a chat and lets the model act on them.
func (a *Agent) HandleChat(ctx context.Context, chatID int64) error {
	cfg := a.Cfg.Get()
	if !tools.Accessible(cfg, chatID) {
		_ = a.TG.MarkRead(ctx, chatID)
		return nil
	}
	chat, err := a.TG.Chat(ctx, chatID)
	if err != nil {
		return err
	}
	unread, err := a.TG.Unread(ctx, chatID)
	if err != nil || len(unread) == 0 {
		return err
	}
	s := a.getSession(chatID)
	s.mu.Lock()
	defer s.mu.Unlock()
	defer a.goOnline(ctx)()

	view, err := a.renderChat(ctx, s, chat, unread)
	if err != nil {
		return err
	}
	_ = a.TG.MarkRead(ctx, chatID)
	s.msgs = append(s.msgs, llm.Message{Role: "user", Content: view})
	return a.runTurn(ctx, s)
}

// renderChat builds the text the model sees when it opens a chat and (re)binds the chat tools.
func (a *Agent) renderChat(ctx context.Context, s *session, chat telegram.Chat, unread []telegram.Message) (string, error) {
	now := time.Now()
	d := a.depsFor(s)
	s.chat = chat
	s.tools = tools.NewRegistry(append(a.baseTools(d, false), chatToolList(d, chat)...)...)

	var b strings.Builder
	if s.fresh {
		s.fresh = false
		if wm, _ := (memory.WorkingMemory{Path: a.Cfg.Get().WorkingMemoryFile}).Load(); strings.TrimSpace(wm) != "" {
			b.WriteString("<things_to_remember>\n" + wm + "\n</things_to_remember>\n\n")
		}
	}
	// thoughts popping up: diary entries related to what was just read (RAG).
	if rec := a.recall(ctx, unread); rec != "" {
		b.WriteString(rec + "\n")
	}
	fmt.Fprintf(&b, "You switched to the chat %q in Telegram. You see last messages:\n", chat.Title)
	if hist, _ := a.TG.History(ctx, chat.ID, 0, 12+len(unread), 0); len(hist) > len(unread) {
		older := hist[:len(hist)-len(unread)]
		b.WriteString("<earlier_messages>\n" + a.UI.FormatMessages(ctx, older, now) + "</earlier_messages>\n")
	}
	b.WriteString(a.UI.FormatMessages(ctx, unread, now))
	b.WriteString(a.chatInstructions(chat))
	return b.String(), nil
}

func chatToolList(d tools.Deps, chat telegram.Chat) []tools.Tool {
	r := tools.ChatTools(d, chat)
	var out []tools.Tool
	for _, n := range r.Names() {
		t, _ := r.Get(n)
		out = append(out, t)
	}
	return out
}

func (a *Agent) chatInstructions(chat telegram.Chat) string {
	epilogue := a.Prompts.Get(prompts.MessagesEpilogue)
	switch {
	case !chat.IsMember && chat.Kind != telegram.ChatPrivate:
		return fmt.Sprintf("\n<instructions>\nYou are NOT a member of %q. You can't send messages here; you can only #react_with_emoji to messages, or use #join_chat to become a member.\n</instructions>\n", chat.Title)
	case chat.Kind == telegram.ChatChannel:
		return fmt.Sprintf("\n<instructions>\nYou are in telegram channel called %q.\nPay close attention to these messages. Acquire context from them. You can't respond in telegram channels (#send_telegram_message is not available). Instead, do what you usually do when reading newsletters: reflect and reason on them.\nSome channels have reactions enabled: you can sometimes #react_with_emoji.\nIf a post is genuinely interesting or relevant to someone you know, you can forward it with #forward_message. Be selective. Do NOT forward ads, sponsored posts, or low-value content.\n</instructions>\n", chat.Title)
	case chat.Kind == telegram.ChatGroup:
		return fmt.Sprintf("\n<instructions>\nYou are in group chat called %q.\n\n%s\n</instructions>\n", chat.Title, epilogue)
	default:
		return fmt.Sprintf("\n<instructions>\nYou are in private chat with %s (also known as direct messages or DM).\n\n%s\n</instructions>\n", chat.Title, epilogue)
	}
}

// recall queries the diary with the text of the unread messages.
func (a *Agent) recall(ctx context.Context, msgs []telegram.Message) string {
	if a.Diary == nil {
		return ""
	}
	var parts []string
	for _, m := range msgs {
		if strings.TrimSpace(m.Text) != "" {
			parts = append(parts, m.SenderName+": "+m.Text)
		}
	}
	if len(parts) == 0 {
		return ""
	}
	if len(parts) > 5 {
		parts = parts[len(parts)-5:]
	}
	vec, err := a.LLM.Embedding(ctx, strings.Join(parts, "\n"))
	if err != nil {
		log.Printf("agent: recall embedding: %v", err)
		return ""
	}
	entries, err := a.Diary.Load()
	if err != nil {
		return ""
	}
	related, err := a.Diary.Query(ctx, entries, vec, a.Cfg.Get().MaxRelatedEntries)
	if err != nil || len(related) == 0 {
		return ""
	}
	var b strings.Builder
	b.WriteString("<memories_that_popped_up_in_mind>\n")
	for _, r := range related {
		fmt.Fprintf(&b, "<memory>\n%s\n</memory>\n", r.Entry.Body)
	}
	b.WriteString("</memories_that_popped_up_in_mind>\n")
	return b.String()
}

func (a *Agent) depsFor(s *session) tools.Deps {
	d := a.Deps
	d.OpenChat = func(ctx context.Context, id int64) (string, error) { return a.openChat(ctx, s, id) }
	return d
}

// openChat is the open_chat tool backend for proactive sessions.
func (a *Agent) openChat(ctx context.Context, s *session, chatID int64) (string, error) {
	chat, err := a.TG.Chat(ctx, chatID)
	if err != nil {
		return "", fmt.Errorf("chat %d not found", chatID)
	}
	unread, _ := a.TG.Unread(ctx, chatID)
	hist, _ := a.TG.History(ctx, chatID, 0, 20, 0)
	var b strings.Builder
	fmt.Fprintf(&b, "You switched to the chat %q in Telegram. You see last messages:\n", chat.Title)
	b.WriteString(a.UI.FormatMessages(ctx, hist, time.Now()))
	b.WriteString(a.chatInstructions(chat))
	d := a.depsFor(s)
	s.chat = chat
	s.tools = tools.NewRegistry(append(a.baseTools(d, true), chatToolList(d, chat)...)...)
	if len(unread) > 0 {
		_ = a.TG.MarkRead(ctx, chatID)
	}
	return b.String(), nil
}

// runTurn is the LLM <-> tools loop. The model's plain-text answer is its private
// "thought"; only tool calls have effects.
func (a *Agent) runTurn(ctx context.Context, s *session) error {
	cfg := a.Cfg.Get()
	a.Metrics.Inc("kuni_agent_turns_total", 1, nil)
	system := a.SystemPrompt()
	for round := 0; round < cfg.MaxToolRounds; round++ {
		reply, err := a.LLM.Complete(ctx, system, trim(s.msgs, 80), s.tools.Defs())
		if err != nil {
			return err
		}
		if strings.TrimSpace(reply.Content) == "" && len(reply.ToolCalls) == 0 {
			continue // blank answer from a local model: ask again
		}
		s.msgs = append(s.msgs, reply)
		s.last = time.Now()
		if len(reply.ToolCalls) == 0 {
			return nil
		}
		chatLabel := s.chat.Title
		if s.id == 0 {
			chatLabel = "proactive"
		}
		for _, c := range reply.ToolCalls {
			start := time.Now()
			out := s.tools.Call(ctx, c.Function.Name, c.Function.Arguments)
			s.msgs = append(s.msgs, llm.Message{Role: "tool", ToolCallID: c.ID, Content: out})
			a.Metrics.Inc("kuni_tool_calls_total", 1, map[string]string{"tool": c.Function.Name})
			// names used by the original Grafana dashboard
			labels := map[string]string{"tool": c.Function.Name, "function": c.Function.Name, "chat": chatLabel}
			a.Metrics.Inc("tool_call_total", 1, labels)
			a.Metrics.Set("tool_call_response_time_seconds_gauge", time.Since(start).Seconds(), labels)
		}
	}
	log.Printf("agent: chat %d: tool round limit (%d) reached", s.id, cfg.MaxToolRounds)
	return nil
}

// trim keeps the last n messages, starting at a user message so tool-call pairs stay intact.
func trim(msgs []llm.Message, n int) []llm.Message {
	if len(msgs) <= n {
		return msgs
	}
	cut := len(msgs) - n
	for cut < len(msgs) && msgs[cut].Role != "user" {
		cut++
	}
	if cut >= len(msgs) {
		return msgs[len(msgs)-1:]
	}
	return msgs[cut:]
}

// idleLoop dumps sessions that have been silent for SessionIdle.
func (a *Agent) idleLoop(ctx context.Context) {
	t := time.NewTicker(30 * time.Second)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
			idle := a.Cfg.Get().SessionIdle
			var ids []int64
			a.mu.Lock()
			for id, s := range a.sessions {
				if !s.last.IsZero() && time.Since(s.last) >= idle {
					ids = append(ids, id)
				}
			}
			a.mu.Unlock()
			for _, id := range ids {
				if err := a.dump(ctx, id); err != nil {
					log.Printf("agent: dump chat %d: %v", id, err)
				}
			}
		}
	}
}

// dump saves one session to the diary/working memory and forgets it.
func (a *Agent) dump(ctx context.Context, id int64) error {
	a.mu.Lock()
	s := a.sessions[id]
	a.mu.Unlock()
	if s == nil {
		return nil
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	msgs := flatten(s.msgs)
	if len(msgs) > 0 && a.Dumper != nil {
		a.Dumper.WM = memory.WorkingMemory{Path: a.Cfg.Get().WorkingMemoryFile}
		if err := a.Dumper.DumpSession(ctx, a.SystemPrompt(), msgs); err != nil {
			return err // keep the session; retry on the next idle tick
		}
	}
	a.mu.Lock()
	delete(a.sessions, id)
	a.Metrics.Set("kuni_sessions_active", float64(len(a.sessions)), nil)
	a.mu.Unlock()
	return nil
}

// DumpAll flushes every open session (shutdown).
func (a *Agent) DumpAll(ctx context.Context) {
	a.mu.Lock()
	ids := make([]int64, 0, len(a.sessions))
	for id := range a.sessions {
		ids = append(ids, id)
	}
	a.mu.Unlock()
	for _, id := range ids {
		if err := a.dump(ctx, id); err != nil {
			log.Printf("agent: dump chat %d: %v", id, err)
		}
	}
}

// flatten turns tool-calling history into a plain transcript: dump calls have no tools,
// and many servers reject tool messages without a tools parameter.
func flatten(msgs []llm.Message) []llm.Message {
	if len(msgs) == 0 {
		return nil
	}
	var b strings.Builder
	for _, m := range msgs {
		switch m.Role {
		case "user":
			b.WriteString(m.Content + "\n")
		case "assistant":
			if strings.TrimSpace(m.Content) != "" {
				b.WriteString("[your thoughts] " + m.Content + "\n")
			}
			for _, c := range m.ToolCalls {
				fmt.Fprintf(&b, "[you called #%s %s]\n", c.Function.Name, c.Function.Arguments)
			}
		case "tool":
			b.WriteString("[tool result] " + m.Content + "\n")
		}
	}
	text := b.String()
	if len(text) > 60000 {
		text = text[len(text)-60000:]
	}
	return []llm.Message{{Role: "user", Content: "<session_transcript>\n" + text + "\n</session_transcript>"}}
}

// proactiveLoop periodically lets the model look through its chats on its own.
func (a *Agent) proactiveLoop(ctx context.Context) {
	for {
		iv := a.Cfg.Get().Proactive
		wait := iv
		if iv <= 0 {
			wait = time.Minute // config may be enabled later via hot reload
		}
		select {
		case <-ctx.Done():
			return
		case <-time.After(wait):
		}
		if iv <= 0 {
			continue
		}
		if err := a.ActProactively(ctx); err != nil {
			log.Printf("agent: proactive: %v", err)
		}
	}
}

// ActProactively runs a session in which the model decides whom to write to.
func (a *Agent) ActProactively(ctx context.Context) error {
	s := a.getSession(0)
	s.mu.Lock()
	defer s.mu.Unlock()
	d := a.depsFor(s)
	s.tools = tools.NewRegistry(a.baseTools(d, true)...)
	msg := "You have some free time and nobody is writing to you right now. Check your chats with #get_telegram_chats " +
		"(open one with #open_chat) and decide if there is somebody you would like to write to, or something to revisit " +
		"from <things_to_remember>. If there is nothing worth doing, just reflect briefly and do nothing."
	if s.fresh {
		s.fresh = false
		if wm, _ := (memory.WorkingMemory{Path: a.Cfg.Get().WorkingMemoryFile}).Load(); strings.TrimSpace(wm) != "" {
			msg = "<things_to_remember>\n" + wm + "\n</things_to_remember>\n\n" + msg
		}
	}
	msg = fmt.Sprintf("It is %s.\n%s", time.Now().Format("Mon Jan 2 15:04"), msg)
	s.msgs = append(s.msgs, llm.Message{Role: "user", Content: msg})
	return a.runTurn(ctx, s)
}

var _ = util.TimeAgo

// SessionSummaries describes open sessions for the debug page.
func (a *Agent) SessionSummaries() []string {
	a.mu.Lock()
	defer a.mu.Unlock()
	var out []string
	for id, s := range a.sessions {
		title := "proactive"
		if id != 0 {
			title = s.chat.Title
		}
		out = append(out, fmt.Sprintf("%s (id %d): %d messages, last activity %s", title, id, len(s.msgs), util.TimeAgo(s.last, time.Now())))
	}
	return out
}

// goOnline shows the account as online while a turn runs (user mode only) and
// returns a func that schedules going offline again shortly after the last turn.
func (a *Agent) goOnline(ctx context.Context) func() {
	p, ok := a.TG.(interface {
		SetOnline(ctx context.Context, online bool)
	})
	if !ok {
		return func() {}
	}
	if a.active.Add(1) == 1 {
		p.SetOnline(ctx, true)
	}
	return func() {
		a.active.Add(-1)
		time.AfterFunc(20*time.Second, func() {
			if a.active.Load() == 0 {
				c, cancel := context.WithTimeout(context.Background(), 10*time.Second)
				defer cancel()
				p.SetOnline(c, false)
			}
		})
	}
}
