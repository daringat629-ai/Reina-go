package desktop

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"image/jpeg"
	"os"
	"os/exec"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

// Options of a desktop session.
type Options struct {
	Width, Height int
	Idle          time.Duration
	// Command builds the command for a shell line (the owner's shell rules apply: user, hard block). nil = sh -c.
	Command func(ctx context.Context, line string) (*exec.Cmd, error)
}

// Desktop is the virtual screen with the programs on it. It starts on first use and stops after Idle of inactivity.
type Desktop struct {
	mu      sync.Mutex
	xvfb    *exec.Cmd
	display string
	x       *X
	apps    []*exec.Cmd
	cancel  context.CancelFunc
	bg      context.Context
	idle    *time.Timer
	idleFor time.Duration

	// the live view has its own connection and lock: it must not wait for a long action (nor disturb it)
	liveMu      sync.Mutex
	liveDisplay string
	viewer      *X
	// pointer is where the last mouse move went (x<<32|y, 0 = never); the screenshot does not draw the cursor.
	pointer atomic.Uint64
}

// Pointer returns the last pointer position on the running desktop and whether there is one.
func (d *Desktop) Pointer() (x, y int, ok bool) {
	v := d.pointer.Load()
	return int(int32(uint32(v >> 32))), int(int32(uint32(v))), v != 0
}

func New() *Desktop { return &Desktop{} }

// Do runs fn with the screen up.
func (d *Desktop) Do(ctx context.Context, opt Options, fn func(s *Screen) error) error {
	if opt.Width < 320 {
		opt.Width = 1280
	}
	if opt.Height < 240 {
		opt.Height = 800
	}
	if opt.Idle <= 0 {
		opt.Idle = 10 * time.Minute
	}
	d.mu.Lock()
	defer d.mu.Unlock()
	if d.idle != nil {
		d.idle.Stop()
	}
	if err := d.ensure(ctx, opt); err != nil {
		d.closeLocked()
		return err
	}
	err := fn(&Screen{d: d, opt: opt})
	d.idleFor = opt.Idle
	d.idle = time.AfterFunc(opt.Idle, d.Close)
	return err
}

func (d *Desktop) Running() bool {
	d.mu.Lock()
	defer d.mu.Unlock()
	return d.xvfb != nil
}

func (d *Desktop) Close() {
	d.mu.Lock()
	defer d.mu.Unlock()
	d.closeLocked()
}

func (d *Desktop) closeLocked() {
	if d.idle != nil {
		d.idle.Stop()
		d.idle = nil
	}
	if d.cancel != nil {
		d.cancel()
	}
	for _, a := range d.apps {
		killTree(a.Process)
	}
	d.apps = nil
	if d.x != nil {
		d.x.Close()
		d.x = nil
	}
	if d.xvfb != nil {
		killTree(d.xvfb.Process)
		d.xvfb = nil
	}
	d.display = ""
	d.pointer.Store(0)
	d.liveMu.Lock()
	d.liveDisplay = ""
	if d.viewer != nil {
		d.viewer.Close()
		d.viewer = nil
	}
	d.liveMu.Unlock()
}

func (d *Desktop) ensure(ctx context.Context, opt Options) error {
	if d.xvfb != nil && d.x != nil {
		return nil
	}
	bin, err := exec.LookPath("Xvfb")
	if err != nil {
		return errors.New("для рабочего стола нужен Xvfb (Alpine: apk add xvfb)")
	}
	r, w, err := os.Pipe()
	if err != nil {
		return err
	}
	defer r.Close()
	cmd := exec.Command(bin, "-displayfd", "3", "-screen", "0", fmt.Sprintf("%dx%dx24", opt.Width, opt.Height), "-nolisten", "tcp", "-ac") // local socket only; -ac lets the programs of her shell user in
	cmd.ExtraFiles = []*os.File{w}
	ownGroup(cmd)
	if err := cmd.Start(); err != nil {
		w.Close()
		return err
	}
	w.Close()
	go func() { _ = cmd.Wait() }()
	got := make(chan string, 1)
	go func() {
		buf := make([]byte, 32)
		n, _ := r.Read(buf)
		got <- strings.TrimSpace(string(buf[:n]))
	}()
	select {
	case n := <-got:
		if n == "" {
			killTree(cmd.Process)
			return errors.New("Xvfb не запустился")
		}
		d.display = ":" + n
		d.liveMu.Lock()
		d.liveDisplay = d.display
		d.liveMu.Unlock()
	case <-time.After(10 * time.Second):
		killTree(cmd.Process)
		return errors.New("Xvfb не ответил за 10 с")
	case <-ctx.Done():
		killTree(cmd.Process)
		return ctx.Err()
	}
	d.xvfb = cmd
	if err := WaitForSocket(d.display, 5*time.Second); err != nil {
		return err
	}
	if d.x, err = Dial(d.display); err != nil {
		return err
	}
	d.x.OnMotion = func(px, py int) { d.pointer.Store(uint64(uint32(int32(px)))<<32 | uint64(uint32(int32(py)))) }
	d.bg, d.cancel = context.WithCancel(context.Background())
	return nil
}

// Screen is the desktop while a Do call holds it.
type Screen struct {
	d   *Desktop
	opt Options
}

func (s *Screen) X() *X { return s.d.x }

// Display is the DISPLAY value programs need.
func (s *Screen) Display() string { return s.d.display }

// Launch starts a program (a shell line) on the screen; it keeps running after the call. It returns after a moment so
// that a quick failure is reported.
func (s *Screen) Launch(line string) error {
	d := s.d
	var cmd *exec.Cmd
	var err error
	if s.opt.Command != nil {
		cmd, err = s.opt.Command(d.bg, line)
	} else {
		cmd = exec.CommandContext(d.bg, "sh", "-c", line)
	}
	if err != nil {
		return err
	}
	cmd.Env = append(os.Environ(), "DISPLAY="+d.display)
	if cmd.Dir == "" {
		cmd.Dir = os.TempDir()
	}
	out := &limited{}
	cmd.Stdout, cmd.Stderr = out, out
	ownGroup(cmd)
	cmd.WaitDelay = time.Second
	if err := cmd.Start(); err != nil {
		return err
	}
	done := make(chan error, 1)
	go func() { done <- cmd.Wait() }()
	select {
	case err := <-done:
		msg := strings.TrimSpace(out.String())
		if err != nil {
			return fmt.Errorf("программа сразу завершилась: %v %s", err, msg)
		}
		return nil // a launcher that started something else and exited is fine
	case <-time.After(1500 * time.Millisecond):
		d.apps = append(d.apps, cmd)
		return nil
	}
}

type limited struct {
	mu sync.Mutex
	b  strings.Builder
}

func (l *limited) Write(p []byte) (int, error) {
	l.mu.Lock()
	defer l.mu.Unlock()
	if l.b.Len() < 2000 {
		l.b.Write(p)
	}
	return len(p), nil
}

func (l *limited) String() string {
	l.mu.Lock()
	defer l.mu.Unlock()
	return l.b.String()
}

// Frame returns the current screen as a JPEG for the live view, without waiting for the actions in progress.
// ok is false when the desktop is not running.
func (d *Desktop) Frame() (jpegData []byte, ok bool, err error) {
	d.liveMu.Lock()
	defer d.liveMu.Unlock()
	if d.liveDisplay == "" {
		return nil, false, nil
	}
	if d.viewer == nil {
		if d.viewer, err = Dial(d.liveDisplay); err != nil {
			return nil, false, err
		}
	}
	img, err := d.viewer.Screenshot()
	if err != nil {
		d.viewer.Close()
		d.viewer = nil
		return nil, false, err
	}
	var buf bytes.Buffer
	if err := jpeg.Encode(&buf, img, &jpeg.Options{Quality: 62}); err != nil {
		return nil, false, err
	}
	return buf.Bytes(), true, nil
}

// Live says whether the desktop is up, without waiting for the actions in progress.
func (d *Desktop) Live() bool {
	d.liveMu.Lock()
	defer d.liveMu.Unlock()
	return d.liveDisplay != ""
}
