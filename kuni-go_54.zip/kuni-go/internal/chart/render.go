package chart

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"image"
	"image/draw"
	"image/png"
	"math"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"time"
)

// ErrNoRenderer: no program on the machine can turn SVG into PNG.
var ErrNoRenderer = errors.New("nothing here turns a chart into a picture: install chromium (or librsvg / imagemagick)")

// Render turns the SVG into PNG. browser is the Chromium binary ("" = look for rsvg-convert and ImageMagick only).
func Render(ctx context.Context, svg string, width, height int, browser string) ([]byte, error) {
	dir, err := os.MkdirTemp("", "kuni-chart-")
	if err != nil {
		return nil, err
	}
	defer os.RemoveAll(dir)
	in := filepath.Join(dir, "chart.svg")
	out := filepath.Join(dir, "chart.png")
	if err := os.WriteFile(in, []byte(svg), 0o600); err != nil {
		return nil, err
	}
	ctx, cancel := context.WithTimeout(ctx, 60*time.Second)
	defer cancel()
	var tried []string
	run := func(name string, args ...string) ([]byte, bool) {
		cmd := exec.CommandContext(ctx, name, args...)
		var stderr bytes.Buffer
		cmd.Stderr = &stderr
		if err := cmd.Run(); err != nil {
			tried = append(tried, fmt.Sprintf("%s: %v %.200s", filepath.Base(name), err, stderr.String()))
			return nil, false
		}
		b, err := os.ReadFile(out)
		if err != nil || len(b) < 8 || string(b[1:4]) != "PNG" {
			tried = append(tried, filepath.Base(name)+": no picture")
			return nil, false
		}
		return b, true
	}
	if browser != "" {
		page := filepath.Join(dir, "chart.html")
		doc := `<!doctype html><html><head><meta charset="utf-8"><style>html,body{margin:0;padding:0;background:#fff;overflow:hidden}</style></head><body>` + svg + `</body></html>`
		if err := os.WriteFile(page, []byte(doc), 0o600); err == nil {
			args := []string{"--headless=new", "--disable-gpu", "--hide-scrollbars", "--no-first-run", "--disable-extensions",
				"--force-device-scale-factor=2", "--default-background-color=ffffffff", "--user-data-dir=" + filepath.Join(dir, "profile"),
				// the new headless mode takes the window frame off the height: a taller window, cropped afterwards
				fmt.Sprintf("--window-size=%d,%d", width, height+240), "--screenshot=" + out, "file://" + page}
			if os.Geteuid() == 0 {
				args = append([]string{"--no-sandbox"}, args...)
			}
			if b, ok := run(browser, args...); ok {
				return crop(b, width*2, height*2)
			}
		}
	}
	if p, err := exec.LookPath("rsvg-convert"); err == nil {
		if b, ok := run(p, "-w", strconv.Itoa(width*2), "-b", "white", "-o", out, in); ok {
			return b, nil
		}
	}
	for _, name := range []string{"magick", "convert"} {
		if p, err := exec.LookPath(name); err == nil {
			if b, ok := run(p, "-density", "192", "-background", "white", in, out); ok {
				return b, nil
			}
		}
	}
	if len(tried) == 0 {
		return nil, ErrNoRenderer
	}
	return nil, fmt.Errorf("could not draw the chart: %s", strings.Join(tried, "; "))
}

// FromRows builds a chart from rows of text: the first row names the columns, the first column holds the labels,
// every other column is a series of numbers ("1 200,5" and "15%" are read too; anything else is a gap). One column
// of numbers alone gets the labels 1, 2, 3...
func FromRows(rows [][]string, kind string) (Chart, error) {
	var clean [][]string
	for _, r := range rows {
		empty := true
		for _, c := range r {
			if strings.TrimSpace(c) != "" {
				empty = false
			}
		}
		if !empty {
			clean = append(clean, r)
		}
	}
	if len(clean) == 0 {
		return Chart{}, errors.New("no data")
	}
	header := clean[0]
	body := clean[1:]
	// no header row: the first row is numbers already
	if allNumbers(header[min(1, len(header)-1):]) {
		header = make([]string, len(clean[0]))
		body = clean
	}
	cols := 0
	for _, r := range clean {
		cols = max(cols, len(r))
	}
	c := Chart{Kind: kind}
	col0 := column(body, 0)
	labels := cols >= 2 && (!allNumbers(col0) || looksLikeLabels(col0))
	for _, r := range body {
		if labels {
			c.Labels = append(c.Labels, strings.TrimSpace(at(r, 0)))
		} else {
			c.Labels = append(c.Labels, strconv.Itoa(len(c.Labels)+1))
		}
	}
	first := 0
	if labels {
		first = 1
	}
	for col := first; col < cols; col++ {
		s := Series{Name: strings.TrimSpace(at(header, col))}
		if s.Name == "" {
			s.Name = fmt.Sprintf("ряд %d", col-first+1)
		}
		valid := 0
		for _, r := range body {
			v := parse(at(r, col))
			if !math.IsNaN(v) {
				valid++
			}
			s.Values = append(s.Values, v)
		}
		if valid > 0 {
			c.Series = append(c.Series, s)
		}
	}
	if len(c.Series) == 0 {
		return Chart{}, errors.New("no numbers in the data: the first column holds the labels, the others the numbers")
	}
	return c, nil
}

func at(r []string, i int) string {
	if i < len(r) {
		return r[i]
	}
	return ""
}

func column(rows [][]string, i int) []string {
	out := make([]string, 0, len(rows))
	for _, r := range rows {
		out = append(out, at(r, i))
	}
	return out
}

func allNumbers(ss []string) bool {
	if len(ss) == 0 {
		return false
	}
	for _, s := range ss {
		if math.IsNaN(parse(s)) {
			return false
		}
	}
	return true
}

// looksLikeLabels: years (2021, 2022...) and small sequences in the first column are labels, not a series.
func looksLikeLabels(ss []string) bool {
	for _, s := range ss {
		v := parse(s)
		if v != math.Trunc(v) || v < 1 || (v > 31 && (v < 1900 || v > 2200)) {
			return false
		}
	}
	return true
}

// parse reads "1 200,5", "-3.5", "15%" (= 15); anything else is NaN.
func parse(s string) float64 {
	s = strings.TrimSpace(s)
	s = strings.TrimSuffix(s, "%")
	s = strings.NewReplacer(" ", "", " ", "", " ", "", ",", ".", "−", "-").Replace(s)
	if s == "" {
		return math.NaN()
	}
	v, err := strconv.ParseFloat(s, 64)
	if err != nil || math.IsInf(v, 0) {
		return math.NaN()
	}
	return v
}

// crop cuts the screenshot to the chart (top left w×h pixels).
func crop(b []byte, w, h int) ([]byte, error) {
	src, err := png.Decode(bytes.NewReader(b))
	if err != nil {
		return nil, err
	}
	r := src.Bounds()
	w, h = min(w, r.Dx()), min(h, r.Dy())
	dst := image.NewRGBA(image.Rect(0, 0, w, h))
	draw.Draw(dst, dst.Bounds(), src, r.Min, draw.Src)
	var out bytes.Buffer
	enc := png.Encoder{CompressionLevel: png.BestCompression}
	if err := enc.Encode(&out, dst); err != nil {
		return nil, err
	}
	return out.Bytes(), nil
}
