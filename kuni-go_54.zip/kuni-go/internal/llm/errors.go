package llm

import (
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"time"
)

// APIError is an answer of the provider that is not a completion: an HTTP error status, or an error object inside
// a 200 answer (OpenRouter forwards the failures of the provider behind it like that).
type APIError struct {
	Status     int    // HTTP status, or the code of the error object
	Body       string // what the server said (cut)
	RetryAfter time.Duration
}

func (e *APIError) Error() string { return fmt.Sprintf("llm: HTTP %d: %s", e.Status, e.Body) }

// Temporary reports whether the same request may succeed later: rate limits, timeouts and server errors.
// Everything else (bad key, no credit, unknown model, a request the server rejects) needs a person to fix it.
func (e *APIError) Temporary() bool {
	return e.Status == http.StatusTooManyRequests || e.Status == http.StatusRequestTimeout || e.Status >= 500
}

// Permanent reports whether err is an answer of the provider that repeating cannot fix (see APIError.Temporary).
// Network failures and timeouts are not permanent.
func Permanent(err error) bool {
	var ae *APIError
	return errors.As(err, &ae) && !ae.Temporary()
}

// upstreamError turns the "error" object of a 200 answer into an APIError.
func upstreamError(raw json.RawMessage) error {
	var e struct {
		Code    any    `json:"code"`
		Message string `json:"message"`
	}
	ae := &APIError{Status: http.StatusBadGateway, Body: "upstream error: " + strings.TrimSpace(string(raw))}
	if json.Unmarshal(raw, &e) == nil {
		switch c := e.Code.(type) {
		case float64:
			if c >= 400 && c < 600 {
				ae.Status = int(c)
			}
		case string:
			if n, err := strconv.Atoi(c); err == nil && n >= 400 && n < 600 {
				ae.Status = n
			}
		}
		if e.Message != "" {
			ae.Body = "upstream error: " + e.Message
		}
	}
	if len(ae.Body) > 600 {
		ae.Body = ae.Body[:600] + "…"
	}
	return ae
}
