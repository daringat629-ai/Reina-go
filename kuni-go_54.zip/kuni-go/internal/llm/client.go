// Package llm is an OpenAI-compatible HTTP client: chat with tool calling and
// vision parts, SSE streaming and embeddings. Port of OpenAIChatImpl.
//
// A request is described by a Request value (system prompt, history, tools and the per-request overrides: model,
// reasoning, tool choice). What the tokens are spent on travels in the context instead (WithPurpose, WithChat),
// because it belongs to the job, not to the single call: a tool that asks the model on her behalf in a chat is
// accounted to that chat without knowing about it. Everything that happens is reported to one Observer.
package llm

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

// Part is one piece of multimodal content ("text" or "image_url").
type Part struct {
	Type     string // "text" | "image_url"
	Text     string
	ImageURL string // data: URL or http(s) URL
}

type FunctionCall struct {
	Name      string `json:"name"`
	Arguments string `json:"arguments"`
}

// UnmarshalJSON accepts the arguments as the JSON string the OpenAI API specifies, and also as a bare JSON object
// (what some Ollama, vLLM and LM Studio versions send). Without this one such tool call made the whole answer fail.
func (f *FunctionCall) UnmarshalJSON(b []byte) error {
	var raw struct {
		Name      string          `json:"name"`
		Arguments json.RawMessage `json:"arguments"`
	}
	if err := json.Unmarshal(b, &raw); err != nil {
		return err
	}
	f.Name = raw.Name
	f.Arguments = ""
	a := bytes.TrimSpace(raw.Arguments)
	switch {
	case len(a) == 0 || string(a) == "null":
	case a[0] == '"':
		if err := json.Unmarshal(a, &f.Arguments); err != nil {
			return err
		}
	default:
		f.Arguments = string(a)
	}
	return nil
}

type ToolCall struct {
	ID       string       `json:"id"`
	Type     string       `json:"type"`
	Function FunctionCall `json:"function"`
}

type Message struct {
	Role       string     `json:"role"`
	Content    string     `json:"content"`
	Parts      []Part     `json:"-"` // if set, sent instead of Content
	ToolCalls  []ToolCall `json:"tool_calls,omitempty"`
	ToolCallID string     `json:"tool_call_id,omitempty"`
}

// UnmarshalJSON reads "content" as a string, null, or an array of parts (some providers answer with
// [{"type":"text","text":...}]); the text parts are joined into Content.
func (m *Message) UnmarshalJSON(b []byte) error {
	var raw struct {
		Role       string          `json:"role"`
		Content    json.RawMessage `json:"content"`
		ToolCalls  []ToolCall      `json:"tool_calls"`
		ToolCallID string          `json:"tool_call_id"`
	}
	if err := json.Unmarshal(b, &raw); err != nil {
		return err
	}
	*m = Message{Role: raw.Role, ToolCalls: raw.ToolCalls, ToolCallID: raw.ToolCallID}
	c := bytes.TrimSpace(raw.Content)
	switch {
	case len(c) == 0 || string(c) == "null":
	case c[0] == '"':
		return json.Unmarshal(c, &m.Content)
	case c[0] == '[':
		var parts []struct {
			Type string `json:"type"`
			Text string `json:"text"`
		}
		if err := json.Unmarshal(c, &parts); err != nil {
			return err
		}
		var sb strings.Builder
		for _, p := range parts {
			if p.Type == "text" || p.Type == "output_text" || (p.Type == "" && p.Text != "") {
				sb.WriteString(p.Text)
			}
		}
		m.Content = sb.String()
	default:
		return fmt.Errorf("llm: unexpected message content %.40s", c)
	}
	return nil
}

// MarshalJSON emits multimodal content arrays when Parts is set.
func (m Message) MarshalJSON() ([]byte, error) {
	out := map[string]any{"role": m.Role}
	if len(m.Parts) > 0 {
		var arr []map[string]any
		for _, p := range m.Parts {
			if p.Type == "image_url" {
				arr = append(arr, map[string]any{"type": "image_url", "image_url": map[string]string{"url": p.ImageURL}})
			} else {
				arr = append(arr, map[string]any{"type": "text", "text": p.Text})
			}
		}
		out["content"] = arr
	} else {
		out["content"] = m.Content
	}
	if len(m.ToolCalls) > 0 {
		out["tool_calls"] = m.ToolCalls
	}
	if m.ToolCallID != "" {
		out["tool_call_id"] = m.ToolCallID
	}
	return json.Marshal(out)
}

// ToolDef is an OpenAI function tool definition.
type ToolDef struct {
	Type     string   `json:"type"`
	Function ToolFunc `json:"function"`
}

type ToolFunc struct {
	Name        string         `json:"name"`
	Description string         `json:"description"`
	Parameters  map[string]any `json:"parameters"`
}

// Settings are the hot-reloadable connection parameters.
type Settings struct {
	BaseURL          string
	EmbeddingBaseURL string
	APIKey           string
	Model            string
	// LightModel, if set, serves background purposes (see lightPurposes) instead of Model.
	LightModel string
	// FastModel, if set, runs delegated jobs (purpose "delegate"); the agent also picks it per request for fast rounds.
	FastModel string
	// VisionModel, if set, serves requests that look at pictures (purpose "image": photos, stickers, screenshots).
	VisionModel    string
	EmbeddingModel string
	Temperature    *float64
	// Reasoning is OpenRouter-style reasoning control: "" = server default, "off" disables reasoning,
	// "low"/"medium"/"high" set the effort. Reasoning models are 3-10x slower with it on.
	Reasoning string
	// CachePrompt marks the system prompt as cacheable (Anthropic-style cache_control) for models that need it;
	// DeepSeek, OpenAI and others cache a stable prompt prefix on their own.
	CachePrompt bool
}

// Request is one chat completion.
type Request struct {
	System   string
	Messages []Message
	Tools    []ToolDef
	// Model overrides the model chosen by the purpose (the panel's comparison, the fast model of a quick round).
	Model string
	// Reasoning overrides llm.reasoning for this request only ("off" for fast rounds).
	Reasoning string
	// ToolChoice is the OpenAI "tool_choice" ("required" forces a tool call); only sent together with tools.
	ToolChoice string
}

// Usage is the token report of one chat request.
type Usage struct {
	Model, Purpose     string
	Prompt, Completion int
	CachedPromptTokens int
}

// Event is what the client reports after every request (see Observer).
type Event struct {
	Kind     string // chat | embedding | stream
	Model    string
	Purpose  string
	Chat     int64 // the chat the request was made for (WithChat); valid when HasChat
	HasChat  bool
	Duration time.Duration
	Err      error
	// Usage is the token report of a chat request; nil when the server sent none (or the request failed).
	Usage *Usage
}

// Observer receives every Event: metrics, the usage tally and the "the model is down" alert all hang off it.
type Observer interface {
	ObserveLLM(ctx context.Context, e Event)
}

// ObserverFunc adapts a function to Observer.
type ObserverFunc func(ctx context.Context, e Event)

// ObserveLLM calls f.
func (f ObserverFunc) ObserveLLM(ctx context.Context, e Event) { f(ctx, e) }

type Client struct {
	noOff   sync.Map // models whose endpoint rejects reasoning:off
	mu      sync.RWMutex
	s       Settings
	timeout atomic.Int64 // per request (all retries included); 0 = none. Hot-reloadable, see SetTimeout.
	HTTP    *http.Client
	// Observer, if set, is told about every request (metrics, usage, alerts).
	Observer Observer
	// Guard, if set, is asked before every chat request; a non-nil error refuses it (daily token budget).
	Guard func() error

	emb embedCache
}

func New(baseURL, embeddingBaseURL, apiKey, model, embeddingModel string, timeout time.Duration) *Client {
	c := &Client{
		s:    Settings{BaseURL: baseURL, EmbeddingBaseURL: embeddingBaseURL, APIKey: apiKey, Model: model, EmbeddingModel: embeddingModel},
		HTTP: &http.Client{}, // the deadline comes from the request context (SetTimeout), so it can change while requests run
	}
	c.SetTimeout(timeout)
	return c
}

// SetTimeout changes how long one request (with its retries and the body) may take. Safe while requests run:
// mutating http.Client.Timeout on the fly is a data race, a context deadline is not.
func (c *Client) SetTimeout(d time.Duration) { c.timeout.Store(int64(d)) }

// withDeadline bounds ctx by the configured request timeout.
func (c *Client) withDeadline(ctx context.Context) (context.Context, context.CancelFunc) {
	if d := time.Duration(c.timeout.Load()); d > 0 {
		return context.WithTimeout(ctx, d)
	}
	return context.WithCancel(ctx)
}

// Update swaps settings atomically (config hot reload).
func (c *Client) Update(s Settings) {
	c.mu.Lock()
	c.s = s
	c.mu.Unlock()
}

func (c *Client) settings() Settings {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return c.s
}

// lightPurposes are the background tasks that can run on the cheaper LightModel.
// "reply" (what the character says) always uses Model; "image" (needs vision) uses VisionModel when it is set.
var lightPurposes = map[string]bool{"ask": true, "sleep": true, "diary": true, "compact": true, "people": true}

// modelFor picks the model for a request by its purpose.
func (s Settings) modelFor(purpose string) string {
	if s.VisionModel != "" && purpose == "image" {
		return s.VisionModel
	}
	if s.FastModel != "" && purpose == "delegate" {
		return s.FastModel
	}
	if s.LightModel != "" && lightPurposes[purpose] {
		return s.LightModel
	}
	return s.Model
}

// needsCacheControl: Anthropic models only cache what is explicitly marked.
func needsCacheControl(model string) bool {
	m := strings.ToLower(model)
	return strings.Contains(m, "claude") || strings.HasPrefix(m, "anthropic/")
}

// Model returns the configured chat model.
func (c *Client) Model() string { return c.settings().Model }

type chatResponse struct {
	Choices []struct {
		Message Message `json:"message"`
	} `json:"choices"`
	Usage *struct {
		PromptTokens        int `json:"prompt_tokens"`
		CompletionTokens    int `json:"completion_tokens"`
		PromptTokensDetails *struct {
			CachedTokens int `json:"cached_tokens"`
		} `json:"prompt_tokens_details,omitempty"`
	} `json:"usage,omitempty"`
	Error json.RawMessage `json:"error,omitempty"`
}

func isOff(r string) bool { return r == "off" || r == "none" || r == "false" }

// Complete is the full-featured chat call: system prompt, history and optional tools.
func (c *Client) Complete(ctx context.Context, r Request) (Message, error) {
	s := c.settings()
	if c.Guard != nil {
		if err := c.Guard(); err != nil {
			return Message{}, err
		}
	}
	purpose := PurposeFrom(ctx)
	model := s.modelFor(purpose)
	if r.Model != "" {
		model = r.Model
	}
	var all any = r.Messages
	switch {
	case r.System != "" && s.CachePrompt && needsCacheControl(model):
		sys := map[string]any{"role": "system", "content": []map[string]any{{"type": "text", "text": r.System, "cache_control": map[string]string{"type": "ephemeral"}}}}
		list := make([]any, 0, len(r.Messages)+1)
		list = append(list, sys)
		for _, m := range r.Messages {
			list = append(list, m)
		}
		all = list
	case r.System != "":
		all = append([]Message{{Role: "system", Content: r.System}}, r.Messages...)
	}
	body := map[string]any{"model": model, "messages": all, "stream": false}
	if len(r.Tools) > 0 {
		body["tools"] = r.Tools
		if r.ToolChoice != "" {
			body["tool_choice"] = r.ToolChoice
		}
	}
	if s.Temperature != nil {
		body["temperature"] = *s.Temperature
	}
	perRequest := r.Reasoning != ""
	reasoning := s.Reasoning
	if perRequest {
		reasoning = r.Reasoning // this request only (fast rounds)
	}
	if c.noOffHas(model) && isOff(reasoning) {
		// this model's endpoint refuses to switch reasoning off. A per-round request (fast rounds) thinks as little as
		// allowed; the global llm.reasoning = "off" falls back to the model's own default instead of crippling every answer
		if perRequest {
			reasoning = "low"
		} else {
			reasoning = ""
		}
	}
	switch {
	case reasoning == "":
	case isOff(reasoning):
		body["reasoning"] = map[string]any{"enabled": false, "exclude": true}
	default:
		body["reasoning"] = map[string]any{"effort": reasoning, "exclude": true}
	}
	var out chatResponse
	start := time.Now()
	err := c.postJSON(ctx, s, s.BaseURL+"chat/completions", body, &out)
	if err != nil && body["reasoning"] != nil && strings.Contains(err.Error(), "easoning is mandatory") {
		// the endpoint cannot run without reasoning: remember it and retry with the lowest effort
		c.noOff.Store(model, true)
		if perRequest {
			body["reasoning"] = map[string]any{"effort": "low", "exclude": true}
		} else {
			delete(body, "reasoning")
		}
		out = chatResponse{}
		err = c.postJSON(ctx, s, s.BaseURL+"chat/completions", body, &out)
	}
	if err == nil && len(out.Error) > 0 && string(out.Error) != "null" {
		err = upstreamError(out.Error)
	}
	if err == nil && len(out.Choices) == 0 {
		err = &APIError{Status: http.StatusBadGateway, Body: "no choices in the answer"}
	}
	ev := Event{Kind: "chat", Model: model, Purpose: purpose, Duration: time.Since(start), Err: err}
	if err == nil && out.Usage != nil {
		u := &Usage{Model: model, Purpose: purpose, Prompt: out.Usage.PromptTokens, Completion: out.Usage.CompletionTokens}
		if out.Usage.PromptTokensDetails != nil {
			u.CachedPromptTokens = out.Usage.PromptTokensDetails.CachedTokens
		}
		ev.Usage = u
	}
	c.observe(ctx, ev)
	if err != nil {
		return Message{}, err
	}
	return out.Choices[0].Message, nil
}

// Chat is Complete without tools, returning only the text.
func (c *Client) Chat(ctx context.Context, systemPrompt string, msgs []Message) (string, error) {
	m, err := c.Complete(ctx, Request{System: systemPrompt, Messages: msgs})
	return m.Content, err
}

// ChatStream forwards SSE deltas of a streamed completion to onDelta.
func (c *Client) ChatStream(ctx context.Context, systemPrompt string, msgs []Message, onDelta func(string)) error {
	if c.Guard != nil {
		if err := c.Guard(); err != nil {
			return err
		}
	}
	s := c.settings()
	purpose := PurposeFrom(ctx)
	model := s.modelFor(purpose)
	start := time.Now()
	err := c.stream(ctx, s, model, systemPrompt, msgs, onDelta)
	c.observe(ctx, Event{Kind: "stream", Model: model, Purpose: purpose, Duration: time.Since(start), Err: err})
	return err
}

func (c *Client) stream(ctx context.Context, s Settings, model, systemPrompt string, msgs []Message, onDelta func(string)) error {
	ctx, cancel := c.withDeadline(ctx)
	defer cancel()
	body := map[string]any{
		"model":    model,
		"messages": append([]Message{{Role: "system", Content: systemPrompt}}, msgs...),
		"stream":   true,
	}
	resp, err := c.do(ctx, s, s.BaseURL+"chat/completions", body)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	sc := bufio.NewScanner(resp.Body)
	sc.Buffer(make([]byte, 1<<20), 1<<24)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if !strings.HasPrefix(line, "data:") {
			continue
		}
		payload := strings.TrimSpace(strings.TrimPrefix(line, "data:"))
		if payload == "[DONE]" {
			break
		}
		var chunk struct {
			Choices []struct {
				Delta struct {
					Content string `json:"content"`
				} `json:"delta"`
			} `json:"choices"`
		}
		if err := json.Unmarshal([]byte(payload), &chunk); err != nil {
			return fmt.Errorf("llm: bad stream chunk: %w", err)
		}
		for _, ch := range chunk.Choices {
			if ch.Delta.Content != "" {
				onDelta(ch.Delta.Content)
			}
		}
	}
	return sc.Err()
}

type embeddingResponse struct {
	Data []struct {
		Embedding []float64 `json:"embedding"`
	} `json:"data"`
}

// Embedding returns the embedding vector of text. Recent results are remembered: the same text (a retried turn, the
// same question to the diary) is not paid for twice.
func (c *Client) Embedding(ctx context.Context, text string) ([]float64, error) {
	s := c.settings()
	key := s.EmbeddingBaseURL + "\x00" + s.EmbeddingModel + "\x00" + text
	if v, ok := c.emb.get(key); ok {
		return v, nil
	}
	body := map[string]any{"model": s.EmbeddingModel, "input": text}
	var out embeddingResponse
	start := time.Now()
	err := c.postJSON(ctx, s, s.EmbeddingBaseURL+"embeddings", body, &out)
	if err == nil && (len(out.Data) == 0 || len(out.Data[0].Embedding) == 0) {
		err = fmt.Errorf("llm: no embedding returned")
	}
	c.observe(ctx, Event{Kind: "embedding", Model: s.EmbeddingModel, Purpose: PurposeFrom(ctx), Duration: time.Since(start), Err: err})
	if err != nil {
		return nil, err
	}
	c.emb.put(key, out.Data[0].Embedding)
	return out.Data[0].Embedding, nil
}

func (c *Client) observe(ctx context.Context, e Event) {
	if c.Observer == nil {
		return
	}
	e.Chat, e.HasChat = ChatFrom(ctx)
	c.Observer.ObserveLLM(ctx, e)
}

// maxBody bounds an answer: a broken server must not make her read gigabytes.
const maxBody = 64 << 20

func (c *Client) postJSON(ctx context.Context, s Settings, url string, body any, out any) error {
	ctx, cancel := c.withDeadline(ctx)
	defer cancel()
	resp, err := c.do(ctx, s, url, body)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	raw, err := io.ReadAll(io.LimitReader(resp.Body, maxBody))
	if err != nil {
		return err
	}
	if err := json.Unmarshal(raw, out); err != nil {
		return fmt.Errorf("llm: decode response: %w (body: %.200s)", err, raw)
	}
	return nil
}

func (c *Client) do(ctx context.Context, s Settings, url string, body any) (*http.Response, error) {
	buf, err := json.Marshal(body)
	if err != nil {
		return nil, err
	}
	var lastErr error
	var wait time.Duration
	for attempt := 0; attempt < 3; attempt++ {
		if attempt > 0 { // transient failure: back off 1s, 3s, or as long as the server asked (Retry-After)
			d := time.Duration(attempt*2-1) * time.Second
			if wait > d {
				d = wait
			}
			select {
			case <-time.After(d):
			case <-ctx.Done():
				return nil, ctx.Err()
			}
		}
		wait = 0
		req, err := http.NewRequestWithContext(ctx, http.MethodPost, url, bytes.NewReader(buf))
		if err != nil {
			return nil, err
		}
		req.Header.Set("Content-Type", "application/json")
		if s.APIKey != "" {
			req.Header.Set("Authorization", "Bearer "+s.APIKey)
		}
		resp, err := c.HTTP.Do(req)
		if err != nil {
			if ctx.Err() != nil {
				return nil, err
			}
			var ne net.Error
			if errors.As(err, &ne) && ne.Timeout() {
				return nil, err // a hung request is not retried: three full timeouts in a row freeze her for minutes
			}
			lastErr = err
			continue
		}
		if resp.StatusCode/100 != 2 {
			b, _ := io.ReadAll(io.LimitReader(resp.Body, 4096))
			resp.Body.Close()
			ae := &APIError{Status: resp.StatusCode, Body: strings.TrimSpace(string(b)), RetryAfter: retryAfter(resp.Header.Get("Retry-After"), time.Now())}
			lastErr = ae
			if ae.Temporary() {
				wait = ae.RetryAfter
				continue
			}
			return nil, lastErr
		}
		return resp, nil
	}
	return nil, lastErr
}

// maxRetryAfter caps how long a single retry waits for a rate limit: longer bans are reported, not slept through.
const maxRetryAfter = 30 * time.Second

// retryAfter reads a Retry-After header (seconds or an HTTP date); 0 when absent or unreadable.
func retryAfter(h string, now time.Time) time.Duration {
	h = strings.TrimSpace(h)
	if h == "" {
		return 0
	}
	var d time.Duration
	if n, err := strconv.ParseFloat(h, 64); err == nil {
		d = time.Duration(n * float64(time.Second))
	} else if t, err := http.ParseTime(h); err == nil {
		d = t.Sub(now)
	}
	if d < 0 {
		return 0
	}
	return min(d, maxRetryAfter)
}

type purposeKey struct{}

// WithPurpose labels LLM requests made with the returned context (reply, ask, diary, sleep, compact, ...),
// so token usage can be split by what it was spent on.
func WithPurpose(ctx context.Context, p string) context.Context {
	return context.WithValue(ctx, purposeKey{}, p)
}

// PurposeFrom returns the label set by WithPurpose ("other" by default).
func PurposeFrom(ctx context.Context) string {
	if p, ok := ctx.Value(purposeKey{}).(string); ok && p != "" {
		return p
	}
	return "other"
}

type chatKey struct{}

// WithChat marks the requests made with the returned context as spent on a chat (0 = her own thoughts).
func WithChat(ctx context.Context, id int64) context.Context {
	return context.WithValue(ctx, chatKey{}, id)
}

// ChatFrom returns the chat set by WithChat.
func ChatFrom(ctx context.Context) (int64, bool) {
	id, ok := ctx.Value(chatKey{}).(int64)
	return id, ok
}

func (c *Client) noOffHas(model string) bool { _, ok := c.noOff.Load(model); return ok }

// Allow asks the budget guard whether a request may be made now (nil = yes).
func (c *Client) Allow() error {
	if c != nil && c.Guard != nil {
		return c.Guard()
	}
	return nil
}

// Report hands the observer an event of a request the client did not make itself (the proxy forwards its clients'
// requests upstream), so those tokens are counted and limited like her own.
func (c *Client) Report(ctx context.Context, e Event) {
	if c != nil {
		c.observe(ctx, e)
	}
}
