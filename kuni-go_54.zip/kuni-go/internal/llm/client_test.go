package llm

import (
	"context"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"
	"time"
)

func TestSystemPromptIsMarkedCacheableOnlyForClaude(t *testing.T) {
	var bodies []string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		b, _ := io.ReadAll(r.Body)
		bodies = append(bodies, string(b))
		_, _ = w.Write([]byte(`{"choices":[{"message":{"role":"assistant","content":"ok"}}],"usage":{"prompt_tokens":100,"completion_tokens":5,"prompt_tokens_details":{"cached_tokens":80}}}`))
	}))
	defer srv.Close()
	c := New(srv.URL+"/", srv.URL+"/", "k", "anthropic/claude-sonnet", "e", 5*time.Second)
	c.Update(Settings{BaseURL: srv.URL + "/", APIKey: "k", Model: "anthropic/claude-sonnet", CachePrompt: true})
	cached := 0
	c.Observer = ObserverFunc(func(_ context.Context, e Event) {
		if e.Usage != nil {
			cached = e.Usage.CachedPromptTokens
		}
	})
	if _, err := c.Complete(context.Background(), Request{System: "SYS", Messages: []Message{{Role: "user", Content: "hi"}}}); err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(bodies[0], `"cache_control":{"type":"ephemeral"}`) || cached != 80 {
		t.Fatalf("claude: cached=%d body=%s", cached, bodies[0])
	}
	c.Update(Settings{BaseURL: srv.URL + "/", APIKey: "k", Model: "deepseek/deepseek-v4-flash", CachePrompt: true})
	if _, err := c.Complete(context.Background(), Request{System: "SYS", Messages: []Message{{Role: "user", Content: "hi"}}}); err != nil {
		t.Fatal(err)
	}
	if strings.Contains(bodies[1], "cache_control") || !strings.Contains(bodies[1], `"content":"SYS"`) {
		t.Fatalf("deepseek must get a plain system message: %s", bodies[1])
	}
}

func TestReasoningMandatoryFallsBackAndRemembers(t *testing.T) {
	var bodies []string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		b, _ := io.ReadAll(r.Body)
		bodies = append(bodies, string(b))
		if strings.Contains(string(b), `"enabled":false`) {
			w.WriteHeader(400)
			_, _ = w.Write([]byte(`{"error":{"message":"Reasoning is mandatory for this endpoint and cannot be disabled.","code":400}}`))
			return
		}
		_, _ = w.Write([]byte(`{"choices":[{"message":{"role":"assistant","content":"ok"}}]}`))
	}))
	defer srv.Close()
	c := New(srv.URL+"/", srv.URL+"/", "k", "m", "e", 5*time.Second)
	c.Update(Settings{BaseURL: srv.URL + "/", APIKey: "k", Model: "m", Reasoning: "off"})
	for i := 0; i < 2; i++ {
		m, err := c.Complete(context.Background(), Request{System: "S", Messages: []Message{{Role: "user", Content: "hi"}}})
		if err != nil || m.Content != "ok" {
			t.Fatalf("round %d: %v %q", i, err, m.Content)
		}
	}
	// 1st call: tried with reasoning, retried without; 2nd call: straight without
	if len(bodies) != 3 {
		t.Fatalf("requests=%d, want 3: %q", len(bodies), bodies)
	}
}

func TestTimeoutIsNotRetried(t *testing.T) {
	var n atomic.Int32
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		n.Add(1)
		time.Sleep(300 * time.Millisecond)
	}))
	defer srv.Close()
	c := New(srv.URL+"/", srv.URL+"/", "k", "m", "e", 100*time.Millisecond)
	if _, err := c.Complete(context.Background(), Request{System: "S", Messages: []Message{{Role: "user", Content: "hi"}}}); err == nil {
		t.Fatal("want a timeout error")
	}
	if n.Load() != 1 {
		t.Fatalf("a timed-out request was sent %d times", n.Load())
	}
}

func TestMandatoryReasoningGlobalOffUsesDefaultAndFastRoundUsesLow(t *testing.T) {
	var bodies []string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		b, _ := io.ReadAll(r.Body)
		bodies = append(bodies, string(b))
		if strings.Contains(string(b), `"enabled":false`) {
			w.WriteHeader(400)
			_, _ = w.Write([]byte(`{"error":{"message":"Reasoning is mandatory for this endpoint and cannot be disabled."}}`))
			return
		}
		_, _ = w.Write([]byte(`{"choices":[{"message":{"role":"assistant","content":"ok"}}]}`))
	}))
	defer srv.Close()
	c := New(srv.URL+"/", srv.URL+"/", "k", "m", "e", 5*time.Second)
	c.Update(Settings{BaseURL: srv.URL + "/", APIKey: "k", Model: "m", Reasoning: "off"})
	msgs := []Message{{Role: "user", Content: "hi"}}
	if _, err := c.Complete(context.Background(), Request{System: "S", Messages: msgs}); err != nil {
		t.Fatal(err)
	}
	if _, err := c.Complete(context.Background(), Request{System: "S", Messages: msgs}); err != nil {
		t.Fatal(err)
	}
	last := bodies[len(bodies)-1]
	if strings.Contains(last, "reasoning") {
		t.Fatalf("global off on a mandatory-reasoning model must use the default, got %s", last)
	}
	if _, err := c.Complete(context.Background(), Request{System: "S", Messages: msgs, Reasoning: "off"}); err != nil {
		t.Fatal(err)
	}
	if last = bodies[len(bodies)-1]; !strings.Contains(last, `"effort":"low"`) {
		t.Fatalf("a fast round must think as little as allowed: %s", last)
	}
}
