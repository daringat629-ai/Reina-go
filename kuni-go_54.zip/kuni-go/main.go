// Command kuni is the Go port of the Kuni character AI: Telegram client, tools,
// RAG diary with sleep consolidation, working memory, and an OpenAI-compatible
// proxy that gives any LLM client the same memory.
//
//	kuni                  run (the first run writes config.toml and exits)
//	kuni doctor           check the setup and exit
//	kuni install-service  install the OpenRC service (Alpine)
//
// Everything the program is made of is assembled in internal/app.
package main

import (
	"context"
	"errors"
	"fmt"
	"io"
	"log"
	"os"
	"os/signal"
	"runtime/debug"
	"syscall"
	"time"
	_ "time/tzdata" // IANA zones for autonomy.timezone even on minimal images (Alpine)

	"kuni/internal/app"
	"kuni/internal/config"
	"kuni/internal/update"
	"kuni/internal/util"
)

func main() {
	if os.Getenv("GOMEMLIMIT") == "" {
		debug.SetMemoryLimit(640 << 20) // soft cap: the GC works harder near it instead of letting the container grow
	}
	update.Init()
	if len(os.Args) > 1 {
		switch os.Args[1] {
		case "doctor": // check the setup and exit (see main_doctor.go)
			if err := runDoctor(config.FileName, os.Stdout); err != nil {
				os.Exit(1)
			}
			return
		case "install-service":
			if err := installService(update.Dir()); err != nil {
				fmt.Fprintln(os.Stderr, err)
				os.Exit(1)
			}
			return
		}
	}
	// a build that was installed from the panel gets one start; if it never confirmed itself, the old one returns
	if update.Boot(update.Dir()) {
		log.Printf("kuni: the new build did not come up, rolled back to the previous one; restarting")
		if err := update.Restart(); err != nil {
			log.Printf("kuni: restart after rollback: %v", err)
		}
	}
	logbuf := util.NewLogBuf(600)
	log.SetOutput(io.MultiWriter(os.Stderr, logbuf))
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	err := app.Run(ctx, app.Options{ConfigPath: config.FileName, Log: logbuf, Started: time.Now()})
	stop()
	if err != nil {
		if errors.Is(err, config.ErrNeedsSetup) {
			fmt.Println(err)
			return
		}
		log.Fatal(err)
	}
	if update.Requested() {
		log.Printf("kuni: restarting into the new build")
		if err := update.Restart(); err != nil {
			log.Fatalf("restart: %v", err)
		}
	}
}
