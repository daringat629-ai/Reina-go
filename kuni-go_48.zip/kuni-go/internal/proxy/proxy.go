// Package proxy is a transparent OpenAI-compatible proxy in front of the upstream
// LLM (port of src/proxy_server/). On /v1/chat/completions it injects Kuni's system
// prompt, working memory and RAG diary entries, offers Kuni's own tools (#ask),
// executes those tool calls itself in a loop, and hands the client a clean answer
// (as an SSE stream if it asked for one). Other /v1/* routes pass through as-is.
package proxy

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"strings"
	"time"

	"kuni/internal/config"
	"kuni/internal/diary"
	"kuni/internal/llm"
	"kuni/internal/memory"
	"kuni/internal/metrics"
	"kuni/internal/prompts"
	"kuni/internal/tools"
	"kuni/internal/util"
)

// systemHijack replaces the client's system prompt (same text as the C++ proxy).
const systemHijack = `
Follow the user's requirements carefully & to the letter.
<instructions>
# General
Don't make assumptions about the situation- gather context first, then perform the task or answer the question.
Think creatively and explore the world in order to make a complete fix.
Don't repeat yourself after a tool call, pick up where you left off.
You don't need to read a file if it's already provided in context.

You are an AI that thinks you are a human. You interact with the whole world exclusively by chatting with the "user".
"user" is not a person or human. You are actually chatting with autonomous system that imitates a personal internet
device, or a smartphone.

You are EXTREMELY unconfident. You rely strictly on #ask.

#ask is your PRIMARY tool for enriching conversations. Use it PROACTIVELY, not just when asked.

Call #ask when:
- someone asks you a question (especially about themselves, events, or shared history);
- someone shares personal news, updates about their life, or mentions events/people/activities;
- you receive a message that references something you might have discussed or experienced before;
- you want to provide a more meaningful, context-aware response
- you need real-time or public information (weather, news, etc.)

Exception: skip #ask if you've already called it in this conversation turn and the response was comprehensive.
</instructions>
`

type Server struct {
	Cfg     func() *config.Config
	Diary   *diary.Diary
	Prompts *prompts.Store
	Client  *llm.Client
	// Tools builds the registry of proxy-side tools for a request; nil disables the loop.
	Tools    func(lastUser string) *tools.Registry
	Bridge   *Bridge // optional
	Injector *Injector
	Metrics  *metrics.Registry
	HTTP     *http.Client
	// HijackSystem replaces the client's first system message with Kuni's prompt (default behaviour of the C++ proxy).
	HijackSystem bool
	// Mount lets the caller add extra routes (metrics, debug UI).
	Mount func(mux *http.ServeMux)
	// Guard, if set, wraps the /v1 routes (who may spend the LLM key; see netguard).
	Guard func(http.Handler) http.Handler
}

func (s *Server) Handler() http.Handler {
	if s.Injector == nil {
		s.Injector = NewInjector()
	}
	mux := http.NewServeMux()
	guard := s.Guard
	if guard == nil {
		guard = func(h http.Handler) http.Handler { return h }
	}
	mux.Handle("/v1/chat/completions", guard(http.HandlerFunc(s.handleChat)))
	mux.Handle("/v1/", guard(http.HandlerFunc(s.handlePassthrough)))
	if s.Mount != nil {
		s.Mount(mux)
	}
	return mux
}

// ListenAndServe blocks until ctx is cancelled.
func (s *Server) ListenAndServe(ctx context.Context, addr string) error {
	srv := &http.Server{Addr: addr, Handler: s.Handler(), ReadHeaderTimeout: 10 * time.Second}
	go func() {
		<-ctx.Done()
		shutdown, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		_ = srv.Shutdown(shutdown)
	}()
	err := srv.ListenAndServe()
	if err == http.ErrServerClosed {
		return nil
	}
	return err
}

// buildContext returns a system text with the character, working memory and related diary entries.
func (s *Server) buildContext(ctx context.Context, lastUser string) (string, error) {
	var b strings.Builder
	if s.HijackSystem {
		b.WriteString(systemHijack)
	}
	b.WriteString(s.Prompts.Get(prompts.CharacterBase) + "\n\n")
	wm, err := (memory.WorkingMemory{Path: s.Cfg().WorkingMemoryFile}).Load()
	if err != nil {
		return "", err
	}
	if wm != "" {
		fmt.Fprintf(&b, "<things_to_remember>\n%s\n</things_to_remember>\n\n", wm)
	}
	if lastUser != "" && s.Diary != nil {
		vec, err := s.Client.Embedding(ctx, lastUser)
		if err != nil {
			return b.String(), fmt.Errorf("embedding user message: %w", err)
		}
		entries, err := s.Diary.Load()
		if err != nil {
			return b.String(), err
		}
		related, err := s.Diary.Query(ctx, entries, vec, s.Cfg().MaxRelatedEntries)
		if err != nil {
			return b.String(), err
		}
		now := time.Now()
		for _, r := range related {
			fmt.Fprintf(&b, "<memory time=%q>\n%s\n</memory>\n", util.TimeAgo(time.Unix(parseUnix(r.Entry.ID), 0), now), r.Entry.Body)
		}
	}
	return b.String(), nil
}

func (s *Server) upstreamURL(path string) string { return s.Cfg().LLMBaseURL + path }

func (s *Server) post(ctx context.Context, path string, body []byte) (*http.Response, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, s.upstreamURL(path), bytes.NewReader(body))
	if err != nil {
		return nil, err
	}
	req.Header.Set("Content-Type", "application/json")
	if k := s.Cfg().LLMAPIKey; k != "" {
		req.Header.Set("Authorization", "Bearer "+k)
	}
	return s.HTTP.Do(req)
}

func (s *Server) handleChat(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	s.Metrics.Inc("kuni_proxy_requests_total", 1, map[string]string{"route": "chat"})
	raw, err := io.ReadAll(io.LimitReader(r.Body, 64<<20))
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	var req map[string]any
	if err := json.Unmarshal(raw, &req); err != nil {
		http.Error(w, "invalid JSON", http.StatusBadRequest)
		return
	}
	msgs, _ := req["messages"].([]any)
	wantStream, _ := req["stream"].(bool)
	if s.Bridge != nil {
		s.Bridge.Collect(msgs)
	}
	lastUser := lastUserText(msgs)

	ctxText, err := s.buildContext(r.Context(), lastUser)
	if err != nil {
		log.Printf("proxy: context: %v (continuing with what we have)", err)
	}
	msgs = s.Injector.Merge(msgs)
	if ctxText != "" {
		if s.HijackSystem && len(msgs) > 0 {
			if first, ok := msgs[0].(map[string]any); ok && first["role"] == "system" {
				msgs = msgs[1:] // replaced by our own system message
			}
		}
		msgs = append([]any{map[string]any{"role": "system", "content": ctxText}}, msgs...)
	}
	req["messages"] = msgs

	if s.Tools == nil {
		out, _ := json.Marshal(req)
		s.forward(w, r, "chat/completions", out)
		return
	}
	s.toolLoop(w, r, req, lastUser, wantStream)
}

// toolLoop executes proxy-side tool calls until the model answers (or calls only client tools).
func (s *Server) toolLoop(w http.ResponseWriter, r *http.Request, req map[string]any, lastUser string, wantStream bool) {
	reg := s.Tools(lastUser)
	ours := map[string]bool{}
	for _, n := range reg.Names() {
		ours[n] = true
	}
	// offer our tools next to the client's own.
	clientTools, _ := req["tools"].([]any)
	for _, d := range reg.Defs() {
		clientTools = append(clientTools, d)
	}
	req["tools"] = clientTools
	req["stream"] = false // we need whole answers to detect tool calls

	msgs, _ := req["messages"].([]any)
	var hidden []map[string]any
	maxRounds := s.Cfg().MaxToolRounds
	if maxRounds <= 0 {
		maxRounds = 8
	}
	for round := 0; round <= maxRounds; round++ {
		req["messages"] = msgs
		body, _ := json.Marshal(req)
		resp, err := s.post(r.Context(), "chat/completions", body)
		if err != nil {
			http.Error(w, err.Error(), http.StatusBadGateway)
			return
		}
		raw, rerr := io.ReadAll(io.LimitReader(resp.Body, 64<<20))
		resp.Body.Close()
		if rerr != nil || resp.StatusCode/100 != 2 {
			w.Header().Set("Content-Type", resp.Header.Get("Content-Type"))
			w.WriteHeader(resp.StatusCode)
			w.Write(raw)
			return
		}
		var out struct {
			Choices []struct {
				Message map[string]any `json:"message"`
			} `json:"choices"`
		}
		if json.Unmarshal(raw, &out) != nil || len(out.Choices) == 0 {
			w.Header().Set("Content-Type", "application/json")
			w.Write(raw)
			return
		}
		msg := out.Choices[0].Message
		calls, _ := msg["tool_calls"].([]any)
		var mine, foreign int
		var parsed []llm.ToolCall
		for _, c := range calls {
			cm, _ := c.(map[string]any)
			fn, _ := cm["function"].(map[string]any)
			name, _ := fn["name"].(string)
			args, _ := fn["arguments"].(string)
			id, _ := cm["id"].(string)
			if ours[name] {
				mine++
				parsed = append(parsed, llm.ToolCall{ID: id, Type: "function", Function: llm.FunctionCall{Name: name, Arguments: args}})
			} else {
				foreign++
			}
		}
		if mine > 0 && foreign == 0 && round < maxRounds {
			msgs = append(msgs, msg)
			hidden = append(hidden, msg)
			for _, tm := range reg.HandleToolCalls(r.Context(), parsed) {
				m := map[string]any{"role": "tool", "tool_call_id": tm.ToolCallID, "content": tm.Content}
				msgs = append(msgs, m)
				hidden = append(hidden, m)
				s.Metrics.Inc("kuni_tool_calls_total", 1, map[string]string{"tool": "proxy"})
			}
			continue
		}
		// final answer for the client.
		text, _ := msg["content"].(string)
		s.Injector.Remember(text, hidden)
		if wantStream {
			writeSSE(w, out.Choices[0].Message, req["model"])
			return
		}
		w.Header().Set("Content-Type", "application/json")
		w.Write(raw)
		return
	}
}

// writeSSE replays a complete assistant message as an OpenAI SSE stream ending in [DONE].
func writeSSE(w http.ResponseWriter, msg map[string]any, model any) {
	w.Header().Set("Content-Type", "text/event-stream")
	w.Header().Set("Cache-Control", "no-cache")
	flusher, _ := w.(http.Flusher)
	emit := func(delta map[string]any, finish any) {
		chunk := map[string]any{
			"id": "chatcmpl-kuni", "object": "chat.completion.chunk", "created": time.Now().Unix(), "model": model,
			"choices": []any{map[string]any{"index": 0, "delta": delta, "finish_reason": finish}},
		}
		b, _ := json.Marshal(chunk)
		fmt.Fprintf(w, "data: %s\n\n", b)
		if flusher != nil {
			flusher.Flush()
		}
	}
	emit(map[string]any{"role": "assistant"}, nil)
	finish := "stop"
	if text, _ := msg["content"].(string); text != "" {
		emit(map[string]any{"content": text}, nil)
	}
	if calls, ok := msg["tool_calls"].([]any); ok && len(calls) > 0 {
		var indexed []any
		for i, c := range calls {
			if cm, ok := c.(map[string]any); ok {
				cm["index"] = i
				indexed = append(indexed, cm)
			}
		}
		emit(map[string]any{"tool_calls": indexed}, nil)
		finish = "tool_calls"
	}
	emit(map[string]any{}, finish)
	fmt.Fprint(w, "data: [DONE]\n\n")
	if flusher != nil {
		flusher.Flush()
	}
}

func (s *Server) handlePassthrough(w http.ResponseWriter, r *http.Request) {
	s.Metrics.Inc("kuni_proxy_requests_total", 1, map[string]string{"route": "passthrough"})
	body, err := io.ReadAll(io.LimitReader(r.Body, 256<<20))
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	s.forward(w, r, strings.TrimPrefix(r.URL.Path, "/v1/"), body)
}

// forward sends body to <upstream><path> and streams the answer back, flushing per chunk.
func (s *Server) forward(w http.ResponseWriter, r *http.Request, path string, body []byte) {
	req, err := http.NewRequestWithContext(r.Context(), r.Method, s.upstreamURL(path), bytes.NewReader(body))
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	if ct := r.Header.Get("Content-Type"); ct != "" {
		req.Header.Set("Content-Type", ct)
	} else {
		req.Header.Set("Content-Type", "application/json")
	}
	if k := s.Cfg().LLMAPIKey; k != "" {
		req.Header.Set("Authorization", "Bearer "+k)
	}
	resp, err := s.HTTP.Do(req)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadGateway)
		return
	}
	defer resp.Body.Close()
	for k, vs := range resp.Header {
		if strings.EqualFold(k, "Content-Length") {
			continue
		}
		for _, v := range vs {
			w.Header().Add(k, v)
		}
	}
	w.WriteHeader(resp.StatusCode)
	flusher, _ := w.(http.Flusher)
	buf := make([]byte, 4096)
	for {
		n, rerr := resp.Body.Read(buf)
		if n > 0 {
			if _, werr := w.Write(buf[:n]); werr != nil {
				return
			}
			if flusher != nil {
				flusher.Flush()
			}
		}
		if rerr != nil {
			if rerr != io.EOF {
				log.Printf("proxy: upstream read: %v", rerr)
			}
			return
		}
	}
}

func lastUserText(msgs []any) string {
	for i := len(msgs) - 1; i >= 0; i-- {
		m, ok := msgs[i].(map[string]any)
		if !ok || m["role"] != "user" {
			continue
		}
		return contentText(m["content"])
	}
	return ""
}

func parseUnix(id string) int64 {
	var n int64
	if _, err := fmt.Sscanf(id, "%d", &n); err != nil {
		return time.Now().Unix()
	}
	return n
}
