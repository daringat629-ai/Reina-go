package agent

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"kuni/internal/telegram"
	"kuni/internal/usage"
)

func TestTransientErrors(t *testing.T) {
	cases := map[error]bool{
		errors.New("llm: HTTP 503: busy"):                   true,
		errors.New("llm: HTTP 429: slow down"):              true,
		errors.New("Post \"x\": connection refused"):        true,
		fmt.Errorf("wrapped: %w", context.DeadlineExceeded): true,
		errors.New("llm: HTTP 401: bad key"):                false,
		errors.New("llm: HTTP 402: no credits"):             false,
		errors.New("llm: HTTP 400: bad request"):            false,
		context.Canceled:                                    false,
		usage.ErrHardLimit:                                  false,
	}
	for err, want := range cases {
		if got := transient(err); got != want {
			t.Errorf("transient(%v) = %v, want %v", err, got, want)
		}
	}
}

// The provider is down for longer than the client's own retries: the turn is repeated later and the person still
// gets an answer, instead of a message that was marked read and never answered.
func TestFailedTurnIsRetriedUntilTheModelAnswers(t *testing.T) {
	old := retryDelays
	retryDelays = []time.Duration{50 * time.Millisecond, 50 * time.Millisecond, 50 * time.Millisecond}
	t.Cleanup(func() { retryDelays = old })

	f := newFakeLLM(t, sendCall)
	var failing atomic.Int32
	failing.Store(3) // the client tries 3 times per request: the whole first turn fails, the retry gets through
	inner := f.srv.Config.Handler
	f.srv.Config.Handler = http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if strings.HasSuffix(r.URL.Path, "/chat/completions") && failing.Add(-1) >= 0 {
			http.Error(w, "upstream down", http.StatusBadGateway)
			return
		}
		inner.ServeHTTP(w, r)
	})
	r := newRig(t, f)
	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan struct{})
	go func() { r.ag.Run(ctx); close(done) }()
	defer func() { cancel(); <-done }()

	r.tg.Incoming(telegram.Chat{ID: 100, Title: "Alex", Kind: telegram.ChatPrivate, IsMember: true}, 100, "Alex", "ты тут?")
	waitFor(t, "an answer after the outage", func() bool { return len(r.tg.SentTexts()) == 1 })
	if n := r.ag.Metrics.Get("kuni_turn_retries_total", nil); n < 1 {
		t.Fatalf("retries metric = %v", n)
	}
}

// A bad key is not retried: three more failing requests would only burn time.
func TestClientErrorIsNotRetried(t *testing.T) {
	old := retryDelays
	retryDelays = []time.Duration{20 * time.Millisecond}
	t.Cleanup(func() { retryDelays = old })
	var calls atomic.Int32
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		calls.Add(1)
		http.Error(w, "invalid key", http.StatusUnauthorized)
	}))
	defer srv.Close()
	f := &fakeLLM{srv: srv}
	r := newRig(t, f)
	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan struct{})
	go func() { r.ag.Run(ctx); close(done) }()
	r.tg.Incoming(telegram.Chat{ID: 100, Title: "Alex", Kind: telegram.ChatPrivate, IsMember: true}, 100, "Alex", "ау")
	waitFor(t, "the failed turn", func() bool { return calls.Load() >= 1 })
	time.Sleep(200 * time.Millisecond)
	cancel()
	<-done
	if n := r.ag.Metrics.Get("kuni_turn_retries_total", nil); n != 0 {
		t.Fatalf("a 401 must not be retried, retries = %v", n)
	}
}
