package agent

import (
	"log"
	"time"
)

// Turns that something else starts (a due reminder, a monitor alert, a scheduled task, the owner's yes to a risky
// action, a slash command, a finished background job) run in goroutines of their own. They used to be fire-and-forget:
// on shutdown they could still be talking to the model and writing files after the final dump of the sessions.
// spawn tracks them, and Run waits for them (they share its context, so they end quickly) before dumping.

// spawn runs f in a tracked goroutine; after shutdown has begun it is dropped (and logged).
func (a *Agent) spawn(what string, f func()) {
	a.bgMu.Lock()
	if a.bgClosed {
		a.bgMu.Unlock()
		log.Printf("agent: shutting down, %s dropped", what)
		return
	}
	a.bg.Add(1)
	a.bgMu.Unlock()
	go func() {
		defer a.bg.Done()
		defer func() {
			if r := recover(); r != nil {
				log.Printf("agent: %s: PANIC recovered: %v", what, r)
			}
		}()
		f()
	}()
}

// WaitBackground stops accepting new background turns and waits up to d for the running ones.
// It reports whether they all finished.
func (a *Agent) WaitBackground(d time.Duration) bool {
	a.bgMu.Lock()
	a.bgClosed = true
	a.bgMu.Unlock()
	done := make(chan struct{})
	go func() { a.bg.Wait(); close(done) }()
	select {
	case <-done:
		return true
	case <-time.After(d):
		log.Printf("agent: background turns still running after %s; going on with the shutdown", d)
		return false
	}
}
