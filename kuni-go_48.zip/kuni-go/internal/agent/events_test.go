package agent

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"kuni/internal/config"
	"kuni/internal/llm"
	"kuni/internal/telegram"
)

func lastUserPrompt(f *fakeLLM) string {
	f.mu.Lock()
	defer f.mu.Unlock()
	var b strings.Builder
	for _, c := range f.calls {
		raw, _ := json.Marshal(c["messages"])
		b.Write(raw)
	}
	return b.String()
}

func TestReactionsAndEditsBecomeNotesWithoutAModelCall(t *testing.T) {
	var n atomic.Int32
	f := newFakeLLM(t, func(int64) llm.ToolCall {
		c := sendCall(0)
		c.Function.Arguments = fmt.Sprintf(`{"text":"reply %d"}`, n.Add(1))
		return c
	})
	r := newRig(t, f)
	r.ag.Cfg.Get().MoodEnabled = true
	ctx, cancel := context.WithCancel(context.Background())
	r.start(t, ctx, cancel)
	chat := telegram.Chat{ID: 55, Title: "Bob", Kind: telegram.ChatPrivate, IsMember: true}
	r.tg.Incoming(chat, 55, "Bob", "hello")
	waitFor(t, "first reply", func() bool { return len(r.tg.SentTexts()) == 1 })
	sent := r.tg.Sent[0]
	time.Sleep(200 * time.Millisecond) // let the turn finish (the model's closing round)
	f.mu.Lock()
	calls := len(f.calls)
	f.mu.Unlock()
	moodBefore := r.ag.Deps.Mood.Level()

	r.tg.Emit(telegram.Event{Kind: telegram.EventReaction, ChatID: 55, MsgID: sent.ID, ActorID: 55, Actor: "Bob", Emoji: "🔥"})
	r.tg.Emit(telegram.Event{Kind: telegram.EventEdit, ChatID: 55, MsgID: 3, Actor: "Bob", Old: "see you at 5", New: "see you at 6"})
	time.Sleep(150 * time.Millisecond)
	f.mu.Lock()
	extra := len(f.calls) - calls
	f.mu.Unlock()
	if extra != 0 {
		t.Fatalf("events must not call the model, made %d calls", extra)
	}
	if got := r.ag.Deps.Mood.Level(); got <= moodBefore {
		t.Fatalf("a 🔥 should lift the mood: %d -> %d", moodBefore, got)
	}

	r.tg.Incoming(chat, 55, "Bob", "are you there?")
	waitFor(t, "second reply", func() bool { return len(r.tg.SentTexts()) == 2 })
	p := lastUserPrompt(f)
	for _, want := range []string{"while_you_were_away", "Bob reacted 🔥 to your message", "was \\\"see you at 5\\\", now \\\"see you at 6\\\""} {
		if !strings.Contains(p, want) {
			t.Fatalf("prompt lacks %q", want)
		}
	}
	// the notes are shown once
	r.tg.Incoming(chat, 55, "Bob", "ok")
	waitFor(t, "third reply", func() bool { return len(r.tg.SentTexts()) == 3 })
	f.mu.Lock()
	raw, _ := json.Marshal(f.calls[len(f.calls)-1]["messages"])
	f.mu.Unlock()
	if c := strings.Count(string(raw), "Bob reacted 🔥"); c > 1 { // never injected again (old views are slimmed)
		t.Fatalf("note repeated %d times in the last request", c)
	}
}

func TestEventsRespectLockdownAndExpire(t *testing.T) {
	r := newRig(t, newFakeLLM(t, sendCall))
	r.ag.Cfg.Get().Lockdown = "papik_only"
	r.ag.onEvent(context.Background(), telegram.Event{Kind: telegram.EventEdit, ChatID: 55, MsgID: 1, Old: "a", New: "b"})
	if got := r.ag.takeNotes(r.ag.getSession(55), time.Now()); got != "" {
		t.Fatalf("locked-down chat must be ignored: %q", got)
	}
	r.ag.Cfg.Get().Lockdown = "none"
	r.ag.onEvent(context.Background(), telegram.Event{Kind: telegram.EventEdit, ChatID: 55, MsgID: 1, Old: "a", New: "b"})
	if got := r.ag.takeNotes(r.ag.getSession(55), time.Now().Add(13*time.Hour)); got != "" {
		t.Fatalf("old notes must expire: %q", got)
	}
	for i := 0; i < 20; i++ {
		r.ag.onEvent(context.Background(), telegram.Event{Kind: telegram.EventEdit, ChatID: 56, MsgID: int64(i), Old: "a", New: "b"})
	}
	if got := r.ag.takeNotes(r.ag.getSession(56), time.Now()); strings.Count(got, "\n- ") != maxNotes {
		t.Fatalf("notes must be capped at %d:\n%s", maxNotes, got)
	}
}

func TestModalityHints(t *testing.T) {
	cfg := &config.Config{MirrorModality: true, TTSBackend: "openai", UseStickers: true}
	voice := []telegram.Message{{ID: 1, Media: telegram.MediaVoice}}
	if h := modalityHint(cfg, voice); !strings.Contains(h, "voice message back") {
		t.Fatalf("voice hint: %q", h)
	}
	cfg.TTSBackend = "none"
	if modalityHint(cfg, voice) != "" {
		t.Fatal("no TTS, no voice hint")
	}
	st := []telegram.Message{{ID: 2, Media: telegram.MediaSticker}}
	if h := modalityHint(cfg, st); !strings.Contains(h, "sticker") {
		t.Fatalf("sticker hint: %q", h)
	}
	cfg.UseStickers = false
	if modalityHint(cfg, st) != "" {
		t.Fatal("stickers off, no hint")
	}
	cfg.UseStickers, cfg.MirrorModality = true, false
	if modalityHint(cfg, st) != "" {
		t.Fatal("switched off")
	}
	cfg.MirrorModality = true
	mixed := []telegram.Message{{ID: 1, Media: telegram.MediaSticker}, {ID: 2, Text: "and a text"}}
	if modalityHint(cfg, mixed) != "" {
		t.Fatal("the last message decides")
	}
	if modalityHint(cfg, []telegram.Message{{ID: 3, Media: telegram.MediaSticker, Outgoing: true}}) != "" {
		t.Fatal("her own message is not a prompt")
	}
}

func TestQueuePhasesAndPanelInfo(t *testing.T) {
	r := newRig(t, newFakeLLM(t, sendCall))
	a := r.ag
	a.setPhase(5, "waiting", time.Time{})
	a.setPhase(6, "late", time.Now().Add(time.Hour))
	a.getSession(5).setChat(telegram.Chat{ID: 5, Title: "Bob"})
	q := a.Queue()
	if len(q) != 2 || q[0].ChatID != 5 || q[0].Title != "Bob" || q[1].Title != "chat 6" || q[1].Until.IsZero() {
		t.Fatalf("queue: %+v", q)
	}
	a.endPhase(5)
	a.endPhase(6) // late and still in the future: stays
	if q = a.Queue(); len(q) != 1 || q[0].Phase != "late" {
		t.Fatalf("late must stay: %+v", q)
	}
	raw, _ := json.Marshal(a.QueueInfo())
	if !strings.Contains(string(raw), `"items":[{"chat_id":6`) || !strings.Contains(string(raw), `"errors":[]`) {
		t.Fatalf("info json: %s", raw)
	}
}

func TestOwnerActionFromThePanelBecomesANote(t *testing.T) {
	r := newRig(t, newFakeLLM(t, sendCall))
	r.ag.NoteOwnerAction(55, "написал от её имени: «привет»")
	s := r.ag.getSession(55)
	got := r.ag.takeNotes(s, time.Now())
	if !strings.Contains(got, "the owner did this himself from the panel") || !strings.Contains(got, "привет") {
		t.Fatalf("note: %q", got)
	}
}
