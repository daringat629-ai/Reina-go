package agent

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"
	"time"

	"kuni/internal/autonomy"
	"kuni/internal/llm"
	"kuni/internal/memory"
	"kuni/internal/tools"
)

// autoSendTools are the calls that start or push a conversation; in an autonomous session they are limited.
var autoSendTools = map[string]bool{"send_telegram_message": true, "sticker_send": true, "forward_message": true}

func (a *Agent) location() *time.Location {
	return autonomy.Location(a.Cfg.Get().AutonomyTimezone)
}

func (a *Agent) limits() autonomy.Limits {
	c := a.Cfg.Get()
	return autonomy.Limits{MaxPerDay: c.AutonomyMaxPerDay, ChatCooldown: time.Duration(c.AutonomyChatCooldown) * time.Minute}
}

// isNight reports whether the configured quiet hours are on right now.
func (a *Agent) isNight(now time.Time) bool {
	c := a.Cfg.Get()
	return c.AutonomyEnabled && autonomy.InQuietHours(now, c.AutonomyQuietFrom, c.AutonomyQuietTo, a.location())
}

// autoDenied enforces the limits in code for messages started in the autonomous (id 0) session.
// It returns the reason when the call must not run.
func (a *Agent) autoDenied(s *session, c llm.ToolCall) string {
	cfg := a.Cfg.Get()
	if s.id != 0 || a.Auto == nil || !cfg.AutonomyEnabled || !autoSendTools[c.Function.Name] {
		return ""
	}
	if s.chat.ID == 0 {
		return "open a chat with open_chat first"
	}
	exempt := cfg.PapikChatID != 0 && s.chat.ID == cfg.PapikChatID
	if ok, why := a.Auto.Allow(s.chat.ID, a.limits(), exempt); !ok {
		return why
	}
	return ""
}

// autoRecord counts a successful autonomous message and journals it.
func (a *Agent) autoRecord(s *session, c llm.ToolCall, out string) {
	cfg := a.Cfg.Get()
	if s.id != 0 || a.Auto == nil || !cfg.AutonomyEnabled || !autoSendTools[c.Function.Name] || strings.HasPrefix(out, "Error") {
		return
	}
	var args struct {
		Text string `json:"text"`
	}
	_ = json.Unmarshal([]byte(c.Function.Arguments), &args)
	text := args.Text
	if text == "" {
		text = "(" + c.Function.Name + ")"
	}
	exempt := cfg.PapikChatID != 0 && s.chat.ID == cfg.PapikChatID
	a.Auto.RecordSend(s.chat.ID, s.chat.Title, text, exempt)
}

// goToSleep is the go_to_sleep tool backend.
func (a *Agent) goToSleep(minutes int, reason string) string {
	if minutes <= 0 {
		minutes = 360
	}
	until := a.Auto.Sleep(time.Duration(minutes)*time.Minute, reason)
	a.Auto.Log(fmt.Sprintf("went to sleep until %s (%s)", until.In(a.location()).Format("15:04"), strings.TrimSpace(reason)))
	a.Metrics.Inc("kuni_autonomy_sleeps_total", 1, nil)
	if a.Diary != nil && a.runCtx != nil {
		ctx := a.runCtx
		a.spawn("sleep consolidation", func() { // sleep consolidates memories (one cycle at a time, see Diary.Consolidate)
			_ = a.Diary.Consolidate(ctx, a.Cfg.Get().SleepMaxTime)
		})
	}
	return fmt.Sprintf("You fall asleep until about %s.", until.In(a.location()).Format("15:04"))
}

// sleepBlock tells the model it is drowsy when it is night or it went to sleep.
func (a *Agent) sleepBlock() string {
	cfg := a.Cfg.Get()
	if !cfg.AutonomyEnabled || a.Auto == nil {
		return ""
	}
	loc := a.location()
	if asleep, until := a.Auto.Asleep(); asleep {
		return fmt.Sprintf("<state>You are asleep until about %s. This message woke you up: answer drowsy and brief, or stay silent if it is not important or not meant for you. Your owner always matters.</state>\n", until.In(loc).Format("15:04"))
	}
	if a.isNight(time.Now()) {
		return fmt.Sprintf("<state>It is night for you (%s). You are drowsy; short sleepy replies are natural.</state>\n", time.Now().In(loc).Format("15:04"))
	}
	return ""
}

// ActAutonomously is one round of her own initiative: she decides whether to write first, speak her mind,
// go to sleep or do nothing. Nights, sleep and the daily cap are checked here; the per-message limits in runTurn.
func (a *Agent) ActAutonomously(ctx context.Context) error {
	cfg := a.Cfg.Get()
	if a.paused.Load() || a.Auto == nil || a.Usage.Over(cfg.DailyTokenLimit) {
		return nil
	}
	now := time.Now()
	if asleep, _ := a.Auto.Asleep(); asleep {
		return nil
	}
	if a.isNight(now) {
		return nil
	}
	left := cfg.AutonomyMaxPerDay - a.Auto.SentToday()
	if left <= 0 {
		return nil
	}
	a.Auto.Ran()
	before := a.Auto.Entries()
	s := a.getSession(0)
	s.mu.Lock()
	defer s.mu.Unlock()
	d := a.depsFor(s)
	s.chat.ID = 0
	s.tools = tools.NewRegistry(a.baseTools(d, true)...)
	var b strings.Builder
	if s.fresh {
		s.fresh = false
		if wm, _ := (memory.WorkingMemory{Path: cfg.WorkingMemoryFile}).Load(); strings.TrimSpace(wm) != "" {
			b.WriteString("<things_to_remember>\n" + wm + "\n</things_to_remember>\n\n")
		}
	}
	fmt.Fprintf(&b, "It is %s (%s).\n%s", now.In(a.location()).Format("Mon 2 Jan 15:04"), partOfDay(now.In(a.location())), a.moodBlock())
	if recent := a.Auto.Recent(6); len(recent) > 0 {
		b.WriteString("<your_recent_initiatives>\n" + strings.Join(recent, "\n") + "\n</your_recent_initiatives>\n")
	}
	fmt.Fprintf(&b, "You have free time and nobody is writing to you right now. You decide what to do, like a real person would:\n"+
		"1. Write first to someone you know (a friend, a group, your owner) - only with a real reason: something you remembered, a thought, a question, news, a joke. Never a bare \"hi, how are you\". Do not write again to someone who has not answered your last message.\n"+
		"2. Speak your mind: tell your owner or a group what you are thinking about, share an opinion, react to what happened in the chats.\n"+
		"3. Go to sleep with #go_to_sleep if you are tired, it is late or your mood is low.\n"+
		"4. Or do nothing (#wait). Doing nothing is often the right choice; do not invent activity.\n"+
		"Look through your chats with #get_telegram_chats and open one with #open_chat. You may start at most %d more conversation(s) today; the limit is enforced, and so are your lockdown rules.", left)
	s.msgs = append(s.msgs, llm.Message{Role: "user", Content: b.String()})
	err := a.runTurn(ctx, s)
	if a.Auto.Entries() == before {
		a.Auto.Log("looked around, did nothing")
	}
	return err
}

func partOfDay(t time.Time) string {
	switch h := t.Hour(); {
	case h < 5:
		return "deep night"
	case h < 12:
		return "morning"
	case h < 18:
		return "afternoon"
	case h < 23:
		return "evening"
	}
	return "late evening"
}
