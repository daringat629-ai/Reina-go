package agent

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"

	"kuni/internal/config"
	"kuni/internal/diary"
	"kuni/internal/llm"
	"kuni/internal/llmui"
	"kuni/internal/media"
	"kuni/internal/memory"
	"kuni/internal/metrics"
	"kuni/internal/mood"
	"kuni/internal/prompts"
	"kuni/internal/telegram"
	"kuni/internal/tools"
)

type fakeLLM struct {
	srv   *httptest.Server
	mu    sync.Mutex
	calls []map[string]any
}

// newFakeLLM answers: tool calls when tools are offered and the last message is from the user,
// a thought after tool results, long diary-like text otherwise.
func newFakeLLM(t *testing.T, toolCall func(chatID int64) llm.ToolCall) *fakeLLM {
	f := &fakeLLM{}
	f.srv = httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		var req map[string]any
		_ = json.NewDecoder(r.Body).Decode(&req)
		f.mu.Lock()
		f.calls = append(f.calls, req)
		f.mu.Unlock()
		if strings.HasSuffix(r.URL.Path, "/embeddings") {
			json.NewEncoder(w).Encode(map[string]any{"data": []any{map[string]any{"embedding": []float64{1, 0.5}}}})
			return
		}
		msgs, _ := req["messages"].([]any)
		last, _ := msgs[len(msgs)-1].(map[string]any)
		msg := map[string]any{"role": "assistant", "content": "A long enough diary page about talking to Alex today.\n---\nSecond page: he asked how I am doing and I said hi."}
		if _, hasTools := req["tools"]; hasTools {
			if last["role"] == "user" {
				msg = map[string]any{"role": "assistant", "content": "I should greet them.", "tool_calls": []any{toolCall(0)}}
			} else {
				msg = map[string]any{"role": "assistant", "content": "ok, done."}
			}
		}
		json.NewEncoder(w).Encode(map[string]any{"choices": []any{map[string]any{"message": msg}}, "usage": map[string]any{"prompt_tokens": 100, "completion_tokens": 10}})
	}))
	t.Cleanup(f.srv.Close)
	return f
}

type rig struct {
	ag  *Agent
	tg  *telegram.Fake
	dir string
}

func newRig(t *testing.T, f *fakeLLM) *rig {
	dir := t.TempDir()
	cfg := &config.Config{
		CharacterName: "Kuni", PapikName: "Alex", PapikChatID: 100,
		LLMBaseURL: f.srv.URL + "/", EmbeddingBaseURL: f.srv.URL + "/", LLMModel: "m", EmbeddingModel: "e",
		DiaryDir: filepath.Join(dir, "diary"), WorkingMemoryFile: filepath.Join(dir, "wm.md"), DataDir: filepath.Join(dir, "data"),
		MaxToolRounds: 6, MaxRelatedEntries: 4, DebounceWindow: 10 * time.Millisecond, UseStickers: true, Lockdown: "none", MoodEnabled: true, GroupReplyMode: "all",
	}
	h := config.NewStaticHolder(cfg)
	client := llm.New(cfg.LLMBaseURL, cfg.EmbeddingBaseURL, "", "m", "e", 5*time.Second)
	ps, err := prompts.NewStore(filepath.Join(dir, "prompts"), prompts.Vars{CharacterName: "Kuni", PapikName: "Alex"})
	if err != nil {
		t.Fatal(err)
	}
	d, _ := diary.New(cfg.DiaryDir, client, 0.1, 4000)
	tg := telegram.NewFake()
	getCfg := h.Get
	svc := func() media.Services { return media.NewDisabled() }
	ui := &llmui.Env{TG: tg, LLM: client, Prompts: ps, Media: svc, Cfg: getCfg}
	m := metrics.New()
	deps := tools.Deps{TG: tg, LLM: client, Diary: d, Prompts: ps, Media: svc, Cfg: getCfg, UI: ui, Metrics: m, Mood: mood.New(filepath.Join(dir, "mood.json"))}
	ag := New(&Agent{Cfg: h, LLM: client, TG: tg, Diary: d, Prompts: ps, UI: ui, Metrics: m, Deps: deps,
		Dumper: &memory.Dumper{LLM: client, Diary: d, Prompts: ps, CharacterName: func() string { return "Kuni" }}})
	// background turns (wakes after an approval, reminders...) must not outlive the test and write into its TempDir
	t.Cleanup(func() { ag.WaitBackground(10 * time.Second) })
	return &rig{ag: ag, tg: tg, dir: dir}
}

func waitFor(t *testing.T, what string, cond func() bool) {
	t.Helper()
	deadline := time.Now().Add(5 * time.Second)
	for time.Now().Before(deadline) {
		if cond() {
			return
		}
		time.Sleep(20 * time.Millisecond)
	}
	t.Fatalf("timeout waiting for %s", what)
}

func sendCall(chatID int64) llm.ToolCall {
	return llm.ToolCall{ID: "c1", Type: "function", Function: llm.FunctionCall{
		Name: "send_telegram_message", Arguments: `{"text":"hi~","photo_filename":null,"audio_filename":null,"reply_to_message_id":null}`}}
}

func TestIncomingMessageGetsAnswerViaTool(t *testing.T) {
	r := newRig(t, newFakeLLM(t, sendCall))
	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan struct{})
	go func() { r.ag.Run(ctx); close(done) }()

	r.tg.Incoming(telegram.Chat{ID: 100, Title: "Alex", Kind: telegram.ChatPrivate, IsMember: true}, 100, "Alex", "hello Kuni")
	waitFor(t, "kuni to answer", func() bool { return len(r.tg.SentTexts()) == 1 })
	if got := r.tg.SentTexts()[0]; got != "hi~" {
		t.Fatalf("sent %q", got)
	}
	if r.ag.Metrics.Get("kuni_tool_calls_total", map[string]string{"tool": "send_telegram_message"}) != 1 {
		t.Fatalf("tool metric missing")
	}
	// messages were marked read, so nothing is pending
	if un, _ := r.tg.Unread(ctx, 100); len(un) != 0 {
		t.Fatalf("unread left: %v", un)
	}
	cancel()
	<-done

	// shutdown dumped the session: diary has entries and working memory is written.
	entries, _ := r.ag.Diary.Load()
	if len(entries) == 0 {
		t.Fatalf("session was not dumped to the diary")
	}
	if wm, _ := os.ReadFile(r.ag.Cfg.Get().WorkingMemoryFile); len(wm) == 0 {
		t.Fatalf("working memory not written")
	}
}

func TestLockdownBlocksForeignChats(t *testing.T) {
	r := newRig(t, newFakeLLM(t, sendCall))
	cfg := *r.ag.Cfg.Get()
	cfg.Lockdown = "papik_only"
	r.ag.Cfg = config.NewStaticHolder(&cfg)
	r.ag.Deps.Cfg = r.ag.Cfg.Get

	r.tg.Incoming(telegram.Chat{ID: 555, Title: "Stranger", Kind: telegram.ChatPrivate, IsMember: true}, 555, "Stranger", "hey")
	if err := r.ag.HandleChat(context.Background(), 555); err != nil {
		t.Fatal(err)
	}
	if n := len(r.tg.SentTexts()); n != 0 {
		t.Fatalf("answered a locked-down chat (%d messages)", n)
	}
}

func TestSendToolRejectsRepeatAndPathTraversal(t *testing.T) {
	r := newRig(t, newFakeLLM(t, sendCall))
	chat := telegram.Chat{ID: 100, Title: "Alex", Kind: telegram.ChatPrivate, IsMember: true}
	r.tg.Incoming(chat, 100, "Alex", "x")
	reg := tools.ChatTools(r.ag.Deps, chat)

	ctx := context.Background()
	if out := reg.Call(ctx, "send_telegram_message", `{"text":"same"}`); !strings.Contains(out, "message_id") {
		t.Fatalf("first send failed: %s", out)
	}
	if out := reg.Call(ctx, "send_telegram_message", `{"text":"same"}`); !strings.HasPrefix(out, "Error") {
		t.Fatalf("repeat should be rejected, got: %s", out)
	}
	if out := reg.Call(ctx, "send_telegram_message", `{"photo_filename":"../../etc/passwd"}`); !strings.HasPrefix(out, "Error") {
		t.Fatalf("path traversal not rejected: %s", out)
	}
}

func TestEditAndRemoveOnlyOwnMessages(t *testing.T) {
	r := newRig(t, newFakeLLM(t, sendCall))
	chat := telegram.Chat{ID: 100, Title: "Alex", Kind: telegram.ChatPrivate, IsMember: true}
	theirs := r.tg.Incoming(chat, 100, "Alex", "mine")
	ctx := context.Background()
	reg := tools.ChatTools(r.ag.Deps, chat)
	args, _ := json.Marshal(map[string]any{"message_id": theirs.ID, "text": "hacked"})
	if out := reg.Call(ctx, "edit_message_text", string(args)); !strings.HasPrefix(out, "Error") {
		t.Fatalf("edited someone else's message: %s", out)
	}
	if out := reg.Call(ctx, "remove_message", `{"message_id":`+itoa(theirs.ID)+`}`); !strings.HasPrefix(out, "Error") {
		t.Fatalf("removed someone else's message: %s", out)
	}
}

func TestReactionNormalisationAndAllowList(t *testing.T) {
	r := newRig(t, newFakeLLM(t, sendCall))
	chat := telegram.Chat{ID: 100, Title: "Alex", Kind: telegram.ChatPrivate, IsMember: true}
	m := r.tg.Incoming(chat, 100, "Alex", "nice")
	reg := tools.ChatTools(r.ag.Deps, chat)
	ctx := context.Background()
	if out := reg.Call(ctx, "react_with_emoji", `{"message_id":`+itoa(m.ID)+`,"emoji":"❤️"}`); strings.HasPrefix(out, "Error") {
		t.Fatalf("heart with U+FE0F rejected: %s", out)
	}
	if got := r.tg.Reacted[m.ID]; got != "❤" {
		t.Fatalf("variation selector not stripped: %q", got)
	}
	if out := reg.Call(ctx, "react_with_emoji", `{"message_id":1,"emoji":"🦖"}`); !strings.HasPrefix(out, "Error") {
		t.Fatalf("disallowed emoji accepted")
	}
}

func TestChannelAndNonMemberToolSets(t *testing.T) {
	r := newRig(t, newFakeLLM(t, sendCall))
	ch := tools.ChatTools(r.ag.Deps, telegram.Chat{ID: -1, Title: "News", Kind: telegram.ChatChannel, IsMember: true})
	if ch.Has("send_telegram_message") || !ch.Has("react_with_emoji") || !ch.Has("forward_message") {
		t.Fatalf("channel tools wrong: %v", ch.Names())
	}
	nm := tools.ChatTools(r.ag.Deps, telegram.Chat{ID: -2, Title: "Club", Kind: telegram.ChatGroup, IsMember: false})
	if nm.Has("send_telegram_message") || !nm.Has("react_with_emoji") {
		t.Fatalf("non-member tools wrong: %v", nm.Names())
	}
	admin := tools.ChatTools(r.ag.Deps, telegram.Chat{ID: -3, Title: "G", Kind: telegram.ChatGroup, IsMember: true, IsAdmin: true})
	if !admin.Has("group_admin_ban_user") {
		t.Fatalf("admin tools missing")
	}
	plain := tools.ChatTools(r.ag.Deps, telegram.Chat{ID: -3, Title: "G", Kind: telegram.ChatGroup, IsMember: true})
	if plain.Has("group_admin_ban_user") {
		t.Fatalf("non-admin got admin tools")
	}
}

func TestTrimKeepsToolPairs(t *testing.T) {
	msgs := []llm.Message{{Role: "user"}, {Role: "assistant"}, {Role: "tool"}, {Role: "user"}, {Role: "assistant"}, {Role: "tool"}}
	got := trim(msgs, 4)
	if got[0].Role != "user" {
		t.Fatalf("trimmed history starts with %s", got[0].Role)
	}
}

func itoa(n int64) string { b, _ := json.Marshal(n); return string(b) }

func TestLockdownContactsOnly(t *testing.T) {
	cfg := &config.Config{Lockdown: "contacts_only", PapikChatID: 100}
	tools.Contacts = func(id int64) bool { return id == 7 }
	defer func() { tools.Contacts = nil }()
	for id, want := range map[int64]bool{100: true, -55: true, 7: true, 8: false} {
		if got := tools.Accessible(cfg, id); got != want {
			t.Errorf("chat %d: got %v want %v", id, got, want)
		}
	}
}

func toolNames(req map[string]any) map[string]bool {
	out := map[string]bool{}
	ts, _ := req["tools"].([]any)
	for _, t := range ts {
		fn, _ := t.(map[string]any)["function"].(map[string]any)
		out[fn["name"].(string)] = true
	}
	return out
}

func TestLazyToolsHideAndAutoUnlock(t *testing.T) {
	n := 0
	f := newFakeLLM(t, func(int64) llm.ToolCall { // distinct texts: identical ones are blocked by anti-repeat
		n++
		return llm.ToolCall{ID: "c", Type: "function", Function: llm.FunctionCall{Name: "send_telegram_message",
			Arguments: `{"text":"hi ` + string(rune('0'+n)) + `","photo_filename":null,"audio_filename":null,"reply_to_message_id":null}`}}
	})
	r := newRig(t, f)
	r.ag.Cfg.Get().LazyTools = true
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	r.start(t, ctx, cancel)
	chat := telegram.Chat{ID: 100, Title: "Alex", Kind: telegram.ChatPrivate, IsMember: true}
	r.tg.Incoming(chat, 100, "Alex", "hello")
	waitFor(t, "reply", func() bool { return len(r.tg.SentTexts()) == 1 })
	f.mu.Lock()
	first := toolNames(f.calls[len(f.calls)-1])
	f.mu.Unlock()
	if !first["send_telegram_message"] || !first["more_tools"] || first["record_audio"] || first["edit_message_text"] {
		t.Fatalf("unexpected tool set: %v", first)
	}
	r.tg.Incoming(chat, 100, "Alex", "скинь голосовое пожалуйста")
	waitFor(t, "second reply", func() bool { return len(r.tg.SentTexts()) == 2 })
	f.mu.Lock()
	last := toolNames(f.calls[len(f.calls)-1])
	f.mu.Unlock()
	if !last["record_audio"] {
		t.Fatalf("media group was not unlocked by the message: %v", last)
	}
}

func TestCompactSummarisesOldHistory(t *testing.T) {
	r := newRig(t, newFakeLLM(t, sendCall))
	r.ag.Cfg.Get().HistoryKeep = 3
	s := r.ag.getSession(5)
	for i := 0; i < 5; i++ {
		s.msgs = append(s.msgs, llm.Message{Role: "user", Content: "u" + string(rune('0'+i))},
			llm.Message{Role: "assistant", Content: "a" + string(rune('0'+i))})
	}
	r.ag.compact(context.Background(), s)
	if len(s.msgs) >= 10 || s.msgs[0].Role != "user" || !strings.HasPrefix(s.msgs[0].Content, "<conversation_so_far>") {
		t.Fatalf("not compacted: %d %+v", len(s.msgs), s.msgs[0])
	}
	if last := s.msgs[len(s.msgs)-1]; last.Content != "a4" {
		t.Fatalf("recent messages must stay verbatim: %+v", last)
	}
	// below the threshold nothing happens
	n := len(s.msgs)
	r.ag.compact(context.Background(), s)
	if len(s.msgs) != n {
		t.Fatal("compacted twice")
	}
}

func TestForcedToolCallAndWait(t *testing.T) {
	f := newFakeLLM(t, func(int64) llm.ToolCall {
		return llm.ToolCall{ID: "w", Type: "function", Function: llm.FunctionCall{Name: "wait", Arguments: `{}`}}
	})
	r := newRig(t, f)
	r.ag.Cfg.Get().ForceTools = true
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	r.start(t, ctx, cancel)
	r.tg.Incoming(telegram.Chat{ID: 100, Title: "Alex", Kind: telegram.ChatPrivate, IsMember: true}, 100, "Alex", "hello")
	waitFor(t, "a turn with tools", func() bool {
		f.mu.Lock()
		defer f.mu.Unlock()
		for _, c := range f.calls {
			if _, ok := c["tools"]; ok {
				return true
			}
		}
		return false
	})
	time.Sleep(300 * time.Millisecond) // a wait-only round must end the turn: no second tool round
	f.mu.Lock()
	defer f.mu.Unlock()
	n := 0
	for _, c := range f.calls {
		if _, ok := c["tools"]; ok {
			n++
			if c["tool_choice"] != "required" {
				t.Fatalf("first round must force a tool call, got %v", c["tool_choice"])
			}
		}
	}
	if n != 1 {
		t.Fatalf("expected exactly 1 tool round, got %d", n)
	}
	if len(r.tg.SentTexts()) != 0 {
		t.Fatal("wait must not send anything")
	}
}

func TestNotificationTurnHasNoOpenChat(t *testing.T) {
	r := newRig(t, newFakeLLM(t, sendCall))
	s := r.ag.getSession(100)
	chat := telegram.Chat{ID: 100, Title: "Alex", Kind: telegram.ChatPrivate, IsMember: true}
	reg := r.ag.newRegistry(s, r.ag.depsFor(s), chat, false, nil)
	if reg.Has("open_chat") || !reg.Has("wait") || !reg.Has("send_telegram_message") {
		t.Fatalf("tools: %v", reg.Names())
	}
	if !r.ag.newRegistry(s, r.ag.depsFor(s), chat, true, nil).Has("open_chat") {
		t.Fatal("proactive turns need open_chat")
	}
}

// start runs the agent and, at the end of the test, stops it and waits for the final
// diary dump to finish so that the temp directory is not deleted under its feet.
func (r *rig) start(t *testing.T, ctx context.Context, cancel context.CancelFunc) {
	done := make(chan struct{})
	go func() { r.ag.Run(ctx); close(done) }()
	t.Cleanup(func() {
		cancel()
		select {
		case <-done:
		case <-time.After(10 * time.Second):
		}
	})
}

func TestMoodIsInjectedAndToggles(t *testing.T) {
	f := newFakeLLM(t, sendCall)
	r := newRig(t, f)
	r.ag.Deps.Mood.Set(5)
	ctx, cancel := context.WithCancel(context.Background())
	r.start(t, ctx, cancel)
	r.tg.Incoming(telegram.Chat{ID: 100, Title: "Alex", Kind: telegram.ChatPrivate, IsMember: true}, 100, "Alex", "hello")
	waitFor(t, "reply", func() bool { return len(r.tg.SentTexts()) == 1 })
	f.mu.Lock()
	defer f.mu.Unlock()
	var first string
	var hasTool bool
	for _, c := range f.calls {
		if ts, ok := c["tools"].([]any); ok {
			for _, x := range ts {
				if x.(map[string]any)["function"].(map[string]any)["name"] == "change_mood" {
					hasTool = true
				}
			}
			for _, m := range c["messages"].([]any) {
				if mm := m.(map[string]any); mm["role"] == "user" {
					first, _ = mm["content"].(string)
					break
				}
			}
			break
		}
	}
	if !strings.Contains(first, `<mood level="5/100"`) || !strings.Contains(first, "swear constantly") {
		t.Fatalf("mood block missing from the turn:\n%s", first)
	}
	if !hasTool {
		t.Fatal("change_mood tool not offered")
	}
}

func TestMoodOffMeansNoBlock(t *testing.T) {
	r := newRig(t, newFakeLLM(t, sendCall))
	r.ag.Cfg.Get().MoodEnabled = false
	if r.ag.moodBlock() != "" {
		t.Fatal("mood block must be empty when the scale is off")
	}
	s := r.ag.getSession(100)
	reg := r.ag.newRegistry(s, r.ag.depsFor(s), telegram.Chat{ID: 100, Kind: telegram.ChatPrivate, IsMember: true}, false, nil)
	if reg.Has("change_mood") {
		t.Fatal("change_mood must be hidden when the scale is off")
	}
}

func TestGroupPromptHasRosterAndRulesAndOwnerGetsAllTools(t *testing.T) {
	r := newRig(t, newFakeLLM(t, sendCall))
	r.ag.Cfg.Get().PapikChatID = 5
	r.ag.Cfg.Get().OwnerTools = true
	r.tg.Roster = map[int64][]telegram.Member{-30: {{ID: 5, Name: "Jaabir", Role: "owner"}, {ID: 9, Name: "Joe", Role: "member"}}}
	group := telegram.Chat{ID: -30, Title: "Club", Kind: telegram.ChatGroup, IsMember: true}
	m := r.tg.Incoming(group, 9, "Joe", "anyone here?")
	s := r.ag.getSession(group.ID)
	view, err := r.ag.renderChat(context.Background(), s, group, []telegram.Message{m})
	if err != nil {
		t.Fatal(err)
	}
	for _, want := range []string{"<chat_info", `user_id="9"`, `is_owner="true"`, "GROUP RULES", "addressed_to_you"} {
		if !strings.Contains(view, want) {
			t.Fatalf("group view lacks %q:\n%s", want, view)
		}
	}
	// the roster is not repeated on the very next turn
	again, _ := r.ag.renderChat(context.Background(), s, group, []telegram.Message{m})
	if strings.Contains(again, "<chat_info") {
		t.Fatal("roster repeated every turn wastes tokens")
	}
	for _, n := range []string{"chat_members", "user_info", "view_messages_around"} {
		if !s.tools.Has(n) {
			t.Fatalf("group chat lacks %s: %v", n, s.tools.Names())
		}
	}
	// owner's own chat: every lazy group is unlocked up front
	os := r.ag.getSession(5)
	reg := r.ag.newRegistry(os, r.ag.depsFor(os), telegram.Chat{ID: 5, Title: "Jaabir", Kind: telegram.ChatPrivate, IsMember: true}, false, nil)
	for _, n := range []string{"shell", "search_messages", "sticker_send", "edit_message_text", "chat_members"} {
		if !reg.Has(n) {
			t.Fatalf("owner chat lacks %s: %v", n, reg.Names())
		}
	}
}

func TestPrivateChatViewShowsTheHeaderAndTheExtrasOfMessages(t *testing.T) {
	r := newRig(t, newFakeLLM(t, sendCall))
	chat := telegram.Chat{ID: 77, Title: "Алина", Kind: telegram.ChatPrivate, IsMember: true, Presence: "online", Typing: "typing"}
	m := r.tg.Incoming(chat, 77, "Алина", "выбери")
	r.tg.S.Update(77, m.ID, func(x *telegram.Message) {
		x.Buttons = [][]telegram.Button{{{Text: "Да", Kind: "callback", Data: "eWVz"}}}
	})
	_ = r.tg.Pin(context.Background(), 77, m.ID, false)
	m, _ = r.tg.Message(context.Background(), 77, m.ID)
	s := r.ag.getSession(77)
	view, err := r.ag.renderChat(context.Background(), s, chat, []telegram.Message{m})
	if err != nil {
		t.Fatal(err)
	}
	for _, want := range []string{`<chat_header`, `status="online"`, `typing_now="typing"`, `pinned="выбери"`, "[1.1 Да]"} {
		if !strings.Contains(view, want) {
			t.Fatalf("view lacks %q:\n%s", want, view)
		}
	}
}

func TestOwnerChatGetsAnOverviewOfTheRestOfTelegram(t *testing.T) {
	r := newRig(t, newFakeLLM(t, sendCall))
	cfg := r.ag.Cfg.Get()
	cfg.PapikChatID, cfg.OwnerTools, cfg.DeskOverview = 5, true, true
	owner := telegram.Chat{ID: 5, Title: "Jaabir", Kind: telegram.ChatPrivate, IsMember: true}
	r.tg.Incoming(telegram.Chat{ID: 60, Title: "Алина", Kind: telegram.ChatPrivate, IsMember: true, Presence: "online", Pinned: true}, 60, "Алина", "ты где?")
	r.tg.Incoming(telegram.Chat{ID: -61, Title: "Работа", Kind: telegram.ChatGroup, IsMember: true, UnreadMentions: 2}, 9, "Бек", "@reina глянь")
	r.tg.Incoming(telegram.Chat{ID: -62, Title: "Новости", Kind: telegram.ChatChannel, IsMember: true, Muted: true}, 9, "Н", "новость")
	r.tg.Incoming(telegram.Chat{ID: 63, Title: "Тихий", Kind: telegram.ChatPrivate, IsMember: true}, 63, "Тихий", "x")
	r.tg.S.UpdateChat(63, func(c *telegram.Chat) { c.Unread = 0 })
	r.tg.Rich.FolderList = []telegram.Folder{{ID: 1, Name: "Семья"}}
	m := r.tg.Incoming(owner, 5, "Jaabir", "что нового?")
	s := r.ag.getSession(5)
	view, err := r.ag.renderChat(context.Background(), s, owner, []telegram.Message{m})
	if err != nil {
		t.Fatal(err)
	}
	for _, want := range []string{"<telegram_desk", `title="Алина"`, `unread="1"`, `online="true"`, `pinned="true"`, `title="Работа"`, `mentions="2"`, "folders: Семья", "1 muted chats"} {
		if !strings.Contains(view, want) {
			t.Fatalf("overview lacks %q:\n%s", want, view)
		}
	}
	if strings.Contains(view, `title="Jaabir"`) || strings.Contains(view, `title="Тихий"`) || strings.Contains(view, `title="Новости"`) {
		t.Fatalf("overview lists the current, empty or muted chat:\n%s", view)
	}
	// a running session does not get it again right away
	s.msgs = append(s.msgs, llm.Message{Role: "user", Content: "x"}, llm.Message{Role: "assistant", Content: "y"})
	again, _ := r.ag.renderChat(context.Background(), s, owner, []telegram.Message{m})
	if strings.Contains(again, "<telegram_desk") {
		t.Fatal("overview repeated on every turn")
	}
	// a stranger's chat never gets it: it names other people's chats
	stranger := telegram.Chat{ID: 70, Title: "Чужой", Kind: telegram.ChatPrivate, IsMember: true}
	sm := r.tg.Incoming(stranger, 70, "Чужой", "привет")
	sv, _ := r.ag.renderChat(context.Background(), r.ag.getSession(70), stranger, []telegram.Message{sm})
	if strings.Contains(sv, "<telegram_desk") || strings.Contains(sv, "Алина") {
		t.Fatalf("a stranger's chat leaked the overview:\n%s", sv)
	}
	// switched off
	cfg.DeskOverview = false
	off, _ := r.ag.renderChat(context.Background(), r.ag.getSession(5+1000), owner, []telegram.Message{m})
	if strings.Contains(off, "<telegram_desk") {
		t.Fatal("overview not switched off")
	}
}
