// Package diary is Kuni's long-term memory: markdown files with a JSON prologue
// (confidence + embedding), RAG-style retrieval by cosine similarity, and the
// "sleep" consolidation loop. Port of src/Diary.cpp.
//
// File format (same as the C++ version):
//
//	---
//	{"confidence":0.5,"embedding":[...]}
//	---
//	free-form body
package diary

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"math/rand"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"kuni/internal/llm"
	"kuni/internal/util"
)

const ext = ".md"

type Metadata struct {
	Confidence float64   `json:"confidence"`
	Embedding  []float64 `json:"embedding,omitempty"`
}

type Entry struct {
	ID   string
	Meta Metadata
	Body string
}

// Related is an entry together with its relevance score for a query.
type Related struct {
	Entry     Entry
	Relevance float64
}

type Diary struct {
	Dir              string
	LLM              *llm.Client
	ConfidenceFactor float64
	TokenTrigger     int
	// SleepPrompt returns the sleep_consolidator system prompt (hot-reloadable).
	SleepPrompt func() string
	rnd         *rand.Rand
	consMu      sync.Mutex   // one sleep consolidation at a time
	tuneMu      sync.RWMutex // guards ConfidenceFactor and TokenTrigger once the diary is in use (SetTuning)
}

// SetTuning changes the ranking weight and the merge trigger while the diary is in use (config hot reload).
func (d *Diary) SetTuning(confidenceFactor float64, tokenTrigger int) {
	d.tuneMu.Lock()
	d.ConfidenceFactor, d.TokenTrigger = confidenceFactor, tokenTrigger
	d.tuneMu.Unlock()
}

func (d *Diary) tuning() (float64, int) {
	d.tuneMu.RLock()
	defer d.tuneMu.RUnlock()
	return d.ConfidenceFactor, d.TokenTrigger
}

func New(dir string, client *llm.Client, confidenceFactor float64, tokenTrigger int) (*Diary, error) {
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return nil, err
	}
	return &Diary{
		Dir:              dir,
		LLM:              client,
		ConfidenceFactor: confidenceFactor,
		TokenTrigger:     tokenTrigger,
		rnd:              rand.New(rand.NewSource(time.Now().UnixNano())),
	}, nil
}

// Parse splits a raw file into metadata and body. Files without a valid
// prologue are returned as body-only entries, as in the C++ parser.
func Parse(id, text string) Entry {
	text = strings.Trim(text, "\n")
	e := Entry{ID: id, Body: text}
	if !strings.HasPrefix(text, "---") {
		return e
	}
	end := strings.Index(text[3:], "---")
	if end < 0 {
		return e
	}
	end += 3
	var meta Metadata
	if err := json.Unmarshal([]byte(strings.TrimSpace(text[3:end])), &meta); err != nil {
		log.Printf("diary: can't parse metadata of %s: %v", id, err)
		return e
	}
	e.Meta = meta
	e.Body = strings.TrimLeft(text[end+3:], "\n")
	return e
}

// Format is the inverse of Parse.
func Format(e Entry) (string, error) {
	js, err := json.Marshal(e.Meta)
	if err != nil {
		return "", err
	}
	return fmt.Sprintf("---\n%s\n---\n%s\n", js, e.Body), nil
}

// Load reads and parses every *.md entry in the diary directory.
func (d *Diary) Load() ([]Entry, error) {
	files, err := os.ReadDir(d.Dir)
	if err != nil {
		return nil, err
	}
	var out []Entry
	for _, f := range files {
		if f.IsDir() || filepath.Ext(f.Name()) != ext {
			continue
		}
		raw, err := os.ReadFile(filepath.Join(d.Dir, f.Name()))
		if err != nil {
			return nil, err
		}
		id := strings.TrimSuffix(f.Name(), ext)
		out = append(out, Parse(id, string(raw)))
	}
	return out, nil
}

// Save writes an entry to <dir>/<id>.md.
func (d *Diary) Save(e Entry) error {
	s, err := Format(e)
	if err != nil {
		return err
	}
	return util.WriteFileAtomic(filepath.Join(d.Dir, e.ID+ext), []byte(s), 0o644)
}

// Remove deletes an entry file if it exists.
func (d *Diary) Remove(id string) error {
	err := os.Remove(filepath.Join(d.Dir, id+ext))
	if os.IsNotExist(err) {
		return nil
	}
	return err
}

// Query returns the top-n entries most related to vec.
// Entries without an embedding get one computed (and persisted) on the fly.
func (d *Diary) Query(ctx context.Context, entries []Entry, vec []float64, n int) ([]Related, error) {
	cf, _ := d.tuning()
	var out []Related
	for i := range entries {
		e := &entries[i]
		if e.Body == "" {
			continue
		}
		if len(e.Meta.Embedding) != len(vec) {
			emb, err := d.LLM.Embedding(ctx, strings.ReplaceAll(e.Body, "\t", "  "))
			if err != nil {
				return nil, fmt.Errorf("embedding for %s: %w", e.ID, err)
			}
			e.Meta.Embedding = emb
			if err := d.Save(*e); err != nil {
				return nil, err
			}
		}
		cos, err := util.CosineSimilarity(vec, e.Meta.Embedding)
		if err != nil {
			continue
		}
		rel := (cos+1)/2 + e.Meta.Confidence*cf
		out = append(out, Related{Entry: *e, Relevance: rel})
	}
	sort.SliceStable(out, func(i, j int) bool { return out[i].Relevance > out[j].Relevance })
	if len(out) > n {
		out = out[:n]
	}
	return out, nil
}

// Consolidate runs one "sleep" cycle, bounded by maxTime. For each chosen chunk
// it finds related entries, asks the LLM to compress/merge them, writes the
// result back under fresh IDs (so they become "recent" again) and deletes the
// superseded low-confidence files.
func (d *Diary) Consolidate(ctx context.Context, maxTime time.Duration) error {
	_, trigger := d.tuning()
	if !d.consMu.TryLock() { // another sleep cycle is already running
		return nil
	}
	defer d.consMu.Unlock()
	deadline := time.Now().Add(maxTime)
	entries, err := d.Load()
	if err != nil {
		return err
	}
	sort.SliceStable(entries, func(i, j int) bool { return idLess(entries[j].ID, entries[i].ID) }) // recent first
	nextID := time.Now().Unix()

	for len(entries) > 0 && time.Now().Before(deadline) && ctx.Err() == nil {
		// 80%: most recent; 20%: random old memory surfaces too.
		idx := 0
		if d.rnd.Float64() >= 0.8 {
			idx = d.rnd.Intn(len(entries))
		}
		target := entries[idx]
		entries = append(entries[:idx], entries[idx+1:]...)
		if target.Body == "" {
			continue
		}
		if len(target.Meta.Embedding) == 0 {
			emb, err := d.LLM.Embedding(ctx, target.Body)
			if err != nil {
				log.Printf("diary: sleep: embedding %s: %v", target.ID, err)
				continue
			}
			target.Meta.Embedding = emb
		}

		results, err := d.Query(ctx, entries, target.Meta.Embedding, 16)
		if err != nil {
			log.Printf("diary: sleep: query: %v", err)
			continue
		}

		// Build the prompt: target first, then related entries until the token trigger.
		var body strings.Builder
		ids := []string{target.ID}
		idsToRemove := []string{}
		// the target itself is superseded by the consolidated entries too (unless it is a pinned fact, confidence ~1).
		if target.Meta.Confidence < 0.9999999 {
			idsToRemove = append(idsToRemove, target.ID)
		}
		writeEntry := func(e Entry) {
			if body.Len() > 0 {
				body.WriteString("\n\n---\n\n")
			}
			meta, _ := json.Marshal(map[string]float64{"confidence": e.Meta.Confidence})
			body.Write(meta)
			body.WriteString(e.Body)
			body.WriteString("\n")
		}
		writeEntry(target)
		consumed := map[string]bool{target.ID: true}
		for i, r := range results {
			if body.Len() > trigger && i >= 2 {
				break
			}
			writeEntry(r.Entry)
			ids = append(ids, r.Entry.ID)
			consumed[r.Entry.ID] = true
			if r.Entry.Meta.Confidence < 0.9999999 {
				idsToRemove = append(idsToRemove, r.Entry.ID)
			}
		}
		entries = removeIDs(entries, consumed)
		log.Printf("diary: sleep: consolidating %v", ids)

		var answer string
		for attempt := 0; attempt < 3; attempt++ {
			answer, err = d.LLM.Chat(llm.WithPurpose(ctx, "sleep"), d.sleepPrompt(), []llm.Message{{Role: "user", Content: body.String()}})
			if err == nil {
				break
			}
			log.Printf("diary: sleep: chat attempt %d: %v", attempt+1, err)
		}
		if err != nil {
			continue
		}

		for _, block := range strings.Split(answer, "\n---") {
			if len(strings.TrimSpace(block)) < 10 {
				continue
			}
			brace := strings.Index(block, "}")
			if brace < 0 {
				continue
			}
			var m struct {
				Confidence float64 `json:"confidence"`
			}
			if err := json.Unmarshal([]byte(block[:brace+1]), &m); err != nil {
				log.Printf("diary: sleep: can't parse block: %v", err)
				continue
			}
			if m.Confidence < -0.99999 {
				continue // dropped by the model
			}
			nextID++
			newEntry := Entry{
				ID:   strconv.FormatInt(nextID, 10),
				Meta: Metadata{Confidence: clamp(m.Confidence, -0.99, 0.99)},
				Body: strings.Trim(block[brace+1:], "\n"),
			}
			if err := d.Save(newEntry); err != nil {
				return err
			}
		}
		for _, id := range idsToRemove {
			if err := d.Remove(id); err != nil {
				return err
			}
		}
	}
	return ctx.Err()
}

// idLess compares diary IDs numerically when possible (unix timestamps), else lexically.
func idLess(a, b string) bool {
	ai, aerr := strconv.ParseInt(a, 10, 64)
	bi, berr := strconv.ParseInt(b, 10, 64)
	if aerr == nil && berr == nil {
		return ai < bi
	}
	return a < b
}

func removeIDs(entries []Entry, ids map[string]bool) []Entry {
	out := entries[:0]
	for _, e := range entries {
		if !ids[e.ID] {
			out = append(out, e)
		}
	}
	return out
}

func clamp(v, lo, hi float64) float64 {
	if v < lo {
		return lo
	}
	if v > hi {
		return hi
	}
	return v
}

func (d *Diary) sleepPrompt() string {
	if d.SleepPrompt != nil {
		if p := d.SleepPrompt(); p != "" {
			return p
		}
	}
	return `Merge, compress or rewrite the given diary entries into fewer, cleaner ones. Each entry starts with a JSON object {"confidence": x}; separate output entries with a line "---"; use confidence -1 to drop an entry.`
}
