package main

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"strings"
	"time"

	"kuni/internal/admin"
	"kuni/internal/browser"
	"kuni/internal/config"
	"kuni/internal/llm"
	"kuni/internal/maint"
	"kuni/internal/telegram"
)

// `kuni doctor` checks the configuration and the machine before (or instead of) a real start: the LLM key and model,
// embeddings, tdlib or the bot token, the helper programs, the disk, and how open the HTTP port is. It changes nothing
// (one tiny chat request of a few tokens is the only cost) and exits with 1 when something essential is broken.

type checkResult struct {
	level string // ok | warn | fail
	what  string
	note  string
}

type doctor struct {
	out     io.Writer
	results []checkResult
}

func (d *doctor) add(level, what, note string) {
	d.results = append(d.results, checkResult{level, what, note})
	mark := map[string]string{"ok": "✔", "warn": "⚠", "fail": "✘"}[level]
	if note != "" {
		fmt.Fprintf(d.out, "%s %s — %s\n", mark, what, note)
	} else {
		fmt.Fprintf(d.out, "%s %s\n", mark, what)
	}
}

func (d *doctor) failed() bool {
	for _, r := range d.results {
		if r.level == "fail" {
			return true
		}
	}
	return false
}

func runDoctor(path string, out io.Writer) error {
	d := &doctor{out: out}
	fmt.Fprintf(out, "kuni doctor: проверяю %s\n\n", path)
	cfg, err := config.Load(path)
	if errors.Is(err, config.ErrNeedsSetup) {
		d.add("fail", "config.toml", "файла не было, создан с настройками по умолчанию: заполни [llm], [general] и [telegram]")
		return errDoctor
	}
	if err != nil {
		d.add("fail", "config.toml", err.Error())
		return errDoctor
	}
	d.add("ok", "config.toml", "читается")

	ctx, cancel := context.WithTimeout(context.Background(), 90*time.Second)
	defer cancel()
	d.checkLLM(ctx, cfg)
	d.checkTelegram(ctx, cfg)
	d.checkPrograms(cfg)
	d.checkDisk(cfg)
	d.checkExposure(cfg, path)

	fmt.Fprintln(out)
	if d.failed() {
		fmt.Fprintln(out, "Есть ошибки (✘): с ними она не заработает. ⚠ — работать будет, но что-то выключено или небезопасно.")
		return errDoctor
	}
	fmt.Fprintln(out, "Главное в порядке. ⚠ — необязательное или стоит поправить.")
	return nil
}

var errDoctor = errors.New("doctor found problems")

func (d *doctor) checkLLM(ctx context.Context, cfg *config.Config) {
	if cfg.LLMBaseURL == "" || cfg.LLMModel == "" {
		d.add("fail", "LLM", "не заданы llm.base_url и llm.model")
		return
	}
	c := llm.New(cfg.LLMBaseURL, cfg.EmbeddingBaseURL, cfg.LLMAPIKey, cfg.LLMModel, cfg.EmbeddingModel, 60*time.Second)
	c.Update(llmSettings(cfg))
	start := time.Now()
	reply, err := c.Chat(llm.WithPurpose(ctx, "doctor"), "Answer with one word.", []llm.Message{{Role: "user", Content: "ping"}})
	switch {
	case err != nil:
		d.add("fail", "LLM "+cfg.LLMModel, explainLLMError(err))
	case strings.TrimSpace(reply) == "":
		d.add("warn", "LLM "+cfg.LLMModel, "отвечает пустым текстом (модель с обязательным рассуждением? попробуй llm.reasoning = \"low\")")
	default:
		d.add("ok", "LLM "+cfg.LLMModel, fmt.Sprintf("отвечает за %s", time.Since(start).Round(100*time.Millisecond)))
	}
	for _, m := range []struct{ name, model string }{{"light_model", cfg.LightModel}, {"fast_model", cfg.FastModel}, {"vision_model", cfg.VisionModel}} {
		if m.model == "" || m.model == cfg.LLMModel {
			continue
		}
		if _, err := c.Chat(llm.WithModel(ctx, m.model), "Answer with one word.", []llm.Message{{Role: "user", Content: "ping"}}); err != nil {
			d.add("warn", "llm."+m.name+" "+m.model, explainLLMError(err))
		} else {
			d.add("ok", "llm."+m.name+" "+m.model, "отвечает")
		}
	}
	if cfg.EmbeddingModel == "" {
		d.add("fail", "эмбеддинги", "не задан llm.embedding_model: без него не работает память (дневник)")
		return
	}
	if v, err := c.Embedding(ctx, "ping"); err != nil {
		d.add("fail", "эмбеддинги "+cfg.EmbeddingModel, explainLLMError(err)+" (без них не работает память; у OpenRouter эмбеддингов нет — нужен отдельный llm.embedding_base_url, например Ollama)")
	} else {
		d.add("ok", "эмбеддинги "+cfg.EmbeddingModel, fmt.Sprintf("вектор из %d чисел", len(v)))
	}
}

func explainLLMError(err error) string {
	s := err.Error()
	switch {
	case strings.Contains(s, "HTTP 401"), strings.Contains(s, "HTTP 403"):
		return "ключ не подходит (llm.api_key): " + short(s)
	case strings.Contains(s, "HTTP 402"):
		return "кончились деньги на балансе провайдера: " + short(s)
	case strings.Contains(s, "HTTP 404"):
		return "нет такого адреса или модели (llm.base_url должен кончаться на /v1/, имя модели — как у провайдера): " + short(s)
	case strings.Contains(s, "HTTP 429"):
		return "провайдер ограничил частоту запросов, попробуй позже: " + short(s)
	case strings.Contains(s, "connection refused"), strings.Contains(s, "no such host"):
		return "сервер не отвечает по llm.base_url: " + short(s)
	}
	return short(s)
}

func short(s string) string {
	s = strings.Join(strings.Fields(s), " ")
	if r := []rune(s); len(r) > 220 {
		return string(r[:220]) + "…"
	}
	return s
}

func (d *doctor) checkTelegram(ctx context.Context, cfg *config.Config) {
	if !cfg.TelegramEnabled {
		d.add("warn", "Telegram", "выключен (general.telegram_enabled = false): работает только прокси")
		return
	}
	if cfg.PapikChatID == 0 {
		d.add("warn", "general.papik_chat_id", "не задан: она не знает, кто владелец (нет команд, отчётов и владельческих инструментов)")
	}
	switch cfg.Mode {
	case "bot":
		if cfg.BotToken == "" {
			d.add("fail", "Telegram bot", "не задан telegram.bot_token")
			return
		}
		req, _ := http.NewRequestWithContext(ctx, http.MethodGet, strings.TrimRight(cfg.TelegramAPI, "/")+"/bot"+cfg.BotToken+"/getMe", nil)
		resp, err := http.DefaultClient.Do(req)
		if err != nil {
			d.add("fail", "Telegram bot", "Bot API недоступен: "+short(err.Error()))
			return
		}
		defer resp.Body.Close()
		var r struct {
			OK     bool `json:"ok"`
			Result struct {
				Username string `json:"username"`
			} `json:"result"`
			Description string `json:"description"`
		}
		_ = json.NewDecoder(io.LimitReader(resp.Body, 1<<20)).Decode(&r)
		if !r.OK {
			d.add("fail", "Telegram bot", "токен не принят: "+r.Description)
			return
		}
		d.add("ok", "Telegram bot", "@"+r.Result.Username)
	case "user":
		if cfg.TelegramAPIID == 0 || cfg.TelegramHash == "" {
			d.add("fail", "Telegram user", "нужны telegram.api_id и api_hash с https://my.telegram.org")
		}
		tr, err := telegram.NewTDJSONTransport()
		if err != nil {
			d.add("fail", "tdlib", short(err.Error()))
			return
		}
		v := tdlibVersion(tr, 10*time.Second)
		switch {
		case v == "":
			d.add("fail", "tdlib", "libtdjson загружена, но не ответила на getOption version")
		case telegram.SupportedTDLib(v):
			d.add("ok", "tdlib "+v, "поддерживается")
		default:
			d.add("fail", "tdlib "+v, "нужна 1.8.61 или новее: пересобери tdlib (см. README)")
		}
		tr.Send([]byte(`{"@type":"close"}`))
		if _, err := os.Stat(cfg.TDLibDir); err != nil {
			d.add("warn", "вход в Telegram", "базы tdlib ("+cfg.TDLibDir+") ещё нет: при первом запуске спросит код из Telegram в консоли")
		} else {
			d.add("ok", "вход в Telegram", "база tdlib есть ("+cfg.TDLibDir+")")
		}
	default:
		d.add("fail", "telegram.mode", fmt.Sprintf("%q: должно быть user или bot", cfg.Mode))
	}
}

func tdlibVersion(tr telegram.Transport, wait time.Duration) string {
	tr.Send([]byte(`{"@type":"getOption","name":"version","@extra":"doctor"}`))
	deadline := time.Now().Add(wait)
	for time.Now().Before(deadline) {
		raw := tr.Receive(200 * time.Millisecond)
		if raw == nil {
			continue
		}
		var m struct {
			Type  string `json:"@type"`
			Extra string `json:"@extra"`
			Name  string `json:"name"`
			Value json.RawMessage
		}
		if json.Unmarshal(raw, &m) != nil {
			continue
		}
		var val struct {
			Value string `json:"value"`
		}
		switch {
		case m.Type == "updateOption" && m.Name == "version":
			_ = json.Unmarshal(m.Value, &val)
			return val.Value
		case m.Extra == "doctor" && m.Type == "optionValueString":
			_ = json.Unmarshal(raw, &val)
			return val.Value
		}
	}
	return ""
}

func (d *doctor) checkPrograms(cfg *config.Config) {
	type prog struct {
		names []string
		need  bool
		why   string
	}
	progs := []prog{
		{[]string{"ffmpeg"}, cfg.STTEnabled || (cfg.TTSBackend != "" && cfg.TTSBackend != "none"), "голосовые и видео (apk add ffmpeg)"},
		{[]string{"pdftotext"}, false, "чтение PDF (apk add poppler-utils)"},
	}
	if cfg.DesktopEnabled {
		progs = append(progs, prog{[]string{"Xvfb"}, true, "виртуальный рабочий стол (apk add xvfb)"})
	}
	for _, p := range progs {
		found := ""
		for _, n := range p.names {
			if path, err := exec.LookPath(n); err == nil {
				found = path
				break
			}
		}
		switch {
		case found != "":
			d.add("ok", p.names[0], found)
		case p.need:
			d.add("fail", p.names[0], "не найден, а нужен: "+p.why)
		default:
			d.add("warn", p.names[0], "не найден: "+p.why)
		}
	}
	if cfg.BrowserEnabled {
		if p := browser.Find(cfg.BrowserPath); p != "" {
			d.add("ok", "браузер", p)
		} else {
			d.add("warn", "браузер", "chromium не найден: инструмент browser не заработает (apk add chromium font-noto)")
		}
	}
}

func (d *doctor) checkDisk(cfg *config.Config) {
	_ = os.MkdirAll(cfg.DataDir, 0o755)
	disk, err := maint.DiskOf(cfg.DataDir)
	if err != nil {
		return
	}
	level := "ok"
	if disk.Low(cfg.DiskWarnPercent) {
		level = "warn"
	}
	d.add(level, "диск", fmt.Sprintf("свободно %s из %s", maint.Human(disk.Free), maint.Human(disk.Total)))
}

func (d *doctor) checkExposure(cfg *config.Config, path string) {
	if admin.Enabled(cfg) {
		d.add("ok", "панель /admin", fmt.Sprintf("включена на порту %d (вход по misc.admin_token)", cfg.ProxyPort))
	} else {
		d.add("warn", "панель /admin", fmt.Sprintf("выключена: задай misc.admin_token (от %d символов)", admin.MinTokenLen))
	}
	if cfg.ProxyEnabled {
		if cfg.ProxyAPIKey == "" {
			d.add("ok", "прокси /v1", "без proxy.api_key: отвечает только этой машине")
		} else if len(cfg.ProxyAPIKey) < 16 {
			d.add("warn", "прокси /v1", "proxy.api_key короче 16 символов: его легко подобрать")
		} else {
			d.add("ok", "прокси /v1", "по ключу proxy.api_key")
		}
	}
	if cfg.LLMAPIKey != "" && strings.Contains(cfg.LLMBaseURL, "http://") && !strings.Contains(cfg.LLMBaseURL, "localhost") && !strings.Contains(cfg.LLMBaseURL, "127.0.0.1") {
		d.add("warn", "llm.base_url", "ключ уходит по незашифрованному http://")
	}
	if st, err := os.Stat(path); err == nil && st.Mode().Perm()&0o077 != 0 {
		d.add("warn", "права config.toml", fmt.Sprintf("%o: в нём ключи, лучше chmod 600 %s", st.Mode().Perm(), path))
	}
}
