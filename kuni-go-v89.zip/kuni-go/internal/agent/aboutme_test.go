package agent

import (
	"context"
	"strings"
	"testing"

	"kuni/internal/telegram"
)

func TestAboutMeHasAccountAndNoNames(t *testing.T) {
	fk := telegram.NewFake()
	fk.Media.Profile = telegram.Profile{FirstName: "Reina", Username: "ReinaVeil", Bio: "hi", PersonalChannel: "Мысли Марин"}
	a := &Agent{}
	a.TG = fk
	got := a.aboutMe(context.Background())
	for _, want := range []string{"<about_me>", "@ReinaVeil", "Мысли Марин", "Мой ноутбук"} {
		if !strings.Contains(got, want) {
			t.Errorf("missing %q in\n%s", want, got)
		}
	}
	if a.aboutMe(context.Background()) != got {
		t.Error("the card is cached")
	}
}
