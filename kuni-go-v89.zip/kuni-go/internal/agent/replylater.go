package agent

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"kuni/internal/llm"
	"kuni/internal/telegram"
	"kuni/internal/tools"
)

// "Busy, I'll answer later" has to be true: when she says it she also leaves herself a note, and when the time comes the
// note is put in front of her in her free time (autonomy), with the chat to go back to. Nobody is promised a reply by a schedule
// she does not keep.

type owedReply struct {
	Chat  int64     `json:"chat"`
	Name  string    `json:"name"`
	At    time.Time `json:"at"`
	Note  string    `json:"note"`
	Tried time.Time `json:"tried,omitempty"` // the last time she was woken for it
}

type replyLater struct {
	mu    sync.Mutex
	path  string
	items []owedReply
	grace map[int64]time.Time // chats she just went back to: her messages there are not initiative limited
}

const maxOwed = 30

func newReplyLater(path string) *replyLater {
	r := &replyLater{path: path}
	if path != "" {
		if b, err := os.ReadFile(path); err == nil {
			_ = json.Unmarshal(b, &r.items)
		}
	}
	return r
}

func (r *replyLater) saveLocked() {
	if r.path == "" {
		return
	}
	if b, err := json.Marshal(r.items); err == nil {
		_ = os.MkdirAll(filepath.Dir(r.path), 0o700)
		_ = os.WriteFile(r.path, b, 0o600)
	}
}

// add notes that she owes the chat an answer after the given minutes (one note per chat; a new one replaces the old).
func (r *replyLater) add(chat int64, name, note string, after time.Duration, now time.Time) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	kept := r.items[:0]
	for _, it := range r.items {
		if it.Chat != chat {
			kept = append(kept, it)
		}
	}
	r.items = kept
	if len(r.items) >= maxOwed {
		return fmt.Errorf("you already owe %d answers; answer some first", maxOwed)
	}
	r.items = append(r.items, owedReply{Chat: chat, Name: name, At: now.Add(after), Note: note})
	r.saveLocked()
	return nil
}

// due returns the notes whose time has come (they stay until she answers: done is called by the send in that chat).
func (r *replyLater) due(now time.Time) []owedReply {
	r.mu.Lock()
	defer r.mu.Unlock()
	var out []owedReply
	for _, it := range r.items {
		if !it.At.After(now) {
			out = append(out, it)
		}
	}
	return out
}

// done removes the note of a chat (she has answered it).
func (r *replyLater) done(chat int64) {
	r.mu.Lock()
	defer r.mu.Unlock()
	for _, it := range r.items {
		if it.Chat == chat {
			if r.grace == nil {
				r.grace = map[int64]time.Time{}
			}
			r.grace[chat] = time.Now().Add(30 * time.Minute)
		}
	}
	kept := r.items[:0]
	for _, it := range r.items {
		if it.Chat != chat {
			kept = append(kept, it)
		}
	}
	if len(kept) != len(r.items) {
		r.items = kept
		r.saveLocked()
	}
}

func (a *Agent) owed() *replyLater {
	a.owedOnce.Do(func() {
		p := ""
		if a.Cfg != nil && a.cfg().DataDir != "" {
			p = filepath.Join(a.cfg().DataDir, "reply_later.json")
		}
		a.owedStore = newReplyLater(p)
	})
	return a.owedStore
}

// replyLaterTool is "I'll answer later": a note to herself that comes back when the time is up.
func (a *Agent) replyLaterTool(chat telegram.Chat) tools.Tool {
	return tools.Tool{
		Name:        "reply_later",
		Description: "You are busy, tired or not in the mood to answer this chat properly right now. Say so in the chat in your own words («занята, отвечу позже»), and call this so that you really come back: the note returns to you at that very minute. Do not promise a time you will not keep.",
		Props: []tools.Prop{
			{Name: "minutes", Type: "integer", Desc: "after how many minutes to come back (1 minute to 7 days)."},
			{Name: "note", Type: "string", Desc: "what you owe this chat, a few words (what they asked, what you wanted to say)."},
		},
		Run: func(ctx context.Context, args tools.Args) (string, error) {
			m := args.Int("minutes")
			if m < 1 {
				m = 1
			}
			if m > 10080 {
				m = 10080
			}
			note := strings.TrimSpace(args.Str("note"))
			if note == "" {
				note = "answer properly"
			}
			if err := a.owed().add(chat.ID, chat.Title, note, time.Duration(m)*time.Minute, time.Now()); err != nil {
				return "", err
			}
			return fmt.Sprintf("noted: you will see this again in about %d min", m), nil
		},
	}
}

// owedBlock is what she owes, as it comes up in her free time.
func (a *Agent) owedBlock(now time.Time) string {
	due := a.owed().due(now)
	if len(due) == 0 {
		return ""
	}
	var b strings.Builder
	b.WriteString("<you_owe_answers>Ты обещала вернуться к этим разговорам, время пришло. Открой чат (#open_chat) и ответь по-человечески, можешь извиниться за задержку, если она была долгой:\n")
	for _, it := range due {
		fmt.Fprintf(&b, "- чат %d (%s): %s\n", it.Chat, it.Name, it.Note)
	}
	b.WriteString("</you_owe_answers>\n")
	return b.String()
}

// keeps tells whether her messages to this chat are keeping a promise (so the limits of free initiative do not apply).
func (r *replyLater) keeps(chat int64, now time.Time) bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	if t, ok := r.grace[chat]; ok && now.Before(t) {
		return true
	}
	for _, it := range r.items {
		if it.Chat == chat {
			return true
		}
	}
	return false
}

// wake returns the notes that are due and have not been tried for ten minutes, and marks them tried.
func (r *replyLater) wake(now time.Time) []owedReply {
	r.mu.Lock()
	defer r.mu.Unlock()
	var out []owedReply
	for i := range r.items {
		it := &r.items[i]
		if !it.At.After(now) && now.Sub(it.Tried) >= 10*time.Minute {
			it.Tried = now
			out = append(out, *it)
		}
	}
	if len(out) > 0 {
		r.saveLocked()
	}
	return out
}

// owedLoop wakes her at the minute a promise falls due, whatever the free-time pause is.
func (a *Agent) owedLoop(ctx context.Context) {
	t := time.NewTicker(15 * time.Second)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
		}
		if a.paused.Load() || a.Usage.Over(a.cfg().DailyTokenLimit) {
			continue
		}
		if due := a.owed().wake(time.Now()); len(due) > 0 {
			if err := a.ActOwed(ctx); err != nil {
				log.Printf("agent: owed replies: %v", err)
			}
		}
	}
}

// ActOwed is the round in which she goes back to what she promised: no night, sleep, daily cap or cooldown stands in the way
// of a promise she made herself.
func (a *Agent) ActOwed(ctx context.Context) error {
	now := time.Now()
	blk := a.owedBlock(now)
	if blk == "" {
		return nil
	}
	s := a.getSession(0)
	s.mu.Lock()
	defer s.mu.Unlock()
	a.ownSession(s)
	loc := a.cfg().Location()
	msg := fmt.Sprintf("It is %s.\n%s%s%s", now.In(loc).Format("Mon 2 Jan 15:04"), a.moodBlock(), a.cycleBlock(now), blk)
	s.msgs = append(s.msgs, llm.Message{Role: "user", Content: msg})
	return a.runTurn(ctx, s)
}
