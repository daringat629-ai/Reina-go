package agent

import (
	"context"
	"strings"
	"testing"

	"kuni/internal/llm"
	"kuni/internal/telegram"
)

func TestNewArrivalsHoldTheAnswerOnce(t *testing.T) {
	r := newRig(t, newFakeLLM(t, func(int64) llm.ToolCall { return sendCall(0) }))
	chat := telegram.Chat{ID: 777, Title: "Ann", Kind: telegram.ChatPrivate, IsMember: true}
	first := r.tg.Incoming(chat, 777, "Ann", "first")
	_ = r.tg.MarkRead(context.Background(), chat.ID)
	s := r.ag.getSession(chat.ID)
	s.readIDs = map[int64]bool{first.ID: true}
	tr := &turn{a: r.ag, s: s, private: true}
	if got := tr.newArrivals(context.Background()); got != "" {
		t.Fatalf("nothing new yet: %q", got)
	}
	r.tg.Incoming(chat, 777, "Ann", "second thing")
	r.tg.Incoming(chat, 777, "Ann", "third thing")
	got := tr.newArrivals(context.Background())
	if !strings.Contains(got, "2 more message") || !strings.Contains(got, "second thing") || !strings.Contains(got, "third thing") {
		t.Fatalf("the new messages must be shown: %q", got)
	}
	if again := tr.newArrivals(context.Background()); again != "" {
		t.Fatalf("each arrival is reported once, no loops: %q", again)
	}
	if (&turn{a: r.ag, s: s, private: false}).newArrivals(context.Background()) != "" {
		t.Fatal("groups are batched elsewhere")
	}
}
