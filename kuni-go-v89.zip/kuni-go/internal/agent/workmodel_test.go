package agent

import (
	"testing"

	"kuni/internal/llm"
)

func TestWorkModelNeverSpeaks(t *testing.T) {
	if !speaks(llm.Message{Content: "привет"}) {
		t.Fatal("plain text is a voice")
	}
	if !speaks(llm.Message{ToolCalls: []llm.ToolCall{call("web_search"), call("send_telegram_message")}}) {
		t.Fatal("a send tool is a voice")
	}
	if speaks(llm.Message{ToolCalls: []llm.ToolCall{call("web_search"), call("read_link")}}) {
		t.Fatal("pure job calls are not")
	}
	if deepOr("", "fast") != "fast" || deepOr("big", "fast") != "big" {
		t.Fatal("deepOr")
	}
}
