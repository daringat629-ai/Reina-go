package llmui

import (
	"context"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"kuni/internal/llm"
	"kuni/internal/telegram"
)

// a tiny valid PNG, enough for the image check
var tinyPNG = []byte("\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x06\x00\x00\x00\x1f\x15\xc4\x89\x00\x00\x00\rIDATx\x9cc\xf8\xff\xff?\x00\x05\xfe\x02\xfe\xa7\x9a\xb2\xe1\x00\x00\x00\x00IEND\xaeB`\x82")

func fakeVision(t *testing.T, answer string) (*httptest.Server, *atomic.Int32) {
	var calls atomic.Int32
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		calls.Add(1)
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write([]byte(`{"choices":[{"message":{"role":"assistant","content":"` + answer + `"},"finish_reason":"stop"}]}`))
	}))
	t.Cleanup(srv.Close)
	return srv, &calls
}

func TestPremiumEmojiInTextAreDescribedOnce(t *testing.T) {
	e, tg := newEnv(t)
	srv, calls := fakeVision(t, "плачущий котик")
	e.LLM = llm.New(srv.URL+"/", "", "k", "m", "", 5*time.Second)
	tg.Media.Custom = map[int64]telegram.CustomEmoji{777: {ID: 777, Emoji: "😿", ThumbID: "t777"}}
	tg.Files["t777"] = tinyPNG
	m := telegram.Message{ID: 1, ChatID: 1, Text: "мне так грустно 😿", Entities: []telegram.Entity{{Type: "emoji", Offset: 15, Length: 2, CustomID: 777}}}

	got := e.Body(context.Background(), m)
	if !strings.Contains(got, "мне так грустно") || !strings.Contains(got, "[premium emoji in the text: 😿 = плачущий котик]") {
		t.Fatalf("got %q", got)
	}
	if again := e.Body(context.Background(), m); again != got || calls.Load() != 1 {
		t.Fatalf("the description must be remembered by id: %d model calls, %q", calls.Load(), again)
	}
	if plain := e.Body(context.Background(), telegram.Message{Text: "обычный текст 😿"}); strings.Contains(plain, "premium") {
		t.Fatalf("no custom emoji, no note: %q", plain)
	}
}

func TestAnimatedStickerIsDescribedByItsStill(t *testing.T) {
	e, tg := newEnv(t)
	srv, _ := fakeVision(t, "котик машет лапкой")
	e.LLM = llm.New(srv.URL+"/", "", "k", "m", "", 5*time.Second)
	tg.Files["anim"] = []byte("\x1f\x8b\x08tgs-not-an-image") // an animated sticker is not a picture the model can read
	tg.Files["still"] = tinyPNG
	m := telegram.Message{ID: 2, ChatID: 1, Media: telegram.MediaSticker, Text: "🐱", FileID: "anim", ThumbID: "still"}
	if got := e.Body(context.Background(), m); !strings.Contains(got, "котик машет лапкой") {
		t.Fatalf("got %q", got)
	}
	tg.Files["anim2"] = []byte("\x1f\x8b\x08another-tgs")
	noThumb := telegram.Message{ID: 3, ChatID: 1, Media: telegram.MediaSticker, Text: "🐱", FileID: "anim2"}
	if got := e.Body(context.Background(), noThumb); !strings.Contains(got, "not supported") {
		t.Fatalf("without a still it stays unsupported: %q", got)
	}
}
