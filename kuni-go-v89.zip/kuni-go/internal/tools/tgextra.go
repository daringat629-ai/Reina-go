package tools

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"kuni/internal/telegram"
)

// mediaKind picks how a file is shown in Telegram by its extension.
func mediaKind(path string, size int64) string {
	switch strings.ToLower(filepath.Ext(path)) {
	case ".mp4", ".mov", ".mkv", ".webm", ".m4v":
		return telegram.KindVideo
	case ".gif":
		return telegram.KindAnimation
	case ".mp3", ".m4a", ".flac", ".ogg", ".opus", ".wav", ".aac":
		return telegram.KindAudio
	case ".jpg", ".jpeg", ".png":
		if size <= 10<<20 { // bigger pictures are refused as photos
			return telegram.KindPhoto
		}
	}
	return telegram.KindDocument
}

// zoneOf is the owner's clock: autonomy.timezone, else the machine's.
func zoneOf(d Deps) *time.Location {
	if n := d.Cfg().AutonomyTimezone; n != "" {
		if loc, err := time.LoadLocation(n); err == nil {
			return loc
		}
	}
	return time.Local
}

var whenLayouts = []string{"2006-01-02 15:04", "2006-01-02T15:04", "02.01.2006 15:04", "02.01 15:04", "15:04"}

// parseWhen reads "in 2h" style durations or a wall-clock time in the owner's zone ("15:30" = the next 15:30).
func parseWhen(in, at string, now time.Time, loc *time.Location) (time.Time, error) {
	if s := strings.TrimSpace(in); s != "" {
		dur, err := parseEvery(s)
		if err != nil {
			return time.Time{}, err
		}
		return now.Add(dur), nil
	}
	s := strings.TrimSpace(at)
	if s == "" {
		return time.Time{}, fmt.Errorf("give `in` (30m, 2h, 1d) or `at` (2026-10-22 10:00 or 10:00)")
	}
	n := now.In(loc)
	for _, l := range whenLayouts {
		t, err := time.ParseInLocation(l, s, loc)
		if err != nil {
			continue
		}
		switch l {
		case "15:04":
			t = time.Date(n.Year(), n.Month(), n.Day(), t.Hour(), t.Minute(), 0, 0, loc)
			if !t.After(now) {
				t = t.AddDate(0, 0, 1)
			}
		case "02.01 15:04":
			t = time.Date(n.Year(), t.Month(), t.Day(), t.Hour(), t.Minute(), 0, 0, loc)
			if !t.After(now) {
				t = t.AddDate(1, 0, 0)
			}
		}
		return t, nil
	}
	return time.Time{}, fmt.Errorf("cannot read the time %q", s)
}

func sendLaterTool(d Deps) Tool {
	return Tool{
		Name:        "send_later",
		Description: "Write a message into any chat at a chosen time (owner only). Telegram itself holds it and sends it, so it goes out even if you are off. Give `in` (30m, 2h, 1d) or `at` (2026-10-22 10:00, or 10:00 = the next one, owner's clock). markdown=true makes *bold* _italic_ `code` [text](url) work; silent=true sends without a notification. For things you must do yourself later use schedule instead.",
		Props: []Prop{
			{Name: "chat", Type: "string", Desc: "Chat id, @username or part of the chat name."},
			{Name: "text", Type: "string", Desc: "The message."},
			{Name: "in", Type: "string", Nullable: true, Desc: "Delay like 30m, 2h, 1d."},
			{Name: "at", Type: "string", Nullable: true, Desc: "Moment in the owner's clock."},
			{Name: "markdown", Type: "boolean", Nullable: true, Desc: "Format the text."},
			{Name: "silent", Type: "boolean", Nullable: true, Desc: "No notification."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			r, ok := d.TG.(telegram.Rich)
			if !ok {
				return "", fmt.Errorf("scheduled messages need the user-account client")
			}
			text := strings.TrimSpace(a.Str("text"))
			if text == "" {
				return "", fmt.Errorf("empty text")
			}
			loc := zoneOf(d)
			now := time.Now()
			when, err := parseWhen(a.Str("in"), a.Str("at"), now, loc)
			if err != nil {
				return "", err
			}
			if when.Before(now.Add(30*time.Second)) || when.After(now.AddDate(0, 0, 360)) {
				return "", fmt.Errorf("the time must be between 30 seconds and a year ahead")
			}
			id, err := resolveChat(ctx, d, a.Str("chat"))
			if err != nil {
				return "", err
			}
			if _, err := r.SendWith(telegram.NoThread(ctx), id, text, telegram.SendOptions{Markdown: a.Bool("markdown"), Silent: a.Bool("silent"), At: when}); err != nil {
				return "", err
			}
			return fmt.Sprintf("scheduled for chat %d at %s", id, when.In(loc).Format("02.01.2006 15:04 MST")), nil
		},
	}
}

func digestTool(d Deps) Tool {
	return Tool{
		Name:        "digest",
		Description: "A summary of what happened in all your chats lately (owner only): which chats were active in the last `hours` (default 12), unread counts, mentions of you and the last messages of the liveliest ones. Use it for 'что я пропустил', 'что в чатах за ночь'; read the text and retell the important part in your own words.",
		Props: []Prop{
			{Name: "hours", Type: "integer", Nullable: true, Desc: "How far back, default 12, max 168."},
			{Name: "max_chats", Type: "integer", Nullable: true, Desc: "How many chats to open, default 6, max 12."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			hours := int(a.Int("hours"))
			if hours <= 0 {
				hours = 12
			}
			if hours > 168 {
				hours = 168
			}
			maxChats := int(a.Int("max_chats"))
			if maxChats <= 0 {
				maxChats = 6
			}
			if maxChats > 12 {
				maxChats = 12
			}
			chats, err := d.TG.Chats(ctx, 100)
			if err != nil {
				return "", err
			}
			now := time.Now()
			cut := now.Add(-time.Duration(hours) * time.Hour)
			var active []telegram.Chat
			for _, c := range chats {
				if c.LastDate.After(cut) && !c.Archived && c.ID != d.Cfg().PapikChatID {
					active = append(active, c)
				}
			}
			if len(active) == 0 {
				return fmt.Sprintf("Nothing happened in your chats in the last %d h.", hours), nil
			}
			// mentions first, then the most unread
			sort.SliceStable(active, func(i, j int) bool {
				if active[i].UnreadMentions != active[j].UnreadMentions {
					return active[i].UnreadMentions > active[j].UnreadMentions
				}
				return active[i].Unread > active[j].Unread
			})
			var b strings.Builder
			fmt.Fprintf(&b, "Active chats in the last %d h: %d\n", hours, len(active))
			for _, c := range active {
				muted := ""
				if c.Muted {
					muted = " (muted)"
				}
				fmt.Fprintf(&b, "- %q%s: unread %d, mentions of you %d, last %s\n", c.Title, muted, c.Unread, c.UnreadMentions, now.Sub(c.LastDate).Round(time.Minute))
			}
			opened := 0
			for _, c := range active {
				if opened >= maxChats || b.Len() > 9000 {
					break
				}
				if c.Muted && c.UnreadMentions == 0 {
					continue
				}
				msgs, err := d.TG.History(ctx, c.ID, 0, 8, 0)
				if err != nil || len(msgs) == 0 {
					continue
				}
				opened++
				fmt.Fprintf(&b, "\n=== %s ===\n%s", c.Title, Truncate(d.UI.FormatMessages(ctx, msgs, now), 1400))
			}
			return Truncate(b.String(), 12000), nil
		},
	}
}

func profileTool(d Deps) Tool {
	return Tool{
		Name:        "my_profile",
		Description: "Your own Telegram profile (owner only, only when he asks): show it, or change first/last name (set_name), bio (set_bio) or avatar (set_photo from an image file). The change is visible to everyone, so do it only on his word.",
		Props: []Prop{
			{Name: "action", Type: "string", Desc: "show, set_name, set_bio or set_photo."},
			{Name: "first", Type: "string", Nullable: true, Desc: "set_name: first name."},
			{Name: "last", Type: "string", Nullable: true, Desc: "set_name: last name (may be empty)."},
			{Name: "text", Type: "string", Nullable: true, Desc: "set_bio: the new bio (up to 70 characters)."},
			{Name: "path", Type: "string", Nullable: true, Desc: "set_photo: image file (jpg or png)."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			pe, ok := d.TG.(telegram.ProfileEditor)
			if !ok {
				return "", fmt.Errorf("the profile can only be changed through the user-account client")
			}
			switch strings.ToLower(strings.TrimSpace(a.Str("action"))) {
			case "show", "":
				p, err := pe.MyProfile(ctx)
				if err != nil {
					return "", err
				}
				return fmt.Sprintf("name: %s %s\nusername: @%s\nbio: %s\npersonal channel: %s", p.FirstName, p.LastName, p.Username, p.Bio, p.PersonalChannel), nil
			case "set_name":
				if err := pe.SetName(ctx, strings.TrimSpace(a.Str("first")), strings.TrimSpace(a.Str("last"))); err != nil {
					return "", err
				}
				d.journal("profile: name "+a.Str("first")+" "+a.Str("last"), 0)
				return "name changed", nil
			case "set_bio":
				bio := strings.TrimSpace(a.Str("text"))
				if len([]rune(bio)) > 70 {
					return "", fmt.Errorf("a bio is at most 70 characters (you wrote %d)", len([]rune(bio)))
				}
				if err := pe.SetBio(ctx, bio); err != nil {
					return "", err
				}
				d.journal("profile: bio", 0)
				return "bio changed", nil
			case "set_photo":
				p := d.resolvePath(a.Str("path"))
				st, err := os.Stat(p)
				if err != nil {
					return "", err
				}
				if st.IsDir() || st.Size() > 10<<20 {
					return "", fmt.Errorf("need an image file up to 10 MB")
				}
				data, err := os.ReadFile(p)
				if err != nil {
					return "", err
				}
				if err := pe.SetProfilePhoto(ctx, data); err != nil {
					return "", err
				}
				d.journal("profile: photo "+p, 0)
				return "avatar changed", nil
			}
			return "", fmt.Errorf("action must be show, set_name, set_bio or set_photo")
		},
	}
}

// myProfileViewTool lets her look at her own Telegram account in any chat (read only). The profile shows things that
// are not in her chat list, for example a personal channel, so "I checked my chats and there is none" proves nothing.
func myProfileViewTool(d Deps) Tool {
	return Tool{
		Name:        "my_profile_view",
		Description: "Look at your own Telegram profile as other people see it: name, username, bio and the personal channel shown on it. Read only. A personal channel is NOT in your chat list, so check here when someone mentions something on your profile.",
		Run: func(ctx context.Context, a Args) (string, error) {
			pe, ok := d.TG.(telegram.ProfileEditor)
			if !ok {
				return "", fmt.Errorf("your profile cannot be read through this client")
			}
			p, err := pe.MyProfile(ctx)
			if err != nil {
				return "", err
			}
			ch := p.PersonalChannel
			if ch == "" {
				ch = "none shown on the profile"
			}
			return fmt.Sprintf("name: %s %s\nusername: @%s\nbio: %s\npersonal channel: %s", p.FirstName, p.LastName, p.Username, p.Bio, ch), nil
		},
	}
}
