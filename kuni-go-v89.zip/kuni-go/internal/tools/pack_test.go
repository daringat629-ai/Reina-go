package tools

import (
	"reflect"
	"strings"
	"testing"
)

func TestPackMessages(t *testing.T) {
	in := []string{"ага", "поняла", "а ты как?", "я вот только проснулась", "кофе пью"}
	cases := []struct {
		name          string
		pack, bubbles int
		want          []string
	}{
		{"off", 0, 0, in},
		{"glue short lines", 30, 0, []string{"ага поняла а ты как?", "я вот только проснулась", "кофе пью"}},
		{"cap on bubbles", 30, 2, []string{"ага поняла а ты как?", "я вот только проснулась кофе пью"}},
		{"cap alone", 0, 1, []string{"ага поняла а ты как? я вот только проснулась кофе пью"}},
	}
	for _, c := range cases {
		got := PackMessages(in, c.pack, c.bubbles)
		if !reflect.DeepEqual(got, c.want) {
			t.Errorf("%s: got %q want %q", c.name, got, c.want)
		}
		if strings.Join(got, " ") != strings.Join(in, " ") {
			t.Errorf("%s: text changed: %q", c.name, got)
		}
	}
	if got := PackMessages([]string{"один"}, 100, 3); len(got) != 1 {
		t.Errorf("single: %q", got)
	}
}

func TestTypoFix(t *testing.T) {
	if got := TypoFix("ну это реально смешно", "ну эот реально смешно"); got != "*это" {
		t.Errorf("got %q", got)
	}
	if got := TypoFix("привет, как дела", "привет, как дела"); got != "" {
		t.Errorf("no typo: %q", got)
	}
	if got := TypoFix("a b", "a"); got != "" {
		t.Errorf("different lengths: %q", got)
	}
}

func TestHumanSplitCutsWhereAPersonWould(t *testing.T) {
	always := func() float64 { return 0 }
	got := HumanSplit([]string{"ха, ну ты даёшь. я вообще не ожидала такого от тебя сегодня. ты серьёзно?"}, always)
	if len(got) != 3 || got[0] != "ха, ну ты даёшь." || got[2] != "ты серьёзно?" {
		t.Fatalf("got %q", got)
	}
	never := func() float64 { return 0.99 }
	one := []string{"ха, ну ты даёшь. я вообще не ожидала такого от тебя сегодня. ты серьёзно?"}
	if g := HumanSplit(one, never); len(g) != 1 {
		t.Fatalf("must keep one: %q", g)
	}
	if g := HumanSplit([]string{"привет, как дела"}, always); len(g) != 1 {
		t.Fatal("a short single sentence is never cut")
	}
	if strings.Join(got, " ") != one[0] {
		t.Fatal("no text may be lost")
	}
}
