package tools

import (
	"context"
	"reflect"
	"strings"
	"testing"
	"time"

	"kuni/internal/config"
	"kuni/internal/metrics"
	"kuni/internal/prompts"
	"kuni/internal/telegram"
)

func TestSendSplitsLines(t *testing.T) {
	ps, err := prompts.NewStore(t.TempDir(), prompts.Vars{})
	if err != nil {
		t.Fatal(err)
	}
	tg := telegram.NewFake()
	d := Deps{RT: NewRuntime(nil), TG: tg, Prompts: ps, Metrics: metrics.New(), Cfg: func() *config.Config { return &config.Config{} }}
	chat := telegram.Chat{ID: 7, Title: "A", Kind: telegram.ChatPrivate, IsMember: true}
	tool := sendTool(d, chat)

	if _, err := tool.Run(context.Background(), Args{"text": "hi\n\ni'm here~\nwhat's up?"}); err != nil {
		t.Fatal(err)
	}
	if got, want := tg.SentTexts(), []string{"hi", "i'm here~", "what's up?"}; !reflect.DeepEqual(got, want) {
		t.Fatalf("got %q want %q", got, want)
	}
	// no cap on the number of messages
	tg2 := telegram.NewFake()
	d.TG = tg2
	if _, err := sendTool(d, chat).Run(context.Background(), Args{"text": "1\n2\n3\n4\n5\n6\n7"}); err != nil {
		t.Fatal(err)
	}
	if got := tg2.SentTexts(); len(got) != 7 || got[6] != "7" {
		t.Fatalf("got %q", got)
	}
	// code is never split
	tg3 := telegram.NewFake()
	d.TG = tg3
	code := "```\na\nb\n```"
	if _, err := sendTool(d, chat).Run(context.Background(), Args{"text": code}); err != nil {
		t.Fatal(err)
	}
	if got := tg3.SentTexts(); len(got) != 1 || got[0] != code {
		t.Fatalf("got %q", got)
	}
}

func TestSplitMessage(t *testing.T) {
	long := "Это довольно длинное сообщение, которое точно не влезет в шестьдесят символов. А вот второе предложение!"
	got := SplitMessage(long, 60)
	if len(got) < 2 {
		t.Fatalf("not split: %q", got)
	}
	for _, g := range got {
		if n := len([]rune(g)); n > 60 || n == 0 {
			t.Fatalf("chunk of %d runes: %q", n, g)
		}
	}
	if strings.Join(got, " ") != long {
		t.Fatalf("text changed: %q", got)
	}
	if got[0] != "Это довольно длинное сообщение," {
		t.Fatalf("expected a cut after the comma, got %q", got[0])
	}
	// a sentence end is preferred
	if g := SplitMessage("Привет! Как дела у тебя сегодня вообще, расскажи мне всё", 20); g[0] != "Привет!" && len([]rune(g[0])) > 20 {
		t.Fatalf("%q", g)
	}
	// a single huge word is hard-cut, nothing is lost
	w := strings.Repeat("a", 130)
	if g := SplitMessage(w, 60); len(g) != 3 || strings.Join(g, "") != w {
		t.Fatalf("%q", g)
	}
	if g := SplitMessage("a\n\n b ", 0); len(g) != 2 {
		t.Fatalf("%q", g)
	}
}

func TestSendLongTextIsChunkedAndTypes(t *testing.T) {
	ps, _ := prompts.NewStore(t.TempDir(), prompts.Vars{})
	tg := telegram.NewFake()
	cfg := &config.Config{MaxMessageChars: 60, TypingMinMs: 30, TypingMaxMs: 60}
	d := Deps{RT: NewRuntime(nil), TG: tg, Prompts: ps, Metrics: metrics.New(), Cfg: func() *config.Config { return cfg }}
	chat := telegram.Chat{ID: 7, Title: "A", Kind: telegram.ChatPrivate, IsMember: true}
	start := time.Now()
	long := strings.Repeat("слово ", 30) // 180 chars
	if _, err := sendTool(d, chat).Run(context.Background(), Args{"text": long}); err != nil {
		t.Fatal(err)
	}
	got := tg.SentTexts()
	if len(got) < 3 {
		t.Fatalf("expected >=3 messages, got %q", got)
	}
	if el := time.Since(start); el < time.Duration(len(got))*30*time.Millisecond {
		t.Fatalf("typing pause skipped: %v for %d messages", el, len(got))
	}
	if tg.Typings < len(got) {
		t.Fatalf("typing status sent %d times for %d messages", tg.Typings, len(got))
	}
	// repeating the same text is still refused as a whole
	if out, err := sendTool(d, chat).Run(context.Background(), Args{"text": long}); err == nil {
		t.Fatalf("repeat must be refused, got %q", out)
	}
	// a cancelled context stops the typing pause
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	cfg.TypingMinMs, cfg.TypingMaxMs = 5000, 5000
	if _, err := sendTool(d, chat).Run(ctx, Args{"text": "другой текст"}); err == nil {
		t.Fatal("cancelled context must stop sending")
	}
}

func TestTypingDurationIsProportionalToLength(t *testing.T) {
	half := func() float64 { return 0.5 }
	short := typingDuration(3000, 4000, 55, "ага", half)
	long := typingDuration(3000, 4000, 55, strings.Repeat("я", 60), half)
	if short >= long || short < 900*time.Millisecond || long > 4*time.Second {
		t.Fatalf("short=%v long=%v", short, long)
	}
	if d := typingDuration(3000, 4000, 55, strings.Repeat("я", 500), half); d != 4*time.Second {
		t.Fatalf("cap = %v", d)
	}
	// 0 per char = the old uniform 3-4 s
	if d := typingDuration(3000, 4000, 0, "ага", half); d < 3*time.Second || d > 4*time.Second {
		t.Fatalf("legacy = %v", d)
	}
	if typingDuration(0, 0, 55, "x", half) != 0 {
		t.Fatal("zero max disables typing")
	}
}

func TestSendMixedProseAndCode(t *testing.T) {
	ps, _ := prompts.NewStore(t.TempDir(), prompts.Vars{})
	tg := telegram.NewFake()
	d := Deps{RT: NewRuntime(nil), TG: tg, Prompts: ps, Metrics: metrics.New(), Cfg: func() *config.Config { return &config.Config{} }}
	chat := telegram.Chat{ID: 7, Title: "A", Kind: telegram.ChatPrivate, IsMember: true}
	text := "держи~\n```python\nprint(1)\n```\nзапусти так: ```sh\npython a.py\n```\nвсё"
	if _, err := sendTool(d, chat).Run(context.Background(), Args{"text": text}); err != nil {
		t.Fatal(err)
	}
	want := []string{"держи~", "```python\nprint(1)\n```", "запусти так:", "```sh\npython a.py\n```", "всё"}
	if got := tg.SentTexts(); !reflect.DeepEqual(got, want) {
		t.Fatalf("got %q\nwant %q", got, want)
	}
}

func TestLongCodeGoesAsAFileAndAnUnclosedFenceDoesNotLoop(t *testing.T) {
	ps, _ := prompts.NewStore(t.TempDir(), prompts.Vars{})
	tg := telegram.NewFake()
	d := Deps{RT: NewRuntime(nil), TG: tg, Prompts: ps, Metrics: metrics.New(), Cfg: func() *config.Config { return &config.Config{} }}
	chat := telegram.Chat{ID: 7, Title: "A", Kind: telegram.ChatPrivate, IsMember: true}
	big := strings.Repeat("x = 1\n", 800) // ~4800 chars
	out, err := sendTool(d, chat).Run(context.Background(), Args{"text": "вот:\n```python\n" + big + "```"})
	if err != nil || !strings.Contains(out, "code.py") {
		t.Fatal(out, err)
	}
	docs := tg.Docs()
	if len(docs) != 1 || docs[0].Name != "code.py" || !strings.HasPrefix(string(docs[0].Data), "x = 1\n") {
		t.Fatalf("%+v", docs)
	}
	if got := tg.SentTexts(); len(got) < 1 || got[0] != "вот:" {
		t.Fatalf("%q", got)
	}
	// ``` never closed: sent as it is, once
	tg2 := telegram.NewFake()
	d.TG = tg2
	if _, err := sendTool(d, chat).Run(context.Background(), Args{"text": "смотри ```never closed"}); err != nil {
		t.Fatal(err)
	}
	if got := tg2.SentTexts(); len(got) != 1 {
		t.Fatalf("%q", got)
	}
	if codeFileName("asm") != "code.asm" || codeFileName("") != "code.txt" || codeFileName("Dockerfile") != "Dockerfile" {
		t.Fatal("file names")
	}
}

func TestGroupQuotesOnlyOneMessagePerTurn(t *testing.T) {
	ps, err := prompts.NewStore(t.TempDir(), prompts.Vars{})
	if err != nil {
		t.Fatal(err)
	}
	tg := telegram.NewFake()
	d := Deps{RT: NewRuntime(nil), TG: tg, Prompts: ps, Metrics: metrics.New(), Cfg: func() *config.Config { return &config.Config{} }}
	chat := telegram.Chat{ID: -9, Title: "G", Kind: telegram.ChatGroup, IsMember: true}
	for _, id := range []int64{11, 12, 13} {
		tg.S.Put(telegram.Message{ID: id, ChatID: chat.ID, SenderID: 5, SenderName: "A", Text: "q", Date: time.Now()}, nil)
	}
	tool := sendToolRaw(d, chat)
	for i, id := range []int64{11, 12, 13} {
		if _, err := tool.Run(context.Background(), Args{"text": "answer " + string(rune('a'+i)), "reply_to_message_id": float64(id), "_norepeat": true}); err != nil {
			t.Fatal(err)
		}
	}
	var replies int
	for _, m := range tg.Sent {
		if m.ReplyTo != 0 {
			replies++
		}
	}
	if replies != 1 || len(tg.Sent) != 3 {
		t.Fatalf("quoted %d of %d answers, want 1 of 3", replies, len(tg.Sent))
	}
}
