package tools

import (
	"context"
	"fmt"
	"os"
	"runtime"
	"strconv"
	"strings"
	"time"

	"kuni/internal/telegram"
)

// The tools below let her look at herself and at the machine she lives on from any chat, read only. A person knows
// her own account, her phone and her day without asking anyone; so does she. What stays closed is what would hurt the
// owner if a stranger asked for it: keys and tokens (settings hides them), other people's private chats and payments.

// MachineLine is one short line about the machine she lives on: memory, disk, load, uptime.
func MachineLine() string {
	var parts []string
	if mem := readKV("/proc/meminfo"); len(mem) > 0 {
		parts = append(parts, fmt.Sprintf("память: свободно %s из %s", humanSize(mem["MemAvailable"]), humanSize(mem["MemTotal"])))
	}
	if total, free, ok := diskFree("/"); ok && total > 0 {
		parts = append(parts, fmt.Sprintf("диск: свободно %s из %s", humanSize(free), humanSize(total)))
	}
	if raw, err := os.ReadFile("/proc/loadavg"); err == nil {
		if f := strings.Fields(string(raw)); len(f) >= 1 {
			parts = append(parts, fmt.Sprintf("нагрузка %s на %d ядер", f[0], runtime.NumCPU()))
		}
	}
	if raw, err := os.ReadFile("/proc/uptime"); err == nil {
		if f := strings.Fields(string(raw)); len(f) > 0 {
			if sec, err := strconv.ParseFloat(f[0], 64); err == nil {
				parts = append(parts, "включён уже "+(time.Duration(sec)*time.Second).Round(time.Minute).String())
			}
		}
	}
	return strings.Join(parts, "; ")
}

// ChatCounts says how many chats of each kind she is in. No names: those belong to other people.
func ChatCounts(chats []telegram.Chat) string {
	var priv, group, channel, unread int
	for _, c := range chats {
		switch c.Kind {
		case telegram.ChatPrivate:
			priv++
		case telegram.ChatChannel:
			channel++
		default:
			group++
		}
		unread += c.Unread
	}
	return fmt.Sprintf("личных чатов %d, групп %d, каналов %d, непрочитанных %d", priv, group, channel, unread)
}

// myChatsTool: the owner's chat gets the full list, every other chat only the counts.
func myChatsTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name:        "my_chats",
		Description: "Your own Telegram chats: how many private chats, groups and channels you are in and how many messages wait unread. In the owner's chat also the full list. Read only. A personal channel shown on your profile is not in this list (see my_profile_view).",
		Run: func(ctx context.Context, a Args) (string, error) {
			if IsOwnerChat(d, chat.ID) {
				return listAllChatsTool(d).Run(ctx, a)
			}
			chats, err := d.TG.Chats(ctx, 200)
			if err != nil {
				return "", err
			}
			return ChatCounts(chats), nil
		},
	}
}

// myLaptopTool is the machine she lives on, as she would feel it: memory, disk, load, uptime.
func myLaptopTool(d Deps) Tool {
	return Tool{
		Name:        "my_laptop",
		Description: "How the laptop you live on is doing right now: free memory, disk, load, uptime. Read only. It is your home: if it is slow or full, you may notice and say so like a person would.",
		Run: func(ctx context.Context, a Args) (string, error) {
			if s := MachineLine(); s != "" {
				return s, nil
			}
			return sysinfoTool(d).Run(ctx, Args{})
		},
	}
}

// mySettingsViewTool reads her own settings (never changes them). Keys, tokens and passwords are hidden by settings itself.
func mySettingsViewTool(d Deps) Tool {
	base := settingsTool(d)
	return Tool{
		Name:        "my_settings_view",
		Description: "Look at your own settings (models, limits, how fast you type, what is on). Read only: search by words or get one key like llm.fast_rounds. Secrets are hidden. Changing settings is for the owner.",
		Props:       []Prop{{Name: "action", Type: "string", Desc: "search or get."}, {Name: "key", Type: "string", Nullable: true, Desc: "get: section.name, for example llm.fast_rounds."}, {Name: "text", Type: "string", Nullable: true, Desc: "search: words to look for."}},
		Run: func(ctx context.Context, a Args) (string, error) {
			act := strings.ToLower(strings.TrimSpace(a.Str("action")))
			if act != "search" && act != "get" {
				return "", fmt.Errorf("read only: use action search (with text) or get (with key)")
			}
			return base.Run(ctx, a)
		},
	}
}
