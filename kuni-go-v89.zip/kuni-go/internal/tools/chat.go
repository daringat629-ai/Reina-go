package tools

import (
	"context"
	"errors"
	"fmt"
	"math/rand"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
	"unicode/utf8"

	"kuni/internal/llmui"
	"kuni/internal/prompts"
	"kuni/internal/store"
	"kuni/internal/telegram"
)

// allowedReactions is the Telegram free-reaction list quoted in the C++ description.
const allowedReactions = "👍 👎 ❤ 🔥 🥰 👏 😁 🤔 🤯 😱 🤬 😢 🎉 🤩 🤮 💩 🙏 👌 🕊 🤡 🥱 🥴 😍 🐳 🌚 🌭 💯 🤣 ⚡ 🍌 🏆 💔 🤨 😐 🍓 🍾 💋 😈 😴 😭 🤓 👻 👀 🎃 😇 😨 🤝 🤗 🎅 💅 🤪 🗿 🆒 💘 🦄 😘 💊 😎 👾 🤷 😡"

func stripVS16(s string) string { return strings.ReplaceAll(s, "️", "") }

func isAllowedReaction(e string) bool {
	e = stripVS16(strings.TrimSpace(e))
	if e == "" {
		return false
	}
	for _, a := range strings.Fields(allowedReactions) {
		if a == e {
			return true
		}
	}
	return false
}

// ChatTools builds the tool set for an opened chat, mirroring the capability
// matrix in main.cpp: channels get react+forward only; non-members get
// react (+join); regular chats get the full set; admins get moderation tools.
func ChatTools(d Deps, chat telegram.Chat) *Registry {
	cfg := d.Cfg()
	r := NewRegistry()

	if !chat.IsMember && chat.Kind != ChatPrivateKind {
		r.Add(reactTool(d, chat))
		if cfg.CanJoinChats {
			r.Add(joinTool(d))
		}
		return r
	}
	if chat.Kind == telegram.ChatChannel {
		r.Add(reactTool(d, chat), forwardTool(d, chat))
		return r
	}

	r.Add(
		sendTool(d, chat),
		getChatPhotoTool(d, chat),
		reactTool(d, chat),
		removeMessageTool(d, chat),
		editTool(d, chat),
		forwardTool(d, chat),
		viewAroundTool(d, chat),
		userInfoTool(d),
		myProfileViewTool(d),
		myChatsTool(d, chat),
		myLaptopTool(d),
		mySettingsViewTool(d),
		readDocumentTool(d, chat),
	)
	if cfg.ReadLinks {
		r.Add(readLinkTool(d))
	}
	r.Add(createPollTool(d, chat), votePollTool(d, chat))
	r.Add(qrTool(d, chat), inviteTool(d, chat))
	r.Add(UtilTools(d)...)
	if d.People != nil {
		r.Add(rememberPersonTool(d, chat), forgetPersonTool(d, chat))
	}
	if d.Reminders != nil {
		r.Add(remindTool(d, chat), remindersTool(d, chat))
	}
	if d.Promises != nil {
		r.Add(myPromiseAddTool(d), myPromiseDoneTool(d)) // her own word is hers in every chat
	}
	if d.Letters != nil && (IsOwnerChat(d, chat.ID) || chat.ID == 0) { // her letters are for her free time and her talk with him
		r.Add(letterWriteTool(d), letterReplyTool(d))
	}
	if d.Keepsakes != nil && (IsOwnerChat(d, chat.ID) || chat.ID == 0) {
		r.Add(keepsakeAddTool(d), keepsakeReleaseTool(d))
	}
	if d.Fear != nil && (IsOwnerChat(d, chat.ID) || chat.ID == 0) {
		r.Add(fearNameTool(d), fearEaseTool(d))
	}
	if d.Promises != nil && IsOwnerChat(d, chat.ID) {
		r.Add(promiseAddTool(d), promiseDoneTool(d), promisesTool(d))
	}
	if chat.Kind == telegram.ChatPrivate || chat.IsAdmin { // in a group pinning needs admin rights
		r.Add(pinTool(d, chat), unpinTool(d, chat))
	}
	if cfg.UseStickers {
		r.Add(stickerListTool(d), stickerFindTool(d), stickerSendTool(d, chat), stickerSaveTool(d, chat))
	}
	if d.Images != nil {
		r.Add(takePhotoTool(d))
	}
	r.Add(recordAudioTool(d))
	if !IsOwnerChat(d, chat.ID) { // the owner's chat has send_file, which reaches any path
		r.Add(shareFileTool(d, chat))
	}
	if chat.Kind == telegram.ChatGroup {
		r.Add(chatMembersTool(d, chat))
		if cfg.CanLeaveChats {
			r.Add(leaveTool(d, chat))
		}
		if chat.IsAdmin {
			r.Add(adminRemoveTool(d, chat), adminBanTool(d, chat), adminTagTool(d, chat))
		}
	}
	return r
}

// ChatPrivateKind is a readability alias.
const ChatPrivateKind = telegram.ChatPrivate

func reactTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name:        "react_with_emoji",
		Description: "Add an emoji reaction to a message. You can use only one of these emojis only: " + allowedReactions,
		Props: []Prop{
			{Name: "message_id", Type: "integer", Desc: "ID of the message to react to. Taken from message_id attribute in <message> tag."},
			{Name: "emoji", Type: "string", Desc: "A single emoji from the allowed list only. Do not use emojis outside the list."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			emoji := a.Str("emoji")
			if !isAllowedReaction(emoji) {
				return "", fmt.Errorf("emoji %q is not allowed; pick one from the list", emoji)
			}
			if err := d.TG.React(ctx, chat.ID, a.Int("message_id"), stripVS16(emoji)); err != nil {
				return "", err
			}
			return "Reaction added", nil
		},
	}
}

func sendToolRaw(d Deps, chat telegram.Chat) Tool {
	var mu sync.Mutex
	inARow := 0
	repliedTo := map[int64]bool{} // in this turn: one answer per message
	quoted := false               // in a group, one quote per turn: the rest of a batch is answered by name, not message by message
	return Tool{
		Name: "send_telegram_message",
		Description: fmt.Sprintf("Sends a message to the %q chat. Requirements:\n"+
			"- before asking them a question, double-check yourself with #ask\n"+
			"- write like in a chat: a message is one to three short sentences; an answer is two or three messages at most, never a stack of one-liners (longer text is split and glued into messages automatically). Example: (1) \"hi~ how are you?\".", chat.Title),
		Props: []Prop{
			{Name: "text", Type: "string", Nullable: true, Desc: "Text of the message. Pass null if not sending any text (e.g., when sending only a photo/audio)."},
			{Name: "photo_filename", Type: "string", Nullable: true, Desc: "Attaches a photo with the given filename (obtained from #take_photo). Pass null if not attaching a photo."},
			{Name: "audio_filename", Type: "string", Nullable: true, Desc: "Attaches an audio file with the given filename from the voice gallery (obtained from #record_audio). Pass null if not attaching audio."},
			{Name: "reply_to_message_id", Type: "integer", Nullable: true, Desc: "If specified, the message will be a reply to the message with this id. Use it if there are multiple messages or to clearly address a specific message. Pass null if not replying."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			mu.Lock()
			inARow++
			n := inARow
			mu.Unlock()
			if n > 80 {
				return "", errors.New("Too many messages in a row. Don't spam!")
			}
			text := strings.ReplaceAll(a.Str("text"), "\r", "")
			photo, audio, reply := a.Str("photo_filename"), a.Str("audio_filename"), a.Int("reply_to_message_id")
			if reply != 0 && chat.Kind == telegram.ChatGroup {
				mu.Lock()
				again := repliedTo[reply]
				if !again && quoted {
					reply = 0 // already quoted one message this turn: address the others by name in the text
				}
				mu.Unlock()
				if reply == 0 {
					// plain follow-up, nothing to check
				} else if again { // a follow-up bubble of the same answer: send it plainly, without quoting the message again
					reply = 0
				} else if err := staleReply(ctx, d, chat.ID, reply); err != nil {
					return "", err
				} else if d.RT != nil && d.RT.talk.seen(chat.ID, reply, time.Now()) {
					// another turn (a new message arrived meanwhile) already answered it; the history she reads can lag behind
					return "", fmt.Errorf("you have already replied to message %d a moment ago: do not answer it again. Answer a newer message meant for you, or stay quiet", reply)
				}
			}
			if text == "" && photo == "" && audio == "" {
				return "", errors.New("nothing to send: specify text, photo_filename or audio_filename")
			}
			if text != "" && audio == "" && !a.Bool("_norepeat") {
				if err := repeatError(ctx, d, chat, text); err != nil {
					return "", err
				}
			}
			_ = d.TG.Typing(ctx, chat.ID)
			var sent telegram.Message
			var err error
			switch {
			case photo != "":
				path, perr := safeJoin(d.dataPath("photos"), photo)
				if perr != nil {
					return "", fmt.Errorf("bad photo_filename %q", photo)
				}
				data, rerr := os.ReadFile(path)
				if rerr != nil {
					return "", fmt.Errorf("photo %q not found; take one with #take_photo", photo)
				}
				sent, err = d.TG.SendPhoto(ctx, chat.ID, data, text, reply)
			case audio != "":
				path, perr := safeJoin(d.dataPath("voice"), audio)
				if perr != nil {
					return "", fmt.Errorf("bad audio_filename %q", audio)
				}
				data, rerr := os.ReadFile(path)
				if rerr != nil {
					return "", fmt.Errorf("audio %q not found; record one with #record_audio", audio)
				}
				sent, err = d.TG.SendVoice(ctx, chat.ID, data, reply)
				if err == nil && text != "" {
					_, err = d.TG.SendText(ctx, chat.ID, text, 0)
				}
			default:
				sent, err = d.TG.SendText(ctx, chat.ID, text, reply)
				if err == nil && reply != 0 {
					mu.Lock()
					repliedTo[reply] = true
					quoted = true
					mu.Unlock()
					if d.RT != nil && chat.Kind == telegram.ChatGroup {
						d.RT.talk.mark(chat.ID, reply, time.Now())
					}
				}
			}
			if err != nil {
				return "", err
			}
			d.Metrics.Inc("kuni_telegram_messages_sent_total", 1, nil)
			return fmt.Sprintf("Message sent (message_id=%d)", sent.ID), nil
		},
	}
}

func ownMessage(ctx context.Context, d Deps, chat telegram.Chat, id int64) (telegram.Message, error) {
	m, err := d.TG.Message(ctx, chat.ID, id)
	if err != nil {
		return m, fmt.Errorf("message %d not found in %q", id, chat.Title)
	}
	return m, nil
}

func editTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name:        "edit_message_text",
		Description: "Edits the text (or the caption of a media message) of one of YOUR OWN messages.",
		Props: []Prop{
			{Name: "message_id", Type: "integer", Desc: "ID of your message to edit."},
			{Name: "text", Type: "string", Desc: "New text."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			m, err := ownMessage(ctx, d, chat, a.Int("message_id"))
			if err != nil {
				return "", err
			}
			if !m.Outgoing {
				return "", errors.New("you can edit only your own messages")
			}
			if err := d.TG.Edit(ctx, chat.ID, m.ID, a.Str("text")); err != nil {
				return "", err
			}
			return "Message edited", nil
		},
	}
}

func removeMessageTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name:        "remove_message",
		Description: "Deletes one of YOUR OWN messages.",
		Props:       []Prop{{Name: "message_id", Type: "integer", Desc: "ID of your message to delete."}},
		Run: func(ctx context.Context, a Args) (string, error) {
			m, err := ownMessage(ctx, d, chat, a.Int("message_id"))
			if err != nil {
				return "", err
			}
			if !m.Outgoing {
				return "", errors.New("you can delete only your own messages")
			}
			if err := d.TG.Delete(ctx, chat.ID, m.ID); err != nil {
				return "", err
			}
			return "Message removed", nil
		},
	}
}

func forwardTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name:        "forward_message",
		Description: "Forwards a message to another chat, optionally with your short comment. Use #get_telegram_chats to find to_chat_id. Be selective.",
		Props: []Prop{
			{Name: "message_id", Type: "integer", Desc: "ID of the message to forward."},
			{Name: "to_chat_id", Type: "integer", Desc: "Destination chat id."},
			{Name: "comment", Type: "string", Nullable: true, Desc: "Optional short comment sent after the forwarded message."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			to := a.Int("to_chat_id")
			if !d.Accessible(to) {
				return "", errors.New("that chat is not accessible (lockdown mode)")
			}
			if err := d.TG.Forward(ctx, chat.ID, a.Int("message_id"), to); err != nil {
				return "", err
			}
			if c := a.Str("comment"); c != "" {
				if _, err := d.TG.SendText(telegram.NoThread(ctx), to, c, 0); err != nil {
					return "", err
				}
			}
			return "Message forwarded", nil
		},
	}
}

func viewAroundTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name:        "view_messages_around",
		Description: "Shows messages around a given message of this chat (context before and after it).",
		Props: []Prop{
			{Name: "message_id", Type: "integer", Desc: "Anchor message id."},
			{Name: "count", Type: "integer", Nullable: true, Desc: "How many messages before and after (default 10, max 30)."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			n := int(a.Int("count"))
			if n <= 0 {
				n = 10
			}
			if n > 30 {
				n = 30
			}
			msgs, err := d.TG.History(ctx, chat.ID, a.Int("message_id"), n, n)
			if err != nil {
				return "", err
			}
			if len(msgs) == 0 {
				return "No messages", nil
			}
			return d.UI.FormatMessages(ctx, msgs, time.Now()), nil
		},
	}
}

func getChatPhotoTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name:        "get_chat_photo",
		Description: "Look at the profile photo (avatar) of the current chat.",
		Run: func(ctx context.Context, a Args) (string, error) {
			data, err := d.TG.ChatPhoto(ctx, chat.ID)
			if err != nil {
				return "", err
			}
			desc, err := d.UI.DescribeImage(ctx, data, false)
			if err != nil {
				return "", err
			}
			return "<chat_photo description>\n" + llmui.Sanitize(desc) + "\n</chat_photo>", nil
		},
	}
}

func leaveTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name:        "leave_chat",
		Description: "Leave this group chat. You will not be able to read it anymore.",
		Run: func(ctx context.Context, a Args) (string, error) {
			if err := d.TG.Leave(ctx, chat.ID); err != nil {
				return "", err
			}
			return "You left the chat", nil
		},
	}
}

func joinTool(d Deps) Tool {
	return Tool{
		Name:        "join_chat",
		Description: "Join a chat so you can fully participate the next time you open it.",
		Props:       []Prop{{Name: "invite_link", Type: "string", Desc: "Invite link or @username."}},
		Run: func(ctx context.Context, a Args) (string, error) {
			if err := d.TG.Join(ctx, a.Str("invite_link")); err != nil {
				return "", err
			}
			return "Joined", nil
		},
	}
}

func adminRemoveTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name:        "group_admin_remove_message",
		Description: "Admin only: delete ANY message in this group (e.g., spam or abuse).",
		Props:       []Prop{{Name: "message_id", Type: "integer", Desc: "Message id."}},
		Run: func(ctx context.Context, a Args) (string, error) {
			if err := d.TG.Delete(ctx, chat.ID, a.Int("message_id")); err != nil {
				return "", err
			}
			return "Message removed", nil
		},
	}
}

func adminBanTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name:        "group_admin_ban_user",
		Description: "Admin only: ban a user from this group. Use sparingly and only for clear abuse.",
		Props: []Prop{
			{Name: "user_id", Type: "integer", Desc: "Telegram user id (sender_id)."},
			{Name: "remove_all_messages", Type: "boolean", Nullable: true, Desc: "Also delete all their messages."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			if a.Int("user_id") == d.TG.MyID() {
				return "", errors.New("you can't ban yourself")
			}
			if err := d.TG.Ban(ctx, chat.ID, a.Int("user_id"), a.Bool("remove_all_messages")); err != nil {
				return "", err
			}
			return "User banned", nil
		},
	}
}

func adminTagTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name:        "group_admin_set_user_tag",
		Description: "Admin only: set a short tag (label) displayed next to a regular member's name. Up to 16 characters, no emoji.",
		Props: []Prop{
			{Name: "user_id", Type: "integer", Desc: "Telegram user id."},
			{Name: "tag", Type: "string", Desc: "Tag text, at most 16 characters, no emoji (empty to clear)."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			tag := strings.TrimSpace(a.Str("tag"))
			if err := validMemberTag(tag); err != nil {
				return "", err // Telegram refuses it with a bare error; say what to change
			}
			if err := d.TG.SetMemberTag(ctx, chat.ID, a.Int("user_id"), tag); err != nil {
				return "", err
			}
			return "Tag set", nil
		},
	}
}

// validMemberTag checks Telegram's rules for member tags: 0-16 characters and no emoji.
func validMemberTag(tag string) error {
	if n := utf8.RuneCountInString(tag); n > 16 {
		return fmt.Errorf("the tag is %d characters long; Telegram allows at most 16", n)
	}
	for _, r := range tag {
		if isEmojiRune(r) {
			return fmt.Errorf("Telegram does not allow emoji in member tags (%q)", string(r))
		}
	}
	return nil
}

// isEmojiRune is a coarse check for pictographs, dingbats, flags and the joiners that build emoji.
func isEmojiRune(r rune) bool {
	switch {
	case r >= 0x1F000 && r <= 0x1FAFF, r >= 0x2600 && r <= 0x27BF, r >= 0x2B00 && r <= 0x2BFF,
		r == 0x200D, r == 0xFE0F, r >= 0x1F1E6 && r <= 0x1F1FF, r >= 0xE0020 && r <= 0xE007F:
		return true
	}
	return false
}

// --- media tools ---

func takePhotoTool(d Deps) Tool {
	return Tool{
		Name: "take_photo",
		Description: "Take a selfie / photo of yourself following the description (or choose one from your gallery). " +
			"Returns a filename to attach with #send_telegram_message(photo_filename). May take a minute.",
		Props: []Prop{{Name: "photo_desc", Type: "string", Desc: "Short description of the photo: pose, clothes, place, mood. No explicit content."}},
		Run: func(ctx context.Context, a Args) (string, error) {
			img, err := d.Images.Generate(ctx, a.Str("photo_desc"))
			if err != nil {
				return "", err
			}
			name := fmt.Sprintf("%d.png", time.Now().UnixNano())
			dir := d.dataPath("photos")
			if err := os.MkdirAll(dir, 0o755); err != nil {
				return "", err
			}
			if err := os.WriteFile(filepath.Join(dir, name), img, 0o644); err != nil {
				return "", err
			}
			desc, derr := d.UI.DescribeImage(ctx, img, false)
			out := "Filename: " + name
			if derr == nil {
				out += "\n<photo description>\n" + desc + "\n</photo>"
			}
			return out, nil
		},
	}
}

func recordAudioTool(d Deps) Tool {
	return Tool{
		Name:        "record_audio",
		Description: "Record a voice message (text-to-speech). Returns a filename to attach with #send_telegram_message(audio_filename).",
		Props:       []Prop{{Name: "speech", Type: "string", Desc: d.Prompts.Get(prompts.RecordAudioSpeech)}},
		Run: func(ctx context.Context, a Args) (string, error) {
			audio, ext, err := d.Media().TTS.Speak(ctx, a.Str("speech"))
			if err != nil {
				return "", err
			}
			name := fmt.Sprintf("%d.%s", time.Now().UnixNano(), ext)
			dir := d.dataPath("voice")
			if err := os.MkdirAll(dir, 0o755); err != nil {
				return "", err
			}
			if err := os.WriteFile(filepath.Join(dir, name), audio, 0o644); err != nil {
				return "", err
			}
			return "Filename: " + name, nil
		},
	}
}

// --- stickers (saved set kept in data/stickers.json) ---

type savedSticker struct {
	FileID      string `json:"file_id"`
	Emoji       string `json:"emoji"`
	Description string `json:"description,omitempty"`
}

func stickerFile(d Deps) string { return d.dataPath("stickers.json") }

func loadStickers(d Deps) map[string]savedSticker {
	out := map[string]savedSticker{}
	store.Load("stickers", stickerFile(d), &out)
	if out == nil {
		out = map[string]savedSticker{}
	}
	return out
}

// stickerListCap is how many of her saved stickers one #sticker_list shows: the whole collection would be a wall of text.
const stickerListCap = 30

func stickerListTool(d Deps) Tool {
	return Tool{
		Name:        "sticker_list",
		Description: "Your own sticker collection (the ones you saved because you liked them). Pass an emoji to see only the stickers for that mood. Use this before #sticker_send. To look for new ones in all of Telegram, use #sticker_find.",
		Props:       []Prop{{Name: "emoji", Type: "string", Nullable: true, Desc: "Show only stickers with this emoji."}},
		Run: func(ctx context.Context, a Args) (string, error) {
			d.rt().stickers.Lock()
			defer d.rt().stickers.Unlock()
			all := loadStickers(d)
			if len(all) == 0 {
				return "No saved stickers. Use #sticker_save on a sticker someone sent, or find some with #sticker_find.", nil
			}
			want := strings.TrimSpace(a.Str("emoji"))
			var b strings.Builder
			n := 0
			for id, s := range all {
				if want != "" && !strings.Contains(s.Emoji, want) {
					continue
				}
				if n++; n > stickerListCap {
					fmt.Fprintf(&b, "(%d in the collection, filter by emoji to see others)\n", len(all))
					break
				}
				fmt.Fprintf(&b, "<sticker sticker_id=%q emoji=%q>%s</sticker>\n", id, s.Emoji, s.Description)
			}
			if b.Len() == 0 {
				return fmt.Sprintf("No saved stickers with %s (%d in the collection). Try #sticker_find.", want, len(all)), nil
			}
			return b.String(), nil
		},
	}
}

// stickerFindTool searches the whole sticker library by emoji, premium stickers included when her account has Premium.
func stickerFindTool(d Deps) Tool {
	return Tool{
		Name:        "sticker_find",
		Description: "Search stickers in all of Telegram by emoji (one or two, like 😂 or 🥺). Returns sticker_id, emoji and premium=true for premium stickers (they are sent only if your account has Telegram Premium). Send one with #sticker_send, keep the ones you love with #sticker_save.",
		Props:       []Prop{{Name: "emoji", Type: "string", Desc: "The emoji (or two) that fits the mood."}},
		Run: func(ctx context.Context, a Args) (string, error) {
			sf, ok := d.TG.(telegram.StickerFinder)
			if !ok {
				return "", errors.New("searching stickers works only through the user-account client")
			}
			found, err := sf.FindStickers(ctx, a.Str("emoji"), 12)
			if err != nil {
				return "", err
			}
			if len(found) == 0 {
				return "Nothing found for that emoji. Try another.", nil
			}
			rt := d.rt()
			rt.stickers.Lock()
			if rt.found == nil || len(rt.found) > 400 {
				rt.found = map[string]telegram.StickerInfo{}
			}
			var b strings.Builder
			for _, s := range found {
				rt.found[s.FileID] = s
				fmt.Fprintf(&b, "<sticker sticker_id=%q emoji=%q premium=\"%t\"/>\n", s.FileID, s.Emoji, s.Premium)
			}
			rt.stickers.Unlock()
			return b.String(), nil
		},
	}
}

func stickerSaveTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name:        "sticker_save",
		Description: "Add a sticker to your own collection because you like it: either a sticker from a message (message_id) or one you found with #sticker_find (sticker_id). Your collection is yours: save what you would really use.",
		Props: []Prop{
			{Name: "message_id", Type: "integer", Nullable: true, Desc: "ID of a message containing a sticker."},
			{Name: "sticker_id", Type: "string", Nullable: true, Desc: "sticker_id from #sticker_find."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			var s savedSticker
			if sid := strings.TrimSpace(a.Str("sticker_id")); sid != "" {
				d.rt().stickers.Lock()
				f, ok := d.rt().found[sid]
				d.rt().stickers.Unlock()
				if !ok {
					return "", errors.New("unknown sticker_id; look for it with #sticker_find first")
				}
				s = savedSticker{FileID: f.FileID, Emoji: f.Emoji}
			} else {
				m, err := ownMessage(ctx, d, chat, a.Int("message_id"))
				if err != nil {
					return "", err
				}
				if m.Media != telegram.MediaSticker {
					return "", errors.New("that message has no sticker")
				}
				desc := ""
				if data, err := d.TG.Download(ctx, m.FileID); err == nil {
					desc, _ = d.UI.DescribeImage(ctx, data, true)
				}
				s = savedSticker{FileID: m.FileID, Emoji: m.Text, Description: desc}
			}
			d.rt().stickers.Lock()
			defer d.rt().stickers.Unlock()
			all := loadStickers(d)
			if _, had := all[s.FileID]; had {
				return "Already in your collection", nil
			}
			all[s.FileID] = s
			if err := store.WriteJSON(stickerFile(d), all, store.Private); err != nil {
				return "", err
			}
			return fmt.Sprintf("Sticker saved (%d in your collection)", len(all)), nil
		},
	}
}

func stickerSendTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name:        "sticker_send",
		Description: "Send a sticker: one from your collection (#sticker_list) or one you just found (#sticker_find). Use it the way a person does: instead of words for laughter, tiredness, embarrassment, tenderness.",
		Props: []Prop{
			{Name: "sticker_id", Type: "string", Desc: "sticker_id from #sticker_list or #sticker_find."},
			{Name: "reply_to_message_id", Type: "integer", Nullable: true, Desc: "Reply target or null."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			id := a.Str("sticker_id")
			d.rt().stickers.Lock()
			s, ok := loadStickers(d)[id]
			f, foundOK := d.rt().found[id]
			d.rt().stickers.Unlock()
			fileID, premium := s.FileID, false
			if !ok {
				if !foundOK {
					return "", errors.New("unknown sticker_id; call #sticker_list or #sticker_find")
				}
				fileID, premium = f.FileID, f.Premium
			}
			m, err := d.TG.SendSticker(ctx, chat.ID, fileID, a.Int("reply_to_message_id"))
			if err != nil {
				if premium {
					return "", fmt.Errorf("%v (this is a premium sticker: it needs Telegram Premium on your account, pick another)", err)
				}
				return "", err
			}
			return fmt.Sprintf("Sticker sent (message_id=%d)", m.ID), nil
		},
	}
}

// repeatError refuses to send the same text again among the last few own messages.
// staleReply refuses a group reply to a message she has already answered (in any turn), or to an old message
// while a newer one replies to her and is still unanswered: that newer one is what she must answer.
func staleReply(ctx context.Context, d Deps, chatID, reply int64) error {
	hist, err := d.TG.History(ctx, chatID, 0, 40, 0)
	if err != nil {
		return nil
	}
	mine, answered := map[int64]bool{}, map[int64]bool{}
	for _, m := range hist {
		if m.Outgoing {
			mine[m.ID] = true
			if m.ReplyTo != 0 {
				answered[m.ReplyTo] = true
			}
		}
	}
	if answered[reply] {
		return fmt.Errorf("you have already answered message %d: do not answer it again. Answer the newest message meant for you, or stop", reply)
	}
	var newest int64
	for _, m := range hist {
		if !m.Outgoing && m.ID > reply && mine[m.ReplyTo] && !answered[m.ID] && m.ID > newest {
			newest = m.ID
		}
	}
	if newest != 0 {
		return fmt.Errorf("message %d is old: newer message %d replies to you and is unanswered. Answer %d (reply_to_message_id=%d) instead", reply, newest, newest, newest)
	}
	return nil
}

func repeatError(ctx context.Context, d Deps, chat telegram.Chat, text string) error {
	norm := func(s string) string { return strings.Join(strings.Fields(strings.ToLower(s)), " ") }
	want := norm(text)
	hist, _ := d.TG.History(ctx, chat.ID, 0, 12, 0)
	var own []string // recent own messages, oldest first (a long text was sent as several of them)
	for _, m := range hist {
		if m.Outgoing {
			own = append(own, norm(m.Text))
		}
	}
	for n := 1; n <= len(own); n++ {
		if strings.Join(own[len(own)-n:], " ") == want {
			return errors.New(strings.TrimSpace(d.Prompts.Get(prompts.AntiRepeat)))
		}
	}
	for _, o := range own {
		if o == want {
			return errors.New(strings.TrimSpace(d.Prompts.Get(prompts.AntiRepeat)))
		}
	}
	return nil
}

// sendTool turns "one call = one short message" into code instead of prompt tokens: plain text is cut into
// messages of at most max_message_chars (as many as needed) and each is preceded by a human-like "typing..." pause.
func sendTool(d Deps, chat telegram.Chat) Tool {
	t := sendToolRaw(d, chat)
	raw := t.Run
	t.Run = func(ctx context.Context, a Args) (string, error) {
		text := strings.TrimSpace(strings.ReplaceAll(a.Str("text"), "\r", ""))
		if text == "" || a.Str("photo_filename") != "" || a.Str("audio_filename") != "" {
			return raw(ctx, a)
		}
		if strings.Contains(text, "```") {
			return sendWithCode(ctx, d, chat, t.Run, raw, a, text)
		}
		if text = PlainText(text); text == "" {
			return "", errors.New("the message was only decorations; write plain words")
		}
		if err := repeatError(ctx, d, chat, text); err != nil {
			return "", err
		}
		cfg := d.Cfg()
		if rid := a.Int("reply_to_message_id"); rid != 0 { // later chunks have no reply: pin the topic of the answered message
			if m, err := d.TG.Message(ctx, chat.ID, rid); err == nil && m.ThreadID != 0 {
				ctx = telegram.WithThread(ctx, m.ThreadID)
			}
		}
		chunks := PackMessages(SplitMessage(text, cfg.MaxMessageChars), cfg.PackChars, 0)
		if cfg.SmartSplit {
			chunks = HumanSplit(chunks, rand.Float64)
		}
		chunks = PackMessages(chunks, 0, cfg.MaxBubbles)
		var out []string
		for i, c := range chunks {
			meant := NoFinalDot(c)
			c = MaybeTypo(meant, cfg.TypoChance, rand.Float64)
			_ = d.TG.Typing(ctx, chat.ID)
			if err := typingPause(ctx, typingDuration(cfg.TypingMinMs, cfg.TypingMaxMs, cfg.TypingPerCharMs, c, rand.Float64)); err != nil {
				return strings.Join(out, "\n"), err
			}
			sub := Args{}
			for k, v := range a {
				sub[k] = v
			}
			sub["text"], sub["_norepeat"] = c, true
			if i > 0 {
				delete(sub, "reply_to_message_id")
			}
			r, err := raw(ctx, sub)
			if err != nil {
				return strings.Join(append(out, "error: "+err.Error()), "\n"), nil
			}
			out = append(out, r)
			// like a person: after a typo, now and then a quick "*word" with the right spelling
			if fix := TypoFix(meant, c); fix != "" && rand.Float64() < cfg.TypoFixChance {
				_ = typingPause(ctx, time.Duration(600+rand.Intn(900))*time.Millisecond)
				fx := Args{"text": fix, "_norepeat": true}
				_, _ = raw(ctx, fx)
			}
		}
		return strings.Join(out, "\n"), nil
	}
	return t
}

// typingDuration is how long "typing..." shows before a message. With perCharMs > 0 it is proportional to the
// text length (a short "ага" is quick, a full-length chunk takes up to maxMs); otherwise it is a random time
// between minMs and maxMs.
func typingDuration(minMs, maxMs, perCharMs int, text string, rnd func() float64) time.Duration {
	if maxMs < minMs {
		maxMs = minMs
	}
	if maxMs <= 0 {
		return 0
	}
	if perCharMs <= 0 {
		return time.Duration(minMs+int(rnd()*float64(maxMs-minMs+1))) * time.Millisecond
	}
	ms := float64(perCharMs * len([]rune(text)))
	ms *= 0.85 + 0.3*rnd() // +-15%
	floor := minMs
	if floor > 1000 {
		floor = 1000
	}
	if ms < float64(floor) {
		ms = float64(floor)
	}
	if ms > float64(maxMs) {
		ms = float64(maxMs)
	}
	return time.Duration(ms) * time.Millisecond
}

func typingPause(ctx context.Context, d time.Duration) error {
	if d <= 0 {
		return nil
	}
	select {
	case <-time.After(d):
		return nil
	case <-ctx.Done():
		return ctx.Err()
	}
}
