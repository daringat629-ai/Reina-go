package tools

import (
	"context"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"kuni/internal/config"
	"kuni/internal/telegram"
)

func ownerDeps(t *testing.T, papik int64) Deps {
	c := &config.Config{DataDir: t.TempDir(), PapikChatID: papik, OwnerTools: true, ShellTimeout: 60}
	return Deps{RT: NewRuntime(nil), TG: telegram.NewFake(), Cfg: func() *config.Config { return c }}
}

func TestOwnerToolsOnlyForOwner(t *testing.T) {
	d := ownerDeps(t, 5)
	if len(OwnerTools(d, telegram.Chat{ID: 6})) != 0 {
		t.Fatal("tools leaked to a stranger")
	}
	names := map[string]bool{}
	for _, tl := range OwnerTools(d, telegram.Chat{ID: 5}) {
		names[tl.Name] = true
	}
	for _, want := range []string{"chat_members", "join_by_link", "send_to_chat", "shell_bg", "jobs", "self_update", "tg_api", "telegram_ui", "web_search",
		"read_file", "http_request", "mail", "calendar", "work", "docker", "places", "make_document", "make_table", "make_chart"} {
		if !names[want] {
			t.Errorf("the owner lacks %s", want)
		}
	}
	if len(names) != 56 {
		t.Errorf("owner tools: %d, want 56", len(names))
	}
	if names["ledger"] || names["tracker"] || names["dates"] {
		t.Error("book-keeping tools without their stores")
	}
}

func TestShell(t *testing.T) {
	d := ownerDeps(t, 5)
	out, _ := shellTool(d).Run(context.Background(), Args{"command": "echo hi; exit 3"})
	if !strings.Contains(out, "exit=3") || !strings.Contains(out, "hi") {
		t.Fatal(out)
	}
	out, _ = shellTool(d).Run(context.Background(), Args{"command": "sleep 5", "timeout_secs": float64(1)})
	if !strings.Contains(out, "timed out") {
		t.Fatal(out)
	}
	if got := Truncate(strings.Repeat("a", 20000), 6000); len(got) > 6100 {
		t.Fatal(len(got))
	}
}

func TestSendFile(t *testing.T) {
	d := ownerDeps(t, 5)
	_, _ = shellTool(d).Run(context.Background(), Args{"command": "echo x > a.txt"})
	if _, err := sendFileTool(d, telegram.Chat{ID: 5}).Run(context.Background(), Args{"path": "a.txt"}); err != nil {
		t.Fatal(err)
	}
}

func TestOwnerCanJoinByLinkAndWriteElsewhere(t *testing.T) {
	d := ownerDeps(t, 5)
	fk := d.TG.(*telegram.Fake)
	if out, err := ownerJoinTool(d).Run(context.Background(), Args{"invite_link": "https://t.me/+abc"}); err != nil || !strings.Contains(out, "Joined") {
		t.Fatalf("%q %v", out, err)
	}
	if len(fk.Joined) != 1 || fk.Joined[0] != "https://t.me/+abc" {
		t.Fatalf("join not requested: %v", fk.Joined)
	}
	if _, err := ownerJoinTool(d).Run(context.Background(), Args{"invite_link": " "}); err == nil {
		t.Fatal("an empty link must fail")
	}
	if _, err := sendToChatTool(d).Run(context.Background(), Args{"chat": "-100777", "text": "привет всем"}); err != nil {
		t.Fatal(err)
	}
	if got := fk.SentTexts(); len(got) != 1 || got[0] != "привет всем" {
		t.Fatalf("sent %v", got)
	}
	if _, err := sendToChatTool(d).Run(context.Background(), Args{"chat": "-100777", "text": " "}); err == nil {
		t.Fatal("an empty text must fail")
	}
}

func TestShellRefusesCatastrophesAndLogsThem(t *testing.T) {
	d := ownerDeps(t, 5)
	d.Cfg().ShellHardBlock = true
	out, err := shellTool(d).Run(context.Background(), Args{"command": "rm -rf /"})
	if err != nil || !strings.Contains(out, "Blocked") {
		t.Fatalf("%q %v", out, err)
	}
	// her own data dir is protected too
	dd := d.Cfg().DataDir
	if out, _ := shellTool(d).Run(context.Background(), Args{"command": "rm -rf " + dd}); !strings.Contains(out, "Blocked") {
		t.Fatalf("data dir not protected: %q", out)
	}
	log, _ := os.ReadFile(filepath.Join(dd, "shell.log"))
	if !strings.Contains(string(log), "BLOCKED") {
		t.Fatalf("blocked attempts must be journaled: %q", log)
	}
}

func TestShellUserThatDoesNotExistNeverFallsBackToRoot(t *testing.T) {
	d := ownerDeps(t, 5)
	d.Cfg().ShellUser = "no_such_user_xyz"
	if _, err := shellTool(d).Run(context.Background(), Args{"command": "echo hi"}); err == nil {
		t.Fatal("must fail instead of running as the current user")
	}
}

func TestHardBlockIsOffByDefault(t *testing.T) {
	d := ownerDeps(t, 5)
	if d.shellDanger("rm -rf /") != "" {
		t.Fatal("the hard block must be opt-in")
	}
	d.Cfg().ShellHardBlock = true
	if d.shellDanger("rm -rf /") == "" {
		t.Fatal("must block when enabled")
	}
}

func TestSelfUpdateInstallsOrRefuses(t *testing.T) {
	d := ownerDeps(t, 5)
	bin := t.TempDir()
	_ = os.WriteFile(filepath.Join(bin, "reina-tdlib"), []byte("\x7fELFold"+strings.Repeat("o", 40)), 0o755)
	d.UpdateDir = bin
	restarted := make(chan struct{}, 1)
	d.Restart = func() { restarted <- struct{}{} }

	// a cut-off archive is refused and nothing changes
	cut := filepath.Join(d.workDir(), "cut.zip")
	_ = os.WriteFile(cut, []byte("PK\x03\x04 half of a zip"), 0o644)
	if _, err := selfUpdateTool(d).Run(context.Background(), Args{"path": cut}); err == nil || !strings.Contains(err.Error(), "not installed") {
		t.Fatalf("a broken archive must be refused: %v", err)
	}
	cur, _ := os.ReadFile(filepath.Join(bin, "reina-tdlib"))
	if !strings.HasPrefix(string(cur), "\x7fELFold") {
		t.Fatal("the old build must stay when the archive is bad")
	}
	if _, err := selfUpdateTool(d).Run(context.Background(), Args{"path": ""}); err == nil {
		t.Fatal("empty path must be an error")
	}
}

func TestSelfRepairToolsAreOffUntilTheOwnerTurnsThemOn(t *testing.T) {
	d := ownerDeps(t, 5)
	if len(SelfRepairTools(d)) != 0 {
		t.Fatal("off by default")
	}
	c := d.Cfg()
	c.SelfRepair = true
	names := map[string]bool{}
	for _, tl := range SelfRepairTools(d) {
		names[tl.Name] = true
	}
	if !names["shell"] || !names["tail_log"] && !names["log"] {
		// the name of the log tool is whatever tailLogTool calls itself: shell must be there at least
		if !names["shell"] {
			t.Fatalf("her own tools missing: %v", names)
		}
	}
	for _, bad := range []string{"send_to_chat", "read_chat", "chat_members", "ssh"} {
		if names[bad] {
			t.Fatalf("self repair must not give her %s", bad)
		}
	}
}
