package config

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestSetInTextReplaceInsertDedupe(t *testing.T) {
	src := "[telegram]\n# c\nlockdown = \"papik_only\"\nlockdown = \"none\"\nmode = \"user\"\n\n[llm]\nmodel = \"a\"\n"
	got := SetInText(src, "telegram", "lockdown", "contacts_only")
	if strings.Count(got, "lockdown") != 1 || !strings.Contains(got, `lockdown = "contacts_only"`) {
		t.Fatalf("replace/dedupe failed:\n%s", got)
	}
	if !strings.Contains(got, `mode = "user"`) || !strings.Contains(got, "# c") {
		t.Fatalf("lost lines:\n%s", got)
	}
	got = SetInText(src, "llm", "reasoning", "off")
	if !strings.Contains(got, "[llm]\nreasoning = \"off\"\nmodel") {
		t.Fatalf("insert under header failed:\n%s", got)
	}
	got = SetInText(src, "capabilities", "owner_tools", true)
	if !strings.HasSuffix(got, "[capabilities]\nowner_tools = true\n") {
		t.Fatalf("new section failed:\n%s", got)
	}
	// a key with a longer name must not be touched
	got = SetInText("[a]\nmodel_x = 1\n", "a", "model", "z")
	if !strings.Contains(got, "model_x = 1") || !strings.Contains(got, `model = "z"`) {
		t.Fatalf("prefix clash:\n%s", got)
	}
}

func TestSetKeyRoundTrip(t *testing.T) {
	dir := t.TempDir()
	p := filepath.Join(dir, "config.toml")
	if _, err := Load(p); err != ErrNeedsSetup {
		t.Fatal(err)
	}
	for _, kv := range [][3]string{{"telegram", "lockdown", "contacts_only"}, {"telegram", "max_message_chars", "45"}, {"capabilities", "owner_tools", "off"}, {"llm", "model", "deepseek/x"}} {
		if err := SetKey(p, kv[0], kv[1], kv[2]); err != nil {
			t.Fatal(err)
		}
	}
	c, err := Load(p)
	if err != nil {
		t.Fatal(err)
	}
	if c.Lockdown != "contacts_only" || c.MaxMessageChars != 45 || c.OwnerTools || c.LLMModel != "deepseek/x" {
		t.Fatalf("%+v", c)
	}
	if c.Value("telegram", "max_message_chars") != "45" || c.Value("telegram", "debounce_ms") != "6000" {
		t.Fatal(c.Value("telegram", "debounce_ms"))
	}
	if err := SetKey(p, "telegram", "max_message_chars", "abc"); err == nil {
		t.Fatal("bad int accepted")
	}
	if err := SetKey(p, "nope", "x", "1"); err == nil {
		t.Fatal("unknown key accepted")
	}
	if _, err := os.Stat(p + ".bak"); err != nil {
		t.Fatal("no backup")
	}
}
