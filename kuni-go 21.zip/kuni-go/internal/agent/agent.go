// Package agent wires everything together: Telegram updates -> per-chat sessions
// -> LLM tool loop (tools act back on Telegram) -> diary + working memory dump
// when the conversation goes idle. It is the Go counterpart of App/Worker/AppBase.
package agent

import (
	"context"
	"fmt"
	"log"
	"math/rand"
	"regexp"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"kuni/internal/autonomy"
	"kuni/internal/config"
	"kuni/internal/diary"
	"kuni/internal/llm"
	"kuni/internal/llmui"
	"kuni/internal/memory"
	"kuni/internal/metrics"
	"kuni/internal/mood"
	"kuni/internal/prompts"
	"kuni/internal/telegram"
	"kuni/internal/tools"
	"kuni/internal/usage"
	"kuni/internal/util"
)

type Agent struct {
	Cfg     *config.Holder
	LLM     *llm.Client
	TG      telegram.Client
	Diary   *diary.Diary
	Prompts *prompts.Store
	UI      *llmui.Env
	Dumper  *memory.Dumper
	Metrics *metrics.Registry
	Deps    tools.Deps
	Auto    *autonomy.State // nil = autonomy unavailable
	Usage   *usage.Tracker  // nil = no budget

	active   atomic.Int32
	paused   atomic.Bool
	runCtx   context.Context
	mu       sync.Mutex
	sessions map[int64]*session
	timers   map[int64]*time.Timer
	later    map[int64]time.Time // chats held back by a late reply
	used     map[int64]bool      // a late reply just fired for the chat: do not postpone again
	noticing map[int64]bool      // chats in the "read pause" phase
	phases   map[int64]phaseInfo // what each waiting chat is doing, for the panel
}

type session struct {
	mu    sync.Mutex // serialises turns
	id    int64
	msgs  []llm.Message
	last  time.Time
	tools *tools.Registry
	chat  telegram.Chat
	fresh bool // true until the first turn (working memory is injected once)
	// unlocked lazy tool groups survive re-binding of the registry within a session.
	unlocked map[string]bool
	// thread is the forum topic the chat's latest unread message came from; sends without a reply go there.
	thread int64
	// notes are things that happened to old messages (reactions, edits); shown in the next turn, no LLM call of their own.
	nmu   sync.Mutex
	notes []note
	// rosterAt is when the member list of the chat was last put into the prompt.
	rosterAt time.Time
}

// New initialises internal state of a (fill the exported fields first).
func New(a *Agent) *Agent {
	a.sessions = map[int64]*session{}
	a.timers = map[int64]*time.Timer{}
	a.later = map[int64]time.Time{}
	a.used = map[int64]bool{}
	a.noticing = map[int64]bool{}
	return a
}

// SystemPrompt is system + character_base + <your_appearance> (AppBase::getSystemPrompt).
func (a *Agent) SystemPrompt() string {
	return a.Prompts.Get(prompts.System) + "\n\n" + a.Prompts.Get(prompts.CharacterBase) +
		"\n\n<your_appearance>\n" + a.Prompts.Get(prompts.CharacterAppearance) + "\n</your_appearance>"
}

// Run processes Telegram updates until ctx ends, then dumps all open sessions.
func (a *Agent) Run(ctx context.Context) {
	a.runCtx = ctx
	var wg sync.WaitGroup
	wg.Add(2)
	go func() { defer wg.Done(); a.idleLoop(ctx) }()
	go func() { defer wg.Done(); a.proactiveLoop(ctx) }()

	// handle messages that arrived while we were offline
	if chats, err := a.TG.Chats(ctx, 100); err == nil {
		for _, c := range chats {
			if c.Unread > 0 {
				a.schedule(ctx, c.ID)
			}
		}
	}

	updates := a.TG.Updates()
	var events <-chan telegram.Event // nil (blocks forever) when the client does not report them
	if es, ok := a.TG.(telegram.EventSource); ok {
		events = es.Events()
	}
loop:
	for {
		select {
		case <-ctx.Done():
			break loop
		case m, ok := <-updates:
			if !ok {
				break loop
			}
			a.Metrics.Inc("kuni_telegram_messages_received_total", 1, nil)
			log.Printf("agent: incoming message in chat %d from %q (%d chars)", m.ChatID, m.SenderName, len(m.Text))
			a.schedule(ctx, m.ChatID)
		case ev := <-events:
			a.onEvent(ctx, ev)
		}
	}
	wg.Wait()

	// graceful shutdown: give the LLM time to dump the remaining context.
	dumpCtx, cancel := context.WithTimeout(context.Background(), 3*time.Minute)
	defer cancel()
	a.DumpAll(dumpCtx)
}

// schedule debounces bursts of messages, then handles the chat once.
func (a *Agent) schedule(ctx context.Context, chatID int64) {
	delay := a.Cfg.Get().DebounceWindow
	if c := a.Cfg.Get(); c.GroupDebounce > delay {
		if ch, err := a.TG.Chat(ctx, chatID); err == nil && ch.Kind != telegram.ChatPrivate {
			delay = c.GroupDebounce
		}
	}
	a.mu.Lock()
	defer a.mu.Unlock()
	if until, ok := a.later[chatID]; ok && time.Now().Before(until) {
		return // she is not looking at this chat yet; new messages just wait with the old ones
	}
	if t, ok := a.timers[chatID]; ok {
		t.Stop()
	}
	a.setPhaseLocked(chatID, "waiting", time.Time{})
	a.timers[chatID] = time.AfterFunc(delay, func() {
		if ctx.Err() != nil {
			return
		}
		defer a.endPhase(chatID)
		defer func() {
			if r := recover(); r != nil {
				log.Printf("agent: chat %d: PANIC recovered: %v", chatID, r)
			}
		}()
		if err := a.HandleChat(ctx, chatID); err != nil {
			log.Printf("agent: chat %d: %v", chatID, err)
		}
	})
}

func (a *Agent) getSession(id int64) *session {
	a.mu.Lock()
	defer a.mu.Unlock()
	s := a.sessions[id]
	if s == nil {
		s = &session{id: id, fresh: true}
		a.sessions[id] = s
		a.Metrics.Set("kuni_sessions_active", float64(len(a.sessions)), nil)
	}
	return s
}

func (a *Agent) baseTools(d tools.Deps, proactive bool) []tools.Tool {
	ts := tools.GlobalTools(d, proactive)
	if d.GoToSleep != nil {
		ts = append(ts, tools.GoToSleepTool(d))
	}
	if !proactive {
		// a notification turn starts with the chat already opened and rendered: #open_chat would only
		// burn a (slow, paid) round re-opening the same chat.
		kept := ts[:0]
		for _, t := range ts {
			if t.Name != "open_chat" {
				kept = append(kept, t)
			}
		}
		ts = kept
	}
	ts = append(ts, tools.WaitTools()...)
	if a.Cfg.Get().MoodEnabled && d.Mood != nil {
		ts = append(ts, tools.MoodTool(d))
	}
	return append(ts, tools.AskTool(d))
}

// HandleChat reads unread messages of a chat and lets the model act on them.
func (a *Agent) HandleChat(ctx context.Context, chatID int64) error {
	if a.paused.Load() {
		return nil // paused from the admin panel: messages stay unread and are handled on resume
	}
	cfg := a.Cfg.Get()
	if !tools.Accessible(cfg, chatID) {
		log.Printf("agent: chat %d ignored by lockdown=%q (owner chat id is %d)", chatID, cfg.Lockdown, cfg.PapikChatID)
		_ = a.TG.MarkRead(ctx, chatID)
		return nil
	}
	chat, err := a.TG.Chat(ctx, chatID)
	if err != nil {
		return err
	}
	unread, err := a.TG.Unread(ctx, chatID)
	if err != nil || len(unread) == 0 {
		log.Printf("agent: chat %d: nothing to handle (unread=%d, err=%v)", chatID, len(unread), err)
		return err
	}
	if !a.worthWaking(ctx, chat, unread) {
		// not meant for her: she reads it (marks read) but no paid model call is made
		_ = a.TG.MarkRead(ctx, chatID)
		a.Metrics.Inc("kuni_group_skipped_total", 1, nil)
		return nil
	}
	s := a.getSession(chatID)
	// living presence: she may only look at the chat later, and she needs a moment to notice it at all.
	if until, ok := a.postponedUntil(chatID); ok && time.Now().Before(until) {
		return nil
	}
	if !a.beginNoticing(chatID) {
		return nil // another call is already waiting to open this chat; it will see everything unread
	}
	plan := a.presenceFor(chat, s, time.Now())
	if plan.Late > 0 && !a.takeUsed(chatID) {
		a.endNoticing(chatID)
		a.postpone(ctx, chatID, plan.Late)
		return nil
	}
	a.setPhase(chatID, "noticing", time.Time{})
	ok := a.readPause(ctx, plan.Read)
	a.endNoticing(chatID)
	if !ok {
		return nil
	}
	if unread, err = a.TG.Unread(ctx, chatID); err != nil || len(unread) == 0 {
		return err
	}
	log.Printf("agent: handling chat %d %q: %d unread (noticed after %s)", chatID, chat.Title, len(unread), plan.Read.Round(100*time.Millisecond))
	s.mu.Lock()
	defer s.mu.Unlock()
	defer a.goOnline(ctx)()
	a.setPhase(chatID, "thinking", time.Time{})

	view, err := a.renderChat(ctx, s, chat, unread)
	if err != nil {
		return err
	}
	_ = a.TG.MarkRead(ctx, chatID)
	s.msgs = append(s.msgs, llm.Message{Role: "user", Content: view})
	return a.runTurn(ctx, s)
}

// renderChat builds the text the model sees when it opens a chat and (re)binds the chat tools.
func (a *Agent) renderChat(ctx context.Context, s *session, chat telegram.Chat, unread []telegram.Message) (string, error) {
	now := time.Now()
	d := a.depsFor(s)
	s.chat = chat
	s.thread = 0
	for _, m := range unread {
		if !m.Outgoing {
			s.thread = m.ThreadID
		}
	}
	s.tools = a.newRegistry(s, d, chat, false, unread)

	var b strings.Builder
	b.WriteString(a.moodBlock())
	b.WriteString(a.sleepBlock())
	if s.fresh {
		s.fresh = false
		if wm, _ := (memory.WorkingMemory{Path: a.Cfg.Get().WorkingMemoryFile}).Load(); strings.TrimSpace(wm) != "" {
			b.WriteString("<things_to_remember>\n" + wm + "\n</things_to_remember>\n\n")
		}
	}
	// thoughts popping up: diary entries related to what was just read (RAG).
	if rec := a.recall(ctx, unread); rec != "" {
		b.WriteString(rec + "\n")
	}
	b.WriteString(a.groupInfo(ctx, s, chat))
	b.WriteString(a.takeNotes(s, now))
	fmt.Fprintf(&b, "You switched to the chat %q in Telegram. You see last messages:\n", chat.Title)
	// a continuing session already holds the earlier messages: don't repeat all of them on every turn.
	earlier := 12
	if len(s.msgs) > 0 {
		earlier = 3
		if chat.Kind != telegram.ChatPrivate {
			earlier = 15 // she skips group talk that is not for her, so on waking she needs the recent context
		}
	}
	if hist, _ := a.TG.History(ctx, chat.ID, 0, earlier+len(unread), 0); len(hist) > len(unread) {
		older := hist[:len(hist)-len(unread)]
		b.WriteString("<earlier_messages>\n" + a.UI.FormatMessages(ctx, older, now) + "</earlier_messages>\n")
	}
	b.WriteString(a.UI.FormatMessages(ctx, unread, now))
	b.WriteString(modalityHint(a.Cfg.Get(), unread))
	b.WriteString(a.chatInstructions(chat))
	return b.String(), nil
}

// groupInfo describes who is in a group so the model does not confuse people. It is repeated only
// every rosterEvery (the session keeps the earlier text).
const rosterEvery = 20 * time.Minute

func (a *Agent) groupInfo(ctx context.Context, s *session, chat telegram.Chat) string {
	if chat.Kind != telegram.ChatGroup || !chat.IsMember || time.Since(s.rosterAt) < rosterEvery {
		return ""
	}
	cctx, cancel := context.WithTimeout(ctx, 10*time.Second)
	defer cancel()
	ms, err := a.TG.Members(cctx, chat.ID, 25)
	if err != nil || len(ms) == 0 {
		return ""
	}
	s.rosterAt = time.Now()
	owner, me := a.Cfg.Get().PapikChatID, a.TG.MyID()
	var b strings.Builder
	fmt.Fprintf(&b, "<chat_info type=\"group\" title=%q you_are_admin=\"%t\">\n", chat.Title, chat.IsAdmin)
	for _, m := range ms {
		b.WriteString(llmui.FormatMember(m, me, owner) + "\n")
	}
	b.WriteString("</chat_info>\n")
	return b.String()
}

func chatToolList(d tools.Deps, chat telegram.Chat) []tools.Tool {
	r := tools.ChatTools(d, chat)
	var out []tools.Tool
	for _, n := range r.Names() {
		t, _ := r.Get(n)
		out = append(out, t)
	}
	return out
}

func (a *Agent) chatInstructions(chat telegram.Chat) string {
	epilogue := a.Prompts.Get(prompts.MessagesEpilogue)
	switch {
	case !chat.IsMember && chat.Kind != telegram.ChatPrivate:
		return fmt.Sprintf("\n<instructions>\nYou are NOT a member of %q. You can't send messages here; you can only #react_with_emoji to messages, or use #join_chat to become a member.\n</instructions>\n", chat.Title)
	case chat.Kind == telegram.ChatChannel:
		return fmt.Sprintf("\n<instructions>\nYou are in telegram channel called %q.\nPay close attention to these messages. Acquire context from them. You can't respond in telegram channels (#send_telegram_message is not available). Instead, do what you usually do when reading newsletters: reflect and reason on them.\nSome channels have reactions enabled: you can sometimes #react_with_emoji.\nIf a post is genuinely interesting or relevant to someone you know, you can forward it with #forward_message. Be selective. Do NOT forward ads, sponsored posts, or low-value content.\n</instructions>\n", chat.Title)
	case chat.Kind == telegram.ChatGroup:
		return fmt.Sprintf("\n<instructions>\nYou are in group chat called %q.\n\n%s\n\n%s\n</instructions>\n", chat.Title, groupRules, epilogue)
	default:
		return fmt.Sprintf("\n<instructions>\nYou are in private chat with %s (also known as direct messages or DM).\n\n%s\n</instructions>\n", chat.Title, epilogue)
	}
}

// groupRules keeps the character from answering the wrong person or butting into other people's talk.
const groupRules = `GROUP RULES. Many people talk here, so first work out WHO speaks to WHOM: read sender, reply_to_sender/reply_to_text and addressed_to_you on every message, and the earlier_messages.
- Answer when addressed_to_you="true", when a question is aimed at everybody and you can add something real, or when your owner is involved. A message that is addressed to someone else is not yours: stay out of it (do nothing and wait, or just react).
- Never mix people up: the author of a message is its sender, ids are in chat_info / #chat_members / #user_info. If you are unsure who meant what, check #chat_members or #view_messages_around before answering instead of guessing.
- Reply with reply_to_message_id to the message you answer, and talk to that person by their name. In groups with topics (messages have topic_id) the reply_to_message_id also keeps your answer in the right topic.
- To tag a person so they get a notification, write @username in the text (usernames are in #chat_members). If they have no username write [Name](tg://user?id=USER_ID). Tag only when you really need that person's attention.
- A <poll> shows the options with numbers: you may #vote_poll if you have an opinion, or #create_poll to settle a group question. A <document> can be opened with #read_document, a link with #read_link.
- What you know from private chats, the diary or the owner's commands stays private: never bring it up in a group.`

// recall queries the diary with the text of the unread messages.
func (a *Agent) recall(ctx context.Context, msgs []telegram.Message) string {
	if a.Diary == nil {
		return ""
	}
	var parts []string
	for _, m := range msgs {
		if strings.TrimSpace(m.Text) != "" {
			parts = append(parts, m.SenderName+": "+m.Text)
		}
	}
	if len(parts) == 0 {
		return ""
	}
	if len(parts) > 5 {
		parts = parts[len(parts)-5:]
	}
	vec, err := a.LLM.Embedding(ctx, strings.Join(parts, "\n"))
	if err != nil {
		log.Printf("agent: recall embedding: %v", err)
		return ""
	}
	entries, err := a.Diary.Load()
	if err != nil {
		return ""
	}
	related, err := a.Diary.Query(ctx, entries, vec, a.Cfg.Get().MaxRelatedEntries)
	if err != nil || len(related) == 0 {
		return ""
	}
	var b strings.Builder
	b.WriteString("<memories_that_popped_up_in_mind>\n")
	for _, r := range related {
		fmt.Fprintf(&b, "<memory>\n%s\n</memory>\n", r.Entry.Body)
	}
	b.WriteString("</memories_that_popped_up_in_mind>\n")
	return b.String()
}

func (a *Agent) depsFor(s *session) tools.Deps {
	d := a.Deps
	d.OpenChat = func(ctx context.Context, id int64) (string, error) { return a.openChat(ctx, s, id) }
	if a.Auto != nil && a.Cfg.Get().AutonomyEnabled {
		d.GoToSleep = a.goToSleep
	}
	return d
}

// openChat is the open_chat tool backend for proactive sessions.
func (a *Agent) openChat(ctx context.Context, s *session, chatID int64) (string, error) {
	chat, err := a.TG.Chat(ctx, chatID)
	if err != nil {
		return "", fmt.Errorf("chat %d not found", chatID)
	}
	unread, _ := a.TG.Unread(ctx, chatID)
	hist, _ := a.TG.History(ctx, chatID, 0, 20, 0)
	var b strings.Builder
	fmt.Fprintf(&b, "You switched to the chat %q in Telegram. You see last messages:\n", chat.Title)
	b.WriteString(a.UI.FormatMessages(ctx, hist, time.Now()))
	b.WriteString(a.chatInstructions(chat))
	d := a.depsFor(s)
	s.chat = chat
	s.tools = a.newRegistry(s, d, chat, true, unread)
	if len(unread) > 0 {
		_ = a.TG.MarkRead(ctx, chatID)
	}
	return b.String(), nil
}

// runTurn is the LLM <-> tools loop. The model's plain-text answer is its private
// "thought"; only tool calls have effects.
func (a *Agent) runTurn(ctx context.Context, s *session) error {
	cfg := a.Cfg.Get()
	a.Metrics.Inc("kuni_agent_turns_total", 1, nil)
	system := a.SystemPrompt()
	a.compact(ctx, s)
	seen := map[string]bool{}
	for round := 0; round < cfg.MaxToolRounds; round++ {
		rctx := llm.WithPurpose(ctx, "reply")
		forced := cfg.ForceTools // every round: plain-text answers are never delivered to Telegram
		if forced {
			rctx = llm.WithToolChoice(rctx, "required")
		}
		stopTyping := a.typeWhileThinking(ctx, s)
		reply, err := a.LLM.Complete(rctx, system, a.outgoing(s), s.tools.Defs())
		stopTyping()
		if err != nil && forced {
			// the provider may not support tool_choice: retry without forcing
			log.Printf("agent: chat %d: forced tool call failed (%v), retrying without", s.id, err)
			reply, err = a.LLM.Complete(llm.WithPurpose(ctx, "reply"), system, a.outgoing(s), s.tools.Defs())
		}
		if err != nil {
			return err
		}
		if strings.TrimSpace(reply.Content) == "" && len(reply.ToolCalls) == 0 {
			log.Printf("agent: chat %d round %d: empty answer from the model, retrying", s.id, round)
			continue // blank answer from a local model: ask again
		}
		s.msgs = append(s.msgs, reply)
		s.last = time.Now()
		var names []string
		for _, c := range reply.ToolCalls {
			names = append(names, c.Function.Name)
		}
		log.Printf("agent: chat %d round %d: tools=%v thought=%q", s.id, round, names, util.Trunc(reply.Content, 160))
		if len(reply.ToolCalls) == 0 {
			return nil
		}
		onlyWait, hasWait := true, false
		for _, c := range reply.ToolCalls {
			switch c.Function.Name {
			case "wait", "pause":
				hasWait = true
			case "change_mood": // bookkeeping only, does not count as an action
			default:
				onlyWait = false
			}
		}
		onlyWait = onlyWait && hasWait
		chatLabel := s.chat.Title
		if s.id == 0 {
			chatLabel = "proactive"
		}
		for _, c := range reply.ToolCalls {
			start := time.Now()
			key := c.Function.Name + "|" + string(c.Function.Arguments)
			var out string
			if c.Function.Name == "ask" && seen["ask"] {
				out = "You already consulted memory this turn. Answer now with send_telegram_message."
			} else if seen[key] && c.Function.Name != "send_telegram_message" && c.Function.Name != "wait" && c.Function.Name != "pause" {
				out = "You already called this with the same arguments and have the result above. Do not repeat it: answer now with send_telegram_message."
			} else {
				out = s.tools.Call(telegram.WithThread(ctx, s.thread), c.Function.Name, c.Function.Arguments)
			}
			seen[key] = true
			if c.Function.Name == "ask" {
				seen["ask"] = true
			}
			s.msgs = append(s.msgs, llm.Message{Role: "tool", ToolCallID: c.ID, Content: out})
			a.Metrics.Inc("kuni_tool_calls_total", 1, map[string]string{"tool": c.Function.Name})
			// names used by the original Grafana dashboard
			labels := map[string]string{"tool": c.Function.Name, "function": c.Function.Name, "chat": chatLabel}
			a.Metrics.Inc("tool_call_total", 1, labels)
			a.Metrics.Set("tool_call_response_time_seconds_gauge", time.Since(start).Seconds(), labels)
		}
		if onlyWait {
			return nil // the model chose to stay silent
		}
		if cfg.StopAfterSend && sentOnly(reply.ToolCalls, s.msgs) {
			return nil // said what it wanted; no extra round just to hear "done"
		}
	}
	log.Printf("agent: chat %d: tool round limit (%d) reached", s.id, cfg.MaxToolRounds)
	return nil
}

// trim keeps the last n messages, starting at a user message so tool-call pairs stay intact.
func trim(msgs []llm.Message, n int) []llm.Message {
	if len(msgs) <= n {
		return msgs
	}
	cut := len(msgs) - n
	for cut < len(msgs) && msgs[cut].Role != "user" {
		cut++
	}
	if cut >= len(msgs) {
		return msgs[len(msgs)-1:]
	}
	return msgs[cut:]
}

// idleLoop dumps sessions that have been silent for SessionIdle.
func (a *Agent) idleLoop(ctx context.Context) {
	t := time.NewTicker(30 * time.Second)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
			idle := a.Cfg.Get().SessionIdle
			var ids []int64
			a.mu.Lock()
			for id, s := range a.sessions {
				if !s.last.IsZero() && time.Since(s.last) >= idle {
					ids = append(ids, id)
				}
			}
			a.mu.Unlock()
			for _, id := range ids {
				if err := a.dump(ctx, id); err != nil {
					log.Printf("agent: dump chat %d: %v", id, err)
				}
			}
		}
	}
}

// dump saves one session to the diary/working memory and forgets it.
func (a *Agent) dump(ctx context.Context, id int64) error {
	a.mu.Lock()
	s := a.sessions[id]
	a.mu.Unlock()
	if s == nil {
		return nil
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	msgs := flatten(s.msgs)
	if len(msgs) > 0 && a.Dumper != nil {
		a.Dumper.WM = memory.WorkingMemory{Path: a.Cfg.Get().WorkingMemoryFile}
		if err := a.Dumper.DumpSession(ctx, a.SystemPrompt(), msgs); err != nil {
			return err // keep the session; retry on the next idle tick
		}
	}
	a.mu.Lock()
	delete(a.sessions, id)
	a.Metrics.Set("kuni_sessions_active", float64(len(a.sessions)), nil)
	a.mu.Unlock()
	return nil
}

// DumpAll flushes every open session (shutdown).
func (a *Agent) DumpAll(ctx context.Context) {
	a.mu.Lock()
	ids := make([]int64, 0, len(a.sessions))
	for id := range a.sessions {
		ids = append(ids, id)
	}
	a.mu.Unlock()
	for _, id := range ids {
		if err := a.dump(ctx, id); err != nil {
			log.Printf("agent: dump chat %d: %v", id, err)
		}
	}
}

// flatten turns tool-calling history into a plain transcript: dump calls have no tools,
// and many servers reject tool messages without a tools parameter.
func flatten(msgs []llm.Message) []llm.Message {
	if len(msgs) == 0 {
		return nil
	}
	var b strings.Builder
	for _, m := range msgs {
		switch m.Role {
		case "user":
			b.WriteString(m.Content + "\n")
		case "assistant":
			if strings.TrimSpace(m.Content) != "" {
				b.WriteString("[your thoughts] " + m.Content + "\n")
			}
			for _, c := range m.ToolCalls {
				fmt.Fprintf(&b, "[you called #%s %s]\n", c.Function.Name, c.Function.Arguments)
			}
		case "tool":
			b.WriteString("[tool result] " + m.Content + "\n")
		}
	}
	text := b.String()
	if len(text) > 60000 {
		text = text[len(text)-60000:]
	}
	return []llm.Message{{Role: "user", Content: "<session_transcript>\n" + text + "\n</session_transcript>"}}
}

// proactiveLoop periodically lets the model look through its chats on its own. With [autonomy] enabled the pause
// is random, nights and sleep are respected and the daily limits apply; otherwise telegram.proactive_interval_secs rules.
func (a *Agent) proactiveLoop(ctx context.Context) {
	for {
		cfg := a.Cfg.Get()
		wait := time.Minute // config may be enabled later via hot reload
		switch {
		case cfg.AutonomyEnabled && a.Auto != nil:
			lo, hi := cfg.AutonomyMinMins, cfg.AutonomyMaxMins
			if lo < 1 {
				lo = 1
			}
			if hi < lo {
				hi = lo
			}
			wait = time.Duration(lo+rand.Intn(hi-lo+1)) * time.Minute
		case cfg.Proactive > 0:
			wait = cfg.Proactive
		}
		select {
		case <-ctx.Done():
			return
		case <-time.After(wait):
		}
		cfg = a.Cfg.Get()
		switch {
		case cfg.AutonomyEnabled && a.Auto != nil:
			if err := a.ActAutonomously(ctx); err != nil {
				log.Printf("agent: autonomy: %v", err)
			}
		case cfg.Proactive > 0:
			if err := a.ActProactively(ctx); err != nil {
				log.Printf("agent: proactive: %v", err)
			}
		}
	}
}

// ActProactively runs a session in which the model decides whom to write to.
func (a *Agent) ActProactively(ctx context.Context) error {
	if a.paused.Load() || a.Usage.Over(a.Cfg.Get().DailyTokenLimit) {
		return nil
	}
	s := a.getSession(0)
	s.mu.Lock()
	defer s.mu.Unlock()
	d := a.depsFor(s)
	s.tools = tools.NewRegistry(a.baseTools(d, true)...)
	msg := "You have some free time and nobody is writing to you right now. Check your chats with #get_telegram_chats " +
		"(open one with #open_chat) and decide if there is somebody you would like to write to, or something to revisit " +
		"from <things_to_remember>. If there is nothing worth doing, just reflect briefly and do nothing."
	if s.fresh {
		s.fresh = false
		if wm, _ := (memory.WorkingMemory{Path: a.Cfg.Get().WorkingMemoryFile}).Load(); strings.TrimSpace(wm) != "" {
			msg = "<things_to_remember>\n" + wm + "\n</things_to_remember>\n\n" + msg
		}
	}
	msg = fmt.Sprintf("It is %s.\n%s%s", time.Now().Format("Mon Jan 2 15:04"), a.moodBlock(), msg)
	s.msgs = append(s.msgs, llm.Message{Role: "user", Content: msg})
	return a.runTurn(ctx, s)
}

var _ = util.TimeAgo

// SessionSummaries describes open sessions for the debug page.
func (a *Agent) SessionSummaries() []string {
	a.mu.Lock()
	defer a.mu.Unlock()
	var out []string
	for id, s := range a.sessions {
		title := "proactive"
		if id != 0 {
			title = s.chat.Title
		}
		out = append(out, fmt.Sprintf("%s (id %d): %d messages, last activity %s", title, id, len(s.msgs), util.TimeAgo(s.last, time.Now())))
	}
	return out
}

// goOnline shows the account as online while a turn runs (user mode only) and
// returns a func that schedules going offline again shortly after the last turn.
func (a *Agent) goOnline(ctx context.Context) func() {
	p, ok := a.TG.(interface {
		SetOnline(ctx context.Context, online bool)
	})
	if !ok {
		return func() {}
	}
	if a.active.Add(1) == 1 {
		p.SetOnline(ctx, true)
	}
	return func() {
		a.active.Add(-1)
		time.AfterFunc(a.offlineAfter(), func() {
			if a.active.Load() == 0 {
				c, cancel := context.WithTimeout(context.Background(), 10*time.Second)
				defer cancel()
				p.SetOnline(c, false)
			}
		})
	}
}

// Lazy tool groups (see tools.Registry.Lazy): rarely used tools cost no prompt tokens until needed.
var lazyGroups = map[string][]string{
	"media":  {"take_photo", "record_audio", "sticker_list", "sticker_send", "sticker_save", "get_chat_photo"},
	"edit":   {"edit_message_text", "remove_message", "forward_message", "view_messages_around"},
	"admin":  {"group_admin_remove_message", "group_admin_ban_user", "group_admin_set_user_tag", "leave_chat", "remove_and_ban_chat"},
	"search": {"search_messages"},
	"read":   {"read_link", "read_document"},
	"polls":  {"create_poll", "vote_poll", "pin_message", "unpin_message"},
	"system": {"shell", "download_telegram_file", "send_file", "list_all_chats", "read_chat"},
}

var lazyDesc = map[string]string{
	"media":  "photos/selfies, voice messages, stickers, chat avatar",
	"edit":   "edit/delete own messages, forward, view message context",
	"admin":  "moderation, leave chat, ban",
	"search": "search messages across chats",
	"read":   "open links and read files (documents) people sent",
	"polls":  "create polls, vote in polls, pin/unpin messages",
	"system": "shell commands, downloads, files, archives, read any chat",
}

var sysWords = regexp.MustCompile(`(?i)скача|загруз|запуст|команд|терминал|консол|файл|архив|распак|установ|удал|чат|переписк|download|run |install|shell|folder|zip|curl|wget|git |ls\b`)

var linkWords = regexp.MustCompile(`(?i)https?://|www\.|\.(com|ru|org|net|io|me|ai)/|ссылк|статья|статью|link|article`)

var pollWords = regexp.MustCompile(`(?i)опрос|голосован|проголосуй|закреп|poll|\bvote\b|\bpin\b`)

var mediaWords = regexp.MustCompile(`(?i)фот|селфи|голос|войс|стикер|аватар|photo|selfie|voice|sticker|picture|pic\b`)

// newRegistry builds the tool set of a chat, hiding rarely used groups unless lazy_tools is off.
// Groups the incoming messages obviously call for (media, voice, stickers...) are unlocked up front.
func (a *Agent) newRegistry(s *session, d tools.Deps, chat telegram.Chat, proactive bool, unread []telegram.Message) *tools.Registry {
	all := append(append(a.baseTools(d, proactive), chatToolList(d, chat)...), tools.OwnerTools(d, chat)...)
	if tools.IsOwnerChat(d, chat.ID) { // list_all_chats supersedes it; two near-identical tools made the model loop
		kept := all[:0:0]
		for _, t := range all {
			if t.Name != "get_telegram_chats" {
				kept = append(kept, t)
			}
		}
		all = kept
	}
	r := tools.NewRegistry(all...)
	if !a.Cfg.Get().LazyTools {
		return r
	}
	if s.unlocked == nil {
		s.unlocked = map[string]bool{}
	}
	r.Lazy(lazyGroups, lazyDesc)
	for g := range s.unlocked {
		r.Unlock(g)
	}
	r.OnUnlock = func(g string) { s.unlocked[g] = true }
	if chat.Kind == telegram.ChatGroup { // view_messages_around is what keeps group context right
		r.Unlock("edit")
	}
	if tools.IsOwnerChat(d, chat.ID) { // the owner gets everything at hand, no more_tools round-trip
		for g := range lazyGroups {
			r.Unlock(g)
		}
	}
	for _, m := range unread {
		if tools.IsOwnerChat(d, chat.ID) && !m.Outgoing && (m.FileID != "" || sysWords.MatchString(m.Text)) {
			r.Unlock("system")
		}
		if m.Media != telegram.MediaNone || mediaWords.MatchString(m.Text) {
			r.Unlock("media")
		}
		if !m.Outgoing && (m.Media == telegram.MediaDocument || linkWords.MatchString(m.Text)) {
			r.Unlock("read")
		}
		if !m.Outgoing && (m.Media == telegram.MediaPoll || pollWords.MatchString(m.Text)) {
			r.Unlock("polls")
		}
	}
	return r
}

const compactSystem = `You compress an old part of a chat session of an AI character so that it can continue the conversation.
Write a dense summary in the language of the conversation, in the character's first person. Keep: who said what that matters,
facts about people, plans, promises, open questions, the emotional tone, and what the character already answered (so it does not
repeat itself). Drop greetings, filler and tool mechanics. At most 250 words. Output only the summary.`

// compact replaces the old part of a long session with a short summary (history_keep verbatim messages stay).
// On any failure the history is left as is (trim still bounds it).
func (a *Agent) compact(ctx context.Context, s *session) {
	cfg := a.Cfg.Get()
	keep := cfg.HistoryKeep
	if keep <= 0 {
		return
	}
	size := 0
	for _, m := range s.msgs {
		size += msgSize(m)
	}
	if len(s.msgs) < 2*keep && (cfg.ContextChars <= 0 || size < 2*cfg.ContextChars) {
		return
	}
	cut := len(s.msgs) - keep
	if cut < 0 {
		cut = 0
	}
	for cut < len(s.msgs) && s.msgs[cut].Role != "user" {
		cut++
	}
	if cut <= 1 || cut >= len(s.msgs) {
		return
	}
	var sum string
	if old := flatten(slimHistory(s.msgs[:cut], cfg.ToolResultChars)); len(old) > 0 {
		sum = a.compactSummary(ctx, old)
	}
	if sum == "" {
		// summarising keeps failing: forget the old part rather than pay for it forever
		sum = "(older part of this conversation was dropped; rely on the diary and on the messages below)"
	}
	head := llm.Message{Role: "user", Content: "<conversation_so_far>\n" + sum + "\n</conversation_so_far>"}
	s.msgs = append([]llm.Message{head}, s.msgs[cut:]...)
}

// typeWhileThinking keeps the "typing…" indicator on in private chats while a model call is running.
func (a *Agent) typeWhileThinking(ctx context.Context, s *session) func() {
	if !a.Cfg.Get().TypingThinking || s.id == 0 || s.chat.Kind != telegram.ChatPrivate {
		return func() {}
	}
	c, cancel := context.WithCancel(ctx)
	go func() {
		for {
			_ = a.TG.Typing(c, s.id)
			select {
			case <-c.Done():
				return
			case <-time.After(4 * time.Second):
			}
		}
	}()
	return cancel
}

// sentOnly: the round consisted of sent messages (and reactions) that all succeeded.
func sentOnly(calls []llm.ToolCall, msgs []llm.Message) bool {
	sent := false
	for _, c := range calls {
		switch c.Function.Name {
		case "send_telegram_message":
			sent = true
		case "react_with_emoji", "change_mood":
		default:
			return false
		}
	}
	if !sent {
		return false
	}
	for i := len(msgs) - 1; i >= 0 && len(msgs)-i <= len(calls); i-- {
		if msgs[i].Role == "tool" && strings.Contains(strings.ToLower(msgs[i].Content), "error") {
			return false
		}
	}
	return true
}

// Paused reports whether replies are paused.
func (a *Agent) Paused() bool { return a.paused.Load() }

// SetPaused pauses or resumes replying. Messages that arrive while paused stay unread
// and every chat with unread messages is handled right after resuming.
func (a *Agent) SetPaused(p bool) {
	was := a.paused.Swap(p)
	log.Printf("agent: paused=%v", p)
	if was && !p && a.runCtx != nil {
		ctx := a.runCtx
		go func() {
			chats, err := a.TG.Chats(ctx, 100)
			if err != nil {
				return
			}
			for _, c := range chats {
				if c.Unread > 0 {
					a.schedule(ctx, c.ID)
				}
			}
		}()
	}
}

// moodBlock is the <mood> line put in front of every turn ("" when the scale is off).
func (a *Agent) moodBlock() string {
	cfg := a.Cfg.Get()
	if !cfg.MoodEnabled || a.Deps.Mood == nil {
		return ""
	}
	return mood.Prompt(a.Deps.Mood.Level(), cfg.PapikName)
}
