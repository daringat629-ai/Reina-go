// Package prompts keeps every text the model is given: the prompts of the memory, vision and image
// engines, her persona, and the instructions the program used to keep in its own code (tones, chat rules,
// what to do in her free time, how to summarise a conversation...). Defaults are written to
// <dir> on first run and the files are then the source of truth: the front matter is stripped, ${CHARACTER_NAME}
// and the like are expanded, and a changed file is picked up without a restart.
//
// Layout of <dir>:
//
//	*.md          the original prompts and her persona
//	chat/*.md     what she is told inside a chat: the tones, the rules, the epilogue of the owner's chat
//	engine/*.md   the program's own jobs: free time, background work, summaries, person cards, helpers
//
// A file that is missing is written from the built-in default; existing files are never overwritten (except a known
// outdated default nobody edited, see outdated).
package prompts

import (
	"crypto/sha256"
	"embed"
	"encoding/hex"
	"io/fs"
	"os"
	"path"
	"path/filepath"
	"sort"
	"strings"
	"sync"
)

//go:embed defaults
var defaults embed.FS

// Names of all prompts.
const (
	System                    = "system"
	CharacterBase             = "character_base"
	CharacterAppearance       = "character_appearance"
	PhotoToText               = "photo_to_text"
	StickerToText             = "sticker_to_text"
	AntiRepeat                = "anti_repeat"
	DiarySave                 = "diary_save"
	SleepConsolidator         = "sleep_consolidator"
	RecordAudioSpeech         = "record_audio_speech"
	MessagesEpilogue          = "messages_epilogue"
	ImageEngineerSystem       = "image_engineer_system"
	ImageEngineerInstructions = "image_engineer_instructions"
	ImageAssessSystem         = "image_assess_system"
	// OwnerPowers is appended to the system prompt only in the owner's private chat and in background jobs.
	OwnerPowers = "owner_powers"

	// what she is told inside a chat
	ToneOwner      = "chat/tone_owner"
	ToneGroup      = "chat/tone_group"
	ToneContact    = "chat/tone_contact"
	ToneStranger   = "chat/tone_stranger"
	RulesVoice     = "chat/rules_voice"
	RulesCode      = "chat/rules_code"
	RulesFollowUp  = "chat/rules_follow_up"
	RulesGroup     = "chat/rules_group"
	OwnerEpilogue  = "chat/owner_epilogue"
	ChannelRules   = "chat/channel"    // ${CHAT_TITLE}
	NotMemberRules = "chat/not_member" // ${CHAT_TITLE}
	AccountRules   = "chat/account"    // ${BOT}

	// the program's own jobs
	Autonomy          = "engine/autonomy" // ${LEFT}
	Proactive         = "engine/proactive"
	WorkRun           = "engine/work_run"  // ${JOB} ${RULES}
	WorkSelf          = "engine/work_self" // ${GOALS} ${DONE} ${RULES}
	Compact           = "engine/compact"
	LearnPersonSystem = "engine/learn_person_system"
	LearnPerson       = "engine/learn_person" // ${NOW}
	DescribePerson    = "engine/describe_person"
	HintPromise       = "engine/hint_promise"
	HintReport        = "engine/hint_report"
	HintRefusal       = "engine/hint_refusal"
	AskSystem         = "engine/ask_system"
	DelegateSystem    = "engine/delegate_system"
	CodeSystem        = "engine/code_system"
	LookAtScreen      = "engine/look_at_screen"
	ProxySystem       = "engine/proxy_system"
)

// Vars are the ${VARIABLES} substituted into prompts.
type Vars struct {
	CharacterName     string
	CharacterNickname string
	PapikName         string
}

// outdated lists, per file, the SHA-256 of default texts that shipped before. A prompt file on disk that is byte for
// byte one of them was never edited by the owner, so it is replaced by the current default (the old one is kept as
// <name>.md.old). A file the owner changed even by one character is never touched.
var outdated = map[string][]string{
	"chat/rules_code.md": {"e1a4013520cde37d926960eef834b80a905ea5c5bc0d33f7f5a14aa99aabdee7"},
	"character_appearance.md": {"6e726bb0354932b85f608f920acf6cbd747b25880210cc77c1d716c175e13727",
		"21b2f6eaa77aa9dece03180eda2ffa76623522b1c4e34cd41839b1ba4d4f6bea"},
	// the 34 KB template character ("soft yandere"), replaced by a minimal core: the rest grows from her brain, memory and diary
	"engine/autonomy.md": {"6fed15480689c612364c6cead68750105114d42ff20343082a4ab3ab8f273cb0", "8cc19ba511288f9587808bc0a95a48097b257be603faecf4f902f7e0517fdddb"},
	"character_base.md": {"6ab27430ad4322bcb11918f30072625f0daadf11508263bf247f0e658ab3ff51", "b0f11918b55c0607b1ed54f39b8d4e884db99a0d51fad58c13f21fe543cc7aa2", "d05de294cb3b9f63c87396d6f239b34be40f20a2be498cadd1c693afff32a6b6", "0d887b99023ae5b223c9a4fae219a2ef181fe1ad9b0699c36fab1817455dbf89", "d2e88e11b71631e2bdee0f35b6206daedec00f93fd46fe87e15cc6b41964a8d8", "c17663ab404bd65fab8844a18cbe23c5d9e90ce8dd2df5b84b73915778766fcd",
		// v90: choppy multi-message texting (so replies split again) + sharper, really-toxic default tone
		"832b815e5a1bcf3450329b62039ce74090cb86330e08df3923c0703054df6469", "45244fe5ca5a166e893c627693e5cb5171aa16b52cdcb5a8d75abeb618597325", "23fb7ee183f2fbc49ac606b2b44e7d6d2dd08ae8da594e621e94bf09d4a19d27" /* v93 */},
	// the system prompt that still carried the owner's powers into every chat (now in owner_powers.md)
	"system.md": {"d71c17cbefc229d86ed3ab31078203c572d880e8add9d3cb52d2a5099ef71815",
		// v71: the toxic voice (heavy мат, insults back) replaced by a warm, friendly one
		"d29dda36d681f60d22962bf8c9a6878c411add0407da0e720f3dbaa686f5aec5",
		// v76: the edge is back (sarcasm, biting back), plain text only
		"701d509d17242fa2d13da2da93626bec71ccfe43712c7726ef2bde14b0fbc057", "21c0c62b645d1ea1e2c1b94c40dc791ef93073d1195eb945d2fee3279940d74b" /* v93 */},
	"chat/rules_group.md": {"242358ff0f6d8ad8aa48dc85fd854e9873c8c6a34a0cf0ca50c8fe691837f1de", "6beb8881ee3ff5fc6d6a4547448532e1b3b59d30ae85d4bb9f484a13cf651a80",
		// v90: allow 2-3 short separate messages in groups (splitting) + sharper default edge
		"4c461ca341709b0fefe5f6813fc3c4c08370620c51ecb8014af59e9413dadb7f"},
	"chat/rules_voice.md":    {"f1b7bd83f19fa809b0e461961f5ef9d0b278e19d5279352bf2e747f05aa49a92", "56d8c0eaecf6e8a5d6caddad25dc69276336799e86ae186319a738bf2ae35689", "1b9dc2583ac59c2102f43ae793ba879423cbbfc5153ef166329d82d87977b7b9", "ee6880cfabd54c01a8dd9ddf603036b53cff881d218e44b5fabceb9632dcb74b", "390f21dd996cc9cd1b9a2111024d2d5b2cdc6a2f6f40994481071cfe2a387aaa", "00ba022fd8011cce717ec5cf97893987d7f49adb3b32f44acc2c25b49e62ddd2", "4f45fc8ba2ef61beec3195444bd9a1de0f4b6dd38eb568990eeed36bb7818661", "99c25df12df9d75023a662328c01ea966d4291477f5e4b5946ec6c3361a0ebf2", "787ca6bd6b08f21235574050c6ecdbc34c704e7a4f8ea7831037a7e22f2d9788", "2f53a47b659e0e3cb997c77d6cb80766aca8973494b496c86d53c39a149c6515", "3b9c03622d606ecda3bd44eed796216642f41a25ec897a2dafed0b3cae294dfc", "0aeb32686ee337b6a89177a39ceb74a6d25bb6c5b580149469e17bc036a12c64", "fb710a976b79b4c382c2df96b608034267bf1036a98297c07fea9ba9bb2de821", "3e1ad659d2663f597c1bdd356e464178d5cbb7a55318815d7de54de1147b9bb2", "4aab6098ca7c556396fb583084fb3ae426abde7b6be68a982640ef7ca133ac3d", "db62759b5c5d0bfb39f9cafffe07a833b66936db33ce05cc386a61a077d9b8af", "5ed15eea41f22460aa4a5fc24adba5f784331057364d7b8380f375152df88191", "598b6b74b3a61e6890e94437056ab3e61d28f64e9a0f650a06338d50b733a02d", "5c3a63a254c4f782b6b9bcdcb494933bd262c53df80b9f936d178113a482eb01", "f5f5b1f9dbb0ef41a62ce21a0a0651830d7d2a0f887c47b36e23666f556b9897" /* v93 */, "0963f52aeb3e3191a866b5838b0604ada8ecab895415d58094b3a8ff732c314b" /* v94 */},
	"chat/tone_owner.md":     {"623ec9eb33abfce0ada5cd00ff29ae6fbba81dab353a01e1479e81af263f80be", "17ee13e7311a37c91be484b24a2c03c3fd052deb4200455de791e5023919c65b" /* v93 */},
	"chat/tone_contact.md":   {"eaa3d3dbaff5103bdafa0d5e04dd1444650e09d5f23bbd518e2dd8f73506ab3a", "5aa07a4971621d7aa697f6b2a5df2f156f45e41ee2d035f4329dfaa17f486851", "a716b9f7985cc91edca2f5ae1faecc0e0028b694168320dd955616e1ea002220", "4803098fd3cfa1044f5c5bb8e8e986b162d104052f4ae40ac5e4b4edbc9024d1" /* v93 */},
	"chat/tone_stranger.md":  {"6b7650ecca7fbfe12b6614d8f7adf33e3c99b300c6fa46de523bf8c0879b70f7", "b3a4644ab44db871b317d88be19a4472a6d7253ad2c0bc56880669d099d97783", "72d47a86f3f2ec8cf6cd273c944e4af8f639f8e53909462eed042d3c21081bd9", "153ca23a8075d87700147b2ecec90514e80881c72d2c6797d5a70f2ec9827960" /* v93 */},
	"chat/tone_group.md":     {"338d8d0f916f6cf4f79e144ec628ebcc5196518204943d04c703bf5c5ca16260", "261a29dab67e37f79931dcc109092ada11a3796a021bff8834bc4fb940203228", "45dbf15e2c0bbc208e44be25e49e5a24e9b9b056f656874268b970083b004260" /* v93 */},
	"chat/owner_epilogue.md": {"90daa9842e68fb84959c0e24b291c6249f2cb8b15a5f03e223cfe8ebeec875f1"},
	"messages_epilogue.md":   {"671a6c91fb7139577404e50e4597d866cf2b7dd1c09eca7bf50684a6332fa6ed", "563415be54f17bb7778b8ff2b9dfbe3baa8edbf62d0b3093ed66b3089666523d"},
	"engine/learn_person.md": {"fce1f59f02a764d12aa3a89282cde8c0bda694e788bbed86e82b64f4fe56fc4a"}, // v72: events to ask about
	"anti_repeat.md":         {"7abbf95ac3056f602d04f0a7f3ffce665e2401f0b46842ae858e83671c363ba0"}, // v93: before v94 humanizing pass
}

func isOutdatedDefault(file string, raw []byte) bool {
	sum := sha256.Sum256(raw)
	h := hex.EncodeToString(sum[:])
	for _, o := range outdated[file] {
		if o == h {
			return true
		}
	}
	return false
}

// names is every prompt name ("system", "chat/tone_owner"...), from the built-in defaults, sorted.
var names = func() []string {
	var out []string
	_ = fs.WalkDir(defaults, "defaults", func(p string, d fs.DirEntry, err error) error {
		if err == nil && !d.IsDir() && strings.HasSuffix(p, ".md") {
			out = append(out, strings.TrimSuffix(strings.TrimPrefix(p, "defaults/"), ".md"))
		}
		return nil
	})
	sort.Strings(out)
	return out
}()

var known = func() map[string]bool {
	m := make(map[string]bool, len(names))
	for _, n := range names {
		m[n] = true
	}
	return m
}()

// Store keeps loaded prompts; Reload re-reads files (hot reload).
type Store struct {
	Dir  string
	mu   sync.RWMutex
	vars Vars
	data map[string]string
}

func NewStore(dir string, vars Vars) (*Store, error) {
	s := &Store{Dir: dir, vars: vars}
	return s, s.Reload()
}

// SetVars changes variables and re-expands prompts.
func (s *Store) SetVars(v Vars) error {
	s.mu.Lock()
	s.vars = v
	s.mu.Unlock()
	return s.Reload()
}

func (s *Store) file(name string) string { return filepath.Join(s.Dir, filepath.FromSlash(name)+".md") }

func defaultOf(name string) []byte {
	b, _ := defaults.ReadFile(path.Join("defaults", name+".md"))
	return b
}

// Reload reads every prompt file, creating missing ones from the embedded defaults.
func (s *Store) Reload() error {
	if err := os.MkdirAll(s.Dir, 0o755); err != nil {
		return err
	}
	s.mu.RLock()
	vars := s.vars
	s.mu.RUnlock()
	out := make(map[string]string, len(names))
	for _, name := range names {
		p := s.file(name)
		raw, err := os.ReadFile(p)
		switch {
		case os.IsNotExist(err):
			raw = defaultOf(name)
			if err := os.MkdirAll(filepath.Dir(p), 0o755); err != nil {
				return err
			}
			if err := os.WriteFile(p, raw, 0o644); err != nil {
				return err
			}
		case err != nil:
			return err
		case isOutdatedDefault(name+".md", raw):
			_ = os.WriteFile(p+".old", raw, 0o644)
			raw = defaultOf(name)
			if err := os.WriteFile(p, raw, 0o644); err != nil {
				return err
			}
		}
		out[name] = expand(StripFrontMatter(string(raw)), vars)
	}
	s.mu.Lock()
	s.data = out
	s.mu.Unlock()
	return nil
}

// Get returns a loaded prompt ("" if unknown, or for a nil store).
func (s *Store) Get(name string) string {
	if s == nil {
		return ""
	}
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.data[name]
}

// Text is Get without the surrounding blank lines, with the ${KEY} placeholders of the call filled in.
func (s *Store) Text(name string, kv map[string]string) string {
	t := strings.TrimSpace(s.Get(name))
	if len(kv) == 0 {
		return t
	}
	pairs := make([]string, 0, len(kv)*2)
	for k, v := range kv {
		pairs = append(pairs, "${"+k+"}", v)
	}
	return strings.NewReplacer(pairs...).Replace(t)
}

// Files lists prompt files for the file watcher.
func (s *Store) Files() []string {
	out := make([]string, 0, len(names))
	for _, n := range names {
		out = append(out, s.file(n))
	}
	return out
}

// StripFrontMatter removes a leading "---\n...\n---" block. Only a block at the very start of the file counts: a
// "---" line further down (a markdown rule, a separator in an example) is part of the text and stays.
func StripFrontMatter(s string) string {
	t := strings.TrimLeft(strings.TrimPrefix(s, "\ufeff"), " \t\r\n")
	if !strings.HasPrefix(t, "---") {
		return s
	}
	j := strings.Index(t[3:], "\n---")
	if j < 0 {
		return s
	}
	rest := t[3+j+4:]
	// the closing marker runs to the end of its line
	if k := strings.IndexByte(rest, '\n'); k >= 0 && strings.Trim(rest[:k], "-\r \t") == "" {
		return rest[k:]
	}
	return rest
}

func expand(s string, v Vars) string {
	return strings.NewReplacer(
		"${CHARACTER_NAME}", v.CharacterName,
		"${CHARACTER_NICKNAME}", v.CharacterNickname,
		"${PAPIK_NAME}", v.PapikName,
	).Replace(s)
}

// Format fills {KEY} placeholders (used by image_engineer_system).
func Format(s string, kv map[string]string) string {
	pairs := make([]string, 0, len(kv)*2)
	for k, v := range kv {
		pairs = append(pairs, "{"+k+"}", v)
	}
	return strings.NewReplacer(pairs...).Replace(s)
}

// Names lists the prompt names (sorted; the ones in folders carry the folder: "chat/tone_owner").
func (s *Store) Names() []string { return append([]string(nil), names...) }

// Raw returns the prompt file as stored (with front matter and ${VARS}).
func (s *Store) Raw(name string) (string, error) {
	if !known[name] {
		return "", os.ErrNotExist
	}
	b, err := os.ReadFile(s.file(name))
	return string(b), err
}

// Default returns the built-in text of a prompt.
func (s *Store) Default(name string) (string, error) {
	if !known[name] {
		return "", os.ErrNotExist
	}
	return string(defaultOf(name)), nil
}

// Write replaces a prompt file (atomically, keeping a .bak) and reloads.
func (s *Store) Write(name, content string) error {
	if !known[name] {
		return os.ErrNotExist
	}
	p := s.file(name)
	if err := os.MkdirAll(filepath.Dir(p), 0o755); err != nil {
		return err
	}
	if old, err := os.ReadFile(p); err == nil {
		_ = os.WriteFile(p+".bak", old, 0o644)
		s.snapshot(name, old)
	}
	tmp := p + ".tmp"
	if err := os.WriteFile(tmp, []byte(content), 0o644); err != nil {
		return err
	}
	if err := os.Rename(tmp, p); err != nil {
		return err
	}
	return s.Reload()
}
