// Package work is the owner's queue of jobs for her to do on her own in the background (orders from freelance
// sites, research, errands). The queue survives restarts; the limits (runs a day, steps per run) are enforced
// by the program, not by the prompt.
package work

import (
	"errors"
	"fmt"
	"strings"
	"sync"
	"time"

	"orvi/internal/store"
)

// Status of a task.
const (
	Queued    = "queued"    // waits for its turn
	Running   = "running"   // being worked on (continues on the next run)
	Blocked   = "blocked"   // waits for an answer or approval from the owner
	Done      = "done"      // finished, result written
	Cancelled = "cancelled" // dropped
)

// Task is one job.
type Task struct {
	ID       int       `json:"id"`
	Title    string    `json:"title"`
	Brief    string    `json:"brief"`
	Status   string    `json:"status"`
	Created  time.Time `json:"created"`
	Updated  time.Time `json:"updated"`
	Runs     int       `json:"runs"`
	MaxRuns  int       `json:"max_runs"`
	Notes    []Note    `json:"notes,omitempty"`
	Question string    `json:"question,omitempty"` // what she waits for while Blocked
	Result   string    `json:"result,omitempty"`
}

// Note is one line of progress.
type Note struct {
	At   time.Time `json:"at"`
	Text string    `json:"text"`
}

const (
	MaxTasks     = 100
	MaxNotes     = 30
	DefaultRuns  = 6
	maxFieldText = 4000
)

type Store struct {
	mu    sync.Mutex
	path  string
	tasks []Task
	next  int
	day   string // date of runsToday
	runs  int
	goals string // her long-term goals in her own words (self-directed work)
	saver store.Saver
}

// file is the on-disk shape of the queue.
type file struct {
	Tasks []Task `json:"tasks"`
	Day   string `json:"day"`
	Runs  int    `json:"runs"`
	Goals string `json:"goals,omitempty"`
}

// New loads path (a missing file starts empty; a broken one is moved aside and reported).
func New(path string) *Store {
	s := &Store{path: path, next: 1, saver: store.Saver{What: "work"}}
	var f file
	if store.Load("work", path, &f) {
		s.tasks, s.day, s.runs, s.goals = f.Tasks, f.Day, f.Runs, f.Goals
	}
	for _, t := range s.tasks {
		if t.ID >= s.next {
			s.next = t.ID + 1
		}
	}
	return s
}

func (s *Store) save() { _ = s.saver.Save(s.path, file{s.tasks, s.day, s.runs, s.goals}) }

func clip(s string) string {
	s = strings.TrimSpace(s)
	if r := []rune(s); len(r) > maxFieldText {
		return string(r[:maxFieldText]) + "…"
	}
	return s
}

func (s *Store) find(id int) *Task {
	for i := range s.tasks {
		if s.tasks[i].ID == id {
			return &s.tasks[i]
		}
	}
	return nil
}

// Add queues a job. maxRuns <= 0 means the default.
func (s *Store) Add(title, brief string, maxRuns int) (Task, error) {
	title, brief = clip(title), clip(brief)
	if title == "" {
		return Task{}, errors.New("a task needs a title")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	open := 0
	for _, t := range s.tasks {
		if t.Status != Done && t.Status != Cancelled {
			open++
		}
	}
	if open >= MaxTasks {
		return Task{}, fmt.Errorf("%d open tasks already; finish or cancel some", open)
	}
	if maxRuns <= 0 {
		maxRuns = DefaultRuns
	}
	now := time.Now()
	t := Task{ID: s.next, Title: title, Brief: brief, Status: Queued, Created: now, Updated: now, MaxRuns: maxRuns}
	s.next++
	s.tasks = append(s.tasks, t)
	s.save()
	return t, nil
}

// Get returns a copy of a task.
func (s *Store) Get(id int) (Task, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if t := s.find(id); t != nil {
		return *t, true
	}
	return Task{}, false
}

// List returns all tasks, open ones first (copies).
func (s *Store) List(all bool) []Task {
	s.mu.Lock()
	defer s.mu.Unlock()
	var open, closed []Task
	for _, t := range s.tasks {
		if t.Status == Done || t.Status == Cancelled {
			closed = append(closed, t)
		} else {
			open = append(open, t)
		}
	}
	if !all {
		return open
	}
	return append(open, closed...)
}

// Note adds a line of progress.
func (s *Store) Note(id int, text string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	t := s.find(id)
	if t == nil {
		return fmt.Errorf("no task #%d", id)
	}
	t.Notes = append(t.Notes, Note{At: time.Now(), Text: clip(text)})
	if len(t.Notes) > MaxNotes {
		t.Notes = t.Notes[len(t.Notes)-MaxNotes:]
	}
	t.Updated = time.Now()
	s.save()
	return nil
}

// Finish closes a task with its result.
func (s *Store) Finish(id int, result string) error {
	return s.set(id, func(t *Task) error {
		if t.Status == Cancelled {
			return errors.New("the task was cancelled")
		}
		t.Status, t.Result, t.Question = Done, clip(result), ""
		return nil
	})
}

// Block parks a task until the owner answers; the question is what she needs from him.
func (s *Store) Block(id int, question string) error {
	return s.set(id, func(t *Task) error {
		if t.Status == Done || t.Status == Cancelled {
			return errors.New("the task is already closed")
		}
		if strings.TrimSpace(question) == "" {
			return errors.New("say what you need from the owner")
		}
		t.Status, t.Question = Blocked, clip(question)
		return nil
	})
}

// Answer records the owner's reply and puts the task back in the queue.
func (s *Store) Answer(id int, text string) error {
	return s.set(id, func(t *Task) error {
		if t.Status != Blocked {
			return errors.New("the task is not waiting for an answer")
		}
		t.Notes = append(t.Notes, Note{At: time.Now(), Text: "OWNER ANSWERED: " + clip(text)})
		t.Status, t.Question = Queued, ""
		if t.Runs >= t.MaxRuns { // he wants it continued: give it a few more runs
			t.MaxRuns = t.Runs + 3
		}
		return nil
	})
}

// Cancel drops a task.
func (s *Store) Cancel(id int) error {
	return s.set(id, func(t *Task) error {
		if t.Status == Done {
			return errors.New("the task is already done")
		}
		t.Status = Cancelled
		return nil
	})
}

func (s *Store) set(id int, f func(*Task) error) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	t := s.find(id)
	if t == nil {
		return fmt.Errorf("no task #%d", id)
	}
	if err := f(t); err != nil {
		return err
	}
	t.Updated = time.Now()
	s.save()
	return nil
}

func today(now time.Time) string { return now.Format("2006-01-02") }

// RunsToday is how many work runs started today.
func (s *Store) RunsToday(now time.Time) int {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.day != today(now) {
		return 0
	}
	return s.runs
}

// Take picks the next task to work on and counts the run: the oldest running one, else the oldest queued.
// A task that used all its runs is parked as blocked, with a question for the owner. ok is false when there is nothing to do or
// the daily limit is reached.
func (s *Store) Take(now time.Time, maxPerDay int) (Task, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.day != today(now) {
		s.day, s.runs = today(now), 0
	}
	if maxPerDay > 0 && s.runs >= maxPerDay {
		return Task{}, false
	}
	var pick *Task
	for _, want := range []string{Running, Queued} {
		for i := range s.tasks {
			t := &s.tasks[i]
			if t.Status != want {
				continue
			}
			if t.Runs >= t.MaxRuns {
				t.Status, t.Question, t.Updated = Blocked, fmt.Sprintf("Used all %d runs without finishing. Continue (more runs), change the plan, or drop it?", t.MaxRuns), now
				continue
			}
			pick = t
			break
		}
		if pick != nil {
			break
		}
	}
	if pick == nil {
		s.save()
		return Task{}, false
	}
	pick.Status, pick.Runs, pick.Updated = Running, pick.Runs+1, now
	s.runs++
	s.save()
	return *pick, true
}

// Render writes a task for the model.
func (t Task) Render(withNotes bool) string {
	var b strings.Builder
	fmt.Fprintf(&b, "#%d [%s] %s (run %d/%d)", t.ID, t.Status, t.Title, t.Runs, t.MaxRuns)
	if t.Brief != "" {
		b.WriteString("\n  brief: " + t.Brief)
	}
	if t.Question != "" {
		b.WriteString("\n  waiting for the owner: " + t.Question)
	}
	if t.Result != "" {
		b.WriteString("\n  result: " + t.Result)
	}
	if withNotes {
		for _, n := range t.Notes {
			fmt.Fprintf(&b, "\n  - %s %s", n.At.Format("02.01 15:04"), n.Text)
		}
	}
	return b.String()
}

// Goals returns her long-term goals ("" = none set yet).
func (s *Store) Goals() string {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.goals
}

// SetGoals replaces her long-term goals.
func (s *Store) SetGoals(text string) {
	s.mu.Lock()
	s.goals = clip(text)
	s.save()
	s.mu.Unlock()
}

// Reserve counts one background run that is not tied to a task (she is choosing her own next goal).
// ok is false when the daily limit is reached (maxPerDay <= 0 = no limit).
func (s *Store) Reserve(now time.Time, maxPerDay int) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.day != today(now) {
		s.day, s.runs = today(now), 0
	}
	if maxPerDay > 0 && s.runs >= maxPerDay {
		return false
	}
	s.runs++
	s.save()
	return true
}

// Open reports whether any task still waits or runs (blocked ones wait for the owner and do not count).
func (s *Store) Open() bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	for _, t := range s.tasks {
		if t.Status == Queued || t.Status == Running {
			return true
		}
	}
	return false
}

// RecentDone lists the last n finished tasks with their results, newest last.
func (s *Store) RecentDone(n int) string {
	s.mu.Lock()
	defer s.mu.Unlock()
	var out []string
	for i := len(s.tasks) - 1; i >= 0 && len(out) < n; i-- {
		t := s.tasks[i]
		if t.Status == Done {
			r := t.Result
			if len([]rune(r)) > 300 {
				r = string([]rune(r)[:300]) + "…"
			}
			out = append([]string{fmt.Sprintf("#%d %s: %s", t.ID, t.Title, r)}, out...)
		}
	}
	return strings.Join(out, "\n")
}
