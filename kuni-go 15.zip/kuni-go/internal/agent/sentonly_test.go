package agent

import (
	"testing"

	"kuni/internal/llm"
)

func call(n string) llm.ToolCall {
	var c llm.ToolCall
	c.Function.Name = n
	return c
}

func TestSentOnly(t *testing.T) {
	ok := []llm.Message{{Role: "tool", Content: "sent"}}
	if !sentOnly([]llm.ToolCall{call("send_telegram_message"), call("react_with_emoji")}, append(ok, ok[0])) {
		t.Fatal("should stop")
	}
	if sentOnly([]llm.ToolCall{call("send_telegram_message"), call("shell")}, ok) {
		t.Fatal("shell needs another round")
	}
	if sentOnly([]llm.ToolCall{call("send_telegram_message")}, []llm.Message{{Role: "tool", Content: "error: repeat"}}) {
		t.Fatal("failed send must not stop")
	}
	if sentOnly([]llm.ToolCall{call("react_with_emoji")}, ok) {
		t.Fatal("react alone is not a reply")
	}
}
