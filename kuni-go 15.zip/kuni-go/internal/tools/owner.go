package tools

import (
	"bytes"
	"context"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"time"

	"kuni/internal/llmui"
	"kuni/internal/telegram"
)

// IsOwnerChat reports whether the chat is the owner's private chat and owner tools are enabled.
func IsOwnerChat(d Deps, chatID int64) bool {
	c := d.Cfg()
	return c.OwnerTools && c.PapikChatID != 0 && chatID == c.PapikChatID
}

func (d Deps) workDir() string {
	dir := d.Cfg().ShellDir
	if dir == "" {
		dir = d.dataPath("workspace")
	}
	_ = os.MkdirAll(dir, 0o755)
	return dir
}

const maxOut = 6000

// Truncate keeps the head and the tail of long output.
func Truncate(s string, n int) string {
	r := []rune(s)
	if len(r) <= n {
		return s
	}
	return string(r[:n/2]) + "\n…(cut " + fmt.Sprint(len(r)-n) + " chars)…\n" + string(r[len(r)-n/2:])
}

// OwnerTools are only ever registered for the owner's private chat.
func OwnerTools(d Deps, chat telegram.Chat) []Tool {
	if !IsOwnerChat(d, chat.ID) {
		return nil
	}
	return []Tool{shellTool(d), downloadFileTool(d, chat), sendFileTool(d, chat), listAllChatsTool(d), readChatTool(d)}
}

func shellTool(d Deps) Tool {
	return Tool{
		Name:        "shell",
		Description: "Run a shell command on the machine you live on (owner only). Working dir is your workspace. Returns exit code and output. Use it for downloads (curl/wget), archives (unzip/tar), files, installs, anything the owner asks.",
		Props: []Prop{
			{Name: "command", Type: "string", Desc: "Command line for sh -c."},
			{Name: "timeout_secs", Type: "integer", Desc: "Optional timeout, default 60, max 600."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			cmdline := strings.TrimSpace(a.Str("command"))
			if cmdline == "" {
				return "", fmt.Errorf("empty command")
			}
			to := d.Cfg().ShellTimeout
			if to <= 0 {
				to = 60
			}
			if v := a.Int("timeout_secs"); v > 0 {
				to = v
			}
			if to > 600 {
				to = 600
			}
			cctx, cancel := context.WithTimeout(ctx, time.Duration(to)*time.Second)
			defer cancel()
			var c *exec.Cmd
			if runtime.GOOS == "windows" {
				c = exec.CommandContext(cctx, "cmd", "/C", cmdline)
			} else {
				c = exec.CommandContext(cctx, "sh", "-c", cmdline)
			}
			c.Dir = d.workDir()
			c.WaitDelay = 2 * time.Second
			var out bytes.Buffer
			c.Stdout, c.Stderr = &out, &out
			err := c.Run()
			code := 0
			if err != nil {
				code = -1
				if ee, ok := err.(*exec.ExitError); ok {
					code = ee.ExitCode()
				}
			}
			res := fmt.Sprintf("exit=%d\n%s", code, Truncate(out.String(), maxOut))
			if cctx.Err() == context.DeadlineExceeded {
				res += "\n(timed out after " + fmt.Sprint(to) + "s, killed)"
			}
			return res, nil
		},
	}
}

func downloadFileTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name:        "download_telegram_file",
		Description: "Save the file/photo/voice/video of a message from this chat into your workspace. Returns the path.",
		Props: []Prop{
			{Name: "message_id", Type: "integer", Desc: "Message with the file."},
			{Name: "filename", Type: "string", Desc: "Optional file name to save as."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			m, err := d.TG.Message(ctx, chat.ID, a.Int("message_id"))
			if err != nil {
				return "", err
			}
			if m.FileID == "" {
				return "", fmt.Errorf("message has no downloadable file")
			}
			data, err := d.TG.Download(ctx, m.FileID)
			if err != nil {
				return "", err
			}
			name := filepath.Base(strings.TrimSpace(a.Str("filename")))
			if name == "." || name == "" || name == string(filepath.Separator) {
				name = fmt.Sprintf("tg_%d_%d", chat.ID, m.ID)
			}
			p := filepath.Join(d.workDir(), name)
			if err := os.WriteFile(p, data, 0o644); err != nil {
				return "", err
			}
			return fmt.Sprintf("saved %d bytes to %s", len(data), p), nil
		},
	}
}

func sendFileTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name:        "send_file",
		Description: "Send a file from your workspace (or an absolute path) to the owner as a document (max 50 MB).",
		Props: []Prop{
			{Name: "path", Type: "string", Desc: "File path; relative paths are inside the workspace."},
			{Name: "caption", Type: "string", Desc: "Optional caption."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			p := a.Str("path")
			if !filepath.IsAbs(p) {
				p = filepath.Join(d.workDir(), p)
			}
			st, err := os.Stat(p)
			if err != nil {
				return "", err
			}
			if st.IsDir() {
				return "", fmt.Errorf("it is a directory; zip it first")
			}
			if st.Size() > 50<<20 {
				return "", fmt.Errorf("file is %d MB, limit is 50", st.Size()>>20)
			}
			data, err := os.ReadFile(p)
			if err != nil {
				return "", err
			}
			if _, err := d.TG.SendDocument(ctx, chat.ID, filepath.Base(p), data, a.Str("caption"), 0); err != nil {
				return "", err
			}
			return "sent " + filepath.Base(p), nil
		},
	}
}

func listAllChatsTool(d Deps) Tool {
	return Tool{
		Name:        "list_all_chats",
		Description: "List ALL your Telegram chats with unread counts and last message (owner only, ignores lockdown).",
		Run: func(ctx context.Context, a Args) (string, error) {
			chats, err := d.TG.Chats(ctx, 100)
			if err != nil {
				return "", err
			}
			var b strings.Builder
			now := time.Now()
			for _, c := range chats {
				b.WriteString(llmui.FormatChat(c, now) + "\n")
			}
			if b.Len() == 0 {
				return "No chats", nil
			}
			return b.String(), nil
		},
	}
}

func readChatTool(d Deps) Tool {
	return Tool{
		Name:        "read_chat",
		Description: "Read recent messages of any of your chats (owner only, ignores lockdown). Does not mark as read.",
		Props: []Prop{
			{Name: "chat", Type: "string", Desc: "Chat id or part of the name."},
			{Name: "limit", Type: "integer", Desc: "How many messages, default 20, max 100."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			q := strings.TrimSpace(a.Str("chat"))
			var id int64
			if _, err := fmt.Sscan(q, &id); err != nil || fmt.Sprint(id) != q {
				cs, err := d.TG.SearchChats(ctx, q)
				if err != nil {
					return "", err
				}
				if len(cs) == 0 {
					return "", fmt.Errorf("no chat matches %q", q)
				}
				id = cs[0].ID
			}
			n := int(a.Int("limit"))
			if n <= 0 {
				n = 20
			}
			if n > 100 {
				n = 100
			}
			msgs, err := d.TG.History(ctx, id, 0, n, 0)
			if err != nil {
				return "", err
			}
			if len(msgs) == 0 {
				return "No messages", nil
			}
			return Truncate(d.UI.FormatMessages(ctx, msgs, time.Now()), 12000), nil
		},
	}
}
