package llm

import (
	"errors"
	"testing"
	"time"
)

func TestHealthRecordsOkAndFailures(t *testing.T) {
	h := NewHealth()
	now := time.Unix(1000, 0)
	h.now = func() time.Time { return now }
	h.record(Event{Kind: "chat", Model: "mercury-3", Purpose: "chat"})
	h.record(Event{Kind: "embedding", Model: "", Purpose: "recall", Err: errors.New("llm: HTTP 400:   Model  does not exist")})
	now = time.Unix(2000, 0)
	h.record(Event{Kind: "chat", Model: "mercury-3"})
	rows := h.Snapshot()
	if len(rows) != 2 {
		t.Fatalf("rows: %+v", rows)
	}
	if rows[0].Kind != "embedding" || rows[0].Fail != 1 || rows[0].ErrText != "llm: HTTP 400: Model does not exist" {
		t.Fatalf("a broken model comes first with a tidy text: %+v", rows[0])
	}
	if rows[1].OK != 2 || rows[1].LastOK != 2000 || rows[1].Fail != 0 {
		t.Fatalf("%+v", rows[1])
	}
}

func TestHealthCutsLongErrorsAndNilIsSafe(t *testing.T) {
	var none *Health
	none.record(Event{Kind: "chat"})
	if none.Snapshot() != nil {
		t.Fatal("nil health must be empty")
	}
	h := NewHealth()
	long := make([]rune, 1000)
	for i := range long {
		long[i] = 'x'
	}
	h.record(Event{Kind: "chat", Model: "m", Err: errors.New(string(long))})
	if n := len([]rune(h.Snapshot()[0].ErrText)); n > maxErrText+1 {
		t.Fatalf("error text not cut: %d", n)
	}
}
