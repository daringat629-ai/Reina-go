package llm

import (
	"sort"
	"strings"
	"sync"
	"time"
)

// HealthRow is how one model has been doing: what the owner's app shows, so a broken model is seen at a glance
// instead of being dug out of the logs.
type HealthRow struct {
	Kind    string `json:"kind"`  // chat | embedding | stream
	Model   string `json:"model"` // "" = a request went out with no model name (an empty setting)
	Purpose string `json:"purpose"`
	OK      int    `json:"ok"`
	Fail    int    `json:"fail"`
	LastOK  int64  `json:"lastOk"`  // unix seconds, 0 = never
	LastErr int64  `json:"lastErr"` // unix seconds, 0 = never
	ErrText string `json:"errText,omitempty"`
}

// Health keeps one HealthRow per (kind, model) since the program started. It holds no secrets: error text is the
// server's own answer, cut short.
type Health struct {
	mu   sync.Mutex
	rows map[string]*HealthRow
	now  func() time.Time
}

// NewHealth returns an empty recorder.
func NewHealth() *Health { return &Health{rows: map[string]*HealthRow{}, now: time.Now} }

const maxErrText = 240

// record counts one finished request.
func (h *Health) record(e Event) {
	if h == nil {
		return
	}
	h.mu.Lock()
	defer h.mu.Unlock()
	k := e.Kind + "|" + e.Model
	r := h.rows[k]
	if r == nil {
		r = &HealthRow{Kind: e.Kind, Model: e.Model}
		h.rows[k] = r
	}
	if e.Purpose != "" {
		r.Purpose = e.Purpose
	}
	t := h.now().Unix()
	if e.Err == nil {
		r.OK++
		r.LastOK = t
		return
	}
	r.Fail++
	r.LastErr = t
	msg := strings.Join(strings.Fields(e.Err.Error()), " ")
	if rs := []rune(msg); len(rs) > maxErrText {
		msg = string(rs[:maxErrText]) + "…"
	}
	r.ErrText = msg
}

// Snapshot is the rows, a copy, in a stable order: the ones that failed most recently first.
func (h *Health) Snapshot() []HealthRow {
	if h == nil {
		return nil
	}
	h.mu.Lock()
	out := make([]HealthRow, 0, len(h.rows))
	for _, r := range h.rows {
		out = append(out, *r)
	}
	h.mu.Unlock()
	sort.Slice(out, func(i, j int) bool {
		if out[i].LastErr != out[j].LastErr {
			return out[i].LastErr > out[j].LastErr
		}
		if out[i].Kind != out[j].Kind {
			return out[i].Kind < out[j].Kind
		}
		return out[i].Model < out[j].Model
	})
	return out
}
