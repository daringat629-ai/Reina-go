package billing

import (
	"errors"
	"net/http"
)

// mountControl adds the owner's switches to the admin app: mute or ban a person, pause her, make a backup.
func (a *Admin) mountControl(h func(path string, f func(r *http.Request, in map[string]any) (any, error))) {
	h("control", func(r *http.Request, _ map[string]any) (any, error) {
		out := map[string]any{"muteOn": a.Mute != nil, "pauseOn": a.SetPaused != nil, "backupOn": a.Backup != nil}
		if a.Paused != nil {
			out["paused"] = a.Paused()
		}
		if a.Muted != nil {
			out["muted"] = a.Muted()
		}
		if a.Backups != nil {
			out["backups"] = a.Backups()
		}
		if a.Health != nil {
			out["health"] = a.Health()
		}
		return out, nil
	})
	h("mute", func(r *http.Request, in map[string]any) (any, error) {
		if a.Mute == nil {
			return nil, errors.New("список игнора выключен")
		}
		id, _ := in["id"].(float64)
		hours, _ := in["hours"].(float64)
		note, _ := in["note"].(string)
		if id <= 0 {
			return nil, errors.New("нужен id человека")
		}
		if o := a.Owner(); o != 0 && int64(id) == o {
			return nil, errors.New("себя заглушить нельзя")
		}
		if hours < 0 || hours > 24*365 {
			return nil, errors.New("срок от 0 (бан до отмены) до года")
		}
		if len([]rune(note)) > 200 {
			note = string([]rune(note)[:200])
		}
		if err := a.Mute(int64(id), hours, note); err != nil {
			return nil, err
		}
		return map[string]any{"ok": true}, nil
	})
	h("unmute", func(r *http.Request, in map[string]any) (any, error) {
		if a.Unmute == nil {
			return nil, errors.New("список игнора выключен")
		}
		id, _ := in["id"].(float64)
		if err := a.Unmute(int64(id)); err != nil {
			return nil, err
		}
		return map[string]any{"ok": true}, nil
	})
	h("pause", func(r *http.Request, in map[string]any) (any, error) {
		if a.SetPaused == nil {
			return nil, errors.New("пауза недоступна")
		}
		on, _ := in["on"].(bool)
		a.SetPaused(on)
		return map[string]any{"paused": on}, nil
	})
	h("backup", func(r *http.Request, _ map[string]any) (any, error) {
		if a.Backup == nil {
			return nil, errors.New("бэкап недоступен")
		}
		what, err := a.Backup()
		if err != nil {
			return nil, err
		}
		return map[string]any{"made": what}, nil
	})
}
