package billing

import (
	"errors"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestOwnerSwitchesMuteBanPauseBackup(t *testing.T) {
	srv, _ := fakeAPI(t)
	dir := t.TempDir()
	st := Open(filepath.Join(dir, "b.json"))
	muted := map[int64]float64{}
	paused := false
	adm := &Admin{Token: "A", BaseURL: srv.URL, Store: st, Pay: newBot(srv, st), QRPath: filepath.Join(dir, "qr.png"), Owner: func() int64 { return 1 }, Now: func() time.Time { return t0 }, Loc: time.UTC,
		Mute:      func(id int64, h float64, note string) error { muted[id] = h; return nil },
		Unmute:    func(id int64) error { delete(muted, id); return nil },
		Muted:     func() any { return []map[string]any{{"id": 5}} },
		Paused:    func() bool { return paused },
		SetPaused: func(on bool) { paused = on },
		Backup:    func() (string, error) { return "backup-1.tgz", nil },
		Backups:   func() any { return []map[string]any{} }}
	h := adm.WebApp()
	boss := signInit("A", `{"id":1}`, t0)
	stranger := signInit("A", `{"id":2}`, t0)

	if w := postJSON(h, "/app/admin/api/mute", `{"id":5,"hours":24}`, stranger); w.Code != 401 || len(muted) != 0 {
		t.Fatalf("a stranger must not mute: %d", w.Code)
	}
	if w := postJSON(h, "/app/admin/api/mute", `{"id":5,"hours":24}`, boss); w.Code != 200 || muted[5] != 24 {
		t.Fatalf("mute: %d %s", w.Code, w.Body.String())
	}
	if w := postJSON(h, "/app/admin/api/mute", `{"id":6,"hours":0}`, boss); w.Code != 200 || muted[6] != 0 || len(muted) != 2 {
		t.Fatalf("ban: %d", w.Code)
	}
	if w := postJSON(h, "/app/admin/api/mute", `{"id":1,"hours":24}`, boss); w.Code != 400 || !strings.Contains(w.Body.String(), "себя") {
		t.Fatalf("the owner cannot mute himself: %d %s", w.Code, w.Body.String())
	}
	if w := postJSON(h, "/app/admin/api/mute", `{"id":9,"hours":-3}`, boss); w.Code != 400 {
		t.Fatalf("a negative time is refused: %d", w.Code)
	}
	if w := postJSON(h, "/app/admin/api/unmute", `{"id":5}`, boss); w.Code != 200 || len(muted) != 1 {
		t.Fatalf("unmute: %d", w.Code)
	}
	if w := postJSON(h, "/app/admin/api/pause", `{"on":true}`, boss); w.Code != 200 || !paused {
		t.Fatalf("pause: %d", w.Code)
	}
	w := postJSON(h, "/app/admin/api/control", `{}`, boss)
	if !strings.Contains(w.Body.String(), `"paused":true`) || !strings.Contains(w.Body.String(), `"muted"`) {
		t.Fatalf("control: %s", w.Body.String())
	}
	if w := postJSON(h, "/app/admin/api/backup", `{}`, boss); w.Code != 200 || !strings.Contains(w.Body.String(), "backup-1.tgz") {
		t.Fatalf("backup: %d %s", w.Code, w.Body.String())
	}
	adm.Backup = func() (string, error) { return "", errors.New("disk full") }
	if w := postJSON(h, "/app/admin/api/backup", `{}`, boss); w.Code != 400 || !strings.Contains(w.Body.String(), "disk full") {
		t.Fatalf("a failed backup says why: %d %s", w.Code, w.Body.String())
	}
}

func TestControlShowsModelHealthToOwnerOnly(t *testing.T) {
	srv, _ := fakeAPI(t)
	st := Open(filepath.Join(t.TempDir(), "b.json"))
	adm := &Admin{Token: "A", BaseURL: srv.URL, Store: st, Pay: newBot(srv, st), Owner: func() int64 { return 1 }, Now: func() time.Time { return t0 }, Loc: time.UTC,
		Health: func() any { return []map[string]any{{"kind": "embedding", "model": "", "fail": 3}} }}
	h := adm.WebApp()
	if w := postJSON(h, "/app/admin/api/control", `{}`, signInit("A", `{"id":2}`, t0)); w.Code != 401 {
		t.Fatalf("a stranger must not see it: %d", w.Code)
	}
	w := postJSON(h, "/app/admin/api/control", `{}`, signInit("A", `{"id":1}`, t0))
	if w.Code != 200 || !strings.Contains(w.Body.String(), `"health"`) || !strings.Contains(w.Body.String(), `"fail":3`) {
		t.Fatalf("health: %d %s", w.Code, w.Body.String())
	}
}
