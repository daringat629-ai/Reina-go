package agent

import (
	"context"
	"sync"

	"kuni/internal/llm"
	"kuni/internal/telegram"
)

// parallelSafe are tools that only read: running several of them at once cannot change the outcome.
var parallelSafe = map[string]bool{
	"web_search": true, "read_link": true, "read_file": true, "read_document": true, "http_request": true,
	"lookup": true, "sysinfo": true, "read_chat": true, "search_messages": true, "view_messages_around": true,
	"query": true, "netcheck": true, "digest": true, "calc": true, "grep": true, "tail_log": true, "rss": true, "textutil": true, "search_chats": true, "user_info": true,
}

// runParallel executes the independent read-only calls of one round at the same time and returns their results
// by call index. Everything else (sends, browser steps, shell...) stays in order in the caller's loop.
func (a *Agent) runParallel(ctx context.Context, s *session, calls []llm.ToolCall, seen map[string]bool) map[int]string {
	if !a.Cfg.Get().ParallelTools {
		return nil
	}
	var idx []int
	keys := map[string]bool{}
	for i, c := range calls {
		key := c.Function.Name + "|" + string(c.Function.Arguments)
		if !parallelSafe[c.Function.Name] || seen[key] || keys[key] {
			continue
		}
		keys[key] = true
		idx = append(idx, i)
	}
	if len(idx) < 2 {
		return nil
	}
	out := make(map[int]string, len(idx))
	var mu sync.Mutex
	var wg sync.WaitGroup
	for _, i := range idx {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			c := calls[i]
			r := s.tools.Call(telegram.WithThread(ctx, s.thread), c.Function.Name, c.Function.Arguments)
			mu.Lock()
			out[i] = r
			mu.Unlock()
		}(i)
	}
	wg.Wait()
	return out
}
