package tools

import (
	"context"
	"net/http"
	"os"
	"path/filepath"
	"strings"

	"kuni/internal/browser"
	"kuni/internal/config"
	"kuni/internal/desktop"
	"kuni/internal/diary"
	"kuni/internal/imagegen"
	"kuni/internal/llm"
	"kuni/internal/llmui"
	"kuni/internal/media"
	"kuni/internal/metrics"
	"kuni/internal/mood"
	"kuni/internal/people"
	"kuni/internal/prompts"
	"kuni/internal/reminders"
	"kuni/internal/sched"
	"kuni/internal/telegram"
	"kuni/internal/web"
	"kuni/internal/work"
)

// Deps is everything tools need; shared between the agent and the proxy.
type Deps struct {
	TG      telegram.Client
	LLM     *llm.Client
	Diary   *diary.Diary
	Prompts *prompts.Store
	Media   func() media.Services
	Cfg     func() *config.Config
	UI      *llmui.Env
	Metrics *metrics.Registry
	Images  *imagegen.Generator
	Mood    *mood.Mood // nil = mood scale off
	// OpenChat is supplied by the agent: it switches the session to a chat and returns the rendered view.
	OpenChat func(ctx context.Context, chatID int64) (string, error)
	// FetchPage opens a link for read_link (nil = the real, SSRF-safe web fetcher).
	FetchPage func(ctx context.Context, url string) (web.Page, error)
	// Reminders and People are the persistent stores behind #remind and the person cards (nil = feature off).
	Reminders *reminders.Store
	People    *people.Store
	// Work is the queue of background jobs behind #work (nil = a private empty one in memory).
	Work *work.Store
	// Sched holds recurring tasks and monitors behind #schedule and #monitor (nil = those tools answer that the scheduler is off).
	Sched *sched.Store
	// ConfigPath is config.toml: #settings changes it, #backup includes it. Empty = those tools say they cannot.
	ConfigPath string
	// Wake starts a turn of hers in a chat because of an outside event (a finished background job...). Supplied by the agent.
	Wake func(chatID int64, text string)
	// UpdateDir and Restart serve #self_update; empty/nil = the real program directory and a real restart.
	UpdateDir string
	Restart   func()
	// MailPlain and CalendarHTTP are for tests: a mail server without TLS, an HTTP client that may reach local addresses.
	MailPlain    bool
	CalendarHTTP *http.Client
	// Searcher overrides the web search of #web_search (tests).
	Searcher media.Searcher
	// Desktop is the virtual desktop behind #desktop (nil = the program-wide one).
	Desktop *desktop.Desktop
	// Browser is the browser behind #browser (nil = the program-wide one).
	Browser *browser.Browser
	// GoToSleep is supplied by the agent when autonomy is on: it starts a sleep and returns a message for the model.
	GoToSleep func(minutes int, reason string) string
}

func (d Deps) dataPath(sub ...string) string {
	return filepath.Join(append([]string{d.Cfg().DataDir}, sub...)...)
}

// safeJoin resolves a model-supplied filename inside dir and rejects path traversal.
func safeJoin(dir, name string) (string, error) {
	clean := filepath.Base(strings.TrimSpace(name))
	if clean == "." || clean == ".." || clean == string(filepath.Separator) || clean != strings.TrimSpace(name) {
		return "", os.ErrInvalid
	}
	return filepath.Join(dir, clean), nil
}

// Contacts reports whether a user is in the account's contact list (set by main in user mode).
var Contacts func(userID int64) bool

// Accessible implements util::isAccessibleFromLockdown: may Kuni touch this chat?
func Accessible(c *config.Config, chatID int64) bool {
	switch c.Lockdown {
	case "papik_only":
		return chatID == c.PapikChatID
	case "contacts_only":
		// groups (negative IDs) and the owner are allowed; private chats need to be contacts
		// (Contacts is set in user mode; the Bot API has no contact list).
		return chatID < 0 || chatID == c.PapikChatID || (Contacts != nil && Contacts(chatID))
	}
	return true
}
