package config

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"
	"sync/atomic"
	"time"

	"kuni/internal/util"
)

// FileName is the runtime configuration file in the working directory.
const FileName = "config.toml"

// Config mirrors the sections of the C++ config.toml.
type Config struct {
	// [general]
	CharacterName   string
	CharacterNick   string
	PapikName       string
	PapikChatID     int64
	TelegramEnabled bool

	// [telegram]
	Mode           string // user | bot
	Phone          string
	TDLibDir       string
	BotToken       string
	TelegramAPI    string
	TelegramAPIID  int64
	TelegramHash   string
	Lockdown       string // none | contacts_only | papik_only
	CanJoinChats   bool
	CanLeaveChats  bool
	SessionIdle    time.Duration
	Proactive      time.Duration // 0 = disabled
	MaxToolRounds  int
	DebounceWindow time.Duration

	// [llm]
	LLMBaseURL       string
	LLMAPIKey        string
	LLMModel         string
	EmbeddingBaseURL string
	EmbeddingModel   string
	RequestTimeout   time.Duration
	Temperature      float64 // < 0 = unset
	Reasoning        string

	// [proxy]
	ProxyEnabled bool
	ProxyPort    int

	// [memory]
	DiaryDir          string
	WorkingMemoryFile string
	DiaryTokenTrigger int
	SleepMaxTime      time.Duration
	ConfidenceFactor  float64
	MaxRelatedEntries int

	// [capabilities]
	WebSearchEnabled bool
	WebSearchURL     string // SearXNG-compatible JSON endpoint, or https://ollama.com/api/web_search
	WebSearchKey     string
	SDEnabled        bool
	SDURL            string
	STTEnabled       bool
	STTURL           string
	STTModel         string
	TTSBackend       string // none | openai | elevenlabs
	TTSURL           string
	TTSKey           string
	TTSModel         string
	TTSVoice         string
	FFmpegPath       string
	UseStickers      bool
	LazyTools        bool
	ForceTools       bool
	MaxMessageChars  int // a message longer than this is split into several (0 = no limit)
	TypingMinMs      int
	TypingMaxMs      int
	HistoryKeep      int

	// [misc]
	MetricsEnabled bool
	DebugUI        bool
	DataDir        string
	PromptsDir     string
}

type field struct {
	section, key, comment string
	def                   any
	ptr                   func(c *Config) any
}

func fields() []field {
	f := func(s, k, comment string, def any, ptr func(c *Config) any) field {
		return field{s, k, comment, def, ptr}
	}
	return []field{
		f("general", "character_name", "the name the character uses for herself", "Reina Veil", func(c *Config) any { return &c.CharacterName }),
		f("general", "character_nickname", "", "@kunii_chan", func(c *Config) any { return &c.CharacterNick }),
		f("general", "papik_name", "the instance owner's nickname", "Alex2772", func(c *Config) any { return &c.PapikName }),
		f("general", "papik_chat_id", "the instance owner's Telegram user ID", int64(0), func(c *Config) any { return &c.PapikChatID }),
		f("general", "telegram_enabled", "set to false to run as a standalone proxy without Telegram", false, func(c *Config) any { return &c.TelegramEnabled }),

		f("telegram", "mode", "user = log in as a regular account via tdlib (like the C++ version; build with -tags tdlib); bot = Bot API", "user", func(c *Config) any { return &c.Mode }),
		f("telegram", "phone_number", "user mode: phone to log in with (asked on stdin if empty)", "", func(c *Config) any { return &c.Phone }),
		f("telegram", "tdlib_dir", "user mode: tdlib database directory (keeps the login)", "tdlib", func(c *Config) any { return &c.TDLibDir }),
		f("telegram", "bot_token", "bot mode: token from @BotFather", "", func(c *Config) any { return &c.BotToken }),
		f("telegram", "api_base", "Bot API base URL", "https://api.telegram.org", func(c *Config) any { return &c.TelegramAPI }),
		f("telegram", "api_id", "user mode: get from https://my.telegram.org", int64(0), func(c *Config) any { return &c.TelegramAPIID }),
		f("telegram", "api_hash", "user mode: get from https://my.telegram.org", "", func(c *Config) any { return &c.TelegramHash }),
		f("telegram", "lockdown", "none | papik_only (only the owner chat is accessible)", "none", func(c *Config) any { return &c.Lockdown }),
		f("telegram", "can_join_chats", "", false, func(c *Config) any { return &c.CanJoinChats }),
		f("telegram", "can_leave_chats", "", false, func(c *Config) any { return &c.CanLeaveChats }),
		f("telegram", "session_idle_secs", "dump the conversation to the diary after this much silence", int64(900), func(c *Config) any { return &c.SessionIdle }),
		f("telegram", "proactive_interval_secs", "0 disables acting proactively", int64(0), func(c *Config) any { return &c.Proactive }),
		f("telegram", "max_tool_rounds", "max LLM<->tool round-trips per turn", int64(12), func(c *Config) any { return &c.MaxToolRounds }),
		f("telegram", "debounce_ms", "wait for follow-up messages before answering", int64(1500), func(c *Config) any { return &c.DebounceWindow }),

		f("llm", "base_url", "OpenAI-compatible endpoint, e.g. http://localhost:11434/v1/", "http://localhost:11434/v1/", func(c *Config) any { return &c.LLMBaseURL }),
		f("llm", "api_key", "bearer key, empty if not needed", "", func(c *Config) any { return &c.LLMAPIKey }),
		f("llm", "model", "chat model name (must support vision to view photos)", "llama3:8b", func(c *Config) any { return &c.LLMModel }),
		f("llm", "embedding_base_url", "endpoint for /embeddings (defaults to base_url if empty)", "", func(c *Config) any { return &c.EmbeddingBaseURL }),
		f("llm", "embedding_model", "embedding model name", "nomic-embed-text", func(c *Config) any { return &c.EmbeddingModel }),
		f("llm", "request_timeout_secs", "", int64(300), func(c *Config) any { return &c.RequestTimeout }),
		f("llm", "reasoning", "OpenRouter reasoning control: empty = default, off = disable (much faster), low|medium|high", "", func(c *Config) any { return &c.Reasoning }),
		f("llm", "temperature", "negative = server default", -1.0, func(c *Config) any { return &c.Temperature }),

		f("proxy", "enabled", "run the OpenAI-compatible proxy", true, func(c *Config) any { return &c.ProxyEnabled }),
		f("proxy", "port", "port of the OpenAI-compatible proxy", int64(10434), func(c *Config) any { return &c.ProxyPort }),

		f("memory", "diary_dir", "where diary entries (*.md) are stored", "data/diary", func(c *Config) any { return &c.DiaryDir }),
		f("memory", "working_memory_file", "", "data/working_memory.md", func(c *Config) any { return &c.WorkingMemoryFile }),
		f("memory", "diary_token_count_trigger", "stop merging related entries after this many characters", int64(4000), func(c *Config) any { return &c.DiaryTokenTrigger }),
		f("memory", "sleep_max_time_secs", "how long one sleep consolidation may run", int64(600), func(c *Config) any { return &c.SleepMaxTime }),
		f("memory", "confidence_factor", "weight of an entry's stored confidence in RAG ranking", 0.1, func(c *Config) any { return &c.ConfidenceFactor }),
		f("memory", "max_related_entries", "how many diary entries are injected into a prompt", int64(8), func(c *Config) any { return &c.MaxRelatedEntries }),

		f("capabilities", "web_search_enabled", "", false, func(c *Config) any { return &c.WebSearchEnabled }),
		f("capabilities", "web_search_url", "SearXNG (…/search) or https://ollama.com/api/web_search", "http://localhost:8888/search", func(c *Config) any { return &c.WebSearchURL }),
		f("capabilities", "web_search_key", "bearer key (ollama web search)", "", func(c *Config) any { return &c.WebSearchKey }),
		f("capabilities", "stable_diffusion_enabled", "photos via Stable Diffusion WebUI (--api)", false, func(c *Config) any { return &c.SDEnabled }),
		f("capabilities", "stable_diffusion_url", "", "http://localhost:7860", func(c *Config) any { return &c.SDURL }),
		f("capabilities", "stt_enabled", "voice/video transcription (Whisper, OpenAI-compatible)", false, func(c *Config) any { return &c.STTEnabled }),
		f("capabilities", "stt_url", "", "http://localhost:9000/v1/", func(c *Config) any { return &c.STTURL }),
		f("capabilities", "stt_model", "", "whisper-1", func(c *Config) any { return &c.STTModel }),
		f("capabilities", "tts_backend", "none | openai | elevenlabs", "none", func(c *Config) any { return &c.TTSBackend }),
		f("capabilities", "tts_url", "OpenAI-compatible base (e.g. OmniVoice http://localhost:8880/v1/) or ElevenLabs base", "http://localhost:8880/v1/", func(c *Config) any { return &c.TTSURL }),
		f("capabilities", "tts_key", "", "", func(c *Config) any { return &c.TTSKey }),
		f("capabilities", "tts_model", "", "tts-1", func(c *Config) any { return &c.TTSModel }),
		f("capabilities", "tts_voice", "voice name / ElevenLabs voice id", "alloy", func(c *Config) any { return &c.TTSVoice }),
		f("capabilities", "ffmpeg_path", "needed for video transcription", "ffmpeg", func(c *Config) any { return &c.FFmpegPath }),
		f("telegram", "max_message_chars", "one Telegram message is at most this many characters; longer text is sent as several messages (no limit on their number). 0 = no limit", int64(60), func(c *Config) any { return &c.MaxMessageChars }),
		f("telegram", "typing_min_ms", "how long the 'typing...' status shows before each message (min)", int64(3000), func(c *Config) any { return &c.TypingMinMs }),
		f("telegram", "typing_max_ms", "how long the 'typing...' status shows before each message (max)", int64(4000), func(c *Config) any { return &c.TypingMaxMs }),
		f("telegram", "force_tool_call", "require the model to call a tool (reply, react or #wait) on the first round of every turn; fixes models that answer in plain text instead of calling #send_telegram_message", true, func(c *Config) any { return &c.ForceTools }),
		f("misc", "lazy_tools", "hide rarely used tools behind #more_tools (saves ~1.5-2k prompt tokens per request)", true, func(c *Config) any { return &c.LazyTools }),
		f("memory", "history_keep", "keep this many recent session messages verbatim; older ones are summarised once there are twice as many (0 = never summarise)", int64(24), func(c *Config) any { return &c.HistoryKeep }),
		f("capabilities", "use_stickers", "", true, func(c *Config) any { return &c.UseStickers }),

		f("misc", "metrics_enabled", "Prometheus endpoint at /metrics", true, func(c *Config) any { return &c.MetricsEnabled }),
		f("misc", "debug_ui", "web debug page at /debug (same port as proxy)", true, func(c *Config) any { return &c.DebugUI }),
		f("misc", "data_dir", "photos, voice, stickers, telegram state", "data", func(c *Config) any { return &c.DataDir }),
		f("misc", "prompts_dir", "prompt files; edited files are hot-reloaded", "prompts", func(c *Config) any { return &c.PromptsDir }),
	}
}

// ErrNeedsSetup is returned on the first run, after a default config.toml was written.
var ErrNeedsSetup = errors.New("config.toml was created; fill it in and start again")

// Load reads config.toml. If it does not exist, a default one is written and
// ErrNeedsSetup is returned, matching the behaviour of the C++ version.
func Load(path string) (*Config, error) {
	raw, err := os.ReadFile(path)
	if errors.Is(err, os.ErrNotExist) {
		if werr := os.WriteFile(path, []byte(defaultFileContents()), 0o644); werr != nil {
			return nil, werr
		}
		return nil, ErrNeedsSetup
	}
	if err != nil {
		return nil, err
	}
	values, err := parseTOML(string(raw))
	if err != nil {
		return nil, fmt.Errorf("%s: %w", path, err)
	}
	c := &Config{}
	for _, f := range fields() {
		v, ok := values[f.section+"."+f.key]
		if !ok {
			v = f.def
		}
		if err := assign(f.ptr(c), v); err != nil {
			return nil, fmt.Errorf("%s.%s: %w", f.section, f.key, err)
		}
	}
	// debounce_ms is stored as seconds by assign(); convert to milliseconds.
	c.DebounceWindow = c.DebounceWindow / 1000
	if c.LLMBaseURL != "" && c.LLMBaseURL[len(c.LLMBaseURL)-1] != '/' {
		c.LLMBaseURL += "/"
	}
	if c.EmbeddingBaseURL == "" {
		c.EmbeddingBaseURL = c.LLMBaseURL
	} else if c.EmbeddingBaseURL[len(c.EmbeddingBaseURL)-1] != '/' {
		c.EmbeddingBaseURL += "/"
	}
	return c, nil
}

func assign(dst any, v any) error {
	switch p := dst.(type) {
	case *string:
		s, ok := v.(string)
		if !ok {
			return fmt.Errorf("want string, got %T", v)
		}
		*p = s
	case *bool:
		b, ok := v.(bool)
		if !ok {
			return fmt.Errorf("want bool, got %T", v)
		}
		*p = b
	case *int64:
		n, err := toInt(v)
		if err != nil {
			return err
		}
		*p = n
	case *int:
		n, err := toInt(v)
		if err != nil {
			return err
		}
		*p = int(n)
	case *float64:
		switch t := v.(type) {
		case float64:
			*p = t
		case int64:
			*p = float64(t)
		default:
			return fmt.Errorf("want number, got %T", v)
		}
	case *time.Duration:
		// keys are named *_secs (or debounce_ms, handled by the unit below)
		n, err := toInt(v)
		if err != nil {
			return err
		}
		*p = time.Duration(n) * time.Second
	default:
		return fmt.Errorf("unsupported field type %T", dst)
	}
	return nil
}

func toInt(v any) (int64, error) {
	switch t := v.(type) {
	case int64:
		return t, nil
	case float64:
		return int64(t), nil
	}
	return 0, fmt.Errorf("want integer, got %T", v)
}

func defaultFileContents() string {
	var sections []tomlSection
	seen := map[string]int{}
	for _, f := range fields() {
		idx, ok := seen[f.section]
		if !ok {
			idx = len(sections)
			seen[f.section] = idx
			sections = append(sections, tomlSection{name: f.section})
		}
		sections[idx].items = append(sections[idx].items, tomlItem{key: f.key, value: f.def, comment: f.comment})
	}
	return formatTOML(sections)
}

// Holder gives lock-free access to the current config and notifies on reload.
type Holder struct {
	p         atomic.Pointer[Config]
	path      string
	listeners []func(*Config)
}

// NewHolder loads the config once.
func NewHolder(path string) (*Holder, error) {
	c, err := Load(path)
	if err != nil {
		return nil, err
	}
	h := &Holder{path: path}
	h.p.Store(c)
	return h, nil
}

// NewStaticHolder wraps an already-built config (tests).
func NewStaticHolder(c *Config) *Holder {
	h := &Holder{}
	h.p.Store(c)
	return h
}

func (h *Holder) Get() *Config { return h.p.Load() }

// OnChange registers a listener called (on the watcher goroutine) after a successful reload.
// Register before calling Watch.
func (h *Holder) OnChange(f func(*Config)) { h.listeners = append(h.listeners, f) }

// Watch hot-reloads the config file until ctx is done. A broken file keeps the old config.
func (h *Holder) Watch(ctx context.Context) {
	util.Watch(ctx, 2*time.Second, func() []string { return []string{h.path} }, func(string) {
		c, err := Load(h.path)
		if err != nil {
			log.Printf("config: reload failed, keeping old config: %v", err)
			return
		}
		h.p.Store(c)
		log.Printf("config: reloaded")
		for _, l := range h.listeners {
			l(c)
		}
	})
}
