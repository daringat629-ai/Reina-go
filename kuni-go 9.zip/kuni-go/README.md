# kuni-go

Go-порт [Kuni](https://github.com/Alex2772/kuni) (C++). Только стандартная библиотека Go 1.24+, без внешних зависимостей.

Все модули из оригинала перенесены и **соединены в один рабочий цикл**:

```
Telegram ──updates──▶ agent ──▶ LLM ◀──tool calls──▶ tools ──▶ Telegram / diary / web / SD / TTS
                        │                                   ▲
                        ├─ RAG: diary (embeddings) ─────────┘
                        └─ idle → дамп сессии → diary + working memory
OpenAI-клиент ──▶ proxy (контекст, ask-tool, tool-loop) ──▶ upstream LLM
```

## Что есть

| C++ (`src/`) | Go (`internal/`) | |
|---|---|---|
| `config.cpp`, toml11, hot-reload | `config/` — свой парсер TOML-подмножества, опрос mtime | ✔ |
| `prompts.cpp` (13 промптов) | `prompts/` — **оригинальные тексты дословно** (`defaults/*.md`), `${VARS}`, hot-reload | ✔ |
| `OpenAIChatImpl`, streaming | `llm/` — chat, tool calls, vision-части, SSE, embeddings | ✔ |
| `Diary.cpp` | `diary/` — RAG, «сон» (консолидация) | ✔ |
| working memory, `diaryDumpMessages` | `memory/` — дамп сессии в дневник + обновление `working_memory.md`, антиплагиат | ✔ |
| `telegram/` (tdlib) | `telegram/` — интерфейс `Client`; **пользовательский аккаунт через tdlib** (`td.go`, как в оригинале), запасной Bot API-клиент, in-memory Fake | ⚠ tdlib не прогонялся с реальной библиотекой |
| `tools/*` (все 20) | `tools/` — реестр + все инструменты, наборы под тип чата (канал / не участник / группа / админ) | ✔ |
| `llmui/` | `llmui/` — `<message>`/`<chat>`, голосовые → STT, фото/стикеры → описание, видео → кадры+аудио, защита от инъекции `kuni_embedding` | ✔ |
| `ImageGenerator.cpp` | `imagegen/` — prompt-engineer → Stable Diffusion → LLM-критик, ретраи | ✔ (упрощён) |
| Whisper, TTS, ElevenLabs, web search, ffmpeg | `media/` | ✔ |
| `main.cpp`, `App`, `Worker` | `agent/` + `main.go` — сессии по чатам, дебаунс, lockdown, acting proactively, дамп при простое/выходе | ✔ |
| `proxy_server/` | `proxy/` — инъекция контекста, tool-loop для `ask`, SSE, passthrough, `MessageInjector`, `ContextBridge` | ✔ |
| `Prometheus.cpp`, Grafana | `metrics/` — `/metrics`, имена `llm_usage_*`, `tool_call_*` как в дашборде | ⚠ |
| AUI debug-окно | `debugui/` — веб-страница `/debug` | ✔ |
| `docker-compose.yml`, `ollama_setup.sh`, `grafana/` | скопированы как есть | ✔ |

## Запуск

```bash
go build -tags tdlib -o kuni .     # пользовательский режим (нужна libtdjson, см. ниже)
# или без tdlib — только режим bot и прокси:
go build -o kuni .
./kuni            # первый запуск создаёт config.toml и выходит
```

В `config.toml`: `[llm]` base_url/model; `[general] telegram_enabled = true`; `[telegram]`:
- `mode = "user"` (по умолчанию, как в оригинале) — `api_id`/`api_hash` с https://my.telegram.org, `phone_number`
  (или ввод в консоль). Код и облачный пароль запрашиваются в stdin при первом входе, сессия хранится в `tdlib_dir`.
- `mode = "bot"` — только `bot_token` от @BotFather.

### Установка libtdjson для режима user
```bash
git clone https://github.com/tdlib/td && cd td && mkdir build && cd build
cmake -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX=/usr/local .. && cmake --build . --target install -j4
# нужны: cmake, gperf, g++, libssl-dev, zlib1g-dev
cd /путь/к/kuni-go && go build -tags tdlib -o kuni .   # при нестандартном пути: CGO_LDFLAGS=-L<dir> CGO_CFLAGS=-I<dir>
```
Нужна версия tdlib с `setChatMemberTag` (свежий master, как в C++ проекте) и `td_send`/`td_receive` (1.8.0+).

```bash
go test ./... && go test -race ./...
```

Каталог `prompts/` создаётся при первом запуске; редактируйте файлы там — они подхватываются без перезапуска
(правка кода промптов не нужна, как и в оригинале). Прокси, `/metrics` и `/debug` слушают порт `[proxy] port` (10434).

## Честно о том, что отличается и что не проверено

**Проверено тестами с фейками** (фейковый LLM, фейковый Bot API, реальный ffmpeg): агент, инструменты, прокси, дневник,
конфиг, промпты, метрики, клиент Bot API, медиа-клиенты. **Не запускалось** против настоящих Telegram, Ollama/DeepSeek,
Stable Diffusion, Whisper и TTS — это первый шаг, который стоит сделать вам.

**Telegram: пользовательский аккаунт через tdlib.** `telegram.TDClient` говорит с tdlib по JSON-интерфейсу
(`td_json`), как C++ `TelegramClientImpl`: вход по телефону/коду/паролю, `getChats`/`getChatHistory`/`viewMessages`
с `force_read`, реакции, пересылка, правка текста и подписей, `setChatMemberTag`, `banChatMember`, блокировка и удаление
личного чата, контакты для `lockdown = contacts_only`, статус «онлайн» только пока идёт обработка, троттлинг до 20
запросов/с (Telegram банит агрессивных сторонних клиентов). Тонкая cgo-обёртка над `libtdjson` лежит в
`td_cgo.go` (тег `tdlib`); вся логика — в чистом Go поверх интерфейса `Transport`.

**Что проверено, а что нет:** логика клиента проверена 12 тестами на скриптованном фейковом tdlib (вход, преобразование
сообщений, **id > 2^53 и int64-как-строки**, формы всех запросов, смещения истории, права в группах, троттлинг), а cgo-слой
собран и прогнан со **стаб**-библиотекой. С *настоящей* libtdjson и аккаунтом Telegram он **не запускался** (в моей среде
нет сети для сборки tdlib). Названия полей tdlib написаны по памяти схемы `td_api` — на живом аккаунте возможны мелкие
расхождения (в первую очередь: `reply_to`, `topic`-поля, `setChatMemberTag`); ошибки tdlib возвращаются модели
как текст, так что их будет видно в логах.

**Режим bot (запасной).** Бот видит только адресованные ему сообщения и историю с момента запуска; не умеет вступать
в чаты, блокировать, управлять «онлайн»/«прочитано». `setChatMemberTag` в Bot API я не сверял.

**Упрощения относительно C++:**
- `imagegen`: 6 попыток вместо сложной схемы с галереей; нет повторного добавления откровенных слов в промпт
  (намеренно), «ребёнок» всегда в negative prompt.
- прокси: цикл tool-call'ов идёт в не-стримовом режиме, SSE для клиента синтезируется; `streaming_filter` не переносился.
- метрики: нет гистограммных bucket'ов (панели с `histogram_quantile` останутся пустыми); цель Prometheus —
  `host.docker.internal:10434`.
- стикеры в user-режиме: вместо «избранных» tdlib используется свой набор `data/stickers.json` (`sticker_save`);
- ключи `config.toml` другие и **не совместимы** со старым файлом.
- веб-поиск: SearXNG (`/search?format=json`) или Ollama web_search.

**Отличие поведения.** В C++ обработанная в «сне» запись-цель, судя по коду, не удалялась с диска (дубли копились);
в Go она удаляется, если `confidence < 1` (записи с `confidence = 1` — «факты» — неприкосновенны).

## Пресет персонажа: Reina Veil

Готовый пресет лежит в `examples/reina_veil/`. Чтобы включить: скопируйте оба файла в `prompts/`
(`cp examples/reina_veil/*.md prompts/`; там же компактные `system.md` и `character_base.md`, экономят ~40% токенов), в `config.toml` задайте `character_name = "Reina Veil"`.
Горячая перезагрузка подхватит файлы без перезапуска.

## Экономия токенов

- `[misc] lazy_tools = true` — редкие инструменты (медиа, правка/удаление, админка, поиск сообщений) скрыты за одним
  `more_tools`; список инструментов в приватном чате ~2,1k → ~1,1k токенов. Медиа открывается автоматически, если во
  входящем есть фото/голос/стикер или слова «фото, голос, стикер…».
- `[memory] history_keep = 24` — когда в сессии набирается вдвое больше сообщений, старая часть сжимается в краткую
  сводку (последние 24 остаются дословно). `0` — отключить.
- Продолжающаяся сессия не повторяет «earlier messages» целиком на каждом ходу.
- Метрика `kuni_llm_tokens_total{model,purpose,direction}` (purpose: reply / ask / diary / sleep / compact / image) и
  `kuni_llm_last_prompt_tokens{purpose}` — видно, на что уходят токены.

## Промпты по умолчанию

В сборку зашиты короткие промпты Рейны Вейл (`internal/prompts/defaults/`: system, character_base, character_appearance;
остальные 10 — оригинальные). При первом запуске они записываются в `prompts/`. Оригинальные промпты Куни лежат в
`examples/kuni_original/`. Если в `prompts/` уже есть старые файлы, программа их не перезаписывает: удалите нужные
(`rm prompts/system.md prompts/character_base.md prompts/character_appearance.md`) и перезапустите.

## Как она пишет

- `[telegram] max_message_chars = 60` — одно сообщение не длиннее 60 символов; длинный текст режется на несколько
  (по концу предложения или пробелу), число сообщений не ограничено. `0` — без нарезки.
- `typing_min_ms = 3000`, `typing_max_ms = 4000` — перед каждым сообщением показывается «печатает…» 3–4 секунды.
- В промпте: собственная воля (может согласиться, отказать, подразнить, проигнорировать), играет только когда сама захочет,
  не ведёт себя как ассистент.
