package llm

import "testing"

func TestIsGoogle(t *testing.T) {
	for url, want := range map[string]bool{
		"https://generativelanguage.googleapis.com/v1beta/openai/": true,
		"https://api.inceptionlabs.ai/v1/":                         false,
		"https://openrouter.ai/api/v1/":                            false,
	} {
		if got := isGoogle(url); got != want {
			t.Errorf("%s: %v, want %v", url, got, want)
		}
	}
}
