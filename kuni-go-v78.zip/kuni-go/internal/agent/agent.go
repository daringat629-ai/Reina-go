// Package agent is her mind at work: it takes what arrives from Telegram, decides when she looks at a chat, lets
// the model think and act through tools, and files what happened into her memory when a conversation goes quiet.
// It is the Go counterpart of App/Worker/AppBase.
//
// It is made of parts that each keep their own state behind their own lock (they used to be seven maps, a journal
// and the pending approvals of one struct under one mutex):
//
//	inbox      when she looks at a chat: debounce, group batches, living presence (pauses, late replies), the queue
//	sessions   the open conversations, their rolling summaries, the dump into the diary when a talk goes quiet
//	turn       one answer: the model thinks, the tools act, until she is done (turn.go)
//	calls      what happens around every tool call (calls.go): de-duplication, her autonomy limits, the owner's
//	           approval of risky actions, read-only calls in parallel, the action journal, metrics, the live feed
//	view       what the model reads when it opens a chat (view.go)
//	journal    what she did (actions.json); approvals: risky actions waiting for the owner's yes
//	loops      reminders, schedules and monitors, background work, her free time, the daily backup (loops.go)
//	commands   the owner's slash commands, answered without the model (commands.go)
package agent

import (
	"context"
	"encoding/json"
	"fmt"
	"kuni/internal/machine"
	"kuni/internal/rhythm"
	"log"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"kuni/internal/autonomy"
	"kuni/internal/config"
	"kuni/internal/diary"
	"kuni/internal/live"
	"kuni/internal/llm"
	"kuni/internal/llmui"
	"kuni/internal/memory"
	"kuni/internal/metrics"
	"kuni/internal/prompts"
	"kuni/internal/run"
	"kuni/internal/telegram"
	"kuni/internal/tools"
	"kuni/internal/usage"
	"kuni/internal/util"
)

type Agent struct {
	innerOnce     sync.Once    // the inner monologue file is opened on first use
	reflect       reflectState // the rhythm of thinking about her own surprises
	inner         *thoughts
	questionMu    sync.Mutex // the open question of the day is offered once
	questionDay   string
	adviceSeedDay string // the day she was last asked whether something is worth asking people about
	failures      failureLog
	machMu        sync.Mutex
	rhythmOnce    sync.Once
	rhythm        *rhythm.Tracker
	mach          machine.State
	machAt        time.Time
	machFill      float64 // how full the context of the session being prepared is
	Cfg           *config.Holder
	LLM           *llm.Client
	TG            telegram.Client
	Diary         *diary.Diary
	Prompts       *prompts.Store
	UI            *llmui.Env
	Dumper        *memory.Dumper
	Metrics       *metrics.Registry
	Deps          tools.Deps
	Auto          *autonomy.State                 // nil = autonomy unavailable
	Usage         *usage.Tracker                  // nil = no budget
	Price         func(model string) usage.Prices // nil = no prices known (the panel shows tokens only)
	ConfigPath    string                          // config.toml, for /backup with backup.include_config
	Started       time.Time                       // for the uptime in /status
	Feed          *live.Feed                      // what she does, for the panel (nil = Deps.RT.Feed)

	paused atomic.Bool
	active atomic.Int32 // turns in progress: the account shows "online" while > 0
	seen   atomic.Int64 // when the account last went offline (unix nanoseconds; 0 = not yet)

	// life ends when Run returns: the turns that outside events start (a reminder, an approval, a finished job) run
	// in it. It exists from New on, so nothing has to wait for Run to set it.
	life context.Context
	end  context.CancelFunc

	inbox     *inbox
	sessions  *sessions
	journal   *journal
	approvals *approvals
	bg        background

	// retryDelays are the pauses before the 1st, 2nd... repeat of a failed turn.
	retryDelays []time.Duration
}

// New initialises internal state of a (fill the exported fields first).
func New(a *Agent) *Agent {
	a.life, a.end = context.WithCancel(context.Background())
	if a.Feed == nil && a.Deps.RT != nil {
		a.Feed = a.Deps.RT.Feed
	}
	dataDir := ""
	if a.Cfg != nil {
		dataDir = a.Cfg.Get().DataDir
	}
	path := func(name string) string {
		if dataDir == "" {
			return ""
		}
		return filepath.Join(dataDir, name)
	}
	a.sessions = newSessions(path("carry.json"), a.Metrics)
	a.journal = newJournal(path("actions.json"))
	a.approvals = &approvals{}
	a.retryDelays = []time.Duration{20 * time.Second, 90 * time.Second, 5 * time.Minute}
	a.inbox = &inbox{
		chats:   map[int64]*chatState{},
		cfg:     a.cfg,
		isGroup: a.isGroup,
		typing:  a.peerTyping,
		handle:  a.handleScheduled,
		title:   a.sessions.title,
		metrics: a.Metrics,
	}
	return a
}

func (a *Agent) cfg() *config.Config { return a.Cfg.Get() }

// SystemPrompt is system + character_base + <your_appearance> (AppBase::getSystemPrompt).
func (a *Agent) SystemPrompt() string { return a.systemPromptBase() + a.machineRule() }

// machineRule is the hard instruction of the machine mode (empty when it is off).
func (a *Agent) machineRule() string {
	if a.machineOn() {
		return machine.Rule
	}
	return ""
}

func (a *Agent) systemPromptBase() string {
	return a.Prompts.Get(prompts.System) + "\n\n" + a.Prompts.Get(prompts.CharacterBase) +
		"\n\n<your_appearance>\n" + a.Prompts.Get(prompts.CharacterAppearance) + "\n</your_appearance>"
}

// SystemPromptFor adds the owner's powers (owner_powers.md) in the sessions where she has them: his private chat
// and background jobs. Everywhere else they cost tokens and only tell strangers what to ask her for.
// Both variants are stable strings, so provider-side prompt caching keeps working for each.
func (a *Agent) SystemPromptFor(s *session) string { return a.systemPromptFor(s) + a.machineRule() }

func (a *Agent) systemPromptFor(s *session) string {
	base := a.systemPromptBase()
	if s == nil || !(s.id == workSessionID || a.cfg().OwnerChat(s.id)) {
		return base
	}
	powers := strings.TrimSpace(a.Prompts.Get(prompts.OwnerPowers))
	// a system.md edited before the split still carries the old owner block: do not say it twice
	if powers == "" || strings.Contains(a.Prompts.Get(prompts.System), "download_telegram_file") {
		return base
	}
	return a.Prompts.Get(prompts.System) + "\n\n" + powers + "\n\n" + a.Prompts.Get(prompts.CharacterBase) +
		"\n\n<your_appearance>\n" + a.Prompts.Get(prompts.CharacterAppearance) + "\n</your_appearance>"
}

// Run processes Telegram updates until ctx ends, then waits for the turns in flight and dumps all open sessions.
func (a *Agent) Run(ctx context.Context) {
	defer a.end()
	go func() { // the agent's own life ends with ctx
		<-ctx.Done()
		a.end()
	}()
	sup := &run.Supervisor{OnCrash: func(name string) {
		a.Metrics.Inc("kuni_app_restarts_total", 1, map[string]string{"loop": "agent " + name})
	}}
	sup.Go(ctx, "reminders", a.reminderLoop)
	sup.Go(ctx, "idle sessions", a.idleLoop)
	sup.Go(ctx, "free time", a.proactiveLoop)
	sup.Go(ctx, "inner voice", a.innerLoop)
	sup.Go(ctx, "self surprise", a.surpriseLoop)
	sup.Go(ctx, "self shift", a.shiftLoop)
	sup.Go(ctx, "background work", a.workLoop)
	sup.Go(ctx, "backup to the owner", a.backupLoop)
	sup.Go(ctx, "schedules", a.schedLoop)

	// handle messages that arrived while we were offline
	a.scheduleUnread(ctx)

	updates := a.TG.Updates()
	var events <-chan telegram.Event // nil (blocks forever) when the client does not report them
	if es, ok := a.TG.(telegram.EventSource); ok {
		events = es.Events()
	}
loop:
	for {
		select {
		case <-ctx.Done():
			break loop
		case m, ok := <-updates:
			if !ok {
				break loop
			}
			a.incoming(ctx, m)
		case ev := <-events:
			a.onEvent(ctx, ev)
		}
	}
	sup.Wait()
	a.bg.wait(30 * time.Second) // turns, reminders, approvals... still running share ctx: they end quickly

	// graceful shutdown: give the LLM time to dump the remaining context.
	dumpCtx, cancel := context.WithTimeout(context.Background(), 3*time.Minute)
	defer cancel()
	a.DumpAll(dumpCtx)
}

// incoming is the first look at a new message: a command is answered at once, an ignored sender costs nothing,
// everything else puts the chat in the inbox.
func (a *Agent) incoming(ctx context.Context, m telegram.Message) {
	a.Metrics.Inc("kuni_telegram_messages_received_total", 1, nil)
	log.Printf("agent: incoming message in chat %d from %q (%d chars)", m.ChatID, m.SenderName, len(m.Text))
	if !m.Outgoing {
		a.feed(live.Event{Kind: "chat", Chat: m.SenderName, Text: "← " + m.Text, ChatID: m.ChatID})
	}
	if a.command(ctx, m) {
		return
	}
	if a.ignoredMessage(m) {
		a.Metrics.Inc("kuni_ignored_total", 1, nil)
		return // on the ignore list: no timer, no reading, no model call
	}
	a.inbox.schedule(ctx, m.ChatID)
}

// scheduleUnread puts every chat with unread messages into the inbox (start, resume).
func (a *Agent) scheduleUnread(ctx context.Context) {
	chats, err := a.TG.Chats(ctx, 100)
	if err != nil {
		log.Printf("agent: the chat list: %v", err)
		return
	}
	for _, c := range chats {
		if c.Unread > 0 {
			a.inbox.schedule(ctx, c.ID)
		}
	}
}

// isGroup tells the inbox whether a chat is batched like a group (only asked when group batching is configured).
func (a *Agent) isGroup(ctx context.Context, chatID int64) bool {
	ch, err := a.TG.Chat(ctx, chatID)
	return err == nil && ch.Kind != telegram.ChatPrivate
}

// peerTyping says whether the person in a private chat is typing (or recording a voice message) right now.
func (a *Agent) peerTyping(ctx context.Context, chatID int64) bool {
	ch, err := a.TG.Chat(ctx, chatID)
	return err == nil && ch.Kind == telegram.ChatPrivate && (ch.Typing == "typing" || ch.Typing == "voice")
}

// handleScheduled is what the inbox calls when a chat's time has come: one turn, tracked so that shutdown waits for
// it before the final dump, with a panic contained to this chat.
func (a *Agent) handleScheduled(ctx context.Context, chatID int64) {
	a.bg.run("chat "+strconv.FormatInt(chatID, 10), func() {
		if err := a.HandleChat(ctx, chatID); err != nil {
			log.Printf("agent: chat %d: %v", chatID, err)
		}
	})
}

// feed shows an event in the panel's live feed.
func (a *Agent) feed(e live.Event) {
	if a.Feed != nil {
		a.Feed.AddEvent(e)
	}
}

// Paused reports whether replies are paused.
func (a *Agent) Paused() bool { return a.paused.Load() }

// SetPaused pauses or resumes replying. Messages that arrive while paused stay unread
// and every chat with unread messages is handled right after resuming.
func (a *Agent) SetPaused(p bool) {
	was := a.paused.Swap(p)
	log.Printf("agent: paused=%v", p)
	if was && !p {
		a.spawn("resume", func() { a.scheduleUnread(a.life) })
	}
}

// goOnline shows the account as online while a turn runs (user mode only) and
// returns a func that schedules going offline again shortly after the last turn.
func (a *Agent) goOnline(ctx context.Context) func() {
	p, ok := a.TG.(interface {
		SetOnline(ctx context.Context, online bool)
	})
	if !ok {
		return func() {}
	}
	if a.active.Add(1) == 1 {
		p.SetOnline(ctx, true)
	}
	return func() {
		a.active.Add(-1)
		a.seen.Store(time.Now().UnixNano())
		time.AfterFunc(a.offlineAfter(), func() {
			if a.active.Load() == 0 {
				c, cancel := context.WithTimeout(context.Background(), 10*time.Second)
				defer cancel()
				p.SetOnline(c, false)
			}
		})
	}
}

// typeWhileThinking keeps the "typing…" indicator on in private chats while a model call is running.
func (a *Agent) typeWhileThinking(ctx context.Context, s *session) func() {
	if !a.cfg().TypingThinking || s.id == 0 || s.chat.Kind != telegram.ChatPrivate {
		return func() {}
	}
	c, cancel := context.WithCancel(ctx)
	go func() {
		for {
			_ = a.TG.Typing(c, s.id)
			select {
			case <-c.Done():
				return
			case <-time.After(4 * time.Second):
			}
		}
	}()
	return cancel
}

// liveTarget finds the Telegram chat a tool call is about and the text it writes there, for the panel's Telegram view.
func liveTarget(name, args string, current int64) (chatID int64, typing string) {
	chatID = current
	if name == "telegram_ui" { // the screen reports where she looks itself; "chat" there may be a number from the list
		return 0, ""
	}
	var v map[string]any
	if json.Unmarshal([]byte(args), &v) != nil {
		return
	}
	if n, ok := v["chat_id"].(float64); ok && n != 0 {
		chatID = int64(n)
	} else if s, ok := v["chat"].(string); ok {
		if n, err := strconv.ParseInt(strings.TrimSpace(s), 10, 64); err == nil {
			chatID = n
		}
	}
	text, _ := v["text"].(string)
	switch name {
	case "send_telegram_message", "edit_message_text", "send_to_chat":
		typing = text
	case "tg_api":
		if act, _ := v["action"].(string); act == "send" || act == "edit" {
			typing = text
		}
	}
	return
}

// dumpPrompt writes what the model is about to see to <data_dir>/last_prompt.txt (misc.debug_prompt).
func (a *Agent) dumpPrompt(cfg *config.Config, system string, msgs []llm.Message, toolNames []string, fast bool, round int) {
	var b strings.Builder
	fmt.Fprintf(&b, "# round=%d fast=%v reasoning=%q tools=%v\n# system prompt: %d chars, tail:\n%s\n\n", round, fast, cfg.Reasoning, toolNames, len(system), util.Trunc(system[max(0, len(system)-1500):], 1500))
	for _, m := range msgs {
		fmt.Fprintf(&b, "--- %s ---\n%s\n", m.Role, m.Content)
		for _, c := range m.ToolCalls {
			fmt.Fprintf(&b, "[call %s %s]\n", c.Function.Name, c.Function.Arguments)
		}
	}
	_ = os.MkdirAll(cfg.DataDir, 0o700)
	_ = os.WriteFile(filepath.Join(cfg.DataDir, "last_prompt.txt"), []byte(b.String()), 0o600)
}

// rhythmT is the tracker of how the owner writes (made on first use).
func (a *Agent) rhythmT() *rhythm.Tracker {
	a.rhythmOnce.Do(func() { a.rhythm = rhythm.New() })
	return a.rhythm
}
