package agent

import (
	"testing"
	"time"
)

func TestPrivateFire(t *testing.T) {
	now := time.Now()
	s := time.Second
	cases := []struct {
		name       string
		first      time.Time
		quiet, max time.Duration
		exp        time.Duration
	}{
		{"first message: the full quiet wait", now, 4 * s, 20 * s, 4 * s},
		{"a steady stream is cut off by the cap", now.Add(-18 * s), 4 * s, 20 * s, 2 * s},
		{"cap already passed: read now", now.Add(-30 * s), 4 * s, 20 * s, 0},
		{"no cap", now.Add(-300 * s), 4 * s, 0, 4 * s},
	}
	for _, c := range cases {
		if got := privateFire(now, c.first, c.quiet, c.max); got != c.exp {
			t.Errorf("%s: %v, want %v", c.name, got, c.exp)
		}
	}
}
