package agent

import (
	"context"
	"sync/atomic"
	"testing"
	"time"

	"kuni/internal/config"
)

func TestInboxWaitsWhileTyping(t *testing.T) {
	old := typingRecheck
	typingRecheck = 20 * time.Millisecond
	defer func() { typingRecheck = old }()

	var typingCalls, handled atomic.Int32
	in := &inbox{
		chats: map[int64]*chatState{},
		cfg:   func() *config.Config { return &config.Config{DebounceWindow: 10 * time.Millisecond} },
		typing: func(context.Context, int64) bool {
			return typingCalls.Add(1) <= 3 // typing for the first three looks, then stops
		},
		handle: func(context.Context, int64) { handled.Add(1) },
	}
	in.schedule(context.Background(), 7)
	time.Sleep(25 * time.Millisecond)
	if handled.Load() != 0 {
		t.Fatalf("answered while they were still typing (%d looks)", typingCalls.Load())
	}
	time.Sleep(200 * time.Millisecond)
	if handled.Load() != 1 || typingCalls.Load() < 4 {
		t.Fatalf("handled %d, looks %d: should answer once after they stopped", handled.Load(), typingCalls.Load())
	}
}
