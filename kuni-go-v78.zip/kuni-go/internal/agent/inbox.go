package agent

import (
	"context"
	"fmt"
	"log"
	"sort"
	"sync"
	"time"

	"kuni/internal/config"
	"kuni/internal/metrics"
)

// The inbox decides WHEN she looks at a chat. A new message does not start a turn at once:
//   - a private chat waits a short debounce (telegram.debounce_ms) for the rest of a burst;
//   - a group waits for a quiet moment, but not longer than group_max_wait after the first new message, and not
//     sooner than group_cooldown after her last answer there; a batch arriving during a turn is read after it;
//   - living presence may hold a chat back for minutes (a late reply at night, a busy moment): new messages just
//     join the old ones and are read together when she comes back;
//   - while she "notices" a chat (the read pause before opening it) a second call for the same chat is not started.
//
// All of it is per-chat state in one place: chatState. The panel's queue ("who is waiting and why") is read from it.
type inbox struct {
	mu    sync.Mutex
	chats map[int64]*chatState

	cfg     func() *config.Config
	isGroup func(ctx context.Context, chatID int64) bool // asked only when group batching is configured
	typing  func(ctx context.Context, chatID int64) bool // the other person in a private chat is typing (or recording) right now
	handle  func(ctx context.Context, chatID int64)      // runs one turn for the chat (HandleChat)
	title   func(chatID int64) string                    // for the panel's queue ("" = unknown)
	metrics *metrics.Registry
}

// chatState is everything the inbox knows about one chat.
type chatState struct {
	timer *time.Timer

	// living presence
	lateUntil time.Time // a late reply: she does not look at the chat before this
	lateUsed  bool      // the current messages were postponed once already: do not postpone them again
	noticing  bool      // a call is in the read pause for this chat

	// what the panel shows
	phase string // waiting | noticing | late | thinking ("" = not in the queue)
	since time.Time
	until time.Time // late: when she will look

	// group batching
	first   time.Time // first message of the batch that is still waiting (zero = none)
	running bool      // a turn in this group is in progress
	pending bool      // messages arrived during that turn: schedule again when it ends
	lastEnd time.Time // when the last turn in this group ended
}

// idle reports whether the state holds nothing worth keeping.
func (c *chatState) idle(now time.Time, cooldown time.Duration) bool {
	return c.timer == nil && c.phase == "" && !c.noticing && !c.lateUsed && !c.running && !c.pending &&
		!now.Before(c.lateUntil) && (c.lastEnd.IsZero() || now.Sub(c.lastEnd) > cooldown)
}

// stateLocked returns the chat's state, creating it (in.mu held).
func (in *inbox) stateLocked(chatID int64) *chatState {
	c := in.chats[chatID]
	if c == nil {
		c = &chatState{}
		in.chats[chatID] = c
	}
	return c
}

// tidyLocked forgets a chat whose state is empty (in.mu held), so the map does not grow with every chat ever seen.
func (in *inbox) tidyLocked(chatID int64) {
	if c := in.chats[chatID]; c != nil && c.idle(time.Now(), in.cfg().GroupCooldown) {
		delete(in.chats, chatID)
	}
}

// groupFire says how long to wait before reading a group: until it has been quiet for `quiet`, but not longer than
// maxWait after the first waiting message, and never sooner than `cooldown` after her last turn there.
func groupFire(now, first, lastEnd time.Time, quiet, maxWait, cooldown time.Duration) time.Duration {
	fire := now.Add(quiet)
	if maxWait > 0 && !first.IsZero() {
		if capAt := first.Add(maxWait); fire.After(capAt) {
			fire = capAt
		}
	}
	if cooldown > 0 && !lastEnd.IsZero() {
		if e := lastEnd.Add(cooldown); fire.Before(e) {
			fire = e
		}
	}
	if d := fire.Sub(now); d > 0 {
		return d
	}
	return 0
}

var (
	typingHoldMax = 60 * time.Second // however long they type, she answers at the latest this long after the first message
	typingRecheck = 2 * time.Second  // how often she looks again while they are typing
)

// privateFire is how long to wait before reading a private chat: until the person has been quiet for `quiet`, but not
// longer than maxWait after the first waiting message (0 = no limit).
func privateFire(now, first time.Time, quiet, maxWait time.Duration) time.Duration {
	if maxWait > 0 && !first.IsZero() {
		if left := first.Add(maxWait).Sub(now); left < quiet {
			return max(left, 0)
		}
	}
	return quiet
}

// schedule debounces bursts of messages, then handles the chat once. In a group the burst is a batch: she waits
// for a quiet moment (but not forever) and then reads everything at once, and not again right after answering.
func (in *inbox) schedule(ctx context.Context, chatID int64) {
	cfg := in.cfg()
	delay := cfg.DebounceWindow
	group := false
	if cfg.GroupDebounce > 0 || cfg.GroupMaxWait > 0 || cfg.GroupCooldown > 0 {
		group = in.isGroup(ctx, chatID)
	}
	in.mu.Lock()
	defer in.mu.Unlock()
	c := in.stateLocked(chatID)
	if time.Now().Before(c.lateUntil) {
		return // she is not looking at this chat yet; new messages just wait with the old ones
	}
	if group {
		if c.running {
			c.pending = true // never two turns at once: the next batch is scheduled when this one ends
			return
		}
		now := time.Now()
		if c.first.IsZero() {
			c.first = now
		}
		delay = groupFire(now, c.first, c.lastEnd, max(delay, cfg.GroupDebounce), cfg.GroupMaxWait, cfg.GroupCooldown)
	}
	if !group {
		// a person typing in bursts: every new message restarts the wait, but not past DebounceMax from the first one
		now := time.Now()
		if c.first.IsZero() {
			c.first = now
		}
		delay = privateFire(now, c.first, delay, cfg.DebounceMax)
	}
	if c.timer != nil {
		c.timer.Stop()
	}
	in.setPhaseLocked(chatID, "waiting", time.Time{})
	c.timer = time.AfterFunc(delay, func() { in.fire(ctx, chatID, group) })
}

// fire is the end of a chat's wait: one turn, with the group bookkeeping around it.
func (in *inbox) fire(ctx context.Context, chatID int64, group bool) {
	if ctx.Err() != nil {
		return
	}
	if !group && in.typing != nil && in.typing(ctx, chatID) {
		// they are still typing: look again shortly instead of answering half of what they want to say
		in.mu.Lock()
		c := in.stateLocked(chatID)
		if !c.first.IsZero() && time.Since(c.first) < typingHoldMax {
			c.timer = time.AfterFunc(typingRecheck, func() { in.fire(ctx, chatID, false) })
			in.mu.Unlock()
			return
		}
		in.mu.Unlock()
	}
	in.mu.Lock()
	c := in.stateLocked(chatID)
	c.timer = nil
	if group {
		c.first, c.running, c.pending = time.Time{}, true, false // this batch is taken; later messages start the next one
	} else {
		c.first = time.Time{}
	}
	in.mu.Unlock()
	defer func() { // runs last: after the turn and after the chat left the queue
		if !group {
			return
		}
		in.mu.Lock()
		c := in.stateLocked(chatID)
		c.running, c.lastEnd = false, time.Now()
		again := c.pending
		c.pending = false
		in.mu.Unlock()
		if again && ctx.Err() == nil {
			in.schedule(ctx, chatID)
		}
	}()
	defer in.endPhase(chatID)
	in.handle(ctx, chatID)
}

// postpone holds the chat back for d and handles it afterwards (the deferral is then used up).
func (in *inbox) postpone(ctx context.Context, chatID int64, d time.Duration) {
	in.mu.Lock()
	c := in.stateLocked(chatID)
	until := time.Now().Add(d)
	c.lateUntil = until
	in.setPhaseLocked(chatID, "late", until)
	if c.timer != nil {
		c.timer.Stop()
	}
	c.timer = time.AfterFunc(d, func() {
		if ctx.Err() != nil {
			return
		}
		in.mu.Lock()
		c := in.stateLocked(chatID)
		c.timer, c.lateUntil, c.lateUsed = nil, time.Time{}, true // do not postpone the same messages twice
		in.setPhaseLocked(chatID, "waiting", time.Time{})
		in.mu.Unlock()
		defer in.endPhase(chatID)
		in.handle(ctx, chatID)
	})
	in.mu.Unlock()
	in.metrics.Inc("kuni_presence_late_replies_total", 1, nil)
	log.Printf("agent: chat %d: will look at it in %s (late reply)", chatID, d.Round(time.Second))
}

// postponedUntil reports whether a late reply is pending for the chat.
func (in *inbox) postponedUntil(chatID int64) (time.Time, bool) {
	in.mu.Lock()
	defer in.mu.Unlock()
	if c := in.chats[chatID]; c != nil && !c.lateUntil.IsZero() {
		return c.lateUntil, true
	}
	return time.Time{}, false
}

// takeUsed reports (and clears) that the chat was already postponed once for the current messages.
func (in *inbox) takeUsed(chatID int64) bool {
	in.mu.Lock()
	defer in.mu.Unlock()
	c := in.chats[chatID]
	if c == nil {
		return false
	}
	u := c.lateUsed
	c.lateUsed = false
	return u
}

// beginNoticing marks the chat as being looked at; false = another call already waits to open it (that one will
// see everything unread).
func (in *inbox) beginNoticing(chatID int64) bool {
	in.mu.Lock()
	defer in.mu.Unlock()
	c := in.stateLocked(chatID)
	if c.noticing {
		return false
	}
	c.noticing = true
	return true
}

func (in *inbox) endNoticing(chatID int64) {
	in.mu.Lock()
	defer in.mu.Unlock()
	if c := in.chats[chatID]; c != nil {
		c.noticing = false
	}
}

// --- the queue the panel shows ---

// QueueItem is a chat she has not answered yet and why: the panel shows these.
type QueueItem struct {
	ChatID int64     `json:"chat_id"`
	Title  string    `json:"title"`
	Phase  string    `json:"phase"` // waiting | noticing | late | thinking
	Since  time.Time `json:"since"`
	Until  time.Time `json:"until,omitempty"` // late: when she will look
}

func (in *inbox) setPhase(chatID int64, phase string, until time.Time) {
	in.mu.Lock()
	defer in.mu.Unlock()
	in.setPhaseLocked(chatID, phase, until)
}

// setPhaseLocked is setPhase for callers that hold in.mu.
func (in *inbox) setPhaseLocked(chatID int64, phase string, until time.Time) {
	c := in.stateLocked(chatID)
	if c.phase != phase {
		c.since = time.Now()
	}
	c.phase, c.until = phase, until
}

// endPhase takes the chat off the queue unless it is postponed (a late reply keeps its entry until it fires).
func (in *inbox) endPhase(chatID int64) {
	in.mu.Lock()
	defer in.mu.Unlock()
	c := in.chats[chatID]
	if c == nil {
		return
	}
	if c.phase == "late" && time.Now().Before(c.until) {
		return
	}
	c.phase, c.since, c.until = "", time.Time{}, time.Time{}
	in.tidyLocked(chatID)
}

// queue lists the chats being waited for, oldest first.
func (in *inbox) queue() []QueueItem {
	in.mu.Lock()
	type entry struct {
		id int64
		c  chatState
	}
	var es []entry
	for id, c := range in.chats {
		if c.phase != "" {
			es = append(es, entry{id, *c})
		}
	}
	in.mu.Unlock()
	out := make([]QueueItem, 0, len(es))
	for _, e := range es {
		title := in.title(e.id)
		if title == "" {
			title = fmt.Sprintf("chat %d", e.id)
		}
		out = append(out, QueueItem{ChatID: e.id, Title: title, Phase: e.c.phase, Since: e.c.since, Until: e.c.until})
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Since.Before(out[j].Since) })
	return out
}
