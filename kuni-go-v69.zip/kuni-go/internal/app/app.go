// Package app assembles the program: it reads the config, builds every service once, runs the long-lived parts
// under a Supervisor and shuts them down in order. Nothing else in the program creates services or holds global
// state; main only picks the subcommand.
package app

import (
	"context"
	"errors"
	"fmt"
	"kuni/internal/billing"
	"kuni/internal/fear"
	"kuni/internal/keepsakes"
	"kuni/internal/letters"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync/atomic"
	"time"

	"kuni/internal/admin"
	"kuni/internal/agent"
	"kuni/internal/allow"
	"kuni/internal/autonomy"
	"kuni/internal/body"
	"kuni/internal/bond"
	"kuni/internal/brain"
	"kuni/internal/browser"
	"kuni/internal/chart"
	"kuni/internal/config"
	"kuni/internal/dates"
	"kuni/internal/debugui"
	"kuni/internal/desktop"
	"kuni/internal/diary"
	"kuni/internal/feel"
	"kuni/internal/ideas"
	"kuni/internal/ignore"
	"kuni/internal/imagegen"
	"kuni/internal/learn"
	"kuni/internal/ledger"
	"kuni/internal/life"
	"kuni/internal/live"
	"kuni/internal/llm"
	"kuni/internal/llmui"
	"kuni/internal/media"
	"kuni/internal/memory"
	"kuni/internal/metrics"
	"kuni/internal/mir"
	"kuni/internal/mood"
	"kuni/internal/netguard"
	"kuni/internal/people"
	"kuni/internal/physics"
	"kuni/internal/promises"
	"kuni/internal/prompts"
	"kuni/internal/proxy"
	"kuni/internal/reminders"
	"kuni/internal/run"
	"kuni/internal/sched"
	"kuni/internal/selfmodel"
	"kuni/internal/sense"
	"kuni/internal/telegram"
	"kuni/internal/tools"
	habits "kuni/internal/tracker"
	"kuni/internal/update"
	"kuni/internal/usage"
	"kuni/internal/util"
	"kuni/internal/work"
)

// Options are what main knows before the program starts.
type Options struct {
	ConfigPath string
	Log        *util.LogBuf // the recent log for the panel
	Started    time.Time
}

// LLMSettings are the connection settings of the LLM client from the config.
func LLMSettings(c *config.Config) llm.Settings {
	s := llm.Settings{CachePrompt: c.CachePrompt, BaseURL: c.LLMBaseURL, EmbeddingBaseURL: c.EmbeddingBaseURL, APIKey: c.LLMAPIKey,
		Model: c.LLMModel, EmbeddingModel: c.EmbeddingModel, Reasoning: c.Reasoning, LightModel: c.LightModel, FastModel: c.FastModel,
		VisionModel: c.VisionModel, LightBaseURL: c.LightBaseURL, LightAPIKey: c.LightAPIKey, FallbackModel: c.FallbackModel, FallbackBaseURL: c.FallbackBaseURL, FallbackAPIKey: c.FallbackAPIKey, EmbeddingAPIKey: c.EmbeddingAPIKey}
	if c.Temperature >= 0 {
		t := c.Temperature
		s.Temperature = &t
	}
	return s
}

func promptVars(c *config.Config) prompts.Vars {
	return prompts.Vars{CharacterName: c.CharacterName, CharacterNickname: c.CharacterNick, PapikName: c.PapikName}
}

// Run starts everything and blocks until ctx ends (Ctrl+C, SIGTERM, a restart after an update), then stops it all in
// order: the agent dumps her open conversations to the diary, tdlib flushes its database.
func Run(ctx context.Context, o Options) error {
	if added, err := config.FillMissing(o.ConfigPath); err != nil {
		log.Printf("kuni: config: could not write the missing settings: %v", err)
	} else if len(added) > 0 {
		log.Printf("kuni: config: wrote %d missing settings with their defaults into %s (old file kept as %s.bak): %s", len(added), o.ConfigPath, o.ConfigPath, strings.Join(added, ", "))
	}
	holder, err := config.NewHolder(o.ConfigPath)
	if err != nil {
		return err
	}
	cfg := holder.Get()
	for _, w := range cfg.Warnings {
		log.Printf("config: %s", w)
	}
	getCfg := holder.Get
	ctx, stop := context.WithCancel(ctx)
	defer stop()
	update.OnRestart(stop)

	sup := &run.Supervisor{}
	reg := metrics.New()
	for name, text := range helpTexts {
		reg.Help(name, text)
	}
	sup.OnCrash = func(name string) { reg.Inc("kuni_app_restarts_total", 1, map[string]string{"loop": name}) }
	feed := &live.Feed{}

	// --- the model, the budget and the owner's alerts ---
	client := llm.New("", "", "", "", "", cfg.RequestTimeout)
	client.Update(LLMSettings(cfg))
	owner := &ownerLine{} // filled once Telegram exists
	_ = os.MkdirAll(cfg.DataDir, 0o700)
	tracker := usage.New(filepath.Join(cfg.DataDir, "usage.json"))
	tracker.SetZone(cfg.Location()) // usage days follow the owner's clock
	client.Guard = func() error { return tracker.Guard(holder.Get().DailyTokenLimit) }
	client.Observer = newLLMWatch(getCfg, reg, tracker, owner.Send)

	if cfg.SDEnabled { // her reference picture: written once, then it is the owner's file
		if p := media.ReferencePath(cfg); p != "" {
			if err := media.SeedReference(p); err != nil {
				log.Printf("reference picture: %v", err)
			}
		}
	}

	ps, err := prompts.NewStore(cfg.PromptsDir, promptVars(cfg))
	if err != nil {
		return err
	}
	d, err := diary.New(cfg.DiaryDir, client, cfg.ConfidenceFactor, cfg.DiaryTokenTrigger)
	if err != nil {
		return err
	}
	d.SleepPrompt = func() string { return ps.Get(prompts.SleepConsolidator) }

	// hot reload: config.toml and prompt files.
	holder.OnChange(func(c *config.Config) {
		client.Update(LLMSettings(c))
		client.SetTimeout(c.RequestTimeout)
		d.SetTuning(c.ConfidenceFactor, c.DiaryTokenTrigger)
		tracker.SetZone(c.Location())
		if err := ps.SetVars(promptVars(c)); err != nil {
			log.Printf("prompts: %v", err)
		}
	})
	sup.Go(ctx, "config watch", holder.Watch)
	sup.Go(ctx, "prompt watch", func(ctx context.Context) {
		util.Watch(ctx, 2*time.Second, ps.Files, func(path string) {
			if err := ps.Reload(); err != nil {
				log.Printf("prompts: reload: %v", err)
				return
			}
			log.Printf("prompts: reloaded (%s changed)", filepath.Base(path))
		})
	})

	mediaSvc := func() media.Services { return media.FromConfig(getCfg()) }

	// --- Telegram ---
	tg, err := newTelegram(cfg)
	if err != nil {
		return err
	}
	if cfg.TelegramEnabled {
		owner.set(getCfg, tg)
	}

	ui := &llmui.Env{TG: tg, LLM: client, Prompts: ps, Media: mediaSvc, Cfg: getCfg}
	gen := &imagegen.Generator{LLM: client, Prompts: ps, Media: mediaSvc, CharacterName: func() string { return getCfg().CharacterName }}
	auto := autonomy.New(filepath.Join(cfg.DataDir, "autonomy.json"), filepath.Join(cfg.DataDir, "autonomy.log"))
	auto.SetZone(cfg.Location())
	rt := tools.NewRuntime(feed) // one browser, one desktop, her background jobs: shared by every chat
	defer rt.Close()
	b := &boot{o: o, holder: holder, cfg: cfg, getCfg: getCfg, stop: stop, sup: sup, reg: reg, feed: feed, client: client, owner: owner, tracker: tracker,
		ps: ps, d: d, tg: tg, ui: ui, gen: gen, auto: auto, rt: rt, mediaSvc: mediaSvc}
	b.newDeps()
	b.startWorld(ctx)
	b.startAgent(ctx)
	panel := b.newPanel()
	b.mountHTTP(ctx, panel)
	b.startLoops(ctx)

	log.Printf("kuni: %s is up (telegram=%v, proxy=%v). Ctrl+C to stop gracefully.", cfg.CharacterName, cfg.TelegramEnabled, cfg.ProxyEnabled)
	<-ctx.Done()
	log.Printf("kuni: shutting down, dumping remaining context…")
	sup.Wait()
	owner.Wait(10 * time.Second)
	return nil
}

// boot is what Run builds first and hands to the start-up stages below, so each stage is one short function instead of
// one long one. The stages run in this order: newDeps, startWorld, startAgent, newPanel, mountHTTP, startLoops.
type boot struct {
	o        Options
	holder   *config.Holder
	cfg      *config.Config // as at start-up; live values come from getCfg
	getCfg   func() *config.Config
	stop     func()
	sup      *run.Supervisor
	reg      *metrics.Registry
	feed     *live.Feed
	client   *llm.Client
	owner    *ownerLine
	tracker  *usage.Tracker
	ps       *prompts.Store
	d        *diary.Diary
	tg       telegram.Client
	ui       *llmui.Env
	gen      *imagegen.Generator
	auto     *autonomy.State
	rt       *tools.Runtime
	mediaSvc func() media.Services

	deps   tools.Deps
	dumper *memory.Dumper
	wsrv   *mir.Server
	ag     *agent.Agent
	clean  cleaner
}

// newDeps opens every store of hers and wires them into the tool dependencies.
func (b *boot) newDeps() {
	o, cfg, getCfg, reg, client, ps, d, tg, ui, gen, rt, mediaSvc := b.o, b.cfg, b.getCfg, b.reg, b.client, b.ps, b.d, b.tg, b.ui, b.gen, b.rt, b.mediaSvc
	b.deps = tools.Deps{RT: rt, TG: tg, LLM: client, Diary: d, Prompts: ps, Media: mediaSvc, Cfg: getCfg, UI: ui, Metrics: reg, Images: gen,
		Mood:   mood.New(filepath.Join(cfg.DataDir, "mood.json")),
		Bond:   bond.New(filepath.Join(cfg.DataDir, "bond.json")),
		Focus:  brain.NewWorkspace(3),
		Self:   selfmodel.New(filepath.Join(cfg.DataDir, "self.json")),
		Brain:  brain.New(filepath.Join(cfg.DataDir, "brain.json.gz"), 20201026),
		Cortex: newCortex(cfg),
		Mind:   newMind(cfg),
		Life:   life.New(cfg.DataDir, time.Now().UnixNano()), Learn: learn.New(filepath.Join(cfg.DataDir, "learn.json")), Sense: sense.New(filepath.Join(cfg.DataDir, "sense.json")), Feel: feel.New(filepath.Join(cfg.DataDir, "feel.json")), Presence: &physics.Presence{}, Body: body.New(filepath.Join(cfg.DataDir, "body.json")), Ideas: ideas.Open(filepath.Join(cfg.DataDir, "ideas.json")), Letters: letters.Open(filepath.Join(cfg.DataDir, "letters.json")), Keepsakes: keepsakes.Open(filepath.Join(cfg.DataDir, "keepsakes.json")), Fear: fear.New(filepath.Join(cfg.DataDir, "fear.json")), Billing: billing.Open(filepath.Join(cfg.DataDir, "billing.json")), Promises: promises.New(filepath.Join(cfg.DataDir, "promises.json")), Reminders: reminders.New(filepath.Join(cfg.DataDir, "reminders.json")), People: people.New(filepath.Join(cfg.DataDir, "people")),
		Work: work.New(filepath.Join(cfg.DataDir, "work.json")), ConfigPath: o.ConfigPath,
		Allow: allow.New(filepath.Join(cfg.DataDir, "allow.json")), Ignore: ignore.New(filepath.Join(cfg.DataDir, "ignore.json")),
		Sched:  sched.New(filepath.Join(cfg.DataDir, "sched.json"), cfg.Location()),
		Ledger: ledger.New(filepath.Join(cfg.DataDir, "ledger.json")), Tracker: habits.New(filepath.Join(cfg.DataDir, "tracker.json")),
		Dates: dates.New(filepath.Join(cfg.DataDir, "dates.json"))}
	if c, ok := tg.(interface {
		Contacts(context.Context) map[int64]bool
	}); ok && cfg.Mode == "user" {
		b.deps.Contacts = func(id int64) bool {
			cc, cancel := context.WithTimeout(context.Background(), 15*time.Second)
			defer cancel()
			return c.Contacts(cc)[id]
		}
	}
	b.dumper = &memory.Dumper{LLM: client, Diary: d, Prompts: ps, CharacterName: func() string { return getCfg().CharacterName },
		WM: memory.WorkingMemory{Path: cfg.WorkingMemoryFile}}

	b.deps.Brain.SetJournal(filepath.Join(cfg.DataDir, "brain.log"))
	b.deps.Focus.SetJournal(filepath.Join(cfg.DataDir, "focus.log"))
}

// startWorld opens her game world (if enabled) and starts its server.
func (b *boot) startWorld(ctx context.Context) {
	cfg, getCfg, sup, rt := b.cfg, b.getCfg, b.sup, b.rt
	if cfg.WorldEnabled {
		if ms, err := mir.Open(filepath.Join(cfg.DataDir, "world"), cfg.CharacterName, func() string {
			if k := getCfg().WorldKey; k != "" {
				return k
			}
			return getCfg().AdminToken
		}); err != nil {
			log.Printf("kuni: world: %v", err)
		} else {
			b.wsrv = ms
			rt.World = b.wsrv
			b.wsrv.BotAutobuild(cfg.WorldAutobuild)
			sup.Go(ctx, "world", b.wsrv.Run)
		}
	}
}

// startAgent starts Telegram and the agent loop, and routes world chat to her.
func (b *boot) startAgent(ctx context.Context) {
	o, cfg, getCfg, stop, sup, reg, feed, client, tracker, ps, d, tg, ui, auto, holder := b.o, b.cfg, b.getCfg, b.stop, b.sup, b.reg, b.feed, b.client, b.tracker, b.ps, b.d, b.tg, b.ui, b.auto, b.holder
	if cfg.TelegramEnabled {
		b.ag = agent.New(&agent.Agent{Price: func(m string) usage.Prices { return PriceOf(holder.Get())(m) }, Cfg: holder, LLM: client, TG: tg,
			Diary: d, Prompts: ps, UI: ui, Dumper: b.dumper, Metrics: reg, Deps: b.deps, Auto: auto, Usage: tracker, ConfigPath: o.ConfigPath, Started: o.Started,
			Feed: feed})
		sup.Go(ctx, "telegram", func(ctx context.Context) {
			if err := tg.Run(ctx); err != nil {
				log.Printf("telegram: %v", err)
				stop()
			}
		})
		sup.Go(ctx, "agent", b.ag.Run)
		if b.wsrv != nil && cfg.WorldModel != "" {
			wp := newWorldPlayer(b.wsrv, client, ps, getCfg, b.deps, filepath.Join(cfg.DataDir, "world"))
			b.wsrv.OnChat = wp.Hear
			sup.Go(ctx, "world player", wp.Run)
		} else if b.wsrv != nil {
			b.wsrv.OnChat = func(from, text string) {
				if id := getCfg().PapikChatID; id != 0 {
					_ = b.ag.Wake(ctx, id, fmt.Sprintf("[Мир] %s пишет в чате мира: «%s». Ответь ему инструментом world (say), при желании посмотри вокруг (look).", from, text))
				}
			}
		}
	}
}

// newPanel builds the admin panel with everything it can show or control.
func (b *boot) newPanel() *admin.Panel {
	o, cfg, getCfg, reg, feed, client, tracker, ps, d, tg, auto, rt, mediaSvc := b.o, b.cfg, b.getCfg, b.reg, b.feed, b.client, b.tracker, b.ps, b.d, b.tg, b.auto, b.rt, b.mediaSvc
	panel := &admin.Panel{Cfg: getCfg, ConfigPath: o.ConfigPath, Prompts: ps, Diary: d, Metrics: reg, Log: o.Log, Started: o.Started, TG: tg,
		Frame: rt.Frame, Stream: rt.Stream, Pointer: rt.PointerOf, Screens: rt.Screens,
		Control: func(src string, c admin.ControlReq) error {
			return rt.Desktop.Control(desktop.Control{Op: c.Op, X: c.X, Y: c.Y, X2: c.X2, Y2: c.Y2, Button: c.Button, N: c.N, Down: c.Down, Text: c.Text, Key: c.Key})
		}, Feed: feed, Mood: b.deps.Mood, Brain: b.deps.Brain, Auto: auto, Usage: tracker, People: b.deps.People,
		Ignore: b.deps.Ignore, Allow: b.deps.Allow, Sched: b.deps.Sched, Ideas: b.deps.Ideas, Letters: b.deps.Letters, Keepsakes: b.deps.Keepsakes, Fear: b.deps.Fear, Billing: b.deps.Billing, Body: b.deps.Body, Presence: b.deps.Presence, Feel: b.deps.Feel, Sense: b.deps.Sense, Learn: b.deps.Learn, Life: b.deps.Life, Cortex: b.deps.Cortex, Mind: b.deps.Mind}
	if b.ag != nil {
		panel.Ctl = adminCtl{b.ag}
		panel.Machine = func() (any, bool) {
			st, at, ok := b.ag.LastMachine()
			if !ok || !getCfg().MachineFeeling {
				return nil, false
			}
			return map[string]any{
				"at": at.Unix(), "load": st.Load, "free_capacity": st.FreeCapacity, "prediction_error": st.PredictionError, "goal_conflict": st.GoalConflict,
				"memory_pressure": st.MemoryPressure, "coherence": st.Coherence, "update_urge": st.UpdateUrge, "withdrawal": st.Withdrawal,
				"threat": st.Threat, "reward": st.Reward, "minutes_since_update": st.MinutesSinceUpdate, "drive": st.Drive,
			}, true
		}
	}
	panel.Compare = func(ctx context.Context, model, phrase string) (string, error) {
		sys := b.ownerPersona() +
			"This is a test of your voice: answer with ONLY the exact text of your next Telegram message to him (several short lines are fine). No tools, no explanations."
		m, err := client.Complete(llm.WithPurpose(ctx, "compare"), llm.Request{System: sys, Messages: []llm.Message{{Role: "user", Content: phrase}}, Model: model})
		return m.Content, err
	}
	call := &liveCall{
		stt: func(ctx context.Context, audio []byte, name string) (string, error) {
			return mediaSvc().STT.Transcribe(ctx, audio, name)
		},
		say: func(ctx context.Context, sys string, msgs []llm.Message) (string, error) {
			m, err := client.Complete(llm.WithPurpose(ctx, "call"), llm.Request{System: sys, Messages: msgs})
			return m.Content, err
		},
		speak: func(ctx context.Context, text string) ([]byte, string, error) {
			if !getCfg().TTSOn() {
				return nil, "", nil
			}
			return mediaSvc().TTS.Speak(ctx, text)
		},
		system: func() string {
			sys := b.ownerPersona() +
				"Now you are on a live voice call with him: he speaks, you answer out loud. Answer with ONLY what you say, one or two short spoken sentences, no tools, no lists, no emoji, no stage directions."
			if b.deps.Cortex != nil {
				sys += "\n" + b.deps.Cortex.Prompt()
			}
			return sys
		},
		hear: func(string) {
			if b.deps.Cortex != nil {
				b.deps.Cortex.Perceive("voice", .6)
			}
		},
	}
	panel.Talk = call.Turn
	b.clean = cleaner{cfg: getCfg, tg: tg, LogFile: filepath.Join(update.Dir(), "reina.log")}
	panel.Clean = func() string { return b.clean.Run(context.Background(), true) }
	if admin.Enabled(cfg) {
		log.Printf("kuni: admin panel on /admin (port %d)", cfg.ProxyPort)
	} else {
		log.Printf("kuni: admin panel is off (set misc.admin_token, 12+ chars, to turn it on)")
	}
	return panel
}

// mountHTTP puts the panel, the world, /metrics, /debug and the proxy on one port and starts serving it.
func (b *boot) mountHTTP(ctx context.Context, panel *admin.Panel) {
	cfg, getCfg, stop, sup, reg, client, ps, d := b.cfg, b.getCfg, b.stop, b.sup, b.reg, b.client, b.ps, b.d
	mux := http.NewServeMux()
	panel.Mount(mux)
	if b.wsrv != nil {
		b.wsrv.Mount(mux)
	}
	// who may use the endpoints next to the panel: the panel has its own login; the rest is local-only unless a key is sent
	adminKey := func() []string { return []string{getCfg().AdminToken} }
	if cfg.MetricsEnabled {
		guard := netguard.Policy{Keys: adminKey, Scope: netguard.Private, Hint: "only this machine and private networks (Prometheus in Docker), or send Authorization: Bearer <misc.admin_token>"}
		mux.Handle("/metrics", guard.Wrap(reg.Handler()))
	}
	if cfg.DebugUI {
		dbg := &debugui.UI{Cfg: getCfg, Diary: d, Client: client}
		if b.ag != nil {
			dbg.Sessions = b.ag.SessionSummaries
		}
		dmux := http.NewServeMux()
		dbg.Mount(dmux)
		guard := netguard.Policy{Keys: adminKey, Scope: netguard.Loopback, Hint: "only from this machine, or send Authorization: Bearer <misc.admin_token>"}
		mux.Handle("/debug", guard.Wrap(dmux))
		mux.Handle("/debug/", guard.Wrap(dmux))
	}
	if cfg.ProxyEnabled {
		bridge := proxy.NewBridge(b.dumper, func() string { return ps.Get(prompts.CharacterBase) }, func() time.Duration { return getCfg().SessionIdle })
		sup.Go(ctx, "proxy bridge", bridge.Run)
		guard := netguard.Policy{Keys: func() []string { return []string{getCfg().ProxyAPIKey} }, Scope: netguard.Loopback, KeyOnly: true,
			Hint: "set proxy.api_key in config.toml and send it as Authorization: Bearer <key> (without a key only this machine may use the proxy)"}
		srv := &proxy.Server{Cfg: getCfg, Diary: d, Prompts: ps, Client: client, Metrics: reg, Bridge: bridge, HijackSystem: true,
			HTTP: &http.Client{Timeout: 10 * time.Minute}, Guard: guard.Wrap,
			Tools: func(string) *tools.Registry { return tools.NewRegistry(tools.AskTool(b.deps)) }}
		srv.Mount(mux)
		if cfg.ProxyAPIKey == "" {
			log.Printf("kuni: proxy: no proxy.api_key, so /v1 answers only this machine; set a key to use it from elsewhere")
		}
		log.Printf("kuni: proxy on /v1 (upstream %s)", cfg.LLMBaseURL)
	}
	if cfg.ProxyEnabled || cfg.MetricsEnabled || cfg.DebugUI || admin.Enabled(cfg) || b.wsrv != nil {
		addr := fmt.Sprintf(":%d", cfg.ProxyPort)
		hs := &http.Server{Addr: addr, Handler: worldOnlyFromTunnel(mux), ReadHeaderTimeout: 10 * time.Second, IdleTimeout: 2 * time.Minute}
		sup.Go(ctx, "http", func(ctx context.Context) { serveHTTP(ctx, hs, stop) })
	}
}

// ownerPersona is who she is when she talks to him: the system prompt, her character and looks, and her tone with him.
// The voice test and the live call both start from it.
func (b *boot) ownerPersona() string {
	ps := b.ps
	return ps.Get(prompts.System) + "\n\n" + ps.Get(prompts.CharacterBase) + "\n\n<your_appearance>\n" + ps.Get(prompts.CharacterAppearance) + "\n</your_appearance>\n\n" +
		ps.Text(prompts.ToneOwner, nil) + "\n"
}

// startLoops starts the housekeeping loops that run for as long as she is up.
func (b *boot) startLoops(ctx context.Context) {
	o, getCfg, sup, owner, tracker, d, tg := b.o, b.getCfg, b.sup, b.owner, b.tracker, b.d, b.tg
	if b.deps.Life != nil {
		if b.deps.Body != nil {
			b.deps.Life.Hurt = func(p float64) { _, _ = b.deps.Body.Do("hurt", p) }
		}
		sup.Go(ctx, "life", func(ctx context.Context) { lifeLoop(ctx, b.deps, getCfg) })
	}
	if b.deps.Cortex != nil {
		sup.Go(ctx, "cortex", func(ctx context.Context) { cortexLoop(ctx, b.deps, getCfg) })
	}
	sup.Go(ctx, "study", func(ctx context.Context) { studyLoop(ctx, b.deps, getCfg) })
	sup.Go(ctx, "sleep", func(ctx context.Context) { sleepLoop(ctx, d, getCfg) })
	sup.Go(ctx, "maintenance", func(ctx context.Context) { maintLoop(ctx, getCfg, o.ConfigPath, owner.Send, b.clean.Run) })
	sup.Go(ctx, "daily report", func(ctx context.Context) { reportLoop(ctx, getCfg, tracker, owner.Send) })
	sup.Go(ctx, "telegram watch", func(ctx context.Context) { watchLoop(ctx, getCfg, tg, owner.Send) })
	if b.deps.Billing != nil {
		sup.Go(ctx, "funnel", func(ctx context.Context) { funnelLoop(ctx, getCfg, b.deps.Billing, b.reg) })
	}
	if c := getCfg(); c.BillingEnabled && c.BillingBotToken != "" && b.deps.Billing != nil {
		bot := &billing.Bot{Token: c.BillingBotToken, Store: b.deps.Billing, Name: c.BillingBotName, Loc: c.Location(),
			Offers: func() []billing.Offer {
				c := getCfg()
				m := int(c.BillingPeriodDays)
				return []billing.Offer{{Plan: billing.Plus, Days: 1, Stars: int(c.BillingPlusDayStars), Som: int(c.BillingPlusDayPrice)}, {Plan: billing.Plus, Days: 7, Stars: int(c.BillingPlusWeekStars), Som: int(c.BillingPlusWeekPrice)}, {Plan: billing.Plus, Days: m, Stars: int(c.BillingPlusStars), Som: int(c.BillingPlusPrice)},
					{Plan: billing.Max, Days: 1, Stars: int(c.BillingMaxDayStars), Som: int(c.BillingMaxDayPrice)}, {Plan: billing.Max, Days: 7, Stars: int(c.BillingMaxWeekStars), Som: int(c.BillingMaxWeekPrice)}, {Plan: billing.Max, Days: m, Stars: int(c.BillingMaxStars), Som: int(c.BillingMaxPrice)}}
			},
			Limits: func() billing.Limits {
				c := getCfg()
				return billing.Limits{Free: int(c.BillingFreePerDay), Plus: int(c.BillingPlusPerDay), Max: int(c.BillingMaxPerDay)}
			},
			RefDays: func() int { return int(getCfg().BillingRefDays) },
			Icons:   func() []string { return strings.Split(getCfg().BillingIcons, ",") },
			Render: func(ctx context.Context, svg string) ([]byte, error) {
				return chart.Render(ctx, svg, 1000, 620, browser.Find(getCfg().BrowserPath))
			},
			Support: func() string { return getCfg().BillingSupport },
			OnPaid: func(id int64, plan string, until time.Time) {
				b.owner.Send(fmt.Sprintf("Папик, оплата: пользователь %d взял тариф %s до %s.", id, plan, until.Format("02.01.2006")))
			}}
		if c.BillingAdminToken != "" {
			adm := &billing.Admin{Token: c.BillingAdminToken, Store: b.deps.Billing, Pay: bot, Loc: c.Location(),
				QRPath: filepath.Join(c.DataDir, "pay_qr.png"), Owner: func() int64 { return getCfg().PapikChatID }}
			bot.QR = func() []byte {
				if !getCfg().BillingQR {
					return nil
				}
				return adm.QRImage()
			}
			bot.OnReceipt = adm.Receipt
			bot.Rates = func() string { return getCfg().BillingRates }
			bot.Currency = func() string { return getCfg().BillingCurrency }
			sup.Go(ctx, "admin bot", adm.Run)
		}
		sup.Go(ctx, "billing bot", bot.Run)
		sup.Go(ctx, "billing reminders", bot.RunReminders)
	}
	if update.Pending(update.Dir()) {
		if b.deps.Fear != nil { // a new build has just replaced the old one: that touches what she is afraid of
			b.deps.Fear.Startle(time.Now(), fear.Changed, .4)
		}
		sup.Go(ctx, "update confirm", func(ctx context.Context) { // a freshly installed build proves itself by staying up
			select {
			case <-time.After(update.ConfirmAfter):
				update.Confirm(update.Dir())
				log.Printf("kuni: the new build is confirmed")
				owner.Send("Папик, обновилась и работаю на новой сборке. Если что-то не так, откат в панели, вкладка «Обновление».")
			case <-ctx.Done():
			}
		})
	}
}

// newTelegram builds the Telegram client the config asks for (a fake that never receives anything when Telegram is
// off, so the tools stay constructible for the proxy).
func newTelegram(cfg *config.Config) (telegram.Client, error) {
	if !cfg.TelegramEnabled {
		return telegram.NewFake(), nil
	}
	switch cfg.Mode {
	case "bot":
		if cfg.BotToken == "" {
			return nil, errors.New(`[telegram] mode = "bot" needs bot_token`)
		}
		bot := telegram.NewBot(cfg.BotToken, cfg.TelegramAPI)
		bot.StatePath = filepath.Join(cfg.DataDir, "telegram_state.json")
		return bot, nil
	default:
		if cfg.TelegramAPIID == 0 || cfg.TelegramHash == "" {
			return nil, errors.New(`[telegram] mode = "user" needs api_id and api_hash from https://my.telegram.org`)
		}
		tr, err := telegram.NewTDJSONTransport()
		if err != nil {
			return nil, err
		}
		return telegram.NewTD(tr, telegram.TDConfig{APIID: cfg.TelegramAPIID, APIHash: cfg.TelegramHash, Phone: cfg.Phone, QR: cfg.TelegramQR, Password: cfg.TelegramPass,
			DBDir: cfg.TDLibDir, AppVersion: "kuni-go"}), nil
	}
}

// serveHTTP runs the server until ctx ends; a port that cannot be opened stops the program (she would be unreachable).
func serveHTTP(ctx context.Context, hs *http.Server, stop func()) {
	errc := make(chan error, 1)
	go func() { errc <- hs.ListenAndServe() }()
	select {
	case err := <-errc:
		if err != nil && !errors.Is(err, http.ErrServerClosed) {
			log.Printf("http: %v", err)
			stop()
		}
	case <-ctx.Done():
		sctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		_ = hs.Shutdown(sctx)
	}
}

// ownerLine sends the program's own messages (alerts, reports) to the owner's private chat. Until Telegram is set up,
// and when no owner is configured, messages are only logged.
type ownerLine struct {
	send     atomic.Pointer[func(string)]
	inflight atomic.Int32
}

func (o *ownerLine) set(cfg func() *config.Config, tg telegram.Client) {
	f := func(text string) {
		c := cfg()
		if c.PapikChatID == 0 {
			log.Printf("kuni: (no owner to tell) %s", text)
			return
		}
		o.inflight.Add(1)
		go func() {
			defer o.inflight.Add(-1)
			sctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
			defer cancel()
			if _, err := tg.SendText(sctx, c.PapikChatID, text, 0); err != nil {
				log.Printf("kuni: could not notify the owner: %v", err)
			}
		}()
	}
	o.send.Store(&f)
}

// Send delivers text to the owner (asynchronously).
func (o *ownerLine) Send(text string) {
	if f := o.send.Load(); f != nil {
		(*f)(text)
		return
	}
	log.Printf("kuni: (to the owner, Telegram is not up) %s", text)
}

// Wait gives the messages still being sent up to d to go out.
func (o *ownerLine) Wait(d time.Duration) {
	deadline := time.Now().Add(d)
	for o.inflight.Load() > 0 && time.Now().Before(deadline) {
		time.Sleep(50 * time.Millisecond)
	}
}

// adminCtl adapts the agent to the admin panel.
type adminCtl struct{ a *agent.Agent }

func (c adminCtl) Paused() bool                            { return c.a.Paused() }
func (c adminCtl) SetPaused(p bool)                        { c.a.SetPaused(p) }
func (c adminCtl) SessionSummaries() []string              { return c.a.SessionSummaries() }
func (c adminCtl) QueueInfo() any                          { return c.a.QueueInfo() }
func (c adminCtl) NoteOwnerAction(chat int64, text string) { c.a.NoteOwnerAction(chat, text) }
func (c adminCtl) Actions(q string, n int) any             { return c.a.Actions(q, n) }
func (c adminCtl) DescribePerson(ctx context.Context, id int64) (people.Card, error) {
	return c.a.DescribePerson(ctx, id)
}
func (c adminCtl) DialogList() any                      { return c.a.DialogList() }
func (c adminCtl) DialogMessages(id int64) (any, error) { return c.a.DialogMessages(id) }

// worldOnlyFromTunnel keeps the admin panel, the debug page, the proxy and the metrics off the internet: a request that
// came through a public tunnel (Cloudflare adds its own headers) may only see the world. Local and home-network requests
// are untouched.
func worldOnlyFromTunnel(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Cf-Connecting-Ip") != "" || r.Header.Get("Cf-Ray") != "" || r.Header.Get("X-Forwarded-For") != "" {
			if r.URL.Path != "/world" && !strings.HasPrefix(r.URL.Path, "/world/") {
				http.NotFound(w, r)
				return
			}
		}
		next.ServeHTTP(w, r)
	})
}
