package agent

import (
	"context"
	"fmt"
	"log"
	"strings"
	"time"

	"kuni/internal/billing"
	"kuni/internal/prompts"
	"kuni/internal/telegram"
)

// billingAllows counts one conversation for a person in a private chat and says whether she may answer. The owner, groups and a
// switched-off billing are never limited. When the limit is over, the person is told once a day (a fixed text, no paid model call)
// where to get more, and the messages are marked read.
func (a *Agent) billingAllows(ctx context.Context, chat telegram.Chat) bool {
	cfg := a.cfg()
	if !cfg.BillingEnabled || a.Deps.Billing == nil || chat.Kind != telegram.ChatPrivate || cfg.IsOwner(chat.ID) {
		return true
	}
	d := a.Deps.Billing.Take(chat.ID, time.Now(), billing.Limits{Free: int(cfg.BillingFreePerDay), Plus: int(cfg.BillingPlusPerDay), Max: int(cfg.BillingMaxPerDay)})
	if d.OK {
		return true
	}
	if d.TellOnce {
		msg := "На сегодня наши разговоры закончились, завтра лимит обновится."
		if cfg.BillingBotName != "" {
			msg += fmt.Sprintf(" Если хочешь говорить больше, тарифы тут: @%s", cfg.BillingBotName)
		}
		if _, err := a.TG.SendText(ctx, chat.ID, msg, 0); err != nil {
			log.Printf("agent: billing: %v", err)
		}
	}
	_ = a.TG.MarkRead(ctx, chat.ID)
	a.Metrics.Inc("kuni_billing_limited_total", 1, map[string]string{"plan": d.Plan})
	return false
}

// planNames are the plans as people see them in the payment bot.
var planNames = map[string]string{billing.Free: "Старт (бесплатный)", billing.Plus: "Plus", billing.Max: "Max"}

// accountBlock tells her this person's plan and how much is left today, so she can answer "how many messages do I have left" or
// "did my payment go through" from the real account instead of guessing. Only in a private chat with someone other than the owner,
// and only when billing is on.
func (a *Agent) accountBlock(chat telegram.Chat, now time.Time) string {
	cfg := a.cfg()
	if !cfg.BillingEnabled || a.Deps.Billing == nil || chat.Kind != telegram.ChatPrivate || cfg.IsOwner(chat.ID) {
		return ""
	}
	acc := a.Deps.Billing.Account(chat.ID, now, billing.Limits{Free: int(cfg.BillingFreePerDay), Plus: int(cfg.BillingPlusPerDay), Max: int(cfg.BillingMaxPerDay)})
	loc := cfg.Location()
	var b strings.Builder
	b.WriteString("\n<account>\n")
	fmt.Fprintf(&b, "plan: %s\n", planNames[acc.Plan])
	if !acc.Until.IsZero() {
		left := acc.Until.Sub(now)
		days := int(left.Hours() / 24)
		fmt.Fprintf(&b, "paid until: %s (%d days %d hours left), no auto-renewal\n", acc.Until.In(loc).Format("02.01.2006 15:04"), days, int(left.Hours())-days*24)
	}
	if acc.Expired != "" {
		fmt.Fprintf(&b, "their %s plan has ended; they are back on Start\n", planNames[acc.Expired])
	}
	if acc.Limit > 0 {
		fmt.Fprintf(&b, "today: %d of %d conversations used, %d left; the limit resets at midnight (%s)\n", acc.Used, acc.Limit, acc.Left, loc)
	} else {
		fmt.Fprintf(&b, "today: %d conversations, no daily cap\n", acc.Used)
	}
	if acc.Paid > 0 {
		fmt.Fprintf(&b, "payments so far: %d\n", acc.Paid)
	}
	if acc.Invited > 0 {
		fmt.Fprintf(&b, "people they invited: %d\n", acc.Invited)
	}
	currency := cfg.BillingCurrency
	if currency == "" {
		currency = "RUB"
	}
	if r := acc.Pending; r != nil {
		state := "waiting for their receipt"
		if r.Status == "sent" {
			state = "receipt sent, the team is checking it"
		}
		fmt.Fprintf(&b, "QR payment in progress: %s for %d days, %d %s, %s\n", planNames[r.Plan], r.Days, r.Som, currency, state)
	}
	b.WriteString("</account>\n")
	bot := "the payment bot"
	if cfg.BillingBotName != "" {
		bot = "@" + cfg.BillingBotName
	}
	if t := a.Prompts.Text(prompts.AccountRules, map[string]string{"BOT": bot}); t != "" {
		b.WriteString(t + "\n")
	}
	return b.String()
}
