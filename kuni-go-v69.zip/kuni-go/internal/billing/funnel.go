package billing

import (
	"time"

	"kuni/internal/metrics"
)

// Funnel is the picture of the business at one moment: how many people came, how many actually talk, how many hit the
// daily limit (the moment they may pay) and how many paid. It is computed from the accounts, so it needs no extra
// bookkeeping and cannot drift from the real numbers.
type Funnel struct {
	Users          int // everyone who ever opened the bot
	New1d, New7d   int // joined today / in the last 7 days
	Activated      int // talked at least once (Total > 0)
	ActiveToday    int // used the bot today
	Returned       int // joined before today and used the bot today
	AtLimitToday   int // used the whole free/paid limit today
	PayingNow      int // a paid plan is active right now
	Referred       int // came by an invitation
	Payments       int // all payments ever
	Stars          int // all Telegram Stars ever paid
	PayingEverEver int // people with at least one payment
}

// Funnel counts the funnel as of now. Days are cut by loc (the bot's own midnight, the same one the daily limit uses).
func (s *Store) Funnel(now time.Time, loc *time.Location, l Limits) Funnel {
	if loc == nil {
		loc = time.Local
	}
	now = now.In(loc)
	today := now.Format("2006-01-02")
	startToday := time.Date(now.Year(), now.Month(), now.Day(), 0, 0, 0, 0, loc)
	week := startToday.AddDate(0, 0, -6)

	s.mu.Lock()
	defer s.mu.Unlock()
	var f Funnel
	for _, u := range s.d.Users {
		f.Users++
		joined := u.Joined.In(loc)
		hasJoined := !u.Joined.IsZero()
		if hasJoined && !joined.Before(startToday) {
			f.New1d++
		}
		if hasJoined && !joined.Before(week) {
			f.New7d++
		}
		if u.Total > 0 {
			f.Activated++
		}
		plan := planAt(u, now)
		usedToday := 0
		if u.Day == today {
			usedToday = u.Used
		}
		if usedToday > 0 {
			f.ActiveToday++
			if hasJoined && joined.Before(startToday) {
				f.Returned++
			}
			if lim := l.of(plan); lim > 0 && usedToday >= lim {
				f.AtLimitToday++
			}
		}
		if plan != Free {
			f.PayingNow++
		}
		if u.Referrer != 0 {
			f.Referred++
		}
		if u.Paid > 0 {
			f.PayingEverEver++
		}
	}
	f.Payments = len(s.d.Payments)
	for _, p := range s.d.Payments {
		f.Stars += p.Stars
	}
	return f
}

// Publish writes the funnel into the Prometheus registry as gauges (kuni_funnel_*).
func (f Funnel) Publish(reg *metrics.Registry) {
	if reg == nil {
		return
	}
	g := func(name, help string, v int) {
		reg.Help(name, help)
		reg.Set(name, float64(v), nil)
	}
	g("kuni_funnel_users", "People who ever opened the bot", f.Users)
	g("kuni_funnel_new_today", "People who joined today", f.New1d)
	g("kuni_funnel_new_7d", "People who joined in the last 7 days", f.New7d)
	g("kuni_funnel_activated", "People who had at least one conversation", f.Activated)
	g("kuni_funnel_active_today", "People who used the bot today", f.ActiveToday)
	g("kuni_funnel_returned_today", "People who joined before today and used the bot today", f.Returned)
	g("kuni_funnel_at_limit_today", "People who used up their daily limit today", f.AtLimitToday)
	g("kuni_funnel_paying_now", "People with an active paid plan", f.PayingNow)
	g("kuni_funnel_paying_ever", "People who paid at least once", f.PayingEverEver)
	g("kuni_funnel_referred", "People who came by an invitation", f.Referred)
	g("kuni_funnel_payments", "All payments ever", f.Payments)
	g("kuni_funnel_stars", "All Telegram Stars paid ever", f.Stars)
}
