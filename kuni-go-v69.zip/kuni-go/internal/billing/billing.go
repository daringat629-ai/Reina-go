// Package billing is the plans people other than the owner are on: Start (free), Plus and Max. Each plan has a daily number of
// conversations (one conversation = one time she answers a batch of new messages in a chat). A payment, taken by a small separate bot
// in Telegram Stars, moves a person to Plus or Max for a number of days. The owner is never limited and never billed.
package billing

import (
	"errors"
	"fmt"
	"sort"
	"sync"
	"time"

	"kuni/internal/store"
)

// Plans.
const (
	Free = "start"
	Plus = "plus"
	Max  = "max"
)

// Merge: conversations this close to the previous counted one are counted as the same one (spam taps, a burst of messages).
const Merge = 20 * time.Second

// Limits are the daily conversation limits per plan (0 = no cap).
type Limits struct{ Free, Plus, Max int }

func (l Limits) of(plan string) int {
	switch plan {
	case Plus:
		return l.Plus
	case Max:
		return l.Max
	}
	return l.Free
}

// User is one person's account.
type User struct {
	ID       int64     `json:"id"`
	Plan     string    `json:"plan"`
	Until    time.Time `json:"until,omitempty"`
	Day      string    `json:"day"`
	Used     int       `json:"used"`
	Told     string    `json:"told,omitempty"` // the day she last said that the limit is over (said once a day)
	Joined   time.Time `json:"joined,omitempty"`
	Referrer int64     `json:"referrer,omitempty"` // who invited this person (0 = nobody)
	Paid     int       `json:"paid,omitempty"`     // how many payments
	Total    int       `json:"total,omitempty"`    // conversations in all time
	Last     time.Time `json:"last,omitempty"`     // when a conversation was last counted
	Reminded time.Time `json:"reminded,omitempty"` // the end date we already reminded about
}

// Payment is one successful payment, kept so that the same charge is never counted twice.
type Payment struct {
	At     time.Time `json:"at"`
	UserID int64     `json:"user_id"`
	Plan   string    `json:"plan"`
	Stars  int       `json:"stars"`
	Charge string    `json:"charge"`
	Days   int       `json:"days"`
	Som    int       `json:"som,omitempty"` // paid by QR, in som
}

type data struct {
	Users    map[int64]*User `json:"users"`
	Payments []Payment       `json:"payments"`
	Requests []Request       `json:"requests,omitempty"`
	NextReq  int             `json:"next_req,omitempty"`
}

// Request is a QR payment someone is making: they transfer Som with Code in the comment and send a receipt; the owner confirms.
type Request struct {
	ID      int       `json:"id"`
	UserID  int64     `json:"user_id"`
	Name    string    `json:"name,omitempty"`
	Plan    string    `json:"plan"`
	Days    int       `json:"days"`
	Som     int       `json:"som"`
	Code    string    `json:"code"`
	At      time.Time `json:"at"`
	Status  string    `json:"status"` // waiting (for a receipt), sent (receipt is with the owner), ok, no
	Decided time.Time `json:"decided,omitempty"`
}

// Store keeps accounts in one JSON file. Safe for concurrent use.
type Store struct {
	mu    sync.Mutex
	path  string
	saver store.Saver
	d     data
}

// Open loads the accounts (or starts empty).
func Open(path string) *Store {
	s := &Store{path: path, saver: store.Saver{What: "billing"}}
	store.Load("billing", path, &s.d)
	if s.d.Users == nil {
		s.d.Users = map[int64]*User{}
	}
	return s
}

func (s *Store) save() { _ = s.saver.Save(s.path, s.d) }

func (s *Store) user(id int64) *User {
	u := s.d.Users[id]
	if u == nil {
		u = &User{ID: id, Plan: Free, Joined: time.Now()}
		s.d.Users[id] = u
	}
	return u
}

// planAt is the plan in force at now (a paid plan that ran out falls back to Start).
func planAt(u *User, now time.Time) string {
	if u.Plan != Free && now.Before(u.Until) {
		return u.Plan
	}
	return Free
}

// Decision is the answer to "may she answer this person now".
type Decision struct {
	OK       bool
	Plan     string
	Left     int  // conversations left today after this one (-1 = no cap)
	TellOnce bool // the limit is over and she has not said so today yet
}

// Take counts one conversation for the person and says whether it is allowed.
func (s *Store) Take(id int64, now time.Time, l Limits) Decision {
	s.mu.Lock()
	defer s.mu.Unlock()
	u := s.user(id)
	day := now.Format("2006-01-02")
	if u.Day != day {
		u.Day, u.Used = day, 0
	}
	plan := planAt(u, now)
	limit := l.of(plan)
	if limit > 0 && u.Used >= limit {
		d := Decision{Plan: plan, TellOnce: u.Told != day}
		u.Told = day
		s.save()
		return d
	}
	if !u.Last.IsZero() && now.Sub(u.Last) >= 0 && now.Sub(u.Last) < Merge {
		s.save() // a burst of messages within a few seconds is one conversation
		left := -1
		if limit > 0 {
			left = limit - u.Used
		}
		return Decision{OK: true, Plan: plan, Left: left}
	}
	u.Used++
	u.Total++
	u.Last = now
	s.save()
	left := -1
	if limit > 0 {
		left = limit - u.Used
	}
	return Decision{OK: true, Plan: plan, Left: left}
}

// Activate records a payment and moves the person to the plan for days more (added to what is left of the same plan).
func (s *Store) Activate(id int64, plan string, days, stars int, charge string, now time.Time) (User, error) {
	if plan != Plus && plan != Max {
		return User{}, fmt.Errorf("billing: unknown plan %q", plan)
	}
	if days <= 0 {
		return User{}, errors.New("billing: days must be positive")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	for _, p := range s.d.Payments {
		if charge != "" && p.Charge == charge {
			return *s.user(id), nil // the same payment again: already counted
		}
	}
	u := s.user(id)
	start := now
	if planAt(u, now) == plan && u.Until.After(now) {
		start = u.Until
	}
	u.Plan, u.Until = plan, start.Add(time.Duration(days)*24*time.Hour)
	u.Paid++
	s.d.Payments = append(s.d.Payments, Payment{At: now, UserID: id, Plan: plan, Stars: stars, Charge: charge, Days: days})
	s.save()
	return *u, nil
}

// Get returns a person's account as of now.
func (s *Store) Get(id int64, now time.Time) User {
	s.mu.Lock()
	defer s.mu.Unlock()
	u := *s.user(id)
	u.Plan = planAt(&u, now)
	return u
}

// All lists every account (paid first) and every payment, for the panel.
func (s *Store) All(now time.Time) ([]User, []Payment) {
	s.mu.Lock()
	defer s.mu.Unlock()
	var us []User
	for _, u := range s.d.Users {
		x := *u
		x.Plan = planAt(&x, now)
		us = append(us, x)
	}
	sort.Slice(us, func(i, j int) bool {
		if (us[i].Plan == Free) != (us[j].Plan == Free) {
			return us[j].Plan == Free
		}
		return us[i].ID < us[j].ID
	})
	return us, append([]Payment(nil), s.d.Payments...)
}

// Refer remembers who invited a person. Only a person who is new (has never paid and has no inviter yet) can be referred, and never by themselves.
func (s *Store) Refer(id, by int64) bool {
	if id == by || by == 0 {
		return false
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	u := s.user(id)
	if u.Referrer != 0 || u.Paid > 0 {
		return false
	}
	u.Referrer = by
	s.save()
	return true
}

// Invited counts the people a person has invited and how many of them paid.
func (s *Store) Invited(by int64) (all, paid int) {
	s.mu.Lock()
	defer s.mu.Unlock()
	for _, u := range s.d.Users {
		if u.Referrer == by {
			all++
			if u.Paid > 0 {
				paid++
			}
		}
	}
	return
}

// Bonus adds free days of a plan (an invite reward) without a payment record.
func (s *Store) Bonus(id int64, plan string, days int, now time.Time) User {
	s.mu.Lock()
	defer s.mu.Unlock()
	u := s.user(id)
	start := now
	if planAt(u, now) != Free && u.Until.After(now) {
		start, plan = u.Until, planAt(u, now) // extend what they already have
	}
	u.Plan, u.Until = plan, start.Add(time.Duration(days)*24*time.Hour)
	s.save()
	return *u
}

// NewRequest opens a QR payment request (an earlier one of the same person that is still waiting for a receipt is closed; one with a receipt sent is left for the owner).
func (s *Store) NewRequest(user int64, name, plan string, days, som int, now time.Time) Request {
	s.mu.Lock()
	defer s.mu.Unlock()
	for i := range s.d.Requests {
		if r := &s.d.Requests[i]; r.UserID == user && r.Status == "waiting" { // a request with a receipt already sent stays open: the owner may still be checking that transfer
			r.Status, r.Decided = "no", now
		}
	}
	s.d.NextReq++
	r := Request{ID: s.d.NextReq, UserID: user, Name: name, Plan: plan, Days: days, Som: som, Code: fmt.Sprintf("R%d", s.d.NextReq), At: now, Status: "waiting"}
	s.d.Requests = append(s.d.Requests, r)
	if len(s.d.Requests) > 500 {
		s.d.Requests = s.d.Requests[len(s.d.Requests)-500:]
	}
	s.save()
	return r
}

// Waiting is the person's request that still needs a receipt.
func (s *Store) Waiting(user int64) (Request, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	for i := len(s.d.Requests) - 1; i >= 0; i-- {
		if r := s.d.Requests[i]; r.UserID == user && r.Status == "waiting" {
			return r, true
		}
	}
	return Request{}, false
}

// Mark moves a request to status; deciding (ok/no) is only possible once.
func (s *Store) Mark(id int, status string, now time.Time) (Request, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	for i := range s.d.Requests {
		r := &s.d.Requests[i]
		if r.ID != id {
			continue
		}
		if r.Status == "ok" || r.Status == "no" {
			return *r, fmt.Errorf("billing: request %s is already decided (%s)", r.Code, r.Status)
		}
		r.Status = status
		if status == "ok" || status == "no" {
			r.Decided = now
		}
		s.save()
		return *r, nil
	}
	return Request{}, fmt.Errorf("billing: no request %d", id)
}

// Approve confirms a QR request: the plan turns on and the payment is recorded in som.
func (s *Store) Approve(id int, now time.Time) (Request, User, error) {
	r, err := s.Mark(id, "ok", now)
	if err != nil {
		return r, User{}, err
	}
	u, err := s.Activate(r.UserID, r.Plan, r.Days, 0, "qr:"+r.Code, now)
	if err != nil {
		return r, u, err
	}
	s.mu.Lock()
	if n := len(s.d.Payments); n > 0 {
		s.d.Payments[n-1].Som = r.Som
	}
	s.save()
	s.mu.Unlock()
	return r, u, nil
}

// Open lists requests still waiting for the owner, oldest first.
func (s *Store) Open() []Request {
	s.mu.Lock()
	defer s.mu.Unlock()
	var out []Request
	for _, r := range s.d.Requests {
		if r.Status == "sent" || r.Status == "waiting" {
			out = append(out, r)
		}
	}
	return out
}

// Stats is the owner's summary.
type Stats struct {
	People, Paying, Today            int
	Stars, Som, StarsToday, SomToday int
	Payments, Open                   int
}

func (s *Store) Stats(now time.Time, loc *time.Location) Stats {
	s.mu.Lock()
	defer s.mu.Unlock()
	day := now.In(loc).Format("2006-01-02")
	var st Stats
	for _, u := range s.d.Users {
		st.People++
		if planAt(u, now) != Free {
			st.Paying++
		}
		if u.Day == now.Format("2006-01-02") {
			st.Today += u.Used
		}
	}
	for _, p := range s.d.Payments {
		st.Payments++
		st.Stars += p.Stars
		st.Som += p.Som
		if p.At.In(loc).Format("2006-01-02") == day {
			st.StarsToday += p.Stars
			st.SomToday += p.Som
		}
	}
	for _, r := range s.d.Requests {
		if r.Status == "sent" || r.Status == "waiting" {
			st.Open++
		}
	}
	return st
}

// Ending lists people whose paid plan ends within the next window and who were not reminded about this end yet; it marks them reminded.
func (s *Store) Ending(now time.Time, window time.Duration) []User {
	s.mu.Lock()
	defer s.mu.Unlock()
	var out []User
	for _, u := range s.d.Users {
		if planAt(u, now) == Free || u.Until.Sub(now) > window || u.Reminded.Equal(u.Until) {
			continue
		}
		u.Reminded = u.Until
		out = append(out, *u)
	}
	if len(out) > 0 {
		s.save()
	}
	return out
}
