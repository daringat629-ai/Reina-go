package billing

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net/http"
	"strconv"
	"strings"
	"sync"
	"time"
)

// Bot is the small payment bot: it shows a person their plan and sends invoices in Telegram Stars (currency XTR). Her own Telegram
// account is a user account and cannot send invoices, so payment lives in a separate bot from @BotFather.
type Bot struct {
	Token     string
	BaseURL   string // https://api.telegram.org by default (tests point it elsewhere)
	Store     *Store
	Offers    func() []Offer // what can be bought now
	Limits    func() Limits
	Name      string        // the bot's @username (for invite links)
	RefDays   func() int    // invite bonus in days (0 = off)
	Support   func() string // where to ask about payments
	Loc       *time.Location
	HTTP      *http.Client
	Now       func() time.Time
	OnPaid    func(userID int64, plan string, until time.Time)      // e.g. tell the owner
	Render    func(ctx context.Context, svg string) ([]byte, error) // SVG to PNG for the profile picture (nil = text only)
	QR        func() []byte                                         // the owner's bank QR picture (nil or empty = no QR payment)
	OnReceipt func(r Request, receipt []byte)                       // a receipt arrived: show it to the owner
	Rates     func() string                                         // "RUB=0.95,KZT=5.7,USD=0.0114": one som in other currencies (shown next to som prices)
	Currency  func() string                                         // main currency of QR prices ("RUB" by default)
	Icons     func() []string                                       // custom emoji ids for the menu buttons (plans, profile, friends, help); "" = an ordinary emoji
	offset    int64
	mu        sync.Mutex
	links     map[string]string
	last      map[int64]lastReq
}

// tok is the token without stray spaces or a line break from pasting; a bad character would put the whole URL, token included, into an error.
func (b *Bot) tok() string { return strings.TrimSpace(b.Token) }

func (b *Bot) now() time.Time {
	if b.Now != nil {
		return b.Now()
	}
	return time.Now()
}

func (b *Bot) call(ctx context.Context, method string, in, out any) error {
	base := b.BaseURL
	if base == "" {
		base = "https://api.telegram.org"
	}
	body, _ := json.Marshal(in)
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, base+"/bot"+b.tok()+"/"+method, bytes.NewReader(body))
	if err != nil {
		return fmt.Errorf("billing bot: %s: bad request (check the bot token in the config)", method) // the error text would hold the URL with the token
	}
	req.Header.Set("Content-Type", "application/json")
	hc := b.HTTP
	if hc == nil {
		hc = &http.Client{Timeout: 70 * time.Second}
	}
	resp, err := hc.Do(req)
	if err != nil {
		return fmt.Errorf("billing bot: %s: %w", method, errors.Unwrap(err)) // never put the token (it is in the URL) into a log line
	}
	defer resp.Body.Close()
	var r struct {
		OK          bool            `json:"ok"`
		Result      json.RawMessage `json:"result"`
		Description string          `json:"description"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&r); err != nil {
		return fmt.Errorf("billing bot: %s: bad answer", method)
	}
	if !r.OK {
		return fmt.Errorf("billing bot: %s: %s", method, r.Description)
	}
	if out != nil {
		return json.Unmarshal(r.Result, out)
	}
	return nil
}

type update struct {
	UpdateID int64 `json:"update_id"`
	Message  *struct {
		From struct {
			ID        int64  `json:"id"`
			FirstName string `json:"first_name"`
		} `json:"from"`
		Chat struct {
			ID int64 `json:"id"`
		} `json:"chat"`
		Text  string `json:"text"`
		Photo []struct {
			FileID string `json:"file_id"`
		} `json:"photo"`
		Document *struct {
			FileID   string `json:"file_id"`
			MimeType string `json:"mime_type"`
		} `json:"document"`
		SuccessfulPayment *struct {
			Currency    string `json:"currency"`
			TotalAmount int    `json:"total_amount"`
			Payload     string `json:"invoice_payload"`
			ChargeID    string `json:"telegram_payment_charge_id"`
		} `json:"successful_payment"`
	} `json:"message"`
	Callback *struct {
		ID   string `json:"id"`
		From struct {
			ID        int64  `json:"id"`
			FirstName string `json:"first_name"`
		} `json:"from"`
		Data    string `json:"data"`
		Message *struct {
			Chat struct {
				ID int64 `json:"id"`
			} `json:"chat"`
		} `json:"message"`
	} `json:"callback_query"`
	PreCheckout *struct {
		ID       string `json:"id"`
		Currency string `json:"currency"`
		Total    int    `json:"total_amount"`
		Payload  string `json:"invoice_payload"`
	} `json:"pre_checkout_query"`
}

// Run polls the Bot API until ctx ends.
func (b *Bot) Run(ctx context.Context) {
	for ctx.Err() == nil {
		var ups []update
		err := b.call(ctx, "getUpdates", map[string]any{"offset": b.offset, "timeout": 50, "allowed_updates": []string{"message", "pre_checkout_query", "callback_query"}}, &ups)
		if err != nil {
			if ctx.Err() == nil {
				log.Printf("%v", err)
				select {
				case <-ctx.Done():
				case <-time.After(10 * time.Second):
				}
			}
			continue
		}
		for _, u := range ups {
			b.offset = u.UpdateID + 1
			b.handle(ctx, u)
		}
	}
}

// Offer is one thing that can be bought: a plan for a number of days at a price in Stars.
type Offer struct {
	Plan  string
	Days  int
	Stars int
	Som   int // price by bank QR (0 = not by QR)
}

// Payload is how an offer travels through an invoice: "plus:7".
func (o Offer) Payload() string { return fmt.Sprintf("%s:%d", o.Plan, o.Days) }

// offer finds the offer behind a payload, if it is still on sale.
func (b *Bot) offer(payload string) (Offer, bool) {
	for _, o := range b.Offers() {
		if o.Payload() == payload && o.Stars > 0 {
			return o, true
		}
	}
	return Offer{}, false
}

func days(n int) string {
	w := "дней"
	switch m10, m100 := n%10, n%100; {
	case m10 == 1 && m100 != 11:
		w = "день"
	case m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14):
		w = "дня"
	}
	return fmt.Sprintf("%d %s", n, w)
}

// Menu buttons: the label people see, an ordinary emoji in front of it when no vector icon is set, and the colour of the button.
type button struct{ label, emoji, style string }

var buttons = []button{{"Подписка", "💳", "primary"}, {"Профиль", "👤", ""}, {"Друзьям", "🤝", "success"}, {"Поддержка", "💬", ""}}

const (
	btnPlans   = "Подписка"
	btnProfile = "Профиль"
	btnFriends = "Друзьям"
	btnHelp    = "Поддержка"
)

// pressed says which menu button a text is, with or without the emoji in front (Telegram sends back only the text).
func pressed(text string) string {
	t := strings.TrimSpace(text)
	for _, b := range buttons {
		if t == b.label || t == b.emoji+" "+b.label {
			return b.label
		}
	}
	return ""
}

func (b *Bot) menu() map[string]any {
	var icons []string
	if b != nil && b.Icons != nil {
		icons = b.Icons()
	}
	row := func(i int) map[string]any {
		x := buttons[i]
		k := map[string]any{"text": x.emoji + " " + x.label}
		if i < len(icons) && strings.TrimSpace(icons[i]) != "" {
			k["text"], k["icon_custom_emoji_id"] = x.label, strings.TrimSpace(icons[i])
		}
		if x.style != "" {
			k["style"] = x.style
		}
		return k
	}
	return map[string]any{"keyboard": [][]map[string]any{{row(0), row(1)}, {row(2), row(3)}}, "resize_keyboard": true, "is_persistent": true}
}

func (b *Bot) handle(ctx context.Context, u update) {
	switch {
	case u.PreCheckout != nil:
		q := u.PreCheckout
		o, on := b.offer(q.Payload)
		ok := q.Currency == "XTR" && on && q.Total == o.Stars
		in := map[string]any{"pre_checkout_query_id": q.ID, "ok": ok}
		if !ok {
			in["error_message"] = "Цена изменилась. Откройте /plans ещё раз."
		}
		if err := b.call(ctx, "answerPreCheckoutQuery", in, nil); err != nil {
			log.Printf("%v", err)
		}
	case u.Callback != nil:
		b.callback(ctx, u)
	case u.Message != nil && (len(u.Message.Photo) > 0 || u.Message.Document != nil) && u.Message.SuccessfulPayment == nil:
		b.receipt(ctx, u)
	case u.Message != nil && u.Message.SuccessfulPayment != nil:
		m, p := u.Message, u.Message.SuccessfulPayment
		plan, d, ok := parsePayload(p.Payload)
		if p.Currency != "XTR" || !ok {
			log.Printf("billing bot: an unexpected payment (%s %d %q) from %d, not applied", p.Currency, p.TotalAmount, p.Payload, m.From.ID)
			return
		}
		first := b.Store.Get(m.From.ID, b.now()).Paid == 0
		ref := b.Store.Get(m.From.ID, b.now()).Referrer
		bonus := 0
		if first && ref != 0 && b.RefDays != nil {
			bonus = b.RefDays()
		}
		acc, err := b.Store.Activate(m.From.ID, plan, d+bonus, p.TotalAmount, p.ChargeID, b.now())
		if err != nil {
			log.Printf("%v", err)
			return
		}
		msg := fmt.Sprintf("Спасибо! Тариф %s действует до %s. Можно возвращаться к Рейне.", title(acc.Plan), acc.Until.In(b.loc()).Format("02.01.2006 15:04"))
		if bonus > 0 {
			msg += fmt.Sprintf("\nПлюс %s в подарок по приглашению друга.", days(bonus))
			r := b.Store.Bonus(ref, Plus, bonus, b.now())
			b.send(ctx, ref, fmt.Sprintf("Твой друг оплатил тариф. Тебе %s Plus в подарок, теперь до %s.", days(bonus), r.Until.In(b.loc()).Format("02.01.2006")))
		}
		b.send(ctx, m.Chat.ID, msg)
		if b.OnPaid != nil {
			b.OnPaid(m.From.ID, acc.Plan, acc.Until)
		}
	case u.Message != nil:
		m := u.Message
		text := strings.TrimSpace(m.Text)
		if b.repeat(m.From.ID, text) {
			return
		}
		low := strings.ToLower(text)
		switch {
		case low == "/terms":
			b.sendMenu(ctx, m.Chat.ID, Terms)
		case low == "/paysupport":
			sup := ""
			if b.Support != nil {
				sup = b.Support()
			}
			if sup == "" {
				sup = "напиши сюда, в этот чат"
			}
			b.sendMenu(ctx, m.Chat.ID, "Вопрос по оплате или возврату: "+sup+". Укажи дату оплаты и тариф. Возврат звёзд возможен, если тариф ещё почти не использован.")
		case strings.HasPrefix(low, "/start"):
			if arg := strings.TrimSpace(strings.TrimPrefix(text, "/start")); strings.HasPrefix(arg, "ref") {
				if by, err := strconv.ParseInt(strings.TrimPrefix(arg, "ref"), 10, 64); err == nil && b.RefDays != nil && b.RefDays() > 0 && b.Store.Refer(m.From.ID, by) {
					b.send(ctx, m.Chat.ID, fmt.Sprintf("Тебя пригласил друг: к первой оплате добавим %s в подарок.", days(b.RefDays())))
				}
			}
			b.sendMenu(ctx, m.Chat.ID, "Здесь можно посмотреть свой тариф и оплатить разговоры с Рейной.\n\n"+b.profile(m.From.ID))
		case low == "/plans" || pressed(text) == btnPlans:
			b.plans(ctx, m.Chat.ID)
		case low == "/status" || low == "/profile" || pressed(text) == btnProfile:
			_ = b.call(ctx, "sendChatAction", map[string]any{"chat_id": m.Chat.ID, "action": "upload_photo"}, nil)
			go b.sendCard(ctx, m.Chat.ID, m.From.ID, m.From.FirstName) // drawing must not hold up other people's taps and payments
		case pressed(text) == btnFriends || low == "/invite":
			b.sendMenu(ctx, m.Chat.ID, b.invite(m.From.ID))
		case pressed(text) == btnHelp || low == "/help":
			sup := ""
			if b.Support != nil {
				sup = b.Support()
			}
			if sup == "" {
				sup = "напиши сюда же, тебе ответят"
			}
			b.sendMenu(ctx, m.Chat.ID, "Вопрос по оплате или тарифу: "+sup+".\nОплата в Telegram Stars, без автопродления: тариф просто заканчивается в срок.")
		default:
			b.sendMenu(ctx, m.Chat.ID, "Выбери в меню ниже: подписка, профиль, друзьям или поддержка.")
		}
	}
}

func title(plan string) string {
	switch plan {
	case Plus:
		return "Plus"
	case Max:
		return "Max"
	}
	return "Старт"
}

func (b *Bot) loc() *time.Location {
	if b.Loc != nil {
		return b.Loc
	}
	return time.Local
}

func parsePayload(p string) (string, int, bool) {
	plan, d, ok := strings.Cut(p, ":")
	n, err := strconv.Atoi(d)
	if !ok || err != nil || n <= 0 || (plan != Plus && plan != Max) {
		return "", 0, false
	}
	return plan, n, true
}

func perDay(n int) string {
	if n <= 0 {
		return "без лимита"
	}
	return fmt.Sprintf("%d в день", n)
}

// bar draws how much of today's limit is used: ▰▰▰▱▱▱▱▱▱▱ 30%.
func bar(used, limit int) string {
	if limit <= 0 {
		return "без лимита"
	}
	f := float64(used) / float64(limit)
	if f > 1 {
		f = 1
	}
	n := int(f*10 + .5)
	return strings.Repeat("▰", n) + strings.Repeat("▱", 10-n) + fmt.Sprintf(" %d%%", int(f*100+.5))
}

// profile is the person's card: plan, today's limit with a bar and the moment it resets, and plain numbers. No rankings, no streaks.
func (b *Bot) profile(id int64) string {
	now := b.now().In(b.loc())
	u := b.Store.Get(id, now)
	limit := b.Limits().of(u.Plan)
	used := 0
	if u.Day == now.Format("2006-01-02") {
		used = u.Used
	}
	reset := time.Date(now.Year(), now.Month(), now.Day()+1, 0, 0, 0, 0, b.loc())
	var sb strings.Builder
	fmt.Fprintf(&sb, "👤 Профиль\n\nТариф: %s (%s)", title(u.Plan), perDay(limit))
	if u.Plan != Free {
		fmt.Fprintf(&sb, ", до %s", u.Until.In(b.loc()).Format("02.01.2006"))
	}
	fmt.Fprintf(&sb, "\n\nСегодня: %d", used)
	if limit > 0 {
		fmt.Fprintf(&sb, " из %d\n%s\nОбновится в %s", limit, bar(used, limit), reset.Format("00:00, 02.01"))
	}
	fmt.Fprintf(&sb, "\n\nРазговоров всего: %d", u.Total)
	if !u.Joined.IsZero() {
		fmt.Fprintf(&sb, "\nС нами с %s", u.Joined.In(b.loc()).Format("02.01.2006"))
	}
	if u.Paid > 0 {
		fmt.Fprintf(&sb, "\nОплат: %d", u.Paid)
	}
	return sb.String()
}

func (b *Bot) invite(id int64) string {
	d := 0
	if b.RefDays != nil {
		d = b.RefDays()
	}
	if d <= 0 || b.Name == "" {
		return "Приглашения сейчас выключены."
	}
	all, paid := b.Store.Invited(id)
	return fmt.Sprintf("🤝 Позови друга\n\nКогда друг впервые оплатит тариф, ему %s в подарок, а тебе %s Plus.\n\nТвоя ссылка:\nhttps://t.me/%s?start=ref%d\n\nПриглашено: %d, оплатили: %d.", days(d), days(d), b.Name, id, all, paid)
}

// plans sends the plans and one invoice per offer that is on sale.
func (b *Bot) plans(ctx context.Context, chat int64) {
	l := b.Limits()
	rows := map[string][]map[string]any{}
	for _, o := range b.Offers() {
		if o.Stars <= 0 {
			continue
		}
		link, err := b.invoiceLink(ctx, o, l)
		if err != nil {
			log.Printf("%v", err)
			continue
		}
		rows[o.Plan] = append(rows[o.Plan], map[string]any{"text": fmt.Sprintf("%s · ⭐ %d", days(o.Days), o.Stars), "url": link})
	}
	var kb [][]map[string]any
	for _, plan := range []string{Plus, Max} {
		if len(rows[plan]) > 0 {
			kb = append(kb, []map[string]any{{"text": "— " + title(plan) + ": " + perDay(l.of(plan)) + " —", "callback_data": "noop"}}, rows[plan])
		}
	}
	if b.qrOn() {
		kb = append(kb, []map[string]any{{"text": "📷 Оплатить по QR (" + b.code() + ")", "callback_data": "qr"}})
	}
	text := fmt.Sprintf("💳 Тарифы\n\nСтарт: %s, бесплатно.\nPlus: %s.\nMax: %s.\n\nВыбери срок кнопкой ниже. Оплата в Telegram Stars, без автопродления.", perDay(l.Free), perDay(l.Plus), perDay(l.Max))
	if len(kb) == 0 {
		b.sendMenu(ctx, chat, text+"\n\nСейчас оплата недоступна, попробуй позже.")
		return
	}
	if err := b.call(ctx, "sendMessage", map[string]any{"chat_id": chat, "text": text, "reply_markup": map[string]any{"inline_keyboard": kb}}, nil); err != nil {
		log.Printf("%v", err)
	}
}

// invoiceLink makes (once per offer and price) a payment link that opens the Stars payment right from a button.
func (b *Bot) invoiceLink(ctx context.Context, o Offer, l Limits) (string, error) {
	key := fmt.Sprintf("%s/%d", o.Payload(), o.Stars)
	b.mu.Lock()
	if b.links == nil {
		b.links = map[string]string{}
	}
	link, ok := b.links[key]
	b.mu.Unlock()
	if ok {
		return link, nil
	}
	desc := fmt.Sprintf("%s разговоров с Рейной, %s.", days(o.Days), perDay(l.of(o.Plan)))
	err := b.call(ctx, "createInvoiceLink", map[string]any{"title": fmt.Sprintf("Рейна · %s · %s", title(o.Plan), days(o.Days)), "description": desc, "payload": o.Payload(),
		"provider_token": "", "currency": "XTR", "prices": []map[string]any{{"label": title(o.Plan) + " · " + days(o.Days), "amount": o.Stars}}}, &link)
	if err != nil {
		return "", err
	}
	b.mu.Lock()
	b.links[key] = link
	b.mu.Unlock()
	return link, nil
}

// repeat says whether this is the same request from the same person again within a few seconds (a double tap, impatience):
// such a repeat is ignored, so ten taps cost the server one answer.
func (b *Bot) repeat(user int64, text string) bool {
	now := b.now()
	b.mu.Lock()
	defer b.mu.Unlock()
	if b.last == nil {
		b.last = map[int64]lastReq{}
	}
	p, ok := b.last[user]
	if len(b.last) > 5000 { // forget old taps so the map cannot grow forever
		for k, v := range b.last {
			if now.Sub(v.at) > time.Minute {
				delete(b.last, k)
			}
		}
	}
	b.last[user] = lastReq{text, now}
	return ok && p.text == text && now.Sub(p.at) < 8*time.Second
}

type lastReq struct {
	text string
	at   time.Time
}

func (b *Bot) sendMenu(ctx context.Context, chat int64, text string) {
	if err := b.call(ctx, "sendMessage", map[string]any{"chat_id": chat, "text": text, "reply_markup": b.menu()}, nil); err != nil {
		log.Printf("%v", err)
	}
}

func (b *Bot) send(ctx context.Context, chat int64, text string) {
	if err := b.call(ctx, "sendMessage", map[string]any{"chat_id": chat, "text": text}, nil); err != nil {
		log.Printf("%v", err)
	}
}

func (b *Bot) qrOn() bool {
	if b.QR == nil || b.OnReceipt == nil {
		return false
	}
	for _, o := range b.Offers() {
		if o.Som > 0 {
			return len(b.QR()) > 0
		}
	}
	return false
}

// callback handles inline buttons: the QR price list, a chosen QR offer.
func (b *Bot) callback(ctx context.Context, u update) {
	q := u.Callback
	_ = b.call(ctx, "answerCallbackQuery", map[string]any{"callback_query_id": q.ID}, nil)
	if q.Message == nil || b.repeat(q.From.ID, "cb:"+q.Data) {
		return
	}
	chat := q.Message.Chat.ID
	switch {
	case q.Data == "qr" && b.qrOn():
		var kb [][]map[string]any
		var list strings.Builder
		for _, o := range b.Offers() {
			if o.Som > 0 {
				kb = append(kb, []map[string]any{{"text": fmt.Sprintf("%s · %s · %s", title(o.Plan), days(o.Days), b.Price(o.Som)), "callback_data": "qr:" + o.Payload()}})
				if a := b.approx(o.Som); a != "" {
					list.WriteString(fmt.Sprintf("\n%s · %s: %s (%s)", title(o.Plan), days(o.Days), b.Price(o.Som), a))
				}
			}
		}
		_ = b.call(ctx, "sendMessage", map[string]any{"chat_id": chat, "text": "📷 Оплата по QR\n\nВыбери тариф. Потом переведёшь сумму по QR и пришлёшь скрин чека, тариф включится после проверки." + b.ratesNote(list.String()), "reply_markup": map[string]any{"inline_keyboard": kb}}, nil)
	case strings.HasPrefix(q.Data, "qr:") && b.qrOn():
		var o Offer
		ok := false
		for _, x := range b.Offers() {
			if "qr:"+x.Payload() == q.Data && x.Som > 0 {
				o, ok = x, true
			}
		}
		if !ok {
			b.send(ctx, chat, "Этот тариф сейчас недоступен, открой «Подписка» ещё раз.")
			return
		}
		r := b.Store.NewRequest(q.From.ID, q.From.FirstName, o.Plan, o.Days, o.Som, b.now())
		cur := ""
		if a := b.approx(o.Som); a != "" {
			cur = "\nВ другой валюте это примерно " + a + ". Если карта в другой валюте, банк сам переведёт по своему курсу, главное, чтобы пришло " + b.Price(o.Som) + "."
		}
		caption := fmt.Sprintf("Заявка %s: %s на %s, %s.%s\n\n1. Отсканируй QR в приложении банка и переведи ровно %s.\n2. В комментарии к переводу напиши код: %s\n3. Пришли сюда скрин чека.\n\nТариф включится после проверки, обычно быстро.", r.Code, title(o.Plan), days(o.Days), b.Price(o.Som), cur, b.Price(o.Som), r.Code)
		if err := b.sendPhotoMarkup(ctx, chat, b.QR(), caption, b.menu()); err != nil {
			log.Printf("billing bot: qr: %v", err)
			b.send(ctx, chat, "Не получилось отправить QR, попробуй позже или напиши в поддержку.")
		}
	}
}

// receipt takes a screenshot of a transfer for the person's open QR request and passes it to the owner.
func (b *Bot) receipt(ctx context.Context, u update) {
	m := u.Message
	r, ok := b.Store.Waiting(m.From.ID)
	if !ok || b.OnReceipt == nil {
		b.sendMenu(ctx, m.Chat.ID, "Чтобы оплатить по QR, нажми «Подписка» и выбери «Оплатить по QR».")
		return
	}
	id := ""
	if len(m.Photo) > 0 {
		id = m.Photo[len(m.Photo)-1].FileID // the largest size
	} else if m.Document != nil && strings.HasPrefix(m.Document.MimeType, "image/") {
		id = m.Document.FileID
	}
	if id == "" {
		b.send(ctx, m.Chat.ID, "Пришли чек картинкой (скрин или фото).")
		return
	}
	img, err := b.download(ctx, id)
	if err != nil {
		log.Printf("billing bot: receipt: %v", err)
		b.send(ctx, m.Chat.ID, "Не получилось принять чек, пришли ещё раз.")
		return
	}
	if r, err = b.Store.Mark(r.ID, "sent", b.now()); err != nil {
		log.Printf("%v", err)
		return
	}
	b.OnReceipt(r, img)
	b.sendMenu(ctx, m.Chat.ID, fmt.Sprintf("Чек по заявке %s получен. Проверим перевод и включим тариф, я напишу.", r.Code))
}

// Tell sends a plain message to a person through the pay bot (used by the admin bot after a decision).
func (b *Bot) Tell(ctx context.Context, user int64, text string) { b.sendMenu(ctx, user, text) }

// download fetches a file people sent to the bot (at most 10 MB).
func (b *Bot) download(ctx context.Context, fileID string) ([]byte, error) {
	var f struct {
		Path string `json:"file_path"`
		Size int    `json:"file_size"`
	}
	if err := b.call(ctx, "getFile", map[string]any{"file_id": fileID}, &f); err != nil {
		return nil, err
	}
	if f.Size > 10<<20 || f.Path == "" {
		return nil, fmt.Errorf("billing bot: file too big or missing")
	}
	base := b.BaseURL
	if base == "" {
		base = "https://api.telegram.org"
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, base+"/file/bot"+b.tok()+"/"+f.Path, nil)
	if err != nil {
		return nil, err
	}
	hc := b.HTTP
	if hc == nil {
		hc = &http.Client{Timeout: 70 * time.Second}
	}
	resp, err := hc.Do(req)
	if err != nil {
		return nil, fmt.Errorf("billing bot: download failed") // the URL holds the token
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("billing bot: download: %s", resp.Status)
	}
	return io.ReadAll(io.LimitReader(resp.Body, 10<<20))
}

var curSign = map[string]string{"RUB": "₽", "KZT": "₸", "UZS": "сум", "USD": "$", "EUR": "€", "TJS": "сомони", "TRY": "₺", "CNY": "¥", "GBP": "£", "UAH": "₴", "AZN": "₼", "GEL": "₾", "AMD": "֏", "KRW": "₩"}

// approx shows a som price in the other currencies the owner set: "≈ 371 ₽ · ≈ 2 223 ₸ · ≈ $4.45".
func (b *Bot) approx(som int) string {
	if b.Rates == nil || som <= 0 {
		return ""
	}
	var parts []string
	for _, kv := range strings.Split(b.Rates(), ",") {
		code, val, ok := strings.Cut(strings.TrimSpace(kv), "=")
		rate, err := strconv.ParseFloat(strings.TrimSpace(val), 64)
		code = strings.ToUpper(strings.TrimSpace(code))
		if !ok || err != nil || rate <= 0 || code == "" || code == b.code() {
			continue
		}
		sign := curSign[code]
		if sign == "" {
			sign = code
		}
		num := money(float64(som) * rate)
		switch sign {
		case "$", "€", "£", "¥":
			parts = append(parts, "≈ "+sign+num)
		default:
			parts = append(parts, "≈ "+num+" "+sign)
		}
	}
	return strings.Join(parts, " · ")
}

// money prints a sum readably: up to two decimals below 100, whole numbers with thin spaces above.
func money(v float64) string {
	if v < 100 {
		return strings.TrimRight(strings.TrimRight(strconv.FormatFloat(v, 'f', 2, 64), "0"), ".")
	}
	n := strconv.FormatInt(int64(v+.5), 10)
	var out []byte
	for i := range n {
		if i > 0 && (len(n)-i)%3 == 0 {
			out = append(out, " "...)
		}
		out = append(out, n[i])
	}
	return string(out)
}

func (b *Bot) ratesNote(list string) string {
	if list == "" {
		return ""
	}
	return "\n" + list + "\n\nКурс примерный. Платёж в " + b.code() + ": если у тебя карта в другой валюте, банк переведёт сам."
}

// Terms are the short conditions shown by /terms (Telegram asks bots that take payment to have them).
const Terms = `Условия Orvi

1. Рейна — ИИ-персонаж, а не человек. Её ответы создаёт программа и могут быть неточными; не используй их как медицинский, юридический или финансовый совет.
2. Тарифы дают дневное число разговоров с Рейной на оплаченный срок. Автопродления нет: тариф просто заканчивается в срок.
3. Оплата в Telegram Stars или переводом по QR. После оплаты тариф включается сразу (Stars) или после проверки перевода (QR).
4. Вопросы по оплате и возврату: /paysupport. Возврат возможен, если тариф ещё почти не использован.
5. Переписка хранится на сервере, чтобы Рейна помнила разговор. Мы не продаём и не передаём её третьим лицам.
6. Запрещено использовать Рейну для спама, обмана и вреда людям: такие аккаунты могут быть ограничены без возврата.`

// RunReminders tells people a day before their plan ends, once per plan end.
func (b *Bot) RunReminders(ctx context.Context) {
	for {
		for _, u := range b.Store.Ending(b.now(), 24*time.Hour) {
			b.sendMenu(ctx, u.ID, fmt.Sprintf("Твой тариф %s заканчивается %s. Продлить можно в «Подписка» 💜", title(u.Plan), u.Until.In(b.loc()).Format("02.01 в 15:04")))
		}
		select {
		case <-ctx.Done():
			return
		case <-time.After(30 * time.Minute):
		}
	}
}

func (b *Bot) code() string {
	if b != nil && b.Currency != nil {
		if c := strings.ToUpper(strings.TrimSpace(b.Currency())); c != "" {
			return c
		}
	}
	return "RUB"
}

// Price writes an amount in the main currency: "399 ₽", "$5", "390 сом".
func (b *Bot) Price(n int) string {
	c := b.code()
	switch sign := curSign[c]; {
	case c == "KGS":
		return fmt.Sprintf("%d сом", n)
	case sign == "$" || sign == "€" || sign == "£" || sign == "¥":
		return fmt.Sprintf("%s%d", sign, n)
	case sign != "":
		return fmt.Sprintf("%d %s", n, sign)
	}
	return fmt.Sprintf("%d %s", n, c)
}
