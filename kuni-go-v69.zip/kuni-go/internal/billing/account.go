package billing

import "time"

// Account is what one person's account looks like right now, for her to know in the chat: their plan, how much is left today,
// when a paid plan ends and whether a payment is on its way. It only reads; nothing is counted.
type Account struct {
	Plan    string    // the plan in force now (a paid plan that ran out is Start)
	Until   time.Time // end of the paid plan (zero on Start)
	Limit   int       // conversations per day on this plan (0 = no cap)
	Used    int       // conversations counted today
	Left    int       // left today (-1 = no cap)
	Paid    int       // payments in all time
	Invited int       // people who came by their invitation
	Expired string    // the paid plan they had before, if it has run out (empty otherwise)
	Pending *Request  // a QR payment that is waiting for a receipt or for the owner's check (nil = none)
}

// Account reads the person's account as of now. Days are cut the same way Take cuts them.
func (s *Store) Account(id int64, now time.Time, l Limits) Account {
	s.mu.Lock()
	defer s.mu.Unlock()
	var a Account
	u := s.d.Users[id]
	if u == nil {
		a.Plan = Free
	} else {
		a.Plan = planAt(u, now)
		if a.Plan != Free {
			a.Until = u.Until
		} else if u.Plan != Free && !u.Until.IsZero() {
			a.Expired = u.Plan
		}
		if u.Day == now.Format("2006-01-02") {
			a.Used = u.Used
		}
		a.Paid = u.Paid
	}
	a.Limit = l.of(a.Plan)
	a.Left = -1
	if a.Limit > 0 {
		a.Left = max(a.Limit-a.Used, 0)
	}
	for _, x := range s.d.Users {
		if x.Referrer == id {
			a.Invited++
		}
	}
	for i := len(s.d.Requests) - 1; i >= 0; i-- {
		if r := s.d.Requests[i]; r.UserID == id && (r.Status == "waiting" || r.Status == "sent") {
			a.Pending = &r
			break
		}
	}
	return a
}
