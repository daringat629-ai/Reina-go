"""
demo_embeddings.py — наглядная демонстрация "Real Embeddings" (было: хэш-
заглушка _hash_embed без семантики). Сделан специально для записи: печатает
чёткие, поочерёдные сравнения HashEmbedder vs реальный Embedder на одних и
тех же фразах, чтобы разница была видна на экране, а не только в коде.

Запуск:
    python3 demo_embeddings.py

Чтобы увидеть РЕАЛЬНУЮ семантику (а не fallback на хэш), нужен один из:
  A) У тебя уже есть ключ OpenRouter (MARIN_OPENROUTER_API_KEY в .env) —
     тогда ничего дополнительно делать не нужно: build_embedder() сам
     находит этот ключ и идёт на openrouter.ai/api/v1/embeddings
     (модель openai/text-embedding-3-small по умолчанию). Если хочется
     другую модель эмбеддингов с OpenRouter — задай явно:
       export MARIN_EMBEDDING_MODEL=openai/text-embedding-3-large
  B) Локальный Ollama с моделью эмбеддингов:
       ollama pull nomic-embed-text
       ollama serve   # если ещё не запущен
  C) Прямой OpenAI-ключ (не через OpenRouter):
       export MARIN_EMBEDDING_API_KEY=sk-...
       export MARIN_EMBEDDING_BASE_URL=https://api.openai.com/v1

Без этого скрипт всё равно отработает (FallbackEmbedder тихо откатится на
HashEmbedder) — но тогда секция "РЕАЛЬНЫЙ EMBEDDER" не покажет улучшения,
скрипт явно предупредит об этом в начале.
"""

from __future__ import annotations

import logging
import sys
import time

from marin_core.config import MarinConfig, build_embedder, load_config
from marin_core.llm.embeddings import HashEmbedder, FallbackEmbedder
from marin_core.numeric import np

# Демо для записи — глушим внутренние retry/fallback-warnings (шумят в
# терминале), даём свой явный, компактный статус вместо них.
logging.getLogger("marin_core.llm.embeddings").setLevel(logging.CRITICAL)


def cos_sim(a, b) -> float:
    an, bn = np.linalg.norm(a), np.linalg.norm(b)
    if an == 0 or bn == 0:
        return 0.0
    return float(np.dot(a, b) / (an * bn))


def header(title: str) -> None:
    print()
    print("=" * 64)
    print(title)
    print("=" * 64)


def check_real_embedder_status(embedder) -> bool:
    """Пробует один embed() и смотрит, дошло ли до реального провайдера или
    тихо откатилось на хэш — HashEmbedder на одном и том же тексте всегда
    детерминирован, поэтому сравниваем вектор с прямым HashEmbedder()."""
    probe = "проверка связи с провайдером эмбеддингов"
    real_vec = embedder.embed(probe)
    hash_vec = HashEmbedder().embed(probe)
    is_hash_fallback = cos_sim(real_vec, hash_vec) > 0.999
    return not is_hash_fallback


MEMORIES = [
    "Дедлайн по проекту в пятницу",
    "Вчера ходил в кино на новый фильм",
    "Погода сегодня отличная, солнечно",
    "У меня есть кот, зовут Барсик",
    "Совещание перенесли на четверг из-за релиза",
    "Купил корм для питомца в зоомагазине",
]

QUERY = "расскажи что-нибудь про мою кошку"  # ни одного общего слова с MEMORIES[3]/[5]


def run_retrieval_demo(embedder, label: str) -> None:
    header(f"Семантический поиск — {label}")
    print(f'Запрос: "{QUERY}"\n')

    query_vec = embedder.embed(QUERY)
    scored = [(cos_sim(query_vec, embedder.embed(m)), m) for m in MEMORIES]
    scored.sort(key=lambda x: x[0], reverse=True)

    for i, (score, text) in enumerate(scored, start=1):
        bar = "#" * max(0, int((score + 1) * 20))
        print(f"  {i}. [{score:+.3f}] {bar:<42} {text}")

    top_score, top_text = scored[0]
    n_tied = sum(1 for s, _ in scored if abs(s - top_score) < 1e-6)
    is_relevant = "кот" in top_text.lower() or "питомц" in top_text.lower()
    if n_tied > 1:
        verdict = f"нет реального различия — {n_tied} записей с одинаковым счётом, порядок случайный, а не смысловой"
    elif is_relevant:
        verdict = "OK — нашла по смыслу, без общих слов с запросом"
    else:
        verdict = "мимо — не увидела смысловую связь"
    print(f"\n  Топ-1: {verdict}")


def run_contradiction_demo(embedder) -> None:
    from marin_core.belief.contradictions import HeuristicContradictionDetector

    header("Contradiction detection (belief/contradictions.py)")
    a = "У меня есть кот"
    b = "У меня нет никаких домашних животных"
    c = "Сегодня хорошая погода"

    detector = HeuristicContradictionDetector()
    emb_a, emb_b, emb_c = embedder.embed(a), embedder.embed(b), embedder.embed(c)

    print(f'  A: "{a}"')
    print(f'  B: "{b}"')
    print(f"  contradiction(A, B) = {detector.is_contradiction(emb_a, emb_b)}  (cos={cos_sim(emb_a, emb_b):+.3f}, theta={detector.theta})")
    print()
    print(f'  C: "{c}"  (не связано по теме)')
    print(f"  contradiction(A, C) = {detector.is_contradiction(emb_a, emb_c)}  (cos={cos_sim(emb_a, emb_c):+.3f}, theta={detector.theta})")
    print()
    print("  Примечание: это косинусная эвристика (см. docstring файла), а не NLI-")
    print("  классификатор — она ловит явно ПРОТИВОПОЛОЖНЫЕ по направлению вектора")
    print("  утверждения, но смысловая противоположность не всегда даёт отрицательный")
    print("  косинус (это следующий пункт роадмапа — п.7 belief/contradictions.py).")


def main() -> None:
    header("Marin X — Real Embeddings demo")

    cfg = load_config()  # читает .env / os.environ, включая авто-детект OpenRouter для эмбеддингов
    real_embedder = build_embedder(cfg)
    hash_embedder = HashEmbedder()

    print(f"Провайдер: {cfg.embedding_provider}  (base_url={cfg.embedding_base_url}, model={cfg.embedding_model if cfg.embedding_provider != 'ollama' else cfg.ollama_embedding_model})")
    print("Проверяю связь с провайдером эмбеддингов...", end=" ", flush=True)
    t0 = time.time()
    is_real = check_real_embedder_status(real_embedder)
    print(f"{time.time() - t0:.2f}s")

    if is_real:
        print(">>> Реальный embedder ОТВЕЧАЕТ — секция ниже покажет настоящую семантику.")
    else:
        print(f">>> Реальный embedder НЕДОСТУПЕН ({cfg.embedding_provider}, {cfg.embedding_base_url}) — FallbackEmbedder тихо откатился на HashEmbedder.")
        print("    Проверь: ключ верный? сеть есть? (если это OpenRouter — ключ должен быть тем же, что и MARIN_OPENROUTER_API_KEY)")
        print("    Либо подними локальный Ollama: `ollama pull nomic-embed-text`.")
        print("    Секция ниже всё равно запустится, но без улучшения — для видео лучше сперва поднять провайдер.")

    # Секция 1: старый способ, для контраста
    run_retrieval_demo(hash_embedder, "HashEmbedder (старая заглушка)")

    # Секция 2: новый способ
    run_retrieval_demo(real_embedder, "реальный Embedder" + ("" if is_real else " (fallback на хэш — см. предупреждение выше)"))

    # Секция 3: contradiction detection поверх реального эмбеддера
    run_contradiction_demo(real_embedder)

    header("Готово")
    print("OK: демо отработало без исключений.")


if __name__ == "__main__":
    sys.exit(main())
