#!/usr/bin/env python3
"""Берёт ключи из настроек Рейны и пишет готовый .env для Марин.

    python3 import_reina.py /work/reina/config.toml --phone +996XXXXXXXXX

Переносятся: api_id и api_hash Telegram (одно приложение может обслуживать несколько
номеров), id владельца, адрес и ключ модели, имя модели, адрес эмбеддингов. Номер у Марин свой:
его надо указать в --phone (или потом вписать TELEGRAM_PHONE в .env). Значения ключей
нигде не печатаются; файл .env создаётся с правами только для владельца и не перезаписывается
без --force.
"""
from __future__ import annotations

import argparse
import os
import re
import shutil
import sys
from typing import Any, Dict

HERE = os.path.dirname(os.path.abspath(__file__))


def load_toml(path: str) -> Dict[str, Dict[str, Any]]:
    try:
        import tomllib  # Python 3.11+
        with open(path, "rb") as f:
            return tomllib.load(f)
    except ImportError:
        pass
    # Python 3.10: простой разбор «[секция] ключ = значение», его хватает для настроек Рейны.
    out: Dict[str, Dict[str, Any]] = {}
    sec = out.setdefault("", {})
    for line in open(path, encoding="utf-8"):
        s = line.split("#", 1)[0].strip() if not re.search(r'"[^"]*#', line) else line.strip()
        if not s:
            continue
        m = re.fullmatch(r"\[([^\]]+)\]", s)
        if m:
            sec = out.setdefault(m.group(1).strip(), {})
            continue
        if "=" in s:
            k, v = s.split("=", 1)
            v = v.strip()
            if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
                val: Any = v[1:-1]
            elif v.lower() in ("true", "false"):
                val = v.lower() == "true"
            else:
                try:
                    val = int(v)
                except ValueError:
                    try:
                        val = float(v)
                    except ValueError:
                        val = v
            sec[k.strip()] = val
    return out


def _get(cfg: Dict[str, Any], section: str, key: str, default: Any = "") -> Any:
    v = (cfg.get(section) or {}).get(key, default)
    return default if v is None else v


def settings_from_reina(cfg: Dict[str, Any], phone: str = "") -> Dict[str, str]:
    """Что подставить в .env Марин. Пустые значения не возвращаются."""
    base = str(_get(cfg, "llm", "base_url")).strip().rstrip("/")
    key = str(_get(cfg, "llm", "api_key")).strip()
    model = str(_get(cfg, "llm", "fast_model")).strip() or str(_get(cfg, "llm", "model")).strip()
    api_id = _get(cfg, "telegram", "api_id", 0)
    api_hash = str(_get(cfg, "telegram", "api_hash")).strip()
    owner = _get(cfg, "general", "papik_chat_id", 0)
    s: Dict[str, str] = {}
    if api_id:
        s["TELEGRAM_API_ID"] = s["MARIN_TELEGRAM_API_ID"] = str(api_id)
    if api_hash:
        s["TELEGRAM_API_HASH"] = s["MARIN_TELEGRAM_API_HASH"] = api_hash
    if owner:
        s["MARIN_OWNER_ID"] = s["TELEGRAM_OWNER_ID"] = str(owner)
    if phone:
        s["TELEGRAM_PHONE"] = s["MARIN_TELEGRAM_PHONE"] = phone
    if base:
        s["MARIN_OPENROUTER_BASE_URL"] = base
    if key:
        s["MARIN_OPENROUTER_API_KEY"] = s["OPENROUTER_API_KEY"] = key
    if model:
        s["MARIN_OPENROUTER_MODEL"] = model
    # запасная модель Рейны годится, только если она на том же адресе
    fb = str(_get(cfg, "llm", "fallback_model")).strip()
    fb_base = str(_get(cfg, "llm", "fallback_base_url")).strip().rstrip("/")
    s["MARIN_OPENROUTER_FALLBACK_MODEL"] = fb if fb and (not fb_base or fb_base == base) else ""
    emb = str(_get(cfg, "llm", "embedding_base_url")).strip().rstrip("/")
    if emb:
        s["MARIN_EMBEDDING_PROVIDER"] = "openai_compat"
        s["MARIN_EMBEDDING_BASE_URL"] = emb
        s["MARIN_EMBEDDING_API_KEY"] = str(_get(cfg, "llm", "embedding_api_key")).strip() or key or "local"
        s["MARIN_EMBEDDING_MODEL"] = str(_get(cfg, "llm", "embedding_model")).strip() or "nomic-embed-text"
    # Модель Рейны (например Inception Mercury) только текстовая: картинки, селфи, голос
    # и распознавание речи через неё не работают, поэтому они выключены до отдельной настройки.
    if "openrouter" not in base.lower():
        for k in ("MARIN_VISION_ENABLED", "MARIN_SELFIE_ENABLED", "MARIN_ILLUSTRATION_ENABLED",
                  "MARIN_VOICE_ENABLED", "MARIN_STT_ENABLED"):
            s[k] = "false"
    return s


def apply_env(template: str, values: Dict[str, str]) -> str:
    """Подставляет значения в шаблон .env; ключи, которых там нет, дописываются в конец."""
    seen = set()
    out = []
    for line in template.splitlines():
        m = re.match(r"^([A-Z0-9_]+)=", line)
        if m and m.group(1) in values:
            out.append(f"{m.group(1)}={values[m.group(1)]}")
            seen.add(m.group(1))
        else:
            out.append(line)
    extra = [f"{k}={v}" for k, v in values.items() if k not in seen]
    if extra:
        out += ["", "# добавлено import_reina.py"] + extra
    return "\n".join(out) + "\n"


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Перенести ключи из настроек Рейны в .env Марин")
    ap.add_argument("config", nargs="?", default="", help="путь к config.toml Рейны")
    ap.add_argument("--phone", default="", help="номер Марин, например +996700000000")
    ap.add_argument("--force", action="store_true", help="перезаписать существующий .env (старый сохранится как .env.bak)")
    a = ap.parse_args(argv)
    path = a.config or next((p for p in ("../config.toml", "/work/reina/config.toml", "/opt/reina/config.toml") if os.path.exists(p)), "")
    if not path or not os.path.exists(path):
        print("Не нашла config.toml Рейны: укажи путь аргументом.")
        return 2
    target = os.path.join(HERE, ".env")
    if os.path.exists(target) and not a.force:
        print(".env уже есть. Чтобы заменить, запусти с --force (старый сохранится как .env.bak).")
        return 2
    values = settings_from_reina(load_toml(path), a.phone.strip())
    template = open(os.path.join(HERE, ".env.example"), encoding="utf-8").read()
    if os.path.exists(target):
        shutil.copyfile(target, target + ".bak")
        os.chmod(target + ".bak", 0o600)
    fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(apply_env(template, values))
    got = sorted(k for k in values if values[k])
    print("Готово: .env создан (права только для владельца).")
    print("Перенесено:", ", ".join(k for k in got if k.startswith(("TELEGRAM_API", "MARIN_OWNER", "MARIN_OPENROUTER_API", "MARIN_OPENROUTER_BASE", "MARIN_OPENROUTER_MODEL"))))
    if not a.phone:
        print("Не забудь вписать номер Марин в TELEGRAM_PHONE и MARIN_TELEGRAM_PHONE (формат +996...).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
