"""Run Marin X as a Telegram user account through Telethon."""
from __future__ import annotations

import asyncio
import logging
import signal

# Явная подстраховка: гарантирует, что .env загружен в os.environ ДО
# любого кода, который читает переменные окружения (Telegram, LLM и т.д.).
from dotenv import load_dotenv
load_dotenv()

from marin_core.telegram import MarinTelegramClient

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)


async def main() -> None:
    app = MarinTelegramClient()
    task = asyncio.current_task()
    loop = asyncio.get_running_loop()
    # systemd/docker останавливают процесс SIGTERM — без обработчика Python
    # умирает сразу, finally не выполняется и последние минуты памяти теряются.
    for sig in (signal.SIGTERM, signal.SIGINT):
        try:
            loop.add_signal_handler(sig, task.cancel)
        except (NotImplementedError, RuntimeError):
            pass
    try:
        await app.run()
    except asyncio.CancelledError:
        logging.getLogger("marin_x").info("Shutdown signal received — saving memory")
    finally:
        await app.disconnect()


if __name__ == "__main__":
    asyncio.run(main())
