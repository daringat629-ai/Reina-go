"""
Self-Reflection — п.21 документа. Периодический процесс (во время
idle/sleep cycle, см. engine/scheduler.py и memory/consolidation.py),
отвечающий на: что произошло? что изменилось? что усвоено? какие
прогнозы не оправдались? какие убеждения стоит пересмотреть?
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

from .metacognition import MetacognitionReport, TickTrace
from ..memory.consolidation import ConsolidationReport


@dataclass
class SelfReflectionSummary:
    n_ticks_reviewed: int
    mean_prediction_error: float
    consistency_score: float
    n_unresolved_contradictions: int
    n_semantic_clusters_created: int
    narrative: str  # человекочитаемое summary, записывается как REFLECTION-узел в memory_graph


def build_self_reflection(
    window: List[TickTrace],
    metacognition_report: MetacognitionReport,
    consolidation_report: ConsolidationReport,
) -> SelfReflectionSummary:
    narrative = (
        f"Reviewed {len(window)} ticks. "
        f"Mean prediction error: {metacognition_report.mean_prediction_error:.3f}. "
        f"Behavior/personality consistency: {metacognition_report.consistency_score:.2f}. "
        f"Unresolved belief contradictions: {len(metacognition_report.unresolved_contradictions)}. "
        f"Memory consolidation created {consolidation_report.semantic_clusters_created} semantic clusters "
        f"from {consolidation_report.nodes_rescored} recent events."
    )
    if getattr(metacognition_report, "resolved_feedback_ticks", 0):
        narrative += (f" Predictions checked against real reactions: {metacognition_report.resolved_feedback_ticks}.")
    if getattr(metacognition_report, "dominant_error_source", None):
        narrative += (f" Most of my mistakes came from: {metacognition_report.dominant_error_source}.")
    return SelfReflectionSummary(
        n_ticks_reviewed=len(window),
        mean_prediction_error=metacognition_report.mean_prediction_error,
        consistency_score=metacognition_report.consistency_score,
        n_unresolved_contradictions=len(metacognition_report.unresolved_contradictions),
        n_semantic_clusters_created=consolidation_report.semantic_clusters_created,
        narrative=narrative,
    )
