"""
Техническая метакогниция на каждом тике — не "самосознание", а честный
отчёт о состоянии собственного знания:

    Что я знаю?            known      + knowledge (0..1)
    Что я предполагаю?     assumed
    Что я не знаю?         unknown    + uncertainty (0..1)
    Насколько я уверена?   prediction_confidence, decision_confidence
    Почему это действие?   reason
    Что оказалось ошибочным? errors (из разрешённого прошлого прогноза)
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, List, Optional


@dataclass
class TickMetacognition:
    tick: int
    knowledge: float
    uncertainty: float
    prediction_confidence: float
    decision_confidence: float
    reason: str
    known: List[str] = field(default_factory=list)
    assumed: List[str] = field(default_factory=list)
    unknown: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    fallbacks_used: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "tick": self.tick,
            "knowledge": round(self.knowledge, 2),
            "uncertainty": round(self.uncertainty, 2),
            "prediction_confidence": round(self.prediction_confidence, 2),
            "decision_confidence": round(self.decision_confidence, 2),
            "reason": self.reason,
            "known": self.known, "assumed": self.assumed, "unknown": self.unknown,
            "errors": self.errors, "fallbacks_used": self.fallbacks_used,
        }

    def to_text(self) -> str:
        lines = [
            f"Knowledge: {self.knowledge:.2f}",
            f"Uncertainty: {self.uncertainty:.2f}",
            f"Prediction confidence: {self.prediction_confidence:.2f}",
            f"Decision confidence: {self.decision_confidence:.2f}",
            f"Reason: {self.reason}",
        ]
        for title, items in (("Знаю", self.known), ("Предполагаю", self.assumed),
                             ("Не знаю", self.unknown), ("Ошибки", self.errors)):
            if items:
                lines.append(f"{title}: " + "; ".join(items[:5]))
        if self.fallbacks_used:
            lines.append("Fallback: " + ", ".join(self.fallbacks_used))
        return "\n".join(lines)


def _cos(a, b) -> float:
    if a is None or b is None:
        return 0.0
    an = math.sqrt(sum(x * x for x in a))
    bn = math.sqrt(sum(x * x for x in b))
    if not an or not bn:
        return 0.0
    return sum(x * y for x, y in zip(a, b)) / (an * bn)


def estimate_knowledge(query_embedding, retrieved: List[Any], relevant_beliefs: List[Any],
                       related_beliefs: Optional[List[str]] = None) -> float:
    """Сколько у меня реально есть по теме: близость лучших воспоминаний +
    уверенность релевантных убеждений (взвешенная их близостью к ситуации)."""
    mem_sims = sorted((_cos(query_embedding, getattr(n, "embedding", None)) for n in retrieved), reverse=True)[:3]
    mem_part = sum(max(0.0, s) for s in mem_sims) / 3.0 if mem_sims else 0.0
    bel_scores = sorted(
        (max(0.0, _cos(query_embedding, getattr(b, "embedding", None))) * getattr(b, "confidence", 0.0)
         for b in relevant_beliefs), reverse=True)[:3]
    bel_part = sum(bel_scores) / 3.0 if bel_scores else 0.0
    k = 0.55 * mem_part + 0.45 * bel_part
    if related_beliefs:
        k = max(k, 0.6)
    return max(0.0, min(1.0, k))


def build_tick_meta(
    tick: int,
    interpretation,
    decision,
    prediction,
    knowledge: float,
    relevant_beliefs: List[Any],
    learning_report=None,
    fallbacks_used: Optional[List[str]] = None,
) -> TickMetacognition:
    known: List[str] = []
    assumed: List[str] = []
    unknown: List[str] = []

    for b in relevant_beliefs[:5]:
        conf = getattr(b, "confidence", 0.0)
        target = known if conf >= 0.7 else assumed
        target.append(f"{b.statement} ({conf:.2f})")
    for f in interpretation.facts:
        known.append(f"собеседник сказал: {f.predicate}={'' if f.polarity > 0 else 'не '}{f.obj}")
    assumed.append(f"намерение: {interpretation.intent} ({interpretation.intent_confidence:.2f})")
    if interpretation.applied_pattern is not None:
        assumed.append(interpretation.applied_pattern.describe())
    assumed.extend(interpretation.context_hypotheses)
    if prediction is not None:
        assumed.append(f"ожидаю реакцию: {prediction.expected_response_type} "
                       f"(валентность {prediction.expected_valence:+.2f})")
    unknown.extend(interpretation.uncertainties)
    if knowledge < 0.3:
        unknown.append("по этой теме у меня почти нет памяти/убеждений")

    errors: List[str] = []
    if learning_report is not None:
        a = learning_report.attribution
        if a.source != "none":
            errors.append(f"прошлый ход ({learning_report.previous_action} на {learning_report.previous_intent}): "
                          f"ошибка в {a.source} — {a.detail}")
        errors.extend(learning_report.lessons)

    return TickMetacognition(
        tick=tick,
        knowledge=knowledge,
        uncertainty=interpretation.uncertainty,
        prediction_confidence=getattr(prediction, "confidence", 0.0) if prediction is not None else 0.0,
        decision_confidence=decision.confidence if decision is not None else 0.0,
        reason=decision.reason if decision is not None else "",
        known=known, assumed=assumed, unknown=unknown, errors=errors,
        fallbacks_used=list(fallbacks_used or []),
    )
