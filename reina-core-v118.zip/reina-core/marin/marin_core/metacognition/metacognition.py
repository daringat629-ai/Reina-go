"""
Metacognition — §13 спеки. НЕ "сознание" — контроль качества собственного
cognition pipeline: согласованность поведения с личностью, накопленная
ошибка прогнозов, неразрешённые противоречия убеждений.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from ..belief.beliefs import BeliefStore, ContradictionFlag
from ..prediction.predictor import Prediction, Outcome
from ..prediction.prediction_error import compute_prediction_error


@dataclass
class MetacognitionReport:
    mean_prediction_error: float
    consistency_score: float          # 0..1, насколько поведение соответствовало Personality
    unresolved_contradictions: List[ContradictionFlag]
    propose_personality_update: bool
    escalate_uncertainty: bool
    dominant_error_source: Optional[str] = None   # intent/belief/social/goal/action — где я чаще ошибаюсь
    resolved_feedback_ticks: int = 0


@dataclass
class TickTrace:
    """Минимальный набор данных с одного тика, нужный для окна metacognition.
    Собирается engine/cycle.py и накапливается снаружи (в CognitiveEngine
    или вызывающей инфраструктуре) между запусками check_window."""

    prediction: Prediction
    outcome: Outcome
    prediction_error: float
    behavior_matched_personality: bool  # грубый бинарный сигнал согласованности
    error_source: Optional[str] = None  # заполнено, если это разрешённый реальной реакцией прогноз


class MetacognitionEngine:
    def __init__(
        self,
        belief_store: BeliefStore,
        consistency_low_threshold: float = 0.4,
        error_high_threshold: float = 0.6,
    ):
        self.belief_store = belief_store
        self.consistency_low_threshold = consistency_low_threshold
        self.error_high_threshold = error_high_threshold

    def check_window(self, window: List[TickTrace]) -> MetacognitionReport:
        """§13: периодический (не каждый тик) проход по последнему окну."""
        if not window:
            return MetacognitionReport(
                mean_prediction_error=0.0,
                consistency_score=1.0,
                unresolved_contradictions=[],
                propose_personality_update=False,
                escalate_uncertainty=False,
            )

        mean_error = sum(t.prediction_error for t in window) / len(window)
        consistency = sum(1.0 for t in window if t.behavior_matched_personality) / len(window)
        open_contradictions = self.belief_store.open_contradictions()

        propose_update = consistency < self.consistency_low_threshold
        escalate = len(open_contradictions) > 0 and any(
            self.belief_store.get(c.belief_id) and self.belief_store.get(c.belief_id).confidence > 0.75
            for c in open_contradictions
        )

        resolved = [t for t in window if t.error_source is not None]
        by_source: Dict[str, float] = {}
        for t in resolved:
            if t.error_source != "none":
                by_source[t.error_source] = by_source.get(t.error_source, 0.0) + t.prediction_error
        dominant = max(by_source, key=by_source.get) if by_source else None
        if resolved:
            # реальные (разрешённые реакцией) ошибки информативнее заглушечных
            mean_error = sum(t.prediction_error for t in resolved) / len(resolved)

        return MetacognitionReport(
            dominant_error_source=dominant,
            resolved_feedback_ticks=len(resolved),
            mean_prediction_error=mean_error,
            consistency_score=consistency,
            unresolved_contradictions=open_contradictions,
            propose_personality_update=propose_update,
            escalate_uncertainty=escalate,
        )
