"""
Offline Consolidation — §14 спеки. Запускается на idle или по расписанию
(engine/scheduler.py), не в real-time цикле. Второй приоритет реализации
(§18) — здесь референсный, упрощённый пайплайн; кластеризация и batch-
belief-update можно заменить на более сильные реализации без смены API.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List
from ..numeric import np

from .memory_graph import MemoryGraph, MemoryNode, NodeType
from .retrieval import compute_importance
from .pruning import prune_memory
import time


@dataclass
class ConsolidationReport:
    nodes_rescored: int
    semantic_clusters_created: int
    reflection_node_id: str | None
    nodes_pruned: int = 0


class ConsolidationEngine:
    def __init__(self, graph: MemoryGraph, similarity_threshold: float = 0.85, min_cluster_size: int = 3):
        self.graph = graph
        self.similarity_threshold = similarity_threshold
        self.min_cluster_size = min_cluster_size

    def run(self, since_ts: float) -> ConsolidationReport:
        window_nodes = [n for n in self.graph.all_nodes(NodeType.EVENT) if n.t_created >= since_ts]

        # 1-2. пересчёт importance с учётом накопленного опыта
        for n in window_nodes:
            n.importance = compute_importance(
                prediction_error_at_creation=n.payload.get("prediction_error", 0.0),
                novelty_at_creation=n.payload.get("novelty", 0.0),
                goal_relevance_at_creation=n.payload.get("goal_relevance", 0.0),
                access_count=n.access_count,
                age_seconds=max(time.time() - n.t_created, 1.0),
                emotional_weight=abs(n.valence),
            )

        # 3. простая кластеризация по косинусной близости (episodic -> semantic promotion)
        clusters = self._cluster(window_nodes)
        created = 0
        for cluster in clusters:
            if len(cluster) >= self.min_cluster_size:
                self._promote_to_semantic(cluster)
                created += 1

        # 4-6. batch belief/relationship/personality updates делегируются
        # соответствующим модулям (belief/, social/, identity/) — вызываются
        # снаружи, ConsolidationEngine отвечает только за память.

        # 7. self-reflection summary как узел
        reflection_id = self._write_reflection(window_nodes, created)

        # 8. забывание: удаляем давно не вспоминавшееся и держим потолок размера
        pruned = prune_memory(self.graph).removed

        return ConsolidationReport(
            nodes_rescored=len(window_nodes),
            semantic_clusters_created=created,
            reflection_node_id=reflection_id,
            nodes_pruned=pruned,
        )

    def _cluster(self, nodes: List[MemoryNode]) -> List[List[MemoryNode]]:
        clusters: List[List[MemoryNode]] = []
        used = set()
        for i, n in enumerate(nodes):
            if n.id in used:
                continue
            group = [n]
            used.add(n.id)
            for m in nodes[i + 1 :]:
                if m.id in used:
                    continue
                if _actor_of(n) != _actor_of(m):
                    continue  # разные люди — разные воспоминания, даже если тема одна
                if _cos_sim(n.embedding, m.embedding) >= self.similarity_threshold:
                    group.append(m)
                    used.add(m.id)
            clusters.append(group)
        return clusters

    def _promote_to_semantic(self, cluster: List[MemoryNode]) -> str:
        mean_embedding = np.mean([n.embedding for n in cluster], axis=0)
        # "Суть", а не точная стенограмма: человек не помнит каждый повтор
        # дословно — берём самого представительного члена кластера (ближе
        # всего к среднему по эмбеддингу), а не усредняем сам текст.
        most_central = max(cluster, key=lambda n: _cos_sim(n.embedding, mean_embedding))
        situation = most_central.payload.get("situation", {}) if isinstance(most_central.payload, dict) else {}
        gist_text = (situation.get("said") or situation.get("summary") or "").strip()
        if not gist_text:
            gist_text = f"Повторяющийся паттерн из {len(cluster)} похожих моментов"
        semantic = MemoryNode(
            type=NodeType.EVENT,
            embedding=mean_embedding,
            importance=max(n.importance for n in cluster),
            valence=sum(n.valence for n in cluster) / len(cluster),
            payload={
                "kind": "semantic",
                "summary": gist_text,
                "n_merged": len(cluster),
                # автор/чат сохраняются: обобщение остаётся ЧЬИМ-ТО, а не общим
                "actor": situation.get("actor", ""),
                "channel_id": situation.get("channel_id", ""),
                "speaker": situation.get("speaker", ""),
                "is_owner": bool(situation.get("is_owner", False)),
            },
        )
        semantic_id = self.graph.add_node(semantic)
        # Реальное сжатие: сырые узлы кластера удаляются, а не остаются
        # рядом с добавленным поверх них semantic-узлом — иначе граф бы
        # только рос с каждой консолидацией вместо того, чтобы сжиматься.
        for n in cluster:
            self.graph.remove_node(n.id)
        return semantic_id

    def _write_reflection(self, window_nodes: List[MemoryNode], clusters_created: int) -> str | None:
        if not window_nodes:
            return None
        mean_embedding = np.mean([n.embedding for n in window_nodes], axis=0)
        reflection = MemoryNode(
            type=NodeType.REFLECTION,
            embedding=mean_embedding,
            payload={
                "n_events": len(window_nodes),
                "semantic_clusters_created": clusters_created,
                "summary": f"Consolidated {len(window_nodes)} events into {clusters_created} semantic clusters.",
            },
        )
        return self.graph.add_node(reflection)


def _cos_sim(a: np.ndarray, b: np.ndarray) -> float:
    an, bn = np.linalg.norm(a), np.linalg.norm(b)
    if an == 0 or bn == 0:
        return 0.0
    return float(np.dot(a, b) / (an * bn))


def _actor_of(node: MemoryNode) -> str:
    payload = node.payload if isinstance(node.payload, dict) else {}
    sit = payload.get("situation") if isinstance(payload.get("situation"), dict) else {}
    return str(sit.get("actor") or payload.get("actor") or "")
