"""
Experience system — обёртка вокруг MemoryGraph, реализующая пайплайн
Observation -> Interpretation -> Experience -> Outcome -> Learning (п.7
исходного документа). working/episodic/semantic/... — это представления
(views) одного и того же графа, а не отдельные подсистемы: фильтры по
NodeType + времени + importance, а не разные хранилища.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional
from ..numeric import np

from .memory_graph import MemoryGraph, MemoryNode, NodeType, RelationType
from .retrieval import compute_importance


@dataclass
class ExperienceRecord:
    """Один прожитый эпизод: что наблюдали, как поняли, что сделали, что получили."""

    observation_node_id: str
    interpretation_summary: str
    action_node_id: Optional[str]
    outcome_node_id: Optional[str]
    prediction_error: float


class ExperienceSystem:
    """Фасад над MemoryGraph для записи/чтения опыта в его естественной форме
    (цепочка Event -> Outcome с рёбрами PRECEDES/CAUSES), вместо ручной
    работы с графом из engine/cycle.py."""

    def __init__(self, graph: MemoryGraph):
        self.graph = graph

    def record_tick(
        self,
        observation_embedding: np.ndarray,
        situation_summary: dict,
        action_type: str,
        outcome_embedding: Optional[np.ndarray],
        prediction_error: float,
        novelty: float,
        goal_relevance: float,
        valence: float = 0.0,
    ) -> ExperienceRecord:
        event = MemoryNode(
            type=NodeType.EVENT,
            embedding=observation_embedding,
            payload={"situation": situation_summary},
            valence=valence,
        )
        self.graph.add_node(event)

        outcome_id = None
        if outcome_embedding is not None:
            outcome = MemoryNode(
                type=NodeType.OUTCOME,
                embedding=outcome_embedding,
                payload={"action_type": action_type},
            )
            outcome_id = self.graph.add_node(outcome)
            self.graph.add_edge(event.id, RelationType.PRECEDES, outcome_id)

        importance = compute_importance(
            prediction_error_at_creation=prediction_error,
            novelty_at_creation=novelty,
            goal_relevance_at_creation=goal_relevance,
            access_count=0,
            age_seconds=1.0,
            emotional_weight=abs(valence),
        )
        event.importance = importance
        if outcome_id:
            self.graph.peek(outcome_id).importance = importance

        return ExperienceRecord(
            observation_node_id=event.id,
            interpretation_summary=situation_summary.get("summary", ""),
            action_node_id=None,
            outcome_node_id=outcome_id,
            prediction_error=prediction_error,
        )

    # ---- "уровни памяти" как представления графа, не отдельные хранилища ----

    def working(self, limit: int = 20) -> List[MemoryNode]:
        nodes = sorted(self.graph.all_nodes(), key=lambda n: n.t_last_access, reverse=True)
        return nodes[:limit]

    def episodic(self) -> List[MemoryNode]:
        return self.graph.all_nodes(NodeType.EVENT)

    def semantic(self) -> List[MemoryNode]:
        # После consolidation семантические обобщения тоже живут как EVENT-узлы
        # с payload["kind"] == "semantic" — см. consolidation.py.
        return [n for n in self.graph.all_nodes(NodeType.EVENT) if n.payload.get("kind") == "semantic"]

    def reflections(self) -> List[MemoryNode]:
        return self.graph.all_nodes(NodeType.REFLECTION)
