"""
Memory Graph — §5 спеки. Единая связанная память вместо семи независимых
memory manager'ов. Узлы типизированы (Event/Belief/Entity/Emotion/Goal/
Outcome), рёбра — типизированные отношения.

Хранилище здесь — in-memory референсная реализация (dict). Для прод-версии
заменяется на графовую БД (Neo4j/Memgraph) или векторный индекс + рёбра
в SQL — интерфейс (add_node/add_edge/get/neighbors) должен остаться таким же.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Tuple
import time
import uuid
from ..numeric import np


class NodeType(str, Enum):
    EVENT = "event"
    BELIEF = "belief"
    ENTITY = "entity"
    EMOTION = "emotion"
    GOAL = "goal"
    OUTCOME = "outcome"
    REFLECTION = "reflection"  # добавляется consolidation'ом, §14 п.7


class RelationType(str, Enum):
    CAUSES = "causes"
    PRECEDES = "precedes"
    INVOLVES = "involves"
    CONTRADICTS = "contradicts"
    SUPPORTS = "supports"
    ABOUT = "about"
    FELT_DURING = "felt_during"


@dataclass
class Edge:
    relation: RelationType
    target_id: str
    weight: float = 1.0


@dataclass
class MemoryNode:
    """§5.1"""

    type: NodeType
    embedding: np.ndarray
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    t_created: float = field(default_factory=time.time)
    t_last_access: float = field(default_factory=time.time)
    importance: float = 0.0
    valence: float = 0.0
    access_count: int = 0
    edges: List[Edge] = field(default_factory=list)
    payload: dict = field(default_factory=dict)  # произвольные структурированные данные узла

    def touch(self) -> None:
        self.t_last_access = time.time()
        self.access_count += 1


class MemoryGraph:
    def __init__(self) -> None:
        self._nodes: Dict[str, MemoryNode] = {}

    def add_node(self, node: MemoryNode) -> str:
        self._nodes[node.id] = node
        return node.id

    def add_edge(self, source_id: str, relation: RelationType, target_id: str, weight: float = 1.0) -> None:
        if source_id not in self._nodes:
            raise KeyError(f"unknown source node {source_id}")
        self._nodes[source_id].edges.append(Edge(relation=relation, target_id=target_id, weight=weight))

    def get(self, node_id: str) -> Optional[MemoryNode]:
        node = self._nodes.get(node_id)
        if node is not None:
            node.touch()
        return node

    def peek(self, node_id: str) -> Optional[MemoryNode]:
        """Как get, но не считается за доступ (для внутренних служебных чтений)."""
        return self._nodes.get(node_id)

    def neighbors(self, node_id: str, relation: Optional[RelationType] = None) -> List[Tuple[Edge, MemoryNode]]:
        node = self._nodes.get(node_id)
        if node is None:
            return []
        result = []
        for edge in node.edges:
            if relation is not None and edge.relation != relation:
                continue
            target = self._nodes.get(edge.target_id)
            if target is not None:
                result.append((edge, target))
        return result

    def all_nodes(self, node_type: Optional[NodeType] = None) -> List[MemoryNode]:
        if node_type is None:
            return list(self._nodes.values())
        return [n for n in self._nodes.values() if n.type == node_type]

    def remove_node(self, node_id: str) -> bool:
        """Нужно для реального сжатия памяти (см. ConsolidationEngine):
        после того как несколько похожих событий свёрнуты в один
        semantic-узел с сутью, исходные узлы удаляются — иначе граф бы
        только рос с каждой консолидацией, а не сжимался."""
        return self._nodes.pop(node_id, None) is not None

    def remove_dangling_edges(self) -> int:
        """Убирает рёбра, ведущие на уже удалённые узлы (после pruning)."""
        removed = 0
        for node in self._nodes.values():
            kept = [e for e in node.edges if e.target_id in self._nodes]
            removed += len(node.edges) - len(kept)
            if len(kept) != len(node.edges):
                node.edges = kept
        return removed

    def __len__(self) -> int:
        return len(self._nodes)
