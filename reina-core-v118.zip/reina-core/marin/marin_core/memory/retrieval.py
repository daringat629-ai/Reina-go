"""
Retrieval — §5.2-5.4 спеки: retrieval_score, importance, retrievability
(forgetting-as-decay вместо удаления, аналог ACT-R base-level activation).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, List, Optional
import time
from ..numeric import np

from .memory_graph import MemoryNode

TAU_RECENCY_SECONDS = 6 * 3600.0     # часы — масштаб recency в retrieval_score
TAU_BASE_FORGET_SECONDS = 3 * 24 * 3600.0  # база для retrievability decay


@dataclass
class RetrievalWeights:
    """beta1..beta6 из §5.2."""

    beta_similarity: float = 1.0
    beta_recency: float = 0.5
    beta_relationship: float = 0.5
    beta_goal: float = 0.7
    beta_importance: float = 0.6
    beta_prediction_relevance: float = 0.4


def _cos_sim(a: np.ndarray, b: np.ndarray) -> float:
    an, bn = np.linalg.norm(a), np.linalg.norm(b)
    if an == 0 or bn == 0:
        return 0.0
    return float(np.dot(a, b) / (an * bn))


def retrieval_score(
    node: MemoryNode,
    situation_embedding: np.ndarray,
    relationship_relevance: float,
    goal_relevance: float,
    prediction_relevance: float,
    weights: RetrievalWeights,
    now: Optional[float] = None,
) -> float:
    """§5.2."""
    now = now or time.time()
    recency = float(np.exp(-(now - node.t_last_access) / TAU_RECENCY_SECONDS))
    return (
        weights.beta_similarity * _cos_sim(node.embedding, situation_embedding)
        + weights.beta_recency * recency
        + weights.beta_relationship * relationship_relevance
        + weights.beta_goal * goal_relevance
        + weights.beta_importance * node.importance
        + weights.beta_prediction_relevance * prediction_relevance
    )


def retrievability(node: MemoryNode, now: Optional[float] = None, tau_base: float = TAU_BASE_FORGET_SECONDS) -> float:
    """§5.4: retrievability(m,t) = importance * exp(-(t - t_last_access) / (tau_base * (1 + access_count)))."""
    now = now or time.time()
    tau = tau_base * (1 + node.access_count)
    return node.importance * float(np.exp(-(now - node.t_last_access) / tau))


def compute_importance(
    prediction_error_at_creation: float,
    novelty_at_creation: float,
    goal_relevance_at_creation: float,
    access_count: float,
    age_seconds: float,
    emotional_weight: float = 0.0,
    gamma: tuple = (0.30, 0.20, 0.20, 0.15, 0.15),
) -> float:
    """§5.3 + эмоциональная память: заряженные события (высокий |valence|)
    получают больший importance и потому дольше переживают forgetting-decay
    в retrievability() — как и должно быть, "мне очень понравилось то, что
    ты сделала" не должно забываться так же быстро, как "ел макароны".
    gamma = (g1..g5); emotional_weight ожидается уже в 0..1 (abs(valence))."""
    g1, g2, g3, g4, g5 = gamma
    access_rate = access_count / max(age_seconds, 1.0)
    return (
        g1 * abs(prediction_error_at_creation)
        + g2 * novelty_at_creation
        + g3 * goal_relevance_at_creation
        + g4 * access_rate
        + g5 * min(1.0, abs(emotional_weight))
    )


def retrieve_top_k(
    nodes: List[MemoryNode],
    situation_embedding: np.ndarray,
    k: int,
    weights: RetrievalWeights,
    relationship_relevance_fn: Callable[[MemoryNode], float] = lambda n: 0.0,
    goal_relevance_fn: Callable[[MemoryNode], float] = lambda n: 0.0,
    prediction_relevance_fn: Callable[[MemoryNode], float] = lambda n: 0.0,
    min_retrievability: float = 0.0,
) -> List[MemoryNode]:
    """Top-K по retrieval_score среди узлов с достаточной retrievability (§5.2 + §5.4)."""
    now = time.time()
    candidates = [n for n in nodes if retrievability(n, now=now) >= min_retrievability]
    scored = [
        (
            retrieval_score(
                n,
                situation_embedding,
                relationship_relevance_fn(n),
                goal_relevance_fn(n),
                prediction_relevance_fn(n),
                weights,
                now=now,
            ),
            n,
        )
        for n in candidates
    ]
    scored.sort(key=lambda pair: pair[0], reverse=True)
    top = [n for _, n in scored[:k]]
    for n in top:
        n.touch()
    return top
