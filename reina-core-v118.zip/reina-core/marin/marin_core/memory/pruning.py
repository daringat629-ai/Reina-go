"""Pruning — настоящее забывание.

Раньше «забывание» было только формулой (retrievability): узлы затухали, но
никогда не удалялись — граф рос бесконечно, каждый тик перебирал все узлы,
а файл состояния раздувался. Здесь — бережная чистка:

* трогаем только EVENT / OUTCOME / REFLECTION; узлы с ``payload["pinned"]``
  и недавние (моложе ``min_age_seconds``) не удаляются никогда;
* удаляется то, что давно не вспоминали и что не было важным/эмоциональным
  (retrievability ниже порога); память о владельце затухает вдвое медленнее;
* «суть» (kind=semantic) живёт дольше сырых эпизодов;
* если узлов всё равно больше ``max_nodes`` — снимаем самые слабые сверху вниз;
* рефлексий храним не больше ``max_reflections`` (самые свежие);
* после чистки удаляются рёбра на несуществующие узлы.
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from typing import List, Optional

from ..env import env_int
from .memory_graph import MemoryGraph, MemoryNode, NodeType
from .retrieval import retrievability

_PRUNE_TAU_SECONDS = 30 * 24 * 3600.0
_PRUNABLE = (NodeType.EVENT, NodeType.OUTCOME, NodeType.REFLECTION)


@dataclass
class PruneReport:
    removed: int = 0
    removed_faded: int = 0
    removed_over_cap: int = 0
    removed_reflections: int = 0
    dangling_edges: int = 0


def default_max_nodes() -> int:
    return env_int("MARIN_MEMORY_MAX_NODES", 5000, minimum=200)


def _payload(node: MemoryNode) -> dict:
    return node.payload if isinstance(node.payload, dict) else {}


def _is_pinned(node: MemoryNode) -> bool:
    return bool(_payload(node).get("pinned"))


def _is_owner(node: MemoryNode) -> bool:
    p = _payload(node)
    sit = p.get("situation") if isinstance(p.get("situation"), dict) else {}
    return bool(sit.get("is_owner") or p.get("is_owner"))


def _strength(node: MemoryNode, now: float) -> float:
    """Насколько узел ещё «жив»: retrievability + бонусы за суть/владельца."""
    # для долгой памяти — медленное затухание (30 дней вместо 3 дней поиска):
    # важное событие двухмесячной давности ещё «живо», пустое — уже нет
    s = retrievability(node, now=now, tau_base=_PRUNE_TAU_SECONDS)
    if _payload(node).get("kind") == "semantic":
        s = s * 1.5 + 0.02
    if _is_owner(node):
        s = s * 2.0 + 0.01
    return s


def prune_memory(
    graph: MemoryGraph,
    *,
    now: Optional[float] = None,
    max_nodes: Optional[int] = None,
    min_age_seconds: float = 14 * 24 * 3600.0,
    fade_threshold: float = 0.005,
    max_reflections: int = 50,
) -> PruneReport:
    now = now or time.time()
    max_nodes = default_max_nodes() if max_nodes is None else int(max_nodes)
    report = PruneReport()

    def removable(n: MemoryNode) -> bool:
        return n.type in _PRUNABLE and not _is_pinned(n) and (now - n.t_created) >= min_age_seconds

    # 1. забытое: старое, давно не вспоминали, не важное
    for n in list(graph.all_nodes()):
        if n.type == NodeType.REFLECTION or not removable(n):
            continue
        if _strength(n, now) < fade_threshold:
            graph.remove_node(n.id)
            report.removed_faded += 1

    # 2. рефлексий — только самые свежие
    reflections: List[MemoryNode] = sorted(
        (n for n in graph.all_nodes(NodeType.REFLECTION) if not _is_pinned(n)),
        key=lambda n: n.t_created, reverse=True,
    )
    for n in reflections[max_reflections:]:
        graph.remove_node(n.id)
        report.removed_reflections += 1

    # 3. потолок размера: снимаем самые слабые из тех, что можно удалять
    overflow = len(graph) - max_nodes
    if overflow > 0:
        weak = sorted((n for n in graph.all_nodes() if removable(n)), key=lambda n: _strength(n, now))
        for n in weak[:overflow]:
            graph.remove_node(n.id)
            report.removed_over_cap += 1

    report.removed = report.removed_faded + report.removed_reflections + report.removed_over_cap
    if report.removed:
        report.dangling_edges = graph.remove_dangling_edges()
    return report
