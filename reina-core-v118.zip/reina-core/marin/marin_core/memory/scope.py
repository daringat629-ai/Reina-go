"""Чьё это воспоминание — границы памяти между людьми и чатами.

Раньше и воспоминания, и убеждения доставались из ОДНОГО общего графа по
одной лишь близости к теме: слово «винда» от постороннего человека всплывало
в личке с владельцем, а в самом тексте воспоминания не было ни автора, ни
чата, ни времени. Отсюда «она спрашивает про ту винду» и «он сделал до —
а она пишет, что делает до».

Режим задаётся ``MARIN_MEMORY_SCOPE``:

* ``strict`` (по умолчанию) — в разговор попадает только память ЭТОГО человека
  и ЭТОГО чата (плюс общие «уроки» о своём поведении). Чужие разговоры
  доходят до неё только явным блоком «что было в других чатах» — с именами.
* ``labeled`` — как раньше видно всё, но каждое воспоминание подписано:
  кто говорил, где и когда.
* ``off`` — прежнее поведение (без фильтра), подписи всё равно добавляются.
"""
from __future__ import annotations

import datetime as _dt
import re
import time
from typing import Any, Dict, Optional

from ..env import env_str

_MODES = ("strict", "labeled", "off")


def scope_mode() -> str:
    mode = (env_str("MARIN_MEMORY_SCOPE", "strict") or "strict").strip().lower()
    return mode if mode in _MODES else "strict"


def _payload(node: Any) -> dict:
    p = getattr(node, "payload", None)
    return p if isinstance(p, dict) else {}


def _situation(node: Any) -> dict:
    p = _payload(node)
    s = p.get("situation")
    return s if isinstance(s, dict) else {}


def node_source(node: Any) -> Dict[str, Any]:
    """Кто/где: actor (id), channel (telegram:<chat>), speaker (имя), is_owner.
    Старые узлы знают только actor — остальное пустое."""
    p, s = _payload(node), _situation(node)

    def pick(key: str) -> Any:
        return s.get(key) or p.get(key) or ""

    return {
        "actor": str(pick("actor") or ""),
        "channel": str(pick("channel_id") or ""),
        "speaker": str(pick("speaker") or ""),
        "is_owner": bool(pick("is_owner")),
    }


def _is_shared_lesson(node: Any) -> bool:
    kind = _payload(node).get("kind")
    node_type = getattr(getattr(node, "type", None), "value", "")
    return kind == "lesson" or node_type == "reflection"


def node_visible(node: Any, *, actor_id: str, channel_id: str, is_owner: bool,
                 mode: Optional[str] = None) -> bool:
    """Можно ли показывать это воспоминание в разговоре с actor_id в channel_id."""
    mode = mode or scope_mode()
    if mode != "strict":
        return True
    if _is_shared_lesson(node):
        return True  # выводы о собственном поведении — не чужая переписка
    src = node_source(node)
    if not src["actor"]:
        return bool(is_owner)  # без автора: только владельцу
    if src["actor"] == str(actor_id):
        return True  # свои же слова этого человека (в любом чате)
    if channel_id and src["channel"] and src["channel"] == str(channel_id):
        return True  # общий чат: слова других участников, но с подписью
    return False


def belief_visible(belief: Any, *, actor_id: str, mode: Optional[str] = None) -> bool:
    """Убеждение о другом человеке не участвует в разговоре с третьим."""
    mode = mode or scope_mode()
    if mode != "strict":
        return True
    subject = getattr(belief, "subject", None)
    return subject is None or str(subject) == str(actor_id)


def same_context_bonus(node: Any, *, actor_id: str, channel_id: str) -> float:
    """Для ранжирования: то, что было в этом же чате / с этим же человеком, ближе."""
    src = node_source(node)
    if channel_id and src["channel"] == str(channel_id):
        return 1.0
    if src["actor"] and src["actor"] == str(actor_id):
        return 0.6
    return 0.0


def relative_when(ts: float, now: Optional[float] = None) -> str:
    now = now or time.time()
    try:
        d_then = _dt.date.fromtimestamp(ts)
        d_now = _dt.date.fromtimestamp(now)
    except (OverflowError, OSError, ValueError):
        return "когда-то"
    days = (d_now - d_then).days
    clock = time.strftime("%H:%M", time.localtime(ts))
    if days <= 0:
        return f"сегодня {clock}"
    if days == 1:
        return f"вчера {clock}"
    if days < 7:
        return f"{days} дн. назад"
    return d_then.strftime("%d.%m")


_SPACES_RE = re.compile(r"\s+")


def _clean(text: Any, limit: int) -> str:
    s = _SPACES_RE.sub(" ", str(text or "")).strip()
    return s if len(s) <= limit else s[: limit - 1].rstrip() + "…"


def format_memory(node: Any, *, now: Optional[float], actor_id: str, channel_id: str,
                  owner_actor_id: str = "") -> str:
    """Одна строка воспоминания С ПОДПИСЬЮ: когда, кто говорил, тот ли это человек,
    что пишет сейчас. Пустая строка — нечего показывать (служебный узел)."""
    from ..interpretation.lexicon import focal_text  # ленивый импорт: без циклов

    p, s = _payload(node), _situation(node)
    src = node_source(node)
    when = relative_when(getattr(node, "t_created", 0.0) or 0.0, now)

    if src["is_owner"] or (owner_actor_id and src["actor"] == str(owner_actor_id)):
        who = "Владелец"
    else:
        who = src["speaker"] or (f"человек id {src['actor']}" if src["actor"] else "кто-то")

    if src["actor"] and src["actor"] == str(actor_id):
        relation = "это тот же человек, что пишет сейчас"
    elif channel_id and src["channel"] == str(channel_id):
        relation = f"другой участник этого же чата — {who}, НЕ тот, кто пишет сейчас"
    elif src["actor"] or src["speaker"]:
        relation = f"ДРУГОЙ человек ({who}) в другом разговоре — не про текущего собеседника"
    else:
        relation = ""

    if p.get("kind") == "semantic":
        body = f"{_clean(p.get('summary'), 260)} (повторялось {p.get('n_merged', '?')} раз)"
        head = f"[{when}" + (f"; {relation}" if relation else "") + "]"
        return f"{head} {body}".strip() if body.strip() else ""

    said = _clean(focal_text(str(s.get("said") or "")), 240)
    reply = _clean(s.get("summary"), 160)
    if not said and not reply:
        return ""
    head = f"[{when}" + (f"; {relation}" if relation else "") + "]"
    parts = []
    if said:
        parts.append(f"{who} написал(а): «{said}»")
    if reply:
        parts.append(f"ты ответила: «{reply}»")
    return f"{head} " + "; ".join(parts)


def format_belief(belief: Any, *, actor_id: str, actor_label: str = "") -> str:
    """Убеждение с указанием, о ком оно: чтобы факт про другого человека не
    читался как факт про собеседника или про саму Marin."""
    base = f"{belief.statement} (confidence={belief.confidence:.2f}, source={belief.source_type.value})"
    subject = getattr(belief, "subject", None)
    if subject is None:
        return base
    if str(subject) == str(actor_id):
        return f"[о собеседнике] {base}"
    return f"[о ДРУГОМ человеке, не о собеседнике] {base}"
