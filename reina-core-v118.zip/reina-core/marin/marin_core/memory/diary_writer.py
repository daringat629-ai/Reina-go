"""
DiaryWriter — строит записи дневника тем же LLMProvider, что и обычные
ответы (§17 спеки: LLM — языковой орган, не источник решений). Использует
ActionType.REMEMBER как сигнал провайдеру "это не сообщение собеседнику, а
личная запись" (см. llm/providers.py::_style_prior_to_system_prompt).

Два режима:
- write_entry(since_ts, period_label)  — запись по периоду (для
  ConsolidationScheduler на простое, §14 спеки).
- write_live_thought(limit)            — "о чём думаю прямо сейчас", по
  последним N эпизодам working memory (для команды в Telegram).
"""

from __future__ import annotations

from typing import List, Optional
import time
import uuid

from ..action.action import ActionType
from ..llm.interface import LLMProvider, LanguagePlanningInput
from ..memory.experience import ExperienceSystem
from ..memory.memory_graph import MemoryNode
from .diary import DiaryEntry, DiaryStore


class DiaryWriter:
    def __init__(
        self,
        provider: LLMProvider,
        experience: ExperienceSystem,
        store: DiaryStore,
        identity=None,
        personality=None,
    ):
        self.provider = provider
        self.experience = experience
        self.store = store
        self.identity = identity
        self.personality = personality

    def write_entry(self, since_ts: float, period_label: str) -> Optional[DiaryEntry]:
        """Запись по периоду — что происходило с since_ts. Возвращает None,
        если за период вообще ничего не было (не пишем пустые записи)."""
        window_nodes = [n for n in self.experience.episodic() if n.t_created >= since_ts]
        if not window_nodes:
            return None
        return self._write(sorted(window_nodes, key=lambda n: n.t_created), period_label)

    def write_live_thought(self, limit: int = 8) -> DiaryEntry:
        """Мгновенная мысль по последним N эпизодам working memory —
        для команды типа ".мысли" в Telegram. В отличие от write_entry
        всегда что-то возвращает, даже если эпизодов мало/нет."""
        window_nodes = self.experience.working(limit=limit)
        return self._write(window_nodes, period_label="прямо сейчас")

    def _write(self, window_nodes: List[MemoryNode], period_label: str) -> DiaryEntry:
        lines = []
        for n in window_nodes:
            said = n.payload.get("said")
            summary = n.payload.get("summary")
            if said:
                lines.append(f"Собеседник сказал: {said}")
            if summary:
                lines.append(f"Я ответила: {summary}")
        events_text = "\n".join(lines[-40:]) or "Ничего особенного не происходило — было тихо."

        style_prior = self.personality.style_prior if self.personality else {}
        constraints = [inv.description for inv in self.identity.invariants] if self.identity else []

        planning_input = LanguagePlanningInput(
            situation_summary=(
                f"Дневниковая запись/мысль за период: {period_label}.\n\n"
                f"Что было:\n{events_text}"
            ),
            retrieved_memory_summaries=[],
            active_belief_summaries=[],
            chosen_action_type=ActionType.REMEMBER,
            goal_context_summary="Отрефлексировать прожитое для себя, не для собеседника.",
            style_prior=style_prior,
            constraints=constraints,
        )
        text = self.provider.generate(planning_input).strip()

        entry = DiaryEntry(
            id=str(uuid.uuid4()),
            t_created=time.time(),
            text=text,
            period_label=period_label,
            n_events=len(window_nodes),
        )
        self.store.add(entry)
        return entry
