"""
Diary — личный дневник Marin. Отдельная, более простая сущность, чем
MemoryGraph: не граф, а просто хронологический список первых-лицных записей
("что происходило", "о чём думаю"), написанных LLM в голосе Marin (см.
diary_writer.py). Не отправляется собеседнику как сообщение сама по себе —
читается по явному запросу (напр. команда в telegram/client.py).

По умолчанию — в памяти процесса, как и остальной marin_core (см. README,
"Дальнейшие шаги"). Если передан path — пишет/читает JSON-файл, совместимый
по духу со старым MARIN_DIARY_FILE=diary.json из v30 (см. config.py).
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import List, Optional
import json
import os
import time
import uuid


@dataclass
class DiaryEntry:
    id: str
    t_created: float
    text: str
    period_label: str          # напр. "23:00–07:40" или "прямо сейчас"
    n_events: int = 0          # сколько эпизодов памяти легло в основу записи


class DiaryStore:
    def __init__(self, path: Optional[str] = None):
        self.path = path
        self.entries: List[DiaryEntry] = []
        if path and os.path.exists(path):
            self._load()

    def add(self, entry: DiaryEntry) -> None:
        self.entries.append(entry)
        if self.path:
            self._save()

    def recent(self, limit: int = 10) -> List[DiaryEntry]:
        return sorted(self.entries, key=lambda e: e.t_created, reverse=True)[:limit]

    def __len__(self) -> int:
        return len(self.entries)

    def _save(self) -> None:
        """Атомарная запись (через tmp + os.replace), чтобы не оставить
        битый JSON при падении процесса посреди записи."""
        data = [asdict(e) for e in self.entries]
        tmp_path = f"{self.path}.tmp"
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(tmp_path, self.path)

    def _load(self) -> None:
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                data = json.load(f)
            self.entries = [DiaryEntry(**d) for d in data]
        except Exception:
            # битый/чужой файл — не роняем движок из-за дневника
            self.entries = []
