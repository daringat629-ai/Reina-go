"""OutputGuard — структурная проверка качества реплики перед отправкой.

Почему не список фраз. Старый фильтр (providers._META_LEAK_MARKERS_*) ловил
только уже виденные формулировки, а модель их постоянно меняет. В живом
чате владелец увидел то, что список пропустил:

  * рассуждение модели вместо реплики — «The owner (Jaabir) just said
    "Я сам не админ" in response to my previous messages… 1. He asked…»;
  * агентный бред-цикл — «Let me connect to the service interactively.
    Let me connect to the service properly. Let me try … using nc.»;
  * перевёрнутый служебный маркер — «подхватила >>>READ:get_bio|<<<».

Здесь проверяется устройство текста, а не конкретные слова:

  hard (реплику отправлять нельзя, во всех путях):
    meta_narration — модель рассуждает о задаче/собеседнике в 3-м лице
                     или объявляет свои «действия» (let me / I will …);
    repetition     — одно и то же предложение (или почти то же) ≥3 раз;
    foreign_script — длинный текст почти целиком латиницей, когда Марин
                     говорит по-русски (только в связке с другими
                     признаками рассуждения, чтобы не глушить
                     нормальный английский ответ англоязычному человеку).

  soft (стоит перегенерировать, если есть попытка, но не блокировать):
    masculine_self — Марин о себе в мужском роде («я включил», «я сам»);
    mixed_language — отдельные английские слова посреди русской фразы.

Модуль без внешних зависимостей и без состояния — дешёвый, вызывается на
каждой реплике.
"""
from __future__ import annotations

import difflib
import re
from dataclasses import dataclass, field
from typing import List

# --------------------------------------------------------------- patterns
_URL_RE = re.compile(r"https?://\S+|t\.me/\S+|www\.\S+", re.IGNORECASE)
_MENTION_RE = re.compile(r"@\w+")
_MARKER_RE = re.compile(r"<<<.*?>>>", re.DOTALL)
_CODE_RE = re.compile(r"`[^`]*`")

# Модель рассуждает о задаче или объявляет свои шаги как агент.
_META_EN = [
    r"\blet me (?:connect|try|check|call|use|run|open|look|think|analy[sz]e|respond|reply|see|figure|start|interact)\b",
    r"\bi(?:'ll| will| need to| should| must| am going to|'m going to) "
    r"(?:connect|try|check|call|use|run|respond|reply|answer|write|produce|generate|craft|analy[sz]e)\b",
    r"\b(?:the|this) (?:owner|user|assistant|human)\b[^.\n]{0,60}\b(?:said|asked|asks|wants|sent|is asking|replied|wrote|just)\b",
    r"\bin response to (?:my|the|his|her|their)\b",
    r"\bmy previous (?:message|messages|reply|replies|response|answer)s?\b",
    r"\b(?:using|via|with) (?:nc|netcat|curl|telnet|ssh|bash|the terminal|the api)\b",
    r"\binteract(?:ively| with (?:it|the service))\b",
    r"\bconnect to the service\b",
    r"\bas an ai\b|\blanguage model\b|\bsystem prompt\b",
    r"\b(?:tool|function) call\b",
    r"\bin character as\b|\brespond as marin\b|\bstay in character\b",
]
_META_RU = [
    r"\bкак (?:ии|ai|языковая модель|нейросеть|ассистент|бот)[,.!\s]",
    r"\b(?:владелец|пользователь|собеседник) (?:написал|просит|спрашивает|хочет|сказал|прислал)\b",
    r"\bмне (?:нужно|надо|следует) (?:ответить|сформулировать|сгенерировать|написать ответ)\b",
    r"\b(?:ответ|отвечаю) (?:в роли|от лица) марин",
    r"\bсистемн(?:ый|ого) промпт",
]
_META_RE = re.compile("|".join(_META_EN + _META_RU), re.IGNORECASE)

# Нумерованный «разбор» (1. … 2. … 3.) латиницей — формат рассуждения.
_NUMBERED_EN_RE = re.compile(r"(?:^|\n)\s*[1-9][.)]\s+[A-Za-z]", re.MULTILINE)

# «я … -л» без «-ла»: мужской род прошедшего времени о себе.
_MASC_SELF_RE = re.compile(
    r"\bя\s+(?:(?:уже|тоже|просто|сейчас|вчера|сегодня|только|вот|же|ведь|не)\s+){0,2}"
    r"(?!был[аио]?\b)([а-яё]{3,}(?:ал|ял|ил|ел|ёл|ыл|ул|шёл|рос|мог|лёг|пёк|вёз|нёс))\b",
    re.IGNORECASE,
)
_MASC_IRREGULAR_RE = re.compile(
    r"\bя\s+(?:(?:уже|тоже|просто|сейчас|вчера|сегодня|только|вот|же|ж|ведь|не|бы)\s+){0,2}"
    r"(мог|шёл|шел|нёс|нес|вёз|вез|лёг|лег|пёк|пек|смог|помог|вышел|ушёл|ушел|пришёл|пришел|нашёл|нашел|зашёл|зашел)\b",
    re.IGNORECASE,
)
_MASC_SAM_RE = re.compile(r"\bя\s+(?:же\s+)?сам\b(?!\s*[,-]?\s*(?:себе|собой))", re.IGNORECASE)

# Слово, где кириллица смешана с латиницей («Сначаla»), и символы, которым
# нечего делать в русской реплике: греческие буквы и комбинируемые знаки
# кириллицы («б꙰ιο») — признак сбоя декодирования модели.
_MIXED_WORD_RE = re.compile(r"(?=[\wꙀ-ꚟ]*[А-Яа-яЁё])(?=[\wꙀ-ꚟ]*[A-Za-z])[\wꙀ-ꚟ]+")
_ODD_SCRIPT_RE = re.compile(r"[\u0370-\u03FF\u0483-\u0489\uA670-\uA69F]")

_SENT_SPLIT_RE = re.compile(r"(?<=[.!?…])\s+|\n+")
_LATIN_WORD_RE = re.compile(r"\b[A-Za-z]{3,}\b")
_CYR_RE = re.compile(r"[А-Яа-яЁё]")
_LAT_RE = re.compile(r"[A-Za-z]")

# Английские слова, которые нормально звучат в русской переписке.
_ALLOWED_LATIN = {
    "ok", "okay", "lol", "wow", "omg", "wtf", "bro", "vibe", "vibes", "cute", "sorry",
    "please", "thanks", "hello", "bye", "yes", "no", "love", "like", "cool", "nice",
    "telegram", "tg", "youtube", "tiktok", "instagram", "google", "iphone", "android",
    "anime", "manga", "cosplay", "marin", "kitagava", "kitagawa", "gojo", "ai", "gg",
    # названия и слова, которые в русской переписке пишут латиницей и не считают «английским»
    "discord", "whatsapp", "viber", "spotify", "netflix", "steam", "twitch", "reddit", "twitter",
    "windows", "linux", "ios", "macbook", "ipad", "python", "github", "chatgpt", "openai",
    "blender", "photoshop", "figma", "minecraft", "roblox", "genshin", "wifi", "vpn", "usb",
    "online", "offline", "stream", "streamer", "vtuber", "live2d", "bot", "id", "pc", "ps",
    "reina", "orvi", "sporadev", "sporadev", "lowpoly", "ok", "dm", "pm", "irl", "ngl", "imo",
}


@dataclass
class Verdict:
    ok: bool
    hard: List[str] = field(default_factory=list)
    soft: List[str] = field(default_factory=list)

    @property
    def retry_worthy(self) -> bool:
        return bool(self.hard or self.soft)

    def describe(self) -> str:
        return ", ".join(self.hard + self.soft) or "ok"


# ------------------------------------------------------------ primitives
def _visible_text(text: str) -> str:
    """Текст без служебных маркеров, ссылок, упоминаний и кода — то, что
    реально прочитает человек и по чему имеет смысл судить о языке."""
    text = _MARKER_RE.sub(" ", text or "")
    text = _URL_RE.sub(" ", text)
    text = _MENTION_RE.sub(" ", text)
    text = _CODE_RE.sub(" ", text)
    return text


def _sentences(text: str) -> List[str]:
    out = []
    for s in _SENT_SPLIT_RE.split(text):
        norm = re.sub(r"[^\w\s]", " ", s.lower())
        norm = re.sub(r"\s+", " ", norm).strip()
        if len(norm.split()) >= 3:
            out.append(norm)
    return out[:40]


def repetition_score(text: str) -> int:
    """Размер самой большой группы почти одинаковых предложений."""
    sents = _sentences(text)
    if len(sents) < 3:
        return len(sents) if len(set(sents)) == 1 and sents else 1
    best = 1
    for i, a in enumerate(sents):
        group = 1
        for b in sents[i + 1:]:
            if a == b or difflib.SequenceMatcher(None, a, b).ratio() >= 0.8:
                group += 1
        best = max(best, group)
    return best


def latin_ratio(text: str) -> float:
    visible = _visible_text(text)
    lat = len(_LAT_RE.findall(visible))
    cyr = len(_CYR_RE.findall(visible))
    total = lat + cyr
    return lat / total if total else 0.0


def stray_latin_words(text: str) -> List[str]:
    """Английские слова внутри в основном русского текста («complications»)."""
    visible = _visible_text(text)
    if len(_CYR_RE.findall(visible)) < 20:
        return []
    return [w for w in _LATIN_WORD_RE.findall(visible) if w.lower() not in _ALLOWED_LATIN]


def garbled_words(text: str) -> List[str]:
    """Испорченные слова: смесь алфавитов внутри слова или «чужие» символы."""
    visible = _visible_text(text)
    hits = _MIXED_WORD_RE.findall(visible)
    hits += _ODD_SCRIPT_RE.findall(visible)
    return hits


# «ты пробовала», «ты сама», «ты была права» — обращение к женщине на «ты».
_FEM_ADDRESS_RE = re.compile(
    r"\bты\s+(?:(?:уже|же|вообще|просто|не|ещё|еще|точно|тоже|правда|вот)\s+){0,2}"
    r"(?:сама\b|[а-яё]{2,}(?:ла|лась)\b)",
    re.IGNORECASE,
)


def feminine_address(text: str) -> List[str]:
    return [m.group(0) for m in _FEM_ADDRESS_RE.finditer(_visible_text(text))]


def masculine_self_reference(text: str) -> List[str]:
    visible = _visible_text(text)
    hits = [m.group(0) for m in _MASC_SELF_RE.finditer(visible)]
    hits += [m.group(0) for m in _MASC_IRREGULAR_RE.finditer(visible)]
    hits += [m.group(0) for m in _MASC_SAM_RE.finditer(visible)]
    return hits


# -------------------------------------------------------------- verdicts
def assess(text: str, *, persona_female: bool = True, addressee_male: bool = False) -> Verdict:
    """Полная оценка реплики. ok=False только при hard-нарушениях."""
    text = (text or "").strip()
    v = Verdict(ok=True)
    if not text:
        return v

    visible = _visible_text(text)
    meta_hit = bool(_META_RE.search(visible))
    lat = latin_ratio(text)
    latin_words = len(_LATIN_WORD_RE.findall(visible))

    if meta_hit:
        v.hard.append("meta_narration")
    if repetition_score(visible) >= 3:
        v.hard.append("repetition")
    # Длинный латинский текст с нумерованным разбором — рассуждение.
    if lat > 0.6 and latin_words >= 12 and _NUMBERED_EN_RE.search(visible):
        if "meta_narration" not in v.hard:
            v.hard.append("meta_narration")
    if lat > 0.6 and latin_words >= 8 and (meta_hit or repetition_score(visible) >= 2):
        v.hard.append("foreign_script")

    if addressee_male and feminine_address(text):
        # Говорит с ним, а обращается на «ты» в женском роде — значит, отвечает
        # сама себе («А ты пробовала без опроса…?» на скриншоте 00:47).
        v.soft.append("self_address")
    if garbled_words(text):
        v.soft.append("garbled_text")
    if persona_female and masculine_self_reference(text):
        v.soft.append("masculine_self")
    if 0 < len(stray_latin_words(text)) <= 3 and lat < 0.25:
        v.soft.append("mixed_language")

    v.ok = not v.hard
    return v


def is_hard_failure(text: str) -> bool:
    return not assess(text).ok


def corrective_hint(verdict: Verdict) -> str:
    """Короткая инструкция для повторной генерации — что именно исправить."""
    notes = []
    if "meta_narration" in verdict.hard or "foreign_script" in verdict.hard:
        notes.append("Прошлый вариант был рассуждением о задаче, а не репликой. "
                     "Напиши только саму живую реплику Марин, по-русски, без анализа и планов.")
    if "repetition" in verdict.hard:
        notes.append("Прошлый вариант зациклился на одной фразе. Скажи мысль один раз, коротко.")
    if "masculine_self" in verdict.soft:
        notes.append("Марин — девушка: о себе только в женском роде (сделала, написала, сама).")
    if "self_address" in verdict.soft:
        notes.append("Ты отвечаешь ЕМУ (он мужчина), а не себе: не обращайся на «ты» в женском роде "
                     "и не давай советов самой себе — говори от своего лица с ним.")
    if "garbled_text" in verdict.soft:
        notes.append("В прошлом варианте были испорченные слова (смесь алфавитов). Пиши обычными русскими словами.")
    if "mixed_language" in verdict.soft:
        notes.append("Без английских слов посреди русской фразы.")
    return " ".join(notes)


# ---------------------------------------------------------- marker repair
_MARKER_KINDS = r"(?:ACTION|READ|GOAL|AUTOGOAL|BELIEF|PERSON|POST|TUNE|STICKER|CUSTOM_EMOJI|MSG)"
# >>>READ:get_bio|<<<   — перевёрнутые скобки (виден на скриншоте)
_REVERSED_RE = re.compile(r">>>\s*(" + _MARKER_KINDS + r"\b[^<>]*?)\s*<<<", re.IGNORECASE)
# <<READ:x>> или <<<READ:x>> или <<READ:x>>> — не хватает угловых скобок
_SHORT_RE = re.compile(
    r"(?<!<)<{2,3}\s*(" + _MARKER_KINDS + r"\b[^<>]*?)\s*>{2,3}(?!>)", re.IGNORECASE
)
# [[READ:x]] / 【READ:x】
_BRACKET_RE = re.compile(r"\[\[\s*(" + _MARKER_KINDS + r":[^\[\]]*?)\s*\]\]", re.IGNORECASE)
# Остатки протокола, которые уже не восстановить
_PROTOCOL_JUNK_RE = re.compile(r">>>\s*<<<|<<<\s*>>>|(?:>>>|<<<)(?=\s|$)")


# <<<ACTION:send_selfie|{"chat": …}>>> — без поля «описание» (скриншот 10:03):
# обычный разбор ждёт тип|описание|данные, и такая команда уходила текстом.
_ACTION_TWO_FIELD_RE = re.compile(r"<<<\s*ACTION\s*:\s*(\w+)\s*\|\s*(\{[^|<>]*\})\s*>>>", re.DOTALL)
_ACTION_TITLES = {
    "send_selfie": "селфи", "send_voice_message": "голосовое", "send_sticker": "стикер",
    "send_dice": "бросок", "send_message": "сообщение", "create_poll": "опрос", "post_story": "история",
}


def normalize_markers(text: str) -> str:
    """Чинит искажённые служебные маркеры, чтобы они исполнились, а не
    утекли текстом: >>>READ:get_bio|<<< → <<<READ:get_bio|>>>,
    <<<ACTION:kind|{json}>>> → <<<ACTION:kind|описание|{json}>>>."""
    if not text or ("<<" not in text and ">>" not in text and "[[" not in text):
        return text
    text = _ACTION_TWO_FIELD_RE.sub(
        lambda m: f"<<<ACTION:{m.group(1)}|{_ACTION_TITLES.get(m.group(1), m.group(1))}|{m.group(2)}>>>", text)
    text = _REVERSED_RE.sub(lambda m: f"<<<{m.group(1).strip()}>>>", text)
    text = _BRACKET_RE.sub(lambda m: f"<<<{m.group(1).strip()}>>>", text)
    text = _SHORT_RE.sub(lambda m: f"<<<{m.group(1).strip()}>>>", text)
    return text


def strip_protocol_junk(text: str) -> str:
    """Последний рубеж: одиночные >>> / <<< не должны дойти до человека.
    Целые валидные маркеры (<<<STICKER:5>>> и т.п.) не трогаем — их ещё
    обработает отправка; чистим только текст МЕЖДУ ними."""
    if not text or (">>>" not in text and "<<<" not in text):
        return (text or "").strip()
    pieces = re.split(r"(<<<[^<>]*?>>>)", text)
    cleaned = [p if re.fullmatch(r"<<<[^<>]*?>>>", p) else _PROTOCOL_JUNK_RE.sub("", p) for p in pieces]
    return re.sub(r"[ \t]{2,}", " ", "".join(cleaned)).strip()
