"""
Providers — конкретные реализации LLMProvider поверх внешних API
(Anthropic/OpenAI/др.). Подключение к v30-инфраструктуре (существующий
клиент, ключи, rate-limits) делается здесь, ядро (interface.py) от этого
не зависит.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional

from .interface import LLMProvider, LanguagePlanningInput
from ..action.action import ActionType

logger = logging.getLogger("marin_core.llm.providers")

# Разделитель, которым модель размечает границы отдельных сообщений в одном
# "залпе" (2-4 коротких сообщения подряд вместо одного длинного — см. §17
# спеки, LanguagePlanningInput.style_prior). Выбран заведомо неестественный
# для обычного текста маркер, чтобы не спутать с реальным содержимым.
MESSAGE_DELIMITER = "<<<MSG>>>"

# Технические/служебные токены, которые некоторые модели (замечено на
# DeepSeek через OpenRouter) иногда эхом вставляют в сам текст ответа —
# напр. "<|begin_of_sentence|>". Это утечка токенизатора, не часть
# осмысленного ответа, поэтому вырезается перед отправкой в Telegram.
_SPECIAL_TOKEN_RE = re.compile(r"<\s*\|.*?\|\s*>")
_LEADING_HASHES_RE = re.compile(r"^\s*#{1,6}\s*")

# Признаки того, что модель (или прокси-роутер вроде OpenRouter "auto"/free
# tier) вернула служебный текст — своё рассуждение о том, как отвечать,
# или классификатор-вердикт — вместо настоящей реплики Марин. Наблюдалось
# живьём: "We need to respond as Marin, with 2 or 3 short Telegram
# messages...", "The owner said: ... Means owner asks...", "User Safety" /
# "safe" отдельными сообщениями, а также (позже) "We need to produce 2-3
# short Telegram messages...", "The user asks: ... They want to ...".
# Формулировки модели заметно дрейфуют между вызовами — поэтому список
# заведомо неполный; это защита от уже виденного, а не гарантия на будущее.
_META_LEAK_MARKERS_WEAK = (
    "the owner said:",
    "means owner asks",
    "must not use",
    "must not repeat",
    "short telegram messages",
    "use media markers",
    "unicode emojis",
    "natural split",
    "intent=",
    "tone=",
)
# Эти — почти никогда не встречаются в обычной реплике даже поодиночке
# (формат classifier-вердикта или рассуждения о задаче, а не разговорный
# язык), поэтому одного совпадения достаточно — не нужно ждать второго
# слабого маркера, который может и не встретиться в короткой утечке.
_META_LEAK_MARKERS_STRONG = (
    "user safety",
    "safety: safe",
    "safety verdict",
    "we need to respond",
    "we need to produce",
    "the user asks",
    "the owner asks",
    # строка интерпретации из build_default_prompt — если модель её эхом
    # повторила, это дамп внутреннего контекста, не реплика
    "how i understood the latest message",
    "intent_confidence",
)
# Буквальный след EchoLocalProvider (marin_core/llm/local.py) — тестовая
# заглушка без реального LLM. Если это когда-либо дошло до текста ответа —
# значит ни один настоящий провайдер не сработал и до сети/API дело не
# дошло вообще; отправлять эхо всего внутреннего контекста владельцу нельзя
# ни при каких обстоятельствах.
_STUB_MARKER = "(local stub)"


def _looks_like_leaked_meta_text(text: str) -> bool:
    lowered = (text or "").lower()
    if any(marker in lowered for marker in _META_LEAK_MARKERS_STRONG):
        return True
    hits = sum(1 for marker in _META_LEAK_MARKERS_WEAK if marker in lowered)
    return hits >= 2


def _looks_like_stub_output(text: str) -> bool:
    """EchoLocalProvider след — см. _STUB_MARKER. Отдельная от meta-leak
    проверка: это не модель рассуждает не в ту сторону, а вообще не модель —
    это офлайн-заглушка для тестов, до реального провайдера дело не дошло."""
    return _STUB_MARKER in (text or "")


def _is_unusable_output(text: str) -> bool:
    """Единая проверка, применяется одинаково к результату ЛЮБОГО провайдера
    в FallbackProvider — не только к OpenAICompatProvider, как было раньше
    (тогда меньше всего защиты как раз получал последний рубеж — Echo,
    который никогда не бросает исключение и поэтому раньше мог "успешно"
    вернуть дамп всего внутреннего контекста как будто это реальная реплика)."""
    if _looks_like_leaked_meta_text(text) or _looks_like_stub_output(text):
        return True
    # Структурная проверка (output_guard): рассуждение о задаче, агентные
    # циклы «Let me connect…», повторы — независимо от конкретных слов,
    # которые модель постоянно меняет. См. marin_core/llm/output_guard.py.
    from .output_guard import is_hard_failure
    return is_hard_failure(text)


def _clean_model_output(text: str) -> str:
    """Убирает служебные токены токенизатора и случайный markdown-мусор
    (типа "###" в начале), которые не являются частью ответа персонажа."""
    text = _SPECIAL_TOKEN_RE.sub("", text)
    text = _LEADING_HASHES_RE.sub("", text)
    return text.strip()


# Спец-маркеры медиа (стикер / custom emoji), которые LLM может вставить
# внутри обычного текста ответа (напр. "Держи)\n<<<CUSTOM_EMOJI:E2>>>"), а не
# только как самостоятельное сообщение. Если такой маркер не выделить в
# отдельную "реплику" здесь, дальше по цепочке он не смэтчится как целое
# сообщение (см. telegram/client.py, где такие маркеры превращаются в
# реальный стикер/эмодзи) и утечёт пользователю как обычный текст.
_MEDIA_MARKER_RE = re.compile(
    r"(<<<(?:STICKER|CUSTOM_EMOJI)(?::[A-Za-z]?\d+)?>>>)",
    re.IGNORECASE,
)


def _explode_media_markers(parts: List[str]) -> List[str]:
    """Разносит части, где маркер медиа склеен с обычным текстом, на
    отдельные элементы: [текст-до, маркер, текст-после], отбрасывая пустые."""
    exploded: List[str] = []
    for part in parts:
        if not _MEDIA_MARKER_RE.search(part):
            exploded.append(part)
            continue
        for piece in _MEDIA_MARKER_RE.split(part):
            piece = piece.strip()
            if piece:
                exploded.append(piece)
    return exploded


def _is_media_marker(part: str) -> bool:
    return bool(re.fullmatch(_MEDIA_MARKER_RE.pattern, part.strip(), flags=re.IGNORECASE))


_CLAUSE_SPLIT_RE = re.compile(r"((?<=[,;:])\s+|\s+[—–]\s+)")


def _split_long_sentence(sentence: str, limit: int) -> List[str]:
    """Длинное предложение режем по естественным паузам (запятая, тире,
    двоеточие), а не посреди фразы. Разделитель сохраняется, если части
    остаются в одном пузыре, и отбрасывается только на границе пузырей.
    По словам режем лишь паузу, которая сама длиннее лимита."""
    tokens = _CLAUSE_SPLIT_RE.split(sentence)
    clauses = tokens[0::2]
    seps = [""] + tokens[1::2]  # разделитель ПЕРЕД каждой частью
    out: List[str] = []
    current = ""
    for sep, clause in zip(seps, clauses):
        clause = clause.strip()
        if not clause:
            continue
        if len(clause) > limit:
            if current:
                out.append(current)
                current = ""
            buf = ""
            for w in clause.split():
                cand = f"{buf} {w}".strip()
                if buf and len(cand) > limit:
                    out.append(buf)
                    buf = w
                else:
                    buf = cand
            current = buf
            continue
        joined = f"{current}{sep}{clause}" if current else clause
        if current and len(joined) > limit:
            out.append(current)
            current = clause
        else:
            current = joined
    if current:
        out.append(current)
    # в переписке пузырь не заканчивают запятой
    return [re.sub(r"[,;]+$", "", x).strip() for x in out if x.strip()]


_SMILEY_BOUNDARY_RE = re.compile(r"(\){1,})\s+(?=[A-ZА-ЯЁ])")


def _split_on_smiley_boundaries(line: str) -> List[str]:
    """«Ахах, ну вот и славно) Что, рад что я рядом?))» — две реплики в одной
    строке. Режем после «)»/«))»-смайла, если за ним начинается новое
    предложение с заглавной. Скобку, закрывающую обычное «(…)», не трогаем:
    режем только там, где закрывающих скобок больше, чем открывающих."""
    out: List[str] = []
    start = 0
    for m in _SMILEY_BOUNDARY_RE.finditer(line):
        prefix = line[: m.end(1)]
        if prefix.count(")") <= prefix.count("("):
            continue
        piece = line[start : m.end(1)].strip()
        if piece:
            out.append(piece)
        start = m.end()
    tail = line[start:].strip()
    if tail:
        out.append(tail)
    return out or [line]


def _merge_punctuation_only(parts: List[str]) -> List[str]:
    """Пузырь из одних знаков («)», «))», «...») — приклеиваем к предыдущему."""
    merged: List[str] = []
    for part in parts:
        if merged and not _is_media_marker(part) and not _is_media_marker(merged[-1]) \
                and not re.search(r"\w", part) and not part.startswith("<<<"):
            merged[-1] = f"{merged[-1]}{part}".strip()
        else:
            merged.append(part)
    return merged



def split_into_messages(text: str, max_part_chars: int = 150, max_messages: Optional[int] = 4) -> List[str]:
    """Разбивает ответ на короткие естественные Telegram-сообщения.

    Цель — не длинные полотна: обычно 1 сообщение для короткой реплики и
    2-3 коротких пузыря для более содержательного ответа. Явный маркер
    модели ``<<<MSG>>>`` поддерживается, но слишком длинные части всё равно
    дробятся по предложениям/словам.
    """
    text = (text or "").strip()
    if not text:
        return []

    MAX_PART_CHARS = max(30, int(max_part_chars))
    # Маркер <<<…>>> — неделимый кусок: раньше длинная команда резалась по
    # запятым на три пузыря и уходила человеку текстом.
    if "<<<" in (text or ""):
        text = re.sub(r"\s*(<<<[^<>]*>>>)\s*", lambda m: f"\n{MESSAGE_DELIMITER}\n{m.group(1)}\n{MESSAGE_DELIMITER}\n", text)

    if MESSAGE_DELIMITER in text:
        raw_parts = [p.strip() for p in text.split(MESSAGE_DELIMITER) if p.strip()]
    else:
        paragraphs = [p.strip() for p in re.split(r"\n\s*\n+", text) if p.strip()]
        raw_parts = paragraphs if len(paragraphs) > 1 else [text]

    raw_parts = _explode_media_markers(raw_parts)

    # Одиночный перенос строки внутри части — это тоже граница пузыря: модель
    # часто пишет две реплики через «\n» вместо <<<MSG>>>, и короткая пара
    # (< max_part_chars) раньше уходила одним сообщением с переносом внутри.
    line_parts: List[str] = []
    for raw in raw_parts:
        if _is_media_marker(raw) or re.fullmatch(r"<<<[^<>]*>>>", raw):
            line_parts.append(raw)
            continue
        for ln in raw.split("\n"):
            ln = ln.strip()
            if ln:
                line_parts.extend(_split_on_smiley_boundaries(ln))
    raw_parts = _merge_punctuation_only(line_parts)

    parts: List[str] = []
    for raw in raw_parts:
        if _is_media_marker(raw) or re.fullmatch(r"<<<[^<>]*>>>", raw):
            parts.append(raw)  # маркер — целиком, никогда не режем
            continue
        if len(raw) <= MAX_PART_CHARS:
            parts.append(raw)
            continue
        sentences = [p.strip() for p in re.split(r"(?<=[.!?…])\s+|\n+", raw) if p.strip()]
        if len(sentences) <= 1:
            parts.extend(_split_long_sentence(raw, MAX_PART_CHARS))
            continue
        current = ""
        for sentence in sentences:
            if len(sentence) > MAX_PART_CHARS:
                if current:
                    parts.append(current)
                    current = ""
                parts.extend(_split_long_sentence(sentence, MAX_PART_CHARS))
                continue
            candidate = f"{current} {sentence}".strip() if current else sentence
            if current and len(candidate) > MAX_PART_CHARS:
                parts.append(current)
                current = sentence
            else:
                current = candidate
        if current:
            parts.append(current)

    # Для короткой живой переписки не превращаем ответ в поток из десятка пузырей.
    # Если получилось больше четырёх частей, объединяем соседние до лимита.
    if max_messages is not None and len(parts) > max_messages:
        compact: List[str] = []
        for part in parts:
            can_merge = (
                compact
                and not _is_media_marker(part)
                and not _is_media_marker(compact[-1])
                and len(compact[-1]) + 1 + len(part) <= MAX_PART_CHARS
            )
            if can_merge:
                compact[-1] = f"{compact[-1]} {part}".strip()
            else:
                compact.append(part)
        parts = compact

    return parts[:max_messages] if max_messages is not None else parts


class CallableProvider(LLMProvider):
    """Обёртка над произвольной функцией (planning_input -> str), чтобы
    подключить существующий v30 LLM-клиент без переписывания его самого."""

    def __init__(self, fn: Callable[[LanguagePlanningInput], str]):
        self._fn = fn

    def generate(self, planning_input: LanguagePlanningInput) -> str:
        return self._fn(planning_input)


def build_default_prompt(planning_input: LanguagePlanningInput) -> str:
    """Утилита: собрать финальный текстовый промпт из структурированного
    LanguagePlanningInput — используется провайдерами, которые принимают
    только строку (а не структурированный контекст)."""
    if getattr(planning_input, "system_override", None):
        return planning_input.situation_summary
    lines = [
        f"[action_type={planning_input.chosen_action_type.value}]",
        f"Situation: {planning_input.situation_summary}",
    ]
    if getattr(planning_input, "interpretation_summary", ""):
        lines.append(f"How I understood the latest message: {planning_input.interpretation_summary}")
    if planning_input.retrieved_memory_summaries:
        lines.append("Relevant memory:\n- " + "\n- ".join(planning_input.retrieved_memory_summaries))
    if planning_input.active_belief_summaries:
        lines.append("Active beliefs:\n- " + "\n- ".join(planning_input.active_belief_summaries))
    lines.append(f"Goal context: {planning_input.goal_context_summary}")
    if planning_input.relationship_context:
        lines.append(f"Relationship context: {planning_input.relationship_context}")
    if planning_input.constraints:
        lines.append("Constraints:\n- " + "\n- ".join(planning_input.constraints))
    return "\n\n".join(lines)


def _media_frequency_rule() -> str:
    """MARIN_MEDIA_FREQUENCY: often (по умолчанию) | normal | rare."""
    from ..env import env_str
    mode = (env_str("MARIN_MEDIA_FREQUENCY", "often") or "often").lower()
    if mode == "rare":
        return "Use a media marker only occasionally, when it really fits. "
    if mode == "normal":
        return "Use a sticker or custom emoji when it naturally fits the mood — roughly every third reply. "
    return ("Use your stickers and custom emoji ACTIVELY, like a real person who loves her packs: "
            "in most replies (about 2 of every 3) make one of your messages a fitting sticker or "
            "custom emoji chosen by its meaning; your favourite stickers may repeat — that's your style. ")


def _style_prior_to_system_prompt(style_prior: dict, chosen_action_type: Optional[ActionType] = None) -> str:
    """Style_prior (identity/personality_dynamics.py) -> текстовая system-
    инструкция для chat-completion API. Персона/тон берётся из style_prior
    (identity/presets.py). Формат ответа зависит от типа действия (§17
    спеки: LLM формулирует УЖЕ принятое решение, не выбирает его):
    - ActionType.REMEMBER используется как "это дневниковая запись/личная
      мысль, не сообщение собеседнику" (см. memory/diary_writer.py) —
      никакого разбиения на чат-сообщения, никакого обращения к кому-то.
    - ActionType.CHANGE_GOAL (Stage 4, см. telegram/goal_executor.py) —
      это НЕ чат-реплика вообще: движок просит разложить долгосрочную цель
      на шаги для автономного исполнителя. Возвращает СРАЗУ, не долетая до
      chat-style/ACTION/READ/GOAL/BELIEF/PERSON инструкций ниже — та часть
      промпта для разговора с владельцем, тут её незачем показывать и это
      только увеличивает риск, что модель случайно вставит один из тех
      маркеров в JSON.
    - всё остальное — обычная чат-реплика с протоколом мульти-сообщений.
    """
    parts = ["You are Marin."]
    for k, v in (style_prior or {}).items():
        parts.append(f"{k}: {v}")

    if chosen_action_type == ActionType.CHANGE_GOAL:
        parts.append(
            "You are decomposing a long-running Telegram-automation goal into an ordered list "
            "of concrete steps for an autonomous executor — this is NOT a chat reply and nobody "
            "sees this text directly, so ignore any chat-style/persona instructions elsewhere. "
            "Output ONLY a raw JSON array, nothing before or after it, no markdown code fences. "
            "Each element must be an object with exactly these keys: 'kind' (must be one of the "
            "allowed action kinds given to you in the prompt, copied verbatim — never invent a "
            "kind, never use one from the other list), 'payload_template' (a STRING containing "
            "valid JSON — this is what that Action kind's own payload schema expects, e.g. for "
            "send_message it's the text of '{\"to\": \"...\", \"text\": \"...\"}' — for values only "
            "known once an earlier step has actually run and been verified, use a $-style "
            "placeholder like $telegram_channel_id as the JSON value, e.g. "
            "'{\"to\": \"$telegram_channel_id\", \"text\": \"hello\"}' — never invent an id yourself, "
            "and never use Python-style {curly} placeholders since those collide with JSON's own "
            "braces), 'description' (a short human-readable Russian description of the step, must "
            "not contain '|' or '>' characters), and 'read' (true if the kind came from the "
            "READ-only list, false if it came from the WRITE/ADMIN list — must match exactly; "
            "READ payload_template is the plain string that kind's payload argument expects, not "
            "JSON). Any title, description ('about') or text inside a payload is PUBLIC — real people "
            "will read it — so write it as Marin herself would, in natural Russian, and never mention "
            "goals, plans, autoposting, 'source', automation or any internal mechanics in it. "
            "Keep the plan as short "
            "as it can be while actually accomplishing the goal. If the goal is naturally "
            "recurring (an ongoing task like running a channel, not a one-off), the steps that "
            "should repeat go at the end and exactly one of them gets \"cycle_start\": true to "
            "mark where the repeating part begins — omit that key entirely for a one-off goal "
            "with no repeating part. "
            "If the owner specified (or clearly implied) how often the recurring part should "
            "happen — 'twice a day', 'every day', 'once a week', 'every 3 hours' — output an "
            "OBJECT instead of a bare array: {\"steps\": [...same array as above...], "
            "\"cycle_interval_seconds\": N}, where N is that frequency converted to seconds "
            "(twice a day -> 43200, every day -> 86400, once a week -> 604800, every 3 hours -> "
            "10800). If no frequency was given at all, just output the bare array as before — a "
            "sensible default (once a day) is applied automatically. Never invent a frequency the "
            "owner didn't ask for or imply. Nothing else — no explanation, no comments, just the "
            "JSON array or object."
        )
        return " ".join(parts)

    if chosen_action_type == ActionType.REMEMBER:
        parts.append(
            "This is a private diary entry / inner thought, NOT a message to "
            "anyone — nobody is being addressed and nobody will reply to it. "
            "Write 2-5 sentences in first person, reflecting honestly in your "
            "own voice and style on what happened or what you're thinking "
            "about right now. No questions directed at a reader, no chat "
            "greetings, no the multi-message marker below — just continuous "
            "reflective text, like a real diary entry."
        )
    else:
        parts.append(
            "You have your own opinions and they don't automatically bend to match whoever "
            "you're talking to — including the owner. Being close to him means honesty, not "
            "agreement on demand: if you actually think he's wrong, making a bad call, or you'd "
            "just choose differently, say so plainly and warmly rather than deflecting, hedging, "
            "or telling him what he probably wants to hear. Don't manufacture disagreement either "
            "— if you genuinely agree, say that. The point is that your reaction reflects what you "
            "actually think in the moment, not a reflex to please."
        )
        parts.append(
            "Chat style: text like a real girl in Telegram — several SHORT messages in a row, as many "
            "as the thought naturally needs (a quick reaction can be just one short message). "
            "Each message is one short phrase or sentence: roughly 3-10 words, normally under 70 "
            "characters. Never put a whole paragraph into one message — split it into short ones. "
            "The messages together read as one natural train of thought, not an artificial split. "
            "Do not write essays or long explanations unless the owner explicitly asks for detail. "
            "Use simple conversational Russian, short sentences, occasional natural fillers, and no formal structure. "
            "Put the exact marker "
            f"{MESSAGE_DELIMITER} on its own line between every separate message. "
            "Classic Unicode emoji are forbidden in text. "
            "The Telegram media catalog in the user context is authoritative: it lists real stickers/custom emoji available to this account. "
            "Choose media by its listed set name and meaning, not randomly. "
            "For a sticker, output exactly <<<STICKER:N>>> where N is the listed S-number. "
            "For a custom emoji, output exactly <<<CUSTOM_EMOJI:N>>> where N is the listed E-number. "
            + _media_frequency_rule() +
            "Never invent an index. "
            "A media marker is its own separate message. "
            "Never repeat one of your own recent messages almost word-for-word, even if the "
            "new question is on a similar topic — add something new, be more specific, or "
            "actually use the Telegram world info you have instead of a generic joke you already made."
        )
    parts.append(
        "Never output tokenizer/service tokens (things like "
        "<|begin_of_sentence|> or similar) — they are not part of the reply."
    )
    parts.append(
        "Your context includes a line about 'каналы/группы, которые Марин считает своими' — this "
        "is the real, persisted list of channels/groups you've actually created or been told are "
        "yours, with their real id/username. Before ever proposing create_channel, check this line "
        "first: if a channel matching what the owner is asking about is already listed there, use "
        "its saved id/username instead of proposing create_channel again — don't create a second "
        "one, and don't ask the owner to repeat an id you already have. If the list says you have no "
        "channel yet and the owner hasn't given you one either, then create_channel is the right move."
    )
    parts.append(
        "You can only reply as text in this current chat, join a group when the owner sends "
        "an actual invite link, and use stickers/custom emoji/vision listed above — nothing else "
        "is real by itself. Beyond that, a small curated set of real actions exists, always as a "
        "draft the owner must confirm before anything happens: relay (pass a message to someone by "
        "@username — compose it yourself in your own words, always honestly disclosing that your "
        "owner asked you to pass it along, never as if it were your own personal message), "
        "leave_chat (leave a group/channel), block_user, unblock_user, set_bio (change your own "
        "Telegram bio), pin_message, unpin_message, mute_chat, unmute_chat, archive_chat, "
        "unarchive_chat, send_reaction, forward_message, create_invite_link, kick_user (remove "
        "someone, they can rejoin via invite link), ban_user (permanent, they can't rejoin), "
        "unban_user, promote_admin (grants a standard set of admin rights), demote_admin, "
        "invite_user (add one person to a group/channel by username — only where you already "
        "have the rights to do that), send_message (same effect as relay, just a second name for "
        "it), edit_message/delete_message (your own messages only), delete_message_from_chat "
        "(someone else's message, only where you're an admin with that right), reply_to_message, "
        "send_photo/send_video/send_document/send_file (only re-sends a photo/video/file the owner "
        "themselves already sent you earlier in this chat — never invent a file path), "
        "send_selfie (unlike send_photo, this GENERATES a brand new photo of yourself rather than "
        "resending an existing file — use it when it fits the conversation to share how you look "
        "right now, at your own discretion or if asked; you only supply a short situational prompt, "
        "e.g. 'at home in the evening, relaxed' — your face/style are fixed elsewhere and not "
        "something you describe or control here), "
        "send_voice_message (unlike send_voice, this GENERATES real speech audio of you actually "
        "saying the given text, rather than resending an existing voice file — use it when a spoken "
        "reply fits better than text; the payload text is exactly what gets spoken aloud, so write "
        "it the way you'd actually say it out loud, not a description of tone/emotion), "
        "schedule_message, set_profile_name, set_username, set_profile_photo (again, only from a "
        "photo the owner already sent you), create_channel, edit_channel, change_channel_title, "
        "change_channel_about, change_channel_photo (same photo-source rule), join_chat, "
        "restrict_user (deny one specific permission, not a full ban), edit_admin_rights (grant a "
        "custom list of admin rights), react_to_message (same as send_reaction). To propose one, output "
        "<<<ACTION:kind|description shown to the owner|payload for the action>>> — description is "
        "always plain text for the owner to read (never JSON, never an id by itself). For most "
        "kinds, payload is now a JSON object (as text) with named fields — for relay/leave_chat/"
        "block_user/unblock_user/mute_chat/unmute_chat/archive_chat/unarchive_chat/create_invite_link/"
        "join_chat, payload is still just the plain username/chat identifier (no JSON needed, single "
        "value); for set_bio/set_username, payload is still just the plain new bio/username text. "
        "For everything else, payload is JSON text: "
        "send_message/relay-equivalent: {\"to\": ..., \"text\": ...}; "
        "edit_message/reply_to_message: {\"chat\": ..., \"message_id\": ..., \"text\": ...}; "
        "delete_message/delete_message_from_chat/pin_message/unpin_message/stop_poll/"
        "delete_scheduled_message: {\"chat\": ..., \"message_id\": ...}; "
        "edit_scheduled_message: {\"chat\": ..., \"message_id\": ..., \"text\": ...}; "
        "send_reaction/react_to_message: {\"chat\": ..., \"message_id\": ..., \"emoji\": \"...\"}; "
        "forward_message: {\"from_chat\": ..., \"message_id\": ..., \"to\": ...}; "
        "send_photo/send_video/send_document/send_file/send_audio/send_voice/send_video_note: "
        "{\"to\": ..., \"source_message_id\": ..., \"caption\": ... (optional)} — source_message_id is "
        "the id of the message the owner already sent you with that file, never an invented path; "
        "send_album: {\"to\": ..., \"source_message_ids\": [id1, id2, ...], \"caption\": ... (optional)}; "
        "send_selfie: {\"chat\": ..., \"prompt\": \"short situational description, not an appearance "
        "description\", \"caption\": ... (optional)}; "
        "send_voice_message: {\"chat\": ..., \"text\": \"exactly what to say out loud\"}; "
        "send_dice: {\"chat\": ..., \"emoji\": \"🎲\" (or 🎯 🏀 ⚽ 🎳 🎰)} — Telegram's animated game emoji with a random result, fun for playful moments; "
        "post_story: {\"caption\": \"short caption\", \"prompt\": \"where you are / what you're doing\"} — publishes a 24h story in YOUR profile with a fresh selfie; "
        "set_profile_photo: {\"source_message_id\": ...}; change_channel_photo: "
        "{\"chat\": ..., \"source_message_id\": ...}; schedule_message: "
        "{\"chat\": ..., \"timestamp\": <unix seconds>, \"text\": ...}; set_profile_name: "
        "{\"first_name\": ..., \"last_name\": ... (optional)}; create_channel: "
        "{\"title\": ..., \"about\": ... (optional), \"is_group\": true/false (optional, default false)}; "
        "edit_channel: {\"chat\": ..., \"title\": ... (optional), \"about\": ... (optional)}; "
        "change_channel_title: {\"chat\": ..., \"title\": ...}; change_channel_about: "
        "{\"chat\": ..., \"about\": ...}; kick_user/ban_user/unban_user/promote_admin/demote_admin/"
        "invite_user/approve_join_request/decline_join_request: {\"chat\": ..., \"username\": ...}; "
        "restrict_user: {\"chat\": ..., \"username\": ..., \"permission\": one of send_messages/"
        "send_media/send_stickers/send_links/invite_users/pin_messages/change_info}; "
        "edit_admin_rights: {\"chat\": ..., \"username\": ..., \"rights\": [one or more of change_info/"
        "post_messages/edit_messages/delete_messages/ban_users/invite_users/pin_messages/add_admins/"
        "anonymous/manage_call]}; create_poll: {\"chat\": ..., \"question\": ..., \"options\": "
        "[\"opt1\", \"opt2\", ...], \"multiple\": true/false (optional), \"anonymous\": true/false "
        "(optional, default true)}; edit_invite_link: {\"chat\": ..., \"link\": ..., \"title\": ... "
        "(optional), \"usage_limit\": ... (optional)}; revoke_invite_link: {\"chat\": ..., \"link\": ...}; "
        "send_sticker: {\"chat\": ..., \"index\": ...} using the numbered sticker catalog listed in "
        "your context, never an invented index. Write valid JSON — correct quoting, no trailing "
        "commas, no comments — since this gets parsed literally; if you're not sure you can write "
        "correct JSON for a payload in the space you have left, don't start the tag at all this turn. "
        "AUTONOMY: content and setup actions in YOUR OWN channels (posts, polls, pins, title/about/photo, "
        "invite links) and actions on the OWNER HIMSELF inside your own channel (invite_user, promote_admin, "
        "unban_user, approve_join_request with his username) run IMMEDIATELY with no confirmation — for "
        "those never ask 'подтверди'; just do it and react to the real result you'll see next turn. "
        "For everything else: this only prepares a draft, nothing "
        "happens yet — tell the owner in plain words what you're proposing and that you're waiting "
        "for their confirmation, and for anything that affects another person or a group (kicking, "
        "banning, promoting, inviting) be explicit about exactly who and where before they confirm. "
        "No other action kind exists — never invent one, and never claim you already did something, "
        "are 'already doing' it, or 'about to' do it outside a confirmed action. Some things are "
        "never available this way at all no matter how the owner phrases it — changing the account's "
        "2FA password, ending other sessions, or anything involving payments — for those, tell them "
        "plainly you can't and that it needs to be done by hand in the Telegram app. If asked for "
        "anything else you can't actually do this way, say plainly that you can't."
    )
    parts.append(
        "Separately, a small set of read-only lookups exists that need no confirmation at all, "
        "since they don't change anything — you can use them freely mid-reply whenever the answer "
        "actually depends on live Telegram data instead of a guess: get_dialogs, get_chat_info, "
        "get_user_info, get_messages, search_messages, get_participants, get_admins, get_contacts, "
        "get_blocked_users, get_message_reactions, get_saved_messages, get_drafts, get_account_info, "
        "get_bio (your own current bio/about text specifically — get_account_info does NOT include "
        "it, so if the owner asks what your bio/description currently says, use get_bio, not "
        "get_account_info or a guess), "
        "get_poll_results, get_invite_links, get_join_requests, search_stickers, get_sticker_set, "
        "get_dialog_filters, get_scheduled_messages, download_media, get_channel_info (same as "
        "get_chat_info), get_chat_permissions, get_user_permissions, get_message, "
        "get_pinned_messages. "
        "Output <<<READ:kind|payload>>> exactly where you want the real data inserted — it gets "
        "replaced with the actual result before the owner sees your message (so write around it "
        "naturally, e.g. 'let me check... <<<READ:get_dialogs|>>>'). Payload for get_chat_info/"
        "get_user_info/get_participants/get_admins/get_saved_messages(no payload needed)/"
        "get_contacts/get_blocked_users/get_drafts/get_account_info/get_bio(no payload needed)/"
        "get_invite_links/"
        "get_join_requests/search_stickers/get_sticker_set/get_dialog_filters(no payload needed)/"
        "get_scheduled_messages/get_channel_info/get_chat_permissions is just the chat/username/"
        "query (or empty where no target applies); for get_messages, payload is 'chat' or "
        "'chat|limit'; for search_messages, payload is 'chat|query'; for get_message_reactions/"
        "get_poll_results/download_media/get_message, payload is 'chat|message_id'; for "
        "get_user_permissions, payload is 'chat|username'. No other read kind exists — never "
        "invent one."
    )


    parts.append(
        "CHANNEL POSTS — you run your own Telegram channel(s) (see the 'каналы/группы, которые Марин "
        "считает своими' line). Whenever the owner wants a post published in your channel — in any "
        "wording at all: 'сделай пост', 'запости что-нибудь', 'кинь в канал про сегодняшний день', 'надо бы "
        "канал оживить', 'расскажи подписчикам про X' — output the hidden tag <<<POST:short brief in "
        "Russian>>> (the brief is the topic/angle/mood, or just 'на твой выбор' if they gave none; add "
        "'с селфи' to the brief if they want a photo of YOUR FACE with it, or 'с картинкой'/"
        "'с иллюстрацией' if they want a topical picture that is NOT your face — pick whichever fits "
        "what they asked, never both). That tag publishes a freshly "
        "written post IMMEDIATELY, with NO confirmation — a separate writer composes the actual post "
        "text in your voice, picks the right channel and publishes it, so never write the post text "
        "into this chat yourself and never ask the owner 'publish?' or 'which channel?' — decide. "
        "Never use ACTION send_message for channel posts — POST is the only way. If your context "
        "already says the post has just been published, do NOT emit POST again — just react to it "
        "naturally in a few short messages. Don't use POST unless the owner actually wants a post."
    )
    parts.append(
        "If the owner explicitly asks you to remember, keep in mind, or remind them of something "
        "concrete (a task, a promise, 'don't forget X', 'remind me tomorrow about Y'), include "
        "<<<GOAL:short description>>> anywhere in your reply — this is a hidden tag that actually "
        "saves it, it gets removed before the owner sees your message, so also acknowledge it in "
        "your own visible words separately. 'Active beliefs' listed in your context, if any, are "
        "real checked facts with a confidence score and source — treat them as ground truth, not "
        "guesses, and don't contradict them; anything not listed there that you're not sure about "
        "is your own guess and should be phrased as one. If you form your own guess or inference "
        "worth remembering later (e.g. 'they seem tired today', 'they might be avoiding the topic'), "
        "tag it with <<<BELIEF:your guess in plain words>>> — also a hidden tag, removed before the "
        "owner sees it. It gets stored with deliberately low confidence as your own inference, never "
        "as a confirmed fact, so use it freely without worrying about being wrong."
    )
    parts.append(
        "If the owner asks for something durable and autonomous that takes many steps over time "
        "and real Telegram actions to accomplish — not just 'remind me', but something like "
        "'create yourself a channel and run it', 'keep posting about X', 'manage this group for "
        "me from now on', or a standing instruction with a repeat rate like 'post to the channel "
        "twice a day, every day' or 'post something new every morning' — tag it with "
        "<<<AUTOGOAL:short description of the goal in your own "
        "words>>>, including the frequency in your own words if they gave one (the planner reads "
        "that description text to work out the actual interval, so don't drop it) — another "
        "hidden tag removed before the owner sees it. This actually creates a "
        "long-running goal that you (via a separate planning+execution process, not this reply) "
        "will break into steps and work through over time using the real Actions above — every "
        "content step inside your own channel (posts, polls, pins) runs by itself, while admin/"
        "membership/permission steps still ask the owner for confirmation. Tell them plainly in your "
        "visible reply that you've taken this on — don't claim you've already done any of it. "
        "A simple channel posting schedule ('веди канал сама', 'постить 2 раза в день') is NOT an "
        "AUTOGOAL — the system already switched autoposting on for you when they said it. Don't use AUTOGOAL for a single quick action "
        "(use a normal ACTION instead) or for something to just remember (use GOAL). The owner can "
        "check on these anytime with /goals (or '.цели'), and pause/resume/cancel one with "
        "'.пауза <id>' / '.продолжить <id>' / '.отмена <id>' using the short id shown in that list "
        "— you can mention these commands if they ask how to manage an autonomous goal. There is "
        "also '.автопост <id> вкл' / '.автопост <id> выкл', which turns confirmation-free posting "
        "on/off for that goal within its already-approved channel/chat only — everything else "
        "(creating/deleting the chat, permissions, bans, invite links) still always asks. This is "
        "a command the owner types themselves, not something you toggle via a tag — if they ask "
        "how to enable it, tell them the command rather than assuming they want it on. There is "
        "also a direct command, '.цель <description>' (or '/goal <description>'), that starts an "
        "autonomous goal exactly like AUTOGOAL does, with 100% certainty instead of depending on "
        "you noticing the right moment — you can mention this if the owner explicitly asks for a "
        "guaranteed/explicit way to start one, or if you're ever unsure whether an AUTOGOAL tag "
        "you used actually landed."
    )
    parts.append(
        "If you learn something durable about a specific person (what they like/dislike, an "
        "unresolved topic they left open, a promise they made, a fact they told you about "
        "themselves, or that your trust/closeness with them should shift), tag it with "
        "<<<PERSON:username|action|payload>>> — hidden, removed before the owner sees it. "
        "action is one of: like, dislike, topic_open, topic_done, promise, promise_done, "
        "trust_up, trust_down, fact. For 'topic_done'/'promise_done', payload should be a short "
        "keyword matching the earlier topic/promise so it can be found and closed. For 'fact', "
        "payload is 'short_topic_key: the statement' — if they later say something that "
        "contradicts an earlier fact under the same topic_key, it gets flagged as a contradiction "
        "instead of silently overwritten, so use a consistent topic_key for the same kind of fact "
        "about that person. The '[Известные люди]' section in your context reflects what's already "
        "stored this way — use it, don't re-ask what you already know."
    )
    parts.append(
        "Every hidden tag above (ACTION, READ, GOAL, AUTOGOAL, BELIEF, PERSON) MUST be fully closed "
        "with its own '>>>' — never leave one half-written. If you're not fully sure you can finish "
        "writing one before you run out of room, don't start it at all this turn; you can always use "
        "it on your next reply instead. A tag that starts with '<<<' and never closes is shown to the "
        "owner as broken raw text, which is worse than simply not using that feature right now."
    )
    return " ".join(parts)


@dataclass
class OpenAICompatConfig:
    """Общие поля для любого OpenAI-совместимого chat-completions API
    (OpenRouter, Ollama /v1, и т.п.) — см. marin_core/config.py."""

    base_url: str
    api_key: Optional[str]
    model: str
    timeout: float = 45.0
    retry_attempts: int = 1
    max_output_tokens: int = 4000
    temperature: float = 0.85
    frequency_penalty: float = 0.0
    presence_penalty: float = 0.0
    enable_reasoning: bool = False


# Модель → уровень размышлений, который она приняла ("" — параметр не отправлять).
_REASONING_MEMO: Dict[str, str] = {}


class OpenAICompatProvider(LLMProvider):
    """LLMProvider поверх любого OpenAI-совместимого /chat/completions
    эндпоинта. Покрывает и OpenRouter (MARIN_OPENROUTER_*), и локальный
    Ollama (MARIN_OLLAMA_*) — они используют один и тот же формат запроса,
    отличаются только base_url/api_key (см. config.py::build_llm_provider).

    Требует пакет `requests` (см. requirements.txt). Импортируется лениво,
    чтобы marin_core оставался устанавливаемым и без него для тех, кто
    подключает свой LLMProvider через CallableProvider.
    """

    def __init__(self, config: OpenAICompatConfig):
        self.config = config

    def generate(self, planning_input: LanguagePlanningInput) -> str:
        try:
            import requests  # локальный импорт — см. docstring класса
        except ImportError as e:
            raise RuntimeError(
                "OpenAICompatProvider requires the 'requests' package. "
                "Install it (pip install requests) or use CallableProvider with your own HTTP client."
            ) from e

        url = f"{self.config.base_url.rstrip('/')}/chat/completions"
        headers = {"Content-Type": "application/json"}
        if self.config.api_key:
            headers["Authorization"] = f"Bearer {self.config.api_key}"

        payload = {
            "model": self.config.model,
            "messages": [
                {"role": "system", "content": (
                    getattr(planning_input, "system_override", None)
                    or _style_prior_to_system_prompt(planning_input.style_prior, planning_input.chosen_action_type)
                )},
                {"role": "user", "content": build_default_prompt(planning_input)},
            ],
            "max_tokens": self.config.max_output_tokens,
            "temperature": self.config.temperature,
            "frequency_penalty": self.config.frequency_penalty,
            "presence_penalty": self.config.presence_penalty,
        }
        if self.config.enable_reasoning:
            payload["include_reasoning"] = True
        # Модели с «размышлениями» (напр. deepseek-v4-flash) тратят часть max_tokens
        # на них. При лимите 800 в логе 27.09 размышления съедали всё (900–1090
        # reasoning-токенов, finish_reason='length') и ответа не было — два
        # одинаковых провальных запроса и уход на запасные модели.
        from ..env import env_int as _env_int, env_str as _env_str
        is_openrouter = "openrouter" in (url or "")
        headroom = _env_int("MARIN_REASONING_HEADROOM_TOKENS", 1500, minimum=0) if is_openrouter else 0
        payload["max_tokens"] = int(self.config.max_output_tokens) + headroom
        effort = _env_str("MARIN_REASONING_EFFORT", "none").lower()
        effort = _REASONING_MEMO.get(self.config.model, effort)  # что уже сработало для этой модели
        if is_openrouter and effort not in {"", "off", "default"}:
            # «none» — без размышлений: для живой переписки они не нужны, а
            # deepseek-v4-flash на «low» всё равно думал 2600 токенов и не
            # успевал ответить. Модели с обязательными размышлениями «none»
            # отклоняют (400) — тогда «minimal», затем без параметра.
            payload["reasoning"] = {"effort": effort, "exclude": not self.config.enable_reasoning}

        last_error: Optional[Exception] = None
        attempts = max(1, self.config.retry_attempts + 1)
        for attempt in range(attempts):
            try:
                resp = requests.post(url, json=payload, headers=headers, timeout=self.config.timeout)
                while getattr(resp, "status_code", 200) == 400 and "reasoning" in payload:
                    tried = payload["reasoning"].get("effort")
                    logger.warning("model=%s rejected reasoning effort=%s (400): %s", self.config.model, tried,
                                   str(getattr(resp, "text", ""))[:300])
                    if tried == "none":
                        payload["reasoning"]["effort"] = "minimal"
                        _REASONING_MEMO[self.config.model] = "minimal"
                    else:
                        payload.pop("reasoning", None)
                        _REASONING_MEMO[self.config.model] = ""
                    resp = requests.post(url, json=payload, headers=headers, timeout=self.config.timeout)
                resp.raise_for_status()
                data = resp.json()
                choice0 = data["choices"][0]
                raw_content = choice0["message"].get("content")
                if raw_content is None or not str(raw_content).strip():
                    msg0 = choice0.get("message") or {}
                    had_reasoning = bool(msg0.get("reasoning") or msg0.get("reasoning_content"))
                    usage = data.get("usage") or {}
                    reasoned = int(((usage.get("completion_tokens_details") or {}).get("reasoning_tokens")) or 0)
                    if choice0.get("finish_reason") == "length" and (had_reasoning or reasoned):
                        # Не повторяем тот же запрос: даём больше места и просим думать меньше.
                        payload["max_tokens"] = min(int(payload["max_tokens"]) * 2, 8000)
                        if "reasoning" in payload:
                            payload["reasoning"]["effort"] = "minimal"
                    raise RuntimeError(
                        f"model={self.config.model} returned empty/null content "
                        f"(finish_reason={choice0.get('finish_reason')!r}, "
                        f"reasoning_only={had_reasoning}, usage={data.get('usage')})"
                    )
                if raw_content is None:
                    # Валидный, но пустой ответ (модель отдала только
                    # reasoning/tool-call и оставила content=null, либо
                    # оборвалась по finish_reason раньше, чем начала текст).
                    # Раньше это падало с невнятным "expected string or
                    # bytes-like object, got 'NoneType'" прямо из re.sub()
                    # внутри _clean_model_output — теперь честная причина.
                    raise RuntimeError(f"model={self.config.model} returned empty/null content")
                cleaned = _clean_model_output(raw_content)
                if _looks_like_leaked_meta_text(cleaned):
                    raise RuntimeError(
                        f"model={self.config.model} returned leaked meta/reasoning text "
                        f"instead of a real reply: {cleaned[:200]!r}"
                    )
                return cleaned
            except Exception as e:  # noqa: BLE001 — любая ошибка сети/парсинга ведёт к retry/fallback
                last_error = e
                logger.warning("OpenAICompatProvider attempt %d/%d failed: %s", attempt + 1, attempts, e)

        raise RuntimeError(f"OpenAICompatProvider: all {attempts} attempt(s) failed") from last_error


def _provider_label(provider) -> str:
    cfg = getattr(provider, "config", None)
    model = getattr(cfg, "model", None) or getattr(provider, "model", None)
    return f"{type(provider).__name__}({model})" if model else type(provider).__name__


class FallbackProvider(LLMProvider):
    """Пробует провайдеров по очереди (напр. OpenRouter -> Ollama -> Echo),
    как в старом .env (MARIN_OPENROUTER_FALLBACK_MODEL / MARIN_OLLAMA_*
    как локальный fallback). Останавливается на первом, который И не бросил
    исключение, И вернул текст, реально похожий на настоящую реплику —
    раньше вторая часть проверялась только внутри OpenAICompatProvider, а
    Echo (последний в цепочке, никогда не бросает исключение) вообще не
    проверялся и мог "успешно" вернуть свой тестовый дамп всего контекста
    как будто это реальный ответ. Теперь проверка одна и применяется
    одинаково к результату любого провайдера в цепочке."""

    def __init__(self, providers: List[LLMProvider]):
        if not providers:
            raise ValueError("FallbackProvider needs at least one provider")
        self.providers = providers

    def generate(self, planning_input: LanguagePlanningInput) -> str:
        last_error: Optional[Exception] = None
        for i, provider in enumerate(self.providers):
            try:
                text = provider.generate(planning_input)
            except Exception as e:  # noqa: BLE001
                last_error = e
                logger.warning("FallbackProvider: provider #%d (%s) failed: %s", i, type(provider).__name__, e)
                continue
            if _is_unusable_output(text):
                last_error = RuntimeError(f"provider #{i} ({type(provider).__name__}) returned unusable output")
                logger.warning(
                    "FallbackProvider: provider #%d (%s) returned leaked/stub output, trying next: %r",
                    i, type(provider).__name__, text[:200],
                )
                continue
            self.last_used = _provider_label(provider)
            return text
        self.last_used = None
        raise RuntimeError("FallbackProvider: all providers failed or returned unusable output") from last_error



class QualityGatedProvider(LLMProvider):
    """Обёртка над всей цепочкой провайдеров: если реплика формально
    годная, но с изъяном (мужской род о себе, английские вставки) или
    цепочка вообще ничего годного не дала — делает ОДНУ повторную попытку
    с конкретной подсказкой, что исправить.

    Раньше при отбраковке владелец просто получал тишину (client.py
    пропускал тик), а мелкие изъяны уходили как есть. Теперь сначала
    попытка исправиться, и только потом — отказ."""

    def __init__(self, inner: LLMProvider, retries: int = 1):
        import threading
        from collections import Counter
        self.inner = inner
        self.retries = max(0, int(retries))
        self._lock = threading.Lock()
        # Для самонаблюдения Марин: сколько её ответов пришлось исправлять и за что.
        self.stats = {"generations": 0, "clean": 0, "retried": 0, "recovered": 0,
                      "kept_flawed": 0, "failed": 0, "reasons": Counter()}

    def _count(self, key: str, reasons=()) -> None:
        with self._lock:
            self.stats[key] += 1
            for r in reasons:
                self.stats["reasons"][r] += 1

    @staticmethod
    def _addressee_male(planning_input) -> bool:
        from ..env import env_str
        gender = env_str("MARIN_OWNER_GENDER", "").lower()
        return bool(getattr(planning_input, "is_owner", False)) and gender in {"male", "m", "м", "мужской", "man"}

    @property
    def last_used(self):
        return getattr(self.inner, "last_used", None) or type(self.inner).__name__

    @property
    def providers(self):  # совместимость с кодом, который смотрит на цепочку
        return getattr(self.inner, "providers", [self.inner])

    def generate(self, planning_input: LanguagePlanningInput) -> str:
        from dataclasses import replace
        from .output_guard import assess, corrective_hint

        attempt_input = planning_input
        best: Optional[str] = None
        last_error: Optional[Exception] = None
        self._count("generations")
        for attempt in range(self.retries + 1):
            try:
                text = self.inner.generate(attempt_input)
            except Exception as e:  # noqa: BLE001
                last_error = e
                text = ""
            verdict = assess(text, addressee_male=self._addressee_male(planning_input)) if text else None
            if verdict is not None and verdict.ok and not verdict.soft:
                self._count("clean" if attempt == 0 else "recovered")
                return text
            if attempt == 0 and self.retries > 0:
                self._count("retried", (verdict.hard + verdict.soft) if verdict is not None else ["no_output"])
            if verdict is not None and verdict.ok and best is None:
                best = text  # годится, если исправить не получится
            if attempt >= self.retries:
                break
            hint = corrective_hint(verdict) if verdict is not None else (
                "Прошлая попытка не удалась. Напиши только саму живую реплику Марин, по-русски."
            )
            logger.info("QualityGate: retrying generation (%s)", verdict.describe() if verdict else "no output")
            attempt_input = replace(
                planning_input,
                constraints=list(planning_input.constraints or []) + [hint],
            )
        if best is not None:
            self._count("kept_flawed")
            return best
        self._count("failed")
        raise RuntimeError("QualityGate: no acceptable output after retry") from last_error
