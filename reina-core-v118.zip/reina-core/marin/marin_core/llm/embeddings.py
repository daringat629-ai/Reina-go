"""
Embeddings — замена _hash_embed на настоящий sentence-embedder (роадмап
"Real Embeddings", приоритет №1). Раньше единственная реализация e(x_t) была
детерминированным хэшем токенов (engine/cognitive_engine.py::_hash_embed) —
рабочая заглушка для холодного старта, но без реальной семантики: "кошка" и
"кот" получали несвязанные вектора.

Дизайн:

    text
     │
     ▼
    RawEmbedder (Ollama / OpenAI-compatible HTTP)   -> ℝ^native_dim
     │
     ▼
    ProjectingEmbedder (детерминированная random projection) -> ℝ^EMBED_DIM
     │
     ▼
    CachingEmbedder (LRU по тексту, не бить по сети на повторные фразы)
     │
     ▼
    FallbackEmbedder (сеть недоступна/ошибка -> HashEmbedder, никогда не роняет tick())

EMBED_DIM остаётся общим пространством с LatentState (см. state/latent_state.py
TOTAL_DIM) — это существующий инвариант всего ядра (retrieval, beliefs,
u_t в cycle.py), поэтому реальные эмбеддинги (обычно 384/768/1536-мерные)
проецируются вниз, а не меняют EMBED_DIM по всему ядру.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Protocol, runtime_checkable
import hashlib
import logging
import threading

from ..numeric import np
from ..state.latent_state import TOTAL_DIM

logger = logging.getLogger(__name__)

EMBED_DIM = TOTAL_DIM  # см. engine/cognitive_engine.py::EMBED_DIM — то же самое пространство


@runtime_checkable
class Embedder(Protocol):
    """str -> ℝ^EMBED_DIM, единичной (по возможности) длины. Тот же интерфейс,
    что раньше был у _DefaultEmbedder/_hash_embed — заменяем реализацию, не
    контракт, поэтому весь остальной код (situation.py, retrieval.py,
    beliefs.py) не меняется."""

    def embed(self, text: str) -> np.ndarray: ...


def hash_embed(text: str, dim: int = EMBED_DIM) -> np.ndarray:
    """Детерминированный псевдо-эмбеддинг без внешней модели — офлайн-фолбэк
    и тесты (было engine/cognitive_engine.py::_hash_embed, перенесено сюда
    как часть единой embeddings-подсистемы)."""
    vec = np.zeros(dim, dtype=np.float32)
    for token in text.lower().split():
        h = int(hashlib.sha256(token.encode("utf-8")).hexdigest(), 16)
        idx = h % dim
        sign = 1.0 if (h // dim) % 2 == 0 else -1.0
        vec[idx] += sign
    norm = np.linalg.norm(vec)
    return vec / norm if norm > 0 else vec


class HashEmbedder:
    """Обёртка над hash_embed под интерфейс Embedder — последний рубеж
    в FallbackEmbedder и дефолт для офлайн-режима/тестов (§18: холодный
    старт без внешних зависимостей должен работать)."""

    def __init__(self, dim: int = EMBED_DIM):
        self.dim = dim

    def embed(self, text: str) -> np.ndarray:
        return hash_embed(text, self.dim)


# --- random projection: native_dim -> EMBED_DIM ---------------------------

_PROJECTION_CACHE: Dict[tuple, np.ndarray] = {}
_PROJECTION_LOCK = threading.Lock()


def _projection_matrix(native_dim: int, target_dim: int, seed: int = 20260101) -> np.ndarray:
    """Фиксированная (детерминированная по seed) случайная матрица проекции
    native_dim -> target_dim, размером (target_dim, native_dim) — так матрицу
    можно применить как mat @ vec (поддержано и numeric.py::Matrix, и
    настоящим numpy) и получить вектор длины target_dim. По лемме
    Джонсона–Линденштрауса случайная проекция приблизительно сохраняет
    косинусные расстояния между векторами — гораздо лучше, чем обрезание до
    первых target_dim компонент (эмбеддинги моделей не отсортированы по
    важности координат). Матрица кэшируется по (native_dim, target_dim),
    чтобы не пересоздаваться на каждый вызов.

    Используем np.random.default_rng вместо np.random.RandomState: доступно
    и в marin_core/numeric.py (numpy-free shim для minimal/Alpine-сборок,
    см. его docstring), и в настоящем numpy, если он когда-нибудь заменит
    shim — единый вызов работает в обоих случаях."""
    key = (native_dim, target_dim, seed)
    with _PROJECTION_LOCK:
        cached = _PROJECTION_CACHE.get(key)
        if cached is not None:
            return cached
        rng = np.random.default_rng(seed)
        scale = 1.0 / float(np.sqrt(target_dim))
        mat = rng.normal(loc=0.0, scale=scale, size=(target_dim, native_dim))
        _PROJECTION_CACHE[key] = mat
        return mat


class ProjectingEmbedder:
    """Оборачивает "сырой" эмбеддер произвольной размерности (Ollama/OpenAI
    обычно отдают 384..1536) и проецирует результат в EMBED_DIM, чтобы он
    был совместим с LatentState/MemoryGraph/BeliefStore, которые везде
    предполагают один общий размер вектора."""

    def __init__(self, raw: "RawEmbedder", target_dim: int = EMBED_DIM):
        self.raw = raw
        self.target_dim = target_dim

    def embed(self, text: str) -> np.ndarray:
        vec = self.raw.embed_raw(text)
        vec = np.array(vec, dtype=np.float32)
        if vec.shape[0] == self.target_dim:
            projected = vec
        else:
            mat = _projection_matrix(vec.shape[0], self.target_dim)
            projected = mat @ vec  # (target_dim, native_dim) @ (native_dim,) -> (target_dim,)
        norm = np.linalg.norm(projected)
        return projected / norm if norm > 0 else projected


class CachingEmbedder:
    """LRU-подобный кэш по точному тексту поверх любого Embedder — реальные
    провайдеры это сетевой вызов, а одни и те же фразы (приветствия,
    короткие реплики, повторные ретраи) в чате встречаются часто. Не
    подменяет память/консолидацию — просто убирает лишние HTTP-запросы для
    идентичного текста в рамках процесса."""

    def __init__(self, inner: Embedder, max_size: int = 4096):
        self.inner = inner
        self.max_size = max_size
        self._cache: Dict[str, np.ndarray] = {}
        self._order: List[str] = []
        self._lock = threading.Lock()

    def embed(self, text: str) -> np.ndarray:
        key = text.strip()
        with self._lock:
            cached = self._cache.get(key)
            if cached is not None:
                return cached
        vec = self.inner.embed(text)
        with self._lock:
            if key not in self._cache and len(self._cache) >= self.max_size:
                oldest = self._order.pop(0)
                self._cache.pop(oldest, None)
            if key not in self._cache:
                self._order.append(key)
            self._cache[key] = vec
        return vec


class FallbackEmbedder:
    """Цепочка эмбеддеров в порядке приоритета (по аналогии с
    llm/providers.py::FallbackProvider): реальная модель -> ... -> HashEmbedder
    в конце, который никогда не бросает исключение. embed() вызывается в
    real-time tick() (situation.py), поэтому сетевая ошибка не должна ронять
    цикл — она просто деградирует до хэш-эмбеддинга для этого конкретного
    вызова."""

    def __init__(self, embedders: List[Embedder]):
        if not embedders:
            raise ValueError("FallbackEmbedder requires at least one embedder")
        self.embedders = embedders

    def embed(self, text: str) -> np.ndarray:
        last_error: Optional[Exception] = None
        for embedder in self.embedders:
            try:
                return embedder.embed(text)
            except Exception as e:  # noqa: BLE001 — любая ошибка -> следующий в цепочке
                last_error = e
                logger.warning("%s failed, falling back: %s", type(embedder).__name__, e)
        # Не должно случиться, т.к. последний элемент цепочки — HashEmbedder,
        # но на случай кастомной цепочки без него — явная ошибка лучше None.
        raise RuntimeError("FallbackEmbedder: all embedders failed") from last_error


# --- raw network embedders --------------------------------------------------


class RawEmbedder(Protocol):
    """Внутренний интерфейс "сырых" сетевых эмбеддеров — возвращают вектор
    родной размерности модели, ProjectingEmbedder приводит его к EMBED_DIM."""

    def embed_raw(self, text: str) -> np.ndarray: ...


@dataclass
class OllamaEmbeddingConfig:
    base_url: str = "http://127.0.0.1:11434"  # нативный Ollama API, БЕЗ /v1 (это не /chat/completions)
    model: str = "nomic-embed-text"
    timeout: float = 30.0
    retry_attempts: int = 1


class OllamaRawEmbedder:
    """POST {base_url}/api/embeddings — нативный (не OpenAI-совместимый)
    эндпоинт Ollama. Тот же локальный сервер, что уже используется как LLM
    fallback (config.py::MARIN_OLLAMA_*), поэтому не требует ни API-ключа,
    ни новой инфраструктуры — только модель эмбеддингов, стянутую заранее
    (напр. `ollama pull nomic-embed-text`)."""

    def __init__(self, config: OllamaEmbeddingConfig):
        self.config = config

    def embed_raw(self, text: str) -> np.ndarray:
        try:
            import requests
        except ImportError as e:
            raise RuntimeError(
                "OllamaRawEmbedder requires the 'requests' package. Install it (pip install requests)."
            ) from e

        url = f"{self.config.base_url.rstrip('/')}/api/embeddings"
        payload = {"model": self.config.model, "prompt": text}

        last_error: Optional[Exception] = None
        attempts = max(1, self.config.retry_attempts + 1)
        for attempt in range(attempts):
            try:
                resp = requests.post(url, json=payload, timeout=self.config.timeout)
                resp.raise_for_status()
                data = resp.json()
                embedding = data.get("embedding")
                if not embedding:
                    raise RuntimeError(f"Ollama embeddings returned empty result for model={self.config.model}")
                return np.array(embedding, dtype=np.float32)
            except Exception as e:  # noqa: BLE001
                last_error = e
                logger.warning("OllamaRawEmbedder attempt %d/%d failed: %s", attempt + 1, attempts, e)

        raise RuntimeError(f"OllamaRawEmbedder: all {attempts} attempt(s) failed") from last_error


@dataclass
class OpenAICompatEmbeddingConfig:
    base_url: str  # напр. https://api.openai.com/v1 или совместимый провайдер
    api_key: Optional[str]
    model: str = "text-embedding-3-small"
    timeout: float = 30.0
    retry_attempts: int = 1


class OpenAICompatRawEmbedder:
    """POST {base_url}/embeddings — стандартный OpenAI-совместимый эндпоинт
    эмбеддингов (OpenAI напрямую, либо любой совместимый прокси/провайдер,
    указанный через MARIN_EMBEDDING_BASE_URL)."""

    def __init__(self, config: OpenAICompatEmbeddingConfig):
        self.config = config

    def embed_raw(self, text: str) -> np.ndarray:
        try:
            import requests
        except ImportError as e:
            raise RuntimeError(
                "OpenAICompatRawEmbedder requires the 'requests' package. Install it (pip install requests)."
            ) from e

        url = f"{self.config.base_url.rstrip('/')}/embeddings"
        headers = {"Content-Type": "application/json"}
        if self.config.api_key:
            headers["Authorization"] = f"Bearer {self.config.api_key}"
        payload = {"model": self.config.model, "input": text}

        last_error: Optional[Exception] = None
        attempts = max(1, self.config.retry_attempts + 1)
        for attempt in range(attempts):
            try:
                resp = requests.post(url, json=payload, headers=headers, timeout=self.config.timeout)
                resp.raise_for_status()
                data = resp.json()
                embedding = data["data"][0]["embedding"]
                return np.array(embedding, dtype=np.float32)
            except Exception as e:  # noqa: BLE001
                last_error = e
                logger.warning("OpenAICompatRawEmbedder attempt %d/%d failed: %s", attempt + 1, attempts, e)

        raise RuntimeError(f"OpenAICompatRawEmbedder: all {attempts} attempt(s) failed") from last_error
