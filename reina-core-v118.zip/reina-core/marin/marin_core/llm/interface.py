"""
LLM Interface — §17 спеки. Вызывается ОДИН раз за тик, с уже собранным
контекстом. LLM не выбирает ActionType — это уже решено Decision Engine.
LLM отвечает за формулировку в рамках заданного действия и стиля.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from ..action.action import Action, ActionType
from ..action.validation import ActionValidator, ValidationResult


@dataclass
class LanguagePlanningInput:
    """§17."""

    situation_summary: str
    retrieved_memory_summaries: List[str]
    active_belief_summaries: List[str]
    chosen_action_type: ActionType
    goal_context_summary: str
    style_prior: Dict[str, Any] = field(default_factory=dict)
    constraints: List[str] = field(default_factory=list)  # identity invariants как текстовые ограничения
    relationship_context: str = ""  # напр. identity.owner_description, если собеседник — владелец
    # Task mode: если задано, провайдер использует ЭТОТ system prompt вместо
    # чат-протокола, а situation_summary отправляет как есть (без служебной
    # обвязки [action_type=...]). Нужен для не-чатовых генераций — пост в
    # канал, выбор канала и т.п. — чтобы не тащить туда маркеры/мульти-
    # сообщения из чатового промпта (см. telegram/channel_publisher.py).
    system_override: Optional[str] = None
    # Как ядро поняло реплику (InterpretationEngine.summary_for_llm): intent,
    # tone, topic, факты, неопределённости. Пусто — если интерпретации нет.
    interpretation_summary: str = ""
    # Разговор именно с владельцем (для фильтра качества: к кому она обращается).
    is_owner: bool = False


class LLMProvider:
    """Абстракция над конкретным провайдером (см. providers.py / local.py)."""

    def generate(self, planning_input: LanguagePlanningInput) -> str:
        raise NotImplementedError


class LanguagePlanner:
    """Оркестрирует вызов LLM + валидацию результата (§17, action_validation)."""

    def __init__(self, provider: LLMProvider, validator: Optional[ActionValidator] = None):
        self.provider = provider
        self.validator = validator or ActionValidator()

    def plan_and_generate(
        self, action: Action, planning_input: LanguagePlanningInput, is_owner: bool = False
    ) -> tuple[str, ValidationResult]:
        text = self.provider.generate(planning_input)
        result = self.validator.validate(action, generated_text=text, is_owner=is_owner)
        return text, result
