"""
Local provider — заглушка без сети, для юнит-тестов cognitive-цикла без
реального обращения к LLM API. Возвращает детерминированный текст на
основе chosen_action_type, чтобы engine/cycle.py можно было тестировать
end-to-end уже сейчас.
"""

from __future__ import annotations

from .interface import LLMProvider, LanguagePlanningInput


class EchoLocalProvider(LLMProvider):
    def generate(self, planning_input: LanguagePlanningInput) -> str:
        return f"[{planning_input.chosen_action_type.value}] (local stub) {planning_input.situation_summary}"
