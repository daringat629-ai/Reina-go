"""
Action validation — §17 спеки: ответ LLM проходит проверку на противоречие
Identity/Belief перед отправкой во внешний канал (Telegram и т.п.).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

from .action import Action


@dataclass
class ValidationResult:
    ok: bool
    violations: List[str]


class ActionValidator:
    """Точка расширения: подключает identity.invariants и belief-store с
    высокой confidence, чтобы отловить прямое противоречие перед отправкой.
    Референсная реализация — заглушка, возвращающая ok=True; реальные
    проверки добавляются по мере роста identity/belief модулей (§18 п.8)."""

    def __init__(self, identity_model=None, belief_store=None):
        self.identity_model = identity_model
        self.belief_store = belief_store

    def validate(self, action: Action, generated_text: Optional[str] = None, is_owner: bool = False) -> ValidationResult:
        violations: List[str] = []

        if self.identity_model is not None and generated_text:
            lowered = generated_text.lower()
            for invariant in getattr(self.identity_model, "invariants", []):
                if is_owner and not getattr(invariant, "applies_to_owner", True):
                    continue  # ограничение снято для владельца (см. identity/presets.py)
                forbidden = getattr(invariant, "forbidden_if_present", None)
                if forbidden and forbidden.lower() in lowered:
                    violations.append(f"violates identity invariant: {getattr(invariant, 'name', 'unnamed')}")

        return ValidationResult(ok=len(violations) == 0, violations=violations)
