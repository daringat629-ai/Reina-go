"""
Action Model — п.18 исходного документа. Действие Marin — не только текстовый
ответ. Decision Engine выбирает ActionType ДО обращения к LLM (§17 спеки);
LLM формулирует содержание уже внутри выбранного типа действия.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, Optional


class ActionType(str, Enum):
    ANSWER = "answer"
    ASK = "ask"
    CLARIFY = "clarify"
    WAIT = "wait"
    IGNORE = "ignore"
    REMEMBER = "remember"
    RETRIEVE = "retrieve"
    USE_TOOL = "use_tool"
    CHANGE_GOAL = "change_goal"
    UPDATE_BELIEF = "update_belief"
    UPDATE_RELATIONSHIP = "update_relationship"
    EXPLORE = "explore"
    # --- расширенный набор DecisionEngine (decision/candidates.py) ---
    FORGET = "forget"      # отозвать belief по просьбе собеседника
    SEARCH = "search"      # углублённый поиск по памяти/убеждениям перед ответом
    OBSERVE = "observe"    # молча принять к сведению (не адресовано Marin)
    DEFER = "defer"        # отложить ответ
    ACT = "act"            # просьба о действии в мире (исполняет инфраструктура)


# Действия, которые производят реплику собеседнику.
SPEAKING_ACTIONS = frozenset({ActionType.ANSWER, ActionType.ASK, ActionType.CLARIFY, ActionType.EXPLORE})
# Действия без реплики — допустимы как основное, только если к Marin не обращались.
SILENT_ACTIONS = frozenset({ActionType.IGNORE, ActionType.OBSERVE, ActionType.DEFER, ActionType.WAIT})
# Побочные действия, выполняемые ВМЕСТЕ с основным (ActionExecutor).
SIDE_EFFECT_ACTIONS = frozenset({ActionType.REMEMBER, ActionType.FORGET, ActionType.SEARCH, ActionType.ACT})


@dataclass
class Action:
    type: ActionType
    payload: Dict[str, Any] = field(default_factory=dict)  # напр. текст ответа, целевой belief_id и т.п.
    target_channel_id: Optional[str] = None
    target_actor_id: Optional[str] = None
