"""
ActionExecutor — исполняет побочные действия, выбранные DecisionEngine
(REMEMBER / FORGET / SEARCH / ACT). Основное "говорящее" действие
исполняет LanguagePlanner; реальные Telegram-действия — инфраструктура
(ACT здесь только помечается, ядро про Telegram не знает).
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Callable, List, Optional

from .action import Action, ActionType
from ..belief.beliefs import SourceType


@dataclass
class ExecutionResult:
    action: str
    ok: bool
    details: List[str] = field(default_factory=list)
    extra_memory: List[str] = field(default_factory=list)   # для SEARCH -> в промпт
    extra_beliefs: List[str] = field(default_factory=list)


def _tokens(text: str) -> set:
    from ..interpretation.lexicon import STOPWORDS, tokens
    return {t for t in tokens(text) if t not in STOPWORDS and len(t) >= 3}


class ActionExecutor:
    def __init__(self, beliefs=None, memory=None, embed: Optional[Callable[[str], Any]] = None, social=None):
        self.beliefs = beliefs
        self.memory = memory
        self.embed = embed
        self.social = social

    # ------------------------------------------------------------ REMEMBER
    def remember(self, interpretation, actor_id: str, evidence: dict) -> ExecutionResult:
        """Явная просьба "запомни" -> подтверждённое убеждение. Обычные
        факты самораскрытия уже прошли через BeliefStore.revise на шаге
        BELIEF UPDATE; здесь они дополнительно закрепляются (confirmed)."""
        res = ExecutionResult(action="remember", ok=True)
        if self.beliefs is None:
            return ExecutionResult("remember", False, ["no belief store"])
        explicit = interpretation.intent == "remember_request"
        for p in interpretation.belief_updates:
            if p.kind not in ("assert", "note"):
                continue
            found = self.beliefs.find_by_key(p.key)
            if found is None and self.embed is not None:
                rev = self.beliefs.revise(p.key, p.statement, self.embed(p.statement), polarity=p.polarity,
                                          confidence=0.9 if explicit else p.confidence, subject=actor_id,
                                          evidence=dict(evidence, source="remember_request" if explicit else "user_statement"),
                                          single_valued=p.single_valued, confirmed=explicit)
                res.details.append(rev.describe())
                found = self.beliefs.find_by_key(p.key)
            if found is not None and explicit:
                bid, b = found
                b.confirmed = True
                b.confidence = max(b.confidence, 0.9)
                res.details.append(f"закреплено по просьбе: «{b.statement}»")
            if found is not None and self.social is not None:
                node = self.social.get_or_create(actor_id)
                if found[0] not in node.beliefs_about_them:
                    node.beliefs_about_them.append(found[0])
        return res

    # ------------------------------------------------------------ FORGET
    def forget(self, interpretation, actor_id: str) -> ExecutionResult:
        res = ExecutionResult(action="forget", ok=False)
        if self.beliefs is None:
            return res
        for p in interpretation.belief_updates:
            if p.kind != "retract":
                continue
            want = _tokens(p.statement)
            best = []
            for bid, b in self.beliefs.about(actor_id):
                overlap = len(want & _tokens(b.statement))
                if overlap:
                    best.append((overlap, bid, b))
            best.sort(key=lambda t: t[0], reverse=True)
            if not best:
                res.details.append(f"не нашла, что забыть по «{p.statement}»")
                continue
            top = best[0][0]
            for overlap, bid, b in best:
                if overlap == top and self.beliefs.retract(bid, reason="forget_request"):
                    res.ok = True
                    res.details.append(f"забыто: «{b.statement}»")
        return res

    # ------------------------------------------------------------ SEARCH
    def search(self, interpretation, query_embedding, already_seen_ids: set, k: int = 6,
               node_ok=None, belief_ok=None) -> ExecutionResult:
        """Углублённый поиск: memory-узлы за пределами обычного top-k и
        belief'ы, совпадающие по сущностям/теме."""
        res = ExecutionResult(action="search", ok=True)
        if self.memory is not None and query_embedding is not None:
            from ..memory.retrieval import RetrievalWeights, retrieve_top_k
            pool = [n for n in self.memory.all_nodes()
                    if n.id not in already_seen_ids and (node_ok is None or node_ok(n))]
            for n in retrieve_top_k(pool, query_embedding, k=k, weights=RetrievalWeights()):
                payload = n.payload if isinstance(n.payload, dict) else {}
                sit = payload.get("situation") if isinstance(payload.get("situation"), dict) else {}
                text = payload.get("summary") or sit.get("said") or ""
                if text:
                    res.extra_memory.append(f"{str(text)[:200]} [найдено поиском]")
        if self.beliefs is not None:
            want = _tokens(" ".join(interpretation.entities + ([interpretation.topic] if interpretation.topic else [])))
            if want:
                for bid, b in self.beliefs.items():
                    if b.is_active and want & _tokens(b.statement) and (belief_ok is None or belief_ok(b)):
                        res.extra_beliefs.append(f"{b.statement} (confidence={b.confidence:.2f}, найдено поиском)")
        res.details.append(f"поиск: +{len(res.extra_memory)} воспоминаний, +{len(res.extra_beliefs)} убеждений")
        return res

    # ------------------------------------------------------------ ACT
    @staticmethod
    def act(interpretation) -> ExecutionResult:
        return ExecutionResult(action="act", ok=True,
                               details=[f"просьба о действии: «{interpretation.focal_text[:120]}» — исполняет инфраструктура"])
