"""
Semantic understanding beyond keyword classification.

This layer is deliberately deterministic and explainable.  It does not choose
Marin's action and does not call an LLM.  It enriches Interpretation with:
- discourse/reference resolution ("это", "он", "там", "тогда", "снова");
- temporal grounding ("сегодня", "завтра", "через два часа", "вчера");
- modality/negation ("не", "может быть", "если", "хочу", "надо");
- multi-intent / clause decomposition;
- lightweight entity normalization and ambiguity reporting.

The module accepts the current observation plus already retrieved memory/world
names.  When evidence is missing it returns an explicit ambiguity instead of
inventing a referent.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
import re
from typing import Any, Dict, List, Optional, Sequence, Tuple


@dataclass
class ReferenceResolution:
    mention: str
    target: Optional[str]
    kind: str
    confidence: float
    evidence: str = ""
    ambiguous: bool = False


@dataclass
class TemporalMention:
    text: str
    kind: str
    normalized: Optional[str] = None
    offset_seconds: Optional[int] = None
    confidence: float = 0.9


@dataclass
class SemanticUnderstanding:
    references: List[ReferenceResolution] = field(default_factory=list)
    temporal: List[TemporalMention] = field(default_factory=list)
    modality: List[str] = field(default_factory=list)
    negations: List[str] = field(default_factory=list)
    clauses: List[str] = field(default_factory=list)
    clause_intents: List[str] = field(default_factory=list)
    normalized_entities: Dict[str, str] = field(default_factory=dict)
    ambiguities: List[str] = field(default_factory=list)
    discourse_links: List[str] = field(default_factory=list)

    @property
    def confidence(self) -> float:
        penalties = len(self.ambiguities) * 0.12
        weak_refs = sum(1 for r in self.references if r.ambiguous or r.confidence < .6)
        penalties += weak_refs * .08
        return max(0.0, min(1.0, 1.0 - penalties))

    def summary(self) -> str:
        parts: List[str] = []
        if self.references:
            parts.append("refs=" + "; ".join(
                f"{r.mention}->{r.target or '?'}({r.confidence:.2f})" for r in self.references[:4]
            ))
        if self.temporal:
            parts.append("time=" + "; ".join(
                f"{t.text}->{t.normalized or '?'}" for t in self.temporal[:4]
            ))
        if self.modality:
            parts.append("modality=" + ",".join(self.modality[:5]))
        if self.negations:
            parts.append("negation=" + "; ".join(self.negations[:3]))
        if len(self.clauses) > 1:
            parts.append(f"clauses={len(self.clauses)}")
        if self.ambiguities:
            parts.append("ambiguous=" + "; ".join(self.ambiguities[:3]))
        return " | ".join(parts)


_WORD = r"[A-Za-zА-Яа-яЁё0-9_-]+"
_REF_PATTERNS = [
    (re.compile(r"\b(это|этот|эта|эти|такое|такой|такую)\b", re.I), "deictic"),
    (re.compile(r"\b(он|она|они|его|ее|её|их|ему|ей|ним|ней)\b", re.I), "person"),
    (re.compile(r"\b(там|сюда|туда|здесь|оттуда|отсюда)\b", re.I), "place"),
    (re.compile(r"\b(тогда|потом|сейчас|раньше|позже|вновь|снова)\b", re.I), "discourse_time"),
    (re.compile(r"\b(this|that|these|those|he|she|they|there|here|then|again)\b", re.I), "deictic"),
]

_TEMP_PATTERNS = [
    (re.compile(r"\bсегодня\b", re.I), "day", 0),
    (re.compile(r"\bзавтра\b", re.I), "day", 86400),
    (re.compile(r"\bпослезавтра\b", re.I), "day", 172800),
    (re.compile(r"\bвчера\b", re.I), "day", -86400),
    (re.compile(r"\bпозавчера\b", re.I), "day", -172800),
    (re.compile(r"\bсейчас\b", re.I), "instant", 0),
    (re.compile(r"\bчерез\s+(\d+)\s+(минут\w*|час\w*|дн\w*|недел\w*)\b", re.I), "relative", None),
    (re.compile(r"\b(\d+)\s+(минут\w*|час\w*|дн\w*|недел\w*)\s+назад\b", re.I), "relative_past", None),
    (re.compile(r"\b(in|через)\s+(\d+)\s+(minutes?|hours?|days?|weeks?)\b", re.I), "relative", None),
    (re.compile(r"\b(yesterday|today|tomorrow|now)\b", re.I), "named_day", None),
]

_MODAL_PATTERNS = [
    ("obligation", r"\b(надо|нужно|необходимо|должен|должна|обязан|обязана|must|need to|have to)\b"),
    ("desire", r"\b(хочу|хочется|хотел|хотела|желаю|want|would like)\b"),
    ("possibility", r"\b(может|возможно|вероятно|можешь|могу|could|might|maybe|perhaps)\b"),
    ("permission", r"\b(можно|разреши|разрешено|may|allowed)\b"),
    ("conditional", r"\b(если|при условии|в случае|if|unless)\b"),
    ("uncertainty", r"\b(наверное|кажется|думаю|вроде|похоже|probably|seems|i think)\b"),
]

_NEGATION_RE = re.compile(
    r"\b(не|ни|никогда|никто|ничего|нет|без|not|never|nobody|nothing|no)\b", re.I
)

# Split on discourse conjunctions, but preserve the original text.
_CLAUSE_SPLIT = re.compile(
    r"\s*(?:,\s*(?=но|а|и|зато|потому что|если|когда|чтобы)\b)|"
    r"\s+(?=(?:но|а|зато|если|когда|потому что|чтобы|and|but|if|when)\b)",
    re.I,
)

def _now_from_observation(observation: Any) -> datetime:
    md = getattr(observation, "metadata", {}) or {}
    raw = md.get("now") or md.get("current_time")
    if isinstance(raw, datetime):
        return raw
    if isinstance(raw, (int, float)):
        return datetime.fromtimestamp(raw, tz=timezone.utc)
    if isinstance(raw, str):
        try:
            return datetime.fromisoformat(raw.replace("Z", "+00:00"))
        except ValueError:
            pass
    ts = getattr(observation, "t_observed", None)
    if ts:
        return datetime.fromtimestamp(float(ts), tz=timezone.utc)
    return datetime.now(timezone.utc)


def _unit_seconds(unit: str) -> int:
    u = unit.lower()
    if u.startswith("мин") or u.startswith("minute"):
        return 60
    if u.startswith("час") or u.startswith("hour"):
        return 3600
    if u.startswith("дн") or u.startswith("day"):
        return 86400
    if u.startswith("недел") or u.startswith("week"):
        return 604800
    return 0


class SemanticUnderstandingEngine:
    """Build a semantic layer from text + conversational/world context."""

    def analyze(
        self,
        text: str,
        *,
        observation: Any = None,
        retrieved: Sequence[Any] = (),
        known_entities: Sequence[str] = (),
        world_continuity: str = "",
        actor_label: str = "Собеседник",
    ) -> SemanticUnderstanding:
        raw = (text or "").strip()
        result = SemanticUnderstanding()
        if not raw:
            return result

        result.clauses = [c.strip() for c in _CLAUSE_SPLIT.split(raw) if c.strip()]
        if not result.clauses:
            result.clauses = [raw]

        # Modality and explicit negation are useful even when intent classifier
        # sees only a single dominant intent.
        low = raw.lower()
        for label, pattern in _MODAL_PATTERNS:
            if re.search(pattern, low, re.I):
                result.modality.append(label)
        result.negations = [m.group(0) for m in _NEGATION_RE.finditer(raw)][:8]

        # Temporal grounding.
        now = _now_from_observation(observation) if observation is not None else datetime.now(timezone.utc)
        for rx, kind, offset in _TEMP_PATTERNS:
            for m in rx.finditer(raw):
                text_m = m.group(0)
                if kind in ("day", "named_day", "instant"):
                    off = offset or 0
                elif kind in ("relative", "relative_past"):
                    nums = [g for g in m.groups() if g and g.isdigit()]
                    units = [g for g in m.groups() if g and not g.isdigit()]
                    if not nums or not units:
                        continue
                    off = int(nums[0]) * _unit_seconds(units[0])
                    if kind == "relative_past":
                        off = -off
                else:
                    off = 0
                target = now + timedelta(seconds=off)
                # ISO date is more useful to downstream scheduling than prose.
                normalized = target.isoformat()
                result.temporal.append(TemporalMention(
                    text=text_m, kind=kind, normalized=normalized,
                    offset_seconds=off, confidence=.95 if kind != "relative" else .9,
                ))

        # Reference resolution: prefer explicit recent discourse evidence.
        candidates = self._candidate_targets(retrieved, known_entities, actor_label)
        for rx, kind in _REF_PATTERNS:
            for m in rx.finditer(raw):
                mention = m.group(0)
                target, conf, evidence = self._resolve_reference(
                    mention, kind, candidates, retrieved, world_continuity, actor_label
                )
                ambiguous = target is None or conf < .6
                result.references.append(ReferenceResolution(
                    mention=mention, target=target, kind=kind,
                    confidence=conf, evidence=evidence, ambiguous=ambiguous,
                ))
                if ambiguous:
                    result.ambiguities.append(
                        f"неясно, к чему относится «{mention}»"
                    )
                elif target:
                    result.discourse_links.append(f"{mention}→{target}")

        # Entity normalization: match spelling/case to known world entities.
        norm_known = {self._norm(e): e for e in known_entities if e}
        for entity in known_entities:
            if self._norm(entity) in self._norm(raw):
                result.normalized_entities[entity] = entity
        # Mention aliases can resolve to known names.
        for mention in re.findall(r"@\w{2,}", raw):
            stripped = mention[1:]
            key = self._norm(stripped)
            for nkey, original in norm_known.items():
                if key == nkey or key in nkey or nkey in key:
                    result.normalized_entities[mention] = original
                    break

        # Keep continuity explicit instead of silently treating a retrieved
        # memory as proof of what a pronoun means.
        if world_continuity and re.search(r"\b(снова|опять|потом|тогда|там|there|again|then)\b", low):
            result.discourse_links.append("ссылка на недавнюю цепочку событий")

        return result

    @staticmethod
    def _norm(value: str) -> str:
        return re.sub(r"[^a-zа-яё0-9]+", " ", value.lower().replace("ё", "е")).strip()

    def _candidate_targets(
        self, retrieved: Sequence[Any], known_entities: Sequence[str], actor_label: str
    ) -> List[str]:
        out: List[str] = []
        if actor_label:
            out.append(actor_label)
        for e in known_entities:
            if e and e not in out:
                out.append(e)
        # Memory payloads are intentionally only weak candidates.
        for node in list(retrieved)[:8]:
            payload = getattr(node, "payload", {}) or {}
            for key in ("speaker", "actor", "entity", "name", "summary"):
                value = payload.get(key)
                if isinstance(value, str) and 1 < len(value) < 80 and value not in out:
                    out.append(value)
        return out[:24]

    def _resolve_reference(
        self, mention: str, kind: str, candidates: Sequence[str],
        retrieved: Sequence[Any], continuity: str, actor_label: str,
    ) -> Tuple[Optional[str], float, str]:
        low = mention.lower()
        if low in {"это", "этот", "эта", "эти", "такое", "такой", "такую", "this", "that", "these", "those"}:
            # Demonstratives most often point to the latest topic/event, but
            # without a matching memory we explicitly leave them unresolved.
            if continuity:
                return "recent_event_chain", .72, "world_continuity"
            if retrieved:
                return "recent_memory", .58, "retrieved_memory"
            return None, .25, "no_recent_context"
        if low in {"там", "сюда", "туда", "здесь", "оттуда", "отсюда", "there", "here"}:
            for node in retrieved:
                p = getattr(node, "payload", {}) or {}
                for key in ("location", "place", "city"):
                    if p.get(key):
                        return str(p[key]), .75, "memory_location"
            return None, .25, "no_location_context"
        if low in {"тогда", "потом", "сейчас", "раньше", "позже", "вновь", "снова", "then", "again"}:
            if continuity:
                return "recent_event_chain", .75, "world_continuity"
            return None, .35, "no_temporal_chain"

        # Person pronouns: if exactly one plausible non-self person exists,
        # resolve it; otherwise don't invent a person.
        people = [c for c in candidates if c and c != actor_label and c.lower() not in {"собеседник", "владелец"}]
        if len(people) == 1:
            return people[0], .62, "single_person_candidate"
        if actor_label and len(people) == 0 and low in {"он", "она", "ему", "ей", "he", "she"}:
            return actor_label, .42, "actor_only_candidate"
        return None, .25, "ambiguous_person"

