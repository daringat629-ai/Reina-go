"""
CognitiveEngine — единая точка входа в marin_core. Владеет CognitiveState
между тиками, всеми подсистемами и внешними адаптерами. Инфраструктура
(Telegram/vision/voice) вызывает только engine.tick(raw_input, ...).

Конструктор даёт рабочие дефолты "из коробки" (§18: сначала работающий
цикл с заглушками, потом наращивание belief/hypothesis/social/metacognition
поверх него), но каждая зависимость подменяема через конструктор.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, List, Optional
from ..numeric import np

from ..state.cognitive_state import CognitiveState
from ..state.latent_state import LatentState, TOTAL_DIM
from ..state.state_transition import StateTransitionModel

from ..identity.identity_model import IdentityModel
from ..identity.personality_dynamics import PersonalityDynamics
from ..identity.presets import create_marin_identity, create_marin_personality

from ..perception.perception import Observation, Modality, TextPerceptionAdapter
from ..perception.situation import SituationBuilder, SituationModel, ActionType as SituationActionType, Tone

from ..perception.attention import AttentionWeights
from ..memory.memory_graph import MemoryGraph, MemoryNode, NodeType
from ..memory.retrieval import RetrievalWeights
from ..memory.experience import ExperienceSystem
from ..memory.diary import DiaryStore
from ..memory.diary_writer import DiaryWriter

from ..belief.beliefs import BeliefStore, Belief, SourceType

from ..world.world_model import WorldModel
from ..world.entities import Entity, EntityKind
from ..world.events import WorldEvent
from ..reasoning.reasoning import ReasoningMode, select_reasoning_mode
from ..state.cognitive_state import CognitiveLoad

from ..metacognition.metacognition import MetacognitionEngine, TickTrace
from ..metacognition.self_reflection import build_self_reflection, SelfReflectionSummary
from ..learning.experience_learning import aggregate_trait_signal_from_window
from ..memory.consolidation import ConsolidationReport

from ..social.social_model import SocialModel

from ..prediction.predictor import Predictor, HeuristicPredictor, Outcome

from ..goals.goals import GoalSet, Goal, GoalLevel, GoalStatus
from ..goals.motivation import ActionCandidate

from ..decision.decision_engine import DecisionEngine

from ..action.action import Action, ActionType
from ..action.validation import ActionValidator

from ..llm.interface import LanguagePlanner, LLMProvider
from ..llm.local import EchoLocalProvider
from ..llm.embeddings import Embedder, HashEmbedder, hash_embed as _hash_embed

from ..perception.classifiers import (
    FallbackStats, KeywordTopicLinker, LexiconToneEstimator, MetadataContextLinker, RuleActionClassifier,
    WithFallback,
)
from ..interpretation.engine import InterpretationEngine
from ..interpretation.lexicon import focal_text
from ..learning.feedback_learning import FeedbackLearner
from ..prediction.predictor import LearnedPredictor
from ..decision.candidates import RichDecisionEngine
from ..action.executor import ActionExecutor

from .cycle import TickDependencies, TickResult, run_tick


EMBED_DIM = TOTAL_DIM  # общее пространство эмбеддингов, см. §1.2 спеки

# _hash_embed переехал в llm/embeddings.py как часть единой embeddings-
# подсистемы (роадмап "Real Embeddings") — реэкспортирован здесь как
# hash_embed для обратной совместимости с кодом/тестами, которые могли
# импортировать его отсюда напрямую.


# ---------------------------------------------------------------------------
# _Default* — ТОЛЬКО fallback. Основная ветка — perception/classifiers.py
# (реальные классификаторы на focal text); сюда управление попадает лишь
# при исключении в реальной реализации (см. WithFallback / FallbackStats).
# ---------------------------------------------------------------------------

class _DefaultEntityLinker:
    def resolve_actor(self, observation: Observation) -> str:
        return observation.source_actor_id


class _DefaultActionClassifier:
    def classify(self, observation: Observation) -> SituationActionType:
        text = observation.content.strip()
        if text.endswith("?"):
            return SituationActionType.ASK_QUESTION
        if len(text) < 12:
            return SituationActionType.SMALL_TALK
        return SituationActionType.STATEMENT


class _DefaultTopicLinker:
    def link(self, observation: Observation) -> Optional[str]:
        return None  # без topic-индекса — заполняется, когда появится world/entities.py в проде


class _DefaultToneEstimator:
    POSITIVE_MARKERS = ("спасибо", "круто", "класс", "здорово", ":)", "❤")
    NEGATIVE_MARKERS = ("плохо", "ужас", "бесит", ":(")

    def estimate(self, observation: Observation) -> Tone:
        text = observation.content.lower()
        valence = 0.0
        for m in self.POSITIVE_MARKERS:
            if m in text:
                valence += 0.3
        for m in self.NEGATIVE_MARKERS:
            if m in text:
                valence -= 0.3
        return Tone(valence=max(-1.0, min(1.0, valence)), energy=min(1.0, len(text) / 200))


class _DefaultContextLinker:
    def link(self, observation: Observation) -> List[str]:
        return []


class _ObservationEmbedder:
    """Адаптер SituationBuilder(embedder=...) -> Embedder: SituationBuilder
    вызывает embed(observation), а Embedder (llm/embeddings.py) работает
    с сырым текстом. Раньше это было захардкожено на _hash_embed
    (_DefaultEmbedder) — теперь принимает любой Embedder извне (реальная
    модель, HashEmbedder-фолбэк, что угодно с интерфейсом str -> ℝ^dim)."""

    def __init__(self, embedder: Embedder):
        self.embedder = embedder

    def embed(self, observation: Observation) -> np.ndarray:
        # Эмбеддим именно то, что собеседник сказал сейчас (focal text), а не
        # весь склеенный Telegram-контекст — иначе novelty/retrieval
        # определяла бы история переписки, а не текущая реплика.
        return self.embedder.embed(focal_text(observation.content) or observation.content)


@dataclass
class EngineConfig:
    retrieval_k: int = 10
    u_dim: int = EMBED_DIM * 2 + 1  # situation + mean(retrieved) + prediction_error, см. cycle._build_u_t


class CognitiveEngine:
    """Верхнеуровневый фасад ядра. См. __init__.py пакета за версией и
    порядком реализации подсистем."""

    def __init__(
        self,
        llm_provider: Optional[LLMProvider] = None,
        config: Optional[EngineConfig] = None,
        situation_builder: Optional[SituationBuilder] = None,
        identity: Optional[IdentityModel] = None,
        personality: Optional[PersonalityDynamics] = None,
        diary_path: Optional[str] = None,
        embedder: Optional[Embedder] = None,
    ):
        self.config = config or EngineConfig()

        # По умолчанию — HashEmbedder (офлайн, детерминированный, без сетевых
        # зависимостей — тот же "холодный старт" контракт, что раньше давал
        # захардкоженный _hash_embed). Реальный embedder (Ollama/OpenAI-
        # совместимый) приходит из config.build_embedder() через build_engine();
        # используется и для situation-эмбеддингов (через situation_builder),
        # и напрямую для belief/reflection statements (remember_fact и т.п.).
        self.embedder: Embedder = embedder or HashEmbedder()

        # По умолчанию — пресет Marin (identity/presets.py). Передайте свои
        # identity/personality в конструктор, чтобы использовать другой характер.
        self.identity = identity or create_marin_identity()
        self.personality = personality or create_marin_personality()

        self.memory = MemoryGraph()
        self.experience = ExperienceSystem(self.memory)
        self.social = SocialModel()

        # Real implementation -> при ошибке -> fallback (_Default*).
        self.fallback_stats = FallbackStats()
        fs = self.fallback_stats
        self.situation_builder = situation_builder or SituationBuilder(
            entity_linker=_DefaultEntityLinker(),  # актор = source_actor_id; тут нечего "угадывать"
            action_classifier=WithFallback("action_classifier", RuleActionClassifier(), _DefaultActionClassifier(), fs),
            topic_linker=WithFallback("topic_linker", KeywordTopicLinker(), _DefaultTopicLinker(), fs),
            tone_estimator=WithFallback("tone_estimator", LexiconToneEstimator(), _DefaultToneEstimator(), fs),
            context_linker=WithFallback("context_linker", MetadataContextLinker(), _DefaultContextLinker(), fs),
            embedder=_ObservationEmbedder(self.embedder),
        )

        # attention_weights берутся из personality (§3/§4 спеки — веса внимания
        # часть личности), не создаются отдельно.
        self.attention_weights = self.personality.attention_weights
        self.retrieval_weights = RetrievalWeights()

        # Обучение из реальных реакций: паттерны интерпретации, Q(intent, action),
        # социальные поправки. Одни и те же хранилища читают интерпретация,
        # предиктор и DecisionEngine — это и есть "замкнутый" цикл обучения.
        self.learner = FeedbackLearner()
        self.interpreter = InterpretationEngine(pattern_store=self.learner.patterns)
        self.predictor: Predictor = LearnedPredictor(
            action_values=self.learner.action_values, social_expectations=self.learner.social,
        )
        self.transition_model = StateTransitionModel(u_dim=self.config.u_dim)
        self.decision_engine = DecisionEngine()
        self.rich_decision = RichDecisionEngine()

        provider = llm_provider or EchoLocalProvider()
        validator = ActionValidator(identity_model=self.identity)
        self.language_planner = LanguagePlanner(provider=provider, validator=validator)

        # Дневник — та же LLM (§17: провайдер как языковой орган), но с
        # ActionType.REMEMBER (см. llm/providers.py) — не чат-реплика, а
        # личная запись/мысль. diary_path=None -> только в памяти процесса,
        # как и остальной marin_core; с путём — persist в JSON (см. config.py
        # MARIN_DIARY_FILE, совместимо по духу со старым v30).
        self.diary = DiaryStore(path=diary_path)
        self.diary_writer = DiaryWriter(
            provider=provider,
            experience=self.experience,
            store=self.diary,
            identity=self.identity,
            personality=self.personality,
        )

        self.goal_set = GoalSet()
        self.goal_set.add(Goal(description="be helpful and consistent", level=GoalLevel.IDENTITY, weight=1.0))
        self.beliefs = BeliefStore()
        self.world = WorldModel()
        self.metacognition = MetacognitionEngine(self.beliefs)
        self.executor = ActionExecutor(
            beliefs=self.beliefs, memory=self.memory, embed=self.embedder.embed, social=self.social,
        )
        self.last_result: Optional[TickResult] = None
        self.meta_history: List[Any] = []
        self._meta_history_max = 50
        self._tick_trace_window: List[TickTrace] = []
        self._tick_trace_window_max = 200

        self.state = CognitiveState(tick=0, z=LatentState.zeros())
        self.perception_adapter = TextPerceptionAdapter()

    def _deps(self) -> TickDependencies:
        return TickDependencies(
            situation_builder=self.situation_builder,
            attention_weights=self.attention_weights,
            retrieval_weights=self.retrieval_weights,
            memory=self.memory,
            experience=self.experience,
            predictor=self.predictor,
            transition_model=self.transition_model,
            decision_engine=self.decision_engine,
            language_planner=self.language_planner,
            retrieval_k=self.config.retrieval_k,
            identity=self.identity,
            personality=self.personality,
            social_model=self.social,
            beliefs=self.beliefs,
            world=self.world,
            interpreter=self.interpreter,
            learner=self.learner,
            rich_decision=self.rich_decision,
            executor=self.executor,
            embed_fn=self.embedder.embed,
        )

    def run_self_reflection(self, consolidation_report: ConsolidationReport) -> Optional[SelfReflectionSummary]:
        """Реальная саморефлексия (§13 + ревью "опыт → анализ → изменение
        внутреннего состояния"): раньше MetacognitionEngine/build_self_reflection
        нигде не вызывались, а personality/update_from_observed_signal и
        aggregate_trait_signal_from_window существовали, но никто их не
        соединял. Вызывается снаружи (ConsolidationScheduler) вместе с
        обычной idle-консолидацией, не на каждый тик."""
        if not self._tick_trace_window:
            return None

        report = self.metacognition.check_window(self._tick_trace_window)
        window = list(self._tick_trace_window)
        reflection = build_self_reflection(window, report, consolidation_report)

        # Изменение personality — только если metacognition реально предложила
        # это (низкая consistency), а не на каждой рефлексии подряд.
        if report.propose_personality_update and self.personality is not None:
            recent_events = self.experience.working(limit=len(window) * 2 or 20)
            trait_signal = aggregate_trait_signal_from_window(recent_events)
            if trait_signal:
                self.personality.update_from_observed_signal(trait_signal)

        # Записываем саму рефлексию как REFLECTION-узел памяти (тот же
        # паттерн, что уже использует ConsolidationEngine._write_reflection)
        # и как самопознание в BeliefStore — то и другое реально читаемо
        # дальше (top_k_relevant / retrieval), а не теряется как лог.
        self.memory.add_node(MemoryNode(
            type=NodeType.REFLECTION,
            embedding=self.embedder.embed(reflection.narrative),
            payload={"kind": "self_reflection", "summary": reflection.narrative},
        ))
        self.remember_fact("latest_self_reflection", reflection.narrative, confidence=0.9)

        # Окно рефлексии — про то, что случилось МЕЖДУ рефлексиями, поэтому
        # очищается после обработки, а не растёт бесконечно.
        self._tick_trace_window.clear()
        return reflection

    def remember_fact(
        self,
        key: str,
        statement: str,
        confidence: float = 0.9,
        source_type: SourceType = SourceType.DIRECT_OBSERVATION,
    ) -> str:
        """Реальная точка входа для BeliefStore извне ядра (напр. Telegram-слой,
        когда он узнаёт что-то конкретное — статус Premium, число диалогов и
        т.п.). key — стабильный идентификатор факта: повторный вызов с тем же
        key обновляет запись вместо того, чтобы плодить дубликаты."""
        belief = Belief(
            statement=statement,
            embedding=self.embedder.embed(statement),
            confidence=confidence,
            source_type=source_type,
        )
        return self.beliefs.upsert(key, belief)

    def remember_person_fact(self, key: str, statement: str, confidence: float = 0.85) -> tuple:
        """Факт, рассказанный конкретным человеком о себе (не про сам
        Telegram-аккаунт, для этого remember_fact) — с обнаружением
        противоречий: если под этим key раньше уже лежал другой statement,
        это не тихая перезапись, а зафиксированное противоречие
        (см. BeliefStore.upsert_with_conflict)."""
        belief = Belief(
            statement=statement,
            embedding=self.embedder.embed(statement),
            confidence=confidence,
            source_type=SourceType.TOLD_BY_USER,
        )
        return self.beliefs.upsert_with_conflict(key, belief)

    def remember_guess(self, statement: str, confidence: float = 0.4) -> str:
        """Точка входа для собственных догадок/выводов модели (не прямых
        фактов) — всегда создаётся как SourceType.LLM_GENERATED и
        unconfirmed, поэтому Belief сам ограничивает confidence сверху
        (см. Belief._clamp_if_unconfirmed_llm) и не может незаметно
        накопить уверенность до уровня факта. Поднять до факта можно
        только явно через self.beliefs.confirm(belief_id)."""
        belief = Belief(
            statement=statement,
            embedding=self.embedder.embed(statement),
            confidence=confidence,
            source_type=SourceType.LLM_GENERATED,
        )
        return self.beliefs.add(belief)

    def add_current_goal(self, description: str, weight: float = 0.8, max_active: int = 8) -> str:
        """Добавляет CURRENT-уровня цель — то, что владелец явно попросил
        держать в фокусе ("напомни мне...", "не забудь..."). IDENTITY-цель
        не трогается. Чтобы такие цели не копились бесконечно, при
        превышении max_active самые старые (не IDENTITY) деактивируются."""
        goal_id = self.goal_set.add(Goal(description=description, level=GoalLevel.CURRENT, weight=weight))
        non_identity_ids = [
            gid for gid, g in self.goal_set.goals.items()
            if g.level != GoalLevel.IDENTITY and g.active
        ]
        if len(non_identity_ids) > max_active:
            for old_id in non_identity_ids[: len(non_identity_ids) - max_active]:
                self.goal_set.goals[old_id].active = False
        return goal_id

    def add_autonomous_goal(
        self, description: str, owner_id: Optional[str] = None, weight: float = 0.9,
        context: Optional[dict] = None,
    ) -> str:
        """Stage 4: долгосрочная цель с автономным планом/выполнением —
        тот же GoalSet/Goal, что и add_current_goal, просто LONG_TERM-уровня
        и с заполненными полями плана/статуса (см. goals/goals.py). План сюда
        не кладётся — этим занимается AutonomousGoalExecutor.plan_goal()
        (marin_core/telegram/goal_executor.py), т.к. решение о шагах зависит
        от реально зарегистрированных Telegram Actions, которых движок сам
        не знает."""
        goal = Goal(
            description=description, level=GoalLevel.LONG_TERM, weight=weight,
            owner_id=owner_id, status=GoalStatus.PENDING, context=dict(context or {}),
        )
        return self.goal_set.add(goal)

    def tick(
        self,
        raw_input: Any,
        *,
        channel_id: str,
        source_actor_id: str,
        is_owner: bool = False,
        action_candidates_fn: Optional[Callable] = None,
        outcome_fn: Optional[Callable] = None,
        addressed: bool = True,
        actor_name: Optional[str] = None,
        metadata: Optional[dict] = None,
    ) -> TickResult:
        """is_owner передаётся инфраструктурой (напр. по Telegram user_id) ДО
        вызова ядра — ядро само не решает, кто владелец, оно только запоминает
        это решение через SocialModel.mark_owner (см. engine/cycle.py)."""
        observation = self.perception_adapter.normalize(raw_input, channel_id=channel_id, source_actor_id=source_actor_id)
        observation.metadata["is_owner"] = is_owner
        observation.metadata["addressed"] = addressed
        if actor_name:
            observation.metadata["actor_name"] = actor_name
        if metadata:
            observation.metadata.update(metadata)

        result = run_tick(
            state=self.state,
            observation=observation,
            deps=self._deps(),
            goal_set=self.goal_set,
            action_candidates_fn=action_candidates_fn or self._default_action_candidates,
            outcome_fn=outcome_fn or self._default_outcome,
            restrict_primary=action_candidates_fn is not None,
        )
        self.last_result = result
        if result.meta is not None:
            self.meta_history.append(result.meta)
            if len(self.meta_history) > self._meta_history_max:
                del self.meta_history[: len(self.meta_history) - self._meta_history_max]
        if result.learning_report is not None:
            lr = result.learning_report
            self._tick_trace_window.append(TickTrace(
                prediction=result.prediction or lr.outcome,  # type: ignore[arg-type]
                outcome=lr.outcome,
                prediction_error=lr.prediction_error,
                behavior_matched_personality=True,
                error_source=lr.attribution.source,
            ))
        self.state = result.state
        self.goal_set.prune_completed_situational()

        if result.prediction is not None and result.outcome is not None:
            self._tick_trace_window.append(TickTrace(
                prediction=result.prediction,
                outcome=result.outcome,
                prediction_error=result.prediction_error,
                behavior_matched_personality=result.behavior_matched_personality,
            ))
            if len(self._tick_trace_window) > self._tick_trace_window_max:
                del self._tick_trace_window[: len(self._tick_trace_window) - self._tick_trace_window_max]

        return result

    def explain_last(self) -> str:
        """Техническая метакогниция последнего тика человекочитаемо:
        что знаю / предполагаю / не знаю, уверенность, почему это действие."""
        r = self.last_result
        if r is None or r.meta is None:
            return "Ещё не было ни одного тика с интерпретацией."
        lines = [r.meta.to_text()]
        if r.interpretation is not None:
            lines.append("Interpretation: " + r.interpretation.summary_for_llm())
        if r.decision is not None:
            top = ", ".join(f"{c.action_type.value}={c.score:.2f}" for c in r.decision.candidates[:4])
            lines.append(f"Кандидаты: {top}")
            if r.secondary_actions:
                lines.append("Побочные действия: " + ", ".join(a.type.value for a in r.secondary_actions))
        if r.learning_report is not None:
            lines.append("Обучение: " + r.learning_report.describe())
        for rev in r.belief_revisions:
            lines.append("Belief: " + rev.describe())
        return "\n".join(lines)

    def learned_patterns(self, limit: int = 10) -> List[str]:
        pats = sorted(self.learner.patterns.patterns.values(), key=lambda p: p.n, reverse=True)
        return [p.describe() for p in pats[:limit]]

    @staticmethod
    def _default_action_candidates(situation, state, goal_set, retrieved) -> List[ActionCandidate]:
        """Минимальный набор кандидатов для холодного старта: всегда можно
        ответить или уточнить. Реальная система расширяет это через
        reasoning/planning.py (§9)."""
        return [
            ActionCandidate(action_type=ActionType.ANSWER.value, cost=0.1, expected_progress={}),
            ActionCandidate(action_type=ActionType.ASK.value, cost=0.15, expected_progress={}),
        ]

    @staticmethod
    def _default_outcome(action: Action, generated_text: Optional[str]) -> Outcome:
        """Заглушка: без обратной связи от среды/пользователя в момент
        отправки используем нейтральную оценку. В реальной интеграции outcome
        пересчитывается, когда придёт реакция пользователя (следующий тик
        может обновить прошлый outcome через ExperienceSystem)."""
        return Outcome(
            actual_type="neutral_reply",
            actual_valence=0.0,
            actual_goal_progress=0.2 if action.type == ActionType.ANSWER else 0.0,
        )
