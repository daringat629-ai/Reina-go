"""
Autonomous Life Loop — supervisor for Marin's long-running life.

One pulse (from MarinTelegramClient._scheduler_loop, every ~60s):

  1. autoposting — every own channel with ``autopost_enabled`` gets a FRESH
     post when its interval is due (ChannelPublisher.autopost_tick). The old
     design bootstrapped an LLM-planned Goal whose ``payload_template`` froze
     the post text at plan time, so every cycle re-published the same text;
     legacy goals of that kind are retired once (see _retire_legacy_goals);
  2. due autonomous goals (".цель ...", <<<AUTOGOAL>>>) keep moving through
     AutonomousGoalExecutor;
  3. self-reflection is fed from idle-consolidation reports at a bounded rate.

Every step is isolated: a failure in one never stops the others or the loop.
"""
from __future__ import annotations

import asyncio
import re
import logging
import os
import time
from typing import Any, Optional

from ..goals.goals import GoalStatus
from ..llm.interface import LanguagePlanningInput
from ..llm.providers import _is_unusable_output
from ..action.action import ActionType

logger = logging.getLogger(__name__)

DEFAULT_LIFE_INTERVAL = 300.0
DEFAULT_ENGAGEMENT_INTERVAL = 900.0
DEFAULT_AUTOPOST_CYCLE = 6 * 3600.0
REFLECTION_MIN_INTERVAL = 6 * 3600.0


# Самостоятельные цели, которые физически не выполнить через Telegram-аккаунт.
_INFEASIBLE_RE = re.compile(
    r"плейлист|playlist|музык|трек[иа]?\b|песн|сним[уа]\w* видео|видеоролик|созвон|позвон|"
    r"встрет|купл|куплю|приготов|испеку|съезж|поед|схож",
    re.IGNORECASE,
)


def _variety_block(tc) -> str:
    """Все недавние собственные идеи (включая сделанные и проваленные) и приевшиеся
    темы. Раньше «не повторяй» касалось только целей в работе — и она снова
    предлагала «осенний пост», «осенний опрос», «осенний плейлист»."""
    try:
        from ..telegram.theme_fatigue import fatigue_note, fatigued_themes, recent_idea_texts, recent_post_texts
    except Exception:
        return ""
    ideas = recent_idea_texts(tc)
    tired = fatigued_themes(ideas + recent_post_texts(tc))
    lines = []
    if ideas:
        lines.append("Недавно ты уже хотела (не повторяй и не перефразируй):\n" + "\n".join(f"- {x}" for x in ideas))
    if tired:
        lines.append(fatigue_note(tired))
    lines.append("Идея должна вырасти из того, что реально было — разговоров, попыток, того, что поняла, "
                 "что зацепило, — а не из дежурных клише про погоду и время года.")
    return "\n".join(lines)


def _local_clock() -> str:
    try:
        from ..telegram.settings import local_now
        now = local_now()
    except Exception:
        import datetime
        now = datetime.datetime.now()
    h = now.hour
    part = "ночь" if h < 6 else "утро" if h < 12 else "день" if h < 18 else "вечер"
    return f"{now.strftime('%H:%M')}, {part}"


class AutonomousLifeLoop:
    def __init__(self, telegram_client: Any):
        self._tc = telegram_client
        self.interval = self._float_env("MARIN_AUTONOMOUS_LIFE_INTERVAL", DEFAULT_LIFE_INTERVAL, 30.0)
        self.default_cycle = self._float_env("MARIN_AUTONOMOUS_POST_INTERVAL", DEFAULT_AUTOPOST_CYCLE, 1800.0)
        self._last_reflection = 0.0
        self._last_pulse = 0.0
        self._legacy_checked = False
        self._last_engagement_check = 0.0
        self._engagement_interval = self._float_env(
            "MARIN_ENGAGEMENT_CHECK_INTERVAL", DEFAULT_ENGAGEMENT_INTERVAL, 60.0
        )
        # Spontaneous social life: Marin may independently start a conversation
        # with an existing human peer. This is deliberately rate-limited and
        # never performs bulk outreach.
        self._social_interval = self._float_env(
            "MARIN_AUTONOMOUS_SOCIAL_INTERVAL", 4 * 3600.0, 1800.0
        )
        self._last_social_action = 0.0
        self._social_peer_cooldown_days = self._float_env(
            "MARIN_AUTONOMOUS_SOCIAL_PEER_COOLDOWN_DAYS", 3.0, 0.5
        )
        self._last_channel_adopt = 0.0
        self._social_max_per_day = int(self._float_env(
            "MARIN_AUTONOMOUS_SOCIAL_MAX_PER_DAY", 2.0, 1.0
        ))
        # Self-initiated goals: she may start something of her own — not asked
        # for by the owner, not on the fixed autopost schedule — occasionally
        # and always transparently (he's told right away, can always check
        # /goals or cancel). Bounded: rate-limited AND capped on how many of
        # her own initiatives can be active at once, so it stays "she does a
        # few things she cares about," not runaway goal creation.
        self._self_initiative_interval = self._float_env(
            "MARIN_SELF_INITIATIVE_INTERVAL", 24 * 3600.0, 3600.0
        )
        self._last_self_initiative = 0.0
        self._self_initiative_max_concurrent = int(self._float_env(
            "MARIN_SELF_INITIATIVE_MAX_CONCURRENT", 2.0, 1.0
        ))

    @staticmethod
    def _float_env(name: str, default: float, minimum: float) -> float:
        from ..env import env_float
        return env_float(name, default, minimum=minimum)

    def _owner_id(self) -> Optional[str]:
        return str(self._tc.config.owner_id) if self._tc.config.owner_id else None

    # ------------------------------------------------------------ migration
    def _retire_legacy_goals(self) -> int:
        """Goals that the previous build auto-created for autopost channels
        (context.autonomous_life=True) would double-post alongside the
        publisher. Retire them once and carry their cadence over."""
        owner_id = self._owner_id()
        if not owner_id:
            return 0
        retired = 0
        for goal in self._tc.engine.goal_set.autonomous_goals(owner_id=owner_id):
            if not goal.context.get("autonomous_life"):
                continue
            if goal.status in {GoalStatus.CANCELLED, GoalStatus.COMPLETED, GoalStatus.FAILED}:
                continue
            channel_id = str(goal.context.get("telegram_channel_id") or "")
            entry = self._tc._own_channels.get(channel_id)
            if entry is not None and not entry.get("autopost_interval"):
                entry["autopost_interval"] = float(goal.context.get("cycle_interval_seconds") or self.default_cycle)
            goal.status = GoalStatus.CANCELLED
            goal.active = False
            goal.next_execution = None
            goal.updated_at = time.time()
            retired += 1
            logger.info("[LIFE] retired legacy autopost goal=%s channel=%s", goal.id, channel_id)
        if retired:
            self._tc._save_own_channels_registry()
        return retired

    def ensure_enabled_channel_goals(self) -> int:
        """Back-compat shim: autopost channels no longer need goals. Fills in
        a default interval for channels enabled by an older build."""
        changed = 0
        for entry in list(getattr(self._tc, "_own_channels", {}).values()):
            if entry.get("autopost_enabled") and not entry.get("autopost_interval"):
                entry["autopost_interval"] = self.default_cycle
                changed += 1
        if changed:
            self._tc._save_own_channels_registry()
        return changed

    # ---------------------------------------------------------------- pulse

    async def _autonomous_social_pulse(self) -> None:
        """Give Marin an occasional chance to initiate a real conversation.

        Candidates are existing human peers from the account's dialogs. This
        is intentionally one peer at a time; there is no broadcast/mass-DM
        path. The cognitive model decides whether the conversation is worth
        initiating and may return [SKIP].
        """
        if os.getenv("MARIN_AUTONOMOUS_SOCIAL_ENABLED", "true").lower() not in {"1", "true", "yes", "on"}:
            return
        now = time.time()
        if now - self._last_social_action < self._social_interval:
            return

        proactive = getattr(self._tc, "proactive", None)
        if proactive is None:
            return

        # Daily cap is persisted in proactive state so restarts don't reset it.
        state = proactive.state
        day = time.strftime("%Y-%m-%d", time.localtime(now))
        log = state.setdefault("sent_log", [])
        sent_today = sum(
            1 for ts, reason in log
            if time.strftime("%Y-%m-%d", time.localtime(float(ts))) == day
            and str(reason).startswith("contact:")
        )
        if sent_today >= self._social_max_per_day:
            return

        try:
            dialogs = await self._tc.client.get_dialogs(limit=80)
        except Exception:
            logger.exception("[LIFE] could not inspect dialogs for autonomous social pulse")
            return

        candidates = []
        last_contacts = state.setdefault("autonomous_contacts", {})
        for d in dialogs or []:
            peer = getattr(d, "entity", None)
            if peer is None:
                continue
            if getattr(peer, "bot", False) or getattr(peer, "broadcast", False):
                continue
            # id — число, owner_id в конфиге — строка: раньше сравнение никогда
            # не срабатывало, и владелец попадал в «с кем возобновить разговор».
            if str(getattr(peer, "id", "")) == str(getattr(self._tc.config, "owner_id", "") or ""):
                continue
            if getattr(peer, "is_self", False):
                continue  # «Избранное» — это она сама
            # Prefer real private human dialogs; groups are observed but not
            # used for unsolicited outreach by this loop.
            if getattr(peer, "id", None) is None:
                continue
            if getattr(peer, "megagroup", False) or getattr(peer, "gigagroup", False):
                continue
            pid = str(getattr(peer, "id"))
            last = float(last_contacts.get(pid, 0.0) or 0.0)
            if now - last < self._social_peer_cooldown_days * 86400:
                continue
            # Only contact people with whom there is actual dialog history.
            if not getattr(d, "message", None):
                continue
            candidates.append(peer)

        if not candidates:
            return

        # Deterministic rotation rather than a random broadcast.
        candidates.sort(key=lambda p: float(last_contacts.get(str(getattr(p, "id")), 0.0) or 0.0))
        for peer in candidates[:8]:
            ok = await proactive.send_to_entity(
                peer,
                reason="Marin самостоятельно решила возобновить разговор.",
                context="Выбери сама, есть ли естественный повод написать этому человеку. "
                        "Если нет — [SKIP].",
            )
            if ok:
                self._last_social_action = now
                return

    async def _self_initiative_pulse(self) -> None:
        """Give Marin a bounded chance to start something SHE decided on —
        a channel post idea, a small personal project, a thing worth doing —
        without the owner having asked for it. Always transparent: he's told
        right away and can cancel like any other goal ('.отмена <id>')."""
        if os.getenv("MARIN_SELF_INITIATIVE_ENABLED", "true").lower() not in {"1", "true", "yes", "on"}:
            return
        owner_id = self._owner_id()
        if not owner_id:
            return
        now = time.time()
        if now - self._last_self_initiative < self._self_initiative_interval:
            return

        active_own = [
            g for g in self._tc.engine.goal_set.autonomous_goals(owner_id=owner_id)
            if g.context.get("self_initiated") and g.active
            and g.status not in {GoalStatus.CANCELLED, GoalStatus.COMPLETED, GoalStatus.FAILED}
        ]
        if len(active_own) >= self._self_initiative_max_concurrent:
            return

        engine = self._tc.engine
        try:
            diary_entries = engine.diary.recent(limit=3)
        except Exception:
            diary_entries = []
        diary_text = "\n".join(f"- {e.text}" for e in diary_entries) or "(пока пусто)"
        reflection = engine.beliefs.find_by_key("latest_self_reflection")
        reflection_text = reflection[1].statement if reflection else "(пока нет)"
        other_active = [
            g.description for g in self._tc.engine.goal_set.autonomous_goals(owner_id=owner_id)
            if g.active and g.status not in {GoalStatus.CANCELLED, GoalStatus.COMPLETED, GoalStatus.FAILED}
        ]
        active_text = "; ".join(other_active) if other_active else "(ничего сейчас)"

        prompt = (
            f"Ты — Марин. Сейчас {_local_clock()} (твоё местное время) — если идея связана со временем "
            "суток, пусть совпадает с ним (утром не «вечерний пост»). "
            "Сейчас спокойный момент, и владелец тебя ни о чём не просил. "
            "У тебя есть возможность — если ты правда этого хочешь — начать что-то СВОЁ: "
            "идею для поста в своём канале, которая реально тебя зацепила прямо сейчас "
            "(не по расписанию), небольшой личный проект, что-то, чем хочется заняться. "
            "Если такое желание реально есть — опиши его ОДНИМ коротким предложением от "
            "первого лица, как настоящее намерение, а не отчёт и не вопрос-разрешение. "
            "Если ничего по-настоящему не зацепило — верни ровно [SKIP]. Не выдумывай "
            "желание просто чтобы что-то написать, и не повторяй то, что уже в работе.\n\n"
            "ВАЖНО — бери только то, что реально можешь сделать сама прямо в Telegram: "
            "написать и опубликовать пост (можно с иллюстрацией или селфи) в своём канале, "
            "запустить в канале опрос, закрепить пост, поменять описание/название/фото своего "
            "канала, обновить своё био, ответить подписчикам в обсуждении. НЕ бери то, чего "
            "сделать не можешь: собрать плейлист или музыку, снять видео, созвониться, "
            "встретиться, что-то купить/приготовить в реальности.\n\n"
            f"Недавние дневниковые записи:\n{diary_text}\n"
            f"Последняя саморефлексия: {reflection_text}\n"
            f"Уже в работе (не повторяй): {active_text}\n"
            + _variety_block(self._tc)
        )
        personality = getattr(engine, "personality", None)
        style = dict(getattr(personality, "style_prior", {}) or {})
        pin = LanguagePlanningInput(
            situation_summary=prompt, retrieved_memory_summaries=[], active_belief_summaries=[],
            chosen_action_type=ActionType.ANSWER, goal_context_summary="", style_prior=style,
        )
        try:
            raw = await asyncio.to_thread(engine.language_planner.provider.generate, pin)
        except Exception:
            logger.exception("[LIFE] self-initiative planning call failed")
            return
        if not raw or _is_unusable_output(raw):
            return
        raw = raw.strip()
        if "[SKIP]" in raw.upper():
            return
        description = raw.strip(" \"'«»").split("\n")[0][:300]
        if not description:
            return
        if _INFEASIBLE_RE.search(description):
            # Модель всё равно придумала то, что в Telegram не выполнить
            # (плейлист, видео, звонок) — не обещаем владельцу невозможное.
            logger.info("[LIFE] self-initiative skipped (not doable in Telegram): %r", description[:200])
            return

        self._last_self_initiative = now
        goal_id = self._tc.goal_executor.create_goal_from_description(
            description, owner_id, context={"self_initiated": True}
        )
        logger.info("[LIFE] self-initiated goal=%s description=%r", goal_id, description[:200])
        try:
            owner_entity = await self._tc.client.get_entity(int(owner_id))
            await self._tc.client.send_message(
                owner_entity,
                f"Слушай, мне тут захотелось кое-что сделать: {description[:1].lower() + description[1:].rstrip('.')} 🙂\n"
                f"Если против — напиши «.отмена {goal_id[:8]}», а так я просто займусь.",
            )
        except Exception:
            logger.exception("[LIFE] could not notify owner about self-initiated goal")

    async def _adopt_own_channels(self) -> None:
        """Каналы, которые она сама создала (creator), считаются её собственными, а
        автопост в своих каналах включён по умолчанию — без команд `.мойканал` /
        `.автопост`. Явное «выкл» владельца уважается (ключ autopost_enabled уже
        стоит и равен False). Что и когда писать, решает она сама: пустая мысль
        = поста нет."""
        from ..env import env_bool
        if not env_bool("MARIN_AUTONOMOUS_CHANNEL_ADOPT", True):
            return
        now = time.time()
        if now - self._last_channel_adopt < 3600:
            return
        self._last_channel_adopt = now
        tc = self._tc
        changed = False
        try:
            from telethon import utils as tl_utils
            dialogs = await tc.client.get_dialogs(limit=200)
            for d in dialogs or []:
                ent = getattr(d, "entity", None)
                if ent is None or not getattr(ent, "broadcast", False) or not getattr(ent, "creator", False):
                    continue
                cid = tl_utils.get_peer_id(ent)
                if str(cid) not in tc._own_channels:
                    tc._remember_own_channel(cid, getattr(ent, "title", "") or "", getattr(ent, "username", "") or "")
                    changed = True
        except Exception:
            logger.debug("[LIFE] own-channel adoption skipped", exc_info=True)
        if env_bool("MARIN_AUTONOMOUS_AUTOPOST_DEFAULT", True):
            for entry in list(getattr(tc, "_own_channels", {}).values()):
                if "autopost_enabled" not in entry:
                    entry["autopost_enabled"] = True
                    entry["autopost_interval"] = entry.get("autopost_interval") or self.default_cycle
                    entry.setdefault("last_post_at", None)
                    changed = True
                    logger.info("[LIFE] autopost enabled by default for channel=%s", entry.get("id"))
        if changed:
            tc._save_own_channels_registry()

    async def pulse(self) -> None:
        if not self._owner_id():
            return
        if not self._legacy_checked:
            self._legacy_checked = True
            try:
                self._retire_legacy_goals()
                self.ensure_enabled_channel_goals()
            except Exception:
                logger.exception("[LIFE] legacy migration failed")

        try:
            await self._adopt_own_channels()
        except Exception:
            logger.exception("[LIFE] channel adoption failed")

        try:
            results = await self._tc.publisher.autopost_tick()
            for res in results:
                if res.ok:
                    logger.info("[LIFE] autopost ok channel=%s msg=%s", res.channel_id, res.message_id)
                    proactive = getattr(self._tc, "proactive", None)
                    if proactive is not None:
                        await proactive.on_autopost(res)
        except Exception:
            logger.exception("[LIFE] autopost tick failed")

        try:
            await self._tc.goal_executor.advance_due_goals()
        except Exception:
            logger.exception("[LIFE] goal pulse failed")

        proactive = getattr(self._tc, "proactive", None)
        if proactive is not None:
            try:
                await proactive.pulse()
            except Exception:
                logger.exception("[LIFE] proactive pulse failed")

        try:
            await self._autonomous_social_pulse()
        except Exception:
            logger.exception("[LIFE] autonomous social pulse failed")

        try:
            await self._self_initiative_pulse()
        except Exception:
            logger.exception("[LIFE] self-initiative pulse failed")

        now = time.time()
        if now - self._last_engagement_check >= self._engagement_interval:
            self._last_engagement_check = now
            publisher = getattr(self._tc, "publisher", None)
            if publisher is not None:
                try:
                    n = await publisher.refresh_all_channels()
                    if n:
                        logger.info("[LIFE] engagement metrics refreshed for %d post(s)", n)
                except Exception:
                    logger.exception("[LIFE] engagement refresh failed")

    async def on_consolidation_report(self, report: Any) -> None:
        if report is None:
            return
        now = time.time()
        if now - self._last_reflection < REFLECTION_MIN_INTERVAL:
            return
        self._last_reflection = now
        try:
            reflection = await asyncio.to_thread(self._tc.engine.run_self_reflection, report)
            if reflection is not None:
                logger.info("[LIFE] self-reflection recorded")
        except Exception:
            logger.exception("[LIFE] self-reflection failed")
