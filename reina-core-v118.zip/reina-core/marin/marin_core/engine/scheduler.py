"""
Scheduler — запускает ConsolidationEngine на idle/по расписанию (§14).
Не часть real-time цикла (cycle.py) — вызывается инфраструктурой снаружи
(например, cron-задачей или asyncio-таском в Telegram-слое v30).

Заодно, если у движка есть diary_writer (см. engine/cognitive_engine.py),
на каждой консолидации пишет дневниковую запись за прожитый период — это
и есть автоматический "дневник", не только ручная команда в Telegram.
"""

from __future__ import annotations

from dataclasses import dataclass
import logging
import time

from ..memory.consolidation import ConsolidationEngine, ConsolidationReport
from .cognitive_engine import CognitiveEngine

logger = logging.getLogger("marin_core.engine.scheduler")


@dataclass
class SchedulerConfig:
    idle_threshold_seconds: float = 30 * 60.0   # считать "простоем", если тишина дольше этого
    min_interval_between_runs_seconds: float = 6 * 3600.0
    write_diary: bool = True  # писать ли дневниковую запись на каждой консолидации


class ConsolidationScheduler:
    def __init__(self, engine: CognitiveEngine, config: SchedulerConfig | None = None):
        self.engine = engine
        self.config = config or SchedulerConfig()
        self.consolidation = ConsolidationEngine(engine.memory)
        self._last_run_ts: float = 0.0
        self._last_observation_ts: float = time.time()

    def notice_activity(self) -> None:
        """Вызывается инфраструктурой при каждом входящем сообщении, чтобы
        scheduler знал, когда наступает простой."""
        self._last_observation_ts = time.time()

    def maybe_run(self, now: float | None = None) -> ConsolidationReport | None:
        now = now or time.time()
        idle_for = now - self._last_observation_ts
        since_last_run = now - self._last_run_ts

        if idle_for >= self.config.idle_threshold_seconds and since_last_run >= self.config.min_interval_between_runs_seconds:
            since_ts = self._last_run_ts or 0.0
            report = self.consolidation.run(since_ts=since_ts)

            if self.config.write_diary and getattr(self.engine, "diary_writer", None) is not None:
                period_label = self._format_period(since_ts, now)
                try:
                    self.engine.diary_writer.write_entry(since_ts=since_ts, period_label=period_label)
                except Exception:
                    logger.exception("Diary entry generation failed — consolidation itself still succeeded")

            self._last_run_ts = now

            try:
                reflection = self.engine.run_self_reflection(report)
            except Exception:
                reflection = None
                logger.exception("Self-reflection failed — consolidation itself still succeeded")
            if reflection is not None:
                logger.info(
                    "Self-reflection: ticks=%d mean_pred_error=%.3f consistency=%.2f "
                    "unresolved_contradictions=%d",
                    reflection.n_ticks_reviewed, reflection.mean_prediction_error,
                    reflection.consistency_score, reflection.n_unresolved_contradictions,
                )

            return report
        return None

    @staticmethod
    def _format_period(since_ts: float, now: float) -> str:
        if since_ts <= 0:
            return time.strftime("до %H:%M %d.%m", time.localtime(now))
        return f"{time.strftime('%H:%M', time.localtime(since_ts))}–{time.strftime('%H:%M %d.%m', time.localtime(now))}"
