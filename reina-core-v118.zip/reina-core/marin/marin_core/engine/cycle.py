"""
Cognitive Loop — §16 спеки:

OBSERVE -> UPDATE SITUATION -> ATTEND -> RETRIEVE -> INTERPRET
-> LEARN FROM FEEDBACK (реакция на прошлый ответ разрешает прошлый прогноз)
-> BELIEF UPDATE -> PREDICT (для каждого кандидата) -> SET/UPDATE GOALS
-> REASON -> DECIDE (основное + побочные действия) -> ACT -> OBSERVE OUTCOME
-> CALCULATE ERROR -> RECORD EXPERIENCE -> METACOGNITION -> UPDATE STATE

Это стержень ядра: одна функция run_tick, вызывающая все подсистемы в
фиксированном порядке. CognitiveEngine (cognitive_engine.py) владеет
состоянием между тиками и зависимостями; run_tick — чистая оркестрация
одного прохода, чтобы её было легко тестировать изолированно.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, List, Optional
from ..numeric import np

from ..state.cognitive_state import CognitiveState, CognitiveLoad
from ..state.state_transition import StateTransitionModel
from ..perception.perception import Observation
from ..perception.situation import SituationBuilder, SituationModel
from ..perception.attention import AttentionWeights, select_top_n
from ..memory.memory_graph import MemoryGraph
from ..memory.retrieval import RetrievalWeights, retrieve_top_k
from ..memory.scope import (
    belief_visible, format_belief, format_memory, node_visible, same_context_bonus, scope_mode,
)
from ..memory.experience import ExperienceSystem
from ..belief.beliefs import BeliefStore
from ..world.world_model import WorldModel
from ..world.entities import Entity, EntityKind
from ..world.events import WorldEvent
from ..reasoning.reasoning import ReasoningMode, select_reasoning_mode
from ..prediction.predictor import Predictor, Outcome
from ..prediction.prediction_error import compute_prediction_error, PredictionErrorWeights
from ..goals.goals import GoalSet
from ..goals.motivation import ActionCandidate
from ..decision.decision_engine import DecisionEngine, DecisionContext
from ..action.action import Action, ActionType
from ..llm.interface import LanguagePlanner, LanguagePlanningInput
from ..action.action import SPEAKING_ACTIONS
from ..action.executor import ActionExecutor
from ..interpretation.engine import InterpretationContext, InterpretationEngine
from ..learning.feedback_learning import FeedbackLearner, PendingTick
from ..decision.candidates import RichDecisionContext, RichDecisionEngine
from ..metacognition.tick_meta import build_tick_meta, estimate_knowledge
from ..goals.motivation import utility, default_conflict_penalty


@dataclass
class TickDependencies:
    """Все внешние/подключаемые зависимости, нужные для одного тика.
    Собираются один раз в CognitiveEngine.__init__ и передаются сюда."""

    situation_builder: SituationBuilder
    attention_weights: AttentionWeights
    retrieval_weights: RetrievalWeights
    memory: MemoryGraph
    experience: ExperienceSystem
    predictor: Predictor
    transition_model: StateTransitionModel
    decision_engine: DecisionEngine
    language_planner: LanguagePlanner
    beliefs: Optional[BeliefStore] = None
    world: Optional[WorldModel] = None
    prediction_error_weights: PredictionErrorWeights = field(default_factory=PredictionErrorWeights)
    retrieval_k: int = 10
    identity: Optional[Any] = None      # identity.identity_model.IdentityModel
    personality: Optional[Any] = None   # identity.personality_dynamics.PersonalityDynamics
    social_model: Optional[Any] = None  # social.social_model.SocialModel
    owner_retrieval_boost: float = 1.5  # во сколько раз увеличивается K при общении с владельцем
    # --- слой понимания/обучения (roadmap: Interpretation -> Beliefs -> Prediction -> Learning)
    interpreter: Optional[InterpretationEngine] = None
    learner: Optional[FeedbackLearner] = None
    rich_decision: Optional[RichDecisionEngine] = None
    executor: Optional[ActionExecutor] = None
    embed_fn: Optional[Any] = None       # str -> вектор (для statement'ов belief'ов)


@dataclass
class TickResult:
    state: CognitiveState
    situation: SituationModel
    action: Action
    generated_text: Optional[str]
    prediction_error: float
    reasoning_mode: Optional[ReasoningMode] = None
    prediction: Optional[Any] = None
    outcome: Optional[Any] = None
    behavior_matched_personality: bool = True
    interpretation: Optional[Any] = None       # interpretation.Interpretation
    decision: Optional[Any] = None             # decision.candidates.Decision
    secondary_actions: List[Any] = field(default_factory=list)
    execution_results: List[Any] = field(default_factory=list)
    belief_revisions: List[Any] = field(default_factory=list)
    learning_report: Optional[Any] = None      # learning.feedback_learning.LearningReport (про ПРОШЛЫЙ ход)
    meta: Optional[Any] = None                 # metacognition.tick_meta.TickMetacognition
    planning_input: Optional[Any] = None       # llm.interface.LanguagePlanningInput этого хода


def run_tick(
    state: CognitiveState,
    observation: Observation,
    deps: TickDependencies,
    goal_set: GoalSet,
    action_candidates_fn,
    outcome_fn,
    restrict_primary: bool = False,
) -> TickResult:
    """Один тик когнитивного цикла (§16).

    action_candidates_fn(situation, state, goal_set, retrieved) -> List[ActionCandidate]
        строит кандидатов действий с их expected_progress для utility (§10.3)
    outcome_fn(action, generated_text) -> Outcome
        получает реальный исход действия (ответ среды/пользователя, если он
        доступен синхронно; иначе — эвристическая оценка на момент отправки)
    restrict_primary
        True, если вызывающий код передал СВОЙ набор кандидатов — тогда
        основное действие выбирается только из него (обратная совместимость).
    """

    # 1. OBSERVE -> UPDATE SITUATION (§2)
    recent_embeddings = [n.embedding for n in deps.experience.working(limit=20)]
    situation = deps.situation_builder.build(observation, recent_embeddings)

    # 1b. OWNER DETECTION — решение принимает инфраструктура (напр. Telegram
    # user_id) ДО вызова ядра и передаёт его через observation.metadata['is_owner'].
    # Ядро только фиксирует это в SocialModel (доверие/близость не "зарабатываются"
    # заново) и помечает текущую ситуацию.
    is_owner = False
    if deps.social_model is not None:
        if observation.metadata.get("is_owner") and not deps.social_model.is_owner(observation.source_actor_id):
            deps.social_model.mark_owner(observation.source_actor_id)
        is_owner = deps.social_model.is_owner(observation.source_actor_id)
    else:
        is_owner = bool(observation.metadata.get("is_owner"))

    situation.is_owner = is_owner
    if is_owner:
        situation.relationship_relevance = 1.0

    # 1c. RELATIONSHIP EVOLUTION (§11) — раньше SocialModel использовался
    # только для is_owner-флага; relationship.py (trust/closeness/valence-EMA)
    # существовал, но никогда не обновлялся и не читался. Теперь каждый тик
    # реально сдвигает relationship EMA по тону ситуации, а relationship_relevance
    # для не-владельца отражает накопленные trust/closeness, а не всегда 0.0.
    if deps.social_model is not None:
        valence = situation.tone.valence
        # observe_interaction трактует trust_signal/closeness_signal == 0.0 как
        # "сигнала нет, не двигать" — поэтому без явного вывода этих сигналов
        # trust/closeness остались бы статичными навсегда, даже подключенные.
        # Эвристика: положительный тон подталкивает доверие вверх/вниз от
        # нейтральной точки 0.5; closeness растёт с самим объёмом общения.
        trust_signal = max(0.0, min(1.0, 0.5 + 0.5 * valence))
        prior_count = deps.social_model.get_or_create(situation.actor_id).relationship.interaction_count
        closeness_signal = min(1.0, (prior_count + 1) / 50.0)
        deps.social_model.observe_interaction(
            situation.actor_id, valence, trust_signal=trust_signal, closeness_signal=closeness_signal
        )
        if not is_owner:
            situation.relationship_relevance = deps.social_model.relationship_relevance(
                situation.actor_id, memory_involves_entity=True
            )

    # 1d. WORLD MODEL (раздел 6) — раньше полностью изолирован (ноль ссылок
    # вне своего модуля). Теперь реально ведёт сущность-актора и цепочку её
    # последних событий, кормя CausalModel настоящими "A потом B"
    # наблюдениями — заодно даёт continuity-сводку для промпта.
    world_continuity = ""
    if deps.world is not None:
        actor_entity = deps.world.find_entity_by_name(situation.actor_id, EntityKind.PERSON)
        actor_world_id = (
            actor_entity.id if actor_entity is not None
            else deps.world.upsert_entity(Entity(kind=EntityKind.PERSON, name=situation.actor_id))
        )
        event = WorldEvent(
            description=(situation.raw_text[:150] or situation.action.value),
            involved_entity_ids=[actor_world_id],
        )
        deps.world.record_sequential_event(event, actor_world_id)
        world_continuity = deps.world.recent_chain_summary(actor_world_id)

    # 1e. REASONING MODE (§9, §15) — раньше ReasoningEngine/select_reasoning_mode
    # нигде не вызывались; stakes был захардкожен (0.3 в DecisionContext), а
    # CognitiveLoad никогда не заполнялся реальными значениями. Теперь stakes
    # реально растёт для владельца и с новизной ситуации, cognitive_load
    # реально учитывает число открытых противоречий в памяти, и режим влияет
    # на глубину retrieval и на явную инструкцию LLM быть внимательнее.
    stakes = min(1.0, (0.8 if is_owner else 0.3) + 0.2 * situation.novelty)
    open_contradictions_count = len(deps.beliefs.open_contradictions()) if deps.beliefs is not None else 0
    cognitive_load = CognitiveLoad(open_contradictions_weight=min(0.3, 0.05 * open_contradictions_count))
    reasoning_mode = select_reasoning_mode(stakes, cognitive_load)
    cognitive_load.deep_reasoning_engaged = reasoning_mode == ReasoningMode.DEEP
    state.cognitive_load = cognitive_load

    # 2. ATTEND (§3)
    effective_k = int(deps.retrieval_k * deps.owner_retrieval_boost) if is_owner else deps.retrieval_k
    if reasoning_mode == ReasoningMode.DEEP:
        effective_k = int(effective_k * 1.3)
    # Границы памяти: разговор с человеком видит память этого человека и этого чата,
    # а не всё подряд (см. memory/scope.py). Раньше отбор шёл по всему графу.
    _scope = scope_mode()
    _actor = str(situation.actor_id or observation.source_actor_id or "")
    _channel = str(observation.channel_id or "")
    all_nodes = [
        n for n in deps.memory.all_nodes()
        if node_visible(n, actor_id=_actor, channel_id=_channel, is_owner=bool(is_owner), mode=_scope)
    ]
    candidates = [
        {
            "embedding": n.embedding,
            "goal_relevance": 0.0,
            "recency": 0.0,
            "novelty": situation.novelty,
            "danger_or_conflict": 0.0,
            "social_salience": situation.relationship_relevance,
            "node": n,
        }
        for n in all_nodes
    ]
    attended = select_top_n(candidates, situation.embedding, deps.attention_weights, n=effective_k * 2)
    attended_nodes = [c["node"] for c in attended]

    # 3. RETRIEVE (§5.2) — для владельца K увеличен (приоритет внимания, §11)
    retrieved = retrieve_top_k(
        attended_nodes,
        situation.embedding,
        k=effective_k,
        weights=deps.retrieval_weights,
        relationship_relevance_fn=lambda n: same_context_bonus(n, actor_id=_actor, channel_id=_channel),
    )

    # 4. INTERPRET — настоящий слой: Perception + Situation + Memory + Social +
    # World + Beliefs + выученные паттерны -> структурированная Interpretation.
    interpretation = None
    pending = None
    learning_report = None
    if deps.interpreter is not None:
        if deps.learner is not None:
            pending = deps.learner.pending_for(situation.actor_id)
        rel = deps.social_model.get_or_create(situation.actor_id).relationship if deps.social_model is not None else None
        known_names = [e.name for e in deps.world.entities.values()] if deps.world is not None else []
        actor_name = (observation.metadata.get("actor_name") or "").strip()
        interp_ctx = InterpretationContext(
            actor_id=situation.actor_id,
            actor_label="Владелец" if is_owner else (actor_name or "Собеседник"),
            is_owner=is_owner,
            retrieved=retrieved,
            relationship=rel,
            world_continuity=world_continuity,
            known_entity_names=known_names,
            beliefs=deps.beliefs,
            situation_embedding=situation.embedding,
            pending=pending,
            addressed=bool(observation.metadata.get("addressed", True)),
        )
        interpretation = deps.interpreter.interpret(observation, situation, interp_ctx)
        situation.interpretation = interpretation
        situation.goal_hint = interpretation.intent
        if interpretation.topic and not situation.topic_id:
            situation.topic_id = interpretation.topic

    # 4b. LEARN FROM FEEDBACK — эта реплика есть реальный исход моего прошлого
    # хода с этим человеком: считаем НАСТОЯЩУЮ ошибку прогноза, находим её
    # источник и обновляем именно его — до того, как решать, что делать сейчас.
    if interpretation is not None and pending is not None and deps.learner is not None:
        learning_report = deps.learner.learn(interpretation, pending, beliefs=deps.beliefs, social_model=deps.social_model)
        for lesson in learning_report.lessons:
            deps.memory.add_node(_reflection_node(deps, f"Урок: {lesson}"))

    # 4c. BELIEF UPDATE — факты, которые собеседник сообщил о себе, это
    # свидетельства: revise() подкрепляет/создаёт/фиксирует противоречие,
    # а не перезаписывает молча.
    belief_revisions: List[Any] = []
    if interpretation is not None and deps.beliefs is not None:
        embed = deps.embed_fn
        for p in interpretation.belief_updates:
            if p.kind != "assert" or embed is None:
                continue
            rev = deps.beliefs.revise(
                p.key, p.statement, embed(p.statement), polarity=p.polarity, confidence=p.confidence,
                subject=situation.actor_id, single_valued=p.single_valued,
                evidence={"tick": state.tick, "text": interpretation.focal_text[:200], "weight": 1.0},
            )
            belief_revisions.append(rev)
            if deps.social_model is not None:
                node = deps.social_model.get_or_create(situation.actor_id)
                if rev.belief_id not in node.beliefs_about_them:
                    node.beliefs_about_them.append(rev.belief_id)

    relevant_belief_pairs: List[Any] = []
    if deps.beliefs is not None:
        relevant_belief_pairs = _top_k_relevant_with_ids(
            deps.beliefs, situation.embedding, k=5, actor_id=_actor, mode=_scope)
    relevant_beliefs = [b for _, b in relevant_belief_pairs]
    knowledge = estimate_knowledge(
        situation.embedding, retrieved, relevant_beliefs,
        interpretation.related_beliefs if interpretation is not None else None,
    )

    # 5. PREDICT (§6) — для каждого кандидата свой прогноз с явными допущениями
    rel_state = deps.social_model.get_or_create(situation.actor_id).relationship if deps.social_model is not None else None

    def _predict(action_value: str):
        if hasattr(deps.predictor, "predict_for"):
            return deps.predictor.predict_for(
                situation, state.z, action_value, interpretation=interpretation,
                relationship=rel_state, actor_id=situation.actor_id, beliefs_used=relevant_beliefs,
            )
        return deps.predictor.predict(situation, state.z, action_value)

    # 6. SET/UPDATE GOALS (§10)
    # Ситуационные цели формируются вызывающим кодом через goal_set до тика.

    # 7. REASON -> candidate actions (§9, §10.3): внешние кандидаты дают goal-utility
    action_candidates: List[ActionCandidate] = action_candidates_fn(situation, state, goal_set, retrieved)

    # 8. DECIDE
    decision = None
    secondary_actions: List[Action] = []
    if interpretation is not None and deps.rich_decision is not None:
        legacy_utils = {}
        for c in action_candidates:
            legacy_utils[c.action_type] = max(0.0, utility(c, goal_set, default_conflict_penalty) + c.cost)
        rctx = RichDecisionContext(
            interpretation=interpretation, stakes=stakes, is_owner=is_owner,
            addressed=interpretation.addressed, knowledge=knowledge,
            action_values=deps.learner.action_values if deps.learner is not None else None,
            predict=_predict, legacy_utilities=legacy_utils,
            allowed_primary=[c.action_type for c in action_candidates] if restrict_primary else None,
        )
        decision = deps.rich_decision.decide(rctx)
        action = decision.primary
        secondary_actions = decision.secondary
        selected = decision.selected
        prediction = selected.prediction if (selected is not None and selected.prediction is not None) else _predict(action.type.value)
    else:
        prediction = deps.predictor.predict(situation, state.z, ActionType.ANSWER)
        decision_ctx = DecisionContext(situation=situation, z=state.z, goal_set=goal_set, stakes=stakes)
        action = deps.decision_engine.decide(decision_ctx, action_candidates)
    state.predictions = [prediction]
    action.target_channel_id = observation.channel_id
    action.target_actor_id = observation.source_actor_id

    # 8b. SEARCH — побочное действие, которое должно случиться ДО генерации
    execution_results: List[Any] = []
    extra_memory: List[str] = []
    extra_beliefs: List[str] = []
    if deps.executor is not None and interpretation is not None:
        for sa in secondary_actions:
            if sa.type == ActionType.SEARCH:
                r = deps.executor.search(
                    interpretation, situation.embedding, {n.id for n in retrieved},
                    node_ok=lambda n: node_visible(n, actor_id=_actor, channel_id=_channel,
                                                   is_owner=bool(is_owner), mode=_scope),
                    belief_ok=lambda b: belief_visible(b, actor_id=_actor, mode=_scope),
                )
                execution_results.append(r)
                extra_memory, extra_beliefs = r.extra_memory, r.extra_beliefs
            elif sa.type == ActionType.ACT:
                execution_results.append(deps.executor.act(interpretation))

    # 9. ACT — включая LLM-шаг (§17)
    generated_text = None
    planning_input = None  # для второго прохода после READ (см. telegram client)
    if action.type in SPEAKING_ACTIONS:
        style_prior = {}
        constraints: List[str] = []
        relationship_context = ""
        if deps.personality is not None:
            style_prior = deps.personality.owner_style_prior if (is_owner and deps.personality.owner_style_prior) else deps.personality.style_prior
        if deps.identity is not None:
            constraints = [
                inv.description
                for inv in deps.identity.invariants
                if not (is_owner and not getattr(inv, "applies_to_owner", True))
            ]
            if is_owner and deps.identity.owner_description:
                relationship_context = deps.identity.owner_description

        if deps.social_model is not None:
            node = deps.social_model.get_or_create(situation.actor_id)
            rel = node.relationship
            rel_line = (
                f"[Relationship state] trust={rel.trust:.2f}, closeness={rel.closeness:.2f}, "
                f"recent tone (EMA)={rel.history_valence_ema:+.2f}, interactions so far={rel.interaction_count}."
            )
            relationship_context = f"{relationship_context}\n{rel_line}".strip()

        if world_continuity:
            relationship_context = f"{relationship_context}\n[Recent event chain] {world_continuity}".strip()

        if reasoning_mode == ReasoningMode.DEEP:
            constraints.append(
                "This situation carries higher stakes than usual — take a bit more care, be more "
                "thorough and precise, and double-check yourself before answering."
            )

        belief_summaries: List[str] = []
        for b in relevant_beliefs:
            belief_summaries.append(format_belief(b, actor_id=_actor))
        belief_summaries.extend(extra_beliefs)

        # Решение и понимание передаются LLM как контекст — LLM формулирует,
        # но не решает (§17).
        if interpretation is not None:
            if action.type == ActionType.CLARIFY:
                constraints.append(
                    "You are not sure what they meant. Briefly and naturally ask what exactly they mean "
                    "(one concrete question), instead of guessing."
                )
            elif action.type == ActionType.ASK:
                constraints.append("Respond, and keep the conversation going with one natural follow-up question.")
            elif interpretation.uncertainty > 0.55:
                constraints.append("You may have misread the message — answer, but don't state guesses as facts.")
            for rev in belief_revisions:
                if rev.kind == "contradicted":
                    constraints.append(
                        f"They said something that contradicts what you knew before (earlier: "
                        f"«{rev.previous_statement}», now: «{rev.statement}»). Trust the new statement; "
                        "you may lightly acknowledge the change if it feels natural."
                    )
            if learning_report is not None and learning_report.attribution.source == "intent":
                constraints.append("Your previous reply misunderstood them — acknowledge it briefly and fix it.")
            elif learning_report is not None and learning_report.attribution.source == "action":
                constraints.append("They didn't like how you replied last time (e.g. extra questions) — just answer directly.")
        memory_summaries: List[str] = []
        _now = time.time()
        _owner_actor = ""
        try:
            _owner_actor = str(getattr(deps.social_model, "owner_id", "") or "") if deps.social_model is not None else ""
        except Exception:
            _owner_actor = ""
        for n in retrieved:
            line = format_memory(n, now=_now, actor_id=_actor, channel_id=_channel, owner_actor_id=_owner_actor)
            if not line:
                continue  # служебный узел без текста (outcome и т.п.) — не в промпт
            tag = ""
            if abs(n.valence) > 0.3:
                tag = " [позитивный момент]" if n.valence > 0 else " [негативный момент]"
            memory_summaries.append(f"{line[:520]}{tag}")
        memory_summaries.extend(extra_memory)

        speaker_label = interpretation.actor_label_used if interpretation is not None else (
            "Владелец" if is_owner else "Собеседник"
        )
        planning_input = LanguagePlanningInput(
            situation_summary=(
                f'{speaker_label} написал(а): "{situation.raw_text}"\n'
                f"(actor={situation.actor_id}, action={situation.action.value}, topic={situation.topic_id})"
            ),
            retrieved_memory_summaries=memory_summaries,
            active_belief_summaries=belief_summaries,
            chosen_action_type=action.type,
            goal_context_summary=", ".join(g.description for g in goal_set.active_goals()),
            style_prior=style_prior,
            constraints=constraints,
            relationship_context=relationship_context,
            is_owner=bool(is_owner),
            interpretation_summary=interpretation.summary_for_llm() if interpretation is not None else "",
        )
        generated_text, validation = deps.language_planner.plan_and_generate(action, planning_input, is_owner=is_owner)
        if not validation.ok:
            # §17: провалидированный конфликт с identity/belief — не отправляем как есть.
            # Минимальная стратегия: fallback на CLARIFY с пометкой в payload.
            action = Action(type=ActionType.CLARIFY, payload={"reason": "validation_failed", "violations": validation.violations})
            generated_text = None

    # 10. OBSERVE OUTCOME
    outcome: Outcome = outcome_fn(action, generated_text)

    # 11. CALCULATE ERROR (§6)
    prediction_error = compute_prediction_error(prediction, outcome, deps.prediction_error_weights)

    # 12. LEARN + UPDATE STATE (§1.2, §12)
    u_t = _build_u_t(observation, situation, retrieved, goal_set, prediction_error, deps.transition_model.u_dim)
    new_z = deps.transition_model.step(state.z, u_t)
    new_state = state.advance(new_z)

    # запись опыта в память (§5, §7)
    record = deps.experience.record_tick(
        observation_embedding=situation.embedding,
        situation_summary={
            "actor": situation.actor_id,
            # кто именно говорил и где — иначе воспоминание безымянно (см. memory/scope.py)
            "speaker": "Владелец" if is_owner else ((observation.metadata.get("actor_name") or "").strip() or "Собеседник"),
            "channel_id": str(observation.channel_id or ""),
            "is_owner": bool(is_owner),
            "action": situation.action.value,
            "said": interpretation.focal_text if interpretation is not None else situation.raw_text,
            "summary": generated_text or "",
            **({"interpretation": {
                "intent": interpretation.intent, "topic": interpretation.topic, "tone": interpretation.tone,
                "uncertainty": round(interpretation.uncertainty, 3),
            }} if interpretation is not None else {}),
        },
        action_type=action.type.value,
        outcome_embedding=situation.embedding,  # заглушка: без отдельного outcome-эмбеддера используем situation
        prediction_error=prediction_error,
        valence=situation.tone.valence,
        novelty=situation.novelty,
        goal_relevance=0.0,
    )
    memory_id = getattr(record, "observation_node_id", None)
    for rev in belief_revisions:
        b = deps.beliefs.get(rev.belief_id) if deps.beliefs is not None else None
        if b is not None and b.evidence:
            b.evidence[-1]["memory_id"] = memory_id
            b.support.append(memory_id)

    # побочные действия, которым нужна запись опыта (evidence -> memory id)
    if deps.executor is not None and interpretation is not None:
        for sa in secondary_actions:
            if sa.type == ActionType.REMEMBER:
                execution_results.append(deps.executor.remember(
                    interpretation, situation.actor_id,
                    evidence={"tick": state.tick, "memory_id": memory_id, "text": interpretation.focal_text[:200]}))
            elif sa.type == ActionType.FORGET:
                execution_results.append(deps.executor.forget(interpretation, situation.actor_id))

    # ожидание реакции: следующая реплика этого человека разрешит этот прогноз
    if deps.learner is not None and interpretation is not None and action.type in SPEAKING_ACTIONS:
        deps.learner.register(PendingTick(
            actor_id=situation.actor_id, tick=state.tick, intent=interpretation.intent,
            signatures=interpretation.signatures, action_type=action.type.value, prediction=prediction,
            belief_ids=[bid for bid, _ in relevant_belief_pairs], topic=interpretation.topic,
        ))

    meta = None
    if interpretation is not None:
        meta = build_tick_meta(
            state.tick, interpretation, decision, prediction, knowledge, relevant_beliefs,
            learning_report=learning_report, fallbacks_used=interpretation.fallbacks_used,
        )

    # §13 metacognition: грубый бинарный сигнал "поведение соответствовало
    # личности" — провал валидации identity/belief-инвариантов означает,
    # что сгенерированный ответ пришлось заменить на CLARIFY, т.е. явное
    # рассогласование между тем, что хотела сказать LLM, и personality/identity.
    behavior_matched_personality = not (
        action.type == ActionType.CLARIFY and action.payload.get("reason") == "validation_failed"
    )

    return TickResult(
        state=new_state,
        situation=situation,
        action=action,
        generated_text=generated_text,
        prediction_error=prediction_error,
        reasoning_mode=reasoning_mode,
        prediction=prediction,
        outcome=outcome,
        behavior_matched_personality=behavior_matched_personality,
        interpretation=interpretation,
        decision=decision,
        secondary_actions=secondary_actions,
        execution_results=execution_results,
        belief_revisions=belief_revisions,
        learning_report=learning_report,
        meta=meta,
        planning_input=planning_input,
    )


def _top_k_relevant_with_ids(beliefs, query_embedding, k: int = 5, actor_id: str = "", mode: str = "off"):
    """Как BeliefStore.top_k_relevant, но с id — чтобы при ошибке прогноза
    знать, КАКИЕ belief'ы были использованы в ответе."""
    import math as _m

    def _cos(a, b) -> float:
        an = _m.sqrt(sum(x * x for x in a))
        bn = _m.sqrt(sum(x * x for x in b))
        if not an or not bn:
            return 0.0
        return sum(x * y for x, y in zip(a, b)) / (an * bn)

    if query_embedding is None:
        return []
    scored = [(_cos(query_embedding, b.embedding), bid, b) for bid, b in beliefs.items()
              if b.is_active and belief_visible(b, actor_id=actor_id, mode=mode)]
    scored.sort(key=lambda t: t[0], reverse=True)
    return [(bid, b) for _, bid, b in scored[:k]]


def _reflection_node(deps, text: str):
    from ..memory.memory_graph import MemoryNode, NodeType
    embed = deps.embed_fn
    emb = embed(text) if embed is not None else np.zeros(1)
    return MemoryNode(type=NodeType.REFLECTION, embedding=emb, payload={"kind": "lesson", "summary": text}, valence=0.0)


def _build_u_t(observation, situation, retrieved, goal_set, prediction_error, u_dim: int) -> np.ndarray:
    """Конкатенация e(x_t), e(S_t), e(retrieval_t), g(G_t), eps_t -> ℝ^u_dim.
    Референсная реализация: усредняем эмбеддинги retrieved, добавляем
    situation.embedding, паддим/обрезаем до u_dim. Заменяется на настоящий
    learned adapter по мере роста системы (§12)."""
    parts = [situation.embedding]
    if retrieved:
        parts.append(np.mean([n.embedding for n in retrieved], axis=0))
    base = np.concatenate(parts) if len(parts) > 1 else parts[0]
    base = np.concatenate([base, np.array([prediction_error], dtype=np.float32)])
    if base.shape[0] >= u_dim:
        return base[:u_dim].astype(np.float32)
    pad = np.zeros(u_dim - base.shape[0], dtype=np.float32)
    return np.concatenate([base, pad]).astype(np.float32)
