"""
marin_core — новое когнитивное ядро Marin X.

Архитектура и формулы: см. MARIN_X_CORE_SPEC.md в корне репозитория.
Порядок реализации (см. §18 спеки):
    1. state/            — CognitiveState, LatentState
    2. engine/cycle.py    — один тик когнитивного цикла
    3. perception/        — Situation Model, Attention
    4. memory/            — Memory Graph, retrieval
    5. prediction/        — Predictor, prediction error
    6. decision/          — Decision Engine
    7. llm/               — LLM Interface
    8. остальное          — beliefs, hypotheses, social, metacognition, consolidation

Это ядро НЕ зависит от Telegram/vision/voice — оно подключается снаружи
через engine.cognitive_engine.CognitiveEngine.tick(observation).
"""

from .engine.cognitive_engine import CognitiveEngine
from .config import MarinConfig, load_config, build_llm_provider, build_engine

__all__ = ["CognitiveEngine", "MarinConfig", "load_config", "build_llm_provider", "build_engine"]
__version__ = "0.1.0"
