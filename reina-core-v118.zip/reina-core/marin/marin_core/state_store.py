"""StateStore — Marin's long-term memory survives restarts and redeploys.

Before this, MemoryGraph / beliefs / goals / world / relationships /
personality lived only in RAM: every restart or deploy wiped them (only the
diary, the Telegram observer and registries were on disk). The export/import
code already existed (persistence.py) but ran only on a manual /export.

StateStore:
  * ``load_into(engine)`` — at startup, BEFORE anything writes facts, so ids
    from the snapshot are restored as-is (import is id-keyed → idempotent);
  * ``save(engine)``      — atomic write (tmp + fsync + os.replace) with
    rotating backups ``.bak1..N``; a corrupted main file falls back to the
    newest readable backup;
  * ``changed(engine)``   — cheap fingerprint so autosave only writes when
    something actually changed.
"""
from __future__ import annotations

import json
import logging
import os
import time
from typing import Dict, Optional

from . import persistence
from .goals.goals import GoalLevel

logger = logging.getLogger("marin_core.state_store")


class StateStore:
    def __init__(self, path: str, backups: int = 3):
        self.path = os.path.abspath(path)
        self.backups = max(0, int(backups))
        self._last_fingerprint: Optional[tuple] = None
        self.last_saved_at: Optional[float] = None

    # -------------------------------------------------------------- helpers
    @staticmethod
    def fingerprint(engine) -> tuple:
        return (
            len(engine.memory),
            len(engine.beliefs._beliefs),
            len(engine.goal_set.goals),
            sum(int(getattr(g, "current_step", 0) or 0) for g in engine.goal_set.goals.values()),
            len(engine.world.entities),
            len(engine.social._nodes),
            getattr(getattr(engine, "state", None), "tick", 0),
            len(engine.beliefs.contradictions),
            # обучение меняет паттерны/Q без изменения размеров остальных структур
            sum(int(v.n) for v in getattr(getattr(engine, "learner", None), "action_values", None).values.values())
            if getattr(engine, "learner", None) is not None else 0,
        )

    def changed(self, engine) -> bool:
        return self.fingerprint(engine) != self._last_fingerprint

    @staticmethod
    def _snapshot(engine) -> dict:
        # Экспорт идёт в потоке событий, а тик может параллельно менять
        # словари в рабочем потоке — при «dict changed size» просто повторяем.
        last_exc: Optional[Exception] = None
        for _ in range(5):
            try:
                data = persistence.export_engine_state(engine)
                state = getattr(engine, "state", None)
                data["cognitive_tick"] = int(getattr(state, "tick", 0) or 0)
                return data
            except RuntimeError as exc:
                last_exc = exc
                time.sleep(0.05)
        raise RuntimeError("could not take a consistent snapshot") from last_exc

    # ----------------------------------------------------------------- save
    def save(self, engine) -> int:
        data = self._snapshot(engine)
        payload = json.dumps(data, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
        tmp = f"{self.path}.tmp"
        with open(tmp, "wb") as fh:
            fh.write(payload)
            fh.flush()
            os.fsync(fh.fileno())
        if self.backups and os.path.exists(self.path):
            for i in range(self.backups, 1, -1):
                older, newer = f"{self.path}.bak{i}", f"{self.path}.bak{i - 1}"
                if os.path.exists(newer):
                    os.replace(newer, older)
            os.replace(self.path, f"{self.path}.bak1")
        os.replace(tmp, self.path)
        self._last_fingerprint = self.fingerprint(engine)
        self.last_saved_at = time.time()
        return len(payload)

    # ----------------------------------------------------------------- load
    def _candidates(self):
        yield self.path
        for i in range(1, self.backups + 1):
            yield f"{self.path}.bak{i}"

    def load_into(self, engine) -> Optional[Dict[str, int]]:
        for candidate in self._candidates():
            if not os.path.exists(candidate):
                continue
            try:
                with open(candidate, "r", encoding="utf-8") as fh:
                    data = json.load(fh)
                counts = persistence.import_engine_state(engine, data)
            except Exception:
                logger.exception("[STATE] snapshot %s unreadable — trying older backup", candidate)
                continue
            tick = int(data.get("cognitive_tick", 0) or 0)
            state = getattr(engine, "state", None)
            if state is not None and tick > getattr(state, "tick", 0):
                try:
                    state.tick = tick
                except Exception:  # frozen dataclass
                    import dataclasses
                    engine.state = dataclasses.replace(state, tick=tick)
            self._dedupe_identity_goals(engine)
            self._last_fingerprint = self.fingerprint(engine)
            logger.info("[STATE] restored from %s: %s", candidate, counts)
            return counts
        return None

    @staticmethod
    def _dedupe_identity_goals(engine) -> None:
        """Движок при создании всегда добавляет IDENTITY-цель со случайным id —
        без этого после каждого рестарта их копилось бы на одну больше."""
        seen = {}
        for gid, g in list(engine.goal_set.goals.items()):
            if g.level != GoalLevel.IDENTITY:
                continue
            key = g.description.strip().lower()
            if key in seen:
                # оставляем более старую (восстановленную) цель
                keep = seen[key]
                older, newer = sorted((keep, gid), key=lambda x: engine.goal_set.goals[x].created_at
                                      if hasattr(engine.goal_set.goals[x], "created_at") else 0)
                engine.goal_set.goals.pop(newer, None)
                seen[key] = older
            else:
                seen[key] = gid
