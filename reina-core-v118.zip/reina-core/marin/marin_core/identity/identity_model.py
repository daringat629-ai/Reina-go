"""
Identity Model — §4 спеки. Identity != Personality != State (текущее z_t).
Обновляется крайне редко и только через явный reflective conflict (§13),
не через обычный learning loop.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional
import time
from ..numeric import np


@dataclass
class Invariant:
    """Жёсткое ограничение идентичности, используется в action/validation.py."""

    name: str
    description: str
    forbidden_if_present: Optional[str] = None  # простая текстовая проверка для холодного старта
    applies_to_owner: bool = True  # False — ограничение снимается в общении с владельцем (§ owner exception)


@dataclass
class IdentityChangeRecord:
    """§23 (Temporal Self): история изменений идентичности — "раньше я
    считала X, потом получила Y, теперь считаю Z"."""

    t: float
    reason: str
    before_summary: str
    after_summary: str


@dataclass
class IdentityModel:
    name: str
    core_values: List[str] = field(default_factory=list)
    invariants: List[Invariant] = field(default_factory=list)
    self_narrative_embedding: Optional[np.ndarray] = None
    history: List[IdentityChangeRecord] = field(default_factory=list)
    owner_description: Optional[str] = None  # роль владельца в self-narrative — значимая фигура, не просто ещё один актор

    update_rate: float = 1e-4  # §4.1 — почти неизменна

    def propose_change(self, reason: str, before_summary: str, after_summary: str) -> None:
        """Единственный легитимный путь изменения идентичности — явная
        запись, инициируемая metacognition (§13) после устойчивого,
        подтверждённого конфликта. Никогда не вызывается из обычного тика."""
        self.history.append(
            IdentityChangeRecord(t=time.time(), reason=reason, before_summary=before_summary, after_summary=after_summary)
        )

    def invariant_names(self) -> List[str]:
        return [i.name for i in self.invariants]
