"""
Personality Dynamics — §4 спеки. Личность = приор распределения над
поведением (behavior_tendency = softmax(trait_priors ⊕ g(z_t, S_t))),
а не статичные числа warmth/playfulness. Меняется медленно (EMA, §4.1/§12).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, Optional
from ..numeric import np

from ..perception.attention import AttentionWeights


def _softmax(x: np.ndarray) -> np.ndarray:
    x = x - x.max()
    e = np.exp(x)
    return e / e.sum()


@dataclass
class PersonalityDynamics:
    trait_priors: Dict[str, float] = field(default_factory=dict)  # напр. {"warmth": 0.6, "curiosity": 0.7, ...}
    attention_weights: AttentionWeights = field(default_factory=AttentionWeights)
    style_prior: Dict[str, str] = field(default_factory=dict)  # для §17 LanguagePlanningInput.style_prior — общение по умолчанию
    owner_style_prior: Dict[str, str] = field(default_factory=dict)  # используется вместо style_prior, когда собеседник — владелец

    update_rate: float = 1e-3  # §4.1
    # Anchor Core: базовые значения черт личности, зафиксированные при
    # создании. Защита от когнитивного дрейфа — сколько бы маленьких EMA-
    # сдвигов ни накопилось за долгий аптайм при постоянной саморефлексии,
    # ни одна черта не может уехать от своего якоря дальше max_drift.
    _anchor_trait_priors: Dict[str, float] = field(default_factory=dict, repr=False)
    max_drift: float = 0.25

    def __post_init__(self) -> None:
        if not self._anchor_trait_priors:
            self._anchor_trait_priors = dict(self.trait_priors)

    def behavior_tendency(self, z_projection: np.ndarray, combine_fn: Optional[Callable] = None) -> Dict[str, float]:
        """behavior_tendency = softmax(trait_priors ⊕ g(z_t, S_t)), §4.

        combine_fn(prior_vector, z_projection) -> combined_vector; по
        умолчанию — простая сумма (⊕ = +), MLP-комбинация подключается
        отдельно, когда появится обучаемый компонент."""
        keys = list(self.trait_priors.keys())
        if not keys:
            return {}
        prior_vec = np.array([self.trait_priors[k] for k in keys], dtype=np.float32)

        if combine_fn is not None:
            combined = combine_fn(prior_vec, z_projection)
        else:
            # без обучаемого g() — используем среднее z_projection как скалярный сдвиг
            shift = float(np.mean(z_projection)) if z_projection.size else 0.0
            combined = prior_vec + shift

        probs = _softmax(combined)
        return dict(zip(keys, probs.tolist()))

    def update_from_observed_signal(self, observed_trait_signal: Dict[str, float]) -> None:
        """§4.1 EMA: Personality_{t+1} = Personality_t + alpha * (signal - Personality_t).
        observed_trait_signal берётся из metacognition (§13): было ли
        поведение согласовано с личностью или было ситуативным отклонением.

        Anchor Core: результат зажимается в [anchor - max_drift, anchor +
        max_drift] — EMA сама по себе не даёт "убежать" резко за один раз,
        но за очень долгий аптайм с частой саморефлексией мелкие сдвиги в
        одну сторону могли бы накопиться в заметный дрейф личности. Якорь
        не даёт этому случиться, не мешая обычной медленной адаптации."""
        for k, signal in observed_trait_signal.items():
            current = self.trait_priors.get(k, signal)
            updated = current + self.update_rate * (signal - current)
            anchor = self._anchor_trait_priors.get(k, updated)
            updated = max(anchor - self.max_drift, min(anchor + self.max_drift, updated))
            self.trait_priors[k] = updated
