"""
Persistence — единый экспорт/импорт состояния ядра Marin в один файл.

До этого модуля на диск сохранялись только diary.py, telegram/observer.py
(люди/события) и media_packs registry в telegram/client.py — MemoryGraph,
BeliefStore, GoalSet, WorldModel, SocialModel/relationship и personality
жили только в оперативной памяти процесса и терялись при каждом рестарте.

Референсная сериализация — dataclasses.asdict() + json: marin_core/numeric.py
намеренно чистый Python без numpy (см. его докстринг), поэтому embeddings
(Vector, подкласс list) сериализуются в JSON напрямую, без конвертации.

Используется командой /export в telegram/client.py, которая объединяет
экспорт этого модуля с Telegram-specific данными (observer, media packs)
в один файл — и автозагрузкой при старте, если такой файл найден рядом
с кодом (см. MARIN_STATE_IMPORT_FILE в client.py).
"""

from __future__ import annotations

import dataclasses
import time
from typing import Any, Dict, Optional

from .numeric import np

from .memory.memory_graph import MemoryGraph, MemoryNode, NodeType, Edge, RelationType
from .belief.beliefs import BeliefStore, Belief, SourceType, ContradictionFlag
from .goals.goals import GoalSet, Goal, GoalLevel, GoalStatus
from .world.world_model import WorldModel
from .world.entities import Entity, EntityKind, Relation
from .world.events import WorldEvent
from .world.causal_model import CausalLink
from .social.social_model import SocialModel, SocialNode
from .social.relationship import RelationshipState

EXPORT_FORMAT_VERSION = 1


# ---- Memory Graph ----------------------------------------------------

def export_memory(graph: MemoryGraph) -> dict:
    nodes = []
    for n in graph.all_nodes():
        d = dataclasses.asdict(n)
        d["type"] = n.type.value
        d["embedding"] = list(n.embedding)
        d["edges"] = [{"relation": e.relation.value, "target_id": e.target_id, "weight": e.weight} for e in n.edges]
        nodes.append(d)
    return {"nodes": nodes}


def import_memory(graph: MemoryGraph, data: dict) -> int:
    count = 0
    for nd in data.get("nodes", []):
        nd = dict(nd)
        nd["type"] = NodeType(nd["type"])
        nd["embedding"] = np.array(nd["embedding"])
        nd["edges"] = [
            Edge(relation=RelationType(e["relation"]), target_id=e["target_id"], weight=e.get("weight", 1.0))
            for e in nd.get("edges", [])
        ]
        node = MemoryNode(**nd)
        graph._nodes[node.id] = node  # напрямую, чтобы сохранить оригинальный id
        count += 1
    return count


# ---- Beliefs -----------------------------------------------------------

def export_beliefs(store: BeliefStore) -> dict:
    beliefs = {}
    for bid, b in store._beliefs.items():
        d = dataclasses.asdict(b)
        d["embedding"] = list(b.embedding)
        d["source_type"] = b.source_type.value
        beliefs[bid] = d
    contradictions = [dataclasses.asdict(c) for c in store.contradictions]
    return {"beliefs": beliefs, "contradictions": contradictions, "id_counter": store._id_counter}


_BELIEF_FIELDS = {f.name for f in dataclasses.fields(Belief)}
_FLAG_FIELDS = {f.name for f in dataclasses.fields(ContradictionFlag)}


def import_beliefs(store: BeliefStore, data: dict) -> int:
    count = 0
    for bid, d in data.get("beliefs", {}).items():
        d = {k: v for k, v in dict(d).items() if k in _BELIEF_FIELDS}
        d["embedding"] = np.array(d["embedding"])
        d["source_type"] = SourceType(d["source_type"])
        store._beliefs[bid] = Belief(**d)
        count += 1
    store.contradictions = [
        ContradictionFlag(**{k: v for k, v in c.items() if k in _FLAG_FIELDS})
        for c in data.get("contradictions", [])
    ]
    store._id_counter = max(store._id_counter, int(data.get("id_counter", 0)))
    return count


# ---- Goals ---------------------------------------------------------------

def export_goals(goal_set: GoalSet) -> dict:
    return {
        "goals": {
            gid: {**dataclasses.asdict(g), "level": g.level.value, "status": g.status.value}
            for gid, g in goal_set.goals.items()
        }
    }


def import_goals(goal_set: GoalSet, data: dict) -> int:
    count = 0
    for gid, d in data.get("goals", {}).items():
        d = dict(d)
        d["level"] = GoalLevel(d["level"])
        if "status" in d and d["status"] is not None:
            d["status"] = GoalStatus(d["status"])
        goal_set.goals[gid] = Goal(**d)
        count += 1
    return count


# ---- World Model -----------------------------------------------------

def export_world(world: WorldModel) -> dict:
    return {
        "entities": {eid: {**dataclasses.asdict(e), "kind": e.kind.value} for eid, e in world.entities.items()},
        "relations": [dataclasses.asdict(r) for r in world.relations],
        "events": {eid: dataclasses.asdict(ev) for eid, ev in world.events.items()},
        "causal_links": [dataclasses.asdict(l) for l in world.causal._links.values()],
        "last_event_by_entity": {k: list(v) for k, v in world.last_event_by_entity.items()},
    }


def import_world(world: WorldModel, data: dict) -> int:
    count = 0
    for eid, d in data.get("entities", {}).items():
        d = dict(d)
        d["kind"] = EntityKind(d["kind"])
        world.entities[eid] = Entity(**d)
        count += 1
    world.relations = [Relation(**r) for r in data.get("relations", [])]
    for eid, d in data.get("events", {}).items():
        world.events[eid] = WorldEvent(**d)
    for link in data.get("causal_links", []):
        cl = CausalLink(**link)
        world.causal._links[(cl.cause_event_id, cl.effect_event_id)] = cl
    world.last_event_by_entity = {k: list(v) for k, v in data.get("last_event_by_entity", {}).items()}
    return count


# ---- Social / Relationship ------------------------------------------

def export_social(social: SocialModel) -> dict:
    nodes = {}
    for eid, node in social._nodes.items():
        nodes[eid] = {
            "beliefs_about_them": list(node.beliefs_about_them),
            "relationship": dataclasses.asdict(node.relationship),
        }
    return {"nodes": nodes, "owner_id": social.owner_id}


def import_social(social: SocialModel, data: dict) -> int:
    count = 0
    for eid, d in data.get("nodes", {}).items():
        rel = RelationshipState(**d["relationship"])
        social._nodes[eid] = SocialNode(
            entity_id=eid, beliefs_about_them=list(d.get("beliefs_about_them", [])), relationship=rel
        )
        count += 1
    social.owner_id = data.get("owner_id")
    return count


# ---- Personality -------------------------------------------------------

def export_personality(personality) -> dict:
    if personality is None:
        return {}
    return {
        "trait_priors": dict(personality.trait_priors),
        "style_prior": dict(personality.style_prior),
        "owner_style_prior": dict(personality.owner_style_prior),
    }


def import_personality(personality, data: dict) -> None:
    if personality is None or not data:
        return
    personality.trait_priors.update(data.get("trait_priors", {}))
    personality.style_prior.update(data.get("style_prior", {}))
    personality.owner_style_prior.update(data.get("owner_style_prior", {}))


# ---- Целиком движок ------------------------------------------------------

def export_engine_state(engine) -> dict:
    """Полный снимок ядра одним словарём — БЕЗ Telegram-специфичных данных
    (observer/media packs), которые бандлятся отдельно в telegram/client.py
    (команда /export) в один общий файл."""
    return {
        "format_version": EXPORT_FORMAT_VERSION,
        "exported_at": time.time(),
        "memory": export_memory(engine.memory),
        "beliefs": export_beliefs(engine.beliefs),
        "goals": export_goals(engine.goal_set),
        "world": export_world(engine.world),
        "social": export_social(engine.social),
        "personality": export_personality(engine.personality),
        # выученное: паттерны интерпретации, Q(intent, action), социальные поправки
        "learning": engine.learner.export() if getattr(engine, "learner", None) is not None else {},
    }


def import_engine_state(engine, data: dict) -> Dict[str, int]:
    """Возвращает счётчики импортированного — для честного отчёта владельцу,
    сколько реально загрузилось, а не просто "готово"."""
    n_memory = import_memory(engine.memory, data.get("memory", {}))
    n_beliefs = import_beliefs(engine.beliefs, data.get("beliefs", {}))
    n_goals = import_goals(engine.goal_set, data.get("goals", {}))
    n_world = import_world(engine.world, data.get("world", {}))
    n_social = import_social(engine.social, data.get("social", {}))
    import_personality(engine.personality, data.get("personality", {}))
    learned = {}
    if getattr(engine, "learner", None) is not None and data.get("learning"):
        learned = engine.learner.load(data.get("learning", {}))
    return {
        "learned_patterns": learned.get("patterns", 0),
        "learned_action_values": learned.get("action_values", 0),
        "memory_nodes": n_memory,
        "beliefs": n_beliefs,
        "goals": n_goals,
        "world_entities": n_world,
        "social_nodes": n_social,
    }
