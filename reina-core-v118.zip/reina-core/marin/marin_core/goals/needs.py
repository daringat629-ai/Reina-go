"""
Needs — §10.2 спеки. НЕ показываются пользователю и не управляют текстом
напрямую (не "Sims-полоски") — входят в goal_utility как модулятор веса целей.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, Dict


class NeedType(str, Enum):
    EXPLORATION = "exploration"
    SOCIAL_CONNECTION = "social_connection"
    CONSISTENCY = "consistency"
    NOVELTY = "novelty"
    COMPLETION = "completion"
    INFORMATION = "information"
    REST = "rest"
    SAFETY = "safety"
    SELF_MAINTENANCE = "self_maintenance"


DEFAULT_DRIFT: Dict[NeedType, float] = {
    NeedType.EXPLORATION: 0.01,
    NeedType.SOCIAL_CONNECTION: 0.015,
    NeedType.CONSISTENCY: 0.005,
    NeedType.NOVELTY: 0.01,
    NeedType.COMPLETION: 0.01,
    NeedType.INFORMATION: 0.01,
    NeedType.REST: 0.008,
    NeedType.SAFETY: 0.003,
    NeedType.SELF_MAINTENANCE: 0.003,
}


@dataclass
class NeedState:
    """§10.2: Need_i(t+1) = Need_i(t) + delta_i - satisfaction_i(action_t)."""

    values: Dict[NeedType, float] = field(default_factory=lambda: {n: 0.3 for n in NeedType})
    drift: Dict[NeedType, float] = field(default_factory=lambda: dict(DEFAULT_DRIFT))

    def step(self, satisfaction: Dict[NeedType, float]) -> None:
        for n in NeedType:
            delta = self.drift.get(n, 0.0)
            sat = satisfaction.get(n, 0.0)
            self.values[n] = max(0.0, min(1.0, self.values[n] + delta - sat))

    def as_goal_modulation(self) -> Dict[NeedType, float]:
        """Возвращает текущие значения как множители для goal_utility (§10.3):
        высокая неудовлетворённая потребность повышает вес связанных целей."""
        return dict(self.values)
