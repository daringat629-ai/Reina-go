"""
Motivation — §10.3 спеки: goal utility и явный conflict_penalty между целями.
Используется decision_engine.py при выборе действия.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Dict, List

from .goals import Goal, GoalSet


@dataclass
class ActionCandidate:
    action_type: str
    cost: float = 0.1
    expected_progress: Dict[str, float] = None  # goal_id -> expected progress delta

    def __post_init__(self):
        if self.expected_progress is None:
            self.expected_progress = {}


def utility(
    action: ActionCandidate,
    goal_set: GoalSet,
    conflict_penalty_fn: Callable[[ActionCandidate, Goal, Goal], float] = lambda a, g1, g2: 0.0,
) -> float:
    """§10.3:
    utility(action) = sum_g w_g * expected_progress(action,g) - cost(action)
                       - sum conflict_penalty(action, g, g')
    """
    active = goal_set.active_goals()
    progress_term = sum(g.weight * action.expected_progress.get(g.id, 0.0) for g in active)

    conflict_term = 0.0
    for i, g1 in enumerate(active):
        for g2 in active[i + 1 :]:
            conflict_term += conflict_penalty_fn(action, g1, g2)

    return progress_term - action.cost - conflict_term


def default_conflict_penalty(action: ActionCandidate, g1: Goal, g2: Goal) -> float:
    """Пример конфликта: прогресс по одной цели предсказуемо вредит другой.
    Эвристика по умолчанию: если действие продвигает g1, но g2 требует
    противоположного прогресса (proxy: expected_progress с разным знаком
    на связанных целях) — штраф пропорционален произведению весов."""
    p1 = action.expected_progress.get(g1.id, 0.0)
    p2 = action.expected_progress.get(g2.id, 0.0)
    if p1 * p2 < 0:
        return abs(p1 * p2) * (g1.weight + g2.weight) / 2
    return 0.0


def rank_actions(actions: List[ActionCandidate], goal_set: GoalSet) -> List[ActionCandidate]:
    scored = [(utility(a, goal_set, default_conflict_penalty), a) for a in actions]
    scored.sort(key=lambda pair: pair[0], reverse=True)
    return [a for _, a in scored]
