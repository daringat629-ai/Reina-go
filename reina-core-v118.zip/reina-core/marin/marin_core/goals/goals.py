"""
Goals — §10.1 спеки. Иерархия: IdentityGoals -> LongTermGoals -> CurrentGoals
-> SituationalGoals. Конфликт целей обрабатывается в goals/motivation.py
(utility, §10.3) — здесь только структура и progress tracking.

Stage 4 (autonomous goal execution): LONG_TERM-цели расширены полями для
многошагового автономного выполнения (план, текущий шаг, статус,
расписание). Это те же Goal/GoalSet — НЕ вторая система целей: обычные
IDENTITY/CURRENT/SITUATIONAL цели просто не используют новые поля (у них
остаются дефолты) и ведут себя как прежде.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional
import time
import uuid


class GoalLevel(str, Enum):
    IDENTITY = "identity"      # почти статичны
    LONG_TERM = "long_term"    # недели/месяцы
    CURRENT = "current"        # активная сессия/тема
    SITUATIONAL = "situational"  # этот обмен репликами


class GoalStatus(str, Enum):
    """Только для автономных (обычно LONG_TERM) целей — см. Stage 4.
    Обычные CURRENT/SITUATIONAL/IDENTITY цели этим полем не пользуются."""
    PENDING = "pending"
    PLANNING = "planning"
    RUNNING = "running"
    WAITING = "waiting"      # ждёт подтверждения владельца на текущем шаге
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class Goal:
    description: str
    level: GoalLevel
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    weight: float = 1.0          # w_g в utility (§10.3)
    progress: float = 0.0        # 0..1
    active: bool = True
    parent_id: Optional[str] = None  # ссылка на цель уровня выше, которой это служит

    # -- Stage 4: autonomous goal execution (используется только теми
    # целями, у которых реально есть план — обычные цели эти поля просто
    # не трогают, дефолты ни на что не влияют) --------------------------
    owner_id: Optional[str] = None
    status: GoalStatus = GoalStatus.PENDING
    plan: List[Dict[str, Any]] = field(default_factory=list)       # список шагов (см. goal_executor.py)
    current_step: int = 0
    total_steps: int = 0
    cycle_start_step: Optional[int] = None  # с какого шага начинается повторяющийся цикл (content loop)
    next_action: Optional[Dict[str, Any]] = None  # что предложено на этом шаге, ждёт confirmation
    last_execution: Optional[float] = None
    next_execution: Optional[float] = None
    last_result: Optional[str] = None
    failure_count: int = 0
    retry_count: int = 0
    max_retries: int = 5
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    context: Dict[str, Any] = field(default_factory=dict)  # goal_context — channel_id и т.п.
    auto_approve: bool = True  # автономные цели публикуют контент без ручного подтверждения; опасные действия всё равно не входят в SAFE_AUTO_APPROVE_KINDS


@dataclass
class GoalSet:
    """Все активные цели субъекта на текущий тик."""

    goals: Dict[str, Goal] = field(default_factory=dict)

    def add(self, goal: Goal) -> str:
        self.goals[goal.id] = goal
        return goal.id

    def active_goals(self, level: Optional[GoalLevel] = None) -> List[Goal]:
        result = [g for g in self.goals.values() if g.active]
        if level is not None:
            result = [g for g in result if g.level == level]
        return result

    def update_progress(self, goal_id: str, delta: float) -> None:
        if goal_id in self.goals:
            g = self.goals[goal_id]
            g.progress = max(0.0, min(1.0, g.progress + delta))
            if g.progress >= 1.0 and g.level == GoalLevel.SITUATIONAL:
                g.active = False

    def prune_completed_situational(self) -> None:
        """Ситуационные цели живут один тик/обмен репликами — вызывается
        в конце тика (engine/cycle.py) для очистки перед следующим циклом."""
        for g in list(self.goals.values()):
            if g.level == GoalLevel.SITUATIONAL and not g.active:
                del self.goals[g.id]

    # -- Stage 4: autonomous goal lifecycle --------------------------------

    def autonomous_goals(self, owner_id: Optional[str] = None) -> List[Goal]:
        """Все цели, созданные как автономные (через add_autonomous_goal),
        отличает их от обычных identity/current/situational целей. НЕ по
        bool(g.plan) — у только что созданной, ещё не спланированной цели
        план пуст, а она всё равно должна попадать в due-проверку, иначе
        планирование никогда не запустится."""
        result = [g for g in self.goals.values() if g.active and g.owner_id is not None]
        if owner_id is not None:
            result = [g for g in result if str(g.owner_id) == str(owner_id)]
        return result

    def due_autonomous_goals(self, now: Optional[float] = None, owner_id: Optional[str] = None) -> List[Goal]:
        """Автономные цели, для которых пора сделать следующий шаг —
        используется Scheduler'ом (см. _advance_autonomous_goals в client.py)."""
        now = now if now is not None else time.time()
        runnable = {GoalStatus.PENDING, GoalStatus.PLANNING, GoalStatus.RUNNING, GoalStatus.WAITING}
        return [
            g for g in self.autonomous_goals(owner_id)
            if g.status in runnable and (g.next_execution is None or now >= g.next_execution)
        ]

    def pause_goal(self, goal_id: str) -> bool:
        g = self.goals.get(goal_id)
        if g is None or g.owner_id is None:
            return False
        g.status = GoalStatus.PAUSED
        g.updated_at = time.time()
        return True

    def resume_goal(self, goal_id: str) -> bool:
        g = self.goals.get(goal_id)
        if g is None or g.owner_id is None or g.status != GoalStatus.PAUSED:
            return False
        g.status = GoalStatus.RUNNING
        g.next_execution = time.time()
        g.updated_at = time.time()
        return True

    def cancel_goal(self, goal_id: str) -> bool:
        g = self.goals.get(goal_id)
        if g is None or g.owner_id is None:
            return False
        g.status = GoalStatus.CANCELLED
        g.active = False
        g.updated_at = time.time()
        return True
