"""
Situation Model — §2 спеки. Структурированное представление "что сейчас
происходит", строится ДО принятия решений (не message -> LLM -> answer,
а message -> perception -> situation -> interpretation -> decision).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, List, Optional
from ..numeric import np


class ActionType(str, Enum):
    """Тип действия актора в наблюдении (не путать с action/ — действием Marin)."""

    ASK_QUESTION = "ask_question"
    STATEMENT = "statement"
    REQUEST = "request"
    REACTION = "reaction"
    GREETING = "greeting"
    SMALL_TALK = "small_talk"
    OTHER = "other"


@dataclass
class Tone:
    valence: float = 0.0   # -1..1
    energy: float = 0.0    # 0..1


@dataclass
class SituationModel:
    """Один инстанс = S_t из спеки."""

    actor_id: str
    action: ActionType
    topic_id: Optional[str] = None
    tone: Tone = field(default_factory=Tone)
    context_refs: List[str] = field(default_factory=list)      # id событий/сообщений, на которые ссылается x_t
    goal_hint: Optional[str] = None
    novelty: float = 0.0
    relationship_relevance: float = 0.0
    is_owner: bool = False   # заполняется в engine/cycle.py на основе SocialModel/observation.metadata
    raw_text: str = ""       # сырой текст наблюдения (observation.content) — то, что реально сказал собеседник;
                              # ДО этого поля actual message text никуда не попадал в LLM-промпт, только мета-теги
    embedding: Optional[np.ndarray] = None  # e(S_t), см. §1.2 и §3
    interpretation: Optional[Any] = None     # interpretation.Interpretation, заполняется на шаге INTERPRET


def novelty_score(x_embedding: np.ndarray, recent_memory_embeddings: List[np.ndarray]) -> float:
    """§2.1: novelty(x_t) = 1 - max_k sim(e(x_t), e(m_k))."""
    if not recent_memory_embeddings:
        return 1.0
    sims = []
    xn = x_embedding / (np.linalg.norm(x_embedding) + 1e-8)
    for m in recent_memory_embeddings:
        mn = m / (np.linalg.norm(m) + 1e-8)
        sims.append(float(np.dot(xn, mn)))
    return 1.0 - max(sims)


class SituationBuilder:
    """§2.2 пайплайн: NER/entity linking -> action classification ->
    topic linking -> tone estimation -> context linking -> novelty scoring.

    Каждый под-шаг — отдельный вызов reasoning engine в fast_reasoning
    режиме (§9), не один большой LLM-промпт. Здесь — оркестрация;
    конкретные классификаторы подключаются как зависимости (DI), чтобы
    их можно было менять независимо от ядра.
    """

    def __init__(self, entity_linker, action_classifier, topic_linker, tone_estimator, context_linker, embedder):
        self.entity_linker = entity_linker
        self.action_classifier = action_classifier
        self.topic_linker = topic_linker
        self.tone_estimator = tone_estimator
        self.context_linker = context_linker
        self.embedder = embedder

    def build(self, observation, recent_memory_embeddings: List[np.ndarray]) -> SituationModel:
        actor_id = self.entity_linker.resolve_actor(observation)
        action = self.action_classifier.classify(observation)
        topic_id = self.topic_linker.link(observation)
        tone = self.tone_estimator.estimate(observation)
        context_refs = self.context_linker.link(observation)
        embedding = self.embedder.embed(observation)
        novelty = novelty_score(embedding, recent_memory_embeddings)

        return SituationModel(
            actor_id=actor_id,
            action=action,
            topic_id=topic_id,
            tone=tone,
            context_refs=context_refs,
            goal_hint=None,  # заполняется на шаге interpretation, не здесь
            novelty=novelty,
            relationship_relevance=0.0,  # заполняется social/ модулем
            raw_text=observation.content,
            embedding=embedding,
        )
