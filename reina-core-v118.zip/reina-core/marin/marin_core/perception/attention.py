"""
Attention — §3 спеки. Не модуль хранения, а скоринговая функция над
кандидатами (память / факты мира / цели), которая решает, что уходит
в retrieval на этот тик. Веса w1..w6 — часть Personality (personality
по-разному расставляет внимание), см. identity/personality_dynamics.py.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, List, Protocol
from ..numeric import np


@dataclass
class AttentionWeights:
    """w1..w6 из §3. Хранится внутри Personality, здесь — дефолт."""

    w_situation_relevance: float = 1.0
    w_goal_relevance: float = 1.0
    w_recency: float = 0.6
    w_novelty: float = 0.5
    w_conflict: float = 0.8   # danger_or_conflict — конфликт с belief/identity приоритетен
    w_social_salience: float = 0.4


class AttentionCandidate(Protocol):
    embedding: np.ndarray
    t_last_access: float
    id: str


def _cos_sim(a: np.ndarray, b: np.ndarray) -> float:
    an, bn = np.linalg.norm(a), np.linalg.norm(b)
    if an == 0 or bn == 0:
        return 0.0
    return float(np.dot(a, b) / (an * bn))


def attention_score(
    candidate_embedding: np.ndarray,
    situation_embedding: np.ndarray,
    goal_relevance: float,
    recency: float,
    novelty: float,
    danger_or_conflict: float,
    social_salience: float,
    weights: AttentionWeights,
) -> float:
    """§3 формула attention_score."""
    return (
        weights.w_situation_relevance * _cos_sim(candidate_embedding, situation_embedding)
        + weights.w_goal_relevance * goal_relevance
        + weights.w_recency * recency
        + weights.w_novelty * novelty
        + weights.w_conflict * danger_or_conflict
        + weights.w_social_salience * social_salience
    )


def select_top_n(
    candidates: List[dict],
    situation_embedding: np.ndarray,
    weights: AttentionWeights,
    n: int,
) -> List[dict]:
    """candidates: список dict с ключами embedding, goal_relevance, recency,
    novelty, danger_or_conflict, social_salience, и произвольной полезной
    нагрузкой (payload). Возвращает top-N по attention_score, убывание."""
    scored = []
    for c in candidates:
        s = attention_score(
            c["embedding"],
            situation_embedding,
            c.get("goal_relevance", 0.0),
            c.get("recency", 0.0),
            c.get("novelty", 0.0),
            c.get("danger_or_conflict", 0.0),
            c.get("social_salience", 0.0),
            weights,
        )
        scored.append((s, c))
    scored.sort(key=lambda pair: pair[0], reverse=True)
    return [c for _, c in scored[:n]]
