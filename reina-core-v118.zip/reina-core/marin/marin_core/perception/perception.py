"""
Perception — входная точка цикла (см. схему в исходном документе, блок
PERCEPTION -> SITUATION MODEL). Нормализует разнородные входы
(текст/vision/voice — подключаются снаружи ядра) в единый Observation,
из которого дальше строится SituationModel (situation.py).

Само ядро не знает про Telegram/vision-модели — сюда приходит уже
извлечённый текст/описание, а не сырые байты.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, Optional
import time


class Modality(str, Enum):
    TEXT = "text"
    IMAGE_DESCRIPTION = "image_description"
    VOICE_TRANSCRIPT = "voice_transcript"
    SYSTEM_EVENT = "system_event"


@dataclass
class Observation:
    """x_t из спеки."""

    modality: Modality
    content: str
    source_actor_id: str
    channel_id: str                      # id чата/канала (для local vs global контекста)
    t_observed: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)


class PerceptionAdapter:
    """Точка расширения: конкретные интеграции (Telegram-текст, ASR-выход,
    vision-caption) реализуют свой `normalize(...)`, возвращающий Observation.
    Cognitive Engine работает только с Observation, не с исходными форматами.
    """

    def normalize(self, raw_input: Any, *, channel_id: str, source_actor_id: str) -> Observation:
        raise NotImplementedError


class TextPerceptionAdapter(PerceptionAdapter):
    def normalize(self, raw_input: Any, *, channel_id: str, source_actor_id: str) -> Observation:
        return Observation(
            modality=Modality.TEXT,
            content=str(raw_input),
            source_actor_id=source_actor_id,
            channel_id=channel_id,
        )
