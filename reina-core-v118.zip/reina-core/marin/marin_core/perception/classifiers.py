"""
Реальные компоненты SituationBuilder (раньше в критическом пути стояли
_Default* эвристики из engine/cognitive_engine.py: "?" в конце -> вопрос,
пара слов-маркеров -> тон, topic всегда None).

Схема теперь:  real implementation -> при исключении -> fallback.
Fallback'и (_Default*) остались, но только как страховка; каждый их вызов
считается в FallbackStats и виден метакогниции.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from .situation import ActionType as SituationActionType, Tone
from ..interpretation.extractors import IntentClassifier, ToneAnalyzer, TopicExtractor
from ..interpretation.engine import INTENT_TO_SITUATION_ACTION
from ..interpretation.lexicon import focal_text

logger = logging.getLogger("marin_core.perception")


@dataclass
class FallbackStats:
    counts: Dict[str, int] = field(default_factory=dict)
    last_errors: Dict[str, str] = field(default_factory=dict)

    def hit(self, name: str, exc: BaseException) -> None:
        self.counts[name] = self.counts.get(name, 0) + 1
        self.last_errors[name] = f"{type(exc).__name__}: {exc}"

    def total(self) -> int:
        return sum(self.counts.values())


class WithFallback:
    """Прокси: вызывает метод primary, при исключении — тот же метод fallback."""

    def __init__(self, name: str, primary, fallback, stats: FallbackStats):
        self._name = name
        self._primary = primary
        self._fallback = fallback
        self._stats = stats

    def __getattr__(self, method):
        primary_fn = getattr(self._primary, method)
        fallback_fn = getattr(self._fallback, method)

        def call(*args, **kwargs):
            try:
                return primary_fn(*args, **kwargs)
            except Exception as exc:  # noqa: BLE001 — любой сбой реализации -> fallback
                logger.exception("%s.%s failed, falling back", self._name, method)
                self._stats.hit(self._name, exc)
                return fallback_fn(*args, **kwargs)

        return call


class RuleActionClassifier:
    def __init__(self, classifier: Optional[IntentClassifier] = None):
        self.classifier = classifier or IntentClassifier()

    def classify(self, observation) -> SituationActionType:
        dist = self.classifier.classify(focal_text(observation.content))
        intent = dist[0][0] if dist else "statement"
        return SituationActionType(INTENT_TO_SITUATION_ACTION.get(intent, "other"))


class LexiconToneEstimator:
    def __init__(self, analyzer: Optional[ToneAnalyzer] = None):
        self.analyzer = analyzer or ToneAnalyzer()

    def estimate(self, observation) -> Tone:
        r = self.analyzer.analyze(focal_text(observation.content))
        return Tone(valence=r.valence, energy=r.energy)


class KeywordTopicLinker:
    def __init__(self, extractor: Optional[TopicExtractor] = None):
        self.extractor = extractor or TopicExtractor()

    def link(self, observation) -> Optional[str]:
        topic, _ = self.extractor.extract(focal_text(observation.content))
        return topic


class MetadataContextLinker:
    """Ссылки на контекст, которые инфраструктура кладёт в metadata
    (reply_to message id, context_refs)."""

    def link(self, observation) -> List[str]:
        md = getattr(observation, "metadata", {}) or {}
        refs = [str(r) for r in md.get("context_refs", []) or []]
        if md.get("reply_to") is not None:
            refs.append(f"reply_to:{md['reply_to']}")
        return refs
