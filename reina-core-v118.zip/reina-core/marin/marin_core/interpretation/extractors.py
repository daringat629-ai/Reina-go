"""
Реальные экстракторы интерпретации: intent (распределение), tone, topic +
entities, facts (самораскрытие собеседника), feedback (реакция на прошлый
ответ Marin). Все работают на focal text — последней реплике собеседника.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from . import lexicon as L


# ============================================================== intent

INTENTS = (
    "question", "request", "statement", "self_disclosure", "greeting", "farewell",
    "gratitude", "correction", "complaint", "small_talk", "remember_request", "forget_request",
)


class IntentClassifier:
    """Возвращает распределение по intent'ам (sum = 1), отсортированное по
    убыванию. Базовая масса у statement — чтобы "ничего не распознано" было
    честным "скорее утверждение, но не уверена", а не 100% уверенностью."""

    def classify(self, text: str) -> List[Tuple[str, float]]:
        raw = (text or "").strip()
        n = L.norm(raw)
        toks = n.split()
        scores: Dict[str, float] = {k: 0.0 for k in INTENTS}
        scores["statement"] = 0.35

        if raw.endswith("?") or "?" in raw[-3:]:
            scores["question"] += 1.2
        elif "?" in raw:
            scores["question"] += 0.6
        if toks and toks[0] in L.QUESTION_WORDS:
            scores["question"] += 0.6

        req = L.any_phrase(n, L.REQUEST_PHRASES)
        if req:
            scores["request"] += 0.7 + 0.2 * min(2, len(req) - 1)
            if L.starts_with_any(n, L.REQUEST_PHRASES):
                scores["request"] += 0.4
            # "можешь ...?" — это просьба в форме вопроса
            if scores["question"] > 0 and L.any_phrase(n, ("можешь", "могла бы", "can you", "could you")):
                scores["request"] += 0.5

        if L.starts_with_any(n, L.GREETING_PHRASES) or (len(toks) <= 3 and L.any_phrase(n, L.GREETING_PHRASES)):
            scores["greeting"] += 1.3
        if L.any_phrase(n, L.FAREWELL_PHRASES) and len(toks) <= 6:
            scores["farewell"] += 1.2
        if L.any_phrase(n, L.GRATITUDE_PHRASES):
            scores["gratitude"] += 1.0 if len(toks) <= 6 else 0.6
        if L.any_phrase(n, L.MEANING_CORRECTION_PHRASES) or L.any_phrase(n, L.BELIEF_DENIAL_PHRASES):
            scores["correction"] += 1.4
        if L.any_phrase(n, L.ACTION_COMPLAINT_PHRASES):
            scores["correction"] += 1.4
        if L.any_phrase(n, L.COMPLAINT_PHRASES):
            scores["complaint"] += 0.8
        if L.any_phrase(n, L.SELF_DISCLOSURE_LEADS) or re.search(r"\bмне\s+\d{1,3}\s+(?:год|года|лет)\b", n):
            scores["self_disclosure"] += 1.1
        if L.starts_with_any(n, L.REMEMBER_PHRASES):
            scores["remember_request"] += 2.5
        elif L.any_phrase(n, L.REMEMBER_PHRASES):
            scores["remember_request"] += 0.8
        if L.starts_with_any(n, L.FORGET_PHRASES):
            # "забудь, что я люблю кофе" — это команда памяти, а не самораскрытие
            scores["forget_request"] += 2.5
            scores["self_disclosure"] = 0.0
        elif L.any_phrase(n, L.FORGET_PHRASES):
            scores["forget_request"] += 0.8

        if len(toks) <= 3 and L.starts_with_any(n, L.ACK_PHRASES):
            scores["small_talk"] += 1.0
        elif len(toks) <= 3 and max(scores.values()) <= 0.35:
            scores["small_talk"] += 0.6

        # softmax-подобная нормализация без exp — масштаб читаемый в логах
        positive = {k: v for k, v in scores.items() if v > 0}
        total = sum(positive.values()) or 1.0
        dist = sorted(((k, v / total) for k, v in positive.items()), key=lambda kv: kv[1], reverse=True)
        return dist


# ============================================================== tone

@dataclass
class ToneReading:
    valence: float
    energy: float
    label: str
    markers: List[str] = field(default_factory=list)


class ToneAnalyzer:
    """Лексикон + отрицания ("не нравится") + усилители ("очень круто") +
    эмодзи/смайлы + пунктуация/капс для энергии."""

    def analyze(self, text: str) -> ToneReading:
        raw = text or ""
        low = raw.lower()
        toks = L.tokens(raw)
        valence = 0.0
        markers: List[str] = []
        for i, tok in enumerate(toks):
            w = L.POSITIVE_WORDS.get(tok, 0.0) + L.NEGATIVE_WORDS.get(tok, 0.0)
            if not w:
                continue
            window = toks[max(0, i - 2):i]
            if any(t in L.NEGATORS for t in window):
                w = -w * 0.8
            mult = max([L.INTENSIFIERS.get(t, 1.0) for t in window] or [1.0])
            valence += w * mult
            markers.append(tok)
        for e in L.POSITIVE_EMOJI:
            if e in low:
                valence += 0.3
                markers.append(e)
        for e in L.NEGATIVE_EMOJI:
            if e in low:
                valence -= 0.3
                markers.append(e)
        smiles = len(re.findall(r"\){1,}", raw)) - len(re.findall(r"(?<!:)\({2,}", raw))
        if smiles > 0:
            valence += min(0.4, 0.15 * smiles)
        elif smiles < 0:
            valence -= min(0.4, 0.15 * -smiles)
        valence = max(-1.0, min(1.0, valence))

        letters = [c for c in raw if c.isalpha()]
        caps_ratio = (sum(1 for c in letters if c.isupper()) / len(letters)) if len(letters) >= 6 else 0.0
        energy = min(1.0, 0.15 + len(raw) / 400 + 0.15 * raw.count("!") + 0.5 * caps_ratio)

        if valence > 0.25:
            label = "excited" if energy > 0.55 else "positive"
        elif valence < -0.25:
            label = "irritated" if energy > 0.55 else "negative"
        elif raw.strip().endswith("?"):
            label = "curious"
        else:
            label = "neutral"
        return ToneReading(valence=valence, energy=energy, label=label, markers=markers)


# ============================================================== topic + entities

_CAP_SEQ = re.compile(r"(?:(?<=\s)|^)([A-ZА-ЯЁ][\w\-]*(?:\s+(?:[A-ZА-ЯЁ][\w\-]*|[A-Z0-9]{1,3}))*)")
_QUOTED = re.compile(r"[«\"]([^»\"]{2,60})[»\"]")
_MENTION = re.compile(r"@\w{3,}")


# Грубый фильтр глагольных/причастных/наречных окончаний: тема — скорее
# существительное ("память", "прогноз"), чем "устроена"/"ошибётся"/"интересно".
_VERBISH = re.compile(
    r"(ться|тся|ть|ти|ешь|ишь|ете|ите|ем|ет|ит|ут|ют|ат|ят|ла|ло|ли|ена|ено|ены|ана|ано|аны|ся|сь|"
    r"но|ing|ed|ly)$"
)


class TopicExtractor:
    """entities: @упоминания, «цитаты», последовательности слов с заглавной
    буквы не в начале предложения ("про Marin X"), латиница внутри русского
    текста. topic: самая "весомая" сущность, иначе лучшее контентное слово."""

    def extract(self, text: str) -> Tuple[Optional[str], List[str]]:
        raw = text or ""
        entities: List[str] = []
        entities += _MENTION.findall(raw)
        entities += [q.strip() for q in _QUOTED.findall(raw)]
        for sent in L.split_sentences(raw):
            for m in _CAP_SEQ.finditer(sent):
                cand = m.group(1).strip()
                if m.start(1) == 0 and " " not in cand and not re.search(r"[A-Za-z]", cand):
                    continue  # первое слово предложения с заглавной — не сущность
                if L.norm(cand) in L.STOPWORDS or len(cand) < 2:
                    continue
                entities.append(cand)
        seen = set()
        uniq = []
        for e in entities:
            k = L.norm(e)
            if k and k not in seen:
                seen.add(k)
                uniq.append(e)

        if uniq:
            topic = max(uniq, key=lambda e: (len(L.tokens(e)), len(e)))
            return L.norm(topic), uniq
        content = [t for t in L.tokens(raw) if t not in L.STOPWORDS and len(t) >= 4 and not t.isdigit()]
        if not content:
            return None, []
        nounish = [t for t in content if not _VERBISH.search(t)]
        return (nounish or content)[0], []


# ============================================================== facts

@dataclass
class ExtractedFact:
    key: str              # стабильный ключ ("likes:кофе", "name", "location")
    predicate: str        # likes / name / age / location / job / has / note
    obj: str
    polarity: int = 1     # +1 утверждение, -1 отрицание ("не люблю")
    confidence: float = 0.8
    single_valued: bool = False  # у человека одно имя/возраст/город — новое значение = обновление

    def statement(self, subject: str) -> str:
        if self.predicate == "likes":
            return f"{subject} {'любит' if self.polarity > 0 else 'не любит'} {self.obj}"
        if self.predicate == "name":
            return f"{subject}: зовут {self.obj}"
        if self.predicate == "age":
            return f"{subject}: возраст {self.obj}"
        if self.predicate == "location":
            return f"{subject} живёт в {self.obj}"
        if self.predicate == "job":
            return f"{subject} работает {self.obj}"
        if self.predicate == "has":
            return f"У {subject} есть {self.obj}"
        return f"{subject}: {self.obj}"


_FACT_PATTERNS = [
    # (regex, predicate, polarity_group|None, fixed_polarity, obj_group, single_valued)
    (re.compile(r"\bя\s+(не\s+)?(?:очень\s+)?(?:люблю|обожаю)\s+(.+)", re.I), "likes", 1, None, 2, False),
    (re.compile(r"\bя\s+(?:очень\s+)?ненавижу\s+(.+)", re.I), "likes", None, -1, 1, False),
    (re.compile(r"\bмне\s+(не\s+)?(?:очень\s+)?нрав(?:ит|ят)ся\s+(.+)", re.I), "likes", 1, None, 2, False),
    (re.compile(r"\bi\s+(don'?t\s+|do not\s+)?(?:really\s+)?(?:love|like|enjoy)\s+(.+)", re.I), "likes", 1, None, 2, False),
    (re.compile(r"\bi\s+hate\s+(.+)", re.I), "likes", None, -1, 1, False),
    (re.compile(r"\bменя\s+зовут\s+([A-Za-zА-Яа-яЁё\-]+)", re.I), "name", None, 1, 1, True),
    (re.compile(r"\bmy\s+name\s+is\s+([A-Za-z\-]+)", re.I), "name", None, 1, 1, True),
    (re.compile(r"\bмне\s+(\d{1,3})\s+(?:год|года|лет)\b", re.I), "age", None, 1, 1, True),
    (re.compile(r"\bя\s+(?:сейчас\s+)?живу\s+в\s+(.+)", re.I), "location", None, 1, 1, True),
    (re.compile(r"\bi\s+live\s+in\s+(.+)", re.I), "location", None, 1, 1, True),
    (re.compile(r"\bя\s+работаю\s+(.+)", re.I), "job", None, 1, 1, True),
    (re.compile(r"\bу\s+меня\s+есть\s+(.+)", re.I), "has", None, 1, 1, False),
]


class FactExtractor:
    """Самораскрытие собеседника -> структурированные факты о нём.
    Вопросы ("ты любишь кофе?") и гипотетика ("если бы я жил в...") не
    считаются фактами о собеседнике."""

    def extract(self, text: str) -> List[ExtractedFact]:
        facts: List[ExtractedFact] = []
        for sent in L.split_sentences(text):
            s = sent.strip()
            if s.endswith("?") or re.search(r"\b(если бы|как будто|представь|if i)\b", s, re.I):
                continue
            if L.starts_with_any(L.norm(s), L.FORGET_PHRASES):
                continue  # "забудь, что я люблю X" — не новое свидетельство, а отзыв
            for rx, pred, pol_group, fixed_pol, obj_group, single in _FACT_PATTERNS:
                m = rx.search(s)
                if not m:
                    continue
                obj = L.clip_object(m.group(obj_group), max_words=4 if pred == "likes" else 5)
                if not obj or L.norm(obj) in L.STOPWORDS:
                    continue
                polarity = fixed_pol if fixed_pol is not None else (-1 if (pol_group and m.group(pol_group)) else 1)
                obj_key = L.norm(obj)
                key = f"{pred}:{obj_key}" if not single else pred
                facts.append(ExtractedFact(key=key, predicate=pred, obj=obj.lower() if pred == "likes" else obj,
                                           polarity=polarity, single_valued=single))
                break
        return facts


def remember_request_body(text: str) -> Optional[str]:
    """"запомни, что я прихожу в 9" -> "я прихожу в 9"."""
    m = re.search(r"(?:запомни|не забудь|учти|имей в виду|remember|keep in mind)[,:\s]+(?:что\s+|that\s+)?(.+)",
                  text or "", re.I | re.S)
    if not m:
        return None
    body = m.group(1).strip().rstrip(".!")
    return body if len(body) >= 3 else None


def forget_request_body(text: str) -> Optional[str]:
    m = re.search(r"(?:забудь|не запоминай|удали из памяти|сотри из памяти|forget)[,:\s]+(?:что\s+|про\s+|о\s+|об\s+|about\s+)?(.+)",
                  text or "", re.I | re.S)
    if not m:
        return None
    body = m.group(1).strip().rstrip(".!")
    return body if len(body) >= 2 else None


# ============================================================== feedback

@dataclass
class Feedback:
    """Реакция собеседника на ПРОШЛЫЙ ответ Marin — сигнал для learning."""

    kind: str = "none"   # none | positive | correction | belief_denial | action_complaint | goal_miss | negative
    strength: float = 0.0
    corrected_intent: Optional[str] = None
    evidence: List[str] = field(default_factory=list)


_CORRECTED_INTENT_CUES = [
    ("question", ("это был вопрос", "я спрашивал", "я спрашивала", "я задал вопрос", "i was asking")),
    ("request", ("я просил", "я просила", "я прошу", "сделай это", "i asked you to")),
    ("small_talk", ("просто поболтать", "просто поговорить", "хотел поговорить", "хотела поговорить",
                    "хотел поболтать", "хотела поболтать", "я просто так", "просто пошутил", "просто пошутила",
                    "это шутка", "just chatting", "just kidding")),
    ("self_disclosure", ("я про себя", "я рассказывал о себе", "я рассказывала о себе")),
    ("complaint", ("я жаловался", "я жаловалась", "мне просто плохо", "я просто пожаловался")),
]


class FeedbackDetector:
    # Только короткие реакции без собственного содержания могут быть
    # "реакцией на мой ответ" по одному тону. "Я люблю кофе" — позитивно,
    # но это рассказ о себе, а не оценка моей реплики.
    TONE_FEEDBACK_INTENTS = ("gratitude", "small_talk", "statement", "correction")

    def detect(self, text: str, tone: ToneReading, had_pending: bool, intent: Optional[str] = None) -> Feedback:
        if not had_pending:
            return Feedback()
        n = L.norm(text)
        corrected = None
        for intent, cues in _CORRECTED_INTENT_CUES:
            if L.any_phrase(n, cues):
                corrected = intent
                break

        hits = L.any_phrase(n, L.MEANING_CORRECTION_PHRASES)
        if hits:
            return Feedback("correction", 0.9, corrected, hits)
        hits = L.any_phrase(n, L.ACTION_COMPLAINT_PHRASES)
        if hits:
            return Feedback("action_complaint", 0.8, corrected, hits)
        hits = L.any_phrase(n, L.BELIEF_DENIAL_PHRASES)
        if hits:
            return Feedback("belief_denial", 0.8, corrected, hits)
        hits = L.any_phrase(n, L.GOAL_MISS_PHRASES)
        if hits and len(n.split()) <= 12:
            return Feedback("goal_miss", 0.6, corrected, hits)
        if corrected:
            return Feedback("correction", 0.6, corrected, [corrected])
        hits = L.any_phrase(n, L.POSITIVE_FEEDBACK_PHRASES) + L.any_phrase(n, L.GRATITUDE_PHRASES)
        n_words = len(n.split())
        # короткая эмоциональная реплика сразу после моего ответа ("ужасно, бесит")
        # — реакция на него, даже если по форме это жалоба
        tone_ok = ((intent is None or intent in self.TONE_FEEDBACK_INTENTS) and n_words <= 8) or \
                  (intent == "complaint" and n_words <= 4)
        if hits or (tone_ok and tone.valence > 0.35):
            return Feedback("positive", min(1.0, 0.5 + 0.5 * max(0.0, tone.valence)), None, hits)
        if tone_ok and tone.valence < -0.35:
            return Feedback("negative", min(1.0, 0.5 + 0.5 * -tone.valence), None, tone.markers[:3])
        return Feedback()
