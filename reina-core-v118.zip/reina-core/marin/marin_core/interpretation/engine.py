"""
InterpretationEngine — шаг INTERPRET цикла (§16) как настоящий слой.

Вход:  Perception (observation) + Situation + Memory (retrieved) + Social
       state + World state + Beliefs + выученные паттерны + ожидание
       реакции на прошлый ответ (pending).
Выход: Interpretation — структурированный результат:
       intent / hypotheses / entities / topic / tone / facts /
       uncertainties / belief_updates / feedback.

LLM здесь не участвует и НЕ превращает сообщение в действие: действие
выбирает DecisionEngine из Interpretation, а LLM только формулирует ответ.

Каждый экстрактор вызывается по схеме "реальная реализация -> при ошибке
fallback", и факт использования fallback'а виден в Interpretation.
"""

from __future__ import annotations

import logging
import math
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from . import lexicon as L
from ..understanding.semantic import SemanticUnderstanding, SemanticUnderstandingEngine
from .extractors import (
    ExtractedFact, Feedback, FeedbackDetector, FactExtractor, IntentClassifier, ToneAnalyzer,
    ToneReading, TopicExtractor, forget_request_body, remember_request_body,
)

logger = logging.getLogger("marin_core.interpretation")


# Маппинг intent -> тип действия актора в SituationModel (обратная совместимость).
INTENT_TO_SITUATION_ACTION = {
    "question": "ask_question", "request": "request", "statement": "statement",
    "self_disclosure": "statement", "greeting": "greeting", "farewell": "small_talk",
    "gratitude": "reaction", "correction": "reaction", "complaint": "statement",
    "small_talk": "small_talk", "remember_request": "request", "forget_request": "request",
}

_SITUATION_ACTION_TO_INTENT = {
    "ask_question": "question", "request": "request", "statement": "statement",
    "reaction": "statement", "greeting": "greeting", "small_talk": "small_talk", "other": "statement",
}


# Семьи intent'ов с одинаковой "формой ответа". Колебание ВНУТРИ семьи
# (вопрос vs просьба рассказать) — не неопределённость понимания: ответ
# нужен в любом случае. Неопределённость — это колебание МЕЖДУ семьями.
INTENT_FAMILY = {
    "question": "needs_answer", "request": "needs_answer",
    "remember_request": "memory_op", "forget_request": "memory_op",
    "greeting": "social", "farewell": "social", "gratitude": "social", "small_talk": "social",
    "statement": "share", "self_disclosure": "share", "complaint": "share",
    "correction": "repair",
}


def family_margin(dist: List[Tuple[str, float]]) -> float:
    fam: Dict[str, float] = {}
    for intent, p in dist:
        f = INTENT_FAMILY.get(intent, intent)
        fam[f] = fam.get(f, 0.0) + p
    vals = sorted(fam.values(), reverse=True)
    if not vals:
        return 0.0
    return vals[0] - (vals[1] if len(vals) > 1 else 0.0)


def family_confidence(dist: List[Tuple[str, float]]) -> float:
    if not dist:
        return 0.0
    top_family = INTENT_FAMILY.get(dist[0][0], dist[0][0])
    return sum(p for i, p in dist if INTENT_FAMILY.get(i, i) == top_family)


@dataclass
class BeliefUpdateProposal:
    kind: str                 # assert | retract | note
    key: str
    statement: str
    polarity: int = 1
    confidence: float = 0.75
    single_valued: bool = False
    source: str = "user_statement"
    conflicts_with: Optional[str] = None  # statement существующего belief, если конфликт виден уже сейчас

    def to_dict(self) -> dict:
        return {k: v for k, v in self.__dict__.items() if v not in (None, "")}


@dataclass
class Interpretation:
    focal_text: str
    intent: str
    intent_confidence: float
    hypotheses: List[Tuple[str, float]]          # распределение по intent'ам
    entities: List[str] = field(default_factory=list)
    known_entities: List[str] = field(default_factory=list)
    topic: Optional[str] = None
    tone: str = "neutral"
    valence: float = 0.0
    energy: float = 0.0
    facts: List[ExtractedFact] = field(default_factory=list)
    uncertainties: List[str] = field(default_factory=list)
    context_hypotheses: List[str] = field(default_factory=list)   # "это ответ на мой вопрос" и т.п.
    belief_updates: List[BeliefUpdateProposal] = field(default_factory=list)
    feedback: Feedback = field(default_factory=Feedback)
    signatures: List[str] = field(default_factory=list)
    applied_pattern: Optional[Any] = None       # learning.pattern_learning.AppliedPattern
    related_beliefs: List[str] = field(default_factory=list)
    fallbacks_used: List[str] = field(default_factory=list)
    actor_label_used: str = "Собеседник"   # реальное имя/роль говорящего, использованное в belief'ах/промпте
    addressed: bool = True
    act_requested: bool = False
    # Semantic layer: discourse references, temporal grounding, modality and clauses.
    semantic: SemanticUnderstanding = field(default_factory=SemanticUnderstanding)

    @property
    def uncertainty(self) -> float:
        """0..1: насколько я НЕ уверена в понимании."""
        margin = family_margin(self.hypotheses)
        conf = family_confidence(self.hypotheses)
        u = 1.0 - (0.6 * conf + 0.4 * min(1.0, margin * 2))
        u += 0.08 * len(self.uncertainties)
        return max(0.0, min(1.0, u))

    @property
    def confidence(self) -> float:
        return 1.0 - self.uncertainty

    def to_dict(self) -> dict:
        return {
            "intent": self.intent,
            "intent_confidence": round(self.intent_confidence, 3),
            "hypotheses": [{"intent": i, "p": round(p, 3)} for i, p in self.hypotheses[:4]],
            "entities": self.entities,
            "topic": self.topic,
            "tone": self.tone,
            "valence": round(self.valence, 3),
            "facts": [{"key": f.key, "predicate": f.predicate, "object": f.obj, "polarity": f.polarity}
                      for f in self.facts],
            "uncertainties": self.uncertainties,
            "context_hypotheses": self.context_hypotheses,
            "belief_updates": [b.to_dict() for b in self.belief_updates],
            "feedback": self.feedback.kind,
            "applied_pattern": self.applied_pattern.describe() if self.applied_pattern else None,
            "uncertainty": round(self.uncertainty, 3),
        }

    def summary_for_llm(self) -> str:
        """Компактная строка для промпта: как я поняла сообщение."""
        parts = [f"intent={self.intent} ({self.intent_confidence:.2f})", f"tone={self.tone}"]
        if self.topic:
            parts.append(f"topic={self.topic}")
        if self.facts:
            parts.append("facts=" + "; ".join(f"{f.predicate}:{'' if f.polarity > 0 else 'NOT '}{f.obj}" for f in self.facts))
        line = ", ".join(parts)
        if self.uncertainties:
            line += " | unsure: " + "; ".join(self.uncertainties[:3])
        if self.context_hypotheses:
            line += " | context: " + "; ".join(self.context_hypotheses[:2])
        semantic = self.semantic.summary()
        if semantic:
            line += " | semantic: " + semantic
        return line


@dataclass
class InterpretationContext:
    """Всё, что интерпретации нужно кроме самого сообщения."""

    actor_id: str
    actor_label: str = "Собеседник"   # реальное имя человека, если известно; иначе роль/дефолт
    is_owner: bool = False
    retrieved: List[Any] = field(default_factory=list)          # MemoryNode
    relationship: Optional[Any] = None                          # RelationshipState
    world_continuity: str = ""
    known_entity_names: List[str] = field(default_factory=list)
    beliefs: Optional[Any] = None                               # BeliefStore
    situation_embedding: Optional[Any] = None
    pending: Optional[Any] = None                               # learning.feedback_learning.PendingTick
    addressed: bool = True


def _cos(a, b) -> float:
    if a is None or b is None:
        return 0.0
    an = math.sqrt(sum(x * x for x in a))
    bn = math.sqrt(sum(x * x for x in b))
    if not an or not bn:
        return 0.0
    return sum(x * y for x, y in zip(a, b)) / (an * bn)


class InterpretationEngine:
    def __init__(
        self,
        pattern_store=None,
        intent_classifier: Optional[IntentClassifier] = None,
        tone_analyzer: Optional[ToneAnalyzer] = None,
        topic_extractor: Optional[TopicExtractor] = None,
        fact_extractor: Optional[FactExtractor] = None,
        feedback_detector: Optional[FeedbackDetector] = None,
    ):
        self.patterns = pattern_store
        self.intent_classifier = intent_classifier or IntentClassifier()
        self.tone_analyzer = tone_analyzer or ToneAnalyzer()
        self.topic_extractor = topic_extractor or TopicExtractor()
        self.fact_extractor = fact_extractor or FactExtractor()
        self.feedback_detector = feedback_detector or FeedbackDetector()
        self.semantic_engine = SemanticUnderstandingEngine()
        self.fallback_counts: Dict[str, int] = {}

    # ------------------------------------------------------------------
    def _safe(self, name: str, fn, fallback, used: List[str]):
        try:
            return fn()
        except Exception:
            logger.exception("interpretation step %s failed — using fallback", name)
            self.fallback_counts[name] = self.fallback_counts.get(name, 0) + 1
            used.append(name)
            return fallback()

    @staticmethod
    def signatures_for(intent: str, focal: str) -> List[str]:
        n = L.norm(focal)
        shape = L.shape_of(focal)
        return [f"{intent}|{shape}|{L.lead_word(n)}", f"{intent}|{shape}"]

    # ------------------------------------------------------------------
    def interpret(self, observation, situation, ctx: InterpretationContext) -> Interpretation:
        used: List[str] = []
        focal = L.focal_text(getattr(observation, "content", "") or "")
        if not focal:
            focal = (getattr(situation, "raw_text", "") or "").strip()

        # --- intent distribution (real -> fallback на situation.action)
        def _fallback_intent():
            base = _SITUATION_ACTION_TO_INTENT.get(getattr(situation.action, "value", "other"), "statement")
            return [(base, 0.5), ("statement" if base != "statement" else "question", 0.5)]
        dist = self._safe("intent", lambda: self.intent_classifier.classify(focal), _fallback_intent, used)
        raw_top = dist[0][0] if dist else "statement"
        signatures = self.signatures_for(raw_top, focal)

        # --- выученные паттерны корректируют распределение
        applied = None
        if self.patterns is not None:
            dist, applied = self.patterns.adjust(signatures, dist)
        intent, intent_p = dist[0] if dist else ("statement", 0.5)

        # --- tone (real -> fallback на situation.tone)
        def _fallback_tone():
            t = situation.tone
            return ToneReading(valence=t.valence, energy=t.energy, label="neutral")
        tone: ToneReading = self._safe("tone", lambda: self.tone_analyzer.analyze(focal), _fallback_tone, used)

        # --- topic + entities, связь с world model
        topic, entities = self._safe("topic", lambda: self.topic_extractor.extract(focal),
                                     lambda: (getattr(situation, "topic_id", None), []), used)
        known_names = {L.norm(n) for n in ctx.known_entity_names}
        known = [e for e in entities if L.norm(e) in known_names]

        # --- facts -> belief update proposals
        facts: List[ExtractedFact] = self._safe("facts", lambda: self.fact_extractor.extract(focal), lambda: [], used)
        subject = ctx.actor_label
        belief_updates: List[BeliefUpdateProposal] = []
        uncertainties: List[str] = []
        related: List[str] = []
        for f in facts:
            key = f"person:{ctx.actor_id}:{f.key}"
            statement = f.statement(subject)
            conflict = None
            if ctx.beliefs is not None:
                found = ctx.beliefs.find_by_key(key)
                if found is not None:
                    _, b = found
                    related.append(b.statement)
                    if b.polarity != f.polarity or (f.single_valued and b.statement.lower() != statement.lower()):
                        conflict = b.statement
                        uncertainties.append(
                            f"противоречит тому, что я знала: «{b.statement}» (confidence={b.confidence:.2f})")
            belief_updates.append(BeliefUpdateProposal(
                kind="assert", key=key, statement=statement, polarity=f.polarity,
                confidence=f.confidence, single_valued=f.single_valued, conflicts_with=conflict,
            ))

        if intent == "remember_request":
            body = remember_request_body(focal)
            if body and not facts:
                key = f"person:{ctx.actor_id}:note:{'_'.join(L.tokens(body)[:6])}"
                belief_updates.append(BeliefUpdateProposal(
                    kind="note", key=key, statement=f"{subject} просил(а) запомнить: {body}", confidence=0.9))
            elif not body:
                uncertainties.append("просят что-то запомнить, но непонятно что именно")
        if intent == "forget_request":
            body = forget_request_body(focal)
            if body:
                belief_updates.append(BeliefUpdateProposal(kind="retract", key=f"person:{ctx.actor_id}:*",
                                                           statement=body, confidence=1.0))
            else:
                uncertainties.append("просят что-то забыть, но непонятно что именно")

        # --- уверенность в самом intent
        if len(dist) > 1 and family_margin(dist) < 0.15:
            top_fam = INTENT_FAMILY.get(dist[0][0])
            rival = next((i for i, _ in dist[1:] if INTENT_FAMILY.get(i) != top_fam), dist[1][0])
            uncertainties.append(f"не уверена, это {dist[0][0]} или {rival}")
        n_tokens = len(L.tokens(focal))
        if (n_tokens <= 2 and intent in ("statement", "small_talk")
                and not L.any_phrase(L.norm(focal), L.GREETING_PHRASES + L.ACK_PHRASES + L.GRATITUDE_PHRASES)):
            uncertainties.append("очень короткая реплика без явного смысла")
        if applied is not None and applied.misread_intent:
            uncertainties.append(f"раньше я неверно понимала такие сообщения как {applied.misread_intent}")
        unknown = [e for e in entities if e not in known]
        if intent == "question" and unknown and ctx.known_entity_names:
            uncertainties.append(f"не знаю, что такое {', '.join(unknown[:2])}")

        # --- контекстные гипотезы из памяти/отношений/pending
        context_hyp: List[str] = []
        pending = ctx.pending
        if pending is not None and getattr(pending, "action_type", "") in ("ask", "clarify") and intent != "question":
            context_hyp.append("скорее всего это ответ на мой прошлый вопрос")
        if ctx.situation_embedding is not None and ctx.retrieved:
            sims = [_cos(ctx.situation_embedding, getattr(n, "embedding", None)) for n in ctx.retrieved[:5]]
            if sims and max(sims) > 0.92:
                context_hyp.append("похожее уже обсуждали раньше")
        rel = ctx.relationship
        if rel is not None and not ctx.is_owner and intent == "request" and getattr(rel, "trust", 0.5) < 0.35:
            uncertainties.append("просьба от человека с низким доверием")
        if rel is not None and getattr(rel, "history_valence_ema", 0.0) < -0.3 and tone.valence < 0:
            context_hyp.append("напряжение в общении копится не первый раз")

        # --- feedback на прошлый ответ
        feedback = self._safe("feedback",
                              lambda: self.feedback_detector.detect(focal, tone, had_pending=pending is not None, intent=intent),
                              Feedback, used)
        if feedback.kind == "correction" and intent != "correction":
            # реплика-исправление — это прежде всего correction, что бы ни говорили паттерны
            dist = [("correction", max(0.6, intent_p))] + [(i, p * 0.4) for i, p in dist if i != "correction"]
            total = sum(p for _, p in dist)
            dist = [(i, p / total) for i, p in dist]
            intent, intent_p = dist[0]

        act_requested = intent == "request" and bool(L.any_phrase(L.norm(focal), L.ACT_PHRASES))

        # --- semantic understanding: discourse/time/modality/reference layer
        semantic = self._safe(
            "semantic",
            lambda: self.semantic_engine.analyze(
                focal,
                observation=observation,
                retrieved=ctx.retrieved,
                known_entities=ctx.known_entity_names,
                world_continuity=ctx.world_continuity,
                actor_label=ctx.actor_label,
            ),
            SemanticUnderstanding,
            used,
        )
        # Classify each clause separately so a compound message can preserve
        # more than one communicative purpose (e.g. "сделай X и скажи Y").
        semantic.clause_intents = [
            (self.intent_classifier.classify(clause) or [("statement", 0.5)])[0][0]
            for clause in semantic.clauses
        ]
        if len(set(semantic.clause_intents)) > 1:
            context_hyp.append(
                "несколько намерений: " + ", ".join(dict.fromkeys(semantic.clause_intents))
            )
        if any(i == "request" for i in semantic.clause_intents):
            act_requested = True

        # Ground simple deictic fact objects when the semantic layer found a
        # concrete referent. If it could not resolve one, don't turn "я люблю
        # это/там" into a false permanent belief.
        for fact in facts:
            ref = next(
                (r for r in semantic.references
                 if L.norm(r.mention) == L.norm(fact.obj)
                 and r.kind in ("deictic", "place")),
                None,
            )
            if ref is not None:
                if ref.target and ref.target not in ("recent_memory", "recent_event_chain"):
                    old_key = f"person:{ctx.actor_id}:{fact.key}"
                    fact.obj = ref.target
                    fact.key = f"{fact.predicate}:{L.norm(fact.obj)}" if not fact.single_valued else fact.predicate
                    new_key = f"person:{ctx.actor_id}:{fact.key}"
                    for proposal in belief_updates:
                        if proposal.key == old_key:
                            proposal.key = new_key
                            proposal.statement = fact.statement(subject)
                else:
                    uncertainties.append(f"не удалось надёжно определить, что означает «{fact.obj}»")
                    belief_updates = [
                        b for b in belief_updates
                        if b.key != f"person:{ctx.actor_id}:{fact.key}"
                    ]

        for ambiguity in semantic.ambiguities[:3]:
            if ambiguity not in uncertainties:
                uncertainties.append(ambiguity)
        if semantic.temporal:
            context_hyp.append("в сообщении есть временная привязка")
        if len(semantic.clauses) > 1:
            context_hyp.append(f"сообщение содержит {len(semantic.clauses)} смысловых частей")

        return Interpretation(
            focal_text=focal, intent=intent, intent_confidence=intent_p, hypotheses=dist,
            entities=entities, known_entities=known, topic=topic, tone=tone.label,
            valence=tone.valence, energy=tone.energy, facts=facts, uncertainties=uncertainties,
            context_hypotheses=context_hyp, belief_updates=belief_updates, feedback=feedback,
            signatures=signatures, applied_pattern=applied, related_beliefs=related,
            fallbacks_used=used, addressed=ctx.addressed, act_requested=act_requested,
            actor_label_used=subject,
            semantic=semantic,
        )
