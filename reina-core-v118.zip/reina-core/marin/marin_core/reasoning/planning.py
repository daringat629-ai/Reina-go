"""
Planning — §9 спеки: PLANNING режим reasoning. Multi-step поиск по Goal
tree с прогнозами на каждый шаг (использует prediction/predictor.py на
каждом узле плана вместо одного прогноза на текущее действие).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, List, Optional

from ..goals.goals import Goal, GoalSet
from ..goals.motivation import ActionCandidate, utility


@dataclass
class PlanStep:
    action: ActionCandidate
    expected_utility: float
    children: List["PlanStep"] = field(default_factory=list)


def plan(
    goal_set: GoalSet,
    generate_candidates_fn: Callable[[GoalSet], List[ActionCandidate]],
    depth: int = 2,
    beam_width: int = 3,
) -> List[PlanStep]:
    """Простой beam search по дереву действий: на каждом уровне держим
    top-beam_width кандидатов по utility (§10.3), раскрываем depth уровней.
    generate_candidates_fn симулирует "что станет с целями после действия"
    и возвращает следующий набор кандидатов — интеграция с prediction/
    происходит внутри неё (сюда передаётся уже готовая функция)."""

    def expand(gs: GoalSet, remaining_depth: int) -> List[PlanStep]:
        candidates = generate_candidates_fn(gs)
        scored = sorted(candidates, key=lambda a: utility(a, gs), reverse=True)[:beam_width]
        steps = []
        for a in scored:
            u = utility(a, gs)
            children = expand(gs, remaining_depth - 1) if remaining_depth > 1 else []
            steps.append(PlanStep(action=a, expected_utility=u, children=children))
        return steps

    return expand(goal_set, depth)


def best_first_action(steps: List[PlanStep]) -> Optional[ActionCandidate]:
    if not steps:
        return None
    return max(steps, key=lambda s: s.expected_utility).action
