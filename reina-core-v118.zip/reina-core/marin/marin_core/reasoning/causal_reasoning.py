"""
Causal reasoning — §9 спеки: запрос к World Model по causal edges (см.
world/causal_model.py). Используется в PLANNING и UNCERTAINTY режимах,
когда нужно оценить "что могло привести к текущей ситуации" или
"что вероятно произойдёт, если...".
"""

from __future__ import annotations

from typing import List

from ..world.world_model import WorldModel
from ..world.causal_model import CausalLink


def explain_effect(world: WorldModel, effect_event_id: str, min_confidence: float = 0.3) -> List[CausalLink]:
    """Возвращает вероятные причины события, отсортированные по confidence."""
    links = world.causal.likely_causes(effect_event_id, min_confidence=min_confidence)
    return sorted(links, key=lambda l: l.confidence, reverse=True)


def project_forward(world: WorldModel, cause_event_id: str, min_confidence: float = 0.3) -> List[CausalLink]:
    """Обратный запрос: какие эффекты обычно следуют за данной причиной —
    используется в PREDICT (§6) для причинно-обоснованных, а не только
    ассоциативных прогнозов."""
    return [
        l for l in world.causal._links.values()  # noqa: SLF001 — внутренний доступ оправдан узостью операции
        if l.cause_event_id == cause_event_id and l.confidence >= min_confidence
    ]
