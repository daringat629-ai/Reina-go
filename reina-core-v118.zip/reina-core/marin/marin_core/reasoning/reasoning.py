"""
Reasoning Engine — §9 спеки. Несколько режимов, но все работают над одним
CognitiveState — не отдельные "мозги". Выбор режима — функция от
cognitive_load_budget(t) и stakes(S_t) (§9, §15).
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Callable, Dict, Optional

from ..state.cognitive_state import CognitiveState, CognitiveLoad


class ReasoningMode(str, Enum):
    FAST = "fast_reasoning"
    DEEP = "deep_reasoning"
    CAUSAL = "causal_reasoning"
    SOCIAL = "social_reasoning"
    TEMPORAL = "temporal_reasoning"
    UNCERTAINTY = "uncertainty_reasoning"
    PLANNING = "planning"


def select_reasoning_mode(stakes: float, cognitive_load: CognitiveLoad, theta_stakes: float = 0.6) -> ReasoningMode:
    """§9: выбор режима — функция stakes и текущего cognitive_load_budget.
    Высокие ставки при доступном бюджете -> deep; иначе -> fast, чтобы не
    превышать budget_max (§15)."""
    if cognitive_load.over_budget:
        return ReasoningMode.FAST
    if stakes > theta_stakes:
        return ReasoningMode.DEEP
    return ReasoningMode.FAST


@dataclass
class ReasoningStep:
    mode: ReasoningMode
    input_summary: str
    output_summary: str


class ReasoningEngine:
    """Точка расширения: конкретные режимы делегируют в LLM (через
    llm/interface.py, отдельный "reasoning" вызов, не путать с финальной
    генерацией ответа) либо в специализированные под-модули (causal_model,
    social_model). Здесь — диспетчер + интерфейс."""

    def __init__(self, handlers: Optional[Dict[ReasoningMode, Callable[..., Any]]] = None):
        self.handlers = handlers or {}

    def register(self, mode: ReasoningMode, handler: Callable[..., Any]) -> None:
        self.handlers[mode] = handler

    def run(self, mode: ReasoningMode, *args, **kwargs) -> Any:
        handler = self.handlers.get(mode)
        if handler is None:
            raise NotImplementedError(f"no handler registered for reasoning mode {mode}")
        return handler(*args, **kwargs)
