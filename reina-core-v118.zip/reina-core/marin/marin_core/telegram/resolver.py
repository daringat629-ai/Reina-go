"""Robust Telegram peer resolution for every action handler.

Bug this fixes: handlers did ``client.get_entity(str(x).strip().lstrip("@"))``.
For a channel id like ``-1001234567890`` that becomes a *string*, and Telethon
treats a digit string as a PHONE NUMBER (``utils.parse_phone`` strips the
minus) — so every action addressed by id (invite, promote, pin, send to
channel...) failed with the generic "нет прав или не нашла чат/человека".
The model also often names a chat by its title («Мысли Марин — источник»),
which ``get_entity`` cannot resolve at all.

``_resolve_peer`` accepts: int / numeric string ids (incl. -100…), @username,
t.me links, "me"/"себя", the owner ("владелец", "меня", owner name/id),
titles of own channels, and titles of any dialog (exact, then fuzzy).
"""
from __future__ import annotations

import difflib
import logging
import re
from typing import Any

logger = logging.getLogger("marin_x.telegram")

_TME_RE = re.compile(r"(?:https?://)?(?:t\.me|telegram\.me)/(?:s/)?([A-Za-z0-9_]{4,32})(?:/\d+)?/?$", re.IGNORECASE)
_SELF_WORDS = {"me", "self", "себя", "себе", "я", "марин", "marin"}
_OWNER_WORDS = {"owner", "владелец", "владельца", "меня", "мне", "хозяин"}


def _norm(s: str) -> str:
    return re.sub(r"[^\w]+", " ", (s or "").lower().replace("ё", "е")).strip()


class EntityResolverMixin:
    async def _resolve_peer(self, ref: Any):
        if ref is None:
            raise ValueError("empty peer reference")
        if not isinstance(ref, (str, int)):
            return ref  # уже entity
        if isinstance(ref, int):
            return await self.client.get_entity(ref)

        raw = ref.strip().strip("«»\"'“”")
        if not raw:
            raise ValueError("empty peer reference")
        low = raw.lower().lstrip("@")

        if low in _SELF_WORDS:
            return await self.client.get_entity("me")
        owner_id = getattr(getattr(self, "config", None), "owner_id", None)
        owner_name = (getattr(self, "owner_name", "") or "").lower()
        if owner_id and (low in _OWNER_WORDS or (owner_name and low == owner_name)):
            return await self.client.get_entity(int(owner_id))

        if re.fullmatch(r"-?\d{5,}", raw):
            return await self.client.get_entity(int(raw))

        m = _TME_RE.search(raw)
        if m:
            return await self.client.get_entity(m.group(1))

        if re.fullmatch(r"@?[A-Za-z][A-Za-z0-9_]{3,31}", raw):
            try:
                return await self.client.get_entity(raw.lstrip("@"))
            except Exception:
                pass  # может быть латинским названием чата — ищем дальше

        # Название: сначала свои каналы, потом все диалоги.
        target = _norm(raw)
        for entry in (getattr(self, "_own_channels", {}) or {}).values():
            if _norm(str(entry.get("title") or "")) == target:
                return await self.client.get_entity(int(entry["id"]))
        try:
            dialogs = await self.client.get_dialogs(limit=300)
        except Exception:
            dialogs = []
        best, best_score = None, 0.0
        for d in dialogs:
            name = _norm(getattr(d, "name", "") or getattr(getattr(d, "entity", None), "title", "") or "")
            if not name:
                continue
            if name == target:
                return d.entity
            score = difflib.SequenceMatcher(None, target, name).ratio()
            if score > best_score:
                best, best_score = d, score
        if best is not None and best_score >= 0.8:
            logger.info("[RESOLVE] %r -> %r (fuzzy %.2f)", raw, getattr(best, "name", ""), best_score)
            return best.entity
        raise ValueError(f"cannot resolve peer {raw!r}")


_REASONS = {
    "UserPrivacyRestricted": "у человека в настройках приватности запрещено добавлять его в чаты",
    "UserNotMutualContact": "Telegram позволяет добавлять в канал только взаимные контакты",
    "ChatAdminRequired": "у меня там нет нужных админ-прав",
    "ChatWriteForbidden": "мне запрещено писать в этот чат",
    "UserNotParticipant": "этого человека ещё нет в чате",
    "RightForbidden": "такие права я выдать не могу (их нет у меня самой)",
    "AdminsTooMuch": "в чате уже максимум админов",
    "BotsTooMuch": "в чате слишком много ботов",
    "UserChannelsTooMuch": "человек уже состоит в слишком многих каналах",
    "UserKicked": "человек забанен в этом чате — сначала надо разбанить",
    "UserBannedInChannel": "человек забанен в этом чате — сначала надо разбанить",
    "UserAlreadyParticipant": "он уже в чате",
    "PeerFlood": "Telegram временно ограничил мне такие действия (антиспам)",
    "FloodWait": "Telegram просит подождать перед следующей попыткой",
    "ChannelPrivate": "чат приватный или меня там нет",
    "UsernameNotOccupied": "такого username не существует",
    "UsernameInvalid": "некорректный username",
}


def tg_error_reason(exc: BaseException) -> str:
    """Человеческое объяснение ошибки Telegram/резолва — чтобы Марин
    говорила ПРАВДУ о причине, а не общее «либо нет прав, либо не нашла»."""
    name = type(exc).__name__
    for key, text in _REASONS.items():
        if key in name:
            if key == "FloodWait" and getattr(exc, "seconds", None):
                return f"{text} (~{int(exc.seconds)} сек)"
            return text
    if isinstance(exc, ValueError) and "cannot resolve" in str(exc):
        m = re.search(r"'(.+?)'", str(exc))
        return f"не нашла «{m.group(1) if m else '?'}» среди своих чатов и контактов"
    if isinstance(exc, KeyError):
        return f"в команде не хватило поля «{exc.args[0] if exc.args else '?'}»"
    if "JSON" in name:
        return "команда пришла в испорченном формате"
    if isinstance(exc, (TypeError, AttributeError)):
        # Это ошибка в коде, а не в команде: раньше она выдавалась за «не
        # хватило данных (чат или человек)» и скрыла настоящую причину сбоя опроса.
        return f"внутренняя ошибка ({name}) — это баг в моём коде, а не права или чат"
    return f"Telegram ответил ошибкой {name}"
