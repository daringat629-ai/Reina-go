"""Режиссёр селфи: кадр совпадает с тем, что она пишет.

Раньше генератору уходила только короткая задумка поста (или «дома,
делюсь мыслью с подписчиками»), и каждое селфи рисовалось с нуля: пост
«сижу вечером у окна» мог прийти с фото в лесу днём, а одежда менялась от
селфи к селфи без всякого повода.

Теперь перед каждым селфи модель по САМОМУ тексту поста/сообщения и
местному времени решает: где она, что делает, во что одета, какой свет,
какое выражение лица. Одежда запоминается на день: следующие селфи в тот
же день — в том же, пока по тексту нет причины переодеться (сон, улица,
особый повод). На следующий день — выбирает заново.

Безопасность та же, что у генератора селфи: только обычная закрытая
повседневная одежда; описание с запрещёнными словами отбрасывается и
заменяется безопасным.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import re
from typing import Any, Dict, Optional

from ..action.action import ActionType
from ..llm.interface import LanguagePlanningInput
from .selfie import _looks_unsafe
from .settings import local_now

logger = logging.getLogger("marin_x.telegram.selfie_director")

_FIELDS = ("PLACE", "DOING", "OUTFIT", "LIGHT", "MOOD")
_FIELD_RE = re.compile(r"^\s*(PLACE|DOING|OUTFIT|LIGHT|MOOD)\s*:\s*(.+?)\s*$", re.IGNORECASE | re.MULTILINE)
_DEFAULT_OUTFIT = "a casual hoodie with a crew neckline"

_DIRECTOR_SYSTEM = """Ты продумываешь кадр для селфи Марин так, чтобы он совпадал с тем, что она пишет.

По тексту ниже определи: где она, что делает, во что одета, какой свет и время суток, какое у неё выражение лица. Всё должно совпадать с текстом и с её местным временем: {clock}. Если места в тексте нет — выбери самое естественное для этого времени и настроения (дома у окна, за столом, на улице, в кафе, в транспорте и т.п.).

Это селфи с фронтальной камеры: она смотрит прямо в объектив, телефона в кадре нет. Поэтому DOING — не «держит телефон / фотографирует себя», а то, что видно в кадре (улыбается, держит кружку у лица, поправляет волосы и т.п.).

Одежда — обычная повседневная и закрытая (без открытых плеч и декольте), подходящая к месту и погоде.
{outfit_rule}

Ответь ровно пятью строками на английском, строго в формате:
PLACE: ...
DOING: ...
OUTFIT: ...
LIGHT: ...
MOOD: ..."""


def _daypart(hour: int) -> str:
    return "night" if hour < 6 else "morning" if hour < 12 else "afternoon" if hour < 18 else "evening"


class SelfieDirector:
    def __init__(self, telegram_client: Any, path: Optional[str] = None):
        self._tc = telegram_client
        self.path = path or default_selfie_state_path()
        self.state: Dict[str, Any] = {}
        self._load()

    # ------------------------------------------------------------ state
    def _load(self) -> None:
        try:
            with open(self.path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            if isinstance(data, dict):
                self.state = data
        except FileNotFoundError:
            return  # первый запуск — состояния ещё нет
        except Exception:
            logger.warning("[SELFIE] director state unreadable, starting fresh", exc_info=True)

    def _save(self) -> None:
        try:
            os.makedirs(os.path.dirname(os.path.abspath(self.path)) or ".", exist_ok=True)
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(self.state, fh, ensure_ascii=False, indent=1)
            os.replace(tmp, self.path)
        except Exception:
            logger.warning("[SELFIE] could not save director state", exc_info=True)

    def today_outfit(self) -> str:
        today = local_now().strftime("%Y-%m-%d")
        return self.state.get("outfit", "") if self.state.get("date") == today else ""

    def last_scene(self) -> str:
        return (self.state.get("scenes") or [""])[-1]

    # ------------------------------------------------------------ scene
    async def scene_for(self, text: str, hint: str = "") -> str:
        """Английское описание кадра для генератора селфи."""
        now = local_now()
        clock = f"{now.strftime('%H:%M')}, {_daypart(now.hour)}"
        outfit = self.today_outfit()
        outfit_rule = (
            f"Сегодня она уже была в: {outfit}. Оставь ту же одежду, если по тексту нет причины "
            f"переодеться (легла спать, вышла на улицу, особый повод)."
            if outfit else "Одежду выбери сама — она запомнится на весь сегодняшний день."
        )
        material = (text or "").strip()[:1200] or "(текста нет)"
        if hint and hint.strip() and hint.strip() not in material:
            material += f"\n\nЗадумка: {hint.strip()[:300]}"
        personality = getattr(self._tc.engine, "personality", None)
        pin = LanguagePlanningInput(
            situation_summary=f"Текст, к которому будет селфи:\n{material}",
            retrieved_memory_summaries=[], active_belief_summaries=[],
            chosen_action_type=ActionType.ANSWER, goal_context_summary="",
            style_prior=dict(getattr(personality, "style_prior", {}) or {}),
            system_override=_DIRECTOR_SYSTEM.format(clock=clock, outfit_rule=outfit_rule),
        )
        fields: Dict[str, str] = {}
        try:
            raw = await asyncio.to_thread(self._tc.engine.language_planner.provider.generate, pin)
            fields = {m.group(1).upper(): m.group(2).strip()[:200] for m in _FIELD_RE.finditer(raw or "")}
        except Exception:
            logger.warning("[SELFIE] director generation failed — using a safe default scene", exc_info=True)

        if fields.get("OUTFIT") and _looks_unsafe(fields["OUTFIT"]):
            logger.info("[SELFIE] unsafe outfit dropped: %r", fields["OUTFIT"])
            fields["OUTFIT"] = outfit or _DEFAULT_OUTFIT
        if not fields.get("PLACE"):
            return self._fallback(now, outfit, hint)

        chosen_outfit = fields.get("OUTFIT") or outfit or _DEFAULT_OUTFIT
        scene = (f"{fields['PLACE']}; {fields.get('DOING', 'taking a selfie')}; wearing {chosen_outfit}; "
                 f"{fields.get('LIGHT', _daypart(now.hour) + ' light')}; expression: {fields.get('MOOD', 'warm smile')}")
        if _looks_unsafe(scene):
            return self._fallback(now, outfit, hint)
        self._remember(now, chosen_outfit, scene)
        return scene

    def _fallback(self, now, outfit: str, hint: str) -> str:
        chosen = outfit or _DEFAULT_OUTFIT
        base = hint.strip() if hint and not _looks_unsafe(hint) else "at home by the window"
        scene = f"{base}; wearing {chosen}; {_daypart(now.hour)} light; expression: warm smile"
        self._remember(now, chosen, scene)
        return scene

    def _remember(self, now, outfit: str, scene: str) -> None:
        self.state["date"] = now.strftime("%Y-%m-%d")
        self.state["outfit"] = outfit
        self.state["scenes"] = (list(self.state.get("scenes") or []) + [scene])[-5:]
        self._save()


def default_selfie_state_path() -> str:
    explicit = os.getenv("MARIN_SELFIE_STATE_FILE")
    if explicit:
        return explicit
    state = os.getenv("MARIN_STATE_FILE")
    base = os.path.dirname(os.path.abspath(state)) if state else os.getcwd()
    return os.path.join(base, "marin_selfie_state.json")
