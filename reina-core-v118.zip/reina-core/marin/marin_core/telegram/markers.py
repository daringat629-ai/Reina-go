"""Hidden-tag protocol parsing (PERSON/BELIEF/GOAL/AUTOGOAL, repair, leak guard).

Mixin of MarinTelegramClient — relies on attributes created in
MarinTelegramClient.__init__ (self.client, self.engine, self.config, ...).
"""
from __future__ import annotations

import json
import logging
from .actions import ACTION_MARKER_RE

from .settings import (
    POST_MARKER_RE,
    AUTOGOAL_MARKER_RE,
    BELIEF_MARKER_RE,
    GOAL_MARKER_RE,
    ID_LIKE_DESCRIPTION_RE,
    JSON_PAYLOAD_CHAT_KEY,
    LEAKED_MARKER_RE,
    NON_CHAT_FIRST_PAYLOAD_KINDS,
    PERSON_MARKER_RE,
    PLAIN_VALUE_CHAT_KINDS,
)

logger = logging.getLogger("marin_x.telegram")

class MarkersMixin:
    def _extract_person_marker(self, text: str) -> str:
        """<<<PERSON:username|action|payload>>> — реальный Person Model:
        симпатии/антипатии, незакрытые темы, обещания, доверие, факты
        (с обнаружением противоречий). Тег вырезается из видимого текста."""
        match = PERSON_MARKER_RE.search(text or "")
        if not match:
            return text
        username, action, payload = match.group(1), match.group(2).strip().lower(), match.group(3).strip()
        if payload:
            if action == "fact":
                topic_key, _, statement = payload.partition(":")
                statement = statement.strip() or payload
                topic_key = (topic_key or statement).strip().lower()[:60]
                _, is_conflict = self.engine.remember_person_fact(f"person:{username}:{topic_key}", statement)
                if is_conflict:
                    logger.info("Contradiction detected for @%s on topic %r", username, topic_key)
            else:
                self.observer.apply_person_marker(username, action, payload)
            logger.info("Person marker applied: @%s %s=%r", username, action, payload)
        return PERSON_MARKER_RE.sub("", text, count=1)

    def _note_marker_issue(self, chat_id: str, note: str) -> None:
        """Stage 5.D: запоминает КОНКРЕТНУЮ формулировку проблемы для
        следующего тика этого чата (см. _last_marker_issue) — читается и
        сразу удаляется в _process_batch, одноразово."""
        self._last_marker_issue[chat_id] = note

    def _strip_leaked_markers(self, text: str, chat_id: str) -> str:
        """Защитная сетка (см. LEAKED_MARKER_RE) — вызывается ПОСЛЕДНЕЙ,
        после всех extract_*/process_readonly_markers. Если модель не
        закрыла тег (например, оборвалась на полуслове payload'а из-за
        лимита длины), настоящая ситуация уже необратима — правильные
        данные из этого куска всё равно не восстановить, поэтому просто
        обрезаем хвост до владельца, вместо того чтобы показать ему сырой
        протокольный мусор вроде "<<<ACTION:send_message|-100...|Привет...".
        Логируем полностью — это сигнал, что модель на этом провайдере
        реально не справляется с закрытием маркера, стоит смотреть логи."""
        match = LEAKED_MARKER_RE.search(text or "")
        if not match:
            return text
        logger.warning(
            "Leaked/unclosed marker stripped before sending to owner: chat=%s tail=%r",
            chat_id, text[match.start():][:300],
        )
        self._note_marker_issue(
            chat_id,
            "In your previous reply you started a hidden tag (like <<<ACTION:...>>> or "
            "<<<READ:...>>>) but never closed it with '>>>', so it had to be cut out before the "
            "owner saw it — whatever you meant to do there didn't happen. Don't repeat that: only "
            "start a tag when you're sure you can finish it fully closed in the room you have left.",
        )
        cleaned = LEAKED_MARKER_RE.sub("", text, count=1).strip()
        return cleaned

    def _repair_action_marker_fields(self, text: str, chat_id: str) -> str:
        """Вызывается ДО self.actions.extract_draft(). Чинит конкретный
        наблюдаемый сбой: модель кладёт chat/user id в description вместо
        payload (см. комментарий у ID_LIKE_DESCRIPTION_RE). Если поймали —
        переносим id в payload (как JSON-ключ для kind'ов из
        JSON_PAYLOAD_CHAT_KEY, или как есть для простых single-value
        kind'ов) и подставляем нейтральное описание вместо голого числа.
        actions.py при этом не тронут — вся починка происходит на сыром
        тексте до того, как он туда попадёт."""
        if "<<<ACTION:" not in text:
            return text

        def _fix(m: "re.Match[str]") -> str:
            kind, description, payload = m.group(1), m.group(2).strip(), m.group(3)
            if kind in NON_CHAT_FIRST_PAYLOAD_KINDS or not ID_LIKE_DESCRIPTION_RE.match(description):
                return m.group(0)
            fixed_description = f"предлагаю выполнить действие «{kind}»"
            if kind in PLAIN_VALUE_CHAT_KINDS:
                logger.warning(
                    "Repaired ACTION marker with id-in-description (plain payload): kind=%s id=%r",
                    kind, description,
                )
                self._note_marker_issue(
                    chat_id,
                    f"In your previous reply's <<<ACTION:{kind}|...>>> tag, you put a bare chat/user "
                    f"id ('{description}') in the description field (the second field, which should "
                    f"be a short human-readable sentence) instead of in the payload where it belongs "
                    f"— it had to be auto-corrected. The description field is always prose for the "
                    f"owner to read, never an id by itself.",
                )
                return f"<<<ACTION:{kind}|{fixed_description}|{description}>>>"
            chat_key = JSON_PAYLOAD_CHAT_KEY.get(kind)
            if chat_key is None:
                return m.group(0)  # неизвестный/незарегистрированный kind — extract_draft сам отбросит
            try:
                params = json.loads(payload)
                if not isinstance(params, dict):
                    return m.group(0)
            except Exception:
                # оригинальный payload вообще не JSON — чинить нечего, пусть
                # сам handler упадёт с понятной ошибкой на json.loads
                return m.group(0)
            params.setdefault(chat_key, description)
            logger.warning(
                "Repaired ACTION marker with id-in-description (JSON payload): kind=%s id=%r key=%s",
                kind, description, chat_key,
            )
            self._note_marker_issue(
                chat_id,
                f"In your previous reply's <<<ACTION:{kind}|...>>> tag, you put a bare id "
                f"('{description}') in the description field instead of putting it as the "
                f"'{chat_key}' key inside the JSON payload — it had to be auto-corrected. The "
                f"description field is always a short prose sentence for the owner, never an id; "
                f"the id belongs inside the JSON payload under its named key.",
            )
            fixed_payload = json.dumps(params, ensure_ascii=False)
            return f"<<<ACTION:{kind}|{fixed_description}|{fixed_payload}>>>"

        return ACTION_MARKER_RE.sub(_fix, text)

    def _extract_belief_marker(self, text: str) -> str:
        """Если модель пометила собственную догадку маркером BELIEF, реально
        сохраняет её как LLM_GENERATED-belief с ограниченной confidence
        (см. CognitiveEngine.remember_guess) и вырезает служебный тег."""
        match = BELIEF_MARKER_RE.search(text or "")
        if not match:
            return text
        statement = match.group(1).strip()
        if statement:
            self.engine.remember_guess(statement)
            logger.info("Recorded own guess as LLM_GENERATED belief: %r", statement)
        return BELIEF_MARKER_RE.sub("", text, count=1)

    def _extract_goal_marker(self, text: str) -> str:
        """Если модель пометила что-то маркером GOAL, реально кладёт это в
        GoalSet движка (см. CognitiveEngine.add_current_goal) и вырезает
        маркер из видимого текста — владелец не должен видеть служебный тег,
        сама Марин обычно и так проговаривает это своими словами рядом."""
        match = GOAL_MARKER_RE.search(text or "")
        if not match:
            return text
        description = match.group(1).strip()
        if description:
            self.engine.add_current_goal(description)
            logger.info("Added current goal: %r", description)
        return GOAL_MARKER_RE.sub("", text, count=1)

    def _extract_autogoal_marker(self, text: str, owner_id: str) -> str:
        """Stage 4: <<<AUTOGOAL:описание>>> — владелец попросил что-то
        долгосрочное и автономное ("создай канал и веди его сама"), а не
        просто "не забудь X" (это остаётся обычным <<<GOAL:...>>> выше).
        Создаёт Goal через goal_executor (тот же GoalSet, LONG_TERM-уровня
        со статусом PLANNING) — реальное планирование и исполнение шагов
        происходит позже, из _scheduler_loop, не прямо тут."""
        match = AUTOGOAL_MARKER_RE.search(text or "")
        if not match:
            return text
        description = match.group(1).strip()
        if description:
            goal_id = self.goal_executor.create_goal_from_description(description, owner_id)
            logger.info("[GOAL] created via AUTOGOAL marker goal_id=%s", goal_id)
        return AUTOGOAL_MARKER_RE.sub("", text, count=1)

    @staticmethod
    def _extract_post_markers(text: str) -> "tuple[str, list[str]]":
        """<<<POST:бриф>>> — владелец (любой формулировкой) хочет пост в
        канал. Маркер вырезается из видимого текста, брифы возвращаются —
        публикацию делает _process_batch через ChannelPublisher. Берём
        не больше одного поста за реплику: модель иногда дублирует тег."""
        briefs = [m.group(1).strip() for m in POST_MARKER_RE.finditer(text or "")]
        if not briefs:
            return text, []
        return POST_MARKER_RE.sub("", text).strip(), briefs[:1]
