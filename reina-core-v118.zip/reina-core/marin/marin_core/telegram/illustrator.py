"""illustrator.py — topical illustrations for channel posts.

Complements selfie.py: a selfie is always Marin's own face; an illustration
is a scene/mood picture matching a post's TOPIC (a rainy street, a cup of
coffee, an abstract sunset) with no consistent character and no reference
image. Same OpenRouter multimodal image endpoint, same defense-in-depth
safety contract (hard-coded style/negative prompt, lexical pre-filter) as
selfie.py — see that module's docstring for the reasoning.
"""
from __future__ import annotations

import base64
import logging
from dataclasses import dataclass
from typing import Protocol

logger = logging.getLogger("marin_core.telegram.illustrator")

ILLUSTRATION_STYLE_GUARDRAIL = (
    "warm editorial photography or soft painterly illustration, tasteful, safe-for-work, "
    "no readable text or watermarks in the image, no real recognizable public figures"
)
ILLUSTRATION_NEGATIVE_PROMPT = (
    "nudity, nsfw, sexual content, gore, violence, disturbing imagery, text, watermark, logo, "
    "real celebrity or public figure likeness"
)

_BLOCKED_TERMS = (
    "nude", "naked", "nsfw", "sex", "porn", "gore", "violence", "голая", "голышом",
    "без одежды", "секс", "порно", "жестокост", "расчленен", "кров",
)


def _looks_unsafe(prompt_hint: str) -> bool:
    text = (prompt_hint or "").lower()
    return any(term in text for term in _BLOCKED_TERMS)


class IllustrationGenerationError(Exception):
    """Ожидаемая, обрабатываемая ошибка — как SelfieGenerationError у селфи."""


class IllustrationGenerator(Protocol):
    async def generate(self, prompt_hint: str) -> bytes: ...


class DisabledIllustrationGenerator:
    async def generate(self, prompt_hint: str) -> bytes:
        raise IllustrationGenerationError(
            "Генерация иллюстраций не настроена — нужен MARIN_ILLUSTRATION_API_KEY "
            "(или уже существующий MARIN_OPENROUTER_API_KEY) в .env."
        )


@dataclass
class OpenRouterIllustrationConfig:
    api_key: str
    model: str = "google/gemini-2.5-flash-image"
    base_url: str = "https://openrouter.ai/api/v1"
    timeout: float = 60.0


class OpenRouterIllustrationGenerator:
    """Тот же unified Image API OpenRouter, что и у селфи (см. selfie.py),
    но без reference-фото — иллюстрация не обязана быть похожа на Марин."""

    def __init__(self, config: OpenRouterIllustrationConfig):
        self.config = config

    async def generate(self, prompt_hint: str) -> bytes:
        if _looks_unsafe(prompt_hint):
            raise IllustrationGenerationError("Такую иллюстрацию не сгенерирую — похоже на небезопасный запрос.")

        import asyncio
        try:
            import requests
        except ImportError as e:
            raise IllustrationGenerationError(
                "OpenRouterIllustrationGenerator requires the 'requests' package (pip install requests)."
            ) from e

        payload = {
            "model": self.config.model,
            "messages": [{"role": "user", "content": self._build_prompt(prompt_hint)}],
            "modalities": ["image", "text"],
        }
        headers = {"Authorization": f"Bearer {self.config.api_key}", "Content-Type": "application/json"}

        def _do_request():
            resp = requests.post(
                f"{self.config.base_url.rstrip('/')}/chat/completions",
                json=payload, headers=headers, timeout=self.config.timeout,
            )
            resp.raise_for_status()
            return resp.json()

        try:
            data = await asyncio.to_thread(_do_request)
        except Exception as e:  # noqa: BLE001
            raise IllustrationGenerationError(f"OpenRouter image API недоступен: {e}") from e
        return self._extract_image_bytes(data)

    def _build_prompt(self, prompt_hint: str) -> str:
        hint = (prompt_hint or "").strip() or "a calm, atmospheric everyday scene"
        return f"{hint}. Style: {ILLUSTRATION_STYLE_GUARDRAIL}. Avoid: {ILLUSTRATION_NEGATIVE_PROMPT}."

    @staticmethod
    def _extract_image_bytes(data: dict) -> bytes:
        choices = data.get("choices") or []
        if not choices:
            raise IllustrationGenerationError(f"OpenRouter image API вернул пустой ответ: {data!r}")
        images = (choices[0].get("message") or {}).get("images") or []
        if not images:
            raise IllustrationGenerationError("Модель не вернула изображение (возможно, отклонила промпт).")
        url = (images[0].get("image_url") or {}).get("url", "")
        if not url.startswith("data:"):
            raise IllustrationGenerationError(f"Неожиданный формат ответа изображения: {url[:60]!r}")
        return base64.b64decode(url.split(",", 1)[-1])
