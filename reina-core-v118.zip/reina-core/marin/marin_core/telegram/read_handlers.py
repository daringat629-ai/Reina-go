"""Curated read-only Telegram lookups (<<<READ:...>>>).

Mixin of MarinTelegramClient — relies on attributes created in
MarinTelegramClient.__init__ (self.client, self.engine, self.config, ...).
"""
from __future__ import annotations

import logging
import os
from telethon import functions, types

from .settings import (
    READONLY_MARKER_RE,
)

logger = logging.getLogger("marin_x.telegram")

class ReadActionsMixin:
    def _register_readonly_actions(self) -> None:
        """Read-only действия — курируются точно так же явным списком, как
        и ActionRegistry, но им не нужен draft/confirm (ничего не меняют),
        поэтому они не проходят через ActionRegistry.register(), а лежат в
        отдельном курируемом словаре и выполняются сразу же, как только
        модель их запросила текущим тиком. ActionRegistry (actions.py) при
        этом не тронут вообще."""
        self._readonly_actions = {
            "get_dialogs": self._read_get_dialogs,
            "get_chat_info": self._read_get_chat_info,
            "get_user_info": self._read_get_user_info,
            "get_messages": self._read_get_messages,
            "search_messages": self._read_search_messages,
            "get_participants": self._read_get_participants,
            "get_admins": self._read_get_admins,
            "get_contacts": self._read_get_contacts,
            "get_blocked_users": self._read_get_blocked_users,
            "get_message_reactions": self._read_get_message_reactions,
            "get_saved_messages": self._read_get_saved_messages,
            "get_drafts": self._read_get_drafts,
            "get_account_info": self._read_get_account_info,
            "get_bio": self._read_get_bio,
            # -- Этап 3 --
            "get_poll_results": self._read_get_poll_results,
            "get_invite_links": self._read_get_invite_links,
            "get_join_requests": self._read_get_join_requests,
            "search_stickers": self._read_search_stickers,
            "get_sticker_set": self._read_get_sticker_set,
            "get_dialog_filters": self._read_get_dialog_filters,
            "get_scheduled_messages": self._read_get_scheduled_messages,
            "download_media": self._read_download_media,
            "get_channel_info": self._read_get_chat_info,  # тот же handler, что get_chat_info
            "get_chat_permissions": self._read_get_chat_permissions,
            "get_user_permissions": self._read_get_user_permissions,
            "get_message": self._read_get_message,
            "get_pinned_messages": self._read_get_pinned_messages,
        }

    async def _collect_readonly_markers(self, text: str) -> "tuple[str, list]":
        """Выполняет <<<READ:...>>> и ВЫРЕЗАЕТ маркеры, возвращая результаты
        отдельно — чтобы модель прочитала их и ответила по-человечески.
        Раньше результат подставлялся прямо в текст, и владелец видел сырое
        «(id=4403242978, тип=Channel, участников: 2)»."""
        if not text or "<<<READ:" not in text:
            return text, []
        results = []
        for m in READONLY_MARKER_RE.finditer(text):
            kind, payload = m.group(1), m.group(2).strip()
            handler = self._readonly_actions.get(kind)
            if handler is None:
                logger.warning("Model proposed unknown/unregistered read kind %r — ignored", kind)
                continue
            try:
                res = await handler(payload)
            except Exception as e:  # noqa: BLE001
                logger.warning("Readonly action %s failed for %r", kind, payload, exc_info=True)
                res = f"не получилось: {e}"
            results.append((kind, payload, res))
        return READONLY_MARKER_RE.sub("", text).strip(), results

    async def _process_readonly_markers(self, text: str) -> str:
        """Находит <<<READ:kind|payload>>>, выполняет только известные
        kind'ы из self._readonly_actions и подставляет результат вместо
        маркера. Неизвестный/незарегистрированный kind — как и в
        ActionRegistry, маркер молча вырезается, побочных эффектов нет."""
        if not text or "<<<READ:" not in text:
            return text

        async def _replace(match: "re.Match[str]") -> str:
            kind = match.group(1)
            payload = match.group(2).strip()
            handler = self._readonly_actions.get(kind)
            if handler is None:
                logger.warning("Model proposed unknown/unregistered read kind %r — ignored", kind)
                return ""
            try:
                return await handler(payload)
            except Exception:
                logger.warning("Readonly action %s failed for %r", kind, payload, exc_info=True)
                return "(не получилось получить данные)"

        # re.sub не умеет ждать корутины, поэтому обходим совпадения вручную.
        result = []
        last_end = 0
        for m in READONLY_MARKER_RE.finditer(text):
            result.append(text[last_end:m.start()])
            result.append(await _replace(m))
            last_end = m.end()
        result.append(text[last_end:])
        return "".join(result)

    # -- Этап 2: read-only handlers (без confirm, см. _process_readonly_markers) --

    async def _read_get_dialogs(self, payload: str) -> str:
        """Человекочитаемо, без построчного дампа id — id тут почти никогда
        не нужен владельцу в чате; если понадобится конкретный чат, для
        этого есть get_chat_info с payload=имя/username."""
        dialogs = await self.client.get_dialogs(limit=20)
        if not dialogs:
            return "диалогов пока нет"
        names = [d.name or d.title or str(d.id) for d in dialogs]
        shown, rest = names[:12], names[12:]
        listed = ", ".join(shown)
        if rest:
            listed += f" и ещё {len(rest)}"
        return f"{len(names)} диалогов: {listed}"

    async def _read_get_chat_info(self, payload: str) -> str:
        entity = await self._resolve_peer(payload)
        title = getattr(entity, "title", None) or getattr(entity, "first_name", None) or "?"
        kind = type(entity).__name__
        participants = getattr(entity, "participants_count", None)
        extra = f", участников: {participants}" if participants else ""
        return f"«{title}» (id={entity.id}, тип={kind}{extra})"

    async def _read_get_user_info(self, payload: str) -> str:
        entity = await self._resolve_peer(payload)
        if getattr(entity, "title", None) is not None or getattr(entity, "broadcast", None) is not None:
            # Не человек. Раньше канал отдавался как «(без имени) — id=…», и модель
            # делала вывод «@kitagawa_room — это живой юзер».
            what = "канал" if getattr(entity, "broadcast", False) else "группа"
            uname = getattr(entity, "username", None)
            return (f"это не человек, а {what} «{getattr(entity, 'title', '?')}»"
                    + (f" (@{uname})" if uname else "") + f", id={entity.id}")
        if getattr(entity, "bot", False):
            return f"это бот @{getattr(entity, 'username', '')} (id={entity.id})"
        full_name = " ".join(filter(None, [getattr(entity, "first_name", ""), getattr(entity, "last_name", "")])).strip()
        username = getattr(entity, "username", None)
        return f"{full_name or '(без имени)'} — id={entity.id}" + (f", @{username}" if username else "")

    async def _read_get_messages(self, payload: str) -> str:
        parts = payload.split("|", 1)
        chat_raw = parts[0].strip()
        limit = int(parts[1].strip()) if len(parts) > 1 and parts[1].strip().isdigit() else 10
        limit = min(limit, 30)
        entity = await self._resolve_peer(chat_raw)
        msgs = await self.client.get_messages(entity, limit=limit)
        if not msgs:
            return "(сообщений нет)"
        lines = [f"[{m.id}] {(m.raw_text or '(медиа)')[:120]}" for m in reversed(list(msgs))]
        return "\n".join(lines)

    async def _read_search_messages(self, payload: str) -> str:
        chat_raw, query = payload.split("|", 1)
        entity = await self._resolve_peer(chat_raw)
        found = await self.client.get_messages(entity, search=query.strip(), limit=10)
        if not found:
            return "(ничего не нашла)"
        lines = [f"[{m.id}] {(m.raw_text or '(медиа)')[:120]}" for m in found]
        return "\n".join(lines)

    async def _read_get_participants(self, payload: str) -> str:
        entity = await self._resolve_peer(payload)
        participants = await self.client.get_participants(entity, limit=50)
        if not participants:
            return "(участников не нашла)"
        lines = [f"{p.first_name or ''} (@{p.username})" if p.username else f"{p.first_name or p.id}" for p in participants]
        return "Участники: " + ", ".join(lines)

    async def _read_get_admins(self, payload: str) -> str:
        entity = await self._resolve_peer(payload)
        admins = await self.client.get_participants(entity, filter=types.ChannelParticipantsAdmins())
        if not admins:
            return "(админов не нашла)"
        lines = [f"{a.first_name or ''} (@{a.username})" if a.username else f"{a.first_name or a.id}" for a in admins]
        return "Админы: " + ", ".join(lines)

    async def _read_get_contacts(self, payload: str) -> str:
        result = await self.client(functions.contacts.GetContactsRequest(hash=0))
        users = getattr(result, "users", [])
        if not users:
            return "(контактов нет)"
        lines = [f"{u.first_name or ''} (@{u.username})" if u.username else f"{u.first_name or u.id}" for u in users[:50]]
        return "Контакты: " + ", ".join(lines)

    async def _read_get_blocked_users(self, payload: str) -> str:
        result = await self.client(functions.contacts.GetBlockedRequest(offset=0, limit=50))
        users = getattr(result, "users", [])
        if not users:
            return "(заблокированных нет)"
        lines = [f"{u.first_name or ''} (@{u.username})" if u.username else f"{u.first_name or u.id}" for u in users]
        return "Заблокированы: " + ", ".join(lines)

    async def _read_get_message_reactions(self, payload: str) -> str:
        chat_raw, msg_id_raw = payload.split("|", 1)
        entity = await self._resolve_peer(chat_raw)
        msg = await self.client.get_messages(entity, ids=int(msg_id_raw.strip()))
        if msg is None or not getattr(msg, "reactions", None):
            return "(реакций нет)"
        parts = []
        for r in msg.reactions.results:
            emoji = getattr(r.reaction, "emoticon", None) or type(r.reaction).__name__
            parts.append(f"{emoji}: {r.count}")
        return "Реакции: " + ", ".join(parts) if parts else "(реакций нет)"

    async def _read_get_saved_messages(self, payload: str) -> str:
        msgs = await self.client.get_messages("me", limit=15)
        if not msgs:
            return "(в избранном пусто)"
        lines = [f"[{m.id}] {(m.raw_text or '(медиа)')[:120]}" for m in msgs]
        return "\n".join(lines)

    async def _read_get_drafts(self, payload: str) -> str:
        drafts = await self.client.get_drafts()
        active = [d for d in drafts if d.text]
        if not active:
            return "(черновиков нет)"
        lines = [f"{getattr(d.entity, 'title', None) or getattr(d.entity, 'first_name', d.entity.id)}: {d.text[:80]}" for d in active[:20]]
        return "Черновики:\n" + "\n".join(lines)

    async def _read_get_account_info(self, payload: str) -> str:
        me = await self.client.get_me()
        username = f"@{me.username}" if me.username else "(без username)"
        about = await self._fetch_own_about()
        base = f"{me.first_name or ''} {me.last_name or ''} {username}, id={me.id}".strip()
        return f"{base}. Био: {about}" if about else base

    async def _read_get_bio(self, payload: str) -> str:
        """Отдельное явное действие для 'что у меня в био/описании' — до
        этого модель иногда путала это с get_account_info (там нет about),
        и как результат придумывала что-то не то. Теперь есть прямой ответ
        именно на этот вопрос."""
        about = await self._fetch_own_about()
        return about or "био сейчас пустое"

    async def _fetch_own_about(self) -> str:
        """functions.users.GetFullUserRequest — единственный способ узнать
        текущий about/bio: обычный get_me() его не возвращает вообще.
        Структура ответа отличалась между слоями Telethon (обёртка
        UserFull то с .full_user.about, то напрямую с .about) — читаем
        адаптивно, как и в остальных версионно-чувствительных местах."""
        try:
            result = await self.client(functions.users.GetFullUserRequest(id="me"))
        except Exception:
            logger.warning("Could not fetch own about/bio", exc_info=True)
            return ""
        full = getattr(result, "full_user", result)
        return (getattr(full, "about", None) or "").strip()

    # -- Этап 3: read-only handlers --------------------------------------

    async def _read_get_poll_results(self, payload: str) -> str:
        """payload = 'chat|message_id'. PollResults/PollAnswerVoters —
        одна из самых стабильных частей схемы опросов (голоса считаются по
        bytes-'option', а не по тексту), поэтому в отличие от create_poll
        тут не нужна адаптация под версию."""
        chat_raw, msg_id_raw = payload.split("|", 1)
        entity = await self._resolve_peer(chat_raw)
        msg = await self.client.get_messages(entity, ids=int(msg_id_raw.strip()))
        results = getattr(msg, "poll_results", None) if msg else None
        if results is None or not getattr(results, "results", None):
            return "(голосов пока нет или это не опрос)"
        poll = getattr(msg, "poll", None)
        option_text = {}
        if poll is not None:
            for ans in poll.answers:
                text = getattr(ans.text, "text", ans.text)
                option_text[ans.option] = text
        lines = []
        for r in results.results:
            label = option_text.get(r.option, r.option)
            lines.append(f"{label}: {r.voters}")
        total = getattr(results, "total_voters", None)
        header = f"Всего голосов: {total}\n" if total is not None else ""
        return header + "\n".join(lines)

    async def _read_get_invite_links(self, payload: str) -> str:
        entity = await self._resolve_peer(payload)
        me = await self.client.get_me()
        result = await self.client(functions.messages.GetExportedChatInvitesRequest(
            peer=entity, admin_id=me, limit=20,
        ))
        invites = getattr(result, "invites", [])
        if not invites:
            return "(активных ссылок-приглашений нет)"
        lines = [f"{inv.link} (использований: {inv.usage or 0})" for inv in invites]
        return "\n".join(lines)

    async def _read_get_join_requests(self, payload: str) -> str:
        entity = await self._resolve_peer(payload)
        result = await self.client(functions.messages.GetChatInviteImportersRequest(
            peer=entity, requested=True, q="", limit=30,
            offset_date=0, offset_user=types.InputUserEmpty(),
        ))
        users = getattr(result, "users", [])
        if not users:
            return "(заявок на вступление нет)"
        lines = [f"{u.first_name or ''} (@{u.username})" if u.username else f"{u.first_name or u.id}" for u in users]
        return "Заявки на вступление: " + ", ".join(lines)

    async def _read_search_stickers(self, payload: str) -> str:
        result = await self.client(functions.messages.SearchStickerSetsRequest(
            q=payload.strip(), hash=0,
        ))
        sets = getattr(result, "sets", [])
        if not sets:
            return "(наборов стикеров не нашла)"
        lines = [f"{s.title} (@{s.short_name})" for s in sets[:15]]
        return "Наборы стикеров: " + ", ".join(lines)

    async def _read_get_sticker_set(self, payload: str) -> str:
        """Тот же вызов, что уже используется в этом файле для загрузки
        медиа-паков (см. _fetch_pack_by_short_name) — переиспользую тот же
        реальный, уже проверенный в этом проекте Request."""
        result = await self.client(functions.messages.GetStickerSetRequest(
            stickerset=types.InputStickerSetShortName(short_name=payload.strip()),
            hash=0,
        ))
        set_info = getattr(result, "set", None)
        count = len(getattr(result, "documents", []) or getattr(result, "packs", []) or [])
        if set_info is None:
            return "(не нашла такой набор)"
        return f"«{set_info.title}» (@{set_info.short_name}), стикеров: {getattr(set_info, 'count', count)}"

    async def _read_get_dialog_filters(self, payload: str) -> str:
        """Структура ответа GetDialogFiltersRequest менялась между слоями
        (то плоский список, то контейнер с .filters) — читаю адаптивно,
        как и просил владелец, вместо жёсткого предположения об одной форме."""
        result = await self.client(functions.messages.GetDialogFiltersRequest())
        items = getattr(result, "filters", result)
        if not items:
            return "(папок нет)"
        lines = []
        for f in items:
            title = getattr(f, "title", None)
            title_text = getattr(title, "text", title) if title is not None else type(f).__name__
            lines.append(str(title_text))
        return "Папки: " + ", ".join(lines)

    async def _read_get_scheduled_messages(self, payload: str) -> str:
        entity = await self._resolve_peer(payload)
        msgs = await self.client.get_messages(entity, scheduled=True, limit=30)
        if not msgs:
            return "(отложенных сообщений нет)"
        lines = [f"[{m.id}] {(m.raw_text or '(медиа)')[:120]}" for m in msgs]
        return "\n".join(lines)

    async def _read_download_media(self, payload: str) -> str:
        """payload = 'chat|message_id'. Сохраняет ТОЛЬКО в фиксированную
        внутреннюю папку рядом с session-файлом, с именем, полностью
        построенным из чисел (chat id + message id) — модель никогда не
        передаёт и не видит сам путь, поэтому нет риска path traversal или
        доступа к произвольному файлу на диске."""
        chat_raw, msg_id_raw = payload.split("|", 1)
        entity = await self._resolve_peer(chat_raw)
        msg_id = int(msg_id_raw.strip())
        msg = await self.client.get_messages(entity, ids=msg_id)
        if msg is None or not getattr(msg, "media", None):
            return "(в этом сообщении нет медиа)"
        base_dir = os.path.join(os.path.dirname(os.path.abspath(self.config.session)) or ".", "marin_downloads")
        os.makedirs(base_dir, exist_ok=True)
        safe_name = f"{abs(int(entity.id))}_{msg_id}"
        saved_path = await self.client.download_media(msg, file=os.path.join(base_dir, safe_name))
        if not saved_path:
            return "(не получилось скачать)"
        size = os.path.getsize(saved_path)
        return f"Скачала в {saved_path} ({size} байт)"

    async def _read_get_chat_permissions(self, payload: str) -> str:
        entity = await self._resolve_peer(payload)
        rights = getattr(entity, "default_banned_rights", None)
        if rights is None:
            return "(у этого чата нет настраиваемых дефолтных прав)"
        denied = [f for f in (
            "send_messages", "send_media", "send_stickers", "send_gifs",
            "send_games", "send_inline", "embed_links", "send_polls",
            "invite_users", "pin_messages", "change_info",
        ) if getattr(rights, f, False)]
        return "Запрещено по умолчанию: " + (", ".join(denied) if denied else "ничего, все права разрешены")

    async def _read_get_user_permissions(self, payload: str) -> str:
        chat_raw, user_raw = payload.split("|", 1)
        chat = await self._resolve_peer(chat_raw)
        user = await self._resolve_peer(user_raw)
        perms = await self.client.get_permissions(chat, user)
        flags = []
        for name in ("is_admin", "is_creator", "is_banned", "has_default_permissions"):
            if getattr(perms, name, False):
                flags.append(name)
        return f"@{user_raw.strip().lstrip('@')}: " + (", ".join(flags) if flags else "обычный участник")

    async def _read_get_message(self, payload: str) -> str:
        chat_raw, msg_id_raw = payload.split("|", 1)
        entity = await self._resolve_peer(chat_raw)
        msg = await self.client.get_messages(entity, ids=int(msg_id_raw.strip()))
        if msg is None:
            return "(такого сообщения не нашла)"
        return f"[{msg.id}] {msg.raw_text or '(медиа без текста)'}"

    async def _read_get_pinned_messages(self, payload: str) -> str:
        entity = await self._resolve_peer(payload)
        msgs = await self.client.get_messages(entity, filter=types.InputMessagesFilterPinned, limit=30)
        if not msgs:
            return "(закреплённых сообщений нет)"
        lines = [f"[{m.id}] {(m.raw_text or '(медиа)')[:120]}" for m in msgs]
        return "\n".join(lines)
