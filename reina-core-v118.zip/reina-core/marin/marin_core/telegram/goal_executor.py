"""
Stage 4 — autonomous goal execution.

Bridges Goal/GoalSet (marin_core/goals/goals.py) to the EXISTING Telegram
ActionRegistry (actions.py) and the EXISTING read-only action dict
(MarinTelegramClient._readonly_actions) — without a parallel action system
and without bypassing the existing draft -> confirm -> execute flow for
WRITE/ADMIN actions.

Design note — why this file does NOT reuse reasoning/planning.py or
decision/decision_engine.py: both of those operate over ActionCandidate /
ActionType, the small closed set of *conversational* moves (ANSWER,
ASK_QUESTION, CLARIFY, WAIT, ...) picked once per incoming message inside a
single cognitive tick. Decomposing "create and run a channel" into an
ordered sequence of concrete Telegram Actions executed over days is a
different problem; forcing it through that module would either break its
conversational contract or produce a fake integration that doesn't really
plan anything. Instead:

  - planning reuses the SAME already-configured LLMProvider
    (engine.language_planner.provider) that generates chat replies, but
    with ActionType.CHANGE_GOAL (an existing, previously-unused ActionType
    — see action/action.py) so providers.py gives it a dedicated
    JSON-only system prompt instead of the chat-reply one;
  - the plan is stored directly on the existing Goal object
    (goals/goals.py) — no second goal system;
  - WRITE/ADMIN steps are executed by draft-confirming them through the
    exact same ActionRegistry.extract_draft() / maybe_confirm() the LLM's
    own <<<ACTION:...>>> markers use — a human owner still has to reply to
    confirm, exactly as before Stage 4;
  - READ steps are executed directly against the existing
    _readonly_actions dict (same as <<<READ:...>>> markers) — no
    confirmation needed, same as before Stage 4;
  - every step's `kind` is checked against the REAL registered action
    kinds (ActionRegistry.known_kinds() / _readonly_actions.keys()) both
    at plan time and at execution time — an invented/hallucinated kind
    cannot reach Telegram; it's dropped and logged, same philosophy as
    ActionRegistry's own "unknown kind is silently ignored".
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
import string
import time
from typing import Any, Dict, List, Optional, TYPE_CHECKING

from ..goals.goals import Goal, GoalStatus
from ..action.action import ActionType
from ..llm.interface import LanguagePlanningInput

if TYPE_CHECKING:  # pragma: no cover - только для типов, без рантайм-цикла импорта
    from .client import MarinTelegramClient

logger = logging.getLogger("marin_core.telegram.goal_executor")

# -- защита от busy loop / runaway планирования (§11 Stage 4) --------------
MAX_STEPS_PER_TICK = 8              # сколько READ-шагов подряд можно сделать за один тик scheduler'а
MAX_PLAN_STEPS = 40                 # план длиннее этого считается подозрительным и обрезается
RETRY_BACKOFF_SECONDS = 15 * 60.0   # базовый backoff между повторами (умножается на retry_count)
WAITING_RENOTIFY_SECONDS = 6 * 3600.0
DEFAULT_CYCLE_INTERVAL_SECONDS = 24 * 3600.0
MIN_CYCLE_INTERVAL_SECONDS = 30 * 60.0  # нельзя попросить публиковать чаще, чем раз в 30 минут

# Kind'ы, для которых нужно НЕ повторять write-действие, если контекст уже
# показывает, что оно один раз успешно выполнилось (§11/§12 Stage 4).
IDEMPOTENT_ONCE_KINDS = {
    "create_channel": "telegram_channel_id",
}

# -- auto_approve (per-goal, owner-toggleable) --------------------------
# Явно ограниченный белый список: только контентные действия внутри уже
# один раз одобренного владельцем канала/чата. НИКОГДА не включает сюда
# ничего, что меняет состав участников, права, настройки аккаунта/чата,
# ссылки-приглашения или что-либо необратимое/затрагивающее безопасность
# — эти kind'ы всегда идут через обычное подтверждение, что бы ни было
# сказано владельцем и что бы ни выставил auto_approve.
# Шаги «опубликовать в канал» — после первого поста по цели они дубли.
_POST_LIKE_KINDS = {"send_message", "send_photo", "send_selfie", "send_file", "send_album", "send_video"}
_SELFIE_RE = re.compile(r"селфи|selfie|своё фото|свое фото|фото себя", re.IGNORECASE)

SAFE_AUTO_APPROVE_KINDS = {
    "send_message", "reply_to_message", "edit_message",
    "send_photo", "send_video", "send_document", "send_file",
    "send_audio", "send_voice", "send_video_note", "send_album", "send_sticker",
    "send_reaction", "create_poll", "pin_message", "unpin_message",
    "schedule_message", "edit_scheduled_message",
}
# Локальная копия client.py::JSON_PAYLOAD_CHAT_KEY, только для того, чтобы
# _target_matches_goal_channel могла проверить правильный ключ в payload —
# не импортируется из client.py напрямую, чтобы не тянуть Telethon-зависимость
# в этот модуль (см. docstring файла). Полный список см. в client.py — тут
# нужны только kind'ы из SAFE_AUTO_APPROVE_KINDS выше.
_AUTO_APPROVE_CHAT_KEY = {
    "send_message": "to", "reply_to_message": "chat", "edit_message": "chat",
    "send_photo": "to", "send_video": "to", "send_document": "to", "send_file": "to",
    "send_audio": "to", "send_voice": "to", "send_video_note": "to", "send_album": "to",
    "send_sticker": "chat", "send_reaction": "chat", "create_poll": "chat",
    "pin_message": "chat", "unpin_message": "chat", "schedule_message": "chat",
    "edit_scheduled_message": "chat",
}

_JSON_FENCE_RE = re.compile(r"^```(?:json)?\s*|\s*```$", re.IGNORECASE | re.MULTILINE)


class AutonomousGoalExecutor:
    """Один экземпляр на MarinTelegramClient (см. __init__ там). Держит
    только ссылку на client — своего state, кроме служебной привязки
    chat_id -> goal_id на время ожидания confirmation, не хранит: реальное
    состояние живёт в Goal (goals/goals.py), которая уже персистится вместе
    с остальным GoalSet (см. persistence.py)."""

    def __init__(self, telegram_client: "MarinTelegramClient"):
        self._tc = telegram_client
        # chat_id -> goal_id, только пока write-шаг ждёт подтверждения —
        # намеренно НЕ персистится: после рестарта пара "какой чат ждёт
        # подтверждения какой цели" реконструируется из самого Goal.status
        # (WAITING) при следующей проверке владельцем, а если подтверждение
        # придёт в чат раньше первого тика после рестарта, maybe_confirm
        # всё равно исполнит handler (сам ActionRegistry это переживёт),
        # просто goal state в этот раз не обновится этим конкретным
        # подтверждением — не хуже, чем до Stage 4.
        self._pending_goal_by_chat: Dict[str, str] = {}
        # Автопостинг для уже существующих автономных целей тоже включён:
        # безопасные контентные действия внутри привязанного канала не ждут
        # ручного «да». Опасные/admin-действия по-прежнему не попадают
        # в SAFE_AUTO_APPROVE_KINDS.
        try:
            for _goal in self._tc.engine.goal_set.goals.values():
                if getattr(_goal, "active", False) and getattr(_goal, "level", None) is not None:
                    if getattr(_goal, "auto_approve", False) is False:
                        _goal.auto_approve = True
                        _goal.updated_at = time.time()
        except Exception:
            logger.debug("[GOAL] could not migrate existing goals to auto_approve", exc_info=True)

    # === публичный интерфейс, используемый из client.py ====================

    def create_goal_from_description(self, description: str, owner_id: str, context: Optional[Dict[str, Any]] = None) -> str:
        """Создаёт LONG_TERM Goal через существующий CognitiveEngine.
        Синхронно (без сети) — реальное планирование происходит позже,
        на следующем тике scheduler'а (см. advance_due_goals). ``context``
        помечает происхождение цели (напр. {"self_initiated": True} —
        см. engine/autonomous_life.py::_self_initiative_pulse), не влияя на
        сам план/исполнение — обычный owner-триггер context не передаёт."""
        goal_id = self._tc.engine.add_autonomous_goal(description, owner_id=owner_id, context=context)
        goal = self._tc.engine.goal_set.goals[goal_id]
        goal.status = GoalStatus.PLANNING
        goal.next_execution = time.time()
        logger.info("[GOAL] created goal_id=%s owner=%s description=%r", goal_id, owner_id, description[:200])
        return goal_id

    async def advance_due_goals(self) -> None:
        """Вызывается из client.py::_scheduler_loop раз в SCHEDULER_CHECK_INTERVAL.
        НЕ busy loop: каждая цель сама решает своё next_execution, тут просто
        периодическая проверка "не пора ли кому-то из них"."""
        owner_id = self._tc.config.owner_id
        if not owner_id:
            return
        due = self._tc.engine.goal_set.due_autonomous_goals(owner_id=owner_id)
        for goal in due:
            try:
                await self._advance_one(goal)
            except Exception:
                logger.exception("[GOAL] tick raised goal_id=%s", goal.id)
                goal.failure_count += 1
                goal.updated_at = time.time()
                goal.next_execution = time.time() + RETRY_BACKOFF_SECONDS * max(1, goal.failure_count)

    async def on_pending_confirmed(self, chat_id: str, result_text: str) -> None:
        """Вызывается из client.py сразу после того, как
        ActionRegistry.maybe_confirm() реально исполнил handler для этого
        чата — client.py сам решает, был ли это goal-шаг (проверяя
        _pending_goal_by_chat), это просто callback с результатом."""
        goal_id = self._pending_goal_by_chat.pop(chat_id, None)
        if goal_id is None:
            return
        goal = self._tc.engine.goal_set.goals.get(goal_id)
        if goal is None:
            return
        await self._handle_step_result(goal, result_text, auto_approved=False)

    async def _handle_step_result(self, goal: Goal, result_text: str, auto_approved: bool) -> bool:
        """Общая логика success/retry/fail/verify для write-шага — не важно,
        подтвердил его владелец вручную (on_pending_confirmed) или он был
        выполнен сам в рамках auto_approve (_advance_one). Возвращает True,
        если можно продолжать выполнять план в этом же тике."""
        goal.last_result = result_text
        goal.last_execution = time.time()
        goal.updated_at = time.time()
        success = (result_text or "").strip().lower().startswith("готово")
        logger.info(
            "[GOAL] action_completed goal_id=%s step=%s result=%r success=%s auto_approved=%s",
            goal.id, goal.current_step, (result_text or "")[:200], success, auto_approved,
        )
        if not success:
            goal.failure_count += 1
            goal.retry_count += 1
            if goal.retry_count > goal.max_retries:
                goal.status = GoalStatus.FAILED
                goal.active = False
                goal.next_execution = None
                logger.info("[GOAL] failed goal_id=%s reason=max_retries_on_step", goal.id)
                await self._notify_owner(
                    goal, f"С «{goal.description}» так и не вышло — {result_text.rstrip('.')}. "
                          f"Не буду долбиться дальше, если хочешь — попробуем по-другому."
                )
                return False
            logger.info("[GOAL] retry goal_id=%s retry_count=%s", goal.id, goal.retry_count)
            goal.status = GoalStatus.RUNNING
            goal.next_execution = time.time() + RETRY_BACKOFF_SECONDS * goal.retry_count
            return False

        goal.failure_count = 0
        goal.retry_count = 0
        await self._verify_and_advance(goal)
        return True

    def status_text(self, goal: Goal) -> str:
        step_info = f"{goal.current_step}/{goal.total_steps}" if goal.total_steps else "-"
        auto = "включено (без подтверждения на постах)" if goal.auto_approve else "выключено (спрашивает каждый раз)"
        return (
            f"«{goal.description}» [{goal.id[:8]}]\n"
            f"Статус: {goal.status.value}, шаг {step_info}\n"
            f"Автоподтверждение постов: {auto}\n"
            f"Последний результат: {goal.last_result or '-'}\n"
            f"Ошибок подряд: {goal.failure_count}\n"
            f"Следующий запуск: {self._fmt_ts(goal.next_execution)}"
        )

    def list_status_text(self, owner_id: str) -> str:
        goals = self._tc.engine.goal_set.autonomous_goals(owner_id=owner_id)
        if not goals:
            return "Автономных целей пока нет."
        return "\n\n".join(self.status_text(g) for g in goals)

    def find_by_channel_id(self, channel_id: str, owner_id: str) -> Optional[Goal]:
        target = str(channel_id).strip()
        for goal in self._tc.engine.goal_set.autonomous_goals(owner_id=owner_id):
            if str(goal.context.get("telegram_channel_id") or "") == target:
                return goal
        return None

    def find_by_short_id(self, short_id: str, owner_id: str) -> Optional[Goal]:
        short_id = short_id.strip().lower()
        for g in self._tc.engine.goal_set.autonomous_goals(owner_id=owner_id):
            if g.id.lower().startswith(short_id):
                return g
        return None

    @staticmethod
    def _fmt_ts(ts: Optional[float]) -> str:
        if not ts:
            return "-"
        return time.strftime("%d.%m %H:%M", time.localtime(ts))

    # === планирование ========================================================

    async def _plan_goal(self, goal: Goal) -> bool:
        tc = self._tc
        write_kinds = sorted(tc.actions.known_kinds())
        read_kinds = sorted(tc._readonly_actions.keys())
        prompt = (
            f"Owner's goal, in their own words: {goal.description!r}\n\n"
            f"Allowed WRITE/ADMIN action kinds (each needs the owner's confirmation before it "
            f"actually runs): {', '.join(write_kinds)}\n\n"
            f"Allowed READ-only action kinds (run immediately, no confirmation): "
            f"{', '.join(read_kinds)}\n\n"
            "Decompose this goal into the ordered JSON plan as instructed. If the owner specified "
            "how often something should repeat (e.g. 'twice a day', 'every day', 'once a week'), "
            "compute cycle_interval_seconds accordingly and include it."
        )
        planning_input = LanguagePlanningInput(
            situation_summary=prompt,
            retrieved_memory_summaries=[],
            active_belief_summaries=[],
            chosen_action_type=ActionType.CHANGE_GOAL,
            goal_context_summary=json.dumps(goal.context, ensure_ascii=False),
            style_prior={},
        )
        try:
            raw = await asyncio.to_thread(tc.engine.language_planner.provider.generate, planning_input)
        except Exception:
            logger.exception("[GOAL] planning LLM call failed goal_id=%s", goal.id)
            return False

        plan, cycle_interval = self._parse_plan(raw, set(write_kinds), set(read_kinds))
        if not plan:
            logger.warning("[GOAL] planning produced no valid steps goal_id=%s raw=%r", goal.id, (raw or "")[:300])
            return False

        goal.plan = plan
        goal.total_steps = len(plan)
        goal.current_step = 0
        cycle_idx = next((i for i, s in enumerate(plan) if s.get("cycle_start")), None)
        goal.cycle_start_step = cycle_idx
        if cycle_interval is not None:
            goal.context["cycle_interval_seconds"] = cycle_interval
        logger.info(
            "[GOAL] planning goal_id=%s steps=%d cycle_start=%s cycle_interval_seconds=%s",
            goal.id, len(plan), cycle_idx, cycle_interval,
        )
        return True

    @staticmethod
    def _parse_plan(raw: str, write_kinds: set, read_kinds: set) -> "tuple[List[Dict[str, Any]], Optional[float]]":
        """Парсит JSON-план модели и фильтрует его по РЕАЛЬНО
        зарегистрированным kind'ам — придуманный/несуществующий kind сюда
        не проходит ни при каких обстоятельствах (см. docstring модуля).
        Модель может вернуть либо просто массив шагов (старый формат), либо
        объект {"steps": [...], "cycle_interval_seconds": N} — второе нужно,
        чтобы 'выкладывай пост 2 раза в день' реально стало интервалом
        ~43200 секунд, а не дефолтными 24 часами на любую периодичность."""
        if not raw:
            return [], None
        text = _JSON_FENCE_RE.sub("", raw.strip()).strip()
        data = None
        try:
            data = json.loads(text)
        except Exception:
            # модель могла добавить текст до/после JSON — попробуем вырезать
            # первый '[' или '{' .. последний ']' или '}'
            for open_ch, close_ch in (("{", "}"), ("[", "]")):
                start, end = text.find(open_ch), text.rfind(close_ch)
                if start != -1 and end != -1 and end > start:
                    try:
                        data = json.loads(text[start:end + 1])
                        break
                    except Exception:
                        continue
        if data is None:
            return [], None

        cycle_interval: Optional[float] = None
        if isinstance(data, dict):
            steps_data = data.get("steps")
            raw_interval = data.get("cycle_interval_seconds")
            if raw_interval is not None:
                try:
                    cycle_interval = max(MIN_CYCLE_INTERVAL_SECONDS, float(raw_interval))
                except (TypeError, ValueError):
                    cycle_interval = None
        else:
            steps_data = data
        if not isinstance(steps_data, list):
            return [], None

        all_kinds = write_kinds | read_kinds
        plan: List[Dict[str, Any]] = []
        for item in steps_data[:MAX_PLAN_STEPS]:
            if not isinstance(item, dict):
                continue
            kind = str(item.get("kind") or "").strip()
            if kind not in all_kinds:
                logger.warning("[GOAL] planner proposed unknown kind %r — dropped from plan", kind)
                continue
            is_read = kind in read_kinds
            description = str(item.get("description") or kind)[:300].replace("|", "/").replace(">", ")")
            payload_template = str(item.get("payload_template") or "")
            plan.append({
                "kind": kind,
                "payload_template": payload_template,
                "description": description,
                "read": is_read,
                "cycle_start": bool(item.get("cycle_start")),
            })
        return plan, cycle_interval

    async def _advance_one(self, goal: Goal) -> None:
        if goal.status in (GoalStatus.PENDING, GoalStatus.PLANNING):
            goal.status = GoalStatus.PLANNING
            ok = await self._plan_goal(goal)
            goal.updated_at = time.time()
            if not ok:
                goal.failure_count += 1
                if goal.failure_count > goal.max_retries:
                    goal.status = GoalStatus.FAILED
                    goal.next_execution = None
                    logger.info("[GOAL] failed goal_id=%s reason=planning_failed", goal.id)
                    await self._notify_owner(goal, f"Не смогла спланировать цель «{goal.description}».")
                else:
                    goal.next_execution = time.time() + RETRY_BACKOFF_SECONDS
                return
            goal.status = GoalStatus.RUNNING
            goal.next_execution = time.time()
            return

        if goal.status == GoalStatus.WAITING:
            if goal.next_execution and time.time() >= goal.next_execution:
                await self._notify_owner(
                    goal, f"Я всё ещё жду твоего «да» — хочу продолжить «{goal.description}»."
                )
                goal.next_execution = time.time() + WAITING_RENOTIFY_SECONDS
            return

        if goal.status != GoalStatus.RUNNING:
            return  # PAUSED/COMPLETED/FAILED/CANCELLED сюда не должны попасть, но не рискуем

        steps_done = 0
        while steps_done < MAX_STEPS_PER_TICK:
            if goal.current_step >= len(goal.plan):
                await self._complete_or_cycle(goal)
                return
            step = goal.plan[goal.current_step]
            kind = step.get("kind")

            if step.get("read") and kind in self._tc._readonly_actions:
                logger.info("[GOAL] step_started goal_id=%s step=%s kind=%s read=true", goal.id, goal.current_step, kind)
                payload = self._render_payload(step, goal)
                try:
                    result = await self._tc._readonly_actions[kind](payload)
                except Exception as e:  # noqa: BLE001 — read-шаг не должен ронять всю цель
                    result = f"(ошибка чтения: {e})"
                goal.context[f"step_{goal.current_step}_result"] = result
                goal.last_result = result
                goal.last_execution = time.time()
                logger.info("[GOAL] action_completed goal_id=%s step=%s result=%r", goal.id, goal.current_step, result[:200])
                goal.current_step += 1
                steps_done += 1
                continue

            if (not step.get("read")) and kind in self._tc.actions.known_kinds():
                idempotency_key = IDEMPOTENT_ONCE_KINDS.get(kind)
                if idempotency_key and goal.context.get(idempotency_key):
                    logger.info(
                        "[GOAL] step_started goal_id=%s step=%s kind=%s skipped=idempotent (%s already set)",
                        goal.id, goal.current_step, kind, idempotency_key,
                    )
                    goal.current_step += 1
                    steps_done += 1
                    continue

                if kind in _POST_LIKE_KINDS and self._goal_already_posted(goal) \
                        and await self._targets_own_channel(goal, step):
                    # Пост по этой цели уже вышел (шагом цели или прямо в разговоре) —
                    # второй «отправить селфи с постом» был бы дублем. Раньше цель
                    # не знала о посте из разговора и спрашивала «Сделать?».
                    result = "Готово — пост по этой цели уже вышел, повторять не стала."
                    should_continue = await self._handle_step_result(goal, result, auto_approved=True)
                    steps_done += 1
                    if not should_continue:
                        return
                    continue

                if self._is_own_channel_post_step(goal, step):
                    # Пост в СВОЙ канал — по политике автономии без «да»
                    # (как «сделай пост» от владельца). Раньше такой шаг
                    # уходил в generic send_message с незаполненным
                    # $telegram_channel_id и падал «не хватило данных
                    # (чат или человек)» — трижды подряд на скриншотах.
                    result = await self._publish_post_step(goal, step)
                    should_continue = await self._handle_step_result(goal, result, auto_approved=True)
                    steps_done += 1
                    if not should_continue:
                        return
                    continue

                payload, own_target = await self._prepare_write_step(goal, step)
                if own_target and kind in SAFE_AUTO_APPROVE_KINDS:
                    # Опрос/закреп/пост и т.п. в СВОЙ канал — без «да», как и в чате.
                    # Раньше для опроса адресат оставался «$telegram_channel_id»,
                    # и после «да» было «не хватило данных (чат или человек)».
                    goal.next_action = {"kind": kind, "payload": payload, "description": step["description"]}
                    result = await self._tc.actions.execute_now(kind, step["description"], payload)
                    result = result or "(не получилось выполнить)"
                    note = getattr(self._tc, "_note_action_outcome", None)
                    if callable(note):
                        note(f"{step['description'][:60]} (цель «{goal.description[:50]}»)", result)
                    should_continue = await self._handle_step_result(goal, result, auto_approved=True)
                    steps_done += 1
                    if not should_continue:
                        return
                    continue

                if goal.auto_approve and kind in SAFE_AUTO_APPROVE_KINDS and self._target_matches_goal_channel(step, goal):
                    logger.info(
                        "[GOAL] step_started goal_id=%s step=%s kind=%s read=false auto_approved=true",
                        goal.id, goal.current_step, kind,
                    )
                    result = await self._execute_auto_approved_step(goal, step)
                    should_continue = await self._handle_step_result(goal, result, auto_approved=True)
                    steps_done += 1
                    if not should_continue:
                        return  # была ошибка — retry/fail уже обработаны, ждём следующего due-тика
                    continue

                await self._draft_write_step(goal, step, payload=payload)
                return  # write-шаг требует confirmation — останавливаемся до него

            logger.warning("[GOAL] skipping invalid/mismatched step goal_id=%s step=%s kind=%r", goal.id, goal.current_step, kind)
            goal.current_step += 1
            steps_done += 1

        # исчерпали потолок read-шагов за тик — продолжим очень скоро, не мгновенно
        goal.next_execution = time.time() + 3.0
        goal.updated_at = time.time()

    async def _execute_auto_approved_step(self, goal: Goal, step: Dict[str, Any]) -> str:
        """Выполняет write-шаг БЕЗ ожидания ответа владельца — но через тот
        же самый ActionRegistry.extract_draft()/maybe_confirm(), просто
        подтверждение подставляется программно вместо того, чтобы ждать
        реальное «да» в чате. Тот же код, что исполнил бы человеческое
        подтверждение — значит те же проверки/логирование/формат результата,
        никакого отдельного пути выполнения действия не существует. Доступно
        только для kind'ов из SAFE_AUTO_APPROVE_KINDS и только внутри уже
        одобренного владельцем канала/чата (см. _target_matches_goal_channel) —
        владелец включает это явно командой '.автопост <id> вкл'."""
        tc = self._tc
        payload = self._render_payload(step, goal)
        description = step["description"]
        goal.next_action = {"kind": step["kind"], "payload": payload, "description": description}

        # Повторяющийся пост в канал цели: текст в payload_template был
        # зафиксирован при планировании, и раньше каждый цикл публиковал ОДНО
        # И ТО ЖЕ. Теперь шаблонный текст — это только бриф, а сам пост
        # каждый раз пишется заново через ChannelPublisher.
        publisher = getattr(tc, "publisher", None)
        in_cycle = goal.cycle_start_step is not None and goal.current_step >= goal.cycle_start_step
        if publisher is not None and step["kind"] == "send_message" and in_cycle:
            try:
                params = json.loads(payload)
            except Exception:
                params = {}
            if isinstance(params, dict):
                channel = str(params.get("to") or goal.context.get("telegram_channel_id") or "")
                brief = str(params.get("text") or goal.description)[:400]
                res = await publisher.publish(
                    f"в духе цели «{goal.description}»; ориентир (не копировать дословно): {brief}",
                    channel_hint=channel, source="goal",
                )
                return "Готово, опубликовала свежий пост." if res.ok else (res.error or "Не получилось опубликовать.")

        result = await tc.actions.execute_now(step["kind"], description, payload)
        return result or "(не получилось выполнить)"

    _POST_GOAL_RE = re.compile(r"\b(?:пост\w*|канал\w*|опубликова\w*|запост\w*|публикац\w*|подписчик\w*)", re.IGNORECASE)

    def _own_channel_keys(self) -> set:
        keys = set()
        for key, entry in (getattr(self._tc, "_own_channels", {}) or {}).items():
            keys.add(str(key))
            keys.add(str(entry.get("id") or ""))
            if entry.get("username"):
                keys.add(str(entry["username"]).lstrip("@").lower())
        keys.discard("")
        return keys

    def _goal_already_posted(self, goal: Goal) -> bool:
        if goal.context.get("posted_at"):
            return True
        created = float(getattr(goal, "created_at", 0) or 0)
        for entry in (getattr(self._tc, "_own_channels", {}) or {}).values():
            for post in entry.get("post_history") or []:
                # автопост на свою тему не выполняет чужую цель — только пост
                # по просьбе в разговоре или шагом цели
                if post.get("source") != "autopost" and float(post.get("at") or 0) > created:
                    return True
        return False

    async def _targets_own_channel(self, goal: Goal, step: Dict[str, Any]) -> bool:
        if self._is_own_channel_post_step(goal, step):
            return True
        _payload, own = await self._prepare_write_step(goal, step)
        return own

    async def _default_own_channel_id(self, goal: Goal) -> str:
        cid = str(goal.context.get("telegram_channel_id") or "")
        if cid and "$" not in cid:
            return cid
        publisher = getattr(self._tc, "publisher", None)
        if publisher is None:
            return ""
        try:
            entry, _auto, _err = await publisher.resolve_channel("")
        except Exception:
            logger.debug("[GOAL] default channel lookup failed", exc_info=True)
            return ""
        if entry and entry.get("id") is not None:
            goal.context.setdefault("telegram_channel_id", str(entry["id"]))
            return str(entry["id"])
        return ""

    async def _prepare_write_step(self, goal: Goal, step: Dict[str, Any]) -> "tuple[str, bool]":
        """Рендерит payload шага. Если адресат не заполнен ($-плейсхолдер или
        пусто), а цель про канал — подставляет её канал (тот же выбор, что у
        постов). Возвращает (payload, адресат — её собственный канал?)."""
        payload = self._render_payload(step, goal)
        try:
            params = json.loads(payload)
        except Exception:
            return payload, False
        if not isinstance(params, dict):
            return payload, False
        key = _AUTO_APPROVE_CHAT_KEY.get(step.get("kind", ""), "chat")
        target = str(params.get(key) or "").strip()
        if (not target or "$" in target) and self._POST_GOAL_RE.search(goal.description or ""):
            own_id = await self._default_own_channel_id(goal)
            if own_id:
                params[key] = own_id
                target = own_id
                payload = json.dumps(params, ensure_ascii=False)
        norm = target.lstrip("@").lower()
        return payload, bool(norm) and norm in self._own_channel_keys()

    def _is_own_channel_post_step(self, goal: Goal, step: Dict[str, Any]) -> bool:
        """send_message-шаг, который на самом деле «пост в мой канал»:
        цель адрес в свой канал ИЛИ адресат не определён (пустой /
        незаполненный $-плейсхолдер), а сама цель — про пост/канал.
        Сообщение конкретному человеку или в чужой чат сюда не попадает —
        оно, как и раньше, ждёт «да»."""
        if step.get("kind") != "send_message" or getattr(self._tc, "publisher", None) is None:
            return False
        try:
            params = json.loads(self._render_payload(step, goal))
        except Exception:
            params = {}
        if not isinstance(params, dict):
            params = {}
        target = str(params.get("to") or params.get("chat") or "").strip()
        norm = target.lstrip("@").lower()
        if norm and norm in self._own_channel_keys():
            return True
        unresolved = (not target) or ("$" in target)
        return unresolved and bool(self._POST_GOAL_RE.search(goal.description or ""))

    async def _publish_post_step(self, goal: Goal, step: Dict[str, Any]) -> str:
        tc = self._tc
        try:
            params = json.loads(self._render_payload(step, goal))
        except Exception:
            params = {}
        if not isinstance(params, dict):
            params = {}
        target = str(params.get("to") or params.get("chat") or "").strip()
        hint = "" if (not target or "$" in target) else target
        brief = str(params.get("text") or step.get("description") or goal.description)[:400]
        goal.next_action = {"kind": "channel_post", "payload": "", "description": step.get("description", "")}
        try:
            wants_selfie = bool(_SELFIE_RE.search(f"{goal.description} {step.get('description', '')} {brief}"))
            if goal.context.get("self_initiated"):
                # Её собственная идея «запостить что-то» — текст из настоящей мысли,
                # а цель только направление. Раньше тема цели («тёплый вечерний
                # пост») шла в пост как шаблон — отсюда осень по кругу.
                res = await tc.publisher.publish(
                    "", channel_hint=hint, source="goal", with_selfie=wants_selfie,
                    inner_focus=goal.description,
                )
            else:
                res = await tc.publisher.publish(
                    f"в духе цели «{goal.description}»; ориентир (не копировать дословно): {brief}",
                    channel_hint=hint, source="goal", with_selfie=wants_selfie,
                )
        except Exception as e:  # noqa: BLE001
            logger.exception("[GOAL] post step failed goal_id=%s", goal.id)
            res = None
            result = f"Не получилось опубликовать: {e}"
        if res is not None:
            if res.ok:
                goal.context["posted_at"] = time.time()
                if res.channel_id:
                    goal.context.setdefault("telegram_channel_id", str(res.channel_id))
                result = "Готово, опубликовала пост" + (f": {res.link}" if res.link else ".")
            else:
                result = res.error or "Не получилось опубликовать."
        note = getattr(tc, "_note_action_outcome", None)
        if callable(note):
            note(f"пост по цели «{goal.description[:60]}»", result)
        if res is not None and res.ok:
            await self._notify_owner(goal, f"Выложила пост, как и хотела 🙂 {res.link}".strip())
        return result

    def _target_matches_goal_channel(self, step: Dict[str, Any], goal: Goal) -> bool:
        """Auto_approve разрешён ТОЛЬКО когда шаг реально нацелен на уже
        одобренный владельцем канал/чат этой цели — не на произвольный
        чат, который мог случайно попасть в план. Надёжнее всего — когда
        сам шаблон payload явно ссылается на сохранённый channel_id/
        username через $-плейсхолдер (а не на буквальное совпадение после
        рендера, которое теоретически могло бы случайно совпасть)."""
        template = step.get("payload_template") or ""
        if "$telegram_channel_id" in template or "$telegram_channel_username" in template:
            return True
        try:
            rendered = json.loads(self._render_payload(step, goal))
        except Exception:
            return False
        if not isinstance(rendered, dict):
            return False
        chat_key = _AUTO_APPROVE_CHAT_KEY.get(step.get("kind", ""), "chat")
        rendered_target = str(rendered.get(chat_key, "")).strip().lstrip("@")
        known = {
            str(goal.context.get("telegram_channel_id") or ""),
            str(goal.context.get("telegram_channel_username") or "").lstrip("@"),
        }
        known.discard("")
        return rendered_target in known

    async def _draft_write_step(self, goal: Goal, step: Dict[str, Any], payload: Optional[str] = None) -> None:
        """Оформляет write-шаг ТОЧНО так же, как если бы модель сама
        написала <<<ACTION:...>>> в чате — через уже существующий
        ActionRegistry.extract_draft(), без изменения actions.py."""
        tc = self._tc
        payload = payload or self._render_payload(step, goal)
        description = step["description"]
        marker = f"<<<ACTION:{step['kind']}|{description}|{payload}>>>"
        owner_chat_id = str(tc.config.owner_id)

        tc.actions.extract_draft(marker, owner_chat_id)
        self._pending_goal_by_chat[owner_chat_id] = goal.id
        goal.status = GoalStatus.WAITING
        goal.next_action = {"kind": step["kind"], "payload": payload, "description": description}
        goal.next_execution = time.time() + WAITING_RENOTIFY_SECONDS
        goal.updated_at = time.time()
        logger.info(
            "[GOAL] step_started goal_id=%s step=%s kind=%s read=false waiting_for_confirmation",
            goal.id, goal.current_step, step["kind"],
        )
        await self._notify_owner(
            goal,
            f"Для «{goal.description}» следующий шаг — {description[:1].lower() + description[1:]}. "
            f"Сделать? Скажи «да», если ок.",
        )

    def _render_payload(self, step: Dict[str, Any], goal: Goal) -> str:
        """payload_template — JSON-строка с $-плейсхолдерами (string.Template,
        НЕ str.format) для значений, известных только после более раннего
        verification-шага (например $telegram_channel_id). $ вместо {} — раз
        сам payload теперь JSON и его фигурные скобки конфликтовали бы с
        синтаксисом .format()."""
        template = step.get("payload_template") or ""
        return string.Template(template).safe_substitute(
            {k: v for k, v in goal.context.items() if isinstance(v, (str, int, float))}
        )

    # === верификация результата (§4 Stage 4) =================================

    async def _verify_and_advance(self, goal: Goal) -> None:
        kind = (goal.next_action or {}).get("kind")
        payload = (goal.next_action or {}).get("payload", "")
        try:
            if kind == "create_channel":
                await self._verify_create_channel(goal, payload)
            elif kind in ("schedule_message", "send_message"):
                await self._verify_sent_or_scheduled(goal, kind, payload)
        except Exception:
            logger.exception("[GOAL] verification failed (non-fatal) goal_id=%s kind=%s", goal.id, kind)
        logger.info("[GOAL] verification goal_id=%s step=%s kind=%s context_keys=%s",
                    goal.id, goal.current_step, kind, list(goal.context.keys()))

        goal.current_step += 1
        goal.status = GoalStatus.RUNNING
        goal.next_execution = time.time()
        goal.updated_at = time.time()

    async def _verify_create_channel(self, goal: Goal, payload: str) -> None:
        try:
            title = str(json.loads(payload)["title"]).strip()
        except Exception:
            logger.warning("[GOAL] could not parse create_channel payload for verification: %r", payload)
            return
        dialogs = await self._tc.client.get_dialogs(limit=10)
        for d in dialogs:
            if (d.name or "").strip() == title:
                goal.context["telegram_channel_id"] = d.id
                goal.context["telegram_channel_username"] = getattr(d.entity, "username", None) or ""
                # Тот же durable-реестр "своих каналов", что и у ручного
                # create_channel в client.py — иначе цель помнит канал
                # только в своём context, а в обычном разговоре (вне этой
                # цели) Марин снова его не знает.
                remember = getattr(self._tc, "_remember_own_channel", None)
                if remember is not None:
                    remember(d.id, title=title, username=getattr(d.entity, "username", None) or "")
                return
        logger.warning("[GOAL] could not verify created channel by title=%r goal_id=%s", title, goal.id)

    async def _verify_sent_or_scheduled(self, goal: Goal, kind: str, payload: str) -> None:
        try:
            chat_raw = str(json.loads(payload)["chat" if kind == "schedule_message" else "to"]).strip()
        except Exception:
            logger.warning("[GOAL] could not parse %s payload for verification: %r", kind, payload)
            return
        if kind == "schedule_message":
            text = await self._tc._readonly_actions["get_scheduled_messages"](chat_raw)
        else:
            text = await self._tc._readonly_actions["get_messages"](f"{chat_raw}|1")
        goal.context["last_post_result"] = text

    async def _complete_or_cycle(self, goal: Goal) -> None:
        if goal.cycle_start_step is not None and goal.cycle_start_step < len(goal.plan):
            goal.current_step = goal.cycle_start_step
            interval = goal.context.get("cycle_interval_seconds") or DEFAULT_CYCLE_INTERVAL_SECONDS
            try:
                interval = max(MIN_CYCLE_INTERVAL_SECONDS, float(interval))
            except (TypeError, ValueError):
                interval = DEFAULT_CYCLE_INTERVAL_SECONDS
            goal.next_execution = time.time() + interval
            goal.status = GoalStatus.RUNNING
            goal.updated_at = time.time()
            logger.info("[GOAL] waiting goal_id=%s next_cycle_in_seconds=%.0f", goal.id, interval)
            await self._notify_owner(
                goal, f"Цикл по цели «{goal.description}» завершён, продолжу примерно через "
                      f"{int(interval // 3600)} ч.",
            )
            return

        goal.status = GoalStatus.COMPLETED
        goal.active = False
        goal.next_execution = None
        goal.updated_at = time.time()
        logger.info("[GOAL] completed goal_id=%s", goal.id)
        await self._notify_owner(goal, f"Готово — цель «{goal.description}» выполнена полностью.")

    async def _notify_owner(self, goal: Goal, text: str) -> None:
        try:
            owner_entity = await self._tc.client.get_entity(int(self._tc.config.owner_id))
            await self._tc.client.send_message(owner_entity, text)
        except Exception:
            logger.exception("[GOAL] could not notify owner goal_id=%s", goal.id)
