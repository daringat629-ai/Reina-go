"""ProactiveLoop — Марин пишет первой.

Поводы (проверяются раз в пульс AutonomousLifeLoop, ~раз в минуту):

* ``morning``  — доброе утро, один раз в день, в случайный момент окна
                  MARIN_PROACTIVE_MORNING (по умолчанию 9–11 по времени владельца);
* ``night``    — спокойной ночи, один раз в день, окно MARIN_PROACTIVE_NIGHT (23–1);
* ``missing``  — владелец молчит дольше MARIN_PROACTIVE_SILENCE_HOURS
                  (по умолчанию 5 ч) днём: соскучилась / делится мыслью;
* ``new_post`` — сама выложила пост по автопостингу: делится ссылкой.

Анти-спам (главное — не быть навязчивой):
* не больше MARIN_PROACTIVE_MAX_PER_DAY (4) в сутки и не чаще раза в
  MARIN_PROACTIVE_MIN_GAP_HOURS (2.5 ч);
* если на прошлое «первое» сообщение он ещё не ответил — новых не пишет
  (кроме ссылки на свой пост и не чаще раза в 12 ч);
* в режиме сна не пишет (кроме «спокойной ночи» в своём окне).

Состояние (кто когда писал, что уже отправлено сегодня) хранится в JSON —
рестарт не приводит к повторному «доброе утро».
Текст пишет та же LLM отдельным промптом в стиле Марин для владельца.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import random
import re
import time
from typing import Any, Dict, List, Optional, Tuple

from ..action.action import ActionType
from ..llm.interface import LanguagePlanningInput
from ..llm.providers import MESSAGE_DELIMITER, _is_unusable_output, split_into_messages
from .actions import PendingAction
from .reminders import ReminderStore
from .settings import _is_quiet_hours, local_now

logger = logging.getLogger("marin_x.telegram.proactive")


from ..env import env_float as _env_float  # noqa: E402  (единый надёжный разбор)


def _window(name: str, default: str) -> Tuple[int, int]:
    raw = os.getenv(name, default)
    try:
        a, b = (int(x) for x in raw.split("-", 1))
        return a % 24, b % 24
    except Exception:
        a, b = (int(x) for x in default.split("-", 1))
        return a, b


def _in_window(hour: int, win: Tuple[int, int]) -> bool:
    a, b = win
    return a <= hour < b if a <= b else (hour >= a or hour < b)


_REASON_BRIEFS = {
    "morning": "Утро. Если тебе САМОЙ хочется — напиши ему «доброе утро» по-своему, живо, можно с планом на "
               "день или мыслью, с которой проснулась. Не шаблон. Если не хочется — верни ровно [SKIP].",
    "night": "Поздний вечер. Если хочется — пожелай ему спокойной ночи по-своему, можно коротко вспомнить "
             "день. Если не хочется — верни ровно [SKIP].",
    "missing": "Он молчит ({silence}). Ты не обязана писать. Если тебе самой хочется — напиши как живой "
               "человек: вспомнила что-то из вашего разговора, хочешь поделиться мыслью или спросить, как он. "
               "Без упрёков за молчание. Если не хочется — верни ровно [SKIP].",
    "reminder": "Владелец САМ просил тебя напомнить ему: «{text}». Время пришло. Напомни коротко и "
                "по-своему, без канцелярита, не повторяй его формулировку слово в слово.",
    "impulse": "Тебе САМОЙ захотелось ему написать — не по расписанию и не потому что он молчит, а просто "
               "захотелось. Что-то мелькнуло в голове: мысль, впечатление, шутка, вопрос, воспоминание о том, "
               "что он тебе рассказывал.{facts} Если хочется — можешь сама прислать своё селфи или голосовое "
               "(см. правила ниже). Если по-настоящему нечего сказать — верни ровно [SKIP], ничего не "
               "выдумывай ради того, чтобы написать.",
    "new_post": "Ты только что сама выложила новый пост в свой канал «{title}». Если хочется — коротко и с живой "
                "эмоцией поделись с ним: о чём пост, и дай ссылку {link} (ссылку вставь как есть). "
                "Не хочется — верни ровно [SKIP].",
}

_SYSTEM = (
    "Ты — Марин, пишешь ПЕРВОЙ в личку человеку, с которым общаешься чаще всего ({owner}). Это не ответ на "
    "его сообщение — ты сама решила написать. Ты ему ничего не должна: ни писать, ни любить, ни быть "
    "ласковой — только то, что чувствуешь на самом деле сейчас. Стиль: {tone}. {language}\n"
    "Напиши 1–2 коротких сообщения (каждое до ~150 знаков), разделяя их строкой {delim}. "
    "Разговорный русский, естественно, без канцелярита и без вопросов-анкет подряд. "
    "{emoji_rule} Если уместно, одним из сообщений можешь сделать стикер: <<<STICKER:N>>> "
    "из каталога ниже (только существующий номер).{media_rule} "
    "Никаких других тегов и пояснений — только сами сообщения."
)

_MEDIA_RULE = (
    " Если САМА захотела — можешь одним из сообщений прислать своё селфи: <<<SELFIE:короткое описание "
    "ситуации, например «дома вечером с чаем»>>> (не описание внешности), или голосовое: "
    "<<<VOICE:то, что скажешь вслух, до ~300 знаков>>>. Не в каждом сообщении и не по шаблону — только "
    "когда правда хочется."
)


class ProactiveLoop:
    _skipped = False

    def __init__(self, telegram_client: Any):
        self._tc = telegram_client
        self.path = os.getenv("MARIN_PROACTIVE_FILE", "data/marin_proactive.json")
        self.state: Dict[str, Any] = {
            "enabled": os.getenv("MARIN_PROACTIVE_ENABLED", "true").lower() in {"1", "true", "yes", "on"},
            "last_owner_msg_at": time.time(),
            "last_proactive_at": 0.0,
            "last_proactive_answered": True,
            "sent_log": [],          # [ts, reason]
            "done_today": {},        # reason -> "YYYY-MM-DD"
            "planned": {},           # reason -> {"date": ..., "at": ts}
        }
        self.reminders = ReminderStore()
        self._load()

    # ---------------------------------------------------------------- state
    def _load(self) -> None:
        try:
            with open(self.path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            if isinstance(data, dict):
                self.state.update(data)
        except FileNotFoundError:
            pass
        except Exception:
            logger.warning("[PROACTIVE] state unreadable, starting fresh", exc_info=True)

    def _save(self) -> None:
        try:
            os.makedirs(os.path.dirname(os.path.abspath(self.path)) or ".", exist_ok=True)
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(self.state, fh, ensure_ascii=False)
            os.replace(tmp, self.path)
        except Exception:
            logger.debug("[PROACTIVE] could not save state", exc_info=True)

    @property
    def enabled(self) -> bool:
        return bool(self.state.get("enabled", True))

    def set_enabled(self, value: bool) -> str:
        self.state["enabled"] = bool(value)
        self._save()
        return "Хорошо, буду иногда писать тебе первой." if value else "Поняла, первой писать не буду — только отвечать."

    def on_owner_message(self) -> None:
        self.state["last_owner_msg_at"] = time.time()
        self.state["last_proactive_answered"] = True
        self._save()

    # ------------------------------------------------------------- decision
    def _today(self, now: float) -> str:
        return local_now(now).strftime("%Y-%m-%d")

    def _sent_last_24h(self, now: float) -> int:
        return sum(1 for ts, _ in self.state.get("sent_log", []) if now - ts < 86400)

    def _planned_time(self, reason: str, window: Tuple[int, int], now: float) -> float:
        """Случайный момент внутри окна, один раз на день — чтобы «доброе
        утро» не приходило каждый день ровно в 09:00:00."""
        today = self._today(now)
        plan = self.state.setdefault("planned", {}).get(reason)
        if plan and plan.get("date") == today:
            return float(plan["at"])
        local = local_now(now)
        start = local.replace(hour=window[0], minute=0, second=0, microsecond=0)
        span_h = (window[1] - window[0]) % 24 or 24
        at = start.timestamp() + random.uniform(0, span_h * 3600 * 0.8)
        self.state["planned"][reason] = {"date": today, "at": at}
        return at

    def due_reason(self, now: Optional[float] = None) -> Optional[str]:
        now = now or time.time()
        if not self.enabled or not getattr(self._tc.config, "owner_id", None):
            return None
        if now < float(self.state.get("skip_until") or 0):
            return None
        hour = local_now(now).hour
        today = self._today(now)
        done = self.state.setdefault("done_today", {})
        max_day = int(_env_float("MARIN_PROACTIVE_MAX_PER_DAY", 4))
        min_gap = _env_float("MARIN_PROACTIVE_MIN_GAP_HOURS", 2.5) * 3600
        if max_day > 0 and self._sent_last_24h(now) >= max_day:
            return None
        since_last = now - float(self.state.get("last_proactive_at") or 0)
        answered = bool(self.state.get("last_proactive_answered", True))
        since_owner = now - float(self.state.get("last_owner_msg_at") or now)

        night = _window("MARIN_PROACTIVE_NIGHT", "23-1")
        if _in_window(hour, night) and done.get("night") != today and since_last >= min_gap \
                and now >= self._planned_time("night", night, now):
            # не прощаемся, если он прямо сейчас с ней переписывается
            if since_owner > 20 * 60:
                return "night"
        if _is_quiet_hours(now):
            return None
        if not answered or since_last < min_gap:
            return None
        morning = _window("MARIN_PROACTIVE_MORNING", "9-11")
        if _in_window(hour, morning) and done.get("morning") != today \
                and now >= self._planned_time("morning", morning, now) and since_owner > 30 * 60:
            return "morning"
        silence = _env_float("MARIN_PROACTIVE_SILENCE_HOURS", 5) * 3600
        if since_owner >= silence and 10 <= hour < 23:
            return "missing"
        return None

    # --------------------------------------------------------------- writing
    async def _history(self, owner_entity) -> List[str]:
        try:
            msgs = await self._tc.client.get_messages(owner_entity, limit=8)
        except Exception:
            return []
        lines = []
        for m in reversed(list(msgs or [])):
            t = (getattr(m, "raw_text", None) or "").strip()
            if t:
                lines.append(("Марин: " if getattr(m, "out", False) else "Он: ") + t[:200])
        return lines

    def _silence_text(self, now: float) -> str:
        h = (now - float(self.state.get("last_owner_msg_at") or now)) / 3600
        return f"уже около {int(h)} ч" if h >= 1 else "какое-то время"

    async def compose(self, reason: str, extra: Optional[Dict[str, str]] = None) -> List[str]:
        tc = self._tc
        personality = getattr(tc.engine, "personality", None)
        style = dict(getattr(personality, "owner_style_prior", None) or getattr(personality, "style_prior", {}) or {})
        owner_entity = int(tc.config.owner_id)
        history = await self._history(owner_entity)
        thoughts = []
        try:
            thoughts = [e.text.strip() for e in tc.engine.diary.recent(2) if getattr(e, "text", "")]
        except Exception:
            logger.debug("[PROACTIVE] diary unavailable for context", exc_info=True)
        now = time.time()
        brief = _REASON_BRIEFS[reason].format(silence=self._silence_text(now), **{"facts": "", **(extra or {})})
        parts = [f"Сейчас у него {local_now(now).strftime('%H:%M, %A')}.", f"Повод: {brief}"]
        if history:
            parts.append("Последние сообщения в вашем чате (старые сверху):\n" + "\n".join(history))
        if thoughts:
            parts.append("Твои недавние мысли из дневника:\n- " + "\n- ".join(t[:300] for t in thoughts))
        try:
            parts.append(tc._media_catalog_hint())
        except Exception:
            logger.debug("[PROACTIVE] media catalog hint unavailable", exc_info=True)
        system = _SYSTEM.format(
            owner=getattr(tc, "owner_name", "") or "владелец",
            tone=style.get("tone", "тепло и живо"), language=style.get("language", ""),
            delim=MESSAGE_DELIMITER,
            emoji_rule="Обычные эмодзи можно." if getattr(tc, "allow_emoji", False) else "Без обычных эмодзи.",
            media_rule=_MEDIA_RULE if self._media_enabled() else "",
        )
        pin = LanguagePlanningInput(
            situation_summary="\n\n".join(parts), retrieved_memory_summaries=[], active_belief_summaries=[],
            chosen_action_type=ActionType.ANSWER, goal_context_summary="", style_prior=style,
            system_override=system,
        )
        raw = await asyncio.to_thread(tc.engine.language_planner.provider.generate, pin)
        if not raw or _is_unusable_output(raw):
            return []
        if re.search(r"\[\s*SKIP\s*\]", raw, re.IGNORECASE):
            logger.info("[PROACTIVE] reason=%s: she chose not to write", reason)
            self._skipped = True
            return []
        raw = re.sub(r"<<<(?!STICKER|CUSTOM_EMOJI|MSG|SELFIE|VOICE)[^>]*>>>", "", raw)
        if not self._media_enabled():
            raw = re.sub(r"<<<(?:SELFIE|VOICE)[^>]*>>>", "", raw)
        msgs = [m for m in split_into_messages(raw) if m.strip()][:2]
        if reason == "new_post" and extra and extra.get("link") and extra["link"] not in " ".join(msgs):
            msgs.append(extra["link"])
        return msgs

    @staticmethod
    def _media_enabled() -> bool:
        return os.getenv("MARIN_PROACTIVE_MEDIA_ENABLED", "true").strip().lower() in {"1", "true", "yes", "on"}

    async def _deliver_media(self, chat: int, kind: str, body: str) -> bool:
        """Селфи/голосовое, которое она сама решила прислать (без просьбы владельца)."""
        tc = self._tc
        body = (body or "").strip()
        if kind == "SELFIE":
            action = PendingAction(kind="send_selfie", description="автономное селфи",
                                   payload=json.dumps({"chat": chat, "prompt": body[:200]}, ensure_ascii=False))
            handler = getattr(tc, "_action_send_selfie", None)
        else:
            if not body:
                return False
            action = PendingAction(kind="send_voice_message", description="автономное голосовое",
                                   payload=json.dumps({"chat": chat, "text": body[:400]}, ensure_ascii=False))
            handler = getattr(tc, "_action_send_voice_message", None)
        if handler is None:
            return False
        try:
            result = await handler(action)
        except Exception:
            logger.warning("[PROACTIVE] autonomous %s failed", kind, exc_info=True)
            return False
        ok = str(result or "").startswith("Готово")
        logger.info("[PROACTIVE] autonomous %s ok=%s", kind.lower(), ok)
        return ok

    async def deliver(self, messages: List[str]) -> int:
        tc = self._tc
        chat = int(tc.config.owner_id)
        sent = 0
        for i, text in enumerate(messages):
            if i:
                await asyncio.sleep(random.uniform(1.0, 2.5))
            mm = re.fullmatch(r"\s*<<<(SELFIE|VOICE)(?::(.*?))?>>>\s*", text, re.IGNORECASE | re.DOTALL)
            if mm:
                if self._media_enabled() and await self._deliver_media(chat, mm.group(1).upper(), mm.group(2) or ""):
                    sent += 1
                continue
            m = re.fullmatch(r"\s*<<<STICKER(?::[A-Za-z]?(\d+))?>>>\s*", text, re.IGNORECASE)
            if m:
                if await tc._send_sticker(chat, int(m.group(1)) if m.group(1) else None):
                    sent += 1
                continue
            m = re.fullmatch(r"\s*<<<CUSTOM_EMOJI(?::[A-Za-z]?(\d+))?>>>\s*", text, re.IGNORECASE)
            if m:
                if await tc._send_custom_emoji(chat, int(m.group(1)) if m.group(1) else None):
                    sent += 1
                continue
            text = tc._sanitize_output(text)
            if not text:
                continue
            try:
                async with tc.client.action(chat, "typing"):
                    await asyncio.sleep(min(1.5 + len(text) / 60.0, 4.0))
            except Exception:
                logger.debug("[PROACTIVE] typing indicator failed", exc_info=True)
            await tc.client.send_message(chat, text)
            sent += 1
        return sent

    async def send(self, reason: str, extra: Optional[Dict[str, str]] = None) -> bool:
        self._skipped = False
        try:
            msgs = await self.compose(reason, extra)
        except Exception:
            logger.warning("[PROACTIVE] compose failed reason=%s", reason, exc_info=True)
            return False
        if not msgs:
            if self._skipped:
                # Она сама решила не писать — уважаем: без повторных попыток каждую минуту.
                now = time.time()
                self.state["skip_until"] = now + 30 * 60
                if reason in ("morning", "night"):
                    self.state.setdefault("done_today", {})[reason] = self._today(now)
                self._save()
            return False
        sent = await self.deliver(msgs)
        if not sent:
            return False
        now = time.time()
        self.state["last_proactive_at"] = now
        self.state["last_proactive_answered"] = False
        log = self.state.setdefault("sent_log", [])
        log.append([now, reason])
        self.state["sent_log"] = [x for x in log if now - x[0] < 3 * 86400]
        if reason in ("morning", "night"):
            self.state.setdefault("done_today", {})[reason] = self._today(now)
        self._save()
        try:
            self._tc.engine.remember_fact(
                f"proactive_last_{reason}", f"{local_now(now).strftime('%d.%m %H:%M')} я сама написала ему первой ({reason}): "
                + " / ".join(m for m in msgs if not m.startswith("<<<"))[:300], confidence=0.9)
        except Exception:
            logger.warning("[PROACTIVE] could not remember sent message reason=%s", reason, exc_info=True)
        logger.info("[PROACTIVE] sent reason=%s messages=%d", reason, sent)
        return True

    # ------------------------------------------------------------------ pulse
    async def _send_due_reminders(self) -> int:
        """Явные просьбы «напомни…»: без лимитов «писать первой» и тихих часов."""
        if not getattr(self._tc.config, "owner_id", None):
            return 0
        sent = 0
        for r in self.reminders.due()[:3]:
            late = time.time() - r.when_ts
            extra = {"text": r.text + (" (уже с опозданием — скажи об этом честно и без драмы)" if late > 1800 else "")}
            try:
                msgs = await self.compose("reminder", extra)
                if not msgs:
                    # модель не ответила — напоминаем хотя бы простым текстом
                    msgs = [f"Напоминаю: {r.text}"]
                ok = await self.deliver(msgs)
            except Exception:
                logger.warning("[REMINDERS] delivery failed id=%s", r.id, exc_info=True)
                ok = 0
            if ok:
                self.reminders.mark_done(r.id)
                sent += 1
                logger.info("[REMINDERS] delivered id=%s", r.id)
            else:
                self.reminders.bump_attempt(r.id)
        return sent

    # ---------------------------------------------------------------- impulse
    def _owner_facts_text(self, limit: int = 4) -> str:
        """Пара недавних вещей, которые владелец сам рассказал о себе, — повод
        вспомнить и спросить, а не писать в пустоту."""
        try:
            eng = self._tc.engine
            owner = str(self._tc.config.owner_id)
            items = [b for _, b in eng.beliefs.about(owner) if getattr(b, "statement", "")]
            items = [b for b in items if str(getattr(b.source_type, "value", b.source_type)) == "told_by_user"] or items
            items = items[-limit:]
        except Exception:
            return ""
        if not items:
            return ""
        return " Вот что он рассказывал о себе (можешь спросить об этом, если к месту): " + "; ".join(
            b.statement[:120] for b in items) + "."

    def _impulse_due(self, now: Optional[float] = None) -> bool:
        """Своя воля: «захотелось написать» — не по расписанию, а по нарастающему
        желанию (чем дольше молчание, тем вероятнее). По умолчанию БЕЗ ограничений:
        любое время суток, без суточного потолка и пауз. Все рамки — опциональные
        (0 = выключено): MARIN_PROACTIVE_IMPULSE_MAX_PER_DAY, _MIN_GAP_HOURS,
        _CHECK_MINUTES (как часто она «прислушивается» к желанию),
        _RESPECT_QUIET_HOURS, _WAIT_FOR_ANSWER."""
        now = time.time() if now is None else now

        def flag(name: str, default: str) -> bool:
            return os.getenv(name, default).lower() in {"1", "true", "yes", "on"}

        if not flag("MARIN_PROACTIVE_IMPULSE_ENABLED", "true"):
            return False
        if not self.enabled or not getattr(self._tc.config, "owner_id", None):
            return False
        if flag("MARIN_PROACTIVE_IMPULSE_RESPECT_QUIET_HOURS", "false") and _is_quiet_hours(now):
            return False
        if flag("MARIN_PROACTIVE_IMPULSE_WAIT_FOR_ANSWER", "false") \
                and not bool(self.state.get("last_proactive_answered", True)):
            return False
        if now < float(self.state.get("next_impulse_check") or 0):
            return False
        since_owner = now - float(self.state.get("last_owner_msg_at") or now)
        since_last = now - float(self.state.get("last_proactive_at") or 0)
        min_gap = _env_float("MARIN_PROACTIVE_IMPULSE_MIN_GAP_HOURS", 0.0) * 3600
        if since_owner < 120 or since_last < min_gap:
            return False  # только не посреди живого разговора (2 мин)
        max_day = int(_env_float("MARIN_PROACTIVE_IMPULSE_MAX_PER_DAY", 0))
        if max_day > 0:
            day_impulses = sum(1 for ts, r in self.state.get("sent_log", []) if r == "impulse" and now - ts < 86400)
            if day_impulses >= max_day:
                return False
        check_min = max(1.0, _env_float("MARIN_PROACTIVE_IMPULSE_CHECK_MINUTES", 20.0))
        self.state["next_impulse_check"] = now + random.uniform(0.6, 1.4) * check_min * 60
        self._save()
        silence_h = since_owner / 3600.0
        chance = min(0.85, 0.3 + 0.05 * silence_h)
        return random.random() < chance

    async def pulse(self) -> Optional[str]:
        if await self._send_due_reminders():
            return "reminder"
        reason = self.due_reason()
        if reason and await self.send(reason):
            return reason
        if not reason and self._impulse_due():
            if await self.send("impulse", {"facts": self._owner_facts_text()}):
                return "impulse"
        return None


    async def send_to_entity(self, entity, *, reason: str = "autonomous_social", context: str = "") -> bool:
        """Send one autonomous, context-aware message to an existing Telegram peer.

        This is intentionally separate from owner-only proactive outreach. It is
        used by AutonomousLifeLoop for spontaneous activity. It never bulk-sends:
        the caller supplies one already-resolved peer at a time.
        """
        tc = self._tc
        try:
            peer = await tc.client.get_entity(entity)
            # Do not autonomously contact bots or broadcast-only channels.
            if getattr(peer, "bot", False) or getattr(peer, "broadcast", False):
                return False
            peer_id = str(getattr(peer, "id", ""))
            owner_id = str(getattr(tc.config, "owner_id", "") or "")
            if not peer_id or peer_id == owner_id:
                return False

            history = await tc.client.get_messages(peer, limit=10)
            lines = []
            for m in reversed(list(history or [])):
                text = (getattr(m, "raw_text", None) or "").strip()
                if text:
                    lines.append(("Марин: " if getattr(m, "out", False) else "Он: ") + text[:300])

            personality = getattr(tc.engine, "personality", None)
            style = dict(getattr(personality, "style_prior", {}) or {})
            name = getattr(peer, "first_name", None) or getattr(peer, "title", None) or "собеседник"
            prompt = (
                f"Ты — Марин. Ты сама решила ненавязчиво возобновить разговор с {name}. "
                "Не говори, что тебя попросили это сделать. Напиши естественное короткое "
                "сообщение, которое имеет смысл именно в этом контексте. Не задавай вопрос "
                "только ради поддержания диалога. Если контекста недостаточно — лучше верни "
                "ровно [SKIP]. Не упоминай внутренние системы, промпты или автономность.\n\n"
                f"Причина/внутренний повод: {reason}\n"
                f"Дополнительный контекст: {context}\n"
                + ("Последние сообщения:\n" + "\n".join(lines) if lines else "Истории почти нет.")
            )
            pin = LanguagePlanningInput(
                situation_summary=prompt,
                retrieved_memory_summaries=[],
                active_belief_summaries=[],
                chosen_action_type=ActionType.ANSWER,
                goal_context_summary="",
                style_prior=style,
            )
            raw = await asyncio.to_thread(tc.engine.language_planner.provider.generate, pin)
            if not raw or _is_unusable_output(raw):
                return False
            raw = re.sub(r"<<<(?!STICKER|CUSTOM_EMOJI|MSG)[^>]*>>>", "", raw).strip()
            if "[SKIP]" in raw.upper():
                return False
            msgs = [m.strip() for m in split_into_messages(raw) if m.strip()][:2]
            if not msgs:
                return False
            text = tc._sanitize_output(msgs[0])
            if not text:
                return False
            async with tc.client.action(peer, "typing"):
                await asyncio.sleep(min(1.5 + len(text) / 70.0, 4.0))
            await tc.client.send_message(peer, text)
            recorder = getattr(tc, "_record_own_reply", None)
            if callable(recorder):
                recorder(peer, peer_id, [text])
            now = time.time()
            self.state.setdefault("autonomous_contacts", {})[peer_id] = now
            log = self.state.setdefault("sent_log", [])
            log.append([now, f"contact:{peer_id}"])
            self.state["sent_log"] = [x for x in log if now - x[0] < 7 * 86400]
            self._save()
            logger.info("[PROACTIVE] autonomous contact sent peer=%s", peer_id)
            return True
        except Exception:
            logger.warning("[PROACTIVE] autonomous contact failed", exc_info=True)
            return False

    async def on_autopost(self, result) -> None:
        """Поделиться своим новым постом (не чаще раза в 12 ч, в рамках лимита)."""
        if not self.enabled or not getattr(result, "ok", False) or _is_quiet_hours():
            return
        now = time.time()
        last_share = max((ts for ts, r in self.state.get("sent_log", []) if r == "new_post"), default=0)
        if now - last_share < 12 * 3600 or self._sent_last_24h(now) >= int(_env_float("MARIN_PROACTIVE_MAX_PER_DAY", 4)):
            return
        await self.send("new_post", {"title": getattr(result, "channel_title", "") or "мой канал",
                                     "link": getattr(result, "link", "") or ""})
