"""Local Telegram world observer for Marin X.

Keeps a compact, persistent picture of what happens in Telegram without
sending replies to non-owner users. It is deliberately independent from the
cognitive engine so observation itself does not spend LLM tokens.
"""
from __future__ import annotations

import json
import os
import re
import time
import uuid
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass
from typing import Dict, List, Optional


@dataclass
class TelegramEvent:
    id: str
    ts: float
    chat_id: str
    chat_title: str
    sender_id: str
    sender_name: str
    username: str
    text: str
    outgoing: bool = False
    media: bool = False


@dataclass
class PersonProfile:
    user_id: str
    name: str = ""
    username: str = ""
    first_seen: float = 0.0
    last_seen: float = 0.0
    message_count: int = 0
    last_message: str = ""
    chats: List[str] = None
    # Углублённый Person Model (по мотивам ревью): trust/симпатии/незакрытые
    # темы/обещания — то, чего не хватало при одних только счётчиках сообщений.
    trust_level: float = 0.5          # 0..1, меняется через <<<PERSON:user|trust_up/trust_down|...>>>
    likes: List[str] = None
    dislikes: List[str] = None
    unresolved_topics: List[Dict] = None   # [{"topic","status","ts","resolved_ts"?}]
    commitments: List[Dict] = None         # [{"action","status","ts","resolved_ts"?}]
    last_topic: str = ""

    def __post_init__(self) -> None:
        if self.chats is None:
            self.chats = []
        if self.likes is None:
            self.likes = []
        if self.dislikes is None:
            self.dislikes = []
        if self.unresolved_topics is None:
            self.unresolved_topics = []
        if self.commitments is None:
            self.commitments = []


class TelegramObserver:
    """Persistent bounded event log + lightweight people/conversation state."""

    def __init__(self, path: Optional[str] = None, max_events: int = 2500, max_profiles: int = 1000):
        self.path = path or "marin_telegram_activity.json"
        self.max_events = max(100, int(max_events))
        self.max_profiles = max(50, int(max_profiles))
        self.events: List[TelegramEvent] = []
        self.people: Dict[str, PersonProfile] = {}
        # Реестр чатов по chat_id (не по названию!) — раньше группы
        # различались только по title в разных местах кода, а два разных
        # чата с одинаковым названием (напр. "Тест") конфликтовали бы
        # между собой. chat_id уникален всегда, title — нет.
        self.chats: Dict[str, Dict] = {}
        self._load()

    def record(self, *, chat_id: str, chat_title: str, sender_id: str,
               sender_name: str, username: str, text: str, outgoing: bool,
               media: bool, ts: Optional[float] = None) -> TelegramEvent:
        now = ts or time.time()
        clean = self._clean_text(text)
        ev = TelegramEvent(
            id=uuid.uuid4().hex[:12], ts=now, chat_id=str(chat_id),
            chat_title=chat_title or "Telegram", sender_id=str(sender_id),
            sender_name=sender_name or "Неизвестный", username=username or "",
            text=clean, outgoing=bool(outgoing), media=bool(media),
        )
        self.events.append(ev)
        if len(self.events) > self.max_events:
            self.events = self.events[-self.max_events:]

        chat_entry = self.chats.get(ev.chat_id)
        if chat_entry is None:
            chat_entry = {"title": ev.chat_title, "first_seen": now, "last_seen": now, "message_count": 0}
            self.chats[ev.chat_id] = chat_entry
        chat_entry["title"] = ev.chat_title  # переименования подхватываются, id остаётся ключом
        chat_entry["last_seen"] = now
        chat_entry["message_count"] += 1

        if not ev.outgoing:
            p = self.people.get(ev.sender_id)
            if p is None:
                p = PersonProfile(user_id=ev.sender_id, first_seen=now)
                self.people[ev.sender_id] = p
            p.name = ev.sender_name
            p.username = ev.username
            p.last_seen = now
            p.message_count += 1
            p.last_message = ev.text
            if ev.chat_title not in p.chats:
                p.chats.append(ev.chat_title)
                p.chats = p.chats[-20:]
            if len(self.people) > self.max_profiles:
                oldest = sorted(self.people.values(), key=lambda x: x.last_seen or x.first_seen)[: len(self.people) - self.max_profiles]
                for old in oldest:
                    self.people.pop(old.user_id, None)
        self._save()
        return ev

    def today_events(self, now: Optional[float] = None) -> List[TelegramEvent]:
        now = now or time.time()
        lt = time.localtime(now)
        start = time.mktime((lt.tm_year, lt.tm_mon, lt.tm_mday, 0, 0, 0, 0, 0, -1))
        return [e for e in self.events if e.ts >= start]

    def since(self, ts: float) -> List[TelegramEvent]:
        return [e for e in self.events if e.ts > ts]

    def people_today(self) -> List[PersonProfile]:
        grouped: Dict[str, PersonProfile] = {}
        for e in self.today_events():
            if e.outgoing:
                continue
            grouped[e.sender_id] = self.people.get(e.sender_id) or PersonProfile(
                user_id=e.sender_id, name=e.sender_name, username=e.username
            )
        return sorted(grouped.values(), key=lambda p: p.last_seen, reverse=True)

    def summary(self, limit: int = 12, since_ts: Optional[float] = None) -> str:
        events = self.since(since_ts) if since_ts is not None else self.today_events()
        incoming = [e for e in events if not e.outgoing]
        if not incoming:
            return "За выбранный период новых входящих сообщений не зафиксировано."

        people: Dict[str, List[TelegramEvent]] = defaultdict(list)
        for e in incoming:
            people[e.sender_id].append(e)

        lines = [f"Наблюдения Telegram: входящих событий {len(incoming)}, собеседников {len(people)}."]
        for _, items in sorted(people.items(), key=lambda kv: kv[1][-1].ts, reverse=True)[:limit]:
            e = items[-1]
            who = e.sender_name or "Неизвестный"
            handle = f" @{e.username}" if e.username else ""
            sample = e.text.replace("\n", " ").strip()
            if len(sample) > 180:
                sample = sample[:177] + "..."
            lines.append(f"- {who}{handle}: {len(items)} сообщ.; чат: {e.chat_title}; последнее: {sample or '[медиа]'}")
        return "\n".join(lines)

    def recent_context(self, limit: int = 20) -> str:
        lines = []
        for e in self.events[-limit:]:
            direction = "Marin" if e.outgoing else e.sender_name
            sample = e.text.replace("\n", " ").strip() or "[медиа]"
            if len(sample) > 220:
                sample = sample[:217] + "..."
            lines.append(f"[{time.strftime('%d.%m %H:%M', time.localtime(e.ts))}] {direction} / {e.chat_title}: {sample}")
        return "\n".join(lines)

    def recent_context_by_chat(self, *, exclude_chat_id: Optional[str] = None, max_chats: int = 5,
                               per_chat: int = 5, text_limit: int = 200, scan: int = 400) -> str:
        """Что было в ДРУГИХ чатах — сгруппировано по чатам, с именами.

        Раньше все чаты шли одним плоским списком по времени: реплики разных
        людей из разных разговоров перемешивались, и модель читала их как
        один разговор («та винда»). Теперь у каждого чата свой заголовок,
        а текущий чат исключён (его история и так в контексте)."""
        skip = str(exclude_chat_id) if exclude_chat_id is not None else None
        grouped: Dict[str, List[TelegramEvent]] = {}
        for e in self.events[-max(1, int(scan)):]:
            if skip is not None and str(e.chat_id) == skip:
                continue
            grouped.setdefault(e.chat_id, []).append(e)
        if not grouped:
            return ""
        latest_first = sorted(grouped.items(), key=lambda kv: kv[1][-1].ts, reverse=True)[:max_chats]
        blocks = []
        for chat_id, items in latest_first:
            title = items[-1].chat_title or "Telegram"
            kind = "группа/канал" if str(chat_id).startswith("-") else "личка"
            stamp = time.strftime("%d.%m %H:%M", time.localtime(items[-1].ts))
            head = f"▸ Чат «{title}» ({kind}), последнее сообщение {stamp}"
            lines = [head]
            for e in items[-per_chat:]:
                who = "Marin (ТЫ)" if e.outgoing else (e.sender_name or "Неизвестный")
                sample = e.text.replace("\n", " ").strip() or "[медиа]"
                if len(sample) > text_limit:
                    sample = sample[: text_limit - 3] + "..."
                lines.append(f"   {who}: {sample}")
            blocks.append("\n".join(lines))
        return "\n".join(blocks)

    def find_by_username(self, username: str) -> Optional[PersonProfile]:
        username = (username or "").lstrip("@").lower()
        if not username:
            return None
        for p in self.people.values():
            if p.username.lower() == username:
                return p
        return None

    def get_or_create_by_username(self, username: str) -> PersonProfile:
        """Возвращает профиль по юзернейму; если человек ещё не встречался
        напрямую (Марин о нём только рассказали), заводит заглушку под
        синтетическим ключом — реальный user_id подставится сам, когда
        он один раз что-то напишет и record() отработает как обычно."""
        person = self.find_by_username(username)
        if person is not None:
            return person
        username = username.lstrip("@")
        key = f"username:{username.lower()}"
        person = self.people.get(key)
        if person is None:
            person = PersonProfile(user_id=key, username=username, first_seen=time.time())
            self.people[key] = person
        return person

    def apply_person_marker(self, username: str, action: str, payload: str) -> None:
        """Единая точка входа для маркера <<<PERSON:username|action|payload>>>
        (см. telegram/client.py) — реально пишет в углублённый Person Model,
        а не просто проговаривает текстом и забывает."""
        person = self.get_or_create_by_username(username)
        action = (action or "").strip().lower()
        payload = (payload or "").strip()
        if not payload:
            return
        if action == "like":
            if payload not in person.likes:
                person.likes.append(payload)
        elif action == "dislike":
            if payload not in person.dislikes:
                person.dislikes.append(payload)
        elif action == "topic_open":
            person.unresolved_topics.append({"topic": payload, "status": "open", "ts": time.time()})
            person.last_topic = payload
        elif action == "topic_done":
            for t in reversed(person.unresolved_topics):
                if t.get("status") == "open" and payload.lower() in t.get("topic", "").lower():
                    t["status"] = "resolved"
                    t["resolved_ts"] = time.time()
                    break
        elif action == "promise":
            person.commitments.append({"action": payload, "status": "pending", "ts": time.time()})
        elif action == "promise_done":
            for c in reversed(person.commitments):
                if c.get("status") == "pending" and payload.lower() in c.get("action", "").lower():
                    c["status"] = "fulfilled"
                    c["resolved_ts"] = time.time()
                    break
        elif action == "trust_up":
            person.trust_level = min(1.0, person.trust_level + 0.1)
        elif action == "trust_down":
            person.trust_level = max(0.0, person.trust_level - 0.1)
        else:
            return
        self._save()

    def person_summary(self, limit: int = 5) -> str:
        """Сводка по недавно активным людям для контекста Марин — реальный
        Person Model, а не только счётчик сообщений."""
        people = sorted(self.people.values(), key=lambda p: p.last_seen, reverse=True)[:limit]
        if not people:
            return "Пока нет накопленных профилей людей."
        lines = []
        for p in people:
            bits = [f"trust={p.trust_level:.1f}"]
            if p.likes:
                bits.append("любит: " + ", ".join(p.likes[:5]))
            if p.dislikes:
                bits.append("не любит: " + ", ".join(p.dislikes[:5]))
            open_topics = [t["topic"] for t in p.unresolved_topics if t.get("status") == "open"]
            if open_topics:
                bits.append("незакрытые темы: " + "; ".join(open_topics[:3]))
            pending = [c["action"] for c in p.commitments if c.get("status") == "pending"]
            if pending:
                bits.append("обещания в ожидании: " + "; ".join(pending[:3]))
            who = p.name or p.username or p.user_id
            handle = f" (@{p.username})" if p.username else ""
            lines.append(f"- {who}{handle}: {', '.join(bits)}")
        return "\n".join(lines)

    def world_stats(self) -> str:
        """Сводка по всему, что накоплено в наблюдателе с начала работы, а не
        только за сегодня — сколько разных чатов и людей вообще известно.
        Считает по chat_id (реально уникален), а не по названию — два разных
        чата с одинаковым title (напр. "Тест") раньше схлопывались бы в один."""
        return (
            f"Всего в наблюдателе с начала работы: известных чатов={len(self.chats)}, "
            f"известных людей={len(self.people)}, событий в логе={len(self.events)}."
        )

    def known_chats_summary(self, limit: int = 15) -> str:
        """Список известных чатов по id — если несколько чатов называются
        одинаково, это видно явно (оба перечислены с разными id), вместо
        того чтобы молча путаться, какой из них имелся в виду."""
        if not self.chats:
            return "Пока нет известных чатов."
        by_title: Dict[str, int] = defaultdict(int)
        for c in self.chats.values():
            by_title[c["title"]] += 1
        items = sorted(self.chats.items(), key=lambda kv: kv[1]["last_seen"], reverse=True)[:limit]
        lines = []
        for chat_id, c in items:
            collision_note = " [ЕСТЬ ЕЩЁ ЧАТЫ С ТАКИМ ЖЕ НАЗВАНИЕМ]" if by_title[c["title"]] > 1 else ""
            lines.append(f"- «{c['title']}» (id={chat_id}, сообщений={c['message_count']}){collision_note}")
        return "\n".join(lines)

    def search(self, query: str, limit: int = 12) -> List[TelegramEvent]:
        q = (query or "").lower().strip()
        if not q:
            return []
        tokens = [x for x in re.findall(r"[\w@-]+", q) if len(x) > 2]
        scored = []
        for e in self.events:
            hay = f"{e.sender_name} @{e.username} {e.chat_title} {e.text}".lower()
            score = sum(1 for token in tokens if token in hay)
            if score:
                scored.append((score, e.ts, e))
        scored.sort(key=lambda x: (x[0], x[1]), reverse=True)
        return [x[2] for x in scored[:limit]]

    def _clean_text(self, text: str) -> str:
        return " ".join((text or "").split())

    def to_dict(self) -> Dict:
        """Как _save(), но возвращает словарь, а не пишет файл — для
        объединения в один бандл-файл командой /export в telegram/client.py."""
        return {
            "events": [asdict(e) for e in self.events],
            "people": {k: asdict(v) for k, v in self.people.items()},
            "chats": self.chats,
            "saved_at": time.time(),
        }

    def merge_from_dict(self, data: Dict) -> int:
        """Как _load(), но мёрджит в уже существующее состояние (для /import
        в другом окружении), а не заменяет его полностью — люди с тем же
        user_id обновляются, новые добавляются."""
        count = 0
        for x in data.get("events", []):
            try:
                self.events.append(TelegramEvent(**x))
                count += 1
            except Exception:
                continue
        self.events = self.events[-self.max_events:]
        for k, v in data.get("people", {}).items():
            try:
                self.people[k] = PersonProfile(**v)
            except Exception:
                continue
        for chat_id, entry in data.get("chats", {}).items():
            if isinstance(entry, dict):
                self.chats[chat_id] = entry
        self._save()
        return count

    def _save(self) -> None:
        payload = {
            "events": [asdict(e) for e in self.events],
            "people": {k: asdict(v) for k, v in self.people.items()},
            "chats": self.chats,
            "saved_at": time.time(),
        }
        directory = os.path.dirname(os.path.abspath(self.path))
        os.makedirs(directory, exist_ok=True)
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
        os.replace(tmp, self.path)

    def _load(self) -> None:
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                data = json.load(f)
            self.events = [TelegramEvent(**x) for x in data.get("events", [])][-self.max_events:]
            self.people = {k: PersonProfile(**v) for k, v in data.get("people", {}).items()}
            self.chats = data.get("chats", {})
        except Exception:
            self.events, self.people, self.chats = [], {}, {}
