"""ChannelPublisher — the single executor for everything Marin publishes in
her own channels.

Before this module, "сделай пост" went through a generic chat tick: the model
had to (1) guess a channel id, (2) write the post inline in a chat reply as an
<<<ACTION:send_message|...|{json}>>> marker, (3) wait for an explicit "да".
Autoposting went through an LLM-generated *plan* whose payload_template
contained the post text frozen at plan time, so each cycle re-published the
same text.

Now there is exactly one path, used by all three entry points:

    owner phrase  ─┐  (intents.detect_intent — deterministic fast path)
    <<<POST:...>>> ├─►  ChannelPublisher.publish()  ─►  Telegram
    autopost tick ─┘  (AutonomousLifeLoop.pulse)

publish():
  1. resolves the target channel (hint -> registry -> discovery of channels
     the account can post in), never asks the owner;
  2. collects context: channel title/about, recent posts (style + anti-repeat),
     Marin's latest diary thoughts, time of day, owner's brief;
  3. writes the post with a dedicated task-mode prompt (system_override —
     no chat protocol, no markers, no 2-3 message splitting);
  4. quality gate: markers/meta-leak stripped, emoji policy, length limits,
     near-duplicate check against recent posts (one rewrite attempt);
  5. publishes immediately (optionally with a freshly generated selfie),
     records the post in the durable registry + episodic memory.

No confirmation step by design: the owner explicitly wants posts in *her own*
channels to be autonomous. Scope stays narrow — only channels that are in the
own-channels registry (or auto-discovered channels this account can post in)
and only content publication / deleting her own last post.
"""
from __future__ import annotations

import asyncio
import difflib
import logging
import re
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from ..action.action import ActionType
from ..env import env_float
from ..llm.interface import LanguagePlanningInput
from ..llm.providers import _is_unusable_output
from .engagement import EngagementMixin
from .inner_thoughts import InnerThoughts
from .theme_fatigue import fatigue_note, fatigued_themes, recent_idea_texts
from .settings import local_now

logger = logging.getLogger("marin_x.telegram.publisher")

TELEGRAM_TEXT_LIMIT = 4096
TELEGRAM_CAPTION_LIMIT = 1024
RECENT_POSTS_FOR_CONTEXT = 6
POST_HISTORY_KEEP = 20
DUPLICATE_SIMILARITY = 0.72
MIN_AUTOPOST_INTERVAL = 30 * 60.0
DEFAULT_AUTOPOST_INTERVAL = 6 * 3600.0

_ANY_MARKER_RE = re.compile(r"<<<[^<>]*?>>>|<<<.*$", re.DOTALL)
_MSG_DELIM_RE = re.compile(r"\s*<<<MSG>>>\s*")
_WRAPPING_QUOTES_RE = re.compile(r'^\s*[«"“](.*)[»"”]\s*$', re.DOTALL)
_PREFACE_RE = re.compile(
    r"^\s*[«\"“]?\s*(?:вот\s+(?:пост|текст|вариант)[^:\n]{0,40}:|пост\s*:|текст\s+поста\s*:|конечно[,!]?\s+вот[^:\n]{0,40}:)\s*[»\"”]?\s*",
    re.IGNORECASE,
)
_EMOJI_RE = re.compile(r"[\U0001F1E0-\U0001F1FF\U0001F300-\U0001FAFF\u2600-\u27BF\uFE0F]")

_POST_SYSTEM_PROMPT = """Ты — Марин. Ты сама ведёшь свой Telegram-канал «{title}». Сейчас ты пишешь ОДИН новый пост для подписчиков.

Как писать:
- От первого лица, своим живым голосом: {tone}. {language}
- Это пост в канал, а не сообщение в личку: обращайся к подписчикам или просто делись мыслью, не к одному человеку.
- Первая строка цепляет. Дальше — по делу, без воды и канцелярита, без «в этом посте я расскажу».
- Обычный объём 300–900 знаков; короче, если мысль короткая; до 1500, только если тема реально требует.
- Абзацы короткие, между ними пустая строка. Без markdown-заголовков (#), без списков-простыней.
- {emoji_rule}
- Хэштеги только если в прошлых постах канала они были.
- Держи манеру прошлых постов канала, но НЕ повторяй их темы, заходы и формулировки.
- Не пиши, что тебя попросили написать пост, не упоминай «владельца», не выдумывай фактов о реальных людях, ссылок и цифр.
- Не выдумывай событий и ощущений, которых с тобой не было («заварила чай», «гуляла под дождём», «укуталась в плед» — только если это есть в материале). Твоя жизнь — разговоры, попытки, мысли, настроение.
- Канал публичный: никаких имён, юзернеймов, цитат из личных переписок и подробностей чужой жизни.
{topic_rule}

Ответ — ТОЛЬКО готовый текст поста. Без кавычек вокруг, без пояснений до или после, без служебных тегов вида <<<...>>>."""


_ANY_TOPIC = {"на твой выбор", "любой", "что угодно", "что-нибудь", "любой пост", "о чём хочешь"}


@dataclass
class PublishResult:
    ok: bool
    text: str = ""
    channel_id: Optional[int] = None
    channel_title: str = ""
    message_id: Optional[int] = None
    link: str = ""
    error: str = ""
    channel_auto_chosen: bool = False
    extra: Dict[str, Any] = field(default_factory=dict)

    def owner_summary(self) -> str:
        """Короткое человеческое подтверждение для владельца (fallback,
        если чат-модель не ответила сама)."""
        if self.extra.get("summary"):
            return str(self.extra["summary"])
        if not self.ok:
            return self.error or "Не получилось опубликовать пост."
        where = f"«{self.channel_title}»" if self.channel_title else "канал"
        return f"Выложила в {where}" + (f"\n{self.link}" if self.link else "")


class ChannelPublisher(EngagementMixin):
    """Uses the MarinTelegramClient as its port (``tc``): Telethon client,
    engine, own-channels registry, selfie generator. Kept as a separate
    object (not a mixin) so it can be unit-tested with a fake ``tc``."""

    def __init__(self, telegram_client: Any):
        self._tc = telegram_client
        self.inner = InnerThoughts(telegram_client)
        self._locks: Dict[str, asyncio.Lock] = {}

    # ------------------------------------------------------------------ utils
    @property
    def _channels(self) -> Dict[str, Dict[str, Any]]:
        return self._tc._own_channels

    def _lock(self, key: str) -> asyncio.Lock:
        if key not in self._locks:
            self._locks[key] = asyncio.Lock()
        return self._locks[key]

    @staticmethod
    def _norm(s: str) -> str:
        return re.sub(r"[^\w]+", " ", (s or "").lower().replace("ё", "е")).strip()

    @staticmethod
    def _link(entry: Dict[str, Any], message_id: Optional[int]) -> str:
        if not message_id:
            return ""
        username = str(entry.get("username") or "").lstrip("@")
        if username:
            return f"https://t.me/{username}/{message_id}"
        cid = str(entry.get("id") or "")
        if cid.startswith("-100"):
            return f"https://t.me/c/{cid[4:]}/{message_id}"
        return ""

    # ------------------------------------------------------ channel resolution
    def _match_hint(self, hint: str) -> Optional[Dict[str, Any]]:
        if not hint:
            return None
        h = hint.strip().lstrip("@")
        hn = self._norm(h)
        for entry in self._channels.values():
            if str(entry.get("id")) == h or str(entry.get("username") or "").lstrip("@").lower() == h.lower():
                return entry
        best, best_score = None, 0.0
        for entry in self._channels.values():
            title = self._norm(str(entry.get("title") or ""))
            if not title:
                continue
            if hn and (hn in title or title in hn):
                return entry
            score = difflib.SequenceMatcher(None, hn, title).ratio()
            if score > best_score:
                best, best_score = entry, score
        return best if best_score >= 0.6 else None

    def _default_entry(self) -> Optional[Dict[str, Any]]:
        entries = list(self._channels.values())
        if not entries:
            return None
        if len(entries) == 1:
            return entries[0]
        for e in entries:
            if e.get("default"):
                return e
        # несколько каналов, дефолт не задан: broadcast-каналы раньше групп,
        # затем тот, где она постила последней (это её «живой» канал)
        entries.sort(key=lambda e: (bool(e.get("is_broadcast", True)), e.get("last_post_at") or 0.0), reverse=True)
        return entries[0]

    async def _discover_postable_channels(self) -> List[Dict[str, Any]]:
        """Каналы, куда этот аккаунт реально может постить (создатель или
        админ с правом post_messages) — используется, только если реестр
        «своих каналов» пуст."""
        found: List[Dict[str, Any]] = []
        try:
            dialogs = await self._tc.client.get_dialogs(limit=200)
        except Exception:
            logger.warning("[POST] could not list dialogs for discovery", exc_info=True)
            return found
        for d in dialogs:
            ent = getattr(d, "entity", None)
            if not getattr(ent, "broadcast", False):
                continue
            rights = getattr(ent, "admin_rights", None)
            if getattr(ent, "creator", False) or getattr(rights, "post_messages", False):
                found.append({
                    "id": getattr(d, "id", None),
                    "title": getattr(ent, "title", "") or getattr(d, "name", "") or "",
                    "username": getattr(ent, "username", "") or "",
                    "creator": bool(getattr(ent, "creator", False)),
                    "date": getattr(getattr(d, "date", None), "timestamp", lambda: 0.0)(),
                })
        found.sort(key=lambda c: (c["creator"], c["date"]), reverse=True)
        return found

    async def resolve_channel(self, hint: str = "") -> Tuple[Optional[Dict[str, Any]], bool, str]:
        """-> (registry entry, auto_chosen, error). Никогда не спрашивает
        владельца: называет канал сама, если это однозначно или разумно."""
        entry = self._match_hint(hint)
        if entry is not None:
            if len(self._channels) > 1 and not entry.get("default"):
                self.set_default(entry)  # владелец явно назвал канал — дальше по умолчанию он
            return entry, False, ""
        if hint:
            # владелец назвал канал, которого нет в реестре — пробуем
            # резолвнуть его напрямую и, если это канал, запоминаем как свой
            try:
                ent = await self._tc.client.get_entity(hint.lstrip("@"))
                if getattr(ent, "broadcast", False) or getattr(ent, "megagroup", False):
                    from telethon import utils  # локально: модуль тестируется без Telethon
                    cid = utils.get_peer_id(ent)
                    self._tc._remember_own_channel(cid, title=getattr(ent, "title", "") or "",
                                                   username=getattr(ent, "username", "") or "")
                    return self._channels.get(str(cid)), False, ""
            except Exception:
                logger.info("[POST] hint %r did not resolve to a channel", hint)
        entry = self._default_entry()
        if entry is not None:
            return entry, len(self._channels) > 1, ""
        candidates = await self._discover_postable_channels()
        if candidates:
            c = candidates[0]
            self._tc._remember_own_channel(c["id"], title=c["title"], username=c["username"])
            entry = self._channels.get(str(c["id"]))
            if entry is not None:
                entry["default"] = True
                self._tc._save_own_channels_registry()
            logger.info("[POST] auto-discovered channel %s «%s» (of %d candidates)", c["id"], c["title"], len(candidates))
            return entry, True, ""
        return None, False, (
            "У меня пока нет своего канала, куда я могу постить. Назначь мне канал командой "
            "«.мойканал @username» или попроси создать новый."
        )

    def set_default(self, entry: Dict[str, Any]) -> None:
        for e in self._channels.values():
            e["default"] = e is entry
        self._tc._save_own_channels_registry()

    # --------------------------------------------------------------- context
    async def _recent_posts(self, entity: Any, entry: Dict[str, Any]) -> List[str]:
        texts: List[str] = []
        try:
            msgs = await self._tc.client.get_messages(entity, limit=RECENT_POSTS_FOR_CONTEXT)
            for m in msgs or []:
                t = (getattr(m, "raw_text", None) or getattr(m, "message", None) or "").strip()
                if t:
                    texts.append(t)
        except Exception:
            logger.debug("[POST] could not read channel history", exc_info=True)
        if not texts:
            texts = [h.get("text", "") for h in reversed(entry.get("post_history") or []) if h.get("text")]
        return texts[:RECENT_POSTS_FOR_CONTEXT]

    async def _channel_about(self, entity: Any) -> str:
        try:
            from telethon import functions  # локально, см. выше
            full = await self._tc.client(functions.channels.GetFullChannelRequest(channel=entity))
            return (getattr(getattr(full, "full_chat", None), "about", "") or "").strip()
        except Exception:
            return ""

    def _recent_thoughts(self, limit: int = 3) -> List[str]:
        try:
            return [e.text.strip() for e in self._tc.engine.diary.recent(limit) if getattr(e, "text", "").strip()]
        except Exception:
            return []

    @staticmethod
    def _daypart() -> str:
        h = local_now().hour  # раньше — часы сервера (UTC): ночью писала «вечерние» посты
        return "ночь" if h < 6 else "утро" if h < 12 else "день" if h < 18 else "вечер"

    def _build_prompt(self, entry: Dict[str, Any], about: str, recent: List[str], brief: str,
                      with_selfie: bool, retry_note: str = "", with_illustration: bool = False,
                      inner: bool = False) -> LanguagePlanningInput:
        personality = getattr(self._tc.engine, "personality", None)
        style = dict(getattr(personality, "style_prior", {}) or {})
        allow_emoji = bool(getattr(self._tc, "allow_emoji", False))
        tired = fatigued_themes(recent + recent_idea_texts(self._tc))
        tired_rule = f"\n- {fatigue_note(tired)}" if tired else ""
        if inner and brief:
            topic_rule = (f"- Это твоя настоящая мысль прямо сейчас: «{brief.strip()}». Раскрой именно её — "
                          f"своими словами, как живой пост. Не добавляй событий, которых в ней нет."
                          + tired_rule)
        elif brief and brief.strip().lower() not in {"на твой выбор", "любой", "что угодно", "что-нибудь"}:
            topic_rule = f"- Тема/угол от тебя самой по задумке: {brief.strip()}. Раскрой именно это."
        else:
            avoid = style.get("avoid_topics")
            topic_rule = (
                "- Тему выбери сама: то, что тебя сейчас реально занимает — из недавних мыслей ниже, "
                "времени суток, настроения. Что-то личное и живое, а не общие банальности."
                + (f" Не бери темы: {avoid}." if avoid else "") + tired_rule
            )
        if with_selfie:
            topic_rule += (f"\n- К посту будет приложено твоё свежее селфи — текст станет подписью, "
                           f"поэтому уложись в {TELEGRAM_CAPTION_LIMIT - 24} знаков.")
        elif with_illustration:
            topic_rule += (f"\n- К посту будет приложена тематическая иллюстрация (не твоё лицо) — текст "
                           f"станет подписью, уложись в {TELEGRAM_CAPTION_LIMIT - 24} знаков.")
        system = _POST_SYSTEM_PROMPT.format(
            title=entry.get("title") or "мой канал",
            tone=style.get("tone", "тепло, живо, искренне"),
            language=style.get("language", ""),
            emoji_rule="Эмодзи можно, но умеренно." if allow_emoji else "Никаких эмодзи.",
            topic_rule=topic_rule,
        )
        parts = [f"Канал: «{entry.get('title') or 'без названия'}»" + (f" (@{entry['username']})" if entry.get("username") else "")]
        if about:
            parts.append(f"Описание канала: {about}")
        parts.append(f"Сейчас: {local_now().strftime('%d.%m.%Y %H:%M')} ({self._daypart()}, твоё местное время).")
        if recent:
            parts.append("Последние посты канала (новые сверху) — стиль держи, темы и заходы НЕ повторяй:\n"
                         + "\n---\n".join(t[:600] for t in recent))
        else:
            parts.append("В канале ещё нет постов — это может быть первый пост, можно коротко представиться.")
        thoughts = self._recent_thoughts()
        if thoughts:
            parts.append("Твои недавние мысли из дневника (материал, не цитировать дословно):\n- "
                         + "\n- ".join(t[:400] for t in thoughts))
        if brief and not inner:
            parts.append(f"Задумка: {brief}")
        insight_text = self.engagement_insights(entry)
        if insight_text:
            parts.append(insight_text)
        if retry_note:
            parts.append(retry_note)
        parts.append("Напиши пост.")
        return LanguagePlanningInput(
            situation_summary="\n\n".join(parts),
            retrieved_memory_summaries=[],
            active_belief_summaries=[],
            chosen_action_type=ActionType.ANSWER,
            goal_context_summary="",
            style_prior=style,
            system_override=system,
        )

    # -------------------------------------------------------- quality gate
    def _clean(self, text: str, limit: int) -> str:
        t = (text or "").strip()
        t = _MSG_DELIM_RE.sub("\n\n", t)
        t = _ANY_MARKER_RE.sub("", t)
        t = _PREFACE_RE.sub("", t)
        m = _WRAPPING_QUOTES_RE.match(t)
        if m and "\n\n" not in m.group(1)[:3]:
            t = m.group(1)
        t = re.sub(r"^\s*#{1,6}\s*", "", t, flags=re.MULTILINE)
        if not getattr(self._tc, "allow_emoji", False):
            t = _EMOJI_RE.sub("", t)
        t = re.sub(r"[ \t]{2,}", " ", t)
        t = re.sub(r"\n{3,}", "\n\n", t).strip()
        if len(t) > limit:
            cut = t[:limit]
            # режем по последнему концу предложения/абзаца, не посреди слова
            idx = max(cut.rfind("\n\n"), cut.rfind(". "), cut.rfind("! "), cut.rfind("? "))
            t = (cut[: idx + 1] if idx > limit * 0.5 else cut.rsplit(" ", 1)[0]).strip()
        return t

    @staticmethod
    def _too_similar(text: str, recent: List[str]) -> bool:
        a = text.lower()
        return any(difflib.SequenceMatcher(None, a, r.lower()).ratio() >= DUPLICATE_SIMILARITY for r in recent if r)

    async def _generate(self, entry: Dict[str, Any], entity: Any, brief: str, with_selfie: bool,
                        with_illustration: bool = False, inner: bool = False) -> str:
        limit = TELEGRAM_CAPTION_LIMIT if (with_selfie or with_illustration) else TELEGRAM_TEXT_LIMIT
        recent = await self._recent_posts(entity, entry)
        about = await self._channel_about(entity)
        provider = self._tc.engine.language_planner.provider
        retry_note = ""
        for attempt in range(2):
            pin = self._build_prompt(entry, about, recent, brief, with_selfie, retry_note, with_illustration, inner)
            raw = await asyncio.to_thread(provider.generate, pin)
            if not raw or _is_unusable_output(raw):
                raise RuntimeError("модель вернула пустой/служебный текст")
            text = self._clean(raw, limit)
            if len(text) < 20:
                retry_note = "Прошлая попытка вышла слишком короткой — напиши полноценный пост."
                continue
            if self._too_similar(text, recent):
                retry_note = ("Прошлая попытка почти повторила один из недавних постов. Возьми другой "
                              "заход и другие слова.")
                logger.info("[POST] near-duplicate draft, rewriting (attempt %d)", attempt + 1)
                continue
            return text
        if len(text) >= 20:
            return text  # лучше опубликовать, чем молча провалить просьбу владельца
        raise RuntimeError("не получилось написать нормальный текст поста")

    # --------------------------------------------------------------- publish
    async def publish(self, brief: str = "", *, verbatim_text: str = "", channel_hint: str = "",
                      with_selfie: bool = False, with_illustration: bool = False,
                      source: str = "owner", inner: bool = False, inner_focus: str = "") -> PublishResult:
        entry, auto_chosen, err = await self.resolve_channel(channel_hint)
        if entry is None:
            return PublishResult(ok=False, error=err)
        key = str(entry.get("id"))
        async with self._lock(key):
            try:
                entity = await self._tc.client.get_entity(int(key) if key.lstrip("-").isdigit() else key)
            except Exception:
                logger.warning("[POST] cannot resolve channel %s", key, exc_info=True)
                return PublishResult(ok=False, channel_title=entry.get("title", ""),
                                     error=f"Не могу открыть канал «{entry.get('title') or key}» — может, меня там больше нет?")
            if not with_selfie and not with_illustration and not verbatim_text:
                with_illustration = self._auto_pick_illustration()
            try:
                if verbatim_text:
                    limit = TELEGRAM_CAPTION_LIMIT if (with_selfie or with_illustration) else TELEGRAM_TEXT_LIMIT
                    text = self._clean(verbatim_text, limit)
                else:
                    topicless = not (brief or "").strip() or (brief or "").strip().lower() in _ANY_TOPIC
                    if not inner and topicless:
                        # «сделай пост» без темы — тоже из настоящей мысли, а не случайной темы
                        since = float(entry.get("last_post_at") or 0) or time.time() - 86400
                        thought, _why = await self.inner.reflect(
                            since, await self._recent_posts(entity, entry), focus=inner_focus,
                            require_news=False)
                        if thought:
                            brief, inner = thought, True
                    text = await self._generate(entry, entity, brief, with_selfie, with_illustration, inner)
            except Exception as e:
                logger.warning("[POST] generation failed: %s", e, exc_info=True)
                return PublishResult(ok=False, channel_title=entry.get("title", ""),
                                     error="Не смогла написать пост — модель сейчас не отвечает нормально. Попробуй чуть позже.")

            try:
                msg = None
                if with_selfie:
                    msg = await self._send_with_selfie(entity, text, brief)
                elif with_illustration:
                    msg = await self._send_with_illustration(entity, text, brief)
                if msg is None:
                    msg = await self._tc.client.send_message(entity, text, link_preview=False)
            except Exception as e:
                logger.warning("[POST] send failed channel=%s", key, exc_info=True)
                reason = type(e).__name__
                hint = " Похоже, у меня нет права публиковать там." if "Admin" in reason or "Forbidden" in reason or "Write" in reason else ""
                return PublishResult(ok=False, channel_title=entry.get("title", ""), text=text,
                                     error=f"Telegram не дал опубликовать в «{entry.get('title') or key}».{hint}")

            message_id = getattr(msg, "id", None)
            self._record(entry, message_id, text, brief, source)
            link = self._link(entry, message_id)
            logger.info("[POST] published channel=%s msg=%s source=%s chars=%d", key, message_id, source, len(text))
            return PublishResult(ok=True, text=text, channel_id=entry.get("id"), channel_title=entry.get("title", ""),
                                 message_id=message_id, link=link, channel_auto_chosen=auto_chosen)

    async def _send_with_selfie(self, entity: Any, caption: str, brief: str):
        try:
            generator = self._tc._get_selfie_generator()
            # кадр — по САМОМУ тексту поста, местному времени и одежде дня
            scene = await self._tc.selfie_director.scene_for(caption, brief)
            logger.info("[POST] selfie scene: %s", scene[:200])
            image = await generator.generate(scene, reference_image_b64=self._tc._get_selfie_reference())
            uploaded = await self._tc.client.upload_file(image, file_name="selfie.jpg")
            return await self._tc.client.send_file(entity, uploaded, caption=caption)
        except Exception:
            logger.warning("[POST] selfie unavailable, publishing text only", exc_info=True)
            return None

    @staticmethod
    def _auto_pick_illustration() -> bool:
        import os
        import random
        try:
            chance = env_float("MARIN_ILLUSTRATION_AUTO_CHANCE", 0)
        except ValueError:
            chance = 0.0
        return chance > 0 and random.random() < chance

    def _illustration_prompt(self, brief: str, post_text: str) -> str:
        if brief.strip():
            base = brief.strip()
        else:
            first = re.split(r"(?<=[.!?])\s", post_text.strip(), maxsplit=1)[0]
            base = first[:180] or "a calm, atmospheric everyday scene"
        # Её лицо появляется только в селфи по референсу. Иначе подписчики
        # видят случайного человека, выданного за неё.
        return f"{base}. No people, no faces, no selfies — only the scene, objects and mood."

    async def _send_with_illustration(self, entity: Any, caption: str, brief: str):
        try:
            generator = self._tc._get_illustration_generator()
            image = await generator.generate(self._illustration_prompt(brief, caption))
            uploaded = await self._tc.client.upload_file(image, file_name="illustration.jpg")
            return await self._tc.client.send_file(entity, uploaded, caption=caption)
        except Exception:
            logger.warning("[POST] illustration unavailable, publishing text only", exc_info=True)
            return None

    def _record(self, entry: Dict[str, Any], message_id: Optional[int], text: str, brief: str, source: str) -> None:
        now = time.time()
        hist = list(entry.get("post_history") or [])
        hist.append({"id": message_id, "at": now, "text": text[:1200], "brief": brief[:200], "source": source})
        entry["post_history"] = hist[-POST_HISTORY_KEEP:]
        self._tc._record_own_channel_post(entry.get("id"), preview=text)  # last_post_at/preview + save
        try:
            self._tc.engine.remember_fact(
                f"channel_post_{entry.get('id')}_{message_id}",
                f"{time.strftime('%d.%m %H:%M')} я опубликовала пост в своём канале «{entry.get('title')}»: {text[:300]}",
                confidence=0.95,
            )
        except Exception:
            logger.debug("[POST] could not write post to memory", exc_info=True)

    # ---------------------------------------------------------------- delete
    async def delete_last(self, channel_hint: str = "") -> PublishResult:
        entry, _, err = await self.resolve_channel(channel_hint)
        if entry is None:
            return PublishResult(ok=False, error=err)
        hist = list(entry.get("post_history") or [])
        if not hist or not hist[-1].get("id"):
            return PublishResult(ok=False, channel_title=entry.get("title", ""),
                                 error="Не вижу своего последнего поста в этом канале — удалять нечего.")
        last = hist[-1]
        key = str(entry.get("id"))
        try:
            entity = await self._tc.client.get_entity(int(key) if key.lstrip("-").isdigit() else key)
            await self._tc.client.delete_messages(entity, [int(last["id"])])
        except Exception:
            logger.warning("[POST] delete failed", exc_info=True)
            return PublishResult(ok=False, channel_title=entry.get("title", ""), error="Не получилось удалить пост.")
        entry["post_history"] = hist[:-1]
        prev = entry["post_history"][-1] if entry["post_history"] else None
        entry["last_post_at"] = prev["at"] if prev else None
        entry["last_post_preview"] = prev["text"][:200] if prev else ""
        self._tc._save_own_channels_registry()
        return PublishResult(ok=True, channel_title=entry.get("title", ""), text=last.get("text", ""),
                             message_id=last.get("id"))

    # -------------------------------------------------------------- autopost
    async def set_autopost(self, enable: bool, *, interval_seconds: Optional[float] = None,
                           channel_hint: str = "", brief: str = "") -> str:
        if not enable and not channel_hint:
            touched = [e for e in self._channels.values() if e.get("autopost_enabled")]
            for e in touched:
                e["autopost_enabled"] = False
            self._tc._save_own_channels_registry()
            return "Ок, больше не пощу сама." if touched else "Я и так сама сейчас ничего не пощу."
        entry, _, err = await self.resolve_channel(channel_hint)
        if entry is None:
            return err
        entry["autopost_enabled"] = bool(enable)
        if enable:
            interval = max(MIN_AUTOPOST_INTERVAL, float(interval_seconds or entry.get("autopost_interval") or DEFAULT_AUTOPOST_INTERVAL))
            entry["autopost_interval"] = interval
            entry["autopost_brief"] = brief or entry.get("autopost_brief", "")
            entry.setdefault("last_post_at", None)
        self._tc._save_own_channels_registry()
        title = entry.get("title") or "канал"
        if not enable:
            return f"Ок, в «{title}» больше сама не пощу."
        return f"Договорились, веду «{title}» сама — {self.human_interval(entry['autopost_interval'])}" + (
            f", про {brief}" if brief and not brief.lower().startswith(("про", "о ", "об ")) else (f", {brief}" if brief else "")) + "."

    @staticmethod
    def human_interval(sec: float) -> str:
        if sec >= 604800 - 1:
            return "примерно раз в неделю"
        if sec >= 86400 - 1:
            days = sec / 86400
            return "примерно раз в день" if days < 1.5 else f"примерно раз в {int(round(days))} дня"
        per_day = 86400 / sec
        if 1.5 <= per_day <= 4.4 and abs(per_day - round(per_day)) < 0.2:
            return f"примерно {int(round(per_day))} раза в день"
        hours = sec / 3600
        return f"примерно каждые {hours:.0f} ч" if hours >= 1 else f"примерно каждые {sec / 60:.0f} мин"

    def due_autopost_channels(self, now: Optional[float] = None) -> List[Dict[str, Any]]:
        now = now or time.time()
        due = []
        for e in self._channels.values():
            if not e.get("autopost_enabled"):
                continue
            interval = max(MIN_AUTOPOST_INTERVAL, float(e.get("autopost_interval") or DEFAULT_AUTOPOST_INTERVAL))
            last = e.get("last_post_at") or 0.0
            last_try = e.get("autopost_last_attempt_at") or 0.0
            # после неудачи не долбим каждые 5 минут — ждём хотя бы 1/4 интервала
            if now - last >= interval and now - last_try >= min(interval / 4, 3600.0):
                due.append(e)
        return due

    async def _autopost_thought(self, entry: Dict[str, Any]) -> "Tuple[str, str]":
        since = float(entry.get("last_post_at") or 0) or time.time() - 86400
        recent: List[str] = []
        try:
            key = str(entry.get("id"))
            entity = await self._tc.client.get_entity(int(key) if key.lstrip("-").isdigit() else key)
            recent = await self._recent_posts(entity, entry)
        except Exception:
            logger.debug("[POST] recent posts unavailable for reflection", exc_info=True)
        return await self.inner.reflect(since, recent, focus=entry.get("autopost_brief") or "")

    async def autopost_tick(self) -> List[PublishResult]:
        results: List[PublishResult] = []
        for entry in self.due_autopost_channels():
            entry["autopost_last_attempt_at"] = time.time()
            self._tc._save_own_channels_registry()
            thought, why = await self._autopost_thought(entry)
            if not thought:
                # Нечего сказать по-настоящему — молчим, а не выдумываем тему.
                logger.info("[POST] autopost skipped channel=%s: %s", entry.get("id"), why)
                results.append(PublishResult(ok=False, channel_title=entry.get("title", ""),
                                             error=why, extra={"skipped": True}))
                continue
            logger.info("[POST] autopost from real thought channel=%s: %r", entry.get("id"), thought[:120])
            res = await self.publish(thought, channel_hint=str(entry.get("id")), source="autopost", inner=True)
            results.append(res)
            if not res.ok:
                logger.warning("[POST] autopost failed channel=%s: %s", entry.get("id"), res.error)
        return results
