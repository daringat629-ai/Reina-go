"""Natural-language intents of the owner that Marin executes herself.

Deterministic fast path (no LLM round-trip) for the most common requests
around her channel:

* ``PostIntent``        — "сделай пост", "кинь в канал что-нибудь про осень",
                          "запости с селфи", "опубликуй дословно: ..."
* ``DeleteLastPostIntent`` — "удали последний пост", "снеси пост"
* ``AutopostIntent``    — "веди канал сама, постить 2 раза в день",
                          "перестань постить", "выключи автопостинг"

Anything these regexes miss is still covered by the LLM: the chat protocol
tells the model to emit ``<<<POST:brief>>>`` (see llm/providers.py), which
lands in the same ChannelPublisher. Two layers, one executor.

The module is pure (no Telethon, no I/O) so it is trivially unit-testable.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional, Union

# --------------------------------------------------------------------------
# vocabulary
# --------------------------------------------------------------------------
_POST_NOUN = r"(?:пост\w*|постик\w*|публикаци\w*|запис\w*|новост\w*)"
_POST_VERB = (
    r"(?:сдела\w*|напиш\w*|написа\w*|выложи\w*|выклад\w*|запост\w*|опубликуй\w*|опубликова\w*|"
    r"кин\w*|закин\w*|скин\w*|зали\w*|бахн\w*|накида\w*|наваля\w*|сооруди\w*|замути\w*|"
    r"подготов\w*|дава\w*|го\b|запили\w*|пили\w*|черкани\w*|черкни\w*)"
)
_CHANNEL_NOUN = r"(?:канал\w*|канальчик\w*|тгк|тг-канал\w*)"

# "запости", "запость" are complete requests on their own.
_STANDALONE_POST_VERB_RE = re.compile(r"\b(?:запост\w*|опубликуй|опубликуешь)\b", re.IGNORECASE)
_VERB_NOUN_RE = re.compile(
    rf"\b{_POST_VERB}\b(?:\s+\S+){{0,4}}?\s+{_POST_NOUN}\b|\b{_POST_NOUN}\b(?:\s+\S+){{0,2}}?\s+{_POST_VERB}\b",
    re.IGNORECASE,
)
# "кинь в канал ...", "напиши в канал ...", "выложи на канал ..."
_VERB_TO_CHANNEL_RE = re.compile(
    rf"\b{_POST_VERB}\b(?:\s+\S+){{0,3}}?\s+(?:в|на)\s+(?:мой\s+|свой\s+|наш\s+|твой\s+)?{_CHANNEL_NOUN}",
    re.IGNORECASE,
)
# "пост в канал про X" / "нужен пост" / "хочу пост"
_NEED_POST_RE = re.compile(
    rf"\b(?:нужен|нужно|надо|хочу|жду|хочется|пора|можно)\b(?:\s+\S+){{0,3}}?\s+{_POST_NOUN}\b",
    re.IGNORECASE,
)
_REVIVE_VERB = r"(?:оживи\w*|оживить|разбав\w*|обнови\w*|порадуй\w*|порадовать)"
_REVIVE_CHANNEL_RE = re.compile(
    rf"\b{_REVIVE_VERB}\b(?:\s+\S+){{0,2}}?\s+(?:{_CHANNEL_NOUN}|подписчик\w*)"
    rf"|\b(?:{_CHANNEL_NOUN}|подписчик\w*)(?:\s+\S+){{0,2}}?\s+{_REVIVE_VERB}",
    re.IGNORECASE,
)

# Things that LOOK like a request but are not one.
_NEGATIVE_RE = re.compile(
    r"(?:\bне\s+(?:надо\s+|нужно\s+|стоит\s+)?(?:делай|пиши|выкладывай|постись?|публикуй|кидай|сейчас\s+пост)\w*"
    r"|\bкак\s+(?:сделать|написать|выложить|опубликовать)\b"
    r"|\bты\s+(?:уже\s+)?(?:сделала|выложила|написала|опубликовала|запостила)\b.*\?"
    r"|\bзачем\b|\bпочему\b"
    r"|\b(?:сделал|написал|выложил|опубликовал|запостил|кинул|закинул|скинул|залил)(?:а|и|о)?\b(?!\s+бы)"
    r"|\bудали\w*|\bснеси\w*|\bубери\w*"
    r"|\bпрочитай\w*|\bпокажи\w*|\bчто\s+(?:было|там)\s+в\b)",
    re.IGNORECASE,
)

_TOPIC_RE = re.compile(
    r"(?:\bо\s+том,?|\bпро\b|\bна\s+тему\b|\bнасч[её]т\b|\bпо\s+поводу\b|\bоб?\b|\bтема\s*[:\-—]?)\s*(.+)",
    re.IGNORECASE | re.DOTALL,
)
_VERBATIM_RE = re.compile(
    r"(?:дословно|слово\s+в\s+слово|вот\s+(?:этот\s+|такой\s+)?текст|с\s+текстом|такой\s+текст|этот\s+текст|"
    r"текст\s+поста)\s*[:\-—]?\s*(.+)",
    re.IGNORECASE | re.DOTALL,
)
_QUOTED_RE = re.compile(r"[«\"“](.{15,}?)[»\"”]", re.DOTALL)
# «с селфи» — именно фото самой Марин (её лица).
_SELFIE_RE = re.compile(
    r"\b(?:с\s+|со\s+|и\s+)(?:сво\w+\s+)?(?:селфи|сво\w+\s+фот\w*)",
    re.IGNORECASE,
)
# «с картинкой/фото/иллюстрацией» без слова «селфи» — тематическая картинка
# к посту, а не её лицо.
_ILLUSTRATION_RE = re.compile(
    r"\b(?:с\s+|со\s+|и\s+)(?:иллюстрац\w*|картинк\w*|фот\w*|фотк\w*|изображени\w*|обложк\w*)\b",
    re.IGNORECASE,
)
_CHANNEL_HINT_RES = (
    re.compile(r"(?:https?://)?t\.me/(?!\+|joinchat/)([A-Za-z0-9_]{4,32})", re.IGNORECASE),
    re.compile(r"(?<![\w@])@([A-Za-z0-9_]{4,32})"),
    re.compile(rf"(?:в|на)\s+{_CHANNEL_NOUN}\s+[«\"“]([^»\"”]{{2,64}})[»\"”]", re.IGNORECASE),
    re.compile(r"(?:в|на)\s+[«\"“]([^»\"”]{2,64})[»\"”]", re.IGNORECASE),
)
# trailing channel reference that should not leak into the topic
_TRAILING_CHANNEL_RE = re.compile(
    rf"\s*(?:,\s*)?(?:(?:в|на)\s+(?:мой\s+|свой\s+|наш\s+|твой\s+)?{_CHANNEL_NOUN}\b.*|@\w+.*|(?:https?://)?t\.me/\S+.*)$",
    re.IGNORECASE | re.DOTALL,
)
_TRAILING_POLITE_RE = re.compile(r"[\s,.!?]*(?:пожалуйста|плиз|pls|please|срочно|сейчас|щас|плз)?[\s,.!?]*$", re.IGNORECASE)

# ---- delete last post --------------------------------------------------------
_DELETE_LAST_RE = re.compile(
    rf"\b(?:удали\w*|снеси\w*|убери\w*|сотри\w*)\b(?:\s+\S+){{0,3}}?\s+(?:последн\w+\s+|этот\s+|тот\s+|свой\s+)?{_POST_NOUN}",
    re.IGNORECASE,
)

# ---- autopost on / off ---------------------------------------------------------
_AUTOPOST_OFF_RE = re.compile(
    r"(?:\b(?:перестань|хватит|прекрати|не\s+надо\s+больше|выключи|отключи|останови)\b"
    r"(?:\s+\S+){0,3}?\s+(?:постить|выкладывать|публиковать|автопост\w*|вести\s+канал|постинг\w*))",
    re.IGNORECASE,
)
_AUTOPOST_ON_RE = re.compile(
    r"(?:\b(?:веди|вести|ведёшь|ведешь)\b(?:\s+\S+){0,2}?\s+канал\w*"
    r"|\b(?:постить|выкладывать|публиковать|пиши\s+посты|делай\s+посты|выкладывай|публикуй|пости)\b"
    r"(?:\s+\S+){0,6}?\s+(?:каждый\s+день|ежедневно|каждое\s+утро|каждый\s+вечер|раз\s+в\s+\S+|\d+\s+раз\w*\s+в\s+\S+|"
    r"(?:два|три|четыре|пять)\s+раза?\s+в\s+\S+|каждые\s+\S+(?:\s+\S+)?|сама|регулярно|периодически|по\s+расписанию)"
    r"|\bвключи\w*\s+автопост\w*)",
    re.IGNORECASE,
)
_WORD_NUM = {"один": 1, "одна": 1, "два": 2, "две": 2, "три": 3, "четыре": 4, "пять": 5, "шесть": 6}


@dataclass
class ProactiveIntent:
    enable: bool


_PROACTIVE_OFF_RE = re.compile(
    r"\b(?:не\s+пиши|хватит\s+писать|перестань\s+писать|не\s+надо\s+писать)\b(?:\s+\S+){0,2}?\s+перв\w*",
    re.IGNORECASE,
)
_PROACTIVE_ON_RE = re.compile(
    r"\b(?:пиши|писать)\b(?:\s+\S+){0,2}?\s+перв\w*",
    re.IGNORECASE,
)


@dataclass
class PostIntent:
    brief: str = ""                 # тема/угол — пусто = "на её выбор"
    verbatim_text: str = ""         # если владелец продиктовал текст дословно
    channel_hint: str = ""          # id / @username / название, если назван
    with_selfie: bool = False
    with_illustration: bool = False


@dataclass
class DeleteLastPostIntent:
    channel_hint: str = ""


@dataclass
class AutopostIntent:
    enable: bool
    interval_seconds: Optional[float] = None
    channel_hint: str = ""
    brief: str = ""


Intent = Union[PostIntent, DeleteLastPostIntent, AutopostIntent, ProactiveIntent]


def _channel_hint(text: str) -> str:
    for rx in _CHANNEL_HINT_RES:
        m = rx.search(text)
        if m:
            return m.group(1).strip()
    return ""


def _clean_topic(raw: str) -> str:
    topic = _TRAILING_CHANNEL_RE.sub("", raw.strip())
    topic = _SELFIE_RE.sub("", topic)
    topic = _ILLUSTRATION_RE.sub("", topic)
    topic = _TRAILING_POLITE_RE.sub("", topic).strip(" \t\n,.;:—-")
    return topic[:400]


def parse_interval(text: str) -> Optional[float]:
    """'2 раза в день' -> 43200, 'каждые 3 часа' -> 10800, 'раз в неделю' -> 604800."""
    t = text.lower()
    m = re.search(r"(\d+|один|одна|два|две|три|четыре|пять|шесть)\s+раз\w*\s+в\s+(день|сутки|неделю)", t)
    if m:
        n = int(m.group(1)) if m.group(1).isdigit() else _WORD_NUM[m.group(1)]
        base = 604800.0 if m.group(2) == "неделю" else 86400.0
        return base / max(1, n)
    m = re.search(r"каждые\s+(\d+|два|две|три|четыре|пять|шесть)?\s*(час\w*|дн\w*|дня)", t)
    if m:
        n = int(m.group(1)) if (m.group(1) or "").isdigit() else _WORD_NUM.get(m.group(1) or "", 1)
        return n * (3600.0 if m.group(2).startswith("час") else 86400.0)
    m = re.search(r"каждый\s+час|раз\s+в\s+час", t)
    if m:
        return 3600.0
    if re.search(r"раз\s+в\s+неделю|еженедельно|каждую\s+неделю", t):
        return 604800.0
    if re.search(r"раз\s+в\s+два\s+дня|через\s+день", t):
        return 172800.0
    if re.search(r"каждый\s+день|ежедневно|раз\s+в\s+день|каждое\s+утро|каждый\s+вечер", t):
        return 86400.0
    return None


def detect_intent(text: str) -> Optional[Intent]:
    """Returns the owner's channel intent or None. Order matters: the more
    specific intents (off, delete, schedule) are checked before one-off post."""
    if not text:
        return None
    t = " ".join(text.split())
    if len(t) > 2000:  # a long pasted text is not a command by itself
        head = t[:400]
    else:
        head = t

    if _PROACTIVE_OFF_RE.search(head):
        return ProactiveIntent(enable=False)
    if _PROACTIVE_ON_RE.search(head):
        return ProactiveIntent(enable=True)

    if _AUTOPOST_OFF_RE.search(head):
        return AutopostIntent(enable=False, channel_hint=_channel_hint(head))

    if _DELETE_LAST_RE.search(head):
        return DeleteLastPostIntent(channel_hint=_channel_hint(head))

    if _AUTOPOST_ON_RE.search(head):
        topic_m = _TOPIC_RE.search(head)
        return AutopostIntent(
            enable=True,
            interval_seconds=parse_interval(head),
            channel_hint=_channel_hint(head),
            brief=_clean_topic(topic_m.group(0)) if topic_m else "",
        )

    is_post = bool(
        _VERB_NOUN_RE.search(head) or _VERB_TO_CHANNEL_RE.search(head)
        or _STANDALONE_POST_VERB_RE.search(head) or _NEED_POST_RE.search(head)
        or _REVIVE_CHANNEL_RE.search(head)
    )
    if not is_post or _NEGATIVE_RE.search(head):
        return None

    has_selfie = bool(_SELFIE_RE.search(head))
    intent = PostIntent(
        channel_hint=_channel_hint(t), with_selfie=has_selfie,
        with_illustration=(not has_selfie) and bool(_ILLUSTRATION_RE.search(head)),
    )
    vm = _VERBATIM_RE.search(text)
    if vm:
        body = vm.group(1).strip()
        q = _QUOTED_RE.fullmatch(body.strip())
        intent.verbatim_text = (q.group(1) if q else body).strip()
        return intent
    tm = _TOPIC_RE.search(t)
    if tm:
        # целиком с предлогом: «про осень», «о котах» — LLM так понятнее
        intent.brief = _clean_topic(tm.group(0))
    else:
        # "сделай пост: осеннее настроение, дождь" — всё после двоеточия = бриф
        cm = re.search(rf"{_POST_NOUN}\s*[:\-—]\s*(.+)", t, re.IGNORECASE | re.DOTALL)
        if cm:
            intent.brief = _clean_topic(cm.group(1))
    return intent
