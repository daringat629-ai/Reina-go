"""Find stickers / custom-emoji packs and downloaded sticker files left by
PREVIOUS Marin versions (other deploy folders) and bring them into the
current build.

Older builds kept their registries with relative paths inside each deploy
folder (``marin_media_packs.json``, ``marin_media_vision_cache.json``) and some
downloaded sticker files (.webp/.tgs/.webm) into ``stickers``/``emoji``
folders. A fresh deploy started with an empty catalog, so Marin "forgot"
everything. On startup we scan the configured roots once and MERGE:

* pack short names   -> current media-pack registry (resolved via Telegram);
* Vision descriptions -> current Vision cache (no re-analysis, no cost);
* local sticker files -> sent as real stickers from disk;
* legacy env vars MARIN_STICKER_PACK / MARIN_EMOJI_PACK (old v30 .env).

Pure filesystem code — no Telethon here; unit-testable.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import re
from dataclasses import dataclass, field
from typing import Dict, List

logger = logging.getLogger("marin_x.telegram.legacy_media")

PACK_FILE_RE = re.compile(r"(media_packs|sticker_packs|emoji_packs|stickers?_registry)[^/]*\.json$", re.IGNORECASE)
VISION_FILE_RE = re.compile(r"vision_cache[^/]*\.json$", re.IGNORECASE)
STICKER_EXT = {".webp", ".tgs", ".webm"}
MEDIA_DIR_HINT_RE = re.compile(r"sticker|emoji|стикер|эмодзи|media", re.IGNORECASE)
SKIP_DIRS = {".venv", "venv", "env", "site-packages", "node_modules", ".git", "__pycache__", "dist-packages",
             ".cache", "proc", "sys", "dev", "tmp", "snap"}
SHORT_NAME_RE = re.compile(r"^[A-Za-z0-9_]{3,64}$")
_TME_PACK_RE = re.compile(r"t\.me/(addstickers|addemoji)/([A-Za-z0-9_]+)", re.IGNORECASE)


@dataclass
class LocalSticker:
    """A sticker file on disk, duck-typed like a Telegram Document (``.id``)."""
    path: str
    id: int
    meaning: str = ""


@dataclass
class LegacyMedia:
    packs: Dict[str, Dict[str, str]] = field(default_factory=dict)
    vision: Dict[str, str] = field(default_factory=dict)
    files: List[LocalSticker] = field(default_factory=list)
    sources: List[str] = field(default_factory=list)


def _file_id(path: str) -> int:
    # стабильный «doc id» для файла: одинаковый файл в разных папках — один стикер
    try:
        with open(path, "rb") as fh:
            digest = hashlib.sha1(fh.read(1 << 20)).digest()
    except OSError:
        digest = hashlib.sha1(path.encode()).digest()
    return int.from_bytes(digest[:7], "big")  # < 2^56, не пересекается с реальными id на практике


def _meaning_from_name(path: str) -> str:
    stem = os.path.splitext(os.path.basename(path))[0]
    stem = re.sub(r"^(sticker|emoji|img|file)[_\-]?\d*", "", stem, flags=re.IGNORECASE)
    words = re.sub(r"[_\-.]+", " ", stem).strip()
    return "" if re.fullmatch(r"[\d\s]*", words) else words


def _read_packs(path: str) -> Dict[str, Dict[str, str]]:
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except Exception:
        return {}
    out: Dict[str, Dict[str, str]] = {}

    def add(short: str, kind: str = "unknown") -> None:
        short = short.strip()
        if SHORT_NAME_RE.match(short):
            out[short.lower()] = {"short_name": short, "kind": kind}

    if isinstance(data, dict):
        for key, val in data.items():
            if isinstance(val, dict) and val.get("short_name"):
                add(str(val["short_name"]), str(val.get("kind") or "unknown"))
            elif isinstance(val, str):
                m = _TME_PACK_RE.search(val)
                add(m.group(2) if m else val, "emoji" if m and m.group(1).lower() == "addemoji" else "unknown")
            elif isinstance(key, str):
                add(key)
    elif isinstance(data, list):
        for item in data:
            if isinstance(item, dict) and item.get("short_name"):
                add(str(item["short_name"]), str(item.get("kind") or "unknown"))
            elif isinstance(item, str):
                m = _TME_PACK_RE.search(item)
                add(m.group(2) if m else item, "emoji" if m and m.group(1).lower() == "addemoji" else "unknown")
    return out


def _read_vision(path: str) -> Dict[str, str]:
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except Exception:
        return {}
    if not isinstance(data, dict):
        return {}
    return {str(k): str(v) for k, v in data.items() if v and str(k).lstrip("-").isdigit()}


def packs_from_env() -> Dict[str, Dict[str, str]]:
    out: Dict[str, Dict[str, str]] = {}
    for var, kind in (("MARIN_STICKER_PACK", "sticker"), ("MARIN_EMOJI_PACK", "emoji"),
                      ("MARIN_STICKER_PACKS", "sticker"), ("MARIN_EMOJI_PACKS", "emoji")):
        for raw in re.split(r"[,\s;]+", os.getenv(var, "") or ""):
            if not raw:
                continue
            m = _TME_PACK_RE.search(raw)
            short = m.group(2) if m else raw
            if SHORT_NAME_RE.match(short):
                out[short.lower()] = {"short_name": short, "kind": kind}
    return out


def discover(roots: List[str], *, max_depth: int = 6, max_files: int = 1500,
             exclude: List[str] = ()) -> LegacyMedia:
    result = LegacyMedia()
    seen_ids: set = set()
    exclude_abs = {os.path.abspath(p) for p in exclude if p}
    for root in roots:
        root = os.path.abspath(os.path.expanduser(root))
        if not os.path.isdir(root):
            continue
        base_depth = root.rstrip(os.sep).count(os.sep)
        for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
            depth = dirpath.count(os.sep) - base_depth
            dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS and not d.startswith(".")] if depth < max_depth else []
            in_media_dir = bool(MEDIA_DIR_HINT_RE.search(dirpath))
            for fn in filenames:
                path = os.path.join(dirpath, fn)
                if os.path.abspath(path) in exclude_abs:
                    continue
                low = fn.lower()
                if low.endswith(".json"):
                    if PACK_FILE_RE.search(low):
                        found = _read_packs(path)
                        if found:
                            result.packs.update({k: v for k, v in found.items() if k not in result.packs})
                            result.sources.append(path)
                    elif VISION_FILE_RE.search(low):
                        found_v = _read_vision(path)
                        if found_v:
                            for k, v in found_v.items():
                                result.vision.setdefault(k, v)
                            result.sources.append(path)
                    continue
                ext = os.path.splitext(low)[1]
                if ext in STICKER_EXT and in_media_dir and len(result.files) < max_files:
                    try:
                        if os.path.getsize(path) > 512 * 1024:  # Telegram-стикеры маленькие; крупное — не стикер
                            continue
                    except OSError:
                        continue
                    fid = _file_id(path)
                    if fid in seen_ids:
                        continue
                    seen_ids.add(fid)
                    result.files.append(LocalSticker(path=path, id=fid, meaning=_meaning_from_name(path)))
    for k, v in packs_from_env().items():
        result.packs.setdefault(k, v)
    return result
