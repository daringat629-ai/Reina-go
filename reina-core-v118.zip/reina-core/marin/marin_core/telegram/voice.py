"""
voice.py — TTS-генерация голосовых сообщений (роадмап п.12: Voice + vision +
Telegram media). Как и selfie.py: чистый Python без Telethon, тестируемый в
изоляции; client.py — тонкая Telethon-обвязка (action handler + send_file).

Раньше send_voice/send_audio в client.py ТОЛЬКО пересылали уже присланный
владельцем файл (см. _resend_media) — ничего не генерировали. Здесь голос
создаётся заново из текста через ElevenLabs (обычно — клонированный голос,
настроенный отдельно в личном кабинете ElevenLabs; см. MARIN_VOICE_ID).

Формат для Telegram: настоящее "голосовое сообщение" (круглый пузырь с
waveform, не обычный файл-вложение) требует OGG-контейнер с кодеком Opus.
ElevenLabs отдаёт MP3 — конвертация через ffmpeg, если он есть на сервере.
Если ffmpeg недоступен или конвертация не удалась, результат всё равно
отправляется (как обычный аудиофайл, voice_note=False) — тихая деградация
без потери сообщения, но честно помечена в VoiceResult.is_voice_note.
"""

from __future__ import annotations

import asyncio
import logging
import os
import shutil
import tempfile
from dataclasses import dataclass
from typing import Optional, Protocol

logger = logging.getLogger("marin_core.telegram.voice")

MAX_TTS_CHARS = 800  # длиннее — режем: голосовые в чате короткие реплики, не аудиокниги


@dataclass
class VoiceResult:
    audio_bytes: bytes
    is_voice_note: bool  # True -> OGG/Opus, можно voice_note=True; False -> обычный аудиофайл
    ext: str             # ".ogg" или ".mp3" — для имени файла при отправке


class VoiceGenerationError(Exception):
    """Ожидаемая, обрабатываемая ошибка (не настроено / провайдер
    недоступен) — отличается от неожиданных исключений."""


class VoiceGenerator(Protocol):
    async def generate(self, text: str) -> VoiceResult: ...


class DisabledVoiceGenerator:
    async def generate(self, text: str) -> VoiceResult:
        raise VoiceGenerationError(
            "Генерация голоса не настроена — нужен MARIN_ELEVENLABS_API_KEY и MARIN_VOICE_ID в .env."
        )


@dataclass
class ElevenLabsVoiceConfig:
    api_key: str
    voice_id: str
    model_id: str = "eleven_multilingual_v2"
    stability: float = 0.5
    similarity_boost: float = 0.75
    base_url: str = "https://api.elevenlabs.io/v1"
    timeout: float = 60.0


class ElevenLabsVoiceGenerator:
    """POST {base_url}/text-to-speech/{voice_id} — см. ElevenLabs REST API.
    В отличие от OpenRouter-эндпоинтов в этом проекте, ответ — не JSON, а
    сырые байты аудио (Content-Type: audio/mpeg) напрямую в теле ответа."""

    def __init__(self, config: ElevenLabsVoiceConfig):
        self.config = config

    async def generate(self, text: str) -> VoiceResult:
        text = (text or "").strip()
        if not text:
            raise VoiceGenerationError("Нечего озвучивать — пустой текст.")
        if len(text) > MAX_TTS_CHARS:
            text = text[:MAX_TTS_CHARS]

        try:
            import requests
        except ImportError as e:
            raise VoiceGenerationError(
                "ElevenLabsVoiceGenerator requires the 'requests' package (pip install requests)."
            ) from e

        url = f"{self.config.base_url.rstrip('/')}/text-to-speech/{self.config.voice_id}"
        headers = {"xi-api-key": self.config.api_key, "Content-Type": "application/json"}
        payload = {
            "text": text,
            "model_id": self.config.model_id,
            "voice_settings": {
                "stability": self.config.stability,
                "similarity_boost": self.config.similarity_boost,
            },
        }

        def _do_request() -> bytes:
            resp = requests.post(url, json=payload, headers=headers, timeout=self.config.timeout)
            resp.raise_for_status()
            return resp.content

        try:
            mp3_bytes = await asyncio.to_thread(_do_request)
        except Exception as e:  # noqa: BLE001 — сеть/HTTP-ошибка любого рода
            raise VoiceGenerationError(f"ElevenLabs API недоступен: {e}") from e

        if not mp3_bytes:
            raise VoiceGenerationError("ElevenLabs вернул пустой ответ.")

        ogg_bytes = await _mp3_to_ogg_opus(mp3_bytes)
        if ogg_bytes:
            return VoiceResult(audio_bytes=ogg_bytes, is_voice_note=True, ext=".ogg")
        # ffmpeg недоступен/упал — не теряем сообщение, просто это будет
        # обычный аудиофайл, а не "голосовое" (без круглого waveform-пузыря)
        logger.warning("mp3->ogg/opus conversion unavailable — sending as a plain audio file instead.")
        return VoiceResult(audio_bytes=mp3_bytes, is_voice_note=False, ext=".mp3")


async def _mp3_to_ogg_opus(mp3_bytes: bytes) -> Optional[bytes]:
    """ffmpeg mp3 -> ogg/opus (48kHz, mono, ~32kbps — стандартные параметры
    голосовых сообщений Telegram). Возвращает None, если ffmpeg не найден
    на сервере или конвертация не удалась — вызывающий код обрабатывает
    это как деградацию, а не фатальную ошибку."""
    if shutil.which("ffmpeg") is None:
        return None

    with tempfile.NamedTemporaryFile(suffix=".mp3") as src, tempfile.NamedTemporaryFile(suffix=".ogg") as dst:
        src.write(mp3_bytes)
        src.flush()
        proc = await asyncio.create_subprocess_exec(
            "ffmpeg", "-y", "-i", src.name,
            "-c:a", "libopus", "-b:a", "32k", "-ar", "48000", "-ac", "1",
            dst.name,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        try:
            await asyncio.wait_for(proc.wait(), timeout=30.0)
        except asyncio.TimeoutError:
            proc.kill()
            logger.warning("ffmpeg mp3->ogg conversion timed out")
            return None
        if proc.returncode != 0:
            logger.warning("ffmpeg mp3->ogg conversion failed, returncode=%s", proc.returncode)
            return None
        dst.seek(0)
        result = dst.read()
        return result or None


# ============================================================ OpenRouter
# Формат — по документации OpenRouter:
#   синтез:        POST {base}/audio/speech  → сырые байты mp3 (не JSON)
#   распознавание: POST {base}/audio/transcriptions, input_audio {data, format} → JSON {"text": ...}
# Голосовые Telegram — OGG/Opus, формат "ogg" распознавание принимает напрямую.

# Модели и голоса OpenRouter меняются (в логе 27.09: «Model
# openai/gpt-4o-mini-tts-2025-12-15 does not exist»). Поэтому: разумный
# дефолт + самостоятельный выбор из каталога /models?output_modalities=speech,
# если модели нет, + голос под семейство модели.
TTS_PREFERRED_MODELS = (
    "x-ai/grok-voice-tts-1.0",            # по выбору владельца: женский голос Eve
    "google/gemini-3.1-flash-tts-preview",
    "google/gemini-3.8-flash-lite-tts",
    "google/gemini-3.8-flash-tts",
)
_FEMALE_VOICES = ("eve", "ara", "Leda", "Zephyr", "Kore", "Aoede", "nova", "shimmer", "coral", "alloy")
_GROK_VOICES = {"eve", "ara", "rex", "sal", "leo"}   # Eve, Ara — женские
_OPENAI_VOICES = {"alloy", "ash", "ballad", "coral", "echo", "fable", "onyx", "nova", "sage", "shimmer", "verse"}


def _tts_family(model: str) -> str:
    m = (model or "").lower()
    return "google" if m.startswith("google/") else "openai" if m.startswith("openai/") else \
        "xai" if m.startswith("x-ai/") else "other"


def _voice_for(model: str, voice: str) -> str:
    """Голос, который подходит семейству модели (OpenAI-шный «nova» у Gemini — ошибка 400)."""
    fam = _tts_family(model)
    v = (voice or "").strip()
    if fam == "google":
        return v if v and v.lower() not in (_OPENAI_VOICES | _GROK_VOICES) else "Leda"
    if fam == "openai":
        return v if v.lower() in _OPENAI_VOICES else "nova"
    if fam == "xai":
        return v.lower() if v.lower() in _GROK_VOICES else "eve"
    return v


@dataclass
class OpenRouterVoiceConfig:
    api_key: str
    model: str = TTS_PREFERRED_MODELS[0]
    voice: str = "eve"
    instructions: str = ("Говори по-русски тепло, живо и естественно, как молодая девушка "
                         "в голосовом сообщении близкому человеку.")
    base_url: str = "https://openrouter.ai/api/v1"
    timeout: float = 60.0


class OpenRouterVoiceGenerator:
    def __init__(self, config: OpenRouterVoiceConfig):
        self.config = config
        self.model = config.model
        self.voice = _voice_for(config.model, config.voice)

    def _payload(self, model: str, voice: str, text: str, with_style: bool) -> dict:
        fam = _tts_family(model)
        body = {"model": model, "input": text[:3000],
                "response_format": "pcm" if fam == "google" else "mp3"}  # Gemini отдаёт сырой PCM
        if voice:
            body["voice"] = voice
        if with_style and self.config.instructions:
            if fam == "google":
                body["provider"] = {"options": {"google-ai-studio": {"speech_metadata": {
                    "style": "warm, lively and natural, like a young woman in a voice message"}}}}
            elif fam == "openai":
                body["provider"] = {"options": {"openai": {"instructions": self.config.instructions}}}
        return body

    def _post(self, body: dict) -> bytes:
        import requests
        resp = requests.post(f"{self.config.base_url.rstrip('/')}/audio/speech", json=body,
                             headers={"Authorization": f"Bearer {self.config.api_key}",
                                      "Content-Type": "application/json"},
                             timeout=self.config.timeout)
        _raise_with_body(resp)
        return resp.content

    def _discover(self) -> "tuple[str, str]":
        """Каталог голосовых моделей OpenRouter → (модель, голос)."""
        import requests
        resp = requests.get(f"{self.config.base_url.rstrip('/')}/models",
                            params={"output_modalities": "speech"},
                            headers={"Authorization": f"Bearer {self.config.api_key}"},
                            timeout=self.config.timeout)
        _raise_with_body(resp)
        models = {m.get("id"): m for m in ((resp.json() or {}).get("data") or []) if m.get("id")}
        if not models:
            return "", ""
        pick = next((m for m in TTS_PREFERRED_MODELS if m in models), None) or \
            next((m for m in models if _tts_family(m) == "google"), None) or \
            next((m for m in models if _tts_family(m) == "openai"), None) or next(iter(models))
        voices = [str(v) for v in (models[pick].get("supported_voices") or [])]
        voice = _voice_for(pick, self.voice)
        if voices and voice not in voices:
            voice = next((v for v in _FEMALE_VOICES if v in voices), voices[0])
        return pick, voice

    async def generate(self, text: str) -> VoiceResult:
        text = (text or "").strip()
        if not text:
            raise VoiceGenerationError("Нечего озвучивать — пустой текст.")
        import asyncio

        def _speak() -> "tuple[bytes, str]":
            try:
                return self._post(self._payload(self.model, self.voice, text, True)), self.model
            except _HTTPBodyError as e:
                body = (e.body or "").lower()
                if e.status in (400, 404) and ("does not exist" in body or "model not found" in body
                                               or "invalid model" in body or "no endpoints" in body):
                    model, voice = self._discover()
                    if not model:
                        raise
                    logger.warning("TTS model %s unavailable — switching to %s (voice %s)", self.model, model, voice)
                    self.model, self.voice = model, voice
                    return self._post(self._payload(model, voice, text, True)), model
                if e.status != 400:
                    raise
                # 400 по другой причине — чаще всего блок стиля; повтор без него
                logger.warning("OpenRouter TTS 400 (%s) — retrying without provider options", e.body)
                return self._post(self._payload(self.model, self.voice, text, False)), self.model

        try:
            audio, model = await asyncio.to_thread(_speak)
        except Exception as e:  # noqa: BLE001
            raise VoiceGenerationError(f"OpenRouter TTS недоступен: {e}") from e
        if not audio:
            raise VoiceGenerationError("OpenRouter TTS вернул пустой ответ.")
        if _tts_family(model) == "google":
            ogg = await _pcm_to_ogg_opus(audio)
            if ogg:
                return VoiceResult(audio_bytes=ogg, is_voice_note=True, ext=".ogg")
            return VoiceResult(audio_bytes=_pcm_to_wav(audio), is_voice_note=False, ext=".wav")
        ogg_bytes = await _mp3_to_ogg_opus(audio)
        if ogg_bytes:
            return VoiceResult(audio_bytes=ogg_bytes, is_voice_note=True, ext=".ogg")
        logger.warning("mp3->ogg/opus conversion unavailable (нет ffmpeg?) — sending as a plain audio file.")
        return VoiceResult(audio_bytes=audio, is_voice_note=False, ext=".mp3")


async def _pcm_to_ogg_opus(pcm: bytes, rate: int = 24000) -> Optional[bytes]:
    """Сырой PCM 16 бит моно (Gemini TTS, 24 кГц) → ogg/opus для круглого голосового."""
    if not shutil.which("ffmpeg"):
        return None
    proc = await asyncio.create_subprocess_exec(
        "ffmpeg", "-loglevel", "error", "-f", "s16le", "-ar", str(rate), "-ac", "1", "-i", "pipe:0",
        "-c:a", "libopus", "-b:a", "32k", "-f", "ogg", "pipe:1",
        stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
    out, _err = await proc.communicate(pcm)
    return out if proc.returncode == 0 and out else None


def _pcm_to_wav(pcm: bytes, rate: int = 24000) -> bytes:
    import io
    import wave
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(pcm)
    return buf.getvalue()


@dataclass
class OpenRouterTranscriberConfig:
    api_key: str
    model: str = "openai/whisper-large-v3"
    language: str = "ru"
    base_url: str = "https://openrouter.ai/api/v1"
    timeout: float = 60.0


class OpenRouterTranscriber:
    """Распознавание голосовых, аудио и звука из видео-«кружочков»."""

    def __init__(self, config: OpenRouterTranscriberConfig):
        self.config = config

    async def transcribe(self, audio: bytes, fmt: str = "ogg") -> str:
        if not audio:
            return ""
        import asyncio
        import base64
        import requests
        payload = {"model": self.config.model,
                   "input_audio": {"data": base64.b64encode(audio).decode("ascii"), "format": fmt}}
        if self.config.language:
            payload["language"] = self.config.language
        headers = {"Authorization": f"Bearer {self.config.api_key}", "Content-Type": "application/json"}

        def _do_request() -> dict:
            resp = requests.post(f"{self.config.base_url.rstrip('/')}/audio/transcriptions",
                                 json=payload, headers=headers, timeout=self.config.timeout)
            _raise_with_body(resp)
            return resp.json()

        data = await asyncio.to_thread(_do_request)
        return str((data or {}).get("text") or "").strip()


class DisabledTranscriber:
    async def transcribe(self, audio: bytes, fmt: str = "ogg") -> str:
        return ""



class _HTTPBodyError(RuntimeError):
    """HTTP-ошибка вместе с текстом ответа: OpenRouter пишет причину отказа в
    теле (например, неверный параметр). Раньше в логе было только «400 Bad
    Request», и понять причину было нельзя."""

    def __init__(self, status: int, body: str):
        super().__init__(f"HTTP {status}: {body}")
        self.status, self.body = status, body


def _raise_with_body(resp) -> None:
    status = int(getattr(resp, "status_code", 200) or 200)
    if status >= 400:
        body = ""
        try:
            body = str(getattr(resp, "text", "") or "")[:400]
        except Exception:
            body = ""
        raise _HTTPBodyError(status, body or "(пустой ответ)")
    resp.raise_for_status()


class FallbackVoiceGenerator:
    """Несколько поставщиков голоса по очереди: если первый не смог (сеть,
    400, нет ключа) — пробуем следующий. Так голосовые работают, даже когда
    один сервис отказывает."""

    def __init__(self, generators):
        self.generators = [g for g in generators if g is not None]
        self._auth_failed: set = set()

    async def generate(self, text: str) -> VoiceResult:
        errors = []
        for gen in self.generators:
            if id(gen) in self._auth_failed:
                continue
            try:
                return await gen.generate(text)
            except VoiceGenerationError as e:
                errors.append(f"{type(gen).__name__}: {e}")
                if any(x in str(e) for x in ("401", "403", "Unauthorized", "Forbidden")):
                    # неверный/отозванный ключ — до перезапуска не тратим на него время
                    self._auth_failed.add(id(gen))
                    logger.warning("voice provider %s: key rejected — disabled until restart: %s",
                                   type(gen).__name__, e)
                    continue
                logger.warning("voice provider %s failed, trying next: %s", type(gen).__name__, e)
        raise VoiceGenerationError("; ".join(errors) or "нет доступных поставщиков голоса")
