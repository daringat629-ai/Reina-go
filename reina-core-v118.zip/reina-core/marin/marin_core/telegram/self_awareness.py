"""Самосознание Марин в инженерном смысле: самонаблюдение + подстройка в рамках.

Интроспекция (SelfModel). Марин может «опросить себя» и получить живой
отчёт: цели и их реальный статус, настоящие итоги последних действий,
сколько её ответов пришлось исправлять фильтру и за что, метакогниция
(насколько уверена, сколько противоречий в убеждениях), потребности,
какая модель сейчас отвечает. Отчёт попадает в контекст ДО генерации,
когда её спрашивают о ней самой, — иначе она сочиняла («пост уже в канале,
всё ок», когда он не вышел; «пойду подбирать треки»).

Интерцессия (SelfTuning) — строго в рамках. Она может менять только
белый список собственных настроек поведения. Для каждой настройки заданы
границы и максимальный шаг за одно изменение; есть пауза между изменениями
и дневной лимит. Каждое изменение пишется в журнал, сообщается владельцу и
откатывается одной командой. Код, промпты, фильтр качества, подтверждения
действий и права ей недоступны — это не настройки поведения, а защита.

Значения применяются слоем переопределений (env.set_override) поверх .env:
сам файл не меняется, базовое значение владельца всегда видно.
"""
from __future__ import annotations

import json
import logging
import os
import re
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

from ..env import clear_override, env_bool, env_float, env_str, get_override, set_override

logger = logging.getLogger("marin_x.telegram.self")


# ============================================================ настройки
@dataclass(frozen=True)
class Knob:
    env: str
    title: str
    default: Any
    kind: str                      # "int" | "float" | "enum"
    lo: float = 0
    hi: float = 0
    max_step: float = 0
    choices: Tuple[str, ...] = ()
    aliases: Tuple[str, ...] = ()


KNOBS: Dict[str, Knob] = {
    "bubble_length": Knob(
        env="MARIN_TELEGRAM_BUBBLE_MAX_CHARS", title="длина одного сообщения (символов)",
        default=70, kind="int", lo=40, hi=120, max_step=20,
        aliases=("длина", "длина_сообщения", "bubble"),
    ),
    "sticker_frequency": Knob(
        env="MARIN_MEDIA_FREQUENCY", title="как часто стикеры",
        default="often", kind="enum", choices=("rare", "normal", "often"),
        aliases=("стикеры", "stickers"),
    ),
    "proactive_per_day": Knob(
        env="MARIN_PROACTIVE_MAX_PER_DAY", title="сколько раз в день писать первой",
        default=4, kind="int", lo=0, hi=6, max_step=2,
        aliases=("первой", "писать_первой", "proactive"),
    ),
    "proactive_silence_hours": Knob(
        env="MARIN_PROACTIVE_SILENCE_HOURS", title="через сколько часов тишины написать первой",
        default=5, kind="float", lo=2, hi=24, max_step=6,
        aliases=("тишина", "silence"),
    ),
}
_ENUM_RU = {"редко": "rare", "обычно": "normal", "нормально": "normal", "часто": "often"}
_ENUM_TITLE = {"rare": "редко", "normal": "обычно", "often": "часто"}


def resolve_knob(name: str) -> Optional[str]:
    key = (name or "").strip().lower().replace(" ", "_")
    if key in KNOBS:
        return key
    for k, knob in KNOBS.items():
        if key in knob.aliases:
            return k
    return None


def _fmt(knob: Knob, value: Any) -> str:
    if knob.kind == "enum":
        return _ENUM_TITLE.get(str(value), str(value))
    if knob.kind == "float":
        return f"{float(value):g}"
    return str(int(value))


class SelfTuning:
    """Белый список собственных настроек с границами, шагом, паузой,
    журналом и откатом. Состояние переживает рестарт (JSON-файл)."""

    def __init__(self, path: str):
        self.path = path
        self.enabled = env_bool("MARIN_SELF_TUNING_ENABLED", True)
        self.cooldown_seconds = env_float("MARIN_SELF_TUNING_COOLDOWN_HOURS", 2.0, minimum=0.0) * 3600
        self.max_per_day = int(env_float("MARIN_SELF_TUNING_MAX_PER_DAY", 6, minimum=0))
        self.values: Dict[str, Any] = {}     # только то, что Марин переопределила
        self.history: List[Dict[str, Any]] = []
        self._load()

    # ---------------------------------------------------------- persistence
    def _load(self) -> None:
        try:
            with open(self.path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
        except FileNotFoundError:
            return
        except Exception:
            logger.warning("[SELF] tuning file unreadable, starting clean", exc_info=True)
            return
        if isinstance(data, dict):
            self.values = {k: v for k, v in (data.get("values") or {}).items() if k in KNOBS}
            self.history = list(data.get("history") or [])[-100:]
            if "enabled" in data:
                self.enabled = bool(data["enabled"]) and self.enabled

    def _save(self) -> None:
        try:
            os.makedirs(os.path.dirname(os.path.abspath(self.path)) or ".", exist_ok=True)
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump({"values": self.values, "history": self.history[-100:], "enabled": self.enabled},
                          fh, ensure_ascii=False, indent=1)
            os.replace(tmp, self.path)
        except Exception:
            logger.warning("[SELF] could not save tuning", exc_info=True)

    def apply_all(self) -> None:
        """Применить сохранённые значения (при старте)."""
        for name, value in self.values.items():
            set_override(KNOBS[name].env, value)

    # --------------------------------------------------------------- values
    def baseline(self, name: str) -> Any:
        """Значение из .env/окружения без её переопределения."""
        knob = KNOBS[name]
        saved = get_override(knob.env)
        clear_override(knob.env)
        try:
            if knob.kind == "enum":
                return env_str(knob.env, knob.default).lower() or knob.default
            return self._num(knob, env_float(knob.env, float(knob.default)))
        finally:
            if saved is not None:
                set_override(knob.env, saved)

    def current(self, name: str) -> Any:
        return self.values.get(name, self.baseline(name))

    @staticmethod
    def _num(knob: Knob, value: float) -> Any:
        return int(round(value)) if knob.kind == "int" else round(float(value), 2)

    def _parse(self, knob: Knob, raw: str, current: Any, limit_step: bool = True) -> Tuple[Optional[Any], str]:
        raw = (raw or "").strip().lower()
        if knob.kind == "enum":
            value = _ENUM_RU.get(raw, raw)
            if value not in knob.choices:
                return None, f"можно только: {', '.join(_ENUM_TITLE[c] for c in knob.choices)}"
            order = list(knob.choices)
            if limit_step and str(current) in order and abs(order.index(value) - order.index(str(current))) > 1:
                # на одну ступень за раз: «часто» → «обычно» → «редко»
                value = order[order.index(str(current)) + (1 if order.index(value) > order.index(str(current)) else -1)]
            return value, ""
        m = re.fullmatch(r"([+-]?)\s*(\d+(?:[.,]\d+)?)", raw)
        if not m:
            return None, "нужно число"
        num = float(m.group(2).replace(",", "."))
        target = float(current) + num if m.group(1) == "+" else float(current) - num if m.group(1) == "-" else num
        target = max(knob.lo, min(knob.hi, target))
        step = target - float(current)
        if limit_step and abs(step) > knob.max_step:
            target = float(current) + (knob.max_step if step > 0 else -knob.max_step)
        return self._num(knob, target), ""

    # --------------------------------------------------------------- change
    def propose(self, name: str, raw_value: str, reason: str = "", by: str = "self") -> Tuple[bool, str]:
        """Изменить настройку. by="self" — сама Марин (с ограничениями),
        by="owner" — команда владельца (без паузы и дневного лимита, но в
        тех же границах)."""
        key = resolve_knob(name)
        if key is None:
            return False, f"такой настройки у меня нет: «{name}»"
        knob = KNOBS[key]
        now = time.time()
        if by == "self":
            if not self.enabled:
                return False, "самонастройка выключена владельцем"
            last = next((h for h in reversed(self.history) if h["knob"] == key and h.get("by") == "self"), None)
            if last and now - last["ts"] < self.cooldown_seconds:
                mins = int((self.cooldown_seconds - (now - last["ts"])) // 60) + 1
                return False, f"«{knob.title}» недавно меняла — снова можно через {mins} мин"
            today = [h for h in self.history if h.get("by") == "self" and now - h["ts"] < 86400]
            if len(today) >= self.max_per_day:
                return False, "на сегодня хватит самонастроек"
        current = self.current(key)
        value, err = self._parse(knob, str(raw_value), current, limit_step=(by == "self"))
        if value is None:
            return False, f"«{knob.title}»: {err}"
        if str(value) == str(current):
            return False, f"«{knob.title}» и так {_fmt(knob, current)}"
        self.values[key] = value
        set_override(knob.env, value)
        self.history.append({"ts": now, "knob": key, "old": current, "new": value,
                             "reason": (reason or "")[:200], "by": by})
        self._save()
        logger.info("[SELF] tuned %s: %r -> %r by=%s reason=%r", key, current, value, by, reason)
        return True, f"{knob.title}: {_fmt(knob, current)} → {_fmt(knob, value)}"

    def undo_last(self) -> str:
        if not self.history:
            return "Откатывать нечего — я себя ещё не подстраивала."
        last = self.history.pop()
        key, knob = last["knob"], KNOBS[last["knob"]]
        if str(last["old"]) == str(self.baseline(key)):
            self.values.pop(key, None)
            clear_override(knob.env)
        else:
            self.values[key] = last["old"]
            set_override(knob.env, last["old"])
        self._save()
        return f"Откатила: {knob.title} снова {_fmt(knob, last['old'])}."

    def reset(self) -> str:
        for key in list(self.values):
            clear_override(KNOBS[key].env)
        self.values.clear()
        self.history.clear()  # после сброса откатывать нечего
        self._save()
        return "Сбросила все свои подстройки — всё как в .env."

    def set_enabled(self, on: bool) -> str:
        self.enabled = on
        self._save()
        return "Самонастройка включена." if on else "Самонастройка выключена — сама себя больше не меняю."

    # ------------------------------------------------------------ rendering
    def status_lines(self) -> List[str]:
        lines = []
        for key, knob in KNOBS.items():
            cur, base = self.current(key), self.baseline(key)
            mark = "" if key not in self.values else f" (в .env: {_fmt(knob, base)})"
            bounds = ("/".join(_ENUM_TITLE[c] for c in knob.choices) if knob.kind == "enum"
                      else f"{knob.lo:g}–{knob.hi:g}, шаг ≤{knob.max_step:g}")
            lines.append(f"- {key}: {_fmt(knob, cur)}{mark} — {knob.title} [{bounds}]")
        return lines

    def history_lines(self, n: int = 5) -> List[str]:
        out = []
        for h in self.history[-n:]:
            knob = KNOBS.get(h["knob"])
            if knob is None:
                continue
            who = "сама" if h.get("by") == "self" else "ты"
            when = time.strftime("%d.%m %H:%M", time.localtime(h["ts"]))
            why = f" — {h['reason']}" if h.get("reason") else ""
            out.append(f"- {when} ({who}) {knob.title}: {_fmt(knob, h['old'])} → {_fmt(knob, h['new'])}{why}")
        return out


# ========================================================= самонаблюдение
CAPABILITY_QUESTION_RE = re.compile(
    r"\b(?:какие|какую|чего)\b.{0,30}\b(?:функци\w*|возможност\w*|умеешь|не\s+хватает)"
    r"|\bчто\s+(?:ты\s+)?умеешь\b|\bчто\s+добавить\b|\bфункци\w*\s+добав\w*",
    re.IGNORECASE | re.DOTALL,
)
SELF_QUESTION_RE = re.compile(
    r"как ты\b|что с тобой|как себя чувству|как самочувств|ты в порядке|что делаешь|чем занят|"
    r"что сейчас делаешь|получилось|вышло\??|сделала|выложила|опубликовала|обновила|"
    r"что у тебя|твои цели|твоё состояние|твое состояние|самонаблюден|о себе|"
    r"ты помнишь|ты уверена|почему ты так|что с постом|где пост|как там|"
    r"во что (?:ты )?одета|что на тебе|что надела|как ты выглядишь|где ты сейчас|покажи себя",
    re.IGNORECASE,
)
TUNING_HINT_RE = re.compile(
    r"короче|длиннее|покороче|подлиннее|стикер|пиши (?:мне )?(?:реже|чаще|первой)|"
    r"не пиши первой|реже пиши|чаще пиши|меньше пиши|настрой|подстрой",
    re.IGNORECASE,
)
TUNE_MARKER_RE = re.compile(r"<<<\s*TUNE\s*:\s*([^|<>]+?)\s*\|\s*([^|<>]*?)\s*(?:\|\s*([^<>]*?))?\s*>>>",
                            re.IGNORECASE | re.DOTALL)


class SelfModel:
    """Живой отчёт о себе из реальных подсистем, без выдумок."""

    def __init__(self, telegram_client: Any):
        self._tc = telegram_client
        self.started_at = time.time()

    # ---------------------------------------------------------- sections
    def _goals(self) -> List[str]:
        tc = self._tc
        owner = str(getattr(tc.config, "owner_id", "") or "")
        try:
            goals = tc.engine.goal_set.autonomous_goals(owner_id=owner)
        except Exception:
            return []
        lines = []
        for g in sorted(goals, key=lambda g: getattr(g, "updated_at", 0) or 0, reverse=True)[:5]:
            status = getattr(getattr(g, "status", None), "value", str(getattr(g, "status", "")))
            human = {"pending": "ещё не начала", "planning": "планирую", "running": "делаю",
                     "waiting": "жду твоего «да»", "paused": "на паузе", "completed": "сделано",
                     "failed": "не вышло", "cancelled": "отменена"}.get(status, status)
            mine = " (моя идея)" if (getattr(g, "context", {}) or {}).get("self_initiated") else ""
            last = (getattr(g, "last_result", "") or "").strip()
            tail = f"; последний итог: {last[:90]}" if last else ""
            lines.append(f"- «{g.description[:70]}»{mine}: {human}{tail}")
        return lines

    def _quality(self) -> List[str]:
        provider = getattr(getattr(self._tc.engine, "language_planner", None), "provider", None)
        stats = getattr(provider, "stats", None)
        lines = []
        if stats and stats.get("generations"):
            g = stats["generations"]
            fixed = stats["retried"]
            reasons = ", ".join(f"{_REASON_RU.get(r, r)} ×{n}" for r, n in stats["reasons"].most_common(3))
            lines.append(f"- ответов за сессию: {g}; пришлось переписывать: {fixed}"
                         + (f" ({reasons})" if reasons else "")
                         + (f"; не удалось ни разу: {stats['failed']}" if stats.get("failed") else ""))
        used = getattr(provider, "last_used", None)
        if used:
            lines.append(f"- последний ответ писала модель: {used}")
        return lines

    def _mind(self) -> List[str]:
        engine = self._tc.engine
        lines = []
        history = list(getattr(engine, "meta_history", []) or [])[-10:]
        if history:
            conf = sum(float(getattr(m, "decision_confidence", 0) or 0) for m in history) / len(history)
            know = sum(float(getattr(m, "knowledge", 0) or 0) for m in history) / len(history)
            lines.append(f"- уверенность в решениях (последние {len(history)}): {conf:.0%}; "
                         f"насколько знаю тему: {know:.0%}")
        last = getattr(engine, "last_result", None)
        if last is not None and getattr(last, "prediction_error", None) is not None:
            lines.append(f"- ошибка предсказания на последнем ходе: {float(last.prediction_error):.2f}")
        try:
            open_c = engine.beliefs.open_contradictions()
            if open_c:
                lines.append(f"- неразрешённых противоречий в том, во что верю: {len(open_c)}")
        except Exception:
            logger.debug("[SELF] contradictions unavailable", exc_info=True)
        try:
            refl = engine.beliefs.find_by_key("latest_self_reflection")
            if refl:
                lines.append(f"- последняя саморефлексия: {refl[1].statement[:140]}")
        except Exception:
            logger.debug("[SELF] self-reflection unavailable", exc_info=True)
        needs = getattr(getattr(engine, "state", None), "needs", None) or getattr(engine, "needs", None)
        values = getattr(needs, "values", None)
        if isinstance(values, dict) and values:
            top = sorted(values.items(), key=lambda kv: kv[1], reverse=True)[:2]
            lines.append("- сильнее всего сейчас хочется: " + ", ".join(
                f"{getattr(k, 'value', k)} ({v:.0%})" for k, v in top))
        return lines

    # ------------------------------------------------------------ public
    def report(self, *, full: bool = True) -> str:
        tc = self._tc
        up_h = (time.time() - self.started_at) / 3600
        parts = [f"Работаю без перерыва {up_h:.1f} ч."]
        goals = self._goals()
        parts.append("Мои цели:\n" + ("\n".join(goals) if goals else "- активных целей нет"))
        director = getattr(tc, "selfie_director", None)
        outfit = director.today_outfit() if director is not None else ""
        if outfit:
            parts.append(f"Сегодня на мне (как на моих селфи): {outfit}. Последний кадр: {director.last_scene()[:160]}")
        outcomes = list(getattr(tc, "_action_outcomes", []) or [])
        parts.append("Что реально получилось/не получилось:\n"
                     + ("\n".join(f"- {x}" for x in outcomes[-6:]) if outcomes else "- действий пока не было"))
        quality = self._quality()
        if quality:
            parts.append("Как я пишу:\n" + "\n".join(quality))
        mind = self._mind()
        if mind and full:
            parts.append("Внутри:\n" + "\n".join(mind))
        tuning = getattr(tc, "self_tuning", None)
        if tuning is not None:
            parts.append("Мои настройки" + ("" if tuning.enabled else " (самонастройка выключена)") + ":\n"
                         + "\n".join(tuning.status_lines()))
            hist = tuning.history_lines(3)
            if hist and full:
                parts.append("Недавно меняла:\n" + "\n".join(hist))
        return "\n\n".join(parts)

    def _capabilities_block(self) -> str:
        from ..env import env_float, env_str
        voice_on = env_str("MARIN_VOICE_ENABLED", "true").lower() in {"1", "true", "yes", "on"}
        selfie_on = env_str("MARIN_SELFIE_ENABLED", "true").lower() in {"1", "true", "yes", "on"}
        pro_on = env_str("MARIN_PROACTIVE_ENABLED", "true").lower() in {"1", "true", "yes", "on"}
        chance = int(env_float("MARIN_VOICE_REPLY_CHANCE", 0.5, minimum=0.0, maximum=1.0) * 100)
        lines = [
            "Голосовые: " + (f"УМЕЕШЬ — иногда отвечаешь голосом (примерно в {chance}% ответов)" if voice_on else "выключены в настройках"),
            "Селфи: " + ("УМЕЕШЬ — можешь прислать своё фото/селфи по просьбе или сама" if selfie_on else "выключены"),
            "Писать первой: " + ("УМЕЕШЬ — утро, ночь, если давно молчит" if pro_on else "выключено"),
            "Напоминания: УМЕЕШЬ — «напомни через 2 часа / завтра в 10 …» — и ты сама напишешь в срок",
            "Память: помнишь разговоры и факты о нём между перезапусками; давно не нужное блёкнет, важное остаётся",
            "Канал: сама пишешь и публикуешь посты, ведёшь автопостинг; понимаешь стикеры, эмодзи-паки, фото",
        ]
        return ("[Что ты УЖЕ умеешь — правда о тебе. Не проси «добавить» то, что здесь есть, и не говори, что этого не "
                "умеешь; если хочешь улучшений, называй только то, чего тут нет]\n- " + "\n- ".join(lines) + "\n")

    def prompt_hint(self, owner_text: str) -> str:
        """Блок для контекста модели: отчёт о себе — только когда вопрос о
        ней; правила самонастройки — только когда речь о её манере."""
        blocks = []
        if SELF_QUESTION_RE.search(owner_text or ""):
            blocks.append("[Самонаблюдение — это ПРАВДА о тебе прямо сейчас. Отвечая о себе, своих делах "
                          "и результатах, опирайся только на это; чего здесь нет — не утверждай]\n"
                          + self.report(full=False) + "\n")
        if CAPABILITY_QUESTION_RE.search(owner_text or ""):
            blocks.append(self._capabilities_block())
        tuning = getattr(self._tc, "self_tuning", None)
        if tuning is not None and tuning.enabled and TUNING_HINT_RE.search(owner_text or ""):
            blocks.append(
                "[Самонастройка — ты можешь сама поменять свою манеру, если он об этом просит или ты "
                "видишь, что так лучше. Формат (на отдельной строке, владелец его не увидит): "
                "<<<TUNE:имя|значение|причина>>>; значение — число, +N/-N или редко/обычно/часто. "
                "Меняется в пределах границ и не больше шага за раз. Доступно только это:\n"
                + "\n".join(tuning.status_lines()) + "]\n"
            )
        return "".join(blocks)


_REASON_RU = {
    "meta_narration": "рассуждала вместо ответа", "repetition": "зацикливалась",
    "foreign_script": "ушла в английский", "masculine_self": "о себе в мужском роде",
    "mixed_language": "английские вставки", "garbled_text": "испорченные слова",
    "self_address": "говорила сама с собой",
    "no_output": "модель не ответила",
}


def extract_tune_markers(text: str, tuning: Optional[SelfTuning]) -> Tuple[str, List[str]]:
    """Вырезает <<<TUNE:...>>> из ответа и применяет их. Возвращает
    (текст без маркеров, человеческие итоги для владельца)."""
    if not text or "TUNE" not in text.upper():
        return text, []
    notices: List[str] = []
    for m in TUNE_MARKER_RE.finditer(text):
        if tuning is None:
            continue
        ok, msg = tuning.propose(m.group(1), m.group(2), reason=(m.group(3) or "").strip(), by="self")
        notices.append(("подстроила себя — " if ok else "не стала менять себя: ") + msg)
    return TUNE_MARKER_RE.sub("", text).strip(), notices


def default_tuning_path() -> str:
    explicit = os.getenv("MARIN_SELF_TUNING_FILE")
    if explicit:
        return explicit
    state = os.getenv("MARIN_STATE_FILE")
    base = os.path.dirname(os.path.abspath(state)) if state else os.getcwd()
    return os.path.join(base, "marin_self_tuning.json")
