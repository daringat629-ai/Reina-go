"""Marin learns from how her channel actually reacts to posts.

Before this, ``ChannelPublisher`` fed the model only the last few post TEXTS
(for style + duplicate avoidance) — it never looked at whether anyone
actually read or reacted to them. A post that fell completely flat and one
that got heavy engagement looked identical to the writer.

``refresh_metrics`` periodically re-fetches ``views``/``reactions`` for
recent posts (Telegram views keep climbing for a while, so a post is
re-checked a few times over its first days, then left alone). ``insights()``
turns the scored history into a short, human-readable note that
``ChannelPublisher`` adds to the writing prompt: what resonated, what fell
flat — steering future posts without hard rules.

Score: reactions matter far more than passive views (a view is nearly free;
a reaction is a deliberate action), combined per-post relative to the
channel's own recent average — a channel with 5 regular readers and one with
50k need entirely different absolute numbers to call a post "a hit".
"""
from __future__ import annotations

import logging
import re
import time
from typing import Any, Dict, List, Optional

logger = logging.getLogger("marin_x.telegram.engagement")

# Сколько раз перепроверять метрики одного поста, пока не сочтём их "устоявшимися".
_RECHECK_WINDOWS_HOURS = (1, 6, 24, 72)
_RECHECK_TOLERANCE_SECONDS = 20 * 60  # окно ловится с запасом, чтобы не пропустить при редких пульсах


def _reaction_total(msg: Any) -> int:
    reactions = getattr(msg, "reactions", None)
    results = getattr(reactions, "results", None) or []
    return sum(int(getattr(r, "count", 0) or 0) for r in results)


def _reaction_breakdown(msg: Any, limit: int = 5) -> Dict[str, int]:
    reactions = getattr(msg, "reactions", None)
    results = getattr(reactions, "results", None) or []
    out: Dict[str, int] = {}
    for r in results[:limit]:
        emoji = getattr(getattr(r, "reaction", None), "emoticon", None) or "❤"
        out[str(emoji)] = int(getattr(r, "count", 0) or 0)
    return out


def _due_recheck(item: Dict[str, Any], now: float) -> bool:
    posted_at = float(item.get("at") or 0)
    if not posted_at:
        return False
    age_h = (now - posted_at) / 3600.0
    checked = int(item.get("metrics_checks") or 0)
    if checked >= len(_RECHECK_WINDOWS_HOURS):
        return False
    target_h = _RECHECK_WINDOWS_HOURS[checked]
    return age_h * 3600 >= target_h * 3600 - _RECHECK_TOLERANCE_SECONDS


async def refresh_metrics(tc: Any, entry: Dict[str, Any], *, force: bool = False) -> int:
    """Дотягивает views/reactions для постов, у которых пора (или для всех,
    если force=True — например, сразу после ручной проверки). Возвращает
    число реально обновлённых записей."""
    history: List[Dict[str, Any]] = list(entry.get("post_history") or [])
    if not history:
        return 0
    now = time.time()
    due = [(i, h) for i, h in enumerate(history) if h.get("id") and (force or _due_recheck(h, now))]
    if not due:
        return 0
    try:
        entity = await tc.client.get_entity(int(entry["id"]) if str(entry["id"]).lstrip("-").isdigit() else entry["id"])
        msgs = await tc.client.get_messages(entity, ids=[h["id"] for _, h in due])
    except Exception:
        logger.warning("[ENGAGEMENT] could not fetch messages for channel=%s", entry.get("id"), exc_info=True)
        return 0

    updated = 0
    for (idx, item), msg in zip(due, msgs):
        if msg is None:
            item["deleted"] = True  # удалён вручную/владельцем — не участвует в статистике
            updated += 1
            continue
        views = getattr(msg, "views", None)
        if views is not None:
            item["views"] = int(views)
        item["reactions_total"] = _reaction_total(msg)
        item["reactions"] = _reaction_breakdown(msg)
        item["metrics_checks"] = int(item.get("metrics_checks") or 0) + 1
        item["metrics_checked_at"] = now
        updated += 1
    entry["post_history"] = history
    if updated:
        tc._save_own_channels_registry()
        logger.info("[ENGAGEMENT] refreshed %d/%d posts for channel=%s", updated, len(due), entry.get("id"))
    return updated


def score(item: Dict[str, Any], baseline_views: float, baseline_reactions: float) -> Optional[float]:
    """Насколько пост показал себя лучше/хуже обычного для этого канала.
    None — метрик ещё нет (рано или пост без просмотров вообще)."""
    if item.get("deleted") or "reactions_total" not in item:
        return None
    views = float(item.get("views") or 0)
    reactions = float(item.get("reactions_total") or 0)
    # per-view reaction rate — то, что реально сравнимо между постами с очень
    # разным охватом (просмотры растут со временем не одинаково для всех).
    rate = reactions / max(views, 1.0)
    base_rate = baseline_reactions / max(baseline_views, 1.0) if baseline_views else 0.0
    view_component = (views / baseline_views - 1.0) if baseline_views else 0.0
    rate_component = (rate / base_rate - 1.0) if base_rate > 0 else (1.0 if reactions > 0 else 0.0)
    # реакции решают куда больше, чем сырой охват: 0.25 просмотрам, 0.75 реакциям
    return round(0.25 * view_component + 0.75 * rate_component, 3)


def _baseline(history: List[Dict[str, Any]]) -> tuple:
    scored = [h for h in history if not h.get("deleted") and "reactions_total" in h]
    if not scored:
        return 0.0, 0.0
    views = [float(h.get("views") or 0) for h in scored]
    reactions = [float(h.get("reactions_total") or 0) for h in scored]
    return (sum(views) / len(views)) or 1.0, sum(reactions) / len(reactions)


def _short(text: str, n: int = 70) -> str:
    text = re.sub(r"\s+", " ", (text or "").strip())
    return text if len(text) <= n else text[: n - 1].rsplit(" ", 1)[0] + "…"


def ranked(entry: Dict[str, Any]) -> List[Dict[str, Any]]:
    """История постов с посчитанным score, отсортированная по убыванию."""
    history = list(entry.get("post_history") or [])
    base_views, base_reactions = _baseline(history)
    out = []
    for h in history:
        s = score(h, base_views, base_reactions)
        if s is not None:
            out.append({**h, "score": s})
    out.sort(key=lambda h: h["score"], reverse=True)
    return out


def insights(entry: Dict[str, Any], *, top_n: int = 3, min_samples: int = 4) -> str:
    """Короткая заметка для промпта: что заходит, что нет. Пусто, если данных
    ещё мало — рано делать выводы по 1–2 постам."""
    scored = ranked(entry)
    if len(scored) < min_samples:
        return ""
    hits = [h for h in scored[:top_n] if h["score"] > 0.15]
    misses = [h for h in scored[-top_n:] if h["score"] < -0.15]
    if not hits and not misses:
        return ""
    lines = ["Что реально заходит подписчикам (по просмотрам/реакциям твоих прошлых постов, не выдумка):"]
    if hits:
        lines.append("Хорошо зашло — держись такого духа, но не копируй дословно:")
        for h in hits:
            lines.append(f"- «{_short(h.get('brief') or h.get('text', ''))}» (реакции/просмотры выше обычного)")
    if misses:
        lines.append("Не зашло / прошло незамеченным — таким форматом/темой лучше не злоупотреблять:")
        for h in misses:
            lines.append(f"- «{_short(h.get('brief') or h.get('text', ''))}»")
    lines.append("Учитывай это как один из ориентиров, а не жёсткое правило — ты не подстраиваешься под "
                 "лайки любой ценой, а просто чуть чаще делаешь то, что людям реально интересно.")
    return "\n".join(lines)


class EngagementMixin:
    """Подмешивается в ChannelPublisher: добавляет обновление метрик и
    инсайты в контекст генерации, не трогая остальную логику публикации."""

    async def refresh_engagement(self, entry: Dict[str, Any], *, force: bool = False) -> int:
        return await refresh_metrics(self._tc, entry, force=force)

    def engagement_insights(self, entry: Dict[str, Any]) -> str:
        try:
            return insights(entry)
        except Exception:
            logger.debug("[ENGAGEMENT] insights failed", exc_info=True)
            return ""

    async def refresh_all_channels(self) -> int:
        total = 0
        for entry in list(self._channels.values()):
            try:
                total += await self.refresh_engagement(entry)
            except Exception:
                logger.warning("[ENGAGEMENT] refresh failed for channel=%s", entry.get("id"), exc_info=True)
        return total
