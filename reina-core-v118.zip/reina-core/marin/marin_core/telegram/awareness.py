"""Telegram world awareness: catch-up, dialogs summary, world hint.

Mixin of MarinTelegramClient — relies on attributes created in
MarinTelegramClient.__init__ (self.client, self.engine, self.config, ...).
"""
from __future__ import annotations

import logging
import time
from typing import Dict

from .settings import (
    DIALOGS_REFRESH_INTERVAL_SECONDS,
)

logger = logging.getLogger("marin_x.telegram")

class AwarenessMixin:
    async def _catch_up_missed_messages(self, max_dialogs: int = 30, max_per_chat: int = 30) -> None:
        """При простое (бот был выключен) Telethon ничего не видел — эти
        сообщения просто терялись из наблюдателя навсегда. Теперь при
        каждом старте реально запрашивает у Telegram историю по каждому
        диалогу с непрочитанными (не только счётчик, как в
        _refresh_dialogs_summary, а сами сообщения) и добавляет их в
        observer с их настоящим временем — так пропуски в простое
        реально закрываются, а не остаются дырой в памяти.

        Дедупликация — через last_msg_id в реестре чатов observer'а
        (min_id у Telethon), поэтому повторный старт не переспрашивает
        то, что уже было один раз обработано."""
        try:
            dialogs = await self.client.get_dialogs(limit=500)
        except Exception:
            logger.debug("Could not fetch dialogs for catch-up", exc_info=True)
            return

        candidates = [d for d in dialogs if int(getattr(d, "unread_count", 0) or 0) > 0][:max_dialogs]
        if not candidates:
            return

        owner_id_str = str(self.config.owner_id) if self.config.owner_id else None
        digest: Dict[str, int] = {}
        total_new = 0
        owner_dialog = None
        owner_missed_messages: list = []  # хронологически, старые -> новые (см. .reverse() ниже)
        for dialog in candidates:
            chat_id = str(dialog.id)
            chat_title = getattr(dialog, "title", None) or "Telegram"
            is_owner_dm = owner_id_str is not None and chat_id == owner_id_str
            last_known_id = int(self.observer.chats.get(chat_id, {}).get("last_msg_id", 0) or 0)
            fetch_limit = min(int(dialog.unread_count or 0), max_per_chat)
            max_seen_id = last_known_id
            new_in_chat = 0
            chat_missed: list = []
            try:
                async for msg in self.client.iter_messages(dialog.entity, min_id=last_known_id, limit=fetch_limit):
                    if getattr(msg, "out", False):
                        continue  # исходящие не "пропущены" — это мы сами отправили
                    sender = getattr(msg, "sender", None)
                    sender_id = str(getattr(msg, "sender_id", None) or getattr(sender, "id", "unknown"))
                    sender_name = (getattr(sender, "first_name", "") or "") if sender else ""
                    username = (getattr(sender, "username", "") or "") if sender else ""
                    self.observer.record(
                        chat_id=chat_id, chat_title=chat_title, sender_id=sender_id,
                        sender_name=sender_name or "Неизвестный", username=username,
                        text=msg.text or "", outgoing=False, media=bool(msg.media),
                        ts=msg.date.timestamp() if msg.date else None,
                    )
                    max_seen_id = max(max_seen_id, msg.id)
                    new_in_chat += 1
                    if is_owner_dm:
                        chat_missed.append(msg)
            except Exception:
                logger.debug("Could not catch up chat %s", chat_id, exc_info=True)
                continue
            if new_in_chat:
                self.observer.chats.setdefault(chat_id, {"title": chat_title, "first_seen": time.time()})
                self.observer.chats[chat_id]["last_msg_id"] = max_seen_id
                if is_owner_dm:
                    # Владельцу — не строчка в сводке, а реальный ответ ниже
                    # (см. owner_missed_messages), чтобы не получалось глупо:
                    # "пропустила твои 3 сообщения" рядом с настоящим ответом
                    # на эти же 3 сообщения.
                    owner_dialog = dialog
                    owner_missed_messages = chat_missed  # iter_messages отдаёт новые->старые
                else:
                    digest[chat_title] = digest.get(chat_title, 0) + new_in_chat
                    total_new += new_in_chat

        if owner_missed_messages:
            self.observer._save()
            owner_missed_messages.reverse()  # в хронологический порядок (старые -> новые)
            logger.info(
                "Catch-up: replying for real to %d missed owner message(s) instead of a digest",
                len(owner_missed_messages),
            )
            try:
                await self._process_batch(owner_missed_messages, owner_dialog.entity, owner_id_str, owner_id_str)
            except Exception:
                logger.exception("Catch-up: real reply to missed owner messages failed")

        if not total_new:
            return
        self.observer._save()
        summary_lines = [f"- «{title}»: {count} сообщ." for title, count in sorted(digest.items(), key=lambda kv: -kv[1])[:15]]
        summary = f"Пока была офлайн, пропустила {total_new} сообщ. в {len(digest)} чатах:\n" + "\n".join(summary_lines)
        logger.info("Catch-up complete: %s", summary.replace("\n", " | "))
        self.engine.remember_fact("last_catchup_digest", summary, confidence=1.0)
        if self.config.owner_id:
            try:
                await self.client.send_message(self.config.owner_id, f"Кстати. {summary}")
            except Exception:
                logger.debug("Could not send catch-up digest to owner", exc_info=True)

    async def _refresh_dialogs_summary(self) -> None:
        """Обновляет сводку по РЕАЛЬНОМУ списку диалогов аккаунта (все чаты/
        группы/каналы, в которых он состоит), а не только тех, где Марин
        что-то наблюдала. Дёргается не на каждый тик — см.
        DIALOGS_REFRESH_INTERVAL_SECONDS — чтобы не перегружать Telegram API.
        """
        try:
            dialogs = await self.client.get_dialogs(limit=500)
        except Exception:
            logger.debug("Could not refresh Telegram dialogs summary", exc_info=True)
            return
        users = groups = channels = 0
        unread_total = 0
        admin_chats = []  # (title, is_creator) — считается из уже загруженных entity, без доп. запросов к API
        for d in dialogs:
            entity = getattr(d, "entity", None)
            unread_total += int(getattr(d, "unread_count", 0) or 0)
            is_channel_like = bool(getattr(entity, "broadcast", False) or getattr(entity, "megagroup", False))
            if getattr(entity, "broadcast", False):
                channels += 1
            elif is_channel_like or type(entity).__name__ in {"Chat", "ChatForbidden"}:
                groups += 1
            else:
                users += 1
            if is_channel_like:
                is_creator = bool(getattr(entity, "creator", False))
                has_admin_rights = getattr(entity, "admin_rights", None) is not None
                if is_creator or has_admin_rights:
                    admin_chats.append((d.name or getattr(entity, "title", "") or str(d.id), is_creator))
        self._admin_chats_summary = (
            "Марин администратор/создатель в: " + "; ".join(
                f"«{title}»{' (создатель)' if is_creator else ''}" for title, is_creator in admin_chats
            ) + "."
        ) if admin_chats else "Марин пока не админ ни в одном известном чате."
        self._dialogs_summary = (
            f"Реальный список диалогов аккаунта: всего={len(dialogs)} "
            f"(личных={users}, групп={groups}, каналов={channels}), "
            f"непрочитанных сообщений в сумме={unread_total}."
        )
        self._dialogs_refreshed_at = time.monotonic()
        self.engine.remember_fact("telegram_dialogs_summary", self._dialogs_summary, confidence=0.95)
        logger.info("Telegram dialogs summary refreshed: %s", self._dialogs_summary)

    async def _maybe_refresh_dialogs_summary(self) -> None:
        if time.monotonic() - self._dialogs_refreshed_at >= DIALOGS_REFRESH_INTERVAL_SECONDS:
            await self._refresh_dialogs_summary()

    def _telegram_world_hint(self) -> str:
        """Честная сводка о том, что Марин реально знает/имеет в Telegram —
        чтобы она не выдумывала цифры, а либо знала точный ответ, либо
        явно говорила, что не уверена/давно не проверяла."""
        pack_count = len(self._media_packs)
        parts = [
            self._own_identity_summary,
            self._own_channels_hint(),
            self._admin_chats_summary,
            self._dialogs_summary or "Реальный список диалогов ещё не подгружался в этой сессии.",
            self.observer.world_stats(),
            f"Каталог медиа: стикеров={len(self._sticker_catalog)}, "
            f"custom emoji={len(self._custom_emoji_catalog)}, добавленных паков={pack_count}.",
            "[Известные группы/чаты]\n" + self.observer.known_chats_summary(limit=50),
            "[Известные люди]\n" + self.observer.person_summary(limit=25),
        ]
        return "[Что Марин реально знает о своём Telegram]\n" + "\n".join(parts)
