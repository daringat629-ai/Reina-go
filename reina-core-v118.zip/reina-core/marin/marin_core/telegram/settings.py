"""Telegram transport settings: env-derived constants, regexes, command sets.

Extracted verbatim from the former monolithic client.py so every mixin can
import exactly what it needs instead of living in one 3.5k-line file.
"""
from __future__ import annotations

import logging
import os
import re
import time
from dataclasses import dataclass
from typing import Optional

from ..env import env_bool, env_float, env_int

logger = logging.getLogger("marin_x.telegram")


# Если собеседник пишет несколько сообщений подряд (как в обычной переписке —
# "погоди", "так вот", "короче в общем...") — ждём это время тишины ПОСЛЕ
# последнего сообщения, прежде чем обрабатывать пачку одним тиком, а не
# реагировать на каждое сообщение отдельно.
DEBOUNCE_SECONDS = env_float("MARIN_TELEGRAM_DEBOUNCE_SECONDS", 2.5)

# Этап 2: отдельный маркер для read-only действий (см. _process_readonly_markers).
# Формат намеренно такой же, как у ACTION_MARKER_RE в actions.py, но это
# независимый механизм — read-only ничего не меняет, поэтому ему не нужен
# pending/confirm.
READONLY_MARKER_RE = re.compile(r"<<<READ:(\w+)\|(.*?)>>>", re.IGNORECASE | re.DOTALL)

# Человеческая задержка перед отметкой сообщения как прочитанного.
READ_DELAY_SECONDS = env_float("MARIN_TELEGRAM_READ_DELAY_SECONDS", 1.5)

# Минимальная задержка перед первым ответом после того, как закончилась пачка.
# Отсчитывается после завершения LLM-обработки, поэтому фактическое время
# от входящего сообщения до ответа может быть чуть больше 10 секунд.
REPLY_DELAY_SECONDS = env_float("MARIN_TELEGRAM_REPLY_DELAY_SECONDS", 5.0)

# "Режим сна" — по просьбе владельца: раньше Марин отвечала одинаково
# быстро в любое время суток, включая 5 утра, что не похоже на живого
# человека со сном. В эти часы (локальное время сервера) первый ответ
# задерживается гораздо дольше обычного — как будто она не сразу
# проснулась/увидела сообщение — а в контекст добавляется честная
# пометка, что сейчас глубокая ночь, чтобы модель могла это учитывать
# в самом тексте (сонная реплика и т.п.), а не только в задержке.
QUIET_HOURS_START = env_int("MARIN_QUIET_HOURS_START", 2)   # 02:00
QUIET_HOURS_END = env_int("MARIN_QUIET_HOURS_END", 9)       # 09:00, [start, end)
QUIET_HOURS_REPLY_DELAY_MIN = env_float("MARIN_QUIET_HOURS_REPLY_DELAY_MIN", 60)
QUIET_HOURS_REPLY_DELAY_MAX = env_float("MARIN_QUIET_HOURS_REPLY_DELAY_MAX", 240)


# Часовой пояс владельца (напр. Asia/Bishkek). Пусто — время сервера, как раньше.
# Используется для режима сна и для того, когда Марин пишет первой.
MARIN_TIMEZONE = os.getenv("MARIN_TIMEZONE", "").strip()


_TZ_CACHE: dict = {}
# Зоны без перехода на летнее время — работают даже без пакета tzdata
# (на Alpine его нет по умолчанию, и Asia/Bishkek не распознавался).
_FIXED_OFFSET_ZONES = {
    "asia/bishkek": 6, "asia/almaty": 5, "asia/tashkent": 5, "asia/dushanbe": 5,
    "asia/ashgabat": 5, "asia/omsk": 6, "asia/novosibirsk": 7, "asia/krasnoyarsk": 7,
    "asia/yekaterinburg": 5, "europe/moscow": 3, "europe/minsk": 3, "europe/samara": 4,
    "asia/baku": 4, "asia/tbilisi": 4, "asia/yerevan": 4, "utc": 0,
}


def _fixed_offset_tz(name: str):
    """Asia/Bishkek → UTC+6 без tzdata; также понимает «UTC+6», «+06:00», «GMT+5:30»."""
    import datetime
    key = (name or "").strip().lower()
    if key in _FIXED_OFFSET_ZONES:
        return datetime.timezone(datetime.timedelta(hours=_FIXED_OFFSET_ZONES[key]), name)
    m = re.fullmatch(r"(?:utc|gmt)?\s*([+-])\s*(\d{1,2})(?::?(\d{2}))?", key)
    if m:
        delta = datetime.timedelta(hours=int(m.group(2)), minutes=int(m.group(3) or 0))
        return datetime.timezone(delta if m.group(1) == "+" else -delta, name)
    return None


def _owner_tz():
    """ZoneInfo владельца, разрешённая один раз. Неверное имя зоны (опечатка
    в MARIN_TIMEZONE или отсутствие tzdata на Alpine) раньше молча давало
    время сервера на КАЖДОМ вызове — режим сна и утренние сообщения
    срабатывали не в те часы без единой строки в логе. Теперь — одно
    предупреждение и явный fallback."""
    if not MARIN_TIMEZONE:
        return None
    if MARIN_TIMEZONE not in _TZ_CACHE:
        try:
            from zoneinfo import ZoneInfo
            _TZ_CACHE[MARIN_TIMEZONE] = ZoneInfo(MARIN_TIMEZONE)
        except Exception as exc:
            fixed = _fixed_offset_tz(MARIN_TIMEZONE)
            if fixed is not None:
                logger.info("[TZ] MARIN_TIMEZONE=%r: нет базы tzdata, использую фиксированный сдвиг %s",
                            MARIN_TIMEZONE, fixed)
            else:
                logger.warning(
                    "[TZ] MARIN_TIMEZONE=%r не распознан (%s) — использую время сервера. "
                    "Установите tzdata (pip install tzdata) или укажите сдвиг, напр. UTC+6.",
                    MARIN_TIMEZONE, exc,
                )
            _TZ_CACHE[MARIN_TIMEZONE] = fixed
    return _TZ_CACHE[MARIN_TIMEZONE]


def local_now(now: Optional[float] = None):
    """struct-подобное локальное время владельца (datetime)."""
    import datetime
    ts = time.time() if now is None else now
    tz = _owner_tz()
    if tz is not None:
        return datetime.datetime.fromtimestamp(ts, tz)
    return datetime.datetime.fromtimestamp(ts)


def _is_quiet_hours(now: Optional[float] = None) -> bool:
    hour = local_now(now).hour
    if QUIET_HOURS_START <= QUIET_HOURS_END:
        return QUIET_HOURS_START <= hour < QUIET_HOURS_END
    return hour >= QUIET_HOURS_START or hour < QUIET_HOURS_END  # окно через полночь

# Пауза между отдельными короткими сообщениями одной реплики.
MESSAGE_GAP_MIN_SECONDS = env_float("MARIN_TELEGRAM_MESSAGE_GAP_MIN_SECONDS", 0.8)
MESSAGE_GAP_MAX_SECONDS = env_float("MARIN_TELEGRAM_MESSAGE_GAP_MAX_SECONDS", 2.2)

# Максимум отдельных пузырей в одном ответе.
MIN_REPLY_MESSAGES = env_int("MARIN_TELEGRAM_MIN_REPLY_MESSAGES", 2)
# 0 = без ограничения: сколько коротких сообщений нужно мысли, столько и
# уходит подряд. Раньше было 3 — лишнее молча отрезалось и до владельца не доходило.
MAX_REPLY_MESSAGES = env_int("MARIN_TELEGRAM_MAX_REPLY_MESSAGES", 0, minimum=0)
# Длина одного пузыря в личке: как в живой переписке, а не абзацем.
REPLY_BUBBLE_MAX_CHARS = env_int("MARIN_TELEGRAM_BUBBLE_MAX_CHARS", 70, minimum=30)


def bubble_max_chars() -> int:
    """Читается при каждом ответе — чтобы самонастройка применялась сразу."""
    return env_int("MARIN_TELEGRAM_BUBBLE_MAX_CHARS", 70, minimum=30)


def cap_messages(messages: list) -> list:
    return messages[:MAX_REPLY_MESSAGES] if MAX_REPLY_MESSAGES > 0 else messages


_MEDIA_ONLY_RE = re.compile(r"\s*<<<(?:STICKER|CUSTOM_EMOJI)(?::[A-Za-z]?\d+)?>>>\s*", re.IGNORECASE)


def fit_messages(messages: list, limit: int) -> list:
    """Уложить в limit сообщений БЕЗ потери текста: текстовый хвост
    присоединяется к последнему сообщению. Маркеры стикеров в текст не
    вклеиваются (иначе ушли бы буквами) — лишние просто не отправляются."""
    messages = [m for m in messages if m and m.strip()]
    if limit <= 0 or len(messages) <= limit:
        return messages
    head, tail = messages[:limit - 1], messages[limit - 1:]
    text_tail = [m.strip() for m in tail if not _MEDIA_ONLY_RE.fullmatch(m)]
    return head + ([" ".join(text_tail)] if text_tail else tail[:1])

# Vision работает отдельно от основного текстового DeepSeek: изображение
# сначала понимает мультимодальная модель, затем описание попадает в обычный
# когнитивный цикл Marin.
VISION_ENABLED = os.getenv("MARIN_VISION_ENABLED", "true").lower() in {"1", "true", "yes", "on"}
VISION_MODEL = os.getenv("MARIN_OPENROUTER_VISION_MODEL", "openai/gpt-4o")
VISION_TIMEOUT = env_float("MARIN_VISION_TIMEOUT", 30)

# Генерация селфи (роадмап п.12) — в отличие от VISION_* (понимание входящих
# фото), это генерация НОВОГО изображения. Отдельный ключ не обязателен:
# если не задан MARIN_SELFIE_API_KEY, используется тот же MARIN_OPENROUTER_API_KEY,
# что и для чата/vision — см. _build_selfie_generator(). SELFIE_REFERENCE_IMAGE —
# фото лица, используемое как referen-изображение для консистентной внешности
# между генерациями (см. marin_core/telegram/selfie.py docstring).
SELFIE_ENABLED = os.getenv("MARIN_SELFIE_ENABLED", "true").lower() in {"1", "true", "yes", "on"}

# Иллюстрация к посту (не селфи — сцена/картинка по теме, без лица Марин).
# См. telegram/illustrator.py; ключ общий с чатом, если MARIN_ILLUSTRATION_API_KEY не задан.
ILLUSTRATION_ENABLED = os.getenv("MARIN_ILLUSTRATION_ENABLED", "true").lower() in {"1", "true", "yes", "on"}
ILLUSTRATION_MODEL = os.getenv("MARIN_ILLUSTRATION_MODEL", "google/gemini-2.5-flash-image")
ILLUSTRATION_TIMEOUT = env_float("MARIN_ILLUSTRATION_TIMEOUT", 60)
SELFIE_MODEL = os.getenv("MARIN_SELFIE_MODEL", "google/gemini-2.5-flash-image")
SELFIE_TIMEOUT = env_float("MARIN_SELFIE_TIMEOUT", 60)
SELFIE_REFERENCE_IMAGE = os.getenv(
    "MARIN_SELFIE_REFERENCE_IMAGE",
    os.path.join(os.path.dirname(__file__), "..", "assets", "marin_face_reference.jpg"),
)

# Генерация голосовых (TTS, ElevenLabs) — как и SELFIE_*, отдельный от
# send_voice (который только пересылает уже присланный владельцем файл,
# см. _resend_media). Требует MARIN_ELEVENLABS_API_KEY + MARIN_VOICE_ID —
# в отличие от эмбеддингов/чата/селфи, тут нет общего с OpenRouter ключа,
# ElevenLabs отдельный сервис.
VOICE_ENABLED = os.getenv("MARIN_VOICE_ENABLED", "true").lower() in {"1", "true", "yes", "on"}
VOICE_MODEL_ID = os.getenv("MARIN_VOICE_MODEL_ID", "eleven_multilingual_v2")
VOICE_TIMEOUT = env_float("MARIN_VOICE_TIMEOUT", 60)

# Внутренние маркеры для медиа. Они не попадают пользователю как текст.
STICKER_MARKER = "<<<STICKER>>>"
CUSTOM_EMOJI_MARKER = "<<<CUSTOM_EMOJI>>>"

# Постоянное общее хранилище Telegram-медиа.
#
# ВАЖНО: каждое новое ядро Марин может лежать в своей папке и иметь свой
# .venv. Поэтому каталог паков и Vision-кэш нельзя хранить относительно
# текущей папки ядра: иначе каждое новое ядро снова считает все стикеры
# "новыми" и повторно отправляет их в Vision.
#
# По умолчанию все ядра используют один каталог:
#   data/media/ (рядом с запуском)
#
# При необходимости путь можно переопределить через
# MARIN_SHARED_MEDIA_DIR.
SHARED_MEDIA_DIR = os.path.abspath(
    os.getenv("MARIN_SHARED_MEDIA_DIR", "data/media")
)
try:
    os.makedirs(SHARED_MEDIA_DIR, exist_ok=True)
except OSError:
    # Нет прав на /mari (локальный запуск, тесты) — не валим импорт модуля;
    # сохранение реестров само залогирует ошибку при записи.
    logging.getLogger("marin_x.telegram").warning(
        "Shared media dir %s is not writable; registries will not persist", SHARED_MEDIA_DIR)

# Сохранённые Telegram-наборы, которые Жаабир прислал Марин ссылкой.
MEDIA_PACKS_FILE = os.getenv(
    "MARIN_TELEGRAM_MEDIA_PACKS_FILE",
    os.path.join(SHARED_MEDIA_DIR, "marin_media_packs.json"),
)
# Каналы/группы, которые Марин считает "своими" (создала сама или владелец
# явно назначил) — до этого такого понятия не было вообще: она каждый раз
# заново узнавала/угадывала id канала из разговора, поэтому путалась, есть
# ли он уже, и забывала его между сообщениями. См. _remember_own_channel /
# _load_own_channels_registry / _telegram_world_hint.
# Долговечный реестр своих каналов: не теряется при установке нового ядра.
OWN_CHANNELS_FILE = os.getenv(
    "MARIN_TELEGRAM_OWN_CHANNELS_FILE",
    os.path.join(SHARED_MEDIA_DIR, "marin_own_channels.json"),
)

# Постоянный кэш Vision-описаний собственных стикеров/custom emoji (doc_id ->
# короткое описание того, что на них изображено). До этого модель выбирала
# медиа вслепую по одному служебному alt-символу от Telegram (часто пустому
# или это просто эмодзи-заглушка, не описание). См. _ensure_vision_catalog.
VISION_CACHE_FILE = os.getenv(
    "MARIN_VISION_CACHE_FILE",
    os.path.join(SHARED_MEDIA_DIR, "marin_media_vision_cache.json"),
)
# Сколько Vision-запросов на каталогизацию можно держать одновременно —
# не последовательно с паузой (было медленно на большом паке), а параллельно
# через семафор, ограниченный этим числом, чтобы не открыть сотни
# соединений к OpenRouter разом.
VISION_CATALOG_CONCURRENCY = env_int("MARIN_VISION_CATALOG_CONCURRENCY", 50)

# Файл, где помнится, какие стикеры/custom emoji НЕ удалось описать (сеть
# подвела, модель отказала, нет превью и т.п.) — чтобы не скачивать и не
# анализировать один и тот же сломанный элемент заново при КАЖДОМ запуске.
VISION_FAILURES_FILE = os.getenv(
    "MARIN_VISION_FAILURES_FILE",
    os.path.join(os.path.dirname(VISION_CACHE_FILE) or ".", "marin_media_vision_failures.json"),
)
# Через сколько дней всё-таки попробовать сломанный элемент ещё раз (вдруг
# провайдер/модель к тому времени починили) — не бесконечный бан, но и не
# долбёжка каждый рестарт.
VISION_RETRY_COOLDOWN_SECONDS = env_float("MARIN_VISION_RETRY_COOLDOWN_DAYS", 7) * 86400.0

logger.info(
    "Telegram shared media storage: %s (Vision cache: %s)",
    SHARED_MEDIA_DIR,
    VISION_CACHE_FILE,
)

MEDIA_PACK_URL_RE = re.compile(r"https?://(?:t\.)?(?:me|telegram\.me)/(addemoji|addstickers)/([A-Za-z0-9_\-]+)", re.IGNORECASE)

# Инвайт-ссылки на группы/каналы (новый формат "+HASH" и старый "joinchat/HASH").
# Раньше на такую ссылку Марин просто отвечала текстом "захожу уже", ничего
# реально не делая — это выглядело как обман. Теперь она правда пытается
# вступить, см. _handle_group_invite_links / _join_chat_from_invite.
GROUP_INVITE_URL_RE = re.compile(r"https?://(?:t\.)?(?:me|telegram\.me)/(?:\+|joinchat/)([A-Za-z0-9_\-]+)", re.IGNORECASE)

# Явная детерминированная команда для пересылки сообщения постороннему
# человеку: "/relay @username текст сообщения" — оставлена как запасной
# прямой вариант. См. _handle_relay_command.
RELAY_COMMAND_RE = re.compile(r"^[./]relay\s+@?(\w{5,32})\s+(.+)$", re.IGNORECASE | re.DOTALL)

# Естественный диалоговый вариант ("напиши ему привет") теперь идёт через
# общий ActionRegistry (marin_core/telegram/actions.py) — модель предлагает
# действие маркером <<<ACTION:kind|описание|payload>>>, владелец видит
# описание и подтверждает коротким словом, только тогда реально исполняется.

# Явная связь с GoalSet (marin_core/goals/goals.py), который раньше реально
# наполнялся только одной статичной IDENTITY-целью при старте движка.
# Когда владелец просит что-то держать в фокусе ("напомни мне...", "не
# забудь..."), модель помечает это маркером — а не просто проговаривает
# текстом, после чего это тут же забывается. Сам маркер не показывается
# владельцу (вырезается из видимого текста), см. _extract_goal_marker.
GOAL_MARKER_RE = re.compile(r"<<<GOAL:(.+?)>>>", re.DOTALL)
# Stage 4: долгосрочная автономная цель (не путать с обычным <<<GOAL:...>>>
# выше, который просто держит что-то в фокусе на текущую сессию) — см.
# _extract_autogoal_marker и telegram/goal_executor.py.
AUTOGOAL_MARKER_RE = re.compile(r"<<<AUTOGOAL:(.+?)>>>", re.DOTALL)
# Пост в собственный канал: <<<POST:бриф>>> — публикуется СРАЗУ, без
# подтверждения, через ChannelPublisher (telegram/channel_publisher.py).
# Второй слой поверх детерминированного intents.detect_intent: ловит любые
# формулировки владельца, которые не покрыли регулярки.
POST_MARKER_RE = re.compile(r"<<<POST:(.*?)>>>", re.IGNORECASE | re.DOTALL)
# Защитная сетка от утечки маркера в чат владельцу. Каждый реальный маркер
# (ACTION/READ/GOAL/AUTOGOAL/BELIEF/PERSON/STICKER/CUSTOM_EMOJI) к этому
# моменту уже должен быть вырезан своим extract_*/process_* — если сюда
# долетел кусок вида "<<<ACTION:..." без своей закрывающей ">>>", значит
# модель не закрыла тег (обрезалась по длине или просто ошиблась), и это
# остаток протокольного синтаксиса, который владелец не должен видеть.
# Достаточно найти начало — раз не сработал точный regex своего типа,
# значит закрытия либо нет, либо оно битое, и весь хвост с этого места
# безопаснее просто убрать, чем показать как есть.
LEAKED_MARKER_RE = re.compile(
    r"<<<\s*(?:ACTION|READ|GOAL|AUTOGOAL|BELIEF|PERSON|POST|TUNE)\s*:(?:(?!>>>).)*$",
    re.IGNORECASE | re.DOTALL,
)
# STICKER/CUSTOM_EMOJI сюда намеренно НЕ входят — в отличие от остальных,
# это не служебные теги, которые должны быть полностью съедены раньше по
# конвейеру: split_into_messages (providers.py) ждёт их в тексте до самого
# конца, чтобы превратить в реальный стикер/эмодзи при отправке. Раньше
# они тут были, и `.*` жадно съедал их ВМЕСТЕ с настоящим закрывающим
# ">>>" — то есть каждый закрытый, полностью рабочий '<<<STICKER:S7>>>'
# ошибочно считался "недописанным" и вырезался целиком, а стикер терялся.
# Заодно сузил и сам паттерн: раньше `.*` матчил и полностью ЗАКРЫТЫЙ
# маркер (просто до конца строки), теперь — только когда до конца строки
# так и не встретилось закрывающего ">>>" (реально недописанный случай).
# Наблюдаемый реальный сбой: модель иногда путает местами поля маркера —
# кладёт голый chat/user id в description (2-е поле, которое ПОДСТАВЛЯЕТСЯ
# видимым текстом владельцу вместо маркера, см. actions.py::extract_draft)
# вместо того, чтобы положить его в начало payload. Результат — владелец
# видит голое число вместо описания, а сам payload у большинства kind'ов
# остаётся без idа чата в начале и реальное действие потом падает с
# generic "не получилось". Чиним это ДО extract_draft — ничего не меняя в
# actions.py — см. _repair_action_marker_fields.
ID_LIKE_DESCRIPTION_RE = re.compile(r"^-?\d{3,}$")
# kind'ы, у которых первый сегмент payload — это НЕ chat/user id, а что-то
# другое (текст/имя) — для них авто-починку делать нельзя, там description,
# похожее на число, просто маловероятная случайность, а не перепутанные поля.
NON_CHAT_FIRST_PAYLOAD_KINDS = {"set_bio", "set_username", "set_profile_name", "set_profile_photo", "create_channel"}
# kind'ы с простым payload-значением (не JSON) — если description оказался
# голым id, правильный payload это буквально этот id, без склейки.
PLAIN_VALUE_CHAT_KINDS = {
    "relay", "leave_chat", "block_user", "unblock_user", "mute_chat", "unmute_chat",
    "archive_chat", "unarchive_chat", "create_invite_link", "join_chat",
}
# для JSON-payload kind'ов — имя ключа, под который нужно положить id,
# если он ошибочно оказался в description (см. _repair_action_marker_fields).
JSON_PAYLOAD_CHAT_KEY = {
    "pin_message": "chat", "unpin_message": "chat", "send_reaction": "chat", "react_to_message": "chat",
    "forward_message": "from_chat", "kick_user": "chat", "ban_user": "chat", "unban_user": "chat",
    "promote_admin": "chat", "demote_admin": "chat", "invite_user": "chat", "send_message": "to",
    "edit_message": "chat", "delete_message": "chat", "delete_message_from_chat": "chat",
    "reply_to_message": "chat", "send_photo": "to", "send_video": "to", "send_document": "to",
    "send_file": "to", "send_audio": "to", "send_voice": "to", "send_video_note": "to", "send_album": "to",
    "schedule_message": "chat", "edit_channel": "chat", "change_channel_title": "chat",
    "change_channel_about": "chat", "change_channel_photo": "chat", "restrict_user": "chat",
    "edit_admin_rights": "chat", "create_poll": "chat", "stop_poll": "chat", "edit_invite_link": "chat",
    "revoke_invite_link": "chat", "approve_join_request": "chat", "decline_join_request": "chat",
    "send_sticker": "chat", "delete_scheduled_message": "chat", "edit_scheduled_message": "chat",
}
GOALS_LIST_COMMANDS = {"/goals", ".цели", ".goals"}
GOAL_PAUSE_RE = re.compile(r"^[./](?:пауза|pause)\s+(\S+)", re.IGNORECASE)
GOAL_RESUME_RE = re.compile(r"^[./](?:продолжить|возобнови|resume)\s+(\S+)", re.IGNORECASE)
GOAL_CANCEL_RE = re.compile(r"^[./](?:отмена|отмени|cancel)\s+(\S+)", re.IGNORECASE)
# Явная, курируемая команда — НЕ свободная интерпретация фразы владельца —
# для включения/выключения auto_approve на конкретной цели (см.
# goal_executor.py SAFE_AUTO_APPROVE_KINDS). Осознанно только команда, а не
# что-то, что LLM могла бы решить сама по смыслу разговора: это переключает
# требование подтверждения, и должно быть однозначным, а не угадываемым.
GOAL_AUTOAPPROVE_ON_RE = re.compile(r"^[./](?:автопост|autopost)\s+(\S+)\s+(?:вкл|on)\b", re.IGNORECASE)
GOAL_AUTOAPPROVE_OFF_RE = re.compile(r"^[./](?:автопост|autopost)\s+(\S+)\s+(?:выкл|off)\b", re.IGNORECASE)
# Явная команда, а не свободная фраза — назначить УЖЕ существующий канал/
# группу "своим", без создания нового (см. _handle_own_channel_command).
# То же самое обоснование, что у автопоста: это меняет то, что Марин
# считает своим ресурсом, поэтому должно быть однозначной командой.
OWN_CHANNEL_ASSIGN_RE = re.compile(r"^[./](?:мойканал|мой_канал|ownchannel)\s+(.+)$", re.IGNORECASE)
# Явная команда для запуска автономной цели (Stage 4) — до этого единственный
# путь был <<<AUTOGOAL:...>>>, который модель должна была сама решить
# предложить по смыслу разговора; на практике это ненадёжно (владелец мог
# сказать что-то, что модель не распознала как повод для автономной цели).
# Команда — гарантированный путь, не зависящий от того, поймёт ли модель намёк.
GOAL_START_RE = re.compile(r"^[./](?:цель|goal)\s+(.+)$", re.IGNORECASE | re.DOTALL)

# Собственные догадки/выводы модели (не прямые факты) — напр. "кажется, он
# сегодня в плохом настроении". Реально пишутся в BeliefStore как
# SourceType.LLM_GENERATED с ограниченной confidence (см.
# CognitiveEngine.remember_guess), а не теряются как обычный текст ответа.
BELIEF_MARKER_RE = re.compile(r"<<<BELIEF:(.+?)>>>", re.DOTALL)

# Углублённый Person Model: <<<PERSON:username|action|payload>>>.
# action ∈ {like, dislike, topic_open, topic_done, promise, promise_done,
# trust_up, trust_down, fact}. Большинство действий пишутся напрямую в
# TelegramObserver.apply_person_marker; "fact" идёт через BeliefStore с
# обнаружением противоречий (см. _extract_person_marker).
PERSON_MARKER_RE = re.compile(r"<<<PERSON:@?(\w{3,32})\|(\w+)\|(.+?)>>>", re.IGNORECASE | re.DOTALL)

# Сколько последних сообщений чата (не считая только что полученной пачки)
# подтягивать как контекст переписки перед тем, как звать CognitiveEngine.
HISTORY_CONTEXT_MESSAGES = env_int("MARIN_HISTORY_MESSAGES", 14, minimum=1)
# Дополнительно — сообщения прошлых дней (вчера и раньше), сжатые до одной строки:
# чтобы «о чём мы болтали вчера» не терялось после шестого сообщения. 0 — выключить.
HISTORY_EARLIER_MESSAGES = env_int("MARIN_HISTORY_EARLIER_MESSAGES", 30, minimum=0)
HISTORY_EARLIER_DAYS = env_int("MARIN_HISTORY_EARLIER_DAYS", 3, minimum=0)
HISTORY_EARLIER_LINE_CHARS = env_int("MARIN_HISTORY_EARLIER_LINE_CHARS", 170, minimum=40)

# --- групповые чаты (не собственный канал Марин, не личка владельца) -------
# Марин может участвовать наравне со всеми, различая КАЖДОГО человека по
# имени (relationship/beliefs/pending-feedback у ядра уже ведутся per-actor,
# см. marin_core/social и marin_core/belief) — здесь только когда и как часто
# ей включаться в разговор, чтобы группа не превратилась в спам.
GROUP_CHAT_ENABLED = os.getenv("MARIN_GROUP_CHAT_ENABLED", "true").lower() in {"1", "true", "yes", "on"}
GROUP_REPLY_COOLDOWN_SECONDS = env_float("MARIN_GROUP_REPLY_COOLDOWN_SECONDS", 20)
GROUP_REPLIES_MAX_PER_HOUR = env_float("MARIN_GROUP_REPLIES_MAX_PER_HOUR", 30)

# Раз в сколько секунд проверять, не пора ли ConsolidationScheduler'у
# запустить простойную консолидацию + дневниковую запись (§14 спеки).
SCHEDULER_CHECK_INTERVAL = 60.0

# Раз в сколько секунд обновлять сводку по реальным диалогам аккаунта —
# сколько всего чатов/групп/каналов, не только тех, где была активность
# (см. _refresh_dialogs_summary()). Не на каждый тик, чтобы не дёргать API.
DIALOGS_REFRESH_INTERVAL_SECONDS = env_float("MARIN_TELEGRAM_DIALOGS_REFRESH_SECONDS", 600)

# Команды дневника/мыслей — доступны только владельцу (это личное), не
# уходят через обычный когнитивный цикл, обрабатываются напрямую.
DIARY_COMMANDS = {".дневник", "/diary", ".diary"}
THOUGHTS_COMMANDS = {".мысли", "/thoughts", ".thoughts", ".мысль"}
OBSERVER_COMMANDS = {".кто писал", ".кто-писал", "/who_today", ".что произошло", ".сводка"}
FULL_OBSERVER_COMMANDS = {".вся сводка", ".все чаты", ".все люди", "/who_all", ".без ограничений", ".всё в тг"}
STATUS_COMMANDS = {"/status", ".статус", ".status"}
# Техническая метакогниция последнего хода: как поняла, что знала/не знала,
# почему выбрала это действие, чему научилась (engine.explain_last()).
WHY_COMMANDS = {"/why", ".почему", ".why", "/meta", ".мета"}
EXPORT_COMMANDS = {"/export", ".export", ".экспорт"}
IMPORT_COMMANDS = {"/import", ".import", ".импорт"}
DASHBOARD_COMMANDS = {"/dashboard", ".дашборд", ".dashboard"}

# Смена собственного профиля аккаунта (имя/юзернейм) — owner-only,
# детерминированная команда с явным аргументом. Это её собственный
# профиль, не третьи лица, действие обратимое — в отличие от общей
# "делай что угодно в Telegram", это разумно ограниченная функция.
PROFILE_NAME_RE = re.compile(r"^[./]setname\s+(.+)$", re.IGNORECASE | re.DOTALL)
PROFILE_USERNAME_RE = re.compile(r"^[./]setusername\s+@?(\w{5,32})$", re.IGNORECASE)

# Если файл с этим именем лежит рядом с кодом при старте — автоматически
# подгружается один раз в start() (см. run()). Так перенос в другое
# окружение делается: /export здесь -> скопировать файл в новое окружение
# -> запустить бота там, он сам подхватит состояние при старте.
STATE_IMPORT_FILE = os.getenv("MARIN_STATE_IMPORT_FILE", "marin_export.json")


@dataclass
class TelegramConfig:
    api_id: int
    api_hash: str
    session: str = "marin_x"
    phone: Optional[str] = None
    owner_id: Optional[str] = None
    respond_to_outgoing: bool = False
    ignore_bots: bool = True

    @classmethod
    def from_env(cls) -> "TelegramConfig":
        raw_id = os.getenv("TELEGRAM_API_ID") or os.getenv("MARIN_TELEGRAM_API_ID")
        api_hash = os.getenv("TELEGRAM_API_HASH") or os.getenv("MARIN_TELEGRAM_API_HASH")
        if not raw_id or not api_hash:
            raise RuntimeError(
                "Telegram requires TELEGRAM_API_ID and TELEGRAM_API_HASH in .env"
            )
        try:
            api_id = int(raw_id)
        except ValueError as exc:
            raise RuntimeError("TELEGRAM_API_ID must be an integer") from exc

        return cls(
            api_id=api_id,
            api_hash=api_hash,
            session=os.getenv("MARIN_TELEGRAM_SESSION", "marin_x"),
            phone=os.getenv("MARIN_TELEGRAM_PHONE") or os.getenv("TELEGRAM_PHONE"),
            owner_id=os.getenv("MARIN_OWNER_ID") or os.getenv("TELEGRAM_OWNER_ID"),
            respond_to_outgoing=os.getenv("MARIN_TELEGRAM_RESPOND_TO_OUTGOING", "false").lower() in {"1", "true", "yes", "on"},
            ignore_bots=os.getenv("MARIN_TELEGRAM_IGNORE_BOTS", "true").lower() in {"1", "true", "yes", "on"},
        )

# Сколько стикеров / custom emoji держать в каталоге (раньше жёстко 300,
# а в подсказку модели попадали только первые 60/40).
MEDIA_CATALOG_MAX = env_int("MARIN_MEDIA_CATALOG_MAX", 600)
