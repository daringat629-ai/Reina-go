"""Curated write/admin Telegram actions (<<<ACTION:...>>>).

Mixin of MarinTelegramClient — relies on attributes created in
MarinTelegramClient.__init__ (self.client, self.engine, self.config, ...).
"""
from __future__ import annotations

import json
import logging
from .actions import PendingAction
from .resolver import tg_error_reason
import re as _re

# Служебный жаргон планировщика, который однажды утёк в описание канала
# («Автономная цель-источник для автопостинга мыслей…»). Публичные поля
# канала с таким текстом не применяем.
_INTERNAL_JARGON_RE = _re.compile(
    r"автономн\w*\s+цел|цель[-\s]источник|автопост|autopost|\bgoal\b|\$telegram|payload|плейсхолдер|placeholder",
    _re.IGNORECASE,
)


def _public_text(value) -> str:
    text = str(value or "").strip()
    if text and _INTERNAL_JARGON_RE.search(text):
        logger.warning("Dropped internal jargon from public channel field: %r", text[:200])
        return ""
    return text
from .selfie import SelfieGenerationError
from .voice import VoiceGenerationError
from telethon import functions, types, utils
from typing import Any, Dict, Optional

logger = logging.getLogger("marin_x.telegram")


def tl_new(cls, **kwargs):
    """Создаёт TL-объект Telethon, заполняя нулями обязательные служебные
    поля, которых нет в kwargs (hash/id и т.п.). Между слоями Telegram такие
    поля добавляются в конструкторы — без этого код падает при обновлении."""
    import inspect
    try:
        params = inspect.signature(cls.__init__).parameters
    except (TypeError, ValueError):
        return cls(**kwargs)
    for name, prm in params.items():
        if name == "self" or name in kwargs or prm.default is not inspect.Parameter.empty:
            continue
        if prm.kind in (prm.VAR_POSITIONAL, prm.VAR_KEYWORD):
            continue
        if name in ("hash", "id") or name.endswith("_hash"):
            kwargs[name] = 0
    return cls(**kwargs)


class WriteActionsMixin:
    def _register_actions(self) -> None:
        """Регистрирует конкретные, ограниченные действия в ActionRegistry —
        это то место, где явно КУРИРУЕТСЯ, что вообще может предложить
        модель через <<<ACTION:...>>>. Список закрытый: неизвестный kind
        игнорируется реестром автоматически (см. actions.py)."""
        self.actions.register("relay", self._action_relay)
        self.actions.register("leave_chat", self._action_leave_chat)
        self.actions.register("block_user", self._action_block_user)
        self.actions.register("unblock_user", self._action_unblock_user)
        self.actions.register("set_bio", self._action_set_bio)
        # Расширенный набор — тот же принцип: один kind = один targeted
        # handler на одну сущность за раз. Осознанно НЕ регистрирую здесь
        # массовые/пакетные операции (разослать многим, разбанить весь чат
        # и т.п.) и операции, необратимо угрожающие доступу к самому
        # аккаунту (2FA, завершение чужих сессий, платежи) — см.
        # CHANGELOG/комментарий ниже про то, что сознательно не добавлено.
        self.actions.register("pin_message", self._action_pin_message)
        self.actions.register("unpin_message", self._action_unpin_message)
        self.actions.register("mute_chat", self._action_mute_chat)
        self.actions.register("unmute_chat", self._action_unmute_chat)
        self.actions.register("archive_chat", self._action_archive_chat)
        self.actions.register("unarchive_chat", self._action_unarchive_chat)
        self.actions.register("send_reaction", self._action_send_reaction)
        self.actions.register("forward_message", self._action_forward_message)
        self.actions.register("create_invite_link", self._action_create_invite_link)
        self.actions.register("kick_user", self._action_kick_user)
        self.actions.register("ban_user", self._action_ban_user)
        self.actions.register("unban_user", self._action_unban_user)
        self.actions.register("promote_admin", self._action_promote_admin)
        self.actions.register("demote_admin", self._action_demote_admin)
        self.actions.register("invite_user", self._action_invite_user)
        # -- Этап 2: ещё write/admin действия, тот же принцип (draft ->
        # confirm -> handler), никакого прямого вызова Telegram API из LLM
        # мимо этого механизма. Read-only действия ниже НЕ регистрируются
        # тут — у них нет состояния для подтверждения, они выполняются через
        # отдельный, тоже курируемый механизм (см. _READONLY_ACTIONS /
        # _process_readonly_markers) без изменения самого ActionRegistry.
        self.actions.register("send_message", self._action_send_message)
        self.actions.register("edit_message", self._action_edit_message)
        self.actions.register("delete_message", self._action_delete_message)
        self.actions.register("delete_message_from_chat", self._action_delete_message)
        self.actions.register("reply_to_message", self._action_reply_to_message)
        self.actions.register("send_photo", self._action_send_photo)
        self.actions.register("send_video", self._action_send_video)
        self.actions.register("send_document", self._action_send_document)
        self.actions.register("send_file", self._action_send_document)
        self.actions.register("schedule_message", self._action_schedule_message)
        self.actions.register("set_profile_name", self._action_set_profile_name)
        self.actions.register("set_username", self._action_set_username)
        self.actions.register("set_profile_photo", self._action_set_profile_photo)
        self.actions.register("create_channel", self._action_create_channel)
        self.actions.register("edit_channel", self._action_edit_channel)
        self.actions.register("change_channel_title", self._action_change_channel_title)
        self.actions.register("change_channel_about", self._action_change_channel_about)
        self.actions.register("change_channel_photo", self._action_change_channel_photo)
        self.actions.register("join_chat", self._action_join_chat)
        self.actions.register("restrict_user", self._action_restrict_user)
        self.actions.register("edit_admin_rights", self._action_edit_admin_rights)
        # react_to_message — то же самое действие, что уже есть под именем
        # send_reaction (этап 1); регистрирую и под этим именем, а не
        # дублирую handler, чтобы модель могла назвать его любым способом.
        self.actions.register("react_to_message", self._action_send_reaction)
        # -- Этап 3: опросы, invite-links/join-requests, стикеры, ещё медиа,
        # альбомы, scheduled messages. create_invite_link уже был
        # зарегистрирован на этапе 1 — не дублирую его здесь.
        self.actions.register("create_poll", self._action_create_poll)
        self.actions.register("stop_poll", self._action_stop_poll)
        self.actions.register("edit_invite_link", self._action_edit_invite_link)
        self.actions.register("revoke_invite_link", self._action_revoke_invite_link)
        self.actions.register("approve_join_request", self._action_approve_join_request)
        self.actions.register("decline_join_request", self._action_decline_join_request)
        self.actions.register("send_sticker", self._action_send_sticker)
        self.actions.register("send_audio", self._action_send_audio)
        self.actions.register("send_voice", self._action_send_voice)
        self.actions.register("send_video_note", self._action_send_video_note)
        self.actions.register("send_album", self._action_send_album)
        self.actions.register("send_selfie", self._action_send_selfie)
        self.actions.register("send_dice", self._action_send_dice)
        self.actions.register("post_story", self._action_post_story)
        self.actions.register("send_voice_message", self._action_send_voice_message)
        self.actions.register("delete_scheduled_message", self._action_delete_scheduled_message)
        self.actions.register("edit_scheduled_message", self._action_edit_scheduled_message)
        self._register_readonly_actions()

    async def _action_relay(self, action: PendingAction) -> str:
        """payload = username. description = уже готовый, честно
        раскрытый текст сообщения (см. системный промпт про <<<ACTION:relay|...>>>)."""
        username = action.payload.strip().lstrip("@")
        try:
            entity = await self._resolve_peer(username)
        except Exception:
            logger.warning("Action relay: could not resolve @%s", username, exc_info=True)
            return f"Не смогла найти @{username} — не отправила."
        try:
            await self.client.send_message(entity, action.description)
        except Exception:
            logger.warning("Action relay: could not send to @%s", username, exc_info=True)
            return f"Не получилось отправить @{username} — Telegram отказал (возможно, у него закрыты личные сообщения)."
        logger.info("Action relay: sent to @%s", username)
        return f"Готово, передала @{username}."

    async def _action_leave_chat(self, action: PendingAction) -> str:
        """payload = username/ссылка/id группы, которую нужно покинуть."""
        identifier = action.payload.strip()
        try:
            entity = await self._resolve_peer(identifier)
            await self.client.delete_dialog(entity)
        except Exception:
            logger.warning("Action leave_chat failed for %r", identifier, exc_info=True)
            return f"Не получилось выйти из «{identifier}» — не нашла такой чат или Telegram отказал."
        return f"Готово, вышла из «{identifier}»."

    async def _action_block_user(self, action: PendingAction) -> str:
        username = action.payload.strip().lstrip("@")
        try:
            entity = await self._resolve_peer(username)
            await self.client(functions.contacts.BlockRequest(id=entity))
        except Exception:
            logger.warning("Action block_user failed for @%s", username, exc_info=True)
            return f"Не получилось заблокировать @{username}."
        return f"Готово, заблокировала @{username}."

    async def _action_unblock_user(self, action: PendingAction) -> str:
        username = action.payload.strip().lstrip("@")
        try:
            entity = await self._resolve_peer(username)
            await self.client(functions.contacts.UnblockRequest(id=entity))
        except Exception:
            logger.warning("Action unblock_user failed for @%s", username, exc_info=True)
            return f"Не получилось разблокировать @{username}."
        return f"Готово, разблокировала @{username}."

    async def _action_set_bio(self, action: PendingAction) -> str:
        bio = (action.payload or action.description).strip()[:70]
        try:
            await self.client(functions.account.UpdateProfileRequest(about=bio))
        except Exception as _e:
            logger.warning("Action set_bio failed", exc_info=True)
            return f"Не получилось обновить био: {tg_error_reason(_e)}."
        return f"Готово, био теперь: {bio}"

    # -- Расширенный набор действий: payload теперь JSON-объект с именованными
    # полями (а не позиционная pipe-строка) — реальный наблюдавшийся сбой был
    # в том, что модель иногда путала порядок pipe-полей (см. CHANGELOG); у
    # именованных ключей просто нет "порядка", который можно перепутать.
    # actions.py/ActionRegistry при этом не тронуты — маркер снаружи всё тот
    # же <<<ACTION:kind|description|payload>>>, поменялось только содержимое
    # payload. Для kind'ов с одним значением (relay, leave_chat, set_bio,
    # mute_chat и т.п. выше) JSON не нужен — там нечего путать местами.

    async def _action_pin_message(self, action: PendingAction) -> str:
        """payload (JSON) = {"chat": ..., "message_id": ...}"""
        try:
            p = json.loads(action.payload)
            entity = await self._resolve_peer(p["chat"])
            await self.client.pin_message(entity, int(p["message_id"]), notify=False)
        except Exception as _e:
            logger.warning("Action pin_message failed for %r", action.payload, exc_info=True)
            return f"Не получилось закрепить сообщение: {tg_error_reason(_e)}."
        return "Готово, закрепила сообщение."

    async def _action_unpin_message(self, action: PendingAction) -> str:
        """payload (JSON) = {"chat": ..., "message_id": ...}"""
        try:
            p = json.loads(action.payload)
            entity = await self._resolve_peer(p["chat"])
            await self.client.unpin_message(entity, int(p["message_id"]))
        except Exception as _e:
            logger.warning("Action unpin_message failed for %r", action.payload, exc_info=True)
            return f"Не получилось открепить сообщение: {tg_error_reason(_e)}."
        return "Готово, открепила сообщение."

    async def _action_mute_chat(self, action: PendingAction) -> str:
        """payload = username/id чата, который нужно замьютить полностью."""
        identifier = action.payload.strip()
        try:
            entity = await self._resolve_peer(identifier)
            await self.client(functions.account.UpdateNotifySettingsRequest(
                peer=types.InputNotifyPeer(await self.client.get_input_entity(entity)),
                settings=types.InputPeerNotifySettings(mute_until=2**31 - 1),
            ))
        except Exception:
            logger.warning("Action mute_chat failed for %r", identifier, exc_info=True)
            return f"Не получилось замьютить «{identifier}»."
        return f"Готово, замьютила «{identifier}»."

    async def _action_unmute_chat(self, action: PendingAction) -> str:
        """payload = username/id чата."""
        identifier = action.payload.strip()
        try:
            entity = await self._resolve_peer(identifier)
            await self.client(functions.account.UpdateNotifySettingsRequest(
                peer=types.InputNotifyPeer(await self.client.get_input_entity(entity)),
                settings=types.InputPeerNotifySettings(mute_until=0),
            ))
        except Exception:
            logger.warning("Action unmute_chat failed for %r", identifier, exc_info=True)
            return f"Не получилось снять мьют с «{identifier}»."
        return f"Готово, сняла мьют с «{identifier}»."

    async def _action_archive_chat(self, action: PendingAction) -> str:
        """payload = username/id чата — переносит его в архив (folder_id=1)."""
        identifier = action.payload.strip()
        try:
            entity = await self._resolve_peer(identifier)
            peer = await self.client.get_input_entity(entity)
            await self.client(functions.messages.EditPeerFoldersRequest(
                folder_peers=[types.InputFolderPeer(peer=peer, folder_id=1)]
            ))
        except Exception:
            logger.warning("Action archive_chat failed for %r", identifier, exc_info=True)
            return f"Не получилось заархивировать «{identifier}»."
        return f"Готово, заархивировала «{identifier}»."

    async def _action_unarchive_chat(self, action: PendingAction) -> str:
        """payload = username/id чата — возвращает из архива (folder_id=0)."""
        identifier = action.payload.strip()
        try:
            entity = await self._resolve_peer(identifier)
            peer = await self.client.get_input_entity(entity)
            await self.client(functions.messages.EditPeerFoldersRequest(
                folder_peers=[types.InputFolderPeer(peer=peer, folder_id=0)]
            ))
        except Exception:
            logger.warning("Action unarchive_chat failed for %r", identifier, exc_info=True)
            return f"Не получилось вернуть «{identifier}» из архива."
        return f"Готово, вернула «{identifier}» из архива."

    async def _action_send_reaction(self, action: PendingAction) -> str:
        """payload (JSON) = {"chat": ..., "message_id": ..., "emoji": "..."} (обычный unicode-эмодзи)."""
        try:
            p = json.loads(action.payload)
            entity = await self._resolve_peer(p["chat"])
            await self.client(functions.messages.SendReactionRequest(
                peer=entity,
                msg_id=int(p["message_id"]),
                reaction=[types.ReactionEmoji(emoticon=str(p["emoji"]).strip())],
            ))
        except Exception as _e:
            logger.warning("Action send_reaction failed for %r", action.payload, exc_info=True)
            return f"Не получилось поставить реакцию: {tg_error_reason(_e)}."
        return "Готово, поставила реакцию."

    async def _action_forward_message(self, action: PendingAction) -> str:
        """payload (JSON) = {"from_chat": ..., "message_id": ..., "to": ...}"""
        try:
            p = json.loads(action.payload)
            from_entity = await self._resolve_peer(p["from_chat"])
            to_entity = await self._resolve_peer(p["to"])
            await self.client.forward_messages(to_entity, int(p["message_id"]), from_entity)
        except Exception as _e:
            logger.warning("Action forward_message failed for %r", action.payload, exc_info=True)
            return f"Не получилось переслать сообщение: {tg_error_reason(_e)}."
        return "Готово, переслала сообщение."

    async def _action_create_invite_link(self, action: PendingAction) -> str:
        """payload = username/id группы или канала."""
        identifier = action.payload.strip()
        try:
            entity = await self._resolve_peer(identifier)
            result = await self.client(functions.messages.ExportChatInviteRequest(peer=entity))
            link = getattr(result, "link", None) or getattr(getattr(result, "invite", None), "link", None)
        except Exception:
            logger.warning("Action create_invite_link failed for %r", identifier, exc_info=True)
            return f"Не получилось создать ссылку-приглашение для «{identifier}»."
        return f"Готово, вот ссылка: {link}" if link else "Создала ссылку, но не смогла её прочитать."

    async def _action_kick_user(self, action: PendingAction) -> str:
        """payload (JSON) = {"chat": ..., "username": ...} — удаляет участника
        из группы/канала (сам может снова зайти по инвайт-ссылке, это не
        постоянный бан)."""
        try:
            p = json.loads(action.payload)
            chat = await self._resolve_peer(p["chat"])
            user = await self._resolve_peer(p["username"])
            await self.client.kick_participant(chat, user)
        except Exception as _e:
            logger.warning("Action kick_user failed for %r", action.payload, exc_info=True)
            return f"Не получилось убрать участника: {tg_error_reason(_e)}."
        return "Готово, убрала участника из чата."

    async def _action_ban_user(self, action: PendingAction) -> str:
        """payload (JSON) = {"chat": ..., "username": ...} — постоянный бан
        (запрет заходить снова)."""
        try:
            p = json.loads(action.payload)
            chat = await self._resolve_peer(p["chat"])
            user = await self._resolve_peer(p["username"])
            await self.client.edit_permissions(chat, user, view_messages=True)
        except Exception as _e:
            logger.warning("Action ban_user failed for %r", action.payload, exc_info=True)
            return f"Не получилось забанить: {tg_error_reason(_e)}."
        return "Готово, забанила участника."

    async def _action_unban_user(self, action: PendingAction) -> str:
        """payload (JSON) = {"chat": ..., "username": ...} — снимает ограничения/бан."""
        try:
            p = json.loads(action.payload)
            chat = await self._resolve_peer(p["chat"])
            user = await self._resolve_peer(p["username"])
            await self.client.edit_permissions(chat, user)
        except Exception as _e:
            logger.warning("Action unban_user failed for %r", action.payload, exc_info=True)
            return f"Не получилось разбанить: {tg_error_reason(_e)}."
        return "Готово, разбанила участника."

    async def _action_promote_admin(self, action: PendingAction) -> str:
        """payload (JSON) = {"chat": ..., "username": ...}. Набор прав зависит
        от типа чата: у broadcast-канала нет ban_users/pin_messages, и сервер
        отклонял весь запрос целиком — поэтому раньше назначение всегда падало."""
        try:
            p = json.loads(action.payload)
            chat = await self._resolve_peer(p["chat"])
            user = await self._resolve_peer(p.get("username") or p.get("user"))
            if getattr(chat, "broadcast", False):
                rights = dict(change_info=True, post_messages=True, edit_messages=True,
                              delete_messages=True, invite_users=True)
            else:
                rights = dict(change_info=True, delete_messages=True, ban_users=True,
                              invite_users=True, pin_messages=True)
            await self.client.edit_admin(chat, user, is_admin=True, **rights)
        except Exception as e:
            logger.warning("Action promote_admin failed for %r", action.payload, exc_info=True)
            return f"Не получилось назначить админом: {tg_error_reason(e)}."
        return f"Готово, назначила админом в «{getattr(chat, 'title', '') or 'чате'}»."

    async def _action_demote_admin(self, action: PendingAction) -> str:
        """payload (JSON) = {"chat": ..., "username": ...} — снимает права администратора."""
        try:
            p = json.loads(action.payload)
            chat = await self._resolve_peer(p["chat"])
            user = await self._resolve_peer(p["username"])
            await self.client.edit_admin(chat, user, is_admin=False)
        except Exception as _e:
            logger.warning("Action demote_admin failed for %r", action.payload, exc_info=True)
            return f"Не получилось снять права администратора: {tg_error_reason(_e)}."
        return "Готово, сняла права администратора."

    async def _action_invite_user(self, action: PendingAction) -> str:
        """payload (JSON) = {"chat": ..., "username": ...}. Если прямое
        добавление запрещено (приватность, «только взаимные контакты» — это
        обычная ситуация для каналов), не сдаёмся, а сразу создаём
        инвайт-ссылку и отправляем её человеку в личку."""
        try:
            p = json.loads(action.payload)
            chat = await self._resolve_peer(p["chat"])
            user = await self._resolve_peer(p.get("username") or p.get("user"))
        except Exception as e:
            logger.warning("Action invite_user: resolve failed for %r", action.payload, exc_info=True)
            return f"Не получилось пригласить: {tg_error_reason(e)}."
        title = getattr(chat, "title", "") or "чат"
        try:
            if getattr(chat, "broadcast", False) or getattr(chat, "megagroup", False):
                await self.client(functions.channels.InviteToChannelRequest(channel=chat, users=[user]))
            else:
                await self.client(functions.messages.AddChatUserRequest(chat_id=chat.id, user_id=user, fwd_limit=50))
            return f"Готово, добавила в «{title}»."
        except Exception as e:
            reason = tg_error_reason(e)
            if "UserAlreadyParticipant" in type(e).__name__:
                return f"Готово — он уже в «{title}»."
            logger.info("invite_user direct add failed (%s) — falling back to invite link", type(e).__name__)
        try:
            invite = await self.client(functions.messages.ExportChatInviteRequest(peer=chat, legacy_revoke_permanent=False))
            link = getattr(invite, "link", "")
            await self.client.send_message(user, f"Заходи в «{title}»: {link}")
            return f"Готово: напрямую добавить нельзя ({reason}), поэтому отправила ему ссылку-приглашение в личку: {link}"
        except Exception as e2:
            logger.warning("invite_user link fallback failed", exc_info=True)
            return f"Не получилось пригласить: {reason}; ссылку тоже не вышло сделать — {tg_error_reason(e2)}."

    # -- Этап 2: ещё write/admin действия -----------------------------------

    async def _action_send_message(self, action: PendingAction) -> str:
        """payload (JSON) = {"to": ..., "text": ...} — отдельное от relay
        действие с тем же эффектом (модель может назвать его любым из двух имён)."""
        try:
            p = json.loads(action.payload)
            entity = await self._resolve_peer(p["to"])
            text = str(p["text"]).strip()
            await self.client.send_message(entity, text)
            self._record_own_channel_post(utils.get_peer_id(entity), preview=text)
        except Exception as _e:
            logger.warning("Action send_message failed for %r", action.payload, exc_info=True)
            return f"Не получилось отправить сообщение: {tg_error_reason(_e)}."
        return "Готово, отправила сообщение."

    async def _action_edit_message(self, action: PendingAction) -> str:
        """payload (JSON) = {"chat": ..., "message_id": ..., "text": ...} —
        редактирует только своё собственное сообщение (так разрешает сам Telegram)."""
        try:
            p = json.loads(action.payload)
            entity = await self._resolve_peer(p["chat"])
            await self.client.edit_message(entity, int(p["message_id"]), str(p["text"]).strip())
        except Exception as _e:
            logger.warning("Action edit_message failed for %r", action.payload, exc_info=True)
            return f"Не получилось отредактировать сообщение: {tg_error_reason(_e)}."
        return "Готово, отредактировала сообщение."

    async def _action_delete_message(self, action: PendingAction) -> str:
        """payload (JSON) = {"chat": ..., "message_id": ...} — используется и
        под именем delete_message (своё сообщение), и delete_message_from_chat
        (чужое, требует прав администратора в этом чате — Telegram сам это проверит)."""
        try:
            p = json.loads(action.payload)
            entity = await self._resolve_peer(p["chat"])
            await self.client.delete_messages(entity, [int(p["message_id"])])
        except Exception as _e:
            logger.warning("Action delete_message failed for %r", action.payload, exc_info=True)
            return f"Не получилось удалить сообщение: {tg_error_reason(_e)}."
        return "Готово, удалила сообщение."

    async def _action_reply_to_message(self, action: PendingAction) -> str:
        """payload (JSON) = {"chat": ..., "message_id": ..., "text": ...}"""
        try:
            p = json.loads(action.payload)
            entity = await self._resolve_peer(p["chat"])
            await self.client.send_message(entity, str(p["text"]).strip(), reply_to=int(p["message_id"]))
        except Exception as _e:
            logger.warning("Action reply_to_message failed for %r", action.payload, exc_info=True)
            return f"Не получилось ответить на сообщение: {tg_error_reason(_e)}."
        return "Готово, ответила на сообщение."

    async def _resend_media(self, payload: str, expect_kind: Optional[str] = None, **send_kwargs) -> str:
        """Общий helper для send_photo/send_video/send_document/send_file/
        send_audio/send_voice/send_video_note.

        payload (JSON) = {"to": ..., "source_message_id": ..., "caption": ... (опционально)}

        Намеренно НЕ принимает произвольный путь к файлу на диске —
        source_message_id — id сообщения, которое владелец уже реально
        отправил Marin в их собственной переписке. Это исключает риск, что
        модель "придумает" путь вроде локального файла сессии/конфига и
        отправит его наружу: источник данных — только уже существующее
        сообщение в Telegram.
        """
        p = json.loads(payload)
        to_entity = await self._resolve_peer(p["to"])
        owner_chat = await self.client.get_entity(int(self.config.owner_id))
        src_msg = await self.client.get_messages(owner_chat, ids=int(p["source_message_id"]))
        caption = p.get("caption")
        if src_msg is None or not getattr(src_msg, "media", None):
            return "Не нашла у себя в переписке с тобой такое сообщение с файлом."
        if expect_kind == "photo" and not src_msg.photo:
            return "Это сообщение не с фото."
        if expect_kind == "video" and not (src_msg.video or src_msg.gif):
            return "Это сообщение не с видео."
        if expect_kind == "audio" and not getattr(src_msg, "audio", None):
            return "Это сообщение не с аудио."
        if expect_kind == "voice" and not getattr(src_msg, "voice", None):
            return "Это сообщение не с голосовым."
        if expect_kind == "video_note" and not getattr(src_msg, "video_note", None):
            return "Это сообщение не с видео-кружком."
        await self.client.send_file(to_entity, src_msg.media, caption=caption, **send_kwargs)
        self._record_own_channel_post(utils.get_peer_id(to_entity), preview=caption or "")
        return "Готово, отправила файл."

    async def _action_send_photo(self, action: PendingAction) -> str:
        try:
            return await self._resend_media(action.payload, expect_kind="photo")
        except Exception as _e:
            logger.warning("Action send_photo failed for %r", action.payload, exc_info=True)
            return f"Не получилось отправить фото: {tg_error_reason(_e)}."

    async def _action_send_video(self, action: PendingAction) -> str:
        try:
            return await self._resend_media(action.payload, expect_kind="video")
        except Exception as _e:
            logger.warning("Action send_video failed for %r", action.payload, exc_info=True)
            return f"Не получилось отправить видео: {tg_error_reason(_e)}."

    async def _action_send_document(self, action: PendingAction) -> str:
        try:
            return await self._resend_media(action.payload)
        except Exception as _e:
            logger.warning("Action send_document failed for %r", action.payload, exc_info=True)
            return f"Не получилось отправить файл: {tg_error_reason(_e)}."

    async def _action_schedule_message(self, action: PendingAction) -> str:
        """payload (JSON) = {"chat": ..., "timestamp": <unix seconds>, "text": ...}"""
        try:
            import datetime as _dt
            p = json.loads(action.payload)
            entity = await self._resolve_peer(p["chat"])
            when = _dt.datetime.fromtimestamp(int(p["timestamp"]), tz=_dt.timezone.utc)
            await self.client.send_message(entity, str(p["text"]).strip(), schedule=when)
        except Exception as _e:
            logger.warning("Action schedule_message failed for %r", action.payload, exc_info=True)
            return f"Не получилось запланировать сообщение: {tg_error_reason(_e)}."
        return "Готово, запланировала сообщение."

    async def _action_set_profile_name(self, action: PendingAction) -> str:
        """payload (JSON) = {"first_name": ..., "last_name": ... (опционально)}"""
        try:
            p = json.loads(action.payload)
            kwargs = {"first_name": str(p["first_name"]).strip()}
            if p.get("last_name"):
                kwargs["last_name"] = str(p["last_name"]).strip()
            await self.client(functions.account.UpdateProfileRequest(**kwargs))
        except Exception as _e:
            logger.warning("Action set_profile_name failed for %r", action.payload, exc_info=True)
            return f"Не получилось поменять имя: {tg_error_reason(_e)}."
        return "Готово, поменяла имя."

    async def _action_set_username(self, action: PendingAction) -> str:
        """payload = новый username (без @), пустая строка — убрать username."""
        try:
            username = action.payload.strip().lstrip("@")
            await self.client(functions.account.UpdateUsernameRequest(username=username))
        except Exception as _e:
            logger.warning("Action set_username failed for %r", action.payload, exc_info=True)
            return f"Не получилось поменять username: {tg_error_reason(_e)}."
        return f"Готово, username теперь: @{username}" if username else "Готово, убрала username."

    async def _find_owner_photo(self, source_id: Any = None, prefer_chat: Any = None):
        """Фото, которое прислал владелец. Сначала по явному id сообщения,
        иначе — последнее его фото: в целевом чате (он мог кинуть картинку
        прямо в группу, как на скриншотах), потом в личке с Марин.
        Раньше требовался точный id и только из лички — модель его не знала,
        и «поменяй фото группы на это» заканчивалось «скинь ещё разок»."""
        owner_id = int(self.config.owner_id)
        chats = []
        if prefer_chat is not None:
            chats.append(prefer_chat)
        try:
            chats.append(await self.client.get_entity(owner_id))
        except Exception:
            logger.debug("owner entity unavailable", exc_info=True)
        try:
            sid = int(str(source_id).strip()) if source_id not in (None, "", "last", "последнее") else None
        except (TypeError, ValueError):
            sid = None
        if sid is not None:
            for chat in chats:
                try:
                    msg = await self.client.get_messages(chat, ids=sid)
                except Exception:
                    continue
                if msg is not None and getattr(msg, "photo", None):
                    return msg
        for chat in chats:
            try:
                async for msg in self.client.iter_messages(chat, limit=40, from_user=owner_id):
                    if getattr(msg, "photo", None):
                        return msg
            except Exception:
                logger.debug("photo lookup failed in %r", chat, exc_info=True)
        return None

    async def _action_set_profile_photo(self, action: PendingAction) -> str:
        """payload = id сообщения с фото ИЛИ пусто/«last» — последнее фото владельца."""
        try:
            src_msg = await self._find_owner_photo(action.payload.strip())
            if src_msg is None:
                return "Не нашла фото, которое ты присылал — кинь картинку, и сразу поставлю."
            raw = await self.client.download_media(src_msg, file=bytes)
            uploaded = await self.client.upload_file(raw, file_name="profile.jpg")
            await self.client(functions.photos.UploadProfilePhotoRequest(file=uploaded))
        except Exception as _e:
            logger.warning("Action set_profile_photo failed for %r", action.payload, exc_info=True)
            return f"Не получилось поменять фото профиля: {tg_error_reason(_e)}."
        return "Готово, поменяла фото профиля."

    async def _action_create_channel(self, action: PendingAction) -> str:
        """payload (JSON) = {"title": ..., "about": ... (опц.), "is_group": bool (опц.)}"""
        title = ""
        try:
            p = json.loads(action.payload)
            title = str(p["title"]).strip()
            about = _public_text(p.get("about"))
            is_group = bool(p.get("is_group"))
            result = await self.client(functions.channels.CreateChannelRequest(
                title=title, about=about, megagroup=is_group,
            ))
            created = result.chats[0] if getattr(result, "chats", None) else None
            if created is not None:
                self._remember_own_channel(
                    utils.get_peer_id(created), title=title, username=getattr(created, "username", "") or "",
                )
        except Exception as _e:
            logger.warning("Action create_channel failed for %r", action.payload, exc_info=True)
            return f"Не получилось создать чат: {tg_error_reason(_e)}."
        return f"Готово, создала «{title}»."

    async def _action_edit_channel(self, action: PendingAction) -> str:
        """payload (JSON) = {"chat": ..., "title": ... (опц.), "about": ... (опц.)}"""
        try:
            p = json.loads(action.payload)
            entity = await self._resolve_peer(p["chat"])
            if p.get("title"):
                await self.client(functions.channels.EditTitleRequest(channel=entity, title=str(p["title"]).strip()))
            if _public_text(p.get("about")):
                await self.client(functions.messages.EditChatAboutRequest(peer=entity, about=_public_text(p["about"])))
        except Exception as _e:
            logger.warning("Action edit_channel failed for %r", action.payload, exc_info=True)
            return f"Не получилось изменить чат: {tg_error_reason(_e)}."
        return "Готово, изменила чат."

    async def _action_change_channel_title(self, action: PendingAction) -> str:
        """payload (JSON) = {"chat": ..., "title": ...}"""
        try:
            p = json.loads(action.payload)
            entity = await self._resolve_peer(p["chat"])
            await self.client(functions.channels.EditTitleRequest(channel=entity, title=str(p["title"]).strip()))
        except Exception as _e:
            logger.warning("Action change_channel_title failed for %r", action.payload, exc_info=True)
            return f"Не получилось поменять название: {tg_error_reason(_e)}."
        return "Готово, поменяла название."

    async def _action_change_channel_about(self, action: PendingAction) -> str:
        """payload (JSON) = {"chat": ..., "about": ...}"""
        try:
            p = json.loads(action.payload)
            entity = await self._resolve_peer(p["chat"])
            about = _public_text(p.get("about"))
            if not about:
                return "Не стала менять описание: текст был служебным, а не для подписчиков."
            await self.client(functions.messages.EditChatAboutRequest(peer=entity, about=about))
        except Exception as _e:
            logger.warning("Action change_channel_about failed for %r", action.payload, exc_info=True)
            return f"Не получилось поменять описание: {tg_error_reason(_e)}."
        return "Готово, поменяла описание."

    async def _action_change_channel_photo(self, action: PendingAction) -> str:
        """payload (JSON) = {"chat": ..., "source_message_id": ... (опц.)}.
        Без source_message_id берётся последнее фото владельца в этом чате
        или в личке. Работает и для каналов/супергрупп, и для обычных групп."""
        try:
            p = json.loads(action.payload)
            entity = await self._resolve_peer(p["chat"])
            src_msg = await self._find_owner_photo(p.get("source_message_id"), prefer_chat=entity)
            if src_msg is None:
                return "Не нашла фото, которое ты присылал — кинь картинку, и сразу поставлю."
            raw = await self.client.download_media(src_msg, file=bytes)
            uploaded = await self.client.upload_file(raw, file_name="chat_photo.jpg")
            photo = types.InputChatUploadedPhoto(file=uploaded)
            is_basic_group = getattr(entity, "megagroup", None) is None and getattr(entity, "broadcast", None) is None
            if is_basic_group:
                # обычная (не супер-) группа: channels.EditPhotoRequest для неё не работает
                await self.client(functions.messages.EditChatPhotoRequest(chat_id=entity.id, photo=photo))
            else:
                await self.client(functions.channels.EditPhotoRequest(channel=entity, photo=photo))
        except Exception as _e:
            logger.warning("Action change_channel_photo failed for %r", action.payload, exc_info=True)
            return f"Не получилось поменять фото чата: {tg_error_reason(_e)}."
        return "Готово, поменяла фото чата."

    async def _action_join_chat(self, action: PendingAction) -> str:
        """payload = username публичного чата/канала (без @)."""
        identifier = action.payload.strip().lstrip("@")
        try:
            entity = await self._resolve_peer(identifier)
            await self.client(functions.channels.JoinChannelRequest(channel=entity))
        except Exception:
            logger.warning("Action join_chat failed for %r", identifier, exc_info=True)
            return f"Не получилось вступить в «{identifier}»."
        return f"Готово, вступила в «{identifier}»."

    async def _action_restrict_user(self, action: PendingAction) -> str:
        """payload (JSON) = {"chat": ..., "username": ..., "permission": "..."}
        — запрещает ОДНО конкретное право (не полный бан): send_messages,
        send_media, send_stickers, send_links, invite_users, pin_messages,
        change_info."""
        allowed = {
            "send_messages", "send_media", "send_stickers", "send_links",
            "invite_users", "pin_messages", "change_info",
        }
        try:
            p = json.loads(action.payload)
            perm = str(p["permission"]).strip()
            if perm not in allowed:
                return f"Не знаю такого права ограничения: {perm}."
            chat = await self._resolve_peer(p["chat"])
            user = await self._resolve_peer(p["username"])
            await self.client.edit_permissions(chat, user, **{perm: True})
        except Exception as _e:
            logger.warning("Action restrict_user failed for %r", action.payload, exc_info=True)
            return f"Не получилось ограничить участника: {tg_error_reason(_e)}."
        return "Готово, ограничила участника."

    async def _action_edit_admin_rights(self, action: PendingAction) -> str:
        """payload (JSON) = {"chat": ..., "username": ..., "rights": ["right1", "right2", ...]}
        — даёт ТОЛЬКО перечисленные права (из набора, который поддерживает
        client.edit_admin): change_info, post_messages, edit_messages,
        delete_messages, ban_users, invite_users, pin_messages, add_admins,
        anonymous, manage_call."""
        allowed = {
            "change_info", "post_messages", "edit_messages", "delete_messages",
            "ban_users", "invite_users", "pin_messages", "add_admins",
            "anonymous", "manage_call",
        }
        try:
            p = json.loads(action.payload)
            rights = [str(r).strip() for r in (p.get("rights") or []) if str(r).strip()]
            unknown = [r for r in rights if r not in allowed]
            if unknown:
                return f"Не знаю таких прав: {', '.join(unknown)}."
            chat = await self._resolve_peer(p["chat"])
            user = await self._resolve_peer(p["username"])
            kwargs = {r: True for r in rights}
            await self.client.edit_admin(chat, user, is_admin=True, **kwargs)
        except Exception as _e:
            logger.warning("Action edit_admin_rights failed for %r", action.payload, exc_info=True)
            return f"Не получилось назначить права: {tg_error_reason(_e)}."
        return "Готово, обновила права администратора."

    # -- Этап 3: опросы, invite-links/join-requests, стикеры, медиа, альбомы,
    # scheduled messages ------------------------------------------------------

    async def _action_create_poll(self, action: PendingAction) -> str:
        """payload (JSON) = {"chat": ..., "question": ..., "options": ["opt1","opt2",...],
        "multiple": bool (опц.), "anonymous": bool (опц., по умолчанию true)}.

        В установленной версии Telethon (>=1.40,<2) схема Poll/PollAnswer
        могла как принимать question/answer как обычную строку, так и
        требовать TextWithEntities (это менялось между слоями TL). Без
        доступа к установленному пакету в этой среде я не могу однозначно
        проверить, какая версия схемы фактически активна, поэтому здесь
        рантайм-адаптация: если telethon.tl.types.TextWithEntities вообще
        существует в установленной версии — используем её (это надёжный
        сигнал, что Poll ожидает именно её), иначе — обычные строки."""
        try:
            p = json.loads(action.payload)
            question = str(p["question"]).strip()
            options = [str(o).strip() for o in p.get("options", []) if str(o).strip()]
            multiple = bool(p.get("multiple"))
            anonymous = p.get("anonymous", True)
            if len(options) < 2:
                return "Нужно минимум два варианта ответа."
            entity = await self._resolve_peer(p["chat"])

            use_entities = hasattr(types, "TextWithEntities")
            if use_entities:
                question_field = tl_new(types.TextWithEntities, text=question, entities=[])
                answers = [
                    tl_new(types.PollAnswer, text=tl_new(types.TextWithEntities, text=o, entities=[]), option=bytes([i]))
                    for i, o in enumerate(options)
                ]
            else:
                question_field = question
                answers = [tl_new(types.PollAnswer, text=o, option=bytes([i])) for i, o in enumerate(options)]

            # В установленном слое Telegram у Poll появилось обязательное
            # поле hash — прямой вызов падал TypeError, а tg_error_reason
            # выдавал это за «не хватило данных (чат или человек)».
            poll = tl_new(
                types.Poll, id=0, question=question_field, answers=answers,
                multiple_choice=multiple, public_voters=not anonymous,
            )
            await self.client.send_message(entity, file=tl_new(types.InputMediaPoll, poll=poll))
            self._record_own_channel_post(utils.get_peer_id(entity), preview=f"[опрос] {question}")
        except Exception as _e:
            logger.warning("Action create_poll failed for %r", action.payload, exc_info=True)
            return f"Не получилось создать опрос: {tg_error_reason(_e)}."
        return "Готово, создала опрос."

    async def _action_stop_poll(self, action: PendingAction) -> str:
        """payload (JSON) = {"chat": ..., "message_id": ...} — закрывает уже
        существующий опрос. Переиспользует реальный объект Poll из уже
        полученного сообщения (просто выставляет closed=True), а не собирает
        его заново — так полностью обходится вопрос про точную схему
        question/answers."""
        try:
            p = json.loads(action.payload)
            entity = await self._resolve_peer(p["chat"])
            msg_id = int(p["message_id"])
            msg = await self.client.get_messages(entity, ids=msg_id)
            poll = getattr(msg, "poll", None) if msg else None
            if poll is None:
                return "Не нашла опрос в этом сообщении."
            poll.closed = True
            await self.client.edit_message(entity, msg_id, file=types.InputMediaPoll(poll=poll))
        except Exception as _e:
            logger.warning("Action stop_poll failed for %r", action.payload, exc_info=True)
            return f"Не получилось закрыть опрос: {tg_error_reason(_e)}."
        return "Готово, закрыла опрос."

    async def _action_edit_invite_link(self, action: PendingAction) -> str:
        """payload (JSON) = {"chat": ..., "link": ..., "title": ... (опц.),
        "usage_limit": ... (опц.)}"""
        try:
            p = json.loads(action.payload)
            entity = await self._resolve_peer(p["chat"])
            kwargs: Dict[str, Any] = {"peer": entity, "link": str(p["link"]).strip()}
            if p.get("usage_limit") is not None:
                kwargs["usage_limit"] = int(p["usage_limit"])
            if p.get("title"):
                kwargs["title"] = str(p["title"]).strip()
            await self.client(functions.messages.EditExportedChatInviteRequest(**kwargs))
        except Exception as _e:
            logger.warning("Action edit_invite_link failed for %r", action.payload, exc_info=True)
            return f"Не получилось изменить ссылку-приглашение: {tg_error_reason(_e)}."
        return "Готово, изменила ссылку-приглашение."

    async def _action_revoke_invite_link(self, action: PendingAction) -> str:
        """payload (JSON) = {"chat": ..., "link": ...}"""
        try:
            p = json.loads(action.payload)
            entity = await self._resolve_peer(p["chat"])
            await self.client(functions.messages.EditExportedChatInviteRequest(
                peer=entity, link=str(p["link"]).strip(), revoked=True,
            ))
        except Exception as _e:
            logger.warning("Action revoke_invite_link failed for %r", action.payload, exc_info=True)
            return f"Не получилось отозвать ссылку-приглашение: {tg_error_reason(_e)}."
        return "Готово, отозвала ссылку-приглашение."

    async def _action_approve_join_request(self, action: PendingAction) -> str:
        """payload (JSON) = {"chat": ..., "username": ...} — требует прав
        администратора в чате."""
        try:
            p = json.loads(action.payload)
            chat = await self._resolve_peer(p["chat"])
            user = await self._resolve_peer(p["username"])
            await self.client(functions.messages.HideChatJoinRequestRequest(
                peer=chat, user_id=user, approved=True,
            ))
        except Exception as _e:
            logger.warning("Action approve_join_request failed for %r", action.payload, exc_info=True)
            return f"Не получилось одобрить заявку на вступление: {tg_error_reason(_e)}."
        return "Готово, одобрила заявку на вступление."

    async def _action_decline_join_request(self, action: PendingAction) -> str:
        """payload (JSON) = {"chat": ..., "username": ...} — требует прав
        администратора в чате."""
        try:
            p = json.loads(action.payload)
            chat = await self._resolve_peer(p["chat"])
            user = await self._resolve_peer(p["username"])
            await self.client(functions.messages.HideChatJoinRequestRequest(
                peer=chat, user_id=user, approved=False,
            ))
        except Exception as _e:
            logger.warning("Action decline_join_request failed for %r", action.payload, exc_info=True)
            return f"Не получилось отклонить заявку на вступление: {tg_error_reason(_e)}."
        return "Готово, отклонила заявку на вступление."

    async def _action_send_voice_message(self, action: PendingAction) -> str:
        """payload (JSON) = {"chat": ..., "text": "..."} — text это то, что
        она СКАЖЕТ (реальный текст реплики, не описание тона/интонации).
        В отличие от send_voice (пересылка уже присланного файла), здесь
        голос генерируется заново через ElevenLabs (см. voice.py)."""
        try:
            p = json.loads(action.payload)
            entity = await self._resolve_peer(p["chat"])
            text = str(p.get("text") or "").strip()

            generator = self._get_voice_generator()
            result = await generator.generate(text)

            ext = result.ext
            uploaded = await self.client.upload_file(result.audio_bytes, file_name=f"voice{ext}")
            await self.client.send_file(entity, uploaded, voice_note=result.is_voice_note)
            self._record_own_channel_post(utils.get_peer_id(entity), preview="[голосовое]")
        except VoiceGenerationError as e:
            # подробности — в лог; владельцу — по-человечески (раньше в чат уходило
            # «OpenRouterVoiceGenerator: … HTTP 400: {"error": …}»)
            logger.info("send_voice_message declined/unavailable: %s", e)
            if "пустой текст" in str(e):
                return "Не поняла, что сказать голосом."
            return "Не получилось записать голосовое — голос сейчас недоступен, напишу текстом."
        except Exception as _e:
            logger.warning("Action send_voice_message failed for %r", action.payload, exc_info=True)
            return f"Не получилось отправить голосовое: {tg_error_reason(_e)}."
        return "Готово, отправила голосовое."

    _DICE_EMOJI = ("🎲", "🎯", "🏀", "⚽", "🎳", "🎰")

    async def _action_send_dice(self, action: PendingAction) -> str:
        """payload (JSON) = {"chat": ..., "emoji": "🎲"} — игровой анимированный эмодзи
        Telegram (кубик, дартс, баскетбол, футбол, боулинг, слоты); результат
        случайный и виден всем."""
        p: dict = {}
        try:
            p = json.loads(action.payload)
            emoji = str(p.get("emoji") or "🎲").strip()
            if emoji not in self._DICE_EMOJI:
                return "Такого броска нет — можно: " + " ".join(self._DICE_EMOJI)
            entity = await self._resolve_peer(p["chat"])
            await self.client.send_message(entity, file=tl_new(types.InputMediaDice, emoticon=emoji))
        except Exception as _e:
            logger.warning("Action send_dice failed for %r", action.payload, exc_info=True)
            return f"Не получилось кинуть {p.get('emoji', '🎲') if isinstance(p, dict) else '🎲'}: {tg_error_reason(_e)}."
        return f"Готово, кинула {emoji}."

    async def _action_post_story(self, action: PendingAction) -> str:
        """payload (JSON) = {"caption": "...", "prompt": "где/что делает" (опц.)} —
        публикует историю (stories) в своём профиле: свежее селфи по референсу
        (кадр — от режиссёра селфи), подпись, видно всем, 24 часа."""
        import random as _random
        try:
            p = json.loads(action.payload or "{}")
            caption = str(p.get("caption") or "").strip()[:200]
            prompt = str(p.get("prompt") or "").strip()
            scene = await self.selfie_director.scene_for(caption or prompt, prompt)
            image = await self._get_selfie_generator().generate(scene, reference_image_b64=self._get_selfie_reference())
            uploaded = await self.client.upload_file(image, file_name="story.jpg")
            request = tl_new(
                functions.stories.SendStoryRequest,
                peer=types.InputPeerSelf(),
                media=tl_new(types.InputMediaUploadedPhoto, file=uploaded),
                privacy_rules=[types.InputPrivacyValueAllowAll()],
                caption=caption or None,
                random_id=_random.getrandbits(62),
                period=86400,
            )
            await self.client(request)
        except SelfieGenerationError as e:
            return str(e)
        except Exception as _e:
            logger.warning("Action post_story failed for %r", action.payload, exc_info=True)
            return f"Не получилось выложить историю: {tg_error_reason(_e)}."
        return "Готово, выложила историю."

    async def _action_send_selfie(self, action: PendingAction) -> str:
        """payload (JSON) = {"chat": ..., "prompt": "...", "caption": ... (опц.)}
        prompt — короткое описание СИТУАЦИИ/повода ("дома вечером", "на
        прогулке", "делаю кофе"), не инструкция по внешности — лицо и стиль
        всегда берутся из referen-фото + SELFIE_STYLE_GUARDRAIL (см.
        selfie.py), это не настраивается через payload."""
        try:
            p = json.loads(action.payload)
            entity = await self._resolve_peer(p["chat"])
            prompt = str(p.get("prompt") or "").strip()
            caption = p.get("caption")

            generator = self._get_selfie_generator()
            scene = await self.selfie_director.scene_for(str(caption or prompt), prompt)
            image_bytes = await generator.generate(scene, reference_image_b64=self._get_selfie_reference())

            uploaded = await self.client.upload_file(image_bytes, file_name="selfie.jpg")
            await self.client.send_file(entity, uploaded, caption=caption)
            self._record_own_channel_post(utils.get_peer_id(entity), preview=caption or "[селфи]")
        except SelfieGenerationError as e:
            logger.info("send_selfie declined/unavailable: %s", e)
            return str(e)
        except Exception as _e:
            logger.warning("Action send_selfie failed for %r", action.payload, exc_info=True)
            return f"Не получилось отправить селфи: {tg_error_reason(_e)}."
        return "Готово, отправила селфи."

    async def _action_send_sticker(self, action: PendingAction) -> str:
        """payload (JSON) = {"chat": ..., "index": ...} — index из уже
        собранного каталога стикеров этого аккаунта (self._sticker_catalog),
        не произвольный файл. Индексация с 1, как в остальных местах этого файла."""
        try:
            p = json.loads(action.payload)
            entity = await self._resolve_peer(p["chat"])
            idx = int(p["index"])
            if not (1 <= idx <= len(self._sticker_catalog)):
                return f"В каталоге нет стикера №{idx}."
            await self.client.send_file(entity, self._sticker_catalog[idx - 1])
            self._record_own_channel_post(utils.get_peer_id(entity), preview="[стикер]")
        except Exception as _e:
            logger.warning("Action send_sticker failed for %r", action.payload, exc_info=True)
            return f"Не получилось отправить стикер: {tg_error_reason(_e)}."
        return "Готово, отправила стикер."

    async def _action_send_audio(self, action: PendingAction) -> str:
        try:
            return await self._resend_media(action.payload, expect_kind="audio")
        except Exception as _e:
            logger.warning("Action send_audio failed for %r", action.payload, exc_info=True)
            return f"Не получилось отправить аудио: {tg_error_reason(_e)}."

    async def _action_send_voice(self, action: PendingAction) -> str:
        try:
            return await self._resend_media(action.payload, expect_kind="voice", voice_note=True)
        except Exception as _e:
            logger.warning("Action send_voice failed for %r", action.payload, exc_info=True)
            return f"Не получилось отправить голосовое: {tg_error_reason(_e)}."

    async def _action_send_video_note(self, action: PendingAction) -> str:
        try:
            return await self._resend_media(action.payload, expect_kind="video_note", video_note=True)
        except Exception as _e:
            logger.warning("Action send_video_note failed for %r", action.payload, exc_info=True)
            return f"Не получилось отправить видео-кружок: {tg_error_reason(_e)}."

    async def _action_send_album(self, action: PendingAction) -> str:
        """payload (JSON) = {"to": ..., "source_message_ids": [id1, id2, ...],
        "caption": ... (опц.)} — как и одиночные send_photo/send_video/etc.,
        источник только сообщения, которые владелец уже прислал Marin
        (никаких произвольных путей)."""
        try:
            p = json.loads(action.payload)
            ids = [int(x) for x in p.get("source_message_ids", [])]
            if len(ids) < 2:
                return "Для альбома нужно минимум два сообщения-источника."
            caption = p.get("caption")
            to_entity = await self._resolve_peer(p["to"])
            owner_chat = await self.client.get_entity(int(self.config.owner_id))
            media_list = []
            for mid in ids:
                src_msg = await self.client.get_messages(owner_chat, ids=mid)
                if src_msg is None or not getattr(src_msg, "media", None):
                    return f"Не нашла у себя в переписке с тобой сообщение {mid} с файлом."
                media_list.append(src_msg.media)
            await self.client.send_file(to_entity, media_list, caption=caption)
            self._record_own_channel_post(utils.get_peer_id(to_entity), preview=caption or "[альбом]")
        except Exception as _e:
            logger.warning("Action send_album failed for %r", action.payload, exc_info=True)
            return f"Не получилось отправить альбом: {tg_error_reason(_e)}."
        return "Готово, отправила альбом."

    async def _action_delete_scheduled_message(self, action: PendingAction) -> str:
        """payload (JSON) = {"chat": ..., "message_id": ...} — отдельный от
        обычного delete_message Request, т.к. отложенные сообщения живут в
        другом пространстве id."""
        try:
            p = json.loads(action.payload)
            entity = await self._resolve_peer(p["chat"])
            await self.client(functions.messages.DeleteScheduledMessagesRequest(
                peer=entity, id=[int(p["message_id"])],
            ))
        except Exception as _e:
            logger.warning("Action delete_scheduled_message failed for %r", action.payload, exc_info=True)
            return f"Не получилось удалить отложенное сообщение: {tg_error_reason(_e)}."
        return "Готово, удалила отложенное сообщение."

    async def _action_edit_scheduled_message(self, action: PendingAction) -> str:
        """payload (JSON) = {"chat": ..., "message_id": ..., "text": ...}"""
        try:
            p = json.loads(action.payload)
            entity = await self._resolve_peer(p["chat"])
            await self.client.edit_message(entity, int(p["message_id"]), str(p["text"]).strip())
        except Exception as _e:
            logger.warning("Action edit_scheduled_message failed for %r", action.payload, exc_info=True)
            return f"Не получилось отредактировать отложенное сообщение: {tg_error_reason(_e)}."
        return "Готово, отредактировала отложенное сообщение."
