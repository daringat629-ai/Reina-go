"""Deterministic owner dot/slash commands.

Mixin of MarinTelegramClient — relies on attributes created in
MarinTelegramClient.__init__ (self.client, self.engine, self.config, ...).
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from .. import persistence
from ..memory.memory_graph import NodeType
from telethon import functions, utils

from .settings import (
    GOALS_LIST_COMMANDS,
    GOAL_AUTOAPPROVE_OFF_RE,
    GOAL_AUTOAPPROVE_ON_RE,
    GOAL_CANCEL_RE,
    GOAL_PAUSE_RE,
    GOAL_RESUME_RE,
    GOAL_START_RE,
    OWN_CHANNEL_ASSIGN_RE,
    PROFILE_NAME_RE,
    PROFILE_USERNAME_RE,
    RELAY_COMMAND_RE,
    STATE_IMPORT_FILE,
    VISION_ENABLED,
    VISION_MODEL,
)

logger = logging.getLogger("marin_x.telegram")

class OwnerCommandsMixin:
    async def _handle_relay_command(self, event, text: str) -> bool:
        """"/relay @username текст" — реально отправляет постороннему
        человеку сообщение с ЧЕСТНЫМ раскрытием, что это передано от
        владельца через Марин, а не выдаёт себя за личное сообщение от
        Марин лично. Только owner может вызвать (гарантируется тем, что
        сюда попадают только сообщения уже прошедшего is_owner-проверку)."""
        match = RELAY_COMMAND_RE.match((text or "").strip())
        if not match:
            return False
        username, message_text = match.group(1), match.group(2).strip()
        if not message_text:
            await event.reply("Не вижу текста для передачи — формат: /relay @username текст")
            return True
        try:
            entity = await self._resolve_peer(username)
        except Exception:
            logger.warning("Relay: could not resolve @%s", username, exc_info=True)
            await event.reply(f"Не смогла найти @{username} в Telegram — проверь юзернейм.")
            return True
        disclosed = (
            f"Привет! Меня попросил передать сообщение мой владелец {self.owner_name}: "
            f"«{message_text}»"
        )
        try:
            await self.client.send_message(entity, disclosed)
        except Exception:
            logger.warning("Relay: could not send message to @%s", username, exc_info=True)
            await event.reply(f"Не получилось отправить @{username} — Telegram отказал (возможно, у него закрыты личные сообщения).")
            return True
        logger.info("Relayed message to @%s", username)
        await event.reply(f"Готово, передала @{username}.")
        return True

    async def _handle_goals_command(self, event, text: str) -> bool:
        """Stage 4: owner-only команды над автономными целями — статус,
        пауза/продолжить/отмена по короткому id (первые символы Goal.id).
        Та же command-инфраструктура, что уже используется для
        DIARY_COMMANDS/STATUS_COMMANDS и т.п. — не отдельный бот."""
        stripped = (text or "").strip()
        lowered = stripped.lower()
        owner_id = str(self.config.owner_id)

        if lowered in GOALS_LIST_COMMANDS:
            await event.reply(self.goal_executor.list_status_text(owner_id))
            return True

        for pattern, action_name in (
            (GOAL_PAUSE_RE, "pause_goal"),
            (GOAL_RESUME_RE, "resume_goal"),
            (GOAL_CANCEL_RE, "cancel_goal"),
        ):
            m = pattern.match(stripped)
            if not m:
                continue
            short_id = m.group(1)
            goal = self.goal_executor.find_by_short_id(short_id, owner_id)
            if goal is None:
                await event.reply(f"Не нашла автономную цель с id «{short_id}».")
                return True
            ok = getattr(self.engine.goal_set, action_name)(goal.id)
            if not ok:
                await event.reply(f"Не получилось это сделать для цели «{goal.description}» (неподходящий статус?).")
                return True
            verb = {"pause_goal": "поставила на паузу", "resume_goal": "продолжаю", "cancel_goal": "отменила"}[action_name]
            log_tag = {"pause_goal": "paused", "resume_goal": "resumed", "cancel_goal": "cancelled"}[action_name]
            logger.info("[GOAL] %s goal_id=%s", log_tag, goal.id)
            await event.reply(f"Готово, {verb} цель «{goal.description}».")
            return True

        for pattern, new_value in ((GOAL_AUTOAPPROVE_ON_RE, True), (GOAL_AUTOAPPROVE_OFF_RE, False)):
            m = pattern.match(stripped)
            if not m:
                continue
            target = m.group(1)
            # 1) Канал (id/@username/название) -> автопостинг через
            #    ChannelPublisher: свежий пост на каждом цикле, без плана и
            #    без подтверждений.
            channel = self.publisher._match_hint(target)
            if channel is not None or not self.goal_executor.find_by_short_id(target, owner_id):
                reply = await self.publisher.set_autopost(new_value, channel_hint=target)
                await event.reply(reply)
                return True
            # 2) Иначе это id автономной цели (.цель ...) — переключаем её
            #    auto_approve, как раньше.
            goal = self.goal_executor.find_by_short_id(target, owner_id)
            goal.auto_approve = new_value
            goal.updated_at = time.time()
            logger.info("[GOAL] auto_approve=%s goal_id=%s", new_value, goal.id)
            await event.reply(
                f"Готово. Цель «{goal.description}» теперь публикует без подтверждения."
                if new_value else f"Готово, вернула подтверждение для цели «{goal.description}»."
            )
            return True

        return False

    async def _handle_own_channel_command(self, event, text: str) -> bool:
        """'.мойканал <id/username/ссылка>' — назначает УЖЕ существующий
        канал/группу "своим", без создания нового. Закрывает дыру: до
        этого запомнить канал как свой можно было только пройдя через
        create_channel — если канал уже есть, каждый раз приходилось
        напоминать id заново."""
        m = OWN_CHANNEL_ASSIGN_RE.match((text or "").strip())
        if not m:
            return False
        target = m.group(1).strip().lstrip("@")
        try:
            entity = await self._resolve_peer(target)
        except Exception:
            logger.warning("own-channel assign: could not resolve %r", target, exc_info=True)
            await event.reply(f"Не смогла найти «{target}» — проверь id/username/ссылку.")
            return True
        is_channel_or_group = bool(getattr(entity, "broadcast", False) or getattr(entity, "megagroup", False)
                                    or type(entity).__name__ in ("Chat", "Channel"))
        if not is_channel_or_group:
            await event.reply(f"«{target}» — это не канал и не группа, назначить как «свой канал» нельзя.")
            return True
        chat_id = utils.get_peer_id(entity)
        title = getattr(entity, "title", "") or ""
        username = getattr(entity, "username", "") or ""
        self._remember_own_channel(chat_id, title=title, username=username)
        await event.reply(f"Готово, теперь считаю «{title or target}» своим каналом.")
        return True

    async def _handle_goal_start_command(self, event, text: str, owner_id: str) -> bool:
        """'.цель <текст>' / '/goal <текст>' — гарантированно создаёт
        автономную цель (Stage 4), в отличие от <<<AUTOGOAL:...>>>, который
        зависит от того, распознает ли модель в разговоре повод для этого.
        Реальное планирование, как и у AUTOGOAL, происходит позже — на
        следующем тике scheduler'а, не прямо тут."""
        m = GOAL_START_RE.match((text or "").strip())
        if not m:
            return False
        description = m.group(1).strip()
        if not description:
            await event.reply("Нужно описание цели: «.цель создай канал про котиков и веди его».")
            return True
        goal_id = self.goal_executor.create_goal_from_description(description, owner_id)
        await event.reply(
            f"Готово, взяла в работу цель «{description}» [{goal_id[:8]}]. "
            f"Построю план на ближайшем тике: посты в свои каналы делаю сама, а админские шаги "
            f"(права, баны, инвайты) спрошу. Статус — /goals."
        )
        return True

    async def _handle_profile_command(self, event, text: str) -> bool:
        """/setname <имя> и /setusername <username> — меняют собственный
        профиль аккаунта. Owner-only, реальный вызов Telegram API,
        честный отчёт об успехе/ошибке."""
        name_match = PROFILE_NAME_RE.match((text or "").strip())
        if name_match:
            new_name = name_match.group(1).strip()[:64]
            try:
                await self.client(functions.account.UpdateProfileRequest(first_name=new_name))
                await event.reply(f"Готово, теперь я {new_name}.")
            except Exception:
                logger.exception("Could not update profile name")
                await event.reply("Не получилось сменить имя — Telegram отказал.")
            return True
        username_match = PROFILE_USERNAME_RE.match((text or "").strip())
        if username_match:
            new_username = username_match.group(1)
            try:
                await self.client(functions.account.UpdateUsernameRequest(username=new_username))
                await event.reply(f"Готово, теперь я @{new_username}.")
            except Exception:
                logger.exception("Could not update username")
                await event.reply("Не получилось сменить юзернейм — возможно, занят или недопустим.")
            return True
        return False

    async def _handle_export_command(self, event) -> None:
        """/export — весь снимок Марин (память/beliefs/goals/world/social/
        personality из ядра + Telegram-наблюдатель + реестр медиа-паков)
        одним файлом, чтобы перенести в другое окружение: скопировать файл
        рядом с кодом там и запустить — см. STATE_IMPORT_FILE в start()."""
        try:
            bundle = {
                "format_version": persistence.EXPORT_FORMAT_VERSION,
                "exported_at": time.time(),
                "engine": persistence.export_engine_state(self.engine),
                "observer": self.observer.to_dict(),
                "media_packs": self._media_packs,
            }
            tmp_path = f"marin_export_{int(time.time())}.json"
            with open(tmp_path, "w", encoding="utf-8") as fh:
                json.dump(bundle, fh, ensure_ascii=False)
            size_kb = os.path.getsize(tmp_path) / 1024
            await self.client.send_file(
                event.chat_id, tmp_path,
                caption=(
                    f"Полный снимок ({size_kb:.0f} КБ): память={len(self.engine.memory)} узлов, "
                    f"beliefs={len(self.engine.beliefs.all())}, цели={len(self.engine.goal_set.goals)}, "
                    f"люди={len(self.observer.people)}, паков={len(self._media_packs)}.\n"
                    f"Чтобы перенести: скопируй этот файл рядом с кодом в новом окружении под именем "
                    f"«{STATE_IMPORT_FILE}» и запусти бота — подхватится сам при старте. "
                    f"Либо пришли этот файл мне (с подписью /import) прямо здесь же."
                ),
            )
            os.remove(tmp_path)
        except Exception:
            logger.exception("Export command failed")
            await event.reply("Не получилось собрать экспорт — что-то упало.")

    async def _load_state_bundle_bytes(self, raw: bytes) -> str:
        data = json.loads(raw.decode("utf-8"))
        engine_counts = persistence.import_engine_state(self.engine, data.get("engine", {}))
        observer_count = self.observer.merge_from_dict(data.get("observer", {}))
        incoming_packs = data.get("media_packs", {})
        if incoming_packs:
            self._media_packs.update(incoming_packs)
            self._save_media_pack_registry()
            await self._load_media_catalog()
            asyncio.create_task(self._ensure_vision_catalog())
        return (
            f"Импортировано: память +{engine_counts['memory_nodes']}, "
            f"beliefs +{engine_counts['beliefs']}, цели +{engine_counts['goals']}, "
            f"world entities +{engine_counts['world_entities']}, "
            f"отношения +{engine_counts['social_nodes']}, "
            f"события наблюдателя +{observer_count}, "
            f"паков всего={len(self._media_packs)}."
        )

    async def _handle_import_command(self, event) -> bool:
        """/import — либо файл приложен к этому же сообщению, либо это реплай
        на сообщение с файлом (напр. тем, что прислал /export). Мёрджит в
        уже текущее состояние, не затирает его."""
        target_event = event
        if getattr(event, "document", None) is None:
            reply = None
            try:
                reply = await event.get_reply_message()
            except Exception:
                reply = None
            if reply is not None and getattr(reply, "document", None) is not None:
                target_event = reply
        if getattr(target_event, "document", None) is None:
            await event.reply("Не вижу файл для импорта — приложи файл экспорта к этой команде или ответь на сообщение с ним.")
            return True
        try:
            raw = await target_event.download_media(bytes)
            summary = await self._load_state_bundle_bytes(raw)
            await event.reply(f"Готово. {summary}")
        except Exception:
            logger.exception("Import command failed")
            await event.reply("Не получилось импортировать — файл повреждён или не в том формате.")
        return True

    def _build_dashboard_html(self) -> str:
        """Собирает самодостаточный HTML-снимок внутреннего состояния —
        честно показывает то, что реально есть (theory_of_mind сейчас
        нигде не наполняется — см. дашборд ниже, это не скрыто)."""
        import html as html_lib

        def esc(s: str) -> str:
            return html_lib.escape(str(s))

        def bar(value: float, color: str = "#7c9cff") -> str:
            pct = max(0, min(100, round(value * 100)))
            return (
                f'<div style="background:#2a2a35;border-radius:4px;overflow:hidden;height:10px;width:160px;display:inline-block;vertical-align:middle;">'
                f'<div style="background:{color};height:100%;width:{pct}%;"></div></div> '
                f'<span style="color:#aaa;font-size:12px;">{value:.2f}</span>'
            )

        # --- Memory graph ---
        nodes = self.engine.memory.all_nodes()
        type_counts = {t.value: 0 for t in NodeType}
        for n in nodes:
            type_counts[n.type.value] = type_counts.get(n.type.value, 0) + 1
        memory_rows = "".join(
            f"<tr><td>{esc(k)}</td><td>{v}</td></tr>" for k, v in type_counts.items() if v
        )

        # --- Beliefs ---
        beliefs = sorted(self.engine.beliefs.all(), key=lambda b: b.confidence, reverse=True)[:30]
        belief_rows = "".join(
            f"<tr><td>{esc(b.statement[:80])}</td><td>{bar(b.confidence)}</td>"
            f"<td>{esc(b.source_type.value)}</td><td>{'✓' if b.confirmed else ''}</td></tr>"
            for b in beliefs
        )
        open_contradictions = len(self.engine.beliefs.open_contradictions())

        # --- Relationships (SocialModel) ---
        rel_rows = ""
        for actor_id in self.engine.social.known_actors():
            node = self.engine.social.get_or_create(actor_id)
            rel = node.relationship
            rel_rows += (
                f"<tr><td>{esc(actor_id)}</td><td>{bar(rel.trust, '#7cff9c')}</td>"
                f"<td>{bar(rel.closeness, '#ffcf7c')}</td><td>{rel.interaction_count}</td></tr>"
            )

        # --- Goals ---
        goal_rows = "".join(
            f"<tr><td>{esc(g.description)}</td><td>{esc(g.level.value)}</td>"
            f"<td>{bar(g.progress, '#7cd4ff')}</td><td>{'да' if g.active else 'нет'}</td></tr>"
            for g in self.engine.goal_set.goals.values()
        )

        # --- Prediction error trend (текущее окно с последней рефлексии) ---
        trace = list(self.engine._tick_trace_window)
        trend_points = ""
        if trace:
            w, h, pad = 600, 100, 10
            max_err = max((t.prediction_error for t in trace), default=1.0) or 1.0
            step = (w - 2 * pad) / max(1, len(trace) - 1)
            pts = [
                f"{pad + i * step:.1f},{h - pad - (t.prediction_error / max_err) * (h - 2 * pad):.1f}"
                for i, t in enumerate(trace)
            ]
            trend_points = (
                f'<svg width="{w}" height="{h}" style="background:#20202a;border-radius:6px;">'
                f'<polyline fill="none" stroke="#ff7c7c" stroke-width="2" points="{" ".join(pts)}"/></svg>'
            )
        else:
            trend_points = "<p style='color:#888'>Окно пусто — рефлексия ещё не запускалась или только что прошла.</p>"

        # --- Person Model (Telegram-наблюдатель) ---
        person_html = esc(self.observer.person_summary(limit=10)).replace("\n", "<br>")

        return f"""<!DOCTYPE html>
<html lang="ru"><head><meta charset="utf-8"><title>Marin — Dashboard</title>
<style>
body {{ background:#15151c; color:#e8e8ef; font-family: -apple-system, Segoe UI, sans-serif; padding: 24px; }}
h1 {{ font-size: 20px; }} h2 {{ font-size: 15px; color:#9fa8ff; margin-top: 28px; border-bottom: 1px solid #333; padding-bottom: 6px; }}
table {{ border-collapse: collapse; width: 100%; margin-top: 8px; }}
td, th {{ padding: 5px 8px; text-align: left; border-bottom: 1px solid #26262f; font-size: 13px; }}
.note {{ color:#888; font-size: 12px; }}
</style></head><body>
<h1>📊 Marin — снимок внутреннего состояния</h1>
<p class="note">Сгенерировано: {esc(time.strftime('%Y-%m-%d %H:%M:%S'))}</p>

<h2>Memory Graph ({len(nodes)} узлов всего)</h2>
<table><tr><th>Тип</th><th>Количество</th></tr>{memory_rows or '<tr><td colspan=2>пусто</td></tr>'}</table>

<h2>Beliefs (топ-30 по confidence, всего {len(self.engine.beliefs.all())}, открытых противоречий: {open_contradictions})</h2>
<table><tr><th>Утверждение</th><th>Confidence</th><th>Источник</th><th>Подтв.</th></tr>{belief_rows or '<tr><td colspan=4>пусто</td></tr>'}</table>

<h2>Relationships (SocialModel)</h2>
<table><tr><th>Actor</th><th>Trust</th><th>Closeness</th><th>Взаимодействий</th></tr>{rel_rows or '<tr><td colspan=4>пусто</td></tr>'}</table>

<h2>Goals ({len(self.engine.goal_set.goals)})</h2>
<table><tr><th>Описание</th><th>Уровень</th><th>Прогресс</th><th>Активна</th></tr>{goal_rows or '<tr><td colspan=4>пусто</td></tr>'}</table>

<h2>Prediction error (текущее окно, {len(trace)} тиков с последней рефлексии)</h2>
{trend_points}

<h2>Person Model (Telegram-наблюдатель)</h2>
<p>{person_html}</p>

<h2>Theory of Mind</h2>
<p class="note">Пока нигде не наполняется — SocialModel.tom создан, но ни один
<code>TheoryOfMindEntry</code> не добавлен ни в одном месте кода. Показано честно,
не скрыто: если нужно, чтобы Марин реально строила гипотезы о том, что думает
о ней собеседник — это отдельная доработка (маркер по аналогии с BELIEF/PERSON).</p>
</body></html>"""

    async def _handle_dashboard_command(self, event) -> None:
        try:
            html_content = self._build_dashboard_html()
            path = f"marin_dashboard_{int(time.time())}.html"
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(html_content)
            await self.client.send_file(
                event.chat_id, path,
                caption="Снимок состояния — открой файл в браузере (офлайн, без интернета).",
            )
            os.remove(path)
        except Exception:
            logger.exception("Dashboard command failed")
            await event.reply("Не получилось собрать дашборд — что-то упало.")

    async def _handle_status_command(self, event) -> None:
        """/status — реальная диагностика, а не просто "я работаю". Собирает
        живые цифры из всех подсистем, которые были подключены за эту сессию
        доработок: BeliefStore, GoalSet, WorldModel, Person Model, каталог
        медиа, реальный список диалогов."""
        try:
            open_contradictions = len(self.engine.beliefs.open_contradictions())
            total_beliefs = len(self.engine.beliefs.all())
            active_goals = len(self.engine.goal_set.active_goals())
            memory_size = len(self.engine.memory)
            known_people = len(self.observer.people)
            known_chats = len(self.observer.chats)
            has_api_key = bool(os.getenv("MARIN_OPENROUTER_API_KEY"))
            pending_actions = self.actions.pending_count()

            lines = [
                "📊 Статус Марин",
                f"Telegram: OK (@{getattr(await self.client.get_me(), 'username', '?')}, "
                f"premium={'да' if self._is_premium else 'нет'})",
                f"LLM: {'ключ задан' if has_api_key else 'НЕТ КЛЮЧА'} (модель={os.getenv('MARIN_OPENROUTER_MODEL', '?')})",
                f"Vision: {'включён' if VISION_ENABLED else 'выключен'} (модель={VISION_MODEL})",
                f"Память: {memory_size} узлов, {total_beliefs} фактов/убеждений "
                f"({open_contradictions} неразрешённых противоречий)",
                f"Цели (GoalSet): {active_goals} активных",
                f"Обучение: паттернов={len(self.engine.learner.patterns.patterns)}, "
                f"Q(intent,action)={len(self.engine.learner.action_values.values)}, "
                f"разобранных реакций={sum(self.engine.learner.count_by_source.values())}",
                f"Люди: {known_people} известных профилей, {known_chats} чатов замечено",
                f"Каталог медиа: стикеров={len(self._sticker_catalog)}, "
                f"custom emoji={len(self._custom_emoji_catalog)}, паков={len(self._media_packs)}",
                f"Ожидают подтверждения (действия): {pending_actions}",
                self._dialogs_summary or "Диалоги: ещё не подгружались в этой сессии",
            ]
            await event.reply("\n".join(lines))
        except Exception:
            logger.exception("Status command failed")
            await event.reply("Не смогла собрать статус — что-то упало при сборе диагностики.")

    async def _handle_why_command(self, event) -> None:
        """/why — техническая метакогниция последнего тика (не "самосознание"):
        интерпретация, знаю/предполагаю/не знаю, уверенность, почему это
        действие, что оказалось ошибочным и какие закономерности выучены."""
        try:
            text = self.engine.explain_last()
            patterns = self.engine.learned_patterns(limit=3)
            if patterns:
                text += "\n\nВыученные паттерны:\n" + "\n".join(f"• {p}" for p in patterns)
            await event.reply(text[:3900])
        except Exception:
            logger.exception("Why command failed")
            await event.reply("Не смогла собрать разбор последнего хода.")

    async def _handle_diary_command(self, event) -> None:
        entries = self.engine.diary.recent(limit=3)
        if not entries:
            await event.reply("Дневник пока пуст — ещё не было периода тишины, чтобы его написать.")
            return
        for entry in reversed(entries):  # от старых к новым
            ts = time.strftime("%d.%m %H:%M", time.localtime(entry.t_created))
            await event.reply(f"📔 {entry.period_label} ({ts})\n\n{entry.text}")
            await asyncio.sleep(0.4)

    async def _handle_thoughts_command(self, event) -> None:
        try:
            entry = await asyncio.to_thread(self.engine.diary_writer.write_live_thought)
        except Exception:
            logger.exception("Failed to generate a live thought")
            await event.reply("Не получилось сформулировать мысль прямо сейчас.")
            return
        await event.reply(f"💭 {entry.text}")

    @staticmethod
    def _is_observer_question(text: str) -> bool:
        phrases = (
            "кто тебе сегодня писал", "кто тебе писал сегодня",
            "кто тебе писал", "кто писал сегодня", "кто сегодня писал",
            "что происходило в тг", "что происходило в телеграме",
            "что произошло в тг", "что произошло в телеграме",
            "что было в тг пока меня не было", "что было в телеграме пока меня не было",
            "кто мне писал сегодня", "кто мне писал",
        )
        return any(p in text for p in phrases)
