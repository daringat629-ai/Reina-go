"""Приевшиеся темы — чтобы канал не превращался в «осень, плед, чай» по кругу.

Однообразие здесь — петля в данных, а не в коде: пост про осень попадает
в дневник и историю постов, из них собирается материал для следующей
мысли, и модель снова пишет про осень. Этот модуль смотрит на её недавние
посты и идеи и находит слова-темы, которые повторяются в заметной доле из
них. Их передают в промпты как «уже приелось — не бери снова, если только
не случилось что-то действительно новое».

Без внешних зависимостей: грубая «основа слова» — первые 5 букв (осень /
осенний / осенью → «осен»), плюс стоп-слова.
"""
from __future__ import annotations

import math
import re
from collections import Counter, defaultdict
from typing import Dict, Iterable, List

_WORD_RE = re.compile(r"[а-яёa-z]{3,}", re.IGNORECASE)

# Частые слова, которые ничего не говорят о теме.
_STOP = {
    "как", "что", "там", "тут", "так", "она", "они", "оно", "его", "ему", "нас", "вас", "нет", "или",
    "без", "под", "над", "для", "про", "при", "чем", "кто", "был", "мой", "моя", "все", "всё", "уже",
    "еще", "ещё", "вот", "раз", "дня", "два", "три", "это", "эти", "мне", "мои", "ты", "вы", "её", "ее",
    "нам", "вам", "кто", "ним", "ней", "них", "тем", "том", "той", "тех", "чуть", "лишь",
    "этот", "эта", "это", "этой", "этом", "этого", "эти", "того", "тоже", "тоже", "только", "очень",
    "просто", "когда", "потому", "поэтому", "который", "которая", "которые", "можно", "нужно",
    "будет", "было", "были", "была", "быть", "если", "даже", "чтобы", "хочу", "хочется", "всегда",
    "снова", "сегодня", "сейчас", "здесь", "там", "тут", "себя", "себе", "меня", "мне", "тебя",
    "тебе", "него", "неё", "нее", "них", "всех", "всем", "всё", "все", "весь", "вся", "свой",
    "своё", "свои", "своих", "своей", "моей", "мой", "моя", "мои", "моих", "твой", "ваши", "ваш",
    "какой", "какая", "какие", "такой", "такая", "такие", "так", "как", "что", "чем", "где",
    "куда", "почему", "зачем", "потом", "после", "перед", "между", "через", "около", "ещё", "еще",
    "уже", "вот", "ведь", "будто", "словно", "именно", "вообще", "кажется", "наверное", "может",
    "могу", "могла", "стала", "стало", "есть", "нету", "пока", "раньше", "дальше", "вместе",
    "друг", "другой", "другие", "самой", "самый", "сама", "сам", "день", "дня", "время", "раз",
    "марин", "подписчики", "подписчиков", "канал", "канале", "пост", "поста", "посте",
    "хочу", "запостить", "написать", "выложить", "пусть", "давай", "делать", "сделать",
}


_ENDINGS = ("иями", "ями", "ами", "ого", "его", "ому", "ему", "ыми", "ими", "ией", "ий", "ый", "ой",
            "ая", "яя", "ое", "ее", "ые", "ие", "ую", "юю", "ью", "ом", "ем", "ам", "ям", "ах", "ях",
            "ов", "ев", "ей", "ми", "ю", "я", "а", "е", "и", "ы", "у", "о", "ь", "й")


def _stem(word: str) -> str:
    """Грубая основа: отрезать окончание, взять первые 4 буквы —
    осень/осенний/осенью → «осен», плед/пледы/пледах → «плед», чай/чаем → «ча»."""
    w = word.lower().replace("ё", "е")
    for end in _ENDINGS:
        if w.endswith(end) and len(w) - len(end) >= 2:
            w = w[: -len(end)]
            break
    return w[:4] if len(w) > 4 else w


def fatigued_themes(texts: Iterable[str], *, min_share: float = 0.4, min_docs: int = 3,
                    top: int = 6) -> List[str]:
    """Слова-темы, встречающиеся минимум в min_share недавних текстов.
    Возвращает самую частую «живую» форму каждого слова."""
    docs = [t for t in texts if t and t.strip()]
    if len(docs) < min_docs:
        return []
    doc_stems: List[set] = []
    surface: Dict[str, Counter] = defaultdict(Counter)
    for text in docs:
        stems = set()
        for w in _WORD_RE.findall(text):
            low = w.lower()
            if low in _STOP:
                continue
            st = _stem(low)
            if st in _STOP_STEMS:
                continue
            stems.add(st)
            surface[st][low] += 1
        doc_stems.append(stems)
    counts = Counter(st for s in doc_stems for st in s)
    threshold = max(3, math.ceil(min_share * len(docs)))  # совпадение в 2 постах — случайность
    tired = [st for st, c in counts.most_common() if c >= threshold][:top]
    return [surface[st].most_common(1)[0][0] for st in tired]


_STOP_STEMS = {_stem(w) for w in _STOP}


def fatigue_note(words: List[str]) -> str:
    if not words:
        return ""
    return ("Уже приелось — это было почти в каждом недавнем посте/идее: " + ", ".join(words)
            + ". Не бери эти темы и слова снова, если только сейчас не случилось что-то "
              "действительно новое именно об этом.")


def recent_post_texts(telegram_client, limit: int = 8) -> List[str]:
    posts = []
    for entry in (getattr(telegram_client, "_own_channels", {}) or {}).values():
        for p in entry.get("post_history") or []:
            if p.get("text"):
                posts.append((float(p.get("at") or 0), str(p["text"])))
    return [t for _, t in sorted(posts, reverse=True)[:limit]]


def recent_idea_texts(telegram_client, limit: int = 6) -> List[str]:
    """Её недавние собственные идеи-цели — любые, включая выполненные и проваленные."""
    try:
        owner = str(getattr(telegram_client.config, "owner_id", "") or "")
        goals = telegram_client.engine.goal_set.autonomous_goals(owner_id=owner)
    except Exception:
        return []
    mine = [g for g in goals if (getattr(g, "context", {}) or {}).get("self_initiated")]
    mine.sort(key=lambda g: float(getattr(g, "created_at", 0) or 0), reverse=True)
    return [g.description for g in mine[:limit]]
