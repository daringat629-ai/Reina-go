"""Durable JSON registries: media packs, own channels, vision cache.

Mixin of MarinTelegramClient — relies on attributes created in
MarinTelegramClient.__init__ (self.client, self.engine, self.config, ...).
"""
from __future__ import annotations

import json
import logging
import os
import time

from .settings import (
    VISION_FAILURES_FILE,
    MEDIA_PACKS_FILE,
    OWN_CHANNELS_FILE,
    VISION_CACHE_FILE,
)

logger = logging.getLogger("marin_x.telegram")

class StateRegistriesMixin:
    def _load_media_pack_registry(self) -> None:
        """Load pack short-names previously added by the owner."""
        try:
            if not os.path.exists(MEDIA_PACKS_FILE):
                return
            with open(MEDIA_PACKS_FILE, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            if isinstance(data, dict):
                self._media_packs = {
                    str(k): v for k, v in data.items()
                    if isinstance(v, dict) and v.get("short_name")
                }
        except Exception:
            logger.debug("Could not load Telegram media pack registry", exc_info=True)

    def _save_media_pack_registry(self) -> None:
        try:
            parent = os.path.dirname(os.path.abspath(MEDIA_PACKS_FILE))
            if parent and parent != ".":
                os.makedirs(parent, exist_ok=True)
            tmp = MEDIA_PACKS_FILE + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(self._media_packs, fh, ensure_ascii=False, indent=2)
            os.replace(tmp, MEDIA_PACKS_FILE)
        except Exception:
            logger.debug("Could not save Telegram media pack registry", exc_info=True)

    def _load_own_channels_registry(self) -> None:
        """Каналы/группы, которые Марин считает своими — переживает
        рестарт точно так же, как каталог медиа-паков (тот же паттерн:
        JSON-файл + атомарная запись через tmp+os.replace)."""
        try:
            if not os.path.exists(OWN_CHANNELS_FILE):
                return
            with open(OWN_CHANNELS_FILE, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            if isinstance(data, dict):
                self._own_channels = {str(k): v for k, v in data.items() if isinstance(v, dict)}
        except Exception:
            logger.debug("Could not load own-channels registry", exc_info=True)

    def _save_own_channels_registry(self) -> None:
        try:
            parent = os.path.dirname(os.path.abspath(OWN_CHANNELS_FILE))
            if parent and parent != ".":
                os.makedirs(parent, exist_ok=True)
            tmp = OWN_CHANNELS_FILE + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(self._own_channels, fh, ensure_ascii=False, indent=2)
            os.replace(tmp, OWN_CHANNELS_FILE)
        except Exception:
            logger.debug("Could not save own-channels registry", exc_info=True)

    def _remember_own_channel(self, chat_id: int, title: str = "", username: str = "") -> None:
        """Единая точка, где Марин запоминает 'это мой канал' — вызывается
        и из ручного _action_create_channel (когда владелец подтвердил
        создание в обычном чат-потоке), и из goal_executor'а (Stage 4),
        так что оба пути ведут к одному и тому же durable-состоянию, а не
        каждый помнит своё. Помимо файла — кладёт факт и в память движка
        (remember_fact), чтобы это тоже участвовало в обычном retrieval,
        а не только в отдельной сводке _telegram_world_hint."""
        key = str(chat_id)
        entry = self._own_channels.get(key, {})
        entry.update({"id": chat_id, "title": title or entry.get("title", ""), "username": username or entry.get("username", "")})
        self._own_channels[key] = entry
        self._save_own_channels_registry()
        label = entry["title"] or f"id={chat_id}"
        handle = f"@{entry['username']}" if entry.get("username") else f"id={chat_id}"
        self.engine.remember_fact(
            f"own_channel_{key}", f"Мой канал «{label}» ({handle}).", confidence=1.0,
        )
        logger.info("[OWN_CHANNEL] remembered chat_id=%s title=%r username=%r", chat_id, title, username)

    def _own_channels_hint(self) -> str:
        if not self._own_channels:
            return "Своих каналов/групп Марин пока не создавала (или не запоминала) — не выдумывай id, если владелец не назвал его явно."
        lines = []
        for entry in self._own_channels.values():
            handle = f"@{entry['username']}" if entry.get("username") else f"id={entry.get('id')}"
            last_post_at = entry.get("last_post_at")
            if last_post_at:
                ago = self._format_time_ago(time.time() - last_post_at)
                post_info = f", последний пост {ago}" + (f": «{entry['last_post_preview']}»" if entry.get("last_post_preview") else "")
            else:
                post_info = ", постов пока не было"
            if entry.get("autopost_enabled"):
                post_info += ", веду сама по расписанию"
            if entry.get("default"):
                post_info += ", основной"
            lines.append(f"«{entry.get('title') or handle}» ({handle}, id={entry.get('id')}{post_info})")
        return "Каналы/группы, которые Марин считает своими (уже существуют, НЕ создавать заново): " + "; ".join(lines) + "."

    @staticmethod
    def _format_time_ago(seconds: float) -> str:
        if seconds < 3600:
            return f"{int(seconds // 60)} мин назад"
        if seconds < 86400:
            return f"{int(seconds // 3600)} ч назад"
        return f"{int(seconds // 86400)} дн назад"

    def _record_own_channel_post(self, chat_id: int, preview: str = "") -> None:
        """Обновляет last_post_at/last_post_preview для канала, ЕСЛИ он уже
        есть в реестре 'своих каналов' — не создаёт новую запись сама, только
        дополняет уже существующую (см. _remember_own_channel). Закрывает
        дыру 'она не знает, когда последний раз постила' без завязки на
        Stage 4/AUTOGOAL — работает и при обычном ручном ACTION-потоке."""
        key = str(chat_id)
        entry = self._own_channels.get(key)
        if entry is None:
            return
        entry["last_post_at"] = time.time()
        if preview:
            entry["last_post_preview"] = preview.strip()[:200]
        self._save_own_channels_registry()

    def _load_vision_cache(self) -> None:
        try:
            if not os.path.exists(VISION_CACHE_FILE):
                return
            with open(VISION_CACHE_FILE, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            if isinstance(data, dict):
                self._vision_cache = {str(k): str(v) for k, v in data.items() if v}
        except Exception:
            logger.debug("Could not load vision cache", exc_info=True)

    def _save_vision_cache(self) -> None:
        try:
            parent = os.path.dirname(os.path.abspath(VISION_CACHE_FILE))
            if parent:
                os.makedirs(parent, exist_ok=True)
            tmp = VISION_CACHE_FILE + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(self._vision_cache, fh, ensure_ascii=False, indent=2)
            os.replace(tmp, VISION_CACHE_FILE)
        except Exception:
            logger.debug("Could not save vision cache", exc_info=True)

    def _load_vision_failures(self) -> None:
        """Стикеры/эмодзи, на которых Vision уже спотыкалась (сеть, отказ
        модели, нет превью) — см. VISION_RETRY_COOLDOWN_SECONDS в
        _ensure_vision_catalog. Без этого файла один и тот же сломанный
        элемент скачивался и заново уходил в Vision API при КАЖДОМ рестарте."""
        try:
            if not os.path.exists(VISION_FAILURES_FILE):
                return
            with open(VISION_FAILURES_FILE, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            if isinstance(data, dict):
                self._vision_failures = {str(k): float(v) for k, v in data.items() if v}
        except Exception:
            logger.debug("Could not load vision failures registry", exc_info=True)

    def _save_vision_failures(self) -> None:
        try:
            parent = os.path.dirname(os.path.abspath(VISION_FAILURES_FILE))
            if parent:
                os.makedirs(parent, exist_ok=True)
            tmp = VISION_FAILURES_FILE + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(self._vision_failures, fh, ensure_ascii=False, indent=2)
            os.replace(tmp, VISION_FAILURES_FILE)
        except Exception:
            logger.debug("Could not save vision failures registry", exc_info=True)
