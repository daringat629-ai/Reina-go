"""CommunityMixin — Marin replies to SUBSCRIBERS, not just the owner, in the
discussion group attached to one of her own broadcast channels (Telegram's
"N comments" thread under a channel post).

Scope is intentionally narrow and safe:

* Only messages inside a chat identified as the discussion group of an
  already-registered own channel trigger a reply at all — every other
  non-owner chat keeps the old behaviour (observed, never answered).
* The reply uses ``engine.tick(..., is_owner=False)``: the SAME safety rails
  that already gate strangers apply (forbidden-topic invariants, no
  owner-level intimacy — ``style_prior`` not ``owner_style_prior``).
* No protocol markers are ever acted on for a commenter's turn: ACTION/READ/
  POST/AUTOGOAL are stripped unexecuted. A commenter cannot make Marin post,
  change the channel, or run any Telegram action — only the owner can.
  BELIEF/PERSON/GOAL markers ARE processed (so she can actually build a
  relationship with regulars), same as for any non-owner tick elsewhere.
* Rate-limited: a cooldown per commenter and a cap on replies per channel per
  hour, so a busy comment section doesn't turn into spam / a flood-ban risk.
* She only engages top-level comments or replies to her OWN messages — a
  reply aimed at another subscriber is left alone.
"""
from __future__ import annotations

import asyncio
import logging
import re
import time
from typing import Any, Dict, List, Optional

from ..llm.providers import _is_unusable_output, split_into_messages
from .settings import fit_messages

logger = logging.getLogger("marin_x.telegram.community")

_ANY_MARKER_RE = re.compile(r"<<<(?:ACTION|READ|POST|AUTOGOAL|TUNE):.*?>>>", re.IGNORECASE | re.DOTALL)


from ..env import env_float as _env_float  # noqa: E402  (единый надёжный разбор)


class CommunityMixin:
    # ------------------------------------------------------------ discovery
    async def _discussion_entry_for_chat(self, chat: Any, chat_id: str) -> Optional[Dict[str, Any]]:
        """Returns the own-channel registry entry this chat is the discussion
        group of, or None. Cached per chat id (cheap after the first lookup)."""
        cache = self.__dict__.setdefault("_discussion_cache", {})
        if chat_id in cache:
            key = cache[chat_id]
            return self._own_channels.get(key) if key else None

        for entry in self._own_channels.values():
            if str(entry.get("discussion_chat_id") or "") == chat_id:
                cache[chat_id] = str(entry.get("id"))
                return entry

        entry = await self._probe_discussion_link(chat, chat_id)
        cache[chat_id] = str(entry.get("id")) if entry else None
        return entry

    async def _probe_discussion_link(self, chat: Any, chat_id: str) -> Optional[Dict[str, Any]]:
        if not getattr(chat, "megagroup", False):
            return None
        try:
            from telethon import functions
            full = await self.client(functions.channels.GetFullChannelRequest(channel=chat))
            linked_id = getattr(getattr(full, "full_chat", None), "linked_chat_id", None)
        except Exception:
            logger.debug("[COMMUNITY] could not probe linked channel for chat=%s", chat_id, exc_info=True)
            return None
        if not linked_id:
            return None
        for entry in self._own_channels.values():
            eid = entry.get("id")
            if eid is not None and (int(eid) == int(linked_id) or str(-1000000000000 - int(linked_id)) == str(eid)):
                entry["discussion_chat_id"] = chat_id
                entry["discussion_title"] = getattr(chat, "title", "") or ""
                self._save_own_channels_registry()
                logger.info("[COMMUNITY] linked discussion chat %s -> channel %r", chat_id, entry.get("title"))
                return entry
        return None

    # ------------------------------------------------------------- gating
    def _community_reply_allowed(self, entry: Dict[str, Any], chat_id: str, sender_id: str, now: float) -> bool:
        cooldown = _env_float("MARIN_COMMENTS_COOLDOWN_SECONDS", 45.0)
        per_hour = _env_float("MARIN_COMMENTS_MAX_PER_HOUR", 20.0)
        last_by_sender: Dict[str, float] = self.__dict__.setdefault("_comment_cooldowns", {})
        sender_key = f"{chat_id}:{sender_id}"
        if now - last_by_sender.get(sender_key, 0.0) < cooldown:
            return False
        log: Dict[str, List[float]] = self.__dict__.setdefault("_comment_hour_log", {})
        recent = [t for t in log.get(chat_id, []) if now - t < 3600.0]
        log[chat_id] = recent
        return len(recent) < per_hour

    async def _should_engage_comment(self, event, chat) -> bool:
        """Не встревает в разговор, адресованный другому подписчику."""
        reply_to = getattr(getattr(event, "message", None), "reply_to", None)
        reply_to_id = getattr(reply_to, "reply_to_msg_id", None)
        if not reply_to_id:
            return True
        try:
            parent = await self.client.get_messages(chat, ids=reply_to_id)
        except Exception:
            return True
        return parent is None or bool(getattr(parent, "out", False))

    def _note_comment_reply(self, chat_id: str, sender_id: str, now: float) -> None:
        self._comment_cooldowns[f"{chat_id}:{sender_id}"] = now
        self._comment_hour_log.setdefault(chat_id, []).append(now)

    # -------------------------------------------------------------- reply
    async def _process_comment_batch(self, events_batch: list, chat: Any, chat_id: str,
                                     sender_id: str, entry: Dict[str, Any]) -> None:
        texts = [self._event_text(e) for e in events_batch if self._event_text(e)]
        if not texts:
            return
        now = time.time()
        if not self._community_reply_allowed(entry, chat_id, sender_id, now):
            logger.info("[COMMUNITY] skipped reply (rate limit) chat=%s sender=%s", chat_id, sender_id)
            return

        new_text = "\n".join(texts)
        combined = (
            f"[Это комментарий подписчика под твоим постом в канале «{entry.get('title') or ''}», "
            "не личка владельца. Отвечай как автор канала своим фанатам — тепло, живо, коротко, "
            "но это ПУБЛИЧНО, посторонние читают]\n"
            + self._owner_awareness_hint()
            + self._identity_rules_hint("other")
            + f"[Сообщение подписчика]\n{new_text}"
        )
        channel_id = f"telegram:{chat_id}"
        try:
            result = await asyncio.to_thread(
                self.engine.tick, combined, channel_id=channel_id,
                source_actor_id=sender_id, is_owner=False,
            )
        except Exception:
            logger.exception("[COMMUNITY] tick failed chat=%s sender=%s", chat_id, sender_id)
            return
        raw = (result.generated_text or "").strip()
        if not raw or _is_unusable_output(raw):
            return  # промолчать — не хуже, чем показать мусор подписчику

        # Маркеры действий комментатор вызвать не может — только текст.
        # BELIEF/PERSON/GOAL безопасны и оставляют модели человеческую память.
        text = _ANY_MARKER_RE.sub("", raw)
        text = self._extract_belief_marker(text)
        text = self._extract_goal_marker(text)
        text = self._extract_person_marker(text)
        text = self._strip_leaked_markers(text, chat_id)
        text = re.sub(r"\n{3,}", "\n\n", text).strip()
        reply = self._sanitize_output(text)
        if not reply:
            return

        messages = fit_messages(split_into_messages(reply, max_messages=None), 2)  # 2 пузыря, но текст не теряется
        if not messages:
            return
        last_event = events_batch[-1]
        for i, msg_text in enumerate(messages):
            if i:
                await asyncio.sleep(1.0)
            sticker_match = re.fullmatch(r"\s*<<<STICKER(?::[A-Za-z]?(\d+))?>>>\s*", msg_text, re.IGNORECASE)
            if sticker_match:
                await self._send_sticker(chat, int(sticker_match.group(1)) if sticker_match.group(1) else None)
                continue
            emoji_match = re.fullmatch(r"\s*<<<CUSTOM_EMOJI(?::[A-Za-z]?(\d+))?>>>\s*", msg_text, re.IGNORECASE)
            if emoji_match:
                await self._send_custom_emoji(chat, int(emoji_match.group(1)) if emoji_match.group(1) else None)
                continue
            msg_text = self._sanitize_output(msg_text)
            if not msg_text:
                continue
            try:
                async with self.client.action(chat, "typing"):
                    await asyncio.sleep(min(1.2 + len(msg_text) / 60.0, 3.0))
            except Exception:
                logger.debug("[COMMUNITY] typing indicator failed", exc_info=True)
            if i == 0:
                await last_event.reply(msg_text)
            else:
                await self.client.send_message(chat, msg_text)
        self._note_comment_reply(chat_id, sender_id, now)
        self._record_own_reply(chat, chat_id, messages)
        logger.info("[COMMUNITY] replied to subscriber chat=%s sender=%s", chat_id, sender_id)
