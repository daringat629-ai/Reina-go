"""Stickers / custom emoji packs, Vision, invite links, selfie & voice generators.

Mixin of MarinTelegramClient — relies on attributes created in
MarinTelegramClient.__init__ (self.client, self.engine, self.config, ...).
"""
from __future__ import annotations

import asyncio
import base64
import logging
import os
import random
import time
from .illustrator import (
    DisabledIllustrationGenerator,
    OpenRouterIllustrationConfig,
    OpenRouterIllustrationGenerator,
)
from .selfie import DisabledSelfieGenerator, OpenRouterSelfieConfig, OpenRouterSelfieGenerator
from .voice import (DisabledTranscriber, DisabledVoiceGenerator, ElevenLabsVoiceConfig, ElevenLabsVoiceGenerator,
                    FallbackVoiceGenerator,
                    OpenRouterTranscriber, OpenRouterTranscriberConfig, OpenRouterVoiceConfig,
                    OpenRouterVoiceGenerator)
from telethon import functions, types

from .legacy_media import LocalSticker, discover as discover_legacy_media
from typing import Optional

from .settings import (
    VISION_RETRY_COOLDOWN_SECONDS,
    ILLUSTRATION_ENABLED,
    ILLUSTRATION_MODEL,
    ILLUSTRATION_TIMEOUT,
    MEDIA_CATALOG_MAX,
    MEDIA_PACKS_FILE,
    VISION_CACHE_FILE,
    GROUP_INVITE_URL_RE,
    MEDIA_PACK_URL_RE,
    SELFIE_ENABLED,
    SELFIE_MODEL,
    SELFIE_REFERENCE_IMAGE,
    SELFIE_TIMEOUT,
    VISION_CATALOG_CONCURRENCY,
    VISION_ENABLED,
    VISION_MODEL,
    VISION_TIMEOUT,
    VOICE_ENABLED,
    VOICE_MODEL_ID,
    VOICE_TIMEOUT,
)

logger = logging.getLogger("marin_x.telegram")

class MediaMixin:
    @staticmethod
    def _pack_short_name_from_url(url: str) -> tuple[str, str] | None:
        match = MEDIA_PACK_URL_RE.search(url or "")
        if not match:
            return None
        return match.group(1).lower(), match.group(2)

    def _index_media_pack(self, full, fallback_kind: str = "unknown") -> tuple[int, int, str]:
        """Index documents from one Telegram sticker/emoji set."""
        sticker_count = 0
        emoji_count = 0
        pack_set = getattr(full, "set", None)
        pack_title = str(getattr(pack_set, "title", "") or "").strip()
        short_name = str(getattr(pack_set, "short_name", "") or "").strip()
        if not short_name:
            return 0, 0, pack_title
        for doc in getattr(full, "documents", []) or []:
            attrs = getattr(doc, "attributes", []) or []
            custom_attr = next((a for a in attrs if type(a).__name__ == "DocumentAttributeCustomEmoji"), None)
            sticker_attr = next((a for a in attrs if type(a).__name__ == "DocumentAttributeSticker"), None)
            if custom_attr is not None:
                if len(self._custom_emoji_catalog) < MEDIA_CATALOG_MAX and int(doc.id) not in self._custom_emoji_meta:
                    self._custom_emoji_catalog.append(doc)
                self._custom_emoji_meta[int(doc.id)] = {
                    "pack": pack_title,
                    "short_name": short_name,
                    "alt": str(getattr(custom_attr, "alt", "") or ""),
                    "vision": self._vision_cache.get(str(doc.id), ""),
                }
                emoji_count += 1
            elif sticker_attr is not None:
                if len(self._sticker_catalog) < MEDIA_CATALOG_MAX and int(doc.id) not in self._sticker_meta:
                    self._sticker_catalog.append(doc)
                self._sticker_meta[int(doc.id)] = {
                    "pack": pack_title,
                    "short_name": short_name,
                    "alt": str(getattr(sticker_attr, "alt", "") or ""),
                    "vision": self._vision_cache.get(str(doc.id), ""),
                }
                sticker_count += 1
        return sticker_count, emoji_count, pack_title

    async def _fetch_pack_by_short_name(self, short_name: str, kind: str = "unknown") -> tuple[int, int, str]:
        full = await self.client(functions.messages.GetStickerSetRequest(
            stickerset=types.InputStickerSetShortName(short_name=short_name),
            hash=0,
        ))
        return self._index_media_pack(full, fallback_kind=kind)

    def _import_legacy_media(self) -> str:
        """Подтягивает стикеры/эмодзи из прошлых версий Марин (другие папки
        деплоя, старые реестры, скачанные файлы) — см. legacy_media.py."""
        roots = [r for r in os.getenv("MARIN_LEGACY_MEDIA_DIRS", "").split(",") if r.strip()]
        try:
            found = discover_legacy_media(roots, exclude=[MEDIA_PACKS_FILE, VISION_CACHE_FILE])
        except Exception:
            logger.warning("Legacy media discovery failed", exc_info=True)
            return ""
        known = {str(v.get("short_name", "")).lower() for v in self._media_packs.values()}
        new_packs = 0
        for key, info in found.packs.items():
            if key in known:
                continue
            self._media_packs[info["short_name"]] = {**info, "source": "legacy"}
            new_packs += 1
        new_vision = 0
        for doc_id, desc in found.vision.items():
            if doc_id not in self._vision_cache:
                self._vision_cache[doc_id] = desc
                new_vision += 1
        self._local_stickers = found.files
        if new_packs:
            self._save_media_pack_registry()
        if new_vision:
            self._save_vision_cache()
        summary = (f"legacy media: +{new_packs} паков, +{new_vision} описаний Vision, "
                   f"{len(found.files)} файлов-стикеров (из {len(found.sources)} старых реестров)")
        logger.info("[MEDIA] %s; roots=%s", summary, roots)
        return summary

    async def _load_media_catalog(self) -> None:
        """Load installed sets plus every pack the owner explicitly added by URL.

        The explicit registry makes added packs persistent across restarts; each
        saved short name is resolved directly with GetStickerSetRequest as well.
        """
        self._sticker_catalog.clear()
        self._custom_emoji_catalog.clear()
        self._sticker_meta.clear()
        self._custom_emoji_meta.clear()
        try:
            # First resolve packs explicitly supplied by the owner.
            for info in list(self._media_packs.values()):
                short_name = str(info.get("short_name", "")).strip()
                if not short_name:
                    continue
                try:
                    await self._fetch_pack_by_short_name(short_name, str(info.get("kind", "unknown")))
                except Exception:
                    logger.debug("Could not load saved Telegram pack %s", short_name, exc_info=True)

            # Then add the normal installed catalog too.
            result = await self.client(functions.messages.GetAllStickersRequest(hash=0))
            sets = getattr(result, "sets", []) or []
            for pack in sets[:80]:
                short_name = str(getattr(pack, "short_name", "") or "").strip()
                if not short_name:
                    continue
                try:
                    await self._fetch_pack_by_short_name(short_name, "installed")
                except Exception:
                    continue
            # Установленные наборы custom emoji — GetAllStickers их НЕ отдаёт,
            # поэтому раньше эмодзи-паки аккаунта в каталог не попадали вовсе.
            try:
                emoji_sets = await self.client(functions.messages.GetEmojiStickersRequest(hash=0))
                for pack in (getattr(emoji_sets, "sets", []) or [])[:40]:
                    short_name = str(getattr(pack, "short_name", "") or "").strip()
                    if short_name:
                        try:
                            await self._fetch_pack_by_short_name(short_name, "emoji")
                        except Exception:
                            continue
            except Exception:
                logger.debug("Could not load installed custom emoji sets", exc_info=True)

            # Скачанные стикеры-файлы из прошлых версий — отправляются с диска.
            for item in getattr(self, "_local_stickers", []) or []:
                if len(self._sticker_catalog) >= MEDIA_CATALOG_MAX:
                    break
                if int(item.id) in self._sticker_meta:
                    continue
                self._sticker_catalog.append(item)
                self._sticker_meta[int(item.id)] = {
                    "pack": "сохранённые стикеры",
                    "short_name": "",
                    "alt": item.meaning,
                    "vision": self._vision_cache.get(str(item.id), ""),
                }
            logger.info(
                "Telegram media catalog: stickers=%d custom_emojis=%d saved_packs=%d",
                len(self._sticker_catalog), len(self._custom_emoji_catalog), len(self._media_packs),
            )
            self.engine.remember_fact(
                "telegram_media_catalog",
                f"Каталог медиа: стикеров={len(self._sticker_catalog)}, "
                f"custom emoji={len(self._custom_emoji_catalog)}, добавленных паков={len(self._media_packs)}.",
                confidence=0.95,
            )
        except Exception:
            logger.debug("Could not load Telegram sticker/custom emoji catalog", exc_info=True)

    async def _add_media_pack_from_url(self, url: str) -> tuple[bool, str, int, int]:
        """Install and immediately index an /addemoji/ or /addstickers/ pack."""
        parsed = self._pack_short_name_from_url(url)
        if not parsed:
            return False, "", 0, 0
        kind, short_name = parsed
        try:
            # Telegram's MTProto uses the same sticker-set installation method
            # for sticker and custom-emoji packs. Using ShortName avoids the
            # access-hash mismatch that can occur when copying a set between accounts.
            try:
                await self.client(functions.messages.InstallStickerSetRequest(
                    stickerset=types.InputStickerSetShortName(short_name=short_name),
                    archived=False,
                ))
            except Exception as exc:
                # Already-installed sets commonly return an RPC error. We still
                # fetch the set directly below, so this is not treated as failure.
                logger.debug("Install pack %s returned %s; trying direct fetch", short_name, exc)

            sticker_count, emoji_count, title = await self._fetch_pack_by_short_name(short_name, kind)
            self._media_packs[short_name] = {
                "short_name": short_name,
                "kind": kind,
                "title": title,
                "url": url,
                "updated_at": str(int(time.time())),
            }
            self._save_media_pack_registry()
            logger.info(
                "Telegram media pack added: kind=%s short_name=%s title=%r stickers=%d custom_emojis=%d",
                kind, short_name, title, sticker_count, emoji_count,
            )
            return True, title or short_name, sticker_count, emoji_count
        except Exception:
            logger.exception("Could not add Telegram media pack from %s", url)
            return False, short_name, 0, 0

    async def _handle_media_pack_links(self, event, text: str) -> bool:
        """Handle owner messages containing /addemoji/ or /addstickers/ URLs."""
        matches = list(MEDIA_PACK_URL_RE.finditer(text or ""))
        if not matches:
            return False
        added = 0
        failed = 0
        for match in matches[:5]:
            ok, title, sticker_count, emoji_count = await self._add_media_pack_from_url(match.group(0))
            if ok:
                added += 1
            else:
                failed += 1
        if added:
            await event.reply("Добавила набор в свою коллекцию.")
            await asyncio.sleep(0.7)
            await self.client.send_message(event.chat_id, "Теперь смогу брать оттуда стикеры и custom-эмодзи.")
            asyncio.create_task(self._ensure_vision_catalog())
        elif failed:
            await event.reply("Не получилось добавить набор.")
            await asyncio.sleep(0.7)
            await self.client.send_message(event.chat_id, "Оставила ссылку, но Telegram не дал мне получить его содержимое.")
        return True

    async def _join_chat_from_invite(self, url: str) -> tuple[bool, str]:
        """Реально вступает в группу/канал по инвайт-ссылке через MTProto.

        До этого фикса Марин на такую ссылку просто отвечала текстом вроде
        "захожу уже" — ничего на самом деле не происходило, владелец получал
        ложное подтверждение действия, которого не было."""
        match = GROUP_INVITE_URL_RE.search(url or "")
        if not match:
            return False, ""
        invite_hash = match.group(1)
        try:
            result = await self.client(functions.messages.ImportChatInviteRequest(hash=invite_hash))
            chats = getattr(result, "chats", []) or []
            title = str(getattr(chats[0], "title", "") or "") if chats else ""
            logger.info("Joined Telegram group via invite: title=%r", title)
            return True, title
        except Exception as exc:
            if "ALREADY_PARTICIPANT" in str(exc).upper():
                return True, ""
            logger.exception("Could not join Telegram group from invite %s", url)
            return False, ""

    async def _handle_group_invite_links(self, event, text: str) -> bool:
        """Owner прислал инвайт-ссылку на группу/канал — реально вступаем,
        вместо того чтобы просто сказать "захожу" (см. _join_chat_from_invite)."""
        matches = list(GROUP_INVITE_URL_RE.finditer(text or ""))
        if not matches:
            return False
        ok, title = await self._join_chat_from_invite(matches[0].group(0))
        if ok:
            await event.reply(f"Зашла в группу{f' «{title}»' if title else ''}.")
        else:
            await event.reply("Не смогла зайти по этой ссылке — Telegram отказал (ссылка могла протухнуть или я уже была в этой группе под другим статусом).")
        return True

    def _get_voice_generator(self):
        """Ленивая инициализация, тот же принцип, что и _get_selfie_generator().
        В отличие от селфи, у ElevenLabs нет общего ключа с OpenRouter —
        нужен отдельный MARIN_ELEVENLABS_API_KEY + MARIN_VOICE_ID (voice_id
        клонированного или выбранного в личном кабинете ElevenLabs голоса)."""
        if self._voice_generator is not None:
            return self._voice_generator
        api_key = os.getenv("MARIN_ELEVENLABS_API_KEY")
        voice_id = os.getenv("MARIN_VOICE_ID")
        provider = (os.getenv("MARIN_VOICE_PROVIDER", "auto") or "auto").strip().lower()
        or_key = os.getenv("MARIN_OPENROUTER_API_KEY") or os.getenv("OPENROUTER_API_KEY")
        eleven_ready = bool(api_key and voice_id)
        if VOICE_ENABLED and or_key and (provider == "openrouter" or (provider == "auto" and not eleven_ready)):
            openrouter = OpenRouterVoiceGenerator(OpenRouterVoiceConfig(
                api_key=or_key,
                model=os.getenv("MARIN_TTS_MODEL", OpenRouterVoiceConfig.model),
                voice=os.getenv("MARIN_TTS_VOICE", OpenRouterVoiceConfig.voice),
                instructions=os.getenv("MARIN_TTS_INSTRUCTIONS", OpenRouterVoiceConfig.instructions),
                timeout=VOICE_TIMEOUT,
            ))
            if eleven_ready:
                # OpenRouter — первым, ElevenLabs — запасной: голосовое не пропадёт,
                # если один сервис отказал (в логе 27.09: OpenRouter TTS 400).
                self._voice_generator = FallbackVoiceGenerator([openrouter, ElevenLabsVoiceGenerator(
                    ElevenLabsVoiceConfig(api_key=api_key, voice_id=voice_id, model_id=VOICE_MODEL_ID,
                                          timeout=VOICE_TIMEOUT))])
            else:
                self._voice_generator = openrouter
            return self._voice_generator
        if not VOICE_ENABLED or not eleven_ready:
            self._voice_generator = DisabledVoiceGenerator()
        else:
            self._voice_generator = ElevenLabsVoiceGenerator(
                ElevenLabsVoiceConfig(
                    api_key=api_key, voice_id=voice_id, model_id=VOICE_MODEL_ID, timeout=VOICE_TIMEOUT
                )
            )
        return self._voice_generator

    def _get_transcriber(self):
        """Распознавание входящих голосовых через OpenRouter (Whisper)."""
        cached = self.__dict__.get("_transcriber")
        if cached is not None:
            return cached
        key = os.getenv("MARIN_OPENROUTER_API_KEY") or os.getenv("OPENROUTER_API_KEY")
        enabled = (os.getenv("MARIN_STT_ENABLED", "true") or "true").lower() in {"1", "true", "yes", "on"}
        if not key or not enabled:
            self._transcriber = DisabledTranscriber()
        else:
            self._transcriber = OpenRouterTranscriber(OpenRouterTranscriberConfig(
                api_key=key, model=os.getenv("MARIN_STT_MODEL", "openai/whisper-large-v3"),
                language=os.getenv("MARIN_STT_LANGUAGE", "ru"),
            ))
        return self._transcriber

    def _get_selfie_generator(self):
        """Ленивая инициализация — один и тот же generator переиспользуется
        между вызовами (не пересоздаёт HTTP-конфиг на каждое селфи).
        MARIN_SELFIE_API_KEY, если задан, приоритетнее MARIN_OPENROUTER_API_KEY —
        но обычно достаточно уже существующего ключа для чата, отдельно
        заводить ничего не нужно."""
        if self._selfie_generator is not None:
            return self._selfie_generator
        api_key = os.getenv("MARIN_SELFIE_API_KEY") or os.getenv("MARIN_OPENROUTER_API_KEY")
        if not SELFIE_ENABLED or not api_key:
            self._selfie_generator = DisabledSelfieGenerator()
        else:
            self._selfie_generator = OpenRouterSelfieGenerator(
                OpenRouterSelfieConfig(api_key=api_key, model=SELFIE_MODEL, timeout=SELFIE_TIMEOUT)
            )
        return self._selfie_generator

    def _get_illustration_generator(self):
        """Ленивая инициализация — тот же принцип, что и _get_selfie_generator(),
        но без референс-фото: иллюстрация не обязана быть похожа на Марин."""
        if self._illustration_generator is not None:
            return self._illustration_generator
        api_key = os.getenv("MARIN_ILLUSTRATION_API_KEY") or os.getenv("MARIN_OPENROUTER_API_KEY")
        if not ILLUSTRATION_ENABLED or not api_key:
            self._illustration_generator = DisabledIllustrationGenerator()
        else:
            self._illustration_generator = OpenRouterIllustrationGenerator(
                OpenRouterIllustrationConfig(api_key=api_key, model=ILLUSTRATION_MODEL, timeout=ILLUSTRATION_TIMEOUT)
            )
        return self._illustration_generator

    def _get_selfie_reference(self) -> Optional[str]:
        """Референсное фото лица (base64) для консистентной внешности между
        генерациями — читается один раз и кэшируется. Отсутствие файла не
        считается ошибкой: генерация просто пойдёт без референса (модель
        будет придумывать внешность из текстового промпта)."""
        if self._selfie_reference_b64 is not None:
            return self._selfie_reference_b64 or None
        try:
            with open(SELFIE_REFERENCE_IMAGE, "rb") as fh:
                self._selfie_reference_b64 = base64.b64encode(fh.read()).decode("ascii")
        except Exception:
            logger.info("No selfie reference image at %s — generating without one.", SELFIE_REFERENCE_IMAGE)
            self._selfie_reference_b64 = ""
        return self._selfie_reference_b64 or None

    async def _vision_describe_bytes(self, raw: bytes, mime: str, prompt: str) -> str:
        """Общий вызов Vision — вынесен из _describe_image, чтобы тот же
        путь использовался и для входящих фото, и для каталогизации
        собственных стикеров/custom emoji (см. _ensure_vision_catalog)."""
        if not VISION_ENABLED or not raw:
            return ""
        api_key = os.getenv("MARIN_OPENROUTER_API_KEY")
        if not api_key:
            return ""
        try:
            encoded = base64.b64encode(raw).decode("ascii")
            import requests
            payload = {
                "model": VISION_MODEL,
                "messages": [{
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {"type": "image_url", "image_url": {"url": f"data:{mime};base64,{encoded}"}},
                    ],
                }],
                "max_tokens": 300,
                "temperature": 0.2,
            }
            resp = await asyncio.to_thread(
                requests.post,
                "https://openrouter.ai/api/v1/chat/completions",
                json=payload,
                headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
                timeout=VISION_TIMEOUT,
            )
            resp.raise_for_status()
            data = resp.json()
            return self._sanitize_output((data["choices"][0]["message"].get("content") or "").strip())
        except Exception:
            logger.exception("Vision processing failed")
            return ""

    async def _describe_image(self, event) -> tuple:
        """Получает короткое описание изображения через OpenRouter Vision.
        Возвращает (описание, kind) — kind нужен, чтобы отличать скриншот
        от обычного фото и запоминать их по-разному (см. вызов ниже)."""
        if not VISION_ENABLED or not self.config.owner_id:
            return "", ""
        mime = getattr(getattr(event, "file", None), "mime_type", None) or "image/jpeg"
        if not (mime.startswith("image/") or bool(getattr(event, "photo", None))):
            return "", ""
        # Скриншоты обычно шлют несжатым файлом (сохраняет качество текста
        # на экране), а живые фото — сжатым "photo". Не идеальная эвристика,
        # но рабочая: даёт другой промпт и другую пометку в памяти.
        is_screenshot = getattr(event, "document", None) is not None and not getattr(event, "photo", None)
        prompt = (
            "Это скриншот экрана телефона или компьютера. Опиши кратко и по делу на "
            "русском: какое приложение/сайт, что написано (ключевой текст), что "
            "происходит на экране. Без эмодзи."
            if is_screenshot else
            "Опиши это изображение кратко и по делу на русском. Отметь людей, предметы, текст и важные детали. Без эмодзи."
        )
        raw = await event.download_media(file=bytes)
        description = await self._vision_describe_bytes(raw, mime, prompt)
        return description, ("скриншот" if is_screenshot else "фото")

    async def _get_vision_source_bytes(self, doc) -> tuple[bytes, str]:
        """Статичное изображение для Vision-анализа документа: сначала
        thumbnail (работает и для анимированных .tgs, и для видео-стикеров —
        Telegram всегда даёт статичный превью-кадр для списка стикеров),
        иначе сам файл, если это уже растровое изображение (обычные
        custom emoji чаще всего webp)."""
        if isinstance(doc, LocalSticker):
            if doc.path.lower().endswith(".webp"):
                try:
                    with open(doc.path, "rb") as fh:
                        return fh.read(), "image/webp"
                except OSError:
                    return b"", ""
            return b"", ""  # .tgs/.webm — смысл берём из имени файла
        thumbs = getattr(doc, "thumbs", None) or []
        if thumbs:
            try:
                raw = await self.client.download_media(doc, thumb=-1, file=bytes)
                if raw:
                    return raw, "image/jpeg"
            except Exception:
                logger.debug("Could not download thumb for doc %s", getattr(doc, "id", "?"), exc_info=True)
        mime = getattr(doc, "mime_type", "") or ""
        if mime.startswith("image/"):
            try:
                raw = await self.client.download_media(doc, file=bytes)
                if raw:
                    return raw, mime
            except Exception:
                logger.debug("Could not download full doc %s", getattr(doc, "id", "?"), exc_info=True)
        return b"", ""

    async def _ensure_vision_catalog(self) -> None:
        """Реально смотрит на новые (ещё не в кэше) стикеры/custom emoji через
        Vision и запоминает описание насовсем — до этого фикса модель выбирала
        медиа вслепую по одному служебному alt-символу от Telegram (часто
        пустому или это просто emoji-заглушка, а не описание содержимого).

        Элемент, который не удалось описать (сеть подвела, модель отказала,
        нет превью), помечается в _vision_failures с меткой времени и не
        трогается VISION_RETRY_COOLDOWN_SECONDS — иначе один и тот же
        сломанный стикер скачивался бы из Telegram и заново уходил в Vision
        API при КАЖДОМ перезапуске, безрезультатно и без остановки.

        Обрабатывает пак целиком за один заход, параллельно — до
        VISION_CATALOG_CONCURRENCY запросов одновременно через семафор,
        а не один за другим с паузой (было ощутимо медленнее на большом
        паке). Задача фоновая, так что общее время (на 100+ стикеров всё
        равно может уйти какое-то время) никого не блокирует."""
        if not VISION_ENABLED or not os.getenv("MARIN_OPENROUTER_API_KEY"):
            return
        items = (
            [(doc, self._sticker_meta, "стикер") for doc in self._sticker_catalog]
            + [(doc, self._custom_emoji_meta, "custom emoji") for doc in self._custom_emoji_catalog]
        )
        now = time.time()
        pending = []
        skipped_recent_failure = 0
        for doc, meta_dict, kind in items:
            doc_id = str(int(doc.id))
            if self._vision_cache.get(doc_id):
                continue
            failed_at = self._vision_failures.get(doc_id)
            if failed_at is not None and now - failed_at < VISION_RETRY_COOLDOWN_SECONDS:
                skipped_recent_failure += 1
                continue
            pending.append((doc, meta_dict, kind))
        if not pending:
            if skipped_recent_failure:
                logger.info(
                    "Vision cataloging: nothing to do (%d item(s) skipped — recently failed, "
                    "cooldown not over yet)", skipped_recent_failure,
                )
            return
        logger.info(
            "Vision cataloging: %d new media items to analyze (concurrency=%d)%s",
            len(pending), VISION_CATALOG_CONCURRENCY,
            f"; {skipped_recent_failure} skipped (recent failure, in cooldown)" if skipped_recent_failure else "",
        )

        semaphore = asyncio.Semaphore(max(1, VISION_CATALOG_CONCURRENCY))
        analyzed = 0
        failed = 0
        counters_lock = asyncio.Lock()

        async def _process_one(doc, meta_dict, kind) -> None:
            nonlocal analyzed, failed
            async with semaphore:
                doc_id = int(doc.id)
                # Скачивание/vision — сетевые операции, любая может бросить
                # (таймаут, ошибка API, битый файл). Раньше исключение шло
                # наружу через asyncio.gather и **отменяло всю пачку**, теряя
                # прогресс по остальным элементам. Теперь один сбойный элемент
                # просто помечается failed (уйдёт в cooldown), а каталог
                # каталогизации продолжается.
                try:
                    raw, mime = await self._get_vision_source_bytes(doc)
                    description = ""
                    if raw:
                        description = await self._vision_describe_bytes(
                            raw, mime,
                            f"Это Telegram {kind}. Опиши одним коротким предложением на русском, что на нём "
                            f"изображено — персонаж, эмоция, действие. Без эмодзи, без вступлений.",
                        )
                except asyncio.CancelledError:
                    raise
                except Exception:
                    logger.warning(
                        "Vision cataloging: item %s (%s) failed, skipping (cooldown)",
                        doc_id, kind, exc_info=True,
                    )
                    description = ""
                async with counters_lock:
                    if description:
                        self._vision_cache[str(doc_id)] = description
                        self._vision_failures.pop(str(doc_id), None)
                        entry = meta_dict.get(doc_id, {})
                        entry["vision"] = description
                        meta_dict[doc_id] = entry
                        analyzed += 1
                    else:
                        self._vision_failures[str(doc_id)] = time.time()
                        failed += 1
                    if (analyzed + failed) % 20 == 0:
                        self._save_vision_cache()
                        self._save_vision_failures()
                        logger.info("Vision cataloging progress: %d/%d (failed so far: %d)",
                                   analyzed + failed, len(pending), failed)

        # return_exceptions=True — второй рубеж: даже если внутри _process_one
        # что-то останется незакрытым, один сбой не отменит остальные корутины.
        await asyncio.gather(
            *(_process_one(doc, meta_dict, kind) for doc, meta_dict, kind in pending),
            return_exceptions=True,
        )
        if analyzed:
            self._save_vision_cache()
        if failed:
            self._save_vision_failures()
        logger.info(
            "Vision-catalogued %d/%d media item(s)%s", analyzed, len(pending),
            f", {failed} failed and will not be retried for {int(VISION_RETRY_COOLDOWN_SECONDS // 86400)}d" if failed else "",
        )

    def _media_catalog_hint(self) -> str:
        """Короткая семантическая карта того, какие media реально есть у аккаунта.

        Модель видит название набора и alt/смысловой маркер каждого элемента,
        поэтому может отличать, например, смешной стикер от грустного, а не
        выбирать любой случайный файл. Полный каталог в prompt не кладём.

        Custom emoji (E-номера) показываются модели, только если у аккаунта
        есть Telegram Premium: без Premium Telegram сам, на уровне сервера,
        заменяет entity custom emoji на обычный unicode alt для ВСЕХ
        получателей, независимо от того, что было отправлено в MTProto-запросе.
        Показывать эти индексы без Premium — гарантированно получать в чате
        обычный смайлик вместо арта пака, что выглядит как баг, хотя код
        отправки при этом отрабатывает корректно.
        """
        lines = []

        def _pick(catalog, meta_dict, limit):
            # Каждый тик — другой срез каталога (описанные в приоритете), но с
            # НАСТОЯЩИМИ индексами: раньше модель видела только первые 60/40
            # элементов, и остальные стикеры не использовались никогда.
            idxs = list(range(len(catalog)))
            random.shuffle(idxs)
            idxs.sort(key=lambda i: 0 if (meta_dict.get(int(catalog[i].id), {}).get("vision")
                                          or meta_dict.get(int(catalog[i].id), {}).get("alt")) else 1)
            return sorted(idxs[:limit])

        for i in _pick(self._sticker_catalog, self._sticker_meta, 60):
            meta = self._sticker_meta.get(int(self._sticker_catalog[i].id), {})
            pack = meta.get("pack") or "без названия"
            smysl = meta.get("vision") or meta.get("alt") or "без описания"
            lines.append(f"S{i + 1}: набор={pack!r}; смысл={smysl!r}")
        if self._is_premium:
            for i in _pick(self._custom_emoji_catalog, self._custom_emoji_meta, 40):
                meta = self._custom_emoji_meta.get(int(self._custom_emoji_catalog[i].id), {})
                pack = meta.get("pack") or "без названия"
                smysl = meta.get("vision") or meta.get("alt") or "без описания"
                lines.append(f"E{i + 1}: набор={pack!r}; смысл={smysl!r}")
        elif self._custom_emoji_catalog:
            lines.append(
                "[custom emoji недоступны: у аккаунта нет Telegram Premium, "
                "поэтому custom emoji нельзя использовать — не предлагай их]"
            )
        if not lines:
            return "[Telegram media] У аккаунта пока нет доступного каталога стикеров/custom emoji."
        return "[Telegram media] Это реальные элементы, доступные аккаунту Марин. Выбирай по смыслу:\n" + "\n".join(lines)

    async def _send_sticker(self, chat, index: Optional[int] = None) -> bool:
        if not self._sticker_catalog:
            return False
        try:
            if index is not None and 1 <= index <= len(self._sticker_catalog):
                doc = self._sticker_catalog[index - 1]
            else:
                doc = random.choice(self._sticker_catalog)
            if isinstance(doc, LocalSticker):
                await self.client.send_file(
                    chat, doc.path,
                    attributes=[types.DocumentAttributeSticker(alt="🙂", stickerset=types.InputStickerSetEmpty())],
                )
            else:
                await self.client.send_file(chat, doc)
            return True
        except Exception:
            logger.debug("Could not send sticker", exc_info=True)
            return False

    async def _send_custom_emoji(self, chat, index: Optional[int] = None) -> bool:
        if not self._custom_emoji_catalog or not self._is_premium:
            return False
        try:
            if index is not None and 1 <= index <= len(self._custom_emoji_catalog):
                doc = self._custom_emoji_catalog[index - 1]
            else:
                doc = random.choice(self._custom_emoji_catalog)
            alt = "*"
            for attr in getattr(doc, "attributes", []) or []:
                if type(attr).__name__ == "DocumentAttributeCustomEmoji":
                    alt = getattr(attr, "alt", None) or alt
                    break
            # ВАЖНО: offset/length у Telegram entity считаются в UTF-16
            # code units, а не в кодовых точках Python. Большинство emoji-
            # alt (напр. "😍" = U+1F60D) лежат за пределами BMP и занимают
            # 2 UTF-16 unit'а, а Python len() вернёт 1 — при неверной длине
            # Telegram молча отбрасывает entity и присылает получателю
            # обычный текст alt вместо настоящего custom emoji.
            alt_len_utf16 = len(alt.encode("utf-16-le")) // 2
            entity = types.MessageEntityCustomEmoji(offset=0, length=alt_len_utf16, document_id=doc.id)
            await self.client.send_message(chat, alt, formatting_entities=[entity])
            logger.info("Sent custom emoji document_id=%s alt=%r", doc.id, alt)
            return True
        except Exception:
            logger.warning("Could not send custom emoji", exc_info=True)
            return False
