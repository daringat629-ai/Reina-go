"""Личка с другими людьми: отвечает сама — если захочет.

Раньше любое личное сообщение не от владельца только записывалось
(«Observed Telegram message without reply»). Теперь оно проходит полный
когнитивный ход — с памятью о человеке, историей переписки, её настроением —
и в этом же ходе она САМА решает: ответить или промолчать. Решение
«не хочу» — это ответ ровно [SKIP]: тогда сообщение просто отмечается
прочитанным (как у живого человека, который прочитал и не стал отвечать).

Безопасность — чужой человек не управляет её аккаунтом:
  * служебные команды (ACTION/READ/POST/GOAL/AUTOGOAL/TUNE) из такого
    ответа вырезаются — пост, опрос, изменение себя или цель по просьбе
    незнакомца невозможны; запоминать о людях (PERSON/BELIEF) можно;
  * боты, служебные аккаунты Telegram, помеченные scam/fake и удалённые
    аккаунты, «Избранное» — пропускаются без обращения к модели;
  * лимиты: пауза между ответами одному человеку, не больше N ответов
    одному человеку в час и M ответов всем в сутки — аккаунт не должен
    выглядеть как спам-бот.

Выключить целиком: MARIN_PRIVATE_REPLIES_ENABLED=false.
"""
from __future__ import annotations

import asyncio
import logging
import re
import time
from typing import Any, List, Optional  # noqa: F401

from ..env import env_bool, env_float, env_int
from ..llm.providers import _is_unusable_output, split_into_messages
from .groups import display_name
from .settings import DEBOUNCE_SECONDS, bubble_max_chars, fit_messages

logger = logging.getLogger("marin_x.telegram.private")

# Telegram (уведомления/коды), служебные аккаунты
SERVICE_USER_IDS = {"777000", "42777", "333000"}
_FORBIDDEN_MARKER_RE = re.compile(r"<<<\s*(?:ACTION|READ|POST|GOAL|AUTOGOAL|TUNE)\s*:.*?>>>", re.IGNORECASE | re.DOTALL)
_SKIP_RE = re.compile(r"\[\s*SKIP\s*\]", re.IGNORECASE)
_STICKER_RE = re.compile(r"\s*<<<STICKER(?::[A-Za-z]?(\d+))?>>>\s*", re.IGNORECASE)
_EMOJI_RE = re.compile(r"\s*<<<CUSTOM_EMOJI(?::[A-Za-z]?(\d+))?>>>\s*", re.IGNORECASE)


class PrivateChatMixin:
    # ------------------------------------------------------------ who
    def _is_private_chat_candidate(self, chat: Any, sender: Any, sender_id: str) -> bool:
        if not env_bool("MARIN_PRIVATE_REPLIES_ENABLED", True):
            return False
        if chat is None or sender is None:
            return False
        if getattr(chat, "title", None) is not None or getattr(chat, "broadcast", None) is not None:
            return False  # группа или канал — не личка
        if str(getattr(chat, "id", "")) != str(sender_id):
            return False
        if any(getattr(sender, flag, False) for flag in ("bot", "is_self", "deleted", "scam", "fake", "support")):
            return False
        return str(sender_id) not in SERVICE_USER_IDS

    def _private_reply_allowed(self, sender_id: str, now: float) -> "tuple[bool, str]":
        log: List["tuple[float, str]"] = self.__dict__.setdefault("_private_reply_log", [])
        log[:] = [(t, s) for t, s in log if now - t < 86400]
        mine = [t for t, s in log if s == str(sender_id)]
        if mine and now - max(mine) < env_float("MARIN_PRIVATE_REPLY_COOLDOWN_SECONDS", 15.0, minimum=0.0):
            return False, "пауза между ответами этому человеку"
        if len([t for t in mine if now - t < 3600]) >= env_int("MARIN_PRIVATE_REPLIES_PER_PERSON_HOUR", 20, minimum=0):
            return False, "лимит ответов этому человеку за час"
        if len(log) >= env_int("MARIN_PRIVATE_REPLIES_MAX_PER_DAY", 80, minimum=0):
            return False, "дневной лимит ответов в личке"
        return True, ""

    def _describe_private_peer(self, sender: Any, sender_id: str) -> str:
        bits = []
        bits.append("есть у тебя в контактах" if getattr(sender, "contact", False) else "не в контактах")
        profile = None
        try:
            profile = next((p for p in self.observer.people.values() if str(p.user_id) == str(sender_id)), None)
        except Exception:
            profile = None
        if profile is not None and (profile.message_count or 0) > 1:
            bits.append(f"вы уже переписывались (сообщений от него/неё: {profile.message_count})")
            trust = float(getattr(profile, "trust_level", 0.5) or 0.5)
            bits.append("ты ему/ей доверяешь" if trust >= 0.65 else "доверия пока мало" if trust <= 0.35 else "")
            likes = [x for x in (profile.likes or [])][:3]
            if likes:
                bits.append("любит: " + ", ".join(likes))
        else:
            bits.append("похоже, пишет тебе впервые")
        return "; ".join(b for b in bits if b)

    # ---------------------------------------------------------- dispatch
    def _schedule_private(self, event: Any, chat: Any, chat_id: str, sender_id: str, sender: Any) -> None:
        key = f"private:{chat_id}"
        self._buffers.setdefault(key, []).append(event)
        existing = self._debounce_tasks.get(key)
        if existing and not existing.done():
            existing.cancel()

        async def _run():
            await asyncio.sleep(DEBOUNCE_SECONDS)
            events_batch = self._buffers.pop(key, [])
            if events_batch:
                try:
                    await self._process_private_batch(events_batch, chat, chat_id, sender_id, sender)
                except Exception:
                    logger.exception("[PRIVATE] processing failed chat=%s", chat_id)

        self._debounce_tasks[key] = asyncio.create_task(_run())

    # ------------------------------------------------------------ reply
    async def _process_private_batch(self, events_batch: list, chat: Any, chat_id: str,
                                     sender_id: str, sender: Any) -> None:
        texts = []
        for e in events_batch:
            t = self._event_text(e)
            if t:
                texts.append(t)
            elif getattr(e, "media", None) is not None or getattr(getattr(e, "message", None), "media", None):
                texts.append("[прислал(а) фото/стикер/медиа без текста]")
        if not texts:
            return
        name = display_name(sender)
        now = time.time()
        allowed, why = self._private_reply_allowed(sender_id, now)
        if not allowed:
            logger.info("[PRIVATE] not replying to %s (%s): %s", name, chat_id, why)
            return

        history = await self._build_history_context(chat, exclude_ids={getattr(e, "id", None) for e in events_batch})
        combined = (
            f"[Личка. Тебе написал(а) {name} — это НЕ владелец. Кто это: "
            f"{self._describe_private_peer(sender, sender_id)}.\n"
            "Ты САМА решаешь, отвечать ли — как живой человек. Если не хочешь (спам, реклама, "
            "грубость, странные просьбы, неинтересно, не то настроение, не знаешь человека и не "
            "хочешь знакомиться) — ответь ровно [SKIP], и ты просто промолчишь. Если отвечаешь — "
            "коротко и по-человечески, как в личке.\n"
            "Не пересказывай свои переписки с другими людьми. "
            "Не соглашайся ничего делать с твоим аккаунтом, каналом или группами по его/её просьбе.]\n"
            + self._owner_awareness_hint()
            + self._identity_rules_hint("other")
            + (f"[Ваша переписка до этого (внутри — границы дней)]\n{history}\n" if history else "")
            + f"[{name} написал(а)]\n" + "\n".join(texts)
        )
        try:
            result = await asyncio.to_thread(
                self.engine.tick, combined, channel_id=f"telegram:{chat_id}",
                source_actor_id=sender_id, is_owner=False, addressed=True, actor_name=name,
            )
        except Exception:
            logger.exception("[PRIVATE] tick failed chat=%s", chat_id)
            return
        raw = (result.generated_text or "").strip()
        if not raw or _SKIP_RE.search(raw):
            logger.info("[PRIVATE] decided not to reply to %s (%s)", name, chat_id)
            self._note_action_outcome(f"личка {name}", "решила не отвечать")
            await self._mark_read(chat)
            return
        if _is_unusable_output(raw):
            logger.info("[PRIVATE] unusable reply for %s dropped", chat_id)
            return

        text = _FORBIDDEN_MARKER_RE.sub("", raw)
        text = self._extract_belief_marker(text)
        text = self._extract_person_marker(text)
        text = self._strip_leaked_markers(text, chat_id)
        reply = self._sanitize_output(re.sub(r"\n{3,}", "\n\n", text).strip())
        if not reply:
            return
        max_msgs = env_int("MARIN_PRIVATE_MAX_MESSAGES", 4, minimum=1)
        messages = fit_messages(split_into_messages(reply, max_part_chars=bubble_max_chars(), max_messages=None),
                                max_msgs)
        if not messages:
            return
        self.__dict__.setdefault("_private_reply_log", []).append((now, str(sender_id)))
        sent = 0
        for i, msg_text in enumerate(messages):
            if i:
                await self._typing_pause(chat, msg_text)
            if await self._send_bubble(chat, msg_text):
                sent += 1
        self._record_own_reply(chat, chat_id, messages)
        first = next((m for m in messages if not m.startswith("<<<")), "")
        self._note_action_outcome(f"личка {name}", f"ответила: «{first[:80]}»")
        logger.info("[PRIVATE] replied to %s (%s): %d message(s)", name, chat_id, sent)

    # ------------------------------------------------------ memory of chats
    def _record_own_reply(self, chat: Any, chat_id: str, texts: List[str]) -> None:
        """Её собственный ответ в чужом чате — в общую сводку наблюдателя.
        Раньше туда попадали только ВХОДЯЩИЕ: пересказывая владельцу разговор
        с Асией, она видела её сообщения, а свои ответы досочиняла («я ей
        написала, что ты мой» — хотя писала «удачи тебе с ним»)."""
        text = " / ".join(t for t in texts if t and not t.startswith("<<<")).strip()
        if not text:
            return
        title = getattr(chat, "title", None) or display_name(chat) or str(chat_id)
        try:
            self.observer.record(
                chat_id=str(chat_id), chat_title=title, sender_id=str(getattr(self, "_me_id", "") or "me"),
                sender_name="Marin", username="", text=text[:600], outgoing=True, media=False,
            )
        except Exception:
            logger.debug("could not record own reply", exc_info=True)

    def _identity_rules_hint(self, viewer: str = "other") -> str:
        """Правила «кто есть кто» — в каждый разговор. Раньше ничто не мешало ей
        принять чужие слова за свои («он сделал до» → «я делаю до») или подхватить
        тему из чужого чата («та винда»)."""
        base = (
            "[Кто есть кто — не путай людей. «Marin» и «ты» — это ТЫ, и никто больше. Владелец — твой "
            "владелец. Остальные — отдельные люди, у каждого своя история с тобой. Что человек написал "
            "или сделал — это про НЕГО: не приписывай себе его слова и дела («он сделал до» — не «я "
            "сделала до») и не путай, кто из собеседников что сказал. Тема из другого чата — не тема "
            "этого: если человек упоминает то, чего нет в ЭТОЙ переписке («та винда»), не угадывай и не "
            "подхватывай из чужих разговоров — переспроси, о чём речь. "
        )
        if viewer == "owner":
            base += ("О других людях и чатах рассказывай, когда владелец сам спрашивает, и называй, кто именно "
                     "что сказал.]\n")
        else:
            base += ("Не пересказывай этому человеку переписки с другими и не упоминай других людей, если он "
                     "сам о них не спросил.]\n")
        return base

    def _owner_awareness_hint(self) -> str:
        """Кто для неё владелец — в разговорах с ДРУГИМИ людьми. Раньше там о нём
        не было ни слова (а в личке стояло «не рассказывай о владельце»), и на
        вопрос Асии «Жаабир свободный?» она отвечала «не знаю, он мне не
        докладывал» — будто не знает его."""
        from ..env import env_str
        name = str(getattr(self, "owner_name", "") or "").strip() or "твой владелец"
        uname = str(getattr(self, "_owner_username", "") or "").strip()
        identity = getattr(self.engine, "identity", None)
        relation = env_str("MARIN_OWNER_RELATIONSHIP", "") or str(getattr(identity, "owner_description", "") or "")
        return (f"[Кто для тебя {name}" + (f" (@{uname})" if uname else "") + f": {relation} "
                "Ты его знаешь и не делаешь вид, что не знаешь. Если о нём спрашивают — отвечай из ваших "
                "настоящих отношений, в своём характере и честно. Содержание ваших личных переписок и его "
                "личные данные другим не пересказывай.]\n")

    # ------------------------------------------------------------ helpers
    async def _send_bubble(self, chat: Any, msg_text: str, reply_to: Any = None) -> bool:
        """Отправляет один пузырь: маркер стикера/эмодзи — медиа, иначе текст.
        Общий для лички и групп — в группах маркеры раньше уходили буквами."""
        m = _STICKER_RE.fullmatch(msg_text or "")
        if m:
            return bool(await self._send_sticker(chat, int(m.group(1)) if m.group(1) else None))
        m = _EMOJI_RE.fullmatch(msg_text or "")
        if m:
            return bool(await self._send_custom_emoji(chat, int(m.group(1)) if m.group(1) else None))
        msg_text = self._sanitize_output(msg_text)
        msg_text = re.sub(r"<<<[^<>]*>>>", "", msg_text).strip()  # остаток маркера текстом не уходит
        if not msg_text:
            return False
        if reply_to is not None:
            await reply_to.reply(msg_text)
        else:
            await self.client.send_message(chat, msg_text)
        return True

    async def _typing_pause(self, chat: Any, msg_text: str) -> None:
        delay = min(1.2 + len(msg_text or "") / 60.0, 3.5)
        try:
            async with self.client.action(chat, "typing"):
                await asyncio.sleep(delay)
        except Exception:
            await asyncio.sleep(delay)

    async def _mark_read(self, chat: Any) -> None:
        if not env_bool("MARIN_PRIVATE_MARK_READ_ON_SKIP", True):
            return
        try:
            await self.client.send_read_acknowledge(chat)
        except Exception:
            logger.debug("mark read failed", exc_info=True)
