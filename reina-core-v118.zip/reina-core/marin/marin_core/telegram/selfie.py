"""
selfie.py — "она сама может кидать свои селфи" (роадмап п.12: Voice + vision
+ Telegram media). Реализует ГЕНЕРАЦИЮ изображения — то, чего раньше не было
вообще (send_photo/send_video/send_audio в client.py только пересылают уже
существующие сообщения-медиа, см. _resend_media, ничего не создают заново).

Разделено по тому же принципу, что actions.py/goal_executor.py: этот файл —
чистый Python без Telethon, тестируемый в изоляции; client.py — тонкая
Telethon-обвязка (action handler + client.send_file). Так весь этот модуль
можно прогнать в CI/юнит-тестах без установленного telethon и без реального
Telegram-аккаунта.

Безопасность контента — НЕ предложение, а жёсткий контракт:
  - SELFIE_STYLE_GUARDRAIL приклеивается к КАЖДОМУ запросу генерации и не
    переопределяется ни моделью Marin, ни payload'ом действия, ни
    прямой просьбой владельца — это часть кода, а не промпта.
  - _looks_unsafe() — лексический фильтр второго рубежа: если prompt_hint
    (то, что предложила сгенерировать модель) явно про NSFW — запрос
    не уходит в сеть вообще, до какого-либо API-вызова.
  - Ни то, ни другое не заменяет собственную модерацию провайдера — это
    defense-in-depth, а не гарантия "невозможно сгенерировать плохое".
"""

from __future__ import annotations

import base64
import logging
from dataclasses import dataclass
from typing import Optional, Protocol

logger = logging.getLogger("marin_core.telegram.selfie")


SELFIE_STYLE_GUARDRAIL = (
    "casual smartphone selfie photo, everyday modest clothing covering "
    "shoulders to collarbone, non-sexual, safe-for-work, natural pose, "
    "photorealistic phone camera look"
)
# Режим по умолчанию: селфи рисуется ПО РЕФЕРЕНСУ — тот же персонаж и тот же
# стиль рисовки, что на аватаре. Раньше в запросе стояло «photorealistic phone
# camera look», модель слушалась текста и рисовала фото случайной реальной
# девушки, а референс игнорировала.
SELFIE_REFERENCE_INSTRUCTION = (
    "The attached image is the reference of ME — the girl who is taking this selfie. "
    "Draw exactly the same character as in the reference: the same face, the same hairstyle "
    "and hair colour, the same eye colour and accessories, and the same art style, line work "
    "and colouring as the reference image. Do NOT turn her into a real person or a photograph "
    "and do not change her appearance. If the reference looks like a round avatar with a glowing "
    "ring or border, that circle is NOT part of her — never draw it."
)
# Раньше тут было «her own arm holding the phone» — модель рисовала вид СО
# СТОРОНЫ: девушка держит телефон, телефон в кадре. Селфи — это то, что видит
# фронтальная камера: она смотрит в объектив, телефона в кадре нет.
SELFIE_COMPOSITION = (
    "a real selfie: the picture IS what her phone's front camera sees — she looks straight into "
    "the lens (eye contact with the viewer), her face and upper body fill the frame from arm's "
    "length, slight high angle; the phone itself is NOT visible. Square full-bleed image edge to "
    "edge — no circular frame, no round vignette, no border, no ring"
)
SELFIE_SAFE_OUTFIT = (
    SELFIE_COMPOSITION + ". Everyday modest clothing covering shoulders to collarbone, "
    "non-sexual, safe-for-work, natural pose"
)
SELFIE_REFERENCE_AVOID = (
    "photorealistic photo, real person, different face, different hair colour, third-person view, "
    "someone photographing her from the side, the phone visible in the frame, mirror selfie, "
    "circular frame, round avatar, glowing ring, border"
)
SELFIE_NEGATIVE_PROMPT = (
    "nudity, nsfw, sexual content, suggestive pose, lingerie, swimwear, "
    "bikini, underwear, exposed skin below the collarbone, revealing outfit"
)

_BLOCKED_TERMS = (
    "nude", "naked", "nsfw", "sex", "porn", "lingerie", "bikini", "underwear",
    "topless", "cleavage", "голая", "голышом", "без одежды", "секс", "порно",
    "нижнем белье", "белье", "купальник", "бикини", "обнажен", "раздет",
)


def _style_mode() -> str:
    """MARIN_SELFIE_STYLE: reference (по умолчанию — как на референсе) | photo."""
    import os
    mode = (os.getenv("MARIN_SELFIE_STYLE", "reference") or "reference").strip().lower()
    return "photo" if mode in {"photo", "photoreal", "realistic", "фото"} else "reference"


def _looks_unsafe(prompt_hint: str) -> bool:
    text = (prompt_hint or "").lower()
    return any(term in text for term in _BLOCKED_TERMS)


class SelfieGenerationError(Exception):
    """Ожидаемая, обрабатываемая ошибка генерации (не настроено / отказ по
    безопасности / провайдер недоступен) — отличается от неожиданных
    исключений, которые должны падать шумно."""


class SelfieGenerator(Protocol):
    async def generate(self, prompt_hint: str, reference_image_b64: Optional[str] = None) -> bytes: ...


class DisabledSelfieGenerator:
    """Дефолт, если провайдер не настроен — явная, понятная ошибка вместо
    попытки куда-то сходить и упасть с невнятным исключением внутри
    Telethon-обработчика."""

    async def generate(self, prompt_hint: str, reference_image_b64: Optional[str] = None) -> bytes:
        raise SelfieGenerationError(
            "Генерация селфи не настроена — нужен MARIN_SELFIE_API_KEY "
            "(или уже существующий MARIN_OPENROUTER_API_KEY) в .env."
        )


@dataclass
class OpenRouterSelfieConfig:
    api_key: str
    model: str = "google/gemini-2.5-flash-image"
    base_url: str = "https://openrouter.ai/api/v1"
    timeout: float = 60.0


class OpenRouterSelfieGenerator:
    """POST {base_url}/chat/completions с modalities=["image","text"] —
    unified Image API OpenRouter (см. openrouter.ai/docs/features/multimodal/
    image-generation). Использует тот же ключ/эндпоинт, что уже настроен
    для обычного чата (MARIN_OPENROUTER_API_KEY) — если он уже есть в .env,
    для селфи отдельно заводить ничего не нужно, см. config.py::build_selfie_generator.

    reference_image_b64 (опционально) — референсное фото лица (см.
    marin_core/assets/marin_face_reference.jpg), передаётся как image_url
    в том же user-сообщении, чтобы модели с поддержкой image-to-image
    старались сохранить узнаваемую внешность между генерациями, а не
    рисовали каждый раз нового случайного персонажа."""

    def __init__(self, config: OpenRouterSelfieConfig):
        self.config = config

    async def generate(self, prompt_hint: str, reference_image_b64: Optional[str] = None) -> bytes:
        if _looks_unsafe(prompt_hint):
            raise SelfieGenerationError("Такое селфи не сгенерирую — запрос похож на NSFW-контент.")

        import asyncio
        try:
            import requests
        except ImportError as e:
            raise SelfieGenerationError(
                "OpenRouterSelfieGenerator requires the 'requests' package (pip install requests)."
            ) from e

        use_reference = bool(reference_image_b64) and _style_mode() == "reference"
        content = []
        if reference_image_b64:
            # референс — ПЕРВЫМ: инструкция ниже ссылается на «attached image»
            content.append({
                "type": "image_url",
                "image_url": {"url": f"data:image/jpeg;base64,{reference_image_b64}"},
            })
        content.append({"type": "text", "text": self._build_prompt(prompt_hint, use_reference)})

        payload = {
            "model": self.config.model,
            "messages": [{"role": "user", "content": content}],
            "modalities": ["image", "text"],
            # квадратный кадр (не круг, как у аватара-референса)
            "image_config": {"aspect_ratio": "1:1"},
        }
        headers = {
            "Authorization": f"Bearer {self.config.api_key}",
            "Content-Type": "application/json",
        }

        def _do_request():
            url = f"{self.config.base_url.rstrip('/')}/chat/completions"
            resp = requests.post(url, json=payload, headers=headers, timeout=self.config.timeout)
            if getattr(resp, "status_code", 200) == 400 and "image_config" in payload:
                # модель не знает image_config — квадрат остаётся в тексте запроса
                logger.warning("image model rejected image_config (400): %s", str(getattr(resp, "text", ""))[:200])
                payload.pop("image_config", None)
                resp = requests.post(url, json=payload, headers=headers, timeout=self.config.timeout)
            resp.raise_for_status()
            return resp.json()

        try:
            data = await asyncio.to_thread(_do_request)
        except Exception as e:  # noqa: BLE001 — сеть/HTTP-ошибка любого рода
            raise SelfieGenerationError(f"OpenRouter image API недоступен: {e}") from e

        return self._extract_image_bytes(data)

    def _build_prompt(self, prompt_hint: str, use_reference: bool = False) -> str:
        hint = (prompt_hint or "").strip() or "a friendly casual selfie, smiling"
        if use_reference:
            return (f"{SELFIE_REFERENCE_INSTRUCTION} Scene of the selfie: {hint}. "
                    f"{SELFIE_SAFE_OUTFIT}. Avoid: {SELFIE_REFERENCE_AVOID}, {SELFIE_NEGATIVE_PROMPT}.")
        return f"{hint}. Style: {SELFIE_STYLE_GUARDRAIL}. Avoid: {SELFIE_NEGATIVE_PROMPT}."

    @staticmethod
    def _extract_image_bytes(data: dict) -> bytes:
        choices = data.get("choices") or []
        if not choices:
            raise SelfieGenerationError(f"OpenRouter image API вернул пустой ответ: {data!r}")
        images = (choices[0].get("message") or {}).get("images") or []
        if not images:
            raise SelfieGenerationError("Модель не вернула изображение (возможно, отклонила промпт).")
        url = (images[0].get("image_url") or {}).get("url", "")
        if not url.startswith("data:"):
            raise SelfieGenerationError(f"Неожиданный формат ответа изображения: {url[:60]!r}")
        b64_part = url.split(",", 1)[-1]
        return base64.b64decode(b64_part)
