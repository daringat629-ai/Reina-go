"""Telegram transport for Marin X.

Imports are lazy so that pure modules (intents, channel_publisher, ...) can be
used/tested without Telethon installed.
"""
__all__ = ["MarinTelegramClient", "TelegramConfig"]


def __getattr__(name):
    if name == "MarinTelegramClient":
        from .client import MarinTelegramClient
        return MarinTelegramClient
    if name == "TelegramConfig":
        from .settings import TelegramConfig
        return TelegramConfig
    raise AttributeError(name)
