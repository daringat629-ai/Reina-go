"""Telethon transport for Marin X.

The adapter deliberately keeps Telegram outside the cognitive core:
Telethon normalizes an incoming message, CognitiveEngine.tick() performs the
whole cognitive cycle, and the adapter sends only TickResult.generated_text.

The class is now composed of cohesive mixins (see ARCHITECTURE.md);
this file only keeps the lifecycle, inbound pipeline and outbound delivery.
"""
from __future__ import annotations

import datetime as _dt

import asyncio
import json
import logging
import os
import random
import re
import time
from typing import Any, Dict, List, Optional, Set

from telethon import TelegramClient, events, functions, utils

from ..config import build_engine, load_config
from ..env import env_float, env_int
from ..engine.autonomous_life import AutonomousLifeLoop
from ..engine.cognitive_engine import CognitiveEngine
from ..engine.scheduler import ConsolidationScheduler, SchedulerConfig
from ..state_store import StateStore
from ..llm.output_guard import normalize_markers, strip_protocol_junk
from .resolver import tg_error_reason
from .private_chats import PrivateChatMixin
from .selfie_director import SelfieDirector
from .self_awareness import KNOBS, SelfModel, SelfTuning, default_tuning_path, extract_tune_markers, resolve_knob
from ..llm.providers import _is_unusable_output, split_into_messages
from .actions import ACTION_MARKER_RE, ActionRegistry, TelegramActions
from .awareness import AwarenessMixin
from .channel_publisher import ChannelPublisher, PublishResult
from .comments import CommunityMixin
from .commands import OwnerCommandsMixin
from .goal_executor import SAFE_AUTO_APPROVE_KINDS, AutonomousGoalExecutor
from .groups import GroupMixin, display_name
from .reminders import parse_reminder
from .intents import AutopostIntent, DeleteLastPostIntent, PostIntent, ProactiveIntent, detect_intent
from .markers import MarkersMixin
from .media import MediaMixin
from .observer import TelegramObserver
from .proactive import ProactiveLoop
from .read_handlers import ReadActionsMixin
from .registries import StateRegistriesMixin
from .resolver import EntityResolverMixin
from .write_handlers import WriteActionsMixin
from .settings import (
    local_now,
    JSON_PAYLOAD_CHAT_KEY,
    DASHBOARD_COMMANDS,
    DEBOUNCE_SECONDS,
    DIARY_COMMANDS,
    EXPORT_COMMANDS,
    FULL_OBSERVER_COMMANDS,
    HISTORY_CONTEXT_MESSAGES,
    HISTORY_EARLIER_DAYS,
    HISTORY_EARLIER_LINE_CHARS,
    HISTORY_EARLIER_MESSAGES,
    IMPORT_COMMANDS,
    MAX_REPLY_MESSAGES,
    MESSAGE_GAP_MAX_SECONDS,
    MESSAGE_GAP_MIN_SECONDS,
    MIN_REPLY_MESSAGES,
    REPLY_BUBBLE_MAX_CHARS,
    bubble_max_chars,
    cap_messages,
    OBSERVER_COMMANDS,
    QUIET_HOURS_REPLY_DELAY_MAX,
    QUIET_HOURS_REPLY_DELAY_MIN,
    READ_DELAY_SECONDS,
    REPLY_DELAY_SECONDS,
    SCHEDULER_CHECK_INTERVAL,
    STATE_IMPORT_FILE,
    STATUS_COMMANDS,
    WHY_COMMANDS,
    THOUGHTS_COMMANDS,
    TelegramConfig,
    VISION_ENABLED,
    VISION_MODEL,
    _is_quiet_hours,
)

logger = logging.getLogger("marin_x.telegram")


async def last_event_reply(events_batch: list, text: str) -> None:
    """Fallback-ответ на последнее сообщение пачки (когда тик не дал текста)."""
    if not text or not events_batch:
        return
    try:
        await events_batch[-1].reply(text)
    except Exception:
        logger.debug("fallback reply failed", exc_info=True)



async def _extract_audio_ogg(video_bytes: bytes) -> "tuple[bytes, str]":
    """Звук из видео-«кружочка» в ogg/opus через ffmpeg; без ffmpeg — как есть (mp4)."""
    import shutil
    if not shutil.which("ffmpeg"):
        return video_bytes, "mp4"
    proc = await asyncio.create_subprocess_exec(
        "ffmpeg", "-loglevel", "error", "-i", "pipe:0", "-vn", "-ac", "1", "-c:a", "libopus", "-f", "ogg", "pipe:1",
        stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
    out, _err = await proc.communicate(video_bytes)
    return (out, "ogg") if proc.returncode == 0 and out else (video_bytes, "mp4")


class MarinTelegramClient(
    PrivateChatMixin,
    EntityResolverMixin,
    CommunityMixin,
    GroupMixin,
    StateRegistriesMixin,
    MediaMixin,
    MarkersMixin,
    ReadActionsMixin,
    WriteActionsMixin,
    AwarenessMixin,
    OwnerCommandsMixin,
):
    """Connects a Telegram user account to one persistent CognitiveEngine."""

    def __init__(self, engine: Optional[CognitiveEngine] = None, config: Optional[TelegramConfig] = None):
        # ВАЖНО: load_config() должен идти ПЕРВЫМ — именно она вызывает
        # load_dotenv() внутри себя (см. marin_core/config.py). Раньше
        # TelegramConfig.from_env() вызывался до неё и читал os.environ
        # ДО того, как .env вообще был загружен в процесс — из-за этого
        # TELEGRAM_API_ID/TELEGRAM_API_HASH никогда не находились, даже
        # если они были в .env: RuntimeError падал независимо от содержимого
        # файла. Простое переупорядочивание этих двух строк чинит это.
        core_cfg = load_config()
        self.config = config or TelegramConfig.from_env()
        if self.config.owner_id and not core_cfg.owner_id:
            core_cfg.owner_id = self.config.owner_id
        self.engine = engine or build_engine(config=core_cfg)
        # Долговременная память: восстанавливаем снимок ДО любых записей
        # фактов, чтобы id из снимка легли как есть (импорт идемпотентен).
        self.state_store = StateStore(
            os.getenv("MARIN_STATE_FILE", "data/marin_state.json"),
            backups=env_int("MARIN_STATE_BACKUPS", 3),
        )
        self._state_autosave_seconds = max(30.0, env_float("MARIN_STATE_AUTOSAVE_SECONDS", 300))
        self._state_restored = None
        if os.getenv("MARIN_STATE_PERSIST", "true").lower() in {"1", "true", "yes", "on"}:
            try:
                self._state_restored = self.state_store.load_into(self.engine)
            except Exception:
                logger.exception("[STATE] restore failed — starting with empty memory")
        else:
            self.state_store = None
        self.scheduler = ConsolidationScheduler(
            self.engine, SchedulerConfig(write_diary=core_cfg.diary_enabled)
        )
        self.client = TelegramClient(self.config.session, self.config.api_id, self.config.api_hash)
        self._registered = False
        self._me_id: Optional[int] = None
        self._is_premium: bool = False
        self._own_username: str = ""
        self._own_identity_summary: str = "Марин ещё не авторизовалась в этой сессии."
        self._admin_chats_summary: str = "Список админ-чатов ещё не подгружался в этой сессии."
        self._scheduler_task: Optional[asyncio.Task] = None

        # Дебаунс-буферы для "чтения" пачки сообщений одним тиком (см.
        # DEBOUNCE_SECONDS выше). Ключ — "chat_id:sender_id", т.к. в группах
        # разные собеседники не должны смешиваться в одну пачку.
        self._buffers: Dict[str, list] = {}
        self._debounce_tasks: Dict[str, asyncio.Task] = {}
        self.observer = TelegramObserver(
            path=core_cfg.telegram_observer_file,
            max_events=core_cfg.telegram_observer_max_events,
        )
        self.owner_name = core_cfg.owner_name
        self.allow_emoji = core_cfg.allow_emoji
        self._last_owner_activity = time.time()
        self._sticker_catalog = []
        self._custom_emoji_catalog = []
        self._sticker_meta: Dict[int, Dict[str, str]] = {}
        self._custom_emoji_meta: Dict[int, Dict[str, str]] = {}
        self._media_packs: Dict[str, Dict[str, str]] = {}
        self._local_stickers: list = []
        self._selfie_generator = None  # lazy — см. _get_selfie_generator()
        self._illustration_generator = None  # lazy — см. _get_illustration_generator()
        self._selfie_reference_b64: Optional[str] = None  # lazy — см. _get_selfie_reference()
        self._voice_generator = None  # lazy — см. _get_voice_generator()
        self.telegram_actions = TelegramActions(self.client)
        self.actions = ActionRegistry()
        self._readonly_actions: Dict[str, Any] = {}
        self._register_actions()
        self._load_media_pack_registry()
        self._own_channels: Dict[str, Dict[str, Any]] = {}
        # Stage 5.D: самокоррекция маркеров — одноразовая заметка "в прошлый
        # раз ты сломала тег вот так" для следующего тика того же чата, а не
        # молчаливое исправление, которое модель никогда не видит и поэтому
        # не учится не повторять. Намеренно НЕ персистится на диск — это
        # подсказка на один следующий ответ, не долгосрочная память.
        self._last_marker_issue: Dict[str, str] = {}
        self._load_own_channels_registry()
        self._vision_cache: Dict[str, str] = {}
        self._load_vision_cache()
        self._vision_failures: Dict[str, float] = {}  # doc_id -> когда в последний раз не вышло
        self._load_vision_failures()
        self._dialogs_summary: str = ""
        self._dialogs_refreshed_at: float = 0.0
        # Stage 4: автономное выполнение долгосрочных целей — тот же
        # self.actions/self._readonly_actions/self.engine.goal_set, никакой
        # второй системы (см. goal_executor.py).
        # Единственный исполнитель публикаций в свои каналы (ручные просьбы,
        # <<<POST>>>, автопостинг, циклические шаги целей) — см.
        # channel_publisher.py. Создаётся ДО goal_executor/autonomous_life,
        # которые им пользуются.
        self.publisher = ChannelPublisher(self)
        self._action_outcomes: List[str] = []
        # Самонаблюдение + подстройка в рамках (telegram/self_awareness.py)
        self.self_tuning = SelfTuning(default_tuning_path())
        self.self_tuning.apply_all()
        self.self_model = SelfModel(self)
        # Режиссёр селфи: кадр по тексту, времени и одежде дня (selfie_director.py)
        self.selfie_director = SelfieDirector(self)
        self._owner_username: str = ""
        self.goal_executor = AutonomousGoalExecutor(self)
        self.proactive = ProactiveLoop(self)
        self._discussion_cache: Dict[str, Optional[str]] = {}
        self._comment_cooldowns: Dict[str, float] = {}
        self._comment_hour_log: Dict[str, List[float]] = {}
        self.autonomous_life = AutonomousLifeLoop(self)

    async def start(self) -> None:
        """Start Telethon and perform the normal Telegram code/2FA flow."""
        phone = self.config.phone
        if phone:
            await self.client.start(phone=phone, code_callback=self._code_callback, password=self._password_callback)
        else:
            await self.client.start()

        me = await self.client.get_me()
        self._me_id = getattr(me, "id", None)
        if self.config.owner_id:
            try:
                owner = await self.client.get_entity(int(self.config.owner_id))
                self._owner_username = getattr(owner, "username", "") or ""
            except Exception:
                logger.debug("could not resolve owner entity", exc_info=True)
        self._is_premium = bool(getattr(me, "premium", False))
        self._own_username = getattr(me, "username", None) or ""
        self._own_identity_summary = (
            f"Марин — это аккаунт {(getattr(me, 'first_name', '') or '').strip()} "
            f"({'@' + self._own_username if self._own_username else 'без username'}, id={self._me_id})."
        )
        logger.info("Telegram authorized: @%s (id=%s)", getattr(me, "username", None), self._me_id)
        self.engine.remember_fact(
            "telegram_premium_status",
            f"У аккаунта {'активна' if self._is_premium else 'НЕТ'} подписка Telegram Premium.",
            confidence=0.98,
        )
        if not self._is_premium:
            logger.warning(
                "Account @%s has NO Telegram Premium: custom emoji entities are "
                "silently downgraded by Telegram's servers to their plain unicode "
                "fallback (alt) for non-Premium accounts. Custom emoji sending will "
                "keep showing regular emoji instead of the pack art until this "
                "account has an active Premium subscription.",
                getattr(me, "username", None),
            )
        self.engine.remember_fact(
            "self_config_models",
            f"Основная LLM-модель: {os.getenv('MARIN_OPENROUTER_MODEL', 'не задана')}. "
            f"Резервная модель: {os.getenv('MARIN_OPENROUTER_FALLBACK_MODEL', 'не задана')}. "
            f"Vision-модель: {VISION_MODEL} ({'включён' if VISION_ENABLED else 'выключен'}).",
            confidence=1.0,
        )
        self._import_legacy_media()
        await self._load_media_catalog()
        await self._refresh_dialogs_summary()
        asyncio.create_task(self._ensure_vision_catalog())
        asyncio.create_task(self._catch_up_missed_messages())

        if os.path.exists(STATE_IMPORT_FILE):
            # Разовый перенос: после импорта файл переименовывается, иначе он
            # подгружался бы на КАЖДОМ старте и затирал свежую память старой.
            try:
                with open(STATE_IMPORT_FILE, "rb") as fh:
                    summary = await self._load_state_bundle_bytes(fh.read())
                os.replace(STATE_IMPORT_FILE, f"{STATE_IMPORT_FILE}.imported-{int(time.time())}")
                logger.info("Auto-imported state bundle from %s: %s", STATE_IMPORT_FILE, summary)
                await self._save_state(force=True)
            except Exception:
                logger.exception("Found %s but could not auto-import it", STATE_IMPORT_FILE)

        if not self._registered:
            self.client.add_event_handler(self._on_message, events.NewMessage(incoming=not self.config.respond_to_outgoing))
            if self.config.respond_to_outgoing:
                # Explicitly register a second handler for outgoing messages only.
                self.client.add_event_handler(self._on_message, events.NewMessage(outgoing=True))
            self._registered = True

    async def _deliver_bubble(self, chat, reply_to_event, text: str, *, as_reply: bool) -> None:
        """Отправка одного пузыря с повтором: FloodWait ждём и повторяем, если
        «ответ» на удалённое сообщение не прошёл — шлём обычным сообщением.
        Раньше любое исключение обрывало цикл, и остаток ответа терялся."""
        last_exc: Optional[BaseException] = None
        for attempt in range(3):
            try:
                if as_reply and attempt == 0:
                    await reply_to_event.reply(text)
                else:
                    await self.client.send_message(chat, text)
                return
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                last_exc = exc
                wait = getattr(exc, "seconds", None)
                delay = min(float(wait) + 1.0, 30.0) if isinstance(wait, (int, float)) else 1.5 * (attempt + 1)
                logger.warning("Send failed (attempt %d/3): %s; retry in %.1fs", attempt + 1, exc, delay)
                await asyncio.sleep(delay)
        logger.error("Could not deliver bubble after retries: %s", last_exc)

    @staticmethod
    def _ensure_minimum_messages(messages: list[str]) -> list[str]:
        """Если модель уложила несколько предложений в одно сообщение — делим
        их на отдельные пузыри. Раньше короткий ответ ещё и дополнялся
        выдуманной репликой «Я рядом.», а длинная фраза резалась пополам
        посреди мысли — это и выглядело неестественно."""
        messages = [m.strip() for m in messages if m and m.strip()]
        if len(messages) >= MIN_REPLY_MESSAGES or not messages:
            return cap_messages(messages)
        sentences = [p.strip() for p in re.split(r"(?<=[.!?…])\s+", messages[0]) if p.strip()]
        if len(sentences) >= 2:
            return cap_messages(sentences)
        return cap_messages(messages)

    def _code_callback(self) -> str:
        return input("Telegram code: ").strip()

    def _password_callback(self) -> str:
        return input("Telegram 2FA password: ").strip()

    async def _on_message(self, event) -> None:
        """Observe every Telegram message, mark it read, but answer only the owner."""
        try:
            if self.config.ignore_bots and getattr(event.sender, "bot", False):
                return
            sender = await event.get_sender()
            sender_id = str(getattr(sender, "id", "unknown"))
            is_owner = bool(self.config.owner_id and sender_id == str(self.config.owner_id))
            chat = await event.get_chat()
            chat_id = str(getattr(chat, "id", getattr(event, "chat_id", sender_id)))
            chat_title = getattr(chat, "title", None) or getattr(sender, "first_name", None) or "Личная переписка"
            text = (event.raw_text or "").strip()
            has_media = bool(getattr(event, "media", None))
            if not text and not has_media:
                text = "[сообщение без текста]"
            if has_media and not text and (is_owner or self._is_private_chat_candidate(chat, sender, sender_id)):
                # Голосовое / аудио / «кружочек» — расшифровываем, дальше это обычный текст.
                transcript = await self._transcribe_event(event)
                if transcript:
                    event._marin_transcript = transcript
                    text = f"[голосовое] {transcript}"

            vision_description = ""
            if is_owner and has_media:
                vision_description, media_kind = await self._describe_image(event)
                if vision_description:
                    label = "Описание скриншота" if media_kind == "скриншот" else "Описание изображения"
                    text = f"{text}\n[{label}: {vision_description}]" if text else f"[{label}: {vision_description}]"
                    # Реально сохраняем как факт в память — раньше описание жило
                    # только внутри одного тика (через embedding сообщения) и
                    # не было отдельно вспоминаемо по запросу вроде "что было
                    # на том скриншоте". Ключ уникален на сообщение, поэтому
                    # разные картинки не затирают друг друга.
                    when = time.strftime("%d.%m %H:%M")
                    self.engine.remember_fact(
                        f"image_{chat_id}_{event.id}",
                        f"{when} — {label.lower()}: {vision_description}",
                        confidence=0.9,
                    )

            # Читаем сообщения независимо от того, будет ли ответ.
            # Небольшая задержка делает момент появления прочитано естественным,
            # вместо мгновенного ACK в ту же миллисекунду, когда пришло событие.
            if READ_DELAY_SECONDS > 0:
                await asyncio.sleep(READ_DELAY_SECONDS)
            try:
                await event.mark_read()
            except Exception:
                try:
                    await self.client.send_read_acknowledge(chat, max_id=event.id)
                except Exception:
                    logger.debug("Could not mark Telegram message as read", exc_info=True)

            self.observer.record(
                chat_id=chat_id, chat_title=chat_title, sender_id=sender_id,
                sender_name=(getattr(sender, "first_name", "") or "") + ((" " + getattr(sender, "last_name", "")) if getattr(sender, "last_name", "") else ""),
                username=getattr(sender, "username", "") or "", text=text,
                outgoing=bool(getattr(event, "out", False)), media=has_media,
            )
            self.scheduler.notice_activity()

            # Чужим — по умолчанию никогда не отвечаем. Единственное исключение:
            # обсуждение (комментарии) под её собственным каналом — там она
            # отвечает подписчикам, см. comments.py::CommunityMixin. Никакие
            # команды/действия/маркеры оттуда не исполняются — только текст.
            if not is_owner and self._is_channel_echo(sender, sender_id, event):
                # Пост её канала, автоматически пересланный в обсуждение: это не
                # комментарий подписчика. Раньше она отвечала сама себе.
                logger.info("Observed channel post echo without reply: chat=%s channel=%s", chat_id, sender_id)
                return
            if not is_owner:
                if os.getenv("MARIN_COMMENTS_ENABLED", "true").lower() in {"1", "true", "yes", "on"}:
                    community_entry = await self._discussion_entry_for_chat(chat, chat_id)
                    if community_entry is not None and not text.startswith(("/", ".")) \
                            and await self._should_engage_comment(event, chat):
                        key = f"community:{chat_id}:{sender_id}"
                        self._buffers.setdefault(key, []).append(event)
                        existing = self._debounce_tasks.get(key)
                        if existing and not existing.done():
                            existing.cancel()
                        self._debounce_tasks[key] = asyncio.create_task(
                            self._flush_comment_after_delay(key, chat, chat_id, sender_id, community_entry)
                        )
                        return
                # Обычная группа (не обсуждение её собственного канала — то
                # выше): по умолчанию всё ещё промолчит, но если к ней
                # обратились по имени/юзернейму или ответили на её сообщение,
                # она отвечает ИМЕННО этому человеку, различая его по имени
                # (см. groups.py::GroupMixin) — а не только владельцу.
                if await self._should_engage_group_message(event, chat, text):
                    actor_name = display_name(sender)
                    key = f"group:{chat_id}:{sender_id}"
                    self._buffers.setdefault(key, []).append(event)
                    existing = self._debounce_tasks.get(key)
                    if existing and not existing.done():
                        existing.cancel()
                    self._debounce_tasks[key] = self._flush_group_after_delay(
                        key, chat, chat_id, sender_id, actor_name
                    )
                    return
                # Личка от другого человека: она сама решит, отвечать ли (private_chats.py).
                if self._is_private_chat_candidate(chat, sender, sender_id):
                    self._schedule_private(event, chat, chat_id, sender_id, sender)
                    return
                logger.info("Observed Telegram message without reply: chat=%s actor=%s", chat_id, sender_id)
                return

            self._last_owner_activity = time.time()
            self.proactive.on_owner_message()
            if await self._handle_media_pack_links(event, text):
                return
            if await self._handle_group_invite_links(event, text):
                return
            if await self._handle_link_request(event, chat, text):
                return
            if await self._handle_relay_command(event, text):
                return
            pending = self.actions._pending.get(chat_id)
            action_result = await self.actions.maybe_confirm(chat_id, text)
            if action_result is not None:
                self._note_action_outcome(getattr(pending, "description", "действие"), action_result)
                await event.reply(action_result)
                # Stage 4: если это подтверждение относилось к write-шагу
                # автономной цели — goal_executor сам решает (по своей
                # приватной chat_id -> goal_id привязке, см. goal_executor.py),
                # был ли это его pending action; если нет, ничего не происходит.
                await self.goal_executor.on_pending_confirmed(chat_id, action_result)
                return
            if await self._handle_goals_command(event, text):
                return
            if await self._handle_own_channel_command(event, text):
                return
            if await self._handle_goal_start_command(event, text, sender_id):
                return
            lowered = text.lower().strip()
            if lowered in DIARY_COMMANDS:
                await self._handle_diary_command(event)
                return
            if lowered in STATUS_COMMANDS:
                await self._handle_status_command(event)
                return
            if await self._handle_self_commands(event, text):
                return
            if lowered in WHY_COMMANDS:
                await self._handle_why_command(event)
                return
            if lowered in EXPORT_COMMANDS:
                await self._handle_export_command(event)
                return
            if lowered in IMPORT_COMMANDS:
                await self._handle_import_command(event)
                return
            if lowered in DASHBOARD_COMMANDS:
                await self._handle_dashboard_command(event)
                return
            if await self._handle_profile_command(event, text):
                return
            if lowered in THOUGHTS_COMMANDS:
                await self._handle_thoughts_command(event)
                return
            if lowered in OBSERVER_COMMANDS or self._is_observer_question(lowered):
                await self._reply_owner(self.observer.summary())
                return
            if lowered in FULL_OBSERVER_COMMANDS:
                await self._reply_owner(self.observer.summary(limit=100, since_ts=0))
                return

            key = f"{chat_id}:{sender_id}"
            self._buffers.setdefault(key, []).append(event)
            existing = self._debounce_tasks.get(key)
            if existing and not existing.done():
                existing.cancel()
            self._debounce_tasks[key] = asyncio.create_task(
                self._flush_after_delay(key, chat, chat_id, sender_id)
            )
        except Exception:
            logger.exception("Telegram -> observation/buffering failed")

    async def _flush_comment_after_delay(self, key: str, chat, chat_id: str, sender_id: str, entry) -> None:
        try:
            await asyncio.sleep(DEBOUNCE_SECONDS)
        except asyncio.CancelledError:
            return
        events_batch = self._buffers.pop(key, [])
        self._debounce_tasks.pop(key, None)
        if not events_batch:
            return
        try:
            await self._process_comment_batch(events_batch, chat, chat_id, sender_id, entry)
        except Exception:
            logger.exception("Telegram -> CognitiveEngine (community) -> Telegram failed")

    async def _flush_after_delay(self, key: str, chat, chat_id: str, sender_id: str) -> None:
        try:
            await asyncio.sleep(DEBOUNCE_SECONDS)
        except asyncio.CancelledError:
            return  # отменено новым сообщением в этой же пачке — обработает следующий вызов

        events_batch = self._buffers.pop(key, [])
        self._debounce_tasks.pop(key, None)
        if not events_batch:
            return

        try:
            await self._process_batch(events_batch, chat, chat_id, sender_id)
        except Exception:
            logger.exception("Telegram -> CognitiveEngine -> Telegram failed")

    async def _build_history_context(self, chat, exclude_ids: Set[int]) -> str:
        """Переписка этого чата как «кто что сказал» — с прошлыми днями.

        Раньше подтягивались только 6 последних сообщений, поэтому всё, о чём
        говорили вчера, для неё не существовало. Теперь: недавние сообщения
        целиком + сжатые сообщения предыдущих дней (по одной строке), а границы
        дней подписаны («— вчера, 27.09 —»), чтобы она понимала, ЧТО было вчера.

        Каждая строка подписана реальным автором (владелец — явной пометкой,
        она сама — «Marin»). Два разных человека с одинаковым именем получают
        разные подписи («Саша #482» / «Саша #117») — иначе их слова сливаются.

        Не должна падать сама по себе — при любой ошибке просто нет истории."""
        earlier_cap = max(0, int(HISTORY_EARLIER_MESSAGES)) if HISTORY_EARLIER_DAYS > 0 else 0
        try:
            msgs = await self.client.get_messages(
                chat, limit=HISTORY_CONTEXT_MESSAGES + earlier_cap + len(exclude_ids) + 2)
        except Exception:
            logger.debug("Could not fetch chat history for context", exc_info=True)
            return ""

        owner_id = str(getattr(self.config, "owner_id", "") or "")
        name_cache: Dict[Any, str] = self.__dict__.setdefault("_history_sender_names", {})
        entries: List[Dict[str, Any]] = []
        for m in reversed(list(msgs)):
            if getattr(m, "id", None) in exclude_ids:
                continue
            t = (getattr(m, "raw_text", None) or "").strip()
            if not t:
                continue
            sid = getattr(m, "sender_id", None)
            if getattr(m, "out", False):
                speaker, kind = "Marin", "me"
            elif sid is not None and str(sid) == owner_id:
                speaker, kind = "Владелец", "owner"
            else:
                kind = "other"
                if sid in name_cache:
                    speaker = name_cache[sid]
                else:
                    try:
                        sender = await m.get_sender()
                        speaker = display_name(sender) if sender is not None else "Собеседник"
                    except Exception:
                        speaker = "Собеседник"
                    if sid is not None:
                        name_cache[sid] = speaker
            entries.append({"sid": sid, "speaker": speaker, "kind": kind, "text": t,
                            "day": self._message_day(m)})

        # одинаковые имена у РАЗНЫХ людей — различаем коротким id
        ids_by_name: Dict[str, Set[Any]] = {}
        for e in entries:
            if e["kind"] == "other" and e["sid"] is not None:
                ids_by_name.setdefault(e["speaker"], set()).add(e["sid"])
        for e in entries:
            if e["kind"] == "other" and e["sid"] is not None and len(ids_by_name.get(e["speaker"], ())) > 1:
                e["speaker"] = f"{e['speaker']} #{str(e['sid'])[-3:]}"

        recent = entries[-HISTORY_CONTEXT_MESSAGES:]
        older = entries[:-HISTORY_CONTEXT_MESSAGES] if len(entries) > HISTORY_CONTEXT_MESSAGES else []
        if older and earlier_cap:
            today = _dt.date.today()
            older = [e for e in older
                     if e["day"] is None or (today - e["day"]).days <= int(HISTORY_EARLIER_DAYS)]
            older = older[-earlier_cap:]
        else:
            older = []

        lines: List[str] = []
        shown_day: Any = "unset"
        today = _dt.date.today()

        def _emit(e: Dict[str, Any], limit: Optional[int]) -> None:
            nonlocal shown_day
            day = e["day"]
            if day is not None and day != shown_day:
                if day != today or shown_day not in ("unset", None):
                    lines.append(self._day_separator(day, today))
                shown_day = day
            body = e["text"]
            if limit is not None:
                body = re.sub(r"\s+", " ", body)
                if len(body) > limit:
                    body = body[: limit - 1].rstrip() + "…"
            lines.append(f"{e['speaker']}: {body}")

        for e in older:
            _emit(e, HISTORY_EARLIER_LINE_CHARS)
        for e in recent:
            _emit(e, None)
        return "\n".join(lines)

    @staticmethod
    def _message_day(m) -> Optional["_dt.date"]:
        d = getattr(m, "date", None)
        if not isinstance(d, _dt.datetime):
            return None
        try:
            return (d.astimezone() if d.tzinfo else d).date()
        except Exception:
            return None

    @staticmethod
    def _day_separator(day, today) -> str:
        delta = (today - day).days
        if delta <= 0:
            return "— сегодня —"
        if delta == 1:
            return f"— вчера, {day.strftime('%d.%m')} —"
        return f"— {day.strftime('%d.%m')} ({delta} дн. назад) —"

    async def _reply_context_hint(self, events_batch: list) -> str:
        """На какое сообщение владелец ответил свайпом. Без этого короткие
        ответы вроде «Подтверждаю» / «Сделай» / «Да» на её же сообщение
        теряли смысл, и она переспрашивала «а что именно подтверждаешь?»."""
        lines = []
        for e in events_batch[-4:]:
            if not (getattr(e, "is_reply", False) or getattr(e, "reply_to", None)):
                continue
            getter = getattr(e, "get_reply_message", None)
            if getter is None:
                continue
            try:
                r = await getter()
            except Exception:
                logger.debug("reply message unavailable", exc_info=True)
                continue
            if r is None:
                continue
            if getattr(r, "out", False):
                who = "твоё сообщение"
            else:
                try:
                    who = f"сообщение {display_name(await r.get_sender())}"
                except Exception:
                    who = "сообщение"
            body = re.sub(r"\s+", " ", (getattr(r, "raw_text", "") or "").strip())[:220] or "[медиа без текста]"
            extra = f" (в нём фото, id сообщения {r.id})" if getattr(r, "photo", None) else ""
            own = re.sub(r"\s+", " ", (getattr(e, "raw_text", "") or "").strip())[:80] or "[медиа]"
            lines.append(f"- «{own}» — ответ на {who}: «{body}»{extra}")
        if not lines:
            return ""
        return ("[На что именно отвечает владелец — понимай его реплику в этом контексте; "
                "короткое «да/сделай/подтверждаю» относится именно к этому]\n" + "\n".join(lines) + "\n")

    async def _process_batch(self, events_batch: list, chat, chat_id: str, sender_id: str) -> None:
        # Дополнительная страховка: обработка возможна только для владельца.
        if not self.config.owner_id or str(sender_id) != str(self.config.owner_id):
            logger.warning("Blocked non-owner cognitive processing: actor=%s", sender_id)
            return

        texts = [self._event_text(e) for e in events_batch if self._event_text(e)]
        if not texts:
            return

        # Целевой момент отправки считается от последнего сообщения пачки,
        # чтобы весь путь "последнее сообщение -> первый ответ" был около
        # заданных 10 секунд, а не 10 секунд плюс время LLM.
        in_quiet_hours = _is_quiet_hours()
        if in_quiet_hours:
            reply_delay = random.uniform(QUIET_HOURS_REPLY_DELAY_MIN, QUIET_HOURS_REPLY_DELAY_MAX)
        else:
            reply_delay = REPLY_DELAY_SECONDS
        target_reply_at = time.monotonic() + max(0.0, reply_delay - DEBOUNCE_SECONDS)
        new_text = "\n".join(texts)

        # Канал: владелец просит пост/удалить пост/вести канал — выполняем
        # СРАЗУ и без подтверждения, до когнитивного тика. Тик потом просто
        # живо реагирует на уже случившийся факт (см. channel_event_hint).
        channel_event: Optional[PublishResult] = None
        channel_event_hint = ""
        intent = detect_intent(new_text)
        if intent is not None:
            channel_event, channel_event_hint = await self._run_channel_intent(intent)

        # Публичные чаты: никаких ограничений на стиль и темы с владельцем —
        # Марин ведёт себя там так же свободно, как в личке (решение владельца).
        public_hint = ""
        if getattr(chat, "title", None) and not getattr(chat, "broadcast", False):
            # В группе владелец пишет ей при всех. Без этой подсказки она
            # отвечала ему о нём же в третьем лице («Он в чатик пишет…»).
            public_hint = (
                f"[Ты сейчас в групповом чате «{chat.title}», твои ответы видят все участники. "
                "Владелец пишет тебе здесь сам — обращайся к нему на «ты», не говори о нём в третьем лице. "
                "Отвечай по существу на его последнюю реплику, 1–2 коротких сообщения, без служебных "
                "подробностей о своих действиях и системе.]\n"
            )
        reminder_hint = ""
        try:
            req = parse_reminder(new_text)
            if req is not None and not getattr(chat, "title", None):
                self.proactive.reminders.add(req.when_ts, req.text)
                when_s = local_now(req.when_ts).strftime("%d.%m в %H:%M")
                reminder_hint = (
                    "[Системное событие — уже выполнено, ставить теги не нужно]\n"
                    f"Напоминание поставлено: «{req.text}» — {when_s}. Ты сама напишешь ему первой в это время. "
                    "Коротко и по-своему подтверди, что напомнишь (можно назвать время).\n"
                )
        except Exception:
            logger.warning("reminder parsing failed", exc_info=True)
        reply_hint = await self._reply_context_hint(events_batch)

        history = await self._build_history_context(chat, exclude_ids={e.id for e in events_batch})
        try:
            observer_context = self.observer.recent_context_by_chat(exclude_chat_id=chat_id)
        except Exception:
            logger.debug("per-chat observer context failed", exc_info=True)
            observer_context = self.observer.recent_context(limit=40)

        # Явно вытаскиваем последние собственные реплики Марин из истории и
        # даём модели прямую инструкцию не повторять их дословно — иначе на
        # семантически похожие вопросы подряд она склонна выдавать один и
        # тот же готовый ответ слово в слово.
        own_recent = [ln[len("Marin: "):] for ln in history.split("\n") if ln.startswith("Marin: ")][-3:]
        anti_repeat = (
            "[Твои последние реплики — НЕ повторяй их дословно и не присылай тот же "
            "текст ещё раз (любимые стикеры повторять можно); если тема похожа, ответь по-новому или дай "
            "конкретную информацию, а не переформулировку той же шутки]\n"
            + "\n".join(f"- {r}" for r in own_recent) + "\n"
            if own_recent else ""
        )

        quiet_hint = (
            "[Сейчас глубокая ночь по времени сервера — если уместно, можешь звучать "
            "немного сонной/медленной, но не обязательно упоминать это явно каждый раз]\n"
            if in_quiet_hours else ""
        )

        # Stage 5.D: одноразовая самокоррекция — если в прошлом ответе этого
        # чата модель сломала маркер (не закрыла тег / перепутала поля),
        # показываем ей конкретно, что пошло не так, прямо сейчас, а не
        # молча чиним и забываем. Читается и сразу удаляется — подсказка
        # только на один следующий тик, не постоянная память об ошибке.
        marker_issue = self._last_marker_issue.pop(chat_id, None)
        marker_issue_hint = (
            f"[Внутренняя заметка о прошлом ответе, владелец её не видел и не видит]\n{marker_issue}\n"
            if marker_issue else ""
        )

        combined_text = (
            f"[Контекст переписки]\n{history}\n" if history else ""
        ) + anti_repeat + self._identity_rules_hint("owner") + quiet_hint + marker_issue_hint + channel_event_hint + reminder_hint + self._action_outcomes_hint() + public_hint + reply_hint + await self._link_facts_hint(new_text) + self.self_model.prompt_hint(new_text) + (
            f"[Что происходило в ДРУГИХ чатах Telegram — это НЕ текущий разговор: у каждого чата свои люди "
            f"и своя тема. Не приноси их темы сюда сама; рассказывай о них, когда владелец спрашивает. "
            f"«Marin (ТЫ)» — это ТЫ: так помечено то, что ты там реально написала. Пересказывая, называй, "
            f"кто из людей что сказал, говори только то, что здесь есть, свои ответы не придумывай]\n"
            f"{observer_context or '(пока ничего)'}\n"
            f"{self._telegram_world_hint()}\n"
            f"{self._media_catalog_hint()}\n"
            f"[Новые сообщения владельца]\n{new_text}"
        )

        channel_id = f"telegram:{chat_id}"
        result = await asyncio.to_thread(
            self.engine.tick, combined_text, channel_id=channel_id,
            source_actor_id=sender_id, is_owner=True,
        )
        raw_generated = (result.generated_text or "").strip()
        # Доп. страховка (помимо проверки внутри FallbackProvider.generate):
        # если сюда всё же долетел явный след EchoLocalProvider-заглушки или
        # рассуждения модели вместо реплики — лучше молча пропустить этот
        # тик (владелец просто не получит ответ и может написать ещё раз),
        # чем показать ему дамп внутреннего контекста/промпта.
        if raw_generated and _is_unusable_output(raw_generated):
            logger.warning(
                "Skipping unusable generated_text for chat=%s (leaked meta/stub text): %r",
                chat_id, raw_generated[:300],
            )
            if channel_event is not None:
                await last_event_reply(events_batch, channel_event.owner_summary())
            return
        # Искажённые маркеры (>>>READ:get_bio|<<<) сначала чиним, чтобы они
        # исполнились, а не утекли владельцу текстом.
        generated = self._repair_action_marker_fields(normalize_markers(raw_generated), chat_id)
        # <<<POST:...>>> — второй слой: модель поняла просьбу о посте в
        # формулировке, которую не поймали регулярки intents.py.
        generated, post_briefs = self._extract_post_markers(generated)
        if post_briefs and channel_event is None:
            channel_event = await self._publish_from_brief(post_briefs[0])
        elif post_briefs:
            logger.info("[POST] ignoring duplicate POST marker — already handled this batch")
        # Контентные ACTION в СВОЙ канал исполняются сразу (политика
        # автономии), всё остальное — как раньше, черновик + «да».
        generated, auto_results = await self._auto_execute_own_channel_actions(generated)
        raw_text = self.actions.extract_draft(generated, chat_id)
        raw_text, read_results = await self._collect_readonly_markers(raw_text)
        if read_results:
            followup = await self._answer_with_read_results(result, read_results)
            if followup:
                raw_text = followup
            else:  # второй проход не удался — лучше короткая правда, чем сырой дамп
                raw_text = (raw_text + "\n" if raw_text else "") + "Посмотрела, но сформулировать сейчас не выходит — спроси ещё раз?"
        raw_text = self._extract_goal_marker(raw_text)
        raw_text = self._extract_autogoal_marker(raw_text, sender_id)
        raw_text = self._extract_belief_marker(raw_text)
        raw_text = self._extract_person_marker(raw_text)
        raw_text, tune_notices = extract_tune_markers(raw_text, self.self_tuning)
        for note in tune_notices:
            self._note_action_outcome("самонастройка", note)
        raw_text = self._strip_leaked_markers(raw_text, chat_id)
        leftover = self._ANY_PROTOCOL_MARKER_RE.findall(raw_text)
        if leftover:
            # Последний рубеж: невыполненная команда не уходит человеку текстом.
            logger.warning("Dropped %d unexecuted marker(s) from owner reply: %r", len(leftover),
                           [x[:80] for x in leftover])
            raw_text = self._ANY_PROTOCOL_MARKER_RE.sub("", raw_text).strip()
        raw_text = re.sub(r"\n{3,}", "\n\n", raw_text).strip()
        reply = self._sanitize_output(raw_text)
        if not reply:
            if channel_event is not None:
                reply = channel_event.owner_summary()
            else:
                logger.warning("Cognitive cycle produced no text for owner batch in chat %s", chat_id)
                return

        messages = self._ensure_minimum_messages(
            split_into_messages(reply, max_part_chars=bubble_max_chars(), max_messages=None)
        )
        if not messages:
            return
        messages = cap_messages(messages)
        # изменения себя владелец видит всегда — не может быть «тихой» самонастройки
        messages = self._append_channel_outcome(messages, channel_event, list(auto_results) + tune_notices)

        last_event = events_batch[-1]
        if await self._maybe_voice_reply(chat, messages, events_batch):
            await self._mark_owner_read(chat, last_event)
            logger.info("Marin replied to owner by voice: chat=%s", chat_id)
            return
        await self._mark_owner_read(chat, last_event)
        for i, msg_text in enumerate(messages):
            # Показываем typing перед каждой отдельной частью. Для первой
            # части подгоняем начало typing так, чтобы само сообщение ушло
            # примерно в целевой момент (10 секунд после последнего входящего).
            typing_delay = min(1.8 + len(msg_text) / 55.0, 4.5)
            if i == 0:
                remaining_before_typing = target_reply_at - time.monotonic() - typing_delay
                if remaining_before_typing > 0:
                    await asyncio.sleep(remaining_before_typing)
            else:
                await asyncio.sleep(max(MESSAGE_GAP_MIN_SECONDS, min(MESSAGE_GAP_MAX_SECONDS, 1.0)))

            try:
                async with self.client.action(chat, "typing"):
                    await asyncio.sleep(typing_delay)
            except Exception:
                await asyncio.sleep(typing_delay)

            # Спецмаркеры медиа — модель может выбрать их, но они не
            # отображаются как текст и не проходят через обычный emoji sanitizer.
            sticker_match = re.fullmatch(
                r"\s*<<<STICKER(?::[A-Za-z]?(\d+))?>>>\s*",
                msg_text,
                flags=re.IGNORECASE,
            )
            if sticker_match:
                idx = int(sticker_match.group(1)) if sticker_match.group(1) else None
                await self._send_sticker(chat, idx)
                continue
            emoji_match = re.fullmatch(
                r"\s*<<<CUSTOM_EMOJI(?::[A-Za-z]?(\d+))?>>>\s*",
                msg_text,
                flags=re.IGNORECASE,
            )
            if emoji_match:
                idx = int(emoji_match.group(1)) if emoji_match.group(1) else None
                await self._send_custom_emoji(chat, idx)
                continue

            msg_text = self._sanitize_output(msg_text)
            if not msg_text:
                continue
            await self._deliver_bubble(chat, last_event, msg_text, as_reply=(i == 0))

        logger.info(
            "Marin replied only to owner: chat=%s actor=%s messages=%d batched_input=%d prediction_error=%.4f",
            chat_id, sender_id, len(messages), len(events_batch), result.prediction_error,
        )

    # ------------------------------------------------------------------
    # Канал: автономные публикации (см. channel_publisher.py / intents.py)
    # ------------------------------------------------------------------
    async def _run_channel_intent(self, intent) -> "tuple[Optional[PublishResult], str]":
        """Исполняет распознанное намерение владельца и возвращает
        (результат, подсказку для когнитивного тика)."""
        try:
            if isinstance(intent, PostIntent):
                res = await self.publisher.publish(
                    intent.brief, verbatim_text=intent.verbatim_text,
                    channel_hint=intent.channel_hint, with_selfie=intent.with_selfie,
                    with_illustration=intent.with_illustration,
                )
                return res, self._channel_event_hint(res, "post")
            if isinstance(intent, DeleteLastPostIntent):
                res = await self.publisher.delete_last(intent.channel_hint)
                if res.ok:
                    res.extra["summary"] = f"Удалила последний пост в «{res.channel_title}»."
                return res, self._channel_event_hint(res, "delete")
            if isinstance(intent, ProactiveIntent):
                status = self.proactive.set_enabled(intent.enable)
                res = PublishResult(ok=True, extra={"summary": status})
                return res, (
                    "[Системное событие — уже выполнено]\n"
                    f"Настройка «писать первой»: {status}\nКоротко и по-своему подтверди это владельцу.\n"
                )
            if isinstance(intent, AutopostIntent):
                status = await self.publisher.set_autopost(
                    intent.enable, interval_seconds=intent.interval_seconds,
                    channel_hint=intent.channel_hint, brief=intent.brief,
                )
                res = PublishResult(ok=True, extra={"summary": status})
                return res, (
                    "[Системное событие — уже выполнено, не спрашивай подтверждения и не ставь "
                    f"никаких тегов]\nНастройка автопостинга: {status}\n"
                    "Коротко и по-своему подтверди владельцу, что теперь так.\n"
                )
        except Exception:
            logger.exception("[POST] channel intent failed: %r", intent)
            res = PublishResult(ok=False, error="Что-то сломалось, пока я возилась с каналом, — посмотри логи.")
            return res, self._channel_event_hint(res, "post")
        return None, ""

    @staticmethod
    def _channel_event_hint(res: PublishResult, kind: str) -> str:
        if kind == "delete":
            if res.ok:
                return ("[Системное событие — уже выполнено]\nТы только что удалила свой последний пост в "
                        f"«{res.channel_title}» по просьбе владельца. Коротко подтверди.\n")
            return f"[Системное событие]\nУдалить пост не получилось: {res.error} Честно скажи об этом.\n"
        if res.ok:
            auto = (" Канал ты выбрала сама — назови его владельцу." if res.channel_auto_chosen else "")
            return (
                "[Системное событие — УЖЕ выполнено, пост опубликован, НЕ используй тег POST и не "
                "переписывай текст поста в чат]\n"
                f"Ты только что опубликовала пост в своём канале «{res.channel_title}»."
                f"{auto} Текст поста:\n«{res.text[:700]}»\n"
                "Ответь владельцу живо и коротко: что выложила и о чём он — можно своими словами, "
                "как делишься с близким. Ссылку добавлять не нужно, она придёт отдельно.\n"
            )
        return (
            "[Системное событие]\nОпубликовать пост не получилось: "
            f"{res.error}\nЧестно и коротко скажи об этом владельцу, не делай вид, что пост вышел.\n"
        )

    async def _publish_from_brief(self, brief: str) -> PublishResult:
        low = (brief or "").lower()
        with_selfie = "селфи" in low
        with_illustration = (not with_selfie) and any(
            w in low for w in ("картинк", "иллюстрац", " фото", "с фото", "изображени", "обложк")
        )
        try:
            return await self.publisher.publish(
                brief, with_selfie=with_selfie, with_illustration=with_illustration, source="marker"
            )
        except Exception:
            logger.exception("[POST] publish from POST marker failed")
            return PublishResult(ok=False, error="Не получилось опубликовать пост.")

    def _is_own_channel_target(self, value: Any) -> bool:
        target = str(value or "").strip().lstrip("@").lower()
        if not target:
            return False
        norm = re.sub(r"[^\w]+", " ", target.replace("ё", "е")).strip()
        for entry in self._own_channels.values():
            if target in {str(entry.get("id") or "").lower(), str(entry.get("username") or "").lstrip("@").lower()}:
                return True
            title = re.sub(r"[^\w]+", " ", str(entry.get("title") or "").lower().replace("ё", "е")).strip()
            if title and norm == title:
                return True
        return False

    def _is_owner_ref(self, value: Any) -> bool:
        v = str(value or "").strip().lstrip("@").lower()
        if not v:
            return False
        refs = {str(self.config.owner_id or "").lower(), "владелец", "владельца", "меня", "мне", "owner"}
        if self.owner_name:
            refs.add(self.owner_name.lower())
        if getattr(self, "_owner_username", ""):
            refs.add(self._owner_username.lower())
        refs.discard("")
        return v in refs

    # Политика автономии: что Марин делает сама, без «да».
    #  * контент в СВОЁМ канале (посты, опросы, закрепы, реакции);
    #  * оформление СВОЕГО канала (название/описание/фото, инвайт-ссылка);
    #  * действия над САМИМ владельцем в своём канале (добавить его, сделать
    #    админом, разбанить, одобрить заявку) — он сам об этом просит.
    # Всё, что затрагивает других людей или чужие чаты, по-прежнему ждёт «да».
    _OWN_CHANNEL_SETUP_KINDS = {
        "create_invite_link", "edit_channel", "change_channel_title",
        "change_channel_about", "change_channel_photo",
    }
    _OWNER_TARGET_KINDS = {
        "invite_user", "promote_admin", "edit_admin_rights", "unban_user", "approve_join_request",
    }

    # Её селфи / голосовое / стикер / кубик ЛИЧНО владельцу — он сам просит в
    # своём же чате; «Жду кидай» не должно превращаться в «Подтвердить?».
    _OWNER_PERSONAL_MEDIA_KINDS = {"send_selfie", "send_voice_message", "send_sticker", "send_dice"}

    def _may_auto_execute(self, kind: str, payload: str) -> bool:
        if kind in self._OWNER_PERSONAL_MEDIA_KINDS:
            try:
                params = json.loads(payload)
            except Exception:
                return False
            return isinstance(params, dict) and self._is_owner_ref(params.get("chat"))
        if kind not in SAFE_AUTO_APPROVE_KINDS | self._OWN_CHANNEL_SETUP_KINDS | self._OWNER_TARGET_KINDS:
            return False
        try:
            params = json.loads(payload)
        except Exception:
            params = {"chat": payload.strip()}  # plain-payload kinds (create_invite_link)
        if not isinstance(params, dict):
            return False
        key = JSON_PAYLOAD_CHAT_KEY.get(kind, "chat")
        if not self._is_own_channel_target(params.get(key) or params.get("chat")):
            return False
        if kind in self._OWNER_TARGET_KINDS:
            return self._is_owner_ref(params.get("username") or params.get("user"))
        return True

    def _note_action_outcome(self, what: str, result: Optional[str]) -> None:
        """Реальный итог действия — в память и в контекст следующих ответов,
        чтобы Марин не говорила «ты теперь админ», когда Telegram отказал."""
        if not result:
            return
        line = f"{time.strftime('%H:%M')} {what}: {result}"
        self._action_outcomes.append(line)
        del self._action_outcomes[:-6]
        try:
            self.engine.remember_fact(f"action_outcome_{int(time.time() * 1000)}", line, confidence=0.98)
        except Exception:
            logger.debug("could not store action outcome", exc_info=True)

    def _action_outcomes_hint(self) -> str:
        if not self._action_outcomes:
            return ""
        return ("[Реальные итоги твоих последних действий в Telegram — говори о них ТОЛЬКО правду; "
                "если что-то не вышло, не утверждай обратное и не обещай, что «уже сделано»]\n"
                + "\n".join(f"- {x}" for x in self._action_outcomes) + "\n")

    async def _auto_execute_own_channel_actions(self, text: str) -> "tuple[str, List[str]]":
        """ACTION-маркеры контентных kind'ов (SAFE_AUTO_APPROVE_KINDS), чья
        цель — один из СВОИХ каналов, выполняются сразу. Всё остальное
        (личка, чужие чаты, админка, баны, права) не трогаем — оно уйдёт в
        обычный extract_draft и будет ждать «да»."""
        if not text or "<<<ACTION:" not in text:
            return text, []
        results: List[str] = []
        out: List[str] = []
        last = 0
        for m in ACTION_MARKER_RE.finditer(text):
            kind, description, payload = m.group(1), m.group(2).strip(), m.group(3).strip()
            if not self._may_auto_execute(kind, payload):
                continue
            result = await self.actions.execute_now(kind, description, payload)
            self._note_action_outcome(description or kind, result)
            logger.info("[AUTONOMY] auto-executed %s: %r", kind, (result or "")[:160])
            silent_ok = kind in self._OWNER_PERSONAL_MEDIA_KINDS and (result or "").startswith("Готово")
            if result and not silent_ok:  # селфи он и так увидит — «Готово, отправила» не дублируем
                results.append(result)
            out.append(text[last:m.start()])
            last = m.end()
        out.append(text[last:])
        return "".join(out).strip(), results

    def _append_channel_outcome(self, messages: List[str], event: Optional[PublishResult],
                                auto_results: List[str]) -> List[str]:
        """Гарантирует, что владелец увидит реальный исход (ссылку/ошибку),
        даже если чат-модель ответила общими словами."""
        extra: List[str] = []
        joined = " ".join(messages).lower()
        if event is not None:
            if event.ok and event.link and event.link not in joined:
                extra.append(event.link)
            elif not event.ok and event.error and event.error.lower()[:40] not in joined:
                extra.append(event.error)
        for r in auto_results:
            if r:
                extra.append(r)  # реальный итог всегда виден — модель не может «приукрасить»
        if not extra:
            return messages
        if MAX_REPLY_MESSAGES <= 0 or len(messages) < MAX_REPLY_MESSAGES:
            return messages + ["\n".join(extra)]
        return messages[:-1] + [messages[-1] + "\n" + "\n".join(extra)]

    _LINK_REQUEST_RE = re.compile(
        r"(?:дай|скинь|кинь|пришли|отправь|покажи|где|нужн\w*|можно)\s+(?:мне\s+|нам\s+)?"
        r"(?:ссылк\w*|линк\w*|инвайт\w*|приглашени\w*)\s+(?:на\s+|в\s+)?(?:эт\w+\s+|сво\w+\s+|наш\w*\s+)?"
        r"(групп\w*|чат\w*|бесед\w*|канал\w*)",
        re.IGNORECASE,
    )

    async def _chat_link(self, entity) -> "tuple[str, str]":
        """(link, error). Публичный — t.me/username; приватный — уже
        существующее приглашение, иначе новое (нужны права админа)."""
        username = getattr(entity, "username", None)
        if username:
            return f"https://t.me/{username}", ""
        try:
            me = await self.client.get_me()
            res = await self.client(functions.messages.GetExportedChatInvitesRequest(peer=entity, admin_id=me, limit=10))
            for inv in getattr(res, "invites", []) or []:
                if not getattr(inv, "revoked", False) and not getattr(inv, "expired", False):
                    return inv.link, ""
        except Exception:
            logger.debug("existing invite lookup failed", exc_info=True)
        try:
            inv = await self.client(functions.messages.ExportChatInviteRequest(peer=entity))
            return inv.link, ""
        except Exception as e:  # noqa: BLE001
            return "", tg_error_reason(e)

    async def _handle_link_request(self, event, chat, text: str) -> bool:
        """«Марин дай ссылку на группу» — детерминированно, без LLM.
        На скриншотах эта просьба просто терялась в болтовне."""
        m = self._LINK_REQUEST_RE.search(text or "")
        if not m:
            return False
        what = m.group(1).lower()
        target = None
        in_group = getattr(chat, "title", None) is not None
        if what.startswith("канал"):
            for entry in (getattr(self, "_own_channels", {}) or {}).values():
                try:
                    target = await self.client.get_entity(int(entry.get("id")))
                    break
                except Exception:
                    continue
            if target is None and in_group and getattr(chat, "broadcast", False):
                target = chat
        elif in_group:
            target = chat
        if target is None:
            return False  # непонятно, о каком чате речь — пусть ответит модель
        link, err = await self._chat_link(target)
        title = getattr(target, "title", "") or "чат"
        if link:
            reply = f"Держи, «{title}»: {link}"
        else:
            reply = f"Не могу сделать ссылку на «{title}»: {err}. Похоже, мне там не хватает прав админа."
        self._note_action_outcome(f"ссылка на «{title}»", reply)
        await event.reply(self._sanitize_output(reply))
        return True

    _SELF_REPORT_COMMANDS = {".я", ".самонаблюдение", "/self", ".self"}

    async def _handle_self_commands(self, event, text: str) -> bool:
        """.я — отчёт о себе; .настройки [откат|сброс|стоп|вкл|<имя> <значение>]."""
        low = (text or "").strip().lower()
        if low in self._SELF_REPORT_COMMANDS:
            await event.reply(self.self_model.report(full=True))
            return True
        if not (low.startswith(".настройки") or low.startswith("/tuning")):
            return False
        args = low.split()[1:]
        t = self.self_tuning
        if not args:
            hist = t.history_lines(5)
            reply = ("Мои настройки" + ("" if t.enabled else " (самонастройка выключена)") + ":\n"
                     + "\n".join(t.status_lines())
                     + ("\n\nНедавно меняла:\n" + "\n".join(hist) if hist else "")
                     + "\n\n.настройки откат · сброс · стоп · вкл · <имя> <значение>")
        elif args[0] in ("откат", "undo"):
            reply = t.undo_last()
        elif args[0] in ("сброс", "reset"):
            reply = t.reset()
        elif args[0] in ("стоп", "выкл", "off"):
            reply = t.set_enabled(False)
        elif args[0] in ("вкл", "on"):
            reply = t.set_enabled(True)
        elif len(args) >= 2 and resolve_knob(args[0]):
            ok, msg = t.propose(args[0], args[1], reason="команда владельца", by="owner")
            reply = ("Поставила: " if ok else "Не поменяла: ") + msg
        else:
            reply = "Не поняла. Настройки: " + ", ".join(KNOBS)
        self._note_action_outcome("настройки", reply.split("\n")[0])
        await event.reply(reply)
        return True

    _ANY_PROTOCOL_MARKER_RE = re.compile(
        r"<<<\s*(?:ACTION|READ|POST|GOAL|AUTOGOAL|BELIEF|PERSON|TUNE)\s*:.*?>>>", re.IGNORECASE | re.DOTALL)

    async def _answer_with_read_results(self, result, read_results: list) -> str:
        """Второй проход: модель САМА прочитала данные и отвечает по сути, как
        после вызова инструмента. Тот же контекст хода (planning_input), без
        повторной записи хода в память."""
        pin = getattr(result, "planning_input", None)
        if pin is None:
            return ""
        from dataclasses import replace
        facts = "\n".join(f"- {kind}({payload or '—'}): {str(res)[:600]}" for kind, payload, res in read_results)
        pin2 = replace(
            pin,
            situation_summary=(pin.situation_summary or "") + (
                "\n\n[Ты только что сама посмотрела это в Telegram — это факты, сверх них не выдумывай]\n" + facts),
            constraints=list(pin.constraints or []) + [
                "Ответь по сути, опираясь на то, что узнала. Не говори «сейчас проверю» — ты уже проверила. "
                "Не пересказывай id и служебные поля, говори по-человечески. Если что-то не получилось узнать — "
                "так и скажи коротко. Без служебных маркеров."],
        )
        try:
            text = await asyncio.to_thread(self.engine.language_planner.provider.generate, pin2)
        except Exception:
            logger.warning("READ follow-up generation failed", exc_info=True)
            return ""
        if not text or _is_unusable_output(text):
            return ""
        return self._ANY_PROTOCOL_MARKER_RE.sub("", normalize_markers(text)).strip()

    _TME_USERNAME_RE = re.compile(r"(?:https?://)?t\.me/(?!joinchat/|\+|c/|s/|addstickers/|addemoji/)([A-Za-z][A-Za-z0-9_]{3,31})\b")

    async def _link_facts_hint(self, text: str) -> str:
        """Владелец прислал t.me-ссылку: заранее выясняем, ЧТО это на самом деле
        (канал/группа/человек/бот) и её права там. Если это канал, где она
        создатель или может публиковать, — записываем его как её канал."""
        found = list(dict.fromkeys(m.group(1) for m in self._TME_USERNAME_RE.finditer(text or "")))[:3]
        if not found:
            return ""
        lines = []
        for uname in found:
            try:
                entity = await self.client.get_entity(uname)
            except Exception as e:  # noqa: BLE001
                lines.append(f"- t.me/{uname}: не нашла ({tg_error_reason(e)})")
                continue
            title = getattr(entity, "title", None)
            if title is None and getattr(entity, "broadcast", None) is None:
                who = "бот" if getattr(entity, "bot", False) else "человек"
                name = " ".join(filter(None, [getattr(entity, "first_name", ""), getattr(entity, "last_name", "")]))
                lines.append(f"- t.me/{uname}: это {who} {name}".rstrip())
                continue
            is_channel = bool(getattr(entity, "broadcast", False))
            rights = getattr(entity, "admin_rights", None)
            can_post = bool(getattr(entity, "creator", False)) or bool(getattr(rights, "post_messages", False))
            role = ("ты его создатель" if getattr(entity, "creator", False)
                    else "ты там админ и можешь публиковать" if can_post
                    else "ты там админ" if rights else "ты там не админ")
            what = "канал" if is_channel else "группа"
            line = f"- t.me/{uname}: это {what} «{title}», {role}"
            if is_channel and can_post:
                try:
                    self._remember_own_channel(utils.get_peer_id(entity), title=title, username=uname)
                    line += " — теперь он записан как твой канал"
                except Exception:
                    logger.debug("could not register own channel %s", uname, exc_info=True)
            lines.append(line)
        return "[Что на самом деле по ссылкам в его сообщении — проверено в Telegram]\n" + "\n".join(lines) + "\n"

    def _is_channel_echo(self, sender, sender_id: str, event) -> bool:
        """Сообщение от имени её канала или авто-пересылка поста канала."""
        def norm(x) -> str:
            x = str(x or "").strip()
            return x[4:] if x.startswith("-100") else x.lstrip("-")
        own = set()
        for key, entry in (getattr(self, "_own_channels", {}) or {}).items():
            own.add(norm(key))
            own.add(norm(entry.get("id")))
        own.discard("")
        if norm(sender_id) in own:
            return True
        msg = getattr(event, "message", event)
        return bool(getattr(sender, "broadcast", False)) and getattr(msg, "fwd_from", None) is not None

    @staticmethod
    def _event_text(e) -> str:
        transcript = getattr(e, "_marin_transcript", None)
        if transcript:
            return f"[голосовое] {transcript}"
        return (getattr(e, "raw_text", "") or "").strip()

    async def _transcribe_event(self, event) -> str:
        msg = getattr(event, "message", event)
        kind = ("voice" if getattr(msg, "voice", None) else "video_note" if getattr(msg, "video_note", None)
                else "audio" if getattr(msg, "audio", None) else "")
        if not kind:
            return ""
        doc = getattr(msg, "document", None)
        if int(getattr(doc, "size", 0) or 0) > int(os.getenv("MARIN_STT_MAX_BYTES", str(15 * 1024 * 1024))):
            logger.info("[STT] %s too large, skipped", kind)
            return ""
        try:
            raw = await self.client.download_media(msg, file=bytes)
            fmt = "ogg"
            if kind == "video_note":
                raw, fmt = await _extract_audio_ogg(raw)
            elif kind == "audio":
                mime = str(getattr(doc, "mime_type", "") or "")
                fmt = ("mp3" if "mpeg" in mime else "m4a" if ("mp4" in mime or "m4a" in mime)
                       else "wav" if "wav" in mime else "ogg")
            text = await self._get_transcriber().transcribe(raw, fmt)
        except Exception:
            logger.warning("[STT] transcription failed (%s)", kind, exc_info=True)
            return ""
        if text:
            logger.info("[STT] %s transcribed: %r", kind, text[:120])
        return text

    async def _maybe_voice_reply(self, chat, messages: list, events_batch: list) -> bool:
        """Ответить голосом на голосовое — иногда, как живой человек."""
        if not any(getattr(e, "_marin_transcript", None) for e in events_batch):
            return False
        import random
        if random.random() >= env_float("MARIN_VOICE_REPLY_CHANCE", 0.5, minimum=0.0, maximum=1.0):
            return False
        media = [m for m in messages if re.fullmatch(r"\s*<<<(?:STICKER|CUSTOM_EMOJI)[^>]*>>>\s*", m or "")]
        spoken = " ".join(self._sanitize_output(m) for m in messages if m not in media).strip()
        spoken = re.sub(r"<<<[^<>]*>>>", "", spoken).strip()
        if not spoken or len(spoken) > 600:
            return False  # длинный ответ удобнее читать
        try:
            result = await self._get_voice_generator().generate(spoken)
            uploaded = await self.client.upload_file(result.audio_bytes, file_name=f"voice{result.ext}")
            await self.client.send_file(chat, uploaded, voice_note=result.is_voice_note)
        except Exception:
            logger.info("voice reply unavailable, answering with text", exc_info=True)
            return False
        for m in media:
            await self._send_bubble(chat, m)
        self._note_action_outcome("ответ голосом", "Готово, ответила голосовым")
        return True

    async def _mark_owner_read(self, chat, last_event) -> None:
        try:
            await self.client.send_read_acknowledge(chat, max_id=getattr(last_event, "id", None))
        except Exception:
            logger.debug("read ack failed", exc_info=True)

    async def _reply_owner(self, text: str) -> None:
        text = self._sanitize_output(text)
        if text:
            await self.client.send_message(self.config.owner_id, text)

    def _sanitize_output(self, text: str) -> str:
        """Final output gate: removes emoji unless explicitly enabled."""
        text = strip_protocol_junk(text)
        if self.allow_emoji:
            return text
        return re.sub(
            r"[\U0001F1E0-\U0001F1FF\U0001F300-\U0001FAFF\u2600-\u27BF\uFE0F]",
            "", text, flags=re.UNICODE,
        ).replace("  ", " ").strip()

    async def run(self) -> None:
        await self.start()
        self._scheduler_task = asyncio.create_task(self._scheduler_loop())
        logger.info("Marin X Telegram transport is running")
        await self.client.run_until_disconnected()

    async def _scheduler_loop(self) -> None:
        """Фоновый цикл: раз в SCHEDULER_CHECK_INTERVAL проверяет простой и,
        если пора, запускает consolidation + дневниковую запись (§14 спеки,
        engine/scheduler.py), а также (Stage 4) даёт шанс продвинуться
        автономным целям через тот же self.goal_executor. Никогда не должен
        ронять весь процесс."""
        while True:
            try:
                await asyncio.sleep(SCHEDULER_CHECK_INTERVAL)
                await self._maybe_refresh_dialogs_summary()
                report = await asyncio.to_thread(self.scheduler.maybe_run)
                if report is not None:
                    logger.info(
                        "Idle consolidation ran: nodes_rescored=%d semantic_clusters=%d",
                        report.nodes_rescored,
                        report.semantic_clusters_created,
                    )
                    await self.autonomous_life.on_consolidation_report(report)
                    await self._save_state(force=True)  # консолидация перестроила память — фиксируем
                await self.autonomous_life.pulse()
                await self._maybe_autosave()
            except asyncio.CancelledError:
                return
            except Exception:
                logger.exception("Scheduler loop iteration failed — will retry on next interval")

    async def _save_state(self, force: bool = False) -> None:
        store = getattr(self, "state_store", None)
        if store is None or (not force and not store.changed(self.engine)):
            return
        try:
            size = store.save(self.engine)
            logger.info("[STATE] saved %.0f KB -> %s", size / 1024, store.path)
        except Exception:
            logger.exception("[STATE] save failed")

    async def _maybe_autosave(self) -> None:
        store = getattr(self, "state_store", None)
        if store is None:
            return
        if store.last_saved_at is None or time.time() - store.last_saved_at >= self._state_autosave_seconds:
            await self._save_state()

    async def disconnect(self) -> None:
        await self._save_state(force=True)  # всё, что было после последнего автосейва
        if self._scheduler_task and not self._scheduler_task.done():
            self._scheduler_task.cancel()
        for task in self._debounce_tasks.values():
            if not task.done():
                task.cancel()
        await self.client.disconnect()
