"""GroupMixin — Marin в обычных групповых чатах (не собственный канал/
обсуждение — см. comments.py; не личка владельца).

До этого модуля любое сообщение не от владельца в группе только
записывалось в TelegramObserver и НИКОГДА не получало ответа — группа была
для Марин полностью немой. Хуже того, даже история переписки, которую видит
LLM (``_build_history_context``), помечала КАЖДУЮ чужую реплику одинаковой
меткой "Собеседник" — так что даже когда отвечала владельцу в группе с
другими людьми, все голоса сливались в один.

Здесь: Марин может ответить любому участнику группы, но только когда к ней
реально обратились (упоминание по имени/юзернейму или ответ на её
сообщение) — иначе группа осталась бы немой ботом-спамером — и КАЖДЫЙ
участник различается по имени: ``engine.tick(..., source_actor_id=sender_id,
actor_name=display_name)`` — relationship/beliefs/pending-feedback у ядра
уже ведутся per-actor (см. marin_core/social, marin_core/belief), здесь
только даём этому имени дойти до промпта, а не растворяться в "Собеседник".

Как и в comments.py: ACTION/READ/POST/AUTOGOAL от не-владельца никогда не
исполняются — только текст. BELIEF/PERSON/GOAL обрабатываются (так она
реально запоминает регулярных участников). Рейт-лимит per (chat, sender) +
общий кап в час на чат, чтобы бойкая группа не превратилась в спам.
"""
from __future__ import annotations

import asyncio
import logging
import re
import time
from typing import Any, Dict, List, Optional

from .settings import GROUP_CHAT_ENABLED, GROUP_REPLIES_MAX_PER_HOUR, GROUP_REPLY_COOLDOWN_SECONDS
from ..llm.providers import _is_unusable_output, split_into_messages
from .settings import fit_messages

logger = logging.getLogger("marin_x.telegram.groups")

_ANY_MARKER_RE = re.compile(r"<<<(?:ACTION|READ|POST|AUTOGOAL|TUNE):.*?>>>", re.IGNORECASE | re.DOTALL)


def display_name(entity: Any) -> str:
    """Человекочитаемое имя для belief-текстов и промпта — не запасной
    generic-лейбл. first_name+last_name, иначе @username, иначе id."""
    first = (getattr(entity, "first_name", "") or "").strip()
    last = (getattr(entity, "last_name", "") or "").strip()
    name = (first + " " + last).strip()
    if name:
        return name
    username = getattr(entity, "username", "") or ""
    if username:
        return f"@{username}"
    title = getattr(entity, "title", "") or ""
    if title:
        return title
    return f"user{getattr(entity, 'id', '')}"


class GroupMixin:
    # ------------------------------------------------------------- gating

    def _is_regular_group_chat(self, chat: Any) -> bool:
        """Групповой чат с несколькими людьми, но НЕ обсуждение под её
        собственным каналом (это отдельный, более широкий сценарий —
        см. comments.py::CommunityMixin) и не приватная переписка."""
        return getattr(chat, "title", None) is not None

    def _mentions_marin(self, text: str) -> bool:
        low = (text or "").lower()
        own_username = (getattr(self, "_own_username", "") or "").lower()
        if own_username and f"@{own_username}" in low:
            return True
        persona_name = (getattr(getattr(self.engine, "identity", None), "name", "") or "марин").lower()
        names = {persona_name, "марин", "маришка", "маринка", "marin"}
        for n in names:
            if re.search(rf"(?<![а-яa-z0-9]){re.escape(n)}(?![а-яa-z0-9])", low):
                return True
        return False

    async def _is_reply_to_marin(self, event, chat) -> bool:
        reply_to = getattr(getattr(event, "message", None), "reply_to", None)
        reply_to_id = getattr(reply_to, "reply_to_msg_id", None)
        if not reply_to_id:
            return False
        try:
            parent = await self.client.get_messages(chat, ids=reply_to_id)
        except Exception:
            return False
        return bool(parent is not None and getattr(parent, "out", False))

    async def _should_engage_group_message(self, event, chat, text: str) -> bool:
        if not GROUP_CHAT_ENABLED:
            return False
        if not self._is_regular_group_chat(chat):
            return False
        if text.startswith(("/", ".")):
            return False  # похоже на команду не ей
        if self._mentions_marin(text):
            return True
        return await self._is_reply_to_marin(event, chat)

    def _group_reply_allowed(self, chat_id: str, sender_id: str, now: float) -> bool:
        last_by_sender: Dict[str, float] = self.__dict__.setdefault("_group_cooldowns", {})
        key = f"{chat_id}:{sender_id}"
        if now - last_by_sender.get(key, 0.0) < GROUP_REPLY_COOLDOWN_SECONDS:
            return False
        log: Dict[str, List[float]] = self.__dict__.setdefault("_group_hour_log", {})
        recent = [t for t in log.get(chat_id, []) if now - t < 3600.0]
        log[chat_id] = recent
        return len(recent) < GROUP_REPLIES_MAX_PER_HOUR

    def _note_group_reply(self, chat_id: str, sender_id: str, now: float) -> None:
        self._group_cooldowns[f"{chat_id}:{sender_id}"] = now
        self._group_hour_log.setdefault(chat_id, []).append(now)

    # ------------------------------------------------------------ dispatch

    def _flush_group_after_delay(self, key: str, chat, chat_id: str, sender_id: str, actor_name: str) -> None:
        async def _run():
            await asyncio.sleep(0.4)
            events_batch = self._buffers.pop(key, [])
            self._debounce_tasks.pop(key, None)
            if not events_batch:
                return
            try:
                await self._process_group_batch(events_batch, chat, chat_id, sender_id, actor_name)
            except Exception:
                logger.exception("[GROUP] processing failed chat=%s sender=%s", chat_id, sender_id)
        return asyncio.create_task(_run())

    async def _process_group_batch(self, events_batch: list, chat, chat_id: str,
                                    sender_id: str, actor_name: str) -> None:
        texts = [self._event_text(e) for e in events_batch if self._event_text(e)]
        if not texts:
            return
        now = time.time()
        if not self._group_reply_allowed(chat_id, sender_id, now):
            logger.info("[GROUP] skipped reply (rate limit) chat=%s sender=%s", chat_id, sender_id)
            return

        new_text = "\n".join(texts)
        history = await self._build_history_context(chat, exclude_ids={e.id for e in events_batch})
        combined = (
            f'[Групповой чат «{getattr(chat, "title", "") or ""}», к тебе обратился(ась) '
            f"{actor_name} (не владелец) — отвечай как в обычной беседе, но помни, что это "
            f"публичное групповое общение, а не личка]\n"
            + self._owner_awareness_hint()
            + self._identity_rules_hint("other")
            + (f"[Контекст переписки (внутри — границы дней)]\n{history}\n" if history else "")
            + f"[{actor_name} написал(а)]\n{new_text}"
        )
        channel_id = f"telegram:{chat_id}"
        try:
            result = await asyncio.to_thread(
                self.engine.tick, combined, channel_id=channel_id,
                source_actor_id=sender_id, is_owner=False, addressed=True, actor_name=actor_name,
            )
        except Exception:
            logger.exception("[GROUP] tick failed chat=%s sender=%s", chat_id, sender_id)
            return
        raw = (result.generated_text or "").strip()
        if not raw or _is_unusable_output(raw):
            return

        text = _ANY_MARKER_RE.sub("", raw)
        text = self._extract_belief_marker(text)
        text = self._extract_goal_marker(text)
        text = self._extract_person_marker(text)
        text = self._strip_leaked_markers(text, chat_id)
        text = re.sub(r"\n{3,}", "\n\n", text).strip()
        reply = self._sanitize_output(text)
        if not reply:
            return

        messages = fit_messages(split_into_messages(reply, max_messages=None), 2)  # 2 пузыря, но текст не теряется
        if not messages:
            return
        self._note_group_reply(chat_id, sender_id, now)
        last_event = events_batch[-1]
        for i, msg_text in enumerate(messages):
            # общий отправщик: маркер стикера — стикер, а не текст «<<<STICKER:5>>>»
            await self._send_bubble(chat, msg_text, reply_to=last_event if i == 0 else None)
        self._record_own_reply(chat, chat_id, messages)
        logger.info("[GROUP] replied chat=%s actor=%s(%s)", chat_id, sender_id, actor_name)
