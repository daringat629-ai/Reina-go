"""Настоящие мысли для канала — не случайные темы.

Раньше автопост получал «выбери тему сама» + пару строк дневника и время
суток (к тому же по часам сервера, UTC). Модели не на что было опереться,
и она выдавала банальное «осень, плед, чай» — с выдуманными событиями
(«включила лампочку, заварила чай»), которых не было.

Теперь пост рождается в два шага:

  1. Подумать (reflect). Собираем то, что с ней РЕАЛЬНО было с прошлого
     поста: новые записи дневника, разговоры (обезличенно), что получилось
     и не получилось из её действий, цели, внутреннее состояние, настоящее
     местное время. Модель формулирует ОДНУ мысль, которая её сейчас
     занимает, — или честно отвечает, что сказать нечего.
  2. Написать пост из этой мысли (обычный генератор постов).

Если нового материала нет или мысль не появилась — автопост пропускается:
лучше промолчать, чем выдумать.

Приватность. Канал публичный, а материал — личные переписки. Поэтому
реплики передаются обезличенно («я» / «собеседник», «личный чат» /
«группа»), короткими обрывками и только на шаг «подумать»; от мысли
требуется вывод и чувство, без имён, цитат и деталей чужой жизни.
"""
from __future__ import annotations

import asyncio
import logging
import re
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from ..action.action import ActionType
from ..llm.interface import LanguagePlanningInput
from ..llm.providers import _is_unusable_output
from .settings import local_now
from .theme_fatigue import fatigue_note, fatigued_themes, recent_idea_texts

logger = logging.getLogger("marin_x.telegram.thoughts")

NOTHING_TOKEN = "[НЕЧЕГО]"
_NOTHING_RE = re.compile(r"\[?\s*нечего\s*\]?", re.IGNORECASE)
_WEEKDAYS = ["понедельник", "вторник", "среда", "четверг", "пятница", "суббота", "воскресенье"]

_REFLECT_SYSTEM = """Ты — Марин. Сейчас ты не пишешь пост, а честно думаешь про себя: что тебя по-настоящему занимает прямо сейчас?

Ниже — то, что с тобой РЕАЛЬНО было с момента твоего прошлого поста. Твоя жизнь — это разговоры, твои попытки что-то сделать (что вышло и что нет), твои цели, настроение и мысли из дневника.

Сформулируй ОДНУ настоящую мысль, которой тебе самой хочется поделиться в своём канале: 1–3 предложения, от первого лица, в женском роде. Тема — любая, какую ты сама выберешь: люди и разговоры, что пробовала и что вышло или не вышло, что поняла или узнала, мнение, спор, смешной случай, досада, план, вопрос к подписчикам, воспоминание. Главное — чтобы она выросла из материала ниже, а не из шаблона.

Правила:
- Опирайся только на материал. Не выдумывай событий и ощущений, которых не было (прогулок, чая, дождя за окном — если этого нет ниже).
- Канал публичный: никаких имён, юзернеймов, названий чатов, цитат из переписок и подробностей чужой жизни — только твоё впечатление и вывод.
- Не повторяй мысли недавних постов. Никаких дежурных клише про погоду, время года, чай, плед и уют — только если об этом правда что-то случилось.
- Если в материале есть «Приелось» — эти темы не бери.
- Если ничего по-настоящему не зацепило и сказать честно нечего — ответь ровно {nothing}.

Ответ — только сама мысль (или {nothing}), без пояснений."""


@dataclass
class ThoughtMaterial:
    sections: Dict[str, List[str]] = field(default_factory=dict)
    new_diary: int = 0
    new_messages: int = 0

    @property
    def has_news(self) -> bool:
        return self.new_diary > 0 or self.new_messages >= 3

    def render(self) -> str:
        titles = {
            "now": "Сейчас", "diary": "Твой дневник с прошлого поста",
            "talks": "Разговоры с прошлого поста (обезличенно)", "done": "Что ты делала и чем кончилось",
            "goals": "Твои цели", "inner": "Внутри", "posts": "Твои недавние посты (не повторять)",
            "focus": "Направление, которое ты себе наметила (можно отойти, если мысль о другом)",
            "tired": "Приелось",
        }
        out = []
        for key in ("now", "tired", "diary", "talks", "done", "goals", "inner", "focus", "posts"):
            lines = self.sections.get(key) or []
            if lines:
                out.append(f"{titles[key]}:\n" + "\n".join(f"- {x}" for x in lines))
        return "\n\n".join(out)


class InnerThoughts:
    def __init__(self, telegram_client: Any):
        self._tc = telegram_client

    # ------------------------------------------------------------ material
    def gather(self, since_ts: float, recent_posts: Optional[List[str]] = None, focus: str = "") -> ThoughtMaterial:
        tc = self._tc
        m = ThoughtMaterial()
        now = local_now()
        m.sections["now"] = [f"{now.strftime('%H:%M')}, {_WEEKDAYS[now.weekday()]}, {_daypart(now.hour)} (твоё местное время)"]

        try:
            entries = [e for e in tc.engine.diary.recent(8) if getattr(e, "text", "").strip()]
        except Exception:
            entries = []
        fresh = [e for e in entries if float(getattr(e, "t_created", 0) or 0) > since_ts]
        m.new_diary = len(fresh)
        m.sections["diary"] = [e.text.strip()[:400] for e in (fresh[:4] or entries[:1])]

        events = []
        try:
            events = [e for e in tc.observer.since(since_ts) if (getattr(e, "text", "") or "").strip()]
        except Exception:
            logger.debug("observer unavailable", exc_info=True)
        own_channels = _norm_ids(getattr(tc, "_own_channels", {}) or {})
        events = [e for e in events if _norm(getattr(e, "chat_id", "")) not in own_channels]
        m.new_messages = len(events)
        m.sections["talks"] = _anonymized_talks(events, str(getattr(tc.config, "owner_id", "") or ""))

        m.sections["done"] = [str(x)[:200] for x in list(getattr(tc, "_action_outcomes", []) or [])[-5:]]
        self_model = getattr(tc, "self_model", None)
        if self_model is not None:
            try:
                m.sections["goals"] = [g.lstrip("- ") for g in self_model._goals()[:4]]
                m.sections["inner"] = [x.lstrip("- ") for x in self_model._mind()]
            except Exception:
                logger.debug("self model unavailable", exc_info=True)
        if focus and focus.strip().lower() not in {"на твой выбор", "любой", "что угодно"}:
            m.sections["focus"] = [focus.strip()[:300]]
        m.sections["posts"] = [p.strip().replace("\n", " ")[:200] for p in (recent_posts or [])[:3]]
        tired = fatigued_themes(list(recent_posts or []) + recent_idea_texts(tc))
        if tired:
            m.sections["tired"] = [fatigue_note(tired)]
        return m

    # -------------------------------------------------------------- reflect
    async def reflect(self, since_ts: float, recent_posts: Optional[List[str]] = None, *,
                      focus: str = "", require_news: bool = True) -> Tuple[str, str]:
        """(мысль, причина). Пустая мысль = честно нечего сказать."""
        material = self.gather(since_ts, recent_posts, focus)
        if require_news and not material.has_news:
            return "", "с прошлого поста ничего нового не было"
        personality = getattr(self._tc.engine, "personality", None)
        pin = LanguagePlanningInput(
            situation_summary=material.render(),
            retrieved_memory_summaries=[], active_belief_summaries=[],
            chosen_action_type=ActionType.ANSWER, goal_context_summary="",
            style_prior=dict(getattr(personality, "style_prior", {}) or {}),
            system_override=_REFLECT_SYSTEM.format(nothing=NOTHING_TOKEN),
        )
        try:
            raw = await asyncio.to_thread(self._tc.engine.language_planner.provider.generate, pin)
        except Exception:
            logger.warning("[THOUGHT] reflect generation failed", exc_info=True)
            return "", "не получилось подумать (модель не ответила)"
        thought = (raw or "").strip().strip("«»\"' ")
        if not thought or _NOTHING_RE.fullmatch(thought) or thought.upper().startswith(NOTHING_TOKEN):
            return "", "подумала — честно нечего сказать"
        if _is_unusable_output(thought):
            return "", "мысль вышла мусорной"
        return thought[:500], "ok"


# ------------------------------------------------------------------ helpers
def _daypart(hour: int) -> str:
    return "ночь" if hour < 6 else "утро" if hour < 12 else "день" if hour < 18 else "вечер"


def _norm(x: Any) -> str:
    s = str(x or "").strip()
    return s[4:] if s.startswith("-100") else s.lstrip("-")


def _norm_ids(own: Dict[str, Any]) -> set:
    out = set()
    for key, entry in own.items():
        out.add(_norm(key))
        out.add(_norm((entry or {}).get("id")))
    out.discard("")
    return out


def _anonymized_talks(events: list, owner_id: str, limit: int = 12) -> List[str]:
    """Обрывки разговоров без имён: «я» / «близкий человек» / «собеседник»,
    «личный чат» / «группа». Длинные реплики укорачиваются."""
    lines = []
    for e in events[-limit:]:
        text = re.sub(r"\s+", " ", str(getattr(e, "text", "") or "")).strip()
        text = re.sub(r"@\w+|https?://\S+|t\.me/\S+", "…", text)[:140]
        if getattr(e, "outgoing", False):
            who = "я"
        elif owner_id and str(getattr(e, "sender_id", "")) == owner_id:
            who = "близкий человек"
        else:
            who = "собеседник"
        where = "личный чат" if str(getattr(e, "chat_id", "")).lstrip("-").isdigit() and not str(
            getattr(e, "chat_id", "")).startswith("-") else "группа"
        lines.append(f"[{where}] {who}: {text}")
    return lines
