"""Напоминания по времени — «напомни через 2 часа позвонить маме».

Раньше «напомни…» превращалось в цель без срока: Марин обещала, но сама
написать в нужный момент не могла (proactive знал только утро/ночь/тишину).
Здесь:

* ``parse_reminder`` — детерминированный разбор русской фразы в (время, текст);
* ``ReminderStore``  — JSON-хранилище с атомарной записью, переживает рестарт;
* ProactiveLoop (proactive.py) на каждом pulse отправляет созревшие
  напоминания своими словами — независимо от лимитов «писать первой» и от
  тихих часов: это явная просьба владельца.

Модуль чистый (без Telethon), время локальное — ``local_now`` из settings.
"""
from __future__ import annotations

import datetime as _dt
import json
import logging
import os
import re
import time
import uuid
from dataclasses import dataclass, asdict
from typing import List, Optional

logger = logging.getLogger("marin_x.telegram.reminders")

_TRIGGER_RE = re.compile(r"\bнапом[ин]\w*", re.IGNORECASE)
_NEGATIVE_RE = re.compile(r"\bне\s+(?:надо\s+|нужно\s+)?напоминай\w*|\bне\s+напомина\w*|\bты\s+(?:мне\s+)?(?:не\s+)?напомн\w*\?", re.IGNORECASE)

_UNIT_SECONDS = (
    (r"секунд\w*|сек\b", 1),
    (r"минут\w*|мин\b", 60),
    (r"час\w*|ч\b", 3600),
    (r"день|дня|дней|сутки|суток", 86400),
    (r"недел\w*", 7 * 86400),
)
_NUMWORDS = {"пару": 2, "пар": 2, "несколько": 3, "один": 1, "одну": 1, "два": 2, "две": 2, "три": 3,
             "четыре": 4, "пять": 5, "десять": 10, "пятнадцать": 15, "двадцать": 20, "тридцать": 30}
_REL_RE = re.compile(
    r"\bчерез\s+(?:(?P<half>пол\s*(?:часа|минуты|дня))|(?:(?P<n>\d+(?:[.,]\d+)?|"
    + "|".join(sorted(_NUMWORDS, key=len, reverse=True))
    + r")\s+)?(?P<unit>" + "|".join(u for u, _ in _UNIT_SECONDS) + r"))",
    re.IGNORECASE,
)
_DAYWORD_RE = re.compile(r"\b(?P<d>сегодня|завтра|послезавтра)\b", re.IGNORECASE)
_TIME_RE = re.compile(r"\bв\s+(?P<h>\d{1,2})(?:[:.\-](?P<m>\d{2}))?(?:\s*(?P<ampm>утра|дня|вечера|ночи))?(?!\d)", re.IGNORECASE)
_PART_RE = re.compile(r"\b(?P<p>утром|днём|днем|вечером|ночью)\b", re.IGNORECASE)
_PART_HOURS = {"утром": 9, "днём": 14, "днем": 14, "вечером": 19, "ночью": 23}
_WEEKDAYS = {"понедельник": 0, "вторник": 1, "среду": 2, "среда": 2, "четверг": 3, "пятницу": 4,
             "пятница": 4, "субботу": 5, "суббота": 5, "воскресенье": 6}
_WEEKDAY_RE = re.compile(r"\b(?:в|во)\s+(?P<w>" + "|".join(_WEEKDAYS) + r")\b", re.IGNORECASE)


@dataclass
class ReminderRequest:
    when_ts: float
    text: str


def _local(ts: float):
    from .settings import local_now  # ленивый импорт: settings тянет окружение
    return local_now(ts)


def _hour_with_ampm(h: int, ampm: Optional[str]) -> int:
    ampm = (ampm or "").lower()
    if ampm in ("дня", "вечера") and h < 12:
        return h + 12
    if ampm == "ночи" and h == 12:
        return 0
    return h


def _clean_text(text: str, spans: List[tuple]) -> str:
    out = text
    for a, b in sorted(spans, reverse=True):
        out = out[:a] + " " + out[b:]
    out = _TRIGGER_RE.sub(" ", out)
    out = re.sub(r"\b(?:мне|пожалуйста|пож|плиз)\b", " ", out, flags=re.IGNORECASE)
    out = re.sub(r"^\W*(?:о\s+том,?\s+что|о\s+том|что|чтобы|чтоб|,|-|—)\s+", "", out.strip(), flags=re.IGNORECASE)
    out = re.sub(r"\s+", " ", out).strip(" ,.-—:;!?\n")
    return out


def parse_reminder(text: str, now: Optional[float] = None) -> Optional[ReminderRequest]:
    """«напомни через 2 часа позвонить маме» → ReminderRequest. Нет времени
    или это не просьба — None (тогда работает обычный путь через LLM)."""
    if not text or not _TRIGGER_RE.search(text) or _NEGATIVE_RE.search(text):
        return None
    now = time.time() if now is None else now
    spans: List[tuple] = []
    when: Optional[float] = None

    m = _REL_RE.search(text)
    if m:
        if m.group("half"):
            unit = m.group("half").lower()
            secs = 1800 if "час" in unit else 30 if "минут" in unit else 43200
        else:
            raw = (m.group("n") or "1").lower()
            n = _NUMWORDS.get(raw)
            if n is None:
                n = float(raw.replace(",", "."))
            unit = m.group("unit").lower()
            per = next(s for pat, s in _UNIT_SECONDS if re.fullmatch(pat, unit) or re.match(pat, unit))
            secs = n * per
        if secs <= 0 or secs > 365 * 86400:
            return None
        when = now + secs
        spans.append(m.span())
    else:
        base = _local(now)
        target_date = None
        d = _DAYWORD_RE.search(text)
        wd = _WEEKDAY_RE.search(text)
        tm = _TIME_RE.search(text)
        part = _PART_RE.search(text)
        if d:
            offs = {"сегодня": 0, "завтра": 1, "послезавтра": 2}[d.group("d").lower()]
            target_date = (base + _dt.timedelta(days=offs)).date()
            spans.append(d.span())
        elif wd:
            want = _WEEKDAYS[wd.group("w").lower()]
            delta = (want - base.weekday()) % 7 or 7
            target_date = (base + _dt.timedelta(days=delta)).date()
            spans.append(wd.span())
        hour = minute = None
        if tm:
            h = _hour_with_ampm(int(tm.group("h")), tm.group("ampm"))
            mi = int(tm.group("m") or 0)
            if 0 <= h <= 23 and 0 <= mi <= 59:
                hour, minute = h, mi
                spans.append(tm.span())
        if hour is None and part:
            hour, minute = _PART_HOURS[part.group("p").lower()], 0
            spans.append(part.span())
        if target_date is None and hour is None:
            return None
        if hour is None:
            hour, minute = 10, 0  # «завтра / в пятницу» без времени — утро
        if target_date is None:
            target_date = base.date()
            cand = base.replace(hour=hour, minute=minute, second=0, microsecond=0)
            if cand.timestamp() <= now + 30:
                target_date = (base + _dt.timedelta(days=1)).date()
        local_target = base.replace(year=target_date.year, month=target_date.month, day=target_date.day,
                                    hour=hour, minute=minute, second=0, microsecond=0)
        when = local_target.timestamp()
        if when <= now:
            return None

    what = _clean_text(text, spans)
    return ReminderRequest(when_ts=when, text=what[:300] or "то, о чём просил напомнить")


@dataclass
class Reminder:
    id: str
    when_ts: float
    text: str
    created_at: float
    done: bool = False
    attempts: int = 0


class ReminderStore:
    def __init__(self, path: Optional[str] = None):
        self.path = path or os.getenv("MARIN_REMINDERS_FILE", "data/marin_reminders.json")
        self.items: List[Reminder] = []
        self._load()

    def _load(self) -> None:
        try:
            with open(self.path, "r", encoding="utf-8") as fh:
                self.items = [Reminder(**d) for d in json.load(fh)]
        except FileNotFoundError:
            pass
        except Exception:
            logger.warning("[REMINDERS] file unreadable, starting empty", exc_info=True)

    def _save(self) -> None:
        try:
            os.makedirs(os.path.dirname(os.path.abspath(self.path)) or ".", exist_ok=True)
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump([asdict(r) for r in self.items], fh, ensure_ascii=False)
            os.replace(tmp, self.path)
        except Exception:
            logger.warning("[REMINDERS] could not save", exc_info=True)

    def add(self, when_ts: float, text: str, now: Optional[float] = None) -> Reminder:
        r = Reminder(id=uuid.uuid4().hex[:8], when_ts=float(when_ts), text=text,
                     created_at=time.time() if now is None else now)
        self.items.append(r)
        self._prune()
        self._save()
        return r

    def due(self, now: Optional[float] = None) -> List[Reminder]:
        now = time.time() if now is None else now
        return sorted((r for r in self.items if not r.done and r.when_ts <= now), key=lambda r: r.when_ts)

    def pending(self) -> List[Reminder]:
        return sorted((r for r in self.items if not r.done), key=lambda r: r.when_ts)

    def mark_done(self, rid: str) -> None:
        for r in self.items:
            if r.id == rid:
                r.done = True
        self._save()

    def bump_attempt(self, rid: str, max_attempts: int = 3) -> None:
        for r in self.items:
            if r.id == rid:
                r.attempts += 1
                if r.attempts >= max_attempts:
                    r.done = True  # не долбим бесконечно, если отправка не проходит
        self._save()

    def _prune(self) -> None:
        cutoff = time.time() - 7 * 86400
        self.items = [r for r in self.items if not (r.done and r.when_ts < cutoff)]
