"""
Action Registry — общая инфраструктура draft -> confirm -> execute для
любого действия, которое реально меняет что-то в Telegram/аккаунте от
имени владельца.

До этого модуля каждая такая функция (relay) писалась с нуля своим
набором regex/state/TTL в client.py. Теперь один переиспользуемый
механизм: регистрируешь handler по имени — дальше маркер/подтверждение/
протухание работают одинаково для всех действий.

Сознательно НЕ даёт LLM возможность вызвать произвольный метод Telegram
API — набор допустимых kind'ов курируется явно через register(): модель
может предложить только то, что реально зарегистрировано в client.py,
неизвестный kind молча отклоняется. Это архитектура для безопасного
расширения набора действий, а не открытый список "делай что угодно".
"""

from __future__ import annotations

import logging
import re
import time
import os
import random
from dataclasses import dataclass, field
from typing import Awaitable, Callable, Dict, List, Optional

from telethon import functions, types

logger = logging.getLogger("marin_core.telegram.actions")

# <<<ACTION:kind|описание для владельца|payload для handler'а>>>
# payload может содержать свои внутренние разделители — конкретный
# handler парсит его как ему нужно, регистратор в это не вмешивается.
ACTION_MARKER_RE = re.compile(r"<<<ACTION:(\w+)\|([^|>]+)\|(.+?)>>>", re.IGNORECASE | re.DOTALL)

# Короткое согласие, в т.ч. живыми фразами («давай просто добавляй», «да,
# делай уже», «подтверждаю»). Отрицания («не надо», «нет, не делай») не проходят.
ACTION_CONFIRM_RE = re.compile(
    r"^(?!.*\bне\b)(?:да|ага|угу|давай|отправляй|отправь|делай|сделай|добавляй|добавь|назначай|"
    r"подтверждаю|подтверди|ок|окей|конечно|го|жги|вперёд|вперед|согласен|можно|"
    r"кидай|кинь|скидывай|скинь|присылай|пришли|шли|жду|валяй|погнали|хорошо|ладно|"
    r"публикуй|выкладывай|запускай|жми|"
    r"go|send|yes|confirm|ok)\b[\w\s,.!)]{0,60}$",
    re.IGNORECASE,
)
ACTION_PENDING_TTL_SECONDS = 900.0


@dataclass
class PendingAction:
    kind: str
    description: str  # человекочитаемое — то, что видит владелец вместо маркера
    payload: str       # сырые данные для конкретного handler'а
    created_ts: float = field(default_factory=time.monotonic)


ActionHandler = Callable[[PendingAction], Awaitable[str]]


class ActionRegistry:
    """Один и тот же путь draft -> confirm -> execute для любого
    зарегистрированного действия — новое действие = один handler,
    а не отдельная с нуля написанная система state/regex/TTL."""

    def __init__(self) -> None:
        self._handlers: Dict[str, ActionHandler] = {}
        self._pending: Dict[str, PendingAction] = {}  # ключ — chat_id

    def register(self, kind: str, handler: ActionHandler) -> None:
        self._handlers[kind] = handler

    def known_kinds(self) -> List[str]:
        return list(self._handlers.keys())

    def extract_draft(self, text: str, chat_id: str) -> str:
        """Если модель предложила действие маркером — сохраняет черновик
        (ничего ещё не выполняется) и заменяет маркер на описание, которое
        увидит владелец. Неизвестный/незарегистрированный kind — модель
        не может "изобрести" несуществующее действие, маркер просто
        вырезается без побочных эффектов."""
        match = ACTION_MARKER_RE.search(text or "")
        if not match:
            return text
        kind, description, payload = match.group(1), match.group(2).strip(), match.group(3).strip()
        if kind not in self._handlers:
            logger.warning("Model proposed unknown/unregistered action kind %r — ignored", kind)
            return ACTION_MARKER_RE.sub("", text, count=1).strip()
        self._pending[chat_id] = PendingAction(kind=kind, description=description, payload=payload)
        return ACTION_MARKER_RE.sub(description, text, count=1)

    async def maybe_confirm(self, chat_id: str, text: str) -> Optional[str]:
        """Если есть pending action для чата и текст — короткое явное
        подтверждение, реально выполняет handler. Возвращает текст
        результата для владельца, либо None (ничего не произошло —
        либо нет pending action, либо это не подтверждение)."""
        pending = self._pending.get(chat_id)
        if pending is None:
            return None
        if time.monotonic() - pending.created_ts > ACTION_PENDING_TTL_SECONDS:
            self._pending.pop(chat_id, None)
            return None
        if not ACTION_CONFIRM_RE.match((text or "").strip()):
            return None
        self._pending.pop(chat_id, None)
        handler = self._handlers.get(pending.kind)
        if handler is None:
            return "Не могу это выполнить — действие больше не поддерживается."
        try:
            return await handler(pending)
        except Exception:
            logger.exception("Action handler failed: kind=%s", pending.kind)
            return "Не получилось выполнить — что-то пошло не так."

    async def execute_now(self, kind: str, description: str, payload: str) -> Optional[str]:
        """Выполнить зарегистрированное действие сразу, без черновика.
        Решение «можно ли без подтверждения» принимает ВЫЗЫВАЮЩИЙ (политика
        автономии, см. client.py::_auto_execute_own_channel_actions и
        goal_executor.SAFE_AUTO_APPROVE_KINDS) — реестр только исполняет
        уже курируемый kind и никогда неизвестный."""
        handler = self._handlers.get(kind)
        if handler is None:
            logger.warning("execute_now: unknown kind %r ignored", kind)
            return None
        try:
            return await handler(PendingAction(kind=kind, description=description, payload=payload))
        except Exception:
            logger.exception("Action handler failed: kind=%s", kind)
            return "Не получилось выполнить — что-то пошло не так."

    def pending_count(self) -> int:
        return len(self._pending)


class TelegramActions:
    """High-level, typed Telethon facade used by Marin's action layer.

    This class does not replace ActionRegistry.  It is the execution surface:
    callers may use the explicit helpers below, or ``invoke`` with an actual
    Telethon TLRequest instance.  The caller remains responsible for deciding
    whether an operation needs draft/confirmation/authorization.
    """

    def __init__(self, client, *, logger_: Optional[logging.Logger] = None) -> None:
        self.client = client
        self.logger = logger_ or logger

    async def invoke(self, request):
        """Execute one real Telethon TLRequest through the connected client."""
        return await self.client(request)

    call = invoke

    async def resolve(self, entity):
        return await self.client.get_entity(entity)

    async def resolve_input(self, entity):
        return await self.client.get_input_entity(entity)

    # ----- account / profile -------------------------------------------------
    async def get_me(self):
        return await self.client.get_me()

    async def update_profile(self, *, first_name=None, last_name=None, about=None):
        return await self.client(functions.account.UpdateProfileRequest(
            first_name=first_name, last_name=last_name, about=about
        ))

    async def set_username(self, username: str):
        return await self.client(functions.account.UpdateUsernameRequest(username=username))

    async def upload_profile_photo(self, file):
        uploaded = await self.client.upload_file(file)
        return await self.client(functions.photos.UploadProfilePhotoRequest(file=uploaded))

    async def delete_profile_photos(self, photo_ids):
        return await self.client(functions.photos.DeletePhotosRequest(id=list(photo_ids)))

    # ----- privacy / contacts ------------------------------------------------
    async def get_privacy(self, key):
        return await self.client(functions.account.GetPrivacyRequest(key=key))

    async def set_privacy(self, key, rules):
        return await self.client(functions.account.SetPrivacyRequest(key=key, rules=rules))

    async def get_contacts(self):
        return await self.client(functions.contacts.GetContactsRequest(hash=0))

    async def block(self, user):
        return await self.client(functions.contacts.BlockRequest(id=await self.resolve_input(user)))

    async def unblock(self, user):
        return await self.client(functions.contacts.UnblockRequest(id=await self.resolve_input(user)))

    async def get_blocked(self, *, offset=0, limit=100):
        return await self.client(functions.contacts.GetBlockedRequest(offset=offset, limit=limit))

    # ----- dialogs / messages ------------------------------------------------
    async def get_dialogs(self, *, limit=None, offset_date=None, offset_id=0, offset_peer=None, ignore_pinned=False):
        return await self.client.get_dialogs(
            limit=limit, offset_date=offset_date, offset_id=offset_id,
            offset_peer=offset_peer, ignore_pinned=ignore_pinned
        )

    async def get_messages(self, entity, *, ids=None, limit=100, min_id=0, max_id=0, from_user=None, search=None):
        if ids is not None:
            return await self.client.get_messages(entity, ids=ids)
        return await self.client.get_messages(
            entity, limit=limit, min_id=min_id, max_id=max_id,
            from_user=from_user, search=search
        )

    async def get_message(self, entity, message_id: int):
        return await self.client.get_messages(entity, ids=message_id)

    async def send_message(self, entity, message, **kwargs):
        return await self.client.send_message(entity, message, **kwargs)

    async def edit_message(self, entity, message_id: int, message=None, **kwargs):
        return await self.client.edit_message(entity, message_id, message, **kwargs)

    async def delete_messages(self, entity, message_ids, *, revoke=True):
        return await self.client.delete_messages(entity, message_ids, revoke=revoke)

    async def pin_message(self, entity, message_id: int, *, notify=False):
        return await self.client.pin_message(entity, message_id, notify=notify)

    async def unpin_message(self, entity, message_id: int):
        return await self.client.unpin_message(entity, message_id)

    async def get_pinned_messages(self, entity, *, limit=100):
        return await self.client.get_messages(entity, filter=types.InputMessagesFilterPinned(), limit=limit)

    async def search_messages(self, entity, query: str, *, limit=100, from_user=None):
        return await self.client.get_messages(entity, search=query, limit=limit, from_user=from_user)

    async def search_global(self, query: str, *, limit=100):
        return await self.client(functions.messages.SearchGlobalRequest(
            q=query, filter=types.InputMessagesFilterEmpty(), min_date=None,
            max_date=None, offset_rate=0, offset_id=0, offset_peer=types.InputPeerEmpty(),
            limit=limit
        ))

    async def mark_read(self, entity, *, max_id=None):
        return await self.client.send_read_acknowledge(entity, max_id=max_id)

    async def forward_messages(self, entity, messages, *, from_peer=None, drop_author=False):
        return await self.client.forward_messages(
            entity, messages, from_peer=from_peer, drop_author=drop_author
        )

    # ----- media / files -----------------------------------------------------
    async def upload_file(self, file, *, file_size=None, progress_callback=None):
        return await self.client.upload_file(
            file, file_size=file_size, progress_callback=progress_callback
        )

    async def download_media(self, message, file=None, *, progress_callback=None):
        return await self.client.download_media(
            message, file=file, progress_callback=progress_callback
        )

    async def send_file(self, entity, file, **kwargs):
        return await self.client.send_file(entity, file, **kwargs)

    async def send_photo(self, entity, file, **kwargs):
        return await self.client.send_file(entity, file, **kwargs)

    async def send_document(self, entity, file, **kwargs):
        return await self.client.send_file(entity, file, force_document=True, **kwargs)

    async def send_album(self, entity, files, **kwargs):
        return await self.client.send_file(entity, files, **kwargs)

    async def send_sticker(self, entity, sticker, **kwargs):
        return await self.client.send_file(entity, sticker, **kwargs)

    async def send_audio(self, entity, file, **kwargs):
        return await self.client.send_file(entity, file, attributes=kwargs.pop("attributes", None), **kwargs)

    async def send_voice(self, entity, file, **kwargs):
        kwargs.setdefault("voice_note", True)
        return await self.client.send_file(entity, file, **kwargs)

    async def send_video(self, entity, file, **kwargs):
        kwargs.setdefault("supports_streaming", True)
        return await self.client.send_file(entity, file, **kwargs)

    async def send_video_note(self, entity, file, **kwargs):
        kwargs.setdefault("video_note", True)
        return await self.client.send_file(entity, file, **kwargs)

    # ----- groups / channels -------------------------------------------------
    async def create_channel(self, title: str, about: str = "", *, megagroup=False, broadcast=True, for_import=False):
        return await self.client(functions.channels.CreateChannelRequest(
            title=title, about=about, broadcast=broadcast,
            megagroup=megagroup, for_import=for_import
        ))

    async def edit_channel(self, channel, *, title=None, about=None, photo=None):
        entity = await self.resolve_input(channel)
        if photo is not None:
            uploaded = await self.client.upload_file(photo)
            photo = types.InputChatUploadedPhoto(file=uploaded)
        return await self.client(functions.channels.EditTitleRequest(channel=entity, title=title)) if (
            title is not None and about is None and photo is None
        ) else await self.client(functions.channels.EditPhotoRequest(channel=entity, photo=photo)) if (
            photo is not None and title is None and about is None
        ) else await self.client(functions.channels.EditAboutRequest(channel=entity, about=about)) if (
            about is not None and title is None and photo is None
        ) else await self._edit_channel_parts(entity, title, about, photo)

    async def _edit_channel_parts(self, entity, title, about, photo):
        result = None
        if title is not None:
            result = await self.client(functions.channels.EditTitleRequest(channel=entity, title=title))
        if about is not None:
            result = await self.client(functions.channels.EditAboutRequest(channel=entity, about=about))
        if photo is not None:
            uploaded = await self.client.upload_file(photo) if isinstance(photo, (str, bytes, os.PathLike)) else photo
            result = await self.client(functions.channels.EditPhotoRequest(
                channel=entity, photo=types.InputChatUploadedPhoto(file=uploaded)
            ))
        return result

    async def join_chat(self, entity):
        resolved = await self.resolve(entity)
        if getattr(resolved, "megagroup", False) or getattr(resolved, "broadcast", False):
            return await self.client(functions.channels.JoinChannelRequest(channel=resolved))
        return await self.client(functions.messages.AddChatUserRequest(
            chat_id=getattr(resolved, "id"), user_id=await self.resolve_input("me"), fwd_limit=0
        ))

    async def leave_chat(self, entity):
        resolved = await self.resolve(entity)
        if hasattr(resolved, "megagroup") or hasattr(resolved, "broadcast"):
            return await self.client(functions.channels.LeaveChannelRequest(channel=resolved))
        return await self.client.delete_dialog(resolved)

    async def invite_users(self, entity, users):
        return await self.client(functions.channels.InviteToChannelRequest(
            channel=await self.resolve_input(entity),
            users=[await self.resolve_input(u) for u in users],
        ))

    async def get_participants(self, entity, *, limit=100, search=None):
        return await self.client.get_participants(entity, limit=limit, search=search)

    async def get_admins(self, entity, *, limit=100):
        return await self.client.get_participants(entity, filter=types.ChannelParticipantsAdmins(), limit=limit)

    async def edit_admin_rights(self, entity, user, rights, *, rank=""):
        return await self.client(functions.channels.EditAdminRequest(
            channel=await self.resolve_input(entity),
            user_id=await self.resolve_input(user),
            admin_rights=rights,
            rank=rank,
        ))

    async def promote_admin(self, entity, user, rights, *, rank=""):
        return await self.edit_admin_rights(entity, user, rights, rank=rank)

    async def restrict_user(self, entity, user, banned_rights, *, rank=""):
        return await self.client(functions.channels.EditBannedRequest(
            channel=await self.resolve_input(entity),
            participant=await self.resolve_input(user),
            banned_rights=banned_rights,
        ))

    async def ban_user(self, entity, user):
        rights = types.ChatBannedRights(until_date=None, view_messages=True, send_messages=True)
        return await self.restrict_user(entity, user, rights)

    async def unban_user(self, entity, user):
        return await self.restrict_user(entity, user, types.ChatBannedRights(until_date=None))

    async def create_invite_link(self, entity, *, name=None, expire_date=None, usage_limit=None, request_needed=False):
        return await self.client(functions.messages.ExportChatInviteRequest(
            peer=await self.resolve_input(entity),
            legacy_revoke_permanent=False,
            request_needed=request_needed,
            expire_date=expire_date,
            usage_limit=usage_limit,
            title=name,
        ))

    async def revoke_invite_link(self, entity, link):
        return await self.client(functions.messages.EditExportedChatInviteRequest(
            peer=await self.resolve_input(entity),
            link=link, revoked=True
        ))

    # ----- reactions / polls / callbacks ------------------------------------
    async def react(self, entity, message_id: int, reaction):
        return await self.client(functions.messages.SendReactionRequest(
            peer=await self.resolve_input(entity),
            msg_id=message_id,
            reaction=[reaction] if not isinstance(reaction, (list, tuple)) else list(reaction),
            add_to_recent=True,
        ))

    async def create_poll(self, entity, question: str, answers, *, multiple_choice=False, quiz=False, close_period=None, close_date=None):
        """Схема Poll менялась между слоями TL (str vs TextWithEntities) —
        адаптируемся в рантайме так же, как client-handler create_poll."""
        def _txt(value: str):
            if hasattr(types, "TextWithEntities"):
                return types.TextWithEntities(text=str(value), entities=[])
            return str(value)

        poll = types.Poll(
            id=random.getrandbits(63),
            question=_txt(question),
            answers=[types.PollAnswer(text=_txt(a), option=bytes([i])) for i, a in enumerate(answers)],
            close_period=close_period,
            close_date=close_date,
            public_voters=False,
            multiple_choice=multiple_choice,
            quiz=quiz,
        )
        return await self.client.send_message(entity, file=types.InputMediaPoll(poll=poll))

    async def stop_poll(self, entity, message_id: int):
        """Закрывает опрос, переиспользуя реальный объект Poll из сообщения."""
        msg = await self.client.get_messages(entity, ids=message_id)
        poll = getattr(msg, "poll", None)
        poll = getattr(poll, "poll", poll)  # MessageMediaPoll -> Poll
        if poll is None:
            raise ValueError("message has no poll")
        poll.closed = True
        return await self.client.edit_message(entity, message_id, file=types.InputMediaPoll(poll=poll))

    async def answer_callback(self, entity, message_id: int, *, data=None, game=False):
        return await self.client(functions.messages.GetBotCallbackAnswerRequest(
            peer=await self.resolve_input(entity), msg_id=message_id, data=data, game=game
        ))

    # ----- scheduled messages / drafts --------------------------------------
    async def schedule_message(self, entity, message, *, schedule):
        return await self.client.send_message(entity, message, schedule=schedule)

    async def get_scheduled_messages(self, entity):
        return await self.client.get_messages(entity, scheduled=True)

    async def delete_scheduled_message(self, entity, message_id: int):
        return await self.client.delete_messages(entity, message_id)

    async def get_drafts(self):
        return await self.client(functions.messages.GetAllDraftsRequest())

    async def clear_draft(self, entity):
        return await self.client(functions.messages.SaveDraftRequest(
            peer=await self.resolve_input(entity), message="", no_webpage=True,
            invert_media=False, entities=[], media=None, reply_to=None
        ))

    # ----- notifications / filters / sessions -------------------------------
    async def get_notify_settings(self, entity):
        return await self.client(functions.account.GetNotifySettingsRequest(
            peer=await self.resolve_input(entity)
        ))

    async def update_notify_settings(self, entity, settings):
        return await self.client(functions.account.UpdateNotifySettingsRequest(
            peer=await self.resolve_input(entity), settings=settings
        ))

    async def get_dialog_filters(self):
        return await self.client(functions.messages.GetDialogFiltersRequest())

    async def get_authorizations(self):
        return await self.client(functions.account.GetAuthorizationsRequest())

    async def reset_authorization(self, hash_value: int):
        return await self.client(functions.account.ResetAuthorizationRequest(hash=hash_value))

    async def set_online(self, online: bool = True):
        return await self.client(functions.account.UpdateStatusRequest(offline=not online))

    # ----- convenience / diagnostics ----------------------------------------
    async def send_reaction(self, entity, message_id: int, reaction):
        return await self.react(entity, message_id, reaction)

    async def forward(self, entity, messages, *, from_peer=None, drop_author=False):
        return await self.forward_messages(entity, messages, from_peer=from_peer, drop_author=drop_author)

    async def chat_info(self, entity):
        return await self.resolve(entity)

    async def user_info(self, entity):
        return await self.resolve(entity)

    async def health(self):
        me = await self.client.get_me()
        return {"connected": bool(me), "id": getattr(me, "id", None), "username": getattr(me, "username", None)}
