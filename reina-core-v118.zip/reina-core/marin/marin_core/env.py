"""Надёжный разбор переменных окружения — единая точка для всего marin_core.

Раньше настройки читались десятками сырых вызовов ``float(os.getenv(...))`` /
``int(os.getenv(...))`` прямо на уровне модулей (см. telegram/settings.py). Любая
опечатка в .env (``MARIN_TELEGRAM_DEBOUNCE_SECONDS=2,5`` с запятой, ``30s`` с
суффиксом, пустая строка) роняла **весь** процесс ещё на импорте — с
непонятным ``ValueError`` вместо работы со значением по умолчанию.

Хелперы ниже никогда не бросают исключение на плохом вводе: они логируют
предупреждение и возвращают default. Так один неверный параметр больше не
мешает боту стартовать. Модуль зависит только от stdlib, поэтому его можно
импортировать откуда угодно (в т.ч. из config.py и telegram/settings.py) без
риска циклических импортов.
"""
from __future__ import annotations

import logging
import os
from typing import Dict, Optional

logger = logging.getLogger("marin_core.env")

# Слой переопределений поверх окружения: самонастройка Марин (см.
# telegram/self_awareness.py) меняет значения здесь, НЕ трогая os.environ
# и .env — базовое значение владельца всегда видно и восстанавливается
# одним сбросом.
_OVERRIDES: Dict[str, str] = {}


def set_override(name: str, value) -> None:
    _OVERRIDES[name] = str(value)


def clear_override(name: str) -> None:
    _OVERRIDES.pop(name, None)


def clear_all_overrides() -> None:
    _OVERRIDES.clear()


def get_override(name: str) -> Optional[str]:
    return _OVERRIDES.get(name)


def _raw(name: str) -> Optional[str]:
    return _OVERRIDES[name] if name in _OVERRIDES else os.getenv(name)

_TRUE = {"1", "true", "yes", "y", "on", "да", "истина"}
_FALSE = {"0", "false", "no", "n", "off", "нет", "ложь", ""}


def env_str(name: str, default: str = "") -> str:
    """Строка окружения с очисткой пробелов; отсутствует → default."""
    val = _raw(name)
    return default if val is None else val.strip()


def env_float(
    name: str,
    default: float,
    *,
    minimum: Optional[float] = None,
    maximum: Optional[float] = None,
) -> float:
    """float из окружения с fallback на default при любой ошибке разбора.

    minimum/maximum, если заданы, зажимают результат в диапазон — удобно для
    таймаутов и вероятностей, которые не должны уходить в отрицательные или
    абсурдно большие значения даже если так написали в .env.
    """
    raw = _raw(name)
    if raw is None or raw.strip() == "":
        value = float(default)
    else:
        try:
            value = float(raw.strip().replace(",", "."))
        except (TypeError, ValueError):
            logger.warning(
                "[ENV] %s=%r — не число, использую значение по умолчанию %s",
                name, raw, default,
            )
            value = float(default)
    if minimum is not None:
        value = max(minimum, value)
    if maximum is not None:
        value = min(maximum, value)
    return value


def env_int(
    name: str,
    default: int,
    *,
    minimum: Optional[int] = None,
    maximum: Optional[int] = None,
) -> int:
    """int из окружения с fallback. Принимает и ``"3"``, и ``"3.0"``."""
    raw = _raw(name)
    if raw is None or raw.strip() == "":
        value = int(default)
    else:
        try:
            # допускаем "3.0" → 3, чтобы float-подобные значения не роняли старт
            value = int(float(raw.strip().replace(",", ".")))
        except (TypeError, ValueError):
            logger.warning(
                "[ENV] %s=%r — не целое число, использую значение по умолчанию %s",
                name, raw, default,
            )
            value = int(default)
    if minimum is not None:
        value = max(minimum, value)
    if maximum is not None:
        value = min(maximum, value)
    return value


def env_bool(name: str, default: bool) -> bool:
    """Булев флаг из окружения. true/1/yes/on/да → True, false/0/no/off/нет → False.

    Незнакомое значение → default (с предупреждением), а не молчаливое False.
    """
    raw = _raw(name)
    if raw is None:
        return default
    token = raw.strip().lower()
    if token in _TRUE:
        return True
    if token in _FALSE:
        return False
    logger.warning(
        "[ENV] %s=%r — непонятный булев флаг, использую значение по умолчанию %s",
        name, raw, default,
    )
    return default
