"""
Theory of Mind — §11 спеки: не только "что мы знаем об акторе", но и
"что, по нашей оценке, актор думает о нас" (their_beliefs_about_us),
с более низкой confidence, так как это вывод второго порядка.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List


@dataclass
class TheoryOfMindEntry:
    """Одно предположение о ментальном состоянии другого актора."""

    actor_id: str
    statement: str            # напр. "user believes Marin remembers their birthday"
    confidence: float = 0.3   # по умолчанию ниже, чем для belief о самом мире (§7),
                               # т.к. это вывод второго порядка
    order: int = 1             # 1 = "что актор думает", 2 = "что актор думает, что мы думаем", ...


class TheoryOfMindStore:
    def __init__(self) -> None:
        self._entries: List[TheoryOfMindEntry] = []

    def add(self, entry: TheoryOfMindEntry) -> None:
        self._entries.append(entry)

    def for_actor(self, actor_id: str) -> List[TheoryOfMindEntry]:
        return [e for e in self._entries if e.actor_id == actor_id]

    def high_confidence_for_actor(self, actor_id: str, threshold: float = 0.6) -> List[TheoryOfMindEntry]:
        return [e for e in self.for_actor(actor_id) if e.confidence >= threshold]
