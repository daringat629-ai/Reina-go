"""
Relationship — §11 спеки. relationship_state обновляется той же EMA-схемой,
что Personality (§4.1), но со своей константой alpha_rel (быстрее, чем
personality, медленнее, чем context — см. таблицу §12).
"""

from __future__ import annotations

from dataclasses import dataclass, field
import time


@dataclass
class RelationshipState:
    entity_id: str
    trust: float = 0.5
    closeness: float = 0.3
    history_valence_ema: float = 0.0
    interaction_count: int = 0
    last_interaction_t: float = field(default_factory=time.time)

    alpha_rel: float = 1e-2  # §4.1/§12: Relationship.update_rate ~ 1e-2

    def observe_interaction(self, valence: float, trust_signal: float = 0.0, closeness_signal: float = 0.0) -> None:
        """EMA-обновление после каждого взаимодействия (§4.1 форма,
        применённая к Relationship вместо Personality)."""
        self.history_valence_ema += self.alpha_rel * (valence - self.history_valence_ema)
        self.trust = max(0.0, min(1.0, self.trust + self.alpha_rel * (trust_signal - self.trust) if trust_signal else self.trust))
        self.closeness = max(0.0, min(1.0, self.closeness + self.alpha_rel * (closeness_signal - self.closeness) if closeness_signal else self.closeness))
        self.interaction_count += 1
        self.last_interaction_t = time.time()
