"""
Social Model — §11 спеки. SocialNode на каждого известного актора,
объединяющий beliefs_about_them, their_beliefs_about_us (theory of mind)
и relationship_state. Основа для нормального поведения в групповых чатах
(раздел 25 документа).
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from .relationship import RelationshipState
from .theory_of_mind import TheoryOfMindStore, TheoryOfMindEntry


@dataclass
class SocialNode:
    entity_id: str
    beliefs_about_them: List[str] = field(default_factory=list)  # ids в BeliefStore
    relationship: RelationshipState = None  # type: ignore[assignment]

    def __post_init__(self):
        if self.relationship is None:
            self.relationship = RelationshipState(entity_id=self.entity_id)


class SocialModel:
    def __init__(self) -> None:
        self._nodes: Dict[str, SocialNode] = {}
        self.tom = TheoryOfMindStore()
        self.owner_id: Optional[str] = None

    def get_or_create(self, entity_id: str) -> SocialNode:
        if entity_id not in self._nodes:
            self._nodes[entity_id] = SocialNode(entity_id=entity_id)
        return self._nodes[entity_id]

    def mark_owner(self, entity_id: str) -> None:
        """Владелец определяется инфраструктурой (напр. по Telegram user_id)
        ДО вызова ядра и сообщается через observation.metadata['is_owner'].
        Здесь — фиксируем это в SocialModel и один раз поднимаем базовый
        trust/closeness, чтобы их не нужно было "зарабатывать" с нуля (§11)."""
        self.owner_id = entity_id
        node = self.get_or_create(entity_id)
        # По умолчанию близость НЕ задаётся заранее: она складывается из реальной
        # истории общения, как с любым человеком. Старое поведение (жёсткие
        # 0.95/0.9) — только при MARIN_OWNER_FIXED_BOND=true.
        if self._fixed_bond():
            node.relationship.trust = max(node.relationship.trust, self.OWNER_TRUST_FLOOR)
            node.relationship.closeness = max(node.relationship.closeness, self.OWNER_CLOSENESS_FLOOR)

    @staticmethod
    def _fixed_bond() -> bool:
        return os.getenv("MARIN_OWNER_FIXED_BOND", "false").strip().lower() in {"1", "true", "yes", "on"}

    def is_owner(self, entity_id: str) -> bool:
        return self.owner_id is not None and entity_id == self.owner_id

    OWNER_TRUST_FLOOR = 0.95
    OWNER_CLOSENESS_FLOOR = 0.9

    def observe_interaction(self, entity_id: str, valence: float, **kwargs) -> None:
        node = self.get_or_create(entity_id)
        node.relationship.observe_interaction(valence, **kwargs)
        # EMA-обновление тянет trust/closeness к сигналу взаимодействия и без
        # этого пола постепенно «разучивало» доверие к владельцу (0.95 -> 0.94…).
        if self.is_owner(entity_id) and self._fixed_bond():
            rel = node.relationship
            rel.trust = max(rel.trust, self.OWNER_TRUST_FLOOR)
            rel.closeness = max(rel.closeness, self.OWNER_CLOSENESS_FLOOR)

    def relationship_relevance(self, entity_id: str, memory_involves_entity: bool) -> float:
        """Используется в attention_score (§3) / retrieval_score (§5.2) как
        relationship_relevance для узла, связанного с данным актором."""
        if not memory_involves_entity or entity_id not in self._nodes:
            return 0.0
        node = self._nodes[entity_id]
        return 0.5 * node.relationship.closeness + 0.5 * node.relationship.trust

    def known_actors(self) -> List[str]:
        return list(self._nodes.keys())
