"""
§8 спеки — решающее правило поверх распределения гипотез:

if max(p_i) > theta_confident:                         act_on(h_argmax)
elif max(p_i) - second_max < theta_close and stakes>theta_stakes:  ASK_CLARIFY
else:                                                    act_on(h_argmax, hedge=True)
"""

from __future__ import annotations

from typing import List, Tuple

from ..action.action import ActionType


def select_action_type_from_hypotheses(
    hypotheses,  # ожидается объект с .items() -> List[(hypothesis, prob)] или список кортежей
    stakes: float,
    theta_confident: float = 0.7,
    theta_close: float = 0.1,
    theta_stakes: float = 0.6,
) -> ActionType:
    items: List[Tuple[object, float]] = hypotheses if isinstance(hypotheses, list) else list(hypotheses.items())
    if not items:
        return ActionType.ANSWER

    sorted_items = sorted(items, key=lambda pair: pair[1], reverse=True)
    top_p = sorted_items[0][1]
    second_p = sorted_items[1][1] if len(sorted_items) > 1 else 0.0

    if top_p > theta_confident:
        return ActionType.ANSWER
    if (top_p - second_p) < theta_close and stakes > theta_stakes:
        return ActionType.CLARIFY
    return ActionType.ANSWER  # act_on(h_argmax, hedge=True) — hedge помечается в payload вызывающим кодом
