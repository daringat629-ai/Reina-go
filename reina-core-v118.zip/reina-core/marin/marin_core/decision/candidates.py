"""
Полноценный набор кандидатов DecisionEngine.

Каждый кандидат оценивается по:
    expected_value  — насколько действие полезно на этот intent
                      (априорная таблица + выученное Q(intent, action))
    risk            — вероятность промаха (неуверенная интерпретация,
                      слабые belief'ы, уклонение от прямого вопроса)
    confidence      — насколько я уверена в самой оценке
    goal_alignment  — соответствие потребности собеседника + goal utility (§10.3)
    social_cost     — цена для отношений (игнор адресованного сообщения,
                      лишние переспрашивания, выученное раздражение)
    prediction      — явный прогноз исхода (prediction/predictor.py)

score = confidence·EV + 0.25·goal_alignment − stakes·risk − social_cost

Основное действие — одно из "говорящих" или "молчаливых"; побочные
(REMEMBER / FORGET / SEARCH / ACT) выбираются независимо, если их
score выше порога, и выполняются ActionExecutor'ом вместе с основным.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

from ..action.action import Action, ActionType, SILENT_ACTIONS


PRIMARY_TYPES = (
    ActionType.ANSWER, ActionType.ASK, ActionType.CLARIFY,
    ActionType.IGNORE, ActionType.OBSERVE, ActionType.DEFER,
)
SECONDARY_TYPES = (ActionType.REMEMBER, ActionType.FORGET, ActionType.SEARCH, ActionType.ACT)
SECONDARY_THRESHOLD = 0.45

_ANSWER_EV = {
    "question": 0.85, "request": 0.8, "statement": 0.65, "self_disclosure": 0.6, "greeting": 0.75,
    "farewell": 0.7, "gratitude": 0.7, "correction": 0.75, "complaint": 0.7, "small_talk": 0.65,
    "remember_request": 0.75, "forget_request": 0.75,
}
_ASK_EV = {"self_disclosure": 0.55, "statement": 0.45, "small_talk": 0.5, "complaint": 0.45, "greeting": 0.4}


@dataclass
class ScoredCandidate:
    action_type: ActionType
    expected_value: float
    risk: float
    confidence: float
    goal_alignment: float
    social_cost: float
    prediction: Optional[Any] = None
    score: float = 0.0
    rationale: str = ""
    vetoed: str = ""

    def to_dict(self) -> dict:
        return {
            "action": self.action_type.value, "score": round(self.score, 3),
            "expected_value": round(self.expected_value, 3), "risk": round(self.risk, 3),
            "confidence": round(self.confidence, 3), "goal_alignment": round(self.goal_alignment, 3),
            "social_cost": round(self.social_cost, 3), "rationale": self.rationale,
            **({"vetoed": self.vetoed} if self.vetoed else {}),
            **({"expected_response": self.prediction.expected_response_type} if self.prediction is not None else {}),
        }


@dataclass
class Decision:
    primary: Action
    secondary: List[Action]
    candidates: List[ScoredCandidate]
    confidence: float
    reason: str

    @property
    def selected(self) -> Optional[ScoredCandidate]:
        for c in self.candidates:
            if c.action_type == self.primary.type:
                return c
        return None


@dataclass
class RichDecisionContext:
    interpretation: Any
    stakes: float = 0.3
    is_owner: bool = False
    addressed: bool = True
    knowledge: float = 0.5                     # 0..1 из metacognition-оценки: знаю ли я тему
    action_values: Optional[Any] = None        # learning.pattern_learning.ActionValueStore
    predict: Optional[Callable[[str], Any]] = None   # action_type(str) -> Prediction
    legacy_utilities: Dict[str, float] = field(default_factory=dict)
    allowed_primary: Optional[List[str]] = None


class CandidateGenerator:
    def _learned(self, ctx: RichDecisionContext, action: str):
        if ctx.action_values is None:
            return 0.0, 0
        av = ctx.action_values.get(ctx.interpretation.intent, action)
        return av.value, av.n

    def generate(self, ctx: RichDecisionContext) -> List[ScoredCandidate]:
        it = ctx.interpretation
        intent = it.intent
        u = it.uncertainty
        misread = it.applied_pattern.misread_rate if (it.applied_pattern and it.applied_pattern.misread_intent) else 0.0
        vague = any("непонятно" in x or "не уверена" in x for x in it.uncertainties)
        out: List[ScoredCandidate] = []

        def add(atype: ActionType, ev, risk, conf, goal, cost, why):
            lv, n = self._learned(ctx, atype.value)
            if n:
                ev = ev + 0.5 * lv * (n / (n + 1.0))
                why += f"; выучено Q={lv:+.2f} (n={n})"
            goal = min(1.0, goal + max(0.0, ctx.legacy_utilities.get(atype.value, 0.0)))
            if atype in SECONDARY_TYPES and ev <= 0.0:
                goal = 0.0  # побочное действие без повода — не "почти выбранное"
            pred = ctx.predict(atype.value) if ctx.predict else None
            if pred is not None and atype in (ActionType.ANSWER,):
                risk += 0.3 * pred.assumptions.get("correction_risk", 0.0)
            out.append(ScoredCandidate(atype, ev, risk, conf, goal, cost, pred, rationale=why))

        answers_directly = intent in ("question", "request")
        # не ко мне обращались — встревать в разговор дорого (групповые чаты)
        intrude = 0.0 if ctx.addressed else 0.5
        speak_ev = 1.0 if ctx.addressed else 0.5
        add(ActionType.ANSWER, speak_ev * _ANSWER_EV.get(intent, 0.6), 0.6 * u, max(0.05, 1.0 - u),
            1.0 if answers_directly else 0.7, intrude, f"ответ на {intent}")
        add(ActionType.ASK, speak_ev * _ASK_EV.get(intent, 0.2), 0.35 if answers_directly else 0.1, 0.6,
            0.5, 0.05 + intrude, "поддержать разговор встречным вопросом")
        add(ActionType.CLARIFY, speak_ev * (0.15 + 0.9 * max(0.0, u - 0.35) + 0.35 * misread + (0.2 if vague else 0.0)),
            0.1, max(0.05, u), 0.4, 0.12 + intrude, f"неопределённость понимания {u:.2f}")
        add(ActionType.IGNORE, 0.05, 0.8 if ctx.addressed else 0.2, 0.7, 0.0,
            0.9 if ctx.addressed else 0.1, "не реагировать")
        add(ActionType.OBSERVE, 0.05 if ctx.addressed else 0.45, 0.3, 0.7, 0.0,
            0.6 if ctx.addressed else 0.05, "принять к сведению молча")
        add(ActionType.DEFER, 0.1, 0.3, 0.5, 0.1, 0.4 if ctx.addressed else 0.1, "ответить позже")

        # --- побочные
        asserts = [b for b in it.belief_updates if b.kind in ("assert", "note")]
        retracts = [b for b in it.belief_updates if b.kind == "retract"]
        add(ActionType.REMEMBER, (1.0 if intent == "remember_request" else 0.75) if asserts else 0.0,
            0.05, 0.8, 0.6, 0.0, f"сохранить {len(asserts)} факт(ов)")
        add(ActionType.FORGET, 1.0 if retracts else 0.0, 0.1, 0.9, 0.6, 0.0, "отозвать убеждение по просьбе")
        search_ev = 0.0
        if intent in ("question", "request") and ctx.knowledge < 0.35:
            search_ev = 0.65
        elif intent == "question" and (it.entities and not it.known_entities):
            search_ev = 0.55
        elif ctx.stakes >= 0.85 and intent in ("question", "request"):
            search_ev = 0.5
        add(ActionType.SEARCH, search_ev, 0.05, 0.8, 0.5, 0.0, f"знание темы {ctx.knowledge:.2f}")
        add(ActionType.ACT, 0.7 if it.act_requested else 0.0, 0.2, 0.7, 0.8, 0.0, "просьба о действии в мире")

        for c in out:
            c.score = c.confidence * c.expected_value + 0.25 * c.goal_alignment - ctx.stakes * c.risk - c.social_cost
        return out


class RichDecisionEngine:
    def __init__(self, generator: Optional[CandidateGenerator] = None):
        self.generator = generator or CandidateGenerator()

    def decide(self, ctx: RichDecisionContext) -> Decision:
        candidates = self.generator.generate(ctx)
        primary_c = [c for c in candidates if c.action_type in PRIMARY_TYPES]
        for c in primary_c:
            if ctx.addressed and c.action_type in SILENT_ACTIONS:
                c.vetoed = "ко мне обратились напрямую — молчать нельзя"
            if ctx.allowed_primary is not None and c.action_type.value not in ctx.allowed_primary:
                c.vetoed = c.vetoed or "не входит в разрешённые вызывающим кодом действия"
        eligible = sorted([c for c in primary_c if not c.vetoed], key=lambda c: c.score, reverse=True)
        if not eligible:
            primary = Action(type=ActionType.WAIT, payload={"reason": "no_candidates"})
            return Decision(primary, [], sorted(candidates, key=lambda c: c.score, reverse=True), 0.0, "нет допустимых действий")

        best = eligible[0]
        second = eligible[1].score if len(eligible) > 1 else best.score - 1.0
        margin = best.score - second
        confidence = 0.5 + 0.5 * math.tanh(4.0 * margin)

        secondary = []
        for c in candidates:
            if c.action_type in SECONDARY_TYPES and c.score >= SECONDARY_THRESHOLD:
                secondary.append(Action(type=c.action_type, payload={"score": round(c.score, 3), "rationale": c.rationale}))

        reason = (f"{best.action_type.value}: {best.rationale} "
                  f"(score {best.score:.2f}, отрыв {margin:.2f} от следующего)")
        primary = Action(type=best.action_type, payload={
            "utility_ranked": True, "decision_score": round(best.score, 3),
            "decision_confidence": round(confidence, 3), "reason": reason,
        })
        ranked = sorted(candidates, key=lambda c: c.score, reverse=True)
        return Decision(primary, secondary, ranked, confidence, reason)
