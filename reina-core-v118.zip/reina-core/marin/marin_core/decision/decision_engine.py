"""
Decision Engine — собирает Situation + State + Goals + Memory + Beliefs +
Predictions + Relationship + Uncertainty в кандидатов действий и выбирает
один (§16 п. decide). LLM НЕ участвует в этом выборе (§17) — она получает
уже принятое решение о ActionType и формулирует содержание.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

from ..action.action import Action, ActionType
from ..goals.goals import GoalSet
from ..goals.motivation import ActionCandidate, rank_actions
from .action_selection import select_action_type_from_hypotheses


@dataclass
class DecisionContext:
    situation: object          # perception.situation.SituationModel
    z: object                  # state.latent_state.LatentState
    goal_set: GoalSet
    hypotheses: Optional[list] = None   # belief.hypotheses.HypothesisSet, если ситуация неоднозначна
    stakes: float = 0.3        # цена ошибки в этой ситуации, 0..1


class DecisionEngine:
    def __init__(self, theta_confident: float = 0.7, theta_close: float = 0.1, theta_stakes: float = 0.6):
        self.theta_confident = theta_confident
        self.theta_close = theta_close
        self.theta_stakes = theta_stakes

    def decide(self, ctx: DecisionContext, action_candidates: List[ActionCandidate]) -> Action:
        # §8: если ситуация неоднозначна — сначала решаем, не нужно ли ASK_CLARIFY
        if ctx.hypotheses is not None:
            forced_type = select_action_type_from_hypotheses(
                ctx.hypotheses, ctx.stakes,
                theta_confident=self.theta_confident,
                theta_close=self.theta_close,
                theta_stakes=self.theta_stakes,
            )
            if forced_type == ActionType.CLARIFY:
                return Action(type=ActionType.CLARIFY, payload={"reason": "unresolved_hypotheses"})

        # §10.3: обычный путь — ранжирование кандидатов по utility
        ranked = rank_actions(action_candidates, ctx.goal_set)
        if not ranked:
            return Action(type=ActionType.WAIT, payload={"reason": "no_candidates"})

        best = ranked[0]
        return Action(type=ActionType(best.action_type), payload={"utility_ranked": True})
