"""Tiny NumPy-free numeric compatibility layer for Marin X.

This module intentionally implements only the small vector/matrix API used by
the reference Marin X core. It uses Python lists + math/random, so it works on
minimal Alpine installations without NumPy, BLAS or CPU-specific wheels.
"""
from __future__ import annotations
import math
import random
from typing import Iterable, Sequence, Union, overload

Number = Union[int, float]

class Vector(list):
    """1-D numeric vector with NumPy-like arithmetic needed by Marin X."""
    @property
    def shape(self):
        return (len(self),)
    def __getitem__(self, key):
        value = super().__getitem__(key)
        return Vector(value) if isinstance(key, slice) else value
    @property
    def size(self):
        return len(self)
    def astype(self, _dtype):
        return self
    def copy(self):
        return Vector(self)
    def mean(self):
        return sum(self) / len(self) if self else 0.0
    def max(self):
        return max(self) if self else float('-inf')
    def min(self):
        return min(self) if self else float('inf')
    def sum(self):
        return sum(self)
    def tolist(self):
        return list(self)
    def _coerce(self, other):
        if isinstance(other, (list, tuple, Vector)):
            # Как в numpy: векторы разной длины — ошибка формы, а не тихое
            # обрезание через zip. Иначе эмбеддинг неверной размерности
            # незаметно портил бы память, которая потом сохраняется на диск.
            if len(other) != len(self):
                raise ValueError(
                    f"operands could not be broadcast together with shapes "
                    f"({len(self)},) ({len(other)},)"
                )
            return other
        return [other] * len(self)
    def __add__(self, other):
        o = self._coerce(other); return Vector(a + b for a,b in zip(self,o))
    def __radd__(self, other): return self.__add__(other)
    def __sub__(self, other):
        o = self._coerce(other); return Vector(a - b for a,b in zip(self,o))
    def __rsub__(self, other):
        o = self._coerce(other); return Vector(a - b for a,b in zip(o,self))
    def __mul__(self, other):
        o = self._coerce(other); return Vector(a * b for a,b in zip(self,o))
    def __rmul__(self, other): return self.__mul__(other)
    def __truediv__(self, other):
        o = self._coerce(other); return Vector(a / b for a,b in zip(self,o))
    def __rtruediv__(self, other):
        o = self._coerce(other); return Vector(a / b for a,b in zip(o,self))
    def __neg__(self): return Vector(-a for a in self)
    def __repr__(self): return f"Vector({list.__repr__(self)})"

class Matrix(list):
    """2-D numeric matrix supporting matrix-vector @ multiplication."""
    @property
    def shape(self):
        return (len(self), len(self[0]) if self else 0)
    def astype(self, _dtype): return self
    def copy(self): return Matrix(Vector(r) for r in self)
    def __matmul__(self, other):
        v = list(other)
        return Vector(sum(a*b for a,b in zip(row,v)) for row in self)

def _is_2d(values) -> bool:
    if isinstance(values, Matrix):
        return True
    if isinstance(values, (list, tuple)) and values:
        return isinstance(values[0], (list, tuple, Vector))
    return False

def _apply(x, fn):
    if isinstance(x, Matrix): return Matrix(_apply(r,fn) for r in x)
    if isinstance(x, (list, tuple, Vector)): return Vector(fn(float(v)) for v in x)
    return fn(float(x))

class _Linalg:
    @staticmethod
    def norm(v):
        if isinstance(v, Matrix):
            return math.sqrt(sum(float(x)*float(x) for row in v for x in row))
        return math.sqrt(sum(float(x)*float(x) for x in v))

class _RNG:
    def __init__(self, seed=0): self.r = random.Random(seed)
    def normal(self, loc=0.0, scale=1.0, size=None):
        if isinstance(size, int): size=(size,)
        if not size: return self.r.gauss(loc,scale)
        if len(size)==1: return Vector(self.r.gauss(loc,scale) for _ in range(size[0]))
        if len(size)==2: return Matrix(Vector(self.r.gauss(loc,scale) for _ in range(size[1])) for _ in range(size[0]))
        raise ValueError("Only 1-D and 2-D random arrays are supported")

class _Random:
    @staticmethod
    def default_rng(seed=0): return _RNG(seed)

class _NP:
    ndarray = (Vector, Matrix)
    float32 = float
    linalg = _Linalg()
    random = _Random()
    @staticmethod
    def zeros(size, dtype=None):
        if isinstance(size, int): return Vector([0.0]*size)
        if len(size)==1: return Vector([0.0]*size[0])
        return Matrix(Vector([0.0]*size[1]) for _ in range(size[0]))
    @staticmethod
    def array(values, dtype=None):
        if isinstance(values, Matrix): return values.copy()
        if isinstance(values, Vector): return values.copy()
        if isinstance(values, (list,tuple)):
            if values and isinstance(values[0], (list,tuple,Vector)): return Matrix(Vector(v) for v in values)
            return Vector(float(v) for v in values)
        return values
    @staticmethod
    def concatenate(parts):
        out=Vector()
        for p in parts: out.extend(list(p))
        return out
    @staticmethod
    def mean(values, axis=None):
        if axis is None:
            # numpy: mean без axis — среднее по ВСЕМ элементам (скаляр), в т.ч.
            # для матрицы. Раньше для 2-D входа sum(rows) давал вектор, и
            # float(np.mean(...)) падал с TypeError.
            vals = [float(x) for row in values for x in row] if _is_2d(values) else [float(v) for v in values]
            return sum(vals)/len(vals) if vals else 0.0
        vals=list(values)
        if not vals: return Vector()
        if axis==0:
            n=len(vals[0]); return Vector(sum(row[i] for row in vals)/len(vals) for i in range(n))
        raise ValueError("Only axis=None and axis=0 are supported")
    @staticmethod
    def stack(values, axis=0):
        vals=[Vector(v) for v in values]
        return Matrix(vals)
    @staticmethod
    def dot(a,b):
        if len(a) != len(b):
            raise ValueError(f"shapes ({len(a)},) and ({len(b)},) not aligned")
        return sum(x*y for x,y in zip(a,b))
    @staticmethod
    def exp(x): return _apply(x, math.exp)
    @staticmethod
    def sqrt(x): return _apply(x, math.sqrt)
    @staticmethod
    def tanh(x): return _apply(x, math.tanh)

np = _NP()
