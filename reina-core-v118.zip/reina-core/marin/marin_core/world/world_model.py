"""
World Model — фасад, объединяющий Entities/Relations/Events/CausalModel
в единую модель "что мы знаем о мире вокруг Marin" (раздел 6 документа).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from .entities import Entity, Relation, EntityKind
from .events import WorldEvent
from .causal_model import CausalModel, CausalLink


class WorldModel:
    def __init__(self) -> None:
        self.entities: Dict[str, Entity] = {}
        self.relations: List[Relation] = []
        self.events: Dict[str, WorldEvent] = {}
        self.causal = CausalModel()
        # Последние N событий на сущность — не просто лог, а то, что кормит
        # CausalModel.observe_sequence реальными "A потом B" наблюдениями и
        # даёт continuity-сводку для конкретного актора (§24 + conversation
        # continuity из ревью), а не только эмбеддинг-based retrieval.
        self.last_event_by_entity: Dict[str, List[str]] = {}

    def record_sequential_event(self, event: "WorldEvent", entity_id: str, chain_len: int = 5) -> None:
        self.add_event(event)
        history = self.last_event_by_entity.setdefault(entity_id, [])
        if history:
            self.causal.observe_sequence(history[-1], event.id)
        history.append(event.id)
        if len(history) > chain_len:
            del history[: len(history) - chain_len]

    def recent_chain_summary(self, entity_id: str) -> str:
        ids = self.last_event_by_entity.get(entity_id, [])
        descriptions = [self.events[eid].description for eid in ids if eid in self.events]
        return " → ".join(descriptions)

    def upsert_entity(self, entity: Entity) -> str:
        self.entities[entity.id] = entity
        return entity.id

    def add_relation(self, relation: Relation) -> None:
        self.relations.append(relation)

    def relations_of(self, entity_id: str) -> List[Relation]:
        return [r for r in self.relations if r.source_id == entity_id]

    def add_event(self, event: WorldEvent) -> str:
        self.events[event.id] = event
        return event.id

    def find_entity_by_name(self, name: str, kind: Optional[EntityKind] = None) -> Optional[Entity]:
        for e in self.entities.values():
            if e.name == name and (kind is None or e.kind == kind):
                return e
        return None
