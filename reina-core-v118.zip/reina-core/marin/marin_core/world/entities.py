"""
Entities — узлы World Model (раздел 6 документа): Entities, Relations,
States, Actors, Locations. Отдельно от Memory Graph: World Model хранит
"текущую модель мира" (факты и их состояния), Memory Graph — прожитый опыт.
Оба графа могут ссылаться друг на друга по id.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional
import uuid


class EntityKind(str, Enum):
    PERSON = "person"
    PLACE = "place"
    TOPIC = "topic"
    OBJECT = "object"
    GOAL = "goal"
    OTHER = "other"


@dataclass
class Entity:
    kind: EntityKind
    name: str
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    attributes: Dict[str, str] = field(default_factory=dict)
    states: Dict[str, str] = field(default_factory=dict)  # текущее известное состояние сущности


@dataclass
class Relation:
    """Например USER --knows--> MARIN, USER --prefers--> TOPIC_Y (раздел 6)."""

    relation_type: str
    source_id: str
    target_id: str
    confidence: float = 1.0  # связывается с belief/, если relation выведена, а не задана явно
