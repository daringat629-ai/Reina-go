"""
Events — временные/причинные события World Model (раздел 6 документа):
EVENT_A.happened_before -> EVENT_B, EVENT_A.caused? -> STATE_C.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional
import uuid
import time


@dataclass
class WorldEvent:
    description: str
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    t_occurred: float = field(default_factory=time.time)
    involved_entity_ids: List[str] = field(default_factory=list)
    caused_state_ids: List[str] = field(default_factory=list)  # с confidence — см. causal_model.py
