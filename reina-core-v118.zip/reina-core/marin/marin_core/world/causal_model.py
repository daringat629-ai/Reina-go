"""
Causal learning — §24 документа: "A happened, B happened" -> постепенно
"A may have contributed to B", с явной неопределённостью, а не жёсткой
причинностью. Используется reasoning/causal_reasoning.py.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Tuple


@dataclass
class CausalLink:
    cause_event_id: str
    effect_event_id: str
    confidence: float = 0.1  # растёт с числом наблюдений совпадения A->B


class CausalModel:
    def __init__(self) -> None:
        self._links: Dict[Tuple[str, str], CausalLink] = {}

    def observe_sequence(self, cause_id: str, effect_id: str, increment: float = 0.05) -> CausalLink:
        """Каждое повторное наблюдение "A потом B" немного усиливает
        причинную гипотезу — аналог §7.1 логит-обновления, но проще (линейно,
        с насыщением), так как здесь нет прямого counter_evidence сигнала."""
        key = (cause_id, effect_id)
        link = self._links.get(key)
        if link is None:
            link = CausalLink(cause_event_id=cause_id, effect_event_id=effect_id, confidence=increment)
            self._links[key] = link
        else:
            link.confidence = min(1.0, link.confidence + increment * (1 - link.confidence))
        return link

    def likely_causes(self, effect_id: str, min_confidence: float = 0.3) -> List[CausalLink]:
        return [l for (c, e), l in self._links.items() if e == effect_id and l.confidence >= min_confidence]
