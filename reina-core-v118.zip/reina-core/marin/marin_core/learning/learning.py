"""
Learning Engine — §12 спеки. Разные подсистемы обучаются с разной
скоростью, но одной и той же математической формой (EMA / logit-EMA),
чтобы вся система оставалась объяснимой. Этот модуль — диспетчер, который
после каждого тика (или консолидации) рассылает сигналы в нужные слои.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional

from ..identity.personality_dynamics import PersonalityDynamics
from ..social.relationship import RelationshipState
from ..prediction.predictor import Prediction, Outcome


LAYER_RATES = {
    "context_state": 1.0,        # пересчитывается каждый тик (§1.2), не EMA
    "prediction_stats": 0.05,    # десятки тиков
    "relationship": 1e-2,        # сотни тиков
    "personality": 1e-3,         # тысячи тиков
    "identity": 1e-4,            # только через явный reflective update, §13
}


@dataclass
class PredictionStats:
    """logit-EMA статистика по типам прогнозов — какие чаще ошибаются (§12, §14 п.6)."""

    mean_error_by_type: Dict[str, float] = None
    rate: float = LAYER_RATES["prediction_stats"]

    def __post_init__(self):
        if self.mean_error_by_type is None:
            self.mean_error_by_type = {}

    def update(self, prediction: Prediction, error: float) -> None:
        key = prediction.expected_response_type
        current = self.mean_error_by_type.get(key, error)
        self.mean_error_by_type[key] = current + self.rate * (error - current)


class LearningEngine:
    """Оркестрирует обновление медленных слоёв после тика/консолидации.
    Context/State и Behavior/Policy НЕ проходят через этот класс — они
    пересчитываются каждый тик напрямую в engine/cycle.py (§1.2)."""

    def __init__(self):
        self.prediction_stats = PredictionStats()

    def on_tick_complete(
        self,
        prediction: Prediction,
        outcome: Outcome,
        prediction_error: float,
        personality: Optional[PersonalityDynamics] = None,
        observed_trait_signal: Optional[Dict[str, float]] = None,
        relationship: Optional[RelationshipState] = None,
        interaction_valence: Optional[float] = None,
    ) -> None:
        self.prediction_stats.update(prediction, prediction_error)

        if personality is not None and observed_trait_signal:
            personality.update_from_observed_signal(observed_trait_signal)

        if relationship is not None and interaction_valence is not None:
            relationship.observe_interaction(interaction_valence)
