"""
Experience learning — связывает memory/experience.py с learning/learning.py:
проходит по накопленным ExperienceRecord и агрегирует их в сигналы для
медленных слоёв (personality trait signals, relationship valence) —
используется, например, во время offline consolidation (§14 п.5).
"""

from __future__ import annotations

from typing import Dict, List

from ..memory.experience import ExperienceSystem
from ..memory.memory_graph import MemoryNode


def aggregate_trait_signal_from_window(nodes: List[MemoryNode]) -> Dict[str, float]:
    """Грубая эвристика для холодного старта: считает долю узлов с
    позитивным/негативным valence как сигнал для personality trait
    "warmth". Реальная версия должна классифицировать поведение по чертам
    через reasoning engine, а не по одному полю.

    valence — реальное поле MemoryNode (не payload-ключ, см. memory_graph.py
    и engine/cycle.py, который его туда пишет из situation.tone.valence)."""
    if not nodes:
        return {}
    valences = [n.valence for n in nodes if n.valence != 0.0]
    if not valences:
        return {}
    avg = sum(valences) / len(valences)
    # маппим среднюю валентность в сигнал по чертe "warmth", 0..1
    warmth_signal = max(0.0, min(1.0, (avg + 1.0) / 2.0))
    return {"warmth": warmth_signal}


def aggregate_relationship_valence(nodes: List[MemoryNode], actor_id: str) -> float:
    """actor лежит вложенно в payload["situation"]["actor"] (см.
    experience.record_tick / engine/cycle.py), а не как плоский payload["actor"]."""
    relevant = [
        n for n in nodes
        if n.payload.get("situation", {}).get("actor") == actor_id and n.valence != 0.0
    ]
    if not relevant:
        return 0.0
    return sum(n.valence for n in relevant) / len(relevant)
