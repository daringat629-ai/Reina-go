"""
Настоящее обучение из prediction error.

Раньше исход действия был заглушкой в момент отправки ("neutral_reply"),
поэтому prediction_error был почти константой и шёл только в метрику.
Теперь:

    тик t:   interpretation + prediction(assumptions) + action  -> PendingTick
    тик t+1: реплика того же человека -> Interpretation.feedback
             -> реальный Outcome для тика t -> prediction_error
             -> attribution: ЧТО было неверным?
                  intent            (ты не так поняла)
                  belief            (это неправда / я такого не говорил)
                  social assumption (реакция холоднее/теплее, чем ждала)
                  goal              (не помогло / это не то, что нужно)
                  action            (не переспрашивай / просто ответь)
             -> обновляется ИМЕННО источник ошибки
             -> следующее решение меняется (patterns / action values /
                belief confidence / social bias)
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from ..prediction.predictor import Outcome, Prediction
from ..prediction.prediction_error import PredictionErrorWeights, compute_prediction_error
from .pattern_learning import ActionValueStore, InterpretationPatternStore, SocialExpectationStore


@dataclass
class PendingTick:
    actor_id: str
    tick: int
    intent: str
    signatures: List[str]
    action_type: str
    prediction: Prediction
    belief_ids: List[str] = field(default_factory=list)
    topic: Optional[str] = None
    t_created: float = field(default_factory=time.time)


@dataclass
class Attribution:
    source: str             # intent | belief | social | goal | action | none
    error: float
    detail: str = ""


@dataclass
class LearningReport:
    feedback: str
    outcome: Outcome
    prediction_error: float
    attribution: Attribution
    updates: List[str] = field(default_factory=list)
    lessons: List[str] = field(default_factory=list)   # новые устойчивые паттерны
    previous_action: str = ""
    previous_intent: str = ""

    def describe(self) -> str:
        s = (f"реакция={self.feedback}, ошибка прогноза={self.prediction_error:.2f}, "
             f"источник={self.attribution.source}")
        if self.updates:
            s += "; обновлено: " + "; ".join(self.updates[:4])
        return s


def outcome_from_feedback(interpretation, pending: PendingTick) -> Outcome:
    fb = interpretation.feedback
    valence = interpretation.valence
    if fb.kind in ("correction", "belief_denial"):
        rtype = "correction"
        valence = min(valence, -0.2)
    elif fb.kind in ("action_complaint", "goal_miss", "negative"):
        rtype = "negative_reply"
        valence = min(valence, -0.3)
    elif fb.kind == "positive":
        rtype = "positive_reply"
        valence = max(valence, 0.3)
    elif pending.action_type in ("ask", "clarify") and interpretation.intent != "question":
        rtype = "clarification_answer"
    else:
        rtype = "neutral_reply"
        # без явной реакции тон реплики — это тон её собственного содержания
        # ("я люблю кофе"), а не оценка моего ответа: учитываем его слабо
        valence = 0.3 * valence

    if fb.kind in ("goal_miss", "correction"):
        progress = 0.0
    elif fb.kind == "action_complaint":
        progress = 0.1
    elif fb.kind == "positive":
        progress = 0.9
    elif rtype == "clarification_answer":
        progress = 0.5
    else:
        progress = 0.5  # разговор продолжился без претензий — частичный успех
    return Outcome(actual_type=rtype, actual_valence=max(-1.0, min(1.0, valence)), actual_goal_progress=progress)


class ErrorAttributor:
    SOCIAL_VALENCE_GAP = 0.45

    def attribute(self, pending: PendingTick, interpretation, outcome: Outcome, error: float) -> Attribution:
        fb = interpretation.feedback
        if fb.kind == "correction" and fb.corrected_intent and fb.corrected_intent == pending.intent:
            # поняла я правильно — не то было само действие
            return Attribution("action", error, f"intent {pending.intent} был верным, но {pending.action_type} не подошло")
        if fb.kind == "correction":
            return Attribution("intent", error, f"я поняла как {pending.intent}"
                               + (f", а имелось в виду {fb.corrected_intent}" if fb.corrected_intent else ""))
        if fb.kind == "belief_denial":
            return Attribution("belief", error, "собеседник опроверг то, что я считала верным")
        if fb.kind == "action_complaint":
            return Attribution("action", error, f"действие {pending.action_type} было неуместным")
        if fb.kind == "goal_miss":
            return Attribution("goal", error, "ответ не решил задачу собеседника")
        gap = outcome.actual_valence - pending.prediction.expected_valence
        if abs(gap) >= self.SOCIAL_VALENCE_GAP:
            direction = "холоднее" if gap < 0 else "теплее"
            return Attribution("social", error, f"реакция {direction}, чем я ожидала ({gap:+.2f})")
        return Attribution("none", error, "прогноз в целом оправдался")


class FeedbackLearner:
    """Держит выучиваемые хранилища и ожидания реакций по каждому актору."""

    PENDING_TTL_SECONDS = 6 * 3600

    def __init__(
        self,
        patterns: Optional[InterpretationPatternStore] = None,
        action_values: Optional[ActionValueStore] = None,
        social: Optional[SocialExpectationStore] = None,
        error_weights: Optional[PredictionErrorWeights] = None,
    ):
        self.patterns = patterns or InterpretationPatternStore()
        self.action_values = action_values or ActionValueStore()
        self.social = social or SocialExpectationStore()
        self.error_weights = error_weights or PredictionErrorWeights()
        self.attributor = ErrorAttributor()
        self.pending: Dict[str, PendingTick] = {}
        self.error_by_source: Dict[str, float] = {}
        self.count_by_source: Dict[str, int] = {}
        self.history: List[LearningReport] = []
        self.history_max = 100

    # --------------------------------------------------------------
    def pending_for(self, actor_id: str, now: Optional[float] = None) -> Optional[PendingTick]:
        p = self.pending.get(actor_id)
        if p is None:
            return None
        if (now or time.time()) - p.t_created > self.PENDING_TTL_SECONDS:
            self.pending.pop(actor_id, None)
            return None
        return p

    def register(self, pending: PendingTick) -> None:
        self.pending[pending.actor_id] = pending

    # --------------------------------------------------------------
    def learn(self, interpretation, pending: PendingTick, beliefs=None, social_model=None) -> LearningReport:
        """Разрешает прошлый прогноз реальной реакцией и обновляет источник ошибки."""
        self.pending.pop(pending.actor_id, None)
        outcome = outcome_from_feedback(interpretation, pending)
        error = compute_prediction_error(pending.prediction, outcome, self.error_weights)
        attr = self.attributor.attribute(pending, interpretation, outcome, error)
        fb = interpretation.feedback
        updates: List[str] = []

        # награда действия: реальная реакция, а не заглушка
        reward = {
            "positive_reply": 0.8, "neutral_reply": 0.2, "clarification_answer": 0.3,
            "negative_reply": -0.6, "correction": -0.5,
        }.get(outcome.actual_type, 0.0)

        if attr.source == "intent":
            self.patterns.learn_correction(pending.signatures, pending.intent, fb.corrected_intent, strength=fb.strength)
            updates.append(f"паттерн {pending.signatures[0]}: {pending.intent} помечен как ошибочное прочтение"
                           + (f", верное — {fb.corrected_intent}" if fb.corrected_intent else ""))
            av = self.action_values.update(pending.intent, pending.action_type, -0.4)
            updates.append(f"Q({pending.intent},{pending.action_type})={av.value:+.2f}")
        elif attr.source == "action":
            av = self.action_values.update(pending.intent, pending.action_type, -0.9)
            updates.append(f"Q({pending.intent},{pending.action_type})={av.value:+.2f}")
            # само прочтение intent было верным — подкрепляем его
            self.patterns.reinforce(pending.signatures, pending.intent, 0.5)
        elif attr.source == "belief":
            touched = self._weaken_beliefs(beliefs, pending, interpretation)
            updates += touched or ["нет belief'ов для ослабления — ошибка залогирована"]
            self.action_values.update(pending.intent, pending.action_type, -0.2)
        elif attr.source == "goal":
            av = self.action_values.update(pending.intent, pending.action_type, -0.6)
            updates.append(f"Q({pending.intent},{pending.action_type})={av.value:+.2f} (не решило задачу)")
        elif attr.source == "social":
            bias = self.social.update(pending.actor_id, pending.prediction.expected_valence, outcome.actual_valence)
            updates.append(f"социальная поправка для {pending.actor_id}: {bias:+.2f}")
            self.action_values.update(pending.intent, pending.action_type, reward)
            if social_model is not None and outcome.actual_valence < -0.4:
                rel = social_model.get_or_create(pending.actor_id).relationship
                rel.trust = max(0.0, rel.trust - 0.02)
        else:
            av = self.action_values.update(pending.intent, pending.action_type, reward)
            # разговор продолжился без поправок — прочтение intent подтверждено
            weight = 1.0 if outcome.actual_type == "positive_reply" else 0.4
            self.patterns.reinforce(pending.signatures, pending.intent, weight)
            self.social.update(pending.actor_id, pending.prediction.expected_valence, outcome.actual_valence)
            if outcome.actual_type == "positive_reply":
                self._support_beliefs(beliefs, pending)
            updates.append(f"Q({pending.intent},{pending.action_type})={av.value:+.2f}")

        n = self.count_by_source.get(attr.source, 0) + 1
        self.count_by_source[attr.source] = n
        prev = self.error_by_source.get(attr.source, error)
        self.error_by_source[attr.source] = prev + max(0.05, 1.0 / n) * (error - prev)

        lessons = [p.describe() for p in self.patterns.new_lessons()]
        report = LearningReport(
            feedback=fb.kind, outcome=outcome, prediction_error=error, attribution=attr,
            updates=updates, lessons=lessons, previous_action=pending.action_type, previous_intent=pending.intent,
        )
        self.history.append(report)
        if len(self.history) > self.history_max:
            del self.history[: len(self.history) - self.history_max]
        return report

    # --------------------------------------------------------------
    @staticmethod
    def _tokens(text: str) -> set:
        from ..interpretation.lexicon import STOPWORDS, tokens
        return {t for t in tokens(text) if t not in STOPWORDS and len(t) >= 3}

    def _weaken_beliefs(self, beliefs, pending: PendingTick, interpretation) -> List[str]:
        if beliefs is None or not pending.belief_ids:
            return []
        fb_tokens = self._tokens(interpretation.focal_text)
        scored = []
        for bid in pending.belief_ids:
            b = beliefs.get(bid)
            if b is None or not b.is_active:
                continue
            overlap = len(fb_tokens & self._tokens(b.statement))
            scored.append((overlap, bid, b))
        if not scored:
            return []
        scored.sort(key=lambda t: t[0], reverse=True)
        # если конкретный belief назван — бьём по нему; иначе слабо по самому релевантному
        targets = [s for s in scored if s[0] > 0] or scored[:1]
        out = []
        for overlap, bid, b in targets:
            weight = -0.9 if overlap > 0 else -0.4
            before = b.confidence
            b.counter_evidence.append(f"feedback:tick{pending.tick}")
            b.update_confidence(weight, kappa=1.0)
            b.evidence.append({"source": "user_denial", "t": time.time(), "weight": weight,
                               "text": interpretation.focal_text[:160]})
            out.append(f"belief «{b.statement[:60]}»: {before:.2f} → {b.confidence:.2f}")
        return out

    @staticmethod
    def _support_beliefs(beliefs, pending: PendingTick) -> None:
        if beliefs is None:
            return
        for bid in pending.belief_ids[:3]:
            b = beliefs.get(bid)
            if b is not None and b.is_active:
                b.update_confidence(0.15)

    # --------------------------------------------------------------
    def export(self) -> dict:
        return {
            "patterns": self.patterns.export(),
            "action_values": self.action_values.export(),
            "social": self.social.export(),
            "error_by_source": dict(self.error_by_source),
            "count_by_source": dict(self.count_by_source),
        }

    def load(self, data: dict) -> Dict[str, int]:
        data = data or {}
        n_p = self.patterns.load(data.get("patterns", {}))
        n_a = self.action_values.load(data.get("action_values", {}))
        n_s = self.social.load(data.get("social", {}))
        self.error_by_source.update(data.get("error_by_source", {}))
        self.count_by_source.update({k: int(v) for k, v in data.get("count_by_source", {}).items()})
        return {"patterns": n_p, "action_values": n_a, "social_biases": n_s}
