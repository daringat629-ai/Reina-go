"""
Adaptation — offline-дообучение GRU-весов StateTransitionModel (§1.2) на
накопленных логах тиков. НЕ часть real-time цикла: запускается отдельным
скриптом/джобой поверх экспортированных (z_t, u_t, z_{t+1}_target) троек.

Референсная реализация — простой градиентный шаг численным дифференцированием
не даётся здесь намеренно: для реального обучения GRU подключается
стандартный autodiff-фреймворк (torch/jax). Этот файл фиксирует контракт
данных, чтобы независимо реализовать обучение, не трогая state_transition.py.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List
from ..numeric import np


@dataclass
class TransitionExample:
    """Одна обучающая пара, собранная из лога тиков."""

    z_t: np.ndarray
    u_t: np.ndarray
    z_next_observed: np.ndarray  # фактическое z_{t+1}, использованное системой
    # опционально: z_next_target — "что было бы лучше", если есть сигнал
    # качества (напр. низкий prediction_error на следующем шаге считается
    # лучшим таргетом, чем высокий)
    quality_weight: float = 1.0  # выше для тиков с низким prediction_error


class TransitionDataset:
    """Простое накопление примеров из логов для последующего batch-обучения."""

    def __init__(self) -> None:
        self.examples: List[TransitionExample] = []

    def add(self, example: TransitionExample) -> None:
        self.examples.append(example)

    def export_arrays(self):
        z = np.stack([e.z_t for e in self.examples])
        u = np.stack([e.u_t for e in self.examples])
        z_next = np.stack([e.z_next_observed for e in self.examples])
        w = np.array([e.quality_weight for e in self.examples], dtype=np.float32)
        return z, u, z_next, w
