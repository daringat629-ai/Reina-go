"""
Выучиваемые закономерности — то, что превращает историю в обучение.

  InterpretationPatternStore — "в сообщениях такого вида собеседник обычно
      имеет в виду X" (confidence). Меняет распределение intent в следующий раз.
  ActionValueStore — сколько на практике "стоит" действие A в ответ на intent I
      (EMA награды из реакций собеседника). Читается DecisionEngine.
  SocialExpectationStore — систематический сдвиг реакции конкретного человека
      относительно прогноза (он обычно реагирует холоднее/теплее, чем я жду).
      Читается предиктором.

Всё — логит/EMA-обновления, как и остальное ядро (§12): объяснимо, без
градиентов, сериализуемо в JSON.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple


# ================================================================ patterns

@dataclass
class InterpretationPattern:
    signature: str
    intent_weights: Dict[str, float] = field(default_factory=dict)  # подтверждённые значения
    misread_weights: Dict[str, float] = field(default_factory=dict)  # intent, который я ошибочно выбрала
    n: float = 0.0
    t_updated: float = field(default_factory=time.time)

    def best(self) -> Optional[Tuple[str, float]]:
        if not self.intent_weights:
            return None
        intent, w = max(self.intent_weights.items(), key=lambda kv: kv[1])
        total = sum(self.intent_weights.values()) or 1.0
        share = w / total
        # доверие растёт с числом наблюдений: 1 случай ≠ закономерность
        support = self.n / (self.n + 2.0)
        return intent, share * support

    def misread_rate(self, intent: str) -> float:
        bad = self.misread_weights.get(intent, 0.0)
        good = self.intent_weights.get(intent, 0.0)
        return bad / (bad + good + 1.0)

    def describe(self) -> str:
        best = self.best()
        if best is None:
            return f"Паттерн «{self.signature}»: пока без устойчивого значения"
        return (f"В сообщениях вида «{self.signature}» собеседник обычно имеет в виду "
                f"{best[0]} (confidence={best[1]:.2f}, наблюдений={self.n:.0f})")


@dataclass
class AppliedPattern:
    signature: str
    intent: str
    confidence: float
    misread_intent: Optional[str] = None
    misread_rate: float = 0.0

    def describe(self) -> str:
        s = f"паттерн «{self.signature}» → {self.intent} ({self.confidence:.2f})"
        if self.misread_intent:
            s += f"; раньше я ошибочно читала это как {self.misread_intent} ({self.misread_rate:.2f})"
        return s


class InterpretationPatternStore:
    MIN_CONFIDENCE_TO_APPLY = 0.25
    MAX_MIX = 0.7            # паттерн не может полностью заглушить сам текст
    LESSON_THRESHOLD = 0.6   # после этого паттерн считается "уроком" (пишется в память)

    def __init__(self) -> None:
        self.patterns: Dict[str, InterpretationPattern] = {}
        self._lessons_emitted: set = set()

    def _get(self, sig: str) -> InterpretationPattern:
        if sig not in self.patterns:
            self.patterns[sig] = InterpretationPattern(signature=sig)
        return self.patterns[sig]

    def adjust(self, signatures: List[str], dist: List[Tuple[str, float]]):
        """Смешивает распределение intent с выученным. Самая специфичная
        сигнатура (первая) побеждает. Возвращает (new_dist, applied|None)."""
        base = dict(dist)
        for sig in signatures:
            p = self.patterns.get(sig)
            if p is None:
                continue
            best = p.best()
            misread_intent, misread_rate = None, 0.0
            if p.misread_weights:
                misread_intent = max(p.misread_weights, key=p.misread_weights.get)
                misread_rate = p.misread_rate(misread_intent)
            if (best is None or best[1] < self.MIN_CONFIDENCE_TO_APPLY) and misread_rate < 0.3:
                continue
            new = dict(base)
            if best is not None and best[1] >= self.MIN_CONFIDENCE_TO_APPLY:
                lam = min(self.MAX_MIX, best[1])
                new = {k: (1 - lam) * v for k, v in new.items()}
                new[best[0]] = new.get(best[0], 0.0) + lam
            if misread_intent and misread_rate >= 0.3 and misread_intent in new:
                # знаю, что обычно ошибаюсь здесь — понижаю доверие к этому прочтению
                new[misread_intent] *= (1.0 - 0.6 * misread_rate)
            total = sum(new.values()) or 1.0
            out = sorted(((k, v / total) for k, v in new.items()), key=lambda kv: kv[1], reverse=True)
            applied = AppliedPattern(
                signature=sig,
                intent=best[0] if best else out[0][0],
                confidence=best[1] if best else 0.0,
                misread_intent=misread_intent if misread_rate >= 0.3 else None,
                misread_rate=misread_rate,
            )
            return out, applied
        return dist, None

    def reinforce(self, signatures: List[str], intent: str, weight: float = 1.0) -> None:
        for i, sig in enumerate(signatures):
            w = weight * (1.0 if i == 0 else 0.5)  # грубая сигнатура учится медленнее
            p = self._get(sig)
            p.intent_weights[intent] = p.intent_weights.get(intent, 0.0) + w
            p.n += w
            p.t_updated = time.time()

    def learn_correction(self, signatures: List[str], wrong_intent: str, corrected_intent: Optional[str],
                         strength: float = 1.0) -> None:
        for i, sig in enumerate(signatures):
            w = strength * (1.0 if i == 0 else 0.5)
            p = self._get(sig)
            p.misread_weights[wrong_intent] = p.misread_weights.get(wrong_intent, 0.0) + w
            if corrected_intent:
                p.intent_weights[corrected_intent] = p.intent_weights.get(corrected_intent, 0.0) + w
                p.n += w
            p.t_updated = time.time()

    def new_lessons(self) -> List[InterpretationPattern]:
        """Паттерны, которые только что стали достаточно уверенными, чтобы
        считаться уроком (каждый отдаётся один раз)."""
        out = []
        for sig, p in self.patterns.items():
            best = p.best()
            if best and best[1] >= self.LESSON_THRESHOLD and sig not in self._lessons_emitted:
                self._lessons_emitted.add(sig)
                out.append(p)
        return out

    # ---- persistence
    def export(self) -> dict:
        return {
            "patterns": {
                s: {"intent_weights": p.intent_weights, "misread_weights": p.misread_weights,
                    "n": p.n, "t_updated": p.t_updated}
                for s, p in self.patterns.items()
            },
            "lessons_emitted": sorted(self._lessons_emitted),
        }

    def load(self, data: dict) -> int:
        for s, d in (data or {}).get("patterns", {}).items():
            self.patterns[s] = InterpretationPattern(
                signature=s, intent_weights=dict(d.get("intent_weights", {})),
                misread_weights=dict(d.get("misread_weights", {})),
                n=float(d.get("n", 0.0)), t_updated=float(d.get("t_updated", time.time())),
            )
        self._lessons_emitted |= set((data or {}).get("lessons_emitted", []))
        return len(self.patterns)


# ================================================================ action values

@dataclass
class ActionValue:
    value: float = 0.0   # EMA награды, -1..1
    n: int = 0


class ActionValueStore:
    """Q(intent, action) как EMA награды. Скорость падает с числом
    наблюдений (1/n до нижней границы rate_floor) — первые реакции двигают
    сильно, дальше оценка стабилизируется."""

    def __init__(self, rate_floor: float = 0.15):
        self.rate_floor = rate_floor
        self.values: Dict[str, ActionValue] = {}

    @staticmethod
    def _key(intent: str, action: str) -> str:
        return f"{intent}|{action}"

    def get(self, intent: str, action: str) -> ActionValue:
        return self.values.get(self._key(intent, action), ActionValue())

    def update(self, intent: str, action: str, reward: float) -> ActionValue:
        reward = max(-1.0, min(1.0, reward))
        k = self._key(intent, action)
        av = self.values.setdefault(k, ActionValue())
        av.n += 1
        # сильные сигналы (явная жалоба / явная похвала) двигают сильнее, чем
        # фоновое "разговор просто продолжился" — иначе один нейтральный ход
        # стирал бы выученное раздражение
        rate = max(self.rate_floor, 1.0 / av.n) * (0.5 + 0.5 * abs(reward))
        av.value += rate * (reward - av.value)
        return av

    def export(self) -> dict:
        return {k: {"value": v.value, "n": v.n} for k, v in self.values.items()}

    def load(self, data: dict) -> int:
        for k, d in (data or {}).items():
            self.values[k] = ActionValue(value=float(d.get("value", 0.0)), n=int(d.get("n", 0)))
        return len(self.values)


# ================================================================ social expectations

class SocialExpectationStore:
    """Сдвиг реальной валентности реакции человека относительно прогноза."""

    def __init__(self, rate: float = 0.2):
        self.rate = rate
        self.valence_bias: Dict[str, float] = {}
        self.n: Dict[str, int] = {}

    def bias(self, actor_id: str) -> float:
        return self.valence_bias.get(actor_id, 0.0)

    def update(self, actor_id: str, expected: float, actual: float) -> float:
        cur = self.valence_bias.get(actor_id, 0.0)
        cur += self.rate * ((actual - expected) - cur)
        self.valence_bias[actor_id] = max(-1.0, min(1.0, cur))
        self.n[actor_id] = self.n.get(actor_id, 0) + 1
        return self.valence_bias[actor_id]

    def export(self) -> dict:
        return {"valence_bias": dict(self.valence_bias), "n": dict(self.n)}

    def load(self, data: dict) -> int:
        self.valence_bias.update({k: float(v) for k, v in (data or {}).get("valence_bias", {}).items()})
        self.n.update({k: int(v) for k, v in (data or {}).get("n", {}).items()})
        return len(self.valence_bias)
