"""
Predictor — §6 спеки. Перед каждым действием Marin формирует явный прогноз
о его результате; после исхода считается prediction error (prediction_error.py).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class Prediction:
    expected_response_type: str      # ожидаемый тип реакции собеседника/среды
    expected_valence: float          # -1..1
    expected_goal_progress: float    # 0..1, ожидаемый прогресс по активной цели
    confidence: float                # 0..1
    # Допущения, на которых построен прогноз — нужны, чтобы при ошибке
    # понять, ЧТО именно было неверным (intent / belief / social / goal / action).
    assumptions: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Outcome:
    actual_type: str
    actual_valence: float
    actual_goal_progress: float


class Predictor:
    """Точка расширения: конкретная реализация может дергать reasoning engine
    (fast/deep) или отдельную легковесную модель. Здесь — интерфейс + простая
    эвристическая реализация по умолчанию для холодного старта без обучения."""

    def predict(self, situation, z, action_candidate, world_model=None, beliefs=None) -> Prediction:
        raise NotImplementedError


class HeuristicPredictor(Predictor):
    """Референсная реализация без ML: использует affect-компоненту z и
    historial base rate из beliefs, если он есть. Годится как заглушка
    для первого запуска цикла (§18 п.5)."""

    def predict(self, situation, z, action_candidate, world_model=None, beliefs=None) -> Prediction:
        affect = z.component("affect")
        expected_valence = float(affect.mean())
        return Prediction(
            expected_response_type="neutral_reply",
            expected_valence=max(-1.0, min(1.0, expected_valence)),
            expected_goal_progress=0.3,
            confidence=0.4,
        )


# Словарь типов реакции, общий для прогноза и реального исхода
# (см. learning/feedback_learning.py: outcome_from_feedback).
RESPONSE_TYPES = ("positive_reply", "neutral_reply", "negative_reply", "correction", "clarification_answer")


class LearnedPredictor(HeuristicPredictor):
    """Прогноз, который опирается на то, что система уже выучила:

      * relationship EMA (как этот человек обычно реагирует),
      * SocialExpectationStore — систематическая поправка к моим ожиданиям
        по этому человеку (я его переоцениваю/недооцениваю),
      * ActionValueStore — как на практике заходило это действие на этот intent,
      * тон и уверенность интерпретации,
      * belief'ы, использованные в ответе (низкая confidence -> риск поправки).

    Все допущения записываются в Prediction.assumptions — по ним потом
    атрибутируется ошибка прогноза.
    """

    def __init__(self, action_values=None, social_expectations=None):
        self.action_values = action_values
        self.social_expectations = social_expectations

    def predict_for(
        self,
        situation,
        z,
        action_type: str,
        interpretation=None,
        relationship=None,
        actor_id: Optional[str] = None,
        beliefs_used: Optional[List[Any]] = None,
    ) -> Prediction:
        base = super().predict(situation, z, action_type)
        intent = getattr(interpretation, "intent", None) or "statement"
        interp_conf = interpretation.confidence if interpretation is not None else 0.5
        tone_val = getattr(interpretation, "valence", 0.0) if interpretation is not None else 0.0

        rel_val = getattr(relationship, "history_valence_ema", 0.0) if relationship is not None else 0.0
        social_bias = self.social_expectations.bias(actor_id) if (self.social_expectations and actor_id) else 0.0

        av = self.action_values.get(intent, action_type) if self.action_values is not None else None
        learned_val = av.value if (av is not None and av.n > 0) else None
        n_obs = av.n if av is not None else 0

        parts = [(0.35, rel_val), (0.25, tone_val), (0.1, base.expected_valence)]
        if learned_val is not None:
            parts.append((0.3, learned_val))
        wsum = sum(w for w, _ in parts)
        expected_valence = sum(w * v for w, v in parts) / wsum + social_bias
        expected_valence = max(-1.0, min(1.0, expected_valence))

        # риск поправки: неуверенная интерпретация или слабые belief'ы в ответе
        weak_beliefs = [b for b in (beliefs_used or []) if getattr(b, "confidence", 1.0) < 0.5]
        correction_risk = (1.0 - interp_conf) * 0.8 + 0.1 * len(weak_beliefs)
        if action_type in ("ask", "clarify") and intent != "question":
            expected_type = "clarification_answer"
        elif correction_risk > 0.55:
            expected_type = "correction"
        elif expected_valence > 0.2:
            expected_type = "positive_reply"
        elif expected_valence < -0.2:
            expected_type = "negative_reply"
        else:
            expected_type = "neutral_reply"

        expected_progress = 0.3
        if action_type in ("answer", "act"):
            expected_progress = 0.35 + 0.4 * interp_conf
        elif action_type in ("clarify", "ask"):
            expected_progress = 0.15
        elif action_type in ("ignore", "observe", "defer"):
            expected_progress = 0.0
        if learned_val is not None:
            expected_progress = max(0.0, min(1.0, expected_progress + 0.2 * learned_val))

        confidence = max(0.05, min(0.95, 0.25 + 0.35 * interp_conf + 0.3 * (n_obs / (n_obs + 3.0))))

        return Prediction(
            expected_response_type=expected_type,
            expected_valence=expected_valence,
            expected_goal_progress=expected_progress,
            confidence=confidence,
            assumptions={
                "intent": intent,
                "intent_confidence": round(interp_conf, 3),
                "action": action_type,
                "relationship_valence": round(rel_val, 3),
                "social_bias": round(social_bias, 3),
                "learned_action_value": None if learned_val is None else round(learned_val, 3),
                "belief_keys": [getattr(b, "key", None) or getattr(b, "statement", "")[:60] for b in (beliefs_used or [])],
                "correction_risk": round(correction_risk, 3),
            },
        )
