"""
Prediction error — §6 спеки, вторая половина формулы (после Outcome).
eps_t идёт: (1) в z_{t+1} через StateTransitionModel, (2) в Learning Engine,
(3) в importance создаваемого memory-узла.
"""

from __future__ import annotations

from dataclasses import dataclass

from .predictor import Prediction, Outcome


@dataclass
class PredictionErrorWeights:
    w_e1: float = 0.4  # response type mismatch
    w_e2: float = 0.35  # valence mismatch
    w_e3: float = 0.25  # goal progress mismatch


def _type_mismatch(expected: str, actual: str) -> float:
    """1 - sim(...). Без эмбеддингов типов — грубая версия: точное совпадение
    строки или нет. Заменяется на sim() эмбеддингов, если типы становятся
    богаче простого enum."""
    return 0.0 if expected == actual else 1.0


def compute_prediction_error(prediction: Prediction, outcome: Outcome, weights: PredictionErrorWeights = PredictionErrorWeights()) -> float:
    """§6: eps_t = w_e1*(1-sim(type)) + w_e2*|dvalence| + w_e3*|dgoal|."""
    return (
        weights.w_e1 * _type_mismatch(prediction.expected_response_type, outcome.actual_type)
        + weights.w_e2 * abs(prediction.expected_valence - outcome.actual_valence)
        + weights.w_e3 * abs(prediction.expected_goal_progress - outcome.actual_goal_progress)
    )
