"""
Hypothesis Engine — §8 спеки. Явное распределение над интерпретациями
неоднозначной ситуации, обновляемое soft-EM-подобным шагом, вместо одного
угадывания. Решающее правило вынесено в decision/action_selection.py.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, List, Tuple


@dataclass
class Hypothesis:
    id: str
    description: str


class HypothesisSet:
    """Hypotheses = [(h_1, p_1), ..., (h_n, p_n)], sum p_i = 1, §8."""

    def __init__(self, hypotheses: List[Hypothesis], initial_probs: List[float] | None = None):
        self.hypotheses = hypotheses
        n = len(hypotheses)
        if initial_probs is None:
            initial_probs = [1.0 / n] * n if n else []
        total = sum(initial_probs) or 1.0
        self.probs: Dict[str, float] = {h.id: p / total for h, p in zip(hypotheses, initial_probs)}

    def items(self) -> List[Tuple[Hypothesis, float]]:
        return [(h, self.probs[h.id]) for h in self.hypotheses]

    def update(self, likelihood_fn: Callable[[Hypothesis], float]) -> None:
        """§8: p_i^{t+1} propto p_i^t * likelihood(evidence_t | h_i)."""
        unnormalized = {h.id: self.probs[h.id] * likelihood_fn(h) for h in self.hypotheses}
        total = sum(unnormalized.values()) or 1.0
        self.probs = {hid: p / total for hid, p in unnormalized.items()}

    def most_likely(self) -> Tuple[Hypothesis, float] | None:
        if not self.hypotheses:
            return None
        best = max(self.hypotheses, key=lambda h: self.probs[h.id])
        return best, self.probs[best.id]
