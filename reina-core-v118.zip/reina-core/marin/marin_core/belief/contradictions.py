"""
Contradictions — вспомогательные функции для §7.2: определение, является ли
новое наблюдение семантическим противоречием существующему belief.

Реальная проверка требует NLI-классификатора (не просто косинусную
близость < -theta, см. предупреждение в спеке); здесь — интерфейс + грубая
эвристика на эмбеддингах для холодного старта.
"""

from __future__ import annotations

from typing import Optional, Protocol
from ..numeric import np


class NLIClassifier(Protocol):
    def contradicts(self, statement_a: str, statement_b: str) -> bool: ...


def _cos_sim(a: np.ndarray, b: np.ndarray) -> float:
    an, bn = np.linalg.norm(a), np.linalg.norm(b)
    if an == 0 or bn == 0:
        return 0.0
    return float(np.dot(a, b) / (an * bn))


class HeuristicContradictionDetector:
    """Заглушка без NLI: считает противоречием сильную отрицательную
    косинусную близость эмбеддингов. Заменить на реальный NLI-классификатор
    до продакшена — эвристика даёт много ложноотрицательных срабатываний."""

    def __init__(self, theta: float = -0.2):
        self.theta = theta

    def is_contradiction(self, embedding_a: np.ndarray, embedding_b: np.ndarray) -> bool:
        return _cos_sim(embedding_a, embedding_b) < self.theta
