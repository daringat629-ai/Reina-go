"""
Belief System — §7 спеки. FACT/MEMORY/BELIEF/HYPOTHESIS/PREDICTION — разные
сущности. Confidence обновляется логит-EMA (§7.1), не перезаписывается напрямую.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Tuple
import time
import math
from ..numeric import np


class SourceType(str, Enum):
    DIRECT_OBSERVATION = "direct_observation"
    INFERENCE = "inference"
    TOLD_BY_USER = "told_by_user"
    LLM_GENERATED = "llm_generated"  # догадка/сочинение модели — никогда не факт, пока не подтверждено явно


# Пока belief не подтверждён явно (см. BeliefStore.confirm), LLM_GENERATED
# не может набрать высокую confidence сам по себе — иначе сочинённая догадка
# со временем накопит "evidence" и станет неотличима от проверенного факта.
MAX_CONFIDENCE_UNCONFIRMED_LLM = 0.5


def _logit(p: float) -> float:
    p = min(max(p, 1e-6), 1 - 1e-6)
    return math.log(p / (1 - p))


def _sigmoid(x: float) -> float:
    return 1.0 / (1.0 + math.exp(-x))


@dataclass
class Belief:
    statement: str
    embedding: np.ndarray
    confidence: float = 0.5
    support: List[str] = field(default_factory=list)          # MemoryNode ids
    counter_evidence: List[str] = field(default_factory=list)  # MemoryNode ids
    t_last_updated: float = field(default_factory=time.time)
    source_type: SourceType = SourceType.INFERENCE
    confirmed: bool = False  # True только после явного подтверждения владельцем/наблюдением
    # --- belief revision (InterpretationEngine -> BeliefStore.revise) ---
    key: Optional[str] = None            # стабильный ключ факта ("person:<actor>:likes:кофе")
    subject: Optional[str] = None        # о ком belief (actor_id), None = о мире/себе
    polarity: int = 1                    # +1 утверждение, -1 отрицание
    status: str = "active"               # active | superseded | retracted
    created_at: float = field(default_factory=time.time)
    evidence: List[dict] = field(default_factory=list)  # [{source, text, t, weight, memory_id, tick}]

    @property
    def source(self) -> str:
        return {"told_by_user": "user_statement"}.get(self.source_type.value, self.source_type.value)

    @property
    def is_active(self) -> bool:
        return self.status == "active"

    def __post_init__(self) -> None:
        self._clamp_if_unconfirmed_llm()

    def _clamp_if_unconfirmed_llm(self) -> None:
        if self.source_type == SourceType.LLM_GENERATED and not self.confirmed:
            self.confidence = min(self.confidence, MAX_CONFIDENCE_UNCONFIRMED_LLM)

    def update_confidence(self, evidence_weight: float, kappa: float = 0.5) -> None:
        """§7.1: logit(confidence_{t+1}) = logit(confidence_t) + kappa * evidence_weight."""
        new_logit = _logit(self.confidence) + kappa * evidence_weight
        self.confidence = _sigmoid(new_logit)
        self._clamp_if_unconfirmed_llm()
        self.t_last_updated = time.time()


@dataclass
class ContradictionFlag:
    belief_id: str
    conflicting_observation_id: str
    t_flagged: float = field(default_factory=time.time)
    resolved: bool = False
    key: Optional[str] = None
    old_statement: str = ""
    new_statement: str = ""
    resolution: str = ""


@dataclass
class BeliefRevision:
    """Результат BeliefStore.revise — что именно произошло с убеждением."""

    kind: str                   # created | reinforced | contradicted | updated
    belief_id: str
    key: str
    statement: str
    confidence: float
    previous_id: Optional[str] = None
    previous_statement: Optional[str] = None
    contradiction: Optional["ContradictionFlag"] = None

    def describe(self) -> str:
        if self.kind == "contradicted":
            return (f"противоречие: раньше «{self.previous_statement}», теперь «{self.statement}» "
                    f"(новое confidence={self.confidence:.2f})")
        if self.kind == "updated":
            return f"обновлено: «{self.previous_statement}» → «{self.statement}»"
        if self.kind == "reinforced":
            return f"подтверждено: «{self.statement}» (confidence={self.confidence:.2f})"
        return f"новое убеждение: «{self.statement}» (confidence={self.confidence:.2f})"


class BeliefStore:
    def __init__(self) -> None:
        self._beliefs: Dict[str, Belief] = {}
        self._id_counter = 0
        self.contradictions: List[ContradictionFlag] = []

    def add(self, belief: Belief) -> str:
        belief._clamp_if_unconfirmed_llm()
        self._id_counter += 1
        belief_id = f"belief_{self._id_counter}"
        self._beliefs[belief_id] = belief
        return belief_id

    def upsert(self, key: str, belief: Belief) -> str:
        """Как add(), но со стабильным ключом: повторный upsert с тем же
        key заменяет старую запись вместо того, чтобы плодить дубликаты.
        Нужно для фактов, которые обновляются периодически (напр. счётчики
        диалогов/каталога Telegram) — иначе BeliefStore рос бы бесконечно
        при каждом refresh."""
        belief._clamp_if_unconfirmed_llm()
        belief_id = f"fact:{key}"
        self._beliefs[belief_id] = belief
        return belief_id

    def upsert_with_conflict(self, key: str, belief: Belief) -> tuple:
        """Как upsert(), но если под этим key уже лежит belief с другим
        statement — это не тихая перезапись, а обнаруженное противоречие
        (§7.2, "человек сказал одно, потом другое"). Старая версия
        архивируется отдельно (с понижённой confidence и флагом
        ContradictionFlag) для аудита/self-reflection, а сам key всегда
        указывает на АКТУАЛЬНОЕ значение — иначе повторные вызовы с тем
        же новым statement заново триггерили бы конфликт против устаревшей
        версии до бесконечности. Возвращает (belief_id, был ли конфликт)."""
        belief_id = f"fact:{key}"
        existing = self._beliefs.get(belief_id)
        if existing is not None and existing.statement.strip().lower() != belief.statement.strip().lower():
            self._id_counter += 1
            archived_id = f"fact_archived_{self._id_counter}:{key}"
            existing.status = "superseded"
            self._beliefs[archived_id] = existing
            n_before = len(self.contradictions)
            self.apply_evidence(archived_id, evidence_source_id=belief_id, evidence_weight=-0.6, is_contradiction=True)
            if len(self.contradictions) == n_before:
                # apply_evidence не завела флаг сама (архивная belief не была
                # high-confidence) — всё равно фиксируем сам факт конфликта.
                self.contradictions.append(ContradictionFlag(belief_id=archived_id, conflicting_observation_id=belief_id))
            self._beliefs[belief_id] = belief
            return belief_id, True
        self._beliefs[belief_id] = belief
        return belief_id, False

    def confirm(self, belief_id: str, new_source_type: SourceType = SourceType.TOLD_BY_USER) -> None:
        """Единственный способ превратить LLM-догадку в подтверждённый факт —
        явный вызов (напр. владелец подтвердил её вслух), никогда автоматически
        через накопление confidence. Меняет source_type и снимает клэмп."""
        belief = self._beliefs.get(belief_id)
        if belief is None:
            return
        belief.source_type = new_source_type
        belief.confirmed = True

    def top_k_relevant(self, query_embedding, k: int = 5) -> List[Belief]:
        """Топ-k убеждений, релевантных текущей ситуации, по косинусной
        близости эмбеддингов — та же идея, что в memory/retrieval.py, но
        для belief'ов, а не memory-узлов."""
        def _cos_sim(a, b) -> float:
            an = math.sqrt(sum(x * x for x in a))
            bn = math.sqrt(sum(x * x for x in b))
            if an == 0 or bn == 0:
                return 0.0
            return sum(x * y for x, y in zip(a, b)) / (an * bn)

        scored = [(_cos_sim(query_embedding, b.embedding), b) for b in self._beliefs.values() if b.is_active]
        scored.sort(key=lambda pair: pair[0], reverse=True)
        return [b for _, b in scored[:k]]

    def get(self, belief_id: str) -> Optional[Belief]:
        return self._beliefs.get(belief_id)

    def all(self) -> List[Belief]:
        return list(self._beliefs.values())

    def apply_evidence(
        self,
        belief_id: str,
        evidence_source_id: str,
        evidence_weight: float,
        is_contradiction: bool = False,
        theta_high: float = 0.75,
    ) -> None:
        """§7.1 + §7.2. Если belief уже высокоуверенный и приходит сильное
        противоречащее свидетельство — НЕ переписываем confidence молча,
        а заводим открытый конфликт."""
        belief = self._beliefs.get(belief_id)
        if belief is None:
            return

        if is_contradiction and belief.confidence > theta_high and abs(evidence_weight) > 0.5:
            belief.counter_evidence.append(evidence_source_id)
            self.contradictions.append(
                ContradictionFlag(belief_id=belief_id, conflicting_observation_id=evidence_source_id)
            )
            return

        if is_contradiction:
            belief.counter_evidence.append(evidence_source_id)
            belief.update_confidence(-abs(evidence_weight))
        else:
            belief.support.append(evidence_source_id)
            belief.update_confidence(abs(evidence_weight))

    def open_contradictions(self) -> List[ContradictionFlag]:
        return [c for c in self.contradictions if not c.resolved]

    # ------------------------------------------------------------------
    # Belief revision: Interpretation -> Belief update (не тупая перезапись)
    # ------------------------------------------------------------------

    def items(self):
        return list(self._beliefs.items())

    def find_by_key(self, key: str) -> Optional[Tuple[str, Belief]]:
        belief_id = f"fact:{key}"
        b = self._beliefs.get(belief_id)
        if b is not None and b.is_active:
            return belief_id, b
        return None

    def about(self, subject: str, active_only: bool = True) -> List[Tuple[str, Belief]]:
        return [(bid, b) for bid, b in self._beliefs.items()
                if b.subject == subject and (b.is_active or not active_only)]

    def revise(
        self,
        key: str,
        statement: str,
        embedding,
        *,
        polarity: int = 1,
        confidence: float = 0.75,
        source_type: SourceType = SourceType.TOLD_BY_USER,
        subject: Optional[str] = None,
        evidence: Optional[dict] = None,
        single_valued: bool = False,
        confirmed: bool = False,
    ) -> BeliefRevision:
        """Обновление убеждения новым свидетельством.

        * такого ключа нет            -> created
        * то же утверждение           -> reinforced (logit-шаг вверх + evidence),
                                         заодно закрывает открытые противоречия
                                         по этому ключу: человек повторил новое.
        * противоположная полярность  -> contradicted: старое НЕ стирается —
          или новое значение             архивируется как superseded с
                                         пониженной confidence и
                                         counter_evidence, новое получает
                                         confidence с дисконтом за конфликт,
                                         заводится ContradictionFlag со
                                         старым и новым утверждением.
        * новое значение single-valued -> updated (имя/город поменялись —
          факта при низкой старой        тоже фиксируется, но без "тревоги")
          уверенности
        """
        ev = dict(evidence or {})
        ev.setdefault("t", time.time())
        ev.setdefault("source", "user_statement" if source_type == SourceType.TOLD_BY_USER else source_type.value)
        belief_id = f"fact:{key}"
        existing = self._beliefs.get(belief_id)

        if existing is None or not existing.is_active:
            b = Belief(statement=statement, embedding=embedding, confidence=confidence, source_type=source_type,
                       key=key, subject=subject, polarity=polarity, evidence=[ev], confirmed=confirmed)
            self._beliefs[belief_id] = b
            return BeliefRevision("created", belief_id, key, statement, b.confidence)

        same = (existing.polarity == polarity
                and existing.statement.strip().lower() == statement.strip().lower())
        if same:
            existing.evidence.append(ev)
            existing.support.append(str(ev.get("memory_id") or ev.get("tick") or "evidence"))
            existing.update_confidence(1.0)
            if confirmed:
                existing.confirmed = True
            for c in self.contradictions:
                if not c.resolved and c.key == key:
                    c.resolved = True
                    c.resolution = "new statement re-confirmed by the same source"
            return BeliefRevision("reinforced", belief_id, key, statement, existing.confidence)

        # конфликт: архивируем старое, не удаляя
        self._id_counter += 1
        archived_id = f"fact_archived_{self._id_counter}:{key}"
        prev_conf = existing.confidence
        existing.status = "superseded"
        existing.counter_evidence.append(belief_id)
        existing.update_confidence(-1.2)
        self._beliefs[archived_id] = existing

        surprising = prev_conf > 0.6 and (existing.polarity != polarity or not single_valued)
        new_conf = confidence * (0.85 if surprising else 1.0)
        b = Belief(statement=statement, embedding=embedding, confidence=new_conf, source_type=source_type,
                   key=key, subject=subject, polarity=polarity, confirmed=confirmed,
                   evidence=[dict(ev, contradicts=archived_id)])
        b.counter_evidence.append(archived_id)
        self._beliefs[belief_id] = b

        flag = ContradictionFlag(
            belief_id=archived_id, conflicting_observation_id=belief_id, key=key,
            old_statement=existing.statement, new_statement=statement,
            resolved=not surprising,
            resolution="" if surprising else "value updated (low prior confidence)",
        )
        self.contradictions.append(flag)
        kind = "contradicted" if surprising else "updated"
        return BeliefRevision(kind, belief_id, key, statement, b.confidence,
                              previous_id=archived_id, previous_statement=existing.statement, contradiction=flag)

    def retract(self, belief_id: str, reason: str = "forget_request") -> bool:
        b = self._beliefs.get(belief_id)
        if b is None or b.status == "retracted":
            return False
        b.status = "retracted"
        b.evidence.append({"source": reason, "t": time.time(), "weight": -1.0})
        for c in self.contradictions:
            if not c.resolved and (c.belief_id == belief_id or c.conflicting_observation_id == belief_id):
                c.resolved = True
                c.resolution = f"retracted ({reason})"
        return True

    def resolve_contradiction(self, flag: ContradictionFlag, resolution: str) -> None:
        flag.resolved = True
        flag.resolution = resolution
