"""
State Transition Model — реализация §1.2 (обновление) и §1.3 (idle decay).

z_{t+1} = f_theta(z_t, e(x_t), e(S_t), e(retrieval_t), g(G_t), eps_t)

f_theta реализован как GRU-ячейка над конкатенацией эмбеддингов входа.
Веса (W_r, W_u, W_h) — обучаемые offline на логах (см. §12 Learning Engine),
здесь даётся инициализация + forward pass. Обучение — отдельный скрипт
в learning/, не часть real-time цикла.
"""

from __future__ import annotations

from dataclasses import dataclass
from ..numeric import np

from .latent_state import LatentState, TOTAL_DIM

EMBED_DIM = TOTAL_DIM  # общее пространство эмбеддингов = размерность z, см. §1.2


def _sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-x))


@dataclass
class TransitionWeights:
    """W_r, W_u, W_h из §1.2. input_dim = z_dim + u_dim, где u_dim — сумма
    эмбеддингов observation/situation/retrieval/goals/prediction_error."""

    W_r: np.ndarray
    W_u: np.ndarray
    W_h: np.ndarray
    b_r: np.ndarray
    b_u: np.ndarray
    b_h: np.ndarray

    @classmethod
    def random_init(cls, z_dim: int, u_dim: int, seed: int = 0) -> "TransitionWeights":
        rng = np.random.default_rng(seed)
        in_dim = z_dim + u_dim
        scale = 1.0 / np.sqrt(in_dim)
        return cls(
            W_r=rng.normal(0, scale, size=(z_dim, in_dim)).astype(np.float32),
            W_u=rng.normal(0, scale, size=(z_dim, in_dim)).astype(np.float32),
            W_h=rng.normal(0, scale, size=(z_dim, in_dim)).astype(np.float32),
            b_r=np.zeros(z_dim, dtype=np.float32),
            b_u=np.zeros(z_dim, dtype=np.float32),
            b_h=np.zeros(z_dim, dtype=np.float32),
        )


class StateTransitionModel:
    """f_theta из §1.2."""

    def __init__(self, u_dim: int, weights: TransitionWeights | None = None, seed: int = 0):
        self.z_dim = TOTAL_DIM
        self.u_dim = u_dim
        self.weights = weights or TransitionWeights.random_init(self.z_dim, u_dim, seed=seed)

    def step(self, z: LatentState, u_t: np.ndarray) -> LatentState:
        """Один шаг GRU-обновления. u_t — конкатенация e(x_t), e(S_t),
        e(retrieval_t), g(G_t), eps_t, уже приведённая к self.u_dim."""
        if u_t.shape != (self.u_dim,):
            raise ValueError(f"u_t must have shape ({self.u_dim},), got {u_t.shape}")

        zv = z.vector
        zu = np.concatenate([zv, u_t])
        w = self.weights

        r = _sigmoid(w.W_r @ zu + w.b_r)
        u_gate = _sigmoid(w.W_u @ zu + w.b_u)
        z_reset_concat = np.concatenate([r * zv, u_t])
        z_tilde = np.tanh(w.W_h @ z_reset_concat + w.b_h)

        z_next = (1 - u_gate) * zv + u_gate * z_tilde
        return LatentState(vector=z_next.astype(np.float32), tick=z.tick + 1)

    @staticmethod
    def idle_decay(z: LatentState, z_baseline: LatentState, delta_real_seconds: float, tau_decay_seconds: float) -> LatentState:
        """§1.3: z_t = z_baseline + (z_t - z_baseline) * exp(-Δreal / tau)."""
        factor = float(np.exp(-delta_real_seconds / max(tau_decay_seconds, 1e-6)))
        decayed = z_baseline.vector + (z.vector - z_baseline.vector) * factor
        return LatentState(vector=decayed.astype(np.float32), tick=z.tick)
