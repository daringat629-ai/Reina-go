"""
CognitiveState — НЕ старый GlobalState. Это контейнер, объединяющий
латентное состояние (z_t) с читаемыми/структурированными подсистемами,
которые z_t модулирует и которые модулируют z_t (см. схему цикла в §16).

Сам CognitiveState не содержит бизнес-логики обновления — она лежит
в соответствующих модулях (identity/, goals/, belief/, ...). Здесь —
только сборка ссылок на текущее состояние всех подсистем для одного тика.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Optional

from .latent_state import LatentState

if TYPE_CHECKING:
    from ..identity.identity_model import IdentityModel
    from ..identity.personality_dynamics import PersonalityDynamics
    from ..goals.goals import GoalSet
    from ..goals.needs import NeedState
    from ..perception.situation import SituationModel
    from ..belief.beliefs import BeliefStore


@dataclass
class CognitiveLoad:
    """§15. Бюджет на тик — ограничивает глубину reasoning и K в retrieval."""

    base_load: float = 0.1
    active_hypotheses_weight: float = 0.0
    open_contradictions_weight: float = 0.0
    deep_reasoning_engaged: bool = False
    deep_cost: float = 0.4
    budget_max: float = 1.0

    @property
    def total(self) -> float:
        return (
            self.base_load
            + self.active_hypotheses_weight
            + self.open_contradictions_weight
            + (self.deep_cost if self.deep_reasoning_engaged else 0.0)
        )

    @property
    def over_budget(self) -> bool:
        return self.total > self.budget_max


@dataclass
class CognitiveState:
    """Снимок состояния субъекта на текущий тик."""

    tick: int
    z: LatentState

    identity: Optional["IdentityModel"] = None
    personality: Optional["PersonalityDynamics"] = None
    goals: Optional["GoalSet"] = None
    needs: Optional["NeedState"] = None
    beliefs: Optional["BeliefStore"] = None
    situation: Optional["SituationModel"] = None

    working_memory: list = field(default_factory=list)  # top-K MemoryNode на этот тик
    predictions: list = field(default_factory=list)      # активные Prediction'ы
    cognitive_load: CognitiveLoad = field(default_factory=CognitiveLoad)

    def advance(self, new_z: LatentState) -> "CognitiveState":
        """Возвращает новый CognitiveState для следующего тика с обновлённым z.
        Остальные подсистемы обновляются своими модулями и присваиваются
        вызывающим кодом (engine/cycle.py) — CognitiveState сам не решает,
        что и как менять, он только переносит ссылки."""
        return CognitiveState(
            tick=self.tick + 1,
            z=new_z,
            identity=self.identity,
            personality=self.personality,
            goals=self.goals,
            needs=self.needs,
            beliefs=self.beliefs,
            situation=None,  # ситуация пересобирается заново каждый тик, §2
            working_memory=[],
            predictions=[],
            cognitive_load=CognitiveLoad(),
        )
