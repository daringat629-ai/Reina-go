"""
LatentState — непрерывное скрытое состояние z_t.

Спека: MARIN_X_CORE_SPEC.md §1.

z_t НЕ хранит ручные enum-настроения (mood="happy"). Это вектор,
из которого читаемые проекции (affect, attention_focus, ...) вычисляются
линейными "адаптерами". Источник истины — сам вектор.

Обновление — GRU-подобная ячейка (§1.2), не прямое присваивание полей.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from ..numeric import np

# Размерности компонент (см. §1.1). Сумма — полная размерность z_t.
COMPONENT_DIMS = {
    "affect": 16,
    "attention": 16,
    "goal_tension": 16,
    "uncertainty": 16,
    "social": 16,
    "novelty": 16,
    "residual": 32,
}
TOTAL_DIM = sum(COMPONENT_DIMS.values())  # 128


def _slice_for(component: str) -> slice:
    start = 0
    for name, dim in COMPONENT_DIMS.items():
        if name == component:
            return slice(start, start + dim)
        start += dim
    raise KeyError(component)


@dataclass
class LatentState:
    """Вектор z_t плюс метаданные о его происхождении."""

    vector: np.ndarray = field(default_factory=lambda: np.zeros(TOTAL_DIM, dtype=np.float32))
    tick: int = 0

    def __post_init__(self) -> None:
        if self.vector.shape != (TOTAL_DIM,):
            raise ValueError(f"LatentState.vector must have shape ({TOTAL_DIM},), got {self.vector.shape}")

    # ---- читаемые проекции (для отладки/логов, НЕ источник истины) ----

    def component(self, name: str) -> np.ndarray:
        return self.vector[_slice_for(name)]

    def norm(self) -> float:
        return float(np.linalg.norm(self.vector))

    def copy(self) -> "LatentState":
        return LatentState(vector=self.vector.copy(), tick=self.tick)

    @classmethod
    def zeros(cls) -> "LatentState":
        return cls(vector=np.zeros(TOTAL_DIM, dtype=np.float32))

    @classmethod
    def baseline_for(cls, personality: "PersonalityDynamics | None" = None) -> "LatentState":
        """z_baseline — состояние покоя, см. §1.3. Пока нейтральный нуль;
        по мере обучения Personality здесь должен читаться её prior."""
        return cls.zeros()
