import os
import tempfile

from marin_core import CognitiveEngine
from marin_core.llm.providers import CallableProvider
from marin_core.engine.scheduler import ConsolidationScheduler, SchedulerConfig


def diary_voice_provider(planning_input) -> str:
    if planning_input.chosen_action_type.value == "remember":
        return "Сегодня было спокойно. Хочется спать."
    return "обычный ответ в чате"


def main():
    tmp_dir = tempfile.mkdtemp()
    diary_path = os.path.join(tmp_dir, "diary.json")

    engine = CognitiveEngine(llm_provider=CallableProvider(diary_voice_provider), diary_path=diary_path)

    # прогоняем несколько обычных тиков, чтобы было что рефлексировать
    for msg in ["привет", "как дела?", "что делаешь"]:
        engine.tick(msg, channel_id="c", source_actor_id="u1")

    assert len(engine.diary) == 0, "дневник не должен писаться сам по себе без явного вызова"

    # 1) запись по периоду
    entry = engine.diary_writer.write_entry(since_ts=0.0, period_label="тестовый период")
    assert entry is not None
    assert "спокойно" in entry.text
    assert entry.n_events == 3
    print("write_entry OK:", entry.text)

    # 2) live thought всегда что-то возвращает
    thought = engine.diary_writer.write_live_thought(limit=5)
    assert thought.period_label == "прямо сейчас"
    print("write_live_thought OK:", thought.text)

    assert len(engine.diary) == 2

    # 3) персистентность — пересоздаём store из того же файла
    from marin_core.memory.diary import DiaryStore

    reloaded = DiaryStore(path=diary_path)
    assert len(reloaded) == 2, f"ожидали 2 записи из файла, получили {len(reloaded)}"
    print("persistence OK: записи пережили пересоздание DiaryStore из файла")

    # 4) ConsolidationScheduler пишет дневник сам при "простое"
    engine2 = CognitiveEngine(llm_provider=CallableProvider(diary_voice_provider))
    engine2.tick("привет", channel_id="c", source_actor_id="u1")
    scheduler = ConsolidationScheduler(
        engine2,
        SchedulerConfig(idle_threshold_seconds=0.0, min_interval_between_runs_seconds=0.0, write_diary=True),
    )
    import time

    report = scheduler.maybe_run(now=time.time() + 1)
    assert report is not None
    assert len(engine2.diary) == 1, "ConsolidationScheduler должен был написать дневниковую запись"
    print("scheduler auto-diary OK:", engine2.diary.recent(1)[0].text)

    print("\nOK: дневник работает — запись по периоду, live thought, персистентность, авто-запись на простое.")


if __name__ == "__main__":
    main()
