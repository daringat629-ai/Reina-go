#!/bin/sh
# Запуск Марин. Первый раз: ./start.sh в терминале, ввести код из Telegram для номера Марин.
cd "$(dirname "$0")" || exit 1
[ -f .env ] || { echo "Нет файла .env. Если Рейна уже работает: python3 import_reina.py /путь/к/config.toml --phone +996... Иначе скопируй .env.example в .env и заполни"; exit 1; }
[ -d .venv ] || python3 -m venv .venv || exit 1
. .venv/bin/activate
pip install -q -r requirements.txt || exit 1
mkdir -p data
exec python run_telegram.py
