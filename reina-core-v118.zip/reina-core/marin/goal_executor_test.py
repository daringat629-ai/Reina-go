"""
Integration test for Stage 4 (autonomous goal execution) — NOT a real
Telegram session, no credentials used anywhere. Exercises:

  create autonomous goal -> plan (fake LLM) -> WRITE step drafted ->
  owner confirms via the real ActionRegistry -> result verified and
  channel_id captured into goal.context -> READ step auto-runs -> next
  WRITE step drafted with the captured channel_id substituted into its
  payload -> confirmed -> cycle completes and reschedules -> goal state
  is persisted -> reloaded into a fresh GoalSet -> a fresh executor tick
  on the reloaded goal does NOT recreate the channel (idempotency).

marin_core.telegram.goal_executor has zero real dependency on Telethon
(the only reference to MarinTelegramClient is inside `if TYPE_CHECKING`),
but marin_core/telegram/__init__.py eagerly imports client.py, which does
need the `telethon` package — not installed in this sandbox. So this test
loads goal_executor.py directly via importlib, registering a minimal fake
`marin_core.telegram` package entry in sys.modules first, instead of doing
`import marin_core.telegram.goal_executor` (which would trigger the real
package __init__ and fail on the missing telethon import). In a real
deployment (telethon installed, per requirements.txt) a normal
`from marin_core.telegram.goal_executor import AutonomousGoalExecutor`
works directly — this workaround exists only for this offline test run.
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
import types
import importlib.util

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "tests"))
import telethon_stub  # noqa: E402 — офлайн-заглушка, если настоящего Telethon нет
telethon_stub.install()

import marin_core
from marin_core import CognitiveEngine
from marin_core.llm.providers import CallableProvider
from marin_core.persistence import export_goals, import_goals
from marin_core.goals.goals import GoalSet, GoalStatus


def _register_fake_telegram_package() -> None:
    """marin_core/telegram/__init__.py eagerly imports client.py, which
    needs `telethon` (not installed in this sandbox) — but neither
    actions.py nor goal_executor.py actually need Telethon at runtime.
    Register a package stub in sys.modules first so `import
    marin_core.telegram.actions` / `...goal_executor` resolve their
    submodules normally without ever running the real __init__.py."""
    pkg_name = "marin_core.telegram"
    if pkg_name in sys.modules:
        return
    pkg = types.ModuleType(pkg_name)
    pkg.__path__ = [os.path.join(os.path.dirname(marin_core.__file__), "telegram")]
    pkg.__package__ = pkg_name
    sys.modules[pkg_name] = pkg


_register_fake_telegram_package()

import importlib

actions_mod = importlib.import_module("marin_core.telegram.actions")
goal_executor_mod = importlib.import_module("marin_core.telegram.goal_executor")
ActionRegistry = actions_mod.ActionRegistry
PendingAction = actions_mod.PendingAction
AutonomousGoalExecutor = goal_executor_mod.AutonomousGoalExecutor


# -- fakes: no real Telegram/Telethon anywhere below this line -------------

class FakeConfig:
    owner_id = "1001"


class FakeEntity:
    def __init__(self, id_, username=""):
        self.id = id_
        self.username = username


class FakeDialog:
    def __init__(self, name, id_):
        self.name = name
        self.id = id_
        self.entity = FakeEntity(id_)


class FakeTelethonClient:
    """Enough surface for goal_executor.py: get_dialogs (verification),
    get_entity/send_message (owner notifications). No network anywhere."""

    def __init__(self):
        self.sent_messages = []
        self.dialogs = [FakeDialog("TestChannel", 999)]

    async def get_dialogs(self, limit=10):
        return self.dialogs

    async def get_entity(self, x):
        return x

    async def send_message(self, entity, text):
        self.sent_messages.append((entity, text))


class FakeTelegramClient:
    """Stand-in for MarinTelegramClient — only the attributes
    AutonomousGoalExecutor actually touches. Uses the REAL ActionRegistry
    (actions.py has no Telethon dependency at all) with fake handlers, so
    the real draft->confirm->execute flow is exercised end to end."""

    def __init__(self, engine):
        self.engine = engine
        self.config = FakeConfig()
        self.client = FakeTelethonClient()
        self.actions = ActionRegistry()
        self.create_channel_calls = 0
        self.send_message_calls = 0

        async def handle_create_channel(action: PendingAction) -> str:
            self.create_channel_calls += 1
            return "Готово, создала «TestChannel»."

        async def handle_send_message(action: PendingAction) -> str:
            self.send_message_calls += 1
            return "Готово, отправила сообщение."

        self.actions.register("create_channel", handle_create_channel)
        self.actions.register("send_message", handle_send_message)

        async def read_get_dialogs(payload: str) -> str:
            return "Диалоги: TestChannel"

        async def read_get_messages(payload: str) -> str:
            return "[1] Первый пост"

        self._readonly_actions = {
            "get_dialogs": read_get_dialogs,
            "get_messages": read_get_messages,
        }


FAKE_PLAN = [
    {"kind": "create_channel", "payload_template": '{"title": "TestChannel", "about": "About"}', "description": "Создать канал", "read": False},
    {"kind": "get_dialogs", "payload_template": "", "description": "Проверить список чатов", "read": True},
    {
        "kind": "send_message", "payload_template": '{"to": "$telegram_channel_id", "text": "Первый пост"}',
        "description": "Опубликовать первый пост", "read": False, "cycle_start": True,
    },
]


def fake_llm_fn(planning_input) -> str:
    # Возвращает готовый план независимо от содержимого промпта — этого
    # достаточно, чтобы проверить именно исполнительный механизм (Stage 4),
    # а не качество самого LLM-планирования.
    return json.dumps(FAKE_PLAN, ensure_ascii=False)


async def main() -> None:
    engine = CognitiveEngine(llm_provider=CallableProvider(fake_llm_fn))
    tc = FakeTelegramClient(engine)
    executor = AutonomousGoalExecutor(tc)
    owner_chat_id = str(tc.config.owner_id)

    # 1) create
    goal_id = executor.create_goal_from_description("Создай себе канал и веди его сама", owner_id=owner_chat_id)
    goal = engine.goal_set.goals[goal_id]
    # Автономные цели по умолчанию публикуют без подтверждения (auto_approve=True).
    # Здесь проверяем именно путь draft -> «да» -> execute, поэтому выключаем.
    goal.auto_approve = False
    assert goal.status == GoalStatus.PLANNING
    print("OK: goal created, status=PLANNING")

    # 2) plan (первый due-тик)
    await executor.advance_due_goals()
    assert goal.status == GoalStatus.RUNNING, goal.status
    assert goal.total_steps == 3 and goal.cycle_start_step == 2
    print("OK: planning produced a 3-step plan with cycle_start_step=2")

    # 3) execute step 0 (create_channel, WRITE) -> должна остановиться на WAITING
    await executor.advance_due_goals()
    assert goal.status == GoalStatus.WAITING
    assert owner_chat_id in tc.actions._pending
    assert tc.actions._pending[owner_chat_id].kind == "create_channel"
    print("OK: WRITE step drafted a real pending ActionRegistry confirmation (create_channel)")

    # 4) владелец подтверждает — ЧЕРЕЗ РЕАЛЬНЫЙ ActionRegistry.maybe_confirm
    result = await tc.actions.maybe_confirm(owner_chat_id, "да")
    assert result is not None and result.startswith("Готово")
    assert tc.create_channel_calls == 1
    await executor.on_pending_confirmed(owner_chat_id, result)
    assert goal.context.get("telegram_channel_id") == 999
    assert goal.current_step == 1
    assert goal.status == GoalStatus.RUNNING
    print("OK: confirmation executed the real handler once, verification captured telegram_channel_id=999")

    # 5) step 1 (get_dialogs, READ) должен выполниться сам и сразу перейти
    # к шагу 2 (send_message, WRITE) внутри того же тика, подставив
    # реальный channel_id в payload_template
    await executor.advance_due_goals()
    assert goal.current_step == 2
    assert goal.status == GoalStatus.WAITING
    pending_payload = tc.actions._pending[owner_chat_id].payload
    parsed_pending = json.loads(pending_payload)
    assert parsed_pending == {"to": "999", "text": "Первый пост"}, parsed_pending
    print("OK: READ step auto-ran, WRITE step JSON payload correctly substituted $telegram_channel_id -> 999")

    # 6) подтверждаем второй write-шаг -> план исчерпан -> должен начаться cycle
    result2 = await tc.actions.maybe_confirm(owner_chat_id, "да")
    assert tc.send_message_calls == 1
    await executor.on_pending_confirmed(owner_chat_id, result2)
    assert goal.current_step == 3
    await executor.advance_due_goals()  # это должно обнаружить current_step==total_steps и зациклиться
    assert goal.current_step == goal.cycle_start_step == 2
    assert goal.status == GoalStatus.RUNNING
    assert goal.next_execution is not None and goal.next_execution > 0
    print("OK: plan exhausted -> cycled back to cycle_start_step instead of completing/duplicating")

    # 7) idempotency guard: даже если current_step сбросить на 0 (например,
    # план перестроили заново после рестарта), create_channel НЕ должен
    # выполниться повторно, т.к. telegram_channel_id уже в context — шаг
    # пропускается, и тик продолжает (READ-шаг сразу следом выполняется
    # сам, WRITE-шаг send_message снова встаёт в WAITING — это ожидаемо,
    # публикация поста НЕ одноразовое действие типа create_channel, она
    # часть повторяющегося цикла и намеренно не идемпотентна).
    goal.current_step = 0
    goal.next_execution = 0.0
    calls_before = tc.create_channel_calls
    await executor.advance_due_goals()
    assert tc.create_channel_calls == calls_before, "create_channel must NOT run again — idempotency violated"
    assert goal.current_step == 2, goal.current_step  # 0 пропущен (идемпотентно), 1 (read) выполнен сам, встали на 2
    print("OK: idempotency — re-encountering create_channel step did not create a second channel")

    # goal сейчас снова WAITING (шаг 2 передрафтовался) — подтверждаем его,
    # чтобы перед проверкой persistence/resume цель была в обычном RUNNING,
    # а не посреди ожидания confirmation (которое персистентность и рестарт
    # обязаны уважать как есть, а не "проматывать").
    result3 = await tc.actions.maybe_confirm(owner_chat_id, "да")
    await executor.on_pending_confirmed(owner_chat_id, result3)
    assert goal.status == GoalStatus.RUNNING

    # 8) persistence: export -> новый GoalSet -> import -> состояние совпадает
    data = export_goals(engine.goal_set)
    reloaded = GoalSet()
    n = import_goals(reloaded, data)
    assert n == len(engine.goal_set.goals)
    reloaded_goal = reloaded.goals[goal_id]
    assert reloaded_goal.status == goal.status
    assert reloaded_goal.context.get("telegram_channel_id") == 999
    assert reloaded_goal.plan == goal.plan
    assert reloaded_goal.current_step == goal.current_step
    print("OK: goal state (status/plan/current_step/context incl. channel_id) survives export/import round-trip")

    # 9) resume after "restart": новый executor поверх нового engine, но с
    # уже загруженным GoalSet — должен продолжить, не начиная сначала, и
    # даже если current_step был бы сброшен в 0 (например, воображаемый
    # рестарт потерял бы прогресс, но НЕ context) — идемпотентность всё
    # равно защищает от повторного создания канала благодаря persisted context.
    engine2 = CognitiveEngine(llm_provider=CallableProvider(fake_llm_fn))
    engine2.goal_set = reloaded
    tc2 = FakeTelegramClient(engine2)
    tc2.client.dialogs = [FakeDialog("TestChannel", 999)]
    executor2 = AutonomousGoalExecutor(tc2)
    reloaded_goal.current_step = 0
    reloaded_goal.next_execution = 0.0
    await executor2.advance_due_goals()
    assert tc2.create_channel_calls == 0, "resumed goal must not recreate the channel after a simulated restart"
    assert reloaded_goal.current_step == 2, reloaded_goal.current_step
    print("OK: resume-after-restart continues from persisted context without recreating the channel")

    print("\nALL STAGE 4 INTEGRATION CHECKS PASSED")

    # === Stage 4.1: opt-in auto_approve for whitelisted content actions ===
    engine3 = CognitiveEngine(llm_provider=CallableProvider(fake_llm_fn))
    tc3 = FakeTelegramClient(engine3)
    executor3 = AutonomousGoalExecutor(tc3)
    gid3 = executor3.create_goal_from_description("Создай канал и веди его", owner_id="1001")
    g3 = engine3.goal_set.goals[gid3]
    g3.auto_approve = False
    await executor3.advance_due_goals()          # plan
    await executor3.advance_due_goals()           # draft create_channel (still requires confirmation, auto_approve is off)
    assert g3.status == GoalStatus.WAITING, "create_channel must NOT be auto-approved even with auto_approve=True"
    r = await tc3.actions.maybe_confirm("1001", "да")
    await executor3.on_pending_confirmed("1001", r)
    assert g3.context.get("telegram_channel_id") == 999

    g3.auto_approve = True  # эквивалент команды ".автопост <id> вкл"
    calls_before = tc3.send_message_calls
    await executor3.advance_due_goals()  # read-шаг сам, затем write send_message — теперь auto_approve
    assert g3.status == GoalStatus.RUNNING, g3.status  # НЕ встала в WAITING — выполнилось само
    assert tc3.send_message_calls == calls_before + 1
    assert "1001" not in tc3.actions._pending  # ничего не осталось pending
    print("OK: auto_approve=True lets a whitelisted content step (send_message) run without WAITING/confirmation")

    g3.auto_approve = False  # эквивалент ".автопост <id> выкл"
    print("OK: auto_approve toggled back off (would require confirmation again on the next write step)")

    print("\nALL STAGE 4.1 (AUTO-APPROVE) CHECKS PASSED")


if __name__ == "__main__":
    asyncio.run(main())
