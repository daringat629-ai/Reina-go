# MARIN_X_CORE_SPEC.md

Техническая спецификация когнитивного ядра **Marin X**.
Документ описывает не поведение, а механику: конкретные структуры данных, формулы обновления состояния, функции retrieval/utility и порядок вычислений в одном когнитивном цикле.

Это основа для реализации `marin_core/`. LLM подключается только на последнем шаге (Language Planning), как языковой орган, а не как источник решений.

---

## 0. Обозначения

| Символ | Смысл |
|---|---|
| `t` | дискретный тик когнитивного цикла (не секунда — один проход цикла) |
| `z_t` | латентное состояние (вектор, ℝ^d) |
| `x_t` | наблюдение (perception input) на шаге t |
| `S_t` | структурированный Situation Model на шаге t |
| `M` | граф памяти (Memory Graph) |
| `W` | граф мира (World Model) |
| `B` | набор убеждений (Beliefs) |
| `G` | набор целей (Goals) |
| `α, β, λ, η` | коэффициенты скорости обучения/забывания (разные для разных слоёв) |
| `sim(a, b)` | косинусная близость эмбеддингов |

Все "обучаемые" числа в этой спеке — это **скользящие обновления (EMA / Bayesian update)**, а не веса нейросети. Нейросеть используется только для эмбеддингов и генерации текста.

---

## 1. Latent State `z_t`

### 1.1 Структура

`z_t ∈ ℝ^d`, d ≈ 128–256. Не имеет ручной семантики по осям — это распределённое представление. Но при создании инициализируется из интерпретируемых компонент, чтобы система была отлаживаема:

```
z_t = concat(
    z_affect,        # 16  — валентность/возбуждение/напряжение как континуум, не enum
    z_attention,      # 16  — текущий фокус, векторно
    z_goal_tension,   # 16  — насколько цели конфликтуют/давят
    z_uncertainty,    # 16  — общая неопределённость по текущей ситуации
    z_social,         # 16  — состояние относительно текущего собеседника
    z_novelty,        # 16  — насколько ситуация нова относительно опыта
    z_residual        # 32+ — свободная часть, ни на что явно не мапится
)
```

Компоненты — это **проекции** полного вектора для чтения/отладки, а не независимые переменные. Явно readable значения (`affect.valence`, `attention.focus_id` и т.п.) вычисляются линейной или MLP-проекцией `z_t`, но не являются источником истины.

### 1.2 Уравнение обновления (State Transition Model)

```
z_{t+1} = f_θ(z_t, e(x_t), e(S_t), e(retrieval_t), g(G_t), ε_t)
```

где:
- `e(·)` — эмбеддинг соответствующего объекта в общее пространство ℝ^d (через линейный адаптер, не через LLM-forward);
- `ε_t` — prediction error с предыдущего шага (см. §6);
- `f_θ` — GRU-подобная ячейка:

```
r_t = σ(W_r · [z_t, u_t] + b_r)                 # reset gate
u_t_gate = σ(W_u · [z_t, u_t] + b_u)             # update gate
z̃_t = tanh(W_h · [r_t ⊙ z_t, u_t] + b_h)
z_{t+1} = (1 - u_t_gate) ⊙ z_t + u_t_gate ⊙ z̃_t
```

где `u_t = concat(e(x_t), e(S_t), e(retrieval_t), g(G_t), ε_t)`.

Это даёт: (а) непрерывность состояния, (б) устойчивость к шуму одного сообщения, (в) обучаемость offline (GRU можно дообучать на логах, не трогая LLM).

### 1.3 Затухание без стимулов (idle decay)

Если между тиками прошло Δreal время:

```
z_t = z_baseline + (z_t - z_baseline) · exp(-Δreal / τ_decay)
```

`z_baseline` — «состояние покоя», индивидуальное для personality (§4). `τ_decay` порядка часов для affect-компонент, порядка дней для goal_tension.

---

## 2. Situation Model `S_t`

Не свободный текст — структура:

```
Situation = {
    actor: EntityRef,
    action: ActionType,
    topic: TopicRef | None,
    tone: {valence: float, energy: float},
    context_ref: List[EventRef],       # на что ссылается текущая реплика
    goal_hint: GoalType | None,        # предполагаемая цель актора
    novelty: float,                    # 0..1, см. §2.1
    relationship_relevance: float,     # 0..1
}
```

### 2.1 Novelty score

```
novelty(x_t) = 1 - max_k sim(e(x_t), e(m_k))     for m_k ∈ top-K recent memory
```
Высокий novelty ⇒ выше вес x_t в обновлении z (см. attention, §3), выше приоритет на consolidation.

### 2.2 Построение Situation Model

Пайплайн: `x_t → NER/entity linking → action classification → topic linking (retrieval) → tone estimation → context linking (temporal + reference resolution) → novelty scoring`.
Каждый под-шаг — отдельный вызов reasoning engine (fast mode, §9), не один большой LLM-промпт "разберись во всём".

---

## 3. Attention

Attention — скоринговая функция над кандидатами (память, факты мира, цели), не отдельный модуль хранения.

```
attention_score(candidate c | S_t, z_t, G_t) =
      w1 · sim(e(c), e(S_t))                      # релевантность ситуации
    + w2 · goal_relevance(c, G_t)                  # релевантность текущим целям
    + w3 · recency(c)                               # экспоненциальный decay по времени
    + w4 · novelty(c)                                # насколько c противоречит/расширяет опыт
    + w5 · danger_or_conflict(c)                     # конфликт с belief/identity — приоритет вверх
    + w6 · social_salience(c, S_t.actor)
```

`w1..w6` — вектор весов, сам являющийся частью `personality policy` (§4), т.е. разные личностные настройки по-разному расставляют внимание (кто-то выше весит novelty, кто-то — relationship).

Top-N кандидатов по `attention_score` идут в retrieval для текущего цикла; остальное отбрасывается до следующего тика.

---

## 4. Identity / Personality / Policy

Явное разделение трёх слоёв:

```
Identity  = { core_values: [...], invariants: [...], self_narrative: EmbeddingSeq }   # τ ~ месяцы/годы
Personality = { trait_priors: Dict[str, float], attention_weights: w1..w6, style_prior }  # τ ~ недели
Policy(t)  = π(z_t, S_t, G_t; Personality, Identity)                                     # момент времени
```

Личность — это не число `warmth=0.8`, а **приор распределения** над возможными реакциями. Конкретное поведение — сэмпл/argmax из этого приора, модулированный текущим `z_t`.

```
behavior_tendency = softmax( Personality.trait_priors ⊕ g(z_t, S_t) )
```

где `⊕` — обучаемая комбинация (взвешенная сумма или маленький MLP), а не переопределение.

### 4.1 Скорости обучения по слоям

```
Identity.update_rate    ≈ 1e-4   (почти неизменна, меняется только через явный reflective conflict, §13)
Personality.update_rate ≈ 1e-3
Relationship.update_rate≈ 1e-2
Behavior/Policy          пересчитывается каждый тик (не накапливает состояние сама по себе)
Context/Prediction        полностью пересчитывается каждый тик
```

Обновление медленных слоёв — EMA:
```
Personality_{t+1} = Personality_t + α_pers · (observed_trait_signal_t - Personality_t)
```
`observed_trait_signal_t` берётся из metacognition (§13): "это поведение было согласовано с личностью или было ситуативным отклонением".

---

## 5. Memory Graph

### 5.1 Узел

```
MemoryNode = {
    id, type: {Event, Belief, Entity, Emotion, Goal, Outcome},
    embedding: ℝ^d,
    t_created, t_last_access,
    importance: float,           # см. 5.3
    valence: float,
    edges: List[(relation_type, target_id, weight)]
}
```

Типы рёбер: `causes, precedes, involves, contradicts, supports, about, felt_during`.

### 5.2 Retrieval score

```
retrieval_score(m | S_t, z_t, G_t) =
      β1 · sim(e(m), e(S_t))
    + β2 · exp(-(t_now - m.t_last_access) / τ_recency)
    + β3 · relationship_relevance(m, S_t.actor)
    + β4 · goal_relevance(m, G_t)
    + β5 · m.importance
    + β6 · prediction_relevance(m, current_predictions)
```

Top-K по `retrieval_score` → working memory на текущий тик. K обычно 5–20, зависит от cognitive_load (§14).

### 5.3 Importance

Вычисляется при консолидации (§7), не при создании:

```
importance(m) = γ1 · |prediction_error at m.t_created|
              + γ2 · novelty(m)
              + γ3 · goal_relevance(m, G_active_at_creation)
              + γ4 · access_count(m) / (t_now - m.t_created)
```

### 5.4 Forgetting

Не удаление, а понижение доступности:
```
retrievability(m, t) = importance(m) · exp(-(t - m.t_last_access) / (τ_base · (1 + access_count(m))))
```
Модель типа spaced-repetition (аналог ACT-R base-level activation). Узлы с низким `retrievability` не удаляются, но перестают попадать в top-K, пока их снова что-то не активирует.

---

## 6. Prediction Engine

Перед каждым действием Marin генерирует явный прогноз:

```
prediction_t = Predict(S_t, z_t, action_candidate, W, B)
             = { expected_response_type, expected_valence, expected_goal_progress, confidence }
```

После получения реального исхода `outcome_t`:

```
ε_t = distance(prediction_t, outcome_t)
    = w_e1 · (1 - sim(prediction_t.expected_response_type, outcome_t.actual_type))
    + w_e2 · |prediction_t.expected_valence - outcome_t.actual_valence|
    + w_e3 · |prediction_t.expected_goal_progress - outcome_t.actual_goal_progress|
```

`ε_t` идёт: (1) обратно в `z_{t+1}` как компонент update (§1.2), (2) в Learning Engine (§12), (3) в importance memory-узла, созданного на этом шаге (§5.3).

---

## 7. Belief System

Явное разделение состояний знания:

```
Observation → Memory → Belief → Hypothesis → Prediction
```

```
Belief = {
    statement: EmbeddingOrProp,
    confidence: float ∈ (0,1),
    support: List[MemoryNodeId],
    counter_evidence: List[MemoryNodeId],
    t_last_updated,
    source_type: {direct_observation, inference, told_by_user, ...}
}
```

### 7.1 Обновление confidence (Bayes-подобное, но упрощённое до логит-формы)

```
logit(confidence_{t+1}) = logit(confidence_t) + κ · evidence_weight(new_evidence)
```

`evidence_weight` положительный для support, отрицательный для counter_evidence, масштабируется по `retrieval_score` источника (более релевантное/недавнее свидетельство весит больше).

### 7.2 Contradiction handling

Если новое наблюдение имеет `sim(new, belief.statement) < -θ` (семантическое противоречие, определяется через NLI-классификатор, не через косинус напрямую):

```
if confidence_t > θ_high and evidence_weight(new) сильное:
    → создать открытый Hypothesis-конфликт, не менять belief молча
    → пометить оба (belief, new_observation) как contradicting
    → повысить attention_score для этой пары на следующих тиках
```

Это то, что предотвращает "тихое переписывание памяти".

---

## 8. Hypothesis Engine

Для неоднозначной ситуации держится явное распределение, а не единственный guess:

```
Hypotheses = [ (h_1, p_1), (h_2, p_2), ..., (h_n, p_n) ],  Σp_i = 1
```

Обновление через нормализованное правдоподобие (как soft-EM шаг):

```
p_i^{t+1} ∝ p_i^t · likelihood(evidence_t | h_i)
```

Решающее правило:
```
if max(p_i) > θ_confident:      action = act_on(h_argmax)
elif max(p_i) - second_max < θ_close and stakes(S_t) > θ_stakes:
                                  action = ASK_CLARIFY
else:                             action = act_on(h_argmax, hedge=True)
```

---

## 9. Reasoning modes

Общий `CognitiveState`, разные режимы вызова:

```
fast_reasoning:    один forward pass, низкий cognitive_load cost, для рутинных S_t
deep_reasoning:    multi-step (decompose → sub-answers → aggregate), высокий cost
causal_reasoning:  запрос к World Model по causal edges
social_reasoning:  запрос к Social Model / Theory of Mind (§11)
uncertainty_reasoning: явная работа с Hypothesis Engine
planning:          multi-step поиск по Goal tree с прогнозами на каждый шаг
```

Выбор режима — функция от `cognitive_load_budget(t)` и `stakes(S_t)` (насколько высока цена ошибки).

---

## 10. Goals / Needs / Utility

### 10.1 Иерархия целей

```
IdentityGoals (почти статичны)
    → LongTermGoals (недели/месяцы, explicit list с progress trackers)
        → CurrentGoals (активная сессия/тема)
            → SituationalGoals (этот обмен репликами)
```

### 10.2 Needs как latent drivers

```
Need_i(t+1) = Need_i(t) + δ_i - satisfaction_i(action_t)
```
Needs не показываются пользователю и не управляют текстом напрямую — они входят в `goal_utility` как модулятор.

### 10.3 Goal utility и конфликт целей

```
utility(action | G_t, Need_t) = Σ_g∈G_t  w_g · expected_progress(action, g) - cost(action) - Σ conflict_penalty(action, g, g')
```

`conflict_penalty` активируется, когда прогресс по одной цели предсказуемо вредит другой (например "помочь сейчас" vs "получить больше информации перед ответом").

---

## 11. Social Model / Theory of Mind

Для каждого известного актора:

```
SocialNode = {
    entity_id,
    beliefs_about_them: List[BeliefId],      # что мы о них знаем
    their_beliefs_about_us: List[BeliefId],  # theory of mind, ниже confidence
    relationship_state: { trust, closeness, history_valence_ema },
    interaction_count, last_interaction_t
}
```

`relationship_state` обновляется той же EMA-схемой, что Personality (§4.1), но с своей константой `α_rel`.

---

## 12. Learning Engine

Общий принцип: **разные подсистемы = разные τ**, но одна и та же математическая форма обновления (EMA / логит-EMA), чтобы вся система была консистентно объяснима.

```
Layer           Update form                     τ (order of magnitude)
Context/State   GRU transition (§1.2)           1 тик
Prediction stats logit-EMA                       десятки тиков
Behavior policy softmax(prior ⊕ g(z))            1 тик (не хранит своё состояние)
Relationship     EMA                              сотни тиков
Personality      EMA, меньший learning rate       тысячи тиков
Identity         explicit reflective update only  требует metacognition conflict (§13)
```

---

## 13. Metacognition & Self-Reflection

Периодический (не при каждом тике — раз в N тиков или на idle) проход:

```
for recent window W of ticks:
    check: prediction_t vs outcome_t  → aggregate ε
    check: behavior_t vs Personality.trait_priors → consistency_score
    check: new beliefs vs existing beliefs → unresolved contradictions
    if consistency_score persistently low over long window:
        → propose Personality update (не Identity)
    if contradiction unresolved and high-confidence on both sides:
        → escalate to explicit uncertainty marker in next relevant answer
```

---

## 14. Sleep / Offline Consolidation

Запускается на idle (нет активных диалогов) или по расписанию:

```
1. Собрать все MemoryNode с t_created в окне с последней консолидации
2. Пересчитать importance (§5.3) с учётом накопленного ε и access_count
3. Кластеризовать по embedding similarity → предложить semantic-обобщения
   (Episodic → Semantic promotion: если N похожих эпизодов, создать
   один SemanticNode с усреднённым embedding и ссылками на источники)
4. Обновить Belief confidences с учётом всего окна разом (batch, не по одному)
5. Обновить relationship_state, personality (EMA, §4.1/§12)
6. Обновить prediction statistics (какие типы прогнозов чаще ошибались)
7. Записать Self-Reflection summary как отдельный MemoryNode типа Reflection
```

`cognitive_load_budget` во время consolidation не тратится на real-time ответы — это фоновый процесс.

---

## 15. Cognitive Load

Скалярный бюджет на тик, ограничивает глубину reasoning и K в retrieval:

```
cognitive_load(t) = base_load
                   + Σ active_hypotheses_weight
                   + open_contradictions_weight
                   + (1 if deep_reasoning_engaged else 0) · deep_cost
```

Если `cognitive_load(t) > budget_max`: система принудительно снижает K (retrieval), переключается на fast_reasoning, может выбрать действие `WAIT` вместо немедленного ответа.

---

## 16. Один тик Cognitive Loop — псевдокод

```python
def tick(x_t):
    S_t = build_situation_model(x_t, W, M)
    candidates = score_attention(S_t, z_t, G_t)        # §3
    retrieved  = retrieve_topk(candidates, S_t, z_t, G_t)  # §5.2
    interpretation = interpret(S_t, retrieved, B)        # §7, §8
    prediction = predict(S_t, z_t, interpretation, W, B)  # §6
    G_t = update_goals(G_t, S_t, Need_t)                  # §10
    reasoning_mode = select_reasoning_mode(S_t, cognitive_load(t))  # §9
    candidate_actions = reason(S_t, z_t, G_t, retrieved, mode=reasoning_mode)
    action = decide(candidate_actions, utility_fn=utility)  # §10.3
    outcome = execute(action)                              # включая LLM-шаг, §17
    ε_t = prediction_error(prediction, outcome)             # §6
    z_{t+1} = transition(z_t, x_t, S_t, retrieved, G_t, ε_t)  # §1.2
    write_memory_node(x_t, S_t, action, outcome, ε_t)        # §5.1
    maybe_trigger_metacognition(ε_t, action)                 # §13
    return action
```

---

## 17. LLM Interface

LLM вызывается один раз за тик (в обычном режиме), уже с полностью собранным контекстом:

```
LanguagePlanningInput = {
    situation: S_t,
    retrieved_memory: [...],
    active_beliefs: [...],
    chosen_action_type: ActionType,     # уже решено ДО LLM
    goal_context: G_t.active,
    style_prior: Personality.style_prior,
    constraints: identity_invariants
}
```

LLM не выбирает `ActionType` (ASK/ANSWER/WAIT/...) — это уже определено Decision Engine. LLM отвечает за формулировку в рамках заданного действия и стиля. Ответ LLM затем проходит `action_validation` (проверка на противоречие Identity/Belief) перед отправкой в Telegram.

---

## 18. Приоритет реализации (для первой итерации кода)

1. `CognitiveState` + `latent_state` (§1) — без этого ничего не работает
2. `cycle.py` — тик-функция из §16, даже с заглушками вместо retrieval/reasoning
3. `situation.py` + `attention.py` (§2, §3) — минимальная версия
4. `memory_graph.py` + `retrieval.py` (§5) — in-memory граф, без консолидации
5. `predictor.py` + `prediction_error.py` (§6) — простейшая версия
6. `decision_engine.py` (§10.3, §16)
7. `llm/interface.py` (§17)
8. Всё остальное (beliefs, hypotheses, social, metacognition, consolidation) — второй итерацией поверх работающего цикла

Это порядок, в котором дальше будет собираться `marin_core/`.
