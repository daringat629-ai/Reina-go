from marin_core.config import load_config, build_llm_provider, build_engine
from marin_core.llm.providers import FallbackProvider, OpenAICompatProvider


def main():
    cfg = load_config("marin_core.env")
    print("owner_id:", cfg.owner_id)
    print("openrouter_model:", cfg.openrouter_model)
    print("openrouter_fallback_model:", cfg.openrouter_fallback_model)
    print("ollama_model:", cfg.ollama_model)
    print("base_temperature:", cfg.base_temperature)
    print("max_output_tokens:", cfg.max_output_tokens)

    assert cfg.owner_id == "123456789"
    assert cfg.openrouter_model == "deepseek/deepseek-v4-pro-0813"
    assert cfg.openrouter_api_key is not None

    provider = build_llm_provider(cfg)
    print("\nprovider chain:", type(provider).__name__)
    assert isinstance(provider, FallbackProvider)
    print("  ->", [type(p).__name__ for p in provider.providers])
    assert isinstance(provider.providers[0], OpenAICompatProvider)
    assert provider.providers[0].config.model == cfg.openrouter_model

    # build_engine собирает CognitiveEngine целиком (без сетевого вызова —
    # мы тут не зовём .tick(), только конструктор)
    engine = build_engine(cfg)
    print("\nengine.identity.name:", engine.identity.name)
    print("engine ready:", engine is not None)

    print("\nOK: config.py loads the trimmed .env and wires a real provider chain.")


if __name__ == "__main__":
    main()
