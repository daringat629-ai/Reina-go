"""
Smoke test — не unit-тест в строгом смысле, а быстрая проверка, что весь
цикл (perception -> situation -> attention -> retrieval -> prediction ->
decision -> llm -> memory write -> state update) действительно собирается
и работает без исключений на нескольких тиках подряд.
"""

from marin_core import CognitiveEngine


def main():
    engine = CognitiveEngine()

    messages = [
        "привет!",
        "расскажи, как устроена память в этом ядре?",
        "спасибо, это очень интересно",
        "а что если прогноз ошибётся?",
    ]

    for i, msg in enumerate(messages):
        result = engine.tick(msg, channel_id="test_channel", source_actor_id="test_user")
        print(f"--- tick {i} ---")
        print("input:", msg)
        print("situation.action:", result.situation.action)
        print("situation.novelty:", round(result.situation.novelty, 3))
        print("action.type:", result.action.type)
        print("generated_text:", result.generated_text)
        print("prediction_error:", round(result.prediction_error, 3))
        print("z.norm:", round(result.state.z.norm(), 3))
        print("memory size:", len(engine.memory))
        print()

    print("OK: full cycle ran without exceptions.")


if __name__ == "__main__":
    main()
