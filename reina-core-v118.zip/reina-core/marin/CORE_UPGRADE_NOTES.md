# Marin X Core — Interpretation / Beliefs / Learning upgrade

Цикл тика теперь:
OBSERVE → SITUATION → ATTEND → RETRIEVE → **INTERPRET** → **LEARN FROM FEEDBACK**
→ **BELIEF UPDATE** → **PREDICT (на каждого кандидата)** → **DECIDE (основное + побочные)**
→ ACT → OUTCOME → RECORD → **METACOGNITION** → STATE UPDATE

Новые модули:
- `interpretation/` — InterpretationEngine: intent-распределение, entities, topic, tone, facts,
  uncertainties, hypotheses, belief_updates, feedback. Работает по последней реплике (focal text).
- `perception/classifiers.py` — реальные классификаторы SituationBuilder; `_Default*` только fallback
  (`engine.fallback_stats`).
- `belief/beliefs.py` — `BeliefStore.revise()` (created / reinforced / contradicted / updated),
  `retract()`, evidence, source, subject, status.
- `prediction/predictor.py` — `LearnedPredictor`, допущения в `Prediction.assumptions`.
- `learning/pattern_learning.py`, `learning/feedback_learning.py` — паттерны интерпретации,
  Q(intent, action), социальные поправки; атрибуция ошибки: intent / belief / social / goal / action.
- `decision/candidates.py` — ANSWER ASK CLARIFY IGNORE REMEMBER FORGET SEARCH OBSERVE DEFER ACT
  с expected_value / risk / confidence / goal_alignment / social_cost / prediction.
- `action/executor.py` — REMEMBER / FORGET / SEARCH / ACT.
- `metacognition/tick_meta.py` — knowledge, uncertainty, prediction/decision confidence, reason,
  known / assumed / unknown / errors. `engine.explain_last()`.

Telegram: только команда `/why` (`.почему`, `/meta`) и строка «Обучение» в `/status`.
Поведение для владельца: адресованное сообщение никогда не получает молчаливое действие.

API совместимо: `engine.tick(...)` принимает новые необязательные `addressed=`, `metadata=`;
`TickResult` получил поля interpretation, decision, secondary_actions, execution_results,
belief_revisions, learning_report, meta. Старые снапшоты импортируются; выученное сохраняется
в секции `learning` экспорта.

Тесты: `python run_tests.py` → 75 passed (новые — `tests/test_cognitive_core.py`).
`config_test.py` падал и до апгрейда: сверяет owner_id с локальным `.env`.

## deploy14_autonomous_life merge (this build)

Merged in from `marin_x_deploy14_autonomous_life.zip` (built on the same
pre-cognition base as deploy13, `AUTONOMOUS_LIFE_LOOP.md` + `engine/autonomous_life.py`
+ `telegram/proactive.py` + `tests/test_autonomous_social.py`): Marin can now
occasionally start a conversation herself with an existing human contact
(rate-limited, one peer at a time, never bulk). This is independent of the
Interpretation/Belief/Learning upgrade — no conflicts, both apply cleanly.

`test_autonomous_social_disabled` uses pytest's `monkeypatch` fixture; it
fails under `run_tests.py` (which is not pytest) both here and in the
original deploy14_autonomous_life.zip — pre-existing, not something this
merge introduced. Run it with `pytest tests/test_autonomous_social.py` if
pytest is available.

## Group-chat person differentiation

Two real bugs fixed:

1. `telegram/client.py::_build_history_context` labelled EVERY non-Marin
   line as generic "Собеседник" — the owner and any stranger in a group were
   indistinguishable in the transcript the LLM sees. Now each line is
   labelled with the real sender (`Владелец` for the owner, real
   name/@username/title for everyone else, cached per chat).
2. Regular multi-person group chats got ZERO replies for anyone but the
   owner (only her own channel's *discussion* group had a reply path, via
   `comments.py`). New `telegram/groups.py::GroupMixin`:
   - engages only when actually addressed (mention of her name/@username,
     or a reply to one of her own messages) — never unsolicited chatter;
   - passes the real sender name into `engine.tick(..., actor_name=...)`,
     which the core already threads through to `InterpretationContext.actor_label`
     (`engine/cycle.py`) and belief statements/situation summaries
     (`interpretation/engine.py`) — so two different people get e.g.
     "Аня любит кофе" / "Борис любит чай" instead of two identical
     "Собеседник любит X" lines;
   - relationship/beliefs/pending-feedback were ALREADY per-`actor_id` in the
     core (SocialModel, BeliefStore, FeedbackLearner) since the cognition
     upgrade — this only makes the Telegram layer surface real names instead
     of losing them;
   - same safety rails as `comments.py`: ACTION/READ/POST/AUTOGOAL from a
     non-owner group member are stripped, never executed; BELIEF/PERSON/GOAL
     are processed so she can build an actual relationship with regulars;
   - rate-limited per (chat, sender) + hourly cap per chat
     (`MARIN_GROUP_CHAT_ENABLED`, `MARIN_GROUP_REPLY_COOLDOWN_SECONDS`,
     `MARIN_GROUP_REPLIES_MAX_PER_HOUR`).

New `engine.tick(..., actor_name=...)` parameter (optional, backward
compatible) and `tests/test_groups.py` (7 tests, all passing).

## "Полностью независимая" — behavioral + psychological independence

Two things, per what was actually asked for (not technical/deployment
independence, which wasn't requested):

### 1. Psychological — her own opinions, not just accommodation

- `identity/presets.py`: new core value ("своё мнение..."), explicit
  personality/style language that she doesn't auto-agree and can push back —
  including with the owner — and a dedicated `owner_style_prior["independence"]`
  field spelling out that closeness with him is not the same as always
  agreeing with him.
- `llm/providers.py::_style_prior_to_system_prompt`: new paragraph in the
  normal chat-reply branch, telling the model directly not to bend opinions
  to please whoever it's talking to, owner included — disagree when she
  actually disagrees, agree when she actually agrees, neither reflexively.
- Nothing here touches belief/fact handling (already evidence-based, not
  deference-based — a contradiction from the owner still goes through
  `BeliefStore.revise()`, not blind acceptance) or removes any safety rail.

### 2. Behavioral — decides to act on her own initiative

New `engine/autonomous_life.py::_self_initiative_pulse` (part of the regular
~60s `pulse()`, alongside autopost/goals/proactive/social):

- periodically (`MARIN_SELF_INITIATIVE_INTERVAL`, default 24h, floor 1h) she
  gets a bounded chance to decide, from her own diary + latest self-reflection
  + what's already in progress, whether there's something SHE actually wants
  to do right now — not asked for by the owner, not the fixed autopost
  schedule. If nothing genuinely stands out she returns `[SKIP]` and nothing
  happens (`MARIN_SELF_INITIATIVE_ENABLED=false` disables this entirely);
- capped concurrency (`MARIN_SELF_INITIATIVE_MAX_CONCURRENT`, default 2) so
  it's "a couple of things she's chosen to care about," not runaway goal
  creation;
- reuses the EXISTING safe goal pipeline end to end — same
  `AutonomousGoalExecutor`/`SAFE_AUTO_APPROVE_KINDS`/draft-confirm-execute
  rails as an owner-typed `.цель ...` or `<<<AUTOGOAL>>>`. Content/setup
  actions in her own channels still run themselves; anything touching another
  real person (kick/ban/invite/promote/relay) still asks the owner to
  confirm — that boundary is about not letting an LLM take irreversible
  action on other humans unchecked, and stays regardless of how "independent"
  she otherwise is;
- always transparent: the owner gets a DM the moment she starts one
  (`«Слушай, я тут сама решила заняться кое-чем: «...» [id]. Если не
  одобряешь — «.отмена <id>» ...»`), and it shows up in `/goals`/`.цели`
  like anything else — cancellable exactly the same way.

`add_autonomous_goal(...)` / `create_goal_from_description(...)` both gained
an optional `context=` param (backward compatible) so self-initiated goals
can be tagged and counted separately from owner-requested ones.

New `tests/test_self_initiative.py` (6 tests, all passing).
