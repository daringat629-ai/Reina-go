#!/bin/sh
set -eu
cd "$(dirname "$0")"
ENV_FILE=".env"
[ -f "$ENV_FILE" ] || { echo "ERROR: .env not found" >&2; exit 1; }
cp -a "$ENV_FILE" "$ENV_FILE.backup_human_chat_$(date +%Y%m%d_%H%M%S)"
set_env() {
  key="$1"; value="$2"
  if grep -q "^${key}=" "$ENV_FILE"; then
    sed -i "s|^${key}=.*|${key}=${value}|" "$ENV_FILE"
  else
    printf '%s=%s\n' "$key" "$value" >> "$ENV_FILE"
  fi
}
set_env MARIN_OPENROUTER_MODEL 'deepseek/deepseek-v4-flash-0731'
set_env MARIN_OPENROUTER_FALLBACK_MODEL 'openrouter/free'
set_env MARIN_OWNER_NAME 'Жаабир'
set_env MARIN_ALLOW_EMOJI 'false'
set_env MARIN_TELEGRAM_RESPOND_TO_OUTGOING 'false'
set_env MARIN_TELEGRAM_IGNORE_BOTS 'true'
set_env MARIN_TELEGRAM_OBSERVER_FILE '/mari/persistent/marin_telegram_activity.json'
set_env MARIN_TELEGRAM_OBSERVER_MAX_EVENTS '2500'
set_env MARIN_TELEGRAM_READ_DELAY_SECONDS '1.5'
set_env MARIN_TELEGRAM_REPLY_DELAY_SECONDS '10.0'
set_env MARIN_TELEGRAM_DEBOUNCE_SECONDS '2.5'
set_env MARIN_TELEGRAM_MESSAGE_GAP_MIN_SECONDS '0.8'
set_env MARIN_TELEGRAM_MESSAGE_GAP_MAX_SECONDS '1.6'
set_env MARIN_TELEGRAM_OWN_CHANNELS_FILE '/mari/persistent/marin_own_channels.json'
set_env MARIN_TELEGRAM_MEDIA_PACKS_FILE '/mari/persistent/marin_media_packs.json'
set_env MARIN_VISION_CACHE_FILE '/mari/persistent/marin_media_vision_cache.json'
set_env MARIN_DIARY_FILE '/mari/persistent/marin_diary.json'
set_env MARIN_STATE_IMPORT_FILE '/mari/persistent/marin_export.json'

echo '--- Marin X settings ---'
grep -E '^(MARIN_OPENROUTER_(MODEL|FALLBACK_MODEL)|MARIN_OWNER_NAME|MARIN_ALLOW_EMOJI|MARIN_TELEGRAM_(RESPOND_TO_OUTGOING|IGNORE_BOTS|OBSERVER_FILE|OBSERVER_MAX_EVENTS|READ_DELAY_SECONDS|REPLY_DELAY_SECONDS|DEBOUNCE_SECONDS|MESSAGE_GAP_MIN_SECONDS|MESSAGE_GAP_MAX_SECONDS|OWN_CHANNELS_FILE|MEDIA_PACKS_FILE)|MARIN_VISION_CACHE_FILE|MARIN_DIARY_FILE|MARIN_STATE_IMPORT_FILE)=' "$ENV_FILE"
echo 'Backup created before changes.'
