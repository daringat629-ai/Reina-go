"""Offline test runner (no pytest needed): python run_tests.py [-k substring] [-q]

Поддерживает минимальный набор pytest-фикстур, которые используются в tests/:
  * monkeypatch — setenv/delenv/setattr/delattr с автоматическим откатом;
  * tmp_path    — свежий временный каталог (pathlib.Path) на каждый тест.

Каждый тест изолирован: переменные окружения и подмены атрибутов
откатываются после него, даже если тест упал — раньше один тест, меняющий
os.environ, мог незаметно влиять на все последующие.

Если установлен pytest, эти же тесты можно запускать и им: `pytest tests`.
"""
from __future__ import annotations

import importlib
import inspect
import os
import pathlib
import shutil
import sys
import tempfile
import time
import traceback

ROOT = os.path.dirname(os.path.abspath(__file__))
TESTS = os.path.join(ROOT, "tests")
sys.path.insert(0, ROOT)
sys.path.insert(0, TESTS)

_MISSING = object()


class MonkeyPatch:
    """Минимальная совместимая с pytest реализация monkeypatch."""

    def __init__(self) -> None:
        self._env: list = []
        self._attrs: list = []
        self._items: list = []

    def setenv(self, name: str, value, prepend=None) -> None:
        value = str(value)
        if prepend and name in os.environ:
            value = value + prepend + os.environ[name]
        self._env.append((name, os.environ.get(name, _MISSING)))
        os.environ[name] = value

    def delenv(self, name: str, raising: bool = True) -> None:
        if name not in os.environ:
            if raising:
                raise KeyError(name)
            return
        self._env.append((name, os.environ[name]))
        del os.environ[name]

    def setattr(self, target, name, value=_MISSING, raising: bool = True) -> None:
        if value is _MISSING:  # форма setattr("pkg.mod.attr", value)
            value = name
            module_path, _, name = str(target).rpartition(".")
            target = importlib.import_module(module_path)
        old = getattr(target, name, _MISSING)
        if old is _MISSING and raising:
            raise AttributeError(f"{target!r} has no attribute {name!r}")
        self._attrs.append((target, name, old))
        setattr(target, name, value)

    def delattr(self, target, name: str, raising: bool = True) -> None:
        old = getattr(target, name, _MISSING)
        if old is _MISSING:
            if raising:
                raise AttributeError(name)
            return
        self._attrs.append((target, name, old))
        delattr(target, name)

    def setitem(self, mapping, key, value) -> None:
        self._items.append((mapping, key, mapping.get(key, _MISSING) if hasattr(mapping, "get") else _MISSING))
        mapping[key] = value

    def delitem(self, mapping, key, raising: bool = True) -> None:
        if key not in mapping:
            if raising:
                raise KeyError(key)
            return
        self._items.append((mapping, key, mapping[key]))
        del mapping[key]

    def undo(self) -> None:
        for mapping, key, old in reversed(self._items):
            if old is _MISSING:
                mapping.pop(key, None)
            else:
                mapping[key] = old
        self._items.clear()
        for target, name, old in reversed(self._attrs):
            if old is _MISSING:
                try:
                    delattr(target, name)
                except AttributeError:
                    pass
            else:
                setattr(target, name, old)
        for name, old in reversed(self._env):
            if old is _MISSING:
                os.environ.pop(name, None)
            else:
                os.environ[name] = old
        self._attrs.clear()
        self._env.clear()


def _run_one(fn):
    """Вызывает тест, подставляя поддерживаемые фикстуры. Возвращает (ok, err)."""
    kwargs, cleanups = {}, []
    for pname in inspect.signature(fn).parameters:
        if pname == "monkeypatch":
            mp = MonkeyPatch()
            kwargs[pname] = mp
            cleanups.append(mp.undo)
        elif pname == "tmp_path":
            d = tempfile.mkdtemp(prefix="marin_tmp_")
            kwargs[pname] = pathlib.Path(d)
            cleanups.append(lambda d=d: shutil.rmtree(d, ignore_errors=True))
        else:
            return False, f"unsupported fixture {pname!r}"
    env_before = dict(os.environ)
    try:
        fn(**kwargs)
        return True, None
    except Exception:
        return False, traceback.format_exc()
    finally:
        for c in reversed(cleanups):
            c()
        # страховка: тест, правящий os.environ напрямую, не влияет на соседей
        if dict(os.environ) != env_before:
            os.environ.clear()
            os.environ.update(env_before)


def main(argv) -> int:
    pattern = None
    quiet = "-q" in argv
    if "-k" in argv:
        i = argv.index("-k")
        pattern = argv[i + 1] if i + 1 < len(argv) else None

    passed = failed = 0
    failures = []
    t0 = time.perf_counter()
    for fn in sorted(os.listdir(TESTS)):
        if not (fn.startswith("test_") and fn.endswith(".py")):
            continue
        try:
            mod = importlib.import_module(fn[:-3])
        except Exception:
            # Модуль не импортируется — это провал, а не повод оборвать весь прогон.
            failed += 1
            err = traceback.format_exc()
            failures.append((f"{fn}::<import>", err))
            print(f"FAIL {fn}::<import>")
            print(err)
            continue
        for name, obj in inspect.getmembers(mod, inspect.isfunction):
            if not name.startswith("test_") or obj.__module__ != mod.__name__:
                continue
            test_id = f"{fn}::{name}"
            if pattern and pattern not in test_id:
                continue
            start = time.perf_counter()
            ok, err = _run_one(obj)
            dt = time.perf_counter() - start
            if ok:
                passed += 1
                if not quiet:
                    print(f"PASS {test_id} ({dt:.2f}s)")
            else:
                failed += 1
                failures.append((test_id, err))
                print(f"FAIL {test_id} ({dt:.2f}s)")
                print(err)

    total = time.perf_counter() - t0
    print(f"\n{passed} passed, {failed} failed in {total:.1f}s")
    if failures:
        print("\nFailed tests:")
        for test_id, _ in failures:
            print(f"  - {test_id}")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
