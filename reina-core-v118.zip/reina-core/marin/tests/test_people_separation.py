"""Память с границами: разные люди не путаются, вчерашняя переписка не теряется.

Разбор живого чата (deploy20):
  * «другой чел написал про винду — а в моей личке она спрашивает про ту винду»;
  * «он говорит, что сделал ДО, а потом она пишет мне, что она делает ДО».
"""
import asyncio
import datetime as dt
import time
from types import SimpleNamespace

import _fakes
from _fakes import Entity, Event
from test_channel_publisher import CALLS, CHAT_SCRIPT, OWNER, make_client

from marin_core.interpretation.lexicon import focal_text
from marin_core.memory.memory_graph import MemoryNode, NodeType
from marin_core.memory.scope import (
    belief_visible, format_memory, node_visible, relative_when,
)


def _node(actor, said, reply="", speaker="", channel="", is_owner=False, age_days=0.0):
    sit = {"actor": actor, "said": said, "summary": reply, "speaker": speaker,
           "channel_id": channel, "is_owner": is_owner}
    n = MemoryNode(type=NodeType.EVENT, embedding=[1.0, 0.0, 0.0, 0.0], payload={"situation": sit})
    n.t_created = time.time() - age_days * 86400
    return n


# ------------------------------------------------------------ focal text

def test_focal_text_understands_the_named_writer_marker():
    blob = ("[Личка. Тебе написал(а) Аня — это НЕ владелец.]\n"
            "[Ваша переписка до этого]\nВладелец: я сделал до\nMarin: ок\n"
            "[Аня написал(а)]\nа где та винда?")
    assert focal_text(blob) == "а где та винда?"
    group = "[Групповой чат «X»]\n[Контекст переписки]\nБорис: сделал до\n[Борис написал(а)]\nпривет"
    assert focal_text(group) == "привет"
    # старые маркеры по-прежнему работают
    assert focal_text("история\n[Новые сообщения владельца]\nдай ссылку") == "дай ссылку"


# ------------------------------------------------------------ scope

def test_strict_scope_hides_other_peoples_memories_but_keeps_own_and_chat():
    other = _node("777", "у меня глючит винда", speaker="Гость", channel="telegram:777")
    mine = _node("42", "мы обсуждали кофе", speaker="Владелец", channel="telegram:42", is_owner=True)
    group_mate = _node("888", "я в группе", speaker="Боря", channel="telegram:-100")
    kw = dict(actor_id="42", channel_id="telegram:42", is_owner=True, mode="strict")
    assert not node_visible(other, **kw)
    assert node_visible(mine, **kw)
    assert not node_visible(group_mate, **kw)
    # в общем чате слова других участников видны (с подписью)
    assert node_visible(group_mate, actor_id="42", channel_id="telegram:-100", is_owner=True, mode="strict")
    # чужой человек не видит память владельца
    assert not node_visible(mine, actor_id="777", channel_id="telegram:777", is_owner=False, mode="strict")
    # выключатель возвращает прежнее поведение
    assert node_visible(other, actor_id="42", channel_id="telegram:42", is_owner=True, mode="off")


def test_reflection_lessons_stay_shared():
    lesson = MemoryNode(type=NodeType.REFLECTION, embedding=[1.0, 0.0, 0.0, 0.0],
                        payload={"kind": "lesson", "summary": "не переспрашивай"})
    assert node_visible(lesson, actor_id="1", channel_id="c", is_owner=False, mode="strict")


def test_beliefs_about_another_person_are_not_used_for_the_third():
    about_other = SimpleNamespace(subject="777")
    about_me = SimpleNamespace(subject="42")
    about_world = SimpleNamespace(subject=None)
    assert not belief_visible(about_other, actor_id="42", mode="strict")
    assert belief_visible(about_me, actor_id="42", mode="strict")
    assert belief_visible(about_world, actor_id="42", mode="strict")
    assert belief_visible(about_other, actor_id="42", mode="labeled")


def test_memory_text_says_who_when_and_whether_it_is_the_same_person():
    n = _node("777", "[Аня написал(а)]\nя сделала до", reply="молодец", speaker="Аня",
              channel="telegram:777", age_days=1)
    line = format_memory(n, now=time.time(), actor_id="42", channel_id="telegram:42")
    assert "вчера" in line
    assert "Аня написал(а): «я сделала до»" in line      # служебный блок отрезан, автор назван
    assert "ты ответила: «молодец»" in line
    assert "ДРУГОЙ человек" in line                       # это не текущий собеседник
    same = format_memory(_node("42", "привет", speaker="Владелец", is_owner=True),
                         now=time.time(), actor_id="42", channel_id="telegram:42")
    assert "тот же человек" in same and "Владелец написал(а)" in same
    # служебный узел без текста в промпт не идёт
    empty = MemoryNode(type=NodeType.OUTCOME, embedding=[1.0, 0.0, 0.0, 0.0], payload={"action_type": "answer"})
    assert format_memory(empty, now=time.time(), actor_id="42", channel_id="c") == ""


def test_relative_when_uses_calendar_days():
    now = time.time()
    assert relative_when(now, now).startswith("сегодня")
    assert relative_when(now - 86400, now).startswith("вчера")
    assert "дн. назад" in relative_when(now - 3 * 86400, now)


# ------------------------------------------------------------ engine end-to-end

def test_engine_does_not_serve_another_persons_memory_in_a_different_chat():
    tc, fake = make_client()
    CHAT_SCRIPT.append("что случилось?")
    tc.engine.tick("[Аня написал(а)]\nу меня сломалась винда, ничего не грузится",
                   channel_id="telegram:555", source_actor_id="555", is_owner=False,
                   actor_name="Аня")
    CALLS["chat"].clear()
    CHAT_SCRIPT.append("привет")
    tc.engine.tick("[Новые сообщения владельца]\nну что там с виндой?",
                   channel_id=f"telegram:{OWNER}", source_actor_id=OWNER, is_owner=True)
    memories = "\n".join(CALLS["chat"][-1].retrieved_memory_summaries)
    assert "сломалась винда" not in memories

    # а в разговоре с самой Аней её же слова доступны — с подписью
    CALLS["chat"].clear()
    CHAT_SCRIPT.append("расскажи")
    tc.engine.tick("[Аня написал(а)]\nпомнишь про мою винду?",
                   channel_id="telegram:555", source_actor_id="555", is_owner=False,
                   actor_name="Аня")
    memories = "\n".join(CALLS["chat"][-1].retrieved_memory_summaries)
    assert "сломалась винда" in memories and "тот же человек" in memories


def test_new_episodes_record_speaker_and_channel_and_the_real_message():
    tc, fake = make_client()
    CHAT_SCRIPT.append("ок")
    tc.engine.tick("[Личка. ...]\n[Ваша переписка до этого]\nBорис: старое\n[Аня написал(а)]\nя сделала до",
                   channel_id="telegram:555", source_actor_id="555", is_owner=False, actor_name="Аня")
    events = [n for n in tc.engine.memory.all_nodes(NodeType.EVENT)
              if n.payload.get("situation", {}).get("actor") == "555"]
    sit = events[-1].payload["situation"]
    assert sit["speaker"] == "Аня" and sit["channel_id"] == "telegram:555" and sit["is_owner"] is False
    assert sit["said"] == "я сделала до"          # а не весь блок с чужой историей


# ------------------------------------------------------------ history: yesterday & namesakes

def _group_with_history(fake, msgs):
    group = Entity(-100777, title="Чат", username="", broadcast=False, creator=False)
    fake.entities[group.id] = group
    fake.history[group.id] = msgs
    return group


def _msg(text, sid, name, when, out=False):
    m = _fakes.Msg(text, out=out)
    m.sender_id = sid
    m.date = when
    ent = Entity(sid, title=name, broadcast=False, creator=False)

    async def get_sender():
        return ent
    m.get_sender = get_sender
    return m


def test_history_includes_yesterday_with_day_separator():
    tc, fake = make_client()
    now = dt.datetime.now().astimezone()
    y = now - dt.timedelta(days=1)
    msgs = [_msg("вчера обсуждали ноутбук", 777, "Гость", y),
            _msg("ага, взял на 16 гигов", 777, "Гость", y, out=False),
            _msg("сегодня продолжим", 777, "Гость", now)]
    group = _group_with_history(fake, msgs)
    ctx = asyncio.run(tc._build_history_context(group, exclude_ids=set()))
    assert "— вчера" in ctx and "— сегодня —" in ctx
    assert ctx.index("вчера обсуждали ноутбук") < ctx.index("— сегодня —") < ctx.index("сегодня продолжим")


def test_history_window_is_bigger_than_six_messages():
    tc, fake = make_client()
    now = dt.datetime.now().astimezone()
    msgs = [_msg(f"сообщение {i}", 777, "Гость", now) for i in range(12)]
    group = _group_with_history(fake, msgs)
    ctx = asyncio.run(tc._build_history_context(group, exclude_ids=set()))
    assert "сообщение 0" in ctx and "сообщение 11" in ctx


def test_two_people_with_the_same_name_get_different_labels():
    tc, fake = make_client()
    now = dt.datetime.now().astimezone()
    msgs = [_msg("я сделал до", 111482, "Саша", now), _msg("а я после", 222117, "Саша", now)]
    group = _group_with_history(fake, msgs)
    ctx = asyncio.run(tc._build_history_context(group, exclude_ids=set()))
    assert "Саша #482: я сделал до" in ctx and "Саша #117: а я после" in ctx


def test_marin_lines_keep_the_plain_prefix_the_anti_repeat_parser_relies_on():
    tc, fake = make_client()
    now = dt.datetime.now().astimezone()
    msgs = [_msg("привет", 777, "Гость", now - dt.timedelta(days=1)), _msg("здарова", 0, "Marin", now, out=True)]
    group = _group_with_history(fake, msgs)
    ctx = asyncio.run(tc._build_history_context(group, exclude_ids=set()))
    assert any(ln.startswith("Marin: здарова") for ln in ctx.split("\n"))


# ------------------------------------------------------------ observer & prompts

def test_observer_context_is_grouped_by_chat_and_excludes_current():
    tc, fake = make_client()
    obs = tc.observer
    obs.events.clear()
    obs.record(chat_id="555", chat_title="Аня", sender_id="555", sender_name="Аня", username="",
               text="у меня сломалась винда", outgoing=False, media=False)
    obs.record(chat_id="-100", chat_title="Общий", sender_id="888", sender_name="Боря", username="",
               text="я сделал до", outgoing=False, media=False)
    obs.record(chat_id=OWNER, chat_title="Владелец", sender_id=OWNER, sender_name="Владелец", username="",
               text="привет", outgoing=False, media=False)
    ctx = obs.recent_context_by_chat(exclude_chat_id=OWNER)
    assert "▸ Чат «Аня» (личка)" in ctx and "▸ Чат «Общий» (группа/канал)" in ctx
    assert "Аня: у меня сломалась винда" in ctx and "Боря: я сделал до" in ctx
    assert "Владелец: привет" not in ctx          # текущий чат исключён


def test_every_conversation_prompt_carries_the_who_is_who_rules():
    tc, fake = make_client()
    CHAT_SCRIPT.append("привет")
    asyncio.run(tc._process_batch([Event("привет", fake, int(OWNER))], chat=int(OWNER),
                                  chat_id=OWNER, sender_id=OWNER))
    assert "Кто есть кто" in CALLS["chat"][-1].situation_summary
    assert "не путай людей" in tc._identity_rules_hint("other")
    assert "ДРУГИХ чатах" in CALLS["chat"][-1].situation_summary
