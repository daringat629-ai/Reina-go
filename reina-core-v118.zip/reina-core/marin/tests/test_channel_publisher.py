"""ChannelPublisher end-to-end against a fake Telethon client + REAL engine,
REAL own-channels registry mixin and REAL MarinTelegramClient pipeline."""
import asyncio
import itertools

import _fakes
from _fakes import Entity, Event, FakeTelethon

from marin_core import CognitiveEngine
from marin_core.llm.providers import CallableProvider

OWNER = "1001"
CHANNEL = Entity(-1001234567890, title="Мысли Марин", username="marin_thoughts")
OTHER = Entity(-1009999, title="Чужой канал", username="someone_else", creator=False)

_POSTS = itertools.count(1)
CALLS = {"post": [], "chat": []}
CHAT_SCRIPT = []  # очередь ответов чат-модели


def fake_llm(pin):
    if pin.system_override:
        CALLS["post"].append(pin)
        n = next(_POSTS)
        return (f"«Вот пост:»\n\nСегодня утро номер {n} пахнет мокрым асфальтом и кофе. "
                f"Я поймала себя на мысли, что осень — это не грусть, а пауза. <<<MSG>>> "
                f"Вариант {n}: берегите себя.")
    CALLS["chat"].append(pin)
    return CHAT_SCRIPT.pop(0) if CHAT_SCRIPT else "ага<<<MSG>>>поняла тебя"


def make_client():
    from marin_core.telegram.client import MarinTelegramClient
    from marin_core.telegram.settings import TelegramConfig

    engine = CognitiveEngine(llm_provider=CallableProvider(fake_llm))
    cfg = TelegramConfig(api_id=1, api_hash="x", owner_id=OWNER)
    tc = MarinTelegramClient(engine=engine, config=cfg)
    fake = FakeTelethon([CHANNEL, OTHER])
    tc.client = fake
    tc._own_channels.clear()
    return tc, fake


def run(coro):
    return asyncio.run(coro)


def test_post_without_registry_discovers_channel_and_publishes():
    tc, fake = make_client()
    res = run(tc.publisher.publish("про осень"))
    assert res.ok, res.error
    # выбрала канал, где она creator, а не чужой
    assert fake.sent[-1][0] == CHANNEL.id
    text = fake.sent[-1][1]
    assert "<<<" not in text and "Вот пост" not in text and not text.startswith("«")
    assert res.link.startswith("https://t.me/marin_thoughts/")
    assert str(CHANNEL.id) in tc._own_channels  # запомнила как свой
    assert "про осень" in CALLS["post"][-1].situation_summary


def test_verbatim_and_delete_last():
    tc, fake = make_client()
    tc._remember_own_channel(CHANNEL.id, title=CHANNEL.title, username=CHANNEL.username)
    res = run(tc.publisher.publish(verbatim_text="Всем привет, я вернулась!"))
    assert res.ok and fake.sent[-1] == (CHANNEL.id, "Всем привет, я вернулась!")
    d = run(tc.publisher.delete_last())
    assert d.ok and fake.deleted[-1] == (CHANNEL.id, [res.message_id])
    d2 = run(tc.publisher.delete_last())
    assert not d2.ok


def test_hint_picks_named_channel_and_becomes_default():
    tc, fake = make_client()
    second = Entity(-100555, title="Кухня Марин", username="marin_kitchen")
    fake.entities[second.id] = second
    fake.by_username["marin_kitchen"] = second
    tc._remember_own_channel(CHANNEL.id, title=CHANNEL.title, username=CHANNEL.username)
    tc._remember_own_channel(second.id, title=second.title, username=second.username)
    res = run(tc.publisher.publish("рецепт", channel_hint="кухня марин"))
    assert res.ok and fake.sent[-1][0] == second.id
    res2 = run(tc.publisher.publish(""))
    assert fake.sent[-1][0] == second.id, "явно названный канал становится основным"


def test_autopost_fresh_text_each_cycle():
    tc, fake = make_client()
    tc._remember_own_channel(CHANNEL.id, title=CHANNEL.title, username=CHANNEL.username)
    msg = run(tc.publisher.set_autopost(True, interval_seconds=3600))
    assert "раз" in msg or "каждые" in msg
    # Автопост теперь пишет из настоящих мыслей: без новых событий она молчит
    # (см. test_inner_thoughts.py). Здесь — у неё была жизнь между циклами.
    for i in range(3):
        tc.observer.record(chat_id=OWNER, chat_title="Jaabir", sender_id=OWNER, sender_name="Jaabir",
                           username="", text=f"поговорили про опрос, попытка {i}", outgoing=False, media=False)
    r1 = run(tc.publisher.autopost_tick())
    assert len(r1) == 1 and r1[0].ok
    assert run(tc.publisher.autopost_tick()) == []  # интервал ещё не прошёл
    entry = tc._own_channels[str(CHANNEL.id)]
    entry["last_post_at"] -= 4000
    entry["autopost_last_attempt_at"] -= 4000
    r2 = run(tc.publisher.autopost_tick())
    assert r2 and r2[0].ok and r2[0].text != r1[0].text, "каждый цикл — новый текст"
    assert "Мысли Марин" in tc._own_channels_hint() and "по расписанию" in tc._own_channels_hint()
    run(tc.publisher.set_autopost(False))
    assert not entry["autopost_enabled"]


def test_owner_phrase_publishes_without_confirmation():
    tc, fake = make_client()
    tc._remember_own_channel(CHANNEL.id, title=CHANNEL.title, username=CHANNEL.username)
    CHAT_SCRIPT.append("выложила, про осень написала<<<MSG>>>зацени")
    ev = Event("сделай пост про осень", fake, int(OWNER))
    run(tc._process_batch([ev], chat=int(OWNER), chat_id=OWNER, sender_id=OWNER))
    channel_posts = [t for cid, t in fake.sent if cid == CHANNEL.id]
    assert len(channel_posts) == 1
    owner_msgs = [t for cid, t in fake.sent if cid == int(OWNER)]
    assert any("t.me/marin_thoughts/" in t for t in owner_msgs), owner_msgs
    assert tc.actions.pending_count() == 0
    # чат-модель получила факт публикации, а не просьбу подтвердить
    assert "УЖЕ выполнено" in CALLS["chat"][-1].situation_summary


def test_post_marker_from_model_publishes_once():
    tc, fake = make_client()
    tc._remember_own_channel(CHANNEL.id, title=CHANNEL.title, username=CHANNEL.username)
    CHAT_SCRIPT.append("ща порадую их<<<POST:что-нибудь тёплое>>><<<POST:дубль>>><<<MSG>>>готово")
    ev = Event("подписчики что-то заскучали", fake, int(OWNER))
    run(tc._process_batch([ev], chat=int(OWNER), chat_id=OWNER, sender_id=OWNER))
    assert len([1 for cid, _ in fake.sent if cid == CHANNEL.id]) == 1
    owner_msgs = [t for cid, t in fake.sent if cid == int(OWNER)]
    assert not any("<<<" in t for t in owner_msgs), owner_msgs


def test_action_to_own_channel_auto_runs_but_foreign_stays_draft():
    tc, fake = make_client()
    tc._remember_own_channel(CHANNEL.id, title=CHANNEL.title, username=CHANNEL.username)
    text = ('ок<<<ACTION:send_message|пост в канал|{"to": "marin_thoughts", "text": "короткая заметка"}>>>'
            '<<<ACTION:send_message|написать Пете|{"to": "someone_else", "text": "привет"}>>>')
    rest, results = run(tc._auto_execute_own_channel_actions(text))
    assert (CHANNEL.id, "короткая заметка") in fake.sent
    assert all(cid != OTHER.id for cid, _ in fake.sent)
    assert "someone_else" in rest and results and results[0].startswith("Готово")


def test_autopost_phrase_and_stop():
    tc, fake = make_client()
    tc._remember_own_channel(CHANNEL.id, title=CHANNEL.title, username=CHANNEL.username)
    ev = Event("веди канал сама, постить 2 раза в день", fake, int(OWNER))
    run(tc._process_batch([ev], chat=int(OWNER), chat_id=OWNER, sender_id=OWNER))
    e = tc._own_channels[str(CHANNEL.id)]
    assert e["autopost_enabled"] and e["autopost_interval"] == 43200
    ev = Event("перестань постить", fake, int(OWNER))
    run(tc._process_batch([ev], chat=int(OWNER), chat_id=OWNER, sender_id=OWNER))
    assert not e["autopost_enabled"]
