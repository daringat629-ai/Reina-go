"""Minimal offline stand-in for Telethon so the transport layer can be
imported and unit-tested without network / without the real package.

Only used when the real ``telethon`` is not importable. Every TL object is a
permissive record: ``types.Foo(a=1)`` just stores kwargs as attributes.
"""
from __future__ import annotations

import sys
import types as _pytypes


class _Record:
    def __init__(self, *args, **kwargs):
        self.args = args
        for k, v in kwargs.items():
            setattr(self, k, v)

    def __repr__(self):  # pragma: no cover - debug aid
        return f"{type(self).__name__}({self.__dict__})"


class _Namespace(_pytypes.ModuleType):
    """Any attribute access yields a new _Record subclass / sub-namespace."""

    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        if name[:1].isupper():
            cls = type(name, (_Record,), {})
        else:
            cls = _Namespace(f"{self.__name__}.{name}")
        setattr(self, name, cls)
        return cls


def install() -> bool:
    try:
        import telethon  # noqa: F401
        return False
    except ImportError:
        pass
    root = _pytypes.ModuleType("telethon")
    functions = _Namespace("telethon.functions")
    types = _Namespace("telethon.types")
    errors = _pytypes.ModuleType("telethon.errors")

    class SessionPasswordNeededError(Exception):
        pass

    class RPCError(Exception):
        pass

    errors.SessionPasswordNeededError = SessionPasswordNeededError
    errors.RPCError = RPCError

    events = _pytypes.ModuleType("telethon.events")

    class NewMessage:
        def __init__(self, *a, **kw):
            self.kw = kw

    events.NewMessage = NewMessage

    utils = _pytypes.ModuleType("telethon.utils")

    def get_peer_id(entity):
        return getattr(entity, "id", entity)

    utils.get_peer_id = get_peer_id

    class TelegramClient:
        def __init__(self, *a, **kw):
            pass

    root.TelegramClient = TelegramClient
    root.functions = functions
    root.types = types
    root.errors = errors
    root.events = events
    root.utils = utils
    tl = _pytypes.ModuleType("telethon.tl")
    tl.types = types
    tl.functions = functions
    for name, mod in {
        "telethon": root, "telethon.functions": functions, "telethon.types": types,
        "telethon.errors": errors, "telethon.events": events, "telethon.utils": utils,
        "telethon.tl": tl, "telethon.tl.types": types, "telethon.tl.functions": functions,
    }.items():
        sys.modules[name] = mod
    return True
