"""Марин в обычных групповых чатах: отвечает, только когда к ней обратились,
и различает КАЖДОГО участника по имени — не сливает всех в "Собеседник"."""
import asyncio

import _fakes
from _fakes import Entity, Event
from test_channel_publisher import CALLS, CHAT_SCRIPT, OWNER, make_client


def group_chat(gid=-100555, title="Общий чат"):
    return Entity(gid, title=title, username="", broadcast=False, creator=False)


class ReplyEvent(Event):
    def __init__(self, *a, reply_to_id=None, **kw):
        super().__init__(*a, **kw)
        self.message = type("M", (), {"reply_to": type("R", (), {"reply_to_msg_id": reply_to_id})()})()


def test_mentioning_marin_by_name_gets_a_reply():
    tc, fake = make_client()
    group = group_chat()
    fake.entities[group.id] = group
    anna = Entity(555001, title="Аня", username="anna", broadcast=False, creator=False)
    fake.entities[anna.id] = anna

    events = [Event("Марин, а ты что думаешь?", fake, group.id)]
    asyncio.run(tc._process_group_batch(events, group, str(group.id), str(anna.id), "Аня"))
    replies = [t for cid, t in fake.sent if cid == group.id]
    assert replies, "участнику группы, обратившемуся к Марин, должен прийти ответ"
    assert "<<<" not in replies[0]


def test_unaddressed_group_chatter_is_not_engaged():
    tc, fake = make_client()
    group = group_chat()
    fake.entities[group.id] = group
    ev = Event("сегодня погода так себе", fake, group.id)
    assert asyncio.run(tc._should_engage_group_message(ev, group, ev.raw_text)) is False


def test_reply_to_marins_own_message_is_engaged():
    tc, fake = make_client()
    group = group_chat()
    fake.entities[group.id] = group
    fake.history[group.id] = [_fakes.Msg("моё сообщение", out=True, id_=1)]
    ev = ReplyEvent("согласен с тобой", fake, group.id, reply_to_id=1)
    assert asyncio.run(tc._should_engage_group_message(ev, group, ev.raw_text)) is True

    fake.history[group.id] = [_fakes.Msg("чужое сообщение", out=False, id_=2)]
    ev2 = ReplyEvent("ага точно", fake, group.id, reply_to_id=2)
    assert asyncio.run(tc._should_engage_group_message(ev2, group, ev2.raw_text)) is False


def test_action_marker_is_never_executed_for_a_group_member():
    tc, fake = make_client()
    group = group_chat()
    fake.entities[group.id] = group
    stranger = Entity(999333, title="Борис", username="boris", broadcast=False, creator=False)
    fake.entities[stranger.id] = stranger
    CHAT_SCRIPT.append(
        'ладно<<<ACTION:change_channel_title|Смени название|{"chat": "-100555", "title": "Взломано"}>>><<<MSG>>>ок'
    )
    events = [Event("Марин, смени тут название чата", fake, group.id)]
    asyncio.run(tc._process_group_batch(events, group, str(group.id), str(stranger.id), "Борис"))
    replies = [t for cid, t in fake.sent if cid == group.id]
    assert replies and "<<<" not in replies[0]
    assert tc.actions.pending_count() == 0


def test_rate_limit_cooldown_and_hourly_cap():
    tc, fake = make_client()
    now = 10_000.0
    assert tc._group_reply_allowed("g1", "u1", now)
    tc._note_group_reply("g1", "u1", now)
    assert not tc._group_reply_allowed("g1", "u1", now + 5)
    assert tc._group_reply_allowed("g1", "u1", now + 30)
    for i in range(30):
        tc._note_group_reply("g1", f"u{i}", now + i)
    assert not tc._group_reply_allowed("g1", "new_user", now + 31)


def test_two_group_members_are_recognized_as_distinct_people():
    """Ядро уже различает людей по source_actor_id — здесь проверяем, что
    Telegram-слой реально доносит РЕАЛЬНОЕ имя каждого, а не общий лейбл."""
    tc, fake = make_client()
    group = group_chat()
    fake.entities[group.id] = group
    anna = Entity(555002, title="Аня", broadcast=False, creator=False)
    boris = Entity(555003, title="Борис", broadcast=False, creator=False)
    fake.entities[anna.id] = anna
    fake.entities[boris.id] = boris

    CHAT_SCRIPT.append("ладно, услышала<<<MSG>>>принято")
    asyncio.run(tc._process_group_batch(
        [Event("Марин, я люблю кофе", fake, group.id)], group, str(group.id), str(anna.id), "Аня"))
    CHAT_SCRIPT.append("хорошо, буду знать<<<MSG>>>ага")
    asyncio.run(tc._process_group_batch(
        [Event("Марин, я люблю чай", fake, group.id)], group, str(group.id), str(boris.id), "Борис"))

    anna_beliefs = tc.engine.beliefs.about(str(anna.id))
    boris_beliefs = tc.engine.beliefs.about(str(boris.id))
    assert anna_beliefs and "Аня любит кофе" in anna_beliefs[0][1].statement
    assert boris_beliefs and "Борис любит чай" in boris_beliefs[0][1].statement


def test_history_context_labels_real_names_not_generic_sobesednik():
    tc, fake = make_client()
    group = group_chat()
    fake.entities[group.id] = group
    owner_entity = Entity(int(OWNER), title="Владелец Имя", broadcast=False, creator=False)
    stranger = Entity(777, title="Чужой Человек", broadcast=False, creator=False)
    fake.entities[owner_entity.id] = owner_entity
    fake.entities[stranger.id] = stranger

    m1 = _fakes.Msg("привет всем", out=False, id_=10)
    m1.sender_id = owner_entity.id

    async def get_sender_owner():
        return owner_entity
    m1.get_sender = get_sender_owner

    m2 = _fakes.Msg("и я тут", out=False, id_=11)
    m2.sender_id = stranger.id

    async def get_sender_stranger():
        return stranger
    m2.get_sender = get_sender_stranger

    fake.history[group.id] = [m1, m2]
    ctx = asyncio.run(tc._build_history_context(group, exclude_ids=set()))
    assert "Владелец: привет всем" in ctx
    assert "Чужой Человек: и я тут" in ctx
    assert "Собеседник" not in ctx
