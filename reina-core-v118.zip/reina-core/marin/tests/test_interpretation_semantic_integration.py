
from marin_core.interpretation.engine import InterpretationEngine, InterpretationContext
from marin_core.perception.perception import Observation, Modality
from marin_core.perception.situation import SituationModel, ActionType, Tone


def test_interpretation_contains_semantic_layer():
    text = "Завтра сделай это, а потом скажи, что получилось"
    obs = Observation(Modality.TEXT, text, "u1", "c1", 1759140000.0, {"now": "2026-09-29T10:00:00+00:00"})
    situation = SituationModel(
        actor_id="u1", action=ActionType.REQUEST, raw_text=text,
        tone=Tone(), embedding=None,
    )
    result = InterpretationEngine().interpret(
        obs, situation,
        InterpretationContext(
            actor_id="u1",
            actor_label="Аня",
            world_continuity="вчера обсуждали отчёт",
        ),
    )
    assert result.semantic.temporal
    assert len(result.semantic.clauses) == 2
    assert "request" in result.semantic.clause_intents
    assert "semantic:" in result.summary_for_llm()
