"""Самонаблюдение + подстройка в рамках (telegram/self_awareness.py)."""
import asyncio
import os
from collections import Counter
from types import SimpleNamespace

import _fakes  # noqa: F401
from _fakes import Event
from test_channel_publisher import CALLS, CHAT_SCRIPT, OWNER, make_client

from marin_core.env import clear_all_overrides
from marin_core.telegram.self_awareness import SelfTuning, extract_tune_markers


def _tuning(tmp_path, **env):
    for k, v in env.items():
        os.environ[k] = str(v)
    return SelfTuning(str(tmp_path / "tuning.json"))


# ------------------------------------------------------------- рамки
def test_self_change_is_bounded_by_step_and_limits(tmp_path):
    try:
        t = _tuning(tmp_path, MARIN_SELF_TUNING_COOLDOWN_HOURS=0)
        ok, msg = t.propose("bubble_length", "10", by="self")   # хочет 10, шаг ≤20 от 70
        assert ok and t.current("bubble_length") == 50, msg
        ok, _ = t.propose("bubble_length", "10", by="self")
        assert ok and t.current("bubble_length") == 40         # нижняя граница 40, не 30
        ok, msg = t.propose("bubble_length", "-5", by="self")
        assert not ok and "и так" in msg                        # ниже границы не уйти
        ok, _ = t.propose("sticker_frequency", "редко", by="self")
        assert ok and t.current("sticker_frequency") == "normal"  # на одну ступень за раз
    finally:
        clear_all_overrides()


def test_only_whitelisted_knobs_can_change(tmp_path):
    try:
        t = _tuning(tmp_path)
        for forbidden in ("quality_gate", "MARIN_QUALITY_GATE_ENABLED", "confirmations", "owner_id"):
            ok, msg = t.propose(forbidden, "0", by="self")
            assert not ok and "нет" in msg, forbidden
    finally:
        clear_all_overrides()


def test_cooldown_daily_cap_and_owner_switch(tmp_path):
    try:
        t = _tuning(tmp_path, MARIN_SELF_TUNING_COOLDOWN_HOURS=2, MARIN_SELF_TUNING_MAX_PER_DAY=6)
        assert t.propose("bubble_length", "60", by="self")[0]
        ok, msg = t.propose("bubble_length", "50", by="self")
        assert not ok and "недавно" in msg                     # пауза между своими изменениями
        assert t.propose("bubble_length", "40", by="owner")[0]  # владельцу пауза не мешает
        t.set_enabled(False)
        ok, msg = t.propose("proactive_per_day", "2", by="self")
        assert not ok and "выключена" in msg
        assert t.propose("proactive_per_day", "2", by="owner")[0]
    finally:
        clear_all_overrides()


def test_undo_reset_and_env_file_untouched(tmp_path):
    try:
        os.environ["MARIN_TELEGRAM_BUBBLE_MAX_CHARS"] = "70"
        t = _tuning(tmp_path, MARIN_SELF_TUNING_COOLDOWN_HOURS=0)
        t.propose("bubble_length", "50", by="self")
        assert os.environ["MARIN_TELEGRAM_BUBBLE_MAX_CHARS"] == "70"   # .env/окружение не тронуты
        assert "70" in t.undo_last() and t.current("bubble_length") == 70
        t.propose("proactive_silence_hours", "8", by="self")
        t.reset()
        assert t.current("proactive_silence_hours") == 5 and not t.values
    finally:
        clear_all_overrides()


def test_tuning_survives_restart(tmp_path):
    try:
        t = _tuning(tmp_path, MARIN_SELF_TUNING_COOLDOWN_HOURS=0)
        t.propose("bubble_length", "55", by="self")
        clear_all_overrides()                                    # «рестарт процесса»
        t2 = SelfTuning(str(tmp_path / "tuning.json"))
        t2.apply_all()
        from marin_core.telegram.settings import bubble_max_chars
        assert bubble_max_chars() == 55 and len(t2.history) == 1
    finally:
        clear_all_overrides()


# ---------------------------------------- подстройка реально меняет поведение
def test_tuning_changes_real_behaviour(tmp_path):
    try:
        t = _tuning(tmp_path, MARIN_SELF_TUNING_COOLDOWN_HOURS=0)
        from marin_core.llm.providers import _media_frequency_rule
        from marin_core.telegram.proactive import _env_float
        from marin_core.telegram.settings import bubble_max_chars
        t.propose("bubble_length", "50", by="self")
        t.propose("sticker_frequency", "normal", by="self")
        t.propose("proactive_per_day", "2", by="self")
        assert bubble_max_chars() == 50
        assert "every third" in _media_frequency_rule()
        assert _env_float("MARIN_PROACTIVE_MAX_PER_DAY", 4) == 2
    finally:
        clear_all_overrides()


def test_tune_markers_are_applied_and_removed(tmp_path):
    try:
        t = _tuning(tmp_path, MARIN_SELF_TUNING_COOLDOWN_HOURS=0)
        text, notes = extract_tune_markers(
            "ок, буду короче\n<<<TUNE:bubble_length|-20|он просит короче>>>\n<<<TUNE:admin_rights|1|хочу>>>", t)
        assert "<<<" not in text and text == "ок, буду короче"
        assert any("подстроила себя" in n and "70 → 50" in n for n in notes)
        assert any("не стала менять себя" in n for n in notes)
    finally:
        clear_all_overrides()


# ---------------------------------------------------------- самонаблюдение
def test_report_uses_real_state_not_guesses(tmp_path, monkeypatch):
    monkeypatch.setenv("MARIN_SELF_TUNING_FILE", str(tmp_path / "t.json"))
    try:
        tc, _ = make_client()
        gid = tc.goal_executor.create_goal_from_description("Хочу написать пост про осень", OWNER,
                                                            context={"self_initiated": True})
        goal = next(g for g in tc.engine.goal_set.autonomous_goals(owner_id=OWNER) if g.id == gid)
        goal.last_result = "в команде не хватило данных"
        tc._note_action_outcome("пост в канал", "Не получилось опубликовать")
        tc.engine.language_planner.provider.stats = {
            "generations": 12, "clean": 9, "retried": 3, "recovered": 3, "kept_flawed": 0, "failed": 0,
            "reasons": Counter({"masculine_self": 2, "meta_narration": 1})}
        report = tc.self_model.report()
        assert "Хочу написать пост про осень" in report and "(моя идея)" in report
        assert "не хватило данных" in report and "Не получилось опубликовать" in report
        assert "пришлось переписывать: 3" in report and "мужском роде ×2" in report
        assert "bubble_length: 70" in report
    finally:
        clear_all_overrides()


def test_prompt_hint_only_when_relevant(tmp_path, monkeypatch):
    monkeypatch.setenv("MARIN_SELF_TUNING_FILE", str(tmp_path / "t.json"))
    try:
        tc, _ = make_client()
        assert "Самонаблюдение" in tc.self_model.prompt_hint("ну что, получилось с постом?")
        assert "<<<TUNE:" in tc.self_model.prompt_hint("пиши покороче")
        assert tc.self_model.prompt_hint("смотри какой котик") == ""
    finally:
        clear_all_overrides()


# ------------------------------------------------------------- сквозные
def test_owner_sees_self_tuning_and_marker_never_leaks(tmp_path, monkeypatch):
    monkeypatch.setenv("MARIN_SELF_TUNING_FILE", str(tmp_path / "t.json"))
    monkeypatch.setenv("MARIN_SELF_TUNING_COOLDOWN_HOURS", "0")
    try:
        tc, fake = make_client()
        CHAT_SCRIPT.append("ок, буду покороче<<<TUNE:bubble_length|-20|он просит писать короче>>>")
        ev = Event("пиши покороче", fake, int(OWNER))
        asyncio.run(tc._process_batch([ev], chat=int(OWNER), chat_id=OWNER, sender_id=OWNER))
        sent = [t for cid, t in fake.sent if cid == int(OWNER)]
        assert not any("TUNE" in t or "<<<" in t for t in sent), sent
        assert any("подстроила себя" in t and "70 → 50" in t for t in sent), sent
        assert tc.self_tuning.current("bubble_length") == 50
        # следующий вопрос о себе — модель видит правду о своей настройке
        CHAT_SCRIPT.append("ага")
        ev2 = Event("как ты, что поменяла в себе?", fake, int(OWNER))
        asyncio.run(tc._process_batch([ev2], chat=int(OWNER), chat_id=OWNER, sender_id=OWNER))
        assert "bubble_length: 50 (в .env: 70)" in CALLS["chat"][-1].situation_summary
    finally:
        clear_all_overrides()


def test_owner_commands(tmp_path, monkeypatch):
    monkeypatch.setenv("MARIN_SELF_TUNING_FILE", str(tmp_path / "t.json"))
    try:
        tc, fake = make_client()

        def cmd(text):
            ev = Event(text, fake, int(OWNER))
            assert asyncio.run(tc._handle_self_commands(ev, text)) is True
            return ev.replies[-1]

        assert "bubble_length" in cmd(".настройки")
        assert "70 → 45" in cmd(".настройки длина 45")
        assert "70" in cmd(".настройки откат")
        assert "выключена" in cmd(".настройки стоп")
        assert "Мои цели" in cmd(".я")
        assert asyncio.run(tc._handle_self_commands(SimpleNamespace(), "привет")) is False
    finally:
        clear_all_overrides()
