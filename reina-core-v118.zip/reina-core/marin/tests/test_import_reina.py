import os
import sys
import textwrap

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import import_reina as ir  # noqa: E402

CFG = textwrap.dedent('''
    [general]
    papik_chat_id = 4242424242
    [telegram]
    api_id = 12345
    api_hash = "abcdef0123456789"
    [llm]
    base_url = "https://api.inceptionlabs.ai/v1/"
    api_key = "SECRET-KEY-VALUE"
    model = "mercury-3"
    fast_model = "mercury-3"
    fallback_model = "mercury-2.5"
    embedding_base_url = "http://127.0.0.1:8081/v1/"
    embedding_model = "nomic-embed-text"
''')


def _cfg(tmp_path):
    p = tmp_path / "config.toml"
    p.write_text(CFG, encoding="utf-8")
    return ir.load_toml(str(p))


def test_settings_carry_the_keys_and_switch_off_vision_on_a_text_only_endpoint(tmp_path):
    s = ir.settings_from_reina(_cfg(tmp_path), "+996700000000")
    assert s["TELEGRAM_API_ID"] == "12345" and s["MARIN_TELEGRAM_API_HASH"] == "abcdef0123456789"
    assert s["MARIN_OWNER_ID"] == "4242424242" and s["TELEGRAM_PHONE"] == "+996700000000"
    assert s["MARIN_OPENROUTER_BASE_URL"] == "https://api.inceptionlabs.ai/v1"  # no trailing slash
    assert s["MARIN_OPENROUTER_API_KEY"] == "SECRET-KEY-VALUE" and s["MARIN_OPENROUTER_MODEL"] == "mercury-3"
    assert s["MARIN_OPENROUTER_FALLBACK_MODEL"] == "mercury-2.5"
    assert s["MARIN_EMBEDDING_PROVIDER"] == "openai_compat" and s["MARIN_EMBEDDING_BASE_URL"].endswith(":8081/v1")
    assert s["MARIN_SELFIE_ENABLED"] == "false" and s["MARIN_VISION_ENABLED"] == "false"


def test_fallback_on_another_endpoint_is_dropped_and_openrouter_keeps_vision(tmp_path):
    cfg = _cfg(tmp_path)
    cfg["llm"]["fallback_base_url"] = "https://openrouter.ai/api/v1"
    assert ir.settings_from_reina(cfg)["MARIN_OPENROUTER_FALLBACK_MODEL"] == ""
    cfg["llm"]["base_url"] = "https://openrouter.ai/api/v1/"
    assert "MARIN_SELFIE_ENABLED" not in ir.settings_from_reina(cfg)


def test_apply_env_replaces_and_appends_without_printing_secrets(tmp_path):
    out = ir.apply_env("A=1\nTELEGRAM_API_ID=\n# c\nB=2\n", {"TELEGRAM_API_ID": "99", "NEW": "x"})
    assert "TELEGRAM_API_ID=99" in out and "A=1" in out and out.rstrip().endswith("NEW=x")


def test_main_writes_private_env_and_refuses_to_overwrite(tmp_path, monkeypatch, capsys):
    p = tmp_path / "config.toml"
    p.write_text(CFG, encoding="utf-8")
    monkeypatch.setattr(ir, "HERE", str(tmp_path))
    (tmp_path / ".env.example").write_text("TELEGRAM_API_ID=\nMARIN_OPENROUTER_API_KEY=\n", encoding="utf-8")
    assert ir.main([str(p), "--phone", "+996700000000"]) == 0
    text = (tmp_path / ".env").read_text(encoding="utf-8")
    assert "MARIN_OPENROUTER_API_KEY=SECRET-KEY-VALUE" in text
    assert oct((tmp_path / ".env").stat().st_mode & 0o777) == "0o600"
    printed = capsys.readouterr().out
    assert "SECRET-KEY-VALUE" not in printed and "abcdef0123456789" not in printed
    assert ir.main([str(p)]) == 2  # does not overwrite without --force
