import time

from marin_core.memory import MemoryGraph, MemoryNode, NodeType, RelationType, prune_memory
from marin_core.numeric import np

DAY = 24 * 3600.0


def _node(age_days, importance=0.0, **kw):
    now = time.time()
    n = MemoryNode(type=kw.pop("type", NodeType.EVENT), embedding=np.array([1.0, 0.0]),
                   importance=importance, **kw)
    n.t_created = n.t_last_access = now - age_days * DAY
    return n


def test_faded_old_nodes_are_forgotten_but_recent_pinned_and_important_stay():
    g = MemoryGraph()
    old = g.add_node(_node(60))
    recent = g.add_node(_node(1))
    pinned = g.add_node(_node(90, payload={"pinned": True}))
    important = g.add_node(_node(60, importance=0.9))
    rep = prune_memory(g, max_nodes=1000)
    assert g.peek(old) is None
    assert g.peek(recent) and g.peek(pinned) and g.peek(important)
    assert rep.removed_faded == 1


def test_cap_removes_weakest_first_and_cleans_edges():
    g = MemoryGraph()
    keep = _node(30, importance=0.9)
    weak = _node(30, importance=0.1)
    g.add_node(keep); g.add_node(weak)
    g.add_edge(keep.id, RelationType.PRECEDES, weak.id)
    rep = prune_memory(g, max_nodes=1, fade_threshold=0.0)
    assert g.peek(keep.id) and g.peek(weak.id) is None
    assert rep.dangling_edges == 1 and keep.edges == []


def test_owner_memories_fade_slower_and_reflections_are_capped():
    g = MemoryGraph()
    now = time.time()
    # у владельца importance чуть выше порога только благодаря бонусу
    owner = _node(40, importance=0.0, payload={"situation": {"is_owner": True}})
    other = _node(40, importance=0.0)
    g.add_node(owner); g.add_node(other)
    for i in range(60):
        r = _node(i * 0.01, type=NodeType.REFLECTION); g.add_node(r)
    rep = prune_memory(g, max_nodes=1000, fade_threshold=0.005)
    assert g.peek(owner.id) is not None and g.peek(other.id) is None
    assert len(g.all_nodes(NodeType.REFLECTION)) == 50 and rep.removed_reflections == 10
