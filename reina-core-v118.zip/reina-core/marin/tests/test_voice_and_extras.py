"""Голос через OpenRouter, распознавание голосовых, ответ голосом, 🎲 и истории."""
import asyncio
import base64
import sys
import types as pytypes
from types import SimpleNamespace

import _fakes  # noqa: F401
from _fakes import Event
from test_channel_publisher import CALLS, CHAT_SCRIPT, OWNER, make_client

from marin_core.telegram import voice as voice_mod


class _Resp:
    def __init__(self, content=b"", data=None):
        self.content, self._data = content, data

    def raise_for_status(self):
        pass

    def json(self):
        return self._data


def _fake_requests(monkeypatch, resp):
    sent = {}

    def post(url, json=None, headers=None, timeout=None):
        sent.update(url=url, json=json, headers=headers)
        return resp

    monkeypatch.setitem(sys.modules, "requests", pytypes.SimpleNamespace(post=post))
    return sent


# ---------------------------------------------------------------- OpenRouter
def test_openrouter_tts_request_matches_the_docs(monkeypatch):
    sent = _fake_requests(monkeypatch, _Resp(content=b"MP3"))

    async def to_ogg(mp3):
        return b"OGG"

    monkeypatch.setattr(voice_mod, "_mp3_to_ogg_opus", to_ogg)
    gen = voice_mod.OpenRouterVoiceGenerator(voice_mod.OpenRouterVoiceConfig(api_key="k", voice="nova", model="openai/gpt-4o-mini-tts-2025-12-15"))
    res = asyncio.run(gen.generate("привет, любимый"))
    assert sent["url"].endswith("/audio/speech")
    body = sent["json"]
    assert body["input"] == "привет, любимый" and body["voice"] == "nova" and body["response_format"] == "mp3"
    assert "instructions" in body["provider"]["options"]["openai"]
    assert res.is_voice_note and res.audio_bytes == b"OGG" and res.ext == ".ogg"


def test_openrouter_tts_without_ffmpeg_sends_plain_audio(monkeypatch):
    _fake_requests(monkeypatch, _Resp(content=b"MP3"))

    async def no_ffmpeg(mp3):
        return None

    monkeypatch.setattr(voice_mod, "_mp3_to_ogg_opus", no_ffmpeg)
    res = asyncio.run(voice_mod.OpenRouterVoiceGenerator(voice_mod.OpenRouterVoiceConfig(api_key="k", model="openai/gpt-4o-mini-tts-2025-12-15")).generate("да"))
    assert not res.is_voice_note and res.ext == ".mp3"


def test_openrouter_transcription_request_matches_the_docs(monkeypatch):
    sent = _fake_requests(monkeypatch, _Resp(data={"text": " привет, как дела? "}))
    tr = voice_mod.OpenRouterTranscriber(voice_mod.OpenRouterTranscriberConfig(api_key="k"))
    text = asyncio.run(tr.transcribe(b"OGGDATA", "ogg"))
    assert sent["url"].endswith("/audio/transcriptions")
    ia = sent["json"]["input_audio"]
    assert ia["format"] == "ogg" and base64.b64decode(ia["data"]) == b"OGGDATA"
    assert sent["json"]["language"] == "ru" and sent["json"]["model"] == "openai/whisper-large-v3"
    assert text == "привет, как дела?"


def test_voice_provider_choice(monkeypatch):
    import marin_core.telegram.media as media
    monkeypatch.setattr(media, "VOICE_ENABLED", True)
    monkeypatch.setenv("MARIN_OPENROUTER_API_KEY", "or-key")
    monkeypatch.setenv("MARIN_ELEVENLABS_API_KEY", "el-key")
    monkeypatch.setenv("MARIN_VOICE_ID", "v1")
    for provider, expected in (("openrouter", "FallbackVoiceGenerator"), ("auto", "ElevenLabsVoiceGenerator"),
                               ("elevenlabs", "ElevenLabsVoiceGenerator")):
        monkeypatch.setenv("MARIN_VOICE_PROVIDER", provider)
        tc, _ = make_client()
        tc._voice_generator = None
        assert type(tc._get_voice_generator()).__name__ == expected, provider
    monkeypatch.setenv("MARIN_VOICE_ID", "")  # не delenv: клиент подгружает .env и заполнит заново
    monkeypatch.setenv("MARIN_VOICE_PROVIDER", "auto")
    tc, _ = make_client()
    tc._voice_generator = None
    assert type(tc._get_voice_generator()).__name__ == "OpenRouterVoiceGenerator"  # нет ElevenLabs — OpenRouter


# ---------------------------------------------------------- голосовые входящие
class _Transcriber:
    def __init__(self, text):
        self.text, self.calls = text, []

    async def transcribe(self, audio, fmt="ogg"):
        self.calls.append((audio, fmt))
        return self.text


def test_voice_message_is_transcribed_and_understood():
    tc, fake = make_client()
    tr = _Transcriber("привет, как прошёл день?")
    tc._get_transcriber = lambda: tr

    async def download_media(msg, file=None):
        return b"OGGVOICE"

    fake.download_media = download_media
    ev = Event("", fake, int(OWNER))
    ev.message = SimpleNamespace(voice=True, document=SimpleNamespace(size=1000, mime_type="audio/ogg"))
    text = asyncio.run(tc._transcribe_event(ev))
    assert text == "привет, как прошёл день?" and tr.calls == [(b"OGGVOICE", "ogg")]
    ev._marin_transcript = text
    CHAT_SCRIPT.append("отлично)")
    asyncio.run(tc._process_batch([ev], chat=int(OWNER), chat_id=OWNER, sender_id=OWNER))
    assert "[голосовое] привет, как прошёл день?" in CALLS["chat"][-1].situation_summary


def test_text_messages_are_not_sent_to_transcription():
    tc, fake = make_client()
    ev = Event("просто текст", fake, int(OWNER))
    ev.message = SimpleNamespace(voice=None, audio=None, video_note=None)
    assert asyncio.run(tc._transcribe_event(ev)) == ""


def _voice_setup(monkeypatch, chance):
    monkeypatch.setenv("MARIN_VOICE_REPLY_CHANCE", str(chance))
    tc, fake = make_client()
    files = []

    class Gen:
        async def generate(self, text):
            return voice_mod.VoiceResult(audio_bytes=b"OGG:" + text.encode(), is_voice_note=True, ext=".ogg")

    async def upload_file(data, file_name=None):
        return data

    async def send_file(entity, file, **kw):
        files.append((file, kw))

    tc._get_voice_generator = lambda: Gen()
    fake.upload_file, fake.send_file = upload_file, send_file
    ev = Event("", fake, int(OWNER))
    ev._marin_transcript = "ты где?"
    return tc, fake, files, ev


def test_she_can_answer_a_voice_message_with_voice(monkeypatch):
    tc, fake, files, ev = _voice_setup(monkeypatch, 1.0)
    CHAT_SCRIPT.append("да тут я)<<<MSG>>>дома сижу")
    asyncio.run(tc._process_batch([ev], chat=int(OWNER), chat_id=OWNER, sender_id=OWNER))
    assert files and files[0][1].get("voice_note") is True
    assert files[0][0] == "OGG:да тут я) дома сижу".encode()
    assert not [t for cid, t in fake.sent if cid == int(OWNER)]      # текстом не дублирует


def test_voice_reply_is_optional(monkeypatch):
    tc, fake, files, ev = _voice_setup(monkeypatch, 0.0)
    CHAT_SCRIPT.append("да тут я)")
    asyncio.run(tc._process_batch([ev], chat=int(OWNER), chat_id=OWNER, sender_id=OWNER))
    assert not files and [t for cid, t in fake.sent if cid == int(OWNER)] == ["да тут я)"]


def test_owner_messages_are_marked_read():
    tc, fake = make_client()
    reads = []

    async def ack(chat, max_id=None, **kw):
        reads.append(max_id)

    fake.send_read_acknowledge = ack
    ev = Event("привет", fake, int(OWNER))
    CHAT_SCRIPT.append("привет)")
    asyncio.run(tc._process_batch([ev], chat=int(OWNER), chat_id=OWNER, sender_id=OWNER))
    assert reads == [ev.id]


# ------------------------------------------------------------ новые действия
def _run_action(tc, kind, payload):
    import json
    from marin_core.telegram.actions import PendingAction
    handler = tc.actions._handlers[kind]
    return asyncio.run(handler(PendingAction(kind, kind, json.dumps(payload))))


def test_send_dice():
    tc, fake = make_client()
    sent = []

    async def resolve(x):
        return SimpleNamespace(id=777)

    async def send_message(entity, text="", file=None, **kw):
        sent.append(file)

    tc._resolve_peer, fake.send_message = resolve, send_message
    assert _run_action(tc, "send_dice", {"chat": 777, "emoji": "🎯"}).startswith("Готово")
    assert getattr(sent[0], "emoticon", None) == "🎯"
    assert "нет" in _run_action(tc, "send_dice", {"chat": 777, "emoji": "🍕"})


def test_post_story_sends_a_24h_story_with_a_selfie(monkeypatch, tmp_path):
    monkeypatch.setenv("MARIN_SELFIE_STATE_FILE", str(tmp_path / "s.json"))
    tc, fake = make_client()
    requests_sent = []

    class Gen:
        async def generate(self, prompt, reference_image_b64=None):
            return b"IMG"

    async def scene_for(text, hint=""):
        return "at home by the window"

    async def upload_file(data, file_name=None):
        return data

    async def call(request):
        requests_sent.append(request)

    tc._get_selfie_generator = lambda: Gen()
    tc._get_selfie_reference = lambda: "QUJD"
    tc.selfie_director.scene_for = scene_for
    fake.upload_file = upload_file
    fake.__call__ = call
    monkeypatch.setattr(type(fake), "__call__", lambda self, req: call(req))
    res = _run_action(tc, "post_story", {"caption": "доброе утро)"})
    assert res.startswith("Готово"), res
    req = requests_sent[-1]
    assert getattr(req, "period", None) == 86400 and getattr(req, "caption", None) == "доброе утро)"


def test_model_knows_about_new_actions():
    import inspect
    import marin_core.llm.providers as prov
    src = inspect.getsource(prov)
    assert "send_dice:" in src and "post_story:" in src



# ------------------------------------------------- лог сервера 27.09: TTS 400
class _HTTP:
    def __init__(self, status, content=b"", text=""):
        self.status_code, self.content, self.text = status, content, text

    def raise_for_status(self):
        if self.status_code >= 400:
            raise RuntimeError(f"{self.status_code} Client Error")

    def json(self):
        return {}


def _sequence_requests(monkeypatch, responses):
    bodies = []

    def post(url, json=None, headers=None, timeout=None):
        bodies.append(json)
        return responses.pop(0)

    monkeypatch.setitem(sys.modules, "requests", pytypes.SimpleNamespace(post=post))
    return bodies


def test_tts_400_is_retried_without_provider_options(monkeypatch):
    bodies = _sequence_requests(monkeypatch, [
        _HTTP(400, text='{"error":{"message":"Unsupported parameter: provider.options"}}'),
        _HTTP(200, content=b"MP3")])

    async def to_ogg(mp3):
        return b"OGG"

    monkeypatch.setattr(voice_mod, "_mp3_to_ogg_opus", to_ogg)
    res = asyncio.run(voice_mod.OpenRouterVoiceGenerator(voice_mod.OpenRouterVoiceConfig(api_key="k", model="openai/gpt-4o-mini-tts-2025-12-15")).generate("привет"))
    assert res.audio_bytes == b"OGG"
    assert "provider" in bodies[0] and "provider" not in bodies[1]


def test_tts_error_reason_is_visible(monkeypatch):
    _sequence_requests(monkeypatch, [_HTTP(400, text='{"error":{"message":"voice not found"}}'),
                                     _HTTP(400, text='{"error":{"message":"voice not found"}}')])
    try:
        asyncio.run(voice_mod.OpenRouterVoiceGenerator(voice_mod.OpenRouterVoiceConfig(api_key="k")).generate("да"))
    except voice_mod.VoiceGenerationError as e:
        assert "voice not found" in str(e), str(e)
    else:
        raise AssertionError("ошибка не поднялась")


def test_voice_falls_back_to_elevenlabs_when_openrouter_fails():
    class Bad:
        async def generate(self, text):
            raise voice_mod.VoiceGenerationError("OpenRouter TTS недоступен: HTTP 400")

    class Good:
        async def generate(self, text):
            return voice_mod.VoiceResult(audio_bytes=b"EL", is_voice_note=True, ext=".ogg")

    res = asyncio.run(voice_mod.FallbackVoiceGenerator([Bad(), Good()]).generate("привет"))
    assert res.audio_bytes == b"EL"
    try:
        asyncio.run(voice_mod.FallbackVoiceGenerator([Bad()]).generate("привет"))
    except voice_mod.VoiceGenerationError as e:
        assert "HTTP 400" in str(e)



# ------------------------------------------ лог 27.09 04:22: модели TTS «не существует»
def _requests_with_catalog(monkeypatch, posts, catalog):
    bodies, gets = [], []

    def post(url, json=None, headers=None, timeout=None):
        bodies.append(json)
        return posts.pop(0)

    def get(url, params=None, headers=None, timeout=None):
        gets.append((url, params))
        return _HTTP(200, text="", content=b"") if catalog is None else _Catalog(catalog)

    monkeypatch.setitem(sys.modules, "requests", pytypes.SimpleNamespace(post=post, get=get))
    return bodies, gets


class _Catalog:
    status_code = 200

    def __init__(self, data):
        self._data = {"data": data}

    def raise_for_status(self):
        pass

    def json(self):
        return self._data


def _patch_pcm(monkeypatch):
    async def to_ogg(pcm, rate=24000):
        return b"OGG:" + pcm
    monkeypatch.setattr(voice_mod, "_pcm_to_ogg_opus", to_ogg)


def test_gemini_tts_request_uses_pcm_leda_and_style(monkeypatch):
    _patch_pcm(monkeypatch)
    bodies, _ = _requests_with_catalog(monkeypatch, [_HTTP(200, content=b"PCM")], [])
    res = asyncio.run(voice_mod.OpenRouterVoiceGenerator(voice_mod.OpenRouterVoiceConfig(
        api_key="k", model="google/gemini-3.1-flash-tts-preview", voice="eve")).generate("привет"))
    body = bodies[0]
    assert body["model"] == "google/gemini-3.1-flash-tts-preview"
    assert body["response_format"] == "pcm" and body["voice"] == "Leda"
    assert "speech_metadata" in body["provider"]["options"]["google-ai-studio"]
    assert res.is_voice_note and res.audio_bytes == b"OGG:PCM"


def test_missing_tts_model_is_replaced_from_the_catalog(monkeypatch):
    _patch_pcm(monkeypatch)
    missing = _HTTP(400, text='{"error":{"message":"Model openai/gpt-4o-mini-tts-2025-12-15 does not exist","code":400}}')
    bodies, gets = _requests_with_catalog(monkeypatch, [missing, _HTTP(200, content=b"PCM")], [
        {"id": "mistralai/voxtral-mini-tts-2603", "supported_voices": ["en_paul_neutral"]},
        {"id": "google/gemini-3.8-flash-lite-tts", "supported_voices": ["Kore", "Leda", "Puck"]},
    ])
    gen = voice_mod.OpenRouterVoiceGenerator(voice_mod.OpenRouterVoiceConfig(
        api_key="k", model="openai/gpt-4o-mini-tts-2025-12-15", voice="nova"))
    res = asyncio.run(gen.generate("привет"))
    assert gets and gets[0][1] == {"output_modalities": "speech"}
    assert bodies[1]["model"] == "google/gemini-3.8-flash-lite-tts" and bodies[1]["voice"] == "Leda"
    assert gen.model == "google/gemini-3.8-flash-lite-tts" and res.audio_bytes == b"OGG:PCM"


def test_voice_matches_the_model_family():
    assert voice_mod._voice_for("google/gemini-3.1-flash-tts-preview", "nova") == "Leda"
    assert voice_mod._voice_for("openai/gpt-4o-mini-tts", "Leda") == "nova"
    assert voice_mod._voice_for("google/gemini-3.1-flash-tts-preview", "Zephyr") == "Zephyr"


def test_rejected_key_is_not_retried_every_time():
    calls = []

    class Unauthorized:
        async def generate(self, text):
            calls.append("el")
            raise voice_mod.VoiceGenerationError("ElevenLabs API недоступен: 401 Client Error: Unauthorized")

    class Good:
        async def generate(self, text):
            return voice_mod.VoiceResult(audio_bytes=b"OK", is_voice_note=True, ext=".ogg")

    gen = voice_mod.FallbackVoiceGenerator([Unauthorized(), Good()])
    asyncio.run(gen.generate("раз"))
    asyncio.run(gen.generate("два"))
    assert calls == ["el"]                       # второй раз сломанный ключ не дёргаем


def test_voice_failure_is_told_like_a_human():
    """В чат ушло «OpenRouterVoiceGenerator: … HTTP 400: {"error": …}»."""
    tc, _ = make_client()

    async def resolve(x):
        return SimpleNamespace(id=1)

    class Broken:
        async def generate(self, text):
            raise voice_mod.VoiceGenerationError('OpenRouter TTS недоступен: HTTP 400: {"error": "x"}')

    tc._resolve_peer = resolve
    tc._get_voice_generator = lambda: Broken()
    res = _run_action(tc, "send_voice_message", {"chat": 1, "text": "привет"})
    assert "HTTP" not in res and "{" not in res and "голосовое" in res, res



# -------------------------------------------------- голос Grok (выбор владельца)
def test_grok_female_voice_is_the_default(monkeypatch):
    bodies, _ = _requests_with_catalog(monkeypatch, [_HTTP(200, content=b"MP3")], [])

    async def to_ogg(mp3):
        return b"OGG"

    monkeypatch.setattr(voice_mod, "_mp3_to_ogg_opus", to_ogg)
    res = asyncio.run(voice_mod.OpenRouterVoiceGenerator(voice_mod.OpenRouterVoiceConfig(api_key="k")).generate("привет"))
    body = bodies[0]
    assert body["model"] == "x-ai/grok-voice-tts-1.0" and body["voice"] == "eve"
    assert body["response_format"] == "mp3" and "provider" not in body
    assert res.is_voice_note


def test_grok_and_gemini_voices_never_mix():
    assert voice_mod._voice_for("x-ai/grok-voice-tts-1.0", "Leda") == "eve"
    assert voice_mod._voice_for("x-ai/grok-voice-tts-1.0", "Ara") == "ara"
    assert voice_mod._voice_for("google/gemini-3.1-flash-tts-preview", "eve") == "Leda"
