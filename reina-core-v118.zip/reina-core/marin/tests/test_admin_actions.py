"""Регрессия по скриншотам: приглашение/админка в своём канале и честные итоги."""
import asyncio
import json

import _fakes
from _fakes import Entity, Event, FakeTelethon
from test_channel_publisher import CHAT_SCRIPT, CALLS, OWNER, make_client, CHANNEL


class UserNotMutualContactError(Exception):
    pass


class ChatAdminRequiredError(Exception):
    pass


class AdminFake(FakeTelethon):
    def __init__(self, *a, invite_error=None, admin_error=None, **kw):
        super().__init__(*a, **kw)
        self.invite_error = invite_error
        self.admin_error = admin_error
        self.admin_calls = []
        self.get_entity_args = []
        owner = Entity(int(OWNER), title="Jaabir", username="kg_bat", broadcast=False, creator=False)
        self.entities[owner.id] = owner
        self.by_username["kg_bat"] = owner

    async def get_entity(self, x):
        self.get_entity_args.append(x)
        return await super().get_entity(x)

    async def __call__(self, request):
        name = type(request).__name__
        if name == "InviteToChannelRequest":
            if self.invite_error:
                raise self.invite_error
            return object()
        if name == "ExportChatInviteRequest":
            return type("Inv", (), {"link": "https://t.me/+AbCdEf"})()
        raise RuntimeError(name)

    async def edit_admin(self, chat, user, **kw):
        if self.admin_error:
            raise self.admin_error
        self.admin_calls.append((chat.id, user.id, kw))


def setup(**kw):
    tc, _ = make_client()
    fake = AdminFake([CHANNEL], **kw)
    tc.client = fake
    tc._owner_username = "kg_bat"
    tc._remember_own_channel(CHANNEL.id, title="Мысли Марин — источник", username="")
    return tc, fake


def act(tc, kind, payload):
    return asyncio.run(tc.actions.execute_now(kind, "x", json.dumps(payload, ensure_ascii=False)))


def test_numeric_string_id_is_resolved_as_id_not_phone():
    tc, fake = setup()
    res = act(tc, "promote_admin", {"chat": str(CHANNEL.id), "username": "kg_bat"})
    assert res.startswith("Готово"), res
    assert CHANNEL.id in fake.get_entity_args  # int, а не строка-«телефон»


def test_chat_by_title_and_owner_by_word():
    tc, fake = setup()
    res = act(tc, "promote_admin", {"chat": "Мысли Марин — источник", "username": "владелец"})
    assert res.startswith("Готово"), res
    assert fake.admin_calls[-1][1] == int(OWNER)


def test_promote_in_broadcast_uses_channel_rights():
    tc, fake = setup()
    act(tc, "promote_admin", {"chat": str(CHANNEL.id), "username": "kg_bat"})
    rights = fake.admin_calls[-1][2]
    assert rights.get("post_messages") and "ban_users" not in rights and "pin_messages" not in rights


def test_invite_falls_back_to_link_in_dm():
    tc, fake = setup(invite_error=UserNotMutualContactError())
    res = act(tc, "invite_user", {"chat": str(CHANNEL.id), "username": "kg_bat"})
    assert res.startswith("Готово") and "https://t.me/+AbCdEf" in res, res
    assert (int(OWNER), "Заходи в «Мысли Марин»: https://t.me/+AbCdEf") in fake.sent or \
        any(cid == int(OWNER) and "t.me/+AbCdEf" in t for cid, t in fake.sent)
    assert "взаимные контакты" in res


def test_real_reason_instead_of_generic():
    tc, fake = setup(admin_error=ChatAdminRequiredError())
    res = act(tc, "promote_admin", {"chat": str(CHANNEL.id), "username": "kg_bat"})
    assert "нет нужных админ-прав" in res and "либо" not in res


def test_owner_targeted_admin_action_runs_without_confirmation_and_outcome_is_remembered():
    tc, fake = setup(admin_error=ChatAdminRequiredError())
    CHAT_SCRIPT.append(
        'щас сделаю<<<ACTION:promote_admin|Сделать тебя админом|{"chat": "%d", "username": "kg_bat"}>>>'
        '<<<MSG>>>готово' % CHANNEL.id)
    ev = Event("сделай меня админом в канале", fake, int(OWNER))
    asyncio.run(tc._process_batch([ev], chat=int(OWNER), chat_id=OWNER, sender_id=OWNER))
    assert tc.actions.pending_count() == 0, "не должна просить «подтверди»"
    owner_msgs = [t for cid, t in fake.sent if cid == int(OWNER)]
    assert any("нет нужных админ-прав" in t for t in owner_msgs), owner_msgs
    # следующий тик видит правду
    CHAT_SCRIPT.append("ок<<<MSG>>>ага")
    ev2 = Event("ну что, я админ?", fake, int(OWNER))
    asyncio.run(tc._process_batch([ev2], chat=int(OWNER), chat_id=OWNER, sender_id=OWNER))
    assert "нет нужных админ-прав" in CALLS["chat"][-1].situation_summary


def test_action_on_other_person_still_needs_confirmation():
    tc, fake = setup()
    stranger = Entity(777777, title="Петя", username="petya_x", broadcast=False, creator=False)
    fake.entities[stranger.id] = stranger
    fake.by_username["petya_x"] = stranger
    CHAT_SCRIPT.append('<<<ACTION:promote_admin|Сделать Петю админом|{"chat": "%d", "username": "petya_x"}>>>ок<<<MSG>>>жду' % CHANNEL.id)
    ev = Event("сделай петю админом", fake, int(OWNER))
    asyncio.run(tc._process_batch([ev], chat=int(OWNER), chat_id=OWNER, sender_id=OWNER))
    assert tc.actions.pending_count() == 1 and not fake.admin_calls


def test_public_chat_has_no_restrictions():
    tc, fake = setup()
    group = Entity(-100888, title="Мысли Марин — источник Chat", broadcast=False, creator=True)
    fake.entities[group.id] = group
    ev = Event("Ого", fake, group.id)
    asyncio.run(tc._process_batch([ev], chat=group, chat_id=str(group.id), sender_id=OWNER))
    summary = CALLS["chat"][-1].situation_summary
    assert "публичном чате" not in summary and "не раскрывай" not in summary
