import asyncio
from types import SimpleNamespace

from marin_core.engine.autonomous_life import AutonomousLifeLoop


def test_autonomous_social_disabled(monkeypatch):
    monkeypatch.setenv("MARIN_AUTONOMOUS_SOCIAL_ENABLED", "false")
    tc = SimpleNamespace(config=SimpleNamespace(owner_id="1"))
    loop = AutonomousLifeLoop(tc)
    asyncio.run(loop._autonomous_social_pulse())
