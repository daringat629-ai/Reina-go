"""Иллюстрации к посту — не селфи, картинка по теме поста."""
import asyncio

import _fakes
from marin_core.telegram.illustrator import _looks_unsafe
from marin_core.telegram.intents import PostIntent, detect_intent
from test_channel_publisher import CHANNEL, make_client


class FakeIllustrator:
    def __init__(self):
        self.calls = []

    async def generate(self, prompt_hint: str) -> bytes:
        self.calls.append(prompt_hint)
        return b"fake-image-bytes"


def test_intent_distinguishes_selfie_from_illustration():
    assert detect_intent("выложи пост с селфи").with_illustration is False
    i = detect_intent("сделай пост с картинкой про осенний дождь")
    assert i.with_selfie is False and i.with_illustration is True and i.brief == "про осенний дождь"
    both = detect_intent("сделай пост с селфи и картинкой")
    assert both.with_selfie is True and both.with_illustration is False  # селфи в приоритете, не оба сразу


def test_publish_with_illustration_sends_photo_with_caption():
    tc, fake = make_client()
    tc._remember_own_channel(CHANNEL.id, title=CHANNEL.title, username=CHANNEL.username)
    fake_gen = FakeIllustrator()
    tc._get_illustration_generator = lambda: fake_gen
    res = asyncio.run(tc.publisher.publish("про осень", with_illustration=True))
    assert res.ok
    assert fake.files_sent and fake.files_sent[-1][0] == CHANNEL.id
    assert fake.files_sent[-1][2].get("caption") == res.text
    assert fake_gen.calls and "осень" in fake_gen.calls[0]


def test_illustration_failure_still_publishes_text():
    tc, fake = make_client()
    tc._remember_own_channel(CHANNEL.id, title=CHANNEL.title, username=CHANNEL.username)

    class Broken:
        async def generate(self, prompt_hint):
            raise RuntimeError("no api key")

    tc._get_illustration_generator = lambda: Broken()
    res = asyncio.run(tc.publisher.publish("про осень", with_illustration=True))
    assert res.ok and (CHANNEL.id, res.text) in fake.sent


def test_post_marker_with_illustration_word_routes_to_illustration_not_selfie():
    tc, fake = make_client()
    tc._remember_own_channel(CHANNEL.id, title=CHANNEL.title, username=CHANNEL.username)
    calls = {}

    async def fake_publish(brief, **kw):
        calls.update(kw)
        from marin_core.telegram.channel_publisher import PublishResult
        return PublishResult(ok=True, channel_title=CHANNEL.title, text="x")

    tc.publisher.publish = fake_publish
    asyncio.run(tc._publish_from_brief("осенняя тема с картинкой"))
    assert calls.get("with_illustration") is True and not calls.get("with_selfie")


def test_unsafe_prompt_is_blocked_before_network():
    assert _looks_unsafe("нарисуй nsfw сцену")
    assert not _looks_unsafe("тёплый осенний вечер, чашка кофе")
