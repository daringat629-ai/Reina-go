"""Память переживает рестарт: сохранение, восстановление, бэкапы, автосейв."""
import asyncio
import json
import os
import tempfile

import _fakes  # noqa: F401
from marin_core import CognitiveEngine
from marin_core.goals.goals import GoalLevel
from marin_core.llm.providers import CallableProvider
from marin_core.state_store import StateStore


def _engine():
    return CognitiveEngine(llm_provider=CallableProvider(lambda p: "ага<<<MSG>>>поняла"))


def test_memory_survives_restart():
    path = os.path.join(tempfile.mkdtemp(), "state.json")
    e1 = _engine()
    e1.tick("меня зовут Жаабир, я люблю зелёный чай", channel_id="c", source_actor_id="1001", is_owner=True)
    e1.remember_fact("owner_tea", "Жаабир любит зелёный чай", confidence=0.95)
    e1.add_current_goal("напомнить про чай")
    store = StateStore(path)
    assert store.changed(e1)
    store.save(e1)
    assert not store.changed(e1)
    n_mem, n_bel = len(e1.memory), len(e1.beliefs._beliefs)

    e2 = _engine()  # «новый процесс»
    counts = StateStore(path).load_into(e2)
    assert counts and len(e2.memory) == n_mem and len(e2.beliefs._beliefs) == n_bel
    assert e2.beliefs._beliefs["fact:owner_tea"].statement == "Жаабир любит зелёный чай"
    assert any(g.description == "напомнить про чай" for g in e2.goal_set.goals.values())
    assert e2.social.owner_id == "1001" and abs(e2.social.get_or_create("1001").relationship.trust - e1.social.get_or_create("1001").relationship.trust) < 1e-6
    ident = [g for g in e2.goal_set.goals.values() if g.level == GoalLevel.IDENTITY]
    assert len(ident) == 1, "IDENTITY-цель не должна дублироваться при каждом рестарте"
    assert e2.state.tick >= e1.state.tick


def test_restart_many_times_does_not_accumulate():
    path = os.path.join(tempfile.mkdtemp(), "state.json")
    e = _engine()
    StateStore(path).save(e)
    for _ in range(5):
        e = _engine()
        StateStore(path).load_into(e)
        StateStore(path).save(e)
    assert len([g for g in e.goal_set.goals.values() if g.level == GoalLevel.IDENTITY]) == 1


def test_corrupted_main_falls_back_to_backup():
    path = os.path.join(tempfile.mkdtemp(), "state.json")
    e = _engine()
    e.remember_fact("k", "старый факт")
    store = StateStore(path, backups=2)
    store.save(e)
    e.remember_fact("k2", "новый факт")
    store.save(e)  # первый снимок ушёл в .bak1
    with open(path, "w") as fh:
        fh.write("{битый json")
    e2 = _engine()
    assert StateStore(path, backups=2).load_into(e2) is not None
    assert "fact:k" in e2.beliefs._beliefs


def test_client_restores_on_start_and_saves_on_disconnect():
    path = os.path.join(tempfile.mkdtemp(), "state.json")
    os.environ["MARIN_STATE_FILE"] = path
    try:
        from test_channel_publisher import make_client
        tc, fake = make_client()
        tc.engine.remember_fact("owner_birthday", "День рождения Жаабира 12 марта")
        asyncio.run(tc._save_state(force=True))
        assert os.path.exists(path)
        tc2, _ = make_client()
        assert tc2._state_restored is not None
        assert tc2.engine.beliefs._beliefs["fact:owner_birthday"].statement.startswith("День рождения")
        # автосейв не пишет, если ничего не менялось
        mtime = os.path.getmtime(path)
        tc2.state_store.last_saved_at = 0
        asyncio.run(tc2._maybe_autosave())
        assert os.path.getmtime(path) == mtime
    finally:
        os.environ["MARIN_STATE_FILE"] = os.path.join(_fakes._TMP, "state_default.json")
