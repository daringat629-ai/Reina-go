"""Регрессии по скриншотам живого чата (26.09): каждый тест воспроизводит
то, что владелец реально увидел в Telegram."""
import asyncio
import re
from types import SimpleNamespace

import _fakes  # noqa: F401
from test_channel_publisher import CHANNEL, OWNER, make_client

from marin_core.goals.goals import GoalStatus
from marin_core.llm.interface import LanguagePlanningInput
from marin_core.llm.output_guard import assess, normalize_markers, strip_protocol_junk
from marin_core.llm.providers import QualityGatedProvider, _is_unusable_output
from marin_core.action.action import ActionType

LEAKS = [
    'The owner (Jaabir) just said "Я сам не админ" in response to my previous messages where I was '
    'asking for a photo to change a group/channel photo.\n1. He asked me to change a group photo\n'
    '2. I asked where the photo is\n3. He sent media (at 15:10 in the log)',
    "Let me connect to the service and interact with it properly. Let me connect to the service "
    "interactively. Let me connect to the service properly.",
    "Let me try to connect interactively using nc.",
]
GOOD = [
    "вау, спасибо)) аж настроение поднялось с утра",
    "а вообще зря ты так, джабир теперь мой админ! так что попрошу не обижать)) но за дерзость респект",
    "Готово, в этот раз всё должно было пройти. Проверь канал: https://t.me/c/4403242978/10",
    "Так что да, всё через вижн — сканирую, читаю, запоминаю. Ты у меня умный, сам допёр)",
    "Hi! Sure, I can help with that — what exactly do you need?",
]


# ------------------------------------------------------------ output guard
def test_leaks_from_screenshots_are_never_sent():
    for text in LEAKS:
        assert _is_unusable_output(text), text[:60]


def test_normal_marin_replies_are_not_blocked():
    for text in GOOD:
        assert not _is_unusable_output(text), text[:60]


def test_reversed_marker_is_repaired_not_leaked():
    assert normalize_markers("Спасибо, подхватила >>>READ:get_bio|<<<") == "Спасибо, подхватила <<<READ:get_bio|>>>"
    assert normalize_markers("<<READ:get_invite_links|x>>") == "<<<READ:get_invite_links|x>>>"
    # стикер-маркер не обрезается, а мусорные скобки — да
    assert strip_protocol_junk("Держи <<<STICKER:5>>>") == "Держи <<<STICKER:5>>>"
    assert strip_protocol_junk("текст >>> и <<<") == "текст и"


def test_masculine_self_reference_is_soft_not_hard():
    v = assess("а внутри тепло — я включил лампочку и заварил чай")
    assert v.ok and "masculine_self" in v.soft
    assert assess("я сама всё сделала").soft == []


# --------------------------------------------------------- quality gate
class _Scripted:
    def __init__(self, outputs):
        self.outputs = list(outputs)
        self.inputs = []

    def generate(self, pin):
        self.inputs.append(pin)
        out = self.outputs.pop(0)
        if isinstance(out, Exception):
            raise out
        return out


def _pin():
    return LanguagePlanningInput(
        situation_summary="s", retrieved_memory_summaries=[], active_belief_summaries=[],
        chosen_action_type=ActionType.ANSWER, goal_context_summary="",
    )


def test_quality_gate_retries_flawed_reply_with_concrete_hint():
    inner = _Scripted(["я включил лампу и заварил чай", "я включила лампу и заварила чай"])
    out = QualityGatedProvider(inner).generate(_pin())
    assert out == "я включила лампу и заварила чай"
    assert any("женском роде" in c for c in inner.inputs[1].constraints)


def test_quality_gate_retries_after_chain_failure_instead_of_silence():
    inner = _Scripted([RuntimeError("all providers returned unusable output"), "ахах, да тут я)"])
    assert QualityGatedProvider(inner).generate(_pin()) == "ахах, да тут я)"


def test_quality_gate_keeps_usable_reply_if_retry_is_worse():
    inner = _Scripted(["я включил лампу", RuntimeError("down")])
    assert QualityGatedProvider(inner).generate(_pin()) == "я включил лампу"


# ------------------------------------------------------- goal executor
def test_self_goal_post_step_publishes_instead_of_failing_on_missing_chat():
    """Скриншоты: «По цели … (шаг 2/2) предлагаю … Подтвердить «да»?» → «да» →
    «Не получилось отправить сообщение: в команде не хватило данных»."""
    tc, fake = make_client()
    gid = tc.goal_executor.create_goal_from_description(
        "Хочу написать в канал тёплый пост про осенний вечер и уют", OWNER, context={"self_initiated": True},
    )
    goal = next(g for g in tc.engine.goal_set.autonomous_goals(owner_id=OWNER) if g.id == gid)
    goal.plan = [{"kind": "send_message", "read": False, "description": "Написать тёплый пост в канал",
                  "payload_template": '{"to": "$telegram_channel_id", "text": "тёплый пост про осенний вечер"}'}]
    goal.total_steps, goal.current_step, goal.status = 1, 0, GoalStatus.RUNNING

    asyncio.run(tc.goal_executor._advance_one(goal))

    assert any(entity == CHANNEL.id for entity, *_ in fake.sent), fake.sent
    assert str(OWNER) not in tc.actions._pending  # не повис в ожидании «да»
    assert (goal.last_result or "").startswith("Готово"), goal.last_result
    assert any("пост по цели" in x for x in tc._action_outcomes)  # правда о результате — в контексте


def test_message_to_a_person_still_needs_confirmation():
    tc, _fake = make_client()
    gid = tc.goal_executor.create_goal_from_description("Хочу поздравить друга", OWNER)
    goal = next(g for g in tc.engine.goal_set.autonomous_goals(owner_id=OWNER) if g.id == gid)
    goal.plan = [{"kind": "send_message", "read": False, "description": "Написать другу",
                  "payload_template": '{"to": "@some_friend", "text": "с днём рождения"}'}]
    goal.total_steps, goal.current_step, goal.status = 1, 0, GoalStatus.RUNNING
    assert not tc.goal_executor._is_own_channel_post_step(goal, goal.plan[0])


def test_self_initiative_does_not_promise_things_impossible_in_telegram():
    import os
    from test_channel_publisher import CHAT_SCRIPT
    os.environ["MARIN_SELF_INITIATIVE_ENABLED"] = "true"
    os.environ["MARIN_SELF_INITIATIVE_INTERVAL"] = "0"
    tc, fake = make_client()
    CHAT_SCRIPT.insert(0, "Хочу собрать для канала осенний плейлист и запостить его")
    asyncio.run(tc.autonomous_life._self_initiative_pulse())
    own = [g for g in tc.engine.goal_set.autonomous_goals(owner_id=OWNER) if g.context.get("self_initiated")]
    assert not own
    assert not fake.sent


# ------------------------------------------------------------- context
class _Ev:
    def __init__(self, text, reply=None):
        self.raw_text = text
        self.is_reply = reply is not None
        self._reply = reply
        self.replies = []

    async def get_reply_message(self):
        return self._reply

    async def reply(self, text):
        self.replies.append(text)


def test_swipe_reply_context_reaches_the_model():
    """Скриншот: «Подтверждаю» свайпом на её сообщение про био → «а что
    именно подтверждаешь? я уже запуталась»."""
    tc, _ = make_client()
    her_msg = SimpleNamespace(out=True, raw_text="По био я так и не обновила, кстати", id=7, photo=None)
    hint = asyncio.run(tc._reply_context_hint([_Ev("Подтверждаю", her_msg)]))
    assert "твоё сообщение" in hint and "По био я так и не обновила" in hint and "Подтверждаю" in hint
    assert asyncio.run(tc._reply_context_hint([_Ev("просто текст")])) == ""


def test_link_request_in_group_answers_with_real_link():
    """Скриншот: «Марин дай ссылку на группу» — просьба просто потерялась."""
    tc, _ = make_client()
    group = SimpleNamespace(id=555, title="Мысли Марин — источник Chat", username="marin_chat", broadcast=False)
    ev = _Ev("Марин дай ссылку на группу")
    assert asyncio.run(tc._handle_link_request(ev, group, ev.raw_text)) is True
    assert "https://t.me/marin_chat" in ev.replies[0]
    assert asyncio.run(tc._handle_link_request(_Ev("как дела"), group, "как дела")) is False


def test_same_sticker_can_repeat_by_owner_choice():
    """Владелец узнаёт Марин по любимым стикерам — повторы разрешены намеренно."""
    tc, fake = make_client()
    tc._sticker_catalog[:] = [SimpleNamespace(id=1), SimpleNamespace(id=2)]
    chat = SimpleNamespace(id=42)
    assert asyncio.run(tc._send_sticker(chat, 1)) is True
    assert asyncio.run(tc._send_sticker(chat, 1)) is True
    assert [f[1].id for f in fake.files_sent[-2:]] == [1, 1]


# ------------------------------------------------ короткие пузыри в личке
LONG_REPLY = (
    "Что касается поста про вечер — честно скажу: две попытки отправить его в канал провалились "
    "с ошибкой. Не получилось опубликовать, хотя текст был готов. Если хочешь, могу попробовать "
    "ещё раз или перенаправить в другой чат. А пока пойду чай заварю. И плед достану."
)


def _words(text):
    import re
    return re.findall(r"[\wё]+", text.lower())


def test_dm_bubbles_are_short_and_nothing_is_lost():
    from marin_core.llm.providers import split_into_messages
    from marin_core.telegram.settings import REPLY_BUBBLE_MAX_CHARS
    tc, _ = make_client()
    msgs = tc._ensure_minimum_messages(
        split_into_messages(LONG_REPLY, max_part_chars=REPLY_BUBBLE_MAX_CHARS, max_messages=None))
    assert len(msgs) > 3                      # раньше обрезалось до 3 — хвост пропадал
    assert all(len(m) <= REPLY_BUBBLE_MAX_CHARS for m in msgs), msgs
    assert _words(" ".join(msgs)) == _words(LONG_REPLY)  # ни слова не потеряно
    assert "Что касается поста про вечер — честно скажу:" in msgs  # тире не теряется при склейке


def test_short_reply_is_not_padded_with_fake_message():
    tc, _ = make_client()
    assert tc._ensure_minimum_messages(["ахах)"]) == ["ахах)"]  # раньше + «Я рядом.»


def test_reply_count_is_unlimited_by_default():
    from marin_core.telegram.settings import cap_messages
    six = [f"m{i}" for i in range(6)]
    assert cap_messages(six) == six


def test_group_limit_keeps_text_and_never_glues_sticker_marker_into_text():
    from marin_core.telegram.settings import fit_messages
    assert fit_messages(["раз", "два", "три", "<<<STICKER:5>>>"], 2) == ["раз", "два три"]
    assert fit_messages(["раз", "<<<STICKER:5>>>"], 2) == ["раз", "<<<STICKER:5>>>"]


def test_prompt_no_longer_demands_exactly_two_or_three_messages():
    import inspect
    import marin_core.llm.providers as prov
    src = inspect.getsource(prov)
    assert "exactly 2 or 3" not in src and "don't repeat the one you just sent" not in src
    assert "under 70" in src


# ------------------------------------------- скриншоты 26.09, 23:31–00:07
def test_poll_goal_step_goes_to_own_channel_without_confirmation():
    """«Сделать? Скажи «да»» → «да» → «Не получилось создать опрос: в команде
    не хватило данных (чат или человек)» — дважды."""
    import json
    tc, fake = make_client()
    calls = []

    async def execute_now(kind, description, payload):
        calls.append((kind, json.loads(payload)))
        return "Готово, создала опрос."

    tc.actions.execute_now = execute_now
    gid = tc.goal_executor.create_goal_from_description(
        "Хочу запустить в канале тёплый осенний опрос — пусть подписчики выберут", OWNER,
        context={"self_initiated": True})
    goal = next(g for g in tc.engine.goal_set.autonomous_goals(owner_id=OWNER) if g.id == gid)
    goal.plan = [{"kind": "create_poll", "read": False, "description": "Создать опрос в канале",
                  "payload_template": '{"chat": "$telegram_channel_id", "question": "Что ближе осенью?", '
                                      '"options": ["чай", "плед"]}'}]
    goal.total_steps, goal.current_step, goal.status = 1, 0, GoalStatus.RUNNING
    asyncio.run(tc.goal_executor._advance_one(goal))
    assert calls and calls[0][0] == "create_poll", calls
    assert str(calls[0][1]["chat"]) == str(CHANNEL.id), calls  # подставлен её канал
    assert str(OWNER) not in tc.actions._pending               # без «да»
    assert (goal.last_result or "").startswith("Готово")


def test_channel_is_not_reported_as_a_person():
    """«@kitagawa_room — это живой юзер» про канал."""
    tc, _ = make_client()

    async def resolve(_):
        return SimpleNamespace(id=77, title="Мысли Марин", broadcast=True, username="kitagawa_room")

    tc._resolve_peer = resolve
    out = asyncio.run(tc._read_get_user_info("kitagawa_room"))
    assert "не человек" in out and "канал «Мысли Марин»" in out, out


def test_owner_link_is_identified_and_own_channel_registered():
    tc, fake = make_client()
    chan = SimpleNamespace(id=4242, title="Мысли Марин", broadcast=True, creator=True, admin_rights=None)

    async def get_entity(x):
        return chan if str(x).lower() == "kitagawa_room" else (_ for _ in ()).throw(ValueError("nope"))

    fake.get_entity = get_entity
    hint = asyncio.run(tc._link_facts_hint("https://t.me/kitagawa_room эхх держи ссылку"))
    assert "это канал «Мысли Марин», ты его создатель" in hint and "записан как твой канал" in hint, hint
    assert "4242" in tc._own_channels
    assert asyncio.run(tc._link_facts_hint("просто текст")) == ""


def test_read_results_are_answered_not_dumped_raw():
    """Сырые «(не получилось получить данные)», «(id=4403242978, тип=Channel…)»,
    «просто Марин» и «Сначала я проверю…» в чате."""
    from test_channel_publisher import CALLS, CHAT_SCRIPT
    from _fakes import Event
    tc, fake = make_client()

    async def get_bio(_):
        return "просто Марин"

    tc._readonly_actions["get_bio"] = get_bio
    CHAT_SCRIPT.append("Поняла! Сначала я проверю своё био <<<READ:get_bio|>>>")
    CHAT_SCRIPT.append("в био у меня сейчас «просто Марин», всё на месте)")
    ev = Event("что у тебя в био?", fake, int(OWNER))
    asyncio.run(tc._process_batch([ev], chat=int(OWNER), chat_id=OWNER, sender_id=OWNER))
    sent = " | ".join(t for cid, t in fake.sent if cid == int(OWNER))
    assert "в био у меня сейчас «просто Марин»" in sent, sent
    assert "Сначала я проверю" not in sent and "<<<" not in sent, sent
    assert "Ты только что сама посмотрела" in CALLS["chat"][-1].situation_summary


def test_garbled_mixed_script_words_trigger_rewrite():
    for t in ("Сначаla я проверю состояние канала", "посмотрю мой б꙰ιο"):
        v = assess(t)
        assert v.ok and "garbled_text" in v.soft, t
    assert assess("Telegram-канал и iPhone — норм").soft == []


# ---------------------------------------------- серверный лог 26.09 18:36–18:39
class _StrictPoll:
    """Как в новом слое Telegram: hash обязателен."""
    def __init__(self, id, question, answers, hash, closed=None, public_voters=None,
                 multiple_choice=None, quiz=None):
        self.id, self.question, self.answers, self.hash = id, question, answers, hash
        self.multiple_choice, self.public_voters = multiple_choice, public_voters


class _Obj:
    def __init__(self, **kw):
        self.__dict__.update(kw)


def test_poll_is_created_with_new_required_hash_field(monkeypatch):
    """Лог: TypeError: Poll.__init__() missing 1 required positional argument: 'hash'
    → владельцу «в команде не хватило данных (чат или человек)»."""
    import json
    import marin_core.telegram.write_handlers as wh
    from marin_core.telegram.actions import PendingAction
    for name, cls in (("Poll", _StrictPoll), ("PollAnswer", _Obj), ("TextWithEntities", _Obj),
                      ("InputMediaPoll", _Obj)):
        monkeypatch.setattr(wh.types, name, cls, raising=False)
    tc, fake = make_client()
    sent = []

    async def resolve(x):
        return SimpleNamespace(id=4403242978)

    async def send_message(entity, text="", file=None, **kw):
        sent.append(file)

    tc._resolve_peer = resolve
    fake.send_message = send_message
    payload = json.dumps({"chat": -1004403242978, "question": "Что для тебя осень?",
                          "options": ["Плед и чай", "Листья"], "multiple": False, "anonymous": True})
    res = asyncio.run(tc._action_create_poll(PendingAction("create_poll", "опрос", payload)))
    assert res.startswith("Готово"), res
    assert sent and sent[0].poll.hash == 0 and len(sent[0].poll.answers) == 2


def test_code_bug_is_not_disguised_as_missing_chat():
    from marin_core.telegram.resolver import tg_error_reason
    msg = tg_error_reason(TypeError("Poll.__init__() missing 1 required positional argument: 'hash'"))
    assert "не хватило данных" not in msg and "баг" in msg, msg
    assert "«chat»" in tg_error_reason(KeyError("chat"))


def test_own_channel_post_echo_in_discussion_is_not_answered():
    """Лог: [COMMUNITY] replied to subscriber … sender=4403242978 — это её канал."""
    tc, _ = make_client()
    tc._own_channels["-1004403242978"] = {"id": -1004403242978, "title": "Мысли Марин — источник"}
    ev = SimpleNamespace(message=SimpleNamespace(fwd_from=None))
    assert tc._is_channel_echo(SimpleNamespace(broadcast=True), "4403242978", ev)
    assert not tc._is_channel_echo(SimpleNamespace(first_name="Ч"), "555", ev)
    fwd = SimpleNamespace(message=SimpleNamespace(fwd_from=object()))
    assert tc._is_channel_echo(SimpleNamespace(broadcast=True), "777", fwd)  # авто-пересылка чужого канала


def test_timezone_works_without_tzdata(monkeypatch):
    """Лог: MARIN_TIMEZONE='Asia/Bishkek' не распознан — сон и утренние сообщения
    шли по времени сервера (UTC), на 6 часов мимо."""
    import datetime
    import marin_core.telegram.settings as st

    def no_tzdata(name):
        raise KeyError(f"No time zone found with key {name}")

    monkeypatch.setattr("zoneinfo.ZoneInfo", no_tzdata)
    monkeypatch.setattr(st, "MARIN_TIMEZONE", "Asia/Bishkek")
    st._TZ_CACHE.clear()
    try:
        assert st.local_now(0.0).utcoffset() == datetime.timedelta(hours=6)
    finally:
        st._TZ_CACHE.clear()
    assert st._fixed_offset_tz("UTC+6").utcoffset(None) == datetime.timedelta(hours=6)
    assert st._fixed_offset_tz("+05:30").utcoffset(None) == datetime.timedelta(hours=5, minutes=30)
    assert st._fixed_offset_tz("Mars/Olympus") is None


# ------------------------------------------------ скриншот 00:47: «сама себе»
def test_talking_to_herself_in_owner_chat_is_rewritten(monkeypatch):
    """«А ты пробовала просто так, без опроса, задать вопрос в посте?» — владельцу-мужчине."""
    from dataclasses import replace
    monkeypatch.setenv("MARIN_OWNER_GENDER", "male")
    owner_pin = replace(_pin(), is_owner=True)
    inner = _Scripted(["А ты пробовала просто так, без опроса, задать вопрос в посте?",
                       "Слушай, а может мне просто спросить в посте, без опроса?"])
    out = QualityGatedProvider(inner).generate(owner_pin)
    assert out.startswith("Слушай, а может мне")
    assert any("ЕМУ" in c for c in inner.inputs[1].constraints)
    # не владелец (девушка в группе) — обращение в женском роде нормально
    inner2 = _Scripted(["А ты пробовала без опроса?"])
    assert QualityGatedProvider(inner2).generate(_pin()) == "А ты пробовала без опроса?"
    assert assess("ты был прав, любимый", addressee_male=True).soft == []


def test_owner_flag_reaches_generation():
    from test_channel_publisher import CALLS, CHAT_SCRIPT
    from _fakes import Event
    tc, fake = make_client()
    CHAT_SCRIPT.append("ага")
    asyncio.run(tc._process_batch([Event("привет", fake, int(OWNER))], chat=int(OWNER),
                                  chat_id=OWNER, sender_id=OWNER))
    assert CALLS["chat"][-1].is_owner is True


def test_social_pulse_never_picks_owner_or_saved_messages(monkeypatch):
    monkeypatch.setenv("MARIN_AUTONOMOUS_SOCIAL_ENABLED", "true")
    tc, fake = make_client()
    owner = SimpleNamespace(id=int(OWNER), first_name="Jaabir")
    me = SimpleNamespace(id=6647535837, is_self=True, first_name="Marin")
    friend = SimpleNamespace(id=12345, first_name="Друг")

    async def get_dialogs(limit=None, **kw):
        return [SimpleNamespace(entity=e, message=object()) for e in (owner, me, friend)]

    picked = []

    async def send_to_entity(peer, **kw):
        picked.append(peer.id)
        return False

    fake.get_dialogs = get_dialogs
    tc.proactive.send_to_entity = send_to_entity
    life = tc.autonomous_life
    life._social_interval, life._last_social_action = 0, 0
    asyncio.run(life._autonomous_social_pulse())
    assert picked == [12345], picked


# ---------------------------------------- скриншоты 09:04–09:06: селфи и дубль шага
def test_selfie_is_drawn_from_the_reference_not_as_a_photo(monkeypatch):
    """Вместо персонажа с аватара вышла фотореалистичная брюнетка: в запросе стояло
    «photorealistic phone camera look», а референс ничем не был обозначен."""
    from marin_core.telegram import selfie
    monkeypatch.delenv("MARIN_SELFIE_STYLE", raising=False)
    gen = selfie.OpenRouterSelfieGenerator.__new__(selfie.OpenRouterSelfieGenerator)
    prompt = gen._build_prompt("вечер, улыбается", use_reference=True)
    assert "photorealistic phone camera look" not in prompt
    assert "same character as in the reference" in prompt and "Do NOT turn her into a real person" in prompt
    assert "non-sexual" in prompt and "nsfw" in prompt       # безопасность осталась
    monkeypatch.setenv("MARIN_SELFIE_STYLE", "photo")
    assert selfie._style_mode() == "photo"


def test_selfie_request_puts_reference_first(monkeypatch):
    import sys
    import types as pytypes
    from marin_core.telegram import selfie
    monkeypatch.delenv("MARIN_SELFIE_STYLE", raising=False)
    captured = {}

    class _Resp:
        def raise_for_status(self):
            pass

        def json(self):
            return {}

    def post(url, json=None, headers=None, timeout=None):
        captured["payload"] = json
        return _Resp()

    monkeypatch.setitem(sys.modules, "requests", pytypes.SimpleNamespace(post=post))
    cfg = SimpleNamespace(model="m", api_key="k", base_url="https://x", timeout=5)
    gen = selfie.OpenRouterSelfieGenerator(cfg)
    gen._extract_image_bytes = lambda data: b"img"
    asyncio.run(gen.generate("вечер", reference_image_b64="QUJD"))
    content = captured["payload"]["messages"][0]["content"]
    assert content[0]["type"] == "image_url" and content[1]["type"] == "text"
    assert "reference" in content[1]["text"]


def test_illustrations_never_show_a_person_as_her():
    tc, _ = make_client()
    assert "No people, no faces" in tc.publisher._illustration_prompt("тёплый вечер", "")
    assert "No people, no faces" in tc.publisher._illustration_prompt("", "Ох, этот вечер. Просто идеальный.")


def _selfie_goal(tc):
    gid = tc.goal_executor.create_goal_from_description(
        "Хочу запостить в канал тёплый вечерний пост с селфи, просто по настроению", OWNER,
        context={"self_initiated": True})
    goal = next(g for g in tc.engine.goal_set.autonomous_goals(owner_id=OWNER) if g.id == gid)
    goal.plan = [{"kind": "send_selfie", "read": False, "description": "отправить селфи с тёплым вечерним постом",
                  "payload_template": '{"chat": "$telegram_channel_id", "prompt": "вечер"}'}]
    goal.total_steps, goal.current_step, goal.status = 1, 0, GoalStatus.RUNNING
    return goal


def test_goal_does_not_repeat_a_post_already_made_in_chat():
    """«Ну всё, запостила) … ссылка» → и тут же «следующий шаг — отправить селфи с
    тёплым вечерним постом. Сделать?»"""
    import time as _t
    tc, fake = make_client()
    tc._remember_own_channel(CHANNEL.id, title=CHANNEL.title, username=CHANNEL.username)
    goal = _selfie_goal(tc)
    entry = tc._own_channels[str(CHANNEL.id)]
    entry["post_history"] = [{"id": 19, "at": _t.time() + 1, "text": "Ох, этот вечер", "source": "owner"}]
    asyncio.run(tc.goal_executor._advance_one(goal))
    assert str(OWNER) not in tc.actions._pending                 # не спрашивает «Сделать?»
    assert "уже вышел" in (goal.last_result or ""), goal.last_result


def test_unrelated_autopost_does_not_count_as_the_goal_post():
    import time as _t
    tc, _ = make_client()
    tc._remember_own_channel(CHANNEL.id, title=CHANNEL.title, username=CHANNEL.username)
    goal = _selfie_goal(tc)
    tc._own_channels[str(CHANNEL.id)]["post_history"] = [
        {"id": 20, "at": _t.time() + 1, "text": "о другом", "source": "autopost"}]
    assert not tc.goal_executor._goal_already_posted(goal)


def test_goal_post_with_selfie_in_description_attaches_a_selfie():
    tc, fake = make_client()
    tc._remember_own_channel(CHANNEL.id, title=CHANNEL.title, username=CHANNEL.username)
    calls = {}

    async def publish(brief, **kw):
        calls.update(kw)
        from marin_core.telegram.channel_publisher import PublishResult
        return PublishResult(ok=True, channel_id=CHANNEL.id, link="https://t.me/c/1/2")

    tc.publisher.publish = publish
    gid = tc.goal_executor.create_goal_from_description("Хочу пост с селфи в канал", OWNER)
    goal = next(g for g in tc.engine.goal_set.autonomous_goals(owner_id=OWNER) if g.id == gid)
    asyncio.run(tc.goal_executor._publish_post_step(goal, {"kind": "send_message", "description": "пост",
                                                           "payload_template": "{}"}))
    assert calls.get("with_selfie") is True and goal.context.get("posted_at")


def test_self_initiative_knows_the_local_time():
    from marin_core.engine.autonomous_life import _local_clock
    clock = _local_clock()
    assert re.match(r"\d\d:\d\d, (ночь|утро|день|вечер)$", clock), clock


# --------------------------------------------- скриншоты 10:02–10:03 и лог 04:00–04:03
SELFIE_REPLY = ('Держи, но предупреждаю — я там помятая, ночь же) <<<ACTION:send_selfie|{"chat": "Jaabir", '
                '"prompt": "at home late at night, relaxed, slightly tired but smiling", '
                '"caption": "Ну вот, лови селфи с ночных бдений))"}>>> Если что-то не так выйдет — разбирайся, хах)')


def test_two_field_action_is_repaired_and_never_split():
    from marin_core.llm.providers import split_into_messages
    fixed = normalize_markers(SELFIE_REPLY)
    assert "<<<ACTION:send_selfie|селфи|{" in fixed
    parts = split_into_messages(fixed, max_part_chars=70, max_messages=None)
    markers = [p for p in parts if "<<<" in p]
    assert len(markers) == 1 and markers[0].startswith("<<<ACTION") and markers[0].endswith(">>>")


def test_owner_selfie_request_is_sent_without_confirmation_and_marker_never_leaks():
    """«Жду кидай» → команда ушла текстом тремя пузырями, селфи не было."""
    from test_channel_publisher import CHAT_SCRIPT
    from _fakes import Event
    tc, fake = make_client()
    tc.owner_name = "Jaabir"
    done = []

    async def execute_now(kind, description, payload):
        done.append(kind)
        return "Готово, отправила селфи."

    tc.actions.execute_now = execute_now
    CHAT_SCRIPT.append(SELFIE_REPLY)
    asyncio.run(tc._process_batch([Event("Жду кидай", fake, int(OWNER))], chat=int(OWNER),
                                  chat_id=OWNER, sender_id=OWNER))
    sent = [t for cid, t in fake.sent if cid == int(OWNER)]
    assert done == ["send_selfie"], done
    assert str(OWNER) not in tc.actions._pending                     # без «Подтвердить?»
    assert not any("<<<" in t or "ACTION" in t or '"caption"' in t for t in sent), sent
    assert not any(t.startswith("Готово") for t in sent), sent       # селфи он и так увидит


def test_unexecuted_marker_is_dropped_not_sent():
    from test_channel_publisher import CHAT_SCRIPT
    from _fakes import Event
    tc, fake = make_client()
    CHAT_SCRIPT.append('ок) <<<ACTION:send_message|{"chat": "x", "text": "сломано>>> держи')
    asyncio.run(tc._process_batch([Event("ну?", fake, int(OWNER))], chat=int(OWNER),
                                  chat_id=OWNER, sender_id=OWNER))
    sent = " | ".join(t for cid, t in fake.sent if cid == int(OWNER))
    assert "ACTION" not in sent and "<<<" not in sent, sent


def test_casual_confirmations_are_understood():
    from marin_core.telegram.actions import ACTION_CONFIRM_RE
    for yes in ("Жду кидай", "кидай", "скинь уже", "присылай", "валяй"):
        assert ACTION_CONFIRM_RE.match(yes), yes
    for no in ("не кидай", "нет, не надо", "жду ответа от него, не отправляй"):
        assert not ACTION_CONFIRM_RE.match(no), no


def _chat_provider(monkeypatch, responses):
    import sys
    import types as pytypes
    from marin_core.llm.providers import OpenAICompatConfig, OpenAICompatProvider
    bodies = []

    class R:
        def __init__(self, status, data=None, text=""):
            self.status_code, self._data, self.text = status, data, text

        def raise_for_status(self):
            if self.status_code >= 400:
                raise RuntimeError(f"{self.status_code} Client Error")

        def json(self):
            return self._data

    queue = [R(*r) for r in responses]

    def post(url, json=None, headers=None, timeout=None):
        import copy
        bodies.append(copy.deepcopy(json))
        return queue.pop(0)

    monkeypatch.setitem(sys.modules, "requests", pytypes.SimpleNamespace(post=post))
    import marin_core.llm.providers as prov
    prov._REASONING_MEMO.clear()
    cfg = OpenAICompatConfig(base_url="https://openrouter.ai/api/v1", api_key="k", model="deepseek/deepseek-v4-flash",
                             max_output_tokens=800, retry_attempts=1)
    return OpenAICompatProvider(cfg), bodies


REASONING_ONLY = {"choices": [{"finish_reason": "length", "message": {"content": None, "reasoning": "..."}}],
                  "usage": {"completion_tokens": 800, "completion_tokens_details": {"reasoning_tokens": 1000}}}
GOOD = {"choices": [{"finish_reason": "stop", "message": {"content": "ахах, да тут я)"}}]}


def test_reasoning_model_gets_room_to_answer(monkeypatch):
    """Лог: deepseek-v4-flash — finish_reason='length', reasoning_tokens 900–1090 при
    max_tokens=800: размышления съедали всё, ответа не было, повтор был тем же запросом."""
    monkeypatch.setenv("MARIN_REASONING_EFFORT", "low")
    provider, bodies = _chat_provider(monkeypatch, [(200, REASONING_ONLY), (200, GOOD)])
    assert provider.generate(_pin()) == "ахах, да тут я)"
    first, second = bodies
    assert first["max_tokens"] == 800 + 1500 and first["reasoning"] == {"effort": "low", "exclude": True}
    assert second["max_tokens"] == 2 * first["max_tokens"] and second["reasoning"]["effort"] == "minimal"


def test_reasoning_is_off_by_default_and_ladder_on_rejection(monkeypatch):
    """Лог 04:24: на «low» deepseek всё равно думал 2632 токена. Теперь сначала «none»;
    модель с обязательными размышлениями отвечает 400 → «minimal» → без параметра."""
    monkeypatch.delenv("MARIN_REASONING_EFFORT", raising=False)
    provider, bodies = _chat_provider(monkeypatch, [
        (400, None, '{"error":"reasoning is mandatory"}'), (400, None, '{"error":"no"}'), (200, GOOD)])
    assert provider.generate(_pin()) == "ахах, да тут я)"
    assert bodies[0]["reasoning"]["effort"] == "none"
    assert bodies[1]["reasoning"]["effort"] == "minimal"
    assert "reasoning" not in bodies[2]
    # запомнила: следующий запрос сразу без параметра, без лишних 400
    import marin_core.llm.providers as prov
    memo = dict(prov._REASONING_MEMO)
    provider2, bodies2 = _chat_provider(monkeypatch, [(200, GOOD)])
    prov._REASONING_MEMO.update(memo)          # помощник теста чистит память — возвращаем её
    provider2.generate(_pin())
    assert "reasoning" not in bodies2[0]


def test_single_newline_between_short_replies_makes_separate_bubbles():
    """Регрессия: «Не переживай так за меня)\\nЯ тут, я в порядке, и я рядом»
    (< лимита пузыря) уходило одним сообщением с переносом внутри."""
    from marin_core.llm.providers import split_into_messages

    assert split_into_messages(
        "Не переживай так за меня)\nЯ тут, я в порядке, и я рядом",
        max_part_chars=70, max_messages=None,
    ) == ["Не переживай так за меня)", "Я тут, я в порядке, и я рядом"]
    assert split_into_messages(
        "Ахах, ну вот и славно)\nЧто, рад что я рядом?))",
        max_part_chars=70, max_messages=None,
    ) == ["Ахах, ну вот и славно)", "Что, рад что я рядом?))"]


def test_smiley_boundary_and_punctuation_bubbles():
    from marin_core.llm.providers import split_into_messages

    kw = dict(max_part_chars=70, max_messages=None)
    assert split_into_messages("Ахах, ну вот и славно) Что, рад что я рядом?))", **kw) == [
        "Ахах, ну вот и славно)", "Что, рад что я рядом?))"]
    # обычные скобки не режем
    assert split_into_messages("Смотри (вот тут) Потом скажешь", **kw) == ["Смотри (вот тут) Потом скажешь"]
    # пузырь из одних знаков приклеивается к предыдущему
    assert split_into_messages("Ок)\n)\nда", **kw) == ["Ок))", "да"]


def test_deliver_bubble_retries_and_falls_back():
    import asyncio
    from marin_core.telegram.client import MarinTelegramClient

    class Flood(Exception):
        seconds = 0

    calls = []

    class Ev:
        async def reply(self, text):
            calls.append(("reply", text))
            raise Flood()

    class Cl:
        n = 0
        async def send_message(self, chat, text):
            Cl.n += 1
            calls.append(("send", text))
            if Cl.n == 1:
                raise Flood()

    obj = MarinTelegramClient.__new__(MarinTelegramClient)
    obj.client = Cl()
    asyncio.run(obj._deliver_bubble("chat", Ev(), "привет", as_reply=True))
    assert calls[-1] == ("send", "привет") and len(calls) == 3


# ---- sister fixes: false alarms on common words, missed masculine forms, honesty --------------
def test_brand_words_are_not_stray_english():
    from marin_core.llm import output_guard as g
    v = g.assess("вчера весь вечер сидела в Discord и рисовала в Blender, потом залипла в Steam, так классно вышло")
    assert not v.soft and v.ok, v.describe()


def test_masculine_irregular_forms_are_caught():
    from marin_core.llm import output_guard as g
    for t in ("я ж не мог тебя разбудить", "я вчера ушёл рано", "я сегодня не смог прийти"):
        assert "masculine_self" in g.assess(t).soft, t
    for t in ("я не смогла прийти", "я могла бы помочь", "я шла домой"):
        assert "masculine_self" not in g.assess(t).soft, t


def test_persona_knows_her_sister_and_is_honest_about_being_ai():
    from marin_core.identity.presets import create_marin_personality
    sp = create_marin_personality().style_prior
    assert "Рейна" in sp["family"] and "ИИ" in sp["honesty"]
