
import time
from datetime import datetime, timezone
from marin_core.understanding.semantic import SemanticUnderstandingEngine
from marin_core.perception.perception import Observation, Modality


def obs(text, now="2026-09-29T10:00:00+00:00"):
    return Observation(
        modality=Modality.TEXT, content=text, source_actor_id="u1",
        channel_id="c1", t_observed=time.time(), metadata={"now": now},
    )


def test_temporal_and_compound_message():
    s = SemanticUnderstandingEngine().analyze(
        "Завтра сделай это, а потом напиши мне",
        observation=obs("x"),
        world_continuity="обсуждали отчёт",
    )
    assert s.temporal[0].normalized.startswith("2026-09-30")
    assert len(s.clauses) == 2
    assert any(r.mention == "это" for r in s.references)


def test_unresolved_reference_is_explicit():
    s = SemanticUnderstandingEngine().analyze(
        "Я люблю это",
        observation=obs("x"),
    )
    ref = next(r for r in s.references if r.mention == "это")
    assert ref.target is None
    assert ref.ambiguous
    assert s.ambiguities


def test_modality_and_negation():
    s = SemanticUnderstandingEngine().analyze(
        "Мне, наверное, не нужно это делать, если можно позже",
        observation=obs("x"),
    )
    assert "uncertainty" in s.modality
    assert "obligation" in s.modality
    assert "conditional" in s.modality
    assert "не" in s.negations
