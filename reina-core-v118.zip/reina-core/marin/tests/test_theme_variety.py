"""Не «осень по кругу»: приевшиеся темы видны ей везде, где она выбирает тему."""
import asyncio

import _fakes  # noqa: F401
from test_channel_publisher import CHANNEL, OWNER, make_client

from marin_core.goals.goals import GoalStatus
from marin_core.llm.providers import CallableProvider
from marin_core.telegram.theme_fatigue import fatigued_themes

AUTUMN_POSTS = [
    "Ох, этот вечер. Снаружи прохладно, листья, я укутываюсь в плед и пью чай.",
    "Осенняя заря на углу, золотой туман, внутри дома тепло — лампочка, горячий чай и пледы.",
    "Осень — это не грусть, а пауза. Плед, чай, тишина.",
    "Тёплый осенний вечер, чай и плед — что ещё нужно.",
]
AUTUMN_IDEAS = [
    "Хочу запустить в канале тёплый осенний опрос",
    "Хочу собрать для канала осенний плейлист",
    "Хочу запостить в канал тёплый вечерний пост с селфи",
]
VARIED = [
    "Сегодня пыталась сделать опрос в канале — Telegram упорно не давал, оказалось баг в коде.",
    "Заметила, что люди в группе спорят о мелочах громче, чем о важном.",
    "Мне впервые написал незнакомец с рекламой. Прочитала и промолчала.",
    "Думаю, что честность в переписке важнее красивых слов.",
    "Училась сегодня отвечать короче — оказывается, это сложно.",
]


def test_detector_finds_the_autumn_loop_and_ignores_variety():
    tired = fatigued_themes(AUTUMN_POSTS + AUTUMN_IDEAS)
    assert {"чай", "плед"} <= set(tired) and any(w.startswith("осен") for w in tired), tired
    assert fatigued_themes(VARIED) == []


def _with_history(tc, texts, source="autopost"):
    import time
    tc._remember_own_channel(CHANNEL.id, title=CHANNEL.title, username=CHANNEL.username)
    tc._own_channels[str(CHANNEL.id)]["post_history"] = [
        {"id": i, "at": time.time() - 3600 * (i + 1), "text": t, "source": source} for i, t in enumerate(texts)]


def _self_ideas(tc, descriptions, status=GoalStatus.COMPLETED):
    for d in descriptions:
        gid = tc.goal_executor.create_goal_from_description(d, OWNER, context={"self_initiated": True})
        g = next(x for x in tc.engine.goal_set.autonomous_goals(owner_id=OWNER) if x.id == gid)
        g.status = status


def test_reflection_sees_what_is_tired():
    tc, _ = make_client()
    tc.observer.events.clear()
    tc.engine.diary.entries.clear()
    seen = []
    tc.engine.language_planner.provider = CallableProvider(lambda pin: seen.append(pin) or "[НЕЧЕГО]")
    asyncio.run(tc.publisher.inner.reflect(0.0, AUTUMN_POSTS, require_news=False))
    material, system = seen[-1].situation_summary, seen[-1].system_override
    assert "Приелось" in material and "плед" in material
    assert "Никаких дежурных клише" in system and "Тема — любая, какую ты сама выберешь" in system


def test_post_prompt_warns_about_tired_themes():
    tc, _ = make_client()
    _with_history(tc, AUTUMN_POSTS)
    entry = tc._own_channels[str(CHANNEL.id)]
    pin = tc.publisher._build_prompt(entry, "", AUTUMN_POSTS, "Сегодня поняла кое-что про людей", False, inner=True)
    assert "Уже приелось" in pin.system_override and "плед" in pin.system_override


def test_owner_topic_is_respected_even_if_tired():
    """Попросил владелец «пост про осень» — это его выбор, не блокируем."""
    tc, _ = make_client()
    entry = {"title": "Канал", "id": CHANNEL.id}
    pin = tc.publisher._build_prompt(entry, "", AUTUMN_POSTS, "про осень", False)
    assert "Тема/угол от тебя самой по задумке: про осень" in pin.system_override


def test_self_initiative_sees_all_recent_ideas_and_tired_themes():
    from marin_core.engine.autonomous_life import _variety_block
    tc, _ = make_client()
    _self_ideas(tc, AUTUMN_IDEAS)                       # уже выполненные — раньше их не было видно
    _with_history(tc, AUTUMN_POSTS)
    block = _variety_block(tc)
    for idea in AUTUMN_IDEAS:
        assert idea in block, idea
    assert "Уже приелось" in block and "дежурных клише" in block


def test_her_own_post_goal_is_written_from_a_real_thought():
    tc, _ = make_client()
    tc._remember_own_channel(CHANNEL.id, title=CHANNEL.title, username=CHANNEL.username)
    calls = []

    async def publish(brief, **kw):
        calls.append((brief, kw))
        from marin_core.telegram.channel_publisher import PublishResult
        return PublishResult(ok=True, channel_id=CHANNEL.id, link="https://t.me/c/1/2")

    tc.publisher.publish = publish
    gid = tc.goal_executor.create_goal_from_description(
        "Хочу запостить в канал тёплый вечерний пост с селфи", OWNER, context={"self_initiated": True})
    goal = next(g for g in tc.engine.goal_set.autonomous_goals(owner_id=OWNER) if g.id == gid)
    asyncio.run(tc.goal_executor._publish_post_step(goal, {"kind": "send_message", "description": "пост",
                                                           "payload_template": "{}"}))
    brief, kw = calls[-1]
    assert brief == "" and kw["inner_focus"] == goal.description and kw["with_selfie"] is True
