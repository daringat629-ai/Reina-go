"""Shared offline fakes for transport-level tests (no network, no Telethon)."""
from __future__ import annotations

import os
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
sys.path.insert(0, HERE)

_TMP = tempfile.mkdtemp(prefix="marin_test_")
os.environ.setdefault("MARIN_SHARED_MEDIA_DIR", _TMP)
os.environ["MARIN_TELEGRAM_OWN_CHANNELS_FILE"] = os.path.join(_TMP, "own_channels.json")
os.environ["MARIN_TELEGRAM_MEDIA_PACKS_FILE"] = os.path.join(_TMP, "packs.json")
os.environ["MARIN_VISION_CACHE_FILE"] = os.path.join(_TMP, "vision.json")
os.environ["MARIN_TELEGRAM_OBSERVER_FILE"] = os.path.join(_TMP, "observer.json")
os.environ["MARIN_STATE_IMPORT_FILE"] = os.path.join(_TMP, "no_such_export.json")
os.environ["MARIN_STATE_FILE"] = os.path.join(_TMP, "state_default.json")
os.environ["MARIN_DIARY_FILE"] = os.path.join(_TMP, "diary.json")
os.environ["MARIN_TELEGRAM_REPLY_DELAY_SECONDS"] = "0"
os.environ["MARIN_TELEGRAM_READ_DELAY_SECONDS"] = "0"
os.environ["MARIN_TELEGRAM_MESSAGE_GAP_MIN_SECONDS"] = "0"
os.environ["MARIN_TELEGRAM_MESSAGE_GAP_MAX_SECONDS"] = "0"
os.environ["MARIN_QUIET_HOURS_START"] = "0"
os.environ["MARIN_QUIET_HOURS_END"] = "0"
os.environ["MARIN_VISION_ENABLED"] = "false"
os.environ["MARIN_SELFIE_ENABLED"] = "false"
os.environ["MARIN_VOICE_ENABLED"] = "false"

import telethon_stub  # noqa: E402

telethon_stub.install()


class Reaction:
    def __init__(self, emoji, count):
        self.reaction = type("R", (), {"emoticon": emoji})()
        self.count = count


class Reactions:
    def __init__(self, results):
        self.results = results


class Msg:
    _next = 100

    def __init__(self, text, out=True, id_=None, views=None, reactions=None):
        Msg._next += 1
        self.id = id_ or Msg._next
        self.raw_text = text
        self.message = text
        self.out = out
        self.views = views
        self.reactions = Reactions([Reaction(e, c) for e, c in reactions.items()]) if reactions else None

    def set_engagement(self, views=None, reactions=None):
        if views is not None:
            self.views = views
        if reactions is not None:
            self.reactions = Reactions([Reaction(e, c) for e, c in reactions.items()])


class Entity:
    def __init__(self, id_, title="", username="", broadcast=True, creator=True):
        self.id = id_
        self.title = title
        self.username = username
        self.broadcast = broadcast
        self.megagroup = False
        self.creator = creator
        self.admin_rights = None
        self.first_name = title


class Dialog:
    def __init__(self, entity):
        self.entity = entity
        self.id = entity.id
        self.name = entity.title
        self.date = None


class _Typing:
    async def __aenter__(self):
        return self

    async def __aexit__(self, *a):
        return False


class FakeTelethon:
    """Records every outgoing call. Channels are keyed by numeric id."""

    def __init__(self, entities=None):
        self.entities = {e.id: e for e in (entities or [])}
        self.by_username = {e.username.lower(): e for e in (entities or []) if e.username}
        self.sent = []          # (entity_id, text)
        self.files_sent = []    # (entity_id, file, kwargs incl. caption)
        self.uploaded = []
        self.deleted = []       # (entity_id, [ids])
        self.history = {}       # entity_id -> [Msg]
        self.linked_chats = {}  # discussion group id -> broadcast channel id

    async def get_entity(self, x):
        if isinstance(x, Entity):
            return x
        key = str(x).lstrip("@")
        if key.lstrip("-").isdigit() and int(key) in self.entities:
            return self.entities[int(key)]
        if key.lower() in self.by_username:
            return self.by_username[key.lower()]
        if key.lstrip("-").isdigit():
            return Entity(int(key), title="user", broadcast=False, creator=False)
        raise ValueError(f"cannot resolve {x!r}")

    async def get_input_entity(self, x):
        return await self.get_entity(x)

    async def get_messages(self, entity, limit=10, ids=None, **kw):
        eid = getattr(entity, "id", entity)
        msgs = self.history.get(eid, [])
        if ids is not None:
            by_id = {m.id: m for m in msgs}
            if isinstance(ids, (list, tuple)):
                return [by_id.get(i) for i in ids]  # порядок и None для отсутствующих — как в Telethon
            return by_id.get(ids)
        return list(reversed(msgs))[:limit]

    async def send_message(self, entity, text="", **kw):
        eid = getattr(entity, "id", entity)
        m = Msg(text, out=True)
        self.history.setdefault(eid, []).append(m)
        self.sent.append((eid, text))
        return m

    async def upload_file(self, file, **kw):
        self.uploaded.append(file)
        return file

    async def send_file(self, entity, file, caption="", **kw):
        eid = getattr(entity, "id", entity)
        m = Msg(caption, out=True)
        self.history.setdefault(eid, []).append(m)
        self.sent.append((eid, caption))
        self.files_sent.append((eid, file, {"caption": caption, **kw}))
        return m

    async def delete_messages(self, entity, ids, **kw):
        eid = getattr(entity, "id", entity)
        self.deleted.append((eid, list(ids)))
        self.history[eid] = [m for m in self.history.get(eid, []) if m.id not in ids]

    async def get_dialogs(self, limit=None, **kw):
        return [Dialog(e) for e in self.entities.values()]

    async def __call__(self, request):
        name = type(request).__name__
        if name == "GetFullChannelRequest":
            channel = getattr(request, "channel", None)
            gid = getattr(channel, "id", channel)
            linked = self.linked_chats.get(gid)
            full_chat = type("FullChat", (), {"linked_chat_id": linked})()
            return type("FullChannel", (), {"full_chat": full_chat})()
        raise RuntimeError(f"raw TL request not supported in fake: {name}")

    def action(self, chat, kind):
        return _Typing()

    async def send_read_acknowledge(self, *a, **kw):
        return None


class Event:
    _next = 5000

    def __init__(self, text, client, chat_id):
        Event._next += 1
        self.id = Event._next
        self.raw_text = text
        self._client = client
        self._chat_id = chat_id
        self.replies = []

    async def reply(self, text):
        self.replies.append(text)
        return await self._client.send_message(self._chat_id, text)
