"""Режиссёр селфи: где она, что делает, во что одета — по тексту и времени."""
import asyncio
import datetime

import _fakes  # noqa: F401
from test_channel_publisher import CHANNEL, make_client

import marin_core.telegram.selfie_director as sd
from marin_core.llm.providers import CallableProvider

EVENING = datetime.datetime(2026, 9, 27, 21, 30)
NEXT_MORNING = datetime.datetime(2026, 9, 28, 9, 5)

SCENE = ("PLACE: at home on the windowsill of her room\nDOING: holding a mug, looking at the night city\n"
         "OUTFIT: {outfit}\nLIGHT: warm lamp light, evening\nMOOD: soft tired smile")


def _client(monkeypatch, tmp_path, outfits, when=EVENING):
    monkeypatch.setenv("MARIN_SELFIE_STATE_FILE", str(tmp_path / "selfie.json"))
    monkeypatch.setattr(sd, "local_now", lambda now=None: when)
    tc, fake = make_client()
    seen = []
    queue = list(outfits)

    def llm(pin):
        seen.append(pin)
        nxt = queue.pop(0) if queue else "a green knit sweater"
        if isinstance(nxt, Exception):
            raise nxt
        return SCENE.format(outfit=nxt)

    tc.engine.language_planner.provider = CallableProvider(llm)
    return tc, fake, seen


def test_scene_follows_the_text_and_local_time(monkeypatch, tmp_path):
    tc, _f, seen = _client(monkeypatch, tmp_path, ["a green knit sweater"])
    text = "Сижу вечером на подоконнике, смотрю на огни города и думаю о сегодняшнем разговоре."
    scene = asyncio.run(tc.selfie_director.scene_for(text))
    assert text in seen[0].situation_summary
    assert "21:30, evening" in seen[0].system_override
    assert "windowsill" in scene and "wearing a green knit sweater" in scene and "evening" in scene


def test_outfit_is_kept_for_the_day_and_reset_next_day(monkeypatch, tmp_path):
    tc, _f, seen = _client(monkeypatch, tmp_path, ["a green knit sweater", "a green knit sweater"])
    asyncio.run(tc.selfie_director.scene_for("вечер дома"))
    assert "Одежду выбери сама" in seen[0].system_override
    asyncio.run(tc.selfie_director.scene_for("всё ещё дома"))
    assert "уже была в: a green knit sweater" in seen[1].system_override
    monkeypatch.setattr(sd, "local_now", lambda now=None: NEXT_MORNING)
    asyncio.run(tc.selfie_director.scene_for("доброе утро"))
    assert "Одежду выбери сама" in seen[2].system_override        # новый день — новая одежда
    assert tc.selfie_director.today_outfit() == "a green knit sweater"


def test_revealing_outfit_is_never_used(monkeypatch, tmp_path):
    tc, _f, _s = _client(monkeypatch, tmp_path, ["black lace lingerie"])
    scene = asyncio.run(tc.selfie_director.scene_for("вечер"))
    assert "lingerie" not in scene and sd._DEFAULT_OUTFIT in scene
    assert "lingerie" not in tc.selfie_director.today_outfit()


def test_model_failure_gives_a_safe_scene(monkeypatch, tmp_path):
    tc, _f, _s = _client(monkeypatch, tmp_path, [RuntimeError("down")])
    scene = asyncio.run(tc.selfie_director.scene_for("вечер", hint="at home"))
    assert "evening light" in scene and "wearing" in scene


def test_post_selfie_uses_the_director_scene(monkeypatch, tmp_path):
    tc, fake, _s = _client(monkeypatch, tmp_path, ["a green knit sweater"])
    tc._remember_own_channel(CHANNEL.id, title=CHANNEL.title, username=CHANNEL.username)
    prompts = []

    class Gen:
        async def generate(self, prompt, reference_image_b64=None):
            prompts.append((prompt, reference_image_b64))
            return b"img"

    async def upload_file(data, file_name=None):
        return data

    tc._get_selfie_generator = lambda: Gen()
    tc._get_selfie_reference = lambda: "QUJD"
    fake.upload_file = upload_file
    asyncio.run(tc.publisher._send_with_selfie(CHANNEL, "Сижу вечером на подоконнике.", "вечер"))
    assert prompts and "windowsill" in prompts[0][0] and "green knit sweater" in prompts[0][0]
    assert prompts[0][1] == "QUJD"                                   # референс на месте


def test_she_knows_what_she_is_wearing_today(monkeypatch, tmp_path):
    tc, _f, _s = _client(monkeypatch, tmp_path, ["a green knit sweater"])
    asyncio.run(tc.selfie_director.scene_for("вечер дома"))
    assert "Сегодня на мне (как на моих селфи): a green knit sweater" in tc.self_model.report()
    assert "Самонаблюдение" in tc.self_model.prompt_hint("а во что ты одета?")



# -------------------------------- скриншот 10:44: вид со стороны и круглый кадр
def test_selfie_is_a_front_camera_view_in_a_square():
    from marin_core.telegram import selfie
    gen = selfie.OpenRouterSelfieGenerator.__new__(selfie.OpenRouterSelfieGenerator)
    prompt = gen._build_prompt("дома у окна", use_reference=True)
    assert "front camera sees" in prompt and "looks straight into" in prompt
    assert "the phone itself is NOT visible" in prompt and "no circular frame" in prompt
    assert "phone visible in the frame" in prompt and "third-person view" in prompt   # в «избегать»
    assert "her own arm holding the phone" not in prompt


def test_square_aspect_is_requested_and_dropped_if_rejected(monkeypatch):
    import sys
    import types as pytypes
    from types import SimpleNamespace
    from marin_core.telegram import selfie
    bodies = []

    class R:
        def __init__(self, status):
            self.status_code, self.text = status, "unknown field image_config"

        def raise_for_status(self):
            if self.status_code >= 400:
                raise RuntimeError("400")

        def json(self):
            return {}

    queue = [R(400), R(200)]

    def post(url, json=None, headers=None, timeout=None):
        import copy
        bodies.append(copy.deepcopy(json))
        return queue.pop(0)

    monkeypatch.setitem(sys.modules, "requests", pytypes.SimpleNamespace(post=post))
    gen = selfie.OpenRouterSelfieGenerator(SimpleNamespace(model="m", api_key="k", base_url="https://x", timeout=5))
    gen._extract_image_bytes = lambda data: b"img"
    asyncio.run(gen.generate("дома", reference_image_b64="QUJD"))
    assert bodies[0]["image_config"] == {"aspect_ratio": "1:1"} and "image_config" not in bodies[1]


def test_reference_is_square_without_the_round_ring():
    import os
    try:
        from PIL import Image
    except ImportError:
        return  # на сервере Pillow может не быть — проверка ассета нужна только при сборке
    path = os.path.join(os.path.dirname(sd.__file__), "..", "assets", "marin_face_reference.jpg")
    im = Image.open(path).convert("RGB")
    assert im.size[0] == im.size[1]
    px = im.load()
    w, h = im.size
    for x, y in ((3, 3), (w - 4, 3), (w - 4, h - 4)):   # углы — не чистый чёрный фон круглого аватара
        r, g, b = px[x, y]
        assert not (r < 12 and g < 12 and b < 12), (x, y, px[x, y])


def test_director_asks_for_eye_contact_not_holding_a_phone(monkeypatch, tmp_path):
    tc, _f, seen = _client(monkeypatch, tmp_path, ["a knit sweater"])
    asyncio.run(tc.selfie_director.scene_for("утро дома"))
    assert "смотрит прямо в объектив, телефона в кадре нет" in seen[0].system_override
