"""Марин может сама начать что-то своё — без просьбы владельца — но
ограниченно (частота, лимит одновременных инициатив) и всегда прозрачно
(владелец сразу узнаёт и может отменить).

Note: ``CALLS``/``CHAT_SCRIPT`` are module-global fakes shared by the whole
test suite (many files push/pop from the same queue), so assertions here
check *counts* (``len(CALLS["chat"])`` before/after) rather than exact
queue contents, and tests that must NOT call the LLM at all avoid pushing
onto ``CHAT_SCRIPT`` in the first place.
"""
import asyncio
import os

import _fakes  # noqa: F401
from test_channel_publisher import CALLS, CHAT_SCRIPT, OWNER, make_client

from marin_core.goals.goals import GoalStatus


def fresh(**env):
    # env vars are process-global and persist across tests (run_tests.py runs
    # the whole suite in one interpreter) — always start from a known
    # baseline so an earlier test's override (e.g. ENABLED="false") can't leak.
    os.environ["MARIN_SELF_INITIATIVE_ENABLED"] = "true"
    for k, v in env.items():
        os.environ[k] = v
    tc, fake = make_client()
    return tc, fake


def own_goals(tc):
    return [g for g in tc.engine.goal_set.autonomous_goals(owner_id=OWNER) if g.context.get("self_initiated")]


def test_self_initiative_creates_goal_and_notifies_owner():
    tc, fake = fresh(MARIN_SELF_INITIATIVE_INTERVAL="0")
    n0 = len(CALLS["chat"])
    CHAT_SCRIPT.insert(0, "хочу написать пост про то, как пахнет осенний вечер")
    asyncio.run(tc.autonomous_life._self_initiative_pulse())

    assert len(CALLS["chat"]) == n0 + 1
    own = own_goals(tc)
    assert len(own) == 1
    owner_msgs = [t for eid, t in fake.sent if eid == int(OWNER)]
    assert owner_msgs and own[0].id[:8] in owner_msgs[0]


def test_self_initiative_skips_when_nothing_feels_worth_it():
    tc, fake = fresh(MARIN_SELF_INITIATIVE_INTERVAL="0")
    CHAT_SCRIPT.insert(0, "[SKIP]")
    asyncio.run(tc.autonomous_life._self_initiative_pulse())
    assert not own_goals(tc)
    assert not fake.sent


def test_self_initiative_respects_rate_limit():
    tc, fake = fresh(MARIN_SELF_INITIATIVE_INTERVAL="0")
    CHAT_SCRIPT.insert(0, "идея номер один")
    asyncio.run(tc.autonomous_life._self_initiative_pulse())
    assert len(own_goals(tc)) == 1

    # интервал по умолчанию для повторного вызова — 24ч; второй вызов сразу
    # после первого не должен создать ещё одну (и не должен даже дойти до LLM).
    tc.autonomous_life._self_initiative_interval = 24 * 3600.0
    n_before_second = len(CALLS["chat"])
    asyncio.run(tc.autonomous_life._self_initiative_pulse())
    assert len(own_goals(tc)) == 1
    assert len(CALLS["chat"]) == n_before_second  # второй вызов не дошёл до LLM


def test_self_initiative_respects_concurrent_cap():
    tc, fake = fresh(MARIN_SELF_INITIATIVE_INTERVAL="0", MARIN_SELF_INITIATIVE_MAX_CONCURRENT="1")
    tc.engine.add_autonomous_goal("уже занята своим делом", owner_id=OWNER, context={"self_initiated": True})
    n_before = len(CALLS["chat"])
    asyncio.run(tc.autonomous_life._self_initiative_pulse())
    assert len(own_goals(tc)) == 1  # лимит не дал завести вторую
    assert len(CALLS["chat"]) == n_before  # не дошла до LLM
    assert not fake.sent


def test_self_initiative_disabled_via_env_flag():
    tc, fake = fresh(MARIN_SELF_INITIATIVE_INTERVAL="0", MARIN_SELF_INITIATIVE_ENABLED="false")
    n_before = len(CALLS["chat"])
    asyncio.run(tc.autonomous_life._self_initiative_pulse())
    assert not own_goals(tc)
    assert len(CALLS["chat"]) == n_before


def test_owner_can_cancel_a_self_initiated_goal_like_any_other():
    """Прозрачность: та же команда `.отмена <id>`, что и для обычных целей."""
    tc, fake = fresh(MARIN_SELF_INITIATIVE_INTERVAL="0")
    goal_id = tc.goal_executor.create_goal_from_description(
        "личный проект", OWNER, context={"self_initiated": True})
    goal = tc.engine.goal_set.goals[goal_id]
    goal.status = GoalStatus.CANCELLED
    goal.active = False
    assert not [g for g in own_goals(tc) if g.active]
