"""Марин видит просмотры/реакции своих постов и учитывает, что заходит."""
import asyncio
import time

import _fakes
from _fakes import Msg
from marin_core.telegram import engagement as eng
from test_channel_publisher import CHANNEL, make_client


def entry_with_history(views_reactions, briefs=None):
    now = time.time()
    hist = []
    for i, (v, r) in enumerate(views_reactions):
        hist.append({"id": 100 + i, "at": now - (len(views_reactions) - i) * 3600,
                     "text": f"пост номер {i}", "brief": (briefs or {}).get(i, f"тема {i}"),
                     "views": v, "reactions_total": r, "reactions": {"❤": r}})
    return {"id": CHANNEL.id, "title": CHANNEL.title, "post_history": hist}


def test_score_rewards_reaction_rate_over_raw_views():
    entry = entry_with_history([(1000, 5), (1000, 60), (1000, 5), (1000, 5)])
    base_v, base_r = eng._baseline(entry["post_history"])
    hit = eng.score(entry["post_history"][1], base_v, base_r)
    flat = eng.score(entry["post_history"][0], base_v, base_r)
    assert hit > 0.5 and flat < 0 and hit > flat + 1.0  # хит явно выделяется на фоне обычных постов


def test_insights_need_enough_samples_and_name_real_briefs():
    small = entry_with_history([(1000, 50), (1000, 5)])
    assert eng.insights(small) == "", "по 2 постам рано делать выводы"
    entry = entry_with_history([(1000, 5), (1000, 80), (1000, 5), (1000, 5), (1000, 3)],
                               briefs={1: "личная история про переезд"})
    text = eng.insights(entry)
    assert "личная история про переезд" in text and "Хорошо зашло" in text


def test_deleted_post_is_excluded_from_scoring():
    entry = entry_with_history([(1000, 5), (1000, 5), (1000, 5), (1000, 5)])
    entry["post_history"][0]["deleted"] = True
    ranked = eng.ranked(entry)
    assert all(not h.get("deleted") for h in ranked) and len(ranked) == 3


def test_refresh_metrics_pulls_real_views_and_reactions_and_is_idempotent_until_due():
    tc, fake = make_client()
    tc._remember_own_channel(CHANNEL.id, title=CHANNEL.title, username=CHANNEL.username)
    entry = tc._own_channels[str(CHANNEL.id)]
    posted_at = time.time() - 2 * 3600  # проверка через 1ч уже наступила
    m = Msg("исходный текст", out=True, id_=555, views=1234, reactions={"🔥": 12, "❤": 3})
    fake.history.setdefault(CHANNEL.id, []).append(m)
    entry["post_history"] = [{"id": 555, "at": posted_at, "text": "исходный текст", "brief": "х"}]

    n = asyncio.run(tc.publisher.refresh_engagement(entry))
    assert n == 1
    item = entry["post_history"][0]
    assert item["views"] == 1234 and item["reactions_total"] == 15 and item["metrics_checks"] == 1

    n2 = asyncio.run(tc.publisher.refresh_engagement(entry))
    assert n2 == 0, "рано для следующей проверки (окно 6ч ещё не наступило)"

    m.views = 5000
    n3 = asyncio.run(tc.publisher.refresh_engagement(entry, force=True))
    assert n3 == 1 and entry["post_history"][0]["views"] == 5000


def test_deleted_message_is_marked_and_excluded():
    tc, fake = make_client()
    tc._remember_own_channel(CHANNEL.id, title=CHANNEL.title, username=CHANNEL.username)
    entry = tc._own_channels[str(CHANNEL.id)]
    entry["post_history"] = [{"id": 999, "at": time.time() - 5 * 3600, "text": "т", "brief": "б"}]
    asyncio.run(tc.publisher.refresh_engagement(entry))  # 999 нет в fake.history -> None
    assert entry["post_history"][0].get("deleted") is True


def test_insights_are_included_in_post_generation_context():
    tc, fake = make_client()
    tc._remember_own_channel(CHANNEL.id, title=CHANNEL.title, username=CHANNEL.username)
    entry = tc._own_channels[str(CHANNEL.id)]
    entry["post_history"] = entry_with_history(
        [(1000, 5), (1000, 90), (1000, 5), (1000, 4)], briefs={1: "честный рассказ про страх"}
    )["post_history"]
    from test_channel_publisher import CALLS
    asyncio.run(tc.publisher.publish("новая тема"))
    assert "честный рассказ про страх" in CALLS["post"][-1].situation_summary
