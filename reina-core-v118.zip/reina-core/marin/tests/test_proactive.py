"""Марин пишет первой — но не спамит."""
import asyncio
import datetime
import os
import tempfile

import _fakes
from _fakes import Event
from test_channel_publisher import make_client, OWNER, CHANNEL
from marin_core.telegram.channel_publisher import PublishResult
from marin_core.telegram.proactive import ProactiveLoop


def at(hour, minute=0, day=1):
    return datetime.datetime(2026, 10, day, hour, minute).timestamp()


def fresh():
    os.environ["MARIN_PROACTIVE_FILE"] = os.path.join(tempfile.mkdtemp(), "p.json")
    # тесты проверяют защитные рамки — не зависим от того, снял ли их владелец в своём .env
    os.environ["MARIN_PROACTIVE_MAX_PER_DAY"] = "4"
    os.environ["MARIN_PROACTIVE_MIN_GAP_HOURS"] = "2.5"
    tc, fake = make_client()
    tc.proactive = ProactiveLoop(tc)
    return tc, fake


def test_morning_once_per_day_in_window():
    tc, _ = fresh()
    p = tc.proactive
    p.state["last_owner_msg_at"] = at(1)
    assert p.due_reason(at(8, 30)) is None           # до окна
    assert p.due_reason(at(10, 59)) == "morning"      # план внутри 9–10:36
    p.state["done_today"]["morning"] = "2026-10-01"
    assert p.due_reason(at(10, 59)) != "morning"
    # новый день — план на "доброе утро" пересчитывается заново, а не залипает на вчера
    plan_day1 = p.state["planned"]["morning"]["date"]
    p._planned_time("morning", (9, 11), at(9, 30, day=2))
    assert p.state["planned"]["morning"]["date"] != plan_day1


def test_missing_after_silence_and_not_twice_without_answer():
    tc, _ = fresh()
    p = tc.proactive
    p.state["last_owner_msg_at"] = at(9)
    p.state["done_today"]["morning"] = "2026-10-01"
    assert p.due_reason(at(12)) is None               # 3 ч тишины — рано
    assert p.due_reason(at(15)) == "missing"
    p.state.update(last_proactive_at=at(15), last_proactive_answered=False)
    assert p.due_reason(at(20)) is None               # не ответил — второй раз не пишет
    p.on_owner_message()
    assert p.state["last_proactive_answered"] is True


def test_daily_cap_and_disable():
    tc, _ = fresh()
    p = tc.proactive
    p.state["last_owner_msg_at"] = at(1)
    p.state["sent_log"] = [[at(12) - i * 60, "missing"] for i in range(4)]
    assert p.due_reason(at(16)) is None
    p.state["sent_log"] = []
    p.set_enabled(False)
    assert p.due_reason(at(16)) is None


def test_send_writes_to_owner_and_persists_state():
    tc, fake = fresh()
    ok = asyncio.run(tc.proactive.send("missing"))
    assert ok
    owner_msgs = [t for cid, t in fake.sent if cid == int(OWNER)]
    assert owner_msgs and not any("<<<" in t for t in owner_msgs)
    again = ProactiveLoop(tc)                          # «рестарт»
    assert again.state["last_proactive_answered"] is False and again.state["sent_log"]


def test_shares_new_autopost_with_link_once():
    tc, fake = fresh()
    res = PublishResult(ok=True, channel_title="Мысли Марин", link="https://t.me/marin_thoughts/42")
    asyncio.run(tc.proactive.on_autopost(res))
    asyncio.run(tc.proactive.on_autopost(res))
    msgs = [t for cid, t in fake.sent if cid == int(OWNER)]
    assert sum("t.me/marin_thoughts/42" in t for t in msgs) == 1


def test_owner_can_switch_off_by_phrase():
    tc, fake = fresh()
    ev = Event("не пиши мне первой", fake, int(OWNER))
    asyncio.run(tc._process_batch([ev], chat=int(OWNER), chat_id=OWNER, sender_id=OWNER))
    assert tc.proactive.enabled is False
    ev = Event("можешь снова писать мне первой", fake, int(OWNER))
    asyncio.run(tc._process_batch([ev], chat=int(OWNER), chat_id=OWNER, sender_id=OWNER))
    assert tc.proactive.enabled is True
