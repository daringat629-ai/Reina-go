import ast
from pathlib import Path

def test_telegram_actions_facade_exists():
    src = Path("marin_core/telegram/actions.py").read_text(encoding="utf-8")
    tree = ast.parse(src)
    names = {n.name for n in tree.body if isinstance(n, ast.ClassDef)}
    assert "ActionRegistry" in names
    assert "TelegramActions" in names

def test_client_wires_facade():
    src = Path("marin_core/telegram/client.py").read_text(encoding="utf-8")
    assert "TelegramActions" in src
    assert "self.telegram_actions = TelegramActions(self.client)" in src
