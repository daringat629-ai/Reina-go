"""deploy21: независимость Марин — близость не зашита, селфи/голосовые и посты по её воле."""
import asyncio
import json
import os
import tempfile

import _fakes
from test_channel_publisher import make_client, OWNER, CHANNEL
from marin_core.social.social_model import SocialModel
from marin_core.telegram.proactive import ProactiveLoop
from marin_core.engine.autonomous_life import AutonomousLifeLoop


def _fresh():
    os.environ["MARIN_PROACTIVE_FILE"] = os.path.join(tempfile.mkdtemp(), "p.json")
    os.environ["OWN_CHANNELS_FILE"] = os.path.join(tempfile.mkdtemp(), "own.json")
    tc, fake = make_client()
    tc.proactive = ProactiveLoop(tc)
    return tc, fake


def test_owner_bond_is_not_hardcoded_by_default(monkeypatch):
    monkeypatch.delenv("MARIN_OWNER_FIXED_BOND", raising=False)
    sm = SocialModel()
    node_before = sm.get_or_create("owner").relationship
    base_trust, base_close = node_before.trust, node_before.closeness
    sm.mark_owner("owner")
    rel = sm.get_or_create("owner").relationship
    assert rel.trust == base_trust and rel.closeness == base_close
    assert rel.trust < 0.95 and rel.closeness < 0.9
    # взаимодействие может и снизить близость — пол больше не держит её наверху
    sm.observe_interaction("owner", -1.0)
    assert sm.get_or_create("owner").relationship.closeness <= base_close


def test_owner_bond_legacy_switch(monkeypatch):
    monkeypatch.setenv("MARIN_OWNER_FIXED_BOND", "true")
    sm = SocialModel()
    sm.mark_owner("owner")
    rel = sm.get_or_create("owner").relationship
    assert rel.trust >= 0.95 and rel.closeness >= 0.9


def test_proactive_can_send_selfie_and_voice_on_her_own(monkeypatch):
    monkeypatch.setenv("MARIN_PROACTIVE_MEDIA_ENABLED", "true")
    tc, fake = _fresh()
    calls = []

    async def selfie(action):
        calls.append((action.kind, json.loads(action.payload)))
        return "Готово, отправила селфи."

    async def voice(action):
        calls.append((action.kind, json.loads(action.payload)))
        return "Готово, отправила голосовое."

    tc._action_send_selfie = selfie
    tc._action_send_voice_message = voice
    sent = asyncio.run(tc.proactive.deliver(
        ["<<<SELFIE:дома вечером с чаем>>>", "<<<VOICE:скучно без тебя, ахах>>>", "привет"]
    ))
    assert sent == 3
    assert calls[0][0] == "send_selfie" and calls[0][1]["chat"] == int(OWNER)
    assert calls[0][1]["prompt"] == "дома вечером с чаем"
    assert calls[1][0] == "send_voice_message" and calls[1][1]["text"] == "скучно без тебя, ахах"
    assert any(t == "привет" for cid, t in fake.sent if cid == int(OWNER))


def test_proactive_media_can_be_switched_off(monkeypatch):
    monkeypatch.setenv("MARIN_PROACTIVE_MEDIA_ENABLED", "false")
    tc, _ = _fresh()
    calls = []

    async def selfie(action):
        calls.append(action)
        return "Готово"

    tc._action_send_selfie = selfie
    sent = asyncio.run(tc.proactive.deliver(["<<<SELFIE:x>>>"]))
    assert sent == 0 and not calls


def test_skip_is_respected_without_retry_storm():
    tc, _ = _fresh()
    p = tc.proactive

    async def skip(reason, extra=None):
        p._skipped = True
        return []

    p.compose = skip
    assert asyncio.run(p.send("morning")) is False
    import time
    assert p.state["skip_until"] > time.time()
    assert p.state["done_today"]["morning"]           # «доброе утро» на сегодня не навязывается
    assert p.due_reason() is None                     # и не дёргается каждую минуту


def test_autopost_default_on_for_own_channels_and_explicit_off_respected():
    tc, fake = _fresh()
    life = AutonomousLifeLoop(tc)
    # она creator этого канала — он становится её каналом без команд
    asyncio.run(life._adopt_own_channels())
    entry = tc._own_channels[str(CHANNEL.id)]
    assert entry["autopost_enabled"] is True and entry["autopost_interval"] > 0

    # владелец явно выключил — не включаем обратно
    entry["autopost_enabled"] = False
    life._last_channel_adopt = 0.0
    asyncio.run(life._adopt_own_channels())
    assert tc._own_channels[str(CHANNEL.id)]["autopost_enabled"] is False


def test_adoption_can_be_disabled(monkeypatch):
    monkeypatch.setenv("MARIN_AUTONOMOUS_CHANNEL_ADOPT", "false")
    tc, _ = _fresh()
    life = AutonomousLifeLoop(tc)
    asyncio.run(life._adopt_own_channels())
    assert not tc._own_channels
