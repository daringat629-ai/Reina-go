import asyncio
import datetime
import time

from marin_core.telegram.reminders import ReminderStore, parse_reminder


def _dt(ts):
    return datetime.datetime.fromtimestamp(ts)


def test_relative_and_absolute_times():
    now = time.time()
    r = parse_reminder("напомни через 2 часа позвонить маме", now)
    assert r and abs(r.when_ts - (now + 7200)) < 1 and r.text == "позвонить маме"
    r = parse_reminder("Напомни мне через полчаса выпить воды", now)
    assert r and abs(r.when_ts - (now + 1800)) < 1 and "выпить воды" in r.text
    r = parse_reminder("напомни завтра в 10 купить хлеб", now)
    assert r and r.text == "купить хлеб" and _dt(r.when_ts).hour == 10
    assert _dt(r.when_ts).date() == (_dt(now) + datetime.timedelta(days=1)).date()
    r = parse_reminder("напомни в пятницу про встречу", now)
    assert r and _dt(r.when_ts).weekday() == 4 and _dt(r.when_ts).hour == 10 and r.when_ts > now


def test_not_a_reminder():
    assert parse_reminder("привет как дела") is None
    assert parse_reminder("не напоминай мне про это") is None
    assert parse_reminder("напомни позвонить") is None  # нет времени — путь через LLM


def test_store_persists_due_and_gives_up(tmp_path):
    path = str(tmp_path / "rem.json")
    st = ReminderStore(path)
    now = time.time()
    a = st.add(now - 5, "чай", now=now - 100)
    st.add(now + 3600, "позже", now=now)
    assert [r.text for r in ReminderStore(path).due(now)] == ["чай"]
    st.mark_done(a.id)
    assert ReminderStore(path).due(now) == []
    b = st.add(now - 1, "ещё", now=now)
    for _ in range(3):
        st.bump_attempt(b.id)
    assert st.due(now) == []


def test_proactive_delivers_due_reminder_once(tmp_path, monkeypatch):
    monkeypatch.setenv("MARIN_REMINDERS_FILE", str(tmp_path / "rem.json"))
    monkeypatch.setenv("MARIN_PROACTIVE_FILE", str(tmp_path / "pro.json"))
    from marin_core.telegram.proactive import ProactiveLoop

    class Cfg:
        owner_id = 1

    class TC:
        config = Cfg()

    loop = ProactiveLoop(TC())
    delivered = []

    async def compose(reason, extra=None):
        assert reason == "reminder" and "чай" in extra["text"]
        return ["пора пить чай)"]

    async def deliver(msgs):
        delivered.append(msgs)
        return 1

    loop.compose, loop.deliver = compose, deliver
    loop.reminders.add(time.time() - 1, "чай")
    assert asyncio.run(loop.pulse()) == "reminder"
    assert delivered == [["пора пить чай)"]]
    assert asyncio.run(loop._send_due_reminders()) == 0


def test_capability_question_gets_truthful_abilities():
    from marin_core.telegram.self_awareness import CAPABILITY_QUESTION_RE as R
    assert R.search("Хмм а какие тебе функции добавить? Чего не хватает")
    assert R.search("что ты умеешь")
    assert not R.search("какая погода")


def _loop(tmp_path, monkeypatch):
    monkeypatch.setenv("MARIN_REMINDERS_FILE", str(tmp_path / "rem.json"))
    monkeypatch.setenv("MARIN_PROACTIVE_FILE", str(tmp_path / "pro.json"))
    from marin_core.telegram.proactive import ProactiveLoop

    class Cfg:
        owner_id = 1

    class TC:
        config = Cfg()

    return ProactiveLoop(TC())


def _noon_ts():
    d = datetime.datetime.now().replace(hour=14, minute=0, second=0, microsecond=0)
    return d.timestamp()


def test_impulse_is_unrestricted_by_default_and_limits_are_opt_in(tmp_path, monkeypatch):
    import marin_core.telegram.proactive as pr
    monkeypatch.setattr(pr, "_is_quiet_hours", lambda now=None: True)  # глубокая ночь — всё равно можно
    monkeypatch.setattr(pr, "local_now", lambda now=None: datetime.datetime.fromtimestamp(now or time.time()))
    loop = _loop(tmp_path, monkeypatch)
    now = _noon_ts()
    loop.state.update(last_owner_msg_at=now - 6 * 3600, last_proactive_at=now - 60,
                      last_proactive_answered=False,
                      sent_log=[[now - 100 * i, "impulse"] for i in range(1, 10)])
    monkeypatch.setattr(pr.random, "random", lambda: 0.0)
    assert loop._impulse_due(now) is True                    # без пауз, потолков, тихих часов
    assert loop._impulse_due(now + 30) is False              # частота «прислушивания» к желанию
    loop.state.update(next_impulse_check=0, last_owner_msg_at=now - 30)
    assert loop._impulse_due(now) is False                   # не посреди живого разговора
    # рамки включаются только явно
    loop.state.update(next_impulse_check=0, last_owner_msg_at=now - 6 * 3600)
    monkeypatch.setenv("MARIN_PROACTIVE_IMPULSE_MAX_PER_DAY", "3")
    assert loop._impulse_due(now) is False
    monkeypatch.delenv("MARIN_PROACTIVE_IMPULSE_MAX_PER_DAY")
    monkeypatch.setenv("MARIN_PROACTIVE_IMPULSE_RESPECT_QUIET_HOURS", "true")
    loop.state["next_impulse_check"] = 0
    assert loop._impulse_due(now) is False
    monkeypatch.setenv("MARIN_PROACTIVE_IMPULSE_ENABLED", "false")
    monkeypatch.delenv("MARIN_PROACTIVE_IMPULSE_RESPECT_QUIET_HOURS")
    loop.state["next_impulse_check"] = 0
    assert loop._impulse_due(now) is False


def test_impulse_skip_is_not_sent_as_text(tmp_path, monkeypatch):
    import marin_core.telegram.proactive as pr
    loop = _loop(tmp_path, monkeypatch)

    class Prov:
        def generate(self, pin):
            return "[SKIP]"

    class Planner:
        provider = Prov()

    class Eng:
        language_planner = Planner()
        personality = None

        class diary:
            @staticmethod
            def recent(n):
                return []

    loop._tc.engine = Eng()
    loop._tc._media_catalog_hint = lambda: ""
    loop._tc.owner_name = "Х"
    loop._tc.allow_emoji = False

    async def hist(owner):
        return []

    loop._history = hist
    assert asyncio.run(loop.compose("impulse", {"facts": ""})) == []
