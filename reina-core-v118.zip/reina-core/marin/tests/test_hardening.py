"""Регрессионные тесты для исправлений из аудита (hardening pass).

Каждый тест воспроизводит конкретный баг, который был в коде до исправления:
  * опечатка в .env роняла весь процесс ещё на импорте;
  * один сбойный стикер отменял всю пачку vision-каталогизации;
  * np.mean по матрице возвращал вектор вместо скаляра;
  * векторы разной длины молча обрезались вместо ошибки;
  * неверный MARIN_TIMEZONE молча давал время сервера без лога.
"""
import asyncio
import logging
import os
import subprocess
import sys

import _fakes  # noqa: F401  (изолированное окружение + telethon stub)
import marin_core.telegram.media as media_mod
import marin_core.telegram.settings as settings_mod
from marin_core.env import env_bool, env_float, env_int
from marin_core.numeric import Vector, np
from test_channel_publisher import make_client
from test_vision_cooldown import Doc, _ForceVisionEnabled

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


# ------------------------------------------------------------------ env.py
def test_env_float_accepts_comma_and_falls_back_on_garbage(monkeypatch):
    monkeypatch.setenv("MARIN_T_F", "2,5")
    assert env_float("MARIN_T_F", 1.0) == 2.5
    monkeypatch.setenv("MARIN_T_F", "30s")
    assert env_float("MARIN_T_F", 1.0) == 1.0
    monkeypatch.setenv("MARIN_T_F", "")
    assert env_float("MARIN_T_F", 1.5) == 1.5
    monkeypatch.setenv("MARIN_T_F", "-5")
    assert env_float("MARIN_T_F", 1.0, minimum=0.0) == 0.0
    monkeypatch.setenv("MARIN_T_F", "999")
    assert env_float("MARIN_T_F", 1.0, maximum=1.0) == 1.0


def test_env_int_accepts_float_notation_and_falls_back(monkeypatch):
    monkeypatch.setenv("MARIN_T_I", "3.0")
    assert env_int("MARIN_T_I", 1) == 3
    monkeypatch.setenv("MARIN_T_I", "three")
    assert env_int("MARIN_T_I", 7) == 7


def test_env_bool_understands_russian_and_keeps_default_on_unknown(monkeypatch):
    monkeypatch.setenv("MARIN_T_B", "да")
    assert env_bool("MARIN_T_B", False) is True
    monkeypatch.setenv("MARIN_T_B", "OFF")
    assert env_bool("MARIN_T_B", True) is False
    # раньше любое незнакомое значение молча превращалось в False
    monkeypatch.setenv("MARIN_T_B", "maybe")
    assert env_bool("MARIN_T_B", True) is True


def test_bad_env_value_does_not_crash_import():
    """До исправления: float(os.getenv(...)) на уровне модуля → ValueError
    при импорте → бот не стартует вообще. Импорт в отдельном процессе, потому
    что константы settings.py вычисляются один раз при первом импорте."""
    env = dict(os.environ)
    env.update({
        "MARIN_TELEGRAM_DEBOUNCE_SECONDS": "2,5 sec",
        "MARIN_QUIET_HOURS_START": "abc",
        "MARIN_VISION_CATALOG_CONCURRENCY": "много",
        "MARIN_STATE_BACKUPS": "x",
    })
    code = (
        "import sys; sys.path.insert(0, 'tests'); import telethon_stub; telethon_stub.install();"
        "from marin_core.telegram import settings as s;"
        "import marin_core.telegram.client;"
        "print(s.DEBOUNCE_SECONDS, s.QUIET_HOURS_START, s.VISION_CATALOG_CONCURRENCY)"
    )
    proc = subprocess.run([sys.executable, "-c", code], cwd=ROOT, env=env,
                          capture_output=True, text=True, timeout=60)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout.strip().split() == ["2.5", "2", "50"], proc.stdout


# --------------------------------------------------------------- numeric.py
def test_numeric_mean_of_matrix_is_scalar():
    assert np.mean(np.array([[1, 2], [3, 4]])) == 2.5
    assert float(np.mean([[1.0, 3.0]])) == 2.0
    assert list(np.mean([[1, 2], [3, 4]], axis=0)) == [2.0, 3.0]
    assert np.mean([]) == 0.0


def test_numeric_shape_mismatch_raises_like_numpy():
    for op in (lambda a, b: a + b, lambda a, b: a - b, lambda a, b: a * b):
        try:
            op(Vector([1.0, 2.0]), Vector([1.0, 2.0, 3.0]))
        except ValueError:
            pass
        else:
            raise AssertionError("dimension mismatch was silently truncated")
    try:
        np.dot([1.0, 2.0], [1.0])
    except ValueError:
        pass
    else:
        raise AssertionError("np.dot accepted misaligned vectors")
    # скалярный broadcast по-прежнему работает
    assert list(Vector([1.0, 2.0]) * 2) == [2.0, 4.0]


# ----------------------------------------------------------------- media.py
def test_one_crashing_item_does_not_abort_vision_catalog(monkeypatch):
    """До исправления исключение в одном элементе уходило через
    asyncio.gather и отменяло каталогизацию всех остальных."""
    monkeypatch.setenv("MARIN_OPENROUTER_API_KEY", "test-key")
    with _ForceVisionEnabled():
        tc, _fake = make_client()
        ids = [501, 502, 503]
        tc._sticker_catalog[:] = [Doc(i) for i in ids]
        tc._sticker_meta.clear()
        for i in ids:
            tc._sticker_meta[i] = {"pack": "p", "alt": "", "vision": ""}
        tc._vision_cache.clear()
        tc._vision_failures.clear()

        async def source_bytes(doc):
            if doc.id == 502:
                raise ConnectionError("download exploded")
            return b"bytes", "image/jpeg"

        async def describe(raw, mime, prompt):
            return "котик машет лапой"

        tc._get_vision_source_bytes = source_bytes
        tc._vision_describe_bytes = describe
        asyncio.run(tc._ensure_vision_catalog())

        assert tc._vision_cache.get("501") == "котик машет лапой"
        assert tc._vision_cache.get("503") == "котик машет лапой"
        assert "502" in tc._vision_failures and "502" not in tc._vision_cache


# -------------------------------------------------------------- settings.py
def test_invalid_timezone_warns_once_and_falls_back(monkeypatch):
    monkeypatch.setattr(settings_mod, "MARIN_TIMEZONE", "Mars/Olympus_Mons")
    settings_mod._TZ_CACHE.clear()
    records = []

    class _H(logging.Handler):
        def emit(self, record):
            records.append(record)

    handler = _H(level=logging.WARNING)
    settings_mod.logger.addHandler(handler)
    try:
        a = settings_mod.local_now(1_700_000_000)
        b = settings_mod.local_now(1_700_000_000)
    finally:
        settings_mod.logger.removeHandler(handler)
        settings_mod._TZ_CACHE.clear()
    assert a == b and a.tzinfo is None  # время сервера, без падения
    tz_warnings = [r for r in records if "MARIN_TIMEZONE" in r.getMessage()]
    assert len(tz_warnings) == 1, [r.getMessage() for r in records]


def test_local_now_respects_explicit_zero_timestamp():
    # раньше `now or time.time()` путал 0.0 с «не передано»
    assert settings_mod.local_now(0.0).year in (1969, 1970)


def test_valid_timezone_is_applied(monkeypatch):
    monkeypatch.setattr(settings_mod, "MARIN_TIMEZONE", "UTC")
    settings_mod._TZ_CACHE.clear()
    try:
        dt = settings_mod.local_now(0.0)
    finally:
        settings_mod._TZ_CACHE.clear()
    if dt.tzinfo is not None:  # tzdata может отсутствовать в минимальных образах
        assert (dt.year, dt.hour) == (1970, 0)
