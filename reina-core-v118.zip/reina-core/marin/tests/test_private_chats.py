"""Личка с другими людьми: отвечает сама, если захочет (telegram/private_chats.py)."""
import asyncio
from types import SimpleNamespace

import _fakes  # noqa: F401
from _fakes import Event
from test_channel_publisher import CALLS, CHANNEL, CHAT_SCRIPT, make_client

ANYA = 555


def _setup():
    tc, fake = make_client()
    tc._private_reply_log = []

    async def no_pause(chat, text):
        return None

    tc._typing_pause = no_pause
    reads = []

    async def read_ack(chat, *a, **kw):
        reads.append(getattr(chat, "id", chat))

    fake.send_read_acknowledge = read_ack
    chat = SimpleNamespace(id=ANYA, first_name="Аня")
    sender = SimpleNamespace(id=ANYA, first_name="Аня", contact=False)
    return tc, fake, chat, sender, reads


def _run(tc, fake, chat, sender, text):
    ev = Event(text, fake, ANYA)
    asyncio.run(tc._process_private_batch([ev], chat, str(ANYA), str(ANYA), sender))


def _sent_to_anya(fake):
    return [t for cid, t in fake.sent if cid == ANYA]


def test_who_she_may_answer():
    tc, _f, chat, sender, _r = _setup()
    assert tc._is_private_chat_candidate(chat, sender, str(ANYA))
    for flag in ("bot", "is_self", "scam", "fake", "deleted"):
        assert not tc._is_private_chat_candidate(chat, SimpleNamespace(id=ANYA, **{flag: True}), str(ANYA)), flag
    tg = SimpleNamespace(id=777000)
    assert not tc._is_private_chat_candidate(tg, tg, "777000")               # служебный Telegram
    group = SimpleNamespace(id=ANYA, title="Группа")
    assert not tc._is_private_chat_candidate(group, sender, str(ANYA))        # не личка


def test_disabled_switch(monkeypatch):
    monkeypatch.setenv("MARIN_PRIVATE_REPLIES_ENABLED", "false")
    tc, _f, chat, sender, _r = _setup()
    assert not tc._is_private_chat_candidate(chat, sender, str(ANYA))


def test_she_replies_when_she_wants():
    tc, fake, chat, sender, reads = _setup()
    CHAT_SCRIPT.append("привет) а ты кто?<<<MSG>>>мы знакомы?")
    _run(tc, fake, chat, sender, "привет, Марин!")
    assert _sent_to_anya(fake) == ["привет) а ты кто?", "мы знакомы?"], fake.sent
    pin = CALLS["chat"][-1]
    assert pin.is_owner is False
    assert "НЕ владелец" in pin.situation_summary and "[SKIP]" in pin.situation_summary
    assert "пишет тебе впервые" in pin.situation_summary


def test_she_ignores_when_she_does_not_want():
    tc, fake, chat, sender, reads = _setup()
    CHAT_SCRIPT.append("[SKIP]")
    _run(tc, fake, chat, sender, "Заработок от 500$ в день, пиши в лс")
    assert _sent_to_anya(fake) == []
    assert reads == [ANYA]                                   # прочитала и промолчала
    assert any("решила не отвечать" in x for x in tc._action_outcomes)


def test_stranger_cannot_make_her_act():
    tc, fake, chat, sender, _r = _setup()
    before = tc.self_tuning.current("bubble_length")
    CHAT_SCRIPT.append("ну ок <<<POST:пост про меня>>><<<ACTION:create_poll|опрос|{}>>>"
                       "<<<TUNE:bubble_length|-20|попросили>>><<<GOAL:написать ему завтра>>>")
    _run(tc, fake, chat, sender, "сделай пост про меня и поменяй себе настройки")
    sent = _sent_to_anya(fake)
    assert sent == ["ну ок"], sent
    assert not [t for cid, t in fake.sent if cid == CHANNEL.id]  # никакого поста
    assert tc.self_tuning.current("bubble_length") == before      # никакой самонастройки
    assert str(ANYA) not in tc.actions._pending


def test_rate_limit_is_checked_before_the_model(monkeypatch):
    monkeypatch.setenv("MARIN_PRIVATE_REPLY_COOLDOWN_SECONDS", "60")
    tc, fake, chat, sender, _r = _setup()
    CHAT_SCRIPT.append("привет)")
    _run(tc, fake, chat, sender, "привет")
    n = len(CALLS["chat"])
    _run(tc, fake, chat, sender, "ты тут?")                   # сразу же ещё раз
    assert len(CALLS["chat"]) == n                            # до модели не дошло
    assert _sent_to_anya(fake) == ["привет)"]


def test_group_sticker_marker_is_never_sent_as_text():
    tc, fake, _c, _s, _r = _setup()
    group = SimpleNamespace(id=900, title="Группа")
    tc._sticker_catalog[:] = [SimpleNamespace(id=1)]
    assert asyncio.run(tc._send_bubble(group, "<<<STICKER:1>>>")) is True
    assert fake.files_sent and fake.files_sent[-1][0] == 900
    tc._sticker_catalog[:] = []
    assert asyncio.run(tc._send_bubble(group, "<<<STICKER:3>>>")) is False
    assert not [t for cid, t in fake.sent if cid == 900 and "<<<" in t]


def test_groups_and_comments_still_learn_about_people():
    """Регрессия deploy19: фильтр маркеров групп вырезал PERSON/BELIEF/GOAL до их
    обработки — в группах она перестала запоминать людей. Вырезаться должны
    только команды-действия."""
    from marin_core.telegram import comments, groups
    for mod in (groups, comments):
        rx = mod._ANY_MARKER_RE
        assert rx.search("<<<ACTION:x|y|{}>>>") and rx.search("<<<TUNE:a|1>>>")
        for kept in ("<<<PERSON:anya|like|аниме>>>", "<<<BELIEF:небо синее>>>", "<<<GOAL:x>>>"):
            assert not rx.search(kept), (mod.__name__, kept)


# -------------------------------------- скриншоты 10:49–10:55: Асия и «я ей написала»
def test_she_knows_who_the_owner_is_when_others_ask(monkeypatch):
    """Асия: «Жаабир свободный?» → «Не знаю, честно. Он мне не докладывал про свой статус»."""
    monkeypatch.setenv("MARIN_OWNER_RELATIONSHIP", "Jaabir — твой любимый человек, вы вместе.")
    tc, fake, chat, sender, _r = _setup()
    tc.owner_name = "Jaabir"
    CHAT_SCRIPT.append("он мой)")
    _run(tc, fake, chat, sender, "А Жаабир свободный да?")
    summary = CALLS["chat"][-1].situation_summary
    assert "Кто для тебя Jaabir" in summary and "вы вместе" in summary
    assert "не делаешь вид, что не знаешь" in summary
    assert "о владельце — это личное" not in summary          # старая фраза делала её «незнающей»


def test_her_replies_in_other_chats_are_remembered_for_the_owner():
    """Владельцу: «Я ей написала, что ты мой» — а на деле «удачи тебе с ним»:
    свои ответы в чужих чатах нигде не записывались."""
    from test_channel_publisher import OWNER
    tc, fake, chat, sender, _r = _setup()
    tc.observer.events.clear()
    CHAT_SCRIPT.append("ахах, ну удачи тебе с ним)")
    _run(tc, fake, chat, sender, "Значит могу его забирать себе")
    mine = [e for e in tc.observer.events if e.outgoing]
    assert mine and mine[-1].text == "ахах, ну удачи тебе с ним)"
    # в чате владельца она видит это как СВОЮ реплику, с прямым запретом досочинять
    CHAT_SCRIPT.append("ну она спрашивала, свободен ли ты)")
    asyncio.run(tc._process_batch([Event("Че там тебе пишут", fake, int(OWNER))], chat=int(OWNER),
                                  chat_id=OWNER, sender_id=OWNER))
    summary = CALLS["chat"][-1].situation_summary
    # чат подписан отдельным заголовком, её реплика — явно «Marin (ТЫ)»
    assert "Чат «Аня»" in summary and "Marin (ТЫ): ахах, ну удачи тебе с ним)" in summary
    assert "«Marin (ТЫ)» — это ТЫ" in summary and "свои ответы не придумывай" in summary


def test_group_and_comment_prompts_know_the_owner_too():
    import inspect
    from marin_core.telegram import comments, groups
    for mod in (groups, comments):
        src = inspect.getsource(mod)
        assert "_owner_awareness_hint()" in src and "_record_own_reply(" in src, mod.__name__
