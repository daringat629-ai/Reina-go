"""Регрессия по логу с сервера: сломанный стикер не должен скачиваться и
уходить в Vision API заново при КАЖДОМ рестарте."""
import asyncio
import json
import os

import _fakes
import marin_core.telegram.media as media_mod
from test_channel_publisher import make_client


class _ForceVisionEnabled:
    """VISION_ENABLED в media.py — константа, зафиксированная при импорте
    (тесты глобально ставят MARIN_VISION_ENABLED=false). Включаем на время теста."""

    def __enter__(self):
        self._old = media_mod.VISION_ENABLED
        media_mod.VISION_ENABLED = True
        return self

    def __exit__(self, *a):
        media_mod.VISION_ENABLED = self._old


class Doc:
    def __init__(self, id_):
        self.id = id_
        self.thumbs = None
        self.mime_type = "image/jpeg"


def _setup(broken_ids, ok_ids):
    tc, fake = make_client()
    tc._sticker_catalog[:] = [Doc(i) for i in broken_ids + ok_ids]
    tc._sticker_meta.clear()
    for i in broken_ids + ok_ids:
        tc._sticker_meta[i] = {"pack": "p", "alt": "", "vision": ""}

    async def fake_source_bytes(doc):
        return b"fake-bytes", "image/jpeg"

    tc._get_vision_source_bytes = fake_source_bytes

    async def fake_describe(raw, mime, prompt):
        # определяем, какой doc сейчас обрабатывается, по счётчику вызовов
        idx = fake_describe.calls
        fake_describe.calls += 1
        return "" if idx < len(broken_ids) else "милый стикер с котиком"
    fake_describe.calls = 0
    tc._vision_describe_bytes = fake_describe
    return tc, fake


def test_broken_item_is_not_retried_on_next_restart():
    os.environ["MARIN_OPENROUTER_API_KEY"] = "test-key"
    ctx = _ForceVisionEnabled()
    ctx.__enter__()
    try:
        tc, fake = _setup(broken_ids=[111], ok_ids=[222])
        asyncio.run(tc._ensure_vision_catalog())
        assert tc._vision_cache.get("222") == "милый стикер с котиком"
        assert "111" in tc._vision_failures and "111" not in tc._vision_cache

        # «рестарт»: новый клиент читает те же файлы реестра с диска
        tc2, fake2 = make_client()
        tc2._sticker_catalog[:] = [Doc(111), Doc(222)]
        tc2._sticker_meta.clear()
        tc2._sticker_meta[111] = {"pack": "p", "alt": "", "vision": ""}
        tc2._sticker_meta[222] = {"pack": "p", "alt": "", "vision": tc.engine.beliefs and ""}
        calls = []

        async def source_bytes(doc):
            calls.append(doc.id)
            return b"fake-bytes", "image/jpeg"

        tc2._get_vision_source_bytes = source_bytes
        tc2._vision_describe_bytes = lambda *a, **kw: (_ for _ in ()).throw(AssertionError("не должна вызываться"))
        tc2._vision_cache = dict(tc._vision_cache)
        tc2._vision_failures = dict(tc._vision_failures)
        asyncio.run(tc2._ensure_vision_catalog())
        assert calls == [], f"сломанный/уже описанный стикер не должен качаться заново: {calls}"
    finally:
        ctx.__exit__()
        del os.environ["MARIN_OPENROUTER_API_KEY"]


def test_failure_registry_persists_to_disk_and_reloads():
    os.environ["MARIN_OPENROUTER_API_KEY"] = "test-key"
    ctx = _ForceVisionEnabled()
    ctx.__enter__()
    try:
        tc, fake = _setup(broken_ids=[333], ok_ids=[])
        asyncio.run(tc._ensure_vision_catalog())
        assert os.path.exists(tc.__class__ and __import__("marin_core.telegram.settings", fromlist=["x"]).VISION_FAILURES_FILE)
        from marin_core.telegram.settings import VISION_FAILURES_FILE
        with open(VISION_FAILURES_FILE) as fh:
            data = json.load(fh)
        assert "333" in data

        tc2, _ = make_client()
        assert "333" in tc2._vision_failures, "реестр отказов должен подхватываться при старте"
    finally:
        ctx.__exit__()
        del os.environ["MARIN_OPENROUTER_API_KEY"]


def test_cooldown_expiry_allows_retry():
    os.environ["MARIN_OPENROUTER_API_KEY"] = "test-key"
    ctx = _ForceVisionEnabled()
    ctx.__enter__()
    try:
        tc, fake = _setup(broken_ids=[], ok_ids=[444])
        tc._vision_failures["444"] = 0.0  # «упало» давно, кулдаун прошёл
        asyncio.run(tc._ensure_vision_catalog())
        assert tc._vision_cache.get("444") == "милый стикер с котиком"
        assert "444" not in tc._vision_failures, "успех должен снимать пометку об отказе"
    finally:
        ctx.__exit__()
        del os.environ["MARIN_OPENROUTER_API_KEY"]


def test_still_within_cooldown_is_skipped_without_download():
    os.environ["MARIN_OPENROUTER_API_KEY"] = "test-key"
    ctx = _ForceVisionEnabled()
    ctx.__enter__()
    try:
        tc, fake = _setup(broken_ids=[], ok_ids=[555])
        tc._vision_failures["555"] = __import__("time").time()  # только что упало
        calls = []

        async def source_bytes(doc):
            calls.append(doc.id)
            return b"x", "image/jpeg"
        tc._get_vision_source_bytes = source_bytes
        asyncio.run(tc._ensure_vision_catalog())
        assert calls == [] and "555" not in tc._vision_cache
    finally:
        ctx.__exit__()
        del os.environ["MARIN_OPENROUTER_API_KEY"]
