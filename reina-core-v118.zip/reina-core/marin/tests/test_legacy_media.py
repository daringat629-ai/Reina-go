"""Стикеры/эмодзи из прошлых версий Марин подхватываются и реально отправляются."""
import asyncio
import json
import os
import tempfile

import _fakes
from _fakes import FakeTelethon
from marin_core.telegram.legacy_media import LocalSticker, discover
from test_channel_publisher import make_client, OWNER


def _tree():
    root = tempfile.mkdtemp(prefix="mari_")
    old1 = os.path.join(root, "marin_x_deploy3")
    old2 = os.path.join(root, "old", "marin_v30", "data")
    os.makedirs(os.path.join(old1, "stickers"))
    os.makedirs(old2)
    os.makedirs(os.path.join(root, "marin_x_deploy3", ".venv", "lib", "stickers"))
    json.dump({"MarinPack": {"short_name": "MarinPack", "kind": "addstickers"}},
              open(os.path.join(old1, "marin_media_packs.json"), "w"))
    json.dump(["https://t.me/addemoji/MarinEmoji", "HeartsPack"],
              open(os.path.join(old2, "marin_media_packs.json"), "w"))
    json.dump({"123456789": "Марин смеётся", "bad": "x"},
              open(os.path.join(old2, "marin_media_vision_cache.json"), "w"))
    for name in ("happy_hug.webp", "sticker_12.tgs", "copy_of_hug.webp"):
        with open(os.path.join(old1, "stickers", name), "wb") as fh:
            fh.write(b"RIFF....WEBP" if "hug" in name else b"tgs-bytes")
    # дубликат содержимого — должен схлопнуться
    with open(os.path.join(old1, "stickers", "copy_of_hug.webp"), "wb") as fh:
        fh.write(b"RIFF....WEBP")
    with open(os.path.join(root, "marin_x_deploy3", ".venv", "lib", "stickers", "x.webp"), "wb") as fh:
        fh.write(b"venv-junk")
    with open(os.path.join(old1, "photo.webp"), "wb") as fh:  # не в папке стикеров — игнор
        fh.write(b"not a sticker")
    return root


def test_discover_finds_packs_vision_and_files_across_versions():
    root = _tree()
    os.environ["MARIN_STICKER_PACK"] = "https://t.me/addstickers/EnvPack"
    try:
        found = discover([root])
    finally:
        del os.environ["MARIN_STICKER_PACK"]
    assert {"marinpack", "marinemoji", "heartspack", "envpack"} <= set(found.packs)
    assert found.packs["marinemoji"]["kind"] == "emoji"
    assert found.vision == {"123456789": "Марин смеётся"}
    names = sorted(os.path.basename(f.path) for f in found.files)
    assert len(found.files) == 2 and "sticker_12.tgs" in names  # дубль схлопнут, .venv и photo.webp пропущены
    hug = next(f for f in found.files if f.path.endswith("hug.webp"))
    assert "hug" in hug.meaning


class MediaFake(FakeTelethon):
    def __init__(self):
        super().__init__([])
        self.files_sent = []

    async def __call__(self, request):
        name = type(request).__name__
        if name in ("GetAllStickersRequest", "GetEmojiStickersRequest"):
            return type("R", (), {"sets": []})()
        raise RuntimeError(name)

    async def send_file(self, chat, file, **kw):
        self.files_sent.append((chat, file, kw))


def test_client_imports_legacy_and_sends_local_sticker():
    root = _tree()
    os.environ["MARIN_LEGACY_MEDIA_DIRS"] = root
    try:
        tc, _ = make_client()
        tc.client = MediaFake()
        tc._media_packs.clear()
        summary = tc._import_legacy_media()
        assert "+3 паков" in summary, summary
        assert "MarinPack" in tc._media_packs and tc._vision_cache.get("123456789") == "Марин смеётся"
        asyncio.run(tc._load_media_catalog())
        local = [d for d in tc._sticker_catalog if isinstance(d, LocalSticker)]
        assert len(local) == 2
        hint = tc._media_catalog_hint()
        assert "сохранённые стикеры" in hint
        idx = tc._sticker_catalog.index(local[0]) + 1
        assert asyncio.run(tc._send_sticker(int(OWNER), idx))
        chat, path, kw = tc.client.files_sent[-1]
        assert path == local[0].path and kw.get("attributes")
        # повторный импорт не дублирует паки
        assert "+0 паков" in tc._import_legacy_media()
    finally:
        del os.environ["MARIN_LEGACY_MEDIA_DIRS"]


def test_hint_rotates_whole_catalog_with_real_indices():
    tc, _ = make_client()
    tc._sticker_catalog[:] = [LocalSticker(path=f"/x/{i}.webp", id=10_000 + i, meaning=f"m{i}") for i in range(200)]
    tc._sticker_meta.clear()
    for d in tc._sticker_catalog:
        tc._sticker_meta[d.id] = {"pack": "p", "alt": d.meaning, "vision": ""}
    seen = set()
    for _ in range(15):
        for line in tc._media_catalog_hint().splitlines():
            if line.startswith("S"):
                n = int(line[1:line.index(":")])
                assert tc._sticker_meta[tc._sticker_catalog[n - 1].id]["alt"] in line  # индекс = реальный
                seen.add(n)
    assert max(seen) > 60 and len(seen) > 150
