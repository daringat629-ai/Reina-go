import _fakes  # noqa: F401
from marin_core.telegram.intents import (
    AutopostIntent, DeleteLastPostIntent, PostIntent, detect_intent, parse_interval,
)


def test_plain_post_requests():
    for phrase in ("сделай пост", "Марин, сделай пост на канал", "запости что-нибудь", "давай пост",
                   "пост сделаешь?", "надо бы канал оживить", "напиши пост"):
        assert isinstance(detect_intent(phrase), PostIntent), phrase


def test_topic_channel_selfie_verbatim():
    i = detect_intent("кинь в канал что-нибудь про дождь, пожалуйста")
    assert isinstance(i, PostIntent) and i.brief == "про дождь"
    i = detect_intent("надо пост про новый год в канал @marin_thoughts")
    assert i.brief == "про новый год" and i.channel_hint == "marin_thoughts"
    i = detect_intent("напиши пост в «Мысли Марин» про сон")
    assert i.channel_hint == "Мысли Марин" and i.brief == "про сон"
    assert detect_intent("выложи пост с селфи").with_selfie
    i = detect_intent("опубликуй дословно: Всем привет, я вернулась!")
    assert i.verbatim_text == "Всем привет, я вернулась!"
    assert detect_intent("сделай пост: осень, дождь, кофе").brief == "осень, дождь, кофе"


def test_not_a_request():
    for phrase in ("ты уже выложила пост?", "как сделать пост в телеге?", "не делай пост сегодня",
                   "привет как дела", "что там в канале было", "я сегодня написал пост в свой блог",
                   "почитай мой последний пост", ""):
        assert detect_intent(phrase) is None, phrase


def test_delete_and_autopost():
    assert isinstance(detect_intent("удали последний пост"), DeleteLastPostIntent)
    i = detect_intent("веди канал сама, постить 2 раза в день")
    assert isinstance(i, AutopostIntent) and i.enable and i.interval_seconds == 43200
    i = detect_intent("пости каждые 3 часа про аниме")
    assert i.interval_seconds == 10800 and i.brief == "про аниме"
    i = detect_intent("перестань постить")
    assert isinstance(i, AutopostIntent) and not i.enable


def test_parse_interval():
    assert parse_interval("раз в неделю") == 604800
    assert parse_interval("каждый день") == 86400
    assert parse_interval("три раза в день") == 28800
    assert parse_interval("просто так") is None
