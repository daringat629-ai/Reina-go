"""Ядро понимания/обучения: Interpretation -> Beliefs -> Prediction ->
Decision -> Outcome -> Learning -> Metacognition."""
import _fakes  # noqa: F401

from marin_core import CognitiveEngine
from marin_core.action.action import ActionType, SILENT_ACTIONS
from marin_core.interpretation import IntentClassifier, focal_text
from marin_core.llm.providers import CallableProvider, build_default_prompt
from marin_core.persistence import export_engine_state, import_engine_state

CAPTURED = []


def _engine():
    def gen(p):
        CAPTURED.append(p)
        return "ага<<<MSG>>>поняла"
    return CognitiveEngine(llm_provider=CallableProvider(gen))


def _tick(e, text, actor="u1", owner=True, **kw):
    return e.tick(text, channel_id="telegram:1", source_actor_id=actor, is_owner=owner, **kw)


# ------------------------------------------------------------ INTERPRET

def test_interpretation_is_structured():
    e = _engine()
    r = _tick(e, "Расскажи про Marin X?")
    i = r.interpretation
    d = i.to_dict()
    for key in ("intent", "topic", "tone", "facts", "uncertainties", "hypotheses", "belief_updates", "entities"):
        assert key in d, key
    assert i.intent in ("question", "request")
    assert i.topic == "marin x"
    assert "Marin X" in i.entities
    assert i.tone == "curious"
    assert r.situation.interpretation is i


def test_focal_text_ignores_telegram_context_blob():
    blob = ("[Контекст переписки]\nВладелец: это ужасно, бесит?\nMarin: ну ладно\n"
            "[Новые сообщения владельца]\nспасибо, очень круто")
    assert focal_text(blob) == "спасибо, очень круто"
    e = _engine()
    r = _tick(e, blob)
    assert r.interpretation.intent == "gratitude"
    assert r.interpretation.valence > 0  # тон из текущей реплики, а не из истории
    assert r.situation.tone.valence > 0


def test_question_vs_request_is_not_treated_as_confusion():
    e = _engine()
    r = _tick(e, "расскажи, как устроена память в этом ядре?")
    assert r.action.type == ActionType.ANSWER
    assert r.interpretation.uncertainty < 0.4


def test_real_classifier_falls_back_on_error_and_is_counted():
    e = _engine()

    class Boom:
        def classify(self, text):
            raise RuntimeError("boom")

    e.situation_builder.action_classifier._primary.classifier = Boom()
    r = _tick(e, "привет?")
    assert r.situation.action.value == "ask_question"  # _DefaultActionClassifier: "?" в конце
    assert e.fallback_stats.counts.get("action_classifier") == 1


# ------------------------------------------------------------ BELIEFS

def test_belief_revision_reinforces_and_records_contradiction():
    e = _engine()
    r1 = _tick(e, "я люблю кофе")
    assert [x.kind for x in r1.belief_revisions] == ["created"]
    bid = r1.belief_revisions[0].belief_id
    b = e.beliefs.get(bid)
    assert b.source == "user_statement" and b.subject == "u1" and b.evidence
    assert b.evidence[0].get("memory_id")  # evidence привязан к узлу памяти

    c0 = b.confidence
    r2 = _tick(e, "я очень люблю кофе")
    assert r2.belief_revisions[0].kind == "reinforced"
    assert e.beliefs.get(bid).confidence > c0

    r3 = _tick(e, "я не люблю кофе")
    rev = r3.belief_revisions[0]
    assert rev.kind == "contradicted"
    assert "не любит" in e.beliefs.get(bid).statement
    old = e.beliefs.get(rev.previous_id)
    assert old.status == "superseded" and "любит кофе" in old.statement  # не стёрто
    flag = e.beliefs.open_contradictions()[-1]
    assert flag.old_statement and flag.new_statement and flag.key.endswith("likes:кофе")
    assert any("противоречит" in u for u in r3.interpretation.uncertainties)
    # LLM узнаёт о противоречии
    assert any("contradicts what you knew" in c for c in CAPTURED[-1].constraints)

    # повторное подтверждение нового закрывает противоречие
    _tick(e, "я не люблю кофе")
    assert not [c for c in e.beliefs.open_contradictions() if c.key == flag.key]


def test_remember_and_forget_actions():
    e = _engine()
    r = _tick(e, "запомни, что у меня встреча в 9")
    assert ActionType.REMEMBER in [a.type for a in r.secondary_actions]
    notes = [b for _, b in e.beliefs.about("u1") if "встреча" in b.statement]
    assert notes and notes[0].confirmed and notes[0].confidence >= 0.9

    _tick(e, "я люблю чай")
    r = _tick(e, "забудь, что я люблю чай")
    assert ActionType.FORGET in [a.type for a in r.secondary_actions]
    assert not r.belief_revisions  # "забудь, что я люблю X" — не новое свидетельство
    assert not [b for _, b in e.beliefs.about("u1") if "чай" in b.statement]


# ------------------------------------------------------------ PREDICTION + LEARNING

def test_prediction_has_explicit_assumptions():
    e = _engine()
    r = _tick(e, "как дела?")
    a = r.prediction.assumptions
    assert a["intent"] == "question" and a["action"] == r.action.type.value
    assert "relationship_valence" in a and "correction_risk" in a


def test_action_complaint_changes_future_decision():
    e = _engine()
    first = _tick(e, "хм")
    assert first.action.type in (ActionType.ASK, ActionType.CLARIFY)
    asked = first.action.type
    r = _tick(e, "не переспрашивай")
    lr = r.learning_report
    assert lr is not None and lr.attribution.source == "action"
    assert e.learner.action_values.get("small_talk", asked.value).value < 0
    again = _tick(e, "хм")
    assert again.action.type == ActionType.ANSWER  # решение изменилось


def test_meaning_correction_learns_pattern_and_shifts_intent():
    e = _engine()
    msg = "расскажи анекдот про кота"
    base = IntentClassifier().classify(msg)[0][0]
    assert base == "request"
    sources = []
    for _ in range(4):
        _tick(e, msg)
        r = _tick(e, "да я просто пошутил")
        sources.append(r.learning_report.attribution.source)
    # сначала ошибка в понимании; когда паттерн выучен и intent уже верный,
    # та же фраза атрибутируется к действию, а не к intent
    assert sources[0] == "intent" and sources[1] == "intent"
    assert set(sources) <= {"intent", "action"}
    r = _tick(e, msg)
    i = r.interpretation
    assert i.applied_pattern is not None
    assert i.applied_pattern.misread_intent == "request"
    probs = dict(i.hypotheses)
    assert probs["small_talk"] > probs.get("request", 0) * 0.5
    # после ещё нескольких подтверждений паттерн становится "уроком" в памяти
    def lessons():
        return [n for n in e.memory.all_nodes() if isinstance(n.payload, dict) and n.payload.get("kind") == "lesson"]
    for _ in range(6):
        if lessons():
            break
        _tick(e, "да я просто пошутил")
        _tick(e, msg)
    assert lessons()
    assert "small_talk" in lessons()[0].payload["summary"]


def test_belief_denial_weakens_used_belief():
    e = _engine()
    e.remember_fact("user_city", "Владелец живёт в Казани", confidence=0.8)
    _tick(e, "где я живу, в Казани?")
    b = e.beliefs.get("fact:user_city")
    before = b.confidence
    r = _tick(e, "это неправда, я не живу в Казани")
    assert r.learning_report.attribution.source == "belief"
    assert e.beliefs.get("fact:user_city").confidence < before


def test_social_expectation_learns_from_cold_reactions():
    e = _engine()
    for _ in range(3):
        _tick(e, "расскажи что-нибудь", actor="grumpy", owner=False)
        _tick(e, "ужасно, бесит", actor="grumpy", owner=False)
    assert e.learner.social.bias("grumpy") < 0
    r = _tick(e, "расскажи что-нибудь", actor="grumpy", owner=False)
    assert r.prediction.assumptions["social_bias"] < 0


# ------------------------------------------------------------ DECISION

def test_decision_candidates_cover_full_action_set():
    e = _engine()
    r = _tick(e, "привет!")
    types = {c.action_type.value for c in r.decision.candidates}
    for t in ("answer", "ask", "clarify", "ignore", "remember", "forget", "search", "observe", "defer", "act"):
        assert t in types, t
    c = r.decision.candidates[0].to_dict()
    for k in ("expected_value", "risk", "confidence", "goal_alignment", "social_cost", "expected_response"):
        assert k in c


def test_addressed_messages_are_never_silently_ignored():
    e = _engine()
    for text in ("ну", "…", "бесит всё", "."):
        r = _tick(e, text, actor="rando", owner=False)
        assert r.action.type not in SILENT_ACTIONS


def test_not_addressed_group_chatter_is_observed():
    e = _engine()
    r = _tick(e, "у нас в чате кто-то написал фигню", actor="rando", owner=False, addressed=False)
    assert r.action.type == ActionType.OBSERVE
    assert r.generated_text is None


def test_custom_candidates_still_restrict_primary():
    from marin_core.goals.motivation import ActionCandidate
    e = _engine()
    r = e.tick("хм", channel_id="c", source_actor_id="u", action_candidates_fn=lambda *a: [
        ActionCandidate(action_type="answer", cost=0.1)])
    assert r.action.type == ActionType.ANSWER


# ------------------------------------------------------------ METACOGNITION + LLM + PERSISTENCE

def test_tick_metacognition_and_explain():
    e = _engine()
    _tick(e, "Расскажи про Marin X?")
    r = _tick(e, "ты не так поняла")
    m = r.meta
    assert 0 <= m.knowledge <= 1 and 0 <= m.uncertainty <= 1
    assert m.reason and m.decision_confidence > 0
    assert any("ошибка в intent" in x for x in m.errors)
    text = e.explain_last()
    for k in ("Knowledge:", "Uncertainty:", "Prediction confidence:", "Decision confidence:", "Reason:"):
        assert k in text


def test_llm_gets_interpretation_but_decision_is_made_before():
    e = _engine()
    _tick(e, "я люблю кофе")
    p = CAPTURED[-1]
    assert "self_disclosure" in p.interpretation_summary
    prompt = build_default_prompt(p)
    assert "How I understood the latest message" in prompt


def test_learning_survives_export_import():
    e1 = _engine()
    _tick(e1, "хм")
    _tick(e1, "не переспрашивай")
    _tick(e1, "я люблю кофе")
    data = export_engine_state(e1)
    e2 = _engine()
    counts = import_engine_state(e2, data)
    assert counts["learned_action_values"] >= 1
    k = next(iter(e1.learner.action_values.values))
    assert e2.learner.action_values.values[k].value == e1.learner.action_values.values[k].value
    b2 = e2.beliefs.find_by_key("person:u1:likes:кофе")
    assert b2 is not None and b2[1].evidence and b2[1].subject == "u1"


def test_old_snapshot_without_new_fields_still_imports():
    e1 = _engine()
    e1.remember_fact("x", "old fact")
    data = export_engine_state(e1)
    for d in data["beliefs"]["beliefs"].values():
        for k in ("key", "subject", "polarity", "status", "created_at", "evidence"):
            d.pop(k, None)
    data.pop("learning", None)
    e2 = _engine()
    import_engine_state(e2, data)
    assert e2.beliefs.get("fact:x").status == "active"
