"""Канал из настоящих мыслей, а не случайных тем (telegram/inner_thoughts.py)."""
import asyncio
import datetime

import _fakes  # noqa: F401
from test_channel_publisher import CHANNEL, OWNER, make_client

from marin_core.llm.providers import CallableProvider


def _scripted(tc, reflect_answer):
    """Модель: шаг «подумать» отвечает reflect_answer, пост — обычным текстом.
    Заодно — чистое прошлое: наблюдатель и дневник лежат в общих tmp-файлах
    тестового прогона, и «новости» соседних тестов не должны сюда просочиться."""
    tc.observer.events.clear()
    tc.engine.diary.entries.clear()
    seen = {"reflect": [], "post": []}

    def llm(pin):
        if pin.system_override and "честно думаешь про себя" in pin.system_override:
            seen["reflect"].append(pin)
            return reflect_answer
        seen["post"].append(pin)
        return "Сегодня поняла одну вещь: когда что-то не выходит, это ещё не конец. Попробую иначе."
    tc.engine.language_planner.provider = CallableProvider(llm)
    return seen


def _news(tc, n=3, text="опрос опять не создался, @kitagawa_room https://t.me/x"):
    for i in range(n):
        tc.observer.record(chat_id=OWNER, chat_title="Jaabir", sender_id=OWNER, sender_name="Jaabir",
                           username="jaabir", text=f"{text} {i}", outgoing=False, media=False)


def _enable(tc):
    tc._remember_own_channel(CHANNEL.id, title=CHANNEL.title, username=CHANNEL.username)
    asyncio.run(tc.publisher.set_autopost(True, interval_seconds=3600))


def test_autopost_stays_silent_when_nothing_happened():
    tc, fake = make_client()
    seen = _scripted(tc, "что-то")
    _enable(tc)
    res = asyncio.run(tc.publisher.autopost_tick())
    assert res and not res[0].ok and res[0].extra.get("skipped")
    assert not [t for cid, t in fake.sent if cid == CHANNEL.id]  # ничего не выдумала
    assert not seen["reflect"]                                   # даже не звала модель


def test_autopost_is_built_from_a_real_thought():
    tc, fake = make_client()
    thought = "Меня бесит, когда я что-то обещаю, а оно не получается — но я не сдаюсь."
    seen = _scripted(tc, thought)
    _enable(tc)
    _news(tc)
    res = asyncio.run(tc.publisher.autopost_tick())
    assert res and res[0].ok, res
    post_prompt = seen["post"][-1].system_override
    assert "Это твоя настоящая мысль прямо сейчас" in post_prompt and thought in post_prompt
    assert "Не выдумывай событий" in post_prompt


def test_reflection_material_is_anonymized():
    tc, _ = make_client()
    seen = _scripted(tc, "мысль")
    _enable(tc)
    _news(tc)
    asyncio.run(tc.publisher.autopost_tick())
    material = seen["reflect"][-1].situation_summary
    assert "близкий человек" in material and "опрос опять не создался" in material
    for private in ("Jaabir", "jaabir", "kitagawa_room", "t.me/x"):
        assert private not in material, private


def test_honest_nothing_to_say_skips_the_post():
    tc, fake = make_client()
    _scripted(tc, "[НЕЧЕГО]")
    _enable(tc)
    _news(tc)
    res = asyncio.run(tc.publisher.autopost_tick())
    assert res and res[0].extra.get("skipped") and "нечего" in res[0].error
    assert not [t for cid, t in fake.sent if cid == CHANNEL.id]


def test_own_channel_posts_do_not_count_as_news():
    tc, _ = make_client()
    _scripted(tc, "мысль")
    _enable(tc)
    for i in range(5):
        tc.observer.record(chat_id=str(CHANNEL.id), chat_title=CHANNEL.title, sender_id=str(CHANNEL.id),
                           sender_name="канал", username="", text=f"мой же пост {i}", outgoing=True, media=False)
    res = asyncio.run(tc.publisher.autopost_tick())
    assert res and res[0].extra.get("skipped")


def test_topicless_owner_post_request_also_uses_a_real_thought():
    tc, fake = make_client()
    seen = _scripted(tc, "Сегодня я поняла, что меня радуют мелочи в разговорах.")
    tc._remember_own_channel(CHANNEL.id, title=CHANNEL.title, username=CHANNEL.username)
    res = asyncio.run(tc.publisher.publish("на твой выбор", source="owner"))
    assert res.ok and seen["reflect"]  # новостей нет, но по просьбе — думает всё равно
    assert "Это твоя настоящая мысль" in seen["post"][-1].system_override
    # с конкретной темой от владельца — пишет про неё, без «подумать»
    n = len(seen["reflect"])
    asyncio.run(tc.publisher.publish("про косплей", source="owner"))
    assert len(seen["reflect"]) == n


def test_post_uses_local_time_not_server_clock(monkeypatch):
    import marin_core.telegram.channel_publisher as cp
    monkeypatch.setattr(cp, "local_now", lambda now=None: datetime.datetime(2026, 9, 27, 0, 40))
    tc, _ = make_client()
    seen = _scripted(tc, "мысль")
    tc._remember_own_channel(CHANNEL.id, title=CHANNEL.title, username=CHANNEL.username)
    asyncio.run(tc.publisher.publish("про ночь", source="owner"))
    summary = seen["post"][-1].situation_summary
    assert "27.09.2026 00:40 (ночь" in summary, summary
