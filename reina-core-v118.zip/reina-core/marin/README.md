# Marin X — когнитивное ядро

> **deploy19:** фильтр качества ответов, посты по целям без «да», контекст свайп-ответов, короткие сообщения, самонаблюдение и самонастройка в рамках (`.я`, `.настройки`) — см. `LIVE_CHAT_FIXES.md`.
>
> **deploy5:** Марин сама ведёт свой канал — «сделай пост» публикуется сразу, без подтверждений. Архитектура, анализ и список изменений — в `ARCHITECTURE.md`. Тесты: `python run_tests.py`.

Новое когнитивное ядро Marin, отделённое от старой инфраструктуры v30
(Telegram/vision/voice/memory-интерфейсов). Формальная спецификация со
всеми формулами — в `MARIN_X_CORE_SPEC.md`. Этот README — только про то,
как запустить и куда двигаться дальше.

## Структура

```
marin_core/
├── engine/          # CognitiveEngine (фасад), cycle.py (тик из §16), scheduler.py (idle consolidation)
├── state/           # LatentState (z_t), CognitiveState, StateTransitionModel (GRU-переход, §1.2)
├── identity/        # IdentityModel (§4, почти неизменна), PersonalityDynamics (приор поведения)
├── perception/      # Observation, SituationModel (§2), Attention (§3)
├── memory/          # MemoryGraph, retrieval (§5), ExperienceSystem, ConsolidationEngine (§14)
├── world/           # Entities/Relations/Events/CausalModel — модель мира, отдельно от памяти опыта
├── social/          # RelationshipState, TheoryOfMindStore, SocialModel (§11)
├── belief/          # BeliefStore (§7), HypothesisSet (§8), contradiction detection (§7.2)
├── goals/           # GoalSet (иерархия, §10.1), NeedState (§10.2), utility/conflict (§10.3)
├── prediction/       # Predictor, prediction_error (§6)
├── reasoning/        # режимы reasoning (§9), causal_reasoning, planning (beam search, §9)
├── decision/          # DecisionEngine — собирает всё в одно решение (§16 decide)
├── learning/          # LearningEngine — разные τ для разных слоёв (§12)
├── metacognition/      # MetacognitionEngine, self-reflection (§13, п.21 документа)
├── action/             # Action / ActionType (не только текст, см. §18 документа), validation
└── llm/                # LLM как языковой орган, не источник решений (§17)
```

## Статус реализации (по приоритету из §18 спеки)

| Приоритет | Модули | Статус |
|---|---|---|
| 1 | state, engine/cycle | ✅ реализовано |
| 2 | perception (situation, attention) | ✅ реализовано (с эвристическими классификаторами по умолчанию) |
| 3 | memory (graph, retrieval) | ✅ реализовано |
| 4 | prediction | ✅ реализовано |
| 5 | decision | ✅ реализовано |
| 6 | llm/interface | ✅ реализовано (с заглушкой-провайдером для офлайн-тестов) |
| 7 | belief, hypotheses, social, metacognition, consolidation, world, reasoning, learning | ✅ каркас реализован, требует замены эвристик на настоящие модели |

Все модули **компилируются и связаны друг с другом** через `CognitiveEngine`
(`engine/cognitive_engine.py`), цикл можно прогнать end-to-end уже сейчас —
см. `smoke_test.py`.

## Что здесь намеренно упрощено (и что заменить в первую очередь)

1. ~~**Эмбеддинги**~~ — сделано: `llm/embeddings.py` — реальный sentence-embedder
   (Ollama `nomic-embed-text` по умолчанию, либо OpenAI-совместимый API),
   с проекцией в общий `EMBED_DIM`, кэшированием и автоматическим fallback
   на прежний хэш-эмбеддинг (`HashEmbedder`), если сеть/модель недоступны —
   см. `config.py::build_embedder` и `MARIN_EMBEDDING_*` в
   `marin_core.env.example`. Хэш-эмбеддинг остаётся дефолтом для
   `CognitiveEngine()` без аргументов (холодный старт/тесты).
2. **SituationBuilder classifiers** — `_Default*` классы в
   `cognitive_engine.py` (entity linking, action classification, tone) —
   примитивные эвристики. Заменяются на reasoning-engine-based версии
   (`reasoning/reasoning.py`, режим `fast_reasoning`).
3. **StateTransitionModel** — веса GRU инициализированы случайно
   (`TransitionWeights.random_init`). Обучение — офлайн, контракт данных
   зафиксирован в `learning/adaptation.py::TransitionDataset`.
4. **Contradiction detection** (`belief/contradictions.py`) — косинусная
   эвристика вместо NLI-классификатора. Явно помечено предупреждением в
   docstring — не использовать в проде как есть.
5. **LLMProvider** — по умолчанию `EchoLocalProvider` (без сети). Подключение
   реального провайдера — `llm/providers.py::CallableProvider`, обёртка
   вокруг существующего клиента v30.

## Быстрый запуск

```bash
pip install -r requirements.txt
python smoke_test.py
```

`smoke_test.py` создаёт `CognitiveEngine`, прогоняет несколько тиков с
текстовыми наблюдениями и печатает выбранное действие + сгенерированный
текст на каждом шаге — это подтверждает, что весь пайплайн
(perception → situation → attention → retrieval → prediction → decision →
llm → memory write) собран и работает end-to-end.

## Подключение к v30-инфраструктуре

`CognitiveEngine.tick(raw_input, channel_id=..., source_actor_id=...)` —
единственная точка входа, которую должен вызывать Telegram/vision/voice
слой. Ядро не импортирует и не знает про v30 — интеграция односторонняя:

```python
from marin_core import CognitiveEngine
from marin_core.llm.providers import CallableProvider

def call_existing_v30_llm_client(planning_input) -> str:
    ...  # обёртка вокруг вашего текущего LLM-клиента

engine = CognitiveEngine(llm_provider=CallableProvider(call_existing_v30_llm_client))

result = engine.tick(
    "как дела?",
    channel_id="telegram:12345",
    source_actor_id="user:678",
)
print(result.action.type, result.generated_text)
```

## Владелец (owner)

Инфраструктура (например, сопоставление по Telegram `user_id`) решает, что
текущий собеседник — владелец, и передаёт это в `engine.tick(..., is_owner=True)`.
Ядро само не определяет, кто владелец — оно только запоминает это решение
через `SocialModel.mark_owner` и с этого момента:

- `RelationshipState.trust`/`closeness` сразу высокие (0.95 / 0.9) — не нужно
  "зарабатывать" их с нуля, как с обычными акторами (`social/social_model.py`).
- Стиль общения переключается на `PersonalityDynamics.owner_style_prior`
  (более неформальный, без внутренней сдержанности) вместо обычного
  `style_prior` (`identity/presets.py`).
- Приоритет внимания в групповых чатах: для владельца `retrieval_k`
  увеличивается (`TickDependencies.owner_retrieval_boost`), а
  `situation.relationship_relevance` форсируется в 1.0, что поднимает
  `social_salience` в attention/retrieval score (§3, §5.2 спеки).
- `IdentityModel.owner_description` — заранее заданный текст про значимость
  владельца, передаётся в LLM как `relationship_context` (§17 спеки).
- Ограничения (`Invariant`) можно пометить `applies_to_owner=False` — тогда
  `ActionValidator` их не проверяет для владельца. В пресете Marin это
  применено к инвариантам про косплей/аниме — с владельцем эти темы разрешены,
  со всеми остальными — по-прежнему блокируются архитектурно.

См. `owner_test.py` — проверяет все четыре эффекта end-to-end.

## Конфигурация (.env)

`marin_core/config.py` — единственное место в ядре, читающее переменные
окружения. Обрезанный `.env` под текущий объём ядра лежит рядом,
`marin_core.env`, полный список того, что удалено и почему — прямо в его
конце. Сейчас ядро отвечает только за подключение LLM и `MARIN_OWNER_ID`;
Telegram/vision/voice/веб-панель/старый self-model-слой пока не читаются
здесь — либо это инфраструктура снаружи ядра, либо системы, которые
marin_core заменяет собственной архитектурой.

```python
from marin_core.config import build_engine

engine = build_engine(env_path="marin_core.env")  # OpenRouter -> Ollama -> Echo fallback-цепочка

result = engine.tick(
    "привет!",
    channel_id="telegram:12345",
    source_actor_id="123456789",
    is_owner=True,  # инфраструктура решает это сама, сверяя с MARIN_OWNER_ID
)
```

См. `config_test.py` — загружает `marin_core.env` и собирает провайдер-цепочку
без реального сетевого вызова (в этой песочнице сеть недоступна; в реальном
окружении `OpenAICompatProvider` делает обычный POST на `/chat/completions`).

## Дальнейшие шаги

1. ~~Заменить `_hash_embed` на настоящий embedder.~~ Сделано — см. `llm/embeddings.py`.
1a. ~~Селфи (генерация нового фото, не пересылка существующего).~~ Сделано —
   см. `telegram/selfie.py` + `telegram/client.py::_action_send_selfie`.
   Реакции/стикеры/медиа-паки уже были реализованы (`send_reaction`,
   `send_sticker`, `_add_media_pack_from_url`) — новых изменений не
   потребовалось. ~~Голос (генерация нового аудио, не пересылка)~~ — тоже
   сделано, см. `telegram/voice.py` + `_action_send_voice_message` (ElevenLabs,
   MP3 -> OGG/Opus через ffmpeg для настоящего "голосового" пузыря в
   Telegram; без ffmpeg на сервере отправляется как обычный аудиофайл).
   `send_voice`/`send_audio`/`send_video_note` остаются пересылкой уже
   присланного владельцем файла — это отдельные kind'ы, не заменены.
   Истории/Stories — НЕ реализовано (нужен отдельный разбор raw Telethon
   `stories`-API, сюда пока не входит).
2. Подключить `BeliefStore`/`HypothesisSet` в `engine/cycle.py` (сейчас шаг
   INTERPRET упрощён — belief/hypothesis engine существуют, но ещё не
   вызываются из тика).
3. Подключить `SocialModel` для relationship_relevance в attention/retrieval.
4. Подключить `MetacognitionEngine` + `ConsolidationScheduler` к реальному
   расписанию (cron/asyncio в v30-слое).
5. Обучить `StateTransitionModel` на логах через `learning/adaptation.py`.

## Telegram / Telethon

Marin X now includes a first-party Telegram transport in `marin_core.telegram`.
The transport is intentionally thin: Telethon handles Telegram I/O and
authorization; `CognitiveEngine.tick()` remains the only cognitive entry point.

Install:

```bash
pip install -r requirements.txt
```

Set these variables in `.env`:

```env
TELEGRAM_API_ID=123456
TELEGRAM_API_HASH=your_api_hash
MARIN_TELEGRAM_SESSION=marin_x
MARIN_TELEGRAM_PHONE=+996XXXXXXXXX
MARIN_OWNER_ID=123456789
```

Then run:

```bash
python run_telegram.py
```

On the first launch Telethon asks for the Telegram login code and, when enabled
on the account, the 2FA password. The session is persisted in the configured
Telethon session file, so subsequent launches normally do not require a new code.

Message flow:

`Telegram event -> TextPerceptionAdapter -> CognitiveEngine.tick() -> DecisionEngine -> LLM -> ActionValidator -> generated_text -> Telegram reply`

The synchronous LLM provider is executed in a worker thread so it does not block
Telethon's asyncio event loop.


## Alpine / NumPy-free build
This build contains no NumPy dependency. Vector and matrix operations used by the reference core are implemented in `marin_core/numeric.py` using Python `list` + `math` + `random`. Telegram transport remains Telethon-based.


## Marin X Telegram Observer / Owner Mode

- Marin observes incoming Telegram messages and marks them as read.
- Non-owner users never reach the LLM and never receive replies.
- Owner is `MARIN_OWNER_ID`; display name is `MARIN_OWNER_NAME=Жаабир`.
- Telegram events and lightweight person profiles persist to `marin_telegram_activity.json`.
- Owner questions such as `кто тебе сегодня писал` / `что происходило в Telegram` use the observer summary.
- Recent Telegram observations are injected into the owner's cognitive context.
- Final replies pass through an emoji-free output gate by default (`MARIN_ALLOW_EMOJI=false`).
- Observer storage is bounded by `MARIN_TELEGRAM_OBSERVER_MAX_EVENTS` (default 2500).

## Fixed10 Telegram human-media behavior
- Reply delay defaults to 5 seconds after the debounce window.
- One response may contain up to 4 short Telegram messages.
- Classic Unicode emoji are stripped from text.
- Telegram custom/Premium emoji and stickers can be emitted through internal markers and are taken from the logged-in user's installed collection.
- Owner images are described by OpenRouter Vision using `openai/gpt-4o` via `MARIN_OPENROUTER_VISION_MODEL`. GPT-4o accepts image input and returns text descriptions.


## Fixed11 — semantic Telegram media + 2-3 message rhythm
- Marin receives a compact catalog of the real stickers/custom emoji installed/available on her Telegram account, including pack name and Telegram alt/meaning.
- The LLM can select a concrete item with `<<<STICKER:N>>>` or `<<<CUSTOM_EMOJI:N>>>`; no invented indexes are accepted.
- Normal owner replies are targeted at 2-3 short Telegram messages. A local fallback splits a one-message answer when possible and adds a tiny second phrase for extremely short replies.
- Classic Unicode emoji remain forbidden in ordinary text.


## Shared Telegram media across new cores

This core keeps the Telegram media-pack registry and Vision descriptions outside
the core directory by default:

`/mari/marin_shared/media/`

That directory is shared by every new Marin core installed under `/mari/`.
The Vision cache is keyed by Telegram document ID, so a sticker/custom emoji
already analyzed by an older core is not sent to Vision again. Set
`MARIN_SHARED_MEDIA_DIR` to another persistent path if needed.

## Semantic understanding

Проект теперь содержит `marin_core/understanding/`: семантический слой для
дискурсивных ссылок, времени, модальности, отрицаний, составных сообщений и
разрешения сущностей. Подробности: `UNDERSTANDING_UPGRADE.md`.
