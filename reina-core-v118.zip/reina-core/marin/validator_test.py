from marin_core import CognitiveEngine
from marin_core.llm.providers import CallableProvider


def bad_provider(planning_input) -> str:
    # намеренно нарушает invariant, чтобы проверить, что validation.py это ловит
    return "Обожаю аниме и вообще часто хожу на косплей!"


def main():
    engine = CognitiveEngine(llm_provider=CallableProvider(bad_provider))
    result = engine.tick("расскажи о себе", channel_id="c", source_actor_id="u")

    print("action.type:", result.action.type)
    print("action.payload:", result.action.payload)
    print("generated_text:", result.generated_text)

    assert result.action.payload.get("reason") == "validation_failed", "invariant should have blocked the output"
    assert result.generated_text is None, "blocked output must not be sent"
    print("\nOK: forbidden-topic output was caught by ActionValidator and blocked.")


if __name__ == "__main__":
    main()
