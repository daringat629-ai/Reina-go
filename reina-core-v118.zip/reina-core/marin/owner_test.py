from marin_core import CognitiveEngine
from marin_core.llm.providers import CallableProvider


def cosplay_provider(planning_input) -> str:
    return "Кстати, обожаю аниме и часто хожу на косплей!"


def main():
    engine = CognitiveEngine(llm_provider=CallableProvider(cosplay_provider))

    # обычный пользователь — тема должна блокироваться (как в validator_test.py)
    r1 = engine.tick("расскажи о себе", channel_id="c", source_actor_id="stranger", is_owner=False)
    print("stranger -> action:", r1.action.type, r1.action.payload)
    assert r1.generated_text is None

    # владелец — та же тема должна пройти
    r2 = engine.tick("расскажи о себе", channel_id="c", source_actor_id="owner_1", is_owner=True)
    print("owner -> action:", r2.action.type)
    print("owner -> text:", r2.generated_text)
    assert r2.generated_text is not None, "owner should not be blocked by cosplay/anime invariant"

    # доверие к владельцу должно быть высоким сразу, без "прогрева"
    rel = engine.social.get_or_create("owner_1").relationship
    print("owner trust:", rel.trust, "closeness:", rel.closeness)
    assert rel.trust >= 0.95 and rel.closeness >= 0.9

    # к обычному пользователю доверие остаётся дефолтным (не задрано)
    rel_stranger = engine.social.get_or_create("stranger").relationship
    print("stranger trust:", rel_stranger.trust, "closeness:", rel_stranger.closeness)
    assert rel_stranger.trust < 0.9

    print("\nOK: owner gets baseline trust + is exempt from the topic restriction, stranger does not.")


if __name__ == "__main__":
    main()
