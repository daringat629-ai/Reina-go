# Marin X — combined autonomous + persistent Telegram media patch

This build combines the Telegram action facade, autonomous channel/autopost flow, and persistent shared media/Vision cache.

## Persistent across new kernels

Default shared directory:
`/mari/marin_shared/media/`

It stores:
- `marin_media_vision_cache.json` — Vision catalog cache
- `marin_media_packs.json` — remembered Telegram packs
- `marin_own_channels.json` — channels explicitly marked as Marin-owned

A new kernel folder and a new `.venv` reuse these files.

## Autonomous channel

Owner can mark an existing channel:
` .мойканал <id|username|link>`

Then enable autonomous posting:
` .автопост <id|username> вкл`

Normal content publication is auto-approved. Dangerous/admin Telegram operations remain outside the safe auto-approve set.

The autonomous life loop restores/maintains the enabled channel goal after restart and runs periodic self-reflection through the existing engine.


## Autonomous social life (deploy14)
Marin X now has a second autonomous path in addition to owner-proactive
messages and channel autoposting. `AutonomousLifeLoop` periodically inspects
existing human private dialogs and gives the Cognitive Core a chance to start
one conversation on its own. The model can return `[SKIP]`; otherwise the
message is sent without an owner confirmation. It never bulk-DMs, skips bots,
channels and groups, and has a persistent cooldown/daily cap.

Environment:
- `MARIN_AUTONOMOUS_SOCIAL_ENABLED=true`
- `MARIN_AUTONOMOUS_SOCIAL_INTERVAL=14400`
- `MARIN_AUTONOMOUS_SOCIAL_MAX_PER_DAY=2`

This is intentionally an autonomous-life feature, not an unrestricted
mass-messaging mechanism.


## deploy21 — независимость от владельца

- **Отношение не зашито.** Убраны «любимый человек, вы вместе» (`MARIN_OWNER_RELATIONSHIP`,
  `identity/presets.py`), жёсткий пол доверия/близости 0.95/0.9 (`SocialModel`, теперь только при
  `MARIN_OWNER_FIXED_BOND=true`) и обязательная нежность в стиле для владельца. Близость складывается из
  реального общения. Просьбы владельца — просьбы, а не приказы.
- **Селфи и голосовые сама.** В личных «пишу первой» (утро/ночь/скучаю/импульс) она может сама выбрать
  `<<<SELFIE:...>>>` или `<<<VOICE:...>>>` (`MARIN_PROACTIVE_MEDIA_ENABLED`). Любой повод можно
  пропустить `[SKIP]` — тогда до конца окна не дёргается.
- **Свой канал без команд.** Каналы, где она creator, регистрируются сами, автопост включён по умолчанию
  (`MARIN_AUTONOMOUS_CHANNEL_ADOPT`, `MARIN_AUTONOMOUS_AUTOPOST_DEFAULT`). Явное `.автопост выкл` уважается.
  Пост не выходит, если ей нечего сказать.
- **Другим людям.** `MARIN_AUTONOMOUS_SOCIAL_PEER_COOLDOWN_DAYS` (по умолчанию 3 дня на человека) и
  `MARIN_AUTONOMOUS_SOCIAL_MAX_PER_DAY` (в `.env` — 4). Рамки против спама остались: по одному человеку,
  без ботов и каналов, без массовых рассылок.
- Старые убеждения в файле состояния (`marin_state.json`, дневник) могут содержать «любимый человек» —
  они не перезаписываются автоматически.
