package tgui

import "testing"

func TestPayLike(t *testing.T) {
	for _, s := range []string{"Оплатить 100 ₽", "💳 Пополнить", "Купить подписку", "Pay now", "Donate"} {
		if !payLike(s) {
			t.Fatalf("%q must be treated as a payment", s)
		}
	}
	for _, s := range []string{"Меню", "Профиль", "Помощь", "Мои чаты", "Настройки Ники"} {
		if payLike(s) {
			t.Fatalf("%q is harmless", s)
		}
	}
}
