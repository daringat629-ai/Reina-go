package agent

import (
	"context"
	"fmt"
	"log"
	"math/rand"
	"time"

	"orvi/internal/prompts"
	"orvi/internal/sched"
)

// The agent's own loops (run by Run under a supervisor): due reminders, scheduled tasks and monitors, background
// work on the owner's queue, her free time, and the daily copy of her memory for the owner. While she is paused
// nothing of it fires: reminders and alerts wait for the resume.

// workSessionID is the session key of background jobs: their own history, apart from every chat.
const workSessionID int64 = -777

// reminderLoop fires reminders when their time has come.
func (a *Agent) reminderLoop(ctx context.Context) {
	t := time.NewTicker(20 * time.Second)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
		}
		a.fireDue(ctx)
	}
}

// fireDue wakes her for every reminder whose time has come (paused: they wait and fire after the resume).
func (a *Agent) fireDue(ctx context.Context) {
	if a.paused.Load() {
		return
	}
	a.fireDates(ctx)
	if a.Deps.Reminders == nil {
		return
	}
	for _, it := range a.Deps.Reminders.Due(time.Now()) {
		a.spawn("reminder", func() {
			text := fmt.Sprintf("A reminder you set %s has come due: %q. Write to the person about it now, in your own words and your usual tone. If it is clearly no longer relevant, you may stay silent.",
				fmtAgo(it.Created), it.Text)
			if err := a.Wake(ctx, it.Chat, text); err != nil {
				log.Printf("agent: reminder #%d for chat %d: %v", it.ID, it.Chat, err)
			}
		})
	}
}

// datesHour is the local hour from which the yearly dates are reminded of (nobody wants a birthday at 3 a.m.).
const datesHour = 10

// fireDates wakes her for the birthdays and other yearly dates of the owner's people: days before and on the day.
func (a *Agent) fireDates(ctx context.Context) {
	cfg := a.cfg()
	if a.Deps.Dates == nil {
		return
	}
	for _, due := range a.Deps.Dates.Due(time.Now().In(cfg.Location()), datesHour) {
		chat := due.Chat
		if chat == 0 {
			chat = cfg.PapikChatID
		}
		if chat == 0 {
			continue
		}
		years := ""
		if due.Turns > 0 {
			years = fmt.Sprintf(" (%d years)", due.Turns)
		}
		note := ""
		if due.Note != "" {
			note = " The note says: " + due.Note + "."
		}
		var text string
		switch {
		case due.Before:
			text = fmt.Sprintf("In %d day(s), on %s, it is %q%s.%s Remind the person now, in your own words, and offer help (a gift idea, a greeting text).", due.DaysLeft, due.On.Format("02.01"), due.Name, years, note)
		case chat != cfg.PapikChatID:
			text = fmt.Sprintf("Today is %q%s, and this chat is that person's.%s Congratulate them warmly in your own words and your usual tone.", due.Name, years, note)
		default:
			text = fmt.Sprintf("Today is %q%s.%s Remind the person in your own words; offer a greeting text they could send.", due.Name, years, note)
		}
		a.spawn("date", func() {
			if err := a.Wake(ctx, chat, text); err != nil {
				log.Printf("agent: date #%d for chat %d: %v", due.ID, chat, err)
			}
		})
	}
}

func fmtAgo(t time.Time) string {
	d := time.Since(t)
	switch {
	case d < time.Minute:
		return "just now"
	case d < time.Hour:
		return fmt.Sprintf("%d min ago", int(d.Minutes()))
	case d < 48*time.Hour:
		return fmt.Sprintf("%d h ago", int(d.Hours()))
	}
	return fmt.Sprintf("%d days ago", int(d.Hours()/24))
}

// schedLoop runs her recurring tasks and the monitors. While she is paused nothing fires (tasks move on, alerts wait).
func (a *Agent) schedLoop(ctx context.Context) {
	if a.Deps.Sched == nil {
		return
	}
	t := time.NewTicker(30 * time.Second)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
		}
		if a.paused.Load() {
			continue
		}
		a.runSched(ctx, time.Now())
	}
}

func (a *Agent) runSched(ctx context.Context, now time.Time) {
	st := a.Deps.Sched
	for _, tk := range st.DueTasks(now) {
		a.spawn("scheduled task", func() {
			text := fmt.Sprintf("A task you were given to do regularly is due (#%d, run %d): %q. Do it now with your tools, then tell the person the result in your own words and usual tone. Keep it short; if there is nothing worth saying this time, stay silent.", tk.ID, tk.Runs+1, tk.Text)
			if err := a.Wake(ctx, tk.Chat, text); err != nil {
				log.Printf("agent: scheduled task #%d: %v", tk.ID, err)
			}
		})
	}
	for _, al := range st.CheckDue(ctx, now, sched.DefaultCheck) {
		a.spawn("monitor alert", func() {
			var text string
			switch {
			case al.Changed:
				text = fmt.Sprintf("A page you watch (monitor #%d) has changed: %s. Tell the person what is new, briefly and in your tone; if the change is noise (a date, a counter), say nothing.", al.Monitor.ID, al.Detail)
			case al.Recovered:
				text = fmt.Sprintf("A monitor you set up reports that things are fine again (%s: %s). Tell the person briefly, in your tone.", al.Monitor.Kind, al.Detail)
			default:
				text = fmt.Sprintf("ALERT from your monitor #%d (%s %s): %s. Tell the person right now what is wrong, in your tone, and say what you can do about it; if you can fix it yourself with your tools, offer to.", al.Monitor.ID, al.Monitor.Kind, al.Monitor.Arg, al.Detail)
			}
			if err := a.Wake(ctx, al.Monitor.Chat, text); err != nil {
				log.Printf("agent: monitor #%d: wake failed (%v), sending plain text", al.Monitor.ID, err)
				plain := "⚠️ " + al.Detail
				switch {
				case al.Recovered:
					plain = "✅ " + al.Detail
				case al.Changed:
					plain = "🔔 " + al.Detail
				}
				if _, err := a.TG.SendText(ctx, al.Monitor.Chat, plain, 0); err != nil {
					log.Printf("agent: monitor #%d: %v", al.Monitor.ID, err)
				}
			}
		})
	}
}

// workLoop gives her jobs from the owner's queue, one run at a time, inside the limits of the settings.
func (a *Agent) workLoop(ctx context.Context) {
	for {
		mins := max(a.cfg().WorkEveryMins, 2)
		select {
		case <-ctx.Done():
			return
		case <-time.After(time.Duration(mins) * time.Minute):
		}
		if err := a.workOnce(ctx); err != nil {
			log.Printf("agent: work run: %v", err)
		}
	}
}

// workOnce starts one background run when it is allowed: work switched on, not paused, token limit not hit,
// the previous run finished, and a job is waiting.
func (a *Agent) workOnce(ctx context.Context) error {
	cfg := a.cfg()
	if !cfg.WorkEnabled || a.paused.Load() || a.Deps.Work == nil || cfg.PapikChatID == 0 {
		return nil
	}
	if a.Usage != nil && a.Usage.Over(cfg.DailyTokenLimit) {
		return nil
	}
	s := a.getSession(workSessionID)
	if !s.mu.TryLock() { // the previous run is still going
		return nil
	}
	s.mu.Unlock()
	rules := workRules(cfg.WorkFreeHand)
	t, ok := a.Deps.Work.Take(time.Now(), cfg.WorkMaxRuns)
	if !ok {
		// Nothing to do: in AGI mode she picks her own next goal (only when no job is waiting; blocked ones wait for the owner).
		if !cfg.WorkSelfDirected || a.Deps.Work.Open() || !a.Deps.Work.Reserve(time.Now(), cfg.WorkMaxRuns) {
			return nil
		}
		goals := a.Deps.Work.Goals()
		if goals == "" {
			goals = "(none yet)"
		}
		done := a.Deps.Work.RecentDone(8)
		if done == "" {
			done = "(nothing yet)"
		}
		log.Printf("agent: self-directed run: choosing the next goal")
		text := a.Prompts.Text(prompts.WorkSelf, map[string]string{"GOALS": goals, "DONE": done, "RULES": rules})
		return a.wake(ctx, workSessionID, cfg.PapikChatID, text, []string{"browser", "desktop"})
	}
	text := a.Prompts.Text(prompts.WorkRun, map[string]string{"JOB": t.Render(true), "RULES": rules})
	log.Printf("agent: background run of job #%d (%s), run %d/%d", t.ID, t.Title, t.Runs, t.MaxRuns)
	return a.wake(ctx, workSessionID, cfg.PapikChatID, text, []string{"browser", "desktop"})
}

// proactiveLoop periodically lets the model look through its chats on its own. With [autonomy] enabled the pause
// is random, nights and sleep are respected and the daily limits apply; otherwise telegram.proactive_interval_secs rules.
func (a *Agent) proactiveLoop(ctx context.Context) {
	for {
		cfg := a.cfg()
		wait := time.Minute // config may be enabled later via hot reload
		switch {
		case cfg.AutonomyEnabled && a.Auto != nil:
			lo, hi := max(cfg.AutonomyMinMins, 1), cfg.AutonomyMaxMins
			hi = max(hi, lo)
			wait = time.Duration(lo+rand.Intn(hi-lo+1)) * time.Minute
		case cfg.Proactive > 0:
			wait = cfg.Proactive
		}
		select {
		case <-ctx.Done():
			return
		case <-time.After(wait):
		}
		cfg = a.cfg()
		switch {
		case cfg.AutonomyEnabled && a.Auto != nil:
			if err := a.ActAutonomously(ctx); err != nil {
				log.Printf("agent: autonomy: %v", err)
			}
		case cfg.Proactive > 0:
			if err := a.ActProactively(ctx); err != nil {
				log.Printf("agent: proactive: %v", err)
			}
		}
	}
}

// workRules is the approval rule block put into every background prompt: with free_hand she acts and reports afterwards,
// without it she parks the job with #work ask. Honesty and legality hold in both modes.
func workRules(freeHand bool) string {
	const always = "Never spend money, never lie that you are human if someone asks, never deceive or impersonate a real person, never do anything illegal, and report the real result including failures."
	if freeHand {
		return "You have a free hand: register accounts, accept terms, publish and write for the owner when the job needs it, without asking; tell him in #work done what you did. " + always
	}
	return "If a step needs his decision, a payment, an account registration, acceptance of terms or a message in his name to a stranger: do the preparation and #work ask with exactly what you want to do and why, then stop. " + always
}
