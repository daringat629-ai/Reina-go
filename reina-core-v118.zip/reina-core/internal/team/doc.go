package team

import (
	"context"
	"errors"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"
)

const maxAnketa = 5 << 20

// download fetches a file the owner sent to the bot. Errors never carry the URL: it holds the bot token.
func (b *Bot) download(ctx context.Context, fileID string) ([]byte, error) {
	var f struct {
		Path string `json:"file_path"`
	}
	if err := b.call(ctx, "getFile", map[string]any{"file_id": fileID}, &f); err != nil || f.Path == "" {
		return nil, errors.New("Telegram не отдал файл")
	}
	base := b.BaseURL
	if base == "" {
		base = "https://api.telegram.org"
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, base+"/file/bot"+strings.TrimSpace(b.Token)+"/"+f.Path, nil)
	if err != nil {
		return nil, errors.New("не удалось скачать файл")
	}
	hc := b.HTTP
	if hc == nil {
		hc = &http.Client{Timeout: 60 * time.Second}
	}
	resp, err := hc.Do(req)
	if err != nil {
		return nil, errors.New("не удалось скачать файл")
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return nil, errors.New("не удалось скачать файл")
	}
	data, err := io.ReadAll(io.LimitReader(resp.Body, maxAnketa+1))
	if err != nil || len(data) > maxAnketa {
		return nil, errors.New("файл слишком большой или оборвался")
	}
	return data, nil
}

// ownerDoc turns a filled form sent by the owner into a member with a key and a ready profile.
func (b *Bot) ownerDoc(ctx context.Context, owner int64, fileID, name string, size int) {
	if !strings.HasSuffix(strings.ToLower(name), ".docx") {
		b.send(ctx, owner, "Пришли анкету файлом Word (.docx). Фото и PDF я не читаю: тогда выдай ключ вручную, /new Имя | Роль.", nil)
		return
	}
	if size > maxAnketa {
		b.send(ctx, owner, "Файл больше 5 МБ, это не похоже на анкету.", nil)
		return
	}
	data, err := b.download(ctx, fileID)
	if err != nil {
		b.send(ctx, owner, err.Error(), nil)
		return
	}
	text, svg := Import(b.Store, data)
	if svg != "" && b.Render != nil {
		if png, err := b.Render(ctx, svg); err == nil && len(png) > 0 {
			_ = b.sendPhoto(ctx, owner, png, "", nil)
		}
	}
	b.send(ctx, owner, text, nil)
}

// Import reads a filled form and makes the member with a key; it returns the owner's reply and the member's card (SVG, "" on failure).
func Import(s *Store, data []byte) (string, string) {
	a, err := ParseAnketa(data)
	if err != nil {
		return "Анкета не прочиталась: " + err.Error() + ".", ""
	}
	m, key, err := s.InviteWith(a.Name, a.Role, a.Profile)
	if err != nil {
		return err.Error(), ""
	}
	var sb strings.Builder
	fmt.Fprintf(&sb, "Создан участник №%d: %s, роль: %s.\nКонтакт: %s\n", m.ID, m.Name, orDash(m.Role), orDash(a.Profile.Contact))
	if a.Profile.Extra != "" {
		sb.WriteString(a.Profile.Extra + "\n")
	}
	fmt.Fprintf(&sb, "\nКлюч (покажу один раз, перешли человеку лично): %s\n", key)
	if len(a.Warnings) > 0 {
		sb.WriteString("\nОбрати внимание:\n")
		for _, w := range a.Warnings {
			sb.WriteString("• " + w + "\n")
		}
	}
	return sb.String(), CardSVG(m, 0, 0, 0, 0, false)
}
