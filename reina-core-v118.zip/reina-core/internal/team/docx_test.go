package team

import (
	"archive/zip"
	"bytes"
	"encoding/xml"
	"strings"
	"testing"
)

func esc(s string) string {
	var b bytes.Buffer
	_ = xml.EscapeText(&b, []byte(s))
	return b.String()
}

// buildDocx makes a minimal .docx: paragraphs first, then tables (rows of cells).
func buildDocx(t *testing.T, paras []string, tables [][][]string) []byte {
	t.Helper()
	var sb strings.Builder
	sb.WriteString(`<?xml version="1.0"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>`)
	for _, p := range paras {
		sb.WriteString(`<w:p><w:r><w:t xml:space="preserve">` + esc(p) + `</w:t></w:r></w:p>`)
	}
	for _, tb := range tables {
		sb.WriteString(`<w:tbl>`)
		for _, r := range tb {
			sb.WriteString(`<w:tr>`)
			for _, c := range r {
				sb.WriteString(`<w:tc><w:p><w:r><w:t>` + esc(c) + `</w:t></w:r></w:p></w:tc>`)
			}
			sb.WriteString(`</w:tr>`)
		}
		sb.WriteString(`</w:tbl>`)
	}
	sb.WriteString(`</w:body></w:document>`)
	var buf bytes.Buffer
	zw := zip.NewWriter(&buf)
	w, _ := zw.Create("word/document.xml")
	_, _ = w.Write([]byte(sb.String()))
	_ = zw.Close()
	return buf.Bytes()
}
