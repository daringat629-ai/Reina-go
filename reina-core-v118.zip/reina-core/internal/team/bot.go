package team

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"net/http"
	"strconv"
	"strings"
	"sync"
	"time"
)

// DefaultRights is a draft of the clause the members accept. It is NOT legal advice: the owner replaces it with the lawyer's text
// (config team.rights_text); a changed text asks every member again.
const DefaultRights = "Работы, которые я делаю для проекта (код, тексты, промпты, рисунки, модели, звук), я делаю сам или у меня есть право их передавать. " +
	"Я передаю проекту право использовать их в продукте, в том числе за плату. Условия оплаты и доли мы согласуем отдельно в письменном виде. " +
	"Я не передаю проекту чужие работы, пароли и чужие данные. " +
	"Я не обсуждаю рабочие задачи и материалы проекта в общих чатах и группах, только с владельцем проекта."

var questions = [...]string{
	1: "Как тебя зовут (имя и фамилия или ник)?",
	2: "Как с тобой связаться? Telegram @username или почта.",
	3: "Что ты умеешь и где это делал? Коротко.",
	4: "Ссылки на твои работы (GitHub, портфолио). Можно «нет».",
	5: "Сколько часов в неделю готов уделять?",
	6: "Реквизиты для выплат (карта, кошелёк или «позже»). Видит только владелец проекта.",
}

// Bot is the team bot: the owner issues keys and tasks, members use their cabinet.
type Bot struct {
	Token   string
	BaseURL string
	Store   *Store
	Owner   func() int64                                          // the owner's Telegram id
	Rights  func() string                                         // the clause text (nil or empty = DefaultRights)
	Icon    func(key string) string                               // custom emoji id of a vector button icon ("" = ordinary emoji)
	Render  func(ctx context.Context, svg string) ([]byte, error) // SVG to PNG for the profile card (nil = text only)
	Now     func() time.Time
	HTTP    *http.Client
	Loc     *time.Location // the owner's time zone for deadlines and the weekly summary (nil = local)
	offset  int64
	mu      sync.Mutex
	tries   map[int64][]time.Time // wrong keys per person: a guess limit
}

func (b *Bot) now() time.Time {
	if b.Now != nil {
		return b.Now()
	}
	return time.Now()
}

func (b *Bot) rights() string {
	if b.Rights != nil {
		if t := strings.TrimSpace(b.Rights()); t != "" {
			return t
		}
	}
	return DefaultRights
}

func (b *Bot) call(ctx context.Context, method string, in, out any) error {
	base := b.BaseURL
	if base == "" {
		base = "https://api.telegram.org"
	}
	body, _ := json.Marshal(in)
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, base+"/bot"+strings.TrimSpace(b.Token)+"/"+method, bytes.NewReader(body))
	if err != nil {
		return fmt.Errorf("team bot: %s: bad request (check the bot token)", method) // the URL would carry the token
	}
	req.Header.Set("Content-Type", "application/json")
	hc := b.HTTP
	if hc == nil {
		hc = &http.Client{Timeout: 70 * time.Second}
	}
	resp, err := hc.Do(req)
	if err != nil {
		if e := errors.Unwrap(err); e != nil {
			err = e
		} else {
			err = errors.New("request failed")
		}
		return fmt.Errorf("team bot: %s: %w", method, err)
	}
	defer resp.Body.Close()
	var r struct {
		OK          bool            `json:"ok"`
		Result      json.RawMessage `json:"result"`
		Description string          `json:"description"`
	}
	if json.NewDecoder(resp.Body).Decode(&r) != nil {
		return fmt.Errorf("team bot: %s: bad answer", method)
	}
	if !r.OK {
		return fmt.Errorf("team bot: %s: %s", method, r.Description)
	}
	if out != nil {
		return json.Unmarshal(r.Result, out)
	}
	return nil
}

type update struct {
	UpdateID int64 `json:"update_id"`
	Message  *struct {
		From struct {
			ID int64 `json:"id"`
		} `json:"from"`
		Chat struct {
			ID int64 `json:"id"`
		} `json:"chat"`
		Text      string `json:"text"`
		MessageID int    `json:"message_id"`
		Caption   string `json:"caption"`
		Photo     []struct {
			FileID string `json:"file_id"`
		} `json:"photo"`
		Document *struct {
			FileID   string `json:"file_id"`
			FileName string `json:"file_name"`
			Size     int    `json:"file_size"`
		} `json:"document"`
	} `json:"message"`
	Callback *struct {
		ID   string `json:"id"`
		From struct {
			ID int64 `json:"id"`
		} `json:"from"`
		Data string `json:"data"`
	} `json:"callback_query"`
}

// Run polls the Bot API until ctx ends.
func (b *Bot) Run(ctx context.Context) {
	for ctx.Err() == nil {
		var ups []update
		err := b.call(ctx, "getUpdates", map[string]any{"offset": b.offset, "timeout": 50, "allowed_updates": []string{"message", "callback_query"}}, &ups)
		if err != nil {
			if ctx.Err() == nil {
				log.Printf("%v", err)
				select {
				case <-ctx.Done():
				case <-time.After(10 * time.Second):
				}
			}
			continue
		}
		for _, u := range ups {
			b.offset = u.UpdateID + 1
			b.handle(ctx, u)
		}
	}
}

func (b *Bot) send(ctx context.Context, chat int64, text string, markup any) {
	in := map[string]any{"chat_id": chat, "text": text}
	if markup != nil {
		in["reply_markup"] = markup
	}
	if err := b.call(ctx, "sendMessage", in, nil); err != nil {
		log.Printf("%v", err)
	}
}

func (b *Bot) toOwner(ctx context.Context, text string) {
	if id := b.owner(); id != 0 {
		b.send(ctx, id, text, nil)
	}
}

func (b *Bot) owner() int64 {
	if b.Owner == nil {
		return 0
	}
	return b.Owner()
}

// menuItems are the cabinet buttons: icon key, ordinary emoji, label.
var menuItems = []struct{ key, emoji, label string }{
	{"profile", "👤", "Профиль"}, {"tasks", "📋", "Задачи"}, {"report", "📝", "Отчёт"}, {"rights", "📜", "Согласие"},
}

// menu is the keyboard; a button gets a vector icon when its custom emoji exists, else the ordinary emoji.
func (b *Bot) menu() map[string]any {
	var row []map[string]any
	for _, it := range menuItems {
		btn := map[string]any{"text": it.emoji + " " + it.label}
		if b.Icon != nil {
			if id := b.Icon(it.key); id != "" {
				btn = map[string]any{"text": it.label, "icon_custom_emoji_id": id}
			}
		}
		row = append(row, btn)
	}
	return map[string]any{"keyboard": [][]map[string]any{row}, "resize_keyboard": true, "is_persistent": true}
}

// canon turns a bare label ("Профиль", how Telegram sends a button with a vector icon) into the form with the emoji.
func canon(text string) string {
	for _, it := range menuItems {
		if text == it.label {
			return it.emoji + " " + it.label
		}
	}
	return text
}

func (b *Bot) handle(ctx context.Context, u update) {
	if c := u.Callback; c != nil {
		_ = b.call(ctx, "answerCallbackQuery", map[string]any{"callback_query_id": c.ID}, nil)
		b.callback(ctx, c.From.ID, c.Data)
		return
	}
	m := u.Message
	if m == nil || (m.Text == "" && m.Document == nil && len(m.Photo) == 0) {
		return
	}
	// the cabinet answers in private chats only: a group message must not run it
	if m.Chat.ID != m.From.ID {
		return
	}
	text := canon(strings.TrimSpace(m.Text))
	if id := b.owner(); id != 0 && m.From.ID == id {
		if d := m.Document; d != nil {
			b.ownerDoc(ctx, id, d.FileID, d.FileName, d.Size)
			return
		}
		b.ownerCmd(ctx, id, text)
		return
	}
	if m.Document != nil || len(m.Photo) > 0 {
		b.memberFile(ctx, m.From.ID, m.MessageID, m.Caption)
		return
	}
	b.memberMsg(ctx, m.From.ID, text)
}

// tooMany says whether this person has already guessed wrong keys too often (5 in 10 minutes).
func (b *Bot) tooMany(tg int64, add bool) bool {
	b.mu.Lock()
	defer b.mu.Unlock()
	if b.tries == nil {
		b.tries = map[int64][]time.Time{}
	}
	now := b.now()
	var keep []time.Time
	for _, t := range b.tries[tg] {
		if now.Sub(t) < 10*time.Minute {
			keep = append(keep, t)
		}
	}
	if add {
		keep = append(keep, now)
	}
	b.tries[tg] = keep
	return len(keep) >= 5
}

func (b *Bot) memberMsg(ctx context.Context, tg int64, text string) {
	m, ok := b.Store.ByTG(tg)
	if !ok {
		if text == "/start" {
			b.send(ctx, tg, "Это кабинет команды. Пришли ключ, который тебе дал владелец проекта (вида SPR-XXXX-XXXX).", nil)
			return
		}
		if b.tooMany(tg, false) {
			b.send(ctx, tg, "Слишком много неверных попыток. Попробуй позже.", nil)
			return
		}
		key := strings.TrimSpace(strings.TrimPrefix(text, "/start"))
		mm, err := b.Store.Redeem(key, tg, b.now())
		if err != nil {
			b.tooMany(tg, true)
			b.send(ctx, tg, "Ключ не подошёл: "+err.Error()+".", nil)
			return
		}
		b.toOwner(ctx, fmt.Sprintf("%s (участник №%d) вошёл в кабинет.", mm.Name, mm.ID))
		b.send(ctx, tg, fmt.Sprintf("Привет, %s! Ты в команде как «%s». Заполни профиль и подтверди согласие.", mm.Name, mm.Role), b.menu())
		if mm.Profile.FullName != "" {
			b.send(ctx, tg, "Твоя анкета уже у нас, данные подставлены (смотри «👤 Профиль»). Осталось одно.", nil)
			b.ask(ctx, tg, mm.ID, 6)
		} else {
			b.ask(ctx, tg, mm.ID, 1)
		}
		return
	}
	// a free report is being typed (Handing -1)
	if m.Handing == -1 && !strings.HasPrefix(text, "/") && !isMenu(text) {
		b.Store.SetStep(m.ID, m.Step, 0)
		if _, err := b.Store.AddReport(m.ID, text, b.now()); err != nil {
			b.send(ctx, tg, err.Error(), b.menu())
			return
		}
		b.send(ctx, tg, "Отчёт записан, владелец его увидит.", b.menu())
		b.toOwner(ctx, fmt.Sprintf("Отчёт от %s:\n%s", m.Name, clip(text)))
		return
	}
	// a task result is being typed
	if m.Handing > 0 && !strings.HasPrefix(text, "/") && !isMenu(text) {
		if err := b.Store.SetStatus(m.Handing, m.ID, Review, text, b.now()); err != nil {
			b.send(ctx, tg, err.Error(), b.menu())
		} else {
			t, _ := b.Store.GetTask(m.Handing)
			b.send(ctx, tg, "Сдано. Владелец посмотрит.", b.menu())
			b.toOwner(ctx, fmt.Sprintf("%s сдал задачу №%d «%s»:\n%s\n\nПринять: /ok %d", m.Name, t.ID, t.Title, t.Result, t.ID))
		}
		b.Store.SetStep(m.ID, m.Step, 0)
		return
	}
	// a profile answer is expected
	if m.Step != 0 && !strings.HasPrefix(text, "/") && !isMenu(text) {
		next := b.Store.Answer(m.ID, m.Step, text)
		if next == 0 {
			b.send(ctx, tg, "Профиль заполнен, спасибо. Не забудь подтвердить согласие: кнопка «📜 Согласие».", b.menu())
			b.toOwner(ctx, fmt.Sprintf("%s заполнил профиль.", m.Name))
		} else {
			b.ask(ctx, tg, m.ID, next)
		}
		return
	}
	switch {
	case text == "👤 Профиль" || text == "/profile":
		b.profile(ctx, tg, m)
	case text == "📋 Задачи" || text == "/tasks":
		b.tasks(ctx, tg, m)
	case text == "📝 Отчёт" || text == "/report":
		b.Store.SetStep(m.ID, m.Step, -1)
		b.send(ctx, tg, "Напиши одним сообщением, что ты сделал: что готово, что в работе, что мешает. Это увидит только владелец проекта. Можно приложить фото или файл. Свои прошлые отчёты: /myreports", nil)
	case text == "/myreports":
		rs := b.Store.LastReports(m.ID, 5)
		if len(rs) == 0 {
			b.send(ctx, tg, "Отчётов пока нет.", b.menu())
			return
		}
		var sb strings.Builder
		for _, r := range rs {
			fmt.Fprintf(&sb, "%s\n%s\n\n", r.At.Format("02.01 15:04"), r.Text)
		}
		b.send(ctx, tg, sb.String(), b.menu())
	case text == "📜 Согласие" || text == "/rights":
		b.rightsMsg(ctx, tg, m)
	case text == "/fill":
		b.ask(ctx, tg, m.ID, 1)
	default:
		b.send(ctx, tg, "Кнопки внизу: профиль, задачи, согласие. /fill заполнить профиль заново.", b.menu())
	}
}

func isMenu(t string) bool {
	return t == "👤 Профиль" || t == "📋 Задачи" || t == "📜 Согласие"
}

func (b *Bot) ask(ctx context.Context, tg int64, id, step int) {
	b.Store.SetStep(id, step, 0)
	b.send(ctx, tg, fmt.Sprintf("%d/6. %s", step, questions[step]), nil)
}

func orDash(s string) string {
	if strings.TrimSpace(s) == "" {
		return "—"
	}
	return s
}

func (b *Bot) profile(ctx context.Context, tg int64, m Member) {
	p := m.Profile
	agreed := b.Store.Agreed(m.ID, b.rights())
	agree := "нет"
	if agreed {
		agree = "да, " + m.ConsentT.Format("02.01.2006")
	}
	text := fmt.Sprintf("Роль: %s\nИмя: %s\nКонтакт: %s\nУмею: %s\nСсылки: %s\nЧасов в неделю: %s\nРеквизиты: %s\nСогласие на права: %s\n\n/fill заполнить заново",
		orDash(m.Role), orDash(p.FullName), orDash(p.Contact), orDash(p.Skills), orDash(p.Links), orDash(p.Hours), orDash(p.Pay), agree)
	if b.Render != nil {
		open, review, closed := 0, 0, 0
		for _, t := range b.Store.Tasks(m.ID) {
			switch t.Status {
			case Open, Taken:
				open++
			case Review:
				review++
			case Closed:
				closed++
			}
		}
		if png, err := b.Render(ctx, CardSVG(m, open, review, closed, len(b.Store.LastReports(m.ID, 1000)), agreed)); err == nil && len(png) > 0 {
			if b.sendPhoto(ctx, tg, png, "", b.menu()) == nil {
				b.send(ctx, tg, text, b.menu())
				return
			}
		}
	}
	b.send(ctx, tg, text, b.menu())
}

var statusRu = map[string]string{Open: "новая", Taken: "в работе", Review: "на проверке", Closed: "принята"}

func (b *Bot) tasks(ctx context.Context, tg int64, m Member) {
	shown := 0
	for _, t := range b.Store.Tasks(m.ID) {
		if t.Status == Closed {
			continue
		}
		shown++
		txt := fmt.Sprintf("№%d · %s\n%s\nСтатус: %s%s", t.ID, t.Title, t.Brief, statusRu[t.Status], dueText(t, b.now(), b.loc()))
		var mk any
		switch t.Status {
		case Open:
			mk = map[string]any{"inline_keyboard": [][]map[string]string{{{"text": "▶ Беру", "callback_data": "take:" + strconv.Itoa(t.ID)}}}}
		case Taken:
			mk = map[string]any{"inline_keyboard": [][]map[string]string{{{"text": "✅ Сдать", "callback_data": "hand:" + strconv.Itoa(t.ID)}}}}
		}
		b.send(ctx, tg, txt, mk)
	}
	if shown == 0 {
		b.send(ctx, tg, "Открытых задач нет. Владелец даст, когда будет что делать.", b.menu())
	}
}

func (b *Bot) rightsMsg(ctx context.Context, tg int64, m Member) {
	txt := b.rights()
	if b.Store.Agreed(m.ID, txt) {
		b.send(ctx, tg, "Ты уже согласился с этим текстом:\n\n"+txt, b.menu())
		return
	}
	b.send(ctx, tg, "Прочитай и подтверди:\n\n"+txt, map[string]any{"inline_keyboard": [][]map[string]string{{{"text": "✅ Согласен", "callback_data": "agree"}}}})
}

func (b *Bot) callback(ctx context.Context, tg int64, data string) {
	m, ok := b.Store.ByTG(tg)
	if !ok {
		return
	}
	switch {
	case data == "agree":
		b.Store.Agree(m.ID, b.rights(), b.now())
		b.send(ctx, tg, "Записано: согласие на этот текст, "+b.now().Format("02.01.2006 15:04")+".", b.menu())
		b.toOwner(ctx, fmt.Sprintf("%s согласился с текстом о правах.", m.Name))
	case strings.HasPrefix(data, "take:"):
		id, _ := strconv.Atoi(strings.TrimPrefix(data, "take:"))
		if err := b.Store.SetStatus(id, m.ID, Taken, "", b.now()); err != nil {
			b.send(ctx, tg, err.Error(), nil)
			return
		}
		b.send(ctx, tg, fmt.Sprintf("Задача №%d в работе. Когда закончишь, нажми «Сдать» в списке задач.", id), b.menu())
		b.toOwner(ctx, fmt.Sprintf("%s взял задачу №%d.", m.Name, id))
	case strings.HasPrefix(data, "hand:"):
		id, _ := strconv.Atoi(strings.TrimPrefix(data, "hand:"))
		if t, ok := b.Store.GetTask(id); !ok || t.Member != m.ID {
			b.send(ctx, tg, "Это не твоя задача.", nil)
			return
		}
		b.Store.SetStep(m.ID, 0, id)
		b.send(ctx, tg, "Напиши одним сообщением, что сделано: ссылка на файл, репозиторий или короткий отчёт.", nil)
	}
}

const ownerHelp = "Команды владельца:\n/new Имя | Роль — выдать ключ\n/team — все участники\n/task N Название | описание | до 12.11 — дать задачу участнику N (описание и срок можно не писать)\n/newkey N — новый ключ (потерял ключ или сменил аккаунт)\n/digest — сводка по команде\n/ok ID — принять задачу\n/reports [N] — последние отчёты (N = номер участника, если нужен один)\n/revoke N — закрыть кабинет участника"

func (b *Bot) ownerCmd(ctx context.Context, id int64, text string) {
	cmd, arg, _ := strings.Cut(text, " ")
	arg = strings.TrimSpace(arg)
	switch cmd {
	case "/new":
		name, role, _ := strings.Cut(arg, "|")
		m, key, err := b.Store.Invite(name, role)
		if err != nil {
			b.send(ctx, id, err.Error(), nil)
			return
		}
		b.send(ctx, id, fmt.Sprintf("Участник №%d: %s (%s).\nКлюч (покажу один раз, перешли человеку лично): %s\nОн открывает этого бота и присылает ключ.", m.ID, m.Name, orDash(m.Role), key), nil)
	case "/team":
		var sb strings.Builder
		for _, m := range b.Store.Members() {
			st := "ждёт ключ"
			switch {
			case m.Revoked:
				st = "закрыт"
			case m.TG != 0:
				st = "в кабинете"
			}
			ok := "нет"
			if b.Store.Agreed(m.ID, b.rights()) {
				ok = "да"
			}
			fmt.Fprintf(&sb, "№%d %s, %s: %s, профиль: %s, согласие: %s\n", m.ID, m.Name, orDash(m.Role), st, orDash(m.Profile.FullName), ok)
		}
		if sb.Len() == 0 {
			sb.WriteString("Пока никого. /new Имя | Роль")
		}
		b.send(ctx, id, sb.String(), nil)
	case "/task":
		n, rest, _ := strings.Cut(arg, " ")
		mid, err := strconv.Atoi(n)
		if err != nil {
			b.send(ctx, id, "Формат: /task N Название | описание", nil)
			return
		}
		parts := strings.Split(rest, "|")
		title, brief, dueS := parts[0], "", ""
		if len(parts) > 1 {
			brief = parts[1]
		}
		if len(parts) > 2 {
			dueS = parts[2]
		}
		var due time.Time
		if strings.TrimSpace(dueS) != "" {
			d, ok := parseDue(dueS, b.now(), b.loc())
			if !ok {
				b.send(ctx, id, "Срок не понял. Пиши: до 12.11 или 12.11.2026", nil)
				return
			}
			due = d
		}
		t, err := b.Store.AddTaskDue(mid, title, brief, due, b.now())
		if err != nil {
			b.send(ctx, id, err.Error(), nil)
			return
		}
		b.send(ctx, id, fmt.Sprintf("Задача №%d дана участнику №%d.%s", t.ID, mid, dueText(t, b.now(), b.loc())), nil)
		if m, ok := b.Store.Get(mid); ok && m.TG != 0 && !m.Revoked {
			b.send(ctx, m.TG, fmt.Sprintf("Новая задача №%d: %s%s\nОткрой «📋 Задачи».", t.ID, t.Title, dueText(t, b.now(), b.loc())), b.menu())
		}
	case "/ok":
		tid, err := strconv.Atoi(arg)
		if err != nil {
			b.send(ctx, id, "Формат: /ok ID", nil)
			return
		}
		if err := b.Store.SetStatus(tid, 0, Closed, "", b.now()); err != nil {
			b.send(ctx, id, err.Error(), nil)
			return
		}
		b.send(ctx, id, fmt.Sprintf("Задача №%d принята.", tid), nil)
		if t, ok := b.Store.GetTask(tid); ok {
			if m, ok := b.Store.Get(t.Member); ok && m.TG != 0 {
				b.send(ctx, m.TG, fmt.Sprintf("Задача №%d принята. Спасибо!", tid), nil)
			}
		}
	case "/reports":
		mid, _ := strconv.Atoi(arg)
		names := map[int]string{}
		for _, m := range b.Store.Members() {
			names[m.ID] = m.Name
		}
		rs := b.Store.LastReports(mid, 10)
		if len(rs) == 0 {
			b.send(ctx, id, "Отчётов пока нет.", nil)
			return
		}
		var sb strings.Builder
		for _, r := range rs {
			fmt.Fprintf(&sb, "%s, №%d %s:\n%s\n\n", r.At.Format("02.01 15:04"), r.Member, names[r.Member], r.Text)
		}
		b.send(ctx, id, sb.String(), nil)
	case "/digest":
		b.send(ctx, id, b.Digest(), nil)
	case "/newkey":
		n, err := strconv.Atoi(arg)
		if err != nil {
			b.send(ctx, id, "Формат: /newkey N (номер участника)", nil)
			return
		}
		m, key, err := b.Store.ResetKey(n)
		if err != nil {
			b.send(ctx, id, err.Error(), nil)
			return
		}
		b.send(ctx, id, fmt.Sprintf("Новый ключ для №%d %s (старый больше не работает, привязка к аккаунту снята): %s", m.ID, m.Name, key), nil)
	case "/revoke":
		n, err := strconv.Atoi(arg)
		if err != nil || b.Store.Revoke(n) != nil {
			b.send(ctx, id, "Формат: /revoke N (номер участника)", nil)
			return
		}
		b.send(ctx, id, fmt.Sprintf("Кабинет участника №%d закрыт.", n), nil)
	default:
		b.send(ctx, id, ownerHelp, nil)
	}
}

// memberFile takes a picture or a file for a report or a task result: it is copied to the owner, the record keeps a note.
func (b *Bot) memberFile(ctx context.Context, tg int64, msgID int, caption string) {
	m, ok := b.Store.ByTG(tg)
	if !ok {
		return
	}
	if m.Handing == 0 {
		b.send(ctx, tg, "Сначала нажми «📝 Отчёт» или «Сдать» у задачи, потом пришли файл.", b.menu())
		return
	}
	caption = clip(caption)
	note := caption
	if note == "" {
		note = "(файл без подписи)"
	}
	head := fmt.Sprintf("Отчёт от %s", m.Name)
	if m.Handing > 0 {
		head = fmt.Sprintf("%s сдал задачу №%d", m.Name, m.Handing)
	}
	if id := b.owner(); id != 0 {
		_ = b.call(ctx, "copyMessage", map[string]any{"chat_id": id, "from_chat_id": tg, "message_id": msgID, "caption": clip(head + ":\n" + note)}, nil)
	}
	b.Store.SetStep(m.ID, m.Step, 0)
	if m.Handing == -1 {
		_, _ = b.Store.AddReport(m.ID, note+" [файл отправлен владельцу]", b.now())
		b.send(ctx, tg, "Отчёт с файлом записан, владелец его видит.", b.menu())
		return
	}
	if err := b.Store.SetStatus(m.Handing, m.ID, Review, note+" [файл отправлен владельцу]", b.now()); err != nil {
		b.send(ctx, tg, err.Error(), b.menu())
		return
	}
	b.send(ctx, tg, "Сдано с файлом. Владелец посмотрит.", b.menu())
	b.toOwner(ctx, fmt.Sprintf("Принять задачу №%d: /ok %d", m.Handing, m.Handing))
}
