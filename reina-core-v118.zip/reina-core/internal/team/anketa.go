package team

import (
	"archive/zip"
	"bytes"
	"encoding/xml"
	"errors"
	"io"
	"strings"
)

// Application is what was read from a filled-in candidate form (the Word file "Анкета кандидата").
type Application struct {
	Name     string
	Role     string
	Profile  Profile
	Adult    bool // the 18+ box is ticked
	Rights   bool // "the works are mine or I may show them" is ticked
	Data     bool // consent to keep the data is ticked
	Warnings []string
}

type block struct {
	para  string
	rows  [][]string // a table: rows of cells
	table bool
}

const maxDocXML = 8 << 20

// readBlocks lists the paragraphs and tables of a .docx in order.
func readBlocks(data []byte) ([]block, error) {
	zr, err := zip.NewReader(bytes.NewReader(data), int64(len(data)))
	if err != nil {
		return nil, errors.New("это не файл Word (.docx)")
	}
	var raw []byte
	for _, f := range zr.File {
		if f.Name != "word/document.xml" {
			continue
		}
		rc, err := f.Open()
		if err != nil {
			return nil, errors.New("не удалось открыть документ")
		}
		raw, err = io.ReadAll(io.LimitReader(rc, maxDocXML))
		rc.Close()
		if err != nil {
			return nil, errors.New("не удалось прочитать документ")
		}
	}
	if raw == nil {
		return nil, errors.New("в файле нет текста документа")
	}
	var out []block
	var para, cell strings.Builder
	var row []string
	var rows [][]string
	depth, inT := 0, false // table depth; inside <w:t>
	dec := xml.NewDecoder(bytes.NewReader(raw))
	for {
		tok, err := dec.Token()
		if err != nil {
			break
		}
		switch t := tok.(type) {
		case xml.StartElement:
			switch t.Name.Local {
			case "tbl":
				depth++
				if depth == 1 {
					rows = nil
				}
			case "tr":
				row = nil
			case "tc":
				cell.Reset()
			case "t":
				inT = true
			case "tab":
				para.WriteString(" ")
			case "br":
				para.WriteString("\n")
			}
		case xml.CharData:
			if inT {
				para.Write(t)
			}
		case xml.EndElement:
			switch t.Name.Local {
			case "t":
				inT = false
			case "p":
				text := strings.TrimSpace(para.String())
				para.Reset()
				if depth > 0 {
					if cell.Len() > 0 && text != "" {
						cell.WriteString("\n")
					}
					cell.WriteString(text)
				} else {
					out = append(out, block{para: text})
				}
			case "tc":
				row = append(row, strings.TrimSpace(cell.String()))
				cell.Reset()
			case "tr":
				rows = append(rows, row)
			case "tbl":
				depth--
				if depth == 0 {
					out = append(out, block{table: true, rows: rows})
				}
			}
		}
	}
	return out, nil
}

// checked reports whether a line begins with a ticked box (or a plain x) and returns the text after the mark.
func checked(line string) (string, bool) {
	line = strings.TrimSpace(line)
	for _, m := range []string{"☒", "☑", "✅", "✔", "✓", "[x]", "[X]", "[х]", "[Х]"} {
		if strings.HasPrefix(line, m) {
			return strings.TrimSpace(strings.TrimPrefix(line, m)), true
		}
	}
	return line, false
}

// unticked reports a line that starts with an empty box, and the text after it.
func unticked(line string) (string, bool) {
	line = strings.TrimSpace(line)
	for _, m := range []string{"☐", "□", "[ ]"} {
		if strings.HasPrefix(line, m) {
			return strings.TrimSpace(strings.TrimPrefix(line, m)), true
		}
	}
	return line, false
}

func blank(s string) bool {
	return strings.Trim(strings.TrimSpace(s), "_ .-—") == ""
}

// ParseAnketa reads the form. It trusts only the structure of our own form and reports what is missing instead of guessing.
func ParseAnketa(data []byte) (Application, error) {
	bl, err := readBlocks(data)
	if err != nil {
		return Application{}, err
	}
	var a Application
	var single []string // the one-cell tables in order: skills, links, wishes
	val := map[string]string{}
	for _, b := range bl {
		if !b.table {
			if text, ok := checked(b.para); ok {
				switch {
				case strings.Contains(text, "18 лет"):
					a.Adult = true
				case strings.Contains(text, "хранит и читает"):
					a.Data = true
				case strings.Contains(text, "сделал я сам"):
					a.Rights = true
				case strings.HasPrefix(text, "Другая роль"):
					if _, v, ok := strings.Cut(text, ":"); ok && !blank(v) {
						a.Role = strings.TrimSpace(v)
					}
				default:
					if a.Role == "" {
						a.Role = text
					}
				}
			} else if text, ok := unticked(b.para); ok && strings.HasPrefix(text, "Другая роль") {
				// the candidate may have written the role without ticking the box
				if _, v, ok := strings.Cut(text, ":"); ok && !blank(v) && a.Role == "" {
					a.Role = strings.TrimSpace(v)
				}
			}
			continue
		}
		if len(b.rows) == 1 && len(b.rows[0]) == 1 {
			single = append(single, b.rows[0][0])
			continue
		}
		for _, r := range b.rows {
			if len(r) >= 2 && !blank(r[1]) {
				val[strings.TrimSpace(r[0])] = r[1]
			}
		}
	}
	pick := func(prefix string) string {
		for k, v := range val {
			if strings.HasPrefix(k, prefix) {
				return v
			}
		}
		return ""
	}
	a.Name = pick("Имя или ник")
	tg, mail := pick("Telegram"), pick("Почта")
	p := &a.Profile
	p.FullName = a.Name
	p.Contact = strings.TrimSpace(strings.Join(nonEmpty(tg, mail), ", "))
	if len(single) > 0 {
		p.Skills = clip(single[0])
	}
	if len(single) > 1 {
		p.Links = clip(single[1])
	}
	var hours []string
	if h := pick("Часов в неделю"); h != "" {
		hours = append(hours, h)
	}
	if h := pick("С какого времени"); h != "" {
		hours = append(hours, "начать: "+h)
	}
	if h := pick("Ожидания"); h != "" {
		hours = append(hours, "ожидания: "+h)
	}
	p.Hours = clip(strings.Join(hours, "; "))
	var extra []string
	if v := pick("Страна"); v != "" {
		extra = append(extra, "страна, пояс: "+v)
	}
	if v := pick("Дата рождения"); v != "" {
		extra = append(extra, "родился: "+v)
	}
	if v := pick("Другая работа"); v != "" {
		extra = append(extra, "сейчас: "+v)
	}
	if len(single) > 2 && !blank(single[2]) {
		extra = append(extra, "хочет заниматься: "+single[2])
	}
	p.Extra = clip(strings.Join(extra, "\n"))
	if a.Name == "" {
		return a, errors.New("в анкете не заполнено «Имя или ник»")
	}
	if a.Role == "" {
		a.Warnings = append(a.Warnings, "роль не отмечена, впиши её в /new или оставь пустой")
	}
	if p.Contact == "" {
		a.Warnings = append(a.Warnings, "нет контакта (Telegram или почты)")
	}
	if !a.Adult {
		a.Warnings = append(a.Warnings, "не отмечено, что ему 18+")
	}
	if !a.Rights {
		a.Warnings = append(a.Warnings, "не отмечено, что работы его собственные")
	}
	return a, nil
}

func nonEmpty(s ...string) []string {
	var out []string
	for _, x := range s {
		if strings.TrimSpace(x) != "" {
			out = append(out, strings.TrimSpace(x))
		}
	}
	return out
}
