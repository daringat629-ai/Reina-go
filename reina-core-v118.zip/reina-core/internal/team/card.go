package team

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"html"
	"io"
	"mime/multipart"
	"net/http"
	"strings"
	"time"
)

// The card is black and white and drawn with lines, like the Orvi cards: no emoji font is needed, so it looks the same everywhere.
const (
	cBg, cBg2, cFg, cMuted, cLine = "#0B0B0B", "#151515", "#F2F2F2", "#9A9A9A", "#2A2A2A"
)

var cardIcons = map[string]string{
	"tasks":  `<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 3.5h6v3H9z"/><path d="M8.5 12l1.8 1.8 3-3.3M8.5 17h7"/>`,
	"report": `<path d="M6 3.5h8l4 4V20.5H6z"/><path d="M14 3.5v4h4"/><path d="M9 12h6M9 15.5h6"/>`,
	"rights": `<path d="M12 3.5l7 2.5v5.5c0 4.2-3 7.4-7 9-4-1.6-7-4.8-7-9V6z"/><path d="M8.8 12l2.2 2.2 4.2-4.4"/>`,
}

func cardIcon(name string, x, y, size float64) string {
	return fmt.Sprintf(`<g transform="translate(%.1f %.1f) scale(%.3f)" fill="none" stroke="%s" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">%s</g>`, x, y, size/24, cFg, cardIcons[name])
}

func clipRunes(s string, n int) string {
	s = strings.Join(strings.Fields(s), " ")
	if r := []rune(s); len(r) > n {
		return string(r[:n-1]) + "…"
	}
	return s
}

// CardSVG draws a member's working card: who, what role, how much work is open and done, and whether the rights clause is accepted.
func CardSVG(m Member, open, review, closed, reports int, agreed bool) string {
	e := func(s string, n int) string { return html.EscapeString(clipRunes(s, n)) }
	var sb strings.Builder
	sb.WriteString(`<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="620" viewBox="0 0 1000 620" font-family="DejaVu Sans, Arial, sans-serif">`)
	fmt.Fprintf(&sb, `<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="%s"/><stop offset="1" stop-color="%s"/></linearGradient></defs>`, cBg2, cBg)
	fmt.Fprintf(&sb, `<rect width="1000" height="620" fill="url(#g)"/><rect x="24" y="24" width="952" height="572" rx="28" fill="none" stroke="%s" stroke-width="2"/>`, cLine)
	fmt.Fprintf(&sb, `<text x="64" y="84" fill="%s" font-size="22" letter-spacing="6">РАБОЧИЙ ПРОФИЛЬ · №%d</text>`, cMuted, m.ID)
	name := m.Profile.FullName
	if name == "" {
		name = m.Name
	}
	fmt.Fprintf(&sb, `<text x="64" y="170" fill="%s" font-size="62" font-weight="300">%s</text>`, cFg, e(name, 22))
	fmt.Fprintf(&sb, `<text x="64" y="222" fill="%s" font-size="30">%s</text>`, cMuted, e(m.Role, 40))
	fmt.Fprintf(&sb, `<path d="M64 262h872" stroke="%s" stroke-width="2"/>`, cLine)
	stat := func(x float64, icon, label string, n int) {
		sb.WriteString(cardIcon(icon, x, 296, 44))
		fmt.Fprintf(&sb, `<text x="%.0f" y="330" fill="%s" font-size="44" font-weight="300">%d</text>`, x+62, cFg, n)
		fmt.Fprintf(&sb, `<text x="%.0f" y="372" fill="%s" font-size="20">%s</text>`, x, cMuted, label)
	}
	stat(64, "tasks", "в работе и новые", open)
	stat(364, "report", "отчётов написано", reports)
	stat(664, "tasks", "задач принято", closed)
	_ = review
	fmt.Fprintf(&sb, `<path d="M64 410h872" stroke="%s" stroke-width="2"/>`, cLine)
	sb.WriteString(cardIcon("rights", 64, 440, 40))
	status, col := "согласие на права не подтверждено", cMuted
	if agreed {
		status, col = "согласие на права подтверждено "+m.ConsentT.Format("02.01.2006"), cFg
	}
	fmt.Fprintf(&sb, `<text x="124" y="470" fill="%s" font-size="26">%s</text>`, col, e(status, 60))
	hours := m.Profile.Hours
	if hours == "" {
		hours = "—"
	}
	fmt.Fprintf(&sb, `<text x="64" y="540" fill="%s" font-size="22">%s</text>`, cMuted, e("занятость: "+hours, 70))
	fmt.Fprintf(&sb, `<text x="936" y="568" fill="%s" font-size="18" text-anchor="end" letter-spacing="4">SPORADEV</text>`, cLine)
	sb.WriteString(`</svg>`)
	return sb.String()
}

// sendPhoto sends a picture with an optional caption and keyboard (the token never goes into an error text).
func (b *Bot) sendPhoto(ctx context.Context, chat int64, png []byte, caption string, markup any) error {
	var body bytes.Buffer
	w := multipart.NewWriter(&body)
	_ = w.WriteField("chat_id", fmt.Sprint(chat))
	if caption != "" {
		_ = w.WriteField("caption", caption)
	}
	if markup != nil {
		kb, _ := json.Marshal(markup)
		_ = w.WriteField("reply_markup", string(kb))
	}
	fw, _ := w.CreateFormFile("photo", "card.png")
	_, _ = fw.Write(png)
	_ = w.Close()
	base := b.BaseURL
	if base == "" {
		base = "https://api.telegram.org"
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, base+"/bot"+strings.TrimSpace(b.Token)+"/sendPhoto", &body)
	if err != nil {
		return errors.New("sendPhoto: bad request")
	}
	req.Header.Set("Content-Type", w.FormDataContentType())
	hc := b.HTTP
	if hc == nil {
		hc = &http.Client{Timeout: 70 * time.Second}
	}
	resp, err := hc.Do(req)
	if err != nil {
		return errors.New("sendPhoto failed")
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(resp.Body)
	var r struct {
		OK          bool   `json:"ok"`
		Description string `json:"description"`
	}
	if json.Unmarshal(raw, &r) != nil || !r.OK {
		return fmt.Errorf("sendPhoto: %s", r.Description)
	}
	return nil
}
