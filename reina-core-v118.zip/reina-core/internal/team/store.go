// Package team is the private cabinet of the people who build the product with us: the owner issues a one-time key, the person
// enters it in the team bot and gets a profile, their own tasks and a recorded consent to the rights clause. The cabinet only
// keeps records: it never moves money and never gives anyone access to the character, the server or the other members.
package team

import (
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"strings"
	"sync"
	"time"

	"orvi/internal/store"
)

// Task statuses.
const (
	Open   = "open"   // given, not taken yet
	Taken  = "taken"  // the member works on it
	Review = "review" // handed in, waits for the owner
	Closed = "closed" // accepted
)

// Member is one person of the team.
type Member struct {
	ID       int       `json:"id"`
	Name     string    `json:"name"`            // how the owner calls them
	Role     string    `json:"role"`            // the role the owner gave
	KeyHash  string    `json:"key_hash"`        // sha256 of the key; the key itself is never stored
	TG       int64     `json:"tg,omitempty"`    // the Telegram id the key was bound to
	Bound    time.Time `json:"bound,omitempty"` // when
	Revoked  bool      `json:"revoked,omitempty"`
	Profile  Profile   `json:"profile"`
	Step     int       `json:"step,omitempty"`    // which profile question waits for an answer (0 = none)
	Handing  int       `json:"handing,omitempty"` // id of the task whose result is being typed (0 = none)
	Consent  string    `json:"consent,omitempty"` // hash of the rights text the person agreed to
	ConsentT time.Time `json:"consent_t,omitempty"`
	Nudged   time.Time `json:"nudged,omitempty"` // when the member was last asked for a report
}

// Profile is what the person tells about themselves. Requisites are free text for the owner's own bookkeeping.
type Profile struct {
	FullName string `json:"full_name,omitempty"`
	Contact  string `json:"contact,omitempty"`
	Skills   string `json:"skills,omitempty"`
	Links    string `json:"links,omitempty"`
	Hours    string `json:"hours,omitempty"`
	Pay      string `json:"pay,omitempty"`
	Extra    string `json:"extra,omitempty"` // country, birth date, other work, wishes: from the form
}

// Task is a job for one member.
type Task struct {
	ID      int       `json:"id"`
	Member  int       `json:"member"`
	Title   string    `json:"title"`
	Brief   string    `json:"brief,omitempty"`
	Status  string    `json:"status"`
	Result  string    `json:"result,omitempty"`
	Created time.Time `json:"created"`
	Updated time.Time `json:"updated"`
	Due     time.Time `json:"due,omitempty"`    // deadline (zero = none)
	Remind  time.Time `json:"remind,omitempty"` // when the member was last reminded
}

// Report is what a member wrote about their own work, with or without a task.
type Report struct {
	ID     int       `json:"id"`
	Member int       `json:"member"`
	Text   string    `json:"text"`
	At     time.Time `json:"at"`
}

type file struct {
	Members []Member `json:"members"`
	Tasks   []Task   `json:"tasks"`
	Reports []Report `json:"reports,omitempty"`
	NextR   int      `json:"next_r,omitempty"`
	Digest  string   `json:"digest,omitempty"` // the day the weekly summary was last sent
	NextM   int      `json:"next_m"`
	NextT   int      `json:"next_t"`
}

// Store keeps the team in one private JSON file.
type Store struct {
	mu    sync.Mutex
	path  string
	saver store.Saver
	f     file
}

const maxText = 1500

// New opens (or creates) the team file.
func New(path string) *Store {
	s := &Store{path: path, saver: store.Saver{What: "team"}}
	store.Load("team", path, &s.f)
	if s.f.NextM == 0 {
		s.f.NextM = 1
	}
	if s.f.NextT == 0 {
		s.f.NextT = 1
	}
	return s
}

func (s *Store) save() { _ = s.saver.Save(s.path, s.f) }

func clip(t string) string {
	t = strings.TrimSpace(t)
	if r := []rune(t); len(r) > maxText {
		t = string(r[:maxText])
	}
	return t
}

func hash(key string) string {
	h := sha256.Sum256([]byte(normKey(key)))
	return hex.EncodeToString(h[:])
}

// normKey makes "spr-ab12-cd34", " SPR AB12 CD34 " and the real thing the same.
func normKey(k string) string {
	k = strings.ToUpper(strings.TrimSpace(k))
	return strings.NewReplacer(" ", "", "-", "", "_", "").Replace(k)
}

const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789" // no 0/O/1/I: a key is read aloud and retyped

func newKey() string {
	b := make([]byte, 8)
	_, _ = rand.Read(b)
	out := make([]byte, 8)
	for i := range b {
		out[i] = alphabet[int(b[i])%len(alphabet)]
	}
	return "SPR-" + string(out[:4]) + "-" + string(out[4:])
}

// Invite adds a member and returns the key; it is shown once and cannot be recovered afterwards.
func (s *Store) Invite(name, role string) (Member, string, error) {
	return s.InviteWith(name, role, Profile{})
}

// InviteWith is Invite with a profile that is already filled in (read from the candidate's form).
func (s *Store) InviteWith(name, role string, p Profile) (Member, string, error) {
	name, role = clip(name), clip(role)
	if name == "" {
		return Member{}, "", errors.New("нужно имя")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	key := newKey()
	m := Member{ID: s.f.NextM, Name: name, Role: role, KeyHash: hash(key), Profile: p}
	s.f.NextM++
	s.f.Members = append(s.f.Members, m)
	s.save()
	return m, key, nil
}

func (s *Store) member(id int) *Member {
	for i := range s.f.Members {
		if s.f.Members[i].ID == id {
			return &s.f.Members[i]
		}
	}
	return nil
}

// ByTG is the member whose Telegram account is bound to the cabinet.
func (s *Store) ByTG(tg int64) (Member, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	for _, m := range s.f.Members {
		if m.TG == tg && !m.Revoked {
			return m, true
		}
	}
	return Member{}, false
}

// Get returns a member by number.
func (s *Store) Get(id int) (Member, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if m := s.member(id); m != nil {
		return *m, true
	}
	return Member{}, false
}

// Redeem binds a key to a Telegram account. A key works once; a revoked or already used key does not.
func (s *Store) Redeem(key string, tg int64, now time.Time) (Member, error) {
	if normKey(key) == "" {
		return Member{}, errors.New("пустой ключ")
	}
	h := hash(key)
	s.mu.Lock()
	defer s.mu.Unlock()
	for i := range s.f.Members {
		m := &s.f.Members[i]
		if m.KeyHash != h {
			continue
		}
		if m.Revoked {
			return Member{}, errors.New("ключ отозван")
		}
		if m.TG != 0 && m.TG != tg {
			return Member{}, errors.New("ключ уже использован")
		}
		m.TG, m.Bound = tg, now
		s.save()
		return *m, nil
	}
	return Member{}, errors.New("такого ключа нет")
}

// Revoke closes the cabinet of a member (the person stays in the list).
func (s *Store) Revoke(id int) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	m := s.member(id)
	if m == nil {
		return errors.New("нет такого участника")
	}
	m.Revoked = true
	s.save()
	return nil
}

// Members lists everyone.
func (s *Store) Members() []Member {
	s.mu.Lock()
	defer s.mu.Unlock()
	return append([]Member(nil), s.f.Members...)
}

// SetStep remembers which profile question the person is answering now.
func (s *Store) SetStep(id, step, handing int) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if m := s.member(id); m != nil {
		m.Step, m.Handing = step, handing
		s.save()
	}
}

// Answer stores one profile answer by its question number (1..6) and moves on; it returns the next step (0 = done).
func (s *Store) Answer(id, step int, text string) int {
	text = clip(text)
	s.mu.Lock()
	defer s.mu.Unlock()
	m := s.member(id)
	if m == nil {
		return 0
	}
	p := &m.Profile
	switch step {
	case 1:
		p.FullName = text
	case 2:
		p.Contact = text
	case 3:
		p.Skills = text
	case 4:
		p.Links = text
	case 5:
		p.Hours = text
	case 6:
		p.Pay = text
	}
	m.Step = step + 1
	if m.Step > 6 {
		m.Step = 0
	}
	s.save()
	return m.Step
}

// Agree records that the person accepted this exact text of the rights clause.
func (s *Store) Agree(id int, text string, now time.Time) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if m := s.member(id); m != nil {
		m.Consent, m.ConsentT = hash(text), now
		s.save()
	}
}

// Agreed says whether the person accepted this very text (a changed text asks again).
func (s *Store) Agreed(id int, text string) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	m := s.member(id)
	return m != nil && m.Consent != "" && m.Consent == hash(text)
}

// AddTask gives a member a job.
func (s *Store) AddTask(member int, title, brief string, now time.Time) (Task, error) {
	return s.AddTaskDue(member, title, brief, time.Time{}, now)
}

// AddTaskDue gives a member a job with a deadline (zero = none).
func (s *Store) AddTaskDue(member int, title, brief string, due, now time.Time) (Task, error) {
	title = clip(title)
	if title == "" {
		return Task{}, errors.New("нужно название задачи")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.member(member) == nil {
		return Task{}, errors.New("нет такого участника")
	}
	t := Task{ID: s.f.NextT, Member: member, Title: title, Brief: clip(brief), Status: Open, Created: now, Updated: now, Due: due}
	s.f.NextT++
	s.f.Tasks = append(s.f.Tasks, t)
	s.save()
	return t, nil
}

// Tasks returns the tasks of one member (member 0 = all of them).
func (s *Store) Tasks(member int) []Task {
	s.mu.Lock()
	defer s.mu.Unlock()
	var out []Task
	for _, t := range s.f.Tasks {
		if member == 0 || t.Member == member {
			out = append(out, t)
		}
	}
	return out
}

// GetTask returns one task.
func (s *Store) GetTask(id int) (Task, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	for _, t := range s.f.Tasks {
		if t.ID == id {
			return t, true
		}
	}
	return Task{}, false
}

// SetStatus moves a task; a member may only touch their own (member 0 = the owner, any task). A result goes with Review.
func (s *Store) SetStatus(id, member int, status, result string, now time.Time) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	for i := range s.f.Tasks {
		t := &s.f.Tasks[i]
		if t.ID != id {
			continue
		}
		if member != 0 && t.Member != member {
			return errors.New("это не твоя задача")
		}
		t.Status, t.Updated = status, now
		if r := clip(result); r != "" {
			t.Result = r
		}
		s.save()
		return nil
	}
	return errors.New("нет такой задачи")
}

// AddReport stores a free report of a member.
func (s *Store) AddReport(member int, text string, now time.Time) (Report, error) {
	text = clip(text)
	if text == "" {
		return Report{}, errors.New("пустой отчёт")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.member(member) == nil {
		return Report{}, errors.New("нет такого участника")
	}
	if s.f.NextR == 0 {
		s.f.NextR = 1
	}
	r := Report{ID: s.f.NextR, Member: member, Text: text, At: now}
	s.f.NextR++
	s.f.Reports = append(s.f.Reports, r)
	s.save()
	return r, nil
}

// LastReports returns up to n newest reports, oldest first (member 0 = everyone).
func (s *Store) LastReports(member, n int) []Report {
	s.mu.Lock()
	defer s.mu.Unlock()
	var out []Report
	for i := len(s.f.Reports) - 1; i >= 0 && len(out) < n; i-- {
		if r := s.f.Reports[i]; member == 0 || r.Member == member {
			out = append(out, r)
		}
	}
	for i, j := 0, len(out)-1; i < j; i, j = i+1, j-1 {
		out[i], out[j] = out[j], out[i]
	}
	return out
}

// ResetKey gives a member a new key and frees the Telegram binding (a lost key or a new account); a closed cabinet opens again.
func (s *Store) ResetKey(id int) (Member, string, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	m := s.member(id)
	if m == nil {
		return Member{}, "", errors.New("нет такого участника")
	}
	key := newKey()
	m.KeyHash, m.TG, m.Bound, m.Revoked, m.Step, m.Handing = hash(key), 0, time.Time{}, false, 0, 0
	s.save()
	return *m, key, nil
}

const (
	staleAfter  = 3 * 24 * time.Hour // an unfinished task this old gets a reminder
	remindEvery = 24 * time.Hour
	quietAfter  = 7 * 24 * time.Hour // no report for this long: ask for one
)

// DueReminders returns the unfinished tasks that need a reminder now (old, or past the deadline) and marks them reminded.
func (s *Store) DueReminders(now time.Time) []Task {
	s.mu.Lock()
	defer s.mu.Unlock()
	var out []Task
	for i := range s.f.Tasks {
		t := &s.f.Tasks[i]
		if t.Status != Open && t.Status != Taken {
			continue
		}
		late := !t.Due.IsZero() && now.After(t.Due)
		if !late && now.Sub(t.Updated) < staleAfter {
			continue
		}
		if now.Sub(t.Remind) < remindEvery {
			continue
		}
		t.Remind = now
		out = append(out, *t)
	}
	if len(out) > 0 {
		s.save()
	}
	return out
}

// QuietMembers returns the members in the cabinet who wrote no report for a week (and were not asked for a week) and marks them asked.
func (s *Store) QuietMembers(now time.Time) []Member {
	s.mu.Lock()
	defer s.mu.Unlock()
	var out []Member
	for i := range s.f.Members {
		m := &s.f.Members[i]
		if m.TG == 0 || m.Revoked || now.Sub(m.Bound) < quietAfter || now.Sub(m.Nudged) < quietAfter {
			continue
		}
		last := m.Bound
		for _, r := range s.f.Reports {
			if r.Member == m.ID && r.At.After(last) {
				last = r.At
			}
		}
		if now.Sub(last) < quietAfter {
			continue
		}
		m.Nudged = now
		out = append(out, *m)
	}
	if len(out) > 0 {
		s.save()
	}
	return out
}

// DigestDue says whether the weekly summary should go out now (Monday from 10:00 local time, once a day) and marks it sent.
func (s *Store) DigestDue(now time.Time) bool {
	day := now.Format("2006-01-02")
	s.mu.Lock()
	defer s.mu.Unlock()
	if now.Weekday() != time.Monday || now.Hour() < 10 || s.f.Digest == day {
		return false
	}
	s.f.Digest = day
	s.save()
	return true
}
