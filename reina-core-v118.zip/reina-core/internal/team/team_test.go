package team

import (
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestKeyBindsOnceAndRevokes(t *testing.T) {
	s := New(filepath.Join(t.TempDir(), "team.json"))
	m, key, err := s.Invite("Руслан", "3D")
	if err != nil || !strings.HasPrefix(key, "SPR-") {
		t.Fatalf("invite: %v %q", err, key)
	}
	now := time.Now()
	if _, err := s.Redeem("wrong", 5, now); err == nil {
		t.Fatal("a wrong key must fail")
	}
	// the key is accepted in any case and spacing
	if _, err := s.Redeem(strings.ToLower(strings.ReplaceAll(key, "-", " ")), 5, now); err != nil {
		t.Fatalf("redeem: %v", err)
	}
	if _, err := s.Redeem(key, 6, now); err == nil {
		t.Fatal("a used key must not bind to another account")
	}
	if got, ok := s.ByTG(5); !ok || got.ID != m.ID {
		t.Fatal("member not found by Telegram id")
	}
	if s.Revoke(m.ID) != nil {
		t.Fatal("revoke")
	}
	if _, ok := s.ByTG(5); ok {
		t.Fatal("a revoked member must lose the cabinet")
	}
	// the key itself is not on disk
	s2 := New(s.path)
	for _, x := range s2.Members() {
		if strings.Contains(x.KeyHash, "SPR") {
			t.Fatal("key stored in clear")
		}
	}
}

func TestProfileTasksConsent(t *testing.T) {
	s := New(filepath.Join(t.TempDir(), "team.json"))
	m, _, _ := s.Invite("Аня", "Арт")
	other, _, _ := s.Invite("Боря", "Звук")
	now := time.Now()
	step := 1
	for i := 1; i <= 6; i++ {
		step = s.Answer(m.ID, i, "ответ")
	}
	if step != 0 {
		t.Fatalf("after the last question the step must be 0, got %d", step)
	}
	if g, _ := s.Get(m.ID); g.Profile.Pay != "ответ" || g.Profile.FullName != "ответ" {
		t.Fatal("answers not stored")
	}
	task, err := s.AddTask(m.ID, "Логотип", "", now)
	if err != nil {
		t.Fatal(err)
	}
	if s.SetStatus(task.ID, other.ID, Taken, "", now) == nil {
		t.Fatal("a member must not touch another member's task")
	}
	if err := s.SetStatus(task.ID, m.ID, Review, "готово", now); err != nil {
		t.Fatal(err)
	}
	if got, _ := s.GetTask(task.ID); got.Status != Review || got.Result != "готово" {
		t.Fatal("review not stored")
	}
	if s.Agreed(m.ID, "текст") {
		t.Fatal("no consent yet")
	}
	s.Agree(m.ID, "текст", now)
	if !s.Agreed(m.ID, "текст") || s.Agreed(m.ID, "другой текст") {
		t.Fatal("consent must be bound to the exact text")
	}
}

func TestParseAnketa(t *testing.T) {
	data := buildDocx(t, []string{"☒  Художник и дизайнер образов", "☐  Тестировщик", "☐  Другая роль: ______", "☒  Мне есть 18 лет. Я понимаю", "☒  Работы, которые я показываю, сделал я сам или есть право"},
		[][][]string{
			{{"Имя или ник", "Руслан"}, {"Telegram (@username)", "@ruslan"}, {"Почта", ""}, {"Дата рождения (нам нужно знать, что тебе 18+)", "01.01.2000"}},
			{{"Blender, три года"}}, {{"https://example.com/work"}},
			{{"Часов в неделю", "10"}, {"Ожидания по оплате или доле", "обсудим"}},
			{{"арт и модели"}},
		})
	a, err := ParseAnketa(data)
	if err != nil {
		t.Fatal(err)
	}
	if a.Name != "Руслан" || a.Role != "Художник и дизайнер образов" || !a.Adult || !a.Rights || a.Data {
		t.Fatalf("bad parse: %+v", a)
	}
	if a.Profile.Contact != "@ruslan" || a.Profile.Skills != "Blender, три года" || a.Profile.Links != "https://example.com/work" || !strings.Contains(a.Profile.Hours, "10") {
		t.Fatalf("bad profile: %+v", a.Profile)
	}
	if _, err := ParseAnketa([]byte("not a zip")); err == nil {
		t.Fatal("a non-docx must be refused")
	}
}

func TestReports(t *testing.T) {
	s := New(filepath.Join(t.TempDir(), "team.json"))
	a, _, _ := s.Invite("Аня", "Арт")
	b, _, _ := s.Invite("Боря", "Звук")
	now := time.Now()
	if _, err := s.AddReport(a.ID, "  ", now); err == nil {
		t.Fatal("an empty report must be refused")
	}
	s.AddReport(a.ID, "первый", now)
	s.AddReport(b.ID, "чужой", now)
	s.AddReport(a.ID, "второй", now)
	got := s.LastReports(a.ID, 5)
	if len(got) != 2 || got[0].Text != "первый" || got[1].Text != "второй" {
		t.Fatalf("own reports in order: %+v", got)
	}
	if len(s.LastReports(0, 2)) != 2 {
		t.Fatal("limit not applied")
	}
}

func TestCardAndMenu(t *testing.T) {
	m := Member{ID: 3, Name: "Аня", Role: "Арт <b>"}
	svg := CardSVG(m, 1, 0, 2, 4, true)
	if !strings.Contains(svg, "Аня") || strings.Contains(svg, "<b>") {
		t.Fatal("name missing or role not escaped")
	}
	if canon("Профиль") != "👤 Профиль" || canon("📋 Задачи") != "📋 Задачи" {
		t.Fatal("canon")
	}
	b := &Bot{Icon: func(k string) string {
		if k == "tasks" {
			return "123"
		}
		return ""
	}}
	row := b.menu()["keyboard"].([][]map[string]any)[0]
	if row[1]["icon_custom_emoji_id"] != "123" || row[1]["text"] != "Задачи" || row[0]["text"] != "👤 Профиль" {
		t.Fatalf("menu: %+v", row)
	}
}

func TestRemindersDigestKeyReset(t *testing.T) {
	s := New(filepath.Join(t.TempDir(), "team.json"))
	m, key, _ := s.Invite("Аня", "Арт")
	t0 := time.Date(2026, 11, 2, 12, 0, 0, 0, time.UTC) // a Monday
	if _, err := s.Redeem(key, 5, t0); err != nil {
		t.Fatal(err)
	}
	task, _ := s.AddTaskDue(m.ID, "Логотип", "", t0.Add(24*time.Hour), t0)
	if len(s.DueReminders(t0.Add(time.Hour))) != 0 {
		t.Fatal("a fresh task needs no reminder")
	}
	late := t0.Add(2 * 24 * time.Hour) // past the deadline, not yet "old"
	if got := s.DueReminders(late); len(got) != 1 || got[0].ID != task.ID {
		t.Fatalf("a late task must be reminded: %+v", got)
	}
	if len(s.DueReminders(late.Add(time.Hour))) != 0 {
		t.Fatal("not twice within a day")
	}
	if len(s.QuietMembers(t0.Add(3*24*time.Hour))) != 0 {
		t.Fatal("not quiet yet")
	}
	if len(s.QuietMembers(t0.Add(8*24*time.Hour))) != 1 {
		t.Fatal("a week without a report must be noticed")
	}
	if len(s.QuietMembers(t0.Add(9*24*time.Hour))) != 0 {
		t.Fatal("asked once a week only")
	}
	if s.DigestDue(t0.Add(-3*time.Hour)) || !s.DigestDue(t0) || s.DigestDue(t0.Add(time.Hour)) {
		t.Fatal("the summary goes out once on Monday after 10:00")
	}
	_, newKey, err := s.ResetKey(m.ID)
	if err != nil {
		t.Fatal(err)
	}
	if _, ok := s.ByTG(5); ok {
		t.Fatal("the old account must be unbound")
	}
	if _, err := s.Redeem(key, 6, t0); err == nil {
		t.Fatal("the old key must stop working")
	}
	if _, err := s.Redeem(newKey, 6, t0); err != nil {
		t.Fatal(err)
	}
}

func TestParseDue(t *testing.T) {
	loc := time.UTC
	now := time.Date(2026, 11, 6, 12, 0, 0, 0, loc)
	if d, ok := parseDue("до 12.11", now, loc); !ok || d.Day() != 12 || d.Year() != 2026 {
		t.Fatalf("%v %v", d, ok)
	}
	if d, ok := parseDue("01.02", now, loc); !ok || d.Year() != 2027 {
		t.Fatalf("a past day means next year: %v", d)
	}
	if d, ok := parseDue("15.12.2026", now, loc); !ok || d.Month() != 12 {
		t.Fatal("full date")
	}
	if _, ok := parseDue("потом", now, loc); ok {
		t.Fatal("garbage must not parse")
	}
}
