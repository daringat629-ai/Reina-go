package team

import (
	"context"
	"fmt"
	"strings"
	"time"
)

func (b *Bot) loc() *time.Location {
	if b.Loc != nil {
		return b.Loc
	}
	return time.Local
}

// parseDue reads "до 12.11", "12.11" or "12.11.2026" as the end of that day; a day already past this year means next year.
func parseDue(s string, now time.Time, loc *time.Location) (time.Time, bool) {
	s = strings.TrimSpace(strings.TrimPrefix(strings.TrimSpace(strings.ToLower(s)), "до"))
	if s == "" {
		return time.Time{}, false
	}
	now = now.In(loc)
	if d, err := time.ParseInLocation("02.01.2006", s, loc); err == nil {
		return d.Add(24*time.Hour - time.Second), true
	}
	if d, err := time.ParseInLocation("02.01", s, loc); err == nil {
		d = time.Date(now.Year(), d.Month(), d.Day(), 23, 59, 59, 0, loc)
		if d.Before(now.Add(-24 * time.Hour)) {
			d = d.AddDate(1, 0, 0)
		}
		return d, true
	}
	return time.Time{}, false
}

func dueText(t Task, now time.Time, loc *time.Location) string {
	if t.Due.IsZero() {
		return ""
	}
	s := "\nСрок: " + t.Due.In(loc).Format("02.01.2006")
	if t.Status != Closed && t.Status != Review && now.After(t.Due) {
		s += " (просрочена)"
	}
	return s
}

// RunReminders nudges members about old tasks and silence, and sends the owner a weekly summary.
func (b *Bot) RunReminders(ctx context.Context) {
	t := time.NewTicker(30 * time.Minute)
	defer t.Stop()
	for {
		b.remindOnce(ctx)
		select {
		case <-ctx.Done():
			return
		case <-t.C:
		}
	}
}

func (b *Bot) remindOnce(ctx context.Context) {
	now := b.now()
	for _, t := range b.Store.DueReminders(now) {
		m, ok := b.Store.Get(t.Member)
		if !ok || m.TG == 0 || m.Revoked {
			continue
		}
		b.send(ctx, m.TG, fmt.Sprintf("Напоминание: задача №%d «%s» ещё не сдана.%s\nЕсли что-то мешает, напиши об этом в «📝 Отчёт».", t.ID, t.Title, dueText(t, now, b.loc())), b.menu())
	}
	for _, m := range b.Store.QuietMembers(now) {
		b.send(ctx, m.TG, "Ты давно не писал отчёт. Нажми «📝 Отчёт» и напиши коротко, что сделано или что мешает.", b.menu())
	}
	if b.Store.DigestDue(now.In(b.loc())) {
		b.toOwner(ctx, b.Digest())
	}
}

// Digest is the owner's summary: who is in the cabinet, what is open, late and waiting for review, who is silent.
func (b *Bot) Digest() string {
	now := b.now()
	var sb strings.Builder
	sb.WriteString("Сводка по команде\n")
	members := b.Store.Members()
	if len(members) == 0 {
		return sb.String() + "Пока никого."
	}
	for _, m := range members {
		if m.Revoked {
			continue
		}
		open, late, review := 0, 0, 0
		for _, t := range b.Store.Tasks(m.ID) {
			switch t.Status {
			case Open, Taken:
				open++
				if !t.Due.IsZero() && now.After(t.Due) {
					late++
				}
			case Review:
				review++
			}
		}
		last := "отчётов нет"
		if rs := b.Store.LastReports(m.ID, 1); len(rs) > 0 {
			last = "отчёт " + rs[0].At.In(b.loc()).Format("02.01")
		}
		st := "ждёт ключ"
		if m.TG != 0 {
			st = "в кабинете"
		}
		agree := "без согласия"
		if b.Store.Agreed(m.ID, b.rights()) {
			agree = "согласие есть"
		}
		fmt.Fprintf(&sb, "\n№%d %s (%s): %s, %s, %s\n  задач: %d открыто, %d просрочено, %d на проверке\n", m.ID, m.Name, orDash(m.Role), st, agree, last, open, late, review)
	}
	return sb.String()
}
