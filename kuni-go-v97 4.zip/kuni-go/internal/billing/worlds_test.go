package billing

import (
	"path/filepath"
	"testing"
	"time"
)

func TestWorldAddrRules(t *testing.T) {
	for _, bad := range []string{"localhost", "127.0.0.1", "10.0.0.5", "192.168.1.2", "169.254.169.254", "0.0.0.0", "::1", "box.local", "svc.internal", "nodots", "a b.com"} {
		if CheckWorldAddr(bad, 25565) == nil {
			t.Errorf("%q must be refused", bad)
		}
	}
	for _, ok := range []string{"play.example.com", "8.8.8.8"} {
		if err := CheckWorldAddr(ok, 25565); err != nil {
			t.Errorf("%q: %v", ok, err)
		}
	}
	if CheckWorldAddr("play.example.com", 80) == nil || CheckWorldAddr("play.example.com", 70000) == nil {
		t.Error("ports out of range must be refused")
	}
}

func TestWorldsAreYoursAlone(t *testing.T) {
	s := Open(filepath.Join(t.TempDir(), "b.json"))
	now := time.Now()
	w, err := s.AddWorld(1, "", "Play.Example.com", 25565, now)
	if err != nil || w.Name != "Мой мир" || w.Host != "play.example.com" {
		t.Fatalf("%+v %v", w, err)
	}
	if _, err := s.AddWorld(1, "x", "play.example.com", 25565, now); err == nil {
		t.Fatal("duplicate")
	}
	s.AddWorld(1, "b", "b.example.com", 25565, now)
	s.AddWorld(1, "c", "c.example.com", 25565, now)
	if _, err := s.AddWorld(1, "d", "d.example.com", 25565, now); err == nil {
		t.Fatal("limit per person")
	}
	if s.DelWorld(2, w.ID) {
		t.Fatal("someone else removed my world")
	}
	if !s.DelWorld(1, w.ID) || len(s.WorldsOf(1)) != 2 {
		t.Fatal("own removal")
	}
	s2 := Open(s.path)
	if len(s2.WorldsOf(1)) != 2 {
		t.Fatal("not kept after reload")
	}
	h, p, n, err := ParseWorld("play.example.com Моя база")
	if err != nil || h != "play.example.com" || p != 25565 || n != "Моя база" {
		t.Fatalf("%s %d %s %v", h, p, n, err)
	}
	if _, _, _, err := ParseWorld("play.example.com:abc"); err == nil {
		t.Fatal("bad port")
	}
}

func TestVisitFeeIsTakenAndReturned(t *testing.T) {
	s := Open(filepath.Join(t.TempDir(), "b.json"))
	now := time.Now()
	if err := s.TakeTokens(5, 100); err == nil {
		t.Fatal("a stranger has no balance")
	}
	s.AddTokens(5, 1000, 0, 0, "x1", "pack", now)
	if err := s.TakeTokens(5, 400); err != nil || s.Get(5, now).Tokens != 600 {
		t.Fatalf("take: %v %d", err, s.Get(5, now).Tokens)
	}
	if s.TakeTokens(5, 601) == nil {
		t.Fatal("more than the balance")
	}
	s.GiveBackTokens(5, 400)
	if u := s.Get(5, now); u.Tokens != 1000 || u.Spent != 0 {
		t.Fatalf("give back: %+v", u)
	}
}
