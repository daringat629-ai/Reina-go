package billing

import (
	"context"
	"errors"
	"fmt"
	"log"
	"regexp"
	"sort"
	"strings"
	"time"
)

// EcoBot is one bot of the ecosystem (Orvi, SpermaDev and whoever joins later). The pay bot shows them as a catalogue, the owner
// manages the list from the admin bot. Reina herself is not stored here: she is always the first line of the catalogue.
type EcoBot struct {
	ID       string    `json:"id"`                 // short name used in commands, a-z 0-9 _
	Name     string    `json:"name"`               // what people see
	Owner    string    `json:"owner"`              // who runs it: orvi, spermadev, ...
	Username string    `json:"username"`           // Telegram @username without @
	About    string    `json:"about,omitempty"`    // one line for the catalogue
	Kind     string    `json:"kind,omitempty"`     // character (an AI persona like Reina), tool, link
	Off      bool      `json:"off,omitempty"`      // hidden from people
	Share    int       `json:"share,omitempty"`    // partner's share of the money in percent (kept for later payouts)
	KeyHash  string    `json:"key_hash,omitempty"` // sha256 of the API key (the key itself is shown once and never stored)
	Credit   bool      `json:"credit,omitempty"`   // the key may ADD tokens (a site that takes payments); without it the key can only read and spend
	Added    time.Time `json:"added,omitempty"`
}

const maxEcoBots = 50

var (
	ecoID   = regexp.MustCompile(`^[a-z0-9_]{2,24}$`)
	ecoUser = regexp.MustCompile(`^[A-Za-z][A-Za-z0-9_]{4,31}$`)
	ecoKind = map[string]bool{"character": true, "tool": true, "link": true}
)

// Ecosystem returns the stored bots in the order they were added.
func (s *Store) Ecosystem() []EcoBot {
	s.mu.Lock()
	defer s.mu.Unlock()
	out := append([]EcoBot(nil), s.d.Bots...)
	sort.SliceStable(out, func(i, j int) bool { return out[i].Added.Before(out[j].Added) })
	return out
}

// EcoBotByID finds one bot.
func (s *Store) EcoBotByID(id string) (EcoBot, bool) {
	id = strings.ToLower(strings.TrimSpace(id))
	for _, b := range s.Ecosystem() {
		if b.ID == id {
			return b, true
		}
	}
	return EcoBot{}, false
}

// AddEcoBot adds a bot, or replaces the one with the same id.
func (s *Store) AddEcoBot(b EcoBot, now time.Time) error {
	b.ID = strings.ToLower(strings.TrimSpace(b.ID))
	b.Owner = strings.ToLower(strings.TrimSpace(b.Owner))
	b.Username = strings.TrimPrefix(strings.TrimSpace(b.Username), "@")
	b.Name = strings.TrimSpace(b.Name)
	b.About = strings.TrimSpace(b.About)
	b.Kind = strings.ToLower(strings.TrimSpace(b.Kind))
	switch {
	case !ecoID.MatchString(b.ID):
		return errors.New("id: 2-24 символа, латиница, цифры и _")
	case b.ID == "reina":
		return errors.New("id reina занят: Рейна всегда первая в списке")
	case !ecoUser.MatchString(b.Username):
		return errors.New("username бота: латиница, цифры и _, 5-32 символа")
	case b.Name == "" || len([]rune(b.Name)) > 40:
		return errors.New("название: от 1 до 40 символов")
	case len([]rune(b.About)) > 160:
		return errors.New("описание: до 160 символов")
	case b.Owner == "" || !ecoID.MatchString(b.Owner):
		return errors.New("владелец: латиница, например orvi или spermadev")
	case b.Share < 0 || b.Share > 90:
		return errors.New("доля партнёра: от 0 до 90 процентов")
	}
	if b.Kind == "" {
		b.Kind = "character"
	}
	if !ecoKind[b.Kind] {
		return errors.New("тип: character, tool или link")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	for i, x := range s.d.Bots {
		if x.ID == b.ID {
			b.Added, b.KeyHash, b.Credit = x.Added, x.KeyHash, x.Credit
			s.d.Bots[i] = b
			s.save()
			return nil
		}
	}
	if len(s.d.Bots) >= maxEcoBots {
		return errors.New("слишком много ботов в списке")
	}
	b.Added = now
	s.d.Bots = append(s.d.Bots, b)
	s.save()
	return nil
}

// DelEcoBot removes a bot from the list.
func (s *Store) DelEcoBot(id string) bool {
	id = strings.ToLower(strings.TrimSpace(id))
	s.mu.Lock()
	defer s.mu.Unlock()
	for i, x := range s.d.Bots {
		if x.ID == id {
			s.d.Bots = append(s.d.Bots[:i], s.d.Bots[i+1:]...)
			s.save()
			return true
		}
	}
	return false
}

// SetEcoBotOff hides a bot from people (or shows it again).
func (s *Store) SetEcoBotOff(id string, off bool) bool {
	id = strings.ToLower(strings.TrimSpace(id))
	s.mu.Lock()
	defer s.mu.Unlock()
	for i := range s.d.Bots {
		if s.d.Bots[i].ID == id {
			s.d.Bots[i].Off = off
			s.save()
			return true
		}
	}
	return false
}

// ParseAddBot reads "/addbot id owner @username Name | about" (the part after the command). Share and kind are set in the app.
func ParseAddBot(args string) (EcoBot, error) {
	head, about, _ := strings.Cut(args, "|")
	f := strings.Fields(head)
	if len(f) < 4 {
		return EcoBot{}, errors.New("формат: /addbot id владелец @username Название | описание")
	}
	return EcoBot{ID: f[0], Owner: f[1], Username: f[2], Name: strings.Join(f[3:], " "), About: about}, nil
}

// botsList is the owner's view of the ecosystem list in the admin bot.
func (a *Admin) botsList() string {
	bots := a.Store.Ecosystem()
	var sb strings.Builder
	sb.WriteString("🤖 Боты экосистемы\n\n1. Рейна (всегда первая)\n")
	for i, b := range bots {
		state := ""
		if b.Off {
			state = " · скрыт"
		}
		api := "ключа нет"
		if b.KeyHash != "" {
			api = "ключ есть"
			if b.Credit {
				api += ", может начислять"
			}
		}
		fmt.Fprintf(&sb, "%d. %s · @%s · %s · %s%s\n   id: %s · API: %s\n", i+2, b.Name, b.Username, b.Owner, b.Kind, state, b.ID, api)
	}
	if len(bots) == 0 {
		sb.WriteString("\nДругих ботов пока нет.")
	}
	sb.WriteString("\n\n/addbot id владелец @username Название | описание\n/botoff id · /boton id · /delbot id\n/botkey id (новый API-ключ) · /botcredit id on|off (можно ли начислять токены)")
	return sb.String()
}

// ecosystem shows people the catalogue: Reina first, then the others, each with a button that opens the bot.
func (b *Bot) ecosystem(ctx context.Context, chat int64) {
	var sb strings.Builder
	var rows [][]map[string]any
	sb.WriteString("🤖 Боты экосистемы\n")
	if her := b.her(); her != "" {
		sb.WriteString("\n🌙 Рейна: AI-подруга, общается как живая.")
		rows = append(rows, []map[string]any{{"text": "🌙 Рейна", "url": "https://t.me/" + her}})
	}
	for _, x := range b.Store.Ecosystem() {
		if x.Off {
			continue
		}
		fmt.Fprintf(&sb, "\n\n%s", x.Name)
		if x.About != "" {
			sb.WriteString(": " + x.About)
		}
		rows = append(rows, []map[string]any{{"text": x.Name, "url": "https://t.me/" + x.Username}})
	}
	if len(rows) == 0 {
		b.sendMenu(ctx, chat, "Скоро здесь появятся боты экосистемы.")
		return
	}
	if err := b.call(ctx, "sendMessage", map[string]any{"chat_id": chat, "text": sb.String(), "reply_markup": map[string]any{"inline_keyboard": rows}}, nil); err != nil {
		log.Printf("%v", err)
	}
}
