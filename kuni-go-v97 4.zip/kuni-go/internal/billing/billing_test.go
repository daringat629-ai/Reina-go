package billing

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"
)

var t0 = time.Date(2026, 10, 30, 12, 0, 0, 0, time.UTC)
var lim = Limits{Free: 2, Plus: 5, Max: 0}

func TestFreeLimitResetsDailyAndIsToldOnce(t *testing.T) {
	s := Open(filepath.Join(t.TempDir(), "b.json"))
	for i := 0; i < 2; i++ {
		if d := s.Take(7, t0.Add(time.Duration(i)*time.Minute), lim); !d.OK || d.Plan != Free {
			t.Fatalf("conversation %d must be allowed: %+v", i, d)
		}
	}
	d := s.Take(7, t0.Add(2*time.Minute), lim)
	if d.OK || !d.TellOnce {
		t.Fatalf("over the limit, told once: %+v", d)
	}
	if d := s.Take(7, t0.Add(3*time.Minute), lim); d.OK || d.TellOnce {
		t.Fatalf("not told twice in a day: %+v", d)
	}
	if d := s.Take(7, t0.Add(24*time.Hour), lim); !d.OK || d.Left != 1 {
		t.Fatalf("a new day resets the count: %+v", d)
	}
}

func TestActivateExtendsAndIgnoresTheSameChargeTwice(t *testing.T) {
	path := filepath.Join(t.TempDir(), "b.json")
	s := Open(path)
	if _, err := s.Activate(7, "gold", 30, 1, "x", t0); err == nil {
		t.Fatal("unknown plan")
	}
	u, err := s.Activate(7, Plus, 30, 250, "c1", t0)
	if err != nil || u.Plan != Plus || !u.Until.Equal(t0.Add(30*24*time.Hour)) {
		t.Fatalf("%+v %v", u, err)
	}
	if u, _ := s.Activate(7, Plus, 30, 250, "c1", t0); !u.Until.Equal(t0.Add(30 * 24 * time.Hour)) {
		t.Fatal("the same charge must not be counted twice")
	}
	if u, _ := s.Activate(7, Plus, 30, 250, "c2", t0.Add(24*time.Hour)); !u.Until.Equal(t0.Add(60 * 24 * time.Hour)) {
		t.Fatalf("a second payment adds to what is left: %v", u.Until)
	}
	for i := 0; i < 5; i++ {
		s.Take(7, t0.Add(time.Duration(i)*time.Minute), lim)
	}
	if d := s.Take(7, t0.Add(6*time.Minute), lim); d.OK {
		t.Fatal("Plus has its own limit")
	}
	if g := Open(path).Get(7, t0.Add(61*24*time.Hour)); g.Plan != Free {
		t.Fatalf("an expired plan falls back to Start (and survives a restart): %+v", g)
	}
	if _, pays := Open(path).All(t0); len(pays) != 2 {
		t.Fatalf("payments are kept: %d", len(pays))
	}
}

func TestMaxHasNoCap(t *testing.T) {
	s := Open(filepath.Join(t.TempDir(), "b.json"))
	_, _ = s.Activate(9, Max, 30, 600, "m", t0)
	for i := 0; i < 100; i++ {
		if d := s.Take(9, t0.Add(time.Duration(i)*time.Minute), lim); !d.OK || d.Left != -1 {
			t.Fatalf("Max without a cap: %+v", d)
		}
	}
}

func fakeAPI(t *testing.T) (*httptest.Server, func(string) []map[string]any) {
	var mu sync.Mutex
	calls := map[string][]map[string]any{}
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		raw, _ := io.ReadAll(r.Body)
		var in map[string]any
		_ = json.Unmarshal(raw, &in)
		m := r.URL.Path[strings.LastIndex(r.URL.Path, "/")+1:]
		mu.Lock()
		calls[m] = append(calls[m], in)
		mu.Unlock()
		if strings.HasPrefix(r.URL.Path, "/file/") {
			w.Write([]byte("RECEIPT-IMAGE"))
			return
		}
		if m == "getFile" {
			w.Write([]byte(`{"ok":true,"result":{"file_path":"photos/1.jpg","file_size":13}}`))
			return
		}
		if m == "createInvoiceLink" {
			w.Write([]byte(`{"ok":true,"result":"https://t.me/$inv-` + in["payload"].(string) + `"}`))
			return
		}
		w.Write([]byte(`{"ok":true,"result":true}`))
	}))
	t.Cleanup(srv.Close)
	return srv, func(m string) []map[string]any { mu.Lock(); defer mu.Unlock(); return calls[m] }
}

func newBot(srv *httptest.Server, st *Store) *Bot {
	return &Bot{Token: "T", BaseURL: srv.URL, Store: st, Now: func() time.Time { return t0 }, Loc: time.UTC, Name: "OrviPayBot",
		Packs: func() []Pack {
			return []Pack{{500000, 20, 120}, {2000000, 77, 0}, {6000000, 0, 1400}}
		},
		PerConv: func() int64 { return 40000 },
		Limits:  func() Limits { return lim }, RefTokens: func() int64 { return 300000 }, Support: func() string { return "@orvi_help" }}
}

func msg(t *testing.T, s string) update {
	var u update
	if err := json.Unmarshal([]byte(s), &u); err != nil {
		t.Fatal(err)
	}
	return u
}

func TestBotSellsTokenPacksAndAppliesPayment(t *testing.T) {
	srv, calls := fakeAPI(t)
	st := Open(filepath.Join(t.TempDir(), "b.json"))
	b := newBot(srv, st)
	var paid string
	b.OnPaid = func(id int64, what string) { paid = what }
	ctx := context.Background()
	b.handle(ctx, msg(t, `{"update_id":1,"message":{"from":{"id":7},"chat":{"id":7},"text":"💳 Пополнить"}}`))
	links := calls("createInvoiceLink")
	if len(links) != 2 || links[0]["currency"] != "XTR" || links[0]["provider_token"] != "" || links[0]["payload"] != "pack:500000" {
		t.Fatalf("one Stars link per pack on sale (the 0-star one is hidden): %d %+v", len(links), links)
	}
	sent := calls("sendMessage")
	if len(sent) != 1 || !strings.Contains(sent[0]["text"].(string), "Бесплатно: 2 разговора") || !strings.Contains(sent[0]["text"].(string), "40 000 токенов") {
		t.Fatalf("the packs message tells the free conversations and the cost of one: %+v", sent)
	}
	kb := sent[0]["reply_markup"].(map[string]any)["inline_keyboard"].([]any)
	if len(kb) != 2 || !strings.Contains(fmt.Sprint(kb[0]), "500 тыс. токенов · ≈ 12 разговоров · ⭐ 20") {
		t.Fatalf("rows: %+v", kb)
	}
	b.handle(ctx, msg(t, `{"update_id":9,"message":{"from":{"id":7},"chat":{"id":7},"text":"Подписка"}}`))
	if len(calls("createInvoiceLink")) != 2 {
		t.Fatal("the old «Подписка» button still works and payment links are reused")
	}
	b.handle(ctx, msg(t, `{"update_id":2,"pre_checkout_query":{"id":"q1","currency":"XTR","total_amount":1,"invoice_payload":"pack:500000"}}`))
	b.handle(ctx, msg(t, `{"update_id":3,"pre_checkout_query":{"id":"q2","currency":"XTR","total_amount":15,"invoice_payload":"plus:1"}}`))
	b.handle(ctx, msg(t, `{"update_id":4,"pre_checkout_query":{"id":"q3","currency":"XTR","total_amount":20,"invoice_payload":"pack:500000"}}`))
	b.handle(ctx, msg(t, `{"update_id":5,"pre_checkout_query":{"id":"q4","currency":"XTR","total_amount":0,"invoice_payload":"pack:6000000"}}`))
	if a := calls("answerPreCheckoutQuery"); a[0]["ok"] != false || a[1]["ok"] != false || a[2]["ok"] != true || a[3]["ok"] != false {
		t.Fatalf("a wrong price, an old plan and a pack not on sale for Stars are refused: %+v", a)
	}
	b.handle(ctx, msg(t, `{"update_id":6,"message":{"from":{"id":7},"chat":{"id":7},"successful_payment":{"currency":"XTR","total_amount":20,"invoice_payload":"pack:500000","telegram_payment_charge_id":"ch1"}}}`))
	b.handle(ctx, msg(t, `{"update_id":7,"message":{"from":{"id":7},"chat":{"id":7},"successful_payment":{"currency":"XTR","total_amount":20,"invoice_payload":"pack:500000","telegram_payment_charge_id":"ch1"}}}`))
	if g := st.Get(7, t0); g.Tokens != 500000 || g.Paid != 1 || !strings.Contains(paid, "500 000") {
		t.Fatalf("500 000 tokens once, and the owner is told: %+v %q", g, paid)
	}
}

func TestInviteGivesBothTokensOnTheFirstPurchaseOnly(t *testing.T) {
	srv, calls := fakeAPI(t)
	st := Open(filepath.Join(t.TempDir(), "b.json"))
	b := newBot(srv, st)
	ctx := context.Background()
	b.handle(ctx, msg(t, `{"update_id":1,"message":{"from":{"id":8},"chat":{"id":8},"text":"/start ref8"}}`))
	if st.Get(8, t0).Referrer != 0 {
		t.Fatal("nobody invites themselves")
	}
	b.handle(ctx, msg(t, `{"update_id":2,"message":{"from":{"id":9},"chat":{"id":9},"text":"/start ref8"}}`))
	if st.Get(9, t0).Referrer != 8 {
		t.Fatal("the inviter is remembered")
	}
	b.handle(ctx, msg(t, `{"update_id":3,"message":{"from":{"id":9},"chat":{"id":9},"successful_payment":{"currency":"XTR","total_amount":20,"invoice_payload":"pack:500000","telegram_payment_charge_id":"a"}}}`))
	if g := st.Get(9, t0); g.Tokens != 800000 {
		t.Fatalf("the friend gets the pack + the bonus: %d", g.Tokens)
	}
	if g := st.Get(8, t0); g.Tokens != 300000 {
		t.Fatalf("the inviter gets the bonus: %+v", g)
	}
	b.handle(ctx, msg(t, `{"update_id":4,"message":{"from":{"id":9},"chat":{"id":9},"successful_payment":{"currency":"XTR","total_amount":20,"invoice_payload":"pack:500000","telegram_payment_charge_id":"b"}}}`))
	if g := st.Get(8, t0); g.Tokens != 300000 {
		t.Fatal("only the first purchase brings a bonus")
	}
	if all, paid := st.Invited(8); all != 1 || paid != 1 {
		t.Fatalf("invites counted: %d %d", all, paid)
	}
	b.handle(ctx, msg(t, `{"update_id":5,"message":{"from":{"id":8},"chat":{"id":8},"text":"🤝 Друзьям"}}`))
	sent := calls("sendMessage")
	if last := sent[len(sent)-1]["text"].(string); !strings.Contains(last, "https://t.me/OrviPayBot?start=ref8") || !strings.Contains(last, "пополнили: 1") {
		t.Fatalf("the invite card: %s", last)
	}
}

func TestProfileShowsBalanceLimitBarAndResetWithoutRankings(t *testing.T) {
	srv, calls := fakeAPI(t)
	st := Open(filepath.Join(t.TempDir(), "b.json"))
	st.Take(7, t0, lim)
	_, _ = st.AddTokens(7, 1250000, 50, 0, "x", "pack", t0)
	b := newBot(srv, st)
	b.handle(context.Background(), msg(t, `{"update_id":1,"message":{"from":{"id":7},"chat":{"id":7},"text":"👤 Профиль"}}`))
	waitCalls(t, calls, "sendMessage", 1)
	sent := calls("sendMessage")
	p := sent[0]["text"].(string)
	for _, w := range []string{"Баланс: 1 250 000 токенов (≈ 31 разговор)", "Бесплатно сегодня: 1 из 2", "▰▰▰▰▰▱▱▱▱▱ 50%", "Обновится в 00:00, 31.10", "Разговоров всего: 1", "Покупок: 1"} {
		if !strings.Contains(p, w) {
			t.Fatalf("missing %q in:\n%s", w, p)
		}
	}
	for _, w := range []string{"Топ", "%% собеседников", "рейтинг"} {
		if strings.Contains(p, w) {
			t.Fatalf("no rankings that press on people: %s", p)
		}
	}
	if !strings.Contains(fmt.Sprint(sent[0]["reply_markup"]), "hist") {
		t.Fatal("the profile has a history button")
	}
}

func TestDaysPlural(t *testing.T) {
	for n, w := range map[int]string{1: "1 день", 3: "3 дня", 7: "7 дней", 11: "11 дней", 21: "21 день", 30: "30 дней"} {
		if days(n) != w {
			t.Fatalf("%d: %q", n, days(n))
		}
	}
}

func TestProfileCardIsAPictureWithDrawnIconsAndTextFallback(t *testing.T) {
	srv, calls := fakeAPI(t)
	st := Open(filepath.Join(t.TempDir(), "b.json"))
	st.Take(7, t0, lim)
	b := newBot(srv, st)
	b.Presence = func() Presence {
		return Presence{Known: true, Asleep: true, WakeAt: t0.Add(3 * time.Hour), Mood: 70, Energy: .4}
	}
	var svg string
	b.Render = func(ctx context.Context, s string) ([]byte, error) { svg = s; return []byte("\x89PNG fake"), nil }
	b.handle(context.Background(), msg(t, `{"update_id":1,"message":{"from":{"id":7,"first_name":"Jaabir <3"},"chat":{"id":7},"text":"👤 Профиль"}}`))
	waitCalls(t, calls, "sendPhoto", 1)
	if len(calls("sendPhoto")) != 1 || len(calls("sendMessage")) != 0 {
		t.Fatalf("the profile goes as a picture: photo %d, text %d", len(calls("sendPhoto")), len(calls("sendMessage")))
	}
	for _, w := range []string{"Jaabir &lt;3", "1 из 2", "Позови друга", "Рейна спит до 15:00", "stroke-linecap=\"round\""} {
		if !strings.Contains(svg, w) {
			t.Fatalf("card is missing %q", w)
		}
	}
	for _, c := range []string{"#B4A5FF", "#6B55E6", "#FF7A8A"} {
		if strings.Contains(svg, c) {
			t.Fatalf("the card is black and white: found %s", c)
		}
	}
	b.Render = func(ctx context.Context, s string) ([]byte, error) { return nil, context.DeadlineExceeded }
	b.Now = func() time.Time { return t0.Add(time.Minute) } // not a double tap
	b.handle(context.Background(), msg(t, `{"update_id":2,"message":{"from":{"id":7},"chat":{"id":7},"text":"👤 Профиль"}}`))
	waitCalls(t, calls, "sendMessage", 1)
	if len(calls("sendMessage")) != 1 {
		t.Fatal("no renderer here: the text profile is sent instead")
	}
}

func TestMenuButtonsGetVectorIconsAndColours(t *testing.T) {
	b := &Bot{}
	kb := b.menu()["keyboard"].([][]map[string]any)
	if len(kb) != 4 || len(kb[3]) != 2 || kb[3][0]["text"] != "🤖 Боты" || kb[3][1]["text"] != "🌍 Миры" || kb[0][0]["text"] != "💳 Пополнить" || kb[0][0]["style"] != "primary" || kb[1][1]["style"] != "success" || kb[1][0]["text"] != "🌙 Рейна" {
		t.Fatalf("without icons: ordinary emoji and colours: %+v", kb)
	}
	if _, has := kb[0][1]["style"]; has {
		t.Fatal("Профиль keeps the app's own colour")
	}
	b.Icons = func() []string { return []string{"5368324170671202286", "", " 777 ", ""} }
	kb = b.menu()["keyboard"].([][]map[string]any)
	if kb[0][0]["text"] != "Пополнить" || kb[0][0]["icon_custom_emoji_id"] != "5368324170671202286" || kb[1][0]["icon_custom_emoji_id"] != "777" {
		t.Fatalf("with an icon the emoji goes away: %+v", kb)
	}
	if kb[0][1]["text"] != "👤 Профиль" || kb[2][1]["text"] != "💬 Помощь" {
		t.Fatal("an empty or missing place keeps the ordinary emoji")
	}
	for in, want := range map[string]string{"Пополнить": btnTopUp, "💳 Пополнить": btnTopUp, " Рейна ": btnReina, "💳 Подписка": btnTopUp, "💬 Поддержка": btnHelp} {
		if pressed(in) != want {
			t.Fatalf("%q must be recognised as %q, got %q", in, want, pressed(in))
		}
	}
	if pressed("подписка на канал") != "" || pressed("Рейна, привет") != "" {
		t.Fatal("ordinary text is not a button")
	}
}

func waitCalls(t *testing.T, calls func(string) []map[string]any, m string, n int) {
	t.Helper()
	for i := 0; i < 200 && len(calls(m)) < n; i++ {
		time.Sleep(10 * time.Millisecond)
	}
}

func TestDoubleTapsAndBurstsCountOnce(t *testing.T) {
	srv, calls := fakeAPI(t)
	st := Open(filepath.Join(t.TempDir(), "b.json"))
	b := newBot(srv, st)
	for i := 0; i < 10; i++ {
		b.handle(context.Background(), msg(t, `{"update_id":1,"message":{"from":{"id":7},"chat":{"id":7},"text":"🤝 Друзьям"}}`))
	}
	if n := len(calls("sendMessage")); n != 1 {
		t.Fatalf("ten taps in a row = one answer, got %d", n)
	}
	for i := 0; i < 5; i++ {
		st.Take(5, t0.Add(time.Duration(i)*3*time.Second), lim) // a burst of messages within seconds
	}
	if u := st.Get(5, t0); u.Used != 1 || u.Total != 1 {
		t.Fatalf("a burst counts as one conversation: %+v", u)
	}
	st.Take(5, t0.Add(time.Minute), lim)
	if u := st.Get(5, t0); u.Used != 2 {
		t.Fatal("a later conversation counts again")
	}
}

func TestQRPaymentGoesThroughTheOwnersAdminBot(t *testing.T) {
	srv, calls := fakeAPI(t)
	dir := t.TempDir()
	st := Open(filepath.Join(dir, "b.json"))
	pay := newBot(srv, st)
	adm := &Admin{Token: "A", BaseURL: srv.URL, Store: st, Pay: pay, QRPath: filepath.Join(dir, "qr.png"), Owner: func() int64 { return 1 }, Now: func() time.Time { return t0 }, Loc: time.UTC}
	pay.QR, pay.OnReceipt = adm.QRImage, adm.Receipt
	ctx := context.Background()
	pay.handle(ctx, msg(t, `{"update_id":1,"message":{"from":{"id":7},"chat":{"id":7},"text":"/plans"}}`))
	if strings.Contains(fmt.Sprint(calls("sendMessage")), "callback_data:qr") {
		t.Fatal("no QR saved yet: no QR button")
	}
	adm.handle(ctx, msg(t, `{"update_id":1,"message":{"from":{"id":66},"chat":{"id":66},"photo":[{"file_id":"x"}]}}`))
	if len(adm.QRImage()) != 0 {
		t.Fatal("the admin bot ignores everyone but the owner")
	}
	adm.handle(ctx, msg(t, `{"update_id":2,"message":{"from":{"id":1},"chat":{"id":1},"photo":[{"file_id":"small"},{"file_id":"big"}]}}`))
	if string(adm.QRImage()) != "RECEIPT-IMAGE" {
		t.Fatal("the owner's QR picture is saved")
	}
	pay.Now = func() time.Time { return t0.Add(time.Minute) }
	pay.handle(ctx, msg(t, `{"update_id":2,"message":{"from":{"id":7},"chat":{"id":7},"text":"/plans"}}`))
	if !strings.Contains(fmt.Sprint(calls("sendMessage")), "callback_data:qr") {
		t.Fatal("with a QR the packs get «Оплатить по QR»")
	}
	pay.handle(ctx, msg(t, `{"update_id":3,"callback_query":{"id":"c1","from":{"id":7,"first_name":"Аня"},"data":"qr:500000","message":{"chat":{"id":7}}}}`))
	r, ok := st.Waiting(7)
	if !ok || r.Som != 120 || r.Tokens != 500000 || r.Code != "R1" {
		t.Fatalf("a request with the price and a code: %+v", r)
	}
	pay.handle(ctx, msg(t, `{"update_id":4,"message":{"from":{"id":7},"chat":{"id":7},"photo":[{"file_id":"rcpt"}]}}`))
	if open := st.Open(); len(open) != 1 || open[0].Status != "sent" {
		t.Fatalf("the receipt goes to the owner: %+v", open)
	}
	if photos := calls("sendPhoto"); len(photos) != 2 {
		t.Fatalf("QR to the person + receipt to the owner: %d photos", len(photos))
	}
	adm.handle(ctx, msg(t, `{"update_id":3,"callback_query":{"id":"x","from":{"id":66},"data":"ok:1","message":{"chat":{"id":66}}}}`))
	if st.Get(7, t0).Tokens != 0 {
		t.Fatal("only the owner can confirm")
	}
	adm.handle(ctx, msg(t, `{"update_id":4,"callback_query":{"id":"y","from":{"id":1},"data":"ok:1","message":{"chat":{"id":1}}}}`))
	if u := st.Get(7, t0); u.Tokens != 500000 || u.Paid != 1 {
		t.Fatalf("✅ adds the tokens: %+v", u)
	}
	if !strings.Contains(fmt.Sprint(calls("sendMessage")), "подтверждена") {
		t.Fatal("the person is told")
	}
	adm.handle(ctx, msg(t, `{"update_id":5,"callback_query":{"id":"z","from":{"id":1},"data":"ok:1","message":{"chat":{"id":1}}}}`))
	if u := st.Get(7, t0); u.Tokens != 500000 {
		t.Fatal("a second ✅ on the same request changes nothing")
	}
	if s := st.Stats(t0, time.UTC); s.Som != 120 || s.SomToday != 120 || s.Paying != 1 || s.TokensSold != 500000 {
		t.Fatalf("stats: %+v", s)
	}
	adm.handle(ctx, msg(t, `{"update_id":6,"message":{"from":{"id":1},"chat":{"id":1},"text":"/give 9 250000"}}`))
	if u := st.Get(9, t0); u.Tokens != 250000 {
		t.Fatal("/give gifts tokens")
	}
}

func TestPricesInOtherCurrencies(t *testing.T) {
	b := &Bot{Currency: func() string { return "KGS" }, Rates: func() string { return "RUB=0.95, kzt=5.7,USD=0.0114,bad,XYZ=2,KGS=1" }}
	got := b.approx(390)
	for _, w := range []string{"≈ 370.5 ₽", "≈ 2 223 ₸", "≈ $4.45", "≈ 780 XYZ"} {
		if !strings.Contains(got, w) && !(w == "≈ 370.5 ₽" && strings.Contains(got, "≈ 371 ₽")) {
			t.Fatalf("missing %q in %q", w, got)
		}
	}
	if strings.Contains(got, "KGS") || strings.Contains(got, "bad") {
		t.Fatalf("som itself and broken entries are skipped: %q", got)
	}
	if (&Bot{}).approx(390) != "" || b.approx(0) != "" {
		t.Fatal("no rates or no price: nothing")
	}
}

func TestEndingRemindsOncePerPlanEnd(t *testing.T) {
	s := Open(filepath.Join(t.TempDir(), "b.json"))
	_, _ = s.Activate(7, Plus, 1, 15, "a", t0)
	_, _ = s.Activate(8, Plus, 30, 250, "b", t0)
	if e := s.Ending(t0.Add(2*time.Hour), 24*time.Hour); len(e) != 1 || e[0].ID != 7 {
		t.Fatalf("only the plan ending within a day: %+v", e)
	}
	if e := s.Ending(t0.Add(3*time.Hour), 24*time.Hour); len(e) != 0 {
		t.Fatal("reminded once")
	}
	_, _ = s.Activate(7, Plus, 1, 15, "c", t0.Add(4*time.Hour)) // renewed: a new end, a new reminder later
	if e := s.Ending(t0.Add(30*time.Hour), 24*time.Hour); len(e) != 1 {
		t.Fatalf("a renewed plan is reminded again: %+v", e)
	}
}

func TestTermsAndPaySupport(t *testing.T) {
	srv, calls := fakeAPI(t)
	b := newBot(srv, Open(filepath.Join(t.TempDir(), "b.json")))
	b.handle(context.Background(), msg(t, `{"update_id":1,"message":{"from":{"id":7},"chat":{"id":7},"text":"/terms"}}`))
	b.handle(context.Background(), msg(t, `{"update_id":2,"message":{"from":{"id":7},"chat":{"id":7},"text":"/paysupport"}}`))
	sent := calls("sendMessage")
	if len(sent) != 2 || !strings.Contains(sent[0]["text"].(string), "не человек") || !strings.Contains(sent[1]["text"].(string), "@orvi_help") {
		t.Fatalf("%+v", sent)
	}
}

func TestRublesAreTheMainCurrencyByDefault(t *testing.T) {
	b := &Bot{Rates: func() string { return "USD=0.01262,RUB=1" }}
	if b.Price(399) != "399 ₽" {
		t.Fatalf("rubles by default: %q", b.Price(399))
	}
	if got := b.approx(399); got != "≈ $5.04" {
		t.Fatalf("the main currency is not repeated, dollars shown: %q", got)
	}
	usd := &Bot{Currency: func() string { return "usd" }}
	if usd.Price(5) != "$5" {
		t.Fatalf("%q", usd.Price(5))
	}
	if (&Bot{Currency: func() string { return "KGS" }}).Price(390) != "390 сом" {
		t.Fatal("som still works if chosen")
	}
}

func TestNewRequestKeepsSentReceipt(t *testing.T) {
	s := Open(filepath.Join(t.TempDir(), "b.json"))
	now := time.Now()
	r1 := s.NewRequest(7, "a", 500000, 129, now)
	if _, err := s.Mark(r1.ID, "sent", now); err != nil {
		t.Fatal(err)
	}
	s.NewRequest(7, "a", 2000000, 299, now.Add(time.Minute))
	if _, _, err := s.Approve(r1.ID, now.Add(2*time.Minute)); err != nil {
		t.Fatalf("a request with a sent receipt must still be approvable: %v", err)
	}
	if u := s.Get(7, now); u.Tokens != 500000 {
		t.Fatalf("approved tokens: %+v", u)
	}
}

func TestRefundRevokesTokensOnceAndVoidsGift(t *testing.T) {
	s := Open(filepath.Join(t.TempDir(), "b.json"))
	if _, err := s.AddTokens(5, 1000, 50, 0, "ch1", "pack", t0); err != nil {
		t.Fatal(err)
	}
	if _, _, ok := s.Refund("nope", t0); ok {
		t.Fatal("unknown charge must not refund")
	}
	p, u, ok := s.Refund("ch1", t0)
	if !ok || u.Tokens != 0 || p.Tokens != 1000 || u.Paid != 0 {
		t.Fatalf("refund: %+v %+v %v", p, u, ok)
	}
	if _, _, ok := s.Refund("ch1", t0); ok {
		t.Fatal("second refund must be ignored")
	}
	s.AddTokens(6, 300, 10, 0, "ch2", "pack", t0)
	s.Take(6, t0, Limits{Free: 0})
	s.AddTokens(6, 100, 0, 0, "", "bonus", t0)
	if _, u, _ := s.Refund("ch2", t0); u.Tokens != 100 {
		t.Fatalf("balance after refund: %d", u.Tokens)
	}
	g := s.NewGift(7, 200, 20, "ch3", t0)
	if _, _, ok := s.Refund("ch3", t0); !ok {
		t.Fatal("gift refund")
	}
	if _, err := s.ClaimGift(g.Code, 8, t0); err == nil {
		t.Fatal("voided gift must not be claimable")
	}
}

func TestRefundCutsPlanDays(t *testing.T) {
	s := Open(filepath.Join(t.TempDir(), "b.json"))
	s.Activate(5, Plus, 30, 100, "c", t0)
	if _, u, ok := s.Refund("c", t0); !ok || u.Plan != Free || !u.Until.IsZero() {
		t.Fatalf("plan must be revoked: %+v", u)
	}
}

func TestGlobalFreeCap(t *testing.T) {
	s := Open(filepath.Join(t.TempDir(), "b.json"))
	l := Limits{Free: 10, GlobalFree: 2}
	if !s.Take(1, t0, l).OK || !s.Take(2, t0, l).OK {
		t.Fatal("first two must pass")
	}
	if s.Take(3, t0, l).OK {
		t.Fatal("global cap must stop the third free account")
	}
	if !s.Take(3, t0.Add(24*time.Hour), l).OK {
		t.Fatal("new day resets the cap")
	}
}

func TestUnwrappedNeverNil(t *testing.T) {
	if unwrapped(fmt.Errorf("x")) == nil {
		t.Fatal("nil")
	}
}
