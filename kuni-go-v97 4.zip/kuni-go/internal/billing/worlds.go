package billing

import (
	"context"
	"errors"
	"fmt"
	"log"
	"net"
	"regexp"
	"strconv"
	"strings"
	"time"
)

// World is a game server (a Minecraft world, for now) a person connected their bot to. Only an address and a port are stored: no
// passwords and no keys. The service that really connects must check the address again at that moment (a name can be pointed at
// a private address later).
type World struct {
	ID    int       `json:"id"`
	Owner int64     `json:"owner"` // Telegram id of the person
	Name  string    `json:"name"`
	Game  string    `json:"game"`
	Host  string    `json:"host"`
	Port  int       `json:"port"`
	Off   bool      `json:"off,omitempty"`
	Added time.Time `json:"added"`
}

const (
	maxWorldsPerUser = 3
	maxWorlds        = 500
)

var hostName = regexp.MustCompile(`^[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?(\.[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?)+$`)

// CheckWorldAddr refuses what must never be reachable from our side: this machine, a home or office network, link-local and cloud metadata addresses.
func CheckWorldAddr(host string, port int) error {
	host = strings.ToLower(strings.TrimSpace(host))
	if port < 1024 || port > 65535 {
		return errors.New("порт: от 1024 до 65535")
	}
	if ip := net.ParseIP(host); ip != nil {
		if ip.IsLoopback() || ip.IsPrivate() || ip.IsUnspecified() || ip.IsLinkLocalUnicast() || ip.IsLinkLocalMulticast() || ip.IsMulticast() {
			return errors.New("этот адрес закрыт: нужен публичный адрес сервера")
		}
		return nil
	}
	if len(host) > 253 || !hostName.MatchString(host) {
		return errors.New("адрес: имя сервера вида play.example.com или публичный IP")
	}
	for _, bad := range []string{".local", ".internal", ".localhost", ".lan", ".home", ".corp"} {
		if strings.HasSuffix(host, bad) {
			return errors.New("этот адрес закрыт: нужен публичный адрес сервера")
		}
	}
	return nil
}

// AddWorld saves a world for a person.
func (s *Store) AddWorld(owner int64, name, host string, port int, now time.Time) (World, error) {
	name = strings.TrimSpace(name)
	if name == "" {
		name = "Мой мир"
	}
	if len([]rune(name)) > 40 {
		return World{}, errors.New("название: до 40 символов")
	}
	host = strings.ToLower(strings.TrimSpace(host))
	if err := CheckWorldAddr(host, port); err != nil {
		return World{}, err
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	n, next := 0, 1
	for _, w := range s.d.Worlds {
		if w.Owner == owner {
			n++
			if w.Host == host && w.Port == port {
				return World{}, errors.New("этот мир уже добавлен")
			}
		}
		if w.ID >= next {
			next = w.ID + 1
		}
	}
	if n >= maxWorldsPerUser {
		return World{}, fmt.Errorf("можно держать до %d миров: удали лишний командой /delworld номер", maxWorldsPerUser)
	}
	if len(s.d.Worlds) >= maxWorlds {
		return World{}, errors.New("сейчас все места заняты, попробуй позже")
	}
	w := World{ID: next, Owner: owner, Name: name, Game: "minecraft", Host: host, Port: port, Added: now}
	s.d.Worlds = append(s.d.Worlds, w)
	s.save()
	return w, nil
}

// WorldsOf lists a person's worlds.
func (s *Store) WorldsOf(owner int64) []World {
	s.mu.Lock()
	defer s.mu.Unlock()
	var out []World
	for _, w := range s.d.Worlds {
		if w.Owner == owner {
			out = append(out, w)
		}
	}
	return out
}

// DelWorld removes a person's own world (nobody can remove someone else's).
func (s *Store) DelWorld(owner int64, id int) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	for i, w := range s.d.Worlds {
		if w.ID == id && w.Owner == owner {
			s.d.Worlds = append(s.d.Worlds[:i], s.d.Worlds[i+1:]...)
			s.save()
			return true
		}
	}
	return false
}

// ParseWorld reads "host:port Name" (port 25565 when left out).
func ParseWorld(args string) (host string, port int, name string, err error) {
	f := strings.Fields(args)
	if len(f) == 0 {
		return "", 0, "", errors.New("формат: /addworld адрес:порт Название\nнапример: /addworld play.example.com:25565 Моя база")
	}
	addr := f[0]
	port = 25565
	if h, p, e := net.SplitHostPort(addr); e == nil {
		n, e2 := strconv.Atoi(p)
		if e2 != nil {
			return "", 0, "", errors.New("порт должен быть числом")
		}
		addr, port = h, n
	} else if strings.Count(addr, ":") == 1 {
		return "", 0, "", errors.New("формат адреса: имя:порт")
	}
	return addr, port, strings.Join(f[1:], " "), nil
}

func (b *Bot) worldsText(user int64) string {
	ws := b.Store.WorldsOf(user)
	var sb strings.Builder
	sb.WriteString("🌍 Твои миры\n\n")
	if len(ws) == 0 {
		sb.WriteString("Пока ни одного.\n")
	}
	for _, w := range ws {
		fmt.Fprintf(&sb, "%d. %s · Minecraft · %s:%d\n", w.ID, w.Name, w.Host, w.Port)
	}
	sb.WriteString("\nПодключить бота к своему серверу:\n/addworld адрес:порт Название\nУдалить: /delworld номер\n\nНужен открытый публичный адрес. Пароли и ключи сюда не присылай, они не нужны.")
	return sb.String()
}

func (b *Bot) addWorld(user int64, args string) string {
	host, port, name, err := ParseWorld(args)
	if err != nil {
		return err.Error()
	}
	w, err := b.Store.AddWorld(user, name, host, port, b.now())
	if err != nil {
		return err.Error()
	}
	return fmt.Sprintf("Готово: мир «%s» (%s:%d) добавлен под номером %d.", w.Name, w.Host, w.Port, w.ID)
}

func (b *Bot) delWorld(user int64, args string) string {
	id, err := strconv.Atoi(strings.TrimSpace(args))
	if err != nil || !b.Store.DelWorld(user, id) {
		return "Не нашёл такой мир. Номера смотри в разделе «Миры»."
	}
	return "Мир удалён."
}

// TakeTokens takes a fixed number of tokens from the balance (a visit to a world), or says there are not enough.
func (s *Store) TakeTokens(id, n int64) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	u := s.d.Users[id]
	if u == nil || u.Tokens < n {
		return errors.New("not enough tokens")
	}
	u.Tokens -= n
	u.Spent += n
	s.save()
	return nil
}

// GiveBackTokens returns what TakeTokens took (the visit did not start).
func (s *Store) GiveBackTokens(id, n int64) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if u := s.d.Users[id]; u != nil {
		u.Tokens += n
		u.Spent -= n
		s.save()
	}
}

// worlds shows a person's worlds with a button to send her in (or take her out).
func (b *Bot) worlds(ctx context.Context, chat, user int64) {
	text := b.worldsText(user)
	var rows [][]map[string]any
	if b.WorldStart != nil {
		for _, w := range b.Store.WorldsOf(user) {
			if b.WorldRunning != nil && b.WorldRunning(w.ID) {
				rows = append(rows, []map[string]any{{"text": "⏹ Отключить: " + w.Name, "callback_data": fmt.Sprintf("wl:%d", w.ID)}})
			} else {
				rows = append(rows, []map[string]any{{"text": "▶️ Рейна в «" + w.Name + "»", "callback_data": fmt.Sprintf("wj:%d", w.ID)}})
			}
		}
		if fee := b.worldFee(); fee > 0 && len(rows) > 0 {
			text += fmt.Sprintf("\n\nОдин визит Рейны стоит %s токенов с баланса.", tokensWord(fee))
		}
	}
	msg := map[string]any{"chat_id": chat, "text": text}
	if len(rows) > 0 {
		msg["reply_markup"] = map[string]any{"inline_keyboard": rows}
	} else {
		msg["reply_markup"] = b.menu()
	}
	if err := b.call(ctx, "sendMessage", msg, nil); err != nil {
		log.Printf("%v", err)
	}
}

func (b *Bot) worldFee() int64 {
	if b.WorldFee != nil {
		return max(b.WorldFee(), 0)
	}
	return 0
}

// worldButton handles "wj:id" (send her in) and "wl:id" (take her out). Only the owner of a world can touch it.
func (b *Bot) worldButton(ctx context.Context, chat, user int64, data string) {
	id, err := strconv.Atoi(data[3:])
	var w World
	found := false
	for _, x := range b.Store.WorldsOf(user) {
		if x.ID == id {
			w, found = x, true
		}
	}
	if err != nil || !found || b.WorldStart == nil {
		b.sendMenu(ctx, chat, "Не нашёл такой мир.")
		return
	}
	if data[:3] == "wl:" {
		if b.WorldStop != nil {
			b.WorldStop(id)
		}
		b.sendMenu(ctx, chat, "Рейна выходит из мира «"+w.Name+"».")
		return
	}
	if b.WorldRunning != nil && b.WorldRunning(id) {
		b.sendMenu(ctx, chat, "Рейна уже там.")
		return
	}
	fee := b.worldFee()
	if fee > 0 {
		if err := b.Store.TakeTokens(user, fee); err != nil {
			b.sendMenu(ctx, chat, fmt.Sprintf("Не хватает токенов: визит стоит %s. Пополнить можно в разделе «Пополнить».", tokensWord(fee)))
			return
		}
	}
	if err := b.WorldStart(w); err != nil {
		if fee > 0 {
			b.Store.GiveBackTokens(user, fee)
		}
		b.sendMenu(ctx, chat, "Не получилось зайти: "+err.Error()+". Токены вернул.")
		return
	}
	b.sendMenu(ctx, chat, "Рейна заходит в «"+w.Name+"». Позови её в чате игры по имени.")
}
