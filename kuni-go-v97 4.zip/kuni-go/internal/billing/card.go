package billing

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"html"
	"io"
	"log"
	"mime/multipart"
	"net/http"
	"strings"
	"time"
)

// Icons are drawn as lines on a 24×24 grid (stroke only, no fill), so the cards look the same on every machine, with no emoji font.
var icons = map[string]string{
	"coins":    `<ellipse cx="12" cy="6" rx="7" ry="3"/><path d="M5 6v6c0 1.7 3.1 3 7 3s7-1.3 7-3V6"/><path d="M5 12v6c0 1.7 3.1 3 7 3s7-1.3 7-3v-6"/>`,
	"chat":     `<path d="M4 5h16v11H9l-5 4z"/><path d="M8 9h8M8 12h5"/>`,
	"clock":    `<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>`,
	"star":     `<path d="M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8-5.2-2.8-5.2 2.8 1-5.8-4.3-4.1 5.9-.9z"/>`,
	"calendar": `<rect x="4" y="5.5" width="16" height="14" rx="2"/><path d="M4 10h16M8.5 3.5v4M15.5 3.5v4"/>`,
	"moon":     `<path d="M19 14.5A7.5 7.5 0 1 1 9.5 5a6 6 0 0 0 9.5 9.5z"/>`,
	"bolt":     `<path d="M13 3L5 13.5h6L10 21l8-10.5h-6z"/>`,
	"heart":    `<path d="M12 19.5s-7.5-4.6-7.5-10A4.2 4.2 0 0 1 12 7a4.2 4.2 0 0 1 7.5 2.5c0 5.4-7.5 10-7.5 10z"/>`,
	"pin":      `<path d="M12 21s6.5-6.2 6.5-11.2a6.5 6.5 0 0 0-13 0C5.5 14.8 12 21 12 21z"/><circle cx="12" cy="9.8" r="2.3"/>`,
	"gift":     `<rect x="4" y="9" width="16" height="11" rx="1.5"/><path d="M3 9h18M12 9v11M12 9c-1.5-3.5-5.5-4-5.5-1.5S10 9 12 9zM12 9c1.5-3.5 5.5-4 5.5-1.5S14 9 12 9z"/>`,
	"spark":    `<path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5L18 18M6 18l2.5-2.5M15.5 8.5L18 6"/>`,
}

// icon places one icon at x,y with the given size and colour.
func icon(name string, x, y, size float64, color string) string {
	return fmt.Sprintf(`<g transform="translate(%.1f %.1f) scale(%.3f)" fill="none" stroke="%s" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">%s</g>`, x, y, size/24, color, icons[name])
}

// The cards are black and white, like the site: one light, no colour.
const (
	cBg, cBg2, cFg, cMuted, cLine, cDim = "#0B0B0B", "#151515", "#F2F2F2", "#9A9A9A", "#2A2A2A", "#5A5A5A"
)

func cardFrame(s *strings.Builder, label, date string) {
	fmt.Fprintf(s, `<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="620" viewBox="0 0 1000 620">
<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="%s"/><stop offset="1" stop-color="%s"/></linearGradient>
<radialGradient id="glow" cx=".88" cy=".05" r=".65"><stop offset="0" stop-color="#FFFFFF" stop-opacity=".09"/><stop offset="1" stop-color="#FFFFFF" stop-opacity="0"/></radialGradient>
<clipPath id="c"><rect width="1000" height="620"/></clipPath></defs>
<rect width="1000" height="620" fill="url(#g)"/><rect width="1000" height="620" fill="url(#glow)"/>
<rect x="1" y="1" width="998" height="618" fill="none" stroke="%s"/>
<g clip-path="url(#c)" font-family="Inter, 'DejaVu Sans', sans-serif" fill="%s">
<text x="56" y="70" font-size="17" letter-spacing="3.5" fill="%s">%s</text>
<text x="944" y="70" font-size="17" text-anchor="end" fill="%s">%s</text>`, cBg2, cBg, cLine, cFg, cMuted, label, cMuted, date)
}

// stat draws an icon with a big value and a small caption under it.
func stat(s *strings.Builder, x, y int, ic, value, caption string) {
	s.WriteString(icon(ic, float64(x), float64(y-30), 30, cFg))
	fmt.Fprintf(s, `<text x="%d" y="%d" font-size="38" font-weight="700">%s</text><text x="%d" y="%d" font-size="17" fill="%s">%s</text>`,
		x+44, y, html.EscapeString(value), x+44, y+30, cMuted, html.EscapeString(caption))
}

// cardSVG draws the profile card: the balance, today's free conversations as a bar with the reset time, plain numbers, Reina's
// status in one line and the invite strip. Like the text profile, it has no rankings and no streaks.
func (b *Bot) cardSVG(id int64, name string) string {
	now := b.now().In(b.loc())
	u := b.Store.Get(id, now)
	limit := b.Limits().of(u.Plan)
	used := 0
	if u.Day == now.Format("2006-01-02") {
		used = u.Used
	}
	if strings.TrimSpace(name) == "" {
		name = "Профиль"
	}
	if r := []rune(name); len(r) > 22 {
		name = string(r[:22]) + "…"
	}
	e := html.EscapeString
	frac, today := 0.0, fmt.Sprintf("%d", used)
	if limit > 0 {
		frac = min(float64(used)/float64(limit), 1)
		today = fmt.Sprintf("%d из %d", used, limit)
	}
	reset := time.Date(now.Year(), now.Month(), now.Day()+1, 0, 0, 0, 0, b.loc()).Format("02.01 в 00:00")
	var s strings.Builder
	cardFrame(&s, "ORVI · ПРОФИЛЬ", now.Format("02.01.2006"))
	fmt.Fprintf(&s, `<text x="56" y="142" font-size="50" font-weight="700">%s</text>`, e(name))
	// balance
	s.WriteString(icon("coins", 56, 168, 34, cFg))
	fmt.Fprintf(&s, `<text x="104" y="196" font-size="30" font-weight="700">%s</text><text x="104" y="226" font-size="18" fill="%s">%s на балансе · не сгорают</text>`,
		e(tokensWord(max(u.Tokens, 0))), cMuted, e(b.convs(u.Tokens)))
	plan := "бесплатно сегодня"
	if u.Plan != Free {
		plan = title(u.Plan) + " до " + u.Until.In(b.loc()).Format("02.01") + " · сегодня"
	}
	s.WriteString(icon("chat", 56, 262, 26, cMuted))
	fmt.Fprintf(&s, `<text x="94" y="284" font-size="17" letter-spacing="2" fill="%s">%s</text>
<text x="944" y="284" font-size="22" text-anchor="end">%s</text>
<rect x="56" y="302" width="888" height="12" rx="6" fill="%s"/><rect x="56" y="302" width="%.0f" height="12" rx="6" fill="%s"/>`,
		cMuted, e(strings.ToUpper(plan)), e(today), cLine, 888*frac, cFg)
	s.WriteString(icon("clock", 56, 326, 20, cMuted))
	fmt.Fprintf(&s, `<text x="84" y="342" font-size="17" fill="%s">%s</text>`, cMuted, e(map[bool]string{true: "без лимита", false: "обновится " + reset}[limit <= 0]))
	// numbers
	joined := "—"
	if !u.Joined.IsZero() {
		joined = u.Joined.In(b.loc()).Format("02.01.2006")
	}
	stat(&s, 56, 432, "spark", fmt.Sprint(u.Total), "разговоров всего")
	stat(&s, 370, 432, "calendar", joined, "с нами с")
	stat(&s, 684, 432, "star", fmt.Sprint(u.Paid), "покупок")
	// the strip at the bottom: Reina right now, and the invite
	p := b.presence()
	fmt.Fprintf(&s, `<rect x="0" y="512" width="1000" height="108" fill="%s"/><line x1="0" y1="512" x2="1000" y2="512" stroke="%s"/>`, cBg2, cLine)
	dot := map[string]string{"online": cFg, "asleep": cDim, "away": cDim}[p.State()]
	if p.State() == "asleep" {
		s.WriteString(icon("moon", 56, 546, 26, cFg))
	} else {
		fmt.Fprintf(&s, `<circle cx="69" cy="559" r="9" fill="%s"/>`, dot)
		if p.Online {
			fmt.Fprintf(&s, `<circle cx="69" cy="559" r="15" fill="none" stroke="%s" stroke-opacity=".35"/>`, cFg)
		}
	}
	fmt.Fprintf(&s, `<text x="98" y="567" font-size="22" font-weight="700">Рейна %s</text>`, e(p.Headline(b.now(), b.loc())))
	if bonus := b.refTokens(); bonus > 0 {
		s.WriteString(icon("gift", 600, 543, 28, cMuted))
		fmt.Fprintf(&s, `<text x="640" y="556" font-size="17" fill="%s">Позови друга:</text><text x="640" y="580" font-size="17" fill="%s">вам обоим +%s токенов</text>`, cFg, cMuted, e(Short(bonus)))
	}
	s.WriteString(`</g></svg>`)
	return s.String()
}

// statusSVG draws Reina's status card: the state in big letters and what she is like right now.
func (b *Bot) statusSVG() string {
	p := b.presence()
	now := b.now()
	e := html.EscapeString
	var s strings.Builder
	cardFrame(&s, "ORVI · РЕЙНА СЕЙЧАС", now.In(b.loc()).Format("15:04 · 02.01"))
	switch p.State() {
	case "asleep":
		s.WriteString(icon("moon", 56, 104, 56, cFg))
	default:
		fill := cDim
		if p.Online {
			fill = cFg
			fmt.Fprintf(&s, `<circle cx="84" cy="132" r="30" fill="none" stroke="%s" stroke-opacity=".25"/><circle cx="84" cy="132" r="42" fill="none" stroke="%s" stroke-opacity=".12"/>`, cFg, cFg)
		}
		fmt.Fprintf(&s, `<circle cx="84" cy="132" r="18" fill="%s"/>`, fill)
	}
	fmt.Fprintf(&s, `<text x="140" y="126" font-size="26" fill="%s">Рейна</text><text x="140" y="170" font-size="46" font-weight="700">%s</text>`, cMuted, e(p.Headline(now, b.loc())))
	rows := [][3]string{}
	if p.Doing != "" {
		rows = append(rows, [3]string{"pin", "Сейчас", p.Doing})
	}
	if w := p.MoodWord(); w != "" {
		rows = append(rows, [3]string{"heart", "Настроение", w})
	}
	if w := p.EnergyWord(); w != "" {
		rows = append(rows, [3]string{"bolt", "Силы", w})
	}
	if p.Asleep && !p.WakeAt.IsZero() {
		rows = append(rows, [3]string{"clock", "Проснётся", "около " + p.WakeAt.In(b.loc()).Format("15:04")})
	} else if !p.Online && !p.LastSeen.IsZero() {
		rows = append(rows, [3]string{"clock", "Была в сети", p.LastSeen.In(b.loc()).Format("15:04, 02.01")})
	}
	if !p.Known {
		rows = append(rows, [3]string{"spark", "Статус", "пока неизвестен"})
	}
	for i, r := range rows {
		y := 250 + i*68
		s.WriteString(icon(r[0], 56, float64(y-24), 30, cFg))
		fmt.Fprintf(&s, `<text x="104" y="%d" font-size="19" fill="%s">%s</text><text x="944" y="%d" font-size="26" text-anchor="end">%s</text><line x1="104" y1="%d" x2="944" y2="%d" stroke="%s"/>`,
			y, cMuted, e(r[1]), y, e(r[2]), y+22, y+22, cLine)
	}
	if p.Energy >= 0 && p.Known {
		y := 250 + len(rows)*68 - 6
		if y < 560 {
			fmt.Fprintf(&s, `<rect x="104" y="%d" width="840" height="8" rx="4" fill="%s"/><rect x="104" y="%d" width="%.0f" height="8" rx="4" fill="%s"/>`, y, cLine, y, 840*min(max(p.Energy, 0), 1), cFg)
		}
	}
	note := "Сообщение можно отправить в любое время."
	if p.Asleep || p.Night {
		note = "У неё ночь: ответ будет сонным и коротким."
	}
	fmt.Fprintf(&s, `<text x="56" y="586" font-size="18" fill="%s">%s</text>`, cMuted, e(note))
	s.WriteString(`</g></svg>`)
	return s.String()
}

func (b *Bot) render(ctx context.Context, svg string) ([]byte, error) {
	if b.Render == nil {
		return nil, fmt.Errorf("no renderer")
	}
	rctx, cancel := context.WithTimeout(ctx, 12*time.Second) // a slow machine must not leave the person without an answer
	defer cancel()
	return b.Render(rctx, svg)
}

// sendCard sends the profile as a picture with buttons for the history and topping up; without a renderer, the text profile.
func (b *Bot) sendCard(ctx context.Context, chat, id int64, name string) {
	kb := map[string]any{"inline_keyboard": [][]map[string]any{{{"text": "📜 История", "callback_data": "hist"}, {"text": "💳 Пополнить", "callback_data": "topup"}}}}
	if b.Render != nil {
		png, err := b.render(ctx, b.cardSVG(id, name))
		if err == nil && len(png) > 0 {
			if err = b.sendPhotoMarkup(ctx, chat, png, "", kb); err == nil {
				return
			}
		}
		log.Printf("billing bot: profile picture: %v (sending text)", err)
	}
	if err := b.call(ctx, "sendMessage", map[string]any{"chat_id": chat, "text": b.profile(id), "reply_markup": kb}, nil); err != nil {
		log.Printf("%v", err)
	}
}

// sendStatus sends Reina's status card with the "tell me when she is online" button; without a renderer, the text.
func (b *Bot) sendStatus(ctx context.Context, chat, id int64) {
	kb := b.watchKeyboard(id)
	if b.Render != nil {
		png, err := b.render(ctx, b.statusSVG())
		if err == nil && len(png) > 0 {
			if err = b.sendPhotoMarkup(ctx, chat, png, "", kb); err == nil {
				return
			}
		}
		log.Printf("billing bot: status picture: %v (sending text)", err)
	}
	if err := b.call(ctx, "sendMessage", map[string]any{"chat_id": chat, "text": b.presence().Text(b.now(), b.loc()), "reply_markup": kb}, nil); err != nil {
		log.Printf("%v", err)
	}
}

func (b *Bot) sendPhoto(ctx context.Context, chat int64, png []byte, caption string) error {
	return b.sendPhotoMarkup(ctx, chat, png, caption, b.menu())
}

func (b *Bot) sendPhotoMarkup(ctx context.Context, chat int64, png []byte, caption string, markup any) error {
	var body bytes.Buffer
	w := multipart.NewWriter(&body)
	_ = w.WriteField("chat_id", fmt.Sprint(chat))
	if caption != "" {
		_ = w.WriteField("caption", caption)
	}
	if markup != nil {
		kb, _ := json.Marshal(markup)
		_ = w.WriteField("reply_markup", string(kb))
	}
	fw, _ := w.CreateFormFile("photo", "profile.png")
	_, _ = fw.Write(png)
	_ = w.Close()
	base := b.BaseURL
	if base == "" {
		base = "https://api.telegram.org"
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, base+"/bot"+b.tok()+"/sendPhoto", &body)
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", w.FormDataContentType())
	hc := b.HTTP
	if hc == nil {
		hc = &http.Client{Timeout: 70 * time.Second}
	}
	resp, err := hc.Do(req)
	if err != nil {
		return fmt.Errorf("sendPhoto failed") // the URL holds the token: never log it
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(resp.Body)
	var r struct {
		OK          bool   `json:"ok"`
		Description string `json:"description"`
	}
	if json.Unmarshal(raw, &r) != nil || !r.OK {
		return fmt.Errorf("sendPhoto: %s", r.Description)
	}
	return nil
}
