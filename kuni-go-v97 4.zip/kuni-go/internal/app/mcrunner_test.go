package app

import (
	"context"
	"os/exec"
	"testing"
	"time"

	"kuni/internal/billing"
	"kuni/internal/config"
)

func TestMCRunnerLimitsAndStop(t *testing.T) {
	c := &config.Config{MCEnabled: true, MCMax: 1, MCMinutes: 1}
	r := newMCRunner(func() *config.Config { return c })
	r.command = func(ctx context.Context, w billing.World, c *config.Config) *exec.Cmd {
		return exec.CommandContext(ctx, "sleep", "30")
	}
	w1 := billing.World{ID: 1, Host: "play.example.com", Port: 25565}
	if err := r.Start(w1); err != nil || !r.Running(1) {
		t.Fatalf("start: %v", err)
	}
	if r.Start(w1) == nil {
		t.Fatal("twice in the same world")
	}
	if r.Start(billing.World{ID: 2, Host: "b.example.com", Port: 25565}) == nil {
		t.Fatal("cap of visits")
	}
	if r.Start(billing.World{ID: 3, Host: "127.0.0.1", Port: 25565}) == nil {
		t.Fatal("closed address")
	}
	r.Stop(1)
	for i := 0; i < 50 && r.Running(1); i++ {
		time.Sleep(50 * time.Millisecond)
	}
	if r.Running(1) {
		t.Fatal("did not stop")
	}
	c.MCEnabled = false
	if r.Start(w1) == nil {
		t.Fatal("feature off")
	}
}
