package app

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"
	"os/exec"
	"strings"
	"sync"
	"time"

	"kuni/internal/billing"
	"kuni/internal/config"
)

// mcRunner sends her into people's Minecraft servers: one node process (tools/mcbot) per visit, with a time limit and a cap on how many
// run at once. The process gets only the settings it needs, not our environment, so no key of ours can leak through it.
type mcRunner struct {
	cfg func() *config.Config

	mu      sync.Mutex
	running map[int]context.CancelFunc

	// command builds the process; tests replace it.
	command func(ctx context.Context, w billing.World, c *config.Config) *exec.Cmd
}

func newMCRunner(cfg func() *config.Config) *mcRunner {
	r := &mcRunner{cfg: cfg, running: map[int]context.CancelFunc{}}
	r.command = realMCCommand
	return r
}

func realMCCommand(ctx context.Context, w billing.World, c *config.Config) *exec.Cmd {
	node, err := exec.LookPath("node")
	if err != nil {
		node = "node"
	}
	cmd := exec.CommandContext(ctx, node, c.MCScript)
	cmd.Env = []string{
		"PATH=" + os.Getenv("PATH"),
		"MC_HOST=" + w.Host, fmt.Sprintf("MC_PORT=%d", w.Port), "MC_VERSION=" + c.MCVersion,
		"MC_USER=" + c.MCName, "BOT_NAME=" + c.MCName, "MC_AUTH=offline",
		"LLM_URL=" + strings.TrimRight(c.LLMBaseURL, "/") + "/chat/completions", "LLM_KEY=" + c.LLMAPIKey, "LLM_MODEL=" + c.LLMModel,
		fmt.Sprintf("MAX_MINUTES=%d", c.MCMinutes),
	}
	return cmd
}

// Running says whether she is in this world now.
func (r *mcRunner) Running(id int) bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	_, ok := r.running[id]
	return ok
}

// Start sends her in. It fails at once when the feature is off, the address is closed or too many visits are going.
func (r *mcRunner) Start(w billing.World) error {
	c := r.cfg()
	if !c.MCEnabled {
		return errors.New("эта функция пока выключена")
	}
	if err := billing.CheckWorldAddr(w.Host, w.Port); err != nil {
		return err
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	if _, ok := r.running[w.ID]; ok {
		return errors.New("она уже там")
	}
	if len(r.running) >= max(c.MCMax, 1) {
		return errors.New("сейчас все места заняты, попробуй чуть позже")
	}
	limit := time.Duration(max(c.MCMinutes, 1)+1) * time.Minute
	ctx, cancel := context.WithTimeout(context.Background(), limit)
	cmd := r.command(ctx, w, c)
	if err := cmd.Start(); err != nil {
		cancel()
		log.Printf("minecraft: start failed: %v", err)
		return errors.New("коннектор не запустился")
	}
	r.running[w.ID] = cancel
	go func() {
		err := cmd.Wait()
		cancel()
		r.mu.Lock()
		delete(r.running, w.ID)
		r.mu.Unlock()
		log.Printf("minecraft: visit %d ended (%v)", w.ID, err)
	}()
	return nil
}

// Stop takes her out.
func (r *mcRunner) Stop(id int) {
	r.mu.Lock()
	cancel := r.running[id]
	r.mu.Unlock()
	if cancel != nil {
		cancel()
	}
}
