'use strict';
// A small Minecraft (Java) client for Reina and other characters: joins a server by address and port, hears the chat and answers in it.
// It never runs code a model wrote and never builds or digs on its own: only chat. Keys come from the environment, never from files in the repo.
const mineflayer = require('mineflayer');
const { resolvePublic, splitChat, shouldReply } = require('./lib');

const env = process.env;
const cfg = {
  host: env.MC_HOST, port: parseInt(env.MC_PORT || '25565', 10), version: env.MC_VERSION || '1.16.5',
  username: env.MC_USER || 'Reina', auth: env.MC_AUTH || 'offline', name: env.BOT_NAME || env.MC_USER || 'Reina',
  llmURL: env.LLM_URL, llmKey: env.LLM_KEY, model: env.LLM_MODEL,
  persona: env.PERSONA || 'Ты ИИ-персонаж, которого игроки видят в чате Minecraft. Ты не человек и честно говоришь об этом, если спросят. Отвечай коротко, по-дружески, одной-двумя фразами.',
  allowLocal: env.MC_ALLOW_LOCAL === '1', // only for a hand-started test on your own machine, never set by a service
  maxMinutes: parseInt(env.MAX_MINUTES || '120', 10),
};

function log(...a) { console.log(new Date().toISOString(), ...a); }

async function ask(history, context) {
  const r = await fetch(cfg.llmURL, {
    method: 'POST',
    headers: { 'content-type': 'application/json', authorization: 'Bearer ' + cfg.llmKey },
    body: JSON.stringify({ model: cfg.model, max_tokens: 150, messages: [{ role: 'system', content: cfg.persona + '\n\n' + context }, ...history] }),
    signal: AbortSignal.timeout(20000),
  });
  if (!r.ok) throw new Error('llm http ' + r.status);
  const j = await r.json();
  return j.choices?.[0]?.message?.content || '';
}

async function main() {
  for (const k of ['host', 'llmURL', 'llmKey', 'model']) if (!cfg[k]) { log('missing setting:', k); process.exit(2); }
  const ip = await resolvePublic(cfg.host, cfg.port, cfg.allowLocal); // checked again on every connect
  if (cfg.allowLocal) log('WARNING: MC_ALLOW_LOCAL=1, closed addresses are allowed');
  log('connecting', cfg.host + ':' + cfg.port, 'version', cfg.version);
  const bot = mineflayer.createBot({ host: ip, port: cfg.port, version: cfg.version, username: cfg.username, auth: cfg.auth });
  const history = [];
  let last = 0, busy = false;
  const stop = (why) => { log('stop:', why); try { bot.quit(); } catch {} setTimeout(() => process.exit(0), 500); };
  setTimeout(() => stop('time limit'), cfg.maxMinutes * 60000);
  process.on('SIGTERM', () => stop('SIGTERM'));
  bot.once('spawn', () => { log('in the world'); bot.chat('Привет! Я ИИ-персонаж. Позови меня по имени.'); });
  bot.on('kicked', (r) => log('kicked'));
  bot.on('error', (e) => log('error', e.code || e.message));
  bot.on('end', () => { log('disconnected'); process.exit(0); });
  bot.on('chat', async (from, text) => {
    if (busy || !shouldReply(cfg.name, from, text, last, Date.now())) return;
    busy = true; last = Date.now();
    try {
      history.push({ role: 'user', content: from + ': ' + text.slice(0, 300) });
      while (history.length > 16) history.shift();
      const near = Object.keys(bot.players).filter((n) => n !== bot.username).slice(0, 8).join(', ') || 'никого';
      const ctx = `Сейчас в мире: ${near}. Здоровье ${Math.round(bot.health ?? 20)}/20. Время суток: ${bot.time?.isDay ? 'день' : 'ночь'}.`;
      const reply = await ask(history, ctx);
      history.push({ role: 'assistant', content: reply });
      for (const part of splitChat(reply)) { bot.chat(part); await new Promise((r) => setTimeout(r, 1200)); }
    } catch (e) { log('reply failed:', e.message); }
    busy = false;
  });
}
main().catch((e) => { log('fatal:', e.message); process.exit(1); });
