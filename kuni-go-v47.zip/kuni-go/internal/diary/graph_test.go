package diary

import (
	"context"
	"encoding/json"
	"sync"
	"testing"
	"time"

	"kuni/internal/llm"
)

func TestOldMetaStillReads(t *testing.T) {
	var m Metadata
	if err := json.Unmarshal([]byte(`{"confidence":0.4}`), &m); err != nil || m.People != nil || m.Links != nil || m.Confidence != .4 {
		t.Fatalf("old meta: %+v %v", m, err)
	}
	b, _ := json.Marshal(Metadata{Confidence: .1})
	if string(b) != `{"confidence":0.1}` {
		t.Fatalf("empty graph fields must not be written: %s", b)
	}
}

func TestGraphRankBoostsPersonAndPullsLinks(t *testing.T) {
	mk := func(id string, people []int64, links []string) Entry {
		return Entry{ID: id, Body: id, Meta: Metadata{People: people, Links: links}}
	}
	es := []Entry{mk("a", nil, nil), mk("b", []int64{7}, []string{"c"}), mk("c", nil, nil)}
	rel := []Related{{Entry: es[0], Relevance: .60}, {Entry: es[1], Relevance: .55}}
	out := graphRank(rel, es, 3, 7)
	if len(out) != 3 || out[0].Entry.ID != "b" {
		t.Fatalf("person boost/ordering wrong: %+v", out)
	}
	if out[1].Entry.ID != "c" || out[1].Relevance >= out[0].Relevance { // b boosted to .67, c pulled in at .67-.05
		t.Fatalf("linked page must follow its source: %+v", out)
	}
	out = graphRank([]Related{{Entry: es[0], Relevance: .60}, {Entry: es[1], Relevance: .55}}, es, 3, 0)
	if out[0].Entry.ID != "a" {
		t.Fatalf("no person, no boost: %+v", out)
	}
	if got := graphRank([]Related{{Entry: es[0], Relevance: .6}, {Entry: es[1], Relevance: .5}}, es, 2, 0); len(got) != 2 {
		t.Fatalf("n must cap the result: %d", len(got))
	}
}

func TestRecallAboutAndSavesAreRaceFree(t *testing.T) {
	srv := fakeLLM(t, "")
	defer srv.Close()
	c := llm.New(srv.URL+"/", srv.URL+"/", "", "m", "e", 5*time.Second)
	d, err := New(t.TempDir(), c, 0, 1000)
	if err != nil {
		t.Fatal(err)
	}
	var wg sync.WaitGroup
	for w := 0; w < 4; w++ {
		wg.Add(2)
		go func(w int) {
			defer wg.Done()
			for i := 0; i < 8; i++ {
				e := Entry{ID: d.NewID(), Body: "страница", Meta: Metadata{Embedding: []float64{1, float64(i % 3)}, People: []int64{int64(w)}}}
				e.Meta.Links = []string{"x"}
				if err := d.Save(e); err != nil {
					t.Error(err)
					return
				}
			}
		}(w)
		go func(w int) {
			defer wg.Done()
			for i := 0; i < 8; i++ {
				if _, err := d.RecallAbout(context.Background(), "страница", 3, int64(w)); err != nil {
					t.Error(err)
					return
				}
			}
		}(w)
	}
	wg.Wait()
}

func TestNoiseCanReorderButNotWithoutIt(t *testing.T) {
	srv := fakeLLM(t, "")
	defer srv.Close()
	c := llm.New(srv.URL+"/", srv.URL+"/", "", "m", "e", 5*time.Second)
	d, err := New(t.TempDir(), c, 0, 1000)
	if err != nil {
		t.Fatal(err)
	}
	es := []Entry{
		{ID: "1", Body: "a", Meta: Metadata{Embedding: []float64{1, 0}}},
		{ID: "2", Body: "b", Meta: Metadata{Embedding: []float64{1, .05}}},
		{ID: "3", Body: "c", Meta: Metadata{Embedding: []float64{1, .1}}},
	}
	plain := map[string]bool{}
	for i := 0; i < 30; i++ {
		r, _ := d.Query(context.Background(), es, []float64{1, 0}, 1)
		plain[r[0].Entry.ID] = true
	}
	if len(plain) != 1 {
		t.Fatalf("without noise the best page is always the same: %v", plain)
	}
	noisy := map[string]bool{}
	for i := 0; i < 60; i++ {
		r, _ := d.Query(WithNoise(context.Background(), .3), es, []float64{1, 0}, 1)
		noisy[r[0].Entry.ID] = true
	}
	if len(noisy) < 2 {
		t.Fatalf("with noise the top hit must sometimes change: %v", noisy)
	}
}
