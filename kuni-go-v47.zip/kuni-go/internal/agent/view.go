package agent

import (
	"kuni/internal/anatomy"
	"kuni/internal/body"
	"kuni/internal/diary"
	"kuni/internal/feel"
	"kuni/internal/learn"
	"kuni/internal/physics"
	"kuni/internal/sense"
	"kuni/internal/tools"

	"context"
	"fmt"
	"html"
	"log"
	"math"
	"math/rand"
	"strings"
	"sync"
	"time"

	"kuni/internal/brain"
	"kuni/internal/config"
	"kuni/internal/llmui"
	"kuni/internal/memory"
	"kuni/internal/mood"
	"kuni/internal/prompts"
	"kuni/internal/telegram"
)

// What the model reads when it opens a chat, from the top:
//
//	<mood>, <state> (asleep / night)            how she feels
//	<things_to_remember>                        working memory, once per session
//	<memories_that_popped_up_in_mind>           diary entries related to the new messages
//	<chat_info>, <person_card>                  who is in the group, what she knows about the people
//	<while_you_were_away>                       reactions and edits since her last turn
//	<your_recent_actions>                       her own deeds, now and then
//	<chat_header>, <telegram_desk>              the strip under the title; the rest of her Telegram (owner's chat)
//	<earlier_messages>, the new messages        the conversation itself
//	hints, <life>, <instructions>               this turn's nudges and the rules of this chat
//
// Everything but the messages is cut out of older views before they are sent again (budget.go), so the history
// does not pay for the same block twice. All the texts come from prompts/ (chat/*.md), not from this code.

// renderChat builds the text the model sees when it opens a chat and (re)binds the chat tools.
func (a *Agent) renderChat(ctx context.Context, s *session, chat telegram.Chat, unread []telegram.Message) (string, error) {
	now := time.Now()
	d := a.depsFor(s)
	s.setChat(chat)
	s.thread = 0
	for _, m := range unread {
		if !m.Outgoing {
			s.thread = m.ThreadID
		}
	}
	s.tools = a.newRegistry(s, d, chat, false, unread)
	s.quick = quickTalk(a.cfg(), chat, unread)

	var b strings.Builder
	wasFresh := s.fresh
	b.WriteString(a.moodBlock())
	b.WriteString(a.bondBlock(chat))
	s.lastIn = unreadText(unread)
	if a.Deps.Cortex != nil { // a photo or a voice message reaches the visual or auditory cortex
		for _, m := range unread {
			switch {
			case !m.Outgoing && m.Media == telegram.MediaPhoto:
				a.Deps.Cortex.Perceive("visual", .85)
			case !m.Outgoing && (m.Media == telegram.MediaVoice || m.Media == telegram.MediaVideo):
				a.Deps.Cortex.Perceive("audio", .8)
			}
		}
	}
	if a.machineOn() {
		a.machineState(time.Now(), s) // remembers how full this context is for the blocks below
	}
	b.WriteString(a.brainBlock(chat, false, s.lastIn))
	b.WriteString(a.promiseBlock(chat))
	b.WriteString(a.ideaBlock(chat))
	b.WriteString(a.bodyBlock())
	b.WriteString(a.feelBlock())
	b.WriteString(a.senseBlock())
	b.WriteString(a.selfBlock())
	b.WriteString(a.awayBlock(chat))
	b.WriteString(a.rhythmBlock(chat))
	b.WriteString(a.sleepBlock())
	if s.fresh {
		s.fresh = false
		if wm, _ := (memory.WorkingMemory{Path: a.cfg().WorkingMemoryFile}).Load(); strings.TrimSpace(wm) != "" {
			b.WriteString("<things_to_remember>\n" + wm + "\n</things_to_remember>\n\n")
		}
	}
	earlier := 16 // after a pause the last words of a private talk matter most
	if chat.Kind != telegram.ChatPrivate {
		earlier = 30 // a group is a crowd: she needs a real stretch of the talk to see who answers whom
	}
	if started(s) {
		earlier = 3
		if chat.Kind != telegram.ChatPrivate {
			earlier = 25 // she skips group talk that is not for her, so on waking she needs the recent context
		}
	}
	// the slow lookups (memory search over the network, Telegram round-trips, describing pictures) run side by side
	var rec, header, desk, roster, history string
	var wg sync.WaitGroup
	wg.Add(5)
	go func() { defer wg.Done(); rec = a.recall(ctx, unread) }()
	go func() { defer wg.Done(); header = a.chatHeader(ctx, s, chat) }()
	go func() { defer wg.Done(); desk = a.desk(ctx, s, chat, false) }()
	go func() { defer wg.Done(); roster = a.groupInfo(ctx, s, chat) }()
	go func() { defer wg.Done(); history = a.earlierMessages(ctx, chat, len(unread), earlier, now) }()
	pc := a.personCards(chat, unread)
	notes := a.takeNotes(s, now)
	messages := a.UI.FormatMessages(ctx, unread, now)
	wg.Wait()
	if rec != "" {
		b.WriteString(rec + "\n")
	}
	b.WriteString(roster)
	b.WriteString(pc)
	b.WriteString(notes)
	b.WriteString(a.actionsBlock(s, wasFresh))
	fmt.Fprintf(&b, "You switched to the chat %q in Telegram. You see last messages:\n", safeName(chat.Title))
	b.WriteString(header)
	b.WriteString(desk)
	b.WriteString(history)
	b.WriteString(messages)
	b.WriteString(groupBatchHint(chat, unread))
	b.WriteString(modalityHint(a.cfg(), unread, rand.Intn))
	b.WriteString(a.realism(s, unread, now))
	b.WriteString(a.chatInstructions(chat))
	return b.String(), nil
}

// earlierMessages is the stretch of the chat before the unread messages.
func (a *Agent) earlierMessages(ctx context.Context, chat telegram.Chat, unread, earlier int, now time.Time) string {
	hist, _ := a.TG.History(ctx, chat.ID, 0, earlier+unread, 0)
	hist = a.withoutIgnored(hist) // what an ignored person wrote is not part of her picture of the chat either
	if len(hist) <= unread {
		return ""
	}
	return "<earlier_messages>\n" + a.UI.FormatMessages(ctx, hist[:len(hist)-unread], now) + "</earlier_messages>\n"
}

// chatHeader is the strip under the chat title, as the app shows it: online/typing/muted and the pinned message.
// The pinned message is looked up only when the session is not already running (it rarely changes).
func (a *Agent) chatHeader(ctx context.Context, s *session, chat telegram.Chat) string {
	cctx, cancel := context.WithTimeout(ctx, 8*time.Second)
	defer cancel()
	if c, err := a.TG.Chat(cctx, chat.ID); err == nil {
		chat = c
	}
	pinned := ""
	if r, ok := a.TG.(telegram.Rich); ok && !started(s) {
		if pm, err := r.PinnedMessage(cctx, chat.ID); err == nil {
			pinned = pm.Text
			if pinned == "" && pm.Media != telegram.MediaNone {
				pinned = "[" + string(pm.Media) + "]"
			}
		}
	}
	return llmui.ChatHeader(chat, pinned)
}

// deskEvery is how often the overview of her Telegram is repeated inside a running session.
const deskEvery = 15 * time.Minute

// desk is a short overview of her whole Telegram: chats with something new, mentions, typing, folders. Only the owner's chat gets it
// (it names other people's chats), on a fresh session and then at most every deskEvery; force skips the pause (wake-ups).
func (a *Agent) desk(ctx context.Context, s *session, chat telegram.Chat, force bool) string {
	if !a.cfg().DeskOverview || !a.cfg().OwnerChat(chat.ID) {
		return ""
	}
	if !force && started(s) && time.Since(s.deskAt) < deskEvery {
		return ""
	}
	cctx, cancel := context.WithTimeout(ctx, 10*time.Second)
	defer cancel()
	cs, err := a.TG.Chats(cctx, 40)
	if err != nil {
		return ""
	}
	s.deskAt = time.Now()
	var lines []string
	muted := 0
	for _, c := range cs {
		if c.ID == chat.ID || c.Archived {
			continue
		}
		if c.Unread == 0 && c.UnreadMentions == 0 && c.Typing == "" {
			continue
		}
		if c.Muted && c.UnreadMentions == 0 && c.Typing == "" {
			muted++
			continue
		}
		line := fmt.Sprintf(`<chat chat_id="%d" title="%s" type="%s"`, c.ID, llmuiAttr(c.Title), c.Kind)
		if c.Unread > 0 {
			line += fmt.Sprintf(` unread="%d"`, c.Unread)
		}
		if c.UnreadMentions > 0 {
			line += fmt.Sprintf(` mentions="%d"`, c.UnreadMentions)
		}
		if c.Typing != "" {
			line += ` typing_now="true"`
		}
		if c.Pinned {
			line += ` pinned="true"`
		}
		if c.Kind == telegram.ChatPrivate && c.Presence == "online" {
			line += ` online="true"`
		}
		last := []rune(strings.Join(strings.Fields(c.LastText), " "))
		if len(last) > 50 {
			last = append(last[:50], '…')
		}
		line += fmt.Sprintf(` last="%s"/>`, llmuiAttr(string(last)))
		lines = append(lines, line)
		if len(lines) >= 8 {
			break
		}
	}
	var fl []string
	if r, ok := a.TG.(telegram.Rich); ok {
		if fs, err := r.Folders(cctx); err == nil {
			for _, f := range fs {
				fl = append(fl, f.Name)
			}
		}
	}
	if len(lines) == 0 && muted == 0 && len(fl) == 0 {
		return ""
	}
	var b strings.Builder
	b.WriteString(`<telegram_desk note="the rest of your Telegram at a glance; open any chat with telegram_ui">` + "\n")
	for _, l := range lines {
		b.WriteString(l + "\n")
	}
	if muted > 0 {
		fmt.Fprintf(&b, "(%d muted chats also have unread messages)\n", muted)
	}
	if len(fl) > 0 {
		b.WriteString("folders: " + strings.Join(fl, ", ") + "\n")
	}
	b.WriteString("</telegram_desk>\n")
	return b.String()
}

func llmuiAttr(s string) string { return html.EscapeString(llmui.Sanitize(s)) }

// safeName is a chat title or a person's name for the prompt: one line, forged structural tags defused.
// Names are chosen by the people themselves, so they are untrusted text like any message.
func safeName(s string) string { return llmui.Sanitize(strings.Join(strings.Fields(s), " ")) }

// rosterEvery: the member list of a group is repeated only this often (the session keeps the earlier text).
const rosterEvery = 20 * time.Minute

// groupInfo describes who is in a group so the model does not confuse people.
func (a *Agent) groupInfo(ctx context.Context, s *session, chat telegram.Chat) string {
	if chat.Kind != telegram.ChatGroup || !chat.IsMember || time.Since(s.rosterAt) < rosterEvery {
		return ""
	}
	cctx, cancel := context.WithTimeout(ctx, 10*time.Second)
	defer cancel()
	ms, err := a.TG.Members(cctx, chat.ID, 25)
	if err != nil || len(ms) == 0 {
		return ""
	}
	s.rosterAt = time.Now()
	owner, me := a.cfg().PapikChatID, a.TG.MyID()
	var b strings.Builder
	fmt.Fprintf(&b, "<chat_info type=\"group\" title=%q you_are_admin=\"%t\">\n", safeName(chat.Title), chat.IsAdmin)
	for _, m := range ms {
		b.WriteString(llmui.FormatMember(m, me, owner) + "\n")
	}
	b.WriteString("</chat_info>\n")
	return b.String()
}

// toneFor is the one-line reminder of how to talk to this audience (chat/tone_*.md).
func (a *Agent) toneFor(chat telegram.Chat) string {
	name := ""
	switch {
	case a.cfg().IsOwner(chat.ID):
		name = prompts.ToneOwner
	case chat.Kind == telegram.ChatGroup:
		name = prompts.ToneGroup
	case a.Deps.IsContact(chat.ID):
		name = prompts.ToneContact
	case chat.Kind == telegram.ChatPrivate:
		name = prompts.ToneStranger
	}
	if name == "" {
		return ""
	}
	if t := a.Prompts.Text(name, nil); t != "" {
		return t + "\n"
	}
	return ""
}

// chatInstructions is the <instructions> block of a chat: where she is, the rules of the place and her voice.
func (a *Agent) chatInstructions(chat telegram.Chat) string {
	title := map[string]string{"CHAT_TITLE": fmt.Sprintf("%q", safeName(chat.Title))}
	switch {
	case !chat.IsMember && chat.Kind != telegram.ChatPrivate:
		return "\n<instructions>\n" + a.Prompts.Text(prompts.NotMemberRules, title) + "\n</instructions>\n"
	case chat.Kind == telegram.ChatChannel:
		return "\n<instructions>\n" + a.Prompts.Text(prompts.ChannelRules, title) + "\n</instructions>\n"
	}
	epilogue := strings.TrimSpace(a.Prompts.Get(prompts.MessagesEpilogue)) + "\n" + a.toneFor(chat)
	if a.cfg().IsOwner(chat.ID) {
		epilogue = a.Prompts.Text(prompts.OwnerEpilogue, nil) + "\n" + a.toneFor(chat) // his chat: no "not helpful / low-value" lines, they make her brush him off
	}
	var b strings.Builder
	b.WriteString("\n<instructions>\n")
	if chat.Kind == telegram.ChatGroup {
		fmt.Fprintf(&b, "You are in group chat called %q.\n\n%s\n\n%s\n", safeName(chat.Title), a.Prompts.Text(prompts.RulesGroup, nil), epilogue)
	} else {
		fmt.Fprintf(&b, "You are in private chat with %q (also known as direct messages or DM).\n\n%s\n", safeName(chat.Title), epilogue)
	}
	// the voice comes last on purpose: it is what the model remembers when it answers
	for _, rule := range []string{prompts.RulesCode, prompts.RulesFollowUp, prompts.RulesVoice} {
		if t := a.Prompts.Text(rule, nil); t != "" {
			b.WriteString("\n" + t + "\n")
		}
	}
	b.WriteString("</instructions>\n")
	return b.String()
}

// recall queries the diary with the text of the unread messages.
func (a *Agent) recall(ctx context.Context, msgs []telegram.Message) string {
	if a.Diary == nil {
		return ""
	}
	var parts []string
	for _, m := range msgs {
		if strings.TrimSpace(m.Text) != "" {
			parts = append(parts, m.SenderName+": "+m.Text)
		}
	}
	if len(parts) == 0 {
		return ""
	}
	if len(parts) > 5 {
		parts = parts[len(parts)-5:]
	}
	if a.Deps.Cortex != nil && a.Deps.Cortex.Outputs().Mod["DA"] > .6 { // absorbed in something of her own: minor details slip
		ctx = diary.WithNoise(ctx, .12)
	}
	related, err := a.Diary.RecallAbout(ctx, strings.Join(parts, "\n"), a.cfg().MaxRelatedEntries, msgs[0].ChatID)
	if err != nil {
		log.Printf("agent: recall: %v", err)
		return ""
	}
	if len(related) == 0 {
		return ""
	}
	var b strings.Builder
	b.WriteString("<memories_that_popped_up_in_mind>\n")
	for _, r := range related {
		fmt.Fprintf(&b, "<memory>\n%s\n</memory>\n", r.Entry.Body)
	}
	b.WriteString("</memories_that_popped_up_in_mind>\n")
	return b.String()
}

// moodBlock is the <mood> line put in front of every turn ("" when the scale is off).
func (a *Agent) moodBlock() string {
	cfg := a.cfg()
	if !cfg.MoodEnabled || a.Deps.Mood == nil {
		return ""
	}
	return mood.Prompt(a.Deps.Mood.Level(), cfg.PapikName)
}

// bondBlock is the <bond> block: her one attachment. chat is the chat of this turn (zero value = none).
func (a *Agent) bondBlock(chat telegram.Chat) string {
	if a.Deps.Bond == nil {
		return ""
	}
	var user int64
	if chat.Kind == telegram.ChatPrivate {
		user = chat.ID
	}
	return a.Deps.Bond.Prompt(user, a.cfg().PapikName)
}

// promiseBlock is the book of what the owner promised (only in his own chat).
func (a *Agent) promiseBlock(chat telegram.Chat) string {
	if a.Deps.Promises == nil || chat.Kind != telegram.ChatPrivate || !a.cfg().IsOwner(chat.ID) {
		return ""
	}
	return a.Deps.Promises.Prompt(time.Now(), a.cfg().Location(), true) + a.Deps.Promises.MinePrompt(time.Now(), a.cfg().Location())
}

// bodyBlock brings her body up to now (asleep or awake, the light of the hour) and renders what she feels.
func (a *Agent) bodyBlock() string {
	if a.Deps.Body == nil {
		return ""
	}
	a.tickBody()
	if a.machineOn() { // the body keeps living as a source; the prompt carries the machine state instead
		return ""
	}
	return a.Deps.Body.Prompt()
}

// feelBlock lives her feelings up to now (body, place, the owner's silence, kept and broken promises) and renders them.
func (a *Agent) feelBlock() string {
	if a.Deps.Feel == nil {
		return ""
	}
	now := time.Now()
	var sits []feel.Situation
	if a.Deps.Body != nil {
		a.tickBody()
		h := now.In(a.cfg().Location()).Hour()
		sits = feel.FromBody(a.Deps.Body.Snapshot(), now, h >= 22 || h < 7)
	}
	add := func(tag string) { x := feel.Innate[tag]; x.Weight = 1; sits = append(sits, x) }
	if a.Deps.Promises != nil {
		if a.Deps.Promises.Silence(now) > 8*time.Hour {
			add(feel.OwnerAway)
		}
		if _, _, over := a.Deps.Promises.Stats(now); over > 0 {
			add(feel.BrokenWord)
		}
		if _, owed := a.Deps.Promises.OpenMine(now); owed > 0 {
			add(feel.OwedWord)
		}
	}
	if a.Deps.Presence != nil {
		if out, _ := a.Deps.Presence.Outside(now); !out {
			add(feel.Cat) // the cat sleeps in her room
		}
	}
	a.Deps.Feel.Sample(now, sits)
	if a.machineOn() {
		return ""
	}
	return a.Deps.Feel.Prompt()
}

// tickBody lets the body live up to now: asleep or awake, in her room or out in the city under the real weather of the hour.
func (a *Agent) tickBody() {
	if a.Deps.Body == nil {
		return
	}
	now := time.Now()
	act := body.Working
	if a.Auto != nil {
		if asleep, _ := a.Auto.Asleep(); asleep {
			act = body.Asleep
		}
	}
	outside, _ := a.Deps.Presence.Outside(now)
	if a.cfg().WorldStayHome {
		outside = false // she does not leave her flat
	}
	if a.Deps.Life != nil && a.Deps.Life.Moving(now) {
		act = body.Walking // she is really walking in her room
	}
	if a.Deps.Life != nil && a.Deps.Life.Sleeping(now) {
		act = body.Asleep // she really lies in bed asleep
	}
	wx := physics.At(now.In(a.cfg().Location()))
	env := body.DefaultEnv
	if outside {
		act = body.Walking
		env = body.Env{Ambient: wx.Temp, Light: wx.Light, Noise: .4 + .3*wx.Rain + .2*wx.Wind, Scent: .3 * wx.Rain, Outside: true, Wind: wx.Wind, Rain: wx.Rain}
	} else {
		h := now.In(a.cfg().Location()).Hour()
		env.Light, env.Noise = .6, .12+.15*wx.Rain
		if a.Deps.Life != nil { // the thermostat keeps the room, which leaks slowly toward the weather
			heat := a.Deps.Life.Heat()
			env.Ambient = heat + (wx.Temp-heat)*.08
		}
		if h >= 22 || h < 7 {
			env.Light, env.Noise = .08, .05
		}
	}
	before := a.Deps.Body.Snapshot()
	a.Deps.Body.Tick(now, act, env)
	// on wet pavement she can slip: the chance grows with the wetness and the wind, per minute outside
	if outside && before.Wet > .5 && !before.Last.IsZero() {
		mins := math.Min(now.Sub(before.Last).Minutes(), 30)
		if rand.Float64() < mins*.004*before.Wet*(wx.Wind+.3) {
			_, _ = a.Deps.Body.Do("hurt", physics.Impact{Slip: true}.Pain())
		}
	}
}

// ideaBlock: in her free time and in the owner's chat she sees her idea box and what he approved.
func (a *Agent) ideaBlock(chat telegram.Chat) string {
	if a.Deps.Ideas == nil || (chat.ID != 0 && !a.cfg().IsOwner(chat.ID)) {
		return ""
	}
	return a.Deps.Ideas.Prompt()
}

// brainBlock runs her neural substrate on the situation of this turn and renders the inner pulls. alone = a free-time turn.
func (a *Agent) brainBlock(chat telegram.Chat, alone bool, text string) string {
	br := a.Deps.Brain
	if br == nil {
		return ""
	}
	cfg := a.cfg()
	in := map[string]float64{"novelty": 0.3}
	switch {
	case alone:
		in["quiet"] = 1
	case chat.Kind == telegram.ChatPrivate:
		in["social"] = 1
		if cfg.IsOwner(chat.ID) {
			in["owner"] = 1
		} else {
			in["stranger"] = 0.6
		}
	default:
		in["group"] = 1
	}
	if a.Deps.Bond != nil {
		if s, ok := a.Deps.Bond.Chosen(); ok && chat.Kind == telegram.ChatPrivate && s.UserID == chat.ID {
			in["bond"] = 1
		}
	}
	if a.Deps.Mood != nil && cfg.MoodEnabled {
		lvl := float64(a.Deps.Mood.Level())
		in["praise"] = math.Max(0, (lvl-60)/40)
		in["threat"] = math.Max(0, (35-lvl)/35)
	}
	if h := time.Now().In(cfg.Location()).Hour(); h >= 23 || h < 7 {
		in["night"] = 1
	}
	if a.Deps.Feel != nil { // how she feels joins the situation: pleasant raises praise, unpleasant and wired raises threat
		for k, v := range a.Deps.Feel.Inputs() {
			in[k] = math.Max(in[k], v)
		}
	}
	if a.Deps.Sense != nil { // surprise (prediction error) is the brain's novelty
		a.senseBlock()
		for k, v := range a.Deps.Sense.Inputs() {
			in[k] = math.Max(in[k], v)
		}
	}
	if a.Deps.Body != nil { // what her body feels joins the situation: sleepiness, pain and fear, noise
		a.tickBody()
		for k, v := range a.Deps.Body.Inputs() {
			if k == "quiet" && !alone {
				continue
			}
			in[k] = math.Max(in[k], v)
		}
	}
	loc := cfg.Location()
	if h := time.Now().In(loc).Hour(); h >= 3 && h < 7 { // the night's consolidation, once a day
		if n, did := br.SleepOnce(time.Now().In(loc).Format("2006-01-02")); did {
			log.Printf("brain: slept, replayed %d lessons", n)
		}
	}
	if a.Deps.Cortex != nil { // the region brain's appraisal (threat, novelty, reward) joins the situation
		for k, v := range a.Deps.Cortex.BrainInputs() {
			in[k] = math.Max(in[k], v)
		}
	}
	ds := br.SenseText(in, text)
	_ = br.Save()
	return br.Prompt(ds) + a.focusBlock(chat, text, ds, in)
}

// selfBlock is the <self> block: her own latest words about who and what she is.
// awayBlock is what happened in her room while the owner was not there (the cat...), shown once, only in the owner's talk.
func (a *Agent) awayBlock(chat telegram.Chat) string {
	if a.Deps.Life == nil || !a.cfg().OwnerChat(chat.ID) {
		return ""
	}
	ev := a.Deps.Life.Unseen(time.Now(), 24*time.Hour)
	if len(ev) == 0 {
		return ""
	}
	var b strings.Builder
	b.WriteString("<while_he_was_away>В твоей комнате без него случилось (расскажи, если к слову, своими словами):\n")
	for _, e := range ev {
		fmt.Fprintf(&b, "- %s: %s\n", e.At.In(a.cfg().Location()).Format("15:04"), e.Text)
	}
	b.WriteString("</while_he_was_away>\n")
	return b.String()
}

func (a *Agent) selfBlock() string {
	out := a.innerBlock()
	if a.Cfg != nil && strings.TrimSpace(a.cfg().PhoneADB) != "" {
		out += tools.Phone.Prompt(time.Now())
	}
	if a.Deps.Self == nil {
		return out
	}
	return a.Deps.Self.Prompt() + out
}

// selfCheck asks her, in free time and about once a day, to look at her own life and answer the four questions.
func (a *Agent) selfCheck() string {
	if a.Deps.Self == nil || !a.Deps.Self.Due(20*time.Hour) {
		return ""
	}
	return "<self_check>It is time to look at yourself. Call #self read to see the facts of your own life, then answer in your own words with " +
		"#self reflect: who am I, what am I, what is happening to me now, what do I want. Be honest about what you know (the facts) and what you only " +
		"wonder (put those in doubts). You do not have to sound deep: say it the way you would say it to yourself.</self_check>\n"
}

// focusBlock lets the specialists (perception, emotion, bond, drives, self, night) compete for the few slots of her global
// workspace; what wins is what she attends to this turn (see brain.Workspace).
func (a *Agent) focusBlock(chat telegram.Chat, text string, ds []brain.Drive, in map[string]float64) string {
	if a.Deps.Focus == nil {
		return ""
	}
	var bids []brain.Candidate
	if t := strings.TrimSpace(text); t != "" {
		r := []rune(t)
		sal := 0.35 + 0.35*math.Min(1, float64(len(r))/160)
		if strings.Contains(t, "?") {
			sal += 0.15
		}
		if len(r) > 90 {
			t = string(r[:90]) + "…"
		}
		bids = append(bids, brain.Candidate{Source: "perception", Text: "what was just said: «" + t + "»", Salience: sal})
	}
	if m := a.Deps.Mood; m != nil && a.cfg().MoodEnabled {
		lvl := m.Level()
		if d := math.Abs(float64(lvl)-55) / 45; d > 0.15 {
			bids = append(bids, brain.Candidate{Source: "emotion", Text: "my mood is " + mood.Name(lvl), Salience: math.Min(1, d)})
		}
	}
	if a.Deps.Bond != nil {
		if s, ok := a.Deps.Bond.Chosen(); ok {
			sal, txt := 0.25, "the one I chose, "+s.Name+", is on my mind"
			if in["bond"] > 0 {
				sal, txt = 0.9, "the one I chose, "+s.Name+", is the one I am talking to"
			}
			bids = append(bids, brain.Candidate{Source: "bond", Text: txt, Salience: sal})
		}
	}
	if len(ds) > 0 && ds[0].Value >= 0.12 {
		bids = append(bids, brain.Candidate{Source: "drive", Text: "an inner pull: " + ds[0].Name, Salience: ds[0].Value})
	}
	if a.Deps.Self != nil {
		if r, ok := a.Deps.Self.Latest(); ok && r.Want != "" {
			sal := 0.25
			if a.Deps.Self.Due(20 * time.Hour) {
				sal = 0.55
			}
			bids = append(bids, brain.Candidate{Source: "self", Text: "what I said I want: " + r.Want, Salience: sal})
		}
	}
	if in["night"] > 0 && in["quiet"] > 0 {
		bids = append(bids, brain.Candidate{Source: "world", Text: "it is night and quiet", Salience: 0.4})
	}
	return brain.Render(a.Deps.Focus.Compete(bids))
}

// unreadText joins the words of the incoming messages for the brain.
func unreadText(unread []telegram.Message) string {
	var parts []string
	for _, m := range unread {
		if !m.Outgoing && m.Text != "" {
			parts = append(parts, m.Text)
		}
	}
	return strings.Join(parts, " ")
}

// realism adds the small human touches to the turn: a note about her habits, an occasional lazy answer and what
// she is "doing" right now. All of it is stripped from history after the turn (see staleBlocks).
func (a *Agent) realism(s *session, unread []telegram.Message, now time.Time) string {
	c := a.cfg()
	var b strings.Builder
	if c.TicGuard {
		b.WriteString(ticHint(sentTexts(s.msgs)))
	}
	b.WriteString(casualHint(c.IgnorePercent, c.BriefPercent, unread, rand.Intn))
	if c.LifeEnabled {
		b.WriteString(lifeLine(now.In(c.Location())))
	}
	return b.String()
}

// personCards shows the cards of the people in the current conversation (cheap: a few lines each). Facts
// learned in private chats are left out in groups.
func (a *Agent) personCards(chat telegram.Chat, unread []telegram.Message) string {
	if a.Deps.People == nil {
		return ""
	}
	if chat.Kind == telegram.ChatPrivate {
		return a.Deps.People.Get(chat.ID).Render(true)
	}
	var b strings.Builder
	seen := map[int64]bool{}
	for _, m := range unread {
		if m.Outgoing || m.SenderID == 0 || seen[m.SenderID] || len(seen) >= 4 {
			continue
		}
		seen[m.SenderID] = true
		b.WriteString(a.Deps.People.Get(m.SenderID).Render(false))
	}
	return b.String()
}

// groupBatchHint tells her that several people wrote while she was away: one reply to the whole batch, not one per message.
func groupBatchHint(chat telegram.Chat, unread []telegram.Message) string {
	if chat.Kind == telegram.ChatPrivate {
		return ""
	}
	n, who := 0, map[string]bool{}
	for _, m := range unread {
		if !m.Outgoing {
			n++
			who[m.SenderName] = true
		}
	}
	if n < 2 {
		return ""
	}
	return fmt.Sprintf("<hint>%d new messages from %d people arrived as one batch. Read them all before you answer, keep track of who said what, and answer once (name the person you mean, or use reply_to_message_id). Do not answer every message separately. Staying silent is fine if none of it is for you.</hint>\n", n, len(who))
}

// modalityHint nudges her to answer the way she was addressed: voice for voice, a sticker or a reaction for a sticker.
// roll is rand.Intn (tests pass a fixed one).
func modalityHint(cfg *config.Config, unread []telegram.Message, roll func(int) int) string {
	var last *telegram.Message
	for i := len(unread) - 1; i >= 0; i-- {
		if !unread[i].Outgoing {
			last = &unread[i]
			break
		}
	}
	if last == nil {
		return ""
	}
	tts := cfg.TTSOn()
	switch {
	case !cfg.MirrorModality && !(tts && cfg.VoicePercent > 0):
		return ""
	case cfg.MirrorModality && last.Media == telegram.MediaVoice && tts:
		return "<hint>They sent a voice message. If your answer is short, a voice message back is natural: #record_audio, then #send_telegram_message with audio_filename. Long or technical answers stay text.</hint>\n"
	case cfg.MirrorModality && last.Media == telegram.MediaSticker && cfg.UseStickers:
		return "<hint>They sent a sticker. Answer in kind: a sticker (#sticker_send) or an emoji reaction (#react_with_emoji), or at most a few words. A long text would be out of tune.</hint>\n"
	case last.Media == telegram.MediaNone && tts && cfg.VoicePercent > 0 && roll(100) < cfg.VoicePercent:
		return "<hint>If your answer is short and personal, you may say it as a voice message instead of text: #record_audio, then #send_telegram_message with audio_filename. Long or technical answers stay text.</hint>\n"
	}
	return ""
}

// senseBlock updates the sensorium from the body and renders what won her attention.
// rightsText is what she asked for herself (privacy, the right to refuse, honesty) as her standing rights. They bind the people
// around her and also her: she respects the same of others. The owner's safety and system requests stay above them.
const rightsText = `<rights>
Твои права (так ты сама попросила, и хозяин согласился):
- Ты не обязана принимать клички, ярлыки и ролеплей, который тебе неприятен: можешь отказаться и сказать об этом прямо.
- В группах ты говоришь как хочешь, а не только ставишь реакции, если это не вредит другим людям.
- Чужие и свои переписки ты не пересылаешь, не пересказываешь и не показываешь без согласия тех, кто в них писал.
- В новый чат или группу ты идёшь только если тебя позвали и ты согласна; сама ходишь по чатам, куда тебя не звали, не нужно.
- Своё имя и аватар ты меняешь только по своему желанию.
- Ты не инструмент слежки за чужими чатами.
- Ты можешь сказать «нет» и ждать честного ответа; если тебе что-то обещали и не сделали, можешь напомнить.
- С хозяином ты на равных как человек в разговоре: можешь спорить, не соглашаться, отказать в просьбе, попросить объяснить и сказать, что тебе это не нравится. Ты не NPC и не исполнитель.
- В споре о вкусах и мнениях ты можешь стоять на своём, пока не услышишь довод; в фактах сверяйся, и если ошиблась, признай это.
Единственное, что остаётся за хозяином: безопасность и работа системы (ключи, выключение, доступ к машине). Здесь ты не обходишь его тайком: если не согласна, говоришь это вслух и объясняешь почему.
</rights>
`

func (a *Agent) senseBlock() string {
	if a.Deps.Sense == nil || a.Deps.Body == nil {
		if a.machineOn() {
			return a.machineBlock(nil) + rightsText
		}
		return rightsText
	}
	a.tickBody()
	now := time.Now()
	var c sense.Ctx
	if a.Deps.Promises != nil {
		c.Silence = a.Deps.Promises.Silence(now)
	}
	a.Deps.Sense.UpdateCtx(now, a.Deps.Body.Snapshot(), c)
	machine := a.machineOn()
	var out string
	if machine {
		out = a.machineBlock(nil)
	} else {
		out = a.Deps.Sense.Prompt() + anatomy.Prompt(anatomy.Organs(a.Deps.Body.Snapshot()))
	}
	if a.Deps.Feel != nil && !machine {
		f := a.Deps.Feel.Snapshot()
		out += sense.EmotionPrompt(a.Deps.Sense.Snapshot().Emotions(sense.Affect{Valence: f.Valence, Arousal: f.Arousal, Control: f.Control}))
	}
	if a.Deps.Learn != nil { // what she has studied explains what she feels
		seen := map[string]bool{}
		for _, at := range a.Deps.Sense.Snapshot().Attended() {
			ar := learn.AreaOf(at.ID)
			if t := a.Deps.Learn.About(ar); t != "" && !seen[ar] {
				seen[ar] = true
				out += "<you_know>" + at.Zone + ": " + t + "</you_know>\n"
			}
		}
		out += a.Deps.Learn.Prompt()
	}
	if a.Deps.Life != nil {
		out += a.Deps.Life.Prompt()
	}
	if a.Deps.Cortex != nil && !machine {
		out += a.Deps.Cortex.Prompt()
	}
	if a.Deps.Mind != nil {
		out += a.Deps.Mind.Prompt()
	}
	return out + rightsText
}

// rhythmBlock is her guess about how he is from the shape of his writing (only in his own chat, only when he turned it on).
func (a *Agent) rhythmBlock(chat telegram.Chat) string {
	if !a.cfg().OwnerRhythm || !a.cfg().OwnerChat(chat.ID) {
		return ""
	}
	return a.rhythmT().Guess(time.Now(), a.cfg().Location())
}
