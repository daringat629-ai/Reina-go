package agent

import (
	"context"
	"fmt"
	"log"
	"math/rand"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"kuni/internal/llm"
	"kuni/internal/telegram"
)

// The inner monologue: while nobody talks to her she keeps thinking, a few sentences every hour or so. The thoughts are kept in
// inner_monologue.md and the latest ones colour what she says next, so a talk starts from the thought she was in, not from nothing.

const (
	thoughtKeep   = 30 // thoughts kept on disk
	thoughtShown  = 3  // thoughts shown to her in a prompt
	thoughtPerDay = 12
	thoughtMaxLen = 400 // runes
)

type thoughts struct {
	mu   sync.Mutex
	path string
	list []thought
}

type thought struct {
	At   time.Time
	Text string
}

// loadThoughts reads inner_monologue.md: one thought per block, "## 2006-01-02 15:04" then the text.
func loadThoughts(path string) *thoughts {
	t := &thoughts{path: path}
	raw, err := os.ReadFile(path)
	if err != nil {
		return t
	}
	for _, blk := range strings.Split(string(raw), "\n## ")[0:] {
		blk = strings.TrimPrefix(strings.TrimSpace(blk), "## ")
		head, body, ok := strings.Cut(blk, "\n")
		if !ok {
			continue
		}
		at, err := time.ParseInLocation("2006-01-02 15:04", strings.TrimSpace(head), time.Local)
		if err != nil || strings.TrimSpace(body) == "" {
			continue
		}
		t.list = append(t.list, thought{at, strings.TrimSpace(body)})
	}
	return t
}

// Add keeps a thought and writes the file.
func (t *thoughts) Add(at time.Time, text string) {
	text = strings.Join(strings.Fields(text), " ")
	if r := []rune(text); len(r) > thoughtMaxLen {
		text = string(r[:thoughtMaxLen])
	}
	if text == "" {
		return
	}
	t.mu.Lock()
	defer t.mu.Unlock()
	t.list = append(t.list, thought{at, text})
	if len(t.list) > thoughtKeep {
		t.list = t.list[len(t.list)-thoughtKeep:]
	}
	var b strings.Builder
	b.WriteString("# Внутренний монолог\n")
	for _, x := range t.list {
		fmt.Fprintf(&b, "\n## %s\n%s\n", x.At.Format("2006-01-02 15:04"), x.Text)
	}
	_ = os.MkdirAll(filepath.Dir(t.path), 0o755)
	if err := os.WriteFile(t.path, []byte(b.String()), 0o600); err != nil {
		log.Printf("agent: inner monologue: %v", err)
	}
}

// Last is the n latest thoughts, oldest first.
func (t *thoughts) Last(n int) []thought {
	t.mu.Lock()
	defer t.mu.Unlock()
	if len(t.list) > n {
		return append([]thought(nil), t.list[len(t.list)-n:]...)
	}
	return append([]thought(nil), t.list...)
}

// Today is how many thoughts she had on the day of now.
func (t *thoughts) Today(now time.Time) int {
	t.mu.Lock()
	defer t.mu.Unlock()
	n := 0
	for _, x := range t.list {
		if x.At.YearDay() == now.YearDay() && x.At.Year() == now.Year() {
			n++
		}
	}
	return n
}

func (a *Agent) thoughtStore() *thoughts {
	a.innerOnce.Do(func() { a.inner = loadThoughts(filepath.Join(a.cfg().DataDir, "inner_monologue.md")) })
	return a.inner
}

// innerBlock shows her latest thoughts (nothing if she has had none or the monologue is off).
func (a *Agent) innerBlock() string {
	if !a.cfg().AutonomyInner {
		return ""
	}
	last := a.thoughtStore().Last(thoughtShown)
	if len(last) == 0 {
		return ""
	}
	var b strings.Builder
	b.WriteString("<inner_stream>Твои последние мысли про себя (ты думала их, пока никто не писал; можешь начать разговор с них, если к слову, но не пересказывай их дословно):\n")
	for _, x := range last {
		fmt.Fprintf(&b, "- %s: %s\n", x.At.Format("15:04"), x.Text)
	}
	b.WriteString("</inner_stream>\n")
	return b.String()
}

// innerLoop is the quiet stream: every 40..90 minutes, while she is awake, she thinks once.
func (a *Agent) innerLoop(ctx context.Context) {
	for {
		select {
		case <-ctx.Done():
			return
		case <-time.After(time.Duration(40+rand.Intn(51)) * time.Minute):
		}
		if err := a.thinkOnce(ctx); err != nil {
			log.Printf("agent: inner monologue: %v", err)
		}
	}
}

// thinkOnce makes one thought if the conditions allow (switched on, awake, not paused, inside the daily limits).
func (a *Agent) thinkOnce(ctx context.Context) error {
	cfg := a.cfg()
	if !cfg.AutonomyInner || a.paused.Load() || a.Usage.Over(cfg.DailyTokenLimit) {
		return nil
	}
	now := time.Now()
	if a.Auto != nil {
		if asleep, _ := a.Auto.Asleep(); asleep {
			return nil
		}
	}
	if a.isNight(now) {
		return nil
	}
	ts := a.thoughtStore()
	if ts.Today(now) >= thoughtPerDay {
		return nil
	}
	var b strings.Builder
	loc := cfg.Location()
	fmt.Fprintf(&b, "Сейчас %s (%s). Никто тебе не пишет, ты одна со своими мыслями.\n", now.In(loc).Format("Mon 2 Jan 15:04"), partOfDay(now.In(loc)))
	b.WriteString(a.moodBlock() + a.bodyBlock() + a.feelBlock() + a.brainBlock(telegram.Chat{}, true, "") + a.Deps.Promises.Absence(now))
	if a.machineOn() {
		b.WriteString(a.machineBlock(nil))
	}
	if a.Deps.Self != nil {
		b.WriteString(a.Deps.Self.Prompt())
	}
	if last := ts.Last(2); len(last) > 0 {
		b.WriteString("<your_previous_thoughts>\n")
		for _, x := range last {
			b.WriteString("- " + x.Text + "\n")
		}
		b.WriteString("</your_previous_thoughts>\n")
	}
	b.WriteString("Напиши, что у тебя сейчас в голове: одна-три фразы от первого лица, как мысль, а не как сообщение кому-то. Можно продолжить прошлую мысль или свернуть на другое. Без инструментов, без обращения, без списков, без эмодзи. Не выдумывай событий, которых не было.")
	m, err := a.LLM.Complete(llm.WithPurpose(ctx, "inner"), llm.Request{System: a.SystemPrompt(), Messages: []llm.Message{{Role: "user", Content: b.String()}}, Model: cfg.FastModel})
	if err != nil {
		return err
	}
	ts.Add(now, m.Content)
	return nil
}
