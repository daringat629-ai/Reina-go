package ideas

import (
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestANoIsFinalForAMonth(t *testing.T) {
	s := Open(filepath.Join(t.TempDir(), "i.json"))
	now := time.Now()
	it, err := s.Propose("Хочу доступ к твоему календарю", "чтобы не пропускать твои дела", now)
	if err != nil {
		t.Fatal(err)
	}
	if err := s.Decide(it.ID, false, now); err != nil {
		t.Fatal(err)
	}
	if _, err := s.Propose("хочу доступ к твоему календарю", "", now.Add(24*time.Hour)); err == nil || !strings.Contains(err.Error(), "нет") {
		t.Fatal("a fresh no must be respected:", err)
	}
	if _, err := s.Propose("Хочу доступ к твоему календарю", "", now.Add(31*24*time.Hour)); err != nil {
		t.Fatal("after a month she may ask again:", err)
	}
	if p := s.Prompt(); !strings.Contains(p, "не дави") {
		t.Fatal(p)
	}
}
