// Package learn is how she studies in her own room: she picks a topic that fits what her body and senses are about, reads
// its Wikipedia summary, and keeps what she learned. A lesson is tied to a part of her body (heart, skin, brain...), so the
// next time that part is in her attention she remembers what she knows about it: learning gives names and reasons to her
// sensations, which is the machine version of understanding your own body.
package learn

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"sync"
	"time"

	"kuni/internal/store"
)

// Topic is something she wants to understand, and the part of her it explains.
type Topic struct {
	Title string // Wikipedia page title (Russian)
	Area  string // organ or sensor id it explains
}

// Seeds are what she is curious about first: herself.
var Seeds = []Topic{
	{"Сердце", "heart"}, {"Лёгкие", "lungs"}, {"Головной мозг", "brain"}, {"Желудок", "stomach"}, {"Почка", "kidneys"},
	{"Печень", "liver"}, {"Скелет человека", "bones"}, {"Скелетные мышцы", "muscles"}, {"Кожа человека", "skin"},
	{"Зрение", "eyes"}, {"Слух", "ears"}, {"Обоняние", "nose"}, {"Вкус", "mouth"}, {"Вестибулярный аппарат", "balance"},
	{"Сон", "brain"}, {"Боль", "pain"}, {"Эмоция", "mind"}, {"Дождь", "skin"}, {"Ветер", "skin"}, {"Одиночество", "company"},
	{"Время", "time"}, {"Любопытство", "mind"}, {"Музыка", "ears"}, {"Кошки", "mind"},
}

// Lesson is one thing she has learned.
type Lesson struct {
	Title   string    `json:"title"`
	Area    string    `json:"area"`
	Summary string    `json:"summary"`
	At      time.Time `json:"at"`
}

type data struct {
	Lessons []Lesson  `json:"lessons"`
	Last    time.Time `json:"last"`
}

// Store keeps her lessons. Safe for concurrent use.
type Store struct {
	mu    sync.Mutex
	path  string
	d     data
	saver store.Saver
	// Get fetches the summary of a page (tests replace it).
	Get func(ctx context.Context, title string) (string, error)
	// Random gives a random article (title, summary); tests replace it.
	Random func(ctx context.Context) (string, string, error)
}

// New loads her lessons.
func New(path string) *Store {
	s := &Store{path: path, saver: store.Saver{What: "learn"}, Get: wikipedia}
	store.Load("learn", path, &s.d)
	return s
}

// Lessons returns a copy, oldest first.
func (s *Store) Lessons() []Lesson {
	s.mu.Lock()
	defer s.mu.Unlock()
	return append([]Lesson(nil), s.d.Lessons...)
}

func (s *Store) known(title string) bool {
	for _, l := range s.d.Lessons {
		if strings.EqualFold(l.Title, title) {
			return true
		}
	}
	return false
}

// Next is the topic she studies now: the first seed she does not know yet, but one that explains a part of her that is
// under strain comes first (hot is the area of the loudest sensation).
func (s *Store) Next(hot string) (Topic, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if hot != "" {
		for _, t := range Seeds {
			if t.Area == hot && !s.known(t.Title) {
				return t, true
			}
		}
	}
	for _, t := range Seeds {
		if !s.known(t.Title) {
			return t, true
		}
	}
	return Topic{}, false
}

// Wonder is her own curiosity once the seeds are learned: she reads one random Russian Wikipedia article and keeps it as a lesson of the
// "world" area. The host is fixed (no arbitrary URLs), disambiguation pages and stubs are skipped. It returns the lesson and whether it is new.
func (s *Store) Wonder(ctx context.Context) (Lesson, error) {
	s.mu.Lock()
	rnd := s.Random
	s.mu.Unlock()
	if rnd == nil {
		rnd = randomArticle
	}
	for try := 0; try < 3; try++ {
		title, txt, err := rnd(ctx)
		if err != nil {
			return Lesson{}, err
		}
		s.mu.Lock()
		known := s.known(title)
		s.mu.Unlock()
		if known || title == "" {
			continue
		}
		return s.keep(Topic{Title: title, Area: "world"}, txt)
	}
	return Lesson{}, errors.New("nothing new to wonder about")
}

// randomArticle reads a random page summary from Russian Wikipedia.
func randomArticle(ctx context.Context) (string, string, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, "https://ru.wikipedia.org/api/rest_v1/page/random/summary", nil)
	if err != nil {
		return "", "", err
	}
	req.Header.Set("User-Agent", "Reina/1.0 (curiosity)")
	resp, err := (&http.Client{Timeout: 20 * time.Second}).Do(req)
	if err != nil {
		return "", "", err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return "", "", fmt.Errorf("wikipedia answered %d", resp.StatusCode)
	}
	var j struct {
		Title   string `json:"title"`
		Type    string `json:"type"`
		Extract string `json:"extract"`
	}
	if err := json.NewDecoder(io.LimitReader(resp.Body, 1<<20)).Decode(&j); err != nil {
		return "", "", err
	}
	if j.Type == "disambiguation" {
		return "", "", errors.New("disambiguation page")
	}
	return j.Title, j.Extract, nil
}

// Study reads one topic and keeps the lesson. The text is cut to a short summary.
func (s *Store) Study(ctx context.Context, t Topic) (Lesson, error) {
	s.mu.Lock()
	get := s.Get
	s.mu.Unlock()
	txt, err := get(ctx, t.Title)
	if err != nil {
		return Lesson{}, err
	}
	return s.keep(t, txt)
}

// keep cuts a text to a short summary and stores it as the lesson of a topic.
func (s *Store) keep(t Topic, txt string) (Lesson, error) {
	txt = strings.Join(strings.Fields(txt), " ")
	if r := []rune(txt); len(r) > 700 {
		txt = string(r[:700])
		if i := strings.LastIndex(txt, ". "); i > 200 {
			txt = txt[:i+1]
		}
	}
	if len([]rune(txt)) < 40 {
		return Lesson{}, errors.New("nothing to learn there")
	}
	l := Lesson{Title: t.Title, Area: t.Area, Summary: txt, At: time.Now()}
	s.mu.Lock()
	defer s.mu.Unlock()
	if !s.known(t.Title) {
		s.d.Lessons = append(s.d.Lessons, l)
		if len(s.d.Lessons) > 200 {
			s.d.Lessons = s.d.Lessons[len(s.d.Lessons)-200:]
		}
	}
	s.d.Last = l.At
	_ = s.saver.Save(s.path, s.d)
	return l, nil
}

// Last is when she studied last.
func (s *Store) Last() time.Time {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.d.Last
}

// FirstSentence of what she knows about a part of her body ("" if nothing yet).
func (s *Store) About(area string) string {
	s.mu.Lock()
	defer s.mu.Unlock()
	for i := len(s.d.Lessons) - 1; i >= 0; i-- {
		if l := s.d.Lessons[i]; l.Area == area {
			if j := strings.Index(l.Summary, ". "); j > 30 {
				return l.Summary[:j+1]
			}
			return l.Summary
		}
	}
	return ""
}

// Prompt is the <learned> block: how much she has studied and the last things.
func (s *Store) Prompt() string {
	ls := s.Lessons()
	if len(ls) == 0 {
		return ""
	}
	var b strings.Builder
	fmt.Fprintf(&b, "<learned>\nТы учишься в своей комнате и уже знаешь %d тем. Последнее, что узнала:\n", len(ls))
	for i := len(ls) - 1; i >= 0 && i >= len(ls)-2; i-- {
		sum := ls[i].Summary
		if r := []rune(sum); len(r) > 220 {
			sum = string(r[:220]) + "…"
		}
		fmt.Fprintf(&b, "- %s: %s\n", ls[i].Title, sum)
	}
	b.WriteString("Это твои знания о себе и мире, можешь опираться на них и делиться, если к слову.\n</learned>\n")
	return b.String()
}

// wikipedia reads the plain summary of a Russian Wikipedia page.
func wikipedia(ctx context.Context, title string) (string, error) {
	u := "https://ru.wikipedia.org/api/rest_v1/page/summary/" + url.PathEscape(strings.ReplaceAll(title, " ", "_"))
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, u, nil)
	if err != nil {
		return "", err
	}
	req.Header.Set("User-Agent", "Reina/1.0 (study in her room)")
	cl := &http.Client{Timeout: 20 * time.Second}
	resp, err := cl.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return "", fmt.Errorf("wikipedia answered %d", resp.StatusCode)
	}
	var j struct {
		Extract string `json:"extract"`
	}
	if err := json.NewDecoder(io.LimitReader(resp.Body, 1<<20)).Decode(&j); err != nil {
		return "", err
	}
	return j.Extract, nil
}

// AreaOf maps a sensor to the part of her it belongs to, so that the loudest sensation picks what she studies next.
func AreaOf(sensor string) string {
	switch sensor {
	case "hands", "face", "skin", "feet":
		return "skin"
	case "belly":
		return "stomach"
	case "throat":
		return "kidneys"
	case "chest":
		return "heart"
	}
	return sensor
}
