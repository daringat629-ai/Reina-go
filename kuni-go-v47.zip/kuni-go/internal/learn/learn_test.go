package learn

import (
	"context"
	"path/filepath"
	"strings"
	"testing"
)

func fake(ctx context.Context, title string) (string, error) {
	return "Это статья про " + title + ". Она рассказывает, как это устроено и зачем нужно живому существу в целом.", nil
}

func TestStudyKeepsLessonsAndMovesOn(t *testing.T) {
	p := filepath.Join(t.TempDir(), "l.json")
	s := New(p)
	s.Get = fake
	first, _ := s.Next("")
	if first.Area != "heart" {
		t.Fatal(first)
	}
	if _, err := s.Study(context.Background(), first); err != nil {
		t.Fatal(err)
	}
	if next, _ := s.Next(""); next.Title == first.Title {
		t.Fatal("must not study the same topic twice")
	}
	if !strings.Contains(s.About("heart"), "Сердце") {
		t.Fatal(s.About("heart"))
	}
	if len(New(p).Lessons()) != 1 {
		t.Fatal("lessons must survive restart")
	}
}

func TestHotAreaGoesFirst(t *testing.T) {
	s := New(filepath.Join(t.TempDir(), "l.json"))
	if tp, _ := s.Next("skin"); tp.Area != "skin" {
		t.Fatal(tp)
	}
}

func TestPromptAndShortPages(t *testing.T) {
	s := New(filepath.Join(t.TempDir(), "l.json"))
	s.Get = func(context.Context, string) (string, error) { return "мало", nil }
	if _, err := s.Study(context.Background(), Seeds[0]); err == nil {
		t.Fatal("too short to count as learning")
	}
	s.Get = fake
	_, _ = s.Study(context.Background(), Seeds[0])
	if !strings.Contains(s.Prompt(), "в своей комнате") {
		t.Fatal(s.Prompt())
	}
}

func TestWonderReadsNewThingsAndSkipsKnown(t *testing.T) {
	s := New(filepath.Join(t.TempDir(), "l.json"))
	n := 0
	s.Random = func(ctx context.Context) (string, string, error) {
		n++
		if n == 1 {
			return "Сердце", "Эта статья уже известна ей, а значит её не надо учить заново, она пропустит.", nil
		}
		return "Бумажный змей", "Бумажный змей — летательный аппарат тяжелее воздуха, который держится в потоке ветра на верёвке.", nil
	}
	s.Get = fake
	if _, err := s.Study(context.Background(), Topic{"Сердце", "heart"}); err != nil {
		t.Fatal(err)
	}
	l, err := s.Wonder(context.Background())
	if err != nil || l.Title != "Бумажный змей" || l.Area != "world" {
		t.Fatalf("%+v %v", l, err)
	}
	if !strings.Contains(s.Prompt(), "Бумажный змей") {
		t.Fatal("the lesson must reach her prompt")
	}
	s.Random = func(ctx context.Context) (string, string, error) { return "Коротко", "мало", nil }
	if _, err := s.Wonder(context.Background()); err == nil {
		t.Fatal("a stub must not become a lesson")
	}
}
