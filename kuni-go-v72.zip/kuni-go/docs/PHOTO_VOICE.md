# Фото и голос у Рейны

Модель Mercury (Inception) понимает только текст. Чтобы Рейна видела фото и слышала голосовые, ей нужны ещё три сервиса. Всё включается в `config.toml`, без пересборки.

## 1. Фото, стикеры, скриншоты

Картинки идут на отдельную модель через OpenRouter.

```toml
[llm]
light_base_url = "https://openrouter.ai/api/v1/"
light_api_key  = "sk-or-..."          # ключ OpenRouter
vision_model   = "google/gemini-2.5-flash"
```

Если `light_model` пустой, фоновые задачи (дневник, сон) остаются на основной модели, а на OpenRouter уходят только картинки.

## 2. Голосовые и кружки → текст (STT)

Любой сервис с API как у OpenAI Whisper. Быстрый и дешёвый вариант: Groq.

```toml
[capabilities]
stt_enabled = true
stt_url     = "https://api.groq.com/openai/v1/"
stt_model   = "whisper-large-v3-turbo"
stt_key     = "gsk_..."
```

## 3. Её голос (TTS)

ElevenLabs, тот же голос, что в роликах.

```toml
[capabilities]
tts_backend = "elevenlabs"
tts_key     = "..."               # ключ ElevenLabs
tts_voice   = "ID голоса"         # ElevenLabs → Voices → нужный голос → Copy voice ID
tts_model   = "eleven_multilingual_v2"

[telegram]
mirror_modality = true   # на голосовое отвечает голосом
voice_percent   = 10     # иногда сама отвечает голосом на текст (0 = никогда)
```

## Проверка

1. Перезапусти Рейну (или подожди: конфиг перечитывается сам).
2. Со второго аккаунта пришли ей фото: она должна описать, что на нём.
3. Пришли голосовое: она должна ответить по смыслу, а при `mirror_modality = true` голосом.

Запросы к `vision_model` списываются с баланса человека по цене основной модели. Распознавание голоса и озвучка не списываются: их оплачиваешь ты. Голосовые обычно короткие, так что это небольшая сумма, но следи за ней в кабинетах Groq и ElevenLabs.
