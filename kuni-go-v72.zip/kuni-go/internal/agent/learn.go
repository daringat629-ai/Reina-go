package agent

import (
	"context"
	"log"
	"strings"
	"time"
	"unicode/utf8"

	"kuni/internal/llm"
	"kuni/internal/prompts"
	"kuni/internal/reminders"
	"kuni/internal/telegram"
)

// learned is what the model took from a finished conversation.
type learned struct {
	Facts    []string
	Changes  []change
	Promises []promise
	Events   []promise // things coming up in their life, to ask about afterwards
}

type change struct{ Old, New string }
type promise struct{ When, What string }

// parseLearned reads the three kinds of lines (see learnAsk). NONE and noise give nothing.
func parseLearned(s string) learned {
	var out learned
	for _, line := range strings.Split(s, "\n") {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		first, size := utf8.DecodeRuneInString(line)
		switch first {
		case '-', '•':
			if f := strings.TrimSpace(strings.TrimLeft(line, "-•* ")); len([]rune(f)) >= 4 && len(out.Facts)+len(out.Changes) < 3 {
				out.Facts = append(out.Facts, f)
			}
		case '~':
			parts := strings.SplitN(strings.TrimSpace(line[size:]), "=>", 2)
			if len(parts) == 2 && len(out.Facts)+len(out.Changes) < 3 {
				o, n := strings.TrimSpace(parts[0]), strings.TrimSpace(parts[1])
				if len([]rune(o)) >= 3 && len([]rune(n)) >= 4 {
					out.Changes = append(out.Changes, change{o, n})
				}
			}
		case '@', '?':
			parts := strings.SplitN(strings.TrimSpace(line[size:]), "|", 2)
			if len(parts) != 2 {
				continue
			}
			w, t := strings.TrimSpace(parts[0]), strings.TrimSpace(parts[1])
			if w == "" || len([]rune(t)) < 4 {
				continue
			}
			if first == '@' && len(out.Promises) < 2 {
				out.Promises = append(out.Promises, promise{w, t})
			} else if first == '?' && len(out.Events) < 2 {
				out.Events = append(out.Events, promise{w, t})
			}
		}
	}
	return out
}

// learnPerson runs once when a private conversation is closed: one short light-model request that files lasting facts on
// the person's card (private, because they were told in private), corrects facts that went out of date and turns her own
// promises into reminders. Anything that is switched off or has no store is simply skipped.
func (a *Agent) learnPerson(ctx context.Context, s *session, msgs []llm.Message) {
	cfg := a.cfg()
	cards := cfg.AutoPersonCards && a.Deps.People != nil
	promises := cfg.AutoPromises && a.Deps.Reminders != nil
	if !(cards || promises) || s.id == 0 || s.chat.Kind != telegram.ChatPrivate {
		return
	}
	users := 0
	for _, m := range msgs {
		if m.Role == "user" {
			users++
		}
	}
	if users < 2 {
		return
	}
	known := "(none yet)"
	if a.Deps.People != nil {
		if k := a.Deps.People.Get(s.id).Render(true); k != "" {
			known = k
		}
	}
	loc := cfg.Location()
	now := time.Now()
	view := fitBudget(slimHistory(trim(msgs, 80), 200), 8000)
	question := a.Prompts.Text(prompts.LearnPerson, map[string]string{"NOW": now.In(loc).Format("Mon 2006-01-02 15:04")})
	ask := append(append([]llm.Message(nil), view...), llm.Message{Role: "user", Content: question + "\n" + known})
	c, cancel := context.WithTimeout(context.WithoutCancel(ctx), 60*time.Second)
	defer cancel()
	out, err := a.LLM.Chat(llm.WithChat(llm.WithPurpose(c, "people"), s.id), a.Prompts.Text(prompts.LearnPersonSystem, nil), ask)
	if err != nil {
		log.Printf("agent: learning from chat %d: %v", s.id, err)
		return
	}
	l := parseLearned(out)
	nf := 0
	if cards {
		for _, f := range l.Facts {
			if a.Deps.People.Add(s.id, s.chat.Title, f, true, now) == nil {
				nf++
			}
		}
		for _, ch := range l.Changes {
			if _, err := a.Deps.People.Supersede(s.id, s.chat.Title, ch.Old, ch.New, true, now); err == nil {
				nf++
			}
		}
	}
	if nf > 0 {
		a.maybeDescribe(s.id)
	}
	np := 0
	if promises {
		for _, p := range l.Promises {
			at, err := reminders.ParseWhen(p.When, now, loc)
			if err != nil || at.Before(now.Add(time.Minute)) || at.After(now.Add(30*24*time.Hour)) {
				continue
			}
			if dup(a.Deps.Reminders.List(s.id), p.What) {
				continue
			}
			if _, err := a.Deps.Reminders.Add(at, s.id, "You promised: "+p.What, now); err == nil {
				np++
			}
		}
	}
	ne := 0
	if promises {
		for _, e := range l.Events {
			at, err := reminders.ParseWhen(e.When, now, loc)
			if err != nil || at.Before(now) || at.After(now.Add(30*24*time.Hour)) {
				continue
			}
			ask := followUpAt(at, loc)
			if dup(a.Deps.Reminders.List(s.id), e.What) {
				continue
			}
			text := "Follow up: they told you about «" + e.What + "» (" + at.In(loc).Format("02.01 15:04") + "). Ask how it went, warmly and in your own words, like a friend who remembered. If they already told you, don't ask again."
			if _, err := a.Deps.Reminders.Add(ask, s.id, text, now); err == nil {
				ne++
			}
		}
	}
	if nf+np+ne > 0 {
		log.Printf("agent: from the talk with %s: %d fact(s), %d promise(s), %d event(s) to ask about", s.chat.Title, nf, np, ne)
	}
}

// followUpAt is when to ask about an event: a couple of hours after it, but never at night (then the next day at 11:00).
func followUpAt(event time.Time, loc *time.Location) time.Time {
	t := event.Add(2 * time.Hour).In(loc)
	if h := t.Hour(); h >= 23 || h < 9 {
		day := t
		if h >= 23 {
			day = t.AddDate(0, 0, 1)
		}
		t = time.Date(day.Year(), day.Month(), day.Day(), 11, 0, 0, 0, loc)
	}
	return t
}

// dup says whether a pending reminder of the chat already holds this promise.
func dup(items []reminders.Item, what string) bool {
	w := strings.ToLower(strings.TrimSpace(what))
	for _, it := range items {
		if strings.Contains(strings.ToLower(it.Text), w) {
			return true
		}
	}
	return false
}
