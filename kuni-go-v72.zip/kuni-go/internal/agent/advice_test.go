package agent

import (
	"path/filepath"
	"strings"
	"testing"
	"time"

	"kuni/internal/advice"
	"kuni/internal/config"
	"kuni/internal/telegram"
	"kuni/internal/tools"
)

func TestAdviceBlockAsksPeopleNotTheOwnerAndAtAPace(t *testing.T) {
	c := &config.Config{PapikChatID: 1}
	box := advice.Open(filepath.Join(t.TempDir(), "a.json"))
	a := &Agent{Cfg: config.NewStaticHolder(c), Deps: tools.Deps{Advice: box}}
	now := time.Now()
	if a.adviceBlock(telegram.Chat{ID: 7, Kind: telegram.ChatPrivate}, now) != "" {
		t.Fatal("no questions: nothing")
	}
	if seed := a.adviceOwnBlock(now); !strings.Contains(seed, "curiosity_seed") || a.adviceOwnBlock(now) != "" {
		t.Fatal("the seed comes once a day in her own time")
	}
	_, _ = box.Ask("как понять, что тебе по-настоящему дорог человек?", now)
	if b := a.adviceBlock(telegram.Chat{ID: 1, Kind: telegram.ChatPrivate}, now); strings.Contains(b, "curiosity") {
		t.Fatal("the owner is not asked")
	}
	if b := a.adviceBlock(telegram.Chat{ID: -5, Kind: telegram.ChatGroup}, now); strings.Contains(b, "curiosity") {
		t.Fatal("not in groups")
	}
	b := a.adviceBlock(telegram.Chat{ID: 7, Kind: telegram.ChatPrivate}, now)
	if !strings.Contains(b, "<curiosity id=") || !strings.Contains(b, "Не называй имён") {
		t.Fatalf("a person may be asked: %s", b)
	}
	if b := a.adviceBlock(telegram.Chat{ID: 7, Kind: telegram.ChatPrivate}, now.Add(time.Minute)); !strings.Contains(b, `state="asked"`) {
		t.Fatalf("then she waits for the answer: %s", b)
	}
}
