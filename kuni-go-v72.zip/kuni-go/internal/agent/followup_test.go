package agent

import (
	"testing"
	"time"
)

func TestEventsInTheirLifeBecomeFollowUps(t *testing.T) {
	l := parseLearned("- учится на врача\n? tomorrow 10:00 | экзамен по анатомии\n? 3h | собеседование\n? 5h | третье лишнее\n@ 1h | скинуть песню\nNONE")
	if len(l.Facts) != 1 || len(l.Promises) != 1 || len(l.Events) != 2 || l.Events[0].What != "экзамен по анатомии" {
		t.Fatalf("%+v", l)
	}
	loc := time.UTC
	day := time.Date(2026, 11, 2, 0, 0, 0, 0, loc)
	if got := followUpAt(day.Add(10*time.Hour), loc); got.Hour() != 12 || got.Day() != 2 {
		t.Fatalf("two hours after: %v", got)
	}
	if got := followUpAt(day.Add(22*time.Hour), loc); got.Hour() != 11 || got.Day() != 3 {
		t.Fatalf("not at midnight, the next day at 11: %v", got)
	}
	if got := followUpAt(day.Add(3*time.Hour), loc); got.Hour() != 11 || got.Day() != 2 {
		t.Fatalf("not at 5 am, the same day at 11: %v", got)
	}
}
