package billing

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"net/url"
	"path/filepath"
	"sort"
	"strings"
	"testing"
	"time"
)

// signInit builds initData the way Telegram does, for tests.
func signInit(token string, user string, at time.Time) string {
	v := url.Values{"user": {user}, "auth_date": {fmt.Sprint(at.Unix())}, "query_id": {"AAA"}}
	var pairs []string
	for k := range v {
		pairs = append(pairs, k+"="+v.Get(k))
	}
	sort.Strings(pairs)
	m := hmac.New(sha256.New, []byte("WebAppData"))
	m.Write([]byte(token))
	m2 := hmac.New(sha256.New, m.Sum(nil))
	m2.Write([]byte(strings.Join(pairs, "\n")))
	v.Set("hash", hex.EncodeToString(m2.Sum(nil)))
	return v.Encode()
}

func TestInitDataIsCheckedWithTheBotToken(t *testing.T) {
	good := signInit("T", `{"id":7,"first_name":"Аня"}`, t0)
	u, err := CheckInitData(good, "T", t0.Add(time.Minute), time.Hour)
	if err != nil || u.ID != 7 || u.FirstName != "Аня" {
		t.Fatalf("%+v %v", u, err)
	}
	if _, err := CheckInitData(good, "other", t0, time.Hour); err == nil {
		t.Fatal("another bot's token must not pass")
	}
	if _, err := CheckInitData(strings.Replace(good, "%22id%22%3A7", "%22id%22%3A8", 1), "T", t0, time.Hour); err == nil {
		t.Fatal("a changed user id must not pass")
	}
	if _, err := CheckInitData(good, "T", t0.Add(2*time.Hour), time.Hour); err == nil {
		t.Fatal("old data must not pass")
	}
}

func TestMiniAppShowsTheAccountAndSellsPacks(t *testing.T) {
	srv, calls := fakeAPI(t)
	st := Open(filepath.Join(t.TempDir(), "b.json"))
	_, _ = st.AddTokens(7, 800000, 30, 0, "x", "pack", t0)
	b := newBot(srv, st)
	b.Presence = func() Presence { return Presence{Known: true, Online: true, Mood: 70, Energy: .8} }
	h := b.WebApp()
	page := httptest.NewRecorder()
	h.ServeHTTP(page, httptest.NewRequest("GET", "/app/", nil))
	if page.Code != 200 || !strings.Contains(page.Body.String(), "telegram-web-app.js") {
		t.Fatalf("the page: %d", page.Code)
	}
	post := func(path, body, init string) *httptest.ResponseRecorder {
		r := httptest.NewRequest("POST", path, strings.NewReader(body))
		r.Header.Set("X-Init-Data", init)
		w := httptest.NewRecorder()
		h.ServeHTTP(w, r)
		return w
	}
	if w := post("/app/api/me", "{}", "hash=bad"); w.Code != http.StatusUnauthorized {
		t.Fatalf("no signature, no data: %d", w.Code)
	}
	init := signInit("T", `{"id":7,"first_name":"Аня"}`, t0)
	w := post("/app/api/me", "{}", init)
	var me map[string]any
	_ = json.Unmarshal(w.Body.Bytes(), &me)
	if w.Code != 200 || me["balance"].(map[string]any)["text"] != "800 000 токенов" || me["reina"].(map[string]any)["headline"] != "в сети" || len(me["packs"].([]any)) != 2 {
		t.Fatalf("me: %d %s", w.Code, w.Body.String())
	}
	if w := post("/app/api/invoice", `{"kind":"pack","tokens":500000}`, init); w.Code != 200 || !strings.Contains(w.Body.String(), "pack:500000") {
		t.Fatalf("invoice: %s", w.Body.String())
	}
	if w := post("/app/api/invoice", `{"kind":"pack","tokens":123}`, init); w.Code != 400 {
		t.Fatal("only packs on sale")
	}
	if w := post("/app/api/watch", `{"on":true}`, init); !strings.Contains(w.Body.String(), "уже в сети") || st.Get(7, t0).Watch {
		t.Fatalf("online already: %s", w.Body.String())
	}
	g := st.NewGift(9, 500000, 20, "g", t0)
	if w := post("/app/api/claim", `{"code":"`+g.Code+`"}`, init); w.Code != 200 || st.Get(7, t0).Tokens != 1300000 {
		t.Fatalf("claim: %s", w.Body.String())
	}
	if len(calls("createInvoiceLink")) != 1 {
		t.Fatal("one invoice link")
	}
}
