package update

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"
)

// Release is the newest build published on GitHub (the workflow uploads the zip that Apply installs).
type Release struct {
	Tag       string
	Name      string
	URL       string // the zip to download
	Published time.Time
}

// Latest asks GitHub for the newest release of repo ("owner/name") and picks its zip.
func Latest(ctx context.Context, hc *http.Client, base, repo string) (Release, error) {
	if base == "" {
		base = "https://api.github.com"
	}
	repo = strings.Trim(strings.TrimSpace(repo), "/")
	if strings.Count(repo, "/") != 1 {
		return Release{}, errors.New("update: github_repo must look like owner/name")
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, base+"/repos/"+repo+"/releases/latest", nil)
	if err != nil {
		return Release{}, err
	}
	req.Header.Set("Accept", "application/vnd.github+json")
	resp, err := hc.Do(req)
	if err != nil {
		return Release{}, err
	}
	defer resp.Body.Close()
	if resp.StatusCode == http.StatusNotFound {
		return Release{}, errors.New("update: no releases yet")
	}
	if resp.StatusCode != http.StatusOK {
		return Release{}, fmt.Errorf("update: github: %s", resp.Status)
	}
	var r struct {
		Tag       string    `json:"tag_name"`
		Name      string    `json:"name"`
		Published time.Time `json:"published_at"`
		Assets    []struct {
			Name string `json:"name"`
			URL  string `json:"browser_download_url"`
		} `json:"assets"`
	}
	if err := json.NewDecoder(io.LimitReader(resp.Body, 1<<20)).Decode(&r); err != nil {
		return Release{}, err
	}
	for _, a := range r.Assets {
		if strings.HasSuffix(strings.ToLower(a.Name), ".zip") {
			return Release{Tag: r.Tag, Name: r.Name, URL: a.URL, Published: r.Published}, nil
		}
	}
	return Release{}, fmt.Errorf("update: release %s has no zip", r.Tag)
}

// Download saves url to dst (at most max bytes), through a temporary file so a cut download never looks complete.
func Download(ctx context.Context, hc *http.Client, url, dst string, max int64) error {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return err
	}
	resp, err := hc.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("update: download: %s", resp.Status)
	}
	tmp := dst + ".part"
	f, err := os.Create(tmp)
	if err != nil {
		return err
	}
	n, err := io.Copy(f, io.LimitReader(resp.Body, max+1))
	if cerr := f.Close(); err == nil {
		err = cerr
	}
	if err == nil && n > max {
		err = fmt.Errorf("update: the archive is bigger than %d MB", max>>20)
	}
	if err != nil {
		_ = os.Remove(tmp)
		return err
	}
	return os.Rename(tmp, dst)
}

// installedFile keeps the tag of the release installed last.
func installedFile(dir string) string { return filepath.Join(dir, ".installed_release") }

// Installed is the tag of the release installed last ("" = none recorded).
func Installed(dir string) string {
	b, _ := os.ReadFile(installedFile(dir))
	return strings.TrimSpace(string(b))
}

// MarkInstalled remembers the tag of the release just installed.
func MarkInstalled(dir, tag string) error {
	return os.WriteFile(installedFile(dir), []byte(tag+"\n"), 0o644)
}

// IsNew says whether a release is newer than what runs: a different tag than the one recorded, or, with no record, a
// release published after the running program file was written (a build put in place by hand counts as current).
func IsNew(r Release, dir, exe string) bool {
	if r.Tag == "" {
		return false
	}
	if t := Installed(dir); t != "" {
		return t != r.Tag
	}
	if st, err := os.Stat(exe); err == nil && !r.Published.IsZero() {
		return r.Published.After(st.ModTime().Add(10 * time.Minute))
	}
	return false
}
