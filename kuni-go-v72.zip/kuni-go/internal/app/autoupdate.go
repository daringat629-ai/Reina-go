package app

import (
	"context"
	"fmt"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"kuni/internal/config"
	"kuni/internal/update"
)

// updater looks for a new build on GitHub Releases and installs it (by itself when update.auto is on, or when the owner
// says /update). Installing goes through update.Apply, which keeps the old build and rolls back if the new one fails.
type updater struct {
	cfg    func() *config.Config
	notify func(string)
	http   *http.Client
	api    string // GitHub API base (tests point it elsewhere)
	mu     sync.Mutex
	told   string // the tag the owner was already told about
}

// check looks for a new release; with install it downloads and installs it and asks for a restart. It returns what happened.
func (u *updater) check(ctx context.Context, install bool) (string, error) {
	c := u.cfg()
	if strings.TrimSpace(c.UpdateRepo) == "" {
		return "", fmt.Errorf("update.github_repo is empty")
	}
	u.mu.Lock()
	defer u.mu.Unlock()
	dir := update.Dir()
	r, err := update.Latest(ctx, u.http, u.api, c.UpdateRepo)
	if err != nil {
		return "", err
	}
	if !update.IsNew(r, dir, update.Exe()) {
		return "Новой сборки нет, стоит последняя (" + r.Tag + ").", nil
	}
	name := r.Name
	if name == "" {
		name = r.Tag
	}
	if !install {
		if u.told == r.Tag {
			return "", nil
		}
		u.told = r.Tag
		return fmt.Sprintf("Папик, на GitHub новая сборка %s. Поставить: /update в админ-боте (или включи update.auto).", name), nil
	}
	zip := filepath.Join(c.DataDir, "release.zip")
	if err := update.Download(ctx, u.http, r.URL, zip, 300<<20); err != nil {
		return "", err
	}
	defer os.Remove(zip)
	names, err := update.Apply(zip, dir)
	if err != nil {
		return "", fmt.Errorf("не поставилась: %v", err)
	}
	_ = update.MarkInstalled(dir, r.Tag)
	go func() {
		time.Sleep(3 * time.Second) // let the message go out first
		update.RequestRestart()
	}()
	return fmt.Sprintf("Папик, ставлю сборку %s (%s) и перезапускаюсь. Если новая не поднимется, вернётся прежняя сама.", name, strings.Join(names, ", ")), nil
}

// loop checks every update.check_hours.
func (u *updater) loop(ctx context.Context) {
	select {
	case <-ctx.Done():
		return
	case <-time.After(2 * time.Minute): // let the program settle (and a fresh build confirm itself) first
	}
	for {
		c := u.cfg()
		if c.UpdateRepo != "" && !update.Pending(update.Dir()) {
			msg, err := u.check(ctx, c.UpdateAuto)
			switch {
			case err != nil:
				log.Printf("update: %v", err)
			case msg != "" && !strings.HasPrefix(msg, "Новой сборки нет"):
				u.notify(msg)
			}
		}
		h := c.UpdateCheckHours
		if h <= 0 {
			h = 6
		}
		select {
		case <-ctx.Done():
			return
		case <-time.After(time.Duration(h) * time.Hour):
		}
	}
}

// updater is the one GitHub updater of this program (made on first use).
func (b *boot) updater() *updater {
	if b.upd == nil {
		b.upd = &updater{cfg: b.getCfg, notify: b.owner.Send, http: &http.Client{Timeout: 10 * time.Minute}}
	}
	return b.upd
}
