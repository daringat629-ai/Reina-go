package app

import (
	"context"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"kuni/internal/config"
)

func TestUpdaterTellsTheOwnerOncePerRelease(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte(`{"tag_name":"build-20","name":"v72","published_at":"2099-01-01T00:00:00Z","assets":[{"name":"reina-alpine-tdlib.zip","browser_download_url":"http://x/z"}]}`))
	}))
	defer srv.Close()
	c := &config.Config{UpdateRepo: "daringat629-ai/Reina-go"}
	u := &updater{cfg: func() *config.Config { return c }, http: srv.Client(), api: srv.URL}
	msg, err := u.check(context.Background(), false)
	if err != nil {
		t.Fatal(err)
	}
	// with no installed tag and no program file to compare, the release is not taken as new
	if msg != "" && !strings.Contains(msg, "v72") && !strings.Contains(msg, "Новой сборки нет") {
		t.Fatalf("%q", msg)
	}
	c.UpdateRepo = ""
	if _, err := u.check(context.Background(), false); err == nil {
		t.Fatal("no repo: an error")
	}
}
