package tools

import (
	"context"
	"errors"
	"fmt"
	"strings"
	"time"

	"kuni/internal/telegram"
)

// AdviceTool: her questions to people about her own life. See package advice.
func AdviceTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name: "advice",
		Description: "Your questions about your own life that you ask different people, out of curiosity. action=ask opens a question " +
			"(general words: never names or private details of anyone, e.g. «как понять, что тебе по-настоящему дорог человек?»). " +
			"action=note keeps what the person in this chat answered (the gist in a sentence or two). action=decide closes a " +
			"question with what you think now, after hearing people. action=list shows your questions.",
		Props: []Prop{
			{Name: "action", Type: "string", Desc: "ask, note, decide or list."},
			{Name: "id", Type: "integer", Nullable: true, Desc: "note/decide: the question id."},
			{Name: "text", Type: "string", Nullable: true, Desc: "ask: the question; note: what they said; decide: what you think now."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			if d.Advice == nil {
				return "", errors.New("advice is off")
			}
			now := time.Now()
			switch strings.ToLower(strings.TrimSpace(a.Str("action"))) {
			case "ask":
				q, err := d.Advice.Ask(a.Str("text"), now)
				if err != nil {
					return "", err
				}
				return fmt.Sprintf("Question %d is open. Bring it up with people when a chat is relaxed, and keep their answers with action=note.", q.ID), nil
			case "note":
				if chat.Kind != telegram.ChatPrivate {
					return "", errors.New("note answers only in a private chat")
				}
				q, err := d.Advice.Note(int(a.Int("id")), chat.ID, chat.Title, a.Str("text"), now)
				if err != nil {
					return "", err
				}
				return fmt.Sprintf("Kept. Question %d has %d answers.", q.ID, len(q.Answers)), nil
			case "decide":
				q, err := d.Advice.Decide(int(a.Int("id")), a.Str("text"), now)
				if err != nil {
					return "", err
				}
				return fmt.Sprintf("Decided. «%s» is now part of you.", q.Conclusion), nil
			case "list":
				var b strings.Builder
				for _, q := range d.Advice.All() {
					state := fmt.Sprintf("open, %d answers", len(q.Answers))
					if !q.Closed.IsZero() {
						state = "decided: " + q.Conclusion
					}
					fmt.Fprintf(&b, "%d. %s (%s)\n", q.ID, q.Text, state)
				}
				if b.Len() == 0 {
					return "No questions yet.", nil
				}
				return b.String(), nil
			}
			return "", errors.New("action must be ask, note, decide or list")
		},
	}
}
