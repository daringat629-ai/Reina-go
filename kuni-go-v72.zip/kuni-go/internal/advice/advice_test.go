package advice

import (
	"path/filepath"
	"strings"
	"testing"
	"time"
)

var t0 = time.Date(2026, 11, 1, 12, 0, 0, 0, time.UTC)

func TestQuestionGoesFromPeopleToHerConclusion(t *testing.T) {
	path := filepath.Join(t.TempDir(), "a.json")
	b := Open(path)
	if _, err := b.Ask("эм", t0); err == nil {
		t.Fatal("a question needs a real sentence")
	}
	q, err := b.Ask("как понять, что тебе по-настоящему дорог человек?", t0)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := b.Ask("а если я боюсь сказать ему об этом?", t0); err != nil {
		t.Fatal(err)
	}
	if _, err := b.Ask("третий вопрос сразу?", t0); err == nil {
		t.Fatal("at most two open questions")
	}
	// offered to one person, then the pace holds the next chat back
	if g, ok := b.Offer(7, t0); !ok || g.ID != q.ID {
		t.Fatalf("offer: %+v %v", g, ok)
	}
	if _, ok := b.Offer(8, t0.Add(time.Minute)); ok {
		t.Fatal("not in every chat at once")
	}
	if p, ok := b.Pending(7, t0.Add(time.Minute)); !ok || p.ID != q.ID {
		t.Fatal("waiting for person 7's answer")
	}
	if _, ok := b.Offer(7, t0.Add(2*time.Hour)); ok {
		t.Fatal("the same person is not asked again for days")
	}
	for i, u := range []int64{7, 8, 9} {
		if _, err := b.Note(q.ID, u, "друг", "когда скучаешь, даже если он рядом", t0.Add(time.Duration(i)*time.Hour)); err != nil {
			t.Fatal(err)
		}
	}
	if _, ok := b.Pending(7, t0.Add(4*time.Hour)); ok {
		t.Fatal("answered: no longer pending")
	}
	_, _ = b.Note(q.ID, 9, "друг", "передумал: когда хочется рассказать ему первому", t0.Add(5*time.Hour))
	if r := Open(path).Ready(); len(r) != 1 || len(r[0].Answers) != 3 || !strings.Contains(r[0].Answers[2].Text, "передумал") {
		t.Fatalf("three voices (a person's newer answer replaces the older), kept on disk: %+v", r)
	}
	if p := b.ReadyPrompt(); !strings.Contains(p, "advice decide") || !strings.Contains(p, "скучаешь") {
		t.Fatalf("ready prompt: %s", p)
	}
	if _, err := b.Decide(q.ID, "дорог тот, о ком думаешь, когда тебе хорошо", t0.Add(6*time.Hour)); err != nil {
		t.Fatal(err)
	}
	if _, err := b.Note(q.ID, 10, "x", "поздно", t0); err == nil {
		t.Fatal("a decided question takes no more answers")
	}
	if l := b.LessonsPrompt(); !strings.Contains(l, "what_people_taught_me") || !strings.Contains(l, "о ком думаешь") || !strings.Contains(l, "3 мнений") {
		t.Fatalf("lessons: %s", l)
	}
	if n, _ := b.OpenCount(); n != 1 {
		t.Fatalf("one question still open: %d", n)
	}
}
