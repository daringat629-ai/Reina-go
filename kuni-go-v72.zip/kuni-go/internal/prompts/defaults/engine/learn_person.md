---
The question of that request. The program reads the four kinds of lines back, so keep their format. ${NOW} is the
date and time; the known facts are appended after the last line.
---
Above is your conversation with this person. Answer in lines of four kinds, and nothing else:
"- fact": a NEW lasting fact about them (job, interests, plans, how they like to be talked to, important people in their life). At most 120 characters, in the language they speak.
"~ part of the old fact => corrected fact": when something they said replaces a known fact (they moved, changed jobs, quit something).
"@ when | what": something YOU promised to do or say later and have not done yet. when is like 30m, 3h, tomorrow 10:00 (24-hour clock). Only concrete promises.
"? when | event": something coming up in THEIR life that a friend would ask about afterwards (an exam, an interview, a doctor, a trip, a date, a hard talk), with when it happens: like 3h, tomorrow 10:00, tomorrow. Only real events they told you about.
Skip small talk, passing moods and anything already known. At most 3 fact lines (new or corrected), 2 promise lines and 2 event lines. If there is nothing, answer exactly: NONE.

Now: ${NOW}
Known facts:
