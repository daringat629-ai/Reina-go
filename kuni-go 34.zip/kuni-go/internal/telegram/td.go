package telegram

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"
	"unicode/utf16"
)

// Transport moves raw tdlib JSON requests/updates. The real one is a thin cgo
// wrapper over libtdjson (build tag "tdlib", see td_cgo.go); tests use a fake.
type Transport interface {
	// Send submits one request (a JSON object). Safe for concurrent use.
	Send(req []byte)
	// Receive waits up to timeout for the next response/update; nil on timeout.
	// It is called from a single goroutine.
	Receive(timeout time.Duration) []byte
}

// TDConfig configures the user-account client.
type TDConfig struct {
	APIID      int64
	APIHash    string
	Phone      string // optional; asked on stdin when empty
	DBDir      string // tdlib database directory (login is kept here)
	AppVersion string
	// Prompt asks the operator for "phone number", "verification code" or "cloud password".
	// Default: print to stdout and read a line from stdin.
	Prompt func(what string) string
	// MaxQPS throttles requests: Telegram bans accounts of aggressive 3rd party clients. Default 20.
	MaxQPS int
}

type obj = map[string]any

// TDClient implements Client for a *user account* through tdlib's JSON interface,
// exactly what the C++ project does (TelegramClientImpl + td_api).
type TDClient struct {
	tr  Transport
	cfg TDConfig

	seq     atomic.Int64
	mu      sync.Mutex
	pending map[string]chan obj
	updates chan Message
	events  chan Event
	ev      eventState
	hl      healthState
	sleepFn func(ctx context.Context, d time.Duration) error // tests
	threads sync.Map                                         // "chat:msg" -> topic id of messages seen in forum topics
	ready   chan struct{}
	readyOK sync.Once
	closed  chan struct{}
	myID    atomic.Int64

	cmu      sync.Mutex
	users    map[int64]string
	chats    map[int64]*tdChat
	actions  map[int64]action // chat -> what someone is doing there (typing...), for the chat list
	statuses map[int64]userSt // user -> online status
	folders  []Folder

	tmu      sync.Mutex
	callTime []time.Time

	contactsMu sync.Mutex
	contacts   map[int64]bool
	contactsAt time.Time
}

type tdChat struct {
	ID           int64
	Title        string
	Kind         ChatKind
	Unread       int
	LastReadIn   int64
	LastMsgID    int64
	LastText     string
	LastDate     time.Time
	PhotoFileID  int64
	InChatList   bool
	superOrBasic bool
	groupID      int64 // supergroup_id or basic_group_id
	basic        bool
	// the live state of the chat list
	Pinned, Muted, Archived bool
	Folders                 []int
	Mentions                int
	UserID                  int64 // private chats
}

func NewTD(tr Transport, cfg TDConfig) *TDClient {
	if cfg.MaxQPS <= 0 {
		cfg.MaxQPS = 20
	}
	if cfg.DBDir == "" {
		cfg.DBDir = "tdlib"
	}
	if cfg.Prompt == nil {
		cfg.Prompt = stdinPrompt
	}
	return &TDClient{tr: tr, cfg: cfg, pending: map[string]chan obj{}, updates: make(chan Message, 256), events: make(chan Event, 128),
		ready: make(chan struct{}), closed: make(chan struct{}), users: map[int64]string{}, chats: map[int64]*tdChat{}}
}

func stdinPrompt(what string) string {
	fmt.Printf("[Authentication] required. Please supply %s: ", what)
	var s string
	fmt.Scanln(&s)
	return strings.TrimSpace(s)
}

func (c *TDClient) Updates() <-chan Message { return c.updates }
func (c *TDClient) MyID() int64             { return c.myID.Load() }

// ---- JSON helpers ----

func decode(raw []byte) (obj, error) {
	var m obj
	d := json.NewDecoder(bytes.NewReader(raw))
	d.UseNumber() // ids exceed 2^53 in the wild; keep them exact
	if err := d.Decode(&m); err != nil {
		return nil, err
	}
	return m, nil
}

func str(m obj, k string) string { s, _ := m[k].(string); return s }
func sub(m obj, k string) obj    { s, _ := m[k].(map[string]any); return s }
func arr(m obj, k string) []any  { s, _ := m[k].([]any); return s }
func typ(m obj) string           { return str(m, "@type") }

func num(v any) int64 {
	switch t := v.(type) {
	case json.Number:
		if n, err := t.Int64(); err == nil {
			return n
		}
		f, _ := t.Float64()
		return int64(f)
	case string: // tdlib's JSON interface encodes int64 fields (e.g. my_id) as strings
		n, _ := strconv.ParseInt(t, 10, 64)
		return n
	case float64:
		return int64(t)
	case int64:
		return t
	case int:
		return int64(t)
	}
	return 0
}

func toObj(v any) obj { m, _ := v.(map[string]any); return m }

// ---- request plumbing ----

func (c *TDClient) throttle(ctx context.Context) error {
	for {
		c.tmu.Lock()
		now := time.Now()
		cut := now.Add(-time.Second)
		i := 0
		for i < len(c.callTime) && c.callTime[i].Before(cut) {
			i++
		}
		c.callTime = c.callTime[i:]
		if len(c.callTime) < c.cfg.MaxQPS {
			c.callTime = append(c.callTime, now)
			c.tmu.Unlock()
			return nil
		}
		wait := c.callTime[0].Add(time.Second).Sub(now)
		c.tmu.Unlock()
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-time.After(wait):
		}
	}
}

// call sends a request and waits for its response; tdlib "error" objects become Go errors.
// A flood-wait (429 "retry after N") is waited out and the request repeated: Telegram rejected it, nothing was done.
func (c *TDClient) call(ctx context.Context, req obj) (obj, error) {
	for attempt := 0; ; attempt++ {
		if err := c.waitFlood(ctx); err != nil {
			return nil, err
		}
		resp, err := c.call1(ctx, req)
		if err == nil {
			return resp, nil
		}
		var te *tdError
		if !errors.As(err, &te) {
			return nil, err
		}
		c.hl.record(str(req, "@type"), num(req["chat_id"]), te.Error())
		if te.Code != 429 || attempt >= 2 {
			return nil, err
		}
		wait := floodDelay(te.Message)
		c.hl.flood(wait)
		fmt.Fprintf(os.Stderr, "telegram: flood wait %s on %s\n", wait, str(req, "@type"))
	}
}

// tdError is a tdlib "error" object.
type tdError struct {
	Code    int
	Message string
}

func (e *tdError) Error() string { return fmt.Sprintf("telegram %d: %s", e.Code, e.Message) }

var retryAfterRe = regexp.MustCompile(`(?i)retry after (\d+)`)

// floodDelay reads "Too Many Requests: retry after 12" (capped: a long ban must not freeze her for hours).
func floodDelay(msg string) time.Duration {
	n := 5
	if m := retryAfterRe.FindStringSubmatch(msg); m != nil {
		n, _ = strconv.Atoi(m[1])
	}
	d := time.Duration(n+1) * time.Second
	if d > 90*time.Second {
		d = 90 * time.Second
	}
	return d
}

// waitFlood holds every request back while a flood wait is running.
func (c *TDClient) waitFlood(ctx context.Context) error {
	d := time.Until(c.hl.until())
	if d <= 0 {
		return nil
	}
	return c.sleep(ctx, d)
}

func (c *TDClient) sleep(ctx context.Context, d time.Duration) error {
	if c.sleepFn != nil {
		return c.sleepFn(ctx, d)
	}
	select {
	case <-time.After(d):
		return nil
	case <-ctx.Done():
		return ctx.Err()
	}
}

func (c *TDClient) call1(ctx context.Context, req obj) (obj, error) {
	if err := c.throttle(ctx); err != nil {
		return nil, err
	}
	id := strconv.FormatInt(c.seq.Add(1), 10)
	req["@extra"] = id
	raw, err := json.Marshal(req)
	if err != nil {
		return nil, err
	}
	ch := make(chan obj, 1)
	c.mu.Lock()
	c.pending[id] = ch
	c.mu.Unlock()
	defer func() { c.mu.Lock(); delete(c.pending, id); c.mu.Unlock() }()
	c.tr.Send(raw)
	select {
	case <-ctx.Done():
		return nil, ctx.Err()
	case <-c.closed:
		return nil, errors.New("tdlib closed")
	case resp := <-ch:
		if typ(resp) == "error" {
			return nil, &tdError{Code: int(num(resp["code"])), Message: str(resp, "message")}
		}
		return resp, nil
	}
}

func (c *TDClient) waitReady(ctx context.Context) error {
	select {
	case <-c.ready:
		return nil
	case <-ctx.Done():
		return ctx.Err()
	}
}

// api waits for login and then calls.
func (c *TDClient) api(ctx context.Context, req obj) (obj, error) {
	if err := c.waitReady(ctx); err != nil {
		return nil, err
	}
	return c.call(ctx, req)
}

// Run drives tdlib (authorization, updates) until ctx ends.
func (c *TDClient) Run(ctx context.Context) error {
	c.tr.Send([]byte(`{"@type":"getOption","name":"version"}`)) // starts the client
	done := make(chan struct{})
	go func() {
		defer close(done)
		for ctx.Err() == nil {
			raw := c.tr.Receive(time.Second)
			if raw == nil {
				continue
			}
			m, err := decode(raw)
			if err != nil {
				continue
			}
			c.dispatch(ctx, m)
		}
	}()
	<-ctx.Done()
	// graceful close so tdlib flushes its database.
	c.tr.Send([]byte(`{"@type":"close"}`))
	select {
	case <-c.closed:
	case <-time.After(5 * time.Second):
	}
	<-done
	return nil
}

func (c *TDClient) dispatch(ctx context.Context, m obj) {
	if extra := str(m, "@extra"); extra != "" {
		c.mu.Lock()
		ch := c.pending[extra]
		c.mu.Unlock()
		if ch != nil {
			ch <- m
		}
		return
	}
	switch typ(m) {
	case "updateAuthorizationState":
		c.onAuthState(ctx, sub(m, "authorization_state"))
	case "updateOption":
		if str(m, "name") == "my_id" {
			c.myID.Store(num(sub(m, "value")["value"]))
		}
	case "updateUser":
		u := sub(m, "user")
		c.cmu.Lock()
		c.users[num(u["id"])] = userDisplay(u)
		if st := sub(u, "status"); st != nil {
			if c.statuses == nil {
				c.statuses = map[int64]userSt{}
			}
			c.statuses[num(u["id"])] = statusOf(st)
		}
		c.cmu.Unlock()
	case "updateNewChat":
		c.storeChat(sub(m, "chat"))
	case "updateChatNotificationSettings", "updateChatUnreadMentionCount", "updateChatPosition", "updateChatAddedToList", "updateChatRemovedFromList",
		"updateChatAction", "updateUserStatus", "updateChatFolders":
		c.chatFlagsUpdate(m)
	case "updateChatLastMessage":
		c.cmu.Lock()
		if ch := c.chats[num(m["chat_id"])]; ch != nil {
			if lm := sub(m, "last_message"); lm != nil {
				ch.LastMsgID, ch.LastDate, ch.LastText = num(lm["id"]), time.Unix(num(lm["date"]), 0), contentPreview(sub(lm, "content"))
			}
		}
		c.cmu.Unlock()
	case "updateChatReadInbox":
		c.cmu.Lock()
		if ch := c.chats[num(m["chat_id"])]; ch != nil {
			ch.LastReadIn, ch.Unread = num(m["last_read_inbox_message_id"]), int(num(m["unread_count"]))
		}
		c.cmu.Unlock()
	case "updateChatTitle":
		c.cmu.Lock()
		if ch := c.chats[num(m["chat_id"])]; ch != nil {
			ch.Title = str(m, "title")
		}
		c.cmu.Unlock()
	case "updateMessageContent":
		go c.onContent(ctx, m)
	case "updateMessageInteractionInfo":
		go c.onInteraction(ctx, m)
	case "updateNewMessage":
		msg := sub(m, "message")
		if msg == nil || msg["is_outgoing"] == true {
			return
		}
		go func() { // resolving names may need a round trip; never block the receive loop
			out := c.parseMessage(ctx, msg)
			c.remember(out)
			select {
			case c.updates <- out:
			default:
			}
		}()
	}
}

func (c *TDClient) onAuthState(ctx context.Context, st obj) {
	go func() {
		var err error
		switch typ(st) {
		case "authorizationStateWaitTdlibParameters":
			_, err = c.call(ctx, obj{"@type": "setTdlibParameters", "database_directory": c.cfg.DBDir, "use_message_database": true,
				"use_secret_chats": true, "api_id": c.cfg.APIID, "api_hash": c.cfg.APIHash, "system_language_code": "en",
				"device_model": "Desktop", "application_version": c.cfg.AppVersion})
		case "authorizationStateWaitPhoneNumber":
			phone := c.cfg.Phone
			if phone == "" {
				phone = c.cfg.Prompt("phone number")
			}
			_, err = c.call(ctx, obj{"@type": "setAuthenticationPhoneNumber", "phone_number": phone})
		case "authorizationStateWaitCode":
			_, err = c.call(ctx, obj{"@type": "checkAuthenticationCode", "code": c.cfg.Prompt("verification code")})
		case "authorizationStateWaitPassword":
			_, err = c.call(ctx, obj{"@type": "checkAuthenticationPassword", "password": c.cfg.Prompt("cloud password")})
		case "authorizationStateReady":
			c.readyOK.Do(func() { close(c.ready) })
		case "authorizationStateClosed":
			select {
			case <-c.closed:
			default:
				close(c.closed)
			}
		}
		if err != nil && ctx.Err() == nil {
			fmt.Fprintf(os.Stderr, "telegram auth (%s): %v\n", typ(st), err)
		}
	}()
}

// ---- caches / conversion ----

func userDisplay(u obj) string {
	name := strings.TrimSpace(str(u, "first_name") + " " + str(u, "last_name"))
	if name == "" {
		if un := sub(u, "usernames"); un != nil {
			if a := arr(un, "active_usernames"); len(a) > 0 {
				name, _ = a[0].(string)
			}
		}
	}
	return name
}

func (c *TDClient) userName(ctx context.Context, id int64) string {
	c.cmu.Lock()
	n, ok := c.users[id]
	c.cmu.Unlock()
	if ok {
		return n
	}
	u, err := c.call(ctx, obj{"@type": "getUser", "user_id": id})
	if err != nil {
		return "user " + strconv.FormatInt(id, 10)
	}
	n = userDisplay(u)
	c.cmu.Lock()
	c.users[id] = n
	c.cmu.Unlock()
	return n
}

func (c *TDClient) storeChat(ch obj) *tdChat {
	if ch == nil {
		return nil
	}
	t := &tdChat{ID: num(ch["id"]), Title: str(ch, "title"), Unread: int(num(ch["unread_count"])), LastReadIn: num(ch["last_read_inbox_message_id"]),
		InChatList: len(arr(ch, "chat_lists")) > 0}
	ty := sub(ch, "type")
	switch typ(ty) {
	case "chatTypePrivate", "chatTypeSecret":
		t.Kind = ChatPrivate
	case "chatTypeBasicGroup":
		t.Kind, t.superOrBasic, t.basic, t.groupID = ChatGroup, true, true, num(ty["basic_group_id"])
	case "chatTypeSupergroup":
		t.superOrBasic, t.groupID = true, num(ty["supergroup_id"])
		if ty["is_channel"] == true {
			t.Kind = ChatChannel
		} else {
			t.Kind = ChatGroup
		}
	}
	applyFlags(t, ch)
	if lm := sub(ch, "last_message"); lm != nil {
		t.LastMsgID, t.LastDate, t.LastText = num(lm["id"]), time.Unix(num(lm["date"]), 0), contentPreview(sub(lm, "content"))
	}
	if p := sub(ch, "photo"); p != nil {
		t.PhotoFileID = num(sub(p, "big")["id"])
	}
	c.cmu.Lock()
	c.chats[t.ID] = t
	c.cmu.Unlock()
	return t
}

func (c *TDClient) chatInfo(ctx context.Context, id int64) (*tdChat, error) {
	c.cmu.Lock()
	t := c.chats[id]
	c.cmu.Unlock()
	if t != nil {
		return t, nil
	}
	ch, err := c.api(ctx, obj{"@type": "getChat", "chat_id": id})
	if err != nil {
		return nil, err
	}
	return c.storeChat(ch), nil
}

func contentPreview(content obj) string {
	switch typ(content) {
	case "messageText":
		return str(sub(content, "text"), "text")
	case "messagePhoto":
		return "[photo] " + str(sub(content, "caption"), "text")
	case "messageVoiceNote":
		return "[voice message]"
	case "messageVideo", "messageVideoNote", "messageAnimation":
		return "[video]"
	case "messageDocument":
		return "[file] " + str(sub(content, "document"), "file_name")
	case "messagePoll":
		return "[poll] " + ftext(sub(content, "poll")["question"])
	case "messageSticker":
		return "[sticker] " + str(sub(content, "sticker"), "emoji")
	case "messageAudio":
		return "[audio] " + str(sub(content, "audio"), "title")
	case "messageLocation", "messageVenue":
		return "[location]"
	case "messageContact":
		return "[contact]"
	case "messageDice":
		return "[dice] " + str(content, "emoji")
	case "messageCall":
		return "[call]"
	case "messagePinMessage":
		return "[pinned a message]"
	case "messageChatAddMembers", "messageChatJoinByLink", "messageChatJoinByRequest":
		return "[joined the chat]"
	case "messageChatDeleteMember":
		return "[left the chat]"
	case "messageChatChangeTitle":
		return "[chat renamed]"
	}
	return "[" + typ(content) + "]"
}

// fileRef returns the id and size of a tdlib "file" object.
func fileRef(f obj) (string, int64) {
	if f == nil {
		return "", 0
	}
	return strconv.FormatInt(num(f["id"]), 10), num(f["size"])
}

// ftext reads a tdlib text that is a plain string in old versions and a formattedText in new ones.
func ftext(v any) string {
	switch t := v.(type) {
	case string:
		return t
	case map[string]any:
		return str(t, "text")
	}
	return ""
}

func parsePoll(p obj) *Poll {
	out := &Poll{Question: ftext(p["question"]), Total: int(num(p["total_voter_count"])), Anonymous: p["is_anonymous"] == true, Closed: p["is_closed"] == true}
	if t := sub(p, "type"); typ(t) == "pollTypeRegular" {
		out.Multiple = t["allow_multiple_answers"] == true
	}
	for _, o := range arr(p, "options") {
		oo := toObj(o)
		out.Options = append(out.Options, PollOption{Text: ftext(oo["text"]), Votes: int(num(oo["voter_count"])), Chosen: oo["is_chosen"] == true})
	}
	return out
}

// threadOf reads the forum topic / thread of a message; tdlib moved it from message_thread_id to topic_id.
func threadOf(m obj) int64 {
	if t := num(m["message_thread_id"]); t != 0 {
		return t
	}
	if tp := sub(m, "topic_id"); tp != nil {
		if t := num(tp["forum_topic_id"]); t != 0 {
			return t
		}
		return num(tp["message_thread_id"])
	}
	return 0
}

func (c *TDClient) parseMessage(ctx context.Context, m obj) Message {
	out := Message{ID: num(m["id"]), ChatID: num(m["chat_id"]), Date: time.Unix(num(m["date"]), 0), Outgoing: m["is_outgoing"] == true,
		Edited: num(m["edit_date"]) > 0}
	snd := sub(m, "sender_id")
	switch typ(snd) {
	case "messageSenderUser":
		out.SenderID = num(snd["user_id"])
		out.SenderName = c.userName(ctx, out.SenderID)
	case "messageSenderChat":
		out.SenderID = num(snd["chat_id"])
		c.cmu.Lock()
		if ch := c.chats[out.SenderID]; ch != nil {
			out.SenderName = ch.Title
		}
		c.cmu.Unlock()
	}
	content := sub(m, "content")
	out.Text = contentPreview(content)
	switch typ(content) {
	case "messageText":
		out.Text = str(sub(content, "text"), "text")
	case "messagePhoto":
		out.Media, out.Text = MediaPhoto, str(sub(content, "caption"), "text")
		if sizes := arr(sub(content, "photo"), "sizes"); len(sizes) > 0 {
			f := sub(toObj(sizes[len(sizes)-1]), "photo")
			out.FileID, out.FileSize = strconv.FormatInt(num(f["id"]), 10), num(f["size"])
		}
	case "messageVoiceNote":
		out.Media, out.Text = MediaVoice, str(sub(content, "caption"), "text")
		out.FileID, out.FileSize = fileRef(sub(sub(content, "voice_note"), "voice"))
	case "messageVideo":
		out.Media, out.Text = MediaVideo, str(sub(content, "caption"), "text")
		out.FileID, out.FileSize = fileRef(sub(sub(content, "video"), "video"))
	case "messageVideoNote":
		out.Media, out.Text, out.MediaDetail = MediaVideo, "", "round"
		out.FileID, out.FileSize = fileRef(sub(sub(content, "video_note"), "video"))
	case "messageAnimation":
		out.Media, out.Text, out.MediaDetail = MediaVideo, str(sub(content, "caption"), "text"), "gif"
		out.FileID, out.FileSize = fileRef(sub(sub(content, "animation"), "animation"))
	case "messageSticker":
		st := sub(content, "sticker")
		out.Media, out.Text = MediaSticker, str(st, "emoji")
		out.FileID, out.FileSize = fileRef(sub(st, "sticker"))
	case "messagePoll":
		out.Media = MediaPoll
		out.Poll = parsePoll(sub(content, "poll"))
		out.Text = out.Poll.Question
	case "messageDocument":
		d := sub(content, "document")
		out.Text = str(sub(content, "caption"), "text")
		out.FileName = str(d, "file_name")
		out.FileID, out.FileSize = fileRef(sub(d, "document"))
		out.Media = MediaDocument
		if strings.HasPrefix(str(d, "mime_type"), "image/") { // a photo sent "as a file": see it like a photo
			out.Media = MediaPhoto
		}
	}
	if rt := sub(m, "reply_to"); typ(rt) == "messageReplyToMessage" {
		out.ReplyTo = num(rt["message_id"])
	}
	c.enrich(ctx, m, content, &out)
	out.ThreadID = threadOf(m)
	if out.ThreadID != 0 {
		c.threads.Store(evKey(out.ChatID, out.ID), out.ThreadID)
	}
	if fi := sub(m, "forward_info"); fi != nil {
		o := sub(fi, "origin")
		switch typ(o) {
		case "messageOriginUser":
			out.ForwardFrom = c.userName(ctx, num(o["sender_user_id"]))
		case "messageOriginHiddenUser":
			out.ForwardFrom = str(o, "sender_name")
		case "messageOriginChannel", "messageOriginChat":
			out.ForwardFrom = str(o, "author_signature")
			if out.ForwardFrom == "" {
				out.ForwardFrom = "chat"
			}
		}
	}
	if ii := sub(m, "interaction_info"); ii != nil {
		for _, r := range arr(sub(ii, "reactions"), "reactions") {
			if t := sub(toObj(r), "type"); typ(t) == "reactionTypeEmoji" {
				out.Reactions = append(out.Reactions, str(t, "emoji"))
			}
		}
	}
	if out.Outgoing {
		out.Read = true
	} else {
		c.cmu.Lock()
		if ch := c.chats[out.ChatID]; ch != nil {
			out.Read = out.ID <= ch.LastReadIn
		}
		c.cmu.Unlock()
	}
	return out
}

func (c *TDClient) toChat(t *tdChat) Chat {
	ch := Chat{ID: t.ID, Title: t.Title, Kind: t.Kind, Unread: t.Unread, IsMember: true, LastText: t.LastText, LastDate: t.LastDate}
	c.cmu.Lock()
	c.decorate(&ch, t)
	c.cmu.Unlock()
	return ch
}

// ---- Client: reading ----

func (c *TDClient) Chats(ctx context.Context, limit int) ([]Chat, error) {
	if limit <= 0 {
		limit = 50
	}
	r, err := c.api(ctx, obj{"@type": "getChats", "chat_list": obj{"@type": "chatListMain"}, "limit": limit})
	if err != nil {
		return nil, err
	}
	var out []Chat
	for _, idv := range arr(r, "chat_ids") {
		t, err := c.chatInfo(ctx, num(idv))
		if err != nil {
			continue
		}
		out = append(out, c.toChat(t))
	}
	return out, nil
}

func (c *TDClient) Chat(ctx context.Context, id int64) (Chat, error) {
	t, err := c.chatInfo(ctx, id)
	if err != nil {
		return Chat{}, err
	}
	ch := c.toChat(t)
	if t.superOrBasic {
		// membership / admin status, like the C++ getChatMember(myId) check
		r, err := c.call(ctx, obj{"@type": "getChatMember", "chat_id": id, "member_id": obj{"@type": "messageSenderUser", "user_id": c.MyID()}})
		if err != nil {
			ch.IsMember = t.InChatList // large channels hide the member list
		} else {
			switch typ(sub(r, "status")) {
			case "chatMemberStatusLeft", "chatMemberStatusBanned":
				ch.IsMember = false
			case "chatMemberStatusCreator", "chatMemberStatusAdministrator":
				ch.IsAdmin = true
			}
		}
	}
	return ch, nil
}

func (c *TDClient) SearchChats(ctx context.Context, q string) ([]Chat, error) {
	var ids []int64
	if strings.HasPrefix(q, "@") {
		r, err := c.api(ctx, obj{"@type": "searchPublicChat", "username": strings.TrimPrefix(q, "@")})
		if err == nil {
			ids = append(ids, num(r["id"]))
			c.storeChat(r)
		}
	}
	r, err := c.api(ctx, obj{"@type": "searchChats", "query": strings.TrimPrefix(q, "@"), "limit": 20})
	if err != nil {
		return nil, err
	}
	for _, v := range arr(r, "chat_ids") {
		ids = append(ids, num(v))
	}
	var out []Chat
	seen := map[int64]bool{}
	for _, id := range ids {
		if seen[id] {
			continue
		}
		seen[id] = true
		if t, err := c.chatInfo(ctx, id); err == nil {
			out = append(out, c.toChat(t))
		}
	}
	return out, nil
}

func (c *TDClient) history(ctx context.Context, chatID, from int64, offset, limit int) ([]Message, error) {
	r, err := c.api(ctx, obj{"@type": "getChatHistory", "chat_id": chatID, "from_message_id": from, "offset": offset, "limit": limit})
	if err != nil {
		return nil, err
	}
	return c.parseList(ctx, arr(r, "messages"), true), nil
}

// parseList converts tdlib's newest-first list; reverse makes it oldest-first.
func (c *TDClient) parseList(ctx context.Context, list []any, reverse bool) []Message {
	out := make([]Message, 0, len(list))
	for _, v := range list {
		if m := toObj(v); m != nil {
			out = append(out, c.parseMessage(ctx, m))
		}
	}
	if reverse {
		for i, j := 0, len(out)-1; i < j; i, j = i+1, j-1 {
			out[i], out[j] = out[j], out[i]
		}
	}
	return out
}

func (c *TDClient) Unread(ctx context.Context, chatID int64) ([]Message, error) {
	t, err := c.chatInfo(ctx, chatID)
	if err != nil {
		return nil, err
	}
	if t.Unread <= 0 {
		return nil, nil
	}
	n := t.Unread
	if n > 100 {
		n = 100
	}
	msgs, err := c.history(ctx, chatID, 0, 0, n)
	if err != nil {
		return nil, err
	}
	var out []Message
	for _, m := range msgs {
		if !m.Outgoing && m.ID > t.LastReadIn {
			out = append(out, m)
		}
	}
	return out, nil
}

func (c *TDClient) History(ctx context.Context, chatID, aroundID int64, before, after int) ([]Message, error) {
	if aroundID == 0 {
		return c.history(ctx, chatID, 0, 0, before+1)
	}
	// a negative offset returns `after` newer messages, the anchor, and older ones.
	return c.history(ctx, chatID, aroundID, -after, before+after+1)
}

func (c *TDClient) Message(ctx context.Context, chatID, msgID int64) (Message, error) {
	r, err := c.api(ctx, obj{"@type": "getMessage", "chat_id": chatID, "message_id": msgID})
	if err != nil {
		return Message{}, err
	}
	return c.parseMessage(ctx, r), nil
}

func (c *TDClient) Search(ctx context.Context, q SearchQuery) ([]Message, error) {
	limit := q.Limit
	if limit <= 0 {
		limit = 20
	}
	var req obj
	if q.ChatID != 0 {
		req = obj{"@type": "searchChatMessages", "chat_id": q.ChatID, "query": q.Text, "from_message_id": 0, "offset": 0, "limit": limit}
		if q.SenderID != 0 {
			req["sender_id"] = obj{"@type": "messageSenderUser", "user_id": q.SenderID}
		}
	} else {
		req = obj{"@type": "searchMessages", "chat_list": obj{"@type": "chatListMain"}, "query": q.Text, "offset": "", "limit": limit}
		if !q.Since.IsZero() {
			req["min_date"] = q.Since.Unix()
		}
	}
	r, err := c.api(ctx, req)
	if err != nil {
		return nil, err
	}
	msgs := c.parseList(ctx, arr(r, "messages"), false)
	var out []Message
	for _, m := range msgs {
		if q.SenderID != 0 && m.SenderID != q.SenderID {
			continue
		}
		if !q.Since.IsZero() && m.Date.Before(q.Since) {
			continue
		}
		out = append(out, m)
	}
	return out, nil
}

// MarkRead opens the chat and views its latest message with force_read, like a human opening it.
func (c *TDClient) MarkRead(ctx context.Context, chatID int64) error {
	t, err := c.chatInfo(ctx, chatID)
	if err != nil {
		return err
	}
	if t.LastMsgID == 0 {
		return nil
	}
	if _, err := c.call(ctx, obj{"@type": "viewMessages", "chat_id": chatID, "message_ids": []int64{t.LastMsgID}, "force_read": true}); err != nil {
		return err
	}
	c.cmu.Lock()
	t.Unread, t.LastReadIn = 0, t.LastMsgID
	c.cmu.Unlock()
	return nil
}

// SetOnline toggles the account's online status (the C++ bot only appears online while active).
func (c *TDClient) SetOnline(ctx context.Context, online bool) {
	_, _ = c.api(ctx, obj{"@type": "setOption", "name": "online", "value": obj{"@type": "optionValueBoolean", "value": online}})
}

// Contacts returns the user's contact ids (cached 5 minutes); used by lockdown=contacts_only.
func (c *TDClient) Contacts(ctx context.Context) map[int64]bool {
	c.contactsMu.Lock()
	defer c.contactsMu.Unlock()
	if c.contacts != nil && time.Since(c.contactsAt) < 5*time.Minute {
		return c.contacts
	}
	r, err := c.api(ctx, obj{"@type": "getContacts"})
	if err != nil {
		return c.contacts
	}
	m := map[int64]bool{}
	for _, v := range arr(r, "user_ids") {
		m[num(v)] = true
	}
	c.contacts, c.contactsAt = m, time.Now()
	return m
}

// ---- Client: acting ----

func formatted(text string) obj { return obj{"@type": "formattedText", "text": text} }

func replyTo(id int64) any {
	if id == 0 {
		return nil
	}
	return obj{"@type": "inputMessageReplyToMessage", "message_id": id}
}

func (c *TDClient) send(ctx context.Context, chatID, reply int64, content obj) (Message, error) {
	return c.sendWith(ctx, chatID, reply, content, nil)
}

func (c *TDClient) sendWith(ctx context.Context, chatID, reply int64, content, options obj) (Message, error) {
	req := obj{"@type": "sendMessage", "chat_id": chatID, "reply_to": replyTo(reply), "input_message_content": content}
	if options != nil {
		req["options"] = options
	}
	c.addThread(ctx, req, chatID, reply)
	r, err := c.api(ctx, req)
	if err != nil {
		return Message{}, err
	}
	return c.parseMessage(ctx, r), nil
}

// addThread routes a send into a forum topic: the topic of the message replied to, else the one on ctx.
// Both field names are set (older tdlib: message_thread_id, newer: topic_id); the unknown one is ignored.
func (c *TDClient) addThread(ctx context.Context, req obj, chatID, reply int64) {
	var t int64
	if reply != 0 { // the topic of the message being answered is the right one, whatever the session last looked at
		if v, ok := c.threads.Load(evKey(chatID, reply)); ok {
			t = v.(int64)
		}
	}
	if t == 0 {
		t = ThreadFrom(ctx)
	}
	if t != 0 {
		req["message_thread_id"] = t
		req["topic_id"] = obj{"@type": "messageTopicForum", "forum_topic_id": t}
	}
}

func (c *TDClient) SendText(ctx context.Context, chatID int64, text string, reply int64) (Message, error) {
	return c.send(ctx, chatID, reply, obj{"@type": "inputMessageText", "text": withMentions(text)})
}

var mentionRe = regexp.MustCompile(`\[([^\]\n]{1,64})\]\(tg://user\?id=(\d{1,15})\)`)

// withMentions turns "[Joe](tg://user?id=9)" into the visible text "Joe" plus a text-mention entity, so people
// without a @username can be tagged. Everything else stays plain text (no markdown surprises).
func withMentions(text string) obj {
	locs := mentionRe.FindAllStringSubmatchIndex(text, -1)
	if len(locs) == 0 {
		return formatted(text)
	}
	var b strings.Builder
	var ents []any
	units, last := 0, 0
	u16 := func(s string) int {
		n := 0
		for _, r := range s {
			n += utf16.RuneLen(r)
		}
		return n
	}
	for _, l := range locs {
		before := text[last:l[0]]
		b.WriteString(before)
		units += u16(before)
		label := text[l[2]:l[3]]
		uid, _ := strconv.ParseInt(text[l[4]:l[5]], 10, 64)
		ents = append(ents, obj{"@type": "textEntity", "offset": units, "length": u16(label),
			"type": obj{"@type": "textEntityTypeMentionName", "user_id": uid}})
		b.WriteString(label)
		units += u16(label)
		last = l[1]
	}
	b.WriteString(text[last:])
	return obj{"@type": "formattedText", "text": b.String(), "entities": ents}
}

func (c *TDClient) SendPoll(ctx context.Context, chatID int64, question string, options []string, anonymous, multiple bool, reply int64) (Message, error) {
	if len(options) < 2 || len(options) > 10 {
		return Message{}, errors.New("a poll needs 2-10 options")
	}
	build := func(newShape bool) obj {
		opts := make([]any, len(options))
		for i, o := range options {
			if newShape {
				opts[i] = formatted(o)
			} else {
				opts[i] = o
			}
		}
		var q any = question
		if newShape {
			q = formatted(question)
		}
		return obj{"@type": "inputMessagePoll", "question": q, "options": opts, "is_anonymous": anonymous,
			"type": obj{"@type": "pollTypeRegular", "allow_multiple_answers": multiple}}
	}
	m, err := c.send(ctx, chatID, reply, build(true)) // recent tdlib: formatted texts
	if err != nil && strings.Contains(err.Error(), "400") && strings.Contains(strings.ToLower(err.Error()), "pars") {
		m, err = c.send(ctx, chatID, reply, build(false)) // older tdlib: plain strings
	}
	return m, err
}

func (c *TDClient) VotePoll(ctx context.Context, chatID, msgID int64, options []int) error {
	ids := make([]int, 0, len(options))
	ids = append(ids, options...)
	_, err := c.api(ctx, obj{"@type": "setPollAnswer", "chat_id": chatID, "message_id": msgID, "option_ids": ids})
	return err
}

func (c *TDClient) Pin(ctx context.Context, chatID, msgID int64, silent bool) error {
	_, err := c.api(ctx, obj{"@type": "pinChatMessage", "chat_id": chatID, "message_id": msgID, "disable_notification": silent, "only_for_self": false})
	return err
}

func (c *TDClient) Unpin(ctx context.Context, chatID, msgID int64) error {
	_, err := c.api(ctx, obj{"@type": "unpinChatMessage", "chat_id": chatID, "message_id": msgID})
	return err
}

func (c *TDClient) outboxFile(name string, data []byte) (string, error) {
	if len(data) == 0 { // telegram answers such a send with "InputFile is not specified"
		return "", fmt.Errorf("file %q is empty, nothing to send", name)
	}
	dir, err := filepath.Abs(filepath.Join(c.cfg.DBDir, "outbox"))
	if err != nil {
		return "", err
	}
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return "", err
	}
	p := filepath.Join(dir, fmt.Sprintf("%d_%s", time.Now().UnixNano(), name))
	return p, os.WriteFile(p, data, 0o644)
}

func (c *TDClient) SendPhoto(ctx context.Context, chatID int64, data []byte, caption string, reply int64) (Message, error) {
	p, err := c.outboxFile("photo.jpg", data)
	if err != nil {
		return Message{}, err
	}
	return c.send(ctx, chatID, reply, obj{"@type": "inputMessagePhoto", "photo": obj{"@type": "inputFileLocal", "path": p}, "caption": withMentions(caption)})
}

func (c *TDClient) SendDocument(ctx context.Context, chatID int64, name string, data []byte, caption string, reply int64) (Message, error) {
	p, err := c.outboxFile(filepath.Base(name), data)
	if err != nil {
		return Message{}, err
	}
	return c.send(ctx, chatID, reply, obj{"@type": "inputMessageDocument", "document": obj{"@type": "inputFileLocal", "path": p}, "caption": withMentions(caption)})
}

func (c *TDClient) SendVoice(ctx context.Context, chatID int64, data []byte, reply int64) (Message, error) {
	p, err := c.outboxFile("voice.ogg", data)
	if err != nil {
		return Message{}, err
	}
	return c.send(ctx, chatID, reply, obj{"@type": "inputMessageVoiceNote", "voice_note": obj{"@type": "inputFileLocal", "path": p}})
}

func (c *TDClient) SendSticker(ctx context.Context, chatID int64, fileID string, reply int64) (Message, error) {
	id, err := strconv.ParseInt(fileID, 10, 64)
	if err != nil || id <= 0 {
		return Message{}, fmt.Errorf("bad sticker file id %q", fileID)
	}
	return c.send(ctx, chatID, reply, obj{"@type": "inputMessageSticker", "sticker": obj{"@type": "inputFileId", "id": id}})
}

// Edit changes text; for media messages it edits the caption (see the C++ fix "caption editing for media messages").
func (c *TDClient) Edit(ctx context.Context, chatID, msgID int64, text string) error {
	m, err := c.api(ctx, obj{"@type": "getMessage", "chat_id": chatID, "message_id": msgID})
	if err != nil {
		return err
	}
	if typ(sub(m, "content")) == "messageText" {
		_, err = c.call(ctx, obj{"@type": "editMessageText", "chat_id": chatID, "message_id": msgID,
			"input_message_content": obj{"@type": "inputMessageText", "text": formatted(text)}})
	} else {
		_, err = c.call(ctx, obj{"@type": "editMessageCaption", "chat_id": chatID, "message_id": msgID, "caption": formatted(text)})
	}
	return err
}

func (c *TDClient) Delete(ctx context.Context, chatID, msgID int64) error {
	_, err := c.api(ctx, obj{"@type": "deleteMessages", "chat_id": chatID, "message_ids": []int64{msgID}, "revoke": true})
	return err
}

func (c *TDClient) Forward(ctx context.Context, from, msgID, to int64) error {
	_, err := c.api(ctx, obj{"@type": "forwardMessages", "chat_id": to, "from_chat_id": from, "message_ids": []int64{msgID}})
	return err
}

func (c *TDClient) React(ctx context.Context, chatID, msgID int64, emoji string) error {
	emoji = strings.ReplaceAll(emoji, "️", "") // the chat's reaction list is stored without the variation selector
	_, err := c.api(ctx, obj{"@type": "addMessageReaction", "chat_id": chatID, "message_id": msgID,
		"reaction_type": obj{"@type": "reactionTypeEmoji", "emoji": emoji}, "is_big": false, "update_recent_reactions": true})
	return err
}

func (c *TDClient) Typing(ctx context.Context, chatID int64) error {
	_, err := c.api(ctx, obj{"@type": "sendChatAction", "chat_id": chatID, "action": obj{"@type": "chatActionTyping"}})
	return err
}

func (c *TDClient) Join(ctx context.Context, link string) error {
	link = strings.TrimSpace(link)
	switch {
	case strings.HasPrefix(link, "@"):
		r, err := c.api(ctx, obj{"@type": "searchPublicChat", "username": strings.TrimPrefix(link, "@")})
		if err != nil {
			return err
		}
		_, err = c.call(ctx, obj{"@type": "joinChat", "chat_id": num(r["id"])})
		return err
	case strings.Contains(link, "t.me/") || strings.HasPrefix(link, "http"):
		_, err := c.api(ctx, obj{"@type": "joinChatByInviteLink", "invite_link": link})
		return err
	}
	id, err := strconv.ParseInt(link, 10, 64)
	if err != nil {
		return fmt.Errorf("don't know how to join %q: pass an invite link, @username or chat id", link)
	}
	_, err = c.api(ctx, obj{"@type": "joinChat", "chat_id": id})
	return err
}

func (c *TDClient) Leave(ctx context.Context, chatID int64) error {
	_, err := c.api(ctx, obj{"@type": "leaveChat", "chat_id": chatID})
	return err
}

func (c *TDClient) Ban(ctx context.Context, chatID, userID int64, removeAll bool) error {
	_, err := c.api(ctx, obj{"@type": "banChatMember", "chat_id": chatID,
		"member_id": obj{"@type": "messageSenderUser", "user_id": userID}, "banned_until_date": 0, "revoke_messages": removeAll})
	return err
}

func (c *TDClient) SetMemberTag(ctx context.Context, chatID, userID int64, tag string) error {
	_, err := c.api(ctx, obj{"@type": "setChatMemberTag", "chat_id": chatID, "user_id": userID, "tag": tag})
	return err
}

func memberRole(status obj) string {
	switch typ(status) {
	case "chatMemberStatusCreator":
		return "owner"
	case "chatMemberStatusAdministrator":
		return "admin"
	}
	return "member"
}

func userUsername(u obj) string {
	if un := sub(u, "usernames"); un != nil {
		if a := arr(un, "active_usernames"); len(a) > 0 {
			s, _ := a[0].(string)
			return s
		}
	}
	return str(u, "username")
}

func (c *TDClient) toMember(ctx context.Context, m obj) (Member, bool) {
	sender := sub(m, "member_id")
	if typ(sender) != "messageSenderUser" {
		return Member{}, false
	}
	id := num(sender["user_id"])
	mem := Member{ID: id, Role: memberRole(sub(m, "status"))}
	if u, err := c.call(ctx, obj{"@type": "getUser", "user_id": id}); err == nil {
		mem.Name, mem.Username = userDisplay(u), userUsername(u)
		mem.IsBot = typ(sub(u, "type")) == "userTypeBot"
	} else {
		mem.Name = c.userName(ctx, id)
	}
	return mem, true
}

func (c *TDClient) Members(ctx context.Context, chatID int64, limit int) ([]Member, error) {
	if limit <= 0 || limit > 200 {
		limit = 50
	}
	t, err := c.chatInfo(ctx, chatID)
	if err != nil {
		return nil, err
	}
	var raw []obj
	switch {
	case t.Kind == ChatPrivate:
		u, err := c.call(ctx, obj{"@type": "getUser", "user_id": chatID})
		if err != nil {
			return nil, err
		}
		return []Member{{ID: chatID, Name: userDisplay(u), Username: userUsername(u), Role: "member", IsBot: typ(sub(u, "type")) == "userTypeBot"}}, nil
	case t.basic:
		r, err := c.api(ctx, obj{"@type": "getBasicGroupFullInfo", "basic_group_id": t.groupID})
		if err != nil {
			return nil, err
		}
		for _, v := range arr(r, "members") {
			if m, ok := v.(map[string]any); ok {
				raw = append(raw, m)
			}
		}
	case t.superOrBasic && t.Kind == ChatGroup:
		// administrators first, then the most recent participants
		for _, f := range []string{"supergroupMembersFilterAdministrators", "supergroupMembersFilterRecent"} {
			r, err := c.api(ctx, obj{"@type": "getSupergroupMembers", "supergroup_id": t.groupID, "filter": obj{"@type": f}, "offset": 0, "limit": limit})
			if err != nil {
				if f == "supergroupMembersFilterAdministrators" {
					continue
				}
				return nil, err
			}
			for _, v := range arr(r, "members") {
				if m, ok := v.(map[string]any); ok {
					raw = append(raw, m)
				}
			}
		}
	default:
		return nil, errors.New("members of channels are not visible")
	}
	var out []Member
	seen := map[int64]bool{}
	for _, m := range raw {
		mem, ok := c.toMember(ctx, m)
		if !ok || seen[mem.ID] {
			continue
		}
		seen[mem.ID] = true
		out = append(out, mem)
	}
	sort.SliceStable(out, func(i, j int) bool { return roleRank(out[i].Role) < roleRank(out[j].Role) })
	if len(out) > limit {
		out = out[:limit]
	}
	return out, nil
}

func roleRank(r string) int {
	switch r {
	case "owner":
		return 0
	case "admin":
		return 1
	}
	return 2
}

func (c *TDClient) UserInfo(ctx context.Context, userID int64) (User, error) {
	u, err := c.call(ctx, obj{"@type": "getUser", "user_id": userID})
	if err != nil {
		return User{}, err
	}
	out := User{ID: userID, Name: userDisplay(u), Username: userUsername(u), IsBot: typ(sub(u, "type")) == "userTypeBot", IsContact: u["is_contact"] == true}
	if f, err := c.call(ctx, obj{"@type": "getUserFullInfo", "user_id": userID}); err == nil {
		out.Bio = str(sub(f, "bio"), "text")
		if out.Bio == "" {
			out.Bio = str(f, "bio")
		}
	}
	return out, nil
}

// Block removes the private chat's history and blocks the user (remove_and_ban_chat for private chats).
func (c *TDClient) Block(ctx context.Context, chatID int64) error {
	if _, err := c.api(ctx, obj{"@type": "setMessageSenderBlockList", "sender_id": obj{"@type": "messageSenderUser", "user_id": chatID},
		"block_list": obj{"@type": "blockListMain"}}); err != nil {
		return err
	}
	_, err := c.call(ctx, obj{"@type": "deleteChatHistory", "chat_id": chatID, "remove_from_chat_list": true, "revoke": true})
	return err
}

func (c *TDClient) Download(ctx context.Context, fileID string) ([]byte, error) {
	id, err := strconv.ParseInt(fileID, 10, 64)
	if err != nil {
		return nil, fmt.Errorf("bad file id %q", fileID)
	}
	r, err := c.api(ctx, obj{"@type": "downloadFile", "file_id": id, "priority": 1, "offset": 0, "limit": 0, "synchronous": true})
	if err != nil {
		return nil, err
	}
	path := str(sub(r, "local"), "path")
	if path == "" {
		return nil, errors.New("tdlib returned no local path")
	}
	return os.ReadFile(path)
}

func (c *TDClient) ChatPhoto(ctx context.Context, chatID int64) ([]byte, error) {
	t, err := c.chatInfo(ctx, chatID)
	if err != nil {
		return nil, err
	}
	if t.PhotoFileID == 0 {
		return nil, errors.New("chat has no photo")
	}
	return c.Download(ctx, strconv.FormatInt(t.PhotoFileID, 10))
}

var _ Client = (*TDClient)(nil)
