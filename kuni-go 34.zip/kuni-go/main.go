// Command kuni is the Go port of the Kuni character AI: Telegram client, tools,
// RAG diary with sleep consolidation, working memory, and an OpenAI-compatible
// proxy that gives any LLM client the same memory.
package main

import (
	"context"
	"errors"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"os/signal"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"time"
	_ "time/tzdata" // IANA zones for autonomy.timezone even on minimal images (Alpine)

	"kuni/internal/admin"
	"kuni/internal/agent"
	"kuni/internal/alerts"
	"kuni/internal/autonomy"
	"kuni/internal/config"
	"kuni/internal/debugui"
	"kuni/internal/diary"
	"kuni/internal/imagegen"
	"kuni/internal/live"
	"kuni/internal/llm"
	"kuni/internal/llmui"
	"kuni/internal/maint"
	"kuni/internal/media"
	"kuni/internal/memory"
	"kuni/internal/metrics"
	"kuni/internal/mood"
	"kuni/internal/people"
	"kuni/internal/prompts"
	"kuni/internal/proxy"
	"kuni/internal/reminders"
	"kuni/internal/telegram"
	"kuni/internal/tools"
	"kuni/internal/update"
	"kuni/internal/usage"
	"kuni/internal/util"
	"kuni/internal/work"
)

func main() {
	update.Init()
	if len(os.Args) > 1 && os.Args[1] == "install-service" {
		if err := installService(update.Dir()); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		return
	}
	// a build that was installed from the panel gets one start; if it never confirmed itself, the old one returns
	if update.Boot(update.Dir()) {
		log.Printf("kuni: the new build did not come up, rolled back to the previous one; restarting")
		if err := update.Restart(); err != nil {
			log.Printf("kuni: restart after rollback: %v", err)
		}
	}
	if err := run(); err != nil {
		if errors.Is(err, config.ErrNeedsSetup) {
			fmt.Println(err)
			return
		}
		log.Fatal(err)
	}
	if update.Requested() {
		log.Printf("kuni: restarting into the new build")
		if err := update.Restart(); err != nil {
			log.Fatalf("restart: %v", err)
		}
	}
}

func llmSettings(c *config.Config) llm.Settings {
	s := llm.Settings{CachePrompt: c.CachePrompt, BaseURL: c.LLMBaseURL, EmbeddingBaseURL: c.EmbeddingBaseURL, APIKey: c.LLMAPIKey, Model: c.LLMModel, EmbeddingModel: c.EmbeddingModel}
	s.Reasoning = c.Reasoning
	s.LightModel = c.LightModel
	s.VisionModel = c.VisionModel
	if c.Temperature >= 0 {
		t := c.Temperature
		s.Temperature = &t
	}
	return s
}

func promptVars(c *config.Config) prompts.Vars {
	return prompts.Vars{CharacterName: c.CharacterName, CharacterNickname: c.CharacterNick, PapikName: c.PapikName}
}

func run() error {
	logbuf := util.NewLogBuf(600)
	log.SetOutput(io.MultiWriter(os.Stderr, logbuf))
	started := time.Now()
	holder, err := config.NewHolder(config.FileName)
	if err != nil {
		return err
	}
	cfg := holder.Get()

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	update.OnRestart(stop)
	var wg sync.WaitGroup
	goRun := func(f func()) { wg.Add(1); go func() { defer wg.Done(); f() }() }

	// --- core services ---
	reg := metrics.New()
	reg.Help("kuni_llm_requests_total", "LLM requests by kind and outcome")
	reg.Help("kuni_tool_calls_total", "Tool calls executed")
	reg.Help("kuni_llm_tokens_total", "LLM tokens by model, purpose (reply/ask/diary/sleep/compact/image) and direction")
	reg.Help("kuni_llm_last_prompt_tokens", "Prompt size of the last LLM request by purpose")
	reg.Help("kuni_sessions_active", "Open conversation sessions")

	client := llm.New("", "", "", "", "", cfg.RequestTimeout)
	client.Update(llmSettings(cfg))
	var ownerNote atomic.Pointer[func(string)] // set once Telegram exists
	notifyOwner := func(text string) {
		if f := ownerNote.Load(); f != nil {
			(*f)(text)
		}
	}
	var llmFails = &alerts.Streak{Threshold: 4}
	var llmGate alerts.Gate
	client.Observe = func(kind string, d time.Duration, err error) {
		outcome := "ok"
		if err != nil {
			outcome = "error"
		}
		switch {
		case err == nil:
			if llmFails.OK() {
				notifyOwner("Папик, модель снова отвечает, всё починилось.")
			}
		case !errors.Is(err, context.Canceled) && holder.Get().AlertsEnabled:
			if llmFails.Fail() && llmGate.Allow("llm", time.Hour, time.Now()) {
				notifyOwner(fmt.Sprintf("Папик, модель не отвечает: %d ошибок подряд, последняя: %v. Проверь ключ и баланс на OpenRouter.", llmFails.Count(), err))
			}
		}
		reg.Inc("kuni_llm_requests_total", 1, map[string]string{"kind": kind, "outcome": outcome})
		reg.Observe("kuni_llm_request_seconds", d.Seconds(), map[string]string{"kind": kind})
	}

	_ = os.MkdirAll(cfg.DataDir, 0o755)
	tracker := usage.New(filepath.Join(cfg.DataDir, "usage.json"))
	if cfg.AutonomyTimezone != "" {
		if loc, err := time.LoadLocation(cfg.AutonomyTimezone); err == nil {
			tracker.SetZone(loc) // usage days follow the owner's clock
		}
	}
	client.Guard = func() error { return tracker.Guard(holder.Get().DailyTokenLimit) }
	client.OnCached = func(model, purpose string, cached int) {
		reg.Inc("kuni_llm_cached_tokens_total", float64(cached), map[string]string{"model": model, "purpose": purpose})
		log.Printf("llm: %s request: %d prompt tokens came from the provider cache", purpose, cached)
	}
	client.OnUsageCtx = func(ctx context.Context, model, purpose string, in, out int) {
		if id, ok := llm.ChatFrom(ctx); ok {
			tracker.AddChat(id, model, in, out)
		}
	}
	client.OnUsage = func(model, purpose string, in, out int) {
		if limit := holder.Get().DailyTokenLimit; tracker.Add(model, in, out, limit) {
			notifyOwner(fmt.Sprintf("Папик, я потратила дневной лимит токенов (%d). Сама ничего начинать не буду до завтра, а на сообщения пока отвечаю. Если расход дойдёт до x%d, остановлюсь совсем.", limit, usage.HardFactor))
		}
		pl := map[string]string{"model": model, "purpose": purpose}
		reg.Inc("kuni_llm_calls_total", 1, pl)
		log.Printf("llm: %s request: prompt=%d completion=%d tokens", purpose, in, out)
		reg.Inc("kuni_llm_tokens_total", float64(in), map[string]string{"model": model, "purpose": purpose, "direction": "input"})
		reg.Inc("kuni_llm_tokens_total", float64(out), map[string]string{"model": model, "purpose": purpose, "direction": "output"})
		reg.Set("kuni_llm_last_prompt_tokens", float64(in), pl)
		l := map[string]string{"model": model}
		reg.Inc("llm_usage_input", float64(in), l) // names used by the original Grafana dashboard
		reg.Inc("llm_usage_output", float64(out), l)
		reg.Set("llm_usage_input_gauge", float64(in), l)
		reg.Set("llm_usage_output_gauge", float64(out), l)
	}

	ps, err := prompts.NewStore(cfg.PromptsDir, promptVars(cfg))
	if err != nil {
		return err
	}
	d, err := diary.New(cfg.DiaryDir, client, cfg.ConfidenceFactor, cfg.DiaryTokenTrigger)
	if err != nil {
		return err
	}
	d.SleepPrompt = func() string { return ps.Get(prompts.SleepConsolidator) }

	// hot reload: config.toml and prompt files.
	holder.OnChange(func(c *config.Config) {
		client.Update(llmSettings(c))
		client.HTTP.Timeout = c.RequestTimeout
		d.ConfidenceFactor, d.TokenTrigger = c.ConfidenceFactor, c.DiaryTokenTrigger
		if err := ps.SetVars(promptVars(c)); err != nil {
			log.Printf("prompts: %v", err)
		}
	})
	goRun(func() { holder.Watch(ctx) })
	goRun(func() {
		util.Watch(ctx, 2*time.Second, ps.Files, func(path string) {
			if err := ps.Reload(); err != nil {
				log.Printf("prompts: reload: %v", err)
				return
			}
			log.Printf("prompts: reloaded (%s changed)", filepath.Base(path))
		})
	})

	getCfg := holder.Get
	mediaSvc := func() media.Services { return media.FromConfig(getCfg()) }

	var tg telegram.Client
	if cfg.TelegramEnabled {
		_ = os.MkdirAll(cfg.DataDir, 0o755)
		switch cfg.Mode {
		case "bot":
			if cfg.BotToken == "" {
				return errors.New("[telegram] mode = \"bot\" needs bot_token")
			}
			bot := telegram.NewBot(cfg.BotToken, cfg.TelegramAPI)
			bot.StatePath = filepath.Join(cfg.DataDir, "telegram_state.json")
			tg = bot
		case "user":
			if cfg.TelegramAPIID == 0 || cfg.TelegramHash == "" {
				return errors.New("[telegram] mode = \"user\" needs api_id and api_hash from https://my.telegram.org")
			}
			tr, err := telegram.NewTDJSONTransport()
			if err != nil {
				return err
			}
			td := telegram.NewTD(tr, telegram.TDConfig{APIID: cfg.TelegramAPIID, APIHash: cfg.TelegramHash, Phone: cfg.Phone,
				DBDir: cfg.TDLibDir, AppVersion: "kuni-go"})
			tools.Contacts = func(id int64) bool {
				c, cancel := context.WithTimeout(context.Background(), 15*time.Second)
				defer cancel()
				return td.Contacts(c)[id]
			}
			tg = td
		default:
			return fmt.Errorf("[telegram] mode must be \"user\" or \"bot\", got %q", cfg.Mode)
		}
	} else {
		tg = telegram.NewFake() // keeps tools constructible; nothing ever arrives
	}

	ui := &llmui.Env{TG: tg, LLM: client, Prompts: ps, Media: mediaSvc, Cfg: getCfg}
	gen := &imagegen.Generator{LLM: client, Prompts: ps, Media: mediaSvc, CharacterName: func() string { return getCfg().CharacterName }}
	auto := autonomy.New(filepath.Join(cfg.DataDir, "autonomy.json"), filepath.Join(cfg.DataDir, "autonomy.log"))
	deps := tools.Deps{TG: tg, LLM: client, Diary: d, Prompts: ps, Media: mediaSvc, Cfg: getCfg, UI: ui, Metrics: reg, Images: gen, Mood: mood.New(filepath.Join(cfg.DataDir, "mood.json")),
		Reminders: reminders.New(filepath.Join(cfg.DataDir, "reminders.json")), People: people.New(filepath.Join(cfg.DataDir, "people")), Work: work.New(filepath.Join(cfg.DataDir, "work.json"))}
	dumper := &memory.Dumper{LLM: client, Diary: d, Prompts: ps, CharacterName: func() string { return getCfg().CharacterName },
		WM: memory.WorkingMemory{Path: cfg.WorkingMemoryFile}}

	var ag *agent.Agent
	if cfg.TelegramEnabled {
		ag = agent.New(&agent.Agent{Price: func(m string) usage.Prices { return priceOf(holder.Get())(m) }, Cfg: holder, LLM: client, TG: tg, Diary: d, Prompts: ps, UI: ui, Dumper: dumper, Metrics: reg, Deps: deps, Auto: auto, Usage: tracker, ConfigPath: config.FileName, Started: started})
		goRun(func() {
			if err := tg.Run(ctx); err != nil {
				log.Printf("telegram: %v", err)
				stop()
			}
		})
		goRun(func() { ag.Run(ctx) })
	}

	if cfg.TelegramEnabled {
		send := func(text string) {
			c := getCfg()
			if c.PapikChatID == 0 {
				return
			}
			go func() {
				sctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
				defer cancel()
				if _, err := tg.SendText(sctx, c.PapikChatID, text, 0); err != nil {
					log.Printf("kuni: could not notify the owner: %v", err)
				}
			}()
		}
		ownerNote.Store(&send)
	}

	// --- HTTP: proxy + metrics + debug ---
	dbg := &debugui.UI{Cfg: getCfg, Diary: d, Client: client}
	if ag != nil {
		dbg.Sessions = ag.SessionSummaries
	}
	panel := &admin.Panel{Cfg: getCfg, ConfigPath: config.FileName, Prompts: ps, Diary: d, Metrics: reg, Log: logbuf, Started: started, TG: tg, Frame: tools.LiveFrame, Screens: tools.LiveRunning, Feed: live.Default, Mood: deps.Mood, Auto: auto, Usage: tracker, People: deps.People}
	if ag != nil {
		panel.Ctl = adminCtl{ag}
	}
	if admin.Enabled(cfg) {
		log.Printf("kuni: admin panel on /admin (port %d)", cfg.ProxyPort)
	} else {
		log.Printf("kuni: admin panel is off (set misc.admin_token, 12+ chars, to turn it on)")
	}
	mount := func(mux *http.ServeMux) {
		panel.Mount(mux)
		if cfg.MetricsEnabled {
			mux.Handle("/metrics", reg.Handler())
		}
		if cfg.DebugUI {
			dbg.Mount(mux)
		}
	}
	addr := fmt.Sprintf(":%d", cfg.ProxyPort)
	if cfg.ProxyEnabled {
		bridge := proxy.NewBridge(dumper, func() string {
			return ps.Get(prompts.CharacterBase)
		}, func() time.Duration { return getCfg().SessionIdle })
		goRun(func() { bridge.Run(ctx) })
		srv := &proxy.Server{
			Cfg: getCfg, Diary: d, Prompts: ps, Client: client, Metrics: reg, Bridge: bridge, HijackSystem: true,
			HTTP: &http.Client{Timeout: 10 * time.Minute},
			Tools: func(lastUser string) *tools.Registry {
				return tools.NewRegistry(tools.AskTool(deps))
			},
			Mount: mount,
		}
		goRun(func() {
			log.Printf("kuni: proxy listening on %s (upstream %s)", addr, cfg.LLMBaseURL)
			if err := srv.ListenAndServe(ctx, addr); err != nil {
				log.Printf("proxy: %v", err)
				stop()
			}
		})
	} else if cfg.MetricsEnabled || cfg.DebugUI {
		mux := http.NewServeMux()
		mount(mux)
		hs := &http.Server{Addr: addr, Handler: mux, ReadHeaderTimeout: 10 * time.Second}
		goRun(func() { _ = hs.ListenAndServe() })
		goRun(func() { <-ctx.Done(); _ = hs.Close() })
	}

	goRun(func() { sleepLoop(ctx, d, getCfg) })
	panel.Compare = func(ctx context.Context, model, phrase string) (string, error) {
		sys := ps.Get(prompts.System) + "\n\n" + ps.Get(prompts.CharacterBase) + "\n\n<your_appearance>\n" + ps.Get(prompts.CharacterAppearance) + "\n</your_appearance>\n\n" +
			"TONE: this is your папик. Be at your most toxic and cheeky with him: roast him, tease him, swear at him affectionately, but he is yours.\n" +
			"This is a test of your voice: answer with ONLY the exact text of your next Telegram message to him (several short lines are fine). No tools, no explanations."
		c := llm.WithModel(llm.WithPurpose(ctx, "compare"), model)
		return client.Chat(c, sys, []llm.Message{{Role: "user", Content: phrase}})
	}
	clean := cleaner{cfg: getCfg, tg: tg, LogFile: filepath.Join(update.Dir(), "reina.log")}
	panel.Clean = func() string { return clean.Run(context.Background(), true) }
	goRun(func() { maintLoop(ctx, getCfg, notifyOwner, clean.Run) })
	goRun(func() { reportLoop(ctx, getCfg, tracker, notifyOwner) })
	goRun(func() { watchLoop(ctx, getCfg, tg, notifyOwner) })

	if update.Pending(update.Dir()) {
		goRun(func() { // a freshly installed build proves itself by staying up
			select {
			case <-time.After(update.ConfirmAfter):
				update.Confirm(update.Dir())
				log.Printf("kuni: the new build is confirmed")
				notifyOwner("Папик, обновилась и работаю на новой сборке. Если что-то не так, откат в панели, вкладка «Обновление».")
			case <-ctx.Done():
			}
		})
	}
	log.Printf("kuni: %s is up (telegram=%v, proxy=%v). Ctrl+C to stop gracefully.", cfg.CharacterName, cfg.TelegramEnabled, cfg.ProxyEnabled)
	<-ctx.Done()
	log.Printf("kuni: shutting down, dumping remaining context…")
	wg.Wait()
	return nil
}

// sleepLoop runs one consolidation cycle a minute after start and then every 6 hours.
func sleepLoop(ctx context.Context, d *diary.Diary, cfg func() *config.Config) {
	timer := time.NewTimer(time.Minute)
	defer timer.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-timer.C:
			if err := d.Consolidate(ctx, cfg().SleepMaxTime); err != nil && !errors.Is(err, context.Canceled) {
				log.Printf("kuni: sleep consolidation: %v", err)
			}
			timer.Reset(6 * time.Hour)
		}
	}
}

// adminCtl adapts the agent to the admin panel.
type adminCtl struct{ a *agent.Agent }

func (c adminCtl) Paused() bool                            { return c.a.Paused() }
func (c adminCtl) SetPaused(p bool)                        { c.a.SetPaused(p) }
func (c adminCtl) SessionSummaries() []string              { return c.a.SessionSummaries() }
func (c adminCtl) QueueInfo() any                          { return c.a.QueueInfo() }
func (c adminCtl) NoteOwnerAction(chat int64, text string) { c.a.NoteOwnerAction(chat, text) }
func (c adminCtl) DialogList() any                         { return c.a.DialogList() }
func (c adminCtl) DialogMessages(id int64) (any, error)    { return c.a.DialogMessages(id) }

// maintLoop watches the disk (clears the image cache when it runs low, warns the owner once a day) and makes
// a daily backup. It starts quietly: the first look is a minute after start.
func maintLoop(ctx context.Context, cfg func() *config.Config, notify func(string), clean func(context.Context, bool) string) {
	var warnedDay string
	var lastClean, lastForced time.Time
	timer := time.NewTimer(time.Minute)
	defer timer.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-timer.C:
		}
		timer.Reset(10 * time.Minute)
		c := cfg()
		if !c.MaintEnabled {
			continue
		}
		if time.Since(lastClean) > 24*time.Hour { // a quiet daily tidy-up so the disk never fills up unnoticed
			lastClean = time.Now()
			log.Printf("kuni: daily cleanup: %s", clean(ctx, false))
		}
		if d, err := maint.DiskOf(c.DataDir); err == nil && d.Low(c.DiskWarnPercent) {
			cleaned := ""
			if time.Since(lastForced) > time.Hour { // a thorough pass at most once an hour
				lastForced = time.Now()
				if rep := clean(ctx, true); !strings.HasPrefix(rep, "Чистить нечего") {
					cleaned = " " + rep
					d, _ = maint.DiskOf(c.DataDir)
				}
			}
			if day := time.Now().Format("2006-01-02"); warnedDay != day && d.Low(c.DiskWarnPercent) {
				warnedDay = day
				log.Printf("kuni: disk is low: %s free of %s", maint.Human(d.Free), maint.Human(d.Total))
				hogs := ""
				if top := biggestOnDisk(ctx); top != "" {
					hogs = " Больше всего места жрут: " + top + "."
				}
				notify(fmt.Sprintf("Папик, на диске почти нет места: свободно %s из %s (%.0f%%).%s%s Надо удалить ненужное, например старые архивы.", maint.Human(d.Free), maint.Human(d.Total), d.Percent(), cleaned, hogs))
			}
		}
		if c.BackupEnabled {
			dir := maint.BackupDirOf(c)
			if list := maint.Backups(dir); len(list) == 0 || time.Since(list[0].Time) > 24*time.Hour {
				if p, err := maint.Backup(maint.Sources(c, config.FileName), dir, c.BackupKeep, time.Now()); err != nil {
					log.Printf("kuni: backup: %v", err)
				} else {
					log.Printf("kuni: backup written: %s", p)
				}
			}
		}
	}
}

// biggestOnDisk names the biggest top-level directories of the root filesystem (empty if du is unavailable).
func biggestOnDisk(ctx context.Context) string {
	c, cancel := context.WithTimeout(ctx, 90*time.Second)
	defer cancel()
	top, err := maint.Biggest(c, "/", 5)
	if err != nil || len(top) == 0 {
		return ""
	}
	var parts []string
	for _, d := range top {
		parts = append(parts, fmt.Sprintf("%s (%s)", d.Path, maint.Human(d.Bytes)))
	}
	return strings.Join(parts, ", ")
}

// reportText is the daily message to the owner about yesterday.
func reportText(y usage.Day, week []usage.Day, free *maint.Disk) string {
	var b strings.Builder
	fmt.Fprintf(&b, "Папик, отчёт за %s: %s токенов на входе, %s на выходе, %d запросов", y.Day, kilo(y.In), kilo(y.Out), y.Calls)
	if y.HasPrice {
		fmt.Fprintf(&b, ", примерно $%.2f", y.USD)
	}
	b.WriteString(".")
	var max usage.Day
	for _, d := range week {
		if d.In+d.Out > max.In+max.Out {
			max = d
		}
	}
	if len(week) > 2 && max.Day != "" && max.Day != y.Day {
		fmt.Fprintf(&b, " Самый жирный день недели: %s (%s токенов).", max.Day, kilo(max.In+max.Out))
	}
	if free != nil {
		fmt.Fprintf(&b, " Диск: свободно %s из %s.", maint.Human(free.Free), maint.Human(free.Total))
	}
	return b.String()
}

func kilo(n int64) string {
	switch {
	case n >= 1_000_000:
		return fmt.Sprintf("%.1fM", float64(n)/1e6)
	case n >= 1000:
		return fmt.Sprintf("%dk", n/1000)
	}
	return fmt.Sprint(n)
}

// reportLoop sends the daily report once the configured hour has come (and never twice a day, even across restarts).
func reportLoop(ctx context.Context, cfg func() *config.Config, tr *usage.Tracker, notify func(string)) {
	t := time.NewTicker(5 * time.Minute)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
		}
		c := cfg()
		if !c.ReportEnabled {
			continue
		}
		now := time.Now()
		if loc, err := time.LoadLocation(c.AutonomyTimezone); err == nil && c.AutonomyTimezone != "" {
			now = now.In(loc)
		}
		if now.Hour() < c.ReportHour {
			continue
		}
		price := priceOf(c)
		y, ok := tr.DueReport(price)
		if !ok {
			continue
		}
		var disk *maint.Disk
		if d, err := maint.DiskOf(c.DataDir); err == nil {
			disk = &d
		}
		week := tr.Days(8, price)
		notify(reportText(y, week[:max(len(week)-1, 0)], disk))
	}
}

func priceOf(c *config.Config) func(string) usage.Prices {
	return func(m string) usage.Prices {
		switch {
		case m == c.LLMModel:
			return usage.Prices{In: c.PriceIn, Out: c.PriceOut}
		case c.LightModel != "" && m == c.LightModel:
			return usage.Prices{In: c.LightPriceIn, Out: c.LightPriceOut}
		}
		return usage.Prices{}
	}
}
