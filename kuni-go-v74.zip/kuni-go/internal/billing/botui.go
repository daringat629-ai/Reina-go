package billing

import (
	"context"
	"fmt"
	"log"
	"strconv"
	"strings"
	"time"
)

// Menu buttons: the label people see, an ordinary emoji in front of it when no vector icon is set, and the colour of the button.
type button struct{ label, emoji, style string }

var buttons = []button{
	{"Пополнить", "💳", "primary"}, {"Профиль", "👤", ""},
	{"Рейна", "🌙", ""}, {"Подарить", "🎁", "success"},
	{"Друзьям", "🤝", ""}, {"Помощь", "💬", ""},
}

const (
	btnTopUp   = "Пополнить"
	btnProfile = "Профиль"
	btnReina   = "Рейна"
	btnGift    = "Подарить"
	btnFriends = "Друзьям"
	btnHelp    = "Помощь"
)

// oldLabels are the buttons of the previous menu: people may still have that keyboard open.
var oldLabels = map[string]string{"Подписка": btnTopUp, "Поддержка": btnHelp}

// pressed says which menu button a text is, with or without the emoji in front (Telegram sends back only the text).
func pressed(text string) string {
	t := strings.TrimSpace(text)
	for _, b := range buttons {
		if t == b.label || t == b.emoji+" "+b.label {
			return b.label
		}
	}
	for old, now := range oldLabels {
		if t == old || strings.HasSuffix(t, " "+old) && len([]rune(t)) <= len([]rune(old))+3 {
			return now
		}
	}
	return ""
}

func (b *Bot) menu() map[string]any {
	var icons []string
	if b != nil && b.Icons != nil {
		icons = b.Icons()
	}
	key := func(i int) map[string]any {
		x := buttons[i]
		k := map[string]any{"text": x.emoji + " " + x.label}
		if i < len(icons) && strings.TrimSpace(icons[i]) != "" {
			k["text"], k["icon_custom_emoji_id"] = x.label, strings.TrimSpace(icons[i])
		}
		if x.style != "" {
			k["style"] = x.style
		}
		return k
	}
	return map[string]any{"keyboard": [][]map[string]any{{key(0), key(1)}, {key(2), key(3)}, {key(4), key(5)}}, "resize_keyboard": true, "is_persistent": true}
}

func (b *Bot) loc() *time.Location {
	if b.Loc != nil {
		return b.Loc
	}
	return time.Local
}

func (b *Bot) perConv() int64 {
	if b.PerConv != nil {
		if n := b.PerConv(); n > 0 {
			return n
		}
	}
	return 40000
}

func (b *Bot) presence() Presence {
	if b.Presence == nil {
		return Presence{}
	}
	return b.Presence()
}

func (b *Bot) refTokens() int64 {
	if b.RefTokens == nil {
		return 0
	}
	return b.RefTokens()
}

// convs is "≈ 25 разговоров" for a number of tokens.
func (b *Bot) convs(tokens int64) string {
	if tokens <= 0 {
		return "0 разговоров"
	}
	return "≈ " + plural(int(tokens/b.perConv()), "разговор", "разговора", "разговоров")
}

// tokensWord is "1 250 000 токенов".
func tokensWord(n int64) string {
	w := "токенов"
	switch m10, m100 := n%10, n%100; {
	case m10 == 1 && m100 != 11:
		w = "токен"
	case m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14):
		w = "токена"
	}
	return Num(n) + " " + w
}

func title(plan string) string {
	switch plan {
	case Plus:
		return "Plus"
	case Max:
		return "Max"
	}
	return "Старт"
}

func perDay(n int) string {
	if n <= 0 {
		return "без лимита"
	}
	return fmt.Sprintf("%d в день", n)
}

// bar draws how much of today's free conversations is used: ▰▰▰▱▱▱▱▱▱▱ 30%.
func bar(used, limit int) string {
	if limit <= 0 {
		return "без лимита"
	}
	f := min(float64(used)/float64(limit), 1)
	n := int(f*10 + .5)
	return strings.Repeat("▰", n) + strings.Repeat("▱", 10-n) + fmt.Sprintf(" %d%%", int(f*100+.5))
}

// payload is how a purchase travels through an invoice: "pack:500000", "gift:2000000".
func payload(kind string, tokens int64) string { return fmt.Sprintf("%s:%d", kind, tokens) }

func parsePayload(p string) (kind string, tokens int64, ok bool) {
	k, n, ok := strings.Cut(p, ":")
	v, err := strconv.ParseInt(n, 10, 64)
	if !ok || err != nil || v <= 0 || (k != "pack" && k != "gift") {
		return "", 0, false
	}
	return k, v, true
}

// pack finds the pack behind a payload, if it is still on sale for Stars.
func (b *Bot) pack(p string) (Pack, string, bool) {
	kind, tokens, ok := parsePayload(p)
	if !ok {
		return Pack{}, "", false
	}
	for _, x := range b.Packs() {
		if x.Tokens == tokens && x.Stars > 0 {
			return x, kind, true
		}
	}
	return Pack{}, "", false
}

func (b *Bot) handle(ctx context.Context, u update) {
	switch {
	case u.PreCheckout != nil:
		q := u.PreCheckout
		p, _, on := b.pack(q.Payload)
		ok := q.Currency == "XTR" && on && q.Total == p.Stars
		in := map[string]any{"pre_checkout_query_id": q.ID, "ok": ok}
		if !ok {
			in["error_message"] = "Цена изменилась. Открой «Пополнить» ещё раз."
		}
		if err := b.call(ctx, "answerPreCheckoutQuery", in, nil); err != nil {
			log.Printf("%v", err)
		}
	case u.Callback != nil:
		b.callback(ctx, u)
	case u.Message != nil && (len(u.Message.Photo) > 0 || u.Message.Document != nil) && u.Message.SuccessfulPayment == nil:
		b.receipt(ctx, u)
	case u.Message != nil && u.Message.SuccessfulPayment != nil:
		b.paid(ctx, u)
	case u.Message != nil:
		b.text(ctx, u)
	}
}

// paid applies a successful Stars payment: a pack goes to the balance, a gift becomes a link for a friend.
func (b *Bot) paid(ctx context.Context, u update) {
	m, p := u.Message, u.Message.SuccessfulPayment
	kind, tokens, ok := parsePayload(p.Payload)
	if p.Currency != "XTR" || !ok {
		log.Printf("billing bot: an unexpected payment (%s %d %q) from %d, not applied", p.Currency, p.TotalAmount, p.Payload, m.From.ID)
		return
	}
	now := b.now()
	before := b.Store.Get(m.From.ID, now)
	if kind == "gift" {
		g := b.Store.NewGift(m.From.ID, tokens, p.TotalAmount, p.ChargeID, now)
		b.sendMenu(ctx, m.Chat.ID, fmt.Sprintf("🎁 Подарок готов: %s (%s).\n\nОтправь другу эту ссылку, она сработает один раз:\n%s\n\nИли код: %s", tokensWord(tokens), b.convs(tokens), b.giftLink(g.Code), g.Code))
		if b.OnPaid != nil {
			b.OnPaid(m.From.ID, fmt.Sprintf("подарок %s токенов за ⭐ %d", Num(tokens), p.TotalAmount))
		}
		return
	}
	acc, err := b.Store.AddTokens(m.From.ID, tokens, p.TotalAmount, 0, p.ChargeID, "pack", now)
	if err != nil {
		log.Printf("%v", err)
		return
	}
	msg := fmt.Sprintf("Спасибо! +%s. Баланс: %s (%s). Токены не сгорают. Можно возвращаться к Рейне.", tokensWord(tokens), tokensWord(acc.Tokens), b.convs(acc.Tokens))
	msg += b.inviteReward(ctx, m.From.ID, before)
	b.sendMenu(ctx, m.Chat.ID, msg)
	if b.OnPaid != nil {
		b.OnPaid(m.From.ID, fmt.Sprintf("пакет %s токенов за ⭐ %d", Num(tokens), p.TotalAmount))
	}
}

// inviteReward gives both sides the invite bonus on a person's first purchase; it returns a line for the buyer ("" if none).
func (b *Bot) inviteReward(ctx context.Context, id int64, before User) string {
	bonus := b.refTokens()
	if before.Paid != 0 || before.Referrer == 0 || bonus <= 0 {
		return ""
	}
	now := b.now()
	if _, err := b.Store.AddTokens(id, bonus, 0, 0, fmt.Sprintf("ref:%d:in", id), "bonus", now); err != nil {
		return ""
	}
	if r, err := b.Store.AddTokens(before.Referrer, bonus, 0, 0, fmt.Sprintf("ref:%d:by", id), "bonus", now); err == nil {
		b.send(ctx, before.Referrer, fmt.Sprintf("🤝 Твой друг впервые пополнил баланс. Тебе +%s в подарок, теперь %s.", tokensWord(bonus), tokensWord(r.Tokens)))
	}
	return fmt.Sprintf("\nИ ещё +%s в подарок по приглашению друга.", tokensWord(bonus))
}

func (b *Bot) support() string {
	if b.Support != nil {
		if s := b.Support(); s != "" {
			return s
		}
	}
	return "напиши сюда же, тебе ответят"
}

func (b *Bot) text(ctx context.Context, u update) {
	m := u.Message
	text := strings.TrimSpace(m.Text)
	if b.repeat(m.From.ID, text) {
		return
	}
	low := strings.ToLower(text)
	switch btn := pressed(text); {
	case low == "/terms":
		b.sendMenu(ctx, m.Chat.ID, Terms)
	case low == "/paysupport":
		b.sendMenu(ctx, m.Chat.ID, "Вопрос по оплате или возврату: "+b.support()+". Укажи дату оплаты и сколько токенов купил(а). Возврат звёзд возможен, если токены ещё почти не потрачены.")
	case strings.HasPrefix(low, "/start"):
		b.start(ctx, m.From.ID, m.Chat.ID, strings.TrimSpace(strings.TrimPrefix(text, "/start")))
	case low == "/plans" || low == "/buy" || btn == btnTopUp:
		b.packs(ctx, m.Chat.ID, m.From.ID, "pack")
	case low == "/gift" || btn == btnGift:
		b.packs(ctx, m.Chat.ID, m.From.ID, "gift")
	case low == "/status" || low == "/profile" || btn == btnProfile:
		_ = b.call(ctx, "sendChatAction", map[string]any{"chat_id": m.Chat.ID, "action": "upload_photo"}, nil)
		go b.sendCard(ctx, m.Chat.ID, m.From.ID, m.From.FirstName) // drawing must not hold up other people's taps and payments
	case low == "/reina" || btn == btnReina:
		_ = b.call(ctx, "sendChatAction", map[string]any{"chat_id": m.Chat.ID, "action": "upload_photo"}, nil)
		go b.sendStatus(ctx, m.Chat.ID, m.From.ID)
	case low == "/history":
		b.sendMenu(ctx, m.Chat.ID, b.history(m.From.ID))
	case btn == btnFriends || low == "/invite":
		b.sendMenu(ctx, m.Chat.ID, b.invite(m.From.ID))
	case btn == btnHelp || low == "/help" || low == "/faq":
		b.faqList(ctx, m.Chat.ID)
	case isGiftCode(text):
		b.claim(ctx, m.From.ID, m.Chat.ID, text)
	case strings.HasPrefix(low, "/promo"):
		b.promo(ctx, m.From.ID, m.Chat.ID, strings.TrimSpace(text[len("/promo"):]))
	case IsPromoLike(text) && b.Store.HasPromo(text):
		b.promo(ctx, m.From.ID, m.Chat.ID, text)
	default:
		b.sendMenu(ctx, m.Chat.ID, "Выбери в меню ниже: пополнить, профиль, Рейна, подарить, друзьям или помощь.")
	}
}

func (b *Bot) start(ctx context.Context, id, chat int64, arg string) {
	switch {
	case strings.HasPrefix(arg, "ref"):
		if by, err := strconv.ParseInt(strings.TrimPrefix(arg, "ref"), 10, 64); err == nil && b.refTokens() > 0 && b.Store.Refer(id, by) {
			b.send(ctx, chat, fmt.Sprintf("Тебя пригласил друг: при первом пополнении вам обоим +%s.", tokensWord(b.refTokens())))
		}
	case strings.HasPrefix(arg, "g") && len(arg) > 1:
		b.claim(ctx, id, chat, arg[1:])
		return
	case strings.HasPrefix(arg, "p_") && len(arg) > 2:
		b.promo(ctx, id, chat, arg[2:])
		return
	}
	p := b.presence()
	text := "Здесь твой баланс разговоров с Рейной, её статус и пополнение.\n\n" + p.Text(b.now(), b.loc()) + "\n\n" + b.profile(id)
	if app := b.appURL(); app != "" {
		kb := map[string]any{"inline_keyboard": [][]map[string]any{{{"text": "Открыть приложение", "web_app": map[string]string{"url": app}}}}}
		if err := b.call(ctx, "sendMessage", map[string]any{"chat_id": chat, "text": text, "reply_markup": kb}, nil); err == nil {
			return
		}
	}
	b.sendMenu(ctx, chat, text)
}

// isGiftCode says whether a message is a gift code someone typed in (8 letters and digits from the code alphabet, in capitals).
func isGiftCode(s string) bool {
	if len(s) != 8 {
		return false
	}
	for _, c := range s {
		if !strings.ContainsRune("ABCDEFGHJKLMNPQRSTUVWXYZ23456789", c) {
			return false
		}
	}
	return true
}

// promo applies a promo code someone entered.
func (b *Bot) promo(ctx context.Context, id, chat int64, code string) {
	if code == "" {
		b.sendMenu(ctx, chat, "Напиши так: /promo КОД")
		return
	}
	p, u, err := b.Store.Redeem(code, id, b.now())
	if err != nil {
		b.sendMenu(ctx, chat, "🎟 "+err.Error()+".")
		return
	}
	b.sendMenu(ctx, chat, fmt.Sprintf("🎟 Промокод %s: +%s (%s). Баланс: %s. Токены не сгорают.", p.Code, tokensWord(p.Tokens), b.convs(p.Tokens), tokensWord(u.Tokens)))
}

// PromoLink is the link that applies a promo code in one tap.
func (b *Bot) PromoLink(code string) string {
	if b.Name == "" {
		return ""
	}
	return fmt.Sprintf("https://t.me/%s?start=p_%s", b.Name, NormPromo(code))
}

func (b *Bot) giftLink(code string) string {
	if b.Name == "" {
		return "код " + code
	}
	return fmt.Sprintf("https://t.me/%s?start=g%s", b.Name, code)
}

func (b *Bot) claim(ctx context.Context, id, chat int64, code string) {
	g, err := b.Store.ClaimGift(code, id, b.now())
	if err != nil {
		b.sendMenu(ctx, chat, "🎁 "+err.Error()+".")
		return
	}
	u := b.Store.Get(id, b.now())
	b.sendMenu(ctx, chat, fmt.Sprintf("🎁 Тебе подарили %s (%s)! Баланс: %s. Токены не сгорают.", tokensWord(g.Tokens), b.convs(g.Tokens), tokensWord(u.Tokens)))
	b.send(ctx, g.From, fmt.Sprintf("🎁 Твой подарок (%s) открыли. Спасибо, что делишься Рейной.", tokensWord(g.Tokens)))
}

// packs sends the packs on sale, each with its own Stars payment link, plus the QR button. kind: pack (for yourself) or gift.
func (b *Bot) packs(ctx context.Context, chat, id int64, kind string) {
	var kb [][]map[string]any
	for _, p := range b.Packs() {
		if p.Stars <= 0 {
			continue
		}
		link, err := b.invoiceLink(ctx, kind, p)
		if err != nil {
			log.Printf("%v", err)
			continue
		}
		kb = append(kb, []map[string]any{{"text": fmt.Sprintf("%s токенов · %s · ⭐ %d", Short(p.Tokens), b.convs(p.Tokens), p.Stars), "url": link}})
	}
	if kind == "pack" && b.qrOn() {
		kb = append(kb, []map[string]any{{"text": "📷 Оплатить по QR (" + b.code() + ")", "callback_data": "qr"}})
	}
	l := b.Limits()
	u := b.Store.Get(id, b.now())
	var text string
	if kind == "gift" {
		text = "🎁 Подарить разговоры с Рейной\n\nВыбери пакет и оплати. Тебе придёт ссылка, её откроет друг, и токены упадут ему на баланс. Ссылка срабатывает один раз."
	} else {
		text = fmt.Sprintf("💳 Пополнить баланс\n\nБесплатно: %s, каждый день.\nСверх этого разговоры идут с баланса токенов. Один разговор сейчас в среднем стоит %s.\nТокены не сгорают, автосписаний нет.\n\nТвой баланс: %s (%s).", plural(l.Free, "разговор", "разговора", "разговоров"), tokensWord(b.perConv()), tokensWord(max(u.Tokens, 0)), b.convs(u.Tokens))
	}
	if len(kb) == 0 {
		b.sendMenu(ctx, chat, text+"\n\nСейчас оплата недоступна, попробуй позже.")
		return
	}
	if err := b.call(ctx, "sendMessage", map[string]any{"chat_id": chat, "text": text, "reply_markup": map[string]any{"inline_keyboard": kb}}, nil); err != nil {
		log.Printf("%v", err)
	}
}

// invoiceLink makes (once per pack, kind and price) a payment link that opens the Stars payment right from a button.
func (b *Bot) invoiceLink(ctx context.Context, kind string, p Pack) (string, error) {
	pl := payload(kind, p.Tokens)
	key := fmt.Sprintf("%s/%d", pl, p.Stars)
	b.mu.Lock()
	if b.links == nil {
		b.links = map[string]string{}
	}
	link, ok := b.links[key]
	b.mu.Unlock()
	if ok {
		return link, nil
	}
	name := fmt.Sprintf("Рейна · %s токенов", Short(p.Tokens))
	desc := fmt.Sprintf("%s на баланс, %s с Рейной. Не сгорают, тратятся только сверх бесплатных.", tokensWord(p.Tokens), b.convs(p.Tokens))
	if kind == "gift" {
		name = "Подарок · " + Short(p.Tokens) + " токенов"
		desc = fmt.Sprintf("Подарок другу: %s (%s с Рейной). После оплаты придёт ссылка для друга.", tokensWord(p.Tokens), b.convs(p.Tokens))
	}
	err := b.call(ctx, "createInvoiceLink", map[string]any{"title": name, "description": desc, "payload": pl,
		"provider_token": "", "currency": "XTR", "prices": []map[string]any{{"label": Short(p.Tokens) + " токенов", "amount": p.Stars}}}, &link)
	if err != nil {
		return "", err
	}
	b.mu.Lock()
	b.links[key] = link
	b.mu.Unlock()
	return link, nil
}

// profile is the person's account as text: balance, today's free conversations, plain numbers. No rankings, no streaks.
func (b *Bot) profile(id int64) string {
	now := b.now().In(b.loc())
	u := b.Store.Get(id, now)
	limit := b.Limits().of(u.Plan)
	used, paidToday := 0, 0
	if u.Day == now.Format("2006-01-02") {
		used, paidToday = u.Used, u.PaidToday
	}
	reset := time.Date(now.Year(), now.Month(), now.Day()+1, 0, 0, 0, 0, b.loc())
	var sb strings.Builder
	fmt.Fprintf(&sb, "👤 Профиль\n\nБаланс: %s (%s)", tokensWord(max(u.Tokens, 0)), b.convs(u.Tokens))
	if u.Plan != Free {
		fmt.Fprintf(&sb, "\nТариф %s до %s: %s", title(u.Plan), u.Until.In(b.loc()).Format("02.01.2006"), perDay(limit))
	}
	label := "Бесплатно сегодня"
	if u.Plan != Free {
		label = "По тарифу сегодня"
	}
	fmt.Fprintf(&sb, "\n\n%s: %d", label, used)
	if limit > 0 {
		fmt.Fprintf(&sb, " из %d\n%s\nОбновится в %s", limit, bar(used, limit), reset.Format("00:00, 02.01"))
	}
	if paidToday > 0 {
		fmt.Fprintf(&sb, "\nС баланса сегодня: %s", plural(paidToday, "разговор", "разговора", "разговоров"))
	}
	fmt.Fprintf(&sb, "\n\nРазговоров всего: %d", u.Total)
	if u.Spent > 0 {
		fmt.Fprintf(&sb, "\nПотрачено с баланса: %s", tokensWord(u.Spent))
	}
	if !u.Joined.IsZero() {
		fmt.Fprintf(&sb, "\nС нами с %s", u.Joined.In(b.loc()).Format("02.01.2006"))
	}
	if u.Paid > 0 {
		fmt.Fprintf(&sb, "\nПокупок: %d", u.Paid)
	}
	return sb.String()
}

var kindNames = map[string]string{"": "тариф", "pack": "пакет", "qr": "пакет по QR", "gift": "подарок другу", "gift_in": "подарок тебе", "bonus": "бонус", "promo": "промокод"}

// history lists the person's purchases, gifts and bonuses.
func (b *Bot) history(id int64) string {
	ps := b.Store.History(id, 15)
	if len(ps) == 0 {
		return "📜 История\n\nПокупок пока нет. Бесплатные разговоры обновляются каждый день, а пополнить баланс можно в «Пополнить»."
	}
	var sb strings.Builder
	sb.WriteString("📜 История\n")
	for _, p := range ps {
		what := kindNames[p.Kind]
		amount := ""
		switch {
		case p.Tokens > 0:
			amount = "+" + Short(p.Tokens) + " токенов"
			if p.Kind == "gift" {
				amount = Short(p.Tokens) + " токенов"
			}
		case p.Days > 0:
			amount = title(p.Plan) + " на " + days(p.Days)
		}
		paid := ""
		switch {
		case p.Stars > 0:
			paid = fmt.Sprintf(" · ⭐ %d", p.Stars)
		case p.Som > 0:
			paid = " · " + b.Price(p.Som)
		}
		fmt.Fprintf(&sb, "\n%s · %s · %s%s", p.At.In(b.loc()).Format("02.01.2006"), what, amount, paid)
	}
	u := b.Store.Get(id, b.now())
	if gs := b.Store.GiftsFrom(id); len(gs) > 0 {
		sb.WriteString("\n\nТвои подарки:")
		for _, g := range gs {
			state := "ещё не открыт: " + b.giftLink(g.Code)
			if g.To != 0 {
				state = "открыт " + g.Claimed.In(b.loc()).Format("02.01")
			}
			fmt.Fprintf(&sb, "\n%s токенов · %s", Short(g.Tokens), state)
		}
	}
	fmt.Fprintf(&sb, "\n\nПотрачено с баланса: %s · сейчас на балансе: %s", tokensWord(u.Spent), tokensWord(max(u.Tokens, 0)))
	return sb.String()
}

func (b *Bot) invite(id int64) string {
	bonus := b.refTokens()
	if bonus <= 0 || b.Name == "" {
		return "Приглашения сейчас выключены."
	}
	all, paid := b.Store.Invited(id)
	return fmt.Sprintf("🤝 Позови друга\n\nКогда друг впервые пополнит баланс, вам обоим +%s (%s).\n\nТвоя ссылка:\nhttps://t.me/%s?start=ref%d\n\nПриглашено: %d, пополнили: %d.", tokensWord(bonus), b.convs(bonus), b.Name, id, all, paid)
}

func (b *Bot) qrOn() bool {
	if b.QR == nil || b.OnReceipt == nil {
		return false
	}
	for _, p := range b.Packs() {
		if p.Price > 0 {
			return len(b.QR()) > 0
		}
	}
	return false
}

// faq is the questions people ask most, answered from the real numbers.
func (b *Bot) faq() [][2]string {
	l := b.Limits()
	return [][2]string{
		{"Что такое токены?", fmt.Sprintf("Токены — это мера того, сколько работы делает модель, когда Рейна читает переписку, вспоминает и отвечает. Чем длиннее и сложнее разговор, тем больше токенов. Сейчас один разговор в среднем стоит %s.", tokensWord(b.perConv()))},
		{"Сколько можно бесплатно?", fmt.Sprintf("%s в день, каждый день. Счётчик обновляется в полночь. Сверх этого разговоры идут с баланса токенов.", plural(l.Free, "разговор", "разговора", "разговоров"))},
		{"Что считается разговором?", "Один разговор — это один ответ Рейны на твои новые сообщения. Несколько сообщений подряд считаются одним разговором."},
		{"Токены сгорают?", "Нет. Купленные и подаренные токены лежат на балансе без срока, автосписаний нет."},
		{"Как подарить?", "Нажми «Подарить», выбери пакет и оплати. Придёт ссылка, отправь её другу: когда он её откроет, токены упадут ему на баланс."},
		{"Что значит статус Рейны?", "«В сети» — она сейчас отвечает кому-то. «Спит» — у неё ночь: написать можно, но ответ будет сонным. В «Рейна» можно включить уведомление, когда она появится в сети."},
		{"Это живой человек?", "Нет. Рейна — ИИ-персонаж, она сама так скажет, если спросить."},
		{"Возврат и проблемы с оплатой", "Напиши /paysupport с датой и суммой. Возврат возможен, если токены ещё почти не потрачены."},
	}
}

func (b *Bot) faqList(ctx context.Context, chat int64) {
	var kb [][]map[string]any
	for i, q := range b.faq() {
		kb = append(kb, []map[string]any{{"text": q[0], "callback_data": fmt.Sprintf("faq:%d", i)}})
	}
	text := "💬 Помощь\n\nВыбери вопрос. Если ответа нет: " + b.support() + ".\nУсловия: /terms"
	if err := b.call(ctx, "sendMessage", map[string]any{"chat_id": chat, "text": text, "reply_markup": map[string]any{"inline_keyboard": kb}}, nil); err != nil {
		log.Printf("%v", err)
	}
}

func (b *Bot) watchKeyboard(id int64) map[string]any {
	u := b.Store.Get(id, b.now())
	row := []map[string]any{{"text": "🔔 Сообщить, когда будет в сети", "callback_data": "watch:on"}}
	if u.Watch {
		row = []map[string]any{{"text": "🔕 Не сообщать", "callback_data": "watch:off"}}
	}
	kb := [][]map[string]any{row}
	if h := b.her(); h != "" {
		kb = append(kb, []map[string]any{{"text": "Написать Рейне", "url": "https://t.me/" + h}})
	}
	return map[string]any{"inline_keyboard": kb}
}

func (b *Bot) appURL() string {
	if b.AppURL == nil {
		return ""
	}
	return strings.TrimSpace(b.AppURL())
}

func (b *Bot) her() string {
	if b.Her == nil {
		return ""
	}
	return strings.TrimPrefix(strings.TrimSpace(b.Her()), "@")
}

// callback handles inline buttons.
func (b *Bot) callback(ctx context.Context, u update) {
	q := u.Callback
	_ = b.call(ctx, "answerCallbackQuery", map[string]any{"callback_query_id": q.ID}, nil)
	if q.Message == nil || b.repeat(q.From.ID, "cb:"+q.Data) {
		return
	}
	chat := q.Message.Chat.ID
	switch {
	case q.Data == "hist":
		b.sendMenu(ctx, chat, b.history(q.From.ID))
	case q.Data == "topup":
		b.packs(ctx, chat, q.From.ID, "pack")
	case strings.HasPrefix(q.Data, "faq:"):
		i, err := strconv.Atoi(strings.TrimPrefix(q.Data, "faq:"))
		if f := b.faq(); err == nil && i >= 0 && i < len(f) {
			b.sendMenu(ctx, chat, "❔ "+f[i][0]+"\n\n"+f[i][1])
		}
	case q.Data == "watch:on":
		if b.presence().Online {
			b.send(ctx, chat, "🟢 Рейна уже в сети, можно писать.")
			return
		}
		b.Store.SetWatch(q.From.ID, true)
		b.send(ctx, chat, "🔔 Напишу, когда Рейна появится в сети. Один раз.")
	case q.Data == "watch:off":
		b.Store.SetWatch(q.From.ID, false)
		b.send(ctx, chat, "🔕 Уведомление выключено.")
	case q.Data == "qr" && b.qrOn():
		var kb [][]map[string]any
		var list strings.Builder
		for _, p := range b.Packs() {
			if p.Price > 0 {
				kb = append(kb, []map[string]any{{"text": fmt.Sprintf("%s токенов · %s", Short(p.Tokens), b.Price(p.Price)), "callback_data": fmt.Sprintf("qr:%d", p.Tokens)}})
				if a := b.approx(p.Price); a != "" {
					list.WriteString(fmt.Sprintf("\n%s токенов: %s (%s)", Short(p.Tokens), b.Price(p.Price), a))
				}
			}
		}
		_ = b.call(ctx, "sendMessage", map[string]any{"chat_id": chat, "text": "📷 Оплата по QR\n\nВыбери пакет. Потом переведёшь сумму по QR и пришлёшь скрин чека, токены начислятся после проверки." + b.ratesNote(list.String()), "reply_markup": map[string]any{"inline_keyboard": kb}}, nil)
	case strings.HasPrefix(q.Data, "qr:") && b.qrOn():
		tokens, _ := strconv.ParseInt(strings.TrimPrefix(q.Data, "qr:"), 10, 64)
		var p Pack
		for _, x := range b.Packs() {
			if x.Tokens == tokens && x.Price > 0 {
				p = x
			}
		}
		if p.Tokens == 0 {
			b.send(ctx, chat, "Этот пакет сейчас недоступен, открой «Пополнить» ещё раз.")
			return
		}
		r := b.Store.NewRequest(q.From.ID, q.From.FirstName, p.Tokens, p.Price, b.now())
		cur := ""
		if a := b.approx(p.Price); a != "" {
			cur = "\nВ другой валюте это примерно " + a + ". Если карта в другой валюте, банк сам переведёт по своему курсу, главное, чтобы пришло " + b.Price(p.Price) + "."
		}
		caption := fmt.Sprintf("Заявка %s: %s, %s.%s\n\n1. Отсканируй QR в приложении банка и переведи ровно %s.\n2. В комментарии к переводу напиши код: %s\n3. Пришли сюда скрин чека.\n\nТокены начислятся после проверки, обычно быстро.", r.Code, tokensWord(p.Tokens), b.Price(p.Price), cur, b.Price(p.Price), r.Code)
		if err := b.sendPhotoMarkup(ctx, chat, b.QR(), caption, b.menu()); err != nil {
			log.Printf("billing bot: qr: %v", err)
			b.send(ctx, chat, "Не получилось отправить QR, попробуй позже или напиши в поддержку.")
		}
	}
}

// RunWatch tells the people who asked when Reina comes online (once each).
func (b *Bot) RunWatch(ctx context.Context) {
	was := b.presence().Online
	for {
		select {
		case <-ctx.Done():
			return
		case <-time.After(20 * time.Second):
		}
		on := b.presence().Online
		if on && !was {
			text := "🟢 Рейна в сети. Самое время написать ей."
			if h := b.her(); h != "" {
				text = "🟢 Рейна в сети. Самое время написать: @" + h
			}
			for _, id := range b.Store.TakeWatchers() {
				b.send(ctx, id, text)
			}
		}
		was = on
	}
}

// RunReminders tells people a day before an old paid plan ends, once per plan end.
func (b *Bot) RunReminders(ctx context.Context) {
	for {
		for _, u := range b.Store.Ending(b.now(), 24*time.Hour) {
			b.sendMenu(ctx, u.ID, fmt.Sprintf("Твой тариф %s заканчивается %s. Дальше остаются бесплатные разговоры каждый день, а сверх них можно пополнить баланс токенов в «Пополнить».", title(u.Plan), u.Until.In(b.loc()).Format("02.01 в 15:04")))
		}
		select {
		case <-ctx.Done():
			return
		case <-time.After(30 * time.Minute):
		}
	}
}

// Terms are the short conditions shown by /terms (Telegram asks bots that take payment to have them).
const Terms = `Условия Orvi

1. Рейна — ИИ-персонаж, а не человек. Её ответы создаёт программа и могут быть неточными; не используй их как медицинский, юридический или финансовый совет.
2. Каждый день есть бесплатные разговоры. Сверх них разговоры оплачиваются токенами с баланса: каждый ответ списывает столько токенов, сколько он реально стоил. Токены не сгорают, автосписаний нет.
3. Оплата в Telegram Stars или переводом по QR. После оплаты токены начисляются сразу (Stars) или после проверки перевода (QR).
4. Вопросы по оплате и возврату: /paysupport. Возврат возможен, если токены ещё почти не потрачены.
5. Переписка хранится на сервере, чтобы Рейна помнила разговор. Мы не продаём и не передаём её третьим лицам.
6. Запрещено использовать Рейну для спама, обмана и вреда людям: такие аккаунты могут быть ограничены без возврата.`
