package prompts

import (
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"
)

// Every replacement of a prompt keeps the text it replaces, so that a change that turned out worse can be taken back: the last
// maxHistory versions of each prompt live in <prompts dir>/.history/<name>/<time>.md (a folder name has "/" turned into "__").

const maxHistory = 30

// Version is one saved text of a prompt.
type Version struct {
	ID   string    `json:"id"`
	At   time.Time `json:"at"`
	Size int       `json:"size"`
	Head string    `json:"head"` // the first line of the text, to recognise it
}

func (s *Store) histDir(name string) string {
	return filepath.Join(s.Dir, ".history", strings.ReplaceAll(name, "/", "__"))
}

// snapshot saves the text that is about to be replaced (nothing when it is empty or equal to the newest version).
func (s *Store) snapshot(name string, old []byte) {
	if len(strings.TrimSpace(string(old))) == 0 {
		return
	}
	dir := s.histDir(name)
	if vs := s.History(name); len(vs) > 0 {
		if last, err := os.ReadFile(filepath.Join(dir, vs[0].ID+".md")); err == nil && string(last) == string(old) {
			return
		}
	}
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return
	}
	id := fmt.Sprintf("%d", time.Now().UnixNano())
	_ = os.WriteFile(filepath.Join(dir, id+".md"), old, 0o644)
	vs := s.History(name)
	for i := maxHistory; i < len(vs); i++ {
		_ = os.Remove(filepath.Join(dir, vs[i].ID+".md"))
	}
}

// History lists the saved versions of a prompt, newest first.
func (s *Store) History(name string) []Version {
	if !known[name] {
		return nil
	}
	ents, err := os.ReadDir(s.histDir(name))
	if err != nil {
		return nil
	}
	var out []Version
	for _, e := range ents {
		id := strings.TrimSuffix(e.Name(), ".md")
		if id == e.Name() {
			continue
		}
		b, err := os.ReadFile(filepath.Join(s.histDir(name), e.Name()))
		if err != nil {
			continue
		}
		var ns int64
		fmt.Sscanf(id, "%d", &ns)
		head := ""
		for _, l := range strings.Split(StripFrontMatter(string(b)), "\n") {
			if strings.TrimSpace(l) != "" {
				head = strings.TrimSpace(l)
				break
			}
		}
		if r := []rune(head); len(r) > 90 {
			head = string(r[:90]) + "…"
		}
		out = append(out, Version{ID: id, At: time.Unix(0, ns), Size: len(b), Head: head})
	}
	sort.Slice(out, func(i, j int) bool { return out[i].At.After(out[j].At) })
	return out
}

// Version returns the text of one saved version.
func (s *Store) Version(name, id string) (string, error) {
	if !known[name] || id == "" || strings.ContainsAny(id, "/\\.") {
		return "", os.ErrNotExist
	}
	b, err := os.ReadFile(filepath.Join(s.histDir(name), id+".md"))
	return string(b), err
}

// Restore puts a saved version back (the text it replaces is kept in the history as well, so a restore can be undone too).
func (s *Store) Restore(name, id string) error {
	t, err := s.Version(name, id)
	if err != nil {
		return err
	}
	return s.Write(name, t)
}
