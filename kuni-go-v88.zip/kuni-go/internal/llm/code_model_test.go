package llm

import "testing"

func TestCodeModelRouting(t *testing.T) {
	s := Settings{Model: "main", FastModel: "fast"}
	if s.modelFor("code") != "fast" {
		t.Fatal("code falls back to the fast model")
	}
	s.CodeModel, s.CodeBaseURL, s.CodeAPIKey = "mercury-2.5", "https://openrouter.ai/api/v1/", "k"
	if s.modelFor("code") != "mercury-2.5" || s.modelFor("reply") != "main" {
		t.Fatal("only code requests use the code model")
	}
	e := s.endpointFor("mercury-2.5")
	if e.BaseURL != "https://openrouter.ai/api/v1/" || e.APIKey != "k" {
		t.Fatalf("own endpoint expected: %+v", e)
	}
	if s.endpointFor("main").BaseURL == "https://openrouter.ai/api/v1/" {
		t.Fatal("the main model must keep its endpoint")
	}
	if (Settings{Model: "main"}).modelFor("code") != "main" {
		t.Fatal("no code and no fast model: the main one")
	}
}
