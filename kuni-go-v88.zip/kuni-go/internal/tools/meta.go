package tools

// Meta is what the agent needs to know about a tool besides calling it. These facts used to live in four lists of
// names inside the agent (parallelSafe, quietTools, lazyGroups, autoSendTools): adding a tool meant editing another
// package, and forgetting one list went unnoticed. Now they are part of the tool; the catalog below fills them in
// for the built-in tools by name, so the whole policy can be read in one place.
type Meta struct {
	// Group is the lazy group that hides the tool until it is unlocked ("" = always visible). See Registry.Lazy.
	Group string
	// ReadOnly tools only look: several of them in one round run at the same time, and they are not journaled.
	ReadOnly bool
	// Quiet tools are bookkeeping (mood, waiting, opening a chat): neither a deed for the journal nor work she owes
	// the person a report about.
	Quiet bool
	// Idle tools do nothing on purpose (wait, pause, skip): a round of only idle calls ends the turn.
	Idle bool
	// Sends tools start or push a conversation: in her autonomous sessions they count against the daily limits.
	Sends bool
	// Repeatable tools may do something new when called again with the same arguments (the next browser step,
	// scrolling her Telegram screen), so the "you already called this" guard leaves them alone.
	Repeatable bool
}

// groupInfo describes each lazy group for the #more_tools tool.
var groupInfo = map[string]string{
	"media":   "photos/selfies, voice messages, stickers, chat avatar",
	"edit":    "edit/delete own messages, forward, view message context",
	"admin":   "moderation, leave chat, ban",
	"search":  "search messages across chats",
	"read":    "open links and read files (documents) people sent",
	"polls":   "create polls, vote in polls, pin/unpin messages",
	"plan":    "reminders: remind someone later, list or cancel reminders",
	"make":    "make files: a Word/PDF document from Markdown, an Excel table, a chart picture, a QR code, a calendar event (.ics)",
	"life":    "the owner's money book with budgets, habits and measurements (weight, sleep, steps), birthdays and yearly dates, the map (places nearby, addresses, routes)",
	"util":    "exact dates and time zones (days between, weekday, add days), unit conversion, fair random (dice, coin, pick, shuffle)",
	"desktop": "a virtual desktop of her own: start graphical programs (office, editors, any app), look at the screen, move the mouse, click, type",
	"browser": "a real web browser: open sites, search the web, click, fill forms, send screenshots",
	"system":  "shell commands, a file manager (write, edit, move, delete, find the biggest folders), machine health (memory, disk, load), running python/node code, notes and to-do list, process and service control, recurring tasks and background monitors that alert him, network checks, zip/tar archives, RSS feeds, hashes and exact text tools, looking at image files (OCR), editing pictures, git, downloading video/music from links, reading SQLite databases, a digest of what happened in all chats, messages sent at a chosen time, her own Telegram profile, an exact calculator, ssh to other machines, speech-to-text for audio/video files, document conversion (pdf/docx), backups, her own log, her own settings, an ignore list (stop reacting to a chat or a person), the white list of people who may use her slash commands, searching inside files, Wikipedia/GitHub/geoip lookups, weather, crypto and exchange rates, downloads, files, archives, read any chat, join a group by link, write into another chat, the Telegram app as a screen (chat list, folders, open a chat, scroll, reply, react, press bot buttons) that the owner watches live, every Telegram action in any chat (search, members, pin, forward, files), web search, read any file (pdf/docx/xlsx), call APIs like GitHub, his e-mail and calendar, long jobs in the background",
}

// Groups lists the lazy groups (name -> what is in it).
func Groups() map[string]string {
	out := make(map[string]string, len(groupInfo))
	for k, v := range groupInfo {
		out[k] = v
	}
	return out
}

// catalog is the metadata of the built-in tools.
var catalog = func() map[string]Meta {
	m := map[string]Meta{}
	set := func(f func(*Meta), names ...string) {
		for _, n := range names {
			x := m[n]
			f(&x)
			m[n] = x
		}
	}
	group := func(g string, names ...string) { set(func(x *Meta) { x.Group = g }, names...) }
	group("media", "take_photo", "record_audio", "sticker_list", "sticker_find", "sticker_send", "sticker_save", "get_chat_photo")
	group("edit", "edit_message_text", "remove_message", "forward_message", "view_messages_around")
	group("admin", "group_admin_remove_message", "group_admin_ban_user", "group_admin_set_user_tag", "leave_chat", "remove_and_ban_chat")
	group("search", "search_messages")
	group("read", "read_link", "read_document")
	group("polls", "create_poll", "vote_poll", "pin_message", "unpin_message")
	group("plan", "remind", "reminders", "my_promise_add", "my_promise_done", "letter_write", "letter_reply", "keepsake_add", "keepsake_release", "fear_name", "fear_ease")
	group("make", "make_document", "make_table", "make_chart", "qr_code", "calendar_invite")
	group("life", "ledger", "tracker", "dates", "places")
	group("util", "datetime", "units", "random")
	group("browser", "browser")
	group("desktop", "desktop")
	group("system", "shell", "download_telegram_file", "send_file", "list_all_chats", "read_chat", "join_by_link", "send_to_chat",
		"shell_bg", "jobs", "tg_api", "telegram_ui", "web_search", "read_file", "http_request", "mail", "calendar", "work", "files",
		"sysinfo", "run_code", "lookup", "notes", "proc", "netcheck", "archive", "rss", "textutil", "service", "schedule", "monitor",
		"see_image", "image", "git", "media_dl", "sqlite", "send_later", "digest", "my_profile", "calc", "ssh", "transcribe",
		"convert_doc", "backup", "tail_log", "settings", "grep", "ignore", "command_users", "docker", "phone")

	set(func(x *Meta) { x.ReadOnly = true }, "my_actions", "delegate", "web_search", "read_link", "read_file", "read_document",
		"http_request", "lookup", "sysinfo", "read_chat", "search_messages", "view_messages_around", "query", "netcheck", "digest",
		"calc", "grep", "tail_log", "rss", "textutil", "search_chats", "user_info", "my_profile_view", "my_chats", "my_laptop", "my_settings_view", "datetime", "units", "places")
	set(func(x *Meta) { x.Quiet = true }, "wait", "pause", "skip", "change_mood", "bond", "advice", "self", "ask", "open_chat", "my_actions", "go_to_sleep",
		"react_with_emoji", "get_telegram_chats", "reply_later")
	set(func(x *Meta) { x.Idle, x.Repeatable = true, true }, "wait", "pause", "skip")
	set(func(x *Meta) { x.Sends = true }, "send_telegram_message", "sticker_send", "forward_message")
	set(func(x *Meta) { x.Repeatable = true }, "browser", "desktop", "telegram_ui", "send_telegram_message", "random")
	return m
}()

// withMeta fills in the catalog's metadata of a tool (fields the tool sets itself win).
func withMeta(t Tool) Tool {
	c, ok := catalog[t.Name]
	if !ok {
		return t
	}
	if t.Group == "" {
		t.Group = c.Group
	}
	t.ReadOnly = t.ReadOnly || c.ReadOnly
	t.Quiet = t.Quiet || c.Quiet
	t.Idle = t.Idle || c.Idle
	t.Sends = t.Sends || c.Sends
	t.Repeatable = t.Repeatable || c.Repeatable
	return t
}

// MetaOf returns the catalog's metadata of a built-in tool by name.
func MetaOf(name string) Meta { return catalog[name] }
