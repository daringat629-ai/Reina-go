package agent

import (
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestReplyLaterComesBackWhenDueAndSurvivesRestart(t *testing.T) {
	p := filepath.Join(t.TempDir(), "r.json")
	r := newReplyLater(p)
	now := time.Now()
	if err := r.add(7, "Вика", "ответить про кино", 30*time.Minute, now); err != nil {
		t.Fatal(err)
	}
	if len(r.due(now.Add(10*time.Minute))) != 0 {
		t.Fatal("not due yet")
	}
	r2 := newReplyLater(p) // restart
	d := r2.due(now.Add(31 * time.Minute))
	if len(d) != 1 || !strings.Contains(d[0].Note, "кино") {
		t.Fatalf("due=%+v", d)
	}
	r2.add(7, "Вика", "новое", time.Hour, now) // one note per chat
	if len(r2.items) != 1 {
		t.Fatalf("items=%d", len(r2.items))
	}
	r2.done(7)
	if len(r2.items) != 0 {
		t.Fatal("done must clear it")
	}
}
