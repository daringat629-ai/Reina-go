package agent

import "testing"

func TestUnbackedClaims(t *testing.T) {
	none := map[string]bool{}
	for _, bad := range []string{"ща, отправила тебе файл", "я проверила твой чат, там тишина", "погуглила в интернете, нету", "удалила файл", "поставила напоминание на пять", "запустила скрипт, всё ок"} {
		if unbackedClaim(bad, none) == "" {
			t.Errorf("must object: %q", bad)
		}
	}
	for _, ok := range []string{"не отправила пока", "я ещё не скинула файл", "привет, как дела", "нашла песню и пропала", "скину файл через минуту", "посмотрела сериал вчера"} {
		if w := unbackedClaim(ok, none); w != "" {
			t.Errorf("must not object: %q (%s)", ok, w)
		}
	}
	if unbackedClaim("отправила тебе файл", map[string]bool{"send_file": true}) != "" {
		t.Error("a claim backed by a tool call is fine")
	}
	if unbackedClaim("проверила чат", map[string]bool{"read_chat": true}) != "" {
		t.Error("read_chat backs a chat check")
	}
}

func TestSlangCountAndGuardOnce(t *testing.T) {
	if n := slangCount("ору, это кринж и вайб, чел"); n < 4 {
		t.Fatalf("n=%d", n)
	}
	if slangCount("привет, как дела, сижу дома") != 0 {
		t.Fatal("plain text has no slang")
	}
	tr := &turn{did: map[string]bool{}}
	msg := "ору, это кринж и вайб, чел"
	if tr.voiceGuard(msg) == "" {
		t.Fatal("too much slang must be objected to")
	}
	if tr.voiceGuard(msg) != "" {
		t.Fatal("the same text passes the second time, no loops")
	}
	if tr.voiceGuard("хай, норм всё") != "" {
		t.Fatal("a normal message passes")
	}
}
