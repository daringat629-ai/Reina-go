package agent

import (
	"fmt"
	"hash/fnv"
	"strings"
	"time"

	"kuni/internal/telegram"
)

// A person is not free and flawless all day: she has a busy stretch, a small thing happened to her, a mood of the day.
// The plan is derived from the date, so it is the same all day, differs from day to day, and needs no storage.

var smallThings = []string{
	"утром разлила кофе на клавиатуру, пришлось вытирать",
	"полночи не могла уснуть, думала о ерунде",
	"нашла в старом плейлисте песню и теперь она крутится в голове",
	"ноут сегодня шумит вентилятором, это бесит",
	"давно хотела что-то заказать и весь день не может выбрать",
	"приснился странный сон, и он не отпускает",
	"забыла про одну мелочь и теперь злится на себя",
	"сегодня в настроении всё переделывать и наводить порядок",
	"за окном такая погода, что никуда не хочется",
	"немного голодная и ленится что-то готовить",
}

var dayMoods = []string{
	"немного рассеянная: может переспросить или забыть деталь",
	"в хорошем настроении, шутит чаще обычного",
	"чуть уставшая, отвечает короче и без восклицаний",
	"слегка раздражена по мелочи, но не срывается на людях",
	"мечтательная, легко уходит в сторону от темы",
}

type dayPlan struct {
	busyFrom, busyTo int // hours; equal = no busy stretch today
	thing, mood      string
}

func planOfDay(t time.Time) dayPlan {
	h := fnv.New64a()
	fmt.Fprintf(h, "%d-%d-%d", t.Year(), t.Month(), t.Day())
	x := h.Sum64()
	p := dayPlan{thing: smallThings[x%uint64(len(smallThings))], mood: dayMoods[(x/16)%uint64(len(dayMoods))]}
	if (x/256)%3 != 0 { // two days out of three have a busy stretch of 1-3 hours in the daytime
		p.busyFrom = 11 + int((x/1024)%6)
		p.busyTo = p.busyFrom + 1 + int((x/8192)%3)
	}
	return p
}

// busy tells whether the hour is inside today's busy stretch.
func (p dayPlan) busy(hour int) bool {
	return p.busyTo > p.busyFrom && hour >= p.busyFrom && hour < p.busyTo
}

// herDayBlock is the <her_day> note: the mood of the day, the small thing that happened, and, during the busy stretch,
// the permission to answer briefly or later. The owner always matters more, and a real problem is never left waiting.
func (a *Agent) herDayBlock(chat telegram.Chat, now time.Time) string {
	cfg := a.cfg()
	if !cfg.DayLife {
		return ""
	}
	loc := cfg.Location()
	n := now.In(loc)
	p := planOfDay(n)
	var b strings.Builder
	fmt.Fprintf(&b, "<her_day>Сегодня ты %s. Из мелочей дня: %s. Это твоя жизнь: можешь вскользь упомянуть, если к слову, но не рассказывай об этом каждому и не по заказу.", p.mood, p.thing)
	if p.busy(n.Hour()) && !cfg.OwnerChat(chat.ID) {
		fmt.Fprintf(&b, " Сейчас до %02d:00 у тебя свои дела: можешь ответить коротко, или сказать «занята, отвечу позже» и вернуться к разговору потом. Если человеку плохо или это срочно, дела подождут.", p.busyTo)
	}
	b.WriteString("</her_day>\n")
	return b.String()
}
