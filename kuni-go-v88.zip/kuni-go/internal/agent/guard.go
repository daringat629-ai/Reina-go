package agent

import (
	"encoding/json"
	"fmt"
	"regexp"
)

// The voice guard stops two things before a message leaves: saying that she did something no tool did, and a pile of slang.
// Both are answered once with an explanation and let through on the repeat, so it can never trap her in a loop.

type claim struct {
	re    *regexp.Regexp
	what  string
	tools []string // any of these succeeding in this turn backs the claim
}

const lb = `(?:^|[^\p{L}])` // Go's \b knows no Cyrillic

func cl(pat, what string, tools ...string) claim {
	return claim{re: regexp.MustCompile(`(?i)` + lb + pat), what: what, tools: tools}
}

var claims = []claim{
	cl(`(?:отправил|скинул|выслал|переслал)[аи]?\s+(?:тебе\s+|ему\s+|ей\s+|им\s+|вам\s+)?(?:файл|фот|картинк|ссылк|документ|видео|аудио|гс|голосов|таблиц|скрипт|архив)`, "sent a file or media",
		"send_file", "share_file", "send_to_chat", "forward_message", "record_audio", "take_photo", "make_document", "make_table", "make_chart", "qr_code", "image", "tg_api", "send_telegram_message_file"),
	cl(`(?:проверил|глянул|посмотрел|прочитал|открыл)[аи]?\s+(?:твой\s+|свой\s+|наш\s+|этот\s+|весь\s+)?(?:чат|список|лог|настройк|сервер|ноут|профиль|канал|диск|переписк)`, "looked at a chat, log or setting",
		"read_chat", "list_all_chats", "get_telegram_chats", "my_chats", "my_laptop", "my_profile_view", "my_settings_view", "tail_log", "sysinfo", "shell", "open_chat", "view_messages_around", "my_profile", "user_info", "search_chats", "settings", "telegram_ui", "digest", "search_messages", "read_file"),
	cl(`(?:погуглил|загуглил|поискал|искал|нашл|нашёл)[аи]?\s+(?:в\s+(?:интернет|инет|гугл|сети)|в\s+google)`, "searched the internet",
		"web_search", "read_link", "browser", "lookup", "http_request"),
	cl(`(?:удалил|стёр|стерл)[аи]?\s+(?:этот\s+|твой\s+|тот\s+)?(?:файл|сообщени|чат|папк)`, "deleted something",
		"files", "shell", "tg_api", "delete_message", "telegram_ui"),
	cl(`поставил[аи]?\s+(?:тебе\s+|себе\s+)?(?:напоминани|таймер|будильник)`, "set a reminder",
		"remind", "schedule", "send_later", "monitor", "reminders"),
	cl(`(?:запустил|перезапустил|установил|скачал|обновил)[аи]?\s+(?:этот\s+|твой\s+|тот\s+)?(?:скрипт|код|программ|бот|сервис|пакет|обновлени|файл|видео|музык)`, "ran or installed something",
		"run_code", "shell", "shell_bg", "service", "self_update", "download_telegram_file", "media_dl", "http_request", "vibe_code", "files", "docker"),
}

var reNeg = regexp.MustCompile(`(?i)(?:^|[^\p{L}])(?:не|ещё не|еще не|пока не|так и не|почти)\s*$`)

// unbackedClaim returns what she says she did when no tool of this turn did it ("" = nothing to object to).
func unbackedClaim(text string, did map[string]bool) string {
	for _, c := range claims {
		for _, loc := range c.re.FindAllStringIndex(text, -1) {
			if reNeg.MatchString(text[:min(loc[0]+1, len(text))]) {
				continue
			}
			backed := false
			for _, t := range c.tools {
				if did[t] {
					backed = true
					break
				}
			}
			if !backed {
				return c.what
			}
		}
	}
	return ""
}

var slangWords = regexp.MustCompile(`(?i)` + lb + `(кринж\p{L}*|вайб\p{L}*|рофл\p{L}*|жиза|имба|изи|краш|токсик\p{L}*|ред\s*флаг|чекни\p{L}*|тильт\p{L}*|форсить|симп|стэн\p{L}*|хайп\p{L}*|душнил\p{L}*|душни\p{L}*|чилл\p{L}*|зашквар\p{L}*|пофиг|капец|пц|жесть|ор|ору|сасно|бро|чел|ваще|короч|типа)`)

// slangCount is how many slang words a message holds.
func slangCount(text string) int { return len(slangWords.FindAllString(text, -1)) }

// voiceGuard checks one outgoing message; the second time the same text comes it passes.
func (t *turn) voiceGuard(text string) string {
	if t.guarded == nil {
		t.guarded = map[string]bool{}
	}
	if t.guarded[text] {
		return ""
	}
	if what := unbackedClaim(text, t.did); what != "" {
		t.guarded[text] = true
		return fmt.Sprintf("Error: not sent. The message says you %s, but no tool call in this turn did that. Never claim an action you did not do. Either do it now with the right tool and then say so, or write the message again honestly (say you have not done it, or that you will).", what)
	}
	if n := slangCount(text); n > 2 {
		t.guarded[text] = true
		return fmt.Sprintf("Error: not sent. Too much slang (%d slang words in one message): it sounds forced. Rewrite it with one or two at most, like a real person who just talks.", n)
	}
	return ""
}

// guardText pulls the text out of a send_telegram_message call.
func guardText(args string) string {
	var v struct {
		Text string `json:"text"`
	}
	_ = json.Unmarshal([]byte(args), &v)
	return v.Text
}
