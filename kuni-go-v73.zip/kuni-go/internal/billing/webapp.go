package billing

import (
	"context"
	"crypto/hmac"
	"crypto/sha256"
	_ "embed"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net/http"
	"net/url"
	"sort"
	"strconv"
	"strings"
	"time"
)

//go:embed webapp/index.html
var webappHTML []byte

// WebUser is the Telegram user a Mini App request comes from, after its signature was checked.
type WebUser struct {
	ID        int64  `json:"id"`
	FirstName string `json:"first_name"`
	Username  string `json:"username"`
}

// CheckInitData verifies Telegram.WebApp.initData with the bot token (the HMAC scheme Telegram documents for Mini Apps) and
// returns the user. Data older than maxAge is refused, so a leaked string cannot be replayed for long.
func CheckInitData(initData, botToken string, now time.Time, maxAge time.Duration) (WebUser, error) {
	vals, err := url.ParseQuery(initData)
	if err != nil || botToken == "" {
		return WebUser{}, errors.New("bad init data")
	}
	hash := vals.Get("hash")
	if hash == "" {
		return WebUser{}, errors.New("no hash")
	}
	var pairs []string
	for k := range vals {
		if k != "hash" {
			pairs = append(pairs, k+"="+vals.Get(k))
		}
	}
	sort.Strings(pairs)
	mac := hmac.New(sha256.New, []byte("WebAppData"))
	mac.Write([]byte(strings.TrimSpace(botToken)))
	secret := mac.Sum(nil)
	mac = hmac.New(sha256.New, secret)
	mac.Write([]byte(strings.Join(pairs, "\n")))
	want := hex.EncodeToString(mac.Sum(nil))
	if !hmac.Equal([]byte(want), []byte(strings.ToLower(hash))) {
		return WebUser{}, errors.New("bad signature")
	}
	at, _ := strconv.ParseInt(vals.Get("auth_date"), 10, 64)
	if at == 0 || now.Sub(time.Unix(at, 0)) > maxAge {
		return WebUser{}, errors.New("init data is too old: reopen the app")
	}
	var u WebUser
	if err := json.Unmarshal([]byte(vals.Get("user")), &u); err != nil || u.ID == 0 {
		return WebUser{}, errors.New("no user")
	}
	return u, nil
}

// WebApp serves the bot's Mini App: one page (balance, Reina's status, packs, gifts, history, help) and a small JSON API
// behind the Telegram signature. Mount it on /app/.
func (b *Bot) WebApp() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("/app/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/app/" {
			http.NotFound(w, r)
			return
		}
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Header().Set("Cache-Control", "no-cache")
		_, _ = w.Write(webappHTML)
	})
	mux.HandleFunc("/app/api/me", b.api(func(ctx context.Context, u WebUser, in map[string]any) (any, error) { return b.me(u), nil }))
	mux.HandleFunc("/app/api/invoice", b.api(func(ctx context.Context, u WebUser, in map[string]any) (any, error) {
		kind, _ := in["kind"].(string)
		tokens, _ := in["tokens"].(float64)
		if kind != "pack" && kind != "gift" {
			return nil, errors.New("unknown kind")
		}
		for _, p := range b.Packs() {
			if p.Tokens == int64(tokens) && p.Stars > 0 {
				link, err := b.invoiceLink(ctx, kind, p)
				if err != nil {
					return nil, err
				}
				return map[string]string{"link": link}, nil
			}
		}
		return nil, errors.New("this pack is not on sale")
	}))
	mux.HandleFunc("/app/api/watch", b.api(func(ctx context.Context, u WebUser, in map[string]any) (any, error) {
		on, _ := in["on"].(bool)
		if on && b.presence().Online {
			return map[string]any{"watch": false, "note": "Рейна уже в сети"}, nil
		}
		b.Store.SetWatch(u.ID, on)
		return map[string]any{"watch": on}, nil
	}))
	mux.HandleFunc("/app/api/qr/start", b.api(func(ctx context.Context, u WebUser, in map[string]any) (any, error) {
		if !b.qrOn() {
			return nil, errors.New("оплата по QR сейчас выключена")
		}
		tokens, _ := in["tokens"].(float64)
		for _, p := range b.Packs() {
			if p.Tokens == int64(tokens) && p.Price > 0 {
				r := b.Store.NewRequest(u.ID, u.FirstName, p.Tokens, p.Price, b.now())
				return map[string]any{"code": r.Code, "price": b.Price(p.Price), "approx": b.approx(p.Price), "tokens": tokensWord(p.Tokens), "qr": dataURL(b.QR())}, nil
			}
		}
		return nil, errors.New("этот пакет по QR недоступен")
	}))
	mux.HandleFunc("/app/api/qr/receipt", signedAPI(func() string { return b.Token }, b.now, nil, func(r *http.Request, u WebUser, _ map[string]any) (any, error) {
		req, ok := b.Store.Waiting(u.ID)
		if !ok || b.OnReceipt == nil {
			return nil, errors.New("нет заявки, которая ждёт чек: начни оплату по QR заново")
		}
		img, err := formImage(r, "photo")
		if err != nil {
			return nil, err
		}
		if req, err = b.Store.Mark(req.ID, "sent", b.now()); err != nil {
			return nil, err
		}
		b.OnReceipt(req, img)
		return map[string]any{"code": req.Code}, nil
	}))
	mux.HandleFunc("/app/api/claim", b.api(func(ctx context.Context, u WebUser, in map[string]any) (any, error) {
		code, _ := in["code"].(string)
		g, err := b.Store.ClaimGift(code, u.ID, b.now())
		if err != nil {
			return nil, err
		}
		b.send(ctx, g.From, fmt.Sprintf("🎁 Твой подарок (%s) открыли. Спасибо, что делишься Рейной.", tokensWord(g.Tokens)))
		return map[string]any{"tokens": g.Tokens}, nil
	}))
	return mux
}

// api wraps an endpoint of the people's app: POST, signed by the pay bot.
func (b *Bot) api(f func(ctx context.Context, u WebUser, in map[string]any) (any, error)) http.HandlerFunc {
	return signedAPI(func() string { return b.Token }, b.now, nil, func(r *http.Request, u WebUser, in map[string]any) (any, error) {
		return f(r.Context(), u, in)
	})
}

// signedAPI wraps a Mini App endpoint: POST only, the Telegram signature (made with token) in X-Init-Data, an optional
// check of who may call it, a JSON body (or a multipart form for uploads, read by f itself), errors as {"error": "..."}.
func signedAPI(token func() string, now func() time.Time, allow func(WebUser) error, f func(r *http.Request, u WebUser, in map[string]any) (any, error)) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("Cache-Control", "no-store")
		if r.Method != http.MethodPost {
			w.WriteHeader(http.StatusMethodNotAllowed)
			return
		}
		fail := func(code int, err error) {
			w.WriteHeader(code)
			_ = json.NewEncoder(w).Encode(map[string]string{"error": err.Error()})
		}
		u, err := CheckInitData(r.Header.Get("X-Init-Data"), token(), now(), 24*time.Hour)
		if err == nil && allow != nil {
			err = allow(u)
		}
		if err != nil {
			fail(http.StatusUnauthorized, err)
			return
		}
		var in map[string]any
		if strings.HasPrefix(r.Header.Get("Content-Type"), "multipart/") {
			r.Body = http.MaxBytesReader(w, r.Body, 11<<20)
		} else {
			_ = json.NewDecoder(http.MaxBytesReader(w, r.Body, 8192)).Decode(&in)
		}
		out, err := f(r, u, in)
		if err != nil {
			fail(http.StatusBadRequest, err)
			return
		}
		_ = json.NewEncoder(w).Encode(out)
	}
}

// formImage reads an uploaded picture (field name) of at most 10 MB.
func formImage(r *http.Request, name string) ([]byte, error) {
	f, h, err := r.FormFile(name)
	if err != nil {
		return nil, errors.New("пришли картинку")
	}
	defer f.Close()
	if h.Size > 10<<20 {
		return nil, errors.New("картинка больше 10 МБ")
	}
	b, err := io.ReadAll(io.LimitReader(f, 10<<20))
	if err != nil {
		return nil, err
	}
	if ct := http.DetectContentType(b); !strings.HasPrefix(ct, "image/") {
		return nil, errors.New("это не картинка")
	}
	return b, nil
}

// dataURL turns a picture into something an <img> can show without another request.
func dataURL(img []byte) string {
	if len(img) == 0 {
		return ""
	}
	return "data:" + http.DetectContentType(img) + ";base64," + base64.StdEncoding.EncodeToString(img)
}

type webPack struct {
	Tokens int64  `json:"tokens"`
	Stars  int    `json:"stars"`
	Label  string `json:"label"`
	Convs  string `json:"convs"`
}

type webPay struct {
	Date   string `json:"date"`
	What   string `json:"what"`
	Amount string `json:"amount"`
	Paid   string `json:"paid"`
}

type webGift struct {
	Tokens string `json:"tokens"`
	Link   string `json:"link"`
	Opened string `json:"opened"`
}

// me is everything the app shows to one person.
func (b *Bot) me(wu WebUser) map[string]any {
	now := b.now().In(b.loc())
	u := b.Store.Get(wu.ID, now)
	limit := b.Limits().of(u.Plan)
	used, paidToday := 0, 0
	if u.Day == now.Format("2006-01-02") {
		used, paidToday = u.Used, u.PaidToday
	}
	var packs []webPack
	for _, p := range b.Packs() {
		if p.Stars > 0 {
			packs = append(packs, webPack{p.Tokens, p.Stars, Short(p.Tokens) + " токенов", b.convs(p.Tokens)})
		}
	}
	var hist []webPay
	for _, p := range b.Store.History(wu.ID, 20) {
		amount := ""
		if p.Tokens > 0 {
			amount = Short(p.Tokens) + " токенов"
		} else if p.Days > 0 {
			amount = title(p.Plan) + " на " + days(p.Days)
		}
		paid := ""
		if p.Stars > 0 {
			paid = fmt.Sprintf("⭐ %d", p.Stars)
		} else if p.Som > 0 {
			paid = b.Price(p.Som)
		}
		hist = append(hist, webPay{p.At.In(b.loc()).Format("02.01.2006"), kindNames[p.Kind], amount, paid})
	}
	var gifts []webGift
	for _, g := range b.Store.GiftsFrom(wu.ID) {
		opened := ""
		if g.To != 0 {
			opened = g.Claimed.In(b.loc()).Format("02.01")
		}
		gifts = append(gifts, webGift{Short(g.Tokens), b.giftLink(g.Code), opened})
	}
	var faq [][2]string
	faq = append(faq, b.faq()...)
	p := b.presence()
	plan := ""
	if u.Plan != Free {
		plan = fmt.Sprintf("%s до %s", title(u.Plan), u.Until.In(b.loc()).Format("02.01.2006"))
	}
	invite := ""
	if b.refTokens() > 0 && b.Name != "" {
		invite = fmt.Sprintf("https://t.me/%s?start=ref%d", b.Name, wu.ID)
	}
	return map[string]any{
		"name":    wu.FirstName,
		"balance": map[string]any{"tokens": max(u.Tokens, 0), "text": tokensWord(max(u.Tokens, 0)), "convs": b.convs(u.Tokens)},
		"today":   map[string]any{"used": used, "limit": limit, "paid": paidToday, "reset": "00:00"},
		"plan":    plan,
		"stats":   map[string]any{"total": u.Total, "spent": tokensWord(u.Spent), "paid": u.Paid, "since": u.Joined.In(b.loc()).Format("02.01.2006")},
		"reina": map[string]any{"state": p.State(), "headline": p.Headline(b.now(), b.loc()), "doing": p.Doing, "mood": p.MoodWord(),
			"energy": p.EnergyWord(), "energyPct": int(max(p.Energy, 0)*100 + .5), "night": p.Night, "known": p.Known, "watch": u.Watch, "her": b.her()},
		"packs": packs, "history": hist, "gifts": gifts, "faq": faq, "perConv": tokensWord(b.perConv()), "free": l10nFree(b.Limits().Free),
		"invite": invite, "refBonus": Short(b.refTokens()),
		"qr": b.qrState(wu.ID),
	}
}

func l10nFree(n int) string {
	return plural(n, "разговор", "разговора", "разговоров") + " в день"
}

// SetMenuApp puts the Mini App on the bot's menu button for everybody (call once at start; a failure is only logged).
func (b *Bot) SetMenuApp(ctx context.Context, appURL string) { b.setMenu(ctx, appURL, "Рейна") }

func (b *Bot) setMenu(ctx context.Context, appURL, text string) {
	if strings.TrimSpace(appURL) == "" {
		return
	}
	err := b.call(ctx, "setChatMenuButton", map[string]any{"menu_button": map[string]any{"type": "web_app", "text": text, "web_app": map[string]string{"url": appURL}}}, nil)
	if err != nil {
		log.Printf("billing bot: menu app: %v", err)
	}
}

// qrState is what the app needs for paying by bank QR: the packs with their price and a request still going on.
func (b *Bot) qrState(id int64) map[string]any {
	if !b.qrOn() {
		return map[string]any{"on": false}
	}
	var packs []map[string]any
	for _, p := range b.Packs() {
		if p.Price > 0 {
			packs = append(packs, map[string]any{"tokens": p.Tokens, "label": Short(p.Tokens) + " токенов", "convs": b.convs(p.Tokens), "price": b.Price(p.Price), "approx": b.approx(p.Price)})
		}
	}
	out := map[string]any{"on": true, "packs": packs, "currency": b.code()}
	for _, r := range b.Store.Open() {
		if r.UserID == id {
			out["pending"] = map[string]any{"code": r.Code, "price": b.Price(r.Som), "what": r.what(), "status": r.Status}
		}
	}
	return out
}
