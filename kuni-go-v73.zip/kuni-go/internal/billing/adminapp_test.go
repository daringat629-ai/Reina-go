package billing

import (
	"bytes"
	"encoding/json"
	"mime/multipart"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

var pngBytes = []byte("\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x02\x00\x00\x00\x90wS\xde")

func upload(t *testing.T, h http.Handler, path, init string) *httptest.ResponseRecorder {
	t.Helper()
	var body bytes.Buffer
	w := multipart.NewWriter(&body)
	fw, _ := w.CreateFormFile("photo", "r.png")
	fw.Write(pngBytes)
	w.Close()
	r := httptest.NewRequest("POST", path, &body)
	r.Header.Set("Content-Type", w.FormDataContentType())
	r.Header.Set("X-Init-Data", init)
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, r)
	return rec
}

func postJSON(h http.Handler, path, body, init string) *httptest.ResponseRecorder {
	r := httptest.NewRequest("POST", path, strings.NewReader(body))
	r.Header.Set("X-Init-Data", init)
	w := httptest.NewRecorder()
	h.ServeHTTP(w, r)
	return w
}

func TestCardByQRFromTheAppToTheOwnersApp(t *testing.T) {
	srv, calls := fakeAPI(t)
	dir := t.TempDir()
	st := Open(filepath.Join(dir, "b.json"))
	pay := newBot(srv, st)
	adm := &Admin{Token: "A", BaseURL: srv.URL, Store: st, Pay: pay, QRPath: filepath.Join(dir, "qr.png"), Owner: func() int64 { return 1 }, Now: func() time.Time { return t0 }, Loc: time.UTC}
	pay.QR, pay.OnReceipt = adm.QRImage, adm.Receipt
	_ = os.WriteFile(adm.QRPath, pngBytes, 0o600)
	app, own := pay.WebApp(), adm.WebApp()
	user := signInit("T", `{"id":7,"first_name":"Аня"}`, t0)

	w := postJSON(app, "/app/api/me", "{}", user)
	if !strings.Contains(w.Body.String(), `"qr":{"currency":"RUB","on":true`) {
		t.Fatalf("the app offers QR: %s", w.Body.String())
	}
	w = postJSON(app, "/app/api/qr/start", `{"tokens":500000}`, user)
	var start map[string]any
	_ = json.Unmarshal(w.Body.Bytes(), &start)
	if w.Code != 200 || start["code"] != "R1" || !strings.HasPrefix(start["qr"].(string), "data:image/png;base64,") || start["price"] != "120 ₽" {
		t.Fatalf("start: %s", w.Body.String())
	}
	if w := upload(t, app, "/app/api/qr/receipt", user); w.Code != 200 {
		t.Fatalf("receipt: %s", w.Body.String())
	}
	if len(calls("sendPhoto")) != 1 {
		t.Fatal("the owner gets the receipt in the admin bot too")
	}

	// the owner's app: only the owner, signed by the ADMIN bot
	if w := postJSON(own, "/app/admin/api/overview", "{}", signInit("A", `{"id":7}`, t0)); w.Code != http.StatusUnauthorized {
		t.Fatal("not the owner: no entry")
	}
	if w := postJSON(own, "/app/admin/api/overview", "{}", signInit("T", `{"id":1}`, t0)); w.Code != http.StatusUnauthorized {
		t.Fatal("signed by the pay bot: no entry")
	}
	boss := signInit("A", `{"id":1,"first_name":"Папик"}`, t0)
	if w := postJSON(own, "/app/admin/api/overview", "{}", boss); w.Code != 200 || !strings.Contains(w.Body.String(), `"open":1`) {
		t.Fatalf("overview: %s", w.Body.String())
	}
	w = postJSON(own, "/app/admin/api/requests", "{}", boss)
	if !strings.Contains(w.Body.String(), `"receipt":"data:image/png;base64,`) || !strings.Contains(w.Body.String(), `"status":"sent"`) {
		t.Fatalf("the request shows its receipt: %s", w.Body.String()[:min(300, len(w.Body.String()))])
	}
	if w := postJSON(own, "/app/admin/api/decide", `{"id":1,"ok":true}`, boss); w.Code != 200 || st.Get(7, t0).Tokens != 500000 {
		t.Fatalf("approve from the app: %s %+v", w.Body.String(), st.Get(7, t0))
	}
	if w := postJSON(own, "/app/admin/api/decide", `{"id":1,"ok":true}`, boss); w.Code != 400 {
		t.Fatal("twice: refused")
	}
	if w := postJSON(own, "/app/admin/api/give", `{"id":9,"tokens":250000}`, boss); w.Code != 200 || st.Get(9, t0).Tokens != 250000 {
		t.Fatal("give from the app")
	}
	if w := postJSON(own, "/app/admin/api/people", `{"q":"9"}`, boss); !strings.Contains(w.Body.String(), `"id":9`) || strings.Contains(w.Body.String(), `"id":7`) {
		t.Fatalf("search by id: %s", w.Body.String())
	}
	if w := postJSON(own, "/app/admin/api/user", `{"id":7}`, boss); !strings.Contains(w.Body.String(), "пакет по QR") {
		t.Fatalf("user history: %s", w.Body.String())
	}
	_ = os.Remove(adm.QRPath)
	if w := upload(t, own, "/app/admin/api/qr", boss); w.Code != 200 || len(adm.QRImage()) == 0 {
		t.Fatal("a new QR from the app")
	}
	if w := postJSON(own, "/app/admin/api/update", `{}`, boss); w.Code != 400 {
		t.Fatal("no updater configured: a clear error")
	}
}
