package tools

import (
	"context"
	"kuni/internal/telegram"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

const sampleDump = `Current Notification List:
  NotificationRecord(0x1 pkg=com.whatsapp user=UserHandle{0} id=1)
    extras={
      android.title=String (Анна)
      android.text=String (привет, ты где?)
    }
  NotificationRecord(0x2 pkg=org.telegram.messenger user=UserHandle{0} id=2)
    extras={
      android.title=Борис
      android.text=ужин в семь
    }
  NotificationRecord(0x3 pkg=com.android.systemui user=UserHandle{0} id=3)
    extras={
      android.progress=0
    }
`

func TestParseNotifications(t *testing.T) {
	got := parseNotifications(sampleDump, 10)
	if len(got) != 2 || got[0] != "[com.whatsapp] Анна: привет, ты где?" || got[1] != "[org.telegram.messenger] Борис: ужин в семь" {
		t.Fatalf("%q", got)
	}
	if got := parseNotifications(sampleDump, 1); len(got) != 1 {
		t.Fatalf("limit ignored: %q", got)
	}
}

func fakeADB(t *testing.T) string {
	dir := t.TempDir()
	calls := filepath.Join(dir, "calls")
	script := "#!/bin/sh\necho \"$@\" >> " + calls + "\ncase \"$*\" in\n*get-state*) echo device;;\n*connect*) echo connected;;\n*dumpsys\\ battery*) printf '  AC powered: false\\n  level: 87\\n';;\n*dumpsys\\ notification*) cat " + filepath.Join(dir, "dump") + ";;\n*screencap*) printf '\\211PNG\\r\\n\\032\\n0000';;\n*install*) echo Success;;\nesac\n"
	os.WriteFile(filepath.Join(dir, "adb"), []byte(script), 0o755)
	os.WriteFile(filepath.Join(dir, "dump"), []byte(sampleDump), 0o644)
	t.Setenv("PATH", dir+string(os.PathListSeparator)+os.Getenv("PATH"))
	return calls
}

func TestPhoneToolWithAFakeAdb(t *testing.T) {
	calls := fakeADB(t)
	d, _ := lifeDeps(t)
	tl := phoneTool(d)
	if _, err := tl.Run(context.Background(), Args{"action": "status"}); err == nil {
		t.Fatal("no address configured: the phone must be off")
	}
	d.Cfg().PhoneADB = "192.168.1.50:5555"
	if out := use(t, tl, Args{"action": "status"}); !strings.Contains(out, "level: 87") {
		t.Fatal(out)
	}
	if out := use(t, tl, Args{"action": "notifications"}); !strings.Contains(out, "Анна: привет") {
		t.Fatal(out)
	}
	use(t, tl, Args{"action": "tap", "x": 100.0, "y": 200.0})
	use(t, tl, Args{"action": "key", "text": "home"})
	use(t, tl, Args{"action": "type", "text": "hello world; rm -rf /"})
	raw, _ := os.ReadFile(calls)
	c := string(raw)
	for _, want := range []string{"-s 192.168.1.50:5555 shell input tap 100 200", "keyevent 3", "input text hello%sworld%srm%s-rf%s/"} {
		if !strings.Contains(c, want) {
			t.Errorf("missing %q in\n%s", want, c)
		}
	}
	if strings.Contains(c, ";") {
		t.Errorf("shell metacharacters must be stripped from typed text:\n%s", c)
	}
	if _, err := tl.Run(context.Background(), Args{"action": "type", "text": "привет"}); err == nil {
		t.Fatal("non-ASCII text cannot be typed over adb and must say so")
	}
	if _, err := tl.Run(context.Background(), Args{"action": "key", "text": "format"}); err == nil {
		t.Fatal("unknown key must be refused")
	}
	if _, err := tl.Run(context.Background(), Args{"action": "install", "path": "/etc/passwd"}); err == nil {
		t.Fatal("only .apk files can be installed")
	}
	apk := filepath.Join(t.TempDir(), "app.apk")
	os.WriteFile(apk, []byte("x"), 0o644)
	if out := use(t, tl, Args{"action": "install", "path": apk}); !strings.Contains(out, "Success") {
		t.Fatal(out)
	}
	d.Cfg().PhoneADB = "192.168.1.50:5555"
	if out := use(t, tl, Args{"action": "call", "number": "+996 555-123-456"}); !strings.Contains(out, "+996555123456") {
		t.Fatal(out)
	}
	for _, bad := range []string{"", "12", "555; reboot", "abc12345"} {
		if _, err := tl.Run(context.Background(), Args{"action": "call", "number": bad}); err == nil {
			t.Fatalf("number %q must be refused", bad)
		}
	}
	use(t, tl, Args{"action": "answer"})
	use(t, tl, Args{"action": "hangup"})
	raw2, _ := os.ReadFile(calls)
	for _, want := range []string{"android.intent.action.CALL -d tel:+996555123456", "keyevent 5", "keyevent 6"} {
		if !strings.Contains(string(raw2), want) {
			t.Errorf("missing %q in\n%s", want, raw2)
		}
	}
	d.Cfg().PhoneADB = "bad target; reboot"
	if _, err := tl.Run(context.Background(), Args{"action": "tap", "x": 1.0, "y": 1.0}); err == nil {
		t.Fatal("a target with shell in it must be refused")
	}
	if RiskOf("phone", `{"action":"install"}`, 5) != "" {
		t.Fatal("it is her own phone: no confirmation to install")
	}
}

func TestPhoneToolOnlyForTheOwnerAndOnlyWhenConfigured(t *testing.T) {
	d, _ := lifeDeps(t)
	has := func(ts []Tool) bool {
		for _, x := range ts {
			if x.Name == "phone" {
				return true
			}
		}
		return false
	}
	if has(OwnerTools(d, owner)) {
		t.Fatal("phone must be off by default")
	}
	d.Cfg().PhoneADB = "x:1"
	if !has(OwnerTools(d, owner)) {
		t.Fatal("phone missing for the owner")
	}
	if has(OwnerTools(d, telegramStranger)) {
		t.Fatal("a stranger must never get the phone")
	}
}

var telegramStranger = telegram.Chat{ID: 999, Kind: telegram.ChatPrivate}

func TestCallsAreLimitedPerDay(t *testing.T) {
	var c callCount
	now := time.Date(2026, 10, 29, 12, 0, 0, 0, time.UTC)
	for i := 0; i < callsPerDay; i++ {
		if !c.take(now) {
			t.Fatalf("call %d must be allowed", i+1)
		}
	}
	if c.take(now) {
		t.Fatal("the sixth call of a day must be refused")
	}
	if !c.take(now.AddDate(0, 0, 1)) {
		t.Fatal("a new day starts fresh")
	}
}

func TestCallStateOf(t *testing.T) {
	for dump, want := range map[string]string{"  mCallState=0\n": "свободна", "mCallState=1": "входящий", " mCallState=2 ": "разговор", "nothing": "не удалось"} {
		if got := callStateOf(dump); !strings.Contains(got, want) {
			t.Errorf("%q -> %q", dump, got)
		}
	}
}

func TestPhoneIsInHerFreeTime(t *testing.T) {
	d, _ := lifeDeps(t)
	if len(PhoneTools(d)) != 0 {
		t.Fatal("off by default")
	}
	d.Cfg().PhoneADB = "x:1"
	if len(PhoneTools(d)) != 1 {
		t.Fatal("she must have the phone in her free time")
	}
}
