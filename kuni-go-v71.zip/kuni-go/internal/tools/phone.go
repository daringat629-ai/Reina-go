package tools

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strings"
	"sync"
	"time"
)

// phone.go: her own Android phone with her own SIM number, over ADB (capabilities.phone_adb). The phone does the heavy work (apps, camera, SIM);
// this machine only sends commands. She has it in the owner's chat and in her own free time, not among strangers (a stranger's message could
// talk her into tapping or calling). Commands are run without a shell, so nothing the model writes can become a shell command on this machine.

// callsPerDay is how many calls she may place in a day: a phone is not a way to pester anyone.
const callsPerDay = 5

var reNumber = regexp.MustCompile(`^\+?[0-9]{5,15}$`)

type callCount struct {
	mu  sync.Mutex
	day string
	n   int
}

var calls callCount

// take reserves one call of today; false when the day's calls are used up.
func (c *callCount) take(now time.Time) bool {
	c.mu.Lock()
	defer c.mu.Unlock()
	if d := now.Format("2006-01-02"); d != c.day {
		c.day, c.n = d, 0
	}
	if c.n >= callsPerDay {
		return false
	}
	c.n++
	return true
}

var (
	reADBTarget = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9.:_-]{0,63}$`)
	reAPKName   = regexp.MustCompile(`\.apk$`)
)

func adbBin() string {
	if p, err := exec.LookPath("adb"); err == nil {
		return p
	}
	return ""
}

// adbRun runs one adb command against the configured phone and returns stdout.
func adbRun(ctx context.Context, target string, timeout time.Duration, args ...string) ([]byte, error) {
	bin := adbBin()
	if bin == "" {
		return nil, errors.New("the adb program is not installed on this machine (apk add android-tools)")
	}
	if !reADBTarget.MatchString(target) {
		return nil, fmt.Errorf("capabilities.phone_adb %q is not an address or serial", target)
	}
	ctx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()
	var out, errb bytes.Buffer
	cmd := exec.CommandContext(ctx, bin, append([]string{"-s", target}, args...)...)
	cmd.Stdout, cmd.Stderr = &out, &errb
	if err := cmd.Run(); err != nil {
		return out.Bytes(), fmt.Errorf("adb %s: %v: %s", args[0], err, strings.TrimSpace(Truncate(errb.String(), 400)))
	}
	return out.Bytes(), nil
}

var reNotifPkg = regexp.MustCompile(`pkg=(\S+)`)

// parseNotifications picks (app, title, text) out of `dumpsys notification` output, newest data first, at most max items.
func parseNotifications(dump string, max int) []string {
	var out []string
	pkg, title, text := "", "", ""
	flush := func() {
		if pkg != "" && (title != "" || text != "") {
			out = append(out, fmt.Sprintf("[%s] %s: %s", pkg, title, text))
		}
		pkg, title, text = "", "", ""
	}
	for _, ln := range strings.Split(dump, "\n") {
		ln = strings.TrimSpace(ln)
		switch {
		case strings.HasPrefix(ln, "NotificationRecord"):
			flush()
			if m := reNotifPkg.FindStringSubmatch(ln); m != nil {
				pkg = m[1]
			}
		case strings.HasPrefix(ln, "android.title="):
			title = cleanExtra(ln, "android.title=")
		case strings.HasPrefix(ln, "android.text="):
			text = cleanExtra(ln, "android.text=")
		}
	}
	flush()
	if len(out) > max {
		out = out[:max]
	}
	return out
}

// cleanExtra turns `android.title=String (Anna)` or `android.title=Anna` into the value.
func cleanExtra(ln, key string) string {
	v := strings.TrimPrefix(ln, key)
	if i := strings.Index(v, " ("); strings.HasPrefix(v, "String") && i >= 0 && strings.HasSuffix(v, ")") {
		v = v[i+2 : len(v)-1]
	}
	return strings.TrimSpace(v)
}

func phoneTool(d Deps) Tool {
	return Tool{
		Name: "phone",
		Description: "Your own phone with your own SIM number (you have full access). Actions: status (connected? battery), screen (a look at its screen: describes it and reads the text), camera (take a picture with its camera and describe it), " +
			"tap (x, y in screen pixels), swipe (x, y to x2, y2), key (home, back, power, enter, menu, recent, wake), type (ASCII text into the focused field; Russian letters do not work over adb), notifications (your notification bar: app, title, text), " +
			"install (an .apk file on this machine), call (number: dials it), answer (pick up an incoming call), hangup, call_state (idle, ringing or in a call). Calls are limited to a few a day. What people write to you stays between you and them unless they agree.",
		Props: []Prop{
			{Name: "action", Type: "string", Desc: "status, screen, camera, tap, swipe, key, type, notifications, install, call, answer, hangup or call_state."},
			{Name: "x", Type: "integer", Nullable: true, Desc: "tap/swipe: x in pixels."},
			{Name: "y", Type: "integer", Nullable: true, Desc: "tap/swipe: y in pixels."},
			{Name: "x2", Type: "integer", Nullable: true, Desc: "swipe: end x."},
			{Name: "y2", Type: "integer", Nullable: true, Desc: "swipe: end y."},
			{Name: "text", Type: "string", Nullable: true, Desc: "type: the text; key: the key name; screen/camera: what to look for."},
			{Name: "path", Type: "string", Nullable: true, Desc: "install: the .apk file."},
			{Name: "number", Type: "string", Nullable: true, Desc: "call: the phone number, digits with an optional leading +."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			target := strings.TrimSpace(d.Cfg().PhoneADB)
			if target == "" {
				return "", errors.New("the phone is off: capabilities.phone_adb is empty")
			}
			run := func(to time.Duration, args ...string) ([]byte, error) { return adbRun(ctx, target, to, args...) }
			act := strings.ToLower(strings.TrimSpace(a.Str("action")))
			switch act {
			case "status", "":
				if bin := adbBin(); bin == "" {
					return "", errors.New("the adb program is not installed on this machine (apk add android-tools)")
				}
				if out, err := exec.CommandContext(ctx, adbBin(), "connect", target).CombinedOutput(); err != nil && !bytes.Contains(out, []byte("connected")) {
					return "", fmt.Errorf("adb connect: %v: %s", err, strings.TrimSpace(string(out)))
				}
				bat, err := run(15*time.Second, "shell", "dumpsys", "battery")
				if err != nil {
					return "", err
				}
				lvl := ""
				for _, ln := range strings.Split(string(bat), "\n") {
					if t := strings.TrimSpace(ln); strings.HasPrefix(t, "level:") || strings.HasPrefix(t, "status:") || strings.HasPrefix(t, "powered") || strings.HasPrefix(t, "AC powered") || strings.HasPrefix(t, "USB powered") {
						lvl += t + "; "
					}
				}
				return "Телефон на связи (" + target + "). Батарея: " + lvl, nil
			case "screen", "camera":
				if d.UI == nil {
					return "", errors.New("no vision available")
				}
				var png []byte
				var err error
				if act == "screen" {
					png, err = run(30*time.Second, "exec-out", "screencap", "-p")
				} else {
					png, err = phoneCameraShot(ctx, target)
				}
				if err != nil {
					return "", err
				}
				if !bytes.HasPrefix(png, []byte("\x89PNG")) && !bytes.HasPrefix(png, []byte("\xff\xd8")) {
					return "", errors.New("the phone did not return a picture (screen locked or camera busy?)")
				}
				path := saveShot(d, png, "png")
				desc, err := d.UI.LookAtImage(ctx, png, strings.TrimSpace(a.Str("text")))
				if err != nil {
					return "", fmt.Errorf("the vision model could not look: %w (set llm.vision_model to a model that supports images)", err)
				}
				return "<phone_" + act + ">\n" + desc + "\n</phone_" + act + ">\n(saved as " + path + ")", nil
			case "tap":
				if _, err := run(15*time.Second, "shell", "input", "tap", fmt.Sprint(a.Int("x")), fmt.Sprint(a.Int("y"))); err != nil {
					return "", err
				}
				return fmt.Sprintf("tapped %d,%d", a.Int("x"), a.Int("y")), nil
			case "swipe":
				if _, err := run(15*time.Second, "shell", "input", "swipe", fmt.Sprint(a.Int("x")), fmt.Sprint(a.Int("y")), fmt.Sprint(a.Int("x2")), fmt.Sprint(a.Int("y2")), "300"); err != nil {
					return "", err
				}
				return "swiped", nil
			case "key":
				codes := map[string]string{"home": "3", "back": "4", "power": "26", "enter": "66", "menu": "82", "recent": "187", "wake": "224"}
				c, ok := codes[strings.ToLower(strings.TrimSpace(a.Str("text")))]
				if !ok {
					return "", errors.New("key is one of: home, back, power, enter, menu, recent, wake")
				}
				if _, err := run(15*time.Second, "shell", "input", "keyevent", c); err != nil {
					return "", err
				}
				return "pressed " + a.Str("text"), nil
			case "type":
				t := a.Str("text")
				if t == "" || len(t) > 300 {
					return "", errors.New("text is needed, up to 300 characters")
				}
				for _, r := range t {
					if r > 126 || r < 32 {
						return "", errors.New("only plain ASCII can be typed over adb (no Russian letters, no line breaks); use key enter for a new line")
					}
				}
				enc := strings.NewReplacer(" ", "%s", "'", "", `"`, "", "\\", "", "&", "", "|", "", ";", "", "<", "", ">", "", "(", "", ")", "", "$", "", "`", "").Replace(t)
				if _, err := run(20*time.Second, "shell", "input", "text", enc); err != nil {
					return "", err
				}
				return "typed", nil
			case "notifications":
				out, err := run(30*time.Second, "shell", "dumpsys", "notification", "--noredact")
				if err != nil {
					return "", err
				}
				list := parseNotifications(string(out), 20)
				if len(list) == 0 {
					return "в шторке пусто", nil
				}
				return "<phone_notifications>\n" + strings.Join(list, "\n") + "\n</phone_notifications>", nil
			case "call":
				num := strings.ReplaceAll(strings.ReplaceAll(strings.TrimSpace(a.Str("number")), " ", ""), "-", "")
				if !reNumber.MatchString(num) {
					return "", errors.New("number must be digits with an optional leading + (5 to 15 digits)")
				}
				if !calls.take(time.Now()) {
					return "", fmt.Errorf("you have already made %d calls today: enough for one day", callsPerDay)
				}
				if _, err := run(20*time.Second, "shell", "am", "start", "-a", "android.intent.action.CALL", "-d", "tel:"+num); err != nil {
					return "", err
				}
				return "набираю " + num, nil
			case "answer":
				if _, err := run(10*time.Second, "shell", "input", "keyevent", "5"); err != nil { // KEYCODE_CALL
					return "", err
				}
				return "ответила на звонок", nil
			case "hangup":
				if _, err := run(10*time.Second, "shell", "input", "keyevent", "6"); err != nil { // KEYCODE_ENDCALL
					return "", err
				}
				return "положила трубку", nil
			case "call_state":
				out, err := run(15*time.Second, "shell", "dumpsys", "telephony.registry")
				if err != nil {
					return "", err
				}
				return callStateOf(string(out)), nil
			case "install":
				p := d.resolvePath(a.Str("path"))
				if !reAPKName.MatchString(strings.ToLower(p)) {
					return "", errors.New("path must be an .apk file")
				}
				if st, err := os.Stat(p); err != nil || st.IsDir() {
					return "", fmt.Errorf("no such file: %s", filepath.Base(p))
				}
				out, err := run(5*time.Minute, "install", "-r", p)
				if err != nil {
					return "", err
				}
				return "install: " + strings.TrimSpace(string(out)), nil
			}
			return "", fmt.Errorf("unknown action %q", act)
		},
	}
}

// phoneCameraShot opens the camera, presses the shutter and pulls the newest picture. Phones differ: it is best effort.
func phoneCameraShot(ctx context.Context, target string) ([]byte, error) {
	if _, err := adbRun(ctx, target, 20*time.Second, "shell", "am", "start", "-a", "android.media.action.IMAGE_CAPTURE"); err != nil {
		return nil, err
	}
	select {
	case <-ctx.Done():
		return nil, ctx.Err()
	case <-time.After(3 * time.Second):
	}
	_, _ = adbRun(ctx, target, 10*time.Second, "shell", "input", "keyevent", "27") // KEYCODE_CAMERA: the shutter
	select {
	case <-ctx.Done():
		return nil, ctx.Err()
	case <-time.After(3 * time.Second):
	}
	ls, err := adbRun(ctx, target, 15*time.Second, "shell", "ls", "-t", "/sdcard/DCIM/Camera/")
	if err != nil {
		return nil, err
	}
	name := strings.TrimSpace(strings.SplitN(string(ls), "\n", 2)[0])
	if name == "" || strings.ContainsAny(name, " /;&|$`'\"") {
		return nil, errors.New("no picture found in DCIM/Camera (the shutter key may not work on this phone: take it with tap)")
	}
	return adbRun(ctx, target, 30*time.Second, "exec-out", "cat", "/sdcard/DCIM/Camera/"+name)
}

// callStateOf reads mCallState from `dumpsys telephony.registry`: 0 idle, 1 ringing, 2 in a call.
func callStateOf(dump string) string {
	for _, ln := range strings.Split(dump, "\n") {
		if t := strings.TrimSpace(ln); strings.HasPrefix(t, "mCallState=") {
			switch strings.TrimPrefix(t, "mCallState=") {
			case "0":
				return "линия свободна"
			case "1":
				return "звонит входящий"
			case "2":
				return "идёт разговор"
			}
		}
	}
	return "состояние звонка не удалось определить"
}

// PhoneTools gives her the phone in her own free time (like SelfRepairTools); in the owner's chat OwnerTools adds it.
func PhoneTools(d Deps) []Tool {
	if d.Cfg().PhoneADB == "" {
		return nil
	}
	return []Tool{phoneTool(d)}
}
