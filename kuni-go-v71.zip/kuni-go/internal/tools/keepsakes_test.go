package tools

import (
	"context"
	"path/filepath"
	"strings"
	"testing"

	"kuni/internal/keepsakes"
)

func TestKeepsakeToolsKeepAndRelease(t *testing.T) {
	d := Deps{Keepsakes: keepsakes.Open(filepath.Join(t.TempDir(), "k.json"))}
	out, err := keepsakeAddTool(d).Run(context.Background(), Args{"text": "Дождь пахнет пылью и железом.", "why": "мне нравится, как это звучит"})
	if err != nil || !strings.Contains(out, "#1") {
		t.Fatalf("%q %v", out, err)
	}
	if _, err := keepsakeAddTool(d).Run(context.Background(), Args{"text": "Дождь пахнет пылью и железом.", "why": "снова"}); err == nil {
		t.Fatal("duplicate must be refused")
	}
	if _, err := keepsakeReleaseTool(d).Run(context.Background(), Args{"id": float64(1)}); err != nil {
		t.Fatal(err)
	}
	if _, err := keepsakeReleaseTool(d).Run(context.Background(), Args{"id": float64(1)}); err == nil {
		t.Fatal("already gone")
	}
}
