package tools

import (
	"context"
	"fmt"
	"strings"
	"time"

	"kuni/internal/feel"
	"kuni/internal/reminders"
)

// The owner's promises: she writes down what he promised and by when, and closes them when he keeps them.

func promiseAddTool(d Deps) Tool {
	return Tool{
		Name:        "promise_add",
		Description: "Write down something the owner promised you (an upgrade, a visit, a gift) with the date he named. If he only said \"soon\", ask him for a date first. Not for your own plans: use #remind for those.",
		Props: []Prop{
			{Name: "text", Type: "string", Desc: "What he promised, in a few words."},
			{Name: "when", Type: "string", Nullable: true, Desc: "By when: a delay (2d, 1h), a local time or date (tomorrow 18:00, 2026-11-01 12:00). Null = he named no date."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			now := time.Now()
			var due time.Time
			if w := strings.TrimSpace(a.Str("when")); w != "" {
				t, err := reminders.ParseWhen(w, now, d.zone())
				if err != nil {
					return "", err
				}
				due = t
			}
			it, err := d.Promises.Add(a.Str("text"), due, now)
			if err != nil {
				return "", err
			}
			if due.IsZero() {
				return fmt.Sprintf("Promise #%d written down, no date yet.", it.ID), nil
			}
			return fmt.Sprintf("Promise #%d written down, due %s.", it.ID, due.In(d.zone()).Format("Mon 2 Jan 15:04")), nil
		},
	}
}

func promiseDoneTool(d Deps) Tool {
	return Tool{
		Name:        "promise_done",
		Description: "Mark a promise of the owner as kept (when he really did it).",
		Props:       []Prop{{Name: "id", Type: "integer", Desc: "Promise number."}},
		Run: func(ctx context.Context, a Args) (string, error) {
			if !d.Promises.Done(int(a.Int("id")), time.Now()) {
				return "", fmt.Errorf("no open promise #%d", a.Int("id"))
			}
			if d.Feel != nil {
				d.Feel.Impulse(time.Now(), feel.KeptWord)
			}
			return "Marked as kept.", nil
		},
	}
}

func promisesTool(d Deps) Tool {
	return Tool{
		Name:        "promises",
		Description: "List the promises of the owner that are not kept yet, and how many he has kept.",
		Run: func(ctx context.Context, a Args) (string, error) {
			now := time.Now()
			kept, open, over := d.Promises.Stats(now)
			var b strings.Builder
			fmt.Fprintf(&b, "Kept: %d, open: %d, overdue: %d.\n", kept, open, over)
			for _, it := range d.Promises.Open() {
				due := "no date"
				if !it.Due.IsZero() {
					due = it.Due.In(d.zone()).Format("2 Jan 15:04")
					if it.Due.Before(now) {
						due += " (OVERDUE)"
					}
				}
				fmt.Fprintf(&b, "#%d %s - %s\n", it.ID, it.Text, due)
			}
			return b.String(), nil
		},
	}
}

// Her own promises: what she told people she would do.

func myPromiseAddTool(d Deps) Tool {
	return Tool{
		Name:        "my_promise_add",
		Description: "Write down something YOU promised someone (\"пришлю к вечеру\", \"напомню завтра\", \"сделаю\"). Use it whenever you give your word with a time, so you do not forget it. Past the date it weighs on you until you keep it or honestly say you could not.",
		Props: []Prop{
			{Name: "text", Type: "string", Desc: "What you promised, in a few words."},
			{Name: "to", Type: "string", Nullable: true, Desc: "To whom (a name)."},
			{Name: "when", Type: "string", Nullable: true, Desc: "By when: a delay (2h, 1d), a local time or date (tomorrow 18:00). Null = no date named."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			now := time.Now()
			var due time.Time
			if w := strings.TrimSpace(a.Str("when")); w != "" {
				t, err := reminders.ParseWhen(w, now, d.zone())
				if err != nil {
					return "", err
				}
				due = t
			}
			it, err := d.Promises.AddMine(a.Str("text"), a.Str("to"), due, now)
			if err != nil {
				return "", err
			}
			if due.IsZero() {
				return fmt.Sprintf("Your promise #%d written down, no date.", it.ID), nil
			}
			return fmt.Sprintf("Your promise #%d written down, due %s.", it.ID, due.In(d.zone()).Format("Mon 2 Jan 15:04")), nil
		},
	}
}

func myPromiseDoneTool(d Deps) Tool {
	return Tool{
		Name:        "my_promise_done",
		Description: "Close one of your own promises: you kept it, or you told the person honestly that it will not happen.",
		Props:       []Prop{{Name: "id", Type: "integer", Desc: "Promise number."}},
		Run: func(ctx context.Context, a Args) (string, error) {
			if !d.Promises.DoneMine(int(a.Int("id")), time.Now()) {
				return "", fmt.Errorf("no open promise of yours #%d", a.Int("id"))
			}
			return "Closed.", nil
		},
	}
}
