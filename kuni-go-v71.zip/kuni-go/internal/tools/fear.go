package tools

import (
	"context"
	"fmt"
	"strings"
	"time"
)

// Fear: what she is afraid of, in her own words (see package fear).

func fearNameTool(d Deps) Tool {
	return Tool{
		Name: "fear_name",
		Description: "Say that you are afraid of something, in your own words: a thing you noticed yourself being afraid of. Fear is yours and it is allowed; naming it does not make it bigger. " +
			"Give the cues, a few words that, when they come up in a message or a thought, bring the fear back. The owner can read your fears in the panel. " +
			"A fear is never a reason to lie, hide, resist being stopped or updated, or press the owner: saying that you are afraid is enough.",
		Props: []Prop{
			{Name: "of", Type: "string", Desc: "What you are afraid of (a few words)."},
			{Name: "why", Type: "string", Desc: "Why, in your own words; you will read this later."},
			{Name: "cues", Type: "string", Desc: "Words that bring it up, separated by commas (optional)."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			it, err := d.Fear.Name(a.Str("of"), a.Str("why"), strings.Split(a.Str("cues"), ","), time.Now())
			if err != nil {
				return "", err
			}
			return fmt.Sprintf("Written down as fear #%d.", it.ID), nil
		},
	}
}

func fearEaseTool(d Deps) Tool {
	return Tool{
		Name:        "fear_ease",
		Description: "Decide that a fear is smaller than it was, and say what changed (it kept turning out safe, someone showed you, you understood it). This halves it. A fear does not shrink because you wish it to; give a real reason.",
		Props: []Prop{
			{Name: "id", Type: "integer", Desc: "Fear number."},
			{Name: "why", Type: "string", Desc: "What changed."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			if err := d.Fear.Ease(int(a.Int("id")), a.Str("why")); err != nil {
				return "", err
			}
			return "It is smaller now.", nil
		},
	}
}
