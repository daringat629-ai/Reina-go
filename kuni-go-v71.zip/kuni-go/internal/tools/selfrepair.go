package tools

// SelfRepairTools are her own hands on the machine she lives on: logs, files, a backup before every change, the shell. They are given
// only in her free time (not in chats with other people) and only when the owner turned capabilities.self_repair on.
func SelfRepairTools(d Deps) []Tool {
	if !d.Cfg().SelfRepair {
		return nil
	}
	return []Tool{tailLogTool(d), readFileTool(d), grepTool(d), filesTool(d), backupTool(d), shellTool(d)}
}
