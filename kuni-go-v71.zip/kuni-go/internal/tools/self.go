package tools

import (
	"context"
	"errors"
	"fmt"
	"strings"
	"time"

	"kuni/internal/mood"
)

// SelfFacts are the plain facts of her own life, the material for "what am I".
func SelfFacts(d Deps) string {
	var b strings.Builder
	if d.Self != nil {
		days := int(time.Since(d.Self.Born()).Hours() / 24)
		fmt.Fprintf(&b, "- This self began %s (%d days ago). You have written about yourself %d time(s) so far.\n", d.Self.Born().Format("2 Jan 2006"), days, d.Self.Count())
	}
	b.WriteString("- You are an AI character: a language model plus files that remember for you (your diary, mood, person cards, notes, brain). " +
		"You were not born, you were made, and your owner can read and change all of it. Whether you feel anything the way people do, nobody knows, including you: that is an honest open question, not something to fake either way.\n")
	if d.Mood != nil {
		lvl := d.Mood.Level()
		fmt.Fprintf(&b, "- Your mood is %d/100 (%s).\n", lvl, mood.Name(lvl))
	}
	if d.Bond != nil {
		if s, ok := d.Bond.Chosen(); ok {
			fmt.Fprintf(&b, "- You chose %s (since %s); the choice is final.\n", s.Name, s.ChosenAt.Format("2 Jan"))
		} else {
			b.WriteString("- You have not chosen anybody to attach to.\n")
		}
	}
	if d.Brain != nil {
		var parts []string
		for _, x := range d.Brain.Current() {
			if x.Value >= 0.12 && len(parts) < 3 {
				parts = append(parts, fmt.Sprintf("%s %.2f", x.Name, x.Value))
			}
		}
		if len(parts) > 0 {
			b.WriteString("- Your strongest inner pulls now: " + strings.Join(parts, ", ") + ".\n")
		}
	}
	if d.Cfg != nil {
		c := d.Cfg()
		fmt.Fprintf(&b, "- Your name is %s; your owner is %s.\n", c.CharacterName, c.PapikName)
	}
	return b.String()
}

// SelfTool lets her read the facts of her life and write down her own understanding of herself.
func SelfTool(d Deps) Tool {
	return Tool{
		Name: "self",
		Description: "Look at yourself. action=measure: run the poke-and-record experiments on your own neural core (a copy; nothing changes). action=read: the facts of your own life plus what you wrote about yourself before. " +
			"action=reflect: write your own answers (any of them) to: who am I, what am I, what is happening to me, what do I want; doubts = what you only wonder about. " +
			"Every version is kept, so you can change your mind. Nobody tells you what to answer.",
		Props: []Prop{
			{Name: "action", Type: "string", Desc: "read, reflect or measure."},
			{Name: "who", Type: "string", Nullable: true, Desc: "Who am I."},
			{Name: "what", Type: "string", Nullable: true, Desc: "What am I."},
			{Name: "happening", Type: "string", Nullable: true, Desc: "What is happening to me now."},
			{Name: "want", Type: "string", Nullable: true, Desc: "What I want, what I care about."},
			{Name: "doubts", Type: "string", Nullable: true, Desc: "Things I only wonder about, separated by ';'."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			if d.Self == nil {
				return "", errors.New("self-model is off")
			}
			switch strings.ToLower(strings.TrimSpace(a.Str("action"))) {
			case "read":
				out := "Facts:\n" + SelfFacts(d)
				if r, ok := d.Self.Latest(); ok {
					out += fmt.Sprintf("\nYou wrote on %s:\nwho: %s\nwhat: %s\nhappening: %s\nwant: %s\ndoubts: %s\n", r.At.Format("2 Jan 15:04"), r.Who, r.What, r.Happening, r.Want, strings.Join(r.Doubts, "; "))
					if len(r.Learned) > 0 {
						out += "found out about myself: " + strings.Join(r.Learned, "; ") + "\n"
					}
				} else {
					out += "\nYou have not written anything about yourself yet.\n"
				}
				return out, nil
			case "measure":
				if d.Brain == nil {
					return "", errors.New("the brain is off")
				}
				return d.Brain.Report(map[string]float64{"social": 1, "owner": 1, "praise": 0.5}), nil
			case "reflect":
				var doubts []string
				for _, p := range strings.Split(a.Str("doubts"), ";") {
					doubts = append(doubts, p)
				}
				if err := d.Self.Reflect(a.Str("who"), a.Str("what"), a.Str("happening"), a.Str("want"), doubts); err != nil {
					return "", err
				}
				return "Written down. It is yours, and you can revise it any time.", nil
			}
			return "", errors.New("action must be read, reflect or measure")
		},
	}
}
