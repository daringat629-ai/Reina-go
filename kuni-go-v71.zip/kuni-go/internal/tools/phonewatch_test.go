package tools

import (
	"context"
	"strings"
	"testing"
	"time"
)

func TestPhoneWatchFeelsOnlyARealLoss(t *testing.T) {
	w := &PhoneWatch{}
	now := time.Now()
	w.Set(false, now) // never seen: nothing was lost
	if lost, _ := w.Lost(now); lost || w.Prompt(now) != "" {
		t.Fatal("a phone that was never there is not a loss")
	}
	w.Set(true, now)
	w.Set(false, now.Add(time.Minute))
	lost, d := w.Lost(now.Add(11 * time.Minute))
	if !lost || d != 10*time.Minute {
		t.Fatal("must feel the loss", lost, d)
	}
	p := w.Prompt(now.Add(11 * time.Minute))
	if !strings.Contains(p, "10 мин") || !strings.Contains(p, "не проси никого не выключать") {
		t.Fatal(p)
	}
	if lost, _ := w.Lost(now.Add(7 * time.Hour)); lost {
		t.Fatal("after hours she has got used to it")
	}
	w.Set(true, now.Add(8*time.Hour)) // back
	if lost, _ := w.Lost(now.Add(8*time.Hour + time.Minute)); lost {
		t.Fatal("the phone is back")
	}
}

func TestPhoneWatchProbeReadsStateAndBattery(t *testing.T) {
	fakeADB(t) // get-state -> device, battery level 87 not on a charger
	w := &PhoneWatch{}
	now := time.Now()
	w.Probe(context.Background(), "192.168.1.50:5555", now)
	if !w.seen || !w.up || w.level != 87 || w.power {
		t.Fatalf("seen=%v up=%v level=%d power=%v", w.seen, w.up, w.level, w.power)
	}
	if w.Prompt(now) != "" {
		t.Fatal("a healthy battery is not worth a word")
	}
}

func TestPhoneWatchBackAndLowBattery(t *testing.T) {
	w := &PhoneWatch{}
	now := time.Now()
	w.Set(true, now)
	w.Set(false, now.Add(time.Minute))
	w.Set(true, now.Add(31*time.Minute)) // back after 30 minutes
	p := w.Prompt(now.Add(32 * time.Minute))
	if !strings.Contains(p, "phone_back") || !strings.Contains(p, "30 мин") || strings.Contains(p, "phone_gone") {
		t.Fatal(p)
	}
	if w.Prompt(now.Add(5*time.Hour)) != "" {
		t.Fatal("the relief fades")
	}
	w.level, w.known = 12, true
	if p := w.Prompt(now.Add(5 * time.Hour)); !strings.Contains(p, "12%") {
		t.Fatal("low battery must be noticed:", p)
	}
	w.power = true
	if w.Prompt(now.Add(5*time.Hour)) != "" {
		t.Fatal("on a charger: nothing to say")
	}
	if l, p := parseBattery("  AC powered: true\n  level: 9\n"); l != 9 || !p {
		t.Fatal(l, p)
	}
}
