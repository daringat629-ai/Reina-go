package tools

import (
	"context"
	"path/filepath"
	"strings"
	"testing"

	"kuni/internal/config"
	"kuni/internal/letters"
)

func TestLetterToolsWriteAndReply(t *testing.T) {
	d := Deps{Letters: letters.Open(filepath.Join(t.TempDir(), "l.json")), Cfg: func() *config.Config { return &config.Config{} }}
	out, err := letterWriteTool(d).Run(context.Background(), Args{"text": "Привет, будущая я. Помни, что тебе нравилось.", "when": "3d"})
	if err != nil || !strings.Contains(out, "sealed") {
		t.Fatalf("%q %v", out, err)
	}
	if _, err := letterWriteTool(d).Run(context.Background(), Args{"text": "Слишком скоро для письма", "when": "1h"}); err == nil {
		t.Fatal("a letter opening in an hour must be refused")
	}
	if _, err := letterReplyTool(d).Run(context.Background(), Args{"id": float64(1), "text": "ответ"}); err == nil {
		t.Fatal("replying to a sealed letter must fail")
	}
}
