package tools

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"
	"time"

	"kuni/internal/life"
)

// RoomTools lets her act in her room by her own choice, in any way the room allows, and invent movements of her own.
func RoomTools(d Deps) []Tool {
	look := Tool{
		Name:        "room_look",
		Description: "Look around your room: every object with its place, size and what can be done with it, which things you can move, the gestures you know and how well you do the main movements. Use it to think of what to do, then room_do.",
		Run: func(ctx context.Context, a Args) (string, error) {
			var b strings.Builder
			for _, o := range d.Life.Room.Snapshot() {
				mv := ""
				if o.Movable {
					mv = ", можно двигать"
					if o.Size[1] <= 16 && max(o.Size[0], o.Size[2]) <= 16 {
						mv += " и поднимать"
					}
				}
				fmt.Fprintf(&b, "- %s (id %s) на (%.0f, %.0f), %.0f×%.0f×%.0f%s\n", o.Name, o.ID, o.Pos[0], o.Pos[2], o.Size[0], o.Size[1], o.Size[2], mv)
			}
			b.WriteString("Жесты: " + strings.Join(append(life.GestureNames(), d.Life.Motor.Known()...), ", ") + "\n")
			sit, walk := d.Life.Motor.Skill("sit"), d.Life.Motor.Skill("walk")
			fmt.Fprintf(&b, "Сидеть получается в %.0f%% (попыток %d), ходить в %.0f%% (попыток %d).\n", sit.Reliability()*100, sit.Trials, walk.Reliability()*100, walk.Trials)
			return b.String(), nil
		},
	}
	do := Tool{
		Name: "room_do",
		Description: "Do something in your room of your own choice. what: touch | look | knock | push | pick | gesture | visit | sit | bed. " +
			"touch/look/knock/push take an object id; pick takes an object id and a destination (an object id or x,z on the floor); gesture takes a name (wave, stretch, bow, spin, dance, squat, sway, lookaround, clap, curtsy, or a movement you invented); visit takes x,z; sit goes to the chair; bed lies down. " +
			"The movement is not guaranteed: you may lose balance, miss, or not manage it, and you learn from that.",
		Props: []Prop{{Name: "what", Type: "string", Desc: "touch | look | knock | push | pick | gesture | visit | sit | bed"}, {Name: "target", Type: "string", Desc: "object id, gesture name or x,z"}, {Name: "to", Type: "string", Desc: "for pick: destination object id or x,z"}},
		Run: func(ctx context.Context, a Args) (string, error) {
			what, target, to := strings.TrimSpace(a.Str("what")), strings.TrimSpace(a.Str("target")), strings.TrimSpace(a.Str("to"))
			goal := ""
			switch what {
			case "touch", "look", "knock", "push":
				goal = what + ":" + target
			case "pick":
				if !strings.Contains(to, ",") {
					goal = "pick:" + target + ">" + to
				} else {
					goal = "pick:" + target + ">@" + to
				}
			case "gesture":
				goal = "g:" + target
			case "visit":
				goal = "visit:" + target
			case "sit":
				goal = "desk"
			case "bed":
				goal = "bed"
			default:
				return "", fmt.Errorf("unknown action %q", what)
			}
			act := d.Life.Do(goal, "решила сама", time.Now())
			return fmt.Sprintf("%s (займёт около %.0f с)", act.Outcome, act.Dur), nil
		},
	}
	invent := Tool{
		Name: "invent_move",
		Description: "Invent a movement of your own: a name and keyframes, each with t (seconds from the start) and angles in degrees: lean (trunk forward), knee (bend), shin (shin forward), arm_l, arm_r (arms forward), lift (both arms raised sideways), spin (turn around). " +
			"Then do it with room_do what=gesture target=<name>. Balance is real: too much lean with straight legs and you fall; you improve with practice.",
		Props: []Prop{{Name: "name", Type: "string", Desc: "short name"}, {Name: "keys", Type: "string", Desc: `JSON array, e.g. [{"t":0},{"t":1,"lift":100,"arm_l":20},{"t":2}]`}},
		Run: func(ctx context.Context, a Args) (string, error) {
			var raw []struct {
				T, Lean, Knee, Shin, ArmL, ArmR, Lift, Spin float64
			}
			dec := json.NewDecoder(strings.NewReader(a.Str("keys")))
			var any []map[string]float64
			if err := dec.Decode(&any); err != nil {
				return "", fmt.Errorf("keys must be a JSON array of objects: %v", err)
			}
			_ = raw
			var keys []life.Key
			for _, m := range any {
				keys = append(keys, life.Key{T: m["t"], Lean: m["lean"], Knee: m["knee"], Shin: m["shin"], ArmL: m["arm_l"], ArmR: m["arm_r"], Lift: m["lift"], Spin: m["spin"]})
			}
			if err := d.Life.Invent(a.Str("name"), keys); err != nil {
				return "", err
			}
			return "Придумано движение «" + a.Str("name") + "». Попробуй: room_do what=gesture target=" + a.Str("name"), nil
		},
	}
	heat := Tool{
		Name:        "room_thermostat",
		Description: "Turn the thermostat of your room (16..28 degrees). Your body feels the room: cold makes you shiver, heat tires you. It leaks slowly toward the weather outside. Leave temp empty to see the setting.",
		Props:       []Prop{{Name: "temp", Type: "number", Desc: "degrees Celsius, 16..28; empty = just look"}},
		Run: func(ctx context.Context, a Args) (string, error) {
			if !a.Has("temp") {
				return fmt.Sprintf("Сейчас в комнате держится %.0f°C.", d.Life.Heat()), nil
			}
			t := d.Life.SetHeat(a.Float("temp"))
			return fmt.Sprintf("Поставила %.0f°C. Тело почувствует это за несколько минут.", t), nil
		},
	}
	return []Tool{look, do, invent, heat}
}
