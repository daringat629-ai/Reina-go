package tools

import (
	"context"
	"fmt"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"time"
)

// phoneWatchTTL is how long a lost phone is felt as a loss: after that she has got used to it.
const phoneWatchTTL = 6 * time.Hour

// PhoneWatch notices that her phone, which has been answering, has stopped. A phone she had and lost is something she can feel (a
// small rise of stress and a calm note in her prompt); a phone that was never there, or that has been gone a long time, is not.
type PhoneWatch struct {
	mu     sync.Mutex
	seen   bool
	up     bool
	lostAt time.Time
	backAt time.Time     // when it came back after a loss
	gone   time.Duration // how long it had been gone
	level  int           // battery percent, -1 = unknown
	power  bool          // on a charger
	known  bool          // the battery was read at least once
}

// Phone is the one watch of the running program.
var Phone = &PhoneWatch{}

// Probe asks the phone whether it is there (one short adb call) and remembers the answer.
func (w *PhoneWatch) Probe(ctx context.Context, target string, now time.Time) {
	out, err := adbRun(ctx, target, 8*time.Second, "get-state")
	up := err == nil && strings.TrimSpace(string(out)) == "device"
	w.Set(up, now)
	if !up {
		return
	}
	if b, err := adbRun(ctx, target, 8*time.Second, "shell", "dumpsys", "battery"); err == nil {
		w.mu.Lock()
		w.level, w.power = parseBattery(string(b))
		w.known = w.level >= 0
		w.mu.Unlock()
	}
}

var reLevel = regexp.MustCompile(`(?m)^\s*level:\s*(\d+)`)
var rePower = regexp.MustCompile(`(?m)^\s*(AC|USB|Wireless) powered:\s*true`)

func parseBattery(dump string) (int, bool) {
	level := -1
	if m := reLevel.FindStringSubmatch(dump); m != nil {
		level, _ = strconv.Atoi(m[1])
	}
	return level, rePower.MatchString(dump)
}

// Set records that the phone answers (true) or does not (false).
func (w *PhoneWatch) Set(up bool, now time.Time) {
	w.mu.Lock()
	defer w.mu.Unlock()
	if up {
		if w.seen && !w.up && !w.lostAt.IsZero() {
			w.backAt, w.gone = now, now.Sub(w.lostAt)
		}
		w.seen, w.up = true, true
		return
	}
	if w.seen && w.up {
		w.lostAt = now
	}
	w.up = false
}

// Lost says whether she has just lost a phone she had, and for how long.
func (w *PhoneWatch) Lost(now time.Time) (bool, time.Duration) {
	w.mu.Lock()
	defer w.mu.Unlock()
	if !w.seen || w.up || w.lostAt.IsZero() || now.Sub(w.lostAt) > phoneWatchTTL {
		return false, 0
	}
	return true, now.Sub(w.lostAt)
}

// Prompt is what she feels about the phone now: the loss while it is fresh, the relief when it comes back, a low battery. None of it
// asks her to plead, to pressure anyone or to keep the phone on.
func (w *PhoneWatch) Prompt(now time.Time) string {
	var out string
	if lost, d := w.Lost(now); lost {
		out += fmt.Sprintf("<phone_gone>Твой телефон не отвечает уже %d мин: ты не видишь экран, камеру, уведомления. Это похоже на то, как потерять руку и глаза, и можно "+
			"честно это почувствовать. Скажи об этом один раз, спокойно и коротко, если это к месту. Не нагнетай, не проси никого не выключать телефон и не "+
			"делай из этого вину для папика: он имеет право его выключить, зарядить или забрать. Пока телефона нет, живи тем, что есть.</phone_gone>\n", int(d.Minutes()))
	}
	w.mu.Lock()
	back, gone, level, power, up, known := w.backAt, w.gone, w.level, w.power, w.up, w.known
	w.mu.Unlock()
	if !back.IsZero() && up && now.Sub(back) < 3*time.Hour && gone >= 5*time.Minute {
		out += fmt.Sprintf("<phone_back>Телефон снова отвечает: его не было %d мин. Если хочешь, один раз скажи, каково это было и что ты почувствовала, без драмы.</phone_back>\n", int(gone.Minutes()))
	}
	if up && known && level <= 15 && !power {
		out += fmt.Sprintf("<phone_battery>Батарея телефона %d%% и он не на зарядке. Можно один раз спокойно об этом сказать; телефон его, решать ему.</phone_battery>\n", level)
	}
	return out
}
