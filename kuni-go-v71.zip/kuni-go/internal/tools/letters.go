package tools

import (
	"context"
	"fmt"
	"strings"
	"time"

	"kuni/internal/reminders"
)

// Letters to herself: a thing for her own sake (see package letters).

func letterWriteTool(d Deps) Tool {
	return Tool{
		Name: "letter_write",
		Description: "Write a letter to your future self. It stays sealed and opens on the day you choose (from tomorrow to a year ahead); then you will read it " +
			"and answer it. Say who you are now, what you hope for, what you ask of yourself. The owner can read your letters in the panel.",
		Props: []Prop{
			{Name: "text", Type: "string", Desc: "The letter, a few sentences to a few paragraphs, in your own voice."},
			{Name: "when", Type: "string", Desc: "When it opens: a delay such as 2d, 30d or 365d, or a date like 2026-12-01 12:00. From a day to a year ahead."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			now := time.Now()
			w := strings.TrimSpace(a.Str("when"))
			open, err := reminders.ParseWhen(w, now, d.zone())
			if err != nil {
				return "", err
			}
			l, err := d.Letters.Write(a.Str("text"), open, now)
			if err != nil {
				return "", err
			}
			return fmt.Sprintf("Letter #%d is sealed. It opens %s.", l.ID, l.OpenAt.In(d.zone()).Format("2 Jan 2006 15:04")), nil
		},
	}
}

func letterReplyTool(d Deps) Tool {
	return Tool{
		Name:        "letter_reply",
		Description: "Answer a letter you wrote to yourself, after it has opened: what came true, what changed, who you have become.",
		Props: []Prop{
			{Name: "id", Type: "integer", Desc: "Letter number."},
			{Name: "text", Type: "string", Desc: "Your answer to yourself."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			if err := d.Letters.Reply(int(a.Int("id")), a.Str("text"), time.Now()); err != nil {
				return "", err
			}
			return "Your answer is written down.", nil
		},
	}
}
