package tools

import (
	"context"
	"fmt"
	"sort"
	"strings"
)

// CortexTool lets her look at her own region brain: which regions are active, what each one does, the neuromodulators.
func CortexTool(d Deps) Tool {
	return Tool{
		Name:        "brain_regions",
		Description: "Look at your own brain made of human brain regions (computational analogues, millions of simulated neurons, not biology): leave empty to see the most active regions and the neuromodulators, or give a region id (amygdala, hippocampus, pfc_dl, striatum, acc, insula, cerebellum, thalamus, vta, dmn...) for what it does and how active it is now.",
		Props:       []Prop{{Name: "region", Type: "string", Desc: "region id or name; empty = overview"}},
		Run: func(ctx context.Context, a Args) (string, error) {
			if q := a.Str("region"); q != "" {
				return d.Cortex.Report(q), nil
			}
			rs := d.Cortex.Regions()
			sort.Slice(rs, func(i, j int) bool { return rs[i].Act > rs[j].Act })
			var b strings.Builder
			fmt.Fprintf(&b, "Нейронов %d, областей %d.\n", d.Cortex.Net.Total(), len(rs))
			for _, r := range rs[:10] {
				fmt.Fprintf(&b, "%s (%s): %.0f%% — %s\n", r.Name, r.ID, r.Act*100, r.Machine)
			}
			return b.String() + d.Cortex.Prompt(), nil
		},
	}
}
