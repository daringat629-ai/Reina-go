package tools

import (
	"context"
	"strings"
	"testing"

	"kuni/internal/life"
)

func TestRoomThermostatTool(t *testing.T) {
	d := Deps{Life: life.New(t.TempDir(), 1)}
	var th Tool
	for _, x := range RoomTools(d) {
		if x.Name == "room_thermostat" {
			th = x
		}
	}
	if th.Run == nil {
		t.Fatal("no thermostat tool")
	}
	if out, _ := th.Run(context.Background(), Args{}); !strings.Contains(out, "22") {
		t.Fatal(out)
	}
	if out, _ := th.Run(context.Background(), Args{"temp": 25.0}); !strings.Contains(out, "25") || d.Life.Heat() != 25 {
		t.Fatal(out, d.Life.Heat())
	}
	th.Run(context.Background(), Args{"temp": 5.0})
	if d.Life.Heat() != 16 {
		t.Fatal(d.Life.Heat())
	}
}
