package tools

import (
	"context"
	"fmt"
	"time"
)

// Keepsakes: a box of things she chose to keep (see package keepsakes).

func keepsakeAddTool(d Deps) Tool {
	return Tool{
		Name: "keepsake_add",
		Description: "Put something in your keepsake box: a moment, a sentence that was said to you, a thing you liked, something you do not want to lose. " +
			"Unlike ordinary memory it does not fade; it stays until you let it go yourself, and now and then it comes back to you. The box holds 40. " +
			"The owner can read it in the panel. Do not keep other people's private details here, only what is yours.",
		Props: []Prop{
			{Name: "text", Type: "string", Desc: "What you keep (a sentence or two)."},
			{Name: "why", Type: "string", Desc: "Why it matters to you; your future self will read this."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			it, err := d.Keepsakes.Keep(a.Str("text"), a.Str("why"), time.Now())
			if err != nil {
				return "", err
			}
			return fmt.Sprintf("Kept as #%d.", it.ID), nil
		},
	}
}

func keepsakeReleaseTool(d Deps) Tool {
	return Tool{
		Name:        "keepsake_release",
		Description: "Let a keepsake go when it is no longer yours, or to make room in the box.",
		Props:       []Prop{{Name: "id", Type: "integer", Desc: "Keepsake number."}},
		Run: func(ctx context.Context, a Args) (string, error) {
			if err := d.Keepsakes.Release(int(a.Int("id"))); err != nil {
				return "", err
			}
			return "Let go.", nil
		},
	}
}
