package city

import (
	"net/http/httptest"
	"strings"
	"testing"
)

func TestStateCarriesWhatSheDecided(t *testing.T) {
	h := Handler(func() State { return State{Doing: &Doing{ID: 3, Goal: "g:wave", OK: true, Dur: 2}} })
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, httptest.NewRequest("GET", "/state.json", nil))
	if !strings.Contains(rec.Body.String(), `"goal":"g:wave"`) {
		t.Fatalf("doing missing: %s", rec.Body.String())
	}
}

func TestCityCarriesHerLifeAndAssets(t *testing.T) {
	h := HandlerLife(func() State { return State{} }, func(have int64) any { return map[string]any{"room": 1} }, nil)
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, httptest.NewRequest("GET", "/state.json?have=5", nil))
	if !strings.Contains(rec.Body.String(), `"life":{"room":1}`) {
		t.Fatalf("life missing: %s", rec.Body.String())
	}
	rec = httptest.NewRecorder()
	h.ServeHTTP(rec, httptest.NewRequest("GET", "/body/model.obj", nil))
	if rec.Code != 200 || rec.Body.Len() < 1000 {
		t.Fatalf("her model must be served: %d", rec.Code)
	}
	rec = httptest.NewRecorder()
	h.ServeHTTP(rec, httptest.NewRequest("GET", "/body/index.html", nil))
	if rec.Code == 200 {
		t.Fatal("only the model and textures are served")
	}
}
