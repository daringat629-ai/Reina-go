// Package city is the third world: a big working city and Reina's room at the top of one tower, running in real time in the browser.
// The page simulates everything itself (day and night by the viewer's clock, traffic and its lights, people on the pavements, the lit
// windows); the server only says what her brain wants now, so that she lives in it: sleeps in her bed, works at the desk, looks out of
// the window at the city, reads, or goes out and walks the streets, by her real drives.
package city

import (
	_ "embed"
	"encoding/json"
	"net/http"
	"strconv"
	"time"

	"kuni/internal/anatomy"
)

//go:embed index.html
var page []byte

// Drive is one output of her brain, 0..1.
type Drive struct {
	Name  string  `json:"name"`
	Value float64 `json:"value"`
}

// Event is one line of what she does (the panel's feed): what the monitor and the phone in her room show.
type Event struct {
	ID     int64  `json:"id"`
	At     int64  `json:"at"` // unix milliseconds
	Kind   string `json:"kind"`
	Chat   string `json:"chat,omitempty"`
	Text   string `json:"text"`
	Typing string `json:"typing,omitempty"`
}

// State is what the page needs to know about her now.
type State struct {
	Drives []Drive `json:"drives"`
	Mood   int     `json:"mood"`            // 0..100, -1 when unknown
	Now    int64   `json:"now"`             // unix milliseconds on the server
	Feed   []Event `json:"feed"`            // the last events of her feed, oldest first
	Sky    Sky     `json:"sky"`             // the weather above the city
	Home   bool    `json:"home"`            // she stays in her flat: no walks in the city
	Study  bool    `json:"study"`           // she has just been studying: she sits at her desk
	Doing  *Doing  `json:"doing,omitempty"` // what she decided in her room just now (the movement brain: internal/life)
	Life   any     `json:"life,omitempty"`  // her real room and body: objects with hitboxes and the recording of what she does (see HandlerLife)
}

// Doing is the last thing she decided to do with her body in the room: the city avatar plays it in its own room.
type Doing struct {
	ID      int64   `json:"id"`
	Goal    string  `json:"goal"` // desk, bed, window, shelf, wander, g:<gesture>, touch:<id> ...
	OK      bool    `json:"ok"`
	Outcome string  `json:"outcome"`
	Elapsed float64 `json:"elapsed"` // seconds since it began
	Dur     float64 `json:"dur"`
}

// Sky is the weather the world draws (and her body feels).
type Sky struct {
	Temp  float64 `json:"temp"`
	Wind  float64 `json:"wind"`
	Rain  float64 `json:"rain"`
	Cloud float64 `json:"cloud"`
}

// Handler serves the page (GET /) and state.json. The state function is called on every poll, so it must be cheap.
//
// report (optional) is told where she is whenever the page POSTs /report {"outside":bool,"act":string}: in her room or out in the city.
func Handler(state func() State, report ...func(outside bool, act string)) http.Handler {
	return HandlerLife(state, nil, report...)
}

// HandlerLife is Handler plus her life: life(have) is her room (objects, hitboxes) and her motion (the action she is performing, its
// frames only when the page does not have it yet, have = its id). With it the page puts her real model and her real room in the world.
func HandlerLife(state func() State, life func(have int64) any, report ...func(outside bool, act string)) http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("/report", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost || len(report) == 0 || report[0] == nil {
			http.Error(w, "POST only", http.StatusMethodNotAllowed)
			return
		}
		var in struct {
			Outside bool   `json:"outside"`
			Act     string `json:"act"`
		}
		if json.NewDecoder(http.MaxBytesReader(w, r.Body, 1<<10)).Decode(&in) != nil {
			http.Error(w, "bad request", http.StatusBadRequest)
			return
		}
		if len(in.Act) > 32 {
			in.Act = in.Act[:32]
		}
		report[0](in.Outside, in.Act)
		w.WriteHeader(http.StatusNoContent)
	})
	mux.HandleFunc("/state.json", func(w http.ResponseWriter, r *http.Request) {
		st := State{Mood: -1}
		if state != nil {
			st = state()
		}
		st.Now = time.Now().UnixMilli()
		if life != nil {
			have, _ := strconv.ParseInt(r.URL.Query().Get("have"), 10, 64)
			st.Life = life(have)
		}
		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("Cache-Control", "no-store")
		_ = json.NewEncoder(w).Encode(st)
	})
	mux.Handle("/body/", http.StripPrefix("/body", anatomy.Assets()))
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Header().Set("Cache-Control", "no-store")
		_, _ = w.Write(page)
	})
	return mux
}
