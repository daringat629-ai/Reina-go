package admin

import (
	"net/http"
	"time"
)

// lettersAPI lists her letters to herself for the "Сны" tab. The text of a letter that has not opened is kept back: the owner sees
// that it exists and when it opens, and reads it when the day comes, together with her.
func (p *Panel) lettersAPI(w http.ResponseWriter, r *http.Request) {
	if p.Letters == nil {
		fail(w, http.StatusNotFound, "письма себе выключены")
		return
	}
	now := time.Now()
	out := p.Letters.All(now)
	for i := range out {
		if out[i].OpenAt.After(now) {
			out[i].Text = ""
		}
	}
	writeJSON(w, map[string]any{"letters": out})
}
