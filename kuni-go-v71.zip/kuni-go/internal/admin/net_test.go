package admin

import (
	"encoding/json"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"kuni/internal/cortex"
	"kuni/internal/keepsakes"
	"kuni/internal/letters"
)

func TestNetAPIShowsRegionsEdgesAndOutputs(t *testing.T) {
	p, mux, _, _ := rig(t)
	// without a brain the tab says so instead of failing
	req := httptest.NewRequest("GET", "/admin/api/net", nil)
	req.Header.Set("Authorization", "Bearer "+tok)
	rec := httptest.NewRecorder()
	mux.ServeHTTP(rec, req)
	if rec.Code != 404 {
		t.Fatal("no cortex must be 404, got", rec.Code)
	}
	p.Cortex = cortex.New("", 50000, 3)
	p.Cortex.Step(cortex.Inputs{Hour: 12, Channels: map[string]float64{}})
	p.Machine = func() (any, bool) { return map[string]any{"load": .4}, true }
	rec = httptest.NewRecorder()
	mux.ServeHTTP(rec, req)
	if rec.Code != 200 {
		t.Fatal(rec.Code, rec.Body.String())
	}
	var j struct {
		Regions []struct {
			ID, Group string
			Pos       [3]float64
			Act       float64
		}
		Edges   []struct{ From, To string }
		Neurons int
		Out     map[string]any
		Machine map[string]any
	}
	if err := json.Unmarshal(rec.Body.Bytes(), &j); err != nil {
		t.Fatal(err)
	}
	if len(j.Regions) != len(cortex.Regions) || len(j.Edges) != len(cortex.Edges) || j.Neurons < 50000 {
		t.Fatalf("regions %d edges %d neurons %d", len(j.Regions), len(j.Edges), j.Neurons)
	}
	for _, r := range j.Regions {
		if r.Group == "" || r.Act < 0 || r.Act > 1 {
			t.Fatalf("bad region %+v", r)
		}
	}
	if _, ok := j.Out["Arousal"]; !ok || j.Machine["load"] != .4 {
		t.Fatal("outputs/machine missing", j.Out, j.Machine)
	}
}

func TestDreamsAPI(t *testing.T) {
	p, mux, _, _ := rig(t)
	req := httptest.NewRequest("GET", "/admin/api/dreams", nil)
	req.Header.Set("Authorization", "Bearer "+tok)
	rec := httptest.NewRecorder()
	mux.ServeHTTP(rec, req)
	if rec.Code != 404 {
		t.Fatal(rec.Code)
	}
	p.Cortex = cortex.New("", 50000, 3)
	rec = httptest.NewRecorder()
	mux.ServeHTTP(rec, req)
	if rec.Code != 200 || !strings.Contains(rec.Body.String(), `"dreams"`) {
		t.Fatal(rec.Code, rec.Body.String())
	}
}

func TestLettersAPIHidesSealedText(t *testing.T) {
	st := letters.Open(filepath.Join(t.TempDir(), "l.json"))
	now := time.Now()
	if _, err := st.Write("запечатанное письмо себе", now.Add(48*time.Hour), now); err != nil {
		t.Fatal(err)
	}
	p := &Panel{Letters: st}
	rec := httptest.NewRecorder()
	p.lettersAPI(rec, httptest.NewRequest("GET", "/api/letters", nil))
	if rec.Code != 200 || !strings.Contains(rec.Body.String(), `"id":1`) || strings.Contains(rec.Body.String(), "запечатанное") {
		t.Fatalf("code %d body %s", rec.Code, rec.Body.String())
	}
}

func TestKeepsakesAPIShowsTheBox(t *testing.T) {
	st := keepsakes.Open(filepath.Join(t.TempDir(), "k.json"))
	if _, err := st.Keep("Дождь пахнет пылью и железом.", "мне нравится, как это звучит", time.Now()); err != nil {
		t.Fatal(err)
	}
	p := &Panel{Keepsakes: st}
	rec := httptest.NewRecorder()
	p.keepsakesAPI(rec, httptest.NewRequest("GET", "/api/keepsakes", nil))
	if rec.Code != 200 || !strings.Contains(rec.Body.String(), "пылью") {
		t.Fatalf("code %d body %s", rec.Code, rec.Body.String())
	}
	if (&Panel{}).Keepsakes != nil {
		t.Fatal("unreachable")
	}
}
