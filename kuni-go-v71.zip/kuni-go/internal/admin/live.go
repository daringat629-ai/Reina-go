package admin

import (
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"
	"time"

	"kuni/internal/anatomy"
	"kuni/internal/body"
	"kuni/internal/city"
	"kuni/internal/live"
	"kuni/internal/physics"
)

// liveFrame serves the current picture of her browser or desktop (JPEG, never cached); 204 when that screen is not running.
func (p *Panel) liveFrame(w http.ResponseWriter, r *http.Request) {
	if p.Frame == nil {
		http.Error(w, "live view is off", http.StatusNotFound)
		return
	}
	src := r.URL.Query().Get("src")
	if src != "desktop" && src != "browser" {
		http.Error(w, "src must be desktop or browser", http.StatusBadRequest)
		return
	}
	data, meta, ok, err := p.Frame(r.Context(), src)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadGateway)
		return
	}
	if !ok {
		w.WriteHeader(http.StatusNoContent)
		return
	}
	w.Header().Set("Content-Type", "image/jpeg")
	w.Header().Set("Cache-Control", "no-store")
	if meta != "" {
		w.Header().Set("X-Pointer", meta)
	}
	_, _ = w.Write(data)
}

// liveEvents returns the feed since an id and which screens are up.
func (p *Panel) liveEvents(w http.ResponseWriter, r *http.Request) {
	since, _ := strconv.ParseInt(r.URL.Query().Get("since"), 10, 64)
	out := map[string]any{"events": []any{}, "last": int64(0), "browser": false, "desktop": false, "paused": false}
	if p.Feed != nil {
		if evs := p.Feed.Since(since); len(evs) > 0 {
			out["events"] = evs
		}
		out["last"] = p.Feed.Last()
	}
	if p.Screens != nil {
		out["browser"], out["desktop"] = p.Screens()
	}
	if p.Ctl != nil {
		out["paused"] = p.Ctl.Paused()
	}
	writeJSON(w, out)
}

// livePointer is the desktop pointer position, cheap enough to poll several times a second.
func (p *Panel) livePointer(w http.ResponseWriter, r *http.Request) {
	s := ""
	if p.Pointer != nil {
		s = p.Pointer(r.URL.Query().Get("src"))
	}
	w.Header().Set("Cache-Control", "no-store")
	writeJSON(w, map[string]string{"p": s})
}

// liveStream is a continuous motion-JPEG stream of her screen: the browser shows it in a plain <img>. Pictures are sent only
// when the screen changed (15 a second by default, ?fps=1..30), so a still desktop costs almost nothing.
func (p *Panel) liveStream(w http.ResponseWriter, r *http.Request) {
	if p.Stream == nil {
		http.Error(w, "live view is off", http.StatusNotFound)
		return
	}
	src := r.URL.Query().Get("src")
	if src != "desktop" && src != "browser" {
		http.Error(w, "src must be desktop or browser", http.StatusBadRequest)
		return
	}
	fl, ok := w.(http.Flusher)
	if !ok {
		http.Error(w, "no streaming here", http.StatusInternalServerError)
		return
	}
	const boundary = "reinaframe"
	w.Header().Set("Content-Type", "multipart/x-mixed-replace; boundary="+boundary)
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("X-Accel-Buffering", "no")
	var prev uint64
	lastSent := time.Now()
	fps, _ := strconv.Atoi(r.URL.Query().Get("fps"))
	if fps < 1 || fps > 30 {
		fps = 15
	}
	tick := time.NewTicker(time.Second / time.Duration(fps))
	defer tick.Stop()
	for {
		data, hash, changed, up, err := p.Stream(r.Context(), src, prev)
		if err != nil || !up {
			return // the page notices the stream ended and looks again
		}
		prev = hash
		if changed || time.Since(lastSent) > 5*time.Second { // a keep-alive picture so a proxy does not close a still stream
			if data == nil {
				data, _, _, _, _ = p.Stream(r.Context(), src, 0)
			}
			if _, err := fmt.Fprintf(w, "--%s\r\nContent-Type: image/jpeg\r\nContent-Length: %d\r\n\r\n", boundary, len(data)); err != nil {
				return
			}
			if _, err := w.Write(data); err != nil {
				return
			}
			_, _ = w.Write([]byte("\r\n"))
			fl.Flush()
			lastSent = time.Now()
		}
		select {
		case <-r.Context().Done():
			return
		case <-tick.C:
		}
	}
}

const deskPage = `<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Рабочий стол Рейны</title><style>
html,body{margin:0;height:100%;background:#05060a;color:#9aa4b2;font:14px system-ui,sans-serif}
body{display:flex;align-items:center;justify-content:center}
img{max-width:100vw;max-height:100vh;object-fit:contain;display:none}
#off{text-align:center;line-height:1.6}
#st{position:fixed;left:10px;bottom:8px;font-size:12px;opacity:.6}
</style></head><body><img id="v" alt=""><div id="off">Рабочий стол сейчас выключен.<br>Он включится, когда Рейна начнёт им пользоваться.</div><div id="st"></div>
<script>
var v=document.getElementById("v"),off=document.getElementById("off"),st=document.getElementById("st"),on=false;
function start(){v.src="/admin/api/live/stream?src=desktop&fps=15&t="+Date.now();}
v.onload=function(){on=true;v.style.display="block";off.style.display="none";st.textContent="прямой эфир"};
v.onerror=function(){on=false;v.style.display="none";off.style.display="";st.textContent="";setTimeout(start,2000)};
document.addEventListener("dblclick",function(){document.fullscreenElement?document.exitFullscreen():document.documentElement.requestFullscreen()});
start();
</script></body></html>`

// deskPage is a bare full-window view of her desktop (double click = full screen), for a second screen or a laptop.
// /admin/desk?token=<misc.admin_token> signs in and shows it.
func (p *Panel) desk(w http.ResponseWriter, r *http.Request) {
	if !Enabled(p.Cfg()) {
		http.NotFound(w, r)
		return
	}
	ip := clientIP(r)
	if t := r.URL.Query().Get("token"); t != "" {
		if p.blocked(ip) {
			http.Error(w, "too many attempts, try later", http.StatusTooManyRequests)
			return
		}
		if same(t, p.Cfg().AdminToken) {
			http.SetCookie(w, &http.Cookie{Name: cookieName, Value: t, Path: "/admin", HttpOnly: true, SameSite: http.SameSiteStrictMode, MaxAge: 30 * 24 * 3600})
			http.Redirect(w, r, "/admin/desk", http.StatusSeeOther)
			return
		}
		p.fail(ip)
	}
	if !p.authed(r) {
		http.Error(w, "нужен вход: открой /admin/desk?token=<misc.admin_token>", http.StatusUnauthorized)
		return
	}
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("X-Frame-Options", "DENY")
	w.Header().Set("Content-Security-Policy", "default-src 'none'; img-src 'self'; style-src 'unsafe-inline'; script-src 'unsafe-inline'")
	_, _ = w.Write([]byte(deskPage))
}

// brainView is the 3D view of her neural core: /admin/brain/ (the token in the query sets the cookie, as for the desk).
func (p *Panel) brainView(w http.ResponseWriter, r *http.Request) {
	if p.Brain == nil {
		http.NotFound(w, r)
		return
	}
	p.worldView("/admin/brain", func() http.Handler { return p.Brain.Handler() })(w, r)
}

// cityView is the third world, her city and her room: /admin/city/. It lives by her brain's drives and her mood.
func (p *Panel) cityView(w http.ResponseWriter, r *http.Request) {
	p.worldView("/admin/city", func() http.Handler {
		return city.HandlerLife(func() city.State {
			st := city.State{Mood: -1}
			if p.Brain != nil {
				for _, d := range p.Brain.Drives() {
					st.Drives = append(st.Drives, city.Drive{Name: d.Name, Value: d.Value})
				}
			}
			if p.Mood != nil {
				st.Mood = p.Mood.Level()
			}
			st.Home = p.Cfg().WorldStayHome
			if p.Life != nil {
				if a, el := p.Life.Current(time.Now()); a != nil {
					st.Doing = &city.Doing{ID: a.ID, Goal: a.Goal, OK: a.OK, Outcome: a.Outcome, Elapsed: el, Dur: a.Dur}
				}
			}
			st.Study = p.Learn != nil && time.Since(p.Learn.Last()) < 6*time.Minute
			wx := physics.At(time.Now())
			st.Sky = city.Sky{Temp: wx.Temp, Wind: wx.Wind, Rain: wx.Rain, Cloud: wx.Cloud}
			evs := p.Feed.Since(0)
			if len(evs) > 40 {
				evs = evs[len(evs)-40:]
			}
			for _, e := range evs {
				if len([]rune(e.Typing)) > 200 {
					e.Typing = string([]rune(e.Typing)[:200])
				}
				st.Feed = append(st.Feed, city.Event{ID: e.ID, At: e.At.UnixMilli(), Kind: e.Kind, Chat: e.Chat, Text: e.Text, Typing: e.Typing})
			}
			return st
		}, p.lifeWorld, func(outside bool, act string) {
			if p.Presence != nil {
				p.Presence.Report(outside, act, time.Now())
			}
		})
	})(w, r)
}

// worldView serves a page of the panel under prefix with the same login as the desk (?token= sets the cookie).
func (p *Panel) worldView(prefix string, h func() http.Handler) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if !Enabled(p.Cfg()) {
			http.NotFound(w, r)
			return
		}
		if t := r.URL.Query().Get("token"); t != "" && r.URL.Path == prefix+"/" {
			ip := clientIP(r)
			if p.blocked(ip) {
				http.Error(w, "too many attempts, try later", http.StatusTooManyRequests)
				return
			}
			if !same(t, p.Cfg().AdminToken) {
				p.fail(ip)
				http.Error(w, "unauthorized", http.StatusUnauthorized)
				return
			}
			http.SetCookie(w, &http.Cookie{Name: cookieName, Value: t, Path: "/admin", HttpOnly: true, SameSite: http.SameSiteStrictMode, MaxAge: 30 * 24 * 3600})
			http.Redirect(w, r, prefix+"/", http.StatusSeeOther)
			return
		}
		p.guard(http.StripPrefix(prefix, h()).ServeHTTP)(w, r)
	}
}

// liveControl lets the owner use her desktop from the panel: click, drag, scroll, type text, press keys. The same screen, the same
// pointer: she sees the result in her next picture. Moves are not written to her feed, everything else is, so she knows who did it.
func (p *Panel) liveControl(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "POST only", http.StatusMethodNotAllowed)
		return
	}
	if p.Control == nil {
		fail(w, http.StatusNotFound, "управление рабочим столом выключено")
		return
	}
	var req struct {
		Src string `json:"src"`
		ControlReq
	}
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 16<<10)).Decode(&req); err != nil {
		fail(w, http.StatusBadRequest, "неверный запрос")
		return
	}
	if req.Src != "desktop" {
		fail(w, http.StatusBadRequest, "управлять можно рабочим столом (src=desktop)")
		return
	}
	if err := p.Control(req.Src, req.ControlReq); err != nil {
		fail(w, http.StatusConflict, err.Error())
		return
	}
	if req.Op != "move" && p.Feed != nil {
		note := req.Op
		switch req.Op {
		case "click":
			note = fmt.Sprintf("клик (%d,%d)", req.X, req.Y)
		case "drag":
			note = fmt.Sprintf("тянет (%d,%d)→(%d,%d)", req.X, req.Y, req.X2, req.Y2)
		case "scroll":
			note = "прокрутка"
		case "type":
			note = "печатает текст"
		case "key":
			note = "клавиша " + req.Key
		}
		p.Feed.AddEvent(live.Event{Kind: "owner", Chat: "рабочий стол", Text: "папик управляет рабочим столом: " + note})
	}
	writeJSON(w, map[string]any{"ok": true})
}

// bodyView is the live 3D model of her body with its organs lit by their load: /admin/body3d/.
func (p *Panel) bodyView(w http.ResponseWriter, r *http.Request) {
	if p.Body == nil {
		http.NotFound(w, r)
		return
	}
	p.worldView("/admin/body3d", func() http.Handler {
		return anatomy.Handler(func(have int64) anatomy.State {
			s := p.Body.Snapshot()
			if time.Since(s.Last) > time.Minute {
				p.Body.Tick(time.Now(), body.Working, body.DefaultEnv)
				s = p.Body.Snapshot()
			}
			var pact string
			if p.Presence != nil {
				_, pact = p.Presence.Outside(time.Now())
			}
			studying := p.Learn != nil && time.Since(p.Learn.Last()) < 6*time.Minute
			st := anatomy.State{Organs: anatomy.Organs(s), Bones: anatomy.Skeleton(s), Act: anatomy.ActFor(s.Doing, pact, studying)}
			if p.Cortex != nil {
				st.Organs = append(st.Organs, brainOrgans(p.Cortex)...)
			}
			if p.Life != nil {
				st.Room = map[string]any{"objects": p.Life.Room.Snapshot(), "boxes": p.Life.Room.Hitboxes(), "half": []float64{p.Life.Room.HalfX, p.Life.Room.HalfZ}}
				st.Motion = p.Life.View(have)
			}
			return st
		})
	})(w, r)
}

// lifeWorld is her real room and body for the city page: the objects with their hitboxes and what she does on her own now.
func (p *Panel) lifeWorld(have int64) any {
	if p.Life == nil {
		return nil
	}
	return map[string]any{
		"room":   map[string]any{"objects": p.Life.Room.Snapshot(), "boxes": p.Life.Room.Hitboxes(), "half": []float64{p.Life.Room.HalfX, p.Life.Room.HalfZ}},
		"motion": p.Life.View(have),
	}
}
