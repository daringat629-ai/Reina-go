package admin

import (
	"net/http"
	"time"
)

// billingAPI lists people's plans and the payments, for the panel.
func (p *Panel) billingAPI(w http.ResponseWriter, r *http.Request) {
	if p.Billing == nil {
		fail(w, http.StatusNotFound, "тарифы выключены")
		return
	}
	us, pays := p.Billing.All(time.Now())
	stars := 0
	for _, x := range pays {
		stars += x.Stars
	}
	writeJSON(w, map[string]any{"enabled": p.Cfg().BillingEnabled, "users": us, "payments": pays, "stars": stars})
}
