package admin

import (
	"encoding/base64"
	"io"
	"net/http"
	"strings"
)

// TalkResult is one turn of the live call: what she heard, what she answered, and the answer as speech (empty if she has no voice).
type TalkResult struct {
	Heard  string `json:"heard"`
	Reply  string `json:"reply"`
	Audio  string `json:"audio,omitempty"` // base64
	Mime   string `json:"mime,omitempty"`
	Silent bool   `json:"silent,omitempty"` // nothing intelligible was heard
}

const maxTalkBytes = 8 << 20

// liveTalk is one turn of the voice call from the panel: the browser sends a recorded phrase (the body, with its media type), she
// answers with text and, when a voice is configured, speech. Half-duplex on purpose: the page records, sends, plays, records again.
func (p *Panel) liveTalk(w http.ResponseWriter, r *http.Request) {
	if p.Talk == nil {
		fail(w, http.StatusNotFound, "звонок выключен")
		return
	}
	if r.Method != http.MethodPost {
		fail(w, http.StatusMethodNotAllowed, "POST only")
		return
	}
	audio, err := io.ReadAll(http.MaxBytesReader(w, r.Body, maxTalkBytes))
	if err != nil || len(audio) < 200 {
		fail(w, http.StatusBadRequest, "пустая запись")
		return
	}
	mime := strings.TrimSpace(strings.SplitN(r.Header.Get("Content-Type"), ";", 2)[0])
	res, err := p.Talk(r.Context(), audio, mime)
	if err != nil {
		fail(w, http.StatusBadGateway, err.Error())
		return
	}
	writeJSON(w, res)
}

// EncodeAudio is the base64 form TalkResult carries.
func EncodeAudio(b []byte) string { return base64.StdEncoding.EncodeToString(b) }
