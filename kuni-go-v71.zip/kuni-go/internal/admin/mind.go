package admin

import (
	"encoding/json"
	"net/http"
)

// mindAPI: GET = the state of her own mind; GET ?export=1[&owner=1] = her conversations as JSONL for fine-tuning a model of her
// own; POST {"bad": "<what was said to her>"} = the owner calls the answer of that habit bad.
func (p *Panel) mindAPI(w http.ResponseWriter, r *http.Request) {
	if p.Mind == nil {
		fail(w, http.StatusNotFound, "её собственный разум выключен (mind.enabled)")
		return
	}
	if r.Method == http.MethodPost {
		var req struct {
			Bad string `json:"bad"`
		}
		if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 8<<10)).Decode(&req); err != nil || req.Bad == "" {
			fail(w, http.StatusBadRequest, "неверный запрос")
			return
		}
		if !p.Mind.Demote(req.Bad) {
			fail(w, http.StatusNotFound, "такой привычки нет")
			return
		}
		p.Mind.Save()
		writeJSON(w, map[string]any{"ok": true, "mind": p.Mind.Stats()})
		return
	}
	if r.URL.Query().Get("export") != "" {
		w.Header().Set("Content-Type", "application/x-ndjson; charset=utf-8")
		w.Header().Set("Content-Disposition", `attachment; filename="reina_dialogs.jsonl"`)
		sys := "Ты " + p.Cfg().CharacterName + ", живая девушка в Telegram. Отвечай коротко, как в чате, своим голосом."
		p.Mind.Export(w, sys, r.URL.Query().Get("owner") != "")
		return
	}
	writeJSON(w, p.Mind.Stats())
}
