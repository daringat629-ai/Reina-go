package admin

import (
	"net/http"

	"kuni/internal/cortex"
)

// netAPI gives the live picture of her brain for the "Сеть" tab: every region with where it sits and how active it is now, the real
// bundles between regions, what the brain tells the rest of her, and (when machine mode is on) the machine state. The picture is a
// view of these numbers; nothing in it is written back.
func (p *Panel) netAPI(w http.ResponseWriter, r *http.Request) {
	if p.Cortex == nil {
		fail(w, http.StatusNotFound, "мозг по областям выключен")
		return
	}
	pos := map[string]cortex.Region{}
	for _, rg := range cortex.Regions {
		pos[rg.ID] = rg
	}
	type reg struct {
		ID    string     `json:"id"`
		Name  string     `json:"name"`
		Group string     `json:"group"`
		Pos   [3]float64 `json:"pos"`
		N     int        `json:"n"`
		Act   float64    `json:"act"`
	}
	var regs []reg
	for _, s := range p.Cortex.Regions() {
		rg := pos[s.ID]
		regs = append(regs, reg{s.ID, s.Name, rg.Group, rg.Pos, s.N, s.Act})
	}
	type edge struct {
		From string  `json:"from"`
		To   string  `json:"to"`
		W    float64 `json:"w"`
		Inh  bool    `json:"inh,omitempty"`
	}
	edges := make([]edge, 0, len(cortex.Edges))
	for _, e := range cortex.Edges {
		edges = append(edges, edge{e.From, e.To, e.W, e.Inh})
	}
	out := map[string]any{"regions": regs, "edges": edges, "neurons": p.Cortex.Net.Total(), "out": p.Cortex.Outputs(), "self_know": p.Cortex.SelfKnow(), "self_surprise": p.Cortex.SelfSurprise()}
	if p.Machine != nil {
		if m, ok := p.Machine(); ok {
			out["machine"] = m
		}
	}
	writeJSON(w, out)
}
