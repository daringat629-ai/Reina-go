package admin

import (
	"kuni/internal/anatomy"
	"kuni/internal/cortex"
)

// brainOrgans puts her brain regions inside the head of the 3D model as small glowing points: the position of a region is its place
// in the head (around the "brain" organ), its glow is the activity of its neurons now.
func brainOrgans(c *cortex.Cortex) []anatomy.Organ {
	pos := map[string][3]float64{}
	for _, r := range cortex.Regions {
		pos[r.ID] = r.Pos
	}
	var out []anatomy.Organ
	for _, r := range c.Regions() {
		p := pos[r.ID]
		out = append(out, anatomy.Organ{ID: "brain:" + r.ID, Name: r.Name, Pts: [][3]float64{{p[0] * 6, 84 + p[1]*7, 1.5 + p[2]*6}}, Load: r.Act, Health: 1, Text: r.Machine, Does: r.Analog})
	}
	return out
}
