package admin

import "net/http"

// keepsakesAPI lists her keepsake box for the "Сны" tab. Nothing is hidden: she knows the owner can read it.
func (p *Panel) keepsakesAPI(w http.ResponseWriter, r *http.Request) {
	if p.Keepsakes == nil {
		fail(w, http.StatusNotFound, "шкатулка выключена")
		return
	}
	writeJSON(w, map[string]any{"keepsakes": p.Keepsakes.All()})
}
