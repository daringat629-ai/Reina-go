package admin

import (
	"encoding/json"
	"net/http"
	"time"

	"kuni/internal/body"
)

// bodyAPI: GET shows her body and her five senses (the body is brought up to now first); POST {do} gives her food, a drink and so on.
func (p *Panel) bodyAPI(w http.ResponseWriter, r *http.Request) {
	if p.Body == nil {
		fail(w, http.StatusNotFound, "модель тела выключена")
		return
	}
	if r.Method == http.MethodPost {
		var req struct {
			Do string `json:"do"`
		}
		if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 4<<10)).Decode(&req); err != nil {
			fail(w, http.StatusBadRequest, "неверный запрос")
			return
		}
		if _, err := p.Body.Do(req.Do, 0); err != nil {
			fail(w, http.StatusBadRequest, err.Error())
			return
		}
	}
	s := p.Body.Snapshot()
	if time.Since(s.Last) > time.Minute {
		p.Body.Tick(time.Now(), body.Working, body.DefaultEnv)
		s = p.Body.Snapshot()
	}
	out := map[string]any{"state": s, "senses": s.Senses(), "hunger": s.Hunger(), "thirst": s.Thirst()}
	if p.Feel != nil {
		f := p.Feel.Snapshot()
		likes, dislikes := f.Tastes()
		if likes == nil {
			likes = []string{}
		}
		if dislikes == nil {
			dislikes = []string{}
		}
		out["feel"] = map[string]any{"valence": f.Valence, "arousal": f.Arousal, "control": f.Control, "word": f.Word, "causes": f.Causes, "likes": likes, "dislikes": dislikes}
	}
	if p.Machine != nil {
		if m, ok := p.Machine(); ok {
			out["machine"] = m
		}
	}
	if p.Cortex != nil {
		o := p.Cortex.Outputs()
		out["cortex"] = map[string]any{"regions": p.Cortex.Regions(), "neurons": p.Cortex.Net.Total(), "mod": o.Mod, "out": o}
	}
	if p.Mind != nil {
		out["mind"] = p.Mind.Stats()
	}
	writeJSON(w, out)
}
