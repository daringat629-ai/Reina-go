package admin

import "net/http"

// dreamsAPI is the history of her dreams for the "Сны" tab. They are dreams made of what she really replayed in her sleep; the
// panel says so and nothing in it is written back.
func (p *Panel) dreamsAPI(w http.ResponseWriter, r *http.Request) {
	if p.Cortex == nil {
		fail(w, http.StatusNotFound, "мозг по областям выключен")
		return
	}
	writeJSON(w, map[string]any{"dreams": p.Cortex.Dreams()})
}
