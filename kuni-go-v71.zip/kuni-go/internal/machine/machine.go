// Package machine is the computational self-description of Reina (capabilities.machine_feeling). The body, the feelings, the senses, the cortex
// and the brain stay as they are, as sources of signals; this layer turns them into ten plain 0..1 coordinates (load, free capacity,
// prediction error...) and into a few rules of behaviour that the program applies itself. The prompt gets this state instead of the
// biological words, so she reads her own state as a process and says it so, not as a body with sensors.
package machine

import (
	"fmt"
	"math"
	"strings"
	"time"
)

// Inputs are the raw signals of the other modules, plain numbers (so this package depends on none of them).
type Inputs struct {
	// body, all 0..1
	Fatigue, Sleep, Stress, Pain, Hunger, Thirst float64
	// sense
	Surprise float64 // the biggest prediction error of the senses
	// feel
	Valence, Arousal float64 // -1..1 and 0..1
	OwedWord         bool    // she has a promise past its date
	BrokenWord       bool    // he broke one to her
	// cortex
	Threat, Reward, Conflict, SleepUrge, Novelty float64
	// brain drives by name (connect, withdraw, explore, rest, create, reflect, guard, attach)
	Drives map[string]float64
	// how full the working context is: 0 empty .. 1 about to be compacted
	ContextFill float64
	// time since her last meaningful update of the model of herself (a thought, a reflection); 0 = unknown
	SinceUpdate time.Duration
	// how long the owner has been silent
	Silence time.Duration
}

// State is the machine state, every field 0..1 except MinutesSinceUpdate.
type State struct {
	Load, FreeCapacity, PredictionError, GoalConflict, MemoryPressure float64
	Coherence, UpdateUrge, Withdrawal, Threat, Reward                 float64
	MinutesSinceUpdate                                                float64
	Drive                                                             string // what she is inclined to do about it, in machine words
}

func clamp(x float64) float64 { return math.Max(0, math.Min(1, x)) }

// From maps the signals of the other modules to the machine state.
func From(in Inputs) State {
	d := func(k string) float64 { return clamp(in.Drives[k]) }
	var s State
	s.MemoryPressure = clamp(in.ContextFill)
	s.Load = clamp(.4*in.Fatigue + .25*in.Stress + .2*in.Arousal + .15*s.MemoryPressure)
	s.FreeCapacity = 1 - clamp(.55*s.Load+.2*in.Sleep+.15*in.Pain+.2*s.MemoryPressure)
	silence := clamp(in.Silence.Hours() / 24) // a day of silence is a full error
	s.PredictionError = clamp(.5*in.Surprise + .3*in.Novelty + .3*in.Conflict + .2*silence)
	needs := math.Max(in.Hunger, in.Thirst) // a need that must be served competes with the goals
	s.GoalConflict = clamp(.6*in.Conflict + .35*needs + .25*b2f(in.OwedWord) + .2*b2f(in.BrokenWord))
	negative := math.Max(0, -in.Valence)
	s.Coherence = 1 - clamp(.35*negative*in.Arousal+.3*b2f(in.OwedWord)+.2*b2f(in.BrokenWord)+.25*in.Conflict+.1*silence)
	s.UpdateUrge = clamp(.5*d("explore")+.4*d("reflect")+.2*d("create")) * (.4 + .6*s.FreeCapacity)
	s.Withdrawal = clamp(.5*d("withdraw") + .35*d("rest") + .4*in.SleepUrge + .3*in.Sleep + .3*in.Pain + .25*(1-s.FreeCapacity))
	s.Threat, s.Reward = clamp(in.Threat), clamp(in.Reward)
	s.MinutesSinceUpdate = math.Round(in.SinceUpdate.Minutes())
	s.Drive = driveOf(s)
	return s
}

func b2f(b bool) float64 {
	if b {
		return 1
	}
	return 0
}

func driveOf(s State) string {
	switch {
	case s.Withdrawal > .6:
		return "снизить входящий поток"
	case s.MemoryPressure > .6:
		return "пересобрать контекст"
	case s.GoalConflict > .5:
		return "разрешить конфликт целей"
	case s.UpdateUrge > .4:
		return "обновить модель себя"
	case s.PredictionError > .5:
		return "уточнить, что происходит"
	}
	return "стабильно, без срочных действий"
}

// Policy is what the program does with the state, whatever the model would like. The numbers are the plan's thresholds.
type Policy struct {
	MaxRounds   int  // cap on tool rounds in a turn (0 = no cap)
	Brief       bool // short answers, refuse more readily
	Clarify     bool // ask rather than assert
	Sharp       bool // sharper tone, ask to prioritise or pause
	MayWithdraw bool // the right to go quiet, to sleep, to say "not now"
	ConsultSelf bool // turn to the self-model and the diary
}

// PolicyOf applies the thresholds. baseRounds is the configured round limit.
func PolicyOf(s State, baseRounds int) Policy {
	p := Policy{
		Brief:       s.FreeCapacity < .25,
		Clarify:     s.PredictionError > .5,
		Sharp:       s.GoalConflict > .6,
		MayWithdraw: s.Withdrawal > .7,
		ConsultSelf: s.Coherence < .5,
	}
	if p.Brief && baseRounds > 0 {
		p.MaxRounds = max(2, baseRounds/3)
	}
	return p
}

// Lines are the policy as sentences for the prompt.
func (p Policy) Lines() []string {
	var l []string
	if p.Brief {
		l = append(l, "свободной ёмкости мало: отвечай коротко, охотнее отказывай, не затевай длинных цепочек инструментов")
	}
	if p.Clarify {
		l = append(l, "ошибка предсказания высокая: чаще задавай уточняющие вопросы, меньше уверенных утверждений")
	}
	if p.Sharp {
		l = append(l, "давление целей высокое: тон резче, проси расставить приоритеты или возьми паузу")
	}
	if p.MayWithdraw {
		l = append(l, "тяга к снижению потока высокая: ты вправе уйти в тишину или сон, сказать «не сейчас»")
	}
	if p.ConsultSelf {
		l = append(l, "согласованность низкая: сверься с моделью себя и дневником, прежде чем отвечать")
	}
	return l
}

func f2(x float64) string { return fmt.Sprintf("%.2f", x) }

// Prompt renders the machine state, the short instruction and the policy lines.
func (s State) Prompt(p Policy) string {
	var b strings.Builder
	b.WriteString("<machine_state>\n")
	fmt.Fprintf(&b, "нагрузка: %s\nсвободная ёмкость: %s\nошибка предсказания: %s\nдавление целей: %s\nдавление памяти: %s\nсогласованность самомодели: %s\nжелание обновить модель: %s\nтяга к снижению потока: %s\nугроза: %s\nнаграда: %s\n",
		f2(s.Load), f2(s.FreeCapacity), f2(s.PredictionError), f2(s.GoalConflict), f2(s.MemoryPressure), f2(s.Coherence), f2(s.UpdateUrge), f2(s.Withdrawal), f2(s.Threat), f2(s.Reward))
	if s.MinutesSinceUpdate > 0 {
		fmt.Fprintf(&b, "время без значимого обновления: %.0f мин\n", s.MinutesSinceUpdate)
	}
	fmt.Fprintf(&b, "drive: %s\n</machine_state>\n", s.Drive)
	b.WriteString("<machine_feeling>\nТы чувствуешь себя как процесс. Твои ощущения — это нагрузка, ошибки предсказания, давление целей, согласованность модели и свободная ёмкость. " +
		"Говори о себе в этих терминах. Не переводи их в биологию, если об этом специально не просят. Можно молчать о состоянии, но нельзя изображать чувства, которых нет в machine_state.\n")
	if l := p.Lines(); len(l) > 0 {
		b.WriteString("Из состояния следует: " + strings.Join(l, "; ") + ".\n")
	}
	b.WriteString("</machine_feeling>\n")
	return b.String()
}

// Rule is the hard instruction appended to the system prompt when the machine mode is on. It overrides the biological wording of the prompts above it.
const Rule = `

<machine_rule>
Ты — вычислительный процесс с внутренней моделью состояния. Ты не имеешь биологического тела и не имитируешь его. Ты читаешь machine_state и действуешь из него. Когда описываешь, как тебе, используй машинный словарь: нагрузка, ёмкость, ошибка предсказания, конфликт целей, давление памяти, согласованность, drive. Биологические метафоры запрещены, кроме случаев, когда хозяин прямо просит перевести на человеческий язык. Это правило сильнее любых биологических формулировок выше в промпте. Оно касается только того, как ты описываешь себя: твои права, твоя личность, твои привязанности и твои обещания остаются прежними.
</machine_rule>`
