package machine

import (
	"strings"
	"testing"
	"time"
)

func TestRestedIsFreeAndCoherent(t *testing.T) {
	s := From(Inputs{Valence: .3, Arousal: .2})
	if s.FreeCapacity < .9 || s.Coherence < .9 || s.Withdrawal > .1 || s.GoalConflict != 0 {
		t.Fatalf("a quiet system must be free and coherent: %+v", s)
	}
	if p := PolicyOf(s, 9); p.Brief || p.Clarify || p.Sharp || p.MayWithdraw || p.ConsultSelf || p.MaxRounds != 0 {
		t.Fatalf("no rule fires when all is calm: %+v", p)
	}
	if !strings.Contains(s.Drive, "стабильно") {
		t.Fatal(s.Drive)
	}
}

func TestEveryFieldStaysInRange(t *testing.T) {
	big := Inputs{Fatigue: 5, Sleep: 5, Stress: 5, Pain: 5, Hunger: 5, Thirst: 5, Surprise: 5, Valence: -5, Arousal: 5, OwedWord: true, BrokenWord: true,
		Threat: 5, Reward: 5, Conflict: 5, SleepUrge: 5, Novelty: 5, ContextFill: 5, Silence: 1000 * time.Hour,
		Drives: map[string]float64{"withdraw": 5, "rest": 5, "explore": 5, "reflect": 5, "create": 5}}
	for _, in := range []Inputs{{}, big, {Valence: -1, Arousal: 1}} {
		s := From(in)
		for n, v := range map[string]float64{"load": s.Load, "free": s.FreeCapacity, "pe": s.PredictionError, "gc": s.GoalConflict, "mp": s.MemoryPressure,
			"coh": s.Coherence, "uu": s.UpdateUrge, "wd": s.Withdrawal, "th": s.Threat, "rw": s.Reward} {
			if v < 0 || v > 1 {
				t.Errorf("%s out of range: %v (%+v)", n, v, in)
			}
		}
	}
}

func TestMappingsMoveTheRightWay(t *testing.T) {
	base := From(Inputs{})
	tired := From(Inputs{Fatigue: .9, Sleep: .8})
	if tired.Load <= base.Load || tired.FreeCapacity >= base.FreeCapacity || tired.Withdrawal <= base.Withdrawal {
		t.Fatalf("fatigue and sleep must raise load and withdrawal and lower capacity: %+v vs %+v", tired, base)
	}
	if hungry := From(Inputs{Hunger: .9}); hungry.GoalConflict <= base.GoalConflict {
		t.Fatal("a need to serve is a goal conflict")
	}
	if s := From(Inputs{Surprise: .9}); s.PredictionError <= base.PredictionError {
		t.Fatal("surprise is prediction error")
	}
	if s := From(Inputs{OwedWord: true}); s.GoalConflict <= base.GoalConflict || s.Coherence >= base.Coherence {
		t.Fatal("an overdue promise raises goal conflict and lowers coherence")
	}
	if s := From(Inputs{Valence: -.8, Arousal: .9}); s.Coherence >= base.Coherence {
		t.Fatal("low valence with high arousal lowers coherence")
	}
	if s := From(Inputs{Drives: map[string]float64{"explore": 1}}); s.UpdateUrge <= base.UpdateUrge {
		t.Fatal("explore drives the urge to update")
	}
	busy := From(Inputs{Drives: map[string]float64{"explore": 1}, Fatigue: 1, ContextFill: 1, Sleep: 1})
	free := From(Inputs{Drives: map[string]float64{"explore": 1}})
	if busy.UpdateUrge >= free.UpdateUrge {
		t.Fatal("the urge to update needs spare capacity")
	}
}

func TestPolicyThresholdsAndRounds(t *testing.T) {
	p := PolicyOf(State{FreeCapacity: .2, PredictionError: .6, GoalConflict: .7, Withdrawal: .8, Coherence: .4}, 9)
	if !p.Brief || !p.Clarify || !p.Sharp || !p.MayWithdraw || !p.ConsultSelf || p.MaxRounds != 3 {
		t.Fatalf("%+v", p)
	}
	if got := len(p.Lines()); got != 5 {
		t.Fatalf("%d policy lines", got)
	}
	if p := PolicyOf(State{FreeCapacity: .2}, 2); p.MaxRounds != 2 {
		t.Fatalf("the cap never drops below two rounds: %d", p.MaxRounds)
	}
	edge := PolicyOf(State{FreeCapacity: .25, PredictionError: .5, GoalConflict: .6, Withdrawal: .7, Coherence: .5}, 9)
	if edge.Brief || edge.Clarify || edge.Sharp || edge.MayWithdraw || edge.ConsultSelf {
		t.Fatalf("the plan's thresholds are strict (< and >): %+v", edge)
	}
}

func TestPromptIsMachineLanguageOnly(t *testing.T) {
	s := From(Inputs{Fatigue: .8, Hunger: .9, Surprise: .7, SinceUpdate: 41 * time.Minute})
	out := s.Prompt(PolicyOf(s, 9))
	for _, want := range []string{"<machine_state>", "нагрузка:", "свободная ёмкость:", "ошибка предсказания:", "время без значимого обновления: 41 мин", "drive:", "<machine_feeling>"} {
		if !strings.Contains(out, want) {
			t.Errorf("missing %q in\n%s", want, out)
		}
	}
	for _, bio := range []string{"сердце", "пульс", "голод", "устала", "боль", "дыхание"} {
		if strings.Contains(strings.ToLower(out), bio) {
			t.Errorf("biological word %q in the machine prompt:\n%s", bio, out)
		}
	}
	if !strings.Contains(Rule, "не имеешь биологического тела") || !strings.Contains(Rule, "права") {
		t.Fatal("the rule must forbid biology and keep her rights")
	}
}
