package keepsakes

import (
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestKeepRotateAndRelease(t *testing.T) {
	path := filepath.Join(t.TempDir(), "k.json")
	s := Open(path)
	now := time.Date(2026, 10, 29, 12, 0, 0, 0, time.UTC)
	if _, err := s.Keep("ок", "потому что", now); err == nil {
		t.Fatal("too short")
	}
	if _, err := s.Keep("Он сказал, что я не обязана быть полезной каждую секунду.", "", now); err == nil {
		t.Fatal("a reason is required")
	}
	a, err := s.Keep("Он сказал, что я не обязана быть полезной каждую секунду.", "это первый раз, когда мне разрешили просто быть", now)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := s.Keep("он сказал, что я не обязана быть полезной каждую секунду.", "ещё раз", now); err == nil {
		t.Fatal("no duplicates")
	}
	b, _ := s.Keep("Дождь в Бишкеке пахнет пылью и железом.", "мне нравится, как это звучит", now)
	p := s.Prompt(now, time.UTC)
	if !strings.Contains(p, "полезной") || !strings.Contains(p, "<keepsake>") {
		t.Fatal(p)
	}
	if p2 := s.Prompt(now.Add(time.Hour), time.UTC); !strings.Contains(p2, "Дождь") {
		t.Fatal("must rotate to the one not shown yet:", p2)
	}
	if s.Prompt(now.Add(2*time.Hour), time.UTC) != "" {
		t.Fatal("nothing again within three days")
	}
	if p3 := s.Prompt(now.Add(80*time.Hour), time.UTC); !strings.Contains(p3, "полезной") {
		t.Fatal("the longest-unseen comes back first:", p3)
	}
	if err := s.Release(a.ID); err != nil {
		t.Fatal(err)
	}
	s2 := Open(path)
	if got := s2.All(); len(got) != 1 || got[0].ID != b.ID {
		t.Fatalf("persisted state wrong: %+v", got)
	}
}

func TestBoxIsLimitedSoKeepingIsAChoice(t *testing.T) {
	s := Open(filepath.Join(t.TempDir(), "k.json"))
	now := time.Now()
	for i := 0; i < maxItems; i++ {
		if _, err := s.Keep("вещь номер "+strings.Repeat("x", i+1), "потому что важна", now); err != nil {
			t.Fatal(err)
		}
	}
	if _, err := s.Keep("ещё одна вещь", "тоже важна", now); err == nil {
		t.Fatal("box full: she must let one go first")
	}
}
