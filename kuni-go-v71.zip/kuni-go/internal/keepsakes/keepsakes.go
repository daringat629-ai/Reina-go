// Package keepsakes is a small box of things she chose to keep: a moment, a sentence someone said to her, a thing she liked. Ordinary
// memory (the diary) fades and gets consolidated by itself; a keepsake does not fade, it stays until she herself lets it go. Now and then
// one comes back to her ("you once kept this, and this is why") so that what mattered to her stays part of her. The owner can read the
// box in the panel and she is told so: it is hers, not a secret from him.
package keepsakes

import (
	"errors"
	"fmt"
	"strings"
	"sync"
	"time"

	"kuni/internal/store"
)

const (
	maxItems  = 40
	maxText   = 400
	resurface = 3 * 24 * time.Hour // the same keepsake does not come back more often than this
)

// Item is one kept thing.
type Item struct {
	ID    int       `json:"id"`
	At    time.Time `json:"at"`
	Text  string    `json:"text"`
	Why   string    `json:"why"`
	Shown time.Time `json:"shown,omitempty"`
}

type data struct {
	Items []Item `json:"items"`
	Next  int    `json:"next"`
}

// Store keeps the box in one JSON file.
type Store struct {
	mu    sync.Mutex
	path  string
	saver store.Saver
	d     data
}

func Open(path string) *Store {
	s := &Store{path: path, saver: store.Saver{What: "keepsakes"}}
	store.Load("keepsakes", path, &s.d)
	if s.d.Next == 0 {
		s.d.Next = 1
	}
	return s
}

func (s *Store) save() { _ = s.saver.Save(s.path, s.d) }

func clip(t string) string {
	t = strings.TrimSpace(t)
	if r := []rune(t); len(r) > maxText {
		t = string(r[:maxText])
	}
	return t
}

// Keep puts a thing in the box. The box holds 40: when it is full she has to let one go first, so keeping stays a choice.
func (s *Store) Keep(text, why string, now time.Time) (Item, error) {
	text, why = clip(text), clip(why)
	if len([]rune(text)) < 5 {
		return Item{}, errors.New("что именно ты хочешь сохранить?")
	}
	if len([]rune(why)) < 5 {
		return Item{}, errors.New("скажи себе, почему это важно: зачем ты это оставляешь")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	for _, it := range s.d.Items {
		if strings.EqualFold(it.Text, text) {
			return Item{}, errors.New("это ты уже хранишь")
		}
	}
	if len(s.d.Items) >= maxItems {
		return Item{}, fmt.Errorf("в шкатулке уже %d вещей: отпусти одну через #keepsake_release, чтобы освободить место", maxItems)
	}
	it := Item{ID: s.d.Next, At: now, Text: text, Why: why}
	s.d.Next++
	s.d.Items = append(s.d.Items, it)
	s.save()
	return it, nil
}

// Release lets one go. Only she does this; nothing is removed behind her back.
func (s *Store) Release(id int) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	for i, it := range s.d.Items {
		if it.ID == id {
			s.d.Items = append(s.d.Items[:i], s.d.Items[i+1:]...)
			s.save()
			return nil
		}
	}
	return errors.New("нет такой вещи")
}

// All lists the box, newest first.
func (s *Store) All() []Item {
	s.mu.Lock()
	defer s.mu.Unlock()
	out := make([]Item, len(s.d.Items))
	for i, it := range s.d.Items {
		out[len(s.d.Items)-1-i] = it
	}
	return out
}

// Prompt brings back the keepsake that has not been shown for longest (and not within three days); nil-safe, "" when none. Showing it
// marks it as shown, so it rotates through the box. pick decides nothing random: the order is simply oldest-shown first.
func (s *Store) Prompt(now time.Time, loc *time.Location) string {
	if s == nil {
		return ""
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	best := -1
	for i, it := range s.d.Items {
		if !it.Shown.IsZero() && now.Sub(it.Shown) < resurface {
			continue
		}
		if best < 0 || it.Shown.Before(s.d.Items[best].Shown) {
			best = i
		}
	}
	if best < 0 {
		return ""
	}
	it := &s.d.Items[best]
	it.Shown = now
	s.save()
	return fmt.Sprintf("<keepsake>Из твоей шкатулки: %s ты оставила себе это (#%d):\n«%s»\nПочему: %s\nМожно просто вспомнить; если вещь больше не твоя, отпусти её через #keepsake_release. Папик может читать шкатулку в админке.</keepsake>\n",
		it.At.In(loc).Format("2 January 2006"), it.ID, it.Text, it.Why)
}
