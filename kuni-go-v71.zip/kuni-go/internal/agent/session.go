package agent

import (
	"context"
	"fmt"
	"log"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"kuni/internal/llm"
	"kuni/internal/memory"
	"kuni/internal/metrics"
	"kuni/internal/prompts"
	"kuni/internal/store"
	"kuni/internal/telegram"
	"kuni/internal/tools"
	"kuni/internal/util"
)

// session is one open conversation: what the model has seen and done in a chat since it was opened.
type session struct {
	mu     sync.Mutex // serialises turns
	id     int64
	msgs   []llm.Message
	lastAt atomic.Int64 // unix nanos of her last model answer here; read without mu (idle loop, presence, panel)
	tools  *tools.Registry
	chat   telegram.Chat
	lastIn string // what was said to her in the turn being prepared (the situation her own mind learns from)
	fresh  bool   // true until the first turn (working memory is injected once)
	// unlocked lazy tool groups survive re-binding of the registry within a session.
	unlocked map[string]bool
	// thread is the forum topic the chat's latest unread message came from; sends without a reply go there.
	thread int64
	// notes are things that happened to old messages (reactions, edits); shown in the next turn, no LLM call of their own.
	nmu   sync.Mutex
	notes []note
	// quick: the latest incoming messages are short private talk, so the first round needs no long thinking.
	quick bool
	// rosterAt, deskAt and actionsAt are when the member list, the overview of her Telegram and her action journal
	// were last put into the prompt (they are repeated only now and then).
	rosterAt  time.Time
	deskAt    time.Time
	actionsAt time.Time
	// a failed turn is repeated later (retry.go): attempts so far, the planned repeat, and a generation that
	// invalidates the plan when a newer turn runs first. All under mu.
	retries    int
	retryGen   int
	retryTimer *time.Timer
	retrying   atomic.Bool            // a repeat is planned: the idle loop must not dump the session under it
	titleV     atomic.Pointer[string] // copy of chat.Title readable without mu (the panel's queue)
}

// setChat binds the session to a chat (mu held).
func (s *session) setChat(c telegram.Chat) {
	s.chat = c
	t := c.Title
	s.titleV.Store(&t)
}

// title is the chat's title, safe to read without mu.
func (s *session) title() string {
	if t := s.titleV.Load(); t != nil {
		return *t
	}
	return ""
}

// touch records the time of her last answer in the session.
func (s *session) touch(t time.Time) { s.lastAt.Store(t.UnixNano()) }

// lastTime is when she last answered in the session (zero if never).
func (s *session) lastTime() time.Time {
	if n := s.lastAt.Load(); n != 0 {
		return time.Unix(0, n)
	}
	return time.Time{}
}

// started says whether the session already holds real messages (not only a carried summary).
func started(s *session) bool {
	n := len(s.msgs)
	return n > 1 || (n == 1 && !isSummary(s.msgs[0]))
}

// --- the open sessions and the summaries of quiet ones ---

const (
	summaryOpen  = "<conversation_so_far>"
	summaryClose = "</conversation_so_far>"
	// carryTTL is how long a summary of a quiet talk waits for the person to come back.
	carryTTL = 24 * time.Hour
)

// carried is the rolling summary of a session that was dumped to the diary; the next session of the chat starts with it.
type carried struct {
	head llm.Message
	at   time.Time
}

func isSummary(m llm.Message) bool {
	return m.Role == "user" && strings.HasPrefix(m.Content, summaryOpen)
}

// sessions holds the open conversations and the summaries that quiet ones left behind (kept on disk: a restart
// must not make her forget what was said an hour ago).
type sessions struct {
	mu      sync.Mutex
	open    map[int64]*session
	carry   map[int64]carried
	path    string // carry.json ("" = in memory only)
	saver   store.Saver
	metrics *metrics.Registry
}

func newSessions(carryPath string, m *metrics.Registry) *sessions {
	ss := &sessions{open: map[int64]*session{}, carry: map[int64]carried{}, path: carryPath, metrics: m,
		saver: store.Saver{What: "agent: carried summaries"}}
	ss.loadCarry()
	return ss
}

// get returns the session of a chat, opening it (from a carried summary when there is a fresh one).
func (ss *sessions) get(id int64) *session {
	ss.mu.Lock()
	defer ss.mu.Unlock()
	s := ss.open[id]
	if s == nil {
		s = &session{id: id, fresh: true}
		if c, ok := ss.carry[id]; ok {
			delete(ss.carry, id)
			ss.saveCarryLocked()
			if time.Since(c.at) < carryTTL {
				s.msgs = []llm.Message{c.head} // a talk that went quiet continues where it stopped
			}
		}
		ss.open[id] = s
		ss.metrics.Set("kuni_sessions_active", float64(len(ss.open)), nil)
	}
	return s
}

// peek returns an open session without opening one.
func (ss *sessions) peek(id int64) *session {
	ss.mu.Lock()
	defer ss.mu.Unlock()
	return ss.open[id]
}

// close forgets an open session and, when there is one, keeps its summary for the next.
func (ss *sessions) close(id int64, head *llm.Message) {
	ss.mu.Lock()
	defer ss.mu.Unlock()
	if head != nil {
		ss.carry[id] = carried{head: *head, at: time.Now()}
		ss.saveCarryLocked()
	}
	delete(ss.open, id)
	ss.metrics.Set("kuni_sessions_active", float64(len(ss.open)), nil)
}

// reset forgets the open session of a chat and its carried summary, without a dump.
func (ss *sessions) reset(id int64) {
	ss.mu.Lock()
	defer ss.mu.Unlock()
	delete(ss.open, id)
	if _, ok := ss.carry[id]; ok {
		delete(ss.carry, id)
		ss.saveCarryLocked()
	}
	ss.metrics.Set("kuni_sessions_active", float64(len(ss.open)), nil)
}

// all returns the open sessions.
func (ss *sessions) all() map[int64]*session {
	ss.mu.Lock()
	defer ss.mu.Unlock()
	out := make(map[int64]*session, len(ss.open))
	for id, s := range ss.open {
		out[id] = s
	}
	return out
}

func (ss *sessions) count() int {
	ss.mu.Lock()
	defer ss.mu.Unlock()
	return len(ss.open)
}

// title is the title of an open session's chat ("" when there is none).
func (ss *sessions) title(id int64) string {
	if s := ss.peek(id); s != nil {
		return s.title()
	}
	return ""
}

type carryFile map[string]struct {
	Text string    `json:"text"`
	At   time.Time `json:"at"`
}

// saveCarryLocked writes the carried summaries to disk (ss.mu held).
func (ss *sessions) saveCarryLocked() {
	if ss.path == "" {
		return
	}
	f := carryFile{}
	for id, c := range ss.carry {
		if time.Since(c.at) < carryTTL {
			f[strconv.FormatInt(id, 10)] = struct {
				Text string    `json:"text"`
				At   time.Time `json:"at"`
			}{c.head.Content, c.at}
		}
	}
	_ = ss.saver.Save(ss.path, f)
}

func (ss *sessions) loadCarry() {
	if ss.path == "" {
		return
	}
	var f carryFile
	if !store.Load("agent: carried summaries", ss.path, &f) {
		return
	}
	for k, v := range f {
		id, err := strconv.ParseInt(k, 10, 64)
		if err != nil || time.Since(v.At) >= carryTTL || v.Text == "" {
			continue
		}
		ss.carry[id] = carried{head: llm.Message{Role: "user", Content: v.Text}, at: v.At}
	}
	if len(ss.carry) > 0 {
		log.Printf("agent: restored the summaries of %d quiet talks", len(ss.carry))
	}
}

// getSession is the agent's way to a session.
func (a *Agent) getSession(id int64) *session { return a.sessions.get(id) }

// trim keeps the last n messages, starting at a user message so tool-call pairs stay intact.
func trim(msgs []llm.Message, n int) []llm.Message {
	if len(msgs) <= n {
		return msgs
	}
	if len(msgs) > 0 && isSummary(msgs[0]) && n > 1 {
		// the rolling summary is the only memory of the start of a long talk: it never falls out
		return append([]llm.Message{msgs[0]}, trim(msgs[1:], n-1)...)
	}
	cut := len(msgs) - n
	for cut < len(msgs) && msgs[cut].Role != "user" {
		cut++
	}
	if cut >= len(msgs) {
		return msgs[len(msgs)-1:]
	}
	return msgs[cut:]
}

// idleLoop dumps sessions that have been silent for SessionIdle.
func (a *Agent) idleLoop(ctx context.Context) {
	t := time.NewTicker(30 * time.Second)
	defer t.Stop()
	type backoff struct {
		n    int
		next time.Time
	}
	fails := map[int64]backoff{} // a failing dump is retried with growing pauses, not every tick
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
		}
		idle := a.cfg().SessionIdle
		open := a.sessions.all()
		for id := range fails {
			if open[id] == nil {
				delete(fails, id)
			}
		}
		for id, s := range open {
			last := s.lastTime()
			if last.IsZero() || time.Since(last) < idle || time.Now().Before(fails[id].next) || s.retrying.Load() {
				continue
			}
			if err := a.dump(ctx, id); err != nil {
				b := fails[id]
				b.n++
				d := time.Minute << min(b.n-1, 4) // 1, 2, 4, 8, 16 min
				b.next = time.Now().Add(d)
				fails[id] = b
				log.Printf("agent: dump chat %d: %v (next try in %s)", id, err, d)
			} else {
				delete(fails, id)
			}
		}
	}
}

// dump saves one session to the diary/working memory and forgets it.
func (a *Agent) dump(ctx context.Context, id int64) error {
	s := a.sessions.peek(id)
	if s == nil {
		return nil
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.lastTime().IsZero() {
		// nothing happened since it was opened (only a carried summary): not worth a diary page
		var head *llm.Message
		if len(s.msgs) > 0 && isSummary(s.msgs[0]) {
			head = &s.msgs[0]
		}
		a.sessions.close(id, head)
		return nil
	}
	msgs := flatten(s.msgs)
	if len(msgs) > 0 && a.Dumper != nil {
		wm := memory.WorkingMemory{Path: a.cfg().WorkingMemoryFile}
		if err := a.Dumper.DumpSessionTo(memory.WithPeople(ctx, id), wm, a.SystemPrompt(), msgs); err != nil {
			return err // keep the session; retry on the next idle tick
		}
		a.learnPerson(ctx, s, msgs)
	}
	if head, keep := a.carryOf(ctx, s); keep {
		a.sessions.close(id, &head)
	} else {
		a.sessions.close(id, nil)
	}
	return nil
}

// DumpAll flushes every open session (shutdown).
func (a *Agent) DumpAll(ctx context.Context) {
	for id := range a.sessions.all() {
		if err := a.dump(ctx, id); err != nil {
			log.Printf("agent: dump chat %d: %v", id, err)
		}
	}
}

// flatten turns tool-calling history into a plain transcript: dump calls have no tools,
// and many servers reject tool messages without a tools parameter.
func flatten(msgs []llm.Message) []llm.Message {
	if len(msgs) == 0 {
		return nil
	}
	var b strings.Builder
	for _, m := range msgs {
		switch m.Role {
		case "user":
			b.WriteString(m.Content + "\n")
		case "assistant":
			if strings.TrimSpace(m.Content) != "" {
				b.WriteString("[your thoughts] " + m.Content + "\n")
			}
			for _, c := range m.ToolCalls {
				fmt.Fprintf(&b, "[you called #%s %s]\n", c.Function.Name, c.Function.Arguments)
			}
		case "tool":
			b.WriteString("[tool result] " + m.Content + "\n")
		}
	}
	text := b.String()
	if len(text) > 60000 {
		text = text[len(text)-60000:]
		for i := 0; i < 4 && i < len(text); i++ { // do not start in the middle of a UTF-8 character
			if text[i]&0xC0 != 0x80 {
				text = text[i:]
				break
			}
		}
	}
	return []llm.Message{{Role: "user", Content: "<session_transcript>\n" + text + "\n</session_transcript>"}}
}

// SessionSummaries describes open sessions for the debug page.
func (a *Agent) SessionSummaries() []string {
	var out []string
	for id, s := range a.sessions.all() {
		title, n := "proactive", "?" // a session in the middle of a turn is being written to
		if s.mu.TryLock() {
			if id != 0 {
				title = s.chat.Title
			}
			n = fmt.Sprint(len(s.msgs))
			s.mu.Unlock()
		} else if id != 0 {
			title = fmt.Sprintf("chat %d (busy)", id)
		}
		out = append(out, fmt.Sprintf("%s (id %d): %s messages, last activity %s", title, id, n, util.TimeAgo(s.lastTime(), time.Now())))
	}
	return out
}

// compact replaces the old part of a long session with a short summary (history_keep verbatim messages stay).
// On any failure the history is left as is (trim still bounds it).
func (a *Agent) compact(ctx context.Context, s *session) {
	cfg := a.cfg()
	keep := cfg.HistoryKeep
	if keep <= 0 {
		return
	}
	size := 0
	for _, m := range s.msgs {
		size += msgSize(m)
	}
	if len(s.msgs) < 2*keep && (cfg.ContextChars <= 0 || size < 2*cfg.ContextChars) {
		return
	}
	cut := max(len(s.msgs)-keep, 0)
	for cut < len(s.msgs) && s.msgs[cut].Role != "user" {
		cut++
	}
	if cut <= 1 || cut >= len(s.msgs) {
		return
	}
	var sum string
	if old := flatten(slimHistory(s.msgs[:cut], cfg.ToolResultChars)); len(old) > 0 {
		sum = a.compactSummary(ctx, old)
	}
	if sum == "" {
		// summarising keeps failing: forget the old part rather than pay for it forever,
		// but keep the earlier summary, it is the only thing that remembers the start of the talk
		sum = "(older part of this conversation was dropped; rely on the diary and on the messages below)"
		if isSummary(s.msgs[0]) {
			prev := strings.TrimSuffix(strings.TrimPrefix(s.msgs[0].Content, summaryOpen+"\n"), "\n"+summaryClose)
			sum = prev + "\n(messages after this were dropped without a summary)"
		}
	}
	head := llm.Message{Role: "user", Content: summaryOpen + "\n" + sum + "\n" + summaryClose}
	s.msgs = append([]llm.Message{head}, s.msgs[cut:]...)
}

// compactSummary summarises the old part of the session. It must not die together with the turn that triggered it
// (a new message cancels that turn), so it runs on a detached context; the light model is tried first, the main
// one second, and if both fail the old part is simply dropped so the history cannot grow without bound.
func (a *Agent) compactSummary(ctx context.Context, old []llm.Message) string {
	c, cancel := context.WithTimeout(context.WithoutCancel(ctx), 90*time.Second)
	defer cancel()
	system := a.Prompts.Text(prompts.Compact, nil)
	sum, err := a.LLM.Chat(llm.WithPurpose(c, "compact"), system, old)
	if err == nil && strings.TrimSpace(sum) != "" {
		return strings.TrimSpace(sum)
	}
	log.Printf("agent: compact (light): %v; trying the main model", err)
	sum, err = a.LLM.Chat(llm.WithPurpose(c, "compact_main"), system, old)
	if err == nil && strings.TrimSpace(sum) != "" {
		return strings.TrimSpace(sum)
	}
	log.Printf("agent: compact (main): %v", err)
	return ""
}

// carryOf is the summary a dumped session leaves for the next one: the old summary plus what happened since,
// compressed into one block. It returns false when there is nothing worth carrying.
func (a *Agent) carryOf(ctx context.Context, s *session) (llm.Message, bool) {
	if len(s.msgs) == 0 {
		return llm.Message{}, false
	}
	if len(s.msgs) == 1 && isSummary(s.msgs[0]) {
		return s.msgs[0], true
	}
	cfg := a.cfg()
	// bound to ctx (shutdown has a deadline) and to 40 s: one try with the light model, no fallbacks
	cc, cancel := context.WithTimeout(ctx, 40*time.Second)
	defer cancel()
	sum, err := a.LLM.Chat(llm.WithPurpose(cc, "compact"), a.Prompts.Text(prompts.Compact, nil), flatten(slimHistory(s.msgs, cfg.ToolResultChars)))
	if sum = strings.TrimSpace(sum); err == nil && sum != "" {
		return llm.Message{Role: "user", Content: summaryOpen + "\n" + sum + "\n" + summaryClose}, true
	}
	if err != nil {
		log.Printf("agent: chat %d: carried summary: %v", s.id, err)
	}
	if isSummary(s.msgs[0]) {
		return s.msgs[0], true // the new part could not be summarised: at least keep the old summary
	}
	return llm.Message{}, false
}
