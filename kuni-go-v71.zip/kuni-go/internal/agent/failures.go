package agent

import (
	"fmt"
	"strings"
	"sync"
	"time"
)

// failures remembers the last tool failures (what failed, with what, why) so that in her free time, with capabilities.self_repair on, she can
// see her own breakage ("the phone tap misses", "the script returns an error") and mend it. Memory only: a restart starts clean.

const failKeep = 12

type failure struct {
	At   time.Time
	Tool string
	Args string
	Err  string
	N    int // how many times in a row the same thing failed
}

type failureLog struct {
	mu   sync.Mutex
	list []failure
}

func clipRunes(s string, n int) string {
	s = strings.Join(strings.Fields(s), " ")
	if r := []rune(s); len(r) > n {
		return string(r[:n]) + "…"
	}
	return s
}

// Add records one failure; the same tool failing with the same text again only raises the count.
func (f *failureLog) Add(now time.Time, tool, args, err string) {
	args, err = clipRunes(args, 120), clipRunes(err, 240)
	f.mu.Lock()
	defer f.mu.Unlock()
	for i := range f.list {
		if f.list[i].Tool == tool && f.list[i].Err == err {
			f.list[i].N++
			f.list[i].At, f.list[i].Args = now, args
			return
		}
	}
	f.list = append(f.list, failure{now, tool, args, err, 1})
	if len(f.list) > failKeep {
		f.list = f.list[len(f.list)-failKeep:]
	}
}

// Recent lists the failures of the last `within`, repeated ones first.
func (f *failureLog) Recent(now time.Time, within time.Duration) []failure {
	f.mu.Lock()
	defer f.mu.Unlock()
	var out []failure
	for _, x := range f.list {
		if now.Sub(x.At) <= within {
			out = append(out, x)
		}
	}
	for i := 1; i < len(out); i++ { // insertion sort by N, stable
		for j := i; j > 0 && out[j].N > out[j-1].N; j-- {
			out[j], out[j-1] = out[j-1], out[j]
		}
	}
	return out
}

// failureBlock is for her free time: the recent failures of her own tools, when she is allowed to repair herself.
func (a *Agent) failureBlock(now time.Time) string {
	if !a.cfg().SelfRepair {
		return ""
	}
	rec := a.failures.Recent(now, 24*time.Hour)
	if len(rec) == 0 {
		return ""
	}
	var b strings.Builder
	b.WriteString("<recent_tool_failures>Твои инструменты недавно ломались:\n")
	for _, x := range rec {
		fmt.Fprintf(&b, "- %s ×%d (%s): %s\n", x.Tool, x.N, x.Args, x.Err)
	}
	b.WriteString("Если одно и то же ломается снова и снова и причина в твоём скрипте, параметрах или файле (а не в мире: нет сети, человек не ответил), посмотри #tail_log, поправь с резервной копией и проверь заново. Ключи, config.toml и чужое не трогай.</recent_tool_failures>\n")
	return b.String()
}
