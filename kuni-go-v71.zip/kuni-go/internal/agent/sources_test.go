package agent

import (
	"strconv"
	"strings"
	"testing"
	"time"

	"kuni/internal/diary"
)

func TestMemoryLabelSaysHowClearAndHowOld(t *testing.T) {
	now := time.Date(2026, 10, 30, 12, 0, 0, 0, time.UTC)
	at := func(d time.Duration) string { return strconv.FormatInt(now.Add(-d).Unix(), 10) }
	for _, c := range []struct {
		e    diary.Entry
		want []string
	}{
		{diary.Entry{ID: at(30 * time.Minute), Meta: diary.Metadata{Confidence: .8}}, []string{"помнишь ясно", "только что"}},
		{diary.Entry{ID: at(3 * 24 * time.Hour), Meta: diary.Metadata{Confidence: .2}}, []string{"помнишь,", "3 дн назад"}},
		{diary.Entry{ID: at(40 * 24 * time.Hour), Meta: diary.Metadata{Confidence: -.4}}, []string{"смутно", "5 нед назад"}},
		{diary.Entry{ID: at(200 * 24 * time.Hour)}, []string{"6 мес назад"}},
		{diary.Entry{ID: "не-время"}, []string{"помнишь"}},
	} {
		got := memoryLabel(c.e, now)
		for _, w := range c.want {
			if !strings.Contains(got, w) {
				t.Errorf("%+v -> %q, want %q", c.e.Meta, got, w)
			}
		}
	}
}

func TestAsksAboutThePast(t *testing.T) {
	if !asksAboutThePast("Помнишь, мы говорили про море?") || !asksAboutThePast("do you remember when") {
		t.Fatal("must notice a request to remember")
	}
	if asksAboutThePast("Привет, как дела?") {
		t.Fatal("an ordinary hello is not one")
	}
}

func TestSourcesNoteSeparatesMemoryKnowledgeAndGuess(t *testing.T) {
	for _, w := range []string{"помню", "знаю", "кажется", "не выдавай догадку за память"} {
		if !strings.Contains(sourcesNote, w) {
			t.Fatalf("missing %q", w)
		}
	}
}
