package agent

import (
	"context"
	"fmt"
	"kuni/internal/feel"
	"log"
	"strings"
	"time"

	"kuni/internal/llm"
	"kuni/internal/telegram"
	"kuni/internal/tools"
)

// HandleChat reads unread messages of a chat and lets the model act on them.
func (a *Agent) HandleChat(ctx context.Context, chatID int64) error {
	if a.paused.Load() {
		return nil // paused from the admin panel: messages stay unread and are handled on resume
	}
	cfg := a.cfg()
	if !a.Deps.Accessible(chatID) {
		log.Printf("agent: chat %d ignored by lockdown=%q (owner chat id is %d)", chatID, cfg.Lockdown, cfg.PapikChatID)
		_ = a.TG.MarkRead(ctx, chatID)
		return nil
	}
	if a.ignoredChat(chatID) {
		return nil // on the ignore list: left unread, not even looked at
	}
	chat, err := a.TG.Chat(ctx, chatID)
	if err != nil {
		return err
	}
	unread, err := a.readable(ctx, chatID)
	if err != nil {
		return err
	}
	if len(unread) == 0 {
		return nil
	}
	if a.Deps.Promises != nil && a.cfg().IsOwner(chatID) {
		a.Deps.Promises.Seen(time.Now())
		if a.Deps.Feel != nil {
			a.Deps.Feel.Impulse(time.Now(), feel.OwnerHere)
		}
	}
	if a.cfg().OwnerRhythm && a.cfg().IsOwner(chatID) {
		for _, m := range unread {
			if !m.Outgoing {
				a.rhythmT().Observe(m.ID, m.Date, m.Text)
			}
		}
	}
	if !a.worthWaking(ctx, chat, unread) {
		// not meant for her: she reads it (marks read) but no paid model call is made
		_ = a.TG.MarkRead(ctx, chatID)
		a.Metrics.Inc("kuni_group_skipped_total", 1, nil)
		return nil
	}
	if !a.billingAllows(ctx, chat) {
		return nil
	}
	s := a.getSession(chatID)
	// living presence: she may only look at the chat later, and she needs a moment to notice it at all.
	if until, ok := a.inbox.postponedUntil(chatID); ok && time.Now().Before(until) {
		return nil
	}
	if !a.inbox.beginNoticing(chatID) {
		return nil // another call is already waiting to open this chat; it will see everything unread
	}
	plan := a.presenceFor(chat, s, time.Now())
	if plan.Late > 0 && !a.inbox.takeUsed(chatID) {
		a.inbox.endNoticing(chatID)
		a.inbox.postpone(ctx, chatID, plan.Late)
		return nil
	}
	a.inbox.setPhase(chatID, "noticing", time.Time{})
	ok := a.readPause(ctx, plan.Read)
	a.inbox.endNoticing(chatID)
	if !ok {
		return nil
	}
	if unread, err = a.readable(ctx, chatID); err != nil || len(unread) == 0 {
		return err
	}
	log.Printf("agent: handling chat %d %q: %d unread (noticed after %s)", chatID, chat.Title, len(unread), plan.Read.Round(100*time.Millisecond))
	s.mu.Lock()
	defer s.mu.Unlock()
	defer a.goOnline(ctx)()
	a.inbox.setPhase(chatID, "thinking", time.Time{})

	view, err := a.renderChat(ctx, s, chat, unread)
	if err != nil {
		return err
	}
	_ = a.TG.MarkRead(ctx, chatID)
	s.msgs = append(s.msgs, llm.Message{Role: "user", Content: view})
	s.supersedeRetryLocked() // this turn sees everything a planned retry would have answered
	if err := a.runTurn(ctx, s); err != nil {
		a.scheduleRetryLocked(ctx, s, err) // the messages are read already: without a retry nobody would answer them
		return err
	}
	s.retries = 0
	return nil
}

// readable is what she would read in a chat now: the unread messages without those of ignored people and, in the
// owner's chat, without his slash commands (the program answers those itself, never the model). When nothing is
// left but commands, they are marked read.
func (a *Agent) readable(ctx context.Context, chatID int64) ([]telegram.Message, error) {
	unread, err := a.TG.Unread(ctx, chatID)
	if err != nil {
		return nil, err
	}
	unread = a.withoutIgnored(unread)
	if a.cfg().IsOwner(chatID) {
		kept := unread[:0:0]
		for _, m := range unread {
			if m.Outgoing || !isCommand(m.Text) {
				kept = append(kept, m)
			}
		}
		if len(kept) == 0 && len(unread) > 0 {
			return nil, a.TG.MarkRead(ctx, chatID)
		}
		unread = kept
	}
	return unread, nil
}

// depsFor gives the tools of a session what only the agent can do: wake her in a chat, switch the session to
// another chat, put her to sleep.
func (a *Agent) depsFor(s *session) tools.Deps {
	d := a.Deps
	d.Wake = func(chatID int64, text string) { a.wakeLater(chatID, text) }
	d.OpenChat = func(ctx context.Context, id int64) (string, error) { return a.openChat(ctx, s, id) }
	if a.Auto != nil && a.cfg().AutonomyEnabled {
		d.GoToSleep = a.goToSleep
	}
	return d
}

// openChat is the open_chat tool backend for proactive sessions.
func (a *Agent) openChat(ctx context.Context, s *session, chatID int64) (string, error) {
	chat, err := a.TG.Chat(ctx, chatID)
	if err != nil {
		return "", fmt.Errorf("chat %d not found", chatID)
	}
	unread, _ := a.TG.Unread(ctx, chatID)
	hist, _ := a.TG.History(ctx, chatID, 0, 20, 0)
	var b strings.Builder
	fmt.Fprintf(&b, "You switched to the chat %q in Telegram. You see last messages:\n", safeName(chat.Title))
	b.WriteString(a.UI.FormatMessages(ctx, hist, time.Now()))
	b.WriteString(a.chatInstructions(chat))
	d := a.depsFor(s)
	s.setChat(chat)
	s.tools = a.newRegistry(s, d, chat, true, unread)
	if len(unread) > 0 {
		_ = a.TG.MarkRead(ctx, chatID)
	}
	return b.String(), nil
}

// Wake lets an outside event (a reminder that is due, a finished background job) start a turn of hers in a chat:
// she sees the event and decides what to write.
func (a *Agent) Wake(ctx context.Context, chatID int64, text string) error {
	return a.wake(ctx, chatID, chatID, text, nil)
}

// wake is Wake with its own session key (background work keeps its own history, so the owner's chat never waits
// behind a long job) and groups of tools to unlock at once.
func (a *Agent) wake(ctx context.Context, key, chatID int64, text string, unlock []string) error {
	if a.paused.Load() {
		return nil
	}
	cfg := a.cfg()
	if !cfg.IsOwner(chatID) && !a.Deps.Accessible(chatID) {
		log.Printf("agent: wake chat %d ignored by lockdown=%q", chatID, cfg.Lockdown)
		return nil
	}
	chat, err := a.TG.Chat(ctx, chatID)
	if err != nil {
		return err
	}
	s := a.getSession(key)
	s.mu.Lock()
	defer s.mu.Unlock()
	defer a.goOnline(ctx)()
	a.inbox.setPhase(key, "thinking", time.Time{})
	defer a.inbox.endPhase(key)

	d := a.depsFor(s)
	s.setChat(chat)
	s.thread, s.quick = 0, false
	s.tools = a.newRegistry(s, d, chat, false, nil)
	for _, g := range unlock {
		s.tools.Unlock(g)
	}
	var b strings.Builder
	b.WriteString(a.moodBlock())
	b.WriteString(a.bondBlock(chat))
	b.WriteString(a.brainBlock(chat, false, text))
	b.WriteString(a.promiseBlock(chat))
	b.WriteString(a.ideaBlock(chat))
	b.WriteString(a.bodyBlock())
	b.WriteString(a.feelBlock())
	b.WriteString(a.senseBlock())
	b.WriteString(a.selfBlock())
	b.WriteString(a.sleepBlock())
	fmt.Fprintf(&b, "You switched to the chat %q in Telegram.\n", safeName(chat.Title))
	b.WriteString(a.desk(ctx, s, chat, true))
	b.WriteString(a.personCards(chat, nil))
	b.WriteString("<event>\n" + strings.TrimSpace(text) + "\n</event>\n")
	b.WriteString(a.chatInstructions(chat))
	s.msgs = append(s.msgs, llm.Message{Role: "user", Content: b.String()})
	return a.runTurn(ctx, s)
}
