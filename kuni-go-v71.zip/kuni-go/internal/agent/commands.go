package agent

import (
	"context"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"slices"
	"sort"
	"strconv"
	"strings"
	"time"

	"kuni/internal/allow"
	"kuni/internal/maint"
	"kuni/internal/telegram"
	"kuni/internal/work"
)

// Slash commands of the owner are answered by the program at once: no model, no tokens, and they work when she is
// paused, stuck or out of budget.
var commandNames = map[string]bool{"help": true, "status": true, "pause": true, "resume": true, "stop": true, "work": true, "usage": true, "backup": true, "yes": true, "no": true, "pending": true, "reset": true, "brain": true, "мозг": true}

// listedCommands are the commands a person on the white list may use; /work and /backup stay the owner's.
var listedCommands = map[string]bool{"help": true, "status": true, "usage": true, "pause": true, "resume": true, "stop": true}

// commandUser: the person is on the white list (config.toml or the file she edits).
func (a *Agent) commandUser(id int64) bool {
	return a.Deps.Allow.Has(id) || slices.Contains(allow.ParseIDs(a.cfg().CommandUsers), id)
}

func parseCommand(text string) (name, rest string, ok bool) {
	t := strings.TrimSpace(text)
	if !strings.HasPrefix(t, "/") {
		return "", "", false
	}
	first, rest, _ := strings.Cut(t[1:], " ")
	first, _, _ = strings.Cut(first, "@")
	name = strings.ToLower(first)
	return name, strings.TrimSpace(rest), commandNames[name]
}

func isCommand(text string) bool { _, _, ok := parseCommand(text); return ok }

// command runs the owner's slash command; false means the message is an ordinary one.
func (a *Agent) command(ctx context.Context, m telegram.Message) bool {
	cfg := a.cfg()
	if m.Outgoing || cfg.PapikChatID == 0 {
		return false
	}
	name, rest, ok := parseCommand(m.Text)
	if !ok {
		return false
	}
	owner := m.ChatID == cfg.PapikChatID && m.SenderID == cfg.PapikChatID
	if !owner {
		// the white list: only in a private chat with her, only the commands that are safe to hand over
		if m.SenderID == 0 || m.ChatID != m.SenderID || !a.commandUser(m.SenderID) || !listedCommands[name] {
			return false
		}
	}
	a.spawn("command /"+name, func() {
		reply := a.runCommand(ctx, name, rest, owner)
		if reply != "" {
			if _, err := a.TG.SendText(ctx, m.ChatID, reply, 0); err != nil {
				log.Printf("agent: command /%s: %v", name, err)
			}
		}
		_ = a.TG.MarkRead(ctx, m.ChatID)
	})
	return true
}

func (a *Agent) runCommand(ctx context.Context, name, rest string, owner bool) string {
	switch name {
	case "help":
		if !owner {
			return "Команды:\n/status: что сейчас с ней\n/usage: токены и расход за сегодня\n/pause и /resume: пауза и продолжение\n/stop: пауза + закрыть браузер и рабочий стол"
		}
		return "Команды (без модели, мгновенно):\n" +
			"/status: что сейчас с ней\n" +
			"/pause и /resume: пауза и продолжение\n" +
			"/stop: пауза + закрыть браузер и рабочий стол\n" +
			"/usage: токены и расход за сегодня\n" +
			"/work: очередь заказов; /work cancel N; /work answer N текст\n" +
			"/backup: сделать бэкап памяти сейчас\n" +
			"/мозг: какие области мозга активны и сколько она уже отвечает сама\n" +
			"/reset ID: забыть текущий разговор в чате ID (если она там запуталась); /reset all: во всех\n" +
			"/yes N и /no N: разрешить или отменить опасное действие, которое она просит; /pending: что ждёт ответа"
	case "pause":
		a.SetPaused(true)
		return "Пауза. Чаты не отвечаю, фон не работает. /resume, чтобы продолжить."
	case "resume":
		a.SetPaused(false)
		return "Снова в деле."
	case "stop":
		a.SetPaused(true)
		if a.Deps.RT != nil {
			a.Deps.RT.StopScreens()
		}
		return "Стоп: пауза, браузер и рабочий стол закрыты. Ход, который уже идёт, дозавершится. /resume, чтобы продолжить."
	case "yes":
		return a.approve(ctx, rest, true)
	case "no":
		return a.approve(ctx, rest, false)
	case "pending":
		return a.approvals.pendingText()
	case "status":
		return a.statusText()
	case "brain", "мозг":
		return a.brainText()
	case "usage":
		return a.usageText()
	case "work":
		return a.workCommand(rest)
	case "reset":
		return a.resetCommand(rest)
	case "backup":
		msg, err := a.makeBackup(ctx, true)
		if err != nil {
			return "Бэкап не получился: " + err.Error()
		}
		return msg
	}
	return ""
}

func (a *Agent) usageText() string {
	cfg := a.cfg()
	in, out := a.Usage.Today()
	s := fmt.Sprintf("Сегодня: %s токенов (вход %s, выход %s)", fmtK(in+out), fmtK(in), fmtK(out))
	if a.Price != nil {
		if usd, ok := a.Usage.Cost(a.Price); ok {
			s += fmt.Sprintf(", примерно $%.2f", usd)
		}
	}
	if cfg.DailyTokenLimit > 0 {
		s += fmt.Sprintf(". Лимит %s (%d%%)", fmtK(cfg.DailyTokenLimit), (in+out)*100/cfg.DailyTokenLimit)
	} else {
		s += ". Лимит не задан (llm.daily_token_limit)"
	}
	return s
}

func fmtK(n int64) string {
	switch {
	case n >= 1_000_000:
		return fmt.Sprintf("%.1fM", float64(n)/1e6)
	case n >= 1000:
		return fmt.Sprintf("%.1fk", float64(n)/1e3)
	}
	return strconv.FormatInt(n, 10)
}

func (a *Agent) statusText() string {
	cfg := a.cfg()
	var b strings.Builder
	state := "работает"
	if a.paused.Load() {
		state = "НА ПАУЗЕ"
	}
	up := ""
	if !a.Started.IsZero() {
		up = ", аптайм " + shortDur(time.Since(a.Started))
	}
	fmt.Fprintf(&b, "%s: %s%s\n", cfg.CharacterName, state, up)
	fmt.Fprintf(&b, "Открытых разговоров: %d, в работе: %d\n", a.sessions.count(), a.active.Load())
	b.WriteString(a.usageText() + "\n")
	if a.Deps.Work != nil {
		var open, blocked int
		for _, t := range a.Deps.Work.List(false) {
			open++
			if t.Status == work.Blocked {
				blocked++
			}
		}
		on := "выключена"
		if cfg.WorkEnabled {
			on = fmt.Sprintf("включена, запусков сегодня %d/%d", a.Deps.Work.RunsToday(time.Now()), cfg.WorkMaxRuns)
		}
		fmt.Fprintf(&b, "Фоновая работа %s. Заданий открыто: %d, ждут тебя: %d\n", on, open, blocked)
	}
	if a.Deps.RT != nil {
		br, dk := a.Deps.RT.Screens()
		fmt.Fprintf(&b, "Браузер: %s, рабочий стол: %s\n", onOff(br), onOff(dk))
	}
	if l := maint.Backups(maint.BackupDirOf(cfg)); len(l) > 0 {
		fmt.Fprintf(&b, "Последний бэкап: %s назад", shortDur(time.Since(l[0].Time)))
	} else {
		b.WriteString("Бэкапов ещё не было")
	}
	return b.String()
}

func onOff(v bool) string {
	if v {
		return "запущен"
	}
	return "закрыт"
}

func shortDur(d time.Duration) string {
	switch {
	case d < time.Minute:
		return "меньше минуты"
	case d < time.Hour:
		return fmt.Sprintf("%d мин", int(d.Minutes()))
	case d < 48*time.Hour:
		return fmt.Sprintf("%d ч %d мин", int(d.Hours()), int(d.Minutes())%60)
	}
	return fmt.Sprintf("%d дн", int(d.Hours()/24))
}

func (a *Agent) workCommand(rest string) string {
	if a.Deps.Work == nil {
		return "Очередь заказов недоступна."
	}
	f := strings.Fields(rest)
	if len(f) >= 2 && (f[0] == "cancel" || f[0] == "answer") {
		id, err := strconv.Atoi(strings.TrimPrefix(f[1], "#"))
		if err != nil {
			return "Номер задания, например: /work cancel 3"
		}
		if f[0] == "cancel" {
			if err := a.Deps.Work.Cancel(id); err != nil {
				return err.Error()
			}
			return fmt.Sprintf("Задание #%d отменено.", id)
		}
		text := strings.TrimSpace(strings.TrimPrefix(strings.TrimSpace(rest[len("answer"):]), f[1]))
		if text == "" {
			return "Что ответить? /work answer 3 да, плати"
		}
		if err := a.Deps.Work.Answer(id, text); err != nil {
			return err.Error()
		}
		return fmt.Sprintf("Ответ записан, задание #%d вернулось в очередь.", id)
	}
	ts := a.Deps.Work.List(false)
	if len(ts) == 0 {
		return "Очередь пуста."
	}
	var b strings.Builder
	for _, t := range ts {
		fmt.Fprintf(&b, "#%d [%s] %s (запуск %d/%d)\n", t.ID, t.Status, t.Title, t.Runs, t.MaxRuns)
		if t.Question != "" {
			b.WriteString("   ждёт тебя: " + t.Question + "\n")
		}
		if n := len(t.Notes); n > 0 {
			b.WriteString("   последнее: " + t.Notes[n-1].Text + "\n")
		}
	}
	return strings.TrimSpace(b.String())
}

// backupLoop sends a copy of her memory to the owner once a day (the on-disk daily backup is main's job).
func (a *Agent) backupLoop(ctx context.Context) {
	select {
	case <-ctx.Done():
		return
	case <-time.After(3 * time.Minute):
	}
	for {
		cfg := a.cfg()
		if cfg.BackupEnabled && cfg.BackupSend && cfg.PapikChatID != 0 && time.Since(a.lastBackupSent()) >= 24*time.Hour {
			if _, err := a.makeBackup(ctx, false); err != nil {
				log.Printf("agent: backup: %v", err)
			}
		}
		select {
		case <-ctx.Done():
			return
		case <-time.After(30 * time.Minute):
		}
	}
}

func (a *Agent) sentMark() string {
	return filepath.Join(maint.BackupDirOf(a.cfg()), ".last-sent")
}

func (a *Agent) lastBackupSent() time.Time {
	if info, err := os.Stat(a.sentMark()); err == nil {
		return info.ModTime()
	}
	return time.Time{}
}

// makeBackup writes the on-disk backup (with the config) and sends a copy without the config to the owner.
func (a *Agent) makeBackup(ctx context.Context, manual bool) (string, error) {
	cfg := a.cfg()
	dir := maint.BackupDirOf(cfg)
	path, err := maint.Backup(maint.Sources(cfg, a.ConfigPath), dir, cfg.BackupKeep, time.Now())
	if err != nil {
		return "", err
	}
	info, _ := os.Stat(path)
	msg := fmt.Sprintf("Бэкап на диске готов: %s", filepath.Base(path))
	if info != nil {
		msg += fmt.Sprintf(" (%.1f МБ)", float64(info.Size())/(1<<20))
	}
	if !cfg.BackupSend || cfg.PapikChatID == 0 {
		return msg + ". Он лежит на том же диске, что и она: включи maintenance.backup_send, чтобы копия приходила тебе.", nil
	}
	tmp, err := os.MkdirTemp("", "reina-send-")
	if err != nil {
		return msg, nil
	}
	defer os.RemoveAll(tmp)
	sp, err := maint.Backup(maint.SourcesToSend(cfg), tmp, 1, time.Now())
	if err != nil {
		return "", err
	}
	data, err := os.ReadFile(sp)
	if err != nil {
		return "", err
	}
	if _, err := a.TG.SendDocument(ctx, cfg.PapikChatID, filepath.Base(sp), data, "Бэкап памяти (без config.toml). Храни его вне сервера.", 0); err != nil {
		return msg + ". Отправить копию не вышло: " + err.Error(), nil
	}
	_ = os.MkdirAll(dir, 0o700)
	_ = os.WriteFile(a.sentMark(), []byte(time.Now().Format(time.RFC3339)), 0o600)
	if manual {
		return msg + ". Копия без конфига отправлена тебе выше.", nil
	}
	return "", nil
}

// resetCommand drops the open conversation of a chat (or of all) without writing it to the diary: when a talk went
// wrong (failed sends, confused names) the next turn starts from the chat itself, not from the muddle.
func (a *Agent) resetCommand(arg string) string {
	arg = strings.TrimSpace(arg)
	if arg == "" {
		return "Укажи чат: /reset -1001234567890 (id из панели или list_all_chats) или /reset all"
	}
	var ids []int64
	if arg == "all" {
		for id := range a.sessions.all() {
			ids = append(ids, id)
		}
		a.sessions.mu.Lock()
		for id := range a.sessions.carry {
			ids = append(ids, id)
		}
		a.sessions.mu.Unlock()
	} else {
		id, err := strconv.ParseInt(arg, 10, 64)
		if err != nil {
			return "Не понял id чата: " + arg
		}
		ids = []int64{id}
	}
	for _, id := range ids {
		a.sessions.reset(id)
	}
	return fmt.Sprintf("Забыла текущий разговор (%d чат.). Дневник и память о людях не тронуты.", len(ids))
}

// brainText is the answer to /мозг: the brain by regions and the progress of her own mind.
func (a *Agent) brainText() string {
	var b strings.Builder
	if c := a.Deps.Cortex; c != nil {
		rs := c.Regions()
		sort.Slice(rs, func(i, j int) bool { return rs[i].Act > rs[j].Act })
		o := c.Outputs()
		fmt.Fprintf(&b, "Мозг: %.1f млн нейронов, %d областей.\nСейчас активнее всего: ", float64(c.Net.Total())/1e6, len(rs))
		for i, r := range rs[:5] {
			if i > 0 {
				b.WriteString(", ")
			}
			fmt.Fprintf(&b, "%s %.0f%%", r.Name, r.Act*100)
		}
		fmt.Fprintf(&b, "\nДофамин %.0f%%, норадреналин %.0f%%, серотонин %.0f%%, ацетилхолин %.0f%%, кортизол %.0f%%.\nВнутри: %s. Угроза %.0f%%, награда %.0f%%, конфликт %.0f%%.", o.Mod["DA"]*100, o.Mod["NE"]*100, o.Mod["SE"]*100, o.Mod["ACh"]*100, o.Mod["cortisol"]*100, o.Inner, o.Threat*100, o.Reward*100, o.Conflict*100)
		if d := c.Dream(); d != "" {
			b.WriteString("\nСон: " + d + ".")
		}
	} else {
		b.WriteString("Мозг по областям выключен (cortex.enabled).")
	}
	if m := a.Deps.Mind; m != nil {
		s := m.Stats()
		fmt.Fprintf(&b, "\n\nСобственный разум: %d разговоров в памяти, привычек выучено %d из %d, сама ответила %d раз (%.0f%% всех ответов), совпадение с учителем %.0f%%.", s.Episodes, s.Graduated, s.Habits, s.Saved, s.Independence*100, s.ShadowHit*100)
		if !a.cfg().MindAnswerAlone {
			b.WriteString("\nОтветы без API выключены (mind.answer_alone): она только учится.")
		}
	}
	return b.String()
}
