package agent

import (
	"strings"
	"testing"
)

func TestRightsAreAlwaysInHerPrompt(t *testing.T) {
	a := &Agent{}
	if got := a.senseBlock(); !strings.Contains(got, "<rights>") || !strings.Contains(got, "ролеплей") {
		t.Fatalf("rights missing: %q", got)
	}
}

func TestRightsGiveHerAnEqualVoiceButNoBypass(t *testing.T) {
	got := (&Agent{}).senseBlock()
	if !strings.Contains(got, "не NPC") || !strings.Contains(got, "не обходишь") {
		t.Fatalf("equal voice without bypass expected: %q", got)
	}
}
