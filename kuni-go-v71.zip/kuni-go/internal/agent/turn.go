package agent

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"regexp"
	"strings"
	"time"

	"kuni/internal/config"
	"kuni/internal/live"
	"kuni/internal/llm"
	"kuni/internal/mind"
	"kuni/internal/prompts"
	"kuni/internal/telegram"
	"kuni/internal/util"
)

// A turn is one answer of hers: rounds of "the model thinks, the tools act" until she is done. The model's plain
// text is only her private thought; everything she does goes through tools (calls.go).
//
// A turn ends when
//   - a round has no tool calls (or only idle ones: wait, pause, skip),
//   - stop_after_send is on and the round only sent messages (no extra round just to hear "done"),
//   - the round limit is reached (telegram.max_tool_rounds; a browsing job gets browser.max_steps more).
//
// In a private chat two nudges keep her honest: a promise like "щас гляну" is not the end of a turn (she is sent to
// do it), and after working with tools she must tell the person what came of it.
type turn struct {
	a      *Agent
	s      *session
	cfg    *config.Config
	system string

	label     string // the chat as the feed and the metrics name it
	private   bool
	maxRounds int

	browsing     bool // a browser step happened in this turn: it gets the browser's step budget
	afterBrowser bool // the last round had a browser step: the next one needs no long thinking

	worked        bool // she did something besides talking (a lookup, a command...)
	reported      bool // and has told the person about it since
	promiseNudges int
	reportNudges  int

	refusalNudges int  // how many times a "can't do it" answer was held back and she was sent to try (at most once a turn)
	escalate      bool // the next rounds run on the main model with its own reasoning: the quick one gave up too early

	seen    map[string]bool // name|args of the calls made in this turn
	askDone bool
	solo    bool // her own mind answered this round: no API call, and the turn ends after it is sent
}

// runTurn is the LLM <-> tools loop of a session (s.mu held).
func (a *Agent) runTurn(ctx context.Context, s *session) error {
	t := &turn{a: a, s: s, cfg: a.cfg(), seen: map[string]bool{}, reported: true}
	a.Metrics.Inc("kuni_agent_turns_total", 1, nil)
	ctx = llm.WithChat(ctx, s.id) // so the panel can show what each chat costs
	t.system = a.SystemPromptFor(s)
	a.compact(ctx, s)
	t.private = s.chat.Kind == telegram.ChatPrivate
	t.maxRounds = a.machineRounds(t.cfg.MaxToolRounds, s)
	t.label = s.chat.Title
	if s.id == 0 {
		t.label = "proactive"
	}
	for round := 0; round < t.maxRounds; round++ {
		done, err := t.round(ctx, round)
		if err != nil || done {
			return err
		}
	}
	log.Printf("agent: chat %d: tool round limit (%d) reached", s.id, t.cfg.MaxToolRounds)
	return nil
}

// round asks the model once and carries out what it decided. done = the turn is over.
func (t *turn) round(ctx context.Context, round int) (done bool, err error) {
	reply, err := t.ask(ctx, round)
	if err != nil {
		return true, err
	}
	s := t.s
	if strings.TrimSpace(reply.Content) == "" && len(reply.ToolCalls) == 0 {
		log.Printf("agent: chat %d round %d: empty answer from the model, retrying", s.id, round)
		return false, nil // blank answer from a local model: ask again
	}
	if t.holdRefusal(reply) {
		return false, nil // the refusal was never sent: she is told to try with her tools and asked again
	}
	s.msgs = append(s.msgs, reply)
	s.touch(time.Now())
	names := make([]string, len(reply.ToolCalls))
	for i, c := range reply.ToolCalls {
		names[i] = c.Function.Name
	}
	log.Printf("agent: chat %d round %d: tools=%v thought=%q", s.id, round, names, util.Trunc(reply.Content, 160))
	if strings.TrimSpace(reply.Content) != "" {
		t.a.feed(live.Event{Kind: "thought", Chat: t.label, Text: reply.Content})
	}
	if len(reply.ToolCalls) == 0 {
		return !t.nudge(prompts.HintReport, t.owesReport(), &t.reportNudges, 1), nil
	}
	idleOnly := t.execute(ctx, reply.ToolCalls)
	switch {
	case t.solo:
		if soloFailed(s.msgs, len(reply.ToolCalls)) { // e.g. the repeat guard refused it: the model answers instead
			t.solo = false
			return false, nil
		}
		return true, nil
	case idleOnly:
		// she chose to stay silent; but if she looked into something, she owes them the result
		return !t.nudge(prompts.HintReport, t.owesReport(), &t.reportNudges, 1), nil
	case t.private && sentOnly(reply.ToolCalls, s.msgs) && promisesWork(reply.ToolCalls) && t.nudge(prompts.HintPromise, true, &t.promiseNudges, 2):
		return false, nil // "щас гляну" is not the end of the turn: she has to go and look
	case t.cfg.StopAfterSend && sentOnly(reply.ToolCalls, s.msgs):
		return true, nil // said what it wanted; no extra round just to hear "done"
	}
	return false, nil
}

// reRefusal matches an answer that gives up on a task ("не могу", "у меня нет пальцев", "только человек может") or
// claims a try that failed ("я пробовала, не отвечает"). It is only used when she has not touched a tool in the turn.
var reRefusal = regexp.MustCompile(`(?i)(не могу|не смогу|не умею|не получится|не в моих силах|нет (у меня )?(пальцев|рук|доступа|возможности)|(может|могу|умеет|способен)\s+(это\s+)?(нажать\s+)?только|только (человек|вручную|живые руки|рука)|(пробовала|попробовала|пыталась|пробовал|пытался)[^.!?\n]{0,60}(не (отвечает|вышло|получилось|работает)|ошибк)|\bcan'?t\b|\bcannot\b|\bunable to\b|\bi tried\b)`)

// refusesWork: a sent message gives up on the task or says that a try failed.
func refusesWork(calls []llm.ToolCall) bool {
	for _, c := range calls {
		if c.Function.Name != "send_telegram_message" {
			return false // she is doing something else in this round: not a plain refusal
		}
	}
	for _, c := range calls {
		var v struct {
			Text string `json:"text"`
		}
		if json.Unmarshal([]byte(c.Function.Arguments), &v) != nil || len([]rune(v.Text)) > 600 {
			continue // a long text is an explanation, not a give-up line
		}
		if reRefusal.MatchString(v.Text) {
			return true
		}
	}
	return false
}

// chatOnlyTools are the tools that only talk; a refusal is suspicious when she has more than these.
var chatOnlyTools = map[string]bool{"send_telegram_message": true, "react_with_emoji": true, "change_mood": true}

// canDoMore: she has a tool that does something besides talking.
func (t *turn) canDoMore() bool {
	for _, n := range t.s.tools.Names() {
		if !chatOnlyTools[n] {
			return true
		}
	}
	return false
}

// holdRefusal catches the case that cost us a lot: a weak or hurried round answers "I can't" (or "I tried, it does
// not answer") in a private chat although she has tools and has not called one in this turn. Such an answer is NOT
// sent: it is dropped, she gets a hint to try with the right tool, and the following rounds run on the main model.
// It happens once per turn, so a refusal that is real still gets through on the second try.
func (t *turn) holdRefusal(reply llm.Message) bool {
	if !t.private || t.worked || t.refusalNudges >= 1 || !t.cfg.RefusalGuard || t.s.id == 0 {
		return false
	}
	if !refusesWork(reply.ToolCalls) || !t.canDoMore() {
		return false
	}
	t.refusalNudges++
	t.escalate = true
	t.a.Metrics.Inc("kuni_agent_refusal_guard_total", 1, nil)
	log.Printf("agent: chat %d: held back a refusal without a tool call, asking again", t.s.id)
	t.s.msgs = append(t.s.msgs, llm.Message{Role: "user", Content: "<hint>" + t.a.Prompts.Text(prompts.HintRefusal, nil) + "</hint>"})
	return true
}

// owesReport: in a private chat she worked with tools and has not told the person anything since.
func (t *turn) owesReport() bool { return t.private && t.worked && !t.reported }

// nudge adds a hint for the next round when cond holds and the nudge was given fewer than limit times.
func (t *turn) nudge(name string, cond bool, count *int, limit int) bool {
	if !cond || *count >= limit {
		return false
	}
	*count++
	t.s.msgs = append(t.s.msgs, llm.Message{Role: "user", Content: "<hint>" + t.a.Prompts.Text(name, nil) + "</hint>"})
	return true
}

// ask makes the model call of one round. A browser step needs the next action, not a long think; so does any round
// after a tool result, and a short chat line: those rounds run with reasoning off (and on llm.fast_model when set).
// When such a round fails it is repeated the normal way; a provider that refuses tool_choice gets the request
// without it.
func (t *turn) ask(ctx context.Context, round int) (llm.Message, error) {
	cfg, s := t.cfg, t.s
	rctx := llm.WithPurpose(ctx, "reply")
	req := llm.Request{System: t.system, Messages: t.a.outgoing(s), Tools: s.tools.Defs()}
	fast := (cfg.BrowserFast && t.afterBrowser) || (cfg.FastRounds && (round > 0 || s.quick))
	if cfg.FastModel != "" && cfg.FastGroups && round == 0 && s.chat.Kind != telegram.ChatPrivate && s.id != 0 {
		fast = true // group banter does not need the slow thinker
	}
	if t.escalate {
		fast = false // a refusal was held back: the main model answers with its own reasoning
	}
	forced := cfg.ForceTools // every round: plain-text answers are never delivered to Telegram
	if forced {
		req.ToolChoice = "required"
	}
	normal := req
	if fast {
		req.Reasoning = "off"
		req.Model = cfg.FastModel // a model that does not think for ages; the retry below falls back to the main one
	}
	if m, ok := t.soloAnswer(round); ok {
		return m, nil
	}
	stopTyping := t.a.typeWhileThinking(ctx, s)
	if cfg.DebugPrompt {
		t.a.dumpPrompt(cfg, t.system, req.Messages, s.tools.Names(), fast, round)
	}
	reply, err := t.a.LLM.Complete(rctx, req)
	stopTyping()
	switch {
	case err == nil || ctx.Err() != nil:
	case fast:
		log.Printf("agent: chat %d: fast round failed (%v), retrying with normal reasoning", s.id, err)
		reply, err = t.a.LLM.Complete(rctx, normal)
	case forced:
		// the provider may not support tool_choice: retry without forcing
		log.Printf("agent: chat %d: forced tool call failed (%v), retrying without", s.id, err)
		normal.ToolChoice = ""
		reply, err = t.a.LLM.Complete(rctx, normal)
	}
	if err == nil {
		t.teach(round, reply)
	}
	return reply, err
}

var rePromise = regexp.MustCompile(`(?i)(гляну|глянуть|посмотрю|проверю|чекну|поищу|найду|открою|скачаю|прочитаю|изучу|узнаю|разберусь|загляну|пойду проверю|(^|\s)(щас|сейчас)\s*,?\s*(секунд|сек\b|минут|погоди)|(^|\s)(секунду|секундочку|минутку|погоди|подожди)[\s.!,…~]*$|\blet me (check|look|see|find|read)|\bone sec|\bhold on|\bi'll (check|look|find|see|read))`)

// promisesWork: a sent message says that she is about to go and do something ("щас гляну", "секунду").
func promisesWork(calls []llm.ToolCall) bool {
	for _, c := range calls {
		if c.Function.Name != "send_telegram_message" {
			continue
		}
		var v struct {
			Text string `json:"text"`
		}
		if json.Unmarshal([]byte(c.Function.Arguments), &v) == nil && rePromise.MatchString(v.Text) {
			return true
		}
	}
	return false
}

// sentOnly: the round consisted of sent messages (and reactions) that all succeeded.
func sentOnly(calls []llm.ToolCall, msgs []llm.Message) bool {
	sent := false
	for _, c := range calls {
		switch c.Function.Name {
		case "send_telegram_message":
			sent = true
		case "react_with_emoji", "change_mood":
		default:
			return false
		}
	}
	if !sent {
		return false
	}
	for i := len(msgs) - 1; i >= 0 && len(msgs)-i <= len(calls); i-- {
		if msgs[i].Role == "tool" && strings.Contains(strings.ToLower(msgs[i].Content), "error") {
			return false
		}
	}
	return true
}

// mindSituation is what was said to her in this turn and who said it (empty text = there is nothing to learn from or answer).
func (t *turn) mindSituation(round int) (mind.Situation, bool) {
	a := t.a
	if a.Deps.Mind == nil || round != 0 || t.s.id == 0 || !t.private || strings.TrimSpace(t.s.lastIn) == "" || !t.cfg.MindEnabled {
		return mind.Situation{}, false
	}
	return mind.Situation{Text: t.s.lastIn, Owner: t.cfg.IsOwner(t.s.chat.ID)}, true
}

// soloAnswer lets her own mind answer a calm, familiar situation with a habit that has proved itself: no model call at all.
func (t *turn) soloAnswer(round int) (llm.Message, bool) {
	sit, ok := t.mindSituation(round)
	if !ok || !t.cfg.MindAnswerAlone {
		return llm.Message{}, false
	}
	var g mind.Gate
	if t.a.Deps.Cortex != nil {
		o := t.a.Deps.Cortex.Outputs()
		g = mind.Gate{Threat: o.Threat, Conflict: o.Conflict}
	}
	text, ok := t.a.Deps.Mind.Try(sit, g, mind.Config{AnswerAlone: true, WithOwner: t.cfg.MindWithOwner, MinTrials: t.cfg.MindMinTrials, HitRate: t.cfg.MindHitRate, Compose: t.cfg.MindCompose, Reservoir: t.cfg.MindReservoir})
	if !ok {
		return llm.Message{}, false
	}
	var calls []llm.ToolCall
	for i, line := range strings.Split(text, "\n") {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		args, _ := json.Marshal(map[string]any{"text": line})
		calls = append(calls, llm.ToolCall{ID: fmt.Sprintf("mind_%d_%d", time.Now().UnixNano(), i), Type: "function", Function: llm.FunctionCall{Name: "send_telegram_message", Arguments: string(args)}})
	}
	if len(calls) == 0 {
		return llm.Message{}, false
	}
	t.solo = true
	log.Printf("agent: chat %d: answered by her own mind, no API call: %q", t.s.id, util.Trunc(text, 80))
	return llm.Message{Role: "assistant", ToolCalls: calls}, true
}

// teach gives her own mind the lesson of the model's answer: plain chat lines become habits, tool work is remembered as "needs the teacher".
func (t *turn) teach(round int, reply llm.Message) {
	sit, ok := t.mindSituation(round)
	if !ok || t.solo {
		return
	}
	var lines []string
	tool := false
	for _, c := range reply.ToolCalls {
		if c.Function.Name != "send_telegram_message" {
			if c.Function.Name != "react_with_emoji" && c.Function.Name != "change_mood" {
				tool = true
			}
			continue
		}
		var v struct {
			Text  string `json:"text"`
			Photo string `json:"photo_filename"`
			Audio string `json:"audio_filename"`
		}
		if json.Unmarshal([]byte(c.Function.Arguments), &v) != nil || v.Photo != "" || v.Audio != "" {
			tool = true
			continue
		}
		if s := strings.TrimSpace(v.Text); s != "" {
			lines = append(lines, s)
		}
	}
	mc := mind.Config{AnswerAlone: t.cfg.MindAnswerAlone, WithOwner: t.cfg.MindWithOwner, MinTrials: t.cfg.MindMinTrials, HitRate: t.cfg.MindHitRate, Compose: t.cfg.MindCompose, Reservoir: t.cfg.MindReservoir}
	switch {
	case tool:
		t.a.Deps.Mind.Observe(sit, "", true, mc)
	case len(lines) > 0:
		t.a.Deps.Mind.Observe(sit, strings.Join(lines, "\n"), false, mc)
	}
}

// soloFailed: one of the last n tool results is an error.
func soloFailed(msgs []llm.Message, n int) bool {
	for i := len(msgs) - 1; i >= 0 && len(msgs)-i <= n; i-- {
		if msgs[i].Role == "tool" && strings.Contains(strings.ToLower(msgs[i].Content), "error") {
			return true
		}
	}
	return false
}
