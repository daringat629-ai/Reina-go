package agent

import (
	"regexp"

	"kuni/internal/config"
	"kuni/internal/telegram"
	"kuni/internal/tools"
)

// Which tools she has in a chat. The chat decides the set (a channel has no "send", the owner's chat has the shell,
// an admin can ban); lazy_tools hides the rarely used groups behind #more_tools until the words of the messages, or
// she herself, call for them.

func (a *Agent) baseTools(d tools.Deps, proactive bool) []tools.Tool {
	ts := tools.GlobalTools(d, proactive)
	if d.Body != nil {
		ts = append(ts, tools.BodyTool(d))
	}
	if d.Life != nil {
		ts = append(ts, tools.RoomTools(d)...)
	}
	if d.Cortex != nil {
		ts = append(ts, tools.CortexTool(d))
	}
	if d.Learn != nil {
		ts = append(ts, tools.StudyTool(d))
	}
	if d.Sense != nil {
		ts = append(ts, tools.SenseTool(d))
	}
	if d.Ideas != nil {
		ts = append(ts, tools.IdeaTools(d)...)
	}
	if d.GoToSleep != nil {
		ts = append(ts, tools.GoToSleepTool(d))
	}
	if !proactive {
		// a notification turn starts with the chat already opened and rendered: #open_chat would only
		// burn a (slow, paid) round re-opening the same chat.
		kept := ts[:0]
		for _, t := range ts {
			if t.Name != "open_chat" {
				kept = append(kept, t)
			}
		}
		ts = kept
	}
	ts = append(ts, tools.WaitTools()...)
	if d.Ignore != nil {
		ts = append(ts, tools.MuteTool(d))
	}
	ts = append(ts, a.myActionsTool())
	if a.cfg().FastModel != "" && d.LLM != nil {
		ts = append(ts, tools.DelegateTool(d))
	}
	if a.cfg().MoodEnabled && d.Mood != nil {
		ts = append(ts, tools.MoodTool(d))
	}
	return append(ts, tools.AskTool(d))
}

var sysWords = regexp.MustCompile(`(?i)вступ|зайд|заход|t\.me|скача|загруз|запуст|команд|терминал|консол|файл|архив|распак|установ|удал|чат|переписк|download|run |install|shell|folder|zip|curl|wget|git |ls\b|docker|контейнер`)

var makeWords = regexp.MustCompile(`(?i)документ|ворд|word|docx|pdf|пдф|отч[её]т|резюме|письмо|таблиц|excel|эксель|xlsx|csv|график|диаграмм|chart|\bqr\b|кьюар|куар|календар|приглашени|\.ics\b|встреч|созвон|wi-?fi|вайфай`)

var lifeWords = regexp.MustCompile(`(?i)потрат|расход|доход|трат|бюджет|деньг|купил|заплатил|зарплат|\bсом\b|сомов|руб|долл|привычк|трекер|вешу|\bвес\b|шаг|выпил|зарядк|пробежк|спал\b|\bсон\b|день рождени|\bдр\b|годовщин|юбиле|\bгде\b|адрес|маршрут|доехать|добраться|рядом|ближайш|на карте|аптек|банкомат`)

var utilWords = regexp.MustCompile(`(?i)сколько дней|какой день|день недели|который час|сколько времени|врем\w* в |часов\w* пояс|перевед|конверт|миль|фунт|дюйм|градус|фаренгейт|унци|галлон|случайн|кубик|монетк|жреби|выбери|рандом|кинь|брось|\bd20\b|сколько будет`)

var errandWords = regexp.MustCompile(`(?i)найди|поищи|узнай|проверь|посмотри|сколько|курс|цен[аы]|стоит|погод|памят|диск|нагрузк|сделай|очисти|удали|почисти|покажи|пугугл`)

var browserWords = regexp.MustCompile(`(?i)браузер|сайт|страниц|скриншот|скрин\b|зайди на|загугл|погугл|гугл|яндекс|найди в интернет|в интернете|https?://|www\.|browser|website|web ?page|screenshot|google`)

var desktopWords = regexp.MustCompile(`(?i)рабоч\w+ стол|десктоп|desktop|приложени|программ[уаы]|окно|мыш|кликни|libreoffice|gimp|firefox|excel|word\b`)

var linkWords = regexp.MustCompile(`(?i)https?://|www\.|\.(com|ru|org|net|io|me|ai)/|ссылк|статья|статью|link|article`)

var pollWords = regexp.MustCompile(`(?i)опрос|голосован|проголосуй|закреп|poll|\bvote\b|\bpin\b`)

var planWords = regexp.MustCompile(`(?i)напомни|напоминан|remind|будильник|таймер|попозже|timer|alarm|через \d|завтра|\bв \d{1,2}[:.]\d{2}`)

var searchWords = regexp.MustCompile(`(?i)найд|поищ|ищи|искать|вспомни|переписк|search|find `)

var mediaWords = regexp.MustCompile(`(?i)фот|селфи|голос|войс|стикер|аватар|photo|selfie|voice|sticker|picture|pic\b`)

// newRegistry builds the tool set of a chat, hiding rarely used groups unless lazy_tools is off.
// Groups the incoming messages obviously call for (media, voice, stickers...) are unlocked up front.
func (a *Agent) newRegistry(s *session, d tools.Deps, chat telegram.Chat, proactive bool, unread []telegram.Message) *tools.Registry {
	cfg := a.cfg()
	owner := cfg.OwnerChat(chat.ID)
	r := tools.NewRegistry(a.baseTools(d, proactive)...)
	r.Add(tools.ChatTools(d, chat).All()...)
	r.Add(tools.OwnerTools(d, chat)...)
	if d.Bond != nil {
		r.Add(tools.BondTool(d, chat))
	}
	if d.Self != nil {
		r.Add(tools.SelfTool(d))
	}
	if owner { // list_all_chats supersedes it; two near-identical tools made the model loop
		r.Remove("get_telegram_chats")
	}
	if !cfg.LazyTools {
		return r
	}
	if s.unlocked == nil {
		s.unlocked = map[string]bool{}
	}
	r.Lazy(tools.Groups())
	for g := range s.unlocked {
		r.Unlock(g)
	}
	r.OnUnlock = func(g string) { s.unlocked[g] = true }
	if chat.Kind == telegram.ChatGroup { // view_messages_around is what keeps group context right
		r.Unlock("edit")
	}
	if owner { // the owner's everyday tools are at hand; the rest unlocks by the words he uses (tokens!)
		r.Unlock("system")
		r.Unlock("edit")
		if cfg.OwnerAllTools {
			for g := range tools.Groups() {
				if g != "admin" {
					r.Unlock(g)
				}
			}
		}
	}
	for _, m := range unread {
		if m.Outgoing {
			if m.Media != telegram.MediaNone || mediaWords.MatchString(m.Text) {
				r.Unlock("media")
			}
			continue
		}
		if owner && (m.FileID != "" || sysWords.MatchString(m.Text)) {
			r.Unlock("system")
		}
		if m.Media != telegram.MediaNone || mediaWords.MatchString(m.Text) {
			r.Unlock("media")
		}
		if planWords.MatchString(m.Text) {
			r.Unlock("plan")
		}
		if searchWords.MatchString(m.Text) {
			r.Unlock("search")
		}
		if owner && browserWords.MatchString(m.Text) {
			r.Unlock("browser")
		}
		if owner && desktopWords.MatchString(m.Text) {
			r.Unlock("desktop")
		}
		if m.Media == telegram.MediaDocument || linkWords.MatchString(m.Text) {
			r.Unlock("read")
		}
		if m.Media == telegram.MediaPoll || pollWords.MatchString(m.Text) {
			r.Unlock("polls")
		}
		if makeWords.MatchString(m.Text) {
			r.Unlock("make")
		}
		if utilWords.MatchString(m.Text) {
			r.Unlock("util")
		}
		if owner && (lifeWords.MatchString(m.Text) || m.Place != nil) {
			r.Unlock("life")
		}
	}
	return r
}

// quickTalk tells whether the unread messages are a short private line: no files, no media, a few words.
func quickTalk(cfg *config.Config, chat telegram.Chat, unread []telegram.Message) bool {
	if cfg.FastShortChars <= 0 || chat.Kind != telegram.ChatPrivate || len(unread) == 0 || len(unread) > 3 {
		return false
	}
	n := 0
	for _, m := range unread {
		if m.Outgoing {
			continue
		}
		if m.Media != telegram.MediaNone || m.FileID != "" || m.Poll != nil || m.ForwardFrom != "" {
			return false
		}
		if errandWords.MatchString(m.Text) || browserWords.MatchString(m.Text) || sysWords.MatchString(m.Text) {
			return false // a request for an action needs her full attention, not a fast first round
		}
		n += len([]rune(m.Text))
	}
	return n > 0 && n <= cfg.FastShortChars
}
