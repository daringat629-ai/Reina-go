package agent

import (
	"path/filepath"
	"strings"
	"testing"

	"kuni/internal/config"
	"kuni/internal/fear"
	"kuni/internal/telegram"
	"kuni/internal/tools"
)

func TestFearBlockOnlyInHisChatAndHerFreeTime(t *testing.T) {
	f := fear.New(filepath.Join(t.TempDir(), "f.json"))
	f.Startle(timeNow(), fear.Stopped, 1)
	c := &config.Config{PapikChatID: 77, OwnerTools: true}
	a := &Agent{Cfg: config.NewStaticHolder(c), Deps: tools.Deps{Fear: f}}
	if a.fearBlock(telegram.Chat{ID: 5, Kind: telegram.ChatPrivate}, "") != "" {
		t.Fatal("never spoken out loud in a stranger's chat")
	}
	if g := a.fearBlock(telegram.Chat{ID: 77, Kind: telegram.ChatPrivate}, ""); !strings.Contains(g, "<fear>") {
		t.Fatal("his chat gets it:", g)
	}
	if g := a.fearBlock(telegram.Chat{}, ""); !strings.Contains(g, "<fear>") {
		t.Fatal("her free time gets it:", g)
	}
}
