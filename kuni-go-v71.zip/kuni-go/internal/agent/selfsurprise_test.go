package agent

import (
	"testing"

	"kuni/internal/config"
	"kuni/internal/cortex"
	"kuni/internal/tools"
)

func TestSelfSurpriseBlockIsQuietUntilSheIsSurprised(t *testing.T) {
	a := &Agent{Cfg: config.NewStaticHolder(&config.Config{}), Deps: tools.Deps{Cortex: cortex.New("", 50000, 3)}}
	if a.selfSurpriseBlock() != "" {
		t.Fatal("nothing to say at the start")
	}
	if (&Agent{}).selfSurpriseBlock() != "" {
		t.Fatal("no cortex: nothing")
	}
}
