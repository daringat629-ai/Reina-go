package agent

import (
	"strings"
	"testing"
	"time"
)

func TestFailureLogCountsRepeatsAndExpires(t *testing.T) {
	var f failureLog
	now := time.Now()
	f.Add(now, "phone", `{"action":"tap"}`, "adb: exit status 1: device offline")
	f.Add(now, "shell", `{"command":"x"}`, "exit 2")
	f.Add(now, "phone", `{"action":"tap","x":1}`, "adb: exit status 1: device offline")
	r := f.Recent(now, time.Hour)
	if len(r) != 2 || r[0].Tool != "phone" || r[0].N != 2 {
		t.Fatalf("repeated failure must come first with its count: %+v", r)
	}
	if len(f.Recent(now.Add(48*time.Hour), time.Hour)) != 0 {
		t.Fatal("old failures must expire")
	}
	for i := 0; i < 50; i++ {
		f.Add(now, "t", "", strings.Repeat("e", i+1))
	}
	if len(f.Recent(now, time.Hour)) > failKeep {
		t.Fatal("the log must stay bounded")
	}
}
