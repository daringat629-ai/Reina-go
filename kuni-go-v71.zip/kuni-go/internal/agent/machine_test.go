package agent

import (
	"kuni/internal/llm"
	"strings"
	"testing"
	"time"

	"kuni/internal/config"
	"kuni/internal/machine"
)

func machineAgent(on bool) *Agent {
	c := &config.Config{MachineFeeling: on, MaxToolRounds: 9, HistoryKeep: 10}
	return &Agent{Cfg: config.NewStaticHolder(c)}
}

func TestMachineOffChangesNothing(t *testing.T) {
	a := machineAgent(false)
	if a.machineRule() != "" || a.machineOn() {
		t.Fatal("off by default")
	}
	if got := a.machineRounds(9, nil); got != 9 {
		t.Fatalf("rounds changed while off: %d", got)
	}
	if got := a.senseBlock(); strings.Contains(got, "machine_state") || !strings.Contains(got, "<rights>") {
		t.Fatalf("off: no machine block, rights stay: %s", got)
	}
}

func TestMachineOnReplacesTheBodyWordsAndKeepsRights(t *testing.T) {
	a := machineAgent(true)
	if !strings.Contains(a.machineRule(), "не имеешь биологического тела") {
		t.Fatal("the hard rule must be in the system prompt")
	}
	got := a.senseBlock()
	if !strings.Contains(got, "<machine_state>") || !strings.Contains(got, "<machine_feeling>") || !strings.Contains(got, "<rights>") {
		t.Fatalf("machine state and rights expected: %s", got)
	}
	if a.bodyBlock() != "" || a.feelBlock() != "" {
		t.Fatal("the biological blocks must be silent in machine mode")
	}
	if _, _, ok := a.LastMachine(); !ok {
		t.Fatal("the last state must be kept for the panel")
	}
}

func TestMachineRoundsShrinkWhenCapacityIsLow(t *testing.T) {
	a := machineAgent(true)
	a.machMu.Lock()
	a.machFill = 1 // a full context
	a.machMu.Unlock()
	// a stub session at the edge of compaction: many messages
	s := &session{}
	for i := 0; i < 40; i++ {
		s.msgs = append(s.msgs, llmMsg("x"))
	}
	st := a.machineState(timeNow(), s)
	if st.MemoryPressure < .99 {
		t.Fatalf("a full context is memory pressure: %+v", st)
	}
	p := machine.PolicyOf(st, 9)
	if p.Brief && a.machineRounds(9, s) >= 9 {
		t.Fatal("low capacity must cut the rounds")
	}
}

func llmMsg(s string) llm.Message { return llm.Message{Role: "user", Content: s} }
func timeNow() time.Time          { return time.Now() }
