package agent

import (
	"context"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"kuni/internal/mind"
	"kuni/internal/telegram"
)

func TestOwnMindAnswersWithoutTheAPI(t *testing.T) {
	f := newFakeLLM(t, sendCall)
	r := newRig(t, f)
	c := r.ag.Cfg.Get()
	c.MindEnabled, c.MindAnswerAlone, c.MindWithOwner, c.MindMinTrials, c.MindHitRate = true, true, true, 8, .8
	m := mind.New(filepath.Join(r.dir, "mind.json"), 1)
	mc := mind.Config{AnswerAlone: true, WithOwner: true, MinTrials: 8, HitRate: .8}
	for i := 0; i < 40; i++ { // the teacher has answered this a lot
		m.Observe(mind.Situation{Text: "hello Kuni", Owner: true}, []string{"hi alex ok", "hi alex yes", "hi alex hey", "hi alex sure"}[i%4], false, mc)
	}
	r.ag.Deps.Mind = m
	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan struct{})
	go func() { r.ag.Run(ctx); close(done) }()
	defer func() { cancel(); <-done }()
	const n = 4
	for i := 1; i <= n; i++ {
		r.tg.Incoming(telegram.Chat{ID: 100, Title: "Alex", Kind: telegram.ChatPrivate, IsMember: true}, 100, "Alex", "hello Kuni")
		time.Sleep(300 * time.Millisecond)
	}
	waitFor(t, "her own answers", func() bool { return m.Stats().Saved >= 2 })
	solo := 0
	for _, s := range r.tg.SentTexts() {
		if strings.HasPrefix(s, "hi alex") {
			solo++
		}
	}
	if solo < 2 || len(f.calls) >= n {
		t.Fatalf("solo %d, model asked %d times for %d messages", solo, len(f.calls), n)
	}
}
