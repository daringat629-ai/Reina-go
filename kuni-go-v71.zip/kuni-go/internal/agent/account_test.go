package agent

import (
	"path/filepath"
	"strings"
	"testing"
	"time"

	"kuni/internal/billing"
	"kuni/internal/config"
	"kuni/internal/metrics"
	"kuni/internal/prompts"
	"kuni/internal/telegram"
	"kuni/internal/tools"
)

func TestAccountBlockOnlyForPeopleWithBilling(t *testing.T) {
	c := &config.Config{PapikChatID: 1, BillingEnabled: true, BillingFreePerDay: 30, BillingPlusPerDay: 300, BillingBotName: "OrviPayBot", BillingEstTokens: 40000}
	ps, err := prompts.NewStore(t.TempDir(), prompts.Vars{CharacterName: "Reina"})
	if err != nil {
		t.Fatal(err)
	}
	st := billing.Open(filepath.Join(t.TempDir(), "b.json"))
	a := &Agent{Cfg: config.NewStaticHolder(c), TG: telegram.NewFake(), Metrics: metrics.New(), Prompts: ps, Deps: tools.Deps{Billing: st}}
	now := time.Now()
	l := billing.Limits{Free: 30, Plus: 300}
	st.Take(42, now, l)
	st.Take(42, now.Add(time.Minute), l)

	got := a.accountBlock(telegram.Chat{ID: 42, Kind: telegram.ChatPrivate}, now.Add(2*time.Minute))
	for _, want := range []string{"<account>", "2 of 30 free conversations used, 28 left", "token balance: 0 tokens", "@OrviPayBot", "Never invent numbers"} {
		if !strings.Contains(got, want) {
			t.Fatalf("missing %q in:\n%s", want, got)
		}
	}
	if _, err := st.AddTokens(42, 400000, 20, 0, "c", "pack", now); err != nil {
		t.Fatal(err)
	}
	if got := a.accountBlock(telegram.Chat{ID: 42, Kind: telegram.ChatPrivate}, now.Add(time.Hour)); !strings.Contains(got, "token balance: 400000 tokens, about 10 more conversations") || !strings.Contains(got, "purchases so far: 1") {
		t.Fatalf("balance block:\n%s", got)
	}
	if _, err := st.Activate(42, billing.Plus, 7, 80, "old", now); err != nil {
		t.Fatal(err)
	}
	if got := a.accountBlock(telegram.Chat{ID: 42, Kind: telegram.ChatPrivate}, now.Add(time.Hour)); !strings.Contains(got, "old Plus plan paid until") || !strings.Contains(got, "of 300 conversations on their old Plus plan") {
		t.Fatalf("an old plan is still shown:\n%s", got)
	}
	if got := a.accountBlock(telegram.Chat{ID: 1, Kind: telegram.ChatPrivate}, now); got != "" {
		t.Fatalf("owner must not get an account block: %q", got)
	}
	if got := a.accountBlock(telegram.Chat{ID: -5, Kind: telegram.ChatGroup}, now); got != "" {
		t.Fatalf("group must not get an account block: %q", got)
	}
	c.BillingEnabled = false
	if got := a.accountBlock(telegram.Chat{ID: 42, Kind: telegram.ChatPrivate}, now); got != "" {
		t.Fatalf("billing off must hide it: %q", got)
	}
	c.BillingEnabled = true
	if in := a.chatInstructions(telegram.Chat{ID: 42, Title: "Ann", Kind: telegram.ChatPrivate, IsMember: true}); !strings.Contains(in, "<account>") {
		t.Fatal("chatInstructions must carry the account block")
	}
}
