package agent

import (
	"context"
	"path/filepath"
	"strings"
	"testing"

	"kuni/internal/billing"
	"kuni/internal/config"
	"kuni/internal/metrics"
	"kuni/internal/telegram"
	"kuni/internal/tools"
)

func TestBillingGateLimitsOthersNeverTheOwner(t *testing.T) {
	c := &config.Config{PapikChatID: 1, BillingEnabled: true, BillingFreePerDay: 1, BillingBotName: "OrviPayBot"}
	tg := telegram.NewFake()
	a := &Agent{Cfg: config.NewStaticHolder(c), TG: tg, Metrics: metrics.New(), Deps: tools.Deps{Billing: billing.Open(filepath.Join(t.TempDir(), "b.json"))}}
	ctx := context.Background()
	stranger := telegram.Chat{ID: 5, Kind: telegram.ChatPrivate}
	if !a.billingAllows(ctx, stranger) {
		t.Fatal("the first conversation is free")
	}
	if a.billingAllows(ctx, stranger) || a.billingAllows(ctx, stranger) {
		t.Fatal("over the limit")
	}
	if s := tg.SentTexts(); len(s) != 1 || !strings.Contains(s[0], "@OrviPayBot") {
		t.Fatalf("told once, with the payment bot: %v", s)
	}
	for i := 0; i < 5; i++ {
		if !a.billingAllows(ctx, telegram.Chat{ID: 1, Kind: telegram.ChatPrivate}) {
			t.Fatal("the owner is never limited")
		}
	}
	if !a.billingAllows(ctx, telegram.Chat{ID: -9, Kind: telegram.ChatGroup}) {
		t.Fatal("groups are not limited")
	}
	c.BillingEnabled = false
	if !a.billingAllows(ctx, stranger) {
		t.Fatal("switched off: no limits")
	}
}
