package agent

import (
	"time"

	"kuni/internal/billing"
	"kuni/internal/body"
)

var doingWords = map[body.Activity]string{body.Resting: "отдыхает дома", body.Working: "занята своими делами", body.Walking: "гуляет", body.Running: "на пробежке", body.Asleep: "спит"}

// Presence is what she is like right now, for the pay bot's status: online or not, asleep, what she is doing, mood and energy.
// It reads her real state and changes nothing.
func (a *Agent) Presence() billing.Presence {
	now := time.Now()
	p := billing.Presence{Known: true, Mood: -1, Energy: -1}
	p.Online = a.active.Load() > 0
	if t := a.seen.Load(); t != 0 {
		p.LastSeen = time.Unix(0, t)
	}
	if p.Online {
		p.LastSeen = now
	}
	if a.Auto != nil {
		p.Asleep, p.WakeAt = a.Auto.Asleep()
	}
	p.Night = a.isNight(now)
	if a.Deps.Body != nil {
		st := a.Deps.Body.Snapshot()
		p.Energy = min(max(1-max(st.Fatigue, st.Sleep), 0), 1)
		if st.Doing == body.Asleep {
			p.Asleep = true
		}
		p.Doing = doingWords[st.Doing]
	}
	if a.Deps.Presence != nil {
		if out, _ := a.Deps.Presence.Outside(now); out {
			p.Outside, p.Doing = true, "гуляет по городу"
		}
	}
	if a.Deps.Mood != nil {
		p.Mood = a.Deps.Mood.Level()
	}
	if p.Asleep && !p.Online {
		p.Doing = "спит"
	}
	return p
}
