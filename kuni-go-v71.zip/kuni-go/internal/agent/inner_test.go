package agent

import (
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestThoughtsPersistTrimAndCount(t *testing.T) {
	p := filepath.Join(t.TempDir(), "inner_monologue.md")
	ts := loadThoughts(p)
	now := time.Now()
	for i := 0; i < thoughtKeep+5; i++ {
		ts.Add(now, "мысль номер "+strings.Repeat("я", i%3)+" "+string(rune('a'+i%26)))
	}
	ts.Add(now, "   ")
	if got := len(ts.Last(100)); got != thoughtKeep {
		t.Fatalf("kept %d, want %d", got, thoughtKeep)
	}
	again := loadThoughts(p)
	if len(again.Last(100)) != thoughtKeep || again.Last(1)[0].Text != ts.Last(1)[0].Text {
		t.Fatalf("not restored from the file")
	}
	if ts.Today(now) != thoughtKeep || ts.Today(now.AddDate(0, 0, -1)) != 0 {
		t.Fatalf("day count wrong: %d", ts.Today(now))
	}
	ts.Add(now, strings.Repeat("ы", 1000))
	if r := []rune(ts.Last(1)[0].Text); len(r) != thoughtMaxLen {
		t.Fatalf("long thought not cut: %d", len(r))
	}
}
