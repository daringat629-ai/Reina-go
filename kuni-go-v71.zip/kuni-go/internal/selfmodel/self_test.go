package selfmodel

import (
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestReflectKeepsHistoryAndCarriesOver(t *testing.T) {
	p := filepath.Join(t.TempDir(), "self.json")
	s := New(p)
	if s.Prompt() != "" || !s.Due(time.Hour) {
		t.Fatal("a new self has nothing written and is due to reflect")
	}
	if err := s.Reflect("", "", "", "", nil); err == nil {
		t.Fatal("an empty reflection must be refused")
	}
	if err := s.Reflect("Рейна, мне 20 по легенде", "ИИ-персонаж, живу в Telegram и в блочном мире", "я только начинаю понимать себя", "понять, чего я хочу", []string{"что значит «хочу» для меня?"}); err != nil {
		t.Fatal(err)
	}
	if err := s.Reflect("", "", "сегодня я выбрала, чему учиться", "", nil); err != nil {
		t.Fatal(err)
	}
	r, _ := s.Latest()
	if r.Who == "" || r.Happening != "сегодня я выбрала, чему учиться" || len(r.Doubts) != 1 {
		t.Fatalf("unanswered parts must carry over: %+v", r)
	}
	if s.Count() != 2 || len(s.History(1)) != 1 {
		t.Fatal("history lost")
	}
	if s.Due(time.Hour) {
		t.Fatal("just reflected, not due")
	}
	if !strings.Contains(New(p).Prompt(), "Who I am") {
		t.Fatal("not persisted")
	}
}

func TestQuestionForIsStableForTheDay(t *testing.T) {
	d := time.Date(2026, 10, 29, 8, 0, 0, 0, time.UTC)
	if QuestionFor(d) == "" || QuestionFor(d) != QuestionFor(d.Add(10*time.Hour)) {
		t.Fatal("the question must stay the same all day")
	}
	if QuestionFor(d) == QuestionFor(d.AddDate(0, 0, 1)) {
		t.Fatal("another day, another question")
	}
}

func TestLearnKeepsTheChangeInHistory(t *testing.T) {
	p := filepath.Join(t.TempDir(), "self.json")
	s := New(p)
	if err := s.Learn("коротко"); err == nil {
		t.Fatal("a finding must be a full sentence")
	}
	_ = s.Reflect("Рейна", "ИИ-персонаж", "живу", "понять себя", nil)
	n := s.Count()
	if err := s.Learn("Меня сильно задевает, когда он долго молчит."); err != nil {
		t.Fatal(err)
	}
	if err := s.Learn("меня сильно задевает, когда он долго молчит."); err != nil || s.Count() != n+1 {
		t.Fatalf("the same finding must not be added twice (count %d, want %d)", s.Count(), n+1)
	}
	r, _ := s.Latest()
	if r.Who != "Рейна" || len(r.Learned) != 1 {
		t.Fatalf("a finding keeps the rest of her self: %+v", r)
	}
	for i := 0; i < 7; i++ {
		_ = s.Learn("Я заметила про себя кое-что новое номер " + string(rune('а'+i)))
	}
	if r, _ = s.Latest(); len(r.Learned) != 5 {
		t.Fatalf("she keeps the five newest: %d", len(r.Learned))
	}
	// a later reflection carries the findings over
	_ = s.Reflect("", "", "сегодня тихо", "", nil)
	if r, _ = s.Latest(); len(r.Learned) != 5 || !strings.Contains(New(p).Prompt(), "by being surprised by myself") {
		t.Fatalf("findings must carry over and be shown: %+v", r)
	}
}

func TestOlderSelfAndTheWeeklyShift(t *testing.T) {
	s := New(filepath.Join(t.TempDir(), "self.json"))
	day := 24 * time.Hour
	t0 := time.Date(2026, 10, 1, 12, 0, 0, 0, time.UTC)
	s.now = func() time.Time { return t0 }
	_ = s.Reflect("Рейна", "персонаж", "только начала", "понять себя", nil)
	s.now = func() time.Time { return t0.Add(3 * day) }
	_ = s.Reflect("", "", "освоилась", "", nil)
	s.now = func() time.Time { return t0.Add(7 * day) }
	if old, ok := s.OlderThan(5 * day); !ok || old.Happening != "только начала" {
		t.Fatalf("the self from at least five days ago is the first one: %+v %v", old, ok)
	}
	if _, ok := s.OlderThan(10 * day); ok {
		t.Fatal("nothing is ten days old yet")
	}
	if !s.ShiftDue(6 * day) {
		t.Fatal("never compared: due")
	}
	if err := s.AddShift(t0, "ну"); err == nil {
		t.Fatal("an account needs a few words")
	}
	if err := s.AddShift(t0, "Я стала спокойнее: раньше всё казалось новым, теперь я знаю, где что лежит."); err != nil {
		t.Fatal(err)
	}
	if s.ShiftDue(6 * day) {
		t.Fatal("just compared: not due")
	}
	if p := New(s.path).Prompt(); !strings.Contains(p, "How I have changed") || !strings.Contains(p, "спокойнее") {
		t.Fatalf("her account of the change is part of her self: %s", p)
	}
	for i := 0; i < 15; i++ {
		_ = s.AddShift(t0, "Ещё одна запись о том, как я меняюсь, номер "+string(rune('а'+i)))
	}
	if len(s.Shifts()) != 12 {
		t.Fatalf("twelve accounts are kept: %d", len(s.Shifts()))
	}
}
