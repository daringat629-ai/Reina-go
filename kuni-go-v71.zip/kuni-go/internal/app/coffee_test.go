package app

import (
	"testing"
	"time"

	"kuni/internal/body"
	"kuni/internal/life"
	"kuni/internal/tools"
)

func TestMorningCoffeeOncePerDay(t *testing.T) {
	dir := t.TempDir()
	d := tools.Deps{Body: body.New(dir + "/b.json"), Life: life.New(dir, 3)}
	loc := time.FixedZone("x", 6*3600)
	h := newDailyHabits(dir)
	at := func(hh, mm int) time.Time { return time.Date(2026, 10, 29, hh, mm, 0, 0, loc) }
	if h.morningCoffee(d, at(5, 0), loc) || h.morningCoffee(d, at(12, 0), loc) {
		t.Fatal("coffee at the wrong hour")
	}
	if !h.morningCoffee(d, at(8, 0), loc) {
		t.Fatal("no coffee in the morning")
	}
	if h.morningCoffee(d, at(9, 0), loc) {
		t.Fatal("second coffee the same day")
	}
	if newDailyHabits(dir).morningCoffee(d, at(9, 30), loc) {
		t.Fatal("coffee forgotten across a restart")
	}
	if !newDailyHabits(dir).morningCoffee(d, at(8, 0).Add(24*time.Hour), loc) {
		t.Fatal("no coffee the next day")
	}
}
