package app

import (
	"context"
	"errors"
	"strings"
	"testing"

	"kuni/internal/llm"
)

func TestLiveCallTurnKeepsHistoryAndSpeaks(t *testing.T) {
	var seen [][]llm.Message
	var heard []string
	c := &liveCall{
		stt: func(ctx context.Context, a []byte, f string) (string, error) {
			return "привет, как ты?", nil
		},
		say: func(ctx context.Context, sys string, m []llm.Message) (string, error) {
			seen = append(seen, m)
			return "Хорошо, а ты?", nil
		},
		speak:  func(ctx context.Context, s string) ([]byte, string, error) { return []byte("AUDIO"), "audio/mpeg", nil },
		system: func() string { return "sys" },
		hear:   func(s string) { heard = append(heard, s) },
	}
	r, err := c.Turn(context.Background(), []byte("x"), "audio/webm;codecs=opus")
	if err != nil || r.Reply != "Хорошо, а ты?" || r.Audio == "" || r.Mime != "audio/mpeg" || r.Heard == "" {
		t.Fatalf("%+v %v", r, err)
	}
	if _, err := c.Turn(context.Background(), []byte("x"), "audio/webm"); err != nil {
		t.Fatal(err)
	}
	if len(seen[1]) != 3 || seen[1][1].Role != "assistant" || len(heard) != 2 {
		t.Fatalf("history not carried: %+v", seen[1])
	}
	for i := 0; i < 20; i++ {
		_, _ = c.Turn(context.Background(), nil, "")
	}
	if len(c.hist) > callKeep {
		t.Fatalf("history grows without bound: %d", len(c.hist))
	}
}

func TestLiveCallSilenceErrorsAndNoVoice(t *testing.T) {
	c := &liveCall{
		stt: func(ctx context.Context, a []byte, f string) (string, error) { return " ", nil },
		say: func(ctx context.Context, sys string, m []llm.Message) (string, error) {
			t.Fatal("must not ask the model for silence")
			return "", nil
		},
		system: func() string { return "" },
	}
	if r, err := c.Turn(context.Background(), []byte("x"), ""); err != nil || !r.Silent {
		t.Fatalf("%+v %v", r, err)
	}
	c.stt = func(ctx context.Context, a []byte, f string) (string, error) { return "", errors.New("whisper down") }
	if _, err := c.Turn(context.Background(), []byte("x"), ""); err == nil || !strings.Contains(err.Error(), "whisper") {
		t.Fatalf("%v", err)
	}
	c.stt = func(ctx context.Context, a []byte, f string) (string, error) { return "алло", nil }
	c.say = func(ctx context.Context, sys string, m []llm.Message) (string, error) { return "слушаю", nil }
	if r, err := c.Turn(context.Background(), []byte("x"), ""); err != nil || r.Reply != "слушаю" || r.Audio != "" {
		t.Fatalf("text-only reply expected: %+v %v", r, err)
	}
}
