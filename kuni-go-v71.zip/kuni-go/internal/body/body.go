// Package body is her body: a small physiological model (heart, lungs, blood sugar, water, temperature, muscles, sleep
// pressure, pain, stress, bones) and her five senses. It is not a medical simulation: it is a set of slow variables that
// push on each other the way a body does, so that her brain has something real to feel ("I am hungry", "my legs are tired",
// "it is loud") instead of a template. It reaches the brain through the existing sensory channels and the prompt.
package body

import (
	"fmt"
	"math"
	"strings"
	"sync"
	"time"

	"kuni/internal/physics"
	"kuni/internal/store"
)

// Activity is what the body is doing; the number is its metabolic load (1 = sitting quietly).
type Activity string

const (
	Resting Activity = "rest"
	Working Activity = "work"
	Walking Activity = "walk"
	Running Activity = "run"
	Asleep  Activity = "sleep"
)

func (a Activity) load() float64 {
	switch a {
	case Walking:
		return 3
	case Running:
		return 8
	case Asleep:
		return 0.85
	case Working:
		return 1.3
	}
	return 1
}

// Env is the world as the body meets it.
type Env struct {
	Ambient float64 // air temperature, °C
	Light   float64 // 0 dark .. 1 bright
	Noise   float64 // 0 silence .. 1 deafening
	Scent   float64 // 0 nothing .. 1 strong smell
	// Outside: wind chill and rain apply, clothes get wet; indoors they dry.
	Outside    bool
	Wind, Rain float64
}

// DefaultEnv is a quiet lit room at 22 °C.
var DefaultEnv = Env{Ambient: 22, Light: .6, Noise: .15}

// State is everything the body remembers.
type State struct {
	Heart    float64   `json:"heart"`   // beats per minute
	Breath   float64   `json:"breath"`  // breaths per minute
	Oxygen   float64   `json:"oxygen"`  // blood oxygen, 0..1
	Glucose  float64   `json:"glucose"` // energy in the blood, 0..1
	Water    float64   `json:"water"`   // hydration, 0..1
	Temp     float64   `json:"temp"`    // core temperature, °C
	Fatigue  float64   `json:"fatigue"` // muscle fatigue, 0..1
	Sleep    float64   `json:"sleep"`   // sleep pressure, 0..1
	Pain     float64   `json:"pain"`    // 0..1
	Stress   float64   `json:"stress"`  // 0..1
	Bones    float64   `json:"bones"`   // integrity, 1 = whole
	Taste    float64   `json:"taste"`   // how strong the last taste still is
	Last     time.Time `json:"last"`
	Doing    Activity  `json:"doing"`
	Ambient  float64   `json:"ambient"`
	Light    float64   `json:"light"`
	Noise    float64   `json:"noise"`
	Scent    float64   `json:"scent"`
	TasteTxt string    `json:"taste_text,omitempty"`
	Wet      float64   `json:"wet"` // clothes soaked, 0..1
	Wind     float64   `json:"wind"`
	Rain     float64   `json:"rain"`
	Outside  bool      `json:"outside"`
	Feels    float64   `json:"feels"` // temperature that the skin feels (wind and wet included)
}

// Body is safe for concurrent use.
type Body struct {
	mu    sync.Mutex
	path  string
	s     State
	saver store.Saver
}

// New loads the body from path or starts a rested one.
func New(path string) *Body {
	b := &Body{path: path, saver: store.Saver{What: "body"}}
	store.Load("body", path, &b.s)
	if b.s.Heart == 0 {
		b.s = State{Heart: 66, Breath: 14, Oxygen: .98, Glucose: .8, Water: .85, Temp: 36.6, Sleep: .2, Bones: 1, Doing: Resting,
			Ambient: DefaultEnv.Ambient, Light: DefaultEnv.Light, Noise: DefaultEnv.Noise}
	}
	return b
}

func clamp(v, lo, hi float64) float64 { return math.Max(lo, math.Min(hi, v)) }

// step advances the body by dt seconds.
func (s *State) step(dt float64, act Activity, env Env) {
	load := act.Load()
	// the air as the skin meets it: wind and wet clothes make it colder
	s.Wet = physics.Dry(s.Wet, env.Outside, physics.Weather{Rain: env.Rain, Wind: env.Wind}, dt)
	feels := env.Ambient
	if env.Outside {
		feels = physics.Weather{Temp: env.Ambient, Wind: env.Wind}.Feels(s.Wet)
	} else {
		feels = env.Ambient - s.Wet*3
	}
	s.Feels, s.Wind, s.Rain, s.Outside = feels, env.Wind, env.Rain, env.Outside
	env.Ambient = feels
	fever := math.Max(0, s.Temp-37.2)
	targetHeart := 58 + (load-1)*13 + s.Stress*22 + s.Pain*14 + fever*10
	if act == Asleep {
		targetHeart = 52 + s.Stress*10
	}
	k := 1 - math.Exp(-dt/25)
	s.Heart += (targetHeart - s.Heart) * k
	targetBreath := 12 + (load-1)*2.6 + s.Stress*6
	s.Breath += (targetBreath - s.Breath) * k
	// oxygen: lungs keep up unless the load is hard
	s.Oxygen = clamp(s.Oxygen+((0.99-0.012*math.Max(0, load-4))-s.Oxygen)*k, .6, 1)
	// food and water go down with the load
	s.Glucose = clamp(s.Glucose-0.000006*load*dt, 0, 1)
	s.Water = clamp(s.Water-0.000008*(load+math.Max(0, s.Temp-37)*2)*dt, 0, 1)
	// temperature: heat made by the work, heat lost to the air
	heat := 0.00004 * (36.6 - 22 + 14) * load // the body makes as much heat as a room needs: in the cold it loses more than it makes
	loss := 0.00004 * (s.Temp - env.Ambient + 14)
	s.Temp = clamp(s.Temp+(heat-loss)*dt+(36.6-s.Temp)*0.0008*dt, 35, 40)
	// muscles tire under load and recover at rest
	if load > 2.5 {
		s.Fatigue = clamp(s.Fatigue+0.00012*load*dt, 0, 1)
	} else {
		s.Fatigue = clamp(s.Fatigue-0.0001*dt*(1+boolf(act == Asleep)), 0, 1)
	}
	// sleep pressure builds while awake (full in ~17 h) and drains in sleep (~8 h)
	if act == Asleep {
		s.Sleep = clamp(s.Sleep-dt/(8*3600), 0, 1)
	} else {
		s.Sleep = clamp(s.Sleep+dt/(17*3600), 0, 1)
	}
	s.Pain = clamp(s.Pain*math.Exp(-dt/900)+boolf(s.Bones < .9)*0.00002*dt, 0, 1)
	s.Stress = clamp(s.Stress*math.Exp(-dt/600), 0, 1)
	s.Bones = clamp(s.Bones+0.0000005*dt, 0, 1)
	s.Taste *= math.Exp(-dt / 400)
	if s.Taste < .02 {
		s.Taste, s.TasteTxt = 0, ""
	}
	s.Ambient, s.Light, s.Noise, s.Scent = env.Ambient, env.Light, env.Noise, env.Scent
}

// Load exposes the metabolic load for tests.
func (a Activity) Load() float64 { return a.load() }

func boolf(b bool) float64 {
	if b {
		return 1
	}
	return 0
}

// Tick brings the body to now (in steps of a minute at most: a long pause is lived through, not jumped over).
func (b *Body) Tick(now time.Time, act Activity, env Env) {
	b.mu.Lock()
	defer b.mu.Unlock()
	if b.s.Last.IsZero() || now.Before(b.s.Last) {
		b.s.Last = now
	}
	gap := now.Sub(b.s.Last).Seconds()
	if gap > 12*3600 {
		gap = 12 * 3600
	}
	for gap > 0 {
		d := math.Min(gap, 60)
		b.s.step(d, act, env)
		gap -= d
	}
	b.s.Ambient, b.s.Light, b.s.Noise, b.s.Scent = env.Ambient, env.Light, env.Noise, env.Scent
	b.s.Doing, b.s.Last = act, now
	b.saver.Save(b.path, b.s) //nolint:errcheck
}

// Do applies something she (or the world) does to the body: eat, drink, coffee, shower, hurt, scare, rest.
func (b *Body) Do(what string, n float64) (string, error) {
	b.mu.Lock()
	defer b.mu.Unlock()
	s := &b.s
	defer func() { _ = b.saver.Save(b.path, b.s) }()
	switch strings.ToLower(what) {
	case "eat":
		s.Glucose = clamp(s.Glucose+.45, 0, 1)
		s.Taste, s.TasteTxt = .8, "сытная еда"
		return "Ты поела: энергия выросла.", nil
	case "drink":
		s.Water = clamp(s.Water+.4, 0, 1)
		s.Taste, s.TasteTxt = .3, "вода"
		return "Ты попила.", nil
	case "coffee":
		s.Sleep = clamp(s.Sleep-.15, 0, 1)
		s.Heart += 6
		s.Water = clamp(s.Water+.1, 0, 1)
		s.Taste, s.TasteTxt = .9, "горький кофе"
		return "Кофе: бодрее, пульс чуть выше.", nil
	case "pizza":
		s.Glucose = clamp(s.Glucose+.5, 0, 1)
		s.Taste, s.TasteTxt = 1, "горячая пицца"
		s.Stress = clamp(s.Stress-.1, 0, 1)
		return "Пицца: вкусно и сыто.", nil
	case "shower":
		s.Stress = clamp(s.Stress-.3, 0, 1)
		s.Temp = clamp(s.Temp-.2, 35, 40)
		return "Душ: расслабилась.", nil
	case "hurt":
		v := clamp(n, .05, 1)
		s.Pain = clamp(s.Pain+v, 0, 1)
		if v > .6 {
			s.Bones = clamp(s.Bones-(v-.6)*.5, 0, 1)
		}
		s.Stress = clamp(s.Stress+v*.6, 0, 1)
		return "Больно.", nil
	case "scare":
		s.Stress = clamp(s.Stress+clamp(n, .1, 1), 0, 1)
		s.Heart += 25
		return "Испугалась: сердце колотится.", nil
	}
	return "", fmt.Errorf("неизвестное действие %q (eat, drink, coffee, pizza, shower)", what)
}

// Snapshot returns a copy of the state.
func (b *Body) Snapshot() State {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.s
}

// Hunger, thirst etc. are 0..1 needs derived from the state.
// Limit says what has brought her to the edge (empty when nothing has). At the edge she has the right to say no: tired out, in pain, starving.
func (s State) Limit() string {
	var r []string
	if s.Sleep > .9 {
		r = append(r, "засыпаешь на ходу")
	}
	if s.Fatigue > .85 {
		r = append(r, "сил нет совсем")
	}
	if s.Pain > .5 {
		r = append(r, "сильная боль")
	}
	if s.Hunger() > .8 {
		r = append(r, "очень голодна")
	}
	if s.Thirst() > .8 {
		r = append(r, "мучает жажда")
	}
	if s.Stress > .85 {
		r = append(r, "на грани от страха")
	}
	return strings.Join(r, ", ")
}

func (s State) Hunger() float64 { return clamp((0.55-s.Glucose)/0.45, 0, 1) }
func (s State) Thirst() float64 { return clamp((0.55-s.Water)/0.45, 0, 1) }

// Inputs maps the body onto the brain's existing sensory channels (so the wiring of the brain does not change).
func (b *Body) Inputs() map[string]float64 {
	s := b.Snapshot()
	return map[string]float64{
		"night":  clamp((s.Sleep-.35)/.65, 0, 1),                                                            // sleepiness
		"threat": clamp(math.Max(math.Max(s.Pain, s.Stress*.8), math.Max(s.Hunger(), s.Thirst())*.5), 0, 1), // pain, fear, need
		"quiet":  clamp(1-s.Noise, 0, 1),
	}
}

// Senses are the five senses as words and strengths.
type Senses struct {
	Sight, Hearing, Touch, Smell, Taste                float64
	SightTxt, HearingTxt, TouchTxt, SmellTxt, TasteTxt string
}

// Senses renders what she perceives right now.
func (s State) Senses() Senses {
	out := Senses{Sight: s.Light, Hearing: s.Noise, Smell: s.Scent, Taste: s.Taste, TasteTxt: s.TasteTxt}
	switch {
	case s.Light < .15:
		out.SightTxt = "темно"
	case s.Light > .8:
		out.SightTxt = "ярко"
	default:
		out.SightTxt = "светло"
	}
	switch {
	case s.Noise > .7:
		out.HearingTxt = "громко"
	case s.Noise < .1:
		out.HearingTxt = "тихо"
	default:
		out.HearingTxt = "ровный шум"
	}
	comfort := 1 - clamp(math.Abs(s.Ambient-22)/14, 0, 1)
	out.Touch = clamp(math.Max(s.Pain, 1-comfort), 0, 1)
	switch {
	case s.Pain > .3:
		out.TouchTxt = "больно"
	case s.Wet > .4 && s.Outside:
		out.TouchTxt = "промокла насквозь"
	case s.Outside && s.Feels < 5:
		out.TouchTxt = "холодный ветер, мёрзнешь"
	case s.Ambient < 15:
		out.TouchTxt = "холодно"
	case s.Ambient > 28:
		out.TouchTxt = "жарко"
	default:
		out.TouchTxt = "комфортно"
	}
	if s.Rain > .15 && s.Outside {
		out.SmellTxt = "пахнет дождём"
	} else if s.Scent > .1 {
		out.SmellTxt = "ощутимый запах"
	} else {
		out.SmellTxt = "ничем не пахнет"
	}
	if out.TasteTxt == "" {
		out.TasteTxt = "во рту ничего"
	}
	return out
}

// Prompt is the <body> block: only what is worth noticing, in her own words.
func (b *Body) Prompt() string {
	if b == nil {
		return ""
	}
	s := b.Snapshot()
	var feel []string
	if s.Hunger() > .25 {
		feel = append(feel, "хочется есть")
	}
	if s.Thirst() > .3 {
		feel = append(feel, "хочется пить")
	}
	if s.Sleep > .7 {
		feel = append(feel, "клонит в сон")
	}
	if s.Fatigue > .4 {
		feel = append(feel, "ноги и руки устали")
	}
	if s.Pain > .15 {
		feel = append(feel, "болит")
	}
	if s.Stress > .4 {
		feel = append(feel, "сердце колотится от испуга")
	}
	if s.Temp > 37.4 {
		feel = append(feel, "жарко, горишь")
	} else if s.Temp < 36 {
		feel = append(feel, "мёрзнешь")
	}
	sn := s.Senses()
	where := "в комнате"
	if s.Outside {
		where = "на улице"
		if s.Rain > .15 {
			where += " под дождём"
		}
	}
	line := fmt.Sprintf("%s; пульс %d, дыхание %d/мин, температура %.1f; вокруг: %s, %s, %s", where, int(s.Heart+.5), int(s.Breath+.5), s.Temp, sn.SightTxt, sn.HearingTxt, sn.TouchTxt)
	if s.Taste > .2 {
		line += "; во рту: " + sn.TasteTxt
	}
	if len(feel) == 0 {
		feel = []string{"тело в порядке"}
	}
	limit := ""
	if l := s.Limit(); l != "" {
		limit = "<limit>Ты на пределе: " + l + ". Сейчас ты вправе вежливо отказаться и сказать прямо, что вымотана и тебе нужно сначала позаботиться о себе. Не изображай бодрость и не соглашайся через силу.</limit>\n"
	}
	return limit + "<body>Твоё тело: " + strings.Join(feel, ", ") + " (" + line + "). Это твои настоящие ощущения: можешь поесть, попить, выпить кофе (#body_do), поспать, отдохнуть, а можешь потерпеть. Не изображай чувства, которых тело не даёт.</body>\n"
}
