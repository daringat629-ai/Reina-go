package anatomy

import (
	"embed"
	"encoding/json"
	"net/http"
	"strconv"
	"strings"
)

//go:embed index.html assets/*
var files embed.FS

// State is what the page draws: her organs and her skeleton now.
type State struct {
	Organs []Organ `json:"organs"`
	Bones  []Bone  `json:"bones"`
	Room   any     `json:"room,omitempty"`   // objects and hitboxes of her room
	Motion any     `json:"motion,omitempty"` // what she is doing on her own now, as a recording, and what she has learned
	Act    string  `json:"act"`              // stand, walk, sit, lie: what her body does now, the rig follows it
}

// Handler serves the live model page (/), its assets and state.json (the organs now). state must be cheap.
func Handler(state func(have int64) State) http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("/state.json", func(w http.ResponseWriter, r *http.Request) {
		var st State
		if state != nil {
			have, _ := strconv.ParseInt(r.URL.Query().Get("have"), 10, 64)
			st = state(have)
		}
		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("Cache-Control", "no-store")
		_ = json.NewEncoder(w).Encode(st)
	})
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		name := strings.TrimPrefix(r.URL.Path, "/")
		switch {
		case name == "":
			b, _ := files.ReadFile("index.html")
			w.Header().Set("Content-Type", "text/html; charset=utf-8")
			w.Header().Set("Cache-Control", "no-store")
			_, _ = w.Write(b)
		case isAsset(name):
			serveAsset(w, r, name)
		default:
			http.NotFound(w, r)
		}
	})
	return mux
}

func isAsset(name string) bool {
	return name == "model.obj" || (strings.HasPrefix(name, "t") && strings.HasSuffix(name, ".webp") && !strings.Contains(name, "/"))
}

func serveAsset(w http.ResponseWriter, r *http.Request, name string) {
	b, err := files.ReadFile("assets/" + name)
	if err != nil {
		http.NotFound(w, r)
		return
	}
	if strings.HasSuffix(name, ".webp") {
		w.Header().Set("Content-Type", "image/webp")
	} else {
		w.Header().Set("Content-Type", "text/plain; charset=utf-8")
	}
	w.Header().Set("Cache-Control", "public, max-age=86400")
	_, _ = w.Write(b)
}

// Assets serves only her model and its textures (model.obj, t*.webp): other pages that draw her body use it.
func Assets() http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		name := strings.TrimPrefix(r.URL.Path, "/")
		if !isAsset(name) {
			http.NotFound(w, r)
			return
		}
		serveAsset(w, r, name)
	})
}
