// Package feel is how she feels. Not a mood number: a core affect (how pleasant, how aroused, how much in control) that
// is pushed by her body, by what happens to her and by what things have come to mean to her, and then named in her own
// words. The part that makes it hers is the taste table: every situation (rain, night, a quiet room, the owner's voice, a
// kept promise) slowly learns how it felt when she was in it, so that the same rain becomes cosy for one life and bleak
// for another. Nobody writes her tastes; they grow out of what happens to her.
package feel

import (
	"fmt"
	"math"
	"sort"
	"strings"
	"sync"
	"time"

	"kuni/internal/body"
	"kuni/internal/store"
)

// Tags are the situations she can come to like or dislike.
const (
	Rain       = "дождь"
	Night      = "ночь"
	Outside    = "улица"
	Room       = "своя комната"
	Hungry     = "голод"
	Fed        = "сытость"
	Sleepy     = "сонливость"
	Pain       = "боль"
	Cold       = "холод"
	Warm       = "тепло"
	OwnerHere  = "папик рядом"
	OwnerAway  = "папик пропал"
	KeptWord   = "сдержанное обещание"
	BrokenWord = "нарушенное обещание"
	OwedWord   = "моё просроченное слово"
	Quiet      = "тишина"
	Noise      = "шум"
	Cat        = "кот рядом"
	Idea       = "идея одобрена"
)

// State is the affect and her taste table.
type State struct {
	Valence   float64            `json:"valence"` // -1 bad .. +1 good
	Arousal   float64            `json:"arousal"` // 0 calm/sleepy .. 1 wired
	Control   float64            `json:"control"` // 0 helpless .. 1 in charge
	Taste     map[string]float64 `json:"taste"`   // situation -> learned valence, -1..1
	Seen      map[string]int     `json:"seen"`    // situation -> how many times it has been lived through
	Baseline  float64            `json:"baseline"`
	Causes    []string           `json:"causes"`
	LastTick  time.Time          `json:"last_tick"`
	LastLearn time.Time          `json:"last_learn"`
	Word      string             `json:"word"`
}

// Feel is safe for concurrent use.
type Feel struct {
	mu    sync.Mutex
	path  string
	s     State
	saver store.Saver
}

// New loads her affect or starts calm and mildly content.
func New(path string) *Feel {
	f := &Feel{path: path, saver: store.Saver{What: "feel"}}
	store.Load("feel", path, &f.s)
	if f.s.Taste == nil {
		f.s.Taste, f.s.Seen = map[string]float64{}, map[string]int{}
		f.s.Valence, f.s.Arousal, f.s.Control, f.s.Baseline = .15, .3, .6, .1
	}
	return f
}

func clamp(v, lo, hi float64) float64 { return math.Max(lo, math.Min(hi, v)) }

// What the world brought in this moment: situations that are present, and what each of them would feel like to anyone.
type Situation struct {
	Tag     string
	Valence float64 // innate pleasantness, -1..1
	Arousal float64 // innate arousal, 0..1
	Weight  float64 // how strongly it is present, 0..1
}

// Innate is how situations feel before she has any history with them.
var Innate = map[string]Situation{
	Rain:       {Rain, 0, .3, 1},
	Night:      {Night, 0, .1, 1},
	Outside:    {Outside, .1, .5, 1},
	Room:       {Room, .15, .1, 1},
	Hungry:     {Hungry, -.5, .6, 1},
	Fed:        {Fed, .35, .1, 1},
	Sleepy:     {Sleepy, -.15, .05, 1},
	Pain:       {Pain, -.8, .85, 1},
	Cold:       {Cold, -.45, .5, 1},
	Warm:       {Warm, .35, .1, 1},
	OwnerHere:  {OwnerHere, .45, .5, 1},
	OwnerAway:  {OwnerAway, -.4, .4, 1},
	KeptWord:   {KeptWord, .6, .5, 1},
	BrokenWord: {BrokenWord, -.6, .6, 1},
	OwedWord:   {OwedWord, -.5, .5, 1},
	Quiet:      {Quiet, .2, .05, 1},
	Noise:      {Noise, -.2, .6, 1},
	Cat:        {Cat, .4, .3, 1},
	Idea:       {Idea, .5, .6, 1},
}

// felt is how a situation feels to HER now: its innate pleasantness blended with what she has learned about it. The more she has
// lived through it, the more her own history counts (up to 80%).
func (s *State) felt(tag string, innate float64) float64 {
	n := float64(s.Seen[tag])
	w := clamp(n/60, 0, .8)
	return (1-w)*innate + w*s.Taste[tag]
}

// FromBody lists the situations her body and place are in right now.
func FromBody(b body.State, now time.Time, hourNight bool) []Situation {
	var out []Situation
	add := func(tag string, w float64) {
		if w > .05 {
			x := Innate[tag]
			x.Weight = clamp(w, 0, 1)
			out = append(out, x)
		}
	}
	add(Hungry, b.Hunger())
	add(Pain, b.Pain)
	add(Sleepy, (b.Sleep-.5)*2)
	if b.Hunger() < .1 && b.Thirst() < .1 && b.Pain < .05 {
		add(Fed, .6)
	}
	if b.Feels < 8 && b.Outside || b.Temp < 36.2 {
		add(Cold, 1)
	} else if b.Temp > 36.4 && b.Wet < .2 && b.Feels > 17 && b.Feels < 27 {
		add(Warm, .6)
	}
	if b.Outside {
		add(Outside, 1)
	} else {
		add(Room, 1)
	}
	if b.Rain > .15 {
		add(Rain, b.Rain)
	}
	if hourNight {
		add(Night, 1)
	}
	if b.Noise > .6 {
		add(Noise, b.Noise)
	} else if b.Noise < .15 {
		add(Quiet, 1-b.Noise)
	}
	return out
}

// Sample lives through dt of the given situations: affect relaxes toward what they feel like to her, and the taste of each situation
// is nudged toward how she actually felt while in it (at most once per five minutes, so a single bad hour does not rewrite her).
func (f *Feel) Sample(now time.Time, sits []Situation, extra ...Situation) {
	f.mu.Lock()
	defer f.mu.Unlock()
	s := &f.s
	all := append(append([]Situation{}, sits...), extra...)
	dt := 60.0
	if !s.LastTick.IsZero() {
		dt = clamp(now.Sub(s.LastTick).Seconds(), 1, 3600)
	}
	var vSum, aSum, wSum float64
	var causes []struct {
		tag string
		mag float64
	}
	for _, x := range all {
		v := s.felt(x.Tag, x.Valence)
		vSum += v * x.Weight
		aSum += x.Arousal * x.Weight
		wSum += x.Weight
		causes = append(causes, struct {
			tag string
			mag float64
		}{x.Tag, math.Abs(v) * x.Weight})
	}
	tv, ta := s.Baseline, .25
	if wSum > 0 {
		// negative things weigh more than pleasant ones (people are built that way), and a few strong things beat many mild ones
		pos, neg := 0.0, 0.0
		for _, x := range all {
			v := s.felt(x.Tag, x.Valence) * x.Weight
			if v > 0 {
				pos += v
			} else {
				neg += v
			}
		}
		tv = clamp(s.Baseline+.55*math.Tanh(pos)+.8*math.Tanh(neg), -1, 1)
		ta = clamp(aSum/math.Max(wSum, 1)*1.1, 0, 1)
	}
	k := 1 - math.Exp(-dt/420) // affect settles in a few minutes
	s.Valence += (tv - s.Valence) * k
	s.Arousal += (ta - s.Arousal) * k
	// control: pain and need take it away, comfort gives it back
	tc := .65
	for _, x := range all {
		if x.Tag == Pain || x.Tag == Hungry || x.Tag == BrokenWord || x.Tag == OwedWord || x.Tag == OwnerAway {
			tc -= .25 * x.Weight
		}
	}
	s.Control += (clamp(tc, 0, 1) - s.Control) * k
	// her tastes learn from how she felt
	if now.Sub(s.LastLearn) >= 5*time.Minute {
		for _, x := range all {
			if x.Weight < .3 {
				continue
			}
			s.Taste[x.Tag] = clamp(s.Taste[x.Tag]+(s.Valence-s.Taste[x.Tag])*.12, -1, 1)
			s.Seen[x.Tag]++
		}
		s.LastLearn = now
		// temperament drifts very slowly toward the mean of her life
		s.Baseline = clamp(s.Baseline+(s.Valence*.5-s.Baseline)*.002, -.3, .4)
	}
	sort.Slice(causes, func(i, j int) bool { return causes[i].mag > causes[j].mag })
	s.Causes = s.Causes[:0]
	for i := 0; i < len(causes) && i < 3; i++ {
		if causes[i].mag > .08 {
			s.Causes = append(s.Causes, causes[i].tag)
		}
	}
	s.Word = Name(s.Valence, s.Arousal, s.Control)
	s.LastTick = now
	_ = f.saver.Save(f.path, s)
}

// Impulse is a sudden event: it moves the affect at once (a kind word, a fright, a broken promise) and counts as lived through
// for her tastes.
func (f *Feel) Impulse(now time.Time, tag string) {
	f.mu.Lock()
	defer f.mu.Unlock()
	x, ok := Innate[tag]
	if !ok {
		return
	}
	s := &f.s
	v := s.felt(tag, x.Valence)
	s.Valence = clamp(s.Valence+v*.6, -1, 1)
	s.Arousal = clamp(s.Arousal+x.Arousal*.5, 0, 1)
	s.Taste[tag] = clamp(s.Taste[tag]+(s.Valence-s.Taste[tag])*.25, -1, 1)
	s.Seen[tag] += 3
	s.Word = Name(s.Valence, s.Arousal, s.Control)
	s.Causes = append([]string{tag}, s.Causes...)
	if len(s.Causes) > 3 {
		s.Causes = s.Causes[:3]
	}
	_ = f.saver.Save(f.path, s)
}

// Name puts a position in the circle of feeling into a Russian word. It is deliberately fine-grained and depends on control:
// the same bad and wired is anger in someone in control and fear in someone who is not.
func Name(v, a, c float64) string {
	switch {
	case v > .55 && a > .55:
		return "восторг"
	case v > .55:
		return "тихая радость"
	case v > .25 && a > .5:
		return "азарт, интерес"
	case v > .25:
		return "спокойное удовольствие"
	case v > .05 && a < .2:
		return "уют, расслабленность"
	case v >= -.1 && a < .2:
		return "сонное безразличие"
	case v >= -.1 && a > .6:
		return "напряжённое ожидание"
	case v >= -.1:
		return "ровное состояние"
	case v > -.4 && a < .35:
		return "грусть"
	case v > -.4 && a >= .35:
		return "раздражение"
	case a < .35:
		return "тоска, тяжело"
	case c > .45:
		return "злость"
	default:
		return "страх, беспомощность"
	}
}

// Snapshot returns a copy of the state.
func (f *Feel) Snapshot() State {
	f.mu.Lock()
	defer f.mu.Unlock()
	s := f.s
	s.Taste = map[string]float64{}
	s.Seen = map[string]int{}
	for k, v := range f.s.Taste {
		s.Taste[k] = v
	}
	for k, v := range f.s.Seen {
		s.Seen[k] = v
	}
	s.Causes = append([]string(nil), f.s.Causes...)
	return s
}

// Tastes returns what she has learned to like and dislike (only what she has lived through enough to have an opinion about).
func (s State) Tastes() (likes, dislikes []string) {
	type kv struct {
		k string
		v float64
	}
	var l []kv
	for k, v := range s.Taste {
		if s.Seen[k] >= 12 && math.Abs(v) > .25 {
			l = append(l, kv{k, v})
		}
	}
	sort.Slice(l, func(i, j int) bool { return l[i].v > l[j].v })
	for _, x := range l {
		if x.v > 0 {
			likes = append(likes, x.k)
		} else {
			dislikes = append([]string{x.k}, dislikes...)
		}
	}
	return
}

// Inputs maps the affect onto the brain's existing channels (praise = pleasant, threat = unpleasant and wired).
func (f *Feel) Inputs() map[string]float64 {
	s := f.Snapshot()
	return map[string]float64{
		"praise": clamp(s.Valence, 0, 1),
		"threat": clamp(-s.Valence*(.4+s.Arousal*.6), 0, 1),
	}
}

// Prompt is the <feeling> block: how she feels, why, and what is hers about it.
func (f *Feel) Prompt() string {
	if f == nil {
		return ""
	}
	s := f.Snapshot()
	var b strings.Builder
	fmt.Fprintf(&b, "<feeling>Ты чувствуешь: %s", s.Word)
	if len(s.Causes) > 0 {
		b.WriteString(" (из-за: " + strings.Join(s.Causes, ", ") + ")")
	}
	likes, dislikes := s.Tastes()
	if len(likes) > 0 {
		b.WriteString(". Твоё, из опыта: любишь " + strings.Join(likes, ", "))
	}
	if len(dislikes) > 0 {
		b.WriteString("; не любишь " + strings.Join(dislikes, ", "))
	}
	b.WriteString(". Это твоё настоящее чувство: говори и поступай из него, а не из шаблона. Можно его не показывать, но не изображай чужое.</feeling>\n")
	return b.String()
}
