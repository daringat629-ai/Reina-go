package letters

import (
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestLetterOpensOnItsDayAndWantsAnAnswer(t *testing.T) {
	s := Open(filepath.Join(t.TempDir(), "l.json"))
	now := time.Date(2026, 10, 29, 12, 0, 0, 0, time.UTC)
	if _, err := s.Write("слишком скоро", now.Add(time.Hour), now); err == nil {
		t.Fatal("an hour is too soon")
	}
	if _, err := s.Write("слишком далеко", now.Add(400*24*time.Hour), now); err == nil {
		t.Fatal("more than a year is too far")
	}
	l, err := s.Write("Дорогая я. Сегодня я боюсь, что забуду, чего хотела. Не забудь.", now.Add(30*24*time.Hour), now)
	if err != nil {
		t.Fatal(err)
	}
	if len(s.Due(now.Add(29*24*time.Hour))) != 0 || s.Prompt(now, time.UTC) != "" {
		t.Fatal("the letter is sealed until its day")
	}
	open := now.Add(31 * 24 * time.Hour)
	p := s.Prompt(open, time.UTC)
	if !strings.Contains(p, "Не забудь") || !strings.Contains(p, "#letter_reply") || !strings.Contains(p, "Папик может читать") {
		t.Fatal(p)
	}
	if err := s.Reply(l.ID, "Я помню. Я стала смелее.", open); err != nil {
		t.Fatal(err)
	}
	if s.Prompt(open, time.UTC) != "" || s.Reply(l.ID, "ещё раз", open) == nil {
		t.Fatal("answered once, then it rests")
	}
	if s.Reply(99, "x", open) == nil {
		t.Fatal("no such letter")
	}
	again := Open(s.path)
	if len(again.All(open)) != 1 || again.All(open)[0].Reply == "" {
		t.Fatal("letters must survive a restart")
	}
}

func TestTooManyPendingLetters(t *testing.T) {
	s := Open(filepath.Join(t.TempDir(), "l.json"))
	now := time.Now()
	for i := 0; i < maxPending; i++ {
		if _, err := s.Write("письмо номер "+strings.Repeat("я", i+1), now.Add(48*time.Hour), now); err != nil {
			t.Fatal(err)
		}
	}
	if _, err := s.Write("ещё одно письмо подряд", now.Add(48*time.Hour), now); err == nil {
		t.Fatal("she must not flood herself")
	}
}
