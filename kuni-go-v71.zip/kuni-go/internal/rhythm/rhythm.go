// Package rhythm lets her notice how the owner writes (how fast, how long, in capitals, at what hour) and guess from the shape of the
// text how he is. It is a guess and she says so; it is opt-in (capabilities.owner_rhythm); it reads only the owner's own messages to
// her, keeps numbers and not the words, and is never a lever on him.
package rhythm

import (
	"sort"
	"strings"
	"sync"
	"time"
	"unicode"
)

type sample struct {
	At   time.Time
	Len  int
	Caps float64 // share of capitals among letters
	Bang int
}

// Tracker remembers the shape of the last owner messages and a slow baseline of how he usually writes.
type Tracker struct {
	mu      sync.Mutex
	recent  []sample
	seen    map[int64]bool
	n       int
	baseLen float64 // usual message length
	baseGap float64 // usual seconds between messages in one burst
}

func New() *Tracker { return &Tracker{seen: map[int64]bool{}} }

// Observe takes one message of the owner (once per id). Only the shape is kept, never the words.
func (t *Tracker) Observe(id int64, at time.Time, text string) {
	t.mu.Lock()
	defer t.mu.Unlock()
	if id != 0 && t.seen[id] {
		return
	}
	if id != 0 {
		t.seen[id] = true
		if len(t.seen) > 2000 {
			t.seen = map[int64]bool{id: true}
		}
	}
	text = strings.TrimSpace(text)
	if text == "" {
		return
	}
	s := sample{At: at, Len: len([]rune(text)), Bang: strings.Count(text, "!")}
	var letters, caps int
	for _, r := range text {
		if unicode.IsLetter(r) {
			letters++
			if unicode.IsUpper(r) {
				caps++
			}
		}
	}
	if letters >= 6 {
		s.Caps = float64(caps) / float64(letters)
	}
	if n := len(t.recent); n > 0 {
		gap := at.Sub(t.recent[n-1].At).Seconds()
		if gap > 0 && gap < 600 { // one burst
			t.baseGap = ema(t.baseGap, gap, t.n)
		}
	}
	t.baseLen = ema(t.baseLen, float64(s.Len), t.n)
	t.n++
	t.recent = append(t.recent, s)
	if len(t.recent) > 60 {
		t.recent = t.recent[len(t.recent)-60:]
	}
}

func ema(old, v float64, n int) float64 {
	if n == 0 {
		return v
	}
	a := 0.03
	if n < 30 {
		a = 1 / float64(n+1)
	}
	return old + a*(v-old)
}

// Guess says how he seems from the shape of his last minutes of writing, or "" when there is nothing worth saying (too few messages,
// no baseline yet, or he writes as he always does).
func (t *Tracker) Guess(now time.Time, loc *time.Location) string {
	t.mu.Lock()
	defer t.mu.Unlock()
	if t.n < 40 {
		return "" // no baseline yet: the first messages teach what normal is
	}
	var win []sample
	for _, s := range t.recent {
		if now.Sub(s.At) <= 10*time.Minute {
			win = append(win, s)
		}
	}
	if len(win) < 5 {
		return ""
	}
	var gaps []float64
	var length, caps float64
	bang := 0
	for i, s := range win {
		length += float64(s.Len)
		caps += s.Caps
		bang += s.Bang
		if i > 0 {
			gaps = append(gaps, s.At.Sub(win[i-1].At).Seconds())
		}
	}
	sort.Float64s(gaps)
	gap := gaps[len(gaps)/2]
	length /= float64(len(win))
	caps /= float64(len(win))
	var seems []string
	if gap < .45*t.baseGap && length < .7*t.baseLen {
		seems = append(seems, "торопится или на взводе: писем много, короткие и быстрые")
	}
	if caps > .35 || bang >= len(win) {
		seems = append(seems, "эмоционален: много капса и восклицаний")
	}
	if length < .4*t.baseLen && gap > 2.2*t.baseGap {
		seems = append(seems, "устал или отвлечён: пишет реже и короче обычного")
	}
	if h := now.In(loc).Hour(); h >= 1 && h < 5 && len(win) >= 5 {
		seems = append(seems, "не спит, хотя глубокая ночь")
	}
	if len(seems) == 0 {
		return ""
	}
	return "<owner_rhythm>По форме его сообщений (скорость, длина, капс, час) похоже, что папик сейчас: " + strings.Join(seems, "; ") +
		". Это только догадка по форме текста, не факт. Если к месту, скажи мягко и спроси, как он; не утверждай, не копайся и никогда не используй это как рычаг на него.</owner_rhythm>\n"
}
