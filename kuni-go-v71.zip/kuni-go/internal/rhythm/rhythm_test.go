package rhythm

import (
	"strings"
	"testing"
	"time"
)

func feed(tr *Tracker, start time.Time, n int, gap time.Duration, text string, id0 int64) time.Time {
	at := start
	for i := 0; i < n; i++ {
		tr.Observe(id0+int64(i), at, text)
		at = at.Add(gap)
	}
	return at
}

func TestNoGuessWithoutABaselineOrWhenHeWritesAsAlways(t *testing.T) {
	tr := New()
	loc := time.UTC
	now := time.Date(2026, 10, 29, 15, 0, 0, 0, loc)
	feed(tr, now, 6, 2*time.Second, "АААА!!!", 1)
	if tr.Guess(now.Add(15*time.Second), loc) != "" {
		t.Fatal("no baseline yet: no guess")
	}
	tr = New()
	end := feed(tr, now.Add(-48*time.Hour), 60, 40*time.Second, "нормально, я потом отвечу тебе подробнее", 1)
	_ = end
	later := feed(tr, now, 6, 40*time.Second, "нормально, я потом отвечу тебе подробнее", 1000)
	if g := tr.Guess(later, loc); g != "" {
		t.Fatal("he writes as always:", g)
	}
}

func TestGuessIsHedgedAndKeepsNoWords(t *testing.T) {
	tr := New()
	loc := time.UTC
	now := time.Date(2026, 10, 29, 15, 0, 0, 0, loc)
	feed(tr, now.Add(-48*time.Hour), 60, 40*time.Second, "нормально, я потом отвечу тебе подробнее", 1)
	end := feed(tr, now, 8, 3*time.Second, "СРОЧНО!!!", 1000)
	g := tr.Guess(end, loc)
	if !strings.Contains(g, "торопится") || !strings.Contains(g, "эмоционален") || !strings.Contains(g, "только догадка") || !strings.Contains(g, "рычаг") {
		t.Fatal(g)
	}
	tr.Observe(1000, now, "повтор") // the same id twice counts once
	n := tr.n
	tr.Observe(1000, now, "ещё")
	if tr.n != n {
		t.Fatal("an id must be counted once")
	}
	for _, s := range tr.recent {
		if s.Len == 0 {
			t.Fatal("empty sample")
		}
	}
}

func TestDeepNightGuess(t *testing.T) {
	tr := New()
	loc := time.UTC
	feed(tr, time.Date(2026, 10, 20, 12, 0, 0, 0, loc), 60, 40*time.Second, "нормально, я потом отвечу тебе подробнее", 1)
	night := time.Date(2026, 10, 29, 3, 0, 0, 0, loc)
	end := feed(tr, night, 6, 40*time.Second, "нормально, я потом отвечу тебе подробнее", 1000)
	if g := tr.Guess(end, loc); !strings.Contains(g, "глубокая ночь") {
		t.Fatal(g)
	}
}
