package billing

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net/http"
	"strconv"
	"strings"
	"sync"
	"time"
)

// Bot is the small payment bot: it shows a person their balance, Reina's status and sells token packs in Telegram Stars (currency
// XTR) or by a bank QR. Her own Telegram account is a user account and cannot send invoices, so payment lives in a separate bot.
type Bot struct {
	Token     string
	BaseURL   string // https://api.telegram.org by default (tests point it elsewhere)
	Store     *Store
	Packs     func() []Pack // what can be bought now
	Limits    func() Limits
	PerConv   func() int64    // tokens one conversation costs on average (for "≈ N разговоров")
	Presence  func() Presence // Reina's state right now (nil = unknown)
	Her       func() string   // Reina's @username without @, for "написать ей" (empty = not shown)
	Name      string          // the bot's @username (for invite and gift links)
	RefTokens func() int64    // invite bonus in tokens for both sides (0 = off)
	Support   func() string   // where to ask about payments
	Loc       *time.Location
	HTTP      *http.Client
	Now       func() time.Time
	OnPaid    func(userID int64, what string)                       // e.g. tell the owner
	Render    func(ctx context.Context, svg string) ([]byte, error) // SVG to PNG for the pictures (nil = text only)
	QR        func() []byte                                         // the owner's bank QR picture (nil or empty = no QR payment)
	OnReceipt func(r Request, receipt []byte)                       // a receipt arrived: show it to the owner
	Rates     func() string                                         // "RUB=0.95,KZT=5.7,USD=0.0114": one unit in other currencies (shown next to QR prices)
	Currency  func() string                                         // main currency of QR prices ("RUB" by default)
	Icons     func() []string                                       // custom emoji ids for the six menu buttons; "" = an ordinary emoji
	offset    int64
	mu        sync.Mutex
	links     map[string]string
	last      map[int64]lastReq
}

// tok is the token without stray spaces or a line break from pasting; a bad character would put the whole URL, token included, into an error.
func (b *Bot) tok() string { return strings.TrimSpace(b.Token) }

func (b *Bot) now() time.Time {
	if b.Now != nil {
		return b.Now()
	}
	return time.Now()
}

func (b *Bot) call(ctx context.Context, method string, in, out any) error {
	base := b.BaseURL
	if base == "" {
		base = "https://api.telegram.org"
	}
	body, _ := json.Marshal(in)
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, base+"/bot"+b.tok()+"/"+method, bytes.NewReader(body))
	if err != nil {
		return fmt.Errorf("billing bot: %s: bad request (check the bot token in the config)", method) // the error text would hold the URL with the token
	}
	req.Header.Set("Content-Type", "application/json")
	hc := b.HTTP
	if hc == nil {
		hc = &http.Client{Timeout: 70 * time.Second}
	}
	resp, err := hc.Do(req)
	if err != nil {
		return fmt.Errorf("billing bot: %s: %w", method, errors.Unwrap(err)) // never put the token (it is in the URL) into a log line
	}
	defer resp.Body.Close()
	var r struct {
		OK          bool            `json:"ok"`
		Result      json.RawMessage `json:"result"`
		Description string          `json:"description"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&r); err != nil {
		return fmt.Errorf("billing bot: %s: bad answer", method)
	}
	if !r.OK {
		return fmt.Errorf("billing bot: %s: %s", method, r.Description)
	}
	if out != nil {
		return json.Unmarshal(r.Result, out)
	}
	return nil
}

type update struct {
	UpdateID int64 `json:"update_id"`
	Message  *struct {
		From struct {
			ID        int64  `json:"id"`
			FirstName string `json:"first_name"`
		} `json:"from"`
		Chat struct {
			ID int64 `json:"id"`
		} `json:"chat"`
		Text  string `json:"text"`
		Photo []struct {
			FileID string `json:"file_id"`
		} `json:"photo"`
		Document *struct {
			FileID   string `json:"file_id"`
			MimeType string `json:"mime_type"`
		} `json:"document"`
		SuccessfulPayment *struct {
			Currency    string `json:"currency"`
			TotalAmount int    `json:"total_amount"`
			Payload     string `json:"invoice_payload"`
			ChargeID    string `json:"telegram_payment_charge_id"`
		} `json:"successful_payment"`
	} `json:"message"`
	Callback *struct {
		ID   string `json:"id"`
		From struct {
			ID        int64  `json:"id"`
			FirstName string `json:"first_name"`
		} `json:"from"`
		Data    string `json:"data"`
		Message *struct {
			Chat struct {
				ID int64 `json:"id"`
			} `json:"chat"`
		} `json:"message"`
	} `json:"callback_query"`
	PreCheckout *struct {
		ID       string `json:"id"`
		Currency string `json:"currency"`
		Total    int    `json:"total_amount"`
		Payload  string `json:"invoice_payload"`
	} `json:"pre_checkout_query"`
}

// Run polls the Bot API until ctx ends.
func (b *Bot) Run(ctx context.Context) {
	for ctx.Err() == nil {
		var ups []update
		err := b.call(ctx, "getUpdates", map[string]any{"offset": b.offset, "timeout": 50, "allowed_updates": []string{"message", "pre_checkout_query", "callback_query"}}, &ups)
		if err != nil {
			if ctx.Err() == nil {
				log.Printf("%v", err)
				select {
				case <-ctx.Done():
				case <-time.After(10 * time.Second):
				}
			}
			continue
		}
		for _, u := range ups {
			b.offset = u.UpdateID + 1
			b.handle(ctx, u)
		}
	}
}

func days(n int) string {
	w := "дней"
	switch m10, m100 := n%10, n%100; {
	case m10 == 1 && m100 != 11:
		w = "день"
	case m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14):
		w = "дня"
	}
	return fmt.Sprintf("%d %s", n, w)
}

// repeat says whether this is the same request from the same person again within a few seconds (a double tap, impatience):
// such a repeat is ignored, so ten taps cost the server one answer.
func (b *Bot) repeat(user int64, text string) bool {
	now := b.now()
	b.mu.Lock()
	defer b.mu.Unlock()
	if b.last == nil {
		b.last = map[int64]lastReq{}
	}
	p, ok := b.last[user]
	if len(b.last) > 5000 { // forget old taps so the map cannot grow forever
		for k, v := range b.last {
			if now.Sub(v.at) > time.Minute {
				delete(b.last, k)
			}
		}
	}
	b.last[user] = lastReq{text, now}
	return ok && p.text == text && now.Sub(p.at) < 8*time.Second
}

type lastReq struct {
	text string
	at   time.Time
}

func (b *Bot) sendMenu(ctx context.Context, chat int64, text string) {
	if err := b.call(ctx, "sendMessage", map[string]any{"chat_id": chat, "text": text, "reply_markup": b.menu()}, nil); err != nil {
		log.Printf("%v", err)
	}
}

func (b *Bot) send(ctx context.Context, chat int64, text string) {
	if err := b.call(ctx, "sendMessage", map[string]any{"chat_id": chat, "text": text}, nil); err != nil {
		log.Printf("%v", err)
	}
}

// receipt takes a screenshot of a transfer for the person's open QR request and passes it to the owner.
func (b *Bot) receipt(ctx context.Context, u update) {
	m := u.Message
	r, ok := b.Store.Waiting(m.From.ID)
	if !ok || b.OnReceipt == nil {
		b.sendMenu(ctx, m.Chat.ID, "Чтобы оплатить по QR, нажми «Пополнить» и выбери «Оплатить по QR».")
		return
	}
	id := ""
	if len(m.Photo) > 0 {
		id = m.Photo[len(m.Photo)-1].FileID // the largest size
	} else if m.Document != nil && strings.HasPrefix(m.Document.MimeType, "image/") {
		id = m.Document.FileID
	}
	if id == "" {
		b.send(ctx, m.Chat.ID, "Пришли чек картинкой (скрин или фото).")
		return
	}
	img, err := b.download(ctx, id)
	if err != nil {
		log.Printf("billing bot: receipt: %v", err)
		b.send(ctx, m.Chat.ID, "Не получилось принять чек, пришли ещё раз.")
		return
	}
	if r, err = b.Store.Mark(r.ID, "sent", b.now()); err != nil {
		log.Printf("%v", err)
		return
	}
	b.OnReceipt(r, img)
	b.sendMenu(ctx, m.Chat.ID, fmt.Sprintf("Чек по заявке %s получен. Проверим перевод и начислим токены, я напишу.", r.Code))
}

// Tell sends a plain message to a person through the pay bot (used by the admin bot after a decision).
func (b *Bot) Tell(ctx context.Context, user int64, text string) { b.sendMenu(ctx, user, text) }

// download fetches a file people sent to the bot (at most 10 MB).
func (b *Bot) download(ctx context.Context, fileID string) ([]byte, error) {
	var f struct {
		Path string `json:"file_path"`
		Size int    `json:"file_size"`
	}
	if err := b.call(ctx, "getFile", map[string]any{"file_id": fileID}, &f); err != nil {
		return nil, err
	}
	if f.Size > 10<<20 || f.Path == "" {
		return nil, fmt.Errorf("billing bot: file too big or missing")
	}
	base := b.BaseURL
	if base == "" {
		base = "https://api.telegram.org"
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, base+"/file/bot"+b.tok()+"/"+f.Path, nil)
	if err != nil {
		return nil, err
	}
	hc := b.HTTP
	if hc == nil {
		hc = &http.Client{Timeout: 70 * time.Second}
	}
	resp, err := hc.Do(req)
	if err != nil {
		return nil, fmt.Errorf("billing bot: download failed") // the URL holds the token
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("billing bot: download: %s", resp.Status)
	}
	return io.ReadAll(io.LimitReader(resp.Body, 10<<20))
}

var curSign = map[string]string{"RUB": "₽", "KZT": "₸", "UZS": "сум", "USD": "$", "EUR": "€", "TJS": "сомони", "TRY": "₺", "CNY": "¥", "GBP": "£", "UAH": "₴", "AZN": "₼", "GEL": "₾", "AMD": "֏", "KRW": "₩"}

// approx shows a som price in the other currencies the owner set: "≈ 371 ₽ · ≈ 2 223 ₸ · ≈ $4.45".
func (b *Bot) approx(som int) string {
	if b.Rates == nil || som <= 0 {
		return ""
	}
	var parts []string
	for _, kv := range strings.Split(b.Rates(), ",") {
		code, val, ok := strings.Cut(strings.TrimSpace(kv), "=")
		rate, err := strconv.ParseFloat(strings.TrimSpace(val), 64)
		code = strings.ToUpper(strings.TrimSpace(code))
		if !ok || err != nil || rate <= 0 || code == "" || code == b.code() {
			continue
		}
		sign := curSign[code]
		if sign == "" {
			sign = code
		}
		num := money(float64(som) * rate)
		switch sign {
		case "$", "€", "£", "¥":
			parts = append(parts, "≈ "+sign+num)
		default:
			parts = append(parts, "≈ "+num+" "+sign)
		}
	}
	return strings.Join(parts, " · ")
}

// money prints a sum readably: up to two decimals below 100, whole numbers with thin spaces above.
func money(v float64) string {
	if v < 100 {
		return strings.TrimRight(strings.TrimRight(strconv.FormatFloat(v, 'f', 2, 64), "0"), ".")
	}
	n := strconv.FormatInt(int64(v+.5), 10)
	var out []byte
	for i := range n {
		if i > 0 && (len(n)-i)%3 == 0 {
			out = append(out, " "...)
		}
		out = append(out, n[i])
	}
	return string(out)
}

func (b *Bot) ratesNote(list string) string {
	if list == "" {
		return ""
	}
	return "\n" + list + "\n\nКурс примерный. Платёж в " + b.code() + ": если у тебя карта в другой валюте, банк переведёт сам."
}
func (b *Bot) code() string {
	if b != nil && b.Currency != nil {
		if c := strings.ToUpper(strings.TrimSpace(b.Currency())); c != "" {
			return c
		}
	}
	return "RUB"
}

// Price writes an amount in the main currency: "399 ₽", "$5", "390 сом".
func (b *Bot) Price(n int) string {
	c := b.code()
	switch sign := curSign[c]; {
	case c == "KGS":
		return fmt.Sprintf("%d сом", n)
	case sign == "$" || sign == "€" || sign == "£" || sign == "¥":
		return fmt.Sprintf("%s%d", sign, n)
	case sign != "":
		return fmt.Sprintf("%d %s", n, sign)
	}
	return fmt.Sprintf("%d %s", n, c)
}
