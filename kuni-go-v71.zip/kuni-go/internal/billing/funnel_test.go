package billing

import (
	"net/http/httptest"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"kuni/internal/metrics"
)

func TestFunnelCountsTheRealAccounts(t *testing.T) {
	loc := time.UTC
	now := time.Date(2026, 10, 31, 15, 0, 0, 0, loc)
	s := Open(filepath.Join(t.TempDir(), "b.json"))
	lim := Limits{Free: 30, Plus: 300, Max: 2000}

	add := func(id int64, u User) { u.ID = id; s.d.Users[id] = &u }
	today := "2026-10-31"
	add(1, User{Plan: Free, Joined: now.Add(-2 * time.Hour)})                                // new today, never talked
	add(2, User{Plan: Free, Joined: now.Add(-3 * time.Hour), Day: today, Used: 5, Total: 5}) // new today, talks
	add(3, User{Plan: Free, Joined: now.AddDate(0, 0, -3), Day: today, Used: 30, Total: 90}) // came back, hit the limit
	add(4, User{Plan: Plus, Until: now.AddDate(0, 0, 5), Joined: now.AddDate(0, 0, -20), Day: today, Used: 40, Total: 400, Paid: 1})
	add(5, User{Plan: Max, Until: now.Add(-time.Hour), Joined: now.AddDate(0, 0, -30), Total: 10, Paid: 1}) // plan ran out
	add(6, User{Plan: Free, Joined: now.AddDate(0, 0, -1), Referrer: 4, Day: "2026-10-30", Used: 9, Total: 9})
	s.d.Payments = []Payment{{UserID: 4, Plan: Plus, Stars: 500, Charge: "a"}, {UserID: 5, Plan: Max, Stars: 1500, Charge: "b"}}

	f := s.Funnel(now, loc, lim)
	want := Funnel{Users: 6, New1d: 2, New7d: 4, Activated: 5, ActiveToday: 3, Returned: 2, AtLimitToday: 1, PayingNow: 1, Referred: 1, Payments: 2, Stars: 2000, PayingEverEver: 2}
	if f != want {
		t.Fatalf("funnel\n got %+v\nwant %+v", f, want)
	}

	reg := metrics.New()
	f.Publish(reg)
	rec := httptest.NewRecorder()
	reg.Handler().ServeHTTP(rec, httptest.NewRequest("GET", "/metrics", nil))
	out := rec.Body.String()
	for _, line := range []string{"kuni_funnel_users 6", "kuni_funnel_stars 2000", "kuni_funnel_at_limit_today 1", "kuni_funnel_paying_now 1", "# TYPE kuni_funnel_users gauge"} {
		if !strings.Contains(out, line) {
			t.Fatalf("metrics output lacks %q:\n%s", line, out)
		}
	}
	f.Publish(nil) // a missing registry is fine
}

func TestFunnelRespectsTheBotsMidnight(t *testing.T) {
	loc := time.FixedZone("bishkek", 6*3600)
	now := time.Date(2026, 11, 1, 0, 30, 0, 0, loc) // half past midnight there, still Oct 31 in UTC
	s := Open(filepath.Join(t.TempDir(), "b.json"))
	s.d.Users[1] = &User{ID: 1, Joined: now.Add(-time.Hour)} // joined 23:30 on the 31st local: not "new today"
	s.d.Users[2] = &User{ID: 2, Joined: now.Add(-10 * time.Minute)}
	f := s.Funnel(now, loc, Limits{Free: 30})
	if f.New1d != 1 || f.New7d != 2 {
		t.Fatalf("day boundary: %+v", f)
	}
}
