package billing

import (
	"path/filepath"
	"testing"
	"time"
)

func TestAccountReadsPlanLimitAndPayment(t *testing.T) {
	s := Open(filepath.Join(t.TempDir(), "b.json"))
	now := time.Date(2026, 11, 1, 12, 0, 0, 0, time.UTC)
	l := Limits{Free: 30, Plus: 300, Max: 2000}

	if a := s.Account(7, now, l, 40000); a.Plan != Free || a.Limit != 30 || a.Left != 30 || a.Used != 0 {
		t.Fatalf("new person: %+v", a)
	}
	for i := 0; i < 3; i++ {
		s.Take(7, now.Add(time.Duration(i)*time.Minute), l)
	}
	if a := s.Account(7, now.Add(5*time.Minute), l, 40000); a.Used != 3 || a.Left != 27 {
		t.Fatalf("after 3: %+v", a)
	}
	// reading counts nothing
	if a := s.Account(7, now.Add(5*time.Minute), l, 40000); a.Used != 3 {
		t.Fatalf("Account must not count: %+v", a)
	}
	// next day the counter is fresh
	if a := s.Account(7, now.Add(24*time.Hour), l, 40000); a.Used != 0 || a.Left != 30 {
		t.Fatalf("next day: %+v", a)
	}
	s.NewRequest(7, "Ann", 500000, 399, now)
	if a := s.Account(7, now, l, 40000); a.Pending == nil || a.Pending.Tokens != 500000 || a.Pending.Status != "waiting" {
		t.Fatalf("pending: %+v", a)
	}
	if _, err := s.Activate(7, Plus, 7, 80, "ch1", now); err != nil {
		t.Fatal(err)
	}
	a := s.Account(7, now.Add(time.Hour), l, 40000)
	if a.Plan != Plus || a.Limit != 300 || a.Paid != 1 || !a.Until.Equal(now.Add(7*24*time.Hour)) {
		t.Fatalf("plus: %+v", a)
	}
	if a := s.Account(7, now.Add(8*24*time.Hour), l, 40000); a.Plan != Free || a.Expired != Plus || !a.Until.IsZero() {
		t.Fatalf("expired: %+v", a)
	}
	s.Refer(9, 7)
	if a := s.Account(7, now, l, 40000); a.Invited != 1 {
		t.Fatalf("invited: %+v", a)
	}
}
