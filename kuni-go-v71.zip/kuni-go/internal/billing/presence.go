package billing

import (
	"fmt"
	"strings"
	"time"
)

// Presence is what Reina is like right now, as the pay bot shows it: the program fills it from her real state (the account's online
// status, sleep, body, mood, where she is). The zero value means "unknown" and is shown as offline.
type Presence struct {
	Known    bool
	Online   bool      // the account is "в сети" right now (she is answering someone)
	LastSeen time.Time // when she was last online (zero = unknown)
	Asleep   bool
	WakeAt   time.Time // when she plans to wake up (zero = unknown)
	Night    bool      // her night: she is drowsy even when awake
	Outside  bool
	Doing    string  // what she is doing, in Russian ("дома", "гуляет", "работает"...); "" = not known
	Mood     int     // 0..100, -1 = not known
	Energy   float64 // 0..1 (1 = fresh), -1 = not known
}

// State is one word for her status, used for the dot and the headline: online, asleep, away.
func (p Presence) State() string {
	switch {
	case p.Online:
		return "online"
	case p.Asleep:
		return "asleep"
	}
	return "away"
}

// Headline is the status as people read it: "в сети", "спит до 08:30", "была в сети 12 минут назад".
func (p Presence) Headline(now time.Time, loc *time.Location) string {
	switch {
	case !p.Known:
		return "не в сети"
	case p.Online:
		return "в сети"
	case p.Asleep && !p.WakeAt.IsZero():
		return "спит до " + p.WakeAt.In(loc).Format("15:04")
	case p.Asleep:
		return "спит"
	case !p.LastSeen.IsZero():
		return "была в сети " + ago(now.Sub(p.LastSeen))
	}
	return "не в сети"
}

// MoodWord turns the 0..100 mood into a word.
func (p Presence) MoodWord() string {
	switch m := p.Mood; {
	case m < 0:
		return ""
	case m < 25:
		return "не в духе"
	case m < 45:
		return "задумчивая"
	case m < 65:
		return "спокойная"
	case m < 85:
		return "в хорошем настроении"
	default:
		return "сияет"
	}
}

// EnergyWord turns 0..1 energy into a word.
func (p Presence) EnergyWord() string {
	switch e := p.Energy; {
	case e < 0:
		return ""
	case e < .25:
		return "очень устала"
	case e < .5:
		return "устала"
	case e < .75:
		return "бодрая"
	default:
		return "полна сил"
	}
}

// Text is the full status as a message (the picture's fallback).
func (p Presence) Text(now time.Time, loc *time.Location) string {
	var b strings.Builder
	dot := map[string]string{"online": "🟢", "asleep": "🌙", "away": "⚪"}[p.State()]
	fmt.Fprintf(&b, "%s Рейна %s", dot, p.Headline(now, loc))
	if !p.Known {
		return b.String()
	}
	if p.Doing != "" {
		fmt.Fprintf(&b, "\nСейчас: %s", p.Doing)
	}
	if w := p.MoodWord(); w != "" {
		fmt.Fprintf(&b, "\nНастроение: %s", w)
	}
	if w := p.EnergyWord(); w != "" {
		fmt.Fprintf(&b, "\nСилы: %s (%d%%)", w, int(p.Energy*100+.5))
	}
	if p.Night && !p.Asleep {
		b.WriteString("\nУ неё ночь: ответы будут сонными и короткими.")
	}
	if p.Asleep {
		b.WriteString("\nНаписать можно: сообщение её разбудит, но ответ будет сонным.")
	}
	return b.String()
}

func ago(d time.Duration) string {
	switch {
	case d < time.Minute:
		return "только что"
	case d < time.Hour:
		return plural(int(d.Minutes()), "минуту", "минуты", "минут") + " назад"
	case d < 24*time.Hour:
		return plural(int(d.Hours()), "час", "часа", "часов") + " назад"
	}
	return plural(int(d.Hours()/24), "день", "дня", "дней") + " назад"
}

func plural(n int, one, few, many string) string {
	w := many
	switch m10, m100 := n%10, n%100; {
	case m10 == 1 && m100 != 11:
		w = one
	case m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14):
		w = few
	}
	return fmt.Sprintf("%d %s", n, w)
}

// Num writes a token count readably: 1 250 000.
func Num(n int64) string {
	neg := n < 0
	if neg {
		n = -n
	}
	s := fmt.Sprint(n)
	var out []byte
	for i := range s {
		if i > 0 && (len(s)-i)%3 == 0 {
			out = append(out, " "...)
		}
		out = append(out, s[i])
	}
	if neg {
		return "−" + string(out)
	}
	return string(out)
}

// Short writes a token count compactly: 500 тыс., 2 млн, 1,5 млн.
func Short(n int64) string {
	switch {
	case n >= 1_000_000:
		v := float64(n) / 1e6
		if v == float64(int64(v)) {
			return fmt.Sprintf("%d млн", int64(v))
		}
		return strings.Replace(fmt.Sprintf("%.1f млн", v), ".", ",", 1)
	case n >= 1000:
		return fmt.Sprintf("%d тыс.", n/1000)
	}
	return fmt.Sprint(n)
}
