package billing

import (
	"context"
	"fmt"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestBalancePaysBeyondTheFreeConversations(t *testing.T) {
	s := Open(filepath.Join(t.TempDir(), "b.json"))
	for i := 0; i < 2; i++ {
		if d := s.Take(7, t0.Add(time.Duration(i)*time.Minute), lim); !d.OK || d.FromBalance {
			t.Fatalf("free first: %+v", d)
		}
		s.Spend(7, 30000, t0.Add(time.Duration(i)*time.Minute))
	}
	if u := s.Get(7, t0); u.Tokens != 0 || u.AllTokens != 60000 || u.DayTokens != 60000 {
		t.Fatalf("free conversations cost the balance nothing but are counted: %+v", u)
	}
	if d := s.Take(7, t0.Add(3*time.Minute), lim); d.OK {
		t.Fatal("no free ones and no balance: no answer")
	}
	_, _ = s.AddTokens(7, 50000, 2, 0, "c", "pack", t0)
	d := s.Take(7, t0.Add(4*time.Minute), lim)
	if !d.OK || !d.FromBalance || d.Balance != 50000 {
		t.Fatalf("paid from the balance: %+v", d)
	}
	s.Spend(7, 35000, t0.Add(4*time.Minute))
	s.Spend(7, 20000, t0.Add(4*time.Minute)) // a second request in the same conversation
	u := s.Get(7, t0)
	if u.Tokens != -5000 || u.Spent != 55000 || u.PaidToday != 1 {
		t.Fatalf("the real cost is taken, a conversation may end a little below zero: %+v", u)
	}
	if d := s.Take(7, t0.Add(10*time.Minute), lim); d.OK {
		t.Fatal("below zero: no more paid conversations")
	}
	if d := s.Take(7, t0.Add(24*time.Hour), lim); !d.OK || d.FromBalance {
		t.Fatalf("the next day the free ones come back: %+v", d)
	}
	if n := s.PerConv(40000); n != 40000 {
		t.Fatalf("too few conversations for a real average: %d", n)
	}
}

func TestFreeTokenCapStopsVeryLongFreeChats(t *testing.T) {
	s := Open(filepath.Join(t.TempDir(), "b.json"))
	l := Limits{Free: 30, FreeTokens: 100000}
	s.Take(7, t0, l)
	s.Spend(7, 120000, t0)
	if d := s.Take(7, t0.Add(time.Minute), l); d.OK {
		t.Fatal("the free token cap is over")
	}
}

func TestPricesCoverTheCost(t *testing.T) {
	stars, price := PackPrice(500000, 0.20, 2.5, 0.013, 0.01262)
	// 0.5M tokens * $0.20 = $0.10; *2.5 = $0.25 -> 19.2 stars -> 20; 0.25/0.01262 = 19.8 -> 20 rubles
	if stars != 20 || price != 20 {
		t.Fatalf("stars %d, price %d", stars, price)
	}
	for _, n := range []int64{100000, 2000000, 6000000} {
		st, _ := PackPrice(n, 0.20, 2.5, 0.013, 0)
		if got := float64(st) * 0.013; got < float64(n)/1e6*0.20*2.5 {
			t.Fatalf("%d tokens: %d stars bring $%.3f, less than the cost with margin", n, st, got)
		}
	}
	if s, p := PackPrice(0, .2, 2, .013, 1); s != 0 || p != 0 {
		t.Fatal("nothing for nothing")
	}
	if c := Credits(10000, 1000, 0.20, 0.70, 0.20); c != 13500 {
		t.Fatalf("output tokens at their own price: %d", c)
	}
	if c := Credits(10000, 0, 0.05, 0.10, 0.20); c != 2500 {
		t.Fatalf("a cheaper model takes less: %d", c)
	}
}

func TestGiftLinkWorksOnceForSomeoneElse(t *testing.T) {
	srv, calls := fakeAPI(t)
	st := Open(filepath.Join(t.TempDir(), "b.json"))
	b := newBot(srv, st)
	ctx := context.Background()
	b.handle(ctx, msg(t, `{"update_id":1,"message":{"from":{"id":7},"chat":{"id":7},"text":"🎁 Подарить"}}`))
	if l := calls("createInvoiceLink"); len(l) != 2 || l[0]["payload"] != "gift:500000" {
		t.Fatalf("gift invoices: %+v", l)
	}
	b.handle(ctx, msg(t, `{"update_id":2,"pre_checkout_query":{"id":"q","currency":"XTR","total_amount":20,"invoice_payload":"gift:500000"}}`))
	if a := calls("answerPreCheckoutQuery"); a[0]["ok"] != true {
		t.Fatal("a gift at the pack's price passes")
	}
	b.handle(ctx, msg(t, `{"update_id":3,"message":{"from":{"id":7},"chat":{"id":7},"successful_payment":{"currency":"XTR","total_amount":20,"invoice_payload":"gift:500000","telegram_payment_charge_id":"g1"}}}`))
	if st.Get(7, t0).Tokens != 0 {
		t.Fatal("a gift does not go to the buyer's balance")
	}
	gs := st.GiftsFrom(7)
	if len(gs) != 1 || !strings.Contains(fmt.Sprint(calls("sendMessage")), "https://t.me/OrviPayBot?start=g"+gs[0].Code) {
		t.Fatalf("the buyer gets the link: %+v", gs)
	}
	b.handle(ctx, msg(t, `{"update_id":4,"message":{"from":{"id":7},"chat":{"id":7},"text":"/start g`+gs[0].Code+`"}}`))
	if st.Get(7, t0).Tokens != 0 {
		t.Fatal("you cannot open your own gift")
	}
	b.handle(ctx, msg(t, `{"update_id":5,"message":{"from":{"id":9},"chat":{"id":9},"text":"/start g`+gs[0].Code+`"}}`))
	if st.Get(9, t0).Tokens != 500000 {
		t.Fatal("the friend gets the tokens")
	}
	b.Now = func() time.Time { return t0.Add(time.Minute) }
	b.handle(ctx, msg(t, `{"update_id":6,"message":{"from":{"id":10},"chat":{"id":10},"text":"`+gs[0].Code+`"}}`))
	if st.Get(10, t0).Tokens != 0 {
		t.Fatal("a gift works once")
	}
	if h := b.history(9); !strings.Contains(h, "подарок тебе") || !strings.Contains(h, "+500 тыс. токенов") {
		t.Fatalf("history of the friend: %s", h)
	}
	if h := b.history(7); !strings.Contains(h, "подарок другу") || !strings.Contains(h, "открыт") {
		t.Fatalf("history of the buyer: %s", h)
	}
}

func TestStatusCardAndOnlineWatch(t *testing.T) {
	srv, calls := fakeAPI(t)
	st := Open(filepath.Join(t.TempDir(), "b.json"))
	b := newBot(srv, st)
	b.Her = func() string { return "@ReinaVeil" }
	p := Presence{Known: true, LastSeen: t0.Add(-12 * time.Minute), Doing: "гуляет", Mood: 80, Energy: .6}
	b.Presence = func() Presence { return p }
	var svg string
	b.Render = func(ctx context.Context, s string) ([]byte, error) { svg = s; return []byte("png"), nil }
	ctx := context.Background()
	b.handle(ctx, msg(t, `{"update_id":1,"message":{"from":{"id":7},"chat":{"id":7},"text":"🌙 Рейна"}}`))
	waitCalls(t, calls, "sendPhoto", 1)
	for _, w := range []string{"была в сети 12 минут назад", "гуляет", "в хорошем настроении", "бодрая", "<g transform"} {
		if !strings.Contains(svg, w) {
			t.Fatalf("status card misses %q", w)
		}
	}
	b.handle(ctx, msg(t, `{"update_id":2,"callback_query":{"id":"c","from":{"id":7},"data":"watch:on","message":{"chat":{"id":7}}}}`))
	if !st.Get(7, t0).Watch {
		t.Fatal("subscribed")
	}
	p.Online = true
	if ids := st.TakeWatchers(); len(ids) != 1 || ids[0] != 7 {
		t.Fatalf("watchers: %v", ids)
	}
	if st.Get(7, t0).Watch {
		t.Fatal("told once, then forgotten")
	}
	b.Now = func() time.Time { return t0.Add(time.Minute) }
	b.handle(ctx, msg(t, `{"update_id":3,"callback_query":{"id":"d","from":{"id":8},"data":"watch:on","message":{"chat":{"id":8}}}}`))
	if st.Get(8, t0).Watch || !strings.Contains(fmt.Sprint(calls("sendMessage")), "уже в сети") {
		t.Fatal("when she is online already, say so instead of subscribing")
	}
	if txt := (Presence{Known: true, Asleep: true, WakeAt: t0.Add(2 * time.Hour), Night: true}).Text(t0, time.UTC); !strings.Contains(txt, "спит до 14:00") || !strings.Contains(txt, "сонным") {
		t.Fatalf("asleep text: %s", txt)
	}
	if (Presence{}).Headline(t0, time.UTC) != "не в сети" {
		t.Fatal("unknown = not online")
	}
}

func TestHelpAnswersFromRealNumbers(t *testing.T) {
	srv, calls := fakeAPI(t)
	b := newBot(srv, Open(filepath.Join(t.TempDir(), "b.json")))
	ctx := context.Background()
	b.handle(ctx, msg(t, `{"update_id":1,"message":{"from":{"id":7},"chat":{"id":7},"text":"💬 Помощь"}}`))
	if kb := fmt.Sprint(calls("sendMessage")[0]["reply_markup"]); !strings.Contains(kb, "faq:0") || !strings.Contains(kb, "Токены сгорают?") {
		t.Fatalf("questions as buttons: %s", kb)
	}
	b.handle(ctx, msg(t, `{"update_id":2,"callback_query":{"id":"c","from":{"id":7},"data":"faq:1","message":{"chat":{"id":7}}}}`))
	sent := calls("sendMessage")
	if last := sent[len(sent)-1]["text"].(string); !strings.Contains(last, "2 разговора в день") {
		t.Fatalf("the answer uses the real free limit: %s", last)
	}
}

func TestNumbersInWords(t *testing.T) {
	for n, w := range map[int64]string{1250000: "1 250 000", 999: "999", -5000: "−5 000"} {
		if Num(n) != w {
			t.Fatalf("%d: %q", n, Num(n))
		}
	}
	for n, w := range map[int64]string{500000: "500 тыс.", 2000000: "2 млн", 1500000: "1,5 млн"} {
		if Short(n) != w {
			t.Fatalf("%d: %q", n, Short(n))
		}
	}
	if tokensWord(1) != "1 токен" || tokensWord(3) != "3 токена" || tokensWord(11) != "11 токенов" {
		t.Fatal("token plurals")
	}
}
