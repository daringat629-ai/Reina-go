package mind

import (
	"bufio"
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"io"
	"os"
	"strings"
	"time"
)

// The corpus is every chat answer the teacher has given, in order, kept for good (the memory of episodes forgets; this does not).
// It is the material for the real way out of the API: fine-tuning a model of her own on her own conversations.

type corpusLine struct {
	T     int64  `json:"t"`
	In    string `json:"in"`
	Out   string `json:"out"`
	Owner bool   `json:"owner"`
}

func (m *Mind) appendCorpus(in, out string, owner bool) {
	if m.path == "" {
		return
	}
	f, err := os.OpenFile(m.path+".corpus.jsonl", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o600)
	if err != nil {
		return
	}
	defer f.Close()
	b, _ := json.Marshal(corpusLine{time.Now().Unix(), in, out, owner})
	if g := m.corpusGCM(); g != nil {
		n := make([]byte, g.NonceSize())
		if _, err := rand.Read(n); err == nil {
			b = []byte(encPrefix + base64.StdEncoding.EncodeToString(g.Seal(n, n, b, nil)))
		}
	}
	_, _ = f.Write(append(b, '\n'))
}

const encPrefix = "enc1:"

// corpusGCM returns the cipher that seals corpus lines, or nil if no key can be had (then lines stay plain, as before).
// The key is KUNI_CORPUS_KEY (64 hex chars) if set, else a random 32-byte file next to the corpus, created on first use.
// A key file beside the data does not stop someone who takes the whole folder; set the variable to keep the key elsewhere.
func (m *Mind) corpusGCM() cipher.AEAD {
	m.gcmOnce.Do(func() { m.gcm = m.buildGCM() })
	return m.gcm
}

func (m *Mind) buildGCM() cipher.AEAD {
	var key []byte
	if h := strings.TrimSpace(os.Getenv("KUNI_CORPUS_KEY")); h != "" {
		key, _ = hex.DecodeString(h)
	} else if m.path != "" {
		kp := m.path + ".corpus.key"
		key, _ = os.ReadFile(kp)
		if len(key) != 32 {
			key = make([]byte, 32)
			if _, err := rand.Read(key); err != nil || os.WriteFile(kp, key, 0o600) != nil {
				return nil
			}
		}
	}
	if len(key) != 32 {
		return nil
	}
	blk, err := aes.NewCipher(key)
	if err != nil {
		return nil
	}
	g, err := cipher.NewGCM(blk)
	if err != nil {
		return nil
	}
	return g
}

// openLine reads one corpus line, plain or sealed.
func openLine(g cipher.AEAD, raw []byte) (corpusLine, bool) {
	var l corpusLine
	if s := string(raw); strings.HasPrefix(s, encPrefix) {
		if g == nil {
			return l, false
		}
		c, err := base64.StdEncoding.DecodeString(s[len(encPrefix):])
		if err != nil || len(c) < g.NonceSize() {
			return l, false
		}
		p, err := g.Open(nil, c[:g.NonceSize()], c[g.NonceSize():], nil)
		if err != nil {
			return l, false
		}
		raw = p
	}
	return l, json.Unmarshal(raw, &l) == nil
}

// Export writes the corpus as JSONL in the chat fine-tuning format ({"messages":[system,user,assistant]}), one line per answer.
// system is the character prompt (may be empty); ownerOnly keeps only the talks with the owner. It returns how many lines it wrote.
func (m *Mind) Export(w io.Writer, system string, ownerOnly bool) int {
	m.mu.Lock()
	path := m.path
	m.mu.Unlock()
	if path == "" {
		return 0
	}
	f, err := os.Open(path + ".corpus.jsonl")
	if err != nil {
		return 0
	}
	defer f.Close()
	sc := bufio.NewScanner(f)
	sc.Buffer(make([]byte, 1<<20), 1<<20)
	n := 0
	g := m.corpusGCM()
	for sc.Scan() {
		l, ok := openLine(g, sc.Bytes())
		if !ok || l.In == "" || l.Out == "" || (ownerOnly && !l.Owner) {
			continue
		}
		msgs := []map[string]string{}
		if system != "" {
			msgs = append(msgs, map[string]string{"role": "system", "content": system})
		}
		msgs = append(msgs, map[string]string{"role": "user", "content": l.In}, map[string]string{"role": "assistant", "content": l.Out})
		b, _ := json.Marshal(map[string]any{"messages": msgs})
		_, _ = w.Write(append(b, '\n'))
		n++
	}
	return n
}

// Demote is the owner's verdict "this answer is bad": the habit that gave it loses its right to answer alone and must pass its
// exams again, and the answer is never said alone again. in is the situation text; it returns whether a habit was found.
func (m *Mind) Demote(in string) bool {
	m.mu.Lock()
	defer m.mu.Unlock()
	v := vec(in)
	var best *episode
	bs := 0.0
	for _, e := range m.eps {
		if e.Tool {
			continue
		}
		if s := cos(v, e.vec); s > bs {
			bs, best = s, e
		}
	}
	if best == nil || bs < .5 {
		return false
	}
	if c := m.cl[best.Cl]; c != nil {
		c.Grad, c.Hit, c.N = false, .2, 0
	}
	m.banned = append(m.banned, best.Out)
	if len(m.banned) > 200 {
		m.banned = m.banned[1:]
	}
	return true
}
