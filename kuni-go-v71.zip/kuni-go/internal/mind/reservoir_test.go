package mind

import (
	"math/rand"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestReservoirLearnsToAnswerFromWordsAlone(t *testing.T) {
	r := newReservoir(1)
	talks := [][2]string{{"привет", "привет, как ты~"}, {"как дела", "нормально, а у тебя~"}, {"спокойной ночи", "спокойной ночи, сладких снов~"}}
	start := time.Now()
	for i := 0; i < 60; i++ {
		for _, x := range talks {
			r.train(x[0], x[1])
		}
	}
	t.Logf("540 words in %v, acc %.2f loss %.2f", time.Since(start), r.acc, r.loss)
	if r.acc < .6 {
		t.Fatalf("next-word accuracy %.2f", r.acc)
	}
	rng := rand.New(rand.NewSource(1))
	got := r.generate("привет", rng, 4)
	if len(got) == 0 {
		t.Fatal("silent")
	}
	ok := false
	for _, g := range got {
		for _, w := range toks(g) {
			if _, known := r.voc[w]; !known {
				t.Fatalf("invented %q", w)
			}
		}
		if strings.HasPrefix(g, "привет") {
			ok = true
		}
	}
	if !ok {
		t.Fatalf("answered %v to привет", got)
	}
	// the same situation read after "спокойной ночи" gives a different answer: the state really remembers the words
	night := r.generate("спокойной ночи", rng, 4)
	if len(night) == 0 || strings.HasPrefix(night[0], "привет") {
		t.Fatalf("night: %v", night)
	}
}

func TestReservoirSavesAndLoads(t *testing.T) {
	p := filepath.Join(t.TempDir(), "r.gz")
	r := newReservoir(1)
	for i := 0; i < 30; i++ {
		r.train("привет", "привет~")
	}
	if err := r.save(p); err != nil {
		t.Fatal(err)
	}
	q := newReservoir(1)
	q.load(p)
	if q.steps != r.steps || len(q.words) != len(r.words) || q.w[5] != r.w[5] {
		t.Fatal("not restored")
	}
}

func TestMindDreamsTrainTheReservoir(t *testing.T) {
	m := New(filepath.Join(t.TempDir(), "m.json"), 1)
	cc := Config{AnswerAlone: true, WithOwner: true, MinTrials: 8, HitRate: .8, Compose: true, Reservoir: true}
	for i := 0; i < 30; i++ {
		m.Observe(Situation{Text: "привет"}, "привет, как ты~", false, cc)
	}
	for i := 0; i < 20; i++ {
		m.Dream(20, cc)
	}
	s := m.Stats()
	if s.ResSteps == 0 || s.ResWords < 4 {
		t.Fatalf("%+v", s)
	}
	m.Close()
	n := New(filepath.Join(filepath.Dir(m.path), "m.json"), 1)
	n.reservoirFor(cc)
	if n.Stats().ResSteps != s.ResSteps {
		t.Fatalf("reservoir not persisted: %d vs %d", n.Stats().ResSteps, s.ResSteps)
	}
}
