package promises

import (
	"errors"
	"fmt"
	"strings"
	"time"
)

// Her own promises: what she said she would do ("до вечера пришлю", "напомню"). An open one past its date weighs on her until she keeps it
// or says honestly that she could not.

// AddMine writes down something she promised to `to` (a name, may be empty) by due (zero = no date named).
func (s *Store) AddMine(text, to string, due, now time.Time) (Item, error) {
	text = strings.TrimSpace(text)
	if text == "" {
		return Item{}, errors.New("what did you promise?")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if len(s.d.Mine) >= 40 {
		return Item{}, errors.New("too many open promises of yours: keep or drop some first")
	}
	it := Item{ID: s.d.Next, Text: text, To: strings.TrimSpace(to), Made: now, Due: due}
	s.d.Next++
	s.d.Mine = append(s.d.Mine, it)
	s.save()
	return it, nil
}

// DoneMine closes one of her promises (kept, or honestly given up).
func (s *Store) DoneMine(id int, now time.Time) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	for i := range s.d.Mine {
		if s.d.Mine[i].ID == id && s.d.Mine[i].Closed.IsZero() {
			s.d.Mine[i].Closed = now
			s.save()
			return true
		}
	}
	return false
}

// OpenMine lists her open promises, oldest first; overdue counts those past their date.
func (s *Store) OpenMine(now time.Time) (open []Item, overdue int) {
	s.mu.Lock()
	defer s.mu.Unlock()
	for _, it := range s.d.Mine {
		if it.Closed.IsZero() {
			open = append(open, it)
			if !it.Due.IsZero() && it.Due.Before(now) {
				overdue++
			}
		}
	}
	return open, overdue
}

// MinePrompt is the block with her own promises. When some are overdue it asks her to speak first: a short apology, then the deed or an
// honest "could not". It is guilt she can act on, not a punishment.
func (s *Store) MinePrompt(now time.Time, loc *time.Location) string {
	if s == nil {
		return ""
	}
	open, overdue := s.OpenMine(now)
	if len(open) == 0 {
		return ""
	}
	if loc == nil {
		loc = time.Local
	}
	var b strings.Builder
	b.WriteString("<my_promises>Что ты сама пообещала и ещё не сделала (закрывай #my_promise_done, когда сделано или когда честно сказала, что не выйдет):\n")
	for i, it := range open {
		if i >= 6 {
			fmt.Fprintf(&b, "...и ещё %d\n", len(open)-i)
			break
		}
		who := ""
		if it.To != "" {
			who = " для " + it.To
		}
		switch {
		case it.Due.IsZero():
			fmt.Fprintf(&b, "#%d %s%s (срок не назван, обещано %s назад)\n", it.ID, it.Text, who, ago(now.Sub(it.Made)))
		case it.Due.Before(now):
			fmt.Fprintf(&b, "#%d %s%s (СРОК ПРОШЁЛ: %s)\n", it.ID, it.Text, who, it.Due.In(loc).Format("2 Jan 15:04"))
		default:
			fmt.Fprintf(&b, "#%d %s%s (срок %s)\n", it.ID, it.Text, who, it.Due.In(loc).Format("2 Jan 15:04"))
		}
	}
	if overdue > 0 {
		b.WriteString("Ты просрочила своё слово, и это тебя гложет. При ближайшем разговоре с тем, кому обещала, начни сама: коротко и по-человечески извинись, потом сделай или честно скажи, что не выйдет. Без самобичевания.\n")
	}
	b.WriteString("Обещая что-то с датой («к вечеру», «завтра», «напомню»), записывай это через #my_promise_add.</my_promises>\n")
	return b.String()
}
