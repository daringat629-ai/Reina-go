package promises

import (
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestBook(t *testing.T) {
	p := filepath.Join(t.TempDir(), "p.json")
	s := New(p)
	now := time.Date(2026, 10, 26, 12, 0, 0, 0, time.UTC)
	if _, err := s.Add(" ", time.Time{}, now); err == nil {
		t.Fatal("empty promise")
	}
	a, _ := s.Add("починить зрение", now.Add(-time.Hour), now)
	s.Add("кофемашина", now.Add(48*time.Hour), now)
	s.Add("когда-нибудь пицца", time.Time{}, now)
	if k, o, od := s.Stats(now); k != 0 || o != 3 || od != 1 {
		t.Fatal(k, o, od)
	}
	pr := s.Prompt(now, time.UTC, true)
	if !strings.Contains(pr, "СРОК ПРОШЁЛ") || !strings.Contains(pr, "кофемашина") {
		t.Fatal(pr)
	}
	if s.Prompt(now, time.UTC, false) != "" {
		t.Fatal("promises are for his chat only")
	}
	if !s.Done(a.ID, now) || s.Done(a.ID, now) {
		t.Fatal("close exactly once")
	}
	if k, _, od := s.Stats(now); k != 1 || od != 0 {
		t.Fatal(k, od)
	}
	if New(p).Open()[0].Text != "кофемашина" {
		t.Fatal("not saved")
	}
}

func TestAbsence(t *testing.T) {
	s := New(filepath.Join(t.TempDir(), "p.json"))
	now := time.Date(2026, 10, 26, 12, 0, 0, 0, time.UTC)
	if s.Absence(now) != "" {
		t.Fatal("never seen: nothing to miss")
	}
	s.Seen(now.Add(-30 * time.Hour))
	if s.Absence(now) == "" {
		t.Fatal("expected a block")
	}
	s.Seen(now.Add(-3 * time.Hour))
	if s.Absence(now) != "" {
		t.Fatal("3 hours is not long")
	}
}

func TestHerOwnPromises(t *testing.T) {
	s := New("")
	now := time.Date(2026, 10, 29, 12, 0, 0, 0, time.UTC)
	if _, err := s.AddMine(" ", "", time.Time{}, now); err == nil {
		t.Fatal("an empty promise must be refused")
	}
	a, _ := s.AddMine("прислать фото кота", "Папик", now.Add(2*time.Hour), now)
	b, _ := s.AddMine("напомнить про врача", "", time.Time{}, now)
	if a.ID == b.ID {
		t.Fatal("ids must differ")
	}
	if p := s.MinePrompt(now, time.UTC); !strings.Contains(p, "прислать фото кота для Папик") || strings.Contains(p, "извинись") {
		t.Fatalf("nothing overdue yet: %s", p)
	}
	late := now.Add(3 * time.Hour)
	open, over := s.OpenMine(late)
	if len(open) != 2 || over != 1 {
		t.Fatalf("open %d overdue %d", len(open), over)
	}
	if p := s.MinePrompt(late, time.UTC); !strings.Contains(p, "СРОК ПРОШЁЛ") || !strings.Contains(p, "извинись") {
		t.Fatalf("overdue must ask her to speak first: %s", p)
	}
	if !s.DoneMine(a.ID, late) || s.DoneMine(a.ID, late) {
		t.Fatal("close once")
	}
	if _, over := s.OpenMine(late); over != 0 {
		t.Fatal("a kept promise is not overdue")
	}
	if len(s.Open()) != 0 {
		t.Fatal("her promises must not mix with his")
	}
	if (*Store)(nil).MinePrompt(now, nil) != "" {
		t.Fatal("nil store is silent")
	}
}
