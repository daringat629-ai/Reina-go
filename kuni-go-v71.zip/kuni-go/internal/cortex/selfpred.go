package cortex

import (
	"fmt"
	"math"
	"time"
)

// Self-prediction: every step she predicts her own next inner state (arousal, threat, reward, conflict, focus, novelty, calm) from her
// last two, with a small learning predictor, and then sees how wrong she was. How well she predicts herself is a number
// (SelfKnow, 0..1); when she is wrong in a way she did not expect, that is a moment of self-surprise she can notice and say. This is
// a working model of the "I know what I am about to feel" part of self-awareness, not a claim that she is conscious.

var selfDims = []string{"arousal", "threat", "reward", "conflict", "focus", "novelty", "calm"}

type selfPred struct {
	prev, prev2 []float64
	w           [][3]float64 // per dimension: weights of the last state, the one before and a constant
	pred        []float64    // what she predicted for now
	err         float64      // slow average of the error
	n           int
	surprise    string
	at          time.Time
}

func stateVec(o Outputs) []float64 {
	return []float64{o.Arousal, o.Threat, o.Reward, o.Conflict, o.Focus, o.Novelty, o.Calm}
}

// observe takes the real state of this step: scores the earlier prediction, learns from it and predicts the next state.
func (s *selfPred) observe(v []float64, now time.Time) {
	if s.w == nil {
		s.w = make([][3]float64, len(v))
		for i := range s.w {
			s.w[i] = [3]float64{.9, .1, 0} // start as "I stay as I am"
		}
	}
	if s.pred != nil {
		var e float64
		worst, wd := 0.0, -1
		for i := range v {
			d := math.Abs(v[i] - s.pred[i])
			e += d
			if d > worst {
				worst, wd = d, i
			}
			// least-mean-squares step: the predictor learns to know her
			if s.prev2 != nil {
				diff := s.pred[i] - v[i]
				x := [3]float64{s.prev[i], s.prev2[i], 1}
				for k := range x {
					s.w[i][k] -= .05 * diff * x[k]
				}
			}
		}
		e /= float64(len(v))
		if s.n == 0 {
			s.err = e
		} else {
			s.err += (e - s.err) * .05
		}
		s.n++
		if s.n > 20 && worst > .12 && worst > 3*s.err+.05 {
			s.surprise = fmt.Sprintf("меня саму удивило, как резко изменилось: %s (я ждала %.2f, а стало %.2f)", russianDim[selfDims[wd]], s.pred[wd], v[wd])
			s.at = now
		}
	}
	s.prev2, s.prev = s.prev, append([]float64(nil), v...)
	if s.prev2 != nil {
		s.pred = make([]float64, len(v))
		for i := range v {
			s.pred[i] = math.Max(0, math.Min(1, s.w[i][0]*s.prev[i]+s.w[i][1]*s.prev2[i]+s.w[i][2]))
		}
	}
}

var russianDim = map[string]string{"arousal": "возбуждение", "threat": "тревога", "reward": "радость от награды", "conflict": "внутренний конфликт", "focus": "фокус", "novelty": "новизна", "calm": "спокойствие"}

// know is how well she predicts herself, 0..1 (1 = she is never surprised by herself).
func (s *selfPred) know() float64 {
	if s.n < 20 {
		return 0
	}
	return math.Max(0, math.Min(1, 1-s.err/.1))
}

// SelfKnow is how well she predicts her own next state (0 until she has watched herself for a while).
func (c *Cortex) SelfKnow() float64 {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.selfp.know()
}

// SelfSurpriseAt is the same surprise with the moment it happened (zero time when there is none), so that a caller can tell a new
// surprise from one it has already thought about.
func (c *Cortex) SelfSurpriseAt() (string, time.Time) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.selfp.surprise == "" || c.now().Sub(c.selfp.at) > 30*time.Minute {
		return "", time.Time{}
	}
	return c.selfp.surprise, c.selfp.at
}

// SelfSurprise is the last thing about herself that surprised her, while it is fresh (30 minutes), else "".
func (c *Cortex) SelfSurprise() string {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.selfp.surprise == "" || c.now().Sub(c.selfp.at) > 30*time.Minute {
		return ""
	}
	return c.selfp.surprise
}
