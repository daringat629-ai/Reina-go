package cortex

import "testing"

// go test ./internal/cortex -run xxx -bench Step -benchtime 5x
func BenchmarkStep200k(b *testing.B) {
	n := NewNet(200000, 1)
	n.Step()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		n.Step()
	}
}

func BenchmarkCortexStep1M(b *testing.B) {
	c := New("", 1000000, 1)
	in := Inputs{Hour: 12, Channels: map[string]float64{}}
	c.Step(in)
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		c.Step(in)
	}
}

func BenchmarkCortexStep4M(b *testing.B) {
	c := New("", 4000000, 1)
	in := Inputs{Hour: 12, Channels: map[string]float64{}}
	c.Step(in)
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		c.Step(in)
	}
}
