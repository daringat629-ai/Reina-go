// Package cortex is her brain at the level of the human brain's parts: about 40 regions, each a population of millions of rate
// neurons in total, wired by the real kind of connections (thalamus <-> cortex, cortex -> striatum -> pallidum -> thalamus, amygdala,
// hippocampus, cerebellum, the neuromodulator nuclei of the brainstem...). Every region has a machine job that is the analogue
// of what its biological counterpart does (a gate, a relevance filter, a forward model, an action selector, a store of
// episodes, a homeostat...). It is an analogy in computation, not an emulation of tissue: the neurons are leaky rate units, the
// synapses are drawn by a hash instead of being stored, and what the regions compute is read as signals (arousal, threat, reward,
// conflict, focus) that colour her choices. It sits beside package brain (the fly-style spiking core with dopamine learning).
package cortex

// Region is one part of the brain.
type Region struct {
	ID      string  // short name used in code
	Name    string  // her name for it (Russian)
	Analog  string  // the biological part it is the analogue of
	Machine string  // what it computes here, in her own terms
	Group   string  // brainstem, thalamus, limbic, basal, cerebellum, cortex
	Human   float64 // neurons of the real part, in millions (an estimate; sets the share of the simulated neurons)
	Tau     float64 // how slowly the population follows its input (ticks)
	Pos     [3]float64
	Mod     string // the neuromodulator this nucleus releases ("" = none)
}

// Regions in the order of the build. Positions are for drawing (x right, y up, z forward, in a head of radius 1).
var Regions = []Region{
	// brainstem and the neuromodulator nuclei
	{ID: "reticular", Name: "ретикулярная формация", Analog: "reticular activating system", Machine: "общий уровень бодрствования: выше при шуме, боли, новизне, ниже перед сном", Group: "brainstem", Human: 70, Tau: 4, Pos: [3]float64{0, -.55, -.35}},
	{ID: "locus", Name: "голубое пятно", Analog: "locus coeruleus", Machine: "норадреналин: настороженность и сужение внимания при угрозе и неожиданности", Group: "brainstem", Human: 0.05, Tau: 3, Pos: [3]float64{.05, -.45, -.4}, Mod: "NE"},
	{ID: "vta", Name: "VTA и чёрная субстанция", Analog: "ventral tegmental area, substantia nigra", Machine: "дофамин: ошибка предсказания награды, разрешает учиться и действовать", Group: "brainstem", Human: 0.6, Tau: 3, Pos: [3]float64{-.05, -.4, -.25}, Mod: "DA"},
	{ID: "raphe", Name: "ядра шва", Analog: "raphe nuclei", Machine: "серотонин: терпение, спокойствие, торможение порывов", Group: "brainstem", Human: 0.3, Tau: 6, Pos: [3]float64{0, -.5, -.3}, Mod: "SE"},
	{ID: "meynert", Name: "базальное ядро Мейнерта", Analog: "nucleus basalis of Meynert", Machine: "ацетилхолин: чёткость внимания и запись в память", Group: "brainstem", Human: 0.2, Tau: 4, Pos: [3]float64{0, -.2, .35}, Mod: "ACh"},
	{ID: "pag", Name: "околоводопроводное серое", Analog: "periaqueductal gray", Machine: "управление болью: подавляет её при угрозе, запускает замирание и бегство", Group: "brainstem", Human: 1.5, Tau: 3, Pos: [3]float64{0, -.3, -.2}},
	{ID: "medulla", Name: "продолговатый мозг", Analog: "medulla and pons", Machine: "автоматика тела: пульс, дыхание, ритм сна, считывает состояние тела", Group: "brainstem", Human: 20, Tau: 2, Pos: [3]float64{0, -.7, -.45}},
	// thalamus and hypothalamus
	{ID: "thalamus", Name: "таламус", Analog: "thalamus", Machine: "вахтёр: пропускает в кору только то, на что направлено внимание сенсориума", Group: "thalamus", Human: 250, Tau: 2, Pos: [3]float64{0, .0, .0}},
	{ID: "hypothalamus", Name: "гипоталамус", Analog: "hypothalamus", Machine: "гомеостат: голод, жажда, температура, суточный ритм, стресс-ось, сон", Group: "thalamus", Human: 10, Tau: 6, Pos: [3]float64{0, -.2, .15}},
	{ID: "pituitary", Name: "гипофиз и эпифиз", Analog: "pituitary and pineal gland", Machine: "гормоны медленной шкалы: кортизол, мелатонин, окситоцин", Group: "thalamus", Human: 0.5, Tau: 12, Pos: [3]float64{0, -.3, .1}},
	{ID: "habenula", Name: "поводок", Analog: "habenula", Machine: "антинаграда: разочарование, когда ожидаемое не пришло", Group: "thalamus", Human: 0.3, Tau: 5, Pos: [3]float64{0, .1, -.1}},
	// limbic
	{ID: "amygdala", Name: "миндалина", Analog: "amygdala", Machine: "быстрая оценка угрозы и эмоциональной значимости; страх, настороженность", Group: "limbic", Human: 12, Tau: 2, Pos: [3]float64{.35, -.2, .15}},
	{ID: "hippocampus", Name: "гиппокамп", Analog: "hippocampus", Machine: "эпизодическая память: запоминает ситуации, узнаёт знакомое, измеряет новизну, проигрывает во сне", Group: "limbic", Human: 40, Tau: 5, Pos: [3]float64{.45, -.15, -.1}},
	{ID: "entorhinal", Name: "энторинальная кора", Analog: "entorhinal cortex (place and grid cells)", Machine: "карта места: где она в комнате, что рядом", Group: "limbic", Human: 7, Tau: 4, Pos: [3]float64{.5, -.25, 0}},
	{ID: "accumbens", Name: "прилежащее ядро", Analog: "nucleus accumbens", Machine: "удовольствие и тяга: насколько хочется того, что сейчас возможно", Group: "limbic", Human: 3, Tau: 3, Pos: [3]float64{.1, -.2, .45}},
	{ID: "acc", Name: "поясная кора", Analog: "anterior cingulate cortex", Machine: "конфликт между тягами и ошибки; переключает на усилие и поправку", Group: "limbic", Human: 90, Tau: 4, Pos: [3]float64{0, .35, .3}},
	{ID: "insula", Name: "островок", Analog: "insular cortex", Machine: "ощущение тела изнутри: сводит боль, голод, пульс, равновесие в одно чувство «как я»", Group: "limbic", Human: 150, Tau: 3, Pos: [3]float64{.55, 0, .1}},
	// basal ganglia
	{ID: "striatum", Name: "полосатое тело", Analog: "striatum (caudate and putamen)", Machine: "вход выбора действия: получает варианты от коры и взвешивает их дофамином", Group: "basal", Human: 110, Tau: 3, Pos: [3]float64{.25, .1, .2}},
	{ID: "gpi", Name: "бледный шар", Analog: "globus pallidus", Machine: "тормоз выбора: держит все действия, кроме выбранного", Group: "basal", Human: 3, Tau: 3, Pos: [3]float64{.2, .0, .1}},
	{ID: "stn", Name: "субталамическое ядро", Analog: "subthalamic nucleus", Machine: "аварийный тормоз: останавливает всё при конфликте или опасности", Group: "basal", Human: 0.3, Tau: 2, Pos: [3]float64{.1, -.15, -.05}},
	// cerebellum
	{ID: "cerebellum", Name: "мозжечок", Analog: "cerebellum", Machine: "прямая модель тела: предсказывает исход движения, ошибка учит координации (сидеть, ходить, вставать)", Group: "cerebellum", Human: 69000, Tau: 3, Pos: [3]float64{0, -.5, -.65}},
	// cortex
	{ID: "pfc_dl", Name: "дорсолатеральная префронтальная кора", Analog: "dorsolateral prefrontal cortex", Machine: "рабочая память на несколько элементов и планирование", Group: "cortex", Human: 1800, Tau: 6, Pos: [3]float64{.3, .5, .6}},
	{ID: "pfc_om", Name: "орбитофронтальная кора", Analog: "orbitofrontal cortex", Machine: "оценка ценности вариантов: что для неё лучше", Group: "cortex", Human: 700, Tau: 5, Pos: [3]float64{0, .15, .75}},
	{ID: "pfc_vm", Name: "вентромедиальная префронтальная кора", Analog: "ventromedial prefrontal cortex", Machine: "регуляция эмоций: гасит страх, когда опасность прошла", Group: "cortex", Human: 600, Tau: 8, Pos: [3]float64{0, .3, .7}},
	{ID: "pfc_pole", Name: "лобный полюс", Analog: "frontopolar cortex", Machine: "долгие цели и «что я хочу вообще»", Group: "cortex", Human: 300, Tau: 12, Pos: [3]float64{0, .4, .9}},
	{ID: "motor", Name: "моторная кора", Analog: "primary motor and premotor cortex, SMA", Machine: "команда движения и подготовка последовательностей", Group: "cortex", Human: 1100, Tau: 2, Pos: [3]float64{.2, .8, .1}},
	{ID: "somato", Name: "соматосенсорная кора", Analog: "primary somatosensory cortex", Machine: "карта тела: касание, давление, положение частей", Group: "cortex", Human: 900, Tau: 2, Pos: [3]float64{.2, .8, -.05}},
	{ID: "visual", Name: "зрительная кора", Analog: "visual cortex V1 to V4", Machine: "обработка картинки: контуры, свет, движение", Group: "cortex", Human: 1500, Tau: 2, Pos: [3]float64{0, .3, -.95}},
	{ID: "auditory", Name: "слуховая кора", Analog: "auditory cortex", Machine: "обработка звука: громкость, речь, музыка", Group: "cortex", Human: 500, Tau: 2, Pos: [3]float64{.75, 0, -.1}},
	{ID: "wernicke", Name: "зона Вернике", Analog: "Wernicke's area", Machine: "понимание текста и речи", Group: "cortex", Human: 400, Tau: 4, Pos: [3]float64{.7, .2, -.3}},
	{ID: "broca", Name: "зона Брока", Analog: "Broca's area", Machine: "выстраивание собственных слов и фраз", Group: "cortex", Human: 300, Tau: 4, Pos: [3]float64{.65, .25, .35}},
	{ID: "temporal", Name: "височная ассоциативная кора", Analog: "temporal association cortex", Machine: "смыслы, лица, имена: кто это и что это значит", Group: "cortex", Human: 1600, Tau: 5, Pos: [3]float64{.7, -.05, .0}},
	{ID: "parietal", Name: "теменная кора", Analog: "posterior parietal cortex", Machine: "пространство и схема тела: где она, где предметы, куда направлено внимание", Group: "cortex", Human: 1700, Tau: 3, Pos: [3]float64{.35, .65, -.35}},
	{ID: "dmn", Name: "сеть пассивного режима", Analog: "default mode network (precuneus, posterior cingulate)", Machine: "мысли о себе, когда рядом никого: самомодель, воспоминания, планы", Group: "cortex", Human: 1200, Tau: 10, Pos: [3]float64{0, .55, -.35}},
	{ID: "callosum", Name: "мозолистое тело", Analog: "corpus callosum", Machine: "связывает правое и левое: держит согласованность двух половин расчёта", Group: "cortex", Human: 200, Tau: 4, Pos: [3]float64{0, .25, 0}},
}

// Edge is a bundle of connections from one region to another.
type Edge struct {
	From, To string
	W        float64 // strength
	Inh      bool    // the bundle inhibits (GABA)
	Learn    float64 // plasticity rate (dopamine-gated); 0 = fixed
}

// Edges is the wiring between the parts. It follows the textbook pathways.
var Edges = []Edge{
	// arousal and neuromodulator systems
	{"reticular", "thalamus", .5, false, 0}, {"reticular", "pfc_dl", .25, false, 0}, {"locus", "amygdala", .4, false, 0}, {"locus", "pfc_dl", .3, false, 0},
	{"locus", "thalamus", .3, false, 0}, {"vta", "striatum", .55, false, 0}, {"vta", "accumbens", .5, false, 0}, {"vta", "pfc_dl", .3, false, 0},
	{"raphe", "amygdala", .4, true, 0}, {"raphe", "pfc_vm", .3, false, 0}, {"meynert", "hippocampus", .35, false, 0}, {"meynert", "temporal", .25, false, 0},
	{"pag", "medulla", .3, false, 0}, {"medulla", "reticular", .3, false, 0}, {"medulla", "insula", .5, false, 0}, {"medulla", "hypothalamus", .35, false, 0},
	// senses through the thalamus to the cortex
	{"thalamus", "visual", .5, false, 0}, {"thalamus", "auditory", .5, false, 0}, {"thalamus", "somato", .5, false, 0}, {"thalamus", "insula", .35, false, 0},
	{"thalamus", "amygdala", .4, false, 0}, {"thalamus", "pfc_dl", .3, false, 0}, {"thalamus", "parietal", .3, false, 0},
	{"visual", "parietal", .4, false, 0}, {"visual", "temporal", .45, false, 0}, {"auditory", "wernicke", .5, false, 0}, {"auditory", "amygdala", .25, false, 0},
	{"somato", "parietal", .4, false, 0}, {"somato", "insula", .35, false, 0}, {"somato", "motor", .3, false, 0}, {"parietal", "motor", .35, false, 0},
	{"parietal", "entorhinal", .4, false, 0}, {"temporal", "hippocampus", .4, false, 0}, {"wernicke", "temporal", .45, false, 0}, {"wernicke", "broca", .5, false, 0},
	{"temporal", "pfc_om", .3, false, 0}, {"temporal", "amygdala", .3, false, 0},
	// memory
	{"entorhinal", "hippocampus", .55, false, 0}, {"hippocampus", "entorhinal", .3, false, 0}, {"hippocampus", "dmn", .35, false, .02}, {"hippocampus", "pfc_dl", .25, false, .02},
	{"hippocampus", "amygdala", .2, false, 0},
	// emotion
	{"amygdala", "pag", .45, false, 0}, {"amygdala", "hypothalamus", .4, false, 0}, {"amygdala", "locus", .35, false, 0}, {"amygdala", "stn", .25, false, 0},
	{"pfc_vm", "amygdala", .5, true, .01}, {"insula", "acc", .4, false, 0}, {"insula", "amygdala", .3, false, 0}, {"acc", "pfc_dl", .35, false, 0},
	{"acc", "stn", .3, false, 0}, {"habenula", "vta", .5, true, 0}, {"accumbens", "habenula", .2, false, 0}, {"accumbens", "gpi", .3, true, 0},
	{"hypothalamus", "pituitary", .5, false, 0}, {"pituitary", "hypothalamus", .2, true, 0}, {"hypothalamus", "reticular", .3, false, 0}, {"hypothalamus", "raphe", .2, false, 0},
	// prefrontal and decision
	{"pfc_dl", "striatum", .5, false, .03}, {"pfc_om", "striatum", .4, false, .03}, {"pfc_om", "accumbens", .4, false, .02}, {"pfc_vm", "hypothalamus", .25, false, 0},
	{"pfc_pole", "pfc_dl", .3, false, 0}, {"pfc_dl", "pfc_pole", .2, false, 0}, {"dmn", "pfc_pole", .3, false, 0}, {"pfc_dl", "dmn", .15, true, 0},
	{"callosum", "pfc_dl", .15, false, 0}, {"pfc_dl", "callosum", .15, false, 0}, {"temporal", "callosum", .1, false, 0}, {"callosum", "temporal", .1, false, 0},
	// action selection loop: cortex -> striatum -> pallidum -> thalamus -> cortex
	{"striatum", "gpi", .55, true, 0}, {"gpi", "thalamus", .45, true, 0}, {"stn", "gpi", .55, false, 0}, {"pfc_dl", "stn", .25, false, 0},
	{"thalamus", "motor", .4, false, 0}, {"motor", "striatum", .25, false, 0},
	// movement and the cerebellum
	{"motor", "cerebellum", .4, false, 0}, {"somato", "cerebellum", .3, false, 0}, {"cerebellum", "thalamus", .4, false, .02}, {"cerebellum", "motor", .35, false, .03},
	{"parietal", "cerebellum", .2, false, 0}, {"broca", "motor", .3, false, 0},
}
