package cortex

import "testing"

func TestDreamsAreKeptNewestFirstAndTrimmed(t *testing.T) {
	c := New("", 50000, 3)
	if len(c.Dreams()) != 0 {
		t.Fatal("no dreams yet")
	}
	for i := 0; i < dreamKeep+5; i++ {
		c.dreamNotes = []string{"было тихо"}
		c.makeDream()
		c.dreams[len(c.dreams)-1].At = int64(i)
	}
	ds := c.Dreams()
	if len(ds) != dreamKeep || ds[0].At != int64(dreamKeep+4) || ds[len(ds)-1].At != 5 {
		t.Fatalf("kept %d, first %d last %d", len(ds), ds[0].At, ds[len(ds)-1].At)
	}
	c.dreamNotes = nil
	c.makeDream() // nothing replayed: no dream
	if len(c.Dreams()) != dreamKeep {
		t.Fatal("an empty sleep must not make a dream")
	}
}
