package cortex

import (
	"strings"
	"testing"
	"time"
)

func TestSelfPredictionLearnsASteadySelfAndIsSurprisedByAJump(t *testing.T) {
	var s selfPred
	now := time.Now()
	calm := []float64{.4, .1, .3, .1, .5, .2, .6}
	for i := 0; i < 80; i++ {
		s.observe(calm, now.Add(time.Duration(i)*time.Second))
	}
	if s.know() < .9 {
		t.Fatalf("a steady self is easy to predict: %.2f", s.know())
	}
	if s.surprise != "" {
		t.Fatal("no surprise in a steady state:", s.surprise)
	}
	jump := []float64{.4, .9, .3, .1, .5, .2, .6} // threat leaps
	s.observe(jump, now.Add(90*time.Second))
	if !strings.Contains(s.surprise, "тревога") {
		t.Fatalf("a sudden leap must surprise her: %q", s.surprise)
	}
}

func TestSelfPredictionNeedsTimeAndHidesBehindFreshness(t *testing.T) {
	c := New("", 50000, 3)
	if c.SelfKnow() != 0 || c.SelfSurprise() != "" {
		t.Fatal("nothing known at the start")
	}
	for i := 0; i < 40; i++ {
		c.Step(Inputs{Hour: 12, Channels: map[string]float64{}})
	}
	if k := c.SelfKnow(); k <= 0 || k > 1 {
		t.Fatalf("after watching herself she has a self-knowledge: %.2f", k)
	}
	c.selfp.surprise, c.selfp.at = "что-то", c.now().Add(-time.Hour)
	if c.SelfSurprise() != "" {
		t.Fatal("an old surprise is gone")
	}
}
