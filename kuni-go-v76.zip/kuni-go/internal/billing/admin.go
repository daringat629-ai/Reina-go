package billing

import (
	"context"
	"fmt"
	"log"
	"os"
	"strconv"
	"strings"
	"time"
)

// Admin is the owner's own bot: a summary, people, QR payment requests with ✅/❌, the QR picture, gifts. It answers only the owner.
type Admin struct {
	Token     string
	BaseURL   string
	Owner     func() int64 // the owner's Telegram id; everyone else is ignored
	Store     *Store
	Pay       *Bot   // the pay bot, to tell people about a decision
	QRPath    string // where the owner's QR picture is kept
	Loc       *time.Location
	Now       func() time.Time
	Update    func(ctx context.Context) (string, error) // /update: install the newest build from GitHub (nil = not offered)
	Check     func(ctx context.Context) (string, error) // only look whether a newer build exists (nil = not offered)
	Presence  func() Presence                           // Reina right now, for the owner's app
	Questions func() any                                // her questions to people (advice), for the owner's app
	Costs     func(days int) map[string]float64         // what the model cost per day in USD ("2006-01-02"), for the profit view
	Money     func() (starUSD, usdPerUnit float64)      // what one Star and one unit of the QR currency are worth in USD
	Settings  func() []Setting                          // the settings the owner may change from the app
	Set       func(section, key, value string) error    // writes one of them into config.toml (hot-reloaded)
	cl        *Bot                                      // the Bot API client of this bot
	offset    int64
}

const (
	aStats  = "📊 Статистика"
	aReqs   = "🧾 Заявки"
	aPeople = "👥 Люди"
	aQR     = "🖼 Мой QR"
)

func (a *Admin) client() *Bot {
	if a.cl == nil {
		a.cl = &Bot{Token: a.Token, BaseURL: a.BaseURL}
	}
	return a.cl
}

func (a *Admin) now() time.Time {
	if a.Now != nil {
		return a.Now()
	}
	return time.Now()
}

func (a *Admin) loc() *time.Location {
	if a.Loc != nil {
		return a.Loc
	}
	return time.Local
}

func adminMenu() map[string]any {
	return map[string]any{"keyboard": [][]map[string]any{{{"text": aStats, "style": "primary"}, {"text": aReqs}}, {{"text": aPeople}, {"text": aQR}}}, "resize_keyboard": true, "is_persistent": true}
}

func (a *Admin) say(ctx context.Context, text string, markup any) {
	if markup == nil {
		markup = adminMenu()
	}
	if err := a.client().call(ctx, "sendMessage", map[string]any{"chat_id": a.Owner(), "text": text, "reply_markup": markup}, nil); err != nil {
		log.Printf("admin bot: %v", err)
	}
}

// QRImage reads the saved QR picture (nil when there is none).
func (a *Admin) QRImage() []byte {
	b, err := os.ReadFile(a.QRPath)
	if err != nil {
		return nil
	}
	return b
}

// Receipt shows the owner a receipt with ✅ / ❌ (called by the pay bot).
func (a *Admin) Receipt(r Request, img []byte) {
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()
	a.keepReceipt(r, img)
	caption := fmt.Sprintf("🧾 Заявка %s\nОт: %s (id %d)\nЧто: %s\nСумма: %s\nКод в комментарии: %s\n\nПроверь, что перевод пришёл, и нажми кнопку.", r.Code, r.Name, r.UserID, r.what(), a.price(r.Som), r.Code)
	if err := a.client().sendPhotoMarkup(ctx, a.Owner(), img, caption, decide(r.ID)); err != nil {
		log.Printf("admin bot: receipt: %v", err)
	}
}

func decide(id int) map[string]any {
	return map[string]any{"inline_keyboard": [][]map[string]any{{{"text": "✅ Пришло, включить", "callback_data": fmt.Sprintf("ok:%d", id), "style": "success"}, {"text": "❌ Не пришло", "callback_data": fmt.Sprintf("no:%d", id), "style": "danger"}}}}
}

// Run polls the Bot API until ctx ends.
func (a *Admin) Run(ctx context.Context) {
	if a.Owner() != 0 {
		a.say(ctx, "Админ-бот Orvi на связи. Кнопки внизу.", nil)
	}
	for ctx.Err() == nil {
		var ups []update
		err := a.client().call(ctx, "getUpdates", map[string]any{"offset": a.offset, "timeout": 50, "allowed_updates": []string{"message", "callback_query"}}, &ups)
		if err != nil {
			if ctx.Err() == nil {
				log.Printf("admin bot: %v", err)
				select {
				case <-ctx.Done():
				case <-time.After(10 * time.Second):
				}
			}
			continue
		}
		for _, u := range ups {
			a.offset = u.UpdateID + 1
			a.handle(ctx, u)
		}
	}
}

func (a *Admin) handle(ctx context.Context, u update) {
	owner := a.Owner()
	switch {
	case u.Callback != nil:
		q := u.Callback
		_ = a.client().call(ctx, "answerCallbackQuery", map[string]any{"callback_query_id": q.ID}, nil)
		if owner == 0 || q.From.ID != owner {
			return
		}
		a.decide(ctx, q.Data)
	case u.Message != nil:
		m := u.Message
		if owner == 0 || m.From.ID != owner {
			return // not the owner: silence
		}
		if len(m.Photo) > 0 {
			a.saveQR(ctx, m.Photo[len(m.Photo)-1].FileID)
			return
		}
		a.command(ctx, strings.TrimSpace(m.Text))
	}
}

func (a *Admin) decide(ctx context.Context, data string) {
	kind, n, ok := strings.Cut(data, ":")
	id, err := strconv.Atoi(n)
	if !ok || err != nil {
		return
	}
	switch kind {
	case "ok":
		r, u, err := a.Store.Approve(id, a.now())
		if err != nil {
			a.say(ctx, "⚠️ "+err.Error(), nil)
			return
		}
		if r.Tokens > 0 {
			a.say(ctx, fmt.Sprintf("✅ %s: +%s пользователю %d, баланс %s.", r.Code, tokensWord(r.Tokens), r.UserID, tokensWord(u.Tokens)), nil)
			if a.Pay != nil {
				a.Pay.Tell(ctx, r.UserID, fmt.Sprintf("Оплата по заявке %s подтверждена: +%s. Баланс: %s. Можно возвращаться к Рейне.", r.Code, tokensWord(r.Tokens), tokensWord(u.Tokens)))
			}
			return
		}
		a.say(ctx, fmt.Sprintf("✅ %s: %s включён пользователю %d до %s.", r.Code, title(u.Plan), r.UserID, u.Until.In(a.loc()).Format("02.01.2006")), nil)
		if a.Pay != nil {
			a.Pay.Tell(ctx, r.UserID, fmt.Sprintf("Оплата по заявке %s подтверждена. Тариф %s действует до %s. Можно возвращаться к Рейне.", r.Code, title(u.Plan), u.Until.In(a.loc()).Format("02.01.2006")))
		}
	case "no":
		r, err := a.Store.Mark(id, "no", a.now())
		if err != nil {
			a.say(ctx, "⚠️ "+err.Error(), nil)
			return
		}
		a.say(ctx, fmt.Sprintf("❌ %s отклонена.", r.Code), nil)
		if a.Pay != nil {
			a.Pay.Tell(ctx, r.UserID, fmt.Sprintf("Перевод по заявке %s не нашли. Если ты переводил(а), напиши в «Поддержка» и приложи чек.", r.Code))
		}
	}
}

func (a *Admin) command(ctx context.Context, text string) {
	f := strings.Fields(text)
	switch {
	case text == aStats || text == "/stats" || text == "/start":
		st := a.Store.Stats(a.now(), a.loc())
		a.say(ctx, fmt.Sprintf("📊 Orvi сейчас\n\nЛюдей: %d\nС балансом или тарифом: %d\nБесплатных разговоров сегодня: %d\n\nСегодня: ⭐ %d · %s\nВсего: ⭐ %d · %s (%d оплат)\nПродано токенов: %s, ещё не потрачено: %s\nЗаявок по QR ждёт: %d", st.People, st.Paying, st.Today, st.StarsToday, a.price(st.SomToday), st.Stars, a.price(st.Som), st.Payments, Num(st.TokensSold), Num(st.TokensLeft), st.Open), nil)
	case text == aReqs || text == "/requests":
		open := a.Store.Open()
		if len(open) == 0 {
			a.say(ctx, "🧾 Открытых заявок нет.", nil)
			return
		}
		for _, r := range open {
			state := "ждёт чек"
			var kb any
			if r.Status == "sent" {
				state, kb = "чек прислан", decide(r.ID)
			}
			a.say(ctx, fmt.Sprintf("%s · %s · %s · %s · %s (%s)", r.Code, r.Name, a.price(r.Som), r.what(), r.At.In(a.loc()).Format("02.01 15:04"), state), kb)
		}
	case text == aPeople || text == "/people":
		us, _ := a.Store.All(a.now())
		var sb strings.Builder
		sb.WriteString("👥 С балансом или тарифом\n")
		n := 0
		for _, u := range us {
			if (u.Plan == Free && u.Tokens <= 0) || n >= 20 {
				continue
			}
			n++
			fmt.Fprintf(&sb, "\n%d · баланс %s", u.ID, Short(max(u.Tokens, 0)))
			if u.Plan != Free {
				fmt.Fprintf(&sb, " · %s до %s", title(u.Plan), u.Until.In(a.loc()).Format("02.01"))
			}
			fmt.Fprintf(&sb, " · всего разговоров %d", u.Total)
		}
		if n == 0 {
			sb.WriteString("\nПока никого.")
		}
		fmt.Fprintf(&sb, "\n\nВсего людей: %d\n/user <id> — подробно\n/give <id> <токенов> — подарить токены", len(us))
		a.say(ctx, sb.String(), nil)
	case text == aQR:
		if len(a.QRImage()) > 0 {
			_ = a.client().sendPhotoMarkup(ctx, a.Owner(), a.QRImage(), "Сейчас люди видят этот QR. Чтобы заменить, пришли новую картинку.", adminMenu())
			return
		}
		a.say(ctx, "QR ещё нет. Открой приложение банка → «Получить по QR» или «Мой QR», сохрани картинку и пришли её сюда фото.", nil)
	case len(f) == 2 && f[0] == "/user":
		id, err := strconv.ParseInt(f[1], 10, 64)
		if err != nil {
			a.say(ctx, "Формат: /user 123456789", nil)
			return
		}
		u := a.Store.Get(id, a.now())
		all, paid := a.Store.Invited(id)
		a.say(ctx, fmt.Sprintf("👤 %d\nБаланс: %s (потрачено %s, все разговоры стоили %s)\nТариф: %s%s\nСегодня: бесплатно %d, с баланса %d\nВсего разговоров: %d\nПокупок: %d\nС нами с %s\nПригласил: %d (пополнили %d)", id, tokensWord(u.Tokens), Num(u.Spent), Num(u.AllTokens), title(u.Plan),
			map[bool]string{true: " до " + u.Until.In(a.loc()).Format("02.01.2006"), false: ""}[u.Plan != Free], u.Used, u.PaidToday, u.Total, u.Paid, u.Joined.In(a.loc()).Format("02.01.2006"), all, paid), nil)
	case text == "/update" && a.Update != nil:
		a.say(ctx, "🔄 Проверяю GitHub…", nil)
		msg, err := a.Update(ctx)
		if err != nil {
			a.say(ctx, "⚠️ "+err.Error(), nil)
			return
		}
		a.say(ctx, msg, nil)
	case len(f) == 3 && f[0] == "/give":
		id, err1 := strconv.ParseInt(f[1], 10, 64)
		n, err2 := strconv.ParseInt(f[2], 10, 64)
		if err1 != nil || err2 != nil || n <= 0 || n > 1_000_000_000 {
			a.say(ctx, "Формат: /give 123456789 500000", nil)
			return
		}
		u, err := a.Store.AddTokens(id, n, 0, 0, "", "bonus", a.now())
		if err != nil {
			a.say(ctx, "⚠️ "+err.Error(), nil)
			return
		}
		a.say(ctx, fmt.Sprintf("🎁 %d: +%s, баланс %s.", id, tokensWord(n), tokensWord(u.Tokens)), nil)
		if a.Pay != nil {
			a.Pay.Tell(ctx, id, fmt.Sprintf("🎁 Тебе подарок: +%s. Баланс: %s. Токены не сгорают.", tokensWord(n), tokensWord(u.Tokens)))
		}
	case len(f) == 4 && f[0] == "/give":
		id, err1 := strconv.ParseInt(f[1], 10, 64)
		d, err2 := strconv.Atoi(f[3])
		plan := strings.ToLower(f[2])
		if err1 != nil || err2 != nil || d <= 0 || d > 365 || (plan != Plus && plan != Max) {
			a.say(ctx, "Формат: /give 123456789 plus 7", nil)
			return
		}
		u := a.Store.Bonus(id, plan, d, a.now())
		a.say(ctx, fmt.Sprintf("🎁 %d: %s до %s.", id, title(u.Plan), u.Until.In(a.loc()).Format("02.01.2006")), nil)
		if a.Pay != nil {
			a.Pay.Tell(ctx, id, fmt.Sprintf("🎁 Тебе подарок: %s на %s. Действует до %s.", title(u.Plan), days(d), u.Until.In(a.loc()).Format("02.01.2006")))
		}
	default:
		a.say(ctx, "Кнопки внизу. Ещё: /user <id>, /give <id> <токенов>, /update (поставить новую сборку с GitHub). Пришли картинку, чтобы поменять QR.", nil)
	}
}

func (a *Admin) saveQR(ctx context.Context, fileID string) {
	img, err := a.client().download(ctx, fileID)
	if err != nil {
		a.say(ctx, "Не получилось сохранить картинку, пришли ещё раз.", nil)
		return
	}
	if err := os.WriteFile(a.QRPath, img, 0o600); err != nil {
		a.say(ctx, "Не получилось сохранить: "+err.Error(), nil)
		return
	}
	a.say(ctx, "🖼 QR сохранён. Теперь в @"+a.payName()+" в «Пополнить» есть кнопка «Оплатить по QR» (если billing.qr = true).", nil)
}

func (a *Admin) payName() string {
	if a.Pay != nil && a.Pay.Name != "" {
		return a.Pay.Name
	}
	return "боте оплаты"
}

func (a *Admin) price(n int) string {
	if a.Pay != nil {
		return a.Pay.Price(n)
	}
	return (&Bot{}).Price(n)
}

// what is what a QR request buys, in words.
func (r Request) what() string {
	if r.Tokens > 0 {
		return tokensWord(r.Tokens)
	}
	return "тариф " + title(r.Plan) + " на " + days(r.Days)
}
