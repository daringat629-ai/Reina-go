package billing

import (
	"context"
	_ "embed"
	"errors"
	"fmt"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"time"
)

//go:embed webapp/admin.html
var adminHTML []byte

// receiptPath is where the picture of a QR request's receipt is kept (next to the owner's QR picture).
func (a *Admin) receiptPath(code string) string {
	return filepath.Join(filepath.Dir(a.QRPath), "receipts", strings.Map(func(r rune) rune {
		if r >= 'A' && r <= 'Z' || r >= '0' && r <= '9' {
			return r
		}
		return -1
	}, code)+".img")
}

// keepReceipt saves a receipt so the owner's app can show it next to the request.
func (a *Admin) keepReceipt(r Request, img []byte) {
	p := a.receiptPath(r.Code)
	if err := os.MkdirAll(filepath.Dir(p), 0o700); err == nil {
		if err := os.WriteFile(p, img, 0o600); err != nil {
			log.Printf("admin bot: keep receipt: %v", err)
		}
	}
}

// WebApp serves the owner's Mini App on /app/admin/: statistics, QR requests with their receipts, people and balances,
// Reina's state and questions, the QR picture and updates. Only the owner gets in: the request must be signed by the admin bot
// and come from the owner's Telegram id.
func (a *Admin) WebApp() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("/app/admin/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/app/admin/" {
			http.NotFound(w, r)
			return
		}
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Header().Set("Cache-Control", "no-cache")
		_, _ = w.Write(adminHTML)
	})
	owner := func(u WebUser) error {
		if o := a.Owner(); o == 0 || u.ID != o {
			return errors.New("это приложение только для владельца")
		}
		return nil
	}
	h := func(path string, f func(r *http.Request, in map[string]any) (any, error)) {
		mux.HandleFunc("/app/admin/api/"+path, signedAPI(func() string { return a.Token }, a.now, owner, func(r *http.Request, _ WebUser, in map[string]any) (any, error) {
			return f(r, in)
		}))
	}
	h("overview", func(r *http.Request, _ map[string]any) (any, error) { return a.overview(), nil })
	h("requests", func(r *http.Request, _ map[string]any) (any, error) { return a.requests(), nil })
	h("decide", func(r *http.Request, in map[string]any) (any, error) {
		id, _ := in["id"].(float64)
		ok, _ := in["ok"].(bool)
		kind := "no"
		if ok {
			kind = "ok"
		}
		for _, x := range a.Store.Open() {
			if x.ID == int(id) {
				a.decide(r.Context(), fmt.Sprintf("%s:%d", kind, int(id)))
				return map[string]any{"done": true}, nil
			}
		}
		return nil, errors.New("заявка уже решена или не найдена")
	})
	h("people", func(r *http.Request, in map[string]any) (any, error) {
		q, _ := in["q"].(string)
		return a.people(strings.TrimSpace(q)), nil
	})
	h("user", func(r *http.Request, in map[string]any) (any, error) {
		id, _ := in["id"].(float64)
		return a.user(int64(id)), nil
	})
	h("give", func(r *http.Request, in map[string]any) (any, error) {
		id, _ := in["id"].(float64)
		n, _ := in["tokens"].(float64)
		if id <= 0 || n <= 0 || n > 1e9 {
			return nil, errors.New("укажи id и число токенов")
		}
		u, err := a.Store.AddTokens(int64(id), int64(n), 0, 0, "", "bonus", a.now())
		if err != nil {
			return nil, err
		}
		if a.Pay != nil {
			a.Pay.Tell(r.Context(), int64(id), fmt.Sprintf("🎁 Тебе подарок: +%s. Баланс: %s. Токены не сгорают.", tokensWord(int64(n)), tokensWord(u.Tokens)))
		}
		return map[string]any{"balance": tokensWord(u.Tokens)}, nil
	})
	h("reina", func(r *http.Request, _ map[string]any) (any, error) {
		out := map[string]any{}
		if a.Presence != nil {
			p := a.Presence()
			out["presence"] = map[string]any{"state": p.State(), "headline": p.Headline(a.now(), a.loc()), "doing": p.Doing, "mood": p.MoodWord(), "moodLevel": p.Mood,
				"energy": p.EnergyWord(), "energyPct": int(max(p.Energy, 0)*100 + .5), "night": p.Night}
		}
		if a.Questions != nil {
			out["questions"] = a.Questions()
		}
		return out, nil
	})
	h("qr", func(r *http.Request, _ map[string]any) (any, error) {
		if strings.HasPrefix(r.Header.Get("Content-Type"), "multipart/") {
			img, err := formImage(r, "photo")
			if err != nil {
				return nil, err
			}
			if err := os.WriteFile(a.QRPath, img, 0o600); err != nil {
				return nil, err
			}
		}
		return map[string]any{"qr": dataURL(a.QRImage())}, nil
	})
	h("profit", func(r *http.Request, in map[string]any) (any, error) {
		n, _ := in["days"].(float64)
		return a.profit(int(n)), nil
	})
	h("settings", func(r *http.Request, _ map[string]any) (any, error) { return a.settings(), nil })
	h("set", func(r *http.Request, in map[string]any) (any, error) {
		if a.Set == nil {
			return nil, errors.New("настройки отсюда недоступны")
		}
		sec, _ := in["section"].(string)
		key, _ := in["key"].(string)
		val := fmt.Sprint(in["value"])
		if err := a.Set(sec, key, val); err != nil {
			return nil, err
		}
		time.Sleep(1500 * time.Millisecond) // the config watcher picks the file up
		return a.settings(), nil
	})
	h("promos", func(r *http.Request, _ map[string]any) (any, error) { return a.promos(), nil })
	h("promo/new", func(r *http.Request, in map[string]any) (any, error) {
		code, _ := in["code"].(string)
		tokens, _ := in["tokens"].(float64)
		limit, _ := in["max"].(float64)
		days, _ := in["days"].(float64)
		note, _ := in["note"].(string)
		if _, err := a.Store.NewPromo(code, int64(tokens), int(limit), int(days), note, a.now()); err != nil {
			return nil, err
		}
		return a.promos(), nil
	})
	h("promo/off", func(r *http.Request, in map[string]any) (any, error) {
		code, _ := in["code"].(string)
		off, _ := in["off"].(bool)
		if err := a.Store.SetPromoOff(code, off); err != nil {
			return nil, err
		}
		return a.promos(), nil
	})
	h("update", func(r *http.Request, in map[string]any) (any, error) {
		install, _ := in["install"].(bool)
		f := a.Check
		if install {
			f = a.Update
		}
		if f == nil {
			return nil, errors.New("обновления из GitHub не настроены (update.github_repo)")
		}
		ctx, cancel := context.WithTimeout(r.Context(), 10*time.Minute)
		defer cancel()
		msg, err := f(ctx)
		if err != nil {
			return nil, err
		}
		if msg == "" {
			msg = "Ты уже знаешь о новой сборке: нажми «Установить»."
		}
		return map[string]any{"message": msg}, nil
	})
	return mux
}

func (a *Admin) overview() map[string]any {
	now := a.now()
	st := a.Store.Stats(now, a.loc())
	out := map[string]any{
		"people": st.People, "paying": st.Paying, "freeToday": st.Today, "open": st.Open, "payments": st.Payments,
		"starsToday": st.StarsToday, "stars": st.Stars, "moneyToday": a.price(st.SomToday), "money": a.price(st.Som),
		"tokensSold": Short(st.TokensSold), "tokensLeft": Short(st.TokensLeft), "starsUSD": fmt.Sprintf("≈ $%.2f", float64(st.Stars)*0.013),
	}
	if a.Pay != nil && a.Pay.Limits != nil {
		f := a.Store.Funnel(now, a.loc(), a.Pay.Limits())
		out["funnel"] = []map[string]any{{"k": "Всего людей", "v": f.Users}, {"k": "Новые сегодня", "v": f.New1d}, {"k": "Новые за 7 дней", "v": f.New7d},
			{"k": "Хоть раз говорили", "v": f.Activated}, {"k": "Говорили сегодня", "v": f.ActiveToday}, {"k": "Вернулись сегодня", "v": f.Returned},
			{"k": "Упёрлись в лимит сегодня", "v": f.AtLimitToday}, {"k": "Платили хоть раз", "v": f.PayingEverEver}, {"k": "По приглашению", "v": f.Referred}}
	}
	if a.Presence != nil {
		p := a.Presence()
		out["reina"] = p.Headline(now, a.loc())
		out["reinaState"] = p.State()
	}
	return out
}

func (a *Admin) requests() []map[string]any {
	var out []map[string]any
	for _, r := range a.Store.Open() {
		img, _ := os.ReadFile(a.receiptPath(r.Code))
		out = append(out, map[string]any{"id": r.ID, "code": r.Code, "name": r.Name, "user": r.UserID, "what": r.what(), "price": a.price(r.Som),
			"at": r.At.In(a.loc()).Format("02.01 15:04"), "status": r.Status, "receipt": dataURL(img)})
	}
	return out
}

func (a *Admin) people(q string) []map[string]any {
	us, _ := a.Store.All(a.now())
	sort.SliceStable(us, func(i, j int) bool {
		if us[i].Tokens != us[j].Tokens {
			return us[i].Tokens > us[j].Tokens
		}
		return us[i].Last.After(us[j].Last)
	})
	var out []map[string]any
	for _, u := range us {
		if q != "" && !strings.Contains(strconv.FormatInt(u.ID, 10), q) {
			continue
		}
		last := ""
		if !u.Last.IsZero() {
			last = u.Last.In(a.loc()).Format("02.01 15:04")
		}
		out = append(out, map[string]any{"id": u.ID, "balance": Short(max(u.Tokens, 0)), "plan": map[bool]string{true: title(u.Plan), false: ""}[u.Plan != Free],
			"total": u.Total, "paid": u.Paid, "last": last})
		if len(out) >= 60 {
			break
		}
	}
	return out
}

func (a *Admin) user(id int64) map[string]any {
	u := a.Store.Get(id, a.now())
	all, paid := a.Store.Invited(id)
	var hist []map[string]string
	for _, p := range a.Store.History(id, 20) {
		amount := ""
		if p.Tokens > 0 {
			amount = Short(p.Tokens) + " токенов"
		} else if p.Days > 0 {
			amount = title(p.Plan) + " на " + days(p.Days)
		}
		money := ""
		if p.Stars > 0 {
			money = fmt.Sprintf("⭐ %d", p.Stars)
		} else if p.Som > 0 {
			money = a.price(p.Som)
		}
		hist = append(hist, map[string]string{"date": p.At.In(a.loc()).Format("02.01.2006"), "what": kindNames[p.Kind], "amount": amount, "money": money})
	}
	joined := ""
	if !u.Joined.IsZero() {
		joined = u.Joined.In(a.loc()).Format("02.01.2006")
	}
	return map[string]any{"id": id, "balance": tokensWord(u.Tokens), "spent": tokensWord(u.Spent), "cost": tokensWord(u.AllTokens),
		"plan":      map[bool]string{true: title(u.Plan) + " до " + u.Until.In(a.loc()).Format("02.01.2006"), false: ""}[u.Plan != Free],
		"freeToday": u.Used, "paidToday": u.PaidToday, "total": u.Total, "paid": u.Paid, "joined": joined, "invited": all, "invitedPaid": paid, "history": hist}
}

// SetMenuApp puts the owner's Mini App on the admin bot's menu button.
func (a *Admin) SetMenuApp(ctx context.Context, appURL string) {
	a.client().setMenu(ctx, appURL, "Админка")
}

// Setting is one value the owner can change from the app.
type Setting struct {
	Section string `json:"section"`
	Key     string `json:"key"`
	Label   string `json:"label"`
	Hint    string `json:"hint"`
	Value   string `json:"value"`
	Kind    string `json:"kind"` // int, float, text, bool
}

func (a *Admin) money() (float64, float64) {
	if a.Money == nil {
		return 0.013, 0
	}
	return a.Money()
}

// profit is income minus what the model cost, per day, for the last n days (oldest first), in USD.
func (a *Admin) profit(n int) map[string]any {
	if n <= 0 || n > 90 {
		n = 14
	}
	now := a.now().In(a.loc())
	star, unit := a.money()
	rev := a.Store.Revenue(now, a.loc(), n)
	cost := map[string]float64{}
	if a.Costs != nil {
		cost = a.Costs(n)
	}
	var days []map[string]any
	var tIn, tCost float64
	for i := n - 1; i >= 0; i-- {
		d := now.AddDate(0, 0, -i).Format("2006-01-02")
		m := rev[d]
		in := float64(m.Stars)*star + float64(m.Som)*unit
		c := cost[d]
		tIn += in
		tCost += c
		days = append(days, map[string]any{"day": d[8:10] + "." + d[5:7], "in": round2(in), "cost": round2(c), "profit": round2(in - c)})
	}
	return map[string]any{"days": days, "in": round2(tIn), "cost": round2(tCost), "profit": round2(tIn - tCost), "noQRRate": unit == 0,
		"note": fmt.Sprintf("Звезда = $%.4f (billing.star_usd), рубль по курсу USD= из billing.rates. Расход — то, что модель стоила по llm.price_*.", star)}
}

func round2(v float64) float64 {
	if v < 0 {
		return -round2(-v)
	}
	return float64(int64(v*100+0.5)) / 100
}

func (a *Admin) settings() map[string]any {
	var list []Setting
	if a.Settings != nil {
		list = a.Settings()
	}
	var packs []map[string]any
	per := ""
	if a.Pay != nil {
		for _, p := range a.Pay.Packs() {
			price := "—"
			if p.Price > 0 {
				price = a.price(p.Price)
			}
			packs = append(packs, map[string]any{"label": Short(p.Tokens) + " токенов", "stars": p.Stars, "price": price, "convs": a.Pay.convs(p.Tokens)})
		}
		per = tokensWord(a.Pay.perConv())
	}
	return map[string]any{"settings": list, "packs": packs, "perConv": per}
}

func (a *Admin) promos() []map[string]any {
	out := []map[string]any{}
	for _, p := range a.Store.PromoStats(a.now()) {
		link := ""
		if a.Pay != nil {
			link = a.Pay.PromoLink(p.Code)
		}
		exp := ""
		if !p.Expires.IsZero() {
			exp = p.Expires.In(a.loc()).Format("02.01.2006")
		}
		out = append(out, map[string]any{"code": p.Code, "tokens": Short(p.Tokens), "note": p.Note, "used": p.Used, "paid": p.Paid, "left": p.Left,
			"max": p.Max, "expires": exp, "active": p.Active, "off": p.Off, "link": link})
	}
	return out
}
