package admin

import (
	"context"
	"encoding/json"
	"errors"
	"kuni/internal/feel"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"strconv"
	"strings"
	"testing"
	"time"

	"kuni/internal/body"
	"kuni/internal/brain"
	"kuni/internal/cortex"
	"kuni/internal/ideas"
	"kuni/internal/life"
	"kuni/internal/live"
	"kuni/internal/physics"
	"kuni/internal/sense"
)

func TestLiveViewIsGuardedAndServesFramesAndFeed(t *testing.T) {
	p, mux, c, _ := rig(t)
	// without a login nothing is served
	if w := do(mux, "GET", "/admin/api/live/frame?src=desktop", "", nil); w.Code != 401 {
		t.Fatalf("frame without auth: %d", w.Code)
	}
	if w := do(mux, "GET", "/admin/api/live/events", "", nil); w.Code != 401 {
		t.Fatalf("events without auth: %d", w.Code)
	}
	// the view is off until the program wires it
	if w := do(mux, "GET", "/admin/api/live/frame?src=desktop", "", auth); w.Code != 404 {
		t.Fatalf("no source: %d", w.Code)
	}
	running := true
	p.Frame = func(_ context.Context, src string) ([]byte, string, bool, error) {
		switch {
		case src == "browser":
			return nil, "", false, errors.New("boom")
		case !running:
			return nil, "", false, nil
		}
		return []byte{0xff, 0xd8, 0xff, 0xd9}, "321,123", true, nil
	}
	p.Screens = func() (bool, bool) { return false, running }
	p.Feed = &live.Feed{}
	p.Feed.Add("tool", "Alex", "browser open")
	p.Feed.Add("result", "Alex", "ok")
	c.paused = true

	w := do(mux, "GET", "/admin/api/live/frame?src=desktop", "", auth)
	if w.Code != 200 || w.Header().Get("Content-Type") != "image/jpeg" || w.Header().Get("X-Pointer") != "321,123" || !strings.Contains(w.Header().Get("Cache-Control"), "no-store") || w.Body.Len() != 4 {
		t.Fatalf("frame: %d %v", w.Code, w.Header())
	}
	running = false
	if w := do(mux, "GET", "/admin/api/live/frame?src=desktop", "", auth); w.Code != 204 {
		t.Fatalf("a stopped screen must be 204, got %d", w.Code)
	}
	if w := do(mux, "GET", "/admin/api/live/frame?src=browser", "", auth); w.Code != 502 {
		t.Fatalf("error: %d", w.Code)
	}
	if w := do(mux, "GET", "/admin/api/live/frame?src=../etc/passwd", "", auth); w.Code != 400 {
		t.Fatalf("bad src: %d", w.Code)
	}

	var j struct {
		Events  []live.Event `json:"events"`
		Last    int64        `json:"last"`
		Desktop bool         `json:"desktop"`
		Browser bool         `json:"browser"`
		Paused  bool         `json:"paused"`
	}
	w = do(mux, "GET", "/admin/api/live/events?since=0", "", auth)
	if err := json.Unmarshal(w.Body.Bytes(), &j); err != nil || len(j.Events) != 2 || j.Last != 2 || j.Desktop || !j.Paused {
		t.Fatalf("events: %s", w.Body.String())
	}
	w = do(mux, "GET", "/admin/api/live/events?since=1", "", auth)
	j.Events = nil
	json.Unmarshal(w.Body.Bytes(), &j)
	if len(j.Events) != 1 || j.Events[0].Kind != "result" {
		t.Fatalf("since: %s", w.Body.String())
	}
	// the tab is part of the page
	if w := do(mux, "GET", "/admin", "", map[string]string{"Authorization": "Bearer " + tok}); !strings.Contains(w.Body.String(), `["live","Эфир"]`) {
		t.Fatal("the Эфир tab is missing from the page")
	}
}

func TestLiveStreamSendsOnlyChangedPictures(t *testing.T) {
	p, mux, _, _ := rig(t)
	calls := 0
	p.Stream = func(ctx context.Context, src string, prev uint64) ([]byte, uint64, bool, bool, error) {
		calls++
		if prev == 7 {
			return nil, 7, false, true, nil
		}
		return []byte{0xff, 0xd8, 0xff, 0xd9}, 7, true, true, nil
	}
	p.Pointer = func(string) string { return "5,6" }
	if w := do(mux, "GET", "/admin/api/live/stream?src=desktop", "", nil); w.Code != 401 {
		t.Fatalf("no login: %d", w.Code)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 600*time.Millisecond)
	defer cancel()
	r := httptest.NewRequest("GET", "/admin/api/live/stream?src=desktop", nil).WithContext(ctx)
	r.RemoteAddr = "10.0.0.5:1234"
	r.Header.Set("Authorization", "Bearer "+tok)
	w := httptest.NewRecorder()
	mux.ServeHTTP(w, r)
	if ct := w.Header().Get("Content-Type"); !strings.HasPrefix(ct, "multipart/x-mixed-replace") {
		t.Fatalf("content type %q", ct)
	}
	if n := strings.Count(w.Body.String(), "Content-Type: image/jpeg"); n != 1 || calls < 3 {
		t.Fatalf("pictures sent = %d for %d looks, want 1", n, calls)
	}
	if w := do(mux, "GET", "/admin/api/live/pointer?src=desktop", "", auth); !strings.Contains(w.Body.String(), "5,6") {
		t.Fatalf("pointer: %s", w.Body.String())
	}
}

func TestDeskPageNeedsLoginAndSetsTheCookie(t *testing.T) {
	_, mux, _, _ := rig(t)
	if w := do(mux, "GET", "/admin/desk", "", nil); w.Code != 401 {
		t.Fatalf("no login: %d", w.Code)
	}
	if w := do(mux, "GET", "/admin/desk?token="+tok, "", nil); w.Code != 303 || !strings.Contains(w.Header().Get("Set-Cookie"), cookieName) {
		t.Fatalf("token login: %d %v", w.Code, w.Header())
	}
	w := do(mux, "GET", "/admin/desk", "", auth)
	if w.Code != 200 || !strings.Contains(w.Body.String(), "live/stream") {
		t.Fatalf("page: %d", w.Code)
	}
}

func TestBrainViewIsGuarded(t *testing.T) {
	p, _, _, _ := rig(t)
	p.Brain = brain.New("", 1)
	mux := http.NewServeMux()
	p.Mount(mux)
	if w := do(mux, "GET", "/admin/brain/", "", nil); w.Code != 401 {
		t.Fatalf("no login: %d", w.Code)
	}
	if w := do(mux, "GET", "/admin/brain/?token="+tok, "", nil); w.Code != 303 {
		t.Fatalf("token login: %d", w.Code)
	}
	if w := do(mux, "GET", "/admin/brain/", "", auth); w.Code != 200 || !strings.Contains(w.Body.String(), "Мозг Рейны") {
		t.Fatalf("page: %d", w.Code)
	}
	w := do(mux, "GET", "/admin/brain/structure.json", "", auth)
	if w.Code != 200 || !strings.Contains(w.Body.String(), `"inhib"`) {
		t.Fatalf("graph: %d", w.Code)
	}
}

func TestCityViewIsGuarded(t *testing.T) {
	p, _, _, _ := rig(t)
	p.Brain = brain.New("", 1)
	mux := http.NewServeMux()
	p.Mount(mux)
	if w := do(mux, "GET", "/admin/city/", "", nil); w.Code != 401 {
		t.Fatalf("no login: %d", w.Code)
	}
	if w := do(mux, "GET", "/admin/city/?token="+tok, "", nil); w.Code != 303 {
		t.Fatalf("token login: %d", w.Code)
	}
	if w := do(mux, "GET", "/admin/city/", "", auth); w.Code != 200 || !strings.Contains(w.Body.String(), "Город Рейны") {
		t.Fatalf("page: %d", w.Code)
	}
	w := do(mux, "GET", "/admin/city/state.json", "", auth)
	if w.Code != 200 || !strings.Contains(w.Body.String(), `"drives"`) || !strings.Contains(w.Body.String(), `"connect"`) {
		t.Fatalf("state: %d %s", w.Code, w.Body.String())
	}
}

func TestOwnerCanControlHerDesktop(t *testing.T) {
	p, mux, _, _ := rig(t)
	body := `{"src":"desktop","op":"click","x":120,"y":340,"button":3}`
	if w := do(mux, "POST", "/admin/api/live/control", body, nil); w.Code != 401 {
		t.Fatalf("no login: %d", w.Code)
	}
	if w := do(mux, "POST", "/admin/api/live/control", body, auth); w.Code != 404 {
		t.Fatalf("control is off until wired: %d", w.Code)
	}
	var got []ControlReq
	p.Control = func(src string, c ControlReq) error {
		if len(got) == 3 {
			return errors.New("рабочий стол выключен")
		}
		got = append(got, c)
		return nil
	}
	p.Feed = &live.Feed{}
	if w := do(mux, "POST", "/admin/api/live/control", body, auth); w.Code != 200 {
		t.Fatalf("click: %d %s", w.Code, w.Body.String())
	}
	if len(got) != 1 || got[0].Op != "click" || got[0].X != 120 || got[0].Y != 340 || got[0].Button != 3 {
		t.Fatalf("passed: %+v", got)
	}
	if w := do(mux, "POST", "/admin/api/live/control", `{"src":"desktop","op":"type","text":"привет"}`, auth); w.Code != 200 {
		t.Fatalf("type: %d", w.Code)
	}
	if w := do(mux, "POST", "/admin/api/live/control", `{"src":"desktop","op":"move","x":1,"y":2}`, auth); w.Code != 200 {
		t.Fatalf("move: %d", w.Code)
	}
	if w := do(mux, "POST", "/admin/api/live/control", `{"src":"browser","op":"click"}`, auth); w.Code != 400 {
		t.Fatalf("only the desktop: %d", w.Code)
	}
	if w := do(mux, "GET", "/admin/api/live/control", "", auth); w.Code != 405 {
		t.Fatalf("GET: %d", w.Code)
	}
	if w := do(mux, "POST", "/admin/api/live/control", body, auth); w.Code != 409 {
		t.Fatalf("desktop off must be reported: %d", w.Code)
	}
	// she is told who did it, but a mouse move is not worth a line
	var notes []string
	for _, e := range p.Feed.Since(0) {
		if e.Kind == "owner" {
			notes = append(notes, e.Text)
		}
	}
	if len(notes) != 2 || !strings.Contains(notes[0], "клик") || !strings.Contains(notes[1], "печатает") {
		t.Fatalf("feed: %v", notes)
	}
}

func TestOwnerAnswersHerIdeas(t *testing.T) {
	p, mux, _, _ := rig(t)
	p.Ideas = ideas.Open(filepath.Join(t.TempDir(), "i.json"))
	it, _ := p.Ideas.Propose("Сделать библиотеку снов в городе", "хочу", time.Now())
	get := func() string {
		req := httptest.NewRequest("GET", "/admin/api/ideas", nil)
		req.Header.Set("Authorization", "Bearer "+tok)
		rec := httptest.NewRecorder()
		mux.ServeHTTP(rec, req)
		return rec.Body.String()
	}
	if !strings.Contains(get(), "библиотеку снов") {
		t.Fatal(get())
	}
	post := func(body string) int {
		req := httptest.NewRequest("POST", "/admin/api/ideas", strings.NewReader(body))
		req.Header.Set("Authorization", "Bearer "+tok)
		req.Header.Set("X-Admin", "1")
		rec := httptest.NewRecorder()
		mux.ServeHTTP(rec, req)
		return rec.Code
	}
	if c := post(`{"id":` + strconv.Itoa(it.ID) + `,"yes":true}`); c != 200 {
		t.Fatal(c)
	}
	if c := post(`{"id":` + strconv.Itoa(it.ID) + `,"yes":false}`); c != 409 {
		t.Fatal("answered twice", c)
	}
	if !strings.Contains(p.Ideas.Prompt(), "ответил ДА") {
		t.Fatal("approved idea must reach her")
	}
}

func TestBodyAPI(t *testing.T) {
	p, mux, _, _ := rig(t)
	req := httptest.NewRequest("GET", "/admin/api/body", nil)
	req.Header.Set("Authorization", "Bearer "+tok)
	rec := httptest.NewRecorder()
	mux.ServeHTTP(rec, req)
	if rec.Code != 404 {
		t.Fatal("off without a body", rec.Code)
	}
	p.Body = body.New(filepath.Join(t.TempDir(), "b.json"))
	rec = httptest.NewRecorder()
	mux.ServeHTTP(rec, req)
	if rec.Code != 200 || !strings.Contains(rec.Body.String(), `"senses"`) {
		t.Fatal(rec.Code, rec.Body.String())
	}
	post := httptest.NewRequest("POST", "/admin/api/body", strings.NewReader(`{"do":"fly"}`))
	post.Header.Set("Authorization", "Bearer "+tok)
	post.Header.Set("X-Admin", "1")
	rec = httptest.NewRecorder()
	mux.ServeHTTP(rec, post)
	if rec.Code != 400 {
		t.Fatal("unknown action", rec.Code)
	}
}

func TestWorldReportsWhereSheIs(t *testing.T) {
	p, _, _, _ := rig(t)
	p.Brain = brain.New("", 1)
	p.Presence = &physics.Presence{}
	mux := http.NewServeMux()
	p.Mount(mux)
	if w := do(mux, "POST", "/admin/city/report", `{"outside":true,"act":"walk"}`, nil); w.Code != 401 {
		t.Fatalf("report without login: %d", w.Code)
	}
	if w := do(mux, "POST", "/admin/city/report", `{"outside":true,"act":"walk"}`, auth); w.Code != 204 {
		t.Fatalf("report: %d", w.Code)
	}
	if out, act := p.Presence.Outside(time.Now()); !out || act != "walk" {
		t.Fatal(out, act)
	}
	if out, _ := p.Presence.Outside(time.Now().Add(10 * time.Minute)); out {
		t.Fatal("an old report is forgotten")
	}
	w := do(mux, "GET", "/admin/city/state.json", "", auth)
	if !strings.Contains(w.Body.String(), `"sky"`) || !strings.Contains(w.Body.String(), `"rain"`) {
		t.Fatal(w.Body.String())
	}
}

func TestSenseAPI(t *testing.T) {
	p, mux, _, _ := rig(t)
	req := httptest.NewRequest("GET", "/admin/api/sense", nil)
	req.Header.Set("Authorization", "Bearer "+tok)
	rec := httptest.NewRecorder()
	mux.ServeHTTP(rec, req)
	if rec.Code != 404 {
		t.Fatal("off without a sensorium", rec.Code)
	}
	p.Body = body.New(filepath.Join(t.TempDir(), "b.json"))
	p.Sense = sense.New(filepath.Join(t.TempDir(), "s.json"))
	rec = httptest.NewRecorder()
	mux.ServeHTTP(rec, req)
	if rec.Code != 200 || !strings.Contains(rec.Body.String(), `"attended"`) {
		t.Fatal(rec.Code, rec.Body.String())
	}
}

func TestBodyViewCarriesHerRoomAndMotion(t *testing.T) {
	p, _, _, _ := rig(t)
	p.Body = body.New(filepath.Join(t.TempDir(), "b.json"))
	p.Sense = sense.New(filepath.Join(t.TempDir(), "s.json"))
	p.Life = life.New(t.TempDir(), 3)
	p.Life.Do("desk", "тест", time.Now())
	mux := http.NewServeMux()
	p.Mount(mux)
	w := do(mux, "GET", "/admin/body3d/state.json?have=0", "", map[string]string{"Authorization": "Bearer " + tok})
	if w.Code != 200 || !strings.Contains(w.Body.String(), `"boxes"`) || !strings.Contains(w.Body.String(), `"frames"`) {
		t.Fatal(w.Code, w.Body.String()[:200])
	}
	w = do(mux, "GET", "/admin/api/sense", "", map[string]string{"Authorization": "Bearer " + tok})
	if w.Code != 200 || !strings.Contains(w.Body.String(), `"motor"`) || strings.Contains(w.Body.String(), `"frames"`) {
		t.Fatal("the panel summary has her skills but not the recording", w.Code)
	}
}

func TestBodyTastesAreEmptyListsNotNull(t *testing.T) {
	p, mux, _, _ := rig(t)
	p.Body = body.New(filepath.Join(t.TempDir(), "b.json"))
	p.Feel = feel.New(filepath.Join(t.TempDir(), "f.json"))
	req := httptest.NewRequest("GET", "/admin/api/body", nil)
	req.Header.Set("Authorization", "Bearer "+tok)
	rec := httptest.NewRecorder()
	mux.ServeHTTP(rec, req)
	if rec.Code != 200 || strings.Contains(rec.Body.String(), `"dislikes":null`) || strings.Contains(rec.Body.String(), `"likes":null`) {
		t.Fatalf("the page does .length on these: %d %s", rec.Code, rec.Body.String())
	}
}

func TestBodyAPIShowsRegionBrain(t *testing.T) {
	p, mux, _, _ := rig(t)
	p.Body = body.New(filepath.Join(t.TempDir(), "b.json"))
	p.Cortex = cortex.New("", 50000, 3)
	p.Cortex.Step(cortex.Inputs{Hour: 12, Channels: map[string]float64{}})
	req := httptest.NewRequest("GET", "/admin/api/body", nil)
	req.Header.Set("Authorization", "Bearer "+tok)
	rec := httptest.NewRecorder()
	mux.ServeHTTP(rec, req)
	if rec.Code != 200 || !strings.Contains(rec.Body.String(), `"cortex"`) || !strings.Contains(rec.Body.String(), "миндалина") {
		t.Fatal(rec.Code, rec.Body.String()[:200])
	}
}
