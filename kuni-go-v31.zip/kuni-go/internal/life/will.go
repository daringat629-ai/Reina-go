package life

import (
	"fmt"
	"math"
	"math/rand"
	"path/filepath"
	"sync"
	"time"
)

// Action is one thing she did on her own initiative, as a recording of her body in the world: it is what a movement
// comes to when learned parameters run through the simulation (so it can end in a fall).
type Action struct {
	ID      int64     `json:"id"`
	Goal    string    `json:"goal"`
	Reason  string    `json:"reason"`  // why she decided so, in her words
	Outcome string    `json:"outcome"` // what came of it
	OK      bool      `json:"ok"`
	Start   time.Time `json:"-"`
	Dur     float64   `json:"dur"`
	Frames  []Frame   `json:"frames"`
	Props   []Prop    `json:"props,omitempty"` // objects she carries or pushes during the action
}

// Inputs is what the will looks at: her body, her mood and her drives.
type Inputs struct {
	Fatigue, Sleep, Stress, Valence float64
	Night, Studying                 bool
	Drives                          map[string]float64
	Bias                            map[string]float64 // the basal ganglia's leaning per goal (package cortex), -0.5..0.5
}

// Life is her life in the room. Safe for concurrent use.
type Life struct {
	mu       sync.Mutex
	seen     []Option
	bias     map[string]float64
	Room     *Room
	Motor    *Motor
	rng      *rand.Rand
	cur      *Action
	next     time.Time
	nextID   int64
	x, z     float64
	yaw      float64
	posture  string     // stand, sit, lie
	seat     string     // what she sits or lies on
	sleepTil time.Time  // she lies in bed asleep until then
	rise     []Frame    // the frames that took her down, reversed to get up from lying
	sitP     [5]float64 // how she sat, to get up from that pose
	sitAt    [3]float64 // seat x, z, yaw
	sitEnv   SitEnv
	later    []func() // what the world is left like when an action ends (an object put somewhere)
	laterAt  time.Time
	custom   map[string][]Key // movements she invented
	History_ []string
	// Hurt is called when she hurts herself (pain 0..1).
	Hurt func(pain float64)
}

// BodyRadius is her body as a circle for walking.
const BodyRadius = 9.0

// New opens her life in dir.
func New(dir string, seed int64) *Life {
	return &Life{Room: NewRoom(filepath.Join(dir, "room.json")), Motor: NewMotor(filepath.Join(dir, "motor.json"), seed),
		rng: rand.New(rand.NewSource(seed + 1)), posture: "stand", yaw: 0}
}

func standFrame(t, x, z, yaw float64) Frame { return Frame{t, x, 48, z, yaw, 0, 0, 0, 0, 0, 0, 0} }

// place turns frames in a local line (z along the facing direction from origin o) into world frames.
func place(fr []Frame, ox, oz, yaw, t0 float64) []Frame {
	out := make([]Frame, len(fr))
	for i, f := range fr {
		g := f
		g[0] = t0 + f[0]
		g[1] = ox + math.Sin(yaw)*f[3] + math.Cos(yaw)*f[1]
		g[3] = oz + math.Cos(yaw)*f[3] - math.Sin(yaw)*f[1]
		g[4] = yaw
		out[i] = g
	}
	return out
}

func angDiff(a, b float64) float64 {
	d := math.Mod(b-a, 2*math.Pi)
	if d > math.Pi {
		d -= 2 * math.Pi
	} else if d < -math.Pi {
		d += 2 * math.Pi
	}
	return d
}

// turn rotates her on the spot to face yaw.
func turn(t, x, z, from, to float64) ([]Frame, float64) {
	d := angDiff(from, to)
	n := int(math.Abs(d)/(2.5/FPS)) + 1
	var out []Frame
	for i := 1; i <= n; i++ {
		t += 1 / FPS
		out = append(out, standFrame(t, x, z, from+d*smooth(float64(i)/float64(n))))
	}
	return out, t
}

// walkFrames walks the path with a gait. A gait that does not hold up ends in a stumble or a fall on the way.
func walkFrames(path [][2]float64, g [5]float64, t0, yaw0 float64) (fr []Frame, x, z, yaw, t float64, res WalkResult) {
	res = WalkSim(g)
	x, z, yaw, t = path[0][0], path[0][1], yaw0, t0
	if len(path) < 2 {
		return
	}
	stepLen, freq := g[0], g[1]
	th := math.Asin(math.Min(1, stepLen/(2*(Lt+Ls))))
	v := math.Max(25, math.Min(110, stepLen*freq))
	budget := math.Inf(1)
	if !res.OK {
		budget = float64(res.StepsOK) * stepLen
	}
	walked, phase := 0.0, 0.0
	for i := 0; i+1 < len(path); i++ {
		a, b := path[i], path[i+1]
		d := math.Hypot(b[0]-a[0], b[1]-a[1])
		if d < 1e-6 {
			continue
		}
		target := math.Atan2(b[0]-a[0], b[1]-a[1])
		if tf, tt := turn(t, x, z, yaw, target); len(tf) > 0 && math.Abs(angDiff(yaw, target)) > .35 {
			fr, t, yaw = append(fr, tf...), tt, target
		}
		for s := 0.0; s < d && walked < budget; s += v / FPS {
			phase += 2 * math.Pi * freq / FPS
			walked += v / FPS
			x, z = a[0]+(b[0]-a[0])*s/d, a[1]+(b[1]-a[1])*s/d
			yaw += angDiff(yaw, target) * .3
			t += 1 / FPS
			fr = append(fr, Frame{t, x, 47 + .7*math.Cos(2*phase), z, yaw, th * math.Sin(phase), -th * math.Sin(phase),
				g[3] * deg * math.Max(0, math.Cos(phase)), g[3] * deg * math.Max(0, -math.Cos(phase)), g[2] * deg, -g[4] * deg * math.Sin(phase), 0, g[4] * deg * math.Sin(phase), 0})
		}
		if walked >= budget {
			ff := fallFrames(pose{hz: 0, hy: 48}, 0, 0, !res.Forward)
			fr = append(fr, place(ff, x, z, yaw, t)...)
			t += ff[len(ff)-1][0]
			return
		}
	}
	fr = append(fr, standFrame(t+.05, x, z, yaw))
	return fr, x, z, yaw, t + .05, res
}

// goalSeat is where she would sit for a goal: the middle of the seat, the way she faces and the seat itself.
func (l *Life) seatFor(id string) (cx, cz, yaw float64, env SitEnv, ok bool) {
	o := l.Room.Get(id)
	if o == nil {
		return
	}
	switch o.Kind {
	case "chair":
		return o.Pos[0], o.Pos[2], o.Yaw, SitEnv{SeatY: o.SeatY, SeatHalf: 12}, true
	case "bed":
		return o.Pos[0] + o.Size[0]/2 - 4, o.Pos[2] + 20, math.Pi / 2, SitEnv{SeatY: o.Size[1], SeatHalf: 14}, true
	}
	return
}

// Decide lets her choose what to do now, if she is free: she weighs what her body and moods say, adds the chance of her own
// whim and picks. Nothing is scheduled; the same state can lead to different choices.
func (l *Life) Decide(now time.Time, in Inputs) *Action {
	l.mu.Lock()
	defer l.mu.Unlock()
	if len(l.later) > 0 && !now.Before(l.laterAt) {
		for _, f := range l.later {
			f()
		}
		l.later = nil
	}
	if l.cur != nil && now.Before(l.cur.Start.Add(time.Duration(l.cur.Dur*float64(time.Second)))) || now.Before(l.next) {
		return nil
	}
	sit := l.Motor.Skill("sit")
	sitRel := sit.Reliability()
	d := func(n string) float64 { return in.Drives[n] }
	cs := []choice{
		{"desk", "хочу посидеть за столом и поучиться", .5 + .8*d("create") + .3*d("reflect") + map[bool]float64{true: 1, false: 0}[in.Studying]},
		{"practice", "хочу потренироваться садиться: пока выходит не всегда", math.Max(0, (.75-sitRel)*1.6) * map[bool]float64{true: 1, false: .2}[sit.Trials < 400]},
		{"rest", "устала, хочу присесть", .2 + 1.8*in.Fatigue + .5*in.Stress},
		{"sleep", "хочу спать по-настоящему: лечь и выспаться", math.Max(0, 2.2*in.Sleep+1.2*in.Fatigue+map[bool]float64{true: .9, false: 0}[in.Night]-1.6)},
		{"bed", "хочу лечь на кровать", map[bool]float64{true: 1 + 2.5*in.Sleep, false: 3 * math.Max(0, in.Sleep-.7)}[in.Night]},
		{"window", "хочу посмотреть в окно", .35 + .7*d("explore") + .5*d("connect") + .4*d("attach")},
		{"shelf", "хочу подойти к полке с книгами", .3 + .5*d("explore") + .3*d("reflect")},
		{"wander", "хочу пройтись по комнате", .3 + .6*d("explore")},
		{"stay", "хочу просто постоять, подумать", .25 + .4*d("withdraw")},
	}
	cs = append(cs, l.candidates(in)...)
	for i := range cs {
		cs[i].u += in.Bias[cs[i].goal] + l.bias[cs[i].goal]
	}
	l.seen = l.seen[:0]
	for _, c := range cs {
		l.seen = append(l.seen, Option{c.goal, math.Max(0, c.u)})
	}
	var sum float64
	w := make([]float64, len(cs))
	for i, c := range cs {
		w[i] = math.Exp(math.Max(0, c.u) / .55)
		sum += w[i]
	}
	r := l.rng.Float64() * sum
	pick := cs[len(cs)-1]
	for i, c := range cs {
		if r -= w[i]; r <= 0 {
			pick = c
			break
		}
	}
	return l.start(pick.goal, pick.why, now)
}

// Do makes her do a goal now (desk, practice, rest, bed, window, shelf, wander, stay), as if she had decided it: the movement is
// still hers to get right. It is for her own tools and for tests.
func (l *Life) Do(goal, why string, now time.Time) *Action {
	l.mu.Lock()
	defer l.mu.Unlock()
	return l.start(goal, why, now)
}

func (l *Life) start(goal, why string, now time.Time) *Action {
	sleeping := goal == "sleep"
	if sleeping {
		goal = "bed" // sleep is lying down on the bed and staying there
	}
	a := l.plan(goal, why, now)
	l.sleepTil = time.Time{}
	if sleeping && a.OK && l.posture == "lie" {
		l.sleepTil = now.Add(time.Duration(a.Dur*float64(time.Second)) + time.Duration((20+l.rng.Float64()*40)*float64(time.Minute)))
		a.Outcome = "легла и заснула"
	}
	pick := struct{ goal, why string }{goal, why}
	dwell := 25 + l.rng.Float64()*70
	if pick.goal == "practice" {
		dwell = 8 + l.rng.Float64()*20
	}
	l.next = now.Add(time.Duration((a.Dur + dwell) * float64(time.Second)))
	if !l.sleepTil.IsZero() {
		l.next = l.sleepTil
	}
	l.cur = a
	l.History_ = append(l.History_, fmt.Sprintf("%s: %s", pick.why, a.Outcome))
	if len(l.History_) > 12 {
		l.History_ = l.History_[1:]
	}
	return a
}

// plan builds the movement for a goal from what she knows now. Everything she cannot do well enough fails in the simulation.
func (l *Life) plan(goal, why string, now time.Time) *Action {
	l.nextID++
	a := &Action{ID: l.nextID, Goal: goal, Reason: why, Start: now}
	t := 0.0
	var fr []Frame
	hold := func() { fr = append(fr, standFrame(t, l.x, l.z, l.yaw)) }
	cx, cz := l.x, l.z
	// getting up first if she is sitting or lying: from lying she sits up again (the lying-down frames reversed), from the seat she
	// stands up by her own learned skill and can fail
	if l.posture != "stand" && len(l.rise) > 0 {
		if l.posture == "lie" {
			n := int(1.8 * FPS)
			if n > len(l.rise) {
				n = len(l.rise)
			}
			for i := len(l.rise) - 1; i >= len(l.rise)-n; i-- {
				f := l.rise[i]
				t += 1 / FPS
				f[0] = t
				fr = append(fr, f)
			}
			l.rise = l.rise[:len(l.rise)-n]
			l.posture = "sit"
		}
		if l.posture == "sit" {
			g := l.Motor.Attempt("stand", .3)
			res := StandSim(l.sitP, g, l.sitEnv)
			sf := place(res.Frames, l.sitAt[0], l.sitAt[1], l.sitAt[2], t)
			fr = append(fr, sf...)
			t = sf[len(sf)-1][0]
			l.Motor.Learned("stand", g, res.Reward, res.OK, res.Why)
			switch {
			case res.Seated:
				a.Outcome = res.Why
				goal = "_still"
			case res.Fell:
				l.hurt(.1)
				a.Outcome = res.Why
				l.posture, l.seat, l.rise = "stand", "", nil
				last := sf[len(sf)-1]
				l.x, l.z, l.yaw = last[1], last[3], last[4]
				goal = "_still"
			default:
				l.posture, l.seat, l.rise = "stand", "", nil
				last := sf[len(sf)-1]
				l.x, l.z, l.yaw = last[1], last[3], last[4]
			}
		}
	}
	cx, cz = l.x, l.z
	if len(fr) == 0 {
		hold()
	}
	walk := func(tx, tz float64, ignore ...string) (ok bool) {
		path := l.Room.Path(l.x, l.z, tx, tz, BodyRadius, ignore...)
		if path == nil {
			a.Outcome = "не нашла, как пройти"
			return false
		}
		g := l.Motor.Attempt("walk", .35)
		w, x, z, yaw, t2, res := walkFrames(path, g, t, l.yaw)
		fr = append(fr, w...)
		t, l.x, l.z, l.yaw = t2, x, z, yaw
		l.Motor.Learned("walk", g, res.Reward, res.OK, res.Why)
		if !res.OK {
			a.Outcome = res.Why
			l.hurt(.06)
			return false
		}
		return true
	}
	face := func(yaw float64) {
		tf, t2 := turn(t, l.x, l.z, l.yaw, yaw)
		fr, t, l.yaw = append(fr, tf...), t2, yaw
	}
	switch goal {
	case "_still":
	case "desk", "practice", "rest", "bed":
		id := "chair"
		if goal == "bed" {
			id = "bed"
		}
		sx, sz, syaw, env, ok := l.seatFor(id)
		if !ok {
			break
		}
		practice := goal == "practice"
		sp := l.Motor.Attempt("sit", map[bool]float64{true: 1, false: .35}[practice])
		f := [2]float64{math.Sin(syaw), math.Cos(syaw)}
		px, pz := sx+f[0]*sp[0], sz+f[1]*sp[0]
		if !l.Room.Free(px, pz, BodyRadius, id) {
			l.Motor.Learned("sit", sp, -.6, false, "встала так, что упёрлась в мебель")
			a.Outcome = "встала так близко к мебели, что не смогла сесть"
			if l.Room.Free(sx+f[0]*20, sz+f[1]*20, BodyRadius, id) {
				walk(sx+f[0]*20, sz+f[1]*20, id)
			}
			break
		}
		if !walk(px, pz, id) {
			break
		}
		face(syaw)
		res := SitSim(sp, env)
		sf := place(res.Frames, sx, sz, syaw, t)
		for i := range sf { // the sit is local to the seat, the stand point is where she is: both agree by construction
			sf[i][0] = t + res.Frames[i][0]
		}
		fr = append(fr, sf...)
		t = sf[len(sf)-1][0]
		l.Motor.Learned("sit", sp, res.Reward, res.OK, res.Why)
		a.OK, a.Outcome = res.OK, res.Why
		if res.Fell {
			l.hurt(.12)
			l.x, l.z, l.yaw = px, pz, syaw
			break
		}
		if !res.OK {
			l.x, l.z, l.yaw = px, pz, syaw
			break
		}
		if res.Impact > 140 {
			l.hurt(.04)
		}
		l.posture, l.seat = "sit", id
		l.rise = append([]Frame(nil), sf...)
		l.sitP, l.sitAt, l.sitEnv = sp, [3]float64{sx, sz, syaw}, env
		l.x, l.z, l.yaw = sf[len(sf)-1][1], sf[len(sf)-1][3], syaw
		if goal == "bed" { // from sitting on the edge she lies back and turns along the bed
			bed := l.Room.Get("bed")
			last := sf[len(sf)-1]
			for i := 1; i <= int(1.8*FPS); i++ {
				u := smooth(float64(i) / (1.8 * FPS))
				t += 1 / FPS
				g := last
				g[0] = t
				g[1], g[3] = last[1]+(bed.Pos[0]-last[1])*u, last[3]+(bed.Pos[2]+14-last[3])*u
				g[2] = last[2] + (26-last[2])*u
				g[4] = last[4] + angDiff(last[4], 0)*u
				for _, k := range []int{5, 6, 7, 8, 9, 10, 12} {
					g[k] = last[k] * (1 - u)
				}
				g[11] = u
				fr = append(fr, g)
			}
			l.posture = "lie"
			l.rise = append(l.rise, fr[len(fr)-int(1.8*FPS):]...)
			l.x, l.z, l.yaw = fr[len(fr)-1][1], fr[len(fr)-1][3], 0
		}
	case "window":
		if walk(-30, -108) {
			face(math.Pi)
			a.OK, a.Outcome = true, "стою у окна и смотрю на город"
		}
	case "shelf":
		if walk(-122, 50) {
			face(-math.Pi / 2)
			a.OK, a.Outcome = true, "стою у полки с книгами"
		}
	case "wander":
		for tries := 0; tries < 20; tries++ {
			x, z := (l.rng.Float64()*2-1)*(l.Room.HalfX-30), (l.rng.Float64()*2-1)*(l.Room.HalfZ-30)
			if l.Room.Free(x, z, BodyRadius) && math.Hypot(x-l.x, z-l.z) > 50 {
				if walk(x, z) {
					face(l.rng.Float64()*2*math.Pi - math.Pi)
					a.OK, a.Outcome = true, "прошлась по комнате"
				}
				break
			}
		}
	default:
		if l.open(goal, a, &fr, &t, now) {
			break
		}
		face(l.yaw + (l.rng.Float64()-.5)*1.2)
		a.OK, a.Outcome = true, "постояла, подумала"
	}
	_ = cx
	_ = cz
	if len(fr) == 0 {
		hold()
	}
	if a.Outcome == "" {
		a.Outcome = "сделано"
	}
	if len(fr) < 2 {
		fr = append(fr, standFrame(t+1, l.x, l.z, l.yaw))
	}
	a.Frames, a.Dur = fr, fr[len(fr)-1][0]
	l.laterAt = now.Add(time.Duration(a.Dur * float64(time.Second)))
	l.Motor.Saw(goal)
	return a
}

func (l *Life) hurt(p float64) {
	if l.Hurt != nil {
		l.Hurt(p)
	}
}

// Current is the action she is performing or last performed, with how far into it she is.
func (l *Life) Current(now time.Time) (a *Action, elapsed float64) {
	l.mu.Lock()
	defer l.mu.Unlock()
	if l.cur == nil {
		return nil, 0
	}
	return l.cur, now.Sub(l.cur.Start).Seconds()
}

// History is the last things she decided and how they went.
func (l *Life) History() []string {
	l.mu.Lock()
	defer l.mu.Unlock()
	return append([]string(nil), l.History_...)
}

// Posture is stand, sit or lie.
func (l *Life) Posture() string {
	l.mu.Lock()
	defer l.mu.Unlock()
	return l.posture
}

// Moving is true while a walk is in progress.
func (l *Life) Moving(now time.Time) bool {
	l.mu.Lock()
	defer l.mu.Unlock()
	return l.cur != nil && l.cur.Goal != "stay" && now.Before(l.cur.Start.Add(time.Duration(l.cur.Dur*float64(time.Second))))
}

// Prompt is the <movement> block: what she decided, how it went and how good she is at moving.
func (l *Life) Prompt() string {
	l.mu.Lock()
	defer l.mu.Unlock()
	if len(l.History_) == 0 {
		return ""
	}
	sit, walk := l.Motor.Skills["sit"], l.Motor.Skills["walk"]
	last := l.History_[len(l.History_)-1]
	return fmt.Sprintf("<movement>\nТы сама решаешь, что делать в комнате, и движения не заготовлены: ты учишься им пробами и ошибками. Последнее: %s. Сидеть у тебя получается в %.0f%% попыток (всего %d), ходить ровно в %.0f%% (всего %d). Ты сейчас %s. Набор действий не ограничен: потрогать, посмотреть, постучать, толкнуть, взять и переложить любой предмет, любой жест или своё движение (room_look, room_do, invent_move). Дальше своей комнаты ты пока не выходишь: дверь закрыта.\n</movement>\n",
		last, sit.Reliability()*100, sit.Trials, walk.Reliability()*100, walk.Trials, map[string]string{"stand": "стоишь", "sit": "сидишь", "lie": "лежишь"}[l.posture])
}

// WarmUp lets her practise walking by herself before she acts in the room, so that the first carrying or visiting
// does not fail only because she has never walked. It is real trial and error (the same physics), not a preset.
func (l *Life) WarmUp(now time.Time) {
	for i := 0; i < 80 && l.Motor.Skill("walk").Trials < 40; i++ {
		l.Do("wander", "разминка", now)
	}
	// and getting up from the seat, by trials on the same physics
	if _, _, _, env, ok := l.seatFor("chair"); ok {
		sit := [5]float64{}
		copy(sit[:], l.Motor.Skill("sit").Mean)
		for i := 0; i < 200 && l.Motor.Skill("stand").Trials < 120; i++ {
			g := l.Motor.Attempt("stand", .6)
			res := StandSim(sit, g, env)
			l.Motor.Learned("stand", g, res.Reward, res.OK, res.Why)
		}
	}
	l.History_ = nil
}

// Sleeping is whether she lies in her bed asleep now (the body rests faster then, and she wakes up by herself later).
func (l *Life) Sleeping(now time.Time) bool {
	l.mu.Lock()
	defer l.mu.Unlock()
	return l.posture == "lie" && now.Before(l.sleepTil)
}

// Option is one thing she could do and how much she wants it right now.
type Option struct {
	Goal string
	U    float64
}

// Options is what she was choosing between the last time she decided (for the brain's basal ganglia).
func (l *Life) Options() []Option {
	l.mu.Lock()
	defer l.mu.Unlock()
	return append([]Option(nil), l.seen...)
}

// Pos is where she is in the room.
func (l *Life) Pos() (x, z float64) {
	l.mu.Lock()
	defer l.mu.Unlock()
	return l.x, l.z
}

// SetBrain sets the leanings the brain's basal ganglia give to the goals (-0.5..0.5); they add to what she wants in Decide.
func (l *Life) SetBrain(b map[string]float64) {
	l.mu.Lock()
	l.bias = b
	l.mu.Unlock()
}
