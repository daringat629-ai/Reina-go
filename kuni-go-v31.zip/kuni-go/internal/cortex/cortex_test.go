package cortex

import (
	"math"
	"path/filepath"
	"testing"
)

func small() *Cortex { return New("", 60000, 1) }

func calm() Inputs {
	return Inputs{Hour: 14, Oxygen: 1, Glucose: .8, Water: .8, Temp: 36.8, Heart: 70, Breath: 14, Light: .6,
		Channels: map[string]float64{"quiet": .6}, Posture: "stand",
		Choices: []Choice{{"a", 1}, {"b", .5}, {"c", .2}}}
}

func run(c *Cortex, in Inputs, n int) Outputs {
	var o Outputs
	for i := 0; i < n; i++ {
		o = c.Step(in)
	}
	return o
}

func TestRegionsCountAndSize(t *testing.T) {
	if len(Regions) < 30 {
		t.Fatalf("only %d regions", len(Regions))
	}
	c := small()
	if c.Net.Total() < 50000 || c.Net.Total() > 120000 {
		t.Fatalf("total %d", c.Net.Total())
	}
	for _, r := range Regions {
		if c.Net.Count(r.ID) < 1500 {
			t.Fatalf("%s too small", r.ID)
		}
	}
	if len(c.Regions()) != len(Regions) {
		t.Fatal("regions list")
	}
}

func TestBoundedDeterministicNoNaN(t *testing.T) {
	a, b := small(), small()
	oa, ob := run(a, calm(), 20), run(b, calm(), 20)
	for _, r := range a.Regions() {
		if math.IsNaN(r.Act) || r.Act < 0 || r.Act > 1 {
			t.Fatalf("%s act %v", r.ID, r.Act)
		}
	}
	if oa.Arousal != ob.Arousal || oa.Selected != ob.Selected {
		t.Fatal("not deterministic")
	}
}

func TestThreatRaisesAmygdalaAndNE(t *testing.T) {
	c := small()
	base := run(c, calm(), 30)
	in := calm()
	in.Channels = map[string]float64{"threat": 1}
	in.Pain = .7
	hot := run(c, in, 40)
	if hot.Threat <= base.Threat+.1 {
		t.Fatalf("threat %v -> %v", base.Threat, hot.Threat)
	}
	if hot.Mod["NE"] <= base.Mod["NE"] {
		t.Fatalf("NE %v -> %v", base.Mod["NE"], hot.Mod["NE"])
	}
}

func TestHippocampusNoveltyFades(t *testing.T) {
	c := small()
	in := calm()
	in.Channels = map[string]float64{"owner": .9, "praise": .8}
	first := c.Step(in).Novelty
	var last float64
	for i := 0; i < 10; i++ {
		last = c.Step(in).Novelty
	}
	if !(last < first) || c.Outputs().Episodes == 0 {
		t.Fatalf("novelty %v -> %v episodes %d", first, last, c.Outputs().Episodes)
	}
}

func TestBasalGangliaPicksStrongest(t *testing.T) {
	c := small()
	o := run(c, calm(), 5)
	if o.Selected != "a" || o.Bias["a"] <= o.Bias["c"] {
		t.Fatalf("sel %q bias %v", o.Selected, o.Bias)
	}
	for _, v := range o.Bias {
		if v < -.5 || v > .5 {
			t.Fatal("bias out of range")
		}
	}
	in := calm()
	in.Choices = []Choice{{"a", 1}, {"b", 1}, {"c", 1}}
	if run(c, in, 5).Conflict <= o.Conflict {
		t.Fatal("equal options should conflict more")
	}
}

func TestCerebellumLearnsMovement(t *testing.T) {
	c := small()
	in := calm()
	for i := int64(1); i <= 15; i++ {
		in.ActionID, in.ActionKind, in.ActionOK = i, "walk", true
		c.Step(in)
	}
	if c.pred["walk"] < .8 {
		t.Fatalf("pred %v", c.pred["walk"])
	}
}

func TestSleepAtNightAndHormones(t *testing.T) {
	c := small()
	in := calm()
	in.Hour, in.Light, in.Fatigue, in.Sleep = 3, 0, .8, .7
	in.Channels = map[string]float64{"night": 1, "quiet": 1}
	in.Sleeping, in.Alone = true, true
	o := run(c, in, 60)
	if o.SleepUrge < .6 || o.Mod["melatonin"] < .3 {
		t.Fatalf("urge %v mel %v", o.SleepUrge, o.Mod["melatonin"])
	}
	if o.Replayed == 0 {
		t.Log("no replay (hippocampus empty)")
	}
}

func TestPersistenceAndPrompt(t *testing.T) {
	p := filepath.Join(t.TempDir(), "cortex.json")
	c := New(p, 60000, 1)
	in := calm()
	in.Channels = map[string]float64{"owner": 1}
	run(c, in, 5)
	c.Save()
	d := New(p, 60000, 1)
	if d.Outputs().Episodes != 0 && false {
		t.Fatal()
	}
	if len(d.hippo) == 0 {
		t.Fatal("hippocampus not restored")
	}
	if s := c.Prompt(); len(s) < 100 {
		t.Fatalf("prompt %q", s)
	}
	if c.Report("amygdala") == "" || c.Report("zzz") == "" {
		t.Fatal("report")
	}
}
