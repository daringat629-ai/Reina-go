package cortex

import (
	"math"
	"runtime"
	"sync"
)

// pop is the population of one region: N leaky rate neurons. Their synapses are not stored: neuron i of a region takes input from
// neuron hash(seed, edge, i, k) of the source region (k = 0..K-1), so millions of neurons cost only their activity.
type pop struct {
	R     Region
	N     int
	x, nx []float32
	mean  float64
	drive float64 // what the machine logic of the region pushes into every neuron (0..1)
	tonic float64 // its own resting level
	in    []*conn
}

type conn struct {
	Edge
	from, to *pop
	w, w0    float64
	salt     uint64
	preMean  float64
}

// Net is the whole brain: the populations, the wiring and the neuromodulators.
type Net struct {
	mu    sync.Mutex
	seed  uint64
	K     int
	pops  []*pop
	byID  map[string]*pop
	conns []*conn
	Mod   map[string]float64
	Ticks int64
	total int
	work  []chunk
}

type chunk struct {
	p      *pop
	lo, hi int
}

const chunkSize = 1 << 16

func mix(a uint64) uint64 {
	a += 0x9e3779b97f4a7c15
	a = (a ^ (a >> 30)) * 0xbf58476d1ce4e5b9
	a = (a ^ (a >> 27)) * 0x94d049bb133111eb
	return a ^ (a >> 31)
}

// NewNet builds the brain with about total neurons. Each region gets a share proportional to the square root of the size of
// its human counterpart (so that the small nuclei are not empty and the cerebellum does not eat everything), at least minPop.
func NewNet(total int, seed int64) *Net {
	const minPop = 1500
	n := &Net{seed: uint64(seed), K: 5, byID: map[string]*pop{}, Mod: map[string]float64{"DA": .4, "NE": .3, "SE": .5, "ACh": .4, "cortisol": .2, "oxytocin": .2, "melatonin": .1}}
	var sum float64
	for _, r := range Regions {
		sum += math.Sqrt(r.Human)
	}
	for _, r := range Regions {
		c := int(float64(total) * math.Sqrt(r.Human) / sum)
		if c < minPop {
			c = minPop
		}
		p := &pop{R: r, N: c, x: make([]float32, c), nx: make([]float32, c), tonic: .1}
		for i := range p.x {
			p.x[i] = float32(.2 + .1*float64(mix(n.seed^uint64(i)*7)%1000)/1000)
		}
		n.pops = append(n.pops, p)
		n.byID[r.ID] = p
		n.total += c
		for lo := 0; lo < c; lo += chunkSize {
			n.work = append(n.work, chunk{p, lo, min(c, lo+chunkSize)})
		}
	}
	for i, e := range Edges {
		f, t := n.byID[e.From], n.byID[e.To]
		if f == nil || t == nil {
			continue
		}
		c := &conn{Edge: e, from: f, to: t, w: e.W, w0: e.W, salt: mix(n.seed ^ uint64(i+1)*0xabcdef)}
		n.conns = append(n.conns, c)
		t.in = append(t.in, c)
	}
	return n
}

// Total is the number of neurons.
func (n *Net) Total() int { return n.total }

// Count is the number of neurons of a region.
func (n *Net) Count(id string) int {
	if p := n.byID[id]; p != nil {
		return p.N
	}
	return 0
}

// Mean is the activity of a region, 0..1.
func (n *Net) Mean(id string) float64 {
	n.mu.Lock()
	defer n.mu.Unlock()
	if p := n.byID[id]; p != nil {
		return p.mean
	}
	return 0
}

// Drive sets what the machine logic of a region pushes into its neurons (0..1).
func (n *Net) Drive(id string, v float64) {
	n.mu.Lock()
	if p := n.byID[id]; p != nil {
		p.drive = math.Max(0, math.Min(1, v))
	}
	n.mu.Unlock()
}

// gain is how strongly the neuromodulators make a region respond: noradrenaline sharpens the senses and the threat circuits,
// dopamine the frontal and striatal ones, acetylcholine the memory and cortical ones, serotonin calms the limbic ones.
func (n *Net) gain(p *pop) float64 {
	g := 1.0
	switch p.R.Group {
	case "limbic":
		g += .5*(n.Mod["NE"]-.3) - .4*(n.Mod["SE"]-.5)
	case "basal":
		g += .8 * (n.Mod["DA"] - .4)
	case "cortex":
		g += .5*(n.Mod["ACh"]-.4) + .3*(n.Mod["DA"]-.4)
	case "thalamus":
		g += .4 * (n.Mod["NE"] - .3)
	}
	if p.R.ID == "dmn" {
		g -= .3 * (n.Mod["ACh"] - .4)
	}
	return math.Max(.4, math.Min(1.8, g))
}

// Step advances all neurons by one tick (in parallel) and updates the means, the neuromodulators and the plasticity.
func (n *Net) Step() {
	n.mu.Lock()
	defer n.mu.Unlock()
	n.Ticks++
	for _, c := range n.conns {
		c.preMean = c.from.mean
	}
	gains := make(map[*pop]float64, len(n.pops))
	for _, p := range n.pops {
		gains[p] = n.gain(p)
	}
	workers := runtime.NumCPU()
	if workers > 8 {
		workers = 8
	}
	jobs := make(chan chunk, len(n.work))
	for _, w := range n.work {
		jobs <- w
	}
	close(jobs)
	var wg sync.WaitGroup
	tick := uint64(n.Ticks)
	K := n.K
	invK := 1 / float32(K)
	for w := 0; w < workers; w++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for j := range jobs {
				p := j.p
				g := float32(gains[p])
				base := float32(p.tonic + p.drive*.9)
				tau := float32(math.Max(1, p.R.Tau))
				norm := float32(.9 / math.Sqrt(math.Max(1, float64(len(p.in)))))
				for i := j.lo; i < j.hi; i++ {
					h := mix(n.seed ^ uint64(i)*0x9e3779b1)
					bias := (float32(h%1000)/1000 - .5) * .3 // every neuron has its own excitability
					noise := (float32(mix(h^tick)%1000)/1000 - .5) * .04
					var inp float32
					for _, c := range p.in {
						src := c.from
						sn := uint64(src.N)
						var s float32
						for k := 0; k < K; k++ {
							s += src.x[mix(c.salt^uint64(i)*131^uint64(k))%sn]
						}
						v := float32(c.w) * s * invK
						if c.Inh {
							v = -v
						}
						inp += v
					}
					u := (base + inp*norm + bias + noise) * g
					if u < 0 {
						u = 0
					} else if u > 1 {
						u = 1
					}
					p.nx[i] = p.x[i] + (u-p.x[i])/tau
				}
			}
		}()
	}
	wg.Wait()
	for _, p := range n.pops {
		p.x, p.nx = p.nx, p.x
		var s float64
		for _, v := range p.x {
			s += float64(v)
		}
		p.mean = s / float64(p.N)
	}
	// the nuclei release their transmitter in proportion to their activity (slowly: a transmitter lingers)
	for _, p := range n.pops {
		if p.R.Mod != "" {
			n.Mod[p.R.Mod] += (p.mean*1.3 - n.Mod[p.R.Mod]) * .15
			n.Mod[p.R.Mod] = math.Max(0, math.Min(1, n.Mod[p.R.Mod]))
		}
	}
	// dopamine-gated plasticity of the learning pathways: what fires together under dopamine is strengthened
	da := n.Mod["DA"] - .4
	for _, c := range n.conns {
		if c.Learn == 0 {
			continue
		}
		c.w += c.Learn * da * (c.preMean - .25) * (c.to.mean - .25)
		c.w = math.Max(.3*c.w0, math.Min(2.5*c.w0, c.w))
	}
}

// Weights returns the learned strengths of the plastic pathways, for saving.
func (n *Net) Weights() map[string]float64 {
	n.mu.Lock()
	defer n.mu.Unlock()
	out := map[string]float64{}
	for _, c := range n.conns {
		if c.Learn != 0 {
			out[c.From+">"+c.To] = c.w
		}
	}
	return out
}

// SetWeights restores learned strengths.
func (n *Net) SetWeights(w map[string]float64) {
	n.mu.Lock()
	defer n.mu.Unlock()
	for _, c := range n.conns {
		if v, ok := w[c.From+">"+c.To]; ok && c.Learn != 0 {
			c.w = math.Max(.3*c.w0, math.Min(2.5*c.w0, v))
		}
	}
}

// SetMod sets a neuromodulator or hormone level (the slow ones are computed by the pituitary logic, not by a nucleus).
func (n *Net) SetMod(k string, v float64) {
	n.mu.Lock()
	n.Mod[k] = math.Max(0, math.Min(1, v))
	n.mu.Unlock()
}

// Mods returns a copy of the neuromodulator levels.
func (n *Net) Mods() map[string]float64 {
	n.mu.Lock()
	defer n.mu.Unlock()
	out := make(map[string]float64, len(n.Mod))
	for k, v := range n.Mod {
		out[k] = v
	}
	return out
}

// Means returns the activity of every region.
func (n *Net) Means() map[string]float64 {
	n.mu.Lock()
	defer n.mu.Unlock()
	out := make(map[string]float64, len(n.pops))
	for _, p := range n.pops {
		out[p.R.ID] = p.mean
	}
	return out
}
