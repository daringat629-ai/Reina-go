package mir

import (
	"strconv"
	"strings"
	"testing"
)

func testWorld(t *testing.T) *Server {
	t.Helper()
	s, err := Open(t.TempDir(), "Рейна", func() string { return "secret" })
	if err != nil {
		t.Fatal(err)
	}
	return s
}

func TestKeyCheck(t *testing.T) {
	s := testWorld(t)
	if s.keyOK("") || s.keyOK("nope") || !s.keyOK("secret") {
		t.Fatal("key check wrong")
	}
	s.NoPassword = true
	if !s.keyOK("") {
		t.Fatal("NoPassword must let anybody in")
	}
	s.NoPassword = false
	s.Key = func() string { return "" }
	if s.keyOK("") {
		t.Fatal("empty key without NoPassword must deny")
	}
}

// drive runs the builder for up to d of simulated time.
func drive(s *Server, d float64) {
	for i := 0; i < int(d/0.05); i++ {
		s.bot.step(0.05)
	}
}

func TestBuildAndUndo(t *testing.T) {
	s := testWorld(t)
	x, z := 40, 40
	y := s.w.Ground(x, z)
	before := s.w.Block(x+1, y, z+1)
	out, err := s.BotBuild("house", x, 0, z, 7, B("planks"), B("cobble"))
	if err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(out, "строю") {
		t.Fatalf("unexpected: %s", out)
	}
	if _, err := s.BotBuild("tower", x+30, 0, z, 5, 0, 0); err == nil {
		t.Fatal("second job while busy must be refused")
	}
	drive(s, 120)
	if !strings.Contains(s.BotBuildStatus(), "ничего") {
		t.Fatalf("still building: %s", s.BotBuildStatus())
	}
	if s.w.Block(x+1, y, z+1) == before && before == 0 {
		t.Fatal("house not built")
	}
	if got := s.BotUndo(); !strings.Contains(got, "отменяю") {
		t.Fatalf("undo: %s", got)
	}
	drive(s, 120)
}

func TestComposeFillPlace(t *testing.T) {
	s := testWorld(t)
	y := s.w.Ground(10, 10) + 5
	if _, err := s.BotCompose("куб", `[{"t":"box","x1":10,"y1":`+itoa(y)+`,"z1":10,"x2":12,"y2":`+itoa(y+1)+`,"z2":12,"b":"stone"}]`); err != nil {
		t.Fatal(err)
	}
	drive(s, 60)
	if s.w.Block(11, y, 11) != B("stone") {
		t.Fatal("compose did not place")
	}
	if _, err := s.BotFill(0, 1, 0, 100, 100, 100, B("stone")); err == nil {
		t.Fatal("too big fill must fail")
	}
	if _, err := s.BotCompose("x", `[{"t":"box","b":"nonsense"}]`); err == nil {
		t.Fatal("unknown block must fail")
	}
	if look := s.BotLook(); !strings.Contains(look, "Карта сверху") {
		t.Fatal("look has no map")
	}
}

func itoa(n int) string { return strconv.Itoa(n) }

func TestBotTeleportsChangesTimeAndHugsNobody(t *testing.T) {
	s := testWorld(t)
	if out := s.BotTP("", 100, 100); !strings.Contains(out, "x=100") {
		t.Fatalf("tp: %s", out)
	}
	if s.bot.p.x < 99 || s.bot.p.x > 101 {
		t.Fatalf("she did not move: %.1f", s.bot.p.x)
	}
	if _, err := s.BotTime("night"); err != nil || s.w.meta.Time != .75 {
		t.Fatalf("night: %v %.2f", err, s.w.meta.Time)
	}
	if _, err := s.BotTime("12"); err != nil {
		t.Fatal(err)
	}
	if _, err := s.BotTime("abc"); err == nil {
		t.Fatal("bad time must be refused")
	}
	if out := s.BotHug("никого"); !strings.Contains(out, "нет в мире") {
		t.Fatalf("hug: %s", out)
	}
	if maxJob < 3700 {
		t.Fatal("her castle of 3700 blocks must fit")
	}
}
