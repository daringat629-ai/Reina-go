package mir

import (
	_ "embed"
	"encoding/json"
	"fmt"
	"math"
	"net/http"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
)

// The host-facing side of the world: how Reina (the model, through the world tool) drives the builder.
// She commands; the builder walks and lays the blocks by itself, in view of everybody.

//go:embed index.html
var indexHTML []byte

const (
	maxJob  = 40000
	maxFill = 4096
)

// Kinds lists the buildings she knows by name.
const Kinds = "house, tower, pyramid, castle, lighthouse, fountain, garden, windmill, igloo, bridge, statue, temple, tree (ready designs) and wall, platform, lamppost, fence (simple, in a chosen block)"

type undoJob struct {
	name string
	ops  []pb
}

// Open opens (or creates) the world in dir. The builder is called botName.
// key returns the password; empty means nobody may enter (unless the host sets NoPassword).
func Open(dir, botName string, key func() string) (*Server, error) {
	w, err := OpenWorld(filepath.Join(dir, "v2"))
	if err != nil {
		return nil, err
	}
	s := NewServer(w, "")
	s.NoPassword = false
	s.Key = key
	if botName != "" {
		s.bot.p.name = botName
	}
	return s, nil
}

// Mount serves the page and the websocket under /world.
func (s *Server) Mount(mux *http.ServeMux) {
	page := func(rw http.ResponseWriter, r *http.Request) {
		rw.Header().Set("Content-Type", "text/html; charset=utf-8")
		rw.Header().Set("Cache-Control", "no-store")
		_, _ = rw.Write(indexHTML)
	}
	mux.HandleFunc("/world", page)
	mux.HandleFunc("/world/", func(rw http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/world/ws" {
			s.handleWS(rw, r)
			return
		}
		page(rw, r)
	})
}

// SetForceMode makes everyone play "survival" or "creative"; empty = each player chooses.
func (s *Server) SetForceMode(m string) { s.mu.Lock(); s.forceMode = m; s.mu.Unlock() }

// Humans lists the people (not her) in the world now.
func (s *Server) Humans() []string {
	s.mu.Lock()
	defer s.mu.Unlock()
	var out []string
	for _, p := range s.players {
		out = append(out, p.name)
	}
	sort.Strings(out)
	return out
}

// BotAutobuild lets her raise buildings on her own while someone is in the world.
func (s *Server) BotAutobuild(on bool) { s.mu.Lock(); s.autoOff = !on; s.mu.Unlock() }

// BlockByName finds a block by its name or label ("planks", "Стекло").
func BlockByName(n string) (uint8, bool) {
	n = strings.ToLower(strings.TrimSpace(n))
	if n == "" {
		return 0, false
	}
	if id, ok := byName[n]; ok {
		return uint8(id), true
	}
	for _, b := range Blocks {
		if strings.ToLower(b.Label) == n {
			return uint8(b.ID), true
		}
	}
	return 0, false
}

// BlockList is the list of block names for the model.
func BlockList() string {
	var out []string
	for _, b := range Blocks {
		if b.Name != "bedrock" {
			out = append(out, b.Name)
		}
	}
	return strings.Join(out, ", ")
}

func (s *Server) BotGoto(x, z float64) string {
	s.mu.Lock()
	defer s.mu.Unlock()
	if !finite(x, z) {
		return "не получилось"
	}
	b := s.bot
	b.mode, b.tx, b.tz = mGoto, x, z
	return fmt.Sprintf("иду к x=%.0f z=%.0f (до цели %.0f блоков)", x, z, math.Hypot(x-b.p.x, z-b.p.z))
}

func (s *Server) BotFollow(name string) string {
	s.mu.Lock()
	defer s.mu.Unlock()
	o := s.findPlayerL(name)
	if o == nil || o.bot {
		return "игрока " + name + " сейчас нет в мире"
	}
	s.bot.mode, s.bot.follow = mFollow, o.name
	return "иду за " + o.name
}

func (s *Server) BotStop() {
	s.mu.Lock()
	b := s.bot
	if b.mode == mBuild {
		b.queue, b.plan = nil, nil
	}
	b.mode = mWander
	b.tx, b.tz = b.p.x, b.p.z
	s.mu.Unlock()
}

func (s *Server) BotSay(text string) {
	text = strings.TrimSpace(text)
	if r := []rune(text); len(r) > 300 {
		text = string(r[:300])
	}
	if text == "" {
		return
	}
	s.mu.Lock()
	s.sayL(s.bot.p.name, text)
	s.mu.Unlock()
}

// begin queues blocks as a job, remembering what was there for undo. The caller holds s.mu.
func (s *Server) beginRawL(name string, ops []pb) (string, error) {
	b := s.bot
	if b.mode == mBuild && len(b.queue) > 0 {
		return "", fmt.Errorf("я ещё строю %s (осталось %d блоков): дождись (build_status) или останови (build_cancel)", b.plan.name, len(b.queue))
	}
	if len(ops) == 0 {
		return "", fmt.Errorf("нечего строить")
	}
	if len(ops) > maxJob {
		return "", fmt.Errorf("слишком большая работа (%d блоков, не больше %d): раздели на части", len(ops), maxJob)
	}
	var prev []pb
	for _, o := range ops {
		if o.y < 1 || o.y >= CY {
			return "", fmt.Errorf("высота y=%d вне мира (1..%d)", o.y, CY-1)
		}
		if cur := s.w.Block(o.x, o.y, o.z); cur != o.id {
			prev = append(prev, pb{o.x, o.y, o.z, cur, false})
		}
	}
	s.rememberUndoL(name, prev)
	b.plan = &plan{name: name}
	b.queue = ops
	b.mode, b.forName = mBuild, ""
	return fmt.Sprintf("взялась: %s, %d блоков; пойду и выложу сама (build_status — как идёт)", name, len(ops)), nil
}

func (s *Server) rememberUndoL(name string, prev []pb) {
	if len(prev) == 0 {
		return
	}
	s.undoList = append(s.undoList, undoJob{name, prev})
	if len(s.undoList) > 8 {
		s.undoList = s.undoList[1:]
	}
}

func boxPB(o *[]pb, x1, y1, z1, x2, y2, z2 int, id byte) {
	for y := y1; y <= y2; y++ {
		for z := z1; z <= z2; z++ {
			for x := x1; x <= x2; x++ {
				*o = append(*o, pb{x, y, z, id, false})
			}
		}
	}
}

var kindAlias = map[string]string{"castle": "замок", "lighthouse": "маяк", "fountain": "фонтан", "garden": "сад", "windmill": "мельниц", "igloo": "иглу", "bridge": "мост", "statue": "статуя", "temple": "храм", "tree": "дерев", "house": "дом", "tower": "башн", "pyramid": "пирамид"}

// BotBuild builds a whole building by itself. (x,z) is the ground corner; y=0 means "on the ground there".
func (s *Server) BotBuild(kind string, x, y, z, size int, m1, m2 uint8) (string, error) {
	kind = strings.ToLower(strings.TrimSpace(kind))
	if y <= 0 {
		y = s.w.Ground(x, z)
	}
	if m1 == 0 {
		m1 = B("planks")
	}
	if m2 == 0 {
		m2 = B("cobble")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.bot.mode == mBuild && len(s.bot.queue) > 0 {
		return "", fmt.Errorf("я ещё строю %s (осталось %d блоков)", s.bot.plan.name, len(s.bot.queue))
	}
	key := kind
	if k, ok := kindAlias[kind]; ok {
		key = k
	}
	for k, f := range blueprints {
		if strings.Contains(key, k) || key == k {
			pl := f(s.bot.r)
			s.rememberPlanUndoL(&pl, x, y, z)
			s.bot.beginL(pl, x, y, z, "")
			return fmt.Sprintf("строю %s у x=%d z=%d (%d блоков), пойду и выложу сама", pl.name, x, z, len(s.bot.queue)), nil
		}
	}
	if size <= 0 {
		size = 7
	}
	var o []pb
	switch kind {
	case "wall":
		l := max(3, min(size, 60))
		for i := 0; i < l; i++ {
			boxPB(&o, x+i, y, z, x+i, y+2, z, m1)
			if i%2 == 0 {
				boxPB(&o, x+i, y+3, z, x+i, y+3, z, m1)
			}
		}
	case "platform":
		n := max(2, min(size, 30))
		boxPB(&o, x, y-1, z, x+n-1, y-1, z+n-1, m1)
	case "lamppost":
		boxPB(&o, x, y, z, x, y+3, z, m1)
		boxPB(&o, x, y+4, z, x, y+4, z, B("lamp"))
	case "fence":
		l := max(2, min(size, 60))
		boxPB(&o, x, y, z, x+l-1, y+1, z, m1)
	default:
		return "", fmt.Errorf("не умею строить %q, умею: %s", kind, Kinds)
	}
	return s.beginRawL(kind, o)
}

func (s *Server) rememberPlanUndoL(pl *plan, ox, oy, oz int) {
	var prev []pb
	for _, p := range pl.blocks {
		if cur := s.w.Block(ox+p.x, oy+p.y, oz+p.z); cur != p.id {
			prev = append(prev, pb{ox + p.x, oy + p.y, oz + p.z, cur, false})
		}
	}
	s.rememberUndoL(pl.name, prev)
}

// BotCompose builds her own design from a JSON list of parts.
func (s *Server) BotCompose(name, spec string) (string, error) {
	var parts []struct {
		T                      string `json:"t"`
		X1, Y1, Z1, X2, Y2, Z2 int
		X, Y, Z, R             int
		B                      string `json:"b"`
	}
	if err := json.Unmarshal([]byte(spec), &parts); err != nil {
		return "", fmt.Errorf("plan должен быть JSON-списком частей: %v", err)
	}
	var ops []pb
	for i, p := range parts {
		id := byte(0)
		if strings.ToLower(p.T) != "clear" {
			v, ok := BlockByName(p.B)
			if !ok {
				return "", fmt.Errorf("часть %d: нет блока %q", i+1, p.B)
			}
			id = v
		}
		x1, x2, y1, y2, z1, z2 := min(p.X1, p.X2), max(p.X1, p.X2), min(p.Y1, p.Y2), max(p.Y1, p.Y2), min(p.Z1, p.Z2), max(p.Z1, p.Z2)
		switch strings.ToLower(p.T) {
		case "box", "clear":
			if (x2-x1+1)*(y2-y1+1)*(z2-z1+1) > maxJob {
				return "", fmt.Errorf("часть %d слишком большая", i+1)
			}
			boxPB(&ops, x1, y1, z1, x2, y2, z2, id)
		case "hollow":
			if (x2-x1+1)*(y2-y1+1)*(z2-z1+1) > 40000 {
				return "", fmt.Errorf("часть %d слишком большая", i+1)
			}
			for y := y1; y <= y2; y++ {
				for z := z1; z <= z2; z++ {
					for x := x1; x <= x2; x++ {
						if x == x1 || x == x2 || y == y1 || y == y2 || z == z1 || z == z2 {
							ops = append(ops, pb{x, y, z, id, false})
						}
					}
				}
			}
		case "sphere":
			r := min(max(p.R, 1), 14)
			for y := -r; y <= r; y++ {
				for z := -r; z <= r; z++ {
					for x := -r; x <= r; x++ {
						if x*x+y*y+z*z <= r*r {
							ops = append(ops, pb{p.X + x, p.Y + y, p.Z + z, id, false})
						}
					}
				}
			}
		default:
			return "", fmt.Errorf("часть %d: тип %q неизвестен (box, hollow, sphere, clear)", i+1, p.T)
		}
		if len(ops) > maxJob {
			return "", fmt.Errorf("слишком большая постройка (больше %d блоков), раздели на несколько заданий", maxJob)
		}
	}
	sort.SliceStable(ops, func(i, j int) bool { return ops[i].y < ops[j].y })
	if name == "" {
		name = "свой чертёж"
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.beginRawL(name, ops)
}

// BotFlatten levels a rectangle to height y (0 = the height in its middle).
func (s *Server) BotFlatten(x1, z1, x2, z2, y int) (string, error) {
	x1, x2, z1, z2 = min(x1, x2), max(x1, x2), min(z1, z2), max(z1, z2)
	if (x2-x1+1)*(z2-z1+1) > 900 {
		return "", fmt.Errorf("площадка слишком большая (не больше 900 клеток, например 30×30)")
	}
	if y <= 0 {
		y = s.w.Ground(x1+(x2-x1)/2, z1+(z2-z1)/2)
	}
	var ops []pb
	for z := z1; z <= z2; z++ {
		for x := x1; x <= x2; x++ {
			g := s.w.Ground(x, z)
			for yy := y + 8; yy >= max(g, y); yy-- {
				if s.w.Block(x, yy, z) != 0 {
					ops = append(ops, pb{x, yy, z, 0, false})
				}
			}
			for yy := g; yy < y; yy++ {
				ops = append(ops, pb{x, yy, z, B("dirt"), false})
			}
			if g <= y {
				ops = append(ops, pb{x, y - 1, z, B("grass"), false})
			}
		}
	}
	if len(ops) == 0 {
		return "уже ровно", nil
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.beginRawL("выравнивание", ops)
}

// BotUndo brings back what the last job changed.
func (s *Server) BotUndo() string {
	s.mu.Lock()
	defer s.mu.Unlock()
	if len(s.undoList) == 0 {
		return "отменять нечего"
	}
	if s.bot.mode == mBuild && len(s.bot.queue) > 0 {
		return "сначала останови стройку (build_cancel)"
	}
	j := s.undoList[len(s.undoList)-1]
	s.undoList = s.undoList[:len(s.undoList)-1]
	ops := make([]pb, 0, len(j.ops))
	for i := len(j.ops) - 1; i >= 0; i-- {
		ops = append(ops, j.ops[i])
	}
	s.bot.plan = &plan{name: "отмена: " + j.name}
	s.bot.queue, s.bot.mode, s.bot.forName = ops, mBuild, ""
	return fmt.Sprintf("отменяю «%s» (%d блоков)", j.name, len(ops))
}

func (s *Server) BotBuildStatus() string {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.bot.mode != mBuild || s.bot.plan == nil {
		return "сейчас ничего не строю"
	}
	return fmt.Sprintf("строю %s: осталось %d блоков", s.bot.plan.name, len(s.bot.queue))
}

func (s *Server) BotBuildCancel() {
	s.mu.Lock()
	if s.bot.mode == mBuild {
		s.bot.queue, s.bot.plan, s.bot.mode = nil, nil, mWander
	}
	s.mu.Unlock()
}

// BotPlace puts one block (0 = air). She walks up to it herself.
func (s *Server) BotPlace(x, y, z int, id uint8) error {
	if !validBlock(int(id)) && id != 0 {
		return fmt.Errorf("нет блока с номером %d", id)
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	_, err := s.beginRawL("блок", []pb{{x, y, z, id, false}})
	return err
}

// BotFill fills a box (0 = air digs it out); returns how many blocks will change.
func (s *Server) BotFill(x1, y1, z1, x2, y2, z2 int, id uint8) (int, error) {
	x1, x2, y1, y2, z1, z2 = min(x1, x2), max(x1, x2), max(1, min(y1, y2)), min(CY-1, max(y1, y2)), min(z1, z2), max(z1, z2)
	if n := (x2 - x1 + 1) * (y2 - y1 + 1) * (z2 - z1 + 1); n > maxFill {
		return 0, fmt.Errorf("слишком много блоков (%d, не больше %d): раздели на части", n, maxFill)
	}
	var ops []pb
	boxPB(&ops, x1, y1, z1, x2, y2, z2, id)
	s.mu.Lock()
	defer s.mu.Unlock()
	if _, err := s.beginRawL("заливка", ops); err != nil {
		return 0, err
	}
	return len(ops), nil
}

var mapChar = map[string]byte{"grass": 'g', "dirt": 'd', "stone": '#', "cobble": '#', "sand": 's', "gravel": ':', "log": 'T', "leaves": 'T', "planks": 'p', "water": '~', "snow": 'n', "snow_grass": 'n', "sandstone": 's', "ice": '~', "clay": 'c', "cactus": 'C', "brick": 'b', "glass": 'o', "lamp": '*'}

// BotLook describes what she sees: place, people, a small map from above, the latest chat.
func (s *Server) BotLook() string {
	s.mu.Lock()
	b := s.bot
	bx, bz := int(math.Floor(b.p.x)), int(math.Floor(b.p.z))
	by := int(math.Floor(b.p.y))
	var near []string
	for _, p := range s.players {
		d := math.Hypot(p.x-b.p.x, p.z-b.p.z)
		near = append(near, fmt.Sprintf("%s (%.0f блоков, x=%.0f y=%.0f z=%.0f)", p.name, d, p.x, p.y, p.z))
	}
	hist := append([]ChatLine(nil), s.history...)
	mode := ""
	switch b.mode {
	case mGoto:
		mode = fmt.Sprintf("Сейчас иду к x=%.0f z=%.0f.\n", b.tx, b.tz)
	case mFollow:
		mode = "Сейчас иду за " + b.follow + ".\n"
	case mBuild:
		if b.plan != nil {
			mode = fmt.Sprintf("Сейчас строю %s, осталось %d блоков.\n", b.plan.name, len(b.queue))
		}
	}
	t := s.w.meta.Time
	s.mu.Unlock()
	sort.Strings(near)
	var sb strings.Builder
	biome := ""
	if i := s.w.gen.BiomeAt(bx, bz); i >= 0 && i < len(biomeNames) {
		biome = biomeNames[i]
	}
	fmt.Fprintf(&sb, "Я в точке x=%d y=%d z=%d, биом: %s, %s.\n", bx, by, bz, biome, dayWord(t))
	sb.WriteString(mode)
	if len(near) == 0 {
		sb.WriteString("Рядом никого.\n")
	} else {
		sb.WriteString("В мире: " + strings.Join(near, "; ") + ".\n")
	}
	const r = 10
	sb.WriteString("Карта сверху 21×21 (вверх — север, −z; вправо — восток, +x; @ я): g трава, d земля, # камень, s песок, ~ вода/лёд, T дерево/листва, n снег, p доски, C кактус, : гравель, c глина, ? другое.\n")
	for dz := -r; dz <= r; dz++ {
		row := make([]byte, 2*r+1)
		for dx := -r; dx <= r; dx++ {
			id, _ := s.w.SurfaceAt(bx+dx, bz+dz)
			ch, ok := mapChar[Blocks[id].Name]
			if !ok {
				ch = '?'
			}
			row[dx+r] = ch
		}
		if dz == 0 {
			row[r] = '@'
		}
		sb.Write(row)
		sb.WriteByte('\n')
	}
	if n := len(hist); n > 0 {
		sb.WriteString("Последний чат:\n")
		for _, l := range hist[max(0, n-8):] {
			who := l.From
			if who == "" {
				who = "·"
			}
			fmt.Fprintf(&sb, "  %s: %s\n", who, l.Text)
		}
	}
	return sb.String()
}

func dayWord(t float64) string {
	switch {
	case t < 0.05 || t >= 0.95:
		return "рассвет"
	case t < 0.5:
		return "день"
	case t < 0.58:
		return "закат"
	}
	return "ночь"
}

// BotTP puts the builder at a place at once (to a player by name, or to x, z on the ground).
func (s *Server) BotTP(name string, x, z float64) string {
	s.mu.Lock()
	defer s.mu.Unlock()
	b := s.bot
	if strings.TrimSpace(name) != "" {
		o := s.findPlayerL(name)
		if o == nil || o.bot {
			return "игрока " + name + " сейчас нет в мире"
		}
		b.p.x, b.p.y, b.p.z = o.x+.8, o.y+.1, o.z+.8
		b.mode, b.tx, b.tz = mWander, b.p.x, b.p.z
		return "я рядом с " + o.name
	}
	if !finite(x, z) {
		return "не получилось"
	}
	b.p.x, b.p.z = x+.5, z+.5
	b.p.y = float64(s.w.Ground(int(math.Floor(x)), int(math.Floor(z))))
	b.mode, b.tx, b.tz = mWander, b.p.x, b.p.z
	return fmt.Sprintf("я в точке x=%.0f y=%.0f z=%.0f", b.p.x, b.p.y, b.p.z)
}

// BotTime sets the time of day: day, night, or an hour 0..24.
func (s *Server) BotTime(spec string) (string, error) {
	spec = strings.ToLower(strings.TrimSpace(spec))
	var t float64
	switch spec {
	case "day", "день":
		t = .27
	case "night", "ночь":
		t = .75
	default:
		h, err := strconv.ParseFloat(spec, 64)
		if err != nil || h < 0 || h > 24 {
			return "", fmt.Errorf("time: day, night or an hour 0..24")
		}
		t = math.Mod((h-6)/24+1, 1)
	}
	s.mu.Lock()
	s.w.meta.Time = t
	s.broadcastL(map[string]any{"t": "time", "v": t}, -1)
	s.mu.Unlock()
	return "время суток изменено", nil
}

// BotHug walks to a player and hugs them (the world has no animations: she comes close and says so).
func (s *Server) BotHug(name string) string {
	s.mu.Lock()
	o := s.findPlayerL(name)
	if o == nil || o.bot {
		s.mu.Unlock()
		return "игрока " + name + " сейчас нет в мире"
	}
	b := s.bot
	b.p.x, b.p.y, b.p.z = o.x+.7, o.y+.05, o.z+.7
	b.mode, b.tx, b.tz = mWander, b.p.x, b.p.z
	who := o.name
	s.mu.Unlock()
	s.BotSay("*обнимает " + who + "*")
	return "обняла " + who
}
