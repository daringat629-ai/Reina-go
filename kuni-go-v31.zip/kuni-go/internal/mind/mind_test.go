package mind

import (
	"fmt"
	"path/filepath"
	"strings"
	"testing"
)

var cfg = Config{AnswerAlone: true, WithOwner: true, MinTrials: 8, HitRate: .8}

func teach(m *Mind, n int) {
	ins := []string{"привет", "приветик", "привет, как дела", "приветствую"}
	for i := 0; i < n; i++ {
		m.Observe(Situation{Text: ins[i%len(ins)]}, []string{"привет~", "привет, ты", "привет там", "приветик ты"}[i%4], false, cfg)
	}
}

func TestHabitGraduatesAndAnswersAlone(t *testing.T) {
	m := New("", 1)
	if _, ok := m.Try(Situation{Text: "привет"}, Gate{}, cfg); ok {
		t.Fatal("answered with an empty memory")
	}
	teach(m, 40)
	s := m.Stats()
	if s.Graduated == 0 || s.ShadowHit < .8 {
		t.Fatalf("%+v", s)
	}
	got := 0
	for i := 0; i < 40; i++ {
		if out, ok := m.Try(Situation{Text: "приветик"}, Gate{}, cfg); ok {
			got++
			if !strings.HasPrefix(out, "привет") {
				t.Fatal(out)
			}
		}
	}
	if got < 1 || got > 39 { // she does not repeat herself, and the examiner takes some
		t.Fatalf("answered alone %d of 40", got)
	}
	if m.Stats().Independence <= 0 {
		t.Fatal("independence")
	}
}

func TestCalmGateAndSwitches(t *testing.T) {
	m := New("", 1)
	teach(m, 40)
	s := Situation{Text: "привет"}
	for i := 0; i < 20; i++ {
		if _, ok := m.Try(s, Gate{Threat: .9}, cfg); ok {
			t.Fatal("answered alone in danger")
		}
		if _, ok := m.Try(s, Gate{Conflict: .9}, cfg); ok {
			t.Fatal("answered alone in conflict")
		}
		if _, ok := m.Try(s, Gate{}, Config{WithOwner: true}); ok {
			t.Fatal("answered alone while off")
		}
	}
	for i := 0; i < 20; i++ {
		if _, ok := m.Try(Situation{Text: "привет", Owner: true}, Gate{}, Config{AnswerAlone: true}); ok {
			t.Fatal("answered the owner without permission")
		}
	}
}

func TestToolSituationsGoToTheTeacher(t *testing.T) {
	m := New("", 1)
	for i := 0; i < 30; i++ {
		m.Observe(Situation{Text: "найди в интернете погоду в бишкеке"}, "", true, cfg)
	}
	if _, ok := m.Try(Situation{Text: "найди в интернете погоду в бишкеке"}, Gate{}, cfg); ok {
		t.Fatal("answered a task that needs tools")
	}
}

func TestInconsistentTeacherNeverGraduates(t *testing.T) {
	m := New("", 1)
	for i := 0; i < 60; i++ {
		m.Observe(Situation{Text: "как дела"}, fmt.Sprintf("%c%c%c%c%c %c%c%c%c", 'а'+rune(i%26), 'а'+rune((i*7)%26), 'а'+rune((i*11+3)%26), 'а'+rune((i*5+1)%26), 'а'+rune((i*13+2)%26), 'а'+rune((i*3+9)%26), 'а'+rune((i*17+4)%26), 'а'+rune((i*19+6)%26), 'а'+rune((i*23+5)%26)), false, cfg)
	}
	if m.Stats().Graduated != 0 {
		t.Fatalf("%+v", m.Stats())
	}
}

func TestDreamsGradeWithoutTeacherAndPersist(t *testing.T) {
	p := filepath.Join(t.TempDir(), "mind.json")
	m := New(p, 1)
	teach(m, 30)
	before := m.Stats().Teacher
	m.Dream(200, cfg)
	s := m.Stats()
	if s.Dream < 50 || s.DreamHit < .6 || s.Teacher != before {
		t.Fatalf("%+v", s)
	}
	m.Save()
	n := New(p, 1)
	if n.Stats().Episodes != s.Episodes || n.Stats().Graduated != s.Graduated {
		t.Fatalf("%+v vs %+v", n.Stats(), s)
	}
	if _, ok := n.Try(Situation{Text: "привет"}, Gate{}, cfg); !ok && n.Stats().Graduated > 0 {
		// the examiner may have taken this one
		if _, ok2 := n.Try(Situation{Text: "привет"}, Gate{}, cfg); !ok2 {
			t.Log("two examiner hits in a row is unlikely but possible")
		}
	}
}

func TestVoiceAndPrompt(t *testing.T) {
	m := New("", 1)
	teach(m, 30)
	if s := m.Stats(); s.VoiceFit <= .05 {
		t.Fatalf("voice %v", s.VoiceFit)
	}
	if m.Prompt() == "" {
		t.Fatal("prompt")
	}
}

func TestHerVoiceWritesNewAnswersFromKnownWords(t *testing.T) {
	m := New("", 3)
	cc := Config{AnswerAlone: true, WithOwner: true, MinTrials: 8, HitRate: .5, Compose: true}
	known := map[string]bool{}
	outs := []string{"ок, понял тебя~", "ага, понял~", "ок, давай попробуем~", "ага, давай тебя послушаю~"}
	for i := 0; i < 40; i++ {
		o := outs[i%4]
		known[o] = true
		m.Observe(Situation{Text: []string{"сделай так", "сделай вот так", "давай так сделаем", "сделаем так"}[i%4]}, o, false, cc)
	}
	m.compose = true
	fresh := 0
	for i := 0; i < 20; i++ {
		for _, c := range m.composeAnswers(outs, []float64{.9, .9, .9, .9}, 8) {
			if !known[c] {
				fresh++
			}
			for _, w := range toks(c) {
				if m.uni[w] == 0 {
					t.Fatalf("invented a word %q", w)
				}
			}
		}
	}
	if fresh == 0 {
		t.Fatal("never wrote anything new")
	}
	if g, ok := m.predict("сделай так", nil, nil); !ok || g.text == "" {
		t.Fatal("no prediction")
	}
	m.Dream(100, cc)
	if m.Stats().Dream == 0 {
		t.Fatal("no dreams")
	}
}
