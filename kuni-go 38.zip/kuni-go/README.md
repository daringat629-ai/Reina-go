# kuni-go

Go-порт [Kuni](https://github.com/Alex2772/kuni) (C++). Только стандартная библиотека Go 1.24+, без внешних зависимостей.

Все модули из оригинала перенесены и **соединены в один рабочий цикл**:

```
Telegram ──updates──▶ agent ──▶ LLM ◀──tool calls──▶ tools ──▶ Telegram / diary / web / SD / TTS
                        │                                   ▲
                        ├─ RAG: diary (embeddings) ─────────┘
                        └─ idle → дамп сессии → diary + working memory
OpenAI-клиент ──▶ proxy (контекст, ask-tool, tool-loop) ──▶ upstream LLM
```

## Что есть

| C++ (`src/`) | Go (`internal/`) | |
|---|---|---|
| `config.cpp`, toml11, hot-reload | `config/` — свой парсер TOML-подмножества, опрос mtime | ✔ |
| `prompts.cpp` (13 промптов) | `prompts/` — **оригинальные тексты дословно** (`defaults/*.md`), `${VARS}`, hot-reload | ✔ |
| `OpenAIChatImpl`, streaming | `llm/` — chat, tool calls, vision-части, SSE, embeddings | ✔ |
| `Diary.cpp` | `diary/` — RAG, «сон» (консолидация) | ✔ |
| working memory, `diaryDumpMessages` | `memory/` — дамп сессии в дневник + обновление `working_memory.md`, антиплагиат | ✔ |
| `telegram/` (tdlib) | `telegram/` — интерфейс `Client`; **пользовательский аккаунт через tdlib** (`td.go`, как в оригинале), запасной Bot API-клиент, in-memory Fake | ⚠ tdlib не прогонялся с реальной библиотекой |
| `tools/*` (все 20) | `tools/` — реестр + все инструменты, наборы под тип чата (канал / не участник / группа / админ) | ✔ |
| `llmui/` | `llmui/` — `<message>`/`<chat>`, голосовые → STT, фото/стикеры → описание, видео → кадры+аудио, защита от инъекции `kuni_embedding` | ✔ |
| `ImageGenerator.cpp` | `imagegen/` — prompt-engineer → Stable Diffusion → LLM-критик, ретраи | ✔ (упрощён) |
| Whisper, TTS, ElevenLabs, web search, ffmpeg | `media/` | ✔ |
| `main.cpp`, `App`, `Worker` | `agent/` + `main.go` — сессии по чатам, дебаунс, lockdown, acting proactively, дамп при простое/выходе | ✔ |
| `proxy_server/` | `proxy/` — инъекция контекста, tool-loop для `ask`, SSE, passthrough, `MessageInjector`, `ContextBridge` | ✔ |
| `Prometheus.cpp`, Grafana | `metrics/` — `/metrics`, имена `llm_usage_*`, `tool_call_*` как в дашборде | ⚠ |
| AUI debug-окно | `debugui/` — веб-страница `/debug` | ✔ |
| `docker-compose.yml`, `ollama_setup.sh`, `grafana/` | скопированы как есть | ✔ |

## Запуск

```bash
go build -tags tdlib -o kuni .     # пользовательский режим (нужна libtdjson, см. ниже)
# или без tdlib — только режим bot и прокси:
go build -o kuni .
./kuni            # первый запуск создаёт config.toml и выходит
```

В `config.toml`: `[llm]` base_url/model; `[general] telegram_enabled = true`; `[telegram]`:
- `mode = "user"` (по умолчанию, как в оригинале) — `api_id`/`api_hash` с https://my.telegram.org, `phone_number`
  (или ввод в консоль). Код и облачный пароль запрашиваются в stdin при первом входе, сессия хранится в `tdlib_dir`.
- `mode = "bot"` — только `bot_token` от @BotFather.

### Установка libtdjson для режима user
```bash
git clone https://github.com/tdlib/td && cd td && mkdir build && cd build
cmake -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX=/usr/local .. && cmake --build . --target install -j4
# нужны: cmake, gperf, g++, libssl-dev, zlib1g-dev
cd /путь/к/kuni-go && go build -tags tdlib -o kuni .   # при нестандартном пути: CGO_LDFLAGS=-L<dir> CGO_CFLAGS=-I<dir>
```
Нужна версия tdlib с `setChatMemberTag` (свежий master, как в C++ проекте) и `td_send`/`td_receive` (1.8.0+).

```bash
go test ./... && go test -race ./...
```

Каталог `prompts/` создаётся при первом запуске; редактируйте файлы там — они подхватываются без перезапуска
(правка кода промптов не нужна, как и в оригинале). Прокси, `/metrics` и `/debug` слушают порт `[proxy] port` (10434).

## Честно о том, что отличается и что не проверено

**Проверено тестами с фейками** (фейковый LLM, фейковый Bot API, реальный ffmpeg): агент, инструменты, прокси, дневник,
конфиг, промпты, метрики, клиент Bot API, медиа-клиенты. **Не запускалось** против настоящих Telegram, Ollama/DeepSeek,
Stable Diffusion, Whisper и TTS — это первый шаг, который стоит сделать вам.

**Telegram: пользовательский аккаунт через tdlib.** `telegram.TDClient` говорит с tdlib по JSON-интерфейсу
(`td_json`), как C++ `TelegramClientImpl`: вход по телефону/коду/паролю, `getChats`/`getChatHistory`/`viewMessages`
с `force_read`, реакции, пересылка, правка текста и подписей, `setChatMemberTag`, `banChatMember`, блокировка и удаление
личного чата, контакты для `lockdown = contacts_only`, статус «онлайн» только пока идёт обработка, троттлинг до 20
запросов/с (Telegram банит агрессивных сторонних клиентов). Тонкая cgo-обёртка над `libtdjson` лежит в
`td_cgo.go` (тег `tdlib`); вся логика — в чистом Go поверх интерфейса `Transport`.

**Что проверено, а что нет:** логика клиента проверена 12 тестами на скриптованном фейковом tdlib (вход, преобразование
сообщений, **id > 2^53 и int64-как-строки**, формы всех запросов, смещения истории, права в группах, троттлинг), а cgo-слой
собран и прогнан со **стаб**-библиотекой. С *настоящей* libtdjson и аккаунтом Telegram он **не запускался** (в моей среде
нет сети для сборки tdlib). Названия полей tdlib написаны по памяти схемы `td_api` — на живом аккаунте возможны мелкие
расхождения (в первую очередь: `reply_to`, `topic`-поля, `setChatMemberTag`); ошибки tdlib возвращаются модели
как текст, так что их будет видно в логах.

**Режим bot (запасной).** Бот видит только адресованные ему сообщения и историю с момента запуска; не умеет вступать
в чаты, блокировать, управлять «онлайн»/«прочитано». `setChatMemberTag` в Bot API я не сверял.

**Упрощения относительно C++:**
- `imagegen`: 6 попыток вместо сложной схемы с галереей; нет повторного добавления откровенных слов в промпт
  (намеренно), «ребёнок» всегда в negative prompt.
- прокси: цикл tool-call'ов идёт в не-стримовом режиме, SSE для клиента синтезируется; `streaming_filter` не переносился.
- метрики: нет гистограммных bucket'ов (панели с `histogram_quantile` останутся пустыми); цель Prometheus —
  `host.docker.internal:10434`.
- стикеры в user-режиме: вместо «избранных» tdlib используется свой набор `data/stickers.json` (`sticker_save`);
- ключи `config.toml` другие и **не совместимы** со старым файлом.
- веб-поиск: SearXNG (`/search?format=json`) или Ollama web_search.

**Отличие поведения.** В C++ обработанная в «сне» запись-цель, судя по коду, не удалялась с диска (дубли копились);
в Go она удаляется, если `confidence < 1` (записи с `confidence = 1` — «факты» — неприкосновенны).

## Пресет персонажа: Reina Veil

Готовый пресет лежит в `examples/reina_veil/`. Чтобы включить: скопируйте оба файла в `prompts/`
(`cp examples/reina_veil/*.md prompts/`; там же компактные `system.md` и `character_base.md`, экономят ~40% токенов), в `config.toml` задайте `character_name = "Reina Veil"`.
Горячая перезагрузка подхватит файлы без перезапуска.

## Экономия токенов

- `[misc] lazy_tools = true` — редкие инструменты (медиа, правка/удаление, админка, поиск сообщений) скрыты за одним
  `more_tools`; список инструментов в приватном чате ~2,1k → ~1,1k токенов. Медиа открывается автоматически, если во
  входящем есть фото/голос/стикер или слова «фото, голос, стикер…».
- `[memory] history_keep = 24` — когда в сессии набирается вдвое больше сообщений, старая часть сжимается в краткую
  сводку (последние 24 остаются дословно). `0` — отключить.
- Продолжающаяся сессия не повторяет «earlier messages» целиком на каждом ходу.
- Метрика `kuni_llm_tokens_total{model,purpose,direction}` (purpose: reply / ask / diary / sleep / compact / image) и
  `kuni_llm_last_prompt_tokens{purpose}` — видно, на что уходят токены.

## Промпты по умолчанию

В сборку зашиты короткие промпты Рейны Вейл (`internal/prompts/defaults/`: system, character_base, character_appearance;
остальные 10 — оригинальные). При первом запуске они записываются в `prompts/`. Оригинальные промпты Куни лежат в
`examples/kuni_original/`. Если в `prompts/` уже есть старые файлы, программа их не перезаписывает: удалите нужные
(`rm prompts/system.md prompts/character_base.md prompts/character_appearance.md`) и перезапустите.

## Как она пишет

- `[telegram] max_message_chars = 60` — одно сообщение не длиннее 60 символов; длинный текст режется на несколько
  (по концу предложения или пробелу), число сообщений не ограничено. `0` — без нарезки.
- `typing_min_ms = 3000`, `typing_max_ms = 4000` — перед каждым сообщением показывается «печатает…» 3–4 секунды.
- В промпте: собственная воля (может согласиться, отказать, подразнить, проигнорировать), играет только когда сама захочет,
  не ведёт себя как ассистент.

## Автозапуск и логи (Alpine)

```
cp deploy/reina.openrc /etc/init.d/reina && chmod +x /etc/init.d/reina
rc-update add reina default
rc-service reina start     # логи: /var/log/reina.log
apk add logrotate && cp deploy/reina.logrotate /etc/logrotate.d/reina
```

Скорость: `stop_after_send` (не делать лишний вызов модели после ответа), `typing_while_thinking`
(«печатает» пока модель думает), `debounce_ms` (800). Запросы к модели автоматически повторяются
при 429/5xx и сетевых сбоях.

## Autonomous mode

`[autonomy] enabled = true` (or the switch on the panel's Status tab) lets her act on her own: every `min_interval_mins`..`max_interval_mins`
(random) she looks through her chats and decides to write first, speak her mind, `go_to_sleep`, or do nothing. Hard limits are enforced in
code, not in the prompt: no initiatives during `quiet_from`..`quiet_to` (in `timezone`, e.g. `Asia/Bishkek`) or while asleep, at most
`max_messages_per_day`, `chat_cooldown_mins` between messages to the same chat, and `lockdown` still decides which chats she may touch.
Your own chat is never limited. Everything she does on her own lands in `data/autonomy.log` (shown on the Status tab); "Разбудить" ends a sleep.

## Diary book

The panel's **Дневник** tab shows the diary as a 3D book: entries oldest to newest, one spread on wide screens and a single page on phones.
Turn pages by tapping the page edge, swiping, the ‹ › buttons, the slider or the arrow keys.

## Messages, people and groups

* Long messages are split like a person texts: per line, then per sentence, then at the best clause boundary; no dangling "и/в/to", no tiny
  tails, links and emoji stay whole (`telegram.max_message_chars`).
* `chat_members` (who is in a group, who is an admin, who is you/the owner) and `user_info` (profile by id) help her not to mix people up.
  In groups every message shows what it replies to and whether it is addressed to her (`addressed_to_you`).
* `llm.light_model` runs background thinking (`ask`, sleep, diary, history compaction) on a cheaper model; replies stay on `llm.model`.

## Server care: disk, spend, backups

* **Disk.** Every 10 minutes she checks the free space (`[maintenance]`): under `disk_warn_percent` (or under 500 MB) she clears cached image
  descriptions older than `cache_days` and, if it is still low, writes to you once a day.
* **Backups.** Daily `data/backups/reina-*.tar.gz` (diary, memory, prompts, mood, config; mode 0600 because the config holds your keys),
  newest `backup_keep` kept; "Сделать бэкап сейчас" on the Status tab makes one on demand.
* **Spend.** The Status tab shows tokens and dollars for today (set `llm.price_in_per_m` / `price_out_per_m`, and the light_* pair).
  `llm.daily_token_limit` > 0: past it she stops acting on her own and tells you; at 3x every LLM request is refused until tomorrow.

## Living presence and richer Telegram

**Presence** (`[presence]`, on by default). She does not answer instantly: she notices a message after a pause
(`read_delay_min_secs`..`read_delay_max_secs`; groups wait longer, a live conversation and your own chat are quick),
shows "online" only while she is busy (`offline_after_secs`), and types as long as the text takes
(`telegram.typing_per_char_ms`, capped by `typing_max_ms`). At night (autonomy quiet hours) `late_reply_percent` of
messages from other people are answered 5-40 minutes later; while she is asleep always. Your chat is never delayed.

**More content she understands.** Links: `read_link` opens public pages only (never localhost, LAN, Tailscale or
cloud metadata addresses; redirects and DNS tricks are checked at connect time), long pages are read in parts.
Documents from anyone up to `capabilities.document_max_mb`: txt, md, csv, json, docx, xlsx, odt and pdf
(`read_document`; PDF needs `pdftotext`: `apk add poppler-utils`). Images sent "as a file", round videos and gifs are
seen like photos/videos (`media_max_mb` limits the size). Reactions on her messages and edits of other people's messages
appear as short notes in her next turn (no extra paid model call); reactions nudge her mood a little.

**Groups.** Forum topics: messages show `topic_id` and her answers stay in the topic of the message she replies to.
`create_poll`, `vote_poll`, `pin_message`/`unpin_message` (pin only where she is admin). Tagging: `@username`, or
`[Name](tg://user?id=ID)` for people without a username. Voice message in, voice message out (when TTS is on) and a
sticker for a sticker (`telegram.mirror_modality`).

**Reliability.** Telegram flood waits (429) are waited out and the request repeated. The panel's Status tab shows who
is waiting for an answer and why, the flood-wait state and the last failed requests.

**Token budget.** Each request carries the session history, so it is kept small: instructions, mood, recalled
memories and the member roster are removed from every message except the newest, old tool results are cut
(`memory.old_tool_result_chars`), and the history is limited to `memory.context_chars` (default 32000 characters,
about 6k tokens). Old history is summarised (light model first, then the main one) and simply dropped if that keeps
failing. In groups she wakes the model only when she is addressed — a reply to her, her name or @nick, or the owner
(`telegram.group_reply_mode = "addressed"`, `group_chime_percent` lets her sometimes join anyway); other messages are
just read. `telegram.group_debounce_secs` batches group bursts. `llm.daily_token_limit` remains the hard stop.

**Upgrade: cheaper, safer, more alive.**
- *Cost.* In the owner's chat only the everyday tools are loaded (the rest unlocks by the words used, or via
  `more_tools`); `llm.cache_prompt` marks the system prompt cacheable for Claude models, other providers cache the stable
  prefix themselves, and the panel's token table shows requests, the average prompt size and the cached share.
  A daily report (`[report] enabled / hour`) tells the owner yesterday's tokens, requests, cost and free disk; the Status
  tab draws a 14-day chart. When the disk runs low the warning names the biggest directories.
- *Safety.* `capabilities.shell_user` runs her shell as an unprivileged user (`adduser -D reina`, then set it; it never
  falls back to root on a mistake). An optional hard floor (`capabilities.shell_hard_block`, off by default) refuses `rm -rf /`, formatting disks,
  `dd` onto devices, fork bombs, shutdown/reboot, `curl | sh` and deleting her own data, even for the owner; blocked
  attempts are journaled and shown in the Commands tab.
- *Life.* `remind` (delays like 45m, 2h, or 18:30, tomorrow 09:00) wakes her in the chat when it is due; `shell_bg` runs long
  commands in the background and wakes her with the exit code and the end of the output; `join_by_link` and
  `send_to_chat` work from the owner's chat. Person cards (`remember_person`) hold a few durable facts per person and
  appear only in that person's conversations; facts from private chats are never shown in groups. The People tab edits
  them, the Dialogs tab shows what she saw and wrote in every open chat.
- *Tone.* Per-audience tone lines (owner, contacts, strangers, groups) sit in each chat's instructions.

## Long conversations

A talk can run for days. Three layers keep it coherent without growing the request:

- **Rolling summary.** Once a session passes `memory.history_keep` (30) ×2 messages (or 2× `memory.context_chars`, 32000), the old part is folded into one `<conversation_so_far>` message of up to 350 words. The previous summary is handed to the summariser, so old facts, plans and promises are carried forward instead of being re-summarised into nothing. The summary is pinned: neither the 80-message trim nor the character budget can drop it. If summarising fails, the previous summary is kept.
- **Carry-over.** After `telegram.session_idle_secs` of silence the session is written to the diary and working memory, and its summary waits 24 h in memory; when the person writes again the new session starts from it, plus the last 16 messages of a private chat read from Telegram.
- **Long-term.** Diary RAG, working memory and person cards, as before.

Limit: the carried summary is kept in memory only, a restart falls back to the diary.

## Browser and the whole Telegram toolbox (owner only)

**`browser`** is a real Chromium she drives through the DevTools protocol (no Node, no Playwright, stdlib only). One tool, actions
`open | look | click | type | key | scroll | back | text | send | close`. Every action returns the page as a short text: address, title, a
**numbered list of what is on screen** (links, buttons, fields, selects) and the start of the visible text, so she clicks "7" instead of
guessing coordinates; `text` pages through the rest of the page; `send` makes a screenshot (visible part or the whole page) and sends it
to the chat (a copy stays in `workspace/browser/`, `tg_api send_photo` can forward it elsewhere). The profile lives in
`<data_dir>/browser-profile`, so logins survive restarts. JavaScript alerts are closed automatically, popups and `target=_blank` links
open in the working tab, downloads are refused, only http(s) addresses are opened. The browser starts on first use and closes itself after
`browser.idle_secs` of silence.

Install it: Alpine `apk add chromium font-noto` (fonts for Cyrillic; add `apk add xvfb` for the graphical mode), then it works at once.
`browser.xvfb = true` runs it with a real window on a virtual screen nobody sees instead of headless.

Not looping, and quick:
- `browser.max_steps` (20) actions per message of the owner; he says "continue" and gets the next batch.
- A loop guard compares the page after every action: the same page twice in a row gets a warning, three times (or the same page five
  times in an A-B-A-B walk) ends the browsing for this message and she must report.
- `browser.fast`: rounds that follow a browser step run with reasoning off (`llm.WithReasoning`), and fall back to normal if the provider refuses.
- Browser rounds are paid by `browser.max_steps`, not by `telegram.max_tool_rounds`; only the newest page stays whole in the history, older ones shrink to a header.
- The tool unlocks by words ("браузер", "сайт", "скриншот", a link, "погугли"...) or `#more_tools "browser"`.

**`tg_api`** is the whole Telegram toolbox for any chat in one tool: `history` (with `message_id` to walk back through a whole chat page by page),
`around`, `search`, `chat_info`, `members`, `user`, `send`, `send_file`, `send_photo`, `edit`, `delete`, `forward`, `react`, `pin`, `unpin`,
`read`, `leave`, `ban`. It ignores lockdown, as the other owner tools do, and is registered in the owner's private chat only.
The daily clean-up also trims the browser cache and old screenshots.

### YouTube and logged-in sites

- **Login without a password.** The owner exports the cookies of his browser (the Cookie-Editor extension: Export → JSON, or a `cookies.txt`),
  sends the file to the chat, and she runs `browser action=cookies path=<file>`. The cookies go into the browser profile (they survive
  restarts), and the file is deleted at once. Typing into password fields is refused (`browser.allow_passwords`, off), so a password never goes
  through the chat or the model. Google may end a session when the IP changes; then she asks for a fresh export.
- **`videos`** lists the video cards on the page (home, search, recommendations, playlists, history) with title, channel, length, views and a clean
  link; scroll to load more. **`transcript`** gives title, channel, length, description and what the video says (its subtitles, in blocks of 30 s
  with timestamps, preferring the language in `text`), paged with `offset`: that is how she "watches" a video and judges whether he would like it.
  Videos without subtitles give only the facts and the description.
- **Guard.** `browser.block_hosts` (default: Google account settings, sign-in, payments, passwords, wallet) are never opened, and if a click lands there
  she steps back. The prompt tells her to only look, search and open on his accounts.
- Not verified against the live YouTube (the sandbox has no access to it): the page readers use several selectors plus a plain-link fallback;
  if YouTube changes its markup, send a screenshot of what she says.

## More hands (owner only)

- **Eyes.** `llm.vision_model` is the model that looks at pictures (photos and stickers in chats, browser screenshots); empty = the main model.
  Use a cheap model with image input (e.g. `google/gemini-2.5-flash`), the text-only main model can stay as it is. In the browser `action=see`
  takes a screenshot and a vision model describes it (with her question): for pictures, charts, canvases and captchas.
- **`web_search`** uses the configured SearXNG/Ollama search, or DuckDuckGo's HTML page without any key when none is set up.
  **`read_file`** turns pdf, docx, xlsx, odt, csv, code and text files of her machine into text (paged by 8000 characters).
- **`http_request`** calls an API. Services live in `integrations.services` (write-only in the panel), format `name|base url|Header: value`, several
  separated by `;`, e.g. `github|https://api.github.com|Authorization: Bearer ghp_xxx`. She passes `service` + `path`; the program adds the key, a
  redirect to another host is refused, and the key is blanked out of anything the API echoes back. Without a service only GET to public addresses works.

## Mail and calendar (owner only)

- **`mail`**: `inbox` (list, filters: unseen, from, subject, text, since), `read` (one letter, paged), `send`. Reading is strictly read-only
  (IMAP `EXAMINE` + `BODY.PEEK`: nothing is marked as read). Sending: at most `mail.send_per_day` letters a day (default 10, log in
  `<data>/mail-sent.log`), up to 5 recipients, header injection is refused. Settings: `mail.imap_host` (`imap.gmail.com`), `mail.smtp_host`
  (`smtp.gmail.com:587`), `mail.user`, `mail.password` (write-only), `mail.from`. For Gmail turn on 2-step verification and create an
  *app password*; the normal password does not work.
- **`calendar`**: read-only, from iCal feeds in `calendar.ics_urls` (write-only, several separated by commas or spaces). Google Calendar:
  Settings → the calendar → "Secret address in iCal format". Repeating events (daily, weekly with days, monthly, yearly, COUNT/UNTIL/EXDATE)
  are expanded; times are shown in the owner's timezone.
- Both are registered in the owner's private chat only, and the credentials never reach the model.

## Desktop (owner only)

- **`desktop`** is a virtual screen (Xvfb) with real graphical programs, nobody has to watch. `launch` starts a program through the same shell
  rules as `shell` (the hard-block list applies), `look` lists windows, `see` sends the screen with a pixel grid to the vision model and returns what
  is where (set `llm.vision_model`), `click`/`move`/`drag`/`type`/`key`/`scroll` act with the mouse and keyboard (Cyrillic and any symbols
  work), `send` posts a screenshot to the chat, `close` shuts everything.
- Switch it on with `desktop.enabled`; settings `desktop.width/height/max_steps/idle_secs`. Install on Alpine: `apk add xvfb` plus the programs you
  want (`chromium font-noto`, `libreoffice`, ...). The same guards as the browser: a step limit per message and a stop when the screen stops changing.
- Programs started by her run as the shell user (`capabilities.shell_user` if set): keep files you care about out of reach of that user.

## Background work (owner only)

- **Queue.** The owner tells her in the private chat: "take such an order on Kwork, do X" and she queues it with `work add` (stored in
  `<data>/work.json`, survives restarts). `work list/show/note/done/ask/answer/cancel` manage it.
- **Runs.** With `work.enabled` (off by default) the program wakes her every `work.every_mins` minutes for one *run* on the oldest running or
  queued job, in a session of its own (the owner's chat never waits behind a job), with the browser and the desktop unlocked. She ends a run with
  `work note` (what she did, what is next: the next run starts from the notes), `work done` or `work ask`.
- **Limits enforced by the program, not the prompt.** `work.max_runs_per_day` runs over all jobs; at most 6 runs per job (the owner's answer to a
  question gives 3 more); a job that used its runs is parked with a question; the run is skipped when the agent is paused or the daily
  `llm.daily_token_limit` is hit; the browser/desktop step limits and loop guards apply inside a run.
- **Asking first.** `work done` and `work ask` message the owner directly (not through the model's wording): "Готово: …" and "ждёт тебя: …".
  The prompt forbids paying, registering, accepting terms and writing in his name to strangers without his yes; remember that is the model's
  discipline, so give her a separate mailbox, a separate browser profile (cookie import) and no card. Platforms may forbid automated accounts:
  check their rules before letting her work under your name.
- The panel's dialogs list shows the background session as «фоновая работа».

## Commands without the model (owner only)

Slash commands from the owner's private chat are answered by the program itself, at once, with no model call: they work when she is paused,
stuck or out of tokens. They are removed from what the model reads (an old command in the backlog is never run late).

`/help`, `/status` (state, uptime, sessions, tokens and cost today, background work and runs, browser/desktop, last backup),
`/pause` and `/resume`, `/stop` (pause + close the browser and the desktop; a turn already in flight finishes), `/usage`,
`/work` (queue; `/work cancel 3`; `/work answer 3 да, плати 500`), `/backup` (backup now).

**Backups.** The daily on-disk backup now also holds people, reminders and the job queue. With `maintenance.backup_send` (on) a copy
**without config.toml** (keys, passwords) is sent to the owner's private chat once a day: the only copy that survives a dead container. Keep it
off the server. The on-disk archive still contains the config (mode 0600).

## Speed: thinking only where it matters

Reasoning models spend most of the time thinking. With `llm.fast_rounds` (on) the program switches the reasoning off for every round that
follows a tool result (the answer is already decided, only the next step is needed) and, with `llm.fast_short_chars` (220), also for the first
round of a short private line without files or media. Long messages, photos, files, groups and background jobs still think on the first
round. If a fast round fails the request is repeated with normal reasoning. Turn `llm.fast_rounds` off if she gets sloppy at multi-step work;
`llm.reasoning = off` switches thinking off everywhere.

## Live view: the «Эфир» tab of the panel

Watch what she does, as it happens (the panel's login protects it; nothing is stored):

- **The screen.** One frame a second of her virtual desktop or her browser (JPEG, about 50-150 KB), with a ring where her mouse pointer is
  (the screenshot has no cursor, so the panel draws it). "Авто" follows the desktop, then the browser; the buttons pick one. When she is not
  using a screen it says so; a screen that is off costs nothing. The viewer has its own connection, so it never waits for her actions and
  never disturbs them. Frames are only taken while the tab is open.
- **The feed.** Her thoughts, tool calls with their arguments, short results and incoming messages, live (a ring of the last 400, in memory).
- **The chat.** A mirror of the chat she is in (a picker lets you choose another), as bubbles.
- It is read-only: you cannot click on her screen from the panel. If you need to take over, close her screen with `/stop`.
- She does not run Telegram Web or a Telegram app on the desktop: she talks through the Telegram API, which is faster and safer
  (a second web login on the same account would be one more session for Telegram to be suspicious about). The tab shows her work in
  the same window anyway.

## The Telegram window in the panel («Телеграм» tab)

A Telegram-like window with her real account, with what the app shows:

- **Chat list:** avatars, 📌 pinned first, 🔕 muted (grey badge), unread and `@` mentions, "печатает…" and the green online dot, groups and
  channels marked. **Folder tabs** (Все / your folders / Архив) work like in the app.
- **Messages:** day separators, formatting (bold, italic, underline, strike, spoiler, code, pre, quotes, links, @mentions — built as DOM
  nodes, never as HTML), replies with the quoted part, forwards, "via bot", channel signatures and counters (views, forwards, comments),
  reactions with counts, edit marks, read ticks, service lines ("… закрепил(а) сообщение", joins, title changes, calls), the pinned-message bar,
  link cards, locations and venues (link to OpenStreetMap), contacts, dice, albums as one bubble, polls with bars, your vote and type, inline bot
  buttons (links open; callback buttons need take-over).
- **Media:** photos (click = full size), stickers (static and video; animated `.tgs` show the emoji), GIFs and videos with a player, round
  videos, voice messages and music with a player, documents as downloads.
- **Search:** the box over the list searches all chats, 🔍 in the header searches the open chat; a result jumps to the message (⬇ returns to the
  newest). Scrolling to the top loads older history.
- **It follows her.** With "следить за ней" on, the window switches to the chat she works in, moves a pink cursor «Рейна» to the message she
  replies to, reacts to, reads or whose button she presses (the message is outlined, the cursor says what she does: «отвечает», «ставит
  реакцию», «нажимает кнопку»), types the text she writes into the input letter by letter and presses ➤.
- **Take-over mode** (`misc.panel_takeover`, **off by default**): when on, the button «✋ перехватить» lets the owner use her account from the
  window: write (with markdown, as a reply, silent), react, edit, delete, pin, vote, press bot buttons, mute. It is switched on per visit,
  every single action asks "от имени Рейны?" first, the server also demands `confirm: true` and allows 40 actions a minute, each action shows
  in the «Эфир» feed, and she is told in her next turn what he did so she does not take his message for her own.
- **Safety of files:** the file type comes from the bytes, never from the sender's claim; only images, mp4/webm, ogg/mp3/m4a play inline, anything
  else (html, svg, scripts) is only an attachment with a sandbox policy; at most 25 MB; reading never marks anything read.
- **Privacy.** Other people's private messages are visible in the panel (behind `admin_token`). Set `misc.panel_chats = false` to switch the
  view off completely.
- On a phone the list and the chat are shown one at a time with a back arrow.

## Her own Telegram screen (`telegram_ui`, owner only)

Besides the plain tools she has the app as a **screen of text**: `telegram_ui` returns what a person would see, with numbers to act on. The
panel shows the same chats, so the owner watches her use the app and her cursor lands on the message she acts on.

```
┌ Telegram · Все чаты · непрочитано (без мьюта): 3
│  1. 📌👤 Jaabir ●2 · в сети — «где ты?» · 21:39
│  2. 🔕👥 Работа @1 ✍ Алекс печатает… — «сроки» · 21:24
└ open(chat = номер) · folders · list(folder) · search(text)
┌ ◀ Jaabir · в сети
│ 📌 закреплено: «Привет, ты где?…»
│ #3 21:40 Jaabir ↩ вы: «Тут я» 
│       Выбери вариант
│       [1.1 Да] [1.2 Нет] [2.1 Открыть сайт ↗ https://…]
```

Actions: `screen, folders, list(folder), open(chat | n), back, up/down` (older/newer messages), `search`, `send, reply(n), edit(n), delete(n),
react(n, emoji), press(n, button), forward(n, to), pin/unpin(n), vote(n, options), view(n)` (a vision model looks at a photo, voice is
transcribed), `read, mute/unmute, dice, location`; `send` takes `markdown`, `silent` and `at` (schedule: `+30m`). The three newest messages with
media are described automatically, older ones are labels until she says `view`. A URL button is never opened from the screen (she gets the
address and can use the browser); the prompt tells her not to press buttons that pay, buy or confirm anything for him. Each action puts a
`ui` event into the feed that the window shows as the cursor.

**In ordinary chats too.** Her normal view of a chat now carries what the app shows around the text: a `<chat_header>` (online/typing now, muted, unread mentions, pinned message), and on each message the quoted part (`reply_quote`), `via` bot, album id, reaction counts, views, the real address behind a link word (`<link/>`), the link card, a location, and bot buttons (`[1.1 Да]`; she presses one with `telegram_ui action=press chat=… n=<message_id>`). Plain messages are unchanged, so the cost is only where there is something to see.

**The whole desk at a glance.** In the owner's chat (and in her wake-ups there) she also gets a `<telegram_desk>` block: up to 8 other chats with unread messages, mentions or someone typing (online, pinned), a count of muted chats with unread, the folder names. It comes on a fresh session and then at most every 15 minutes; other people's chats never get it because it names other chats. `misc.desk_overview = false` switches it off.

What the account side needs from tdlib (not verifiable in this build, checked only against a scripted fake): chat folders, notification
settings, chat positions, typing actions, user statuses, `getCallbackQueryAnswer`, `parseTextEntities`, scheduled `sendMessage`. Not covered on
purpose: calls, secret chats, Stars/gifts/payments, stories, Business features.

