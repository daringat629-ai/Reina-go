package agent

import (
	"regexp"

	"kuni/internal/config"
	"kuni/internal/telegram"
	"kuni/internal/tools"
)

func (a *Agent) baseTools(d tools.Deps, proactive bool) []tools.Tool {
	ts := tools.GlobalTools(d, proactive)
	if d.GoToSleep != nil {
		ts = append(ts, tools.GoToSleepTool(d))
	}
	if !proactive {
		// a notification turn starts with the chat already opened and rendered: #open_chat would only
		// burn a (slow, paid) round re-opening the same chat.
		kept := ts[:0]
		for _, t := range ts {
			if t.Name != "open_chat" {
				kept = append(kept, t)
			}
		}
		ts = kept
	}
	ts = append(ts, tools.WaitTools()...)
	if a.Cfg.Get().MoodEnabled && d.Mood != nil {
		ts = append(ts, tools.MoodTool(d))
	}
	return append(ts, tools.AskTool(d))
}

func chatToolList(d tools.Deps, chat telegram.Chat) []tools.Tool {
	r := tools.ChatTools(d, chat)
	var out []tools.Tool
	for _, n := range r.Names() {
		t, _ := r.Get(n)
		out = append(out, t)
	}
	return out
}

// Lazy tool groups (see tools.Registry.Lazy): rarely used tools cost no prompt tokens until needed.
var lazyGroups = map[string][]string{
	"media":   {"take_photo", "record_audio", "sticker_list", "sticker_send", "sticker_save", "get_chat_photo"},
	"edit":    {"edit_message_text", "remove_message", "forward_message", "view_messages_around"},
	"admin":   {"group_admin_remove_message", "group_admin_ban_user", "group_admin_set_user_tag", "leave_chat", "remove_and_ban_chat"},
	"search":  {"search_messages"},
	"read":    {"read_link", "read_document"},
	"polls":   {"create_poll", "vote_poll", "pin_message", "unpin_message"},
	"plan":    {"remind", "reminders"},
	"browser": {"browser"},
	"desktop": {"desktop"},
	"system":  {"shell", "download_telegram_file", "send_file", "list_all_chats", "read_chat", "join_by_link", "send_to_chat", "shell_bg", "jobs", "tg_api", "telegram_ui", "web_search", "read_file", "http_request", "mail", "calendar", "work"},
}

var lazyDesc = map[string]string{
	"media":   "photos/selfies, voice messages, stickers, chat avatar",
	"edit":    "edit/delete own messages, forward, view message context",
	"admin":   "moderation, leave chat, ban",
	"search":  "search messages across chats",
	"read":    "open links and read files (documents) people sent",
	"polls":   "create polls, vote in polls, pin/unpin messages",
	"plan":    "reminders: remind someone later, list or cancel reminders",
	"desktop": "a virtual desktop of her own: start graphical programs (office, editors, any app), look at the screen, move the mouse, click, type",
	"browser": "a real web browser: open sites, search the web, click, fill forms, send screenshots",
	"system":  "shell commands, downloads, files, archives, read any chat, join a group by link, write into another chat, the Telegram app as a screen (chat list, folders, open a chat, scroll, reply, react, press bot buttons) that the owner watches live, every Telegram action in any chat (search, members, pin, forward, files), web search, read any file (pdf/docx/xlsx), call APIs like GitHub, his e-mail and calendar, long jobs in the background",
}

var sysWords = regexp.MustCompile(`(?i)вступ|зайд|заход|t\.me|скача|загруз|запуст|команд|терминал|консол|файл|архив|распак|установ|удал|чат|переписк|download|run |install|shell|folder|zip|curl|wget|git |ls\b`)

var errandWords = regexp.MustCompile(`(?i)найди|поищи|узнай|проверь|посмотри|сколько|курс|цен[аы]|стоит|погод|памят|диск|нагрузк|сделай|очисти|удали|почисти|покажи|пугугл`)

var browserWords = regexp.MustCompile(`(?i)браузер|сайт|страниц|скриншот|скрин\b|зайди на|загугл|погугл|гугл|яндекс|найди в интернет|в интернете|https?://|www\.|browser|website|web ?page|screenshot|google`)

var desktopWords = regexp.MustCompile(`(?i)рабоч\w+ стол|десктоп|desktop|приложени|программ[уаы]|окно|мыш|кликни|libreoffice|gimp|firefox|excel|word\b`)

var linkWords = regexp.MustCompile(`(?i)https?://|www\.|\.(com|ru|org|net|io|me|ai)/|ссылк|статья|статью|link|article`)

var pollWords = regexp.MustCompile(`(?i)опрос|голосован|проголосуй|закреп|poll|\bvote\b|\bpin\b`)

var planWords = regexp.MustCompile(`(?i)напомни|напоминан|remind|будильник|таймер|попозже|timer|alarm|через \d|завтра|\bв \d{1,2}[:.]\d{2}`)

var searchWords = regexp.MustCompile(`(?i)найд|поищ|ищи|искать|вспомни|переписк|search|find `)

var mediaWords = regexp.MustCompile(`(?i)фот|селфи|голос|войс|стикер|аватар|photo|selfie|voice|sticker|picture|pic\b`)

// newRegistry builds the tool set of a chat, hiding rarely used groups unless lazy_tools is off.
// Groups the incoming messages obviously call for (media, voice, stickers...) are unlocked up front.
func (a *Agent) newRegistry(s *session, d tools.Deps, chat telegram.Chat, proactive bool, unread []telegram.Message) *tools.Registry {
	all := append(append(a.baseTools(d, proactive), chatToolList(d, chat)...), tools.OwnerTools(d, chat)...)
	if tools.IsOwnerChat(d, chat.ID) { // list_all_chats supersedes it; two near-identical tools made the model loop
		kept := all[:0:0]
		for _, t := range all {
			if t.Name != "get_telegram_chats" {
				kept = append(kept, t)
			}
		}
		all = kept
	}
	r := tools.NewRegistry(all...)
	if !a.Cfg.Get().LazyTools {
		return r
	}
	if s.unlocked == nil {
		s.unlocked = map[string]bool{}
	}
	r.Lazy(lazyGroups, lazyDesc)
	for g := range s.unlocked {
		r.Unlock(g)
	}
	r.OnUnlock = func(g string) { s.unlocked[g] = true }
	if chat.Kind == telegram.ChatGroup { // view_messages_around is what keeps group context right
		r.Unlock("edit")
	}
	if tools.IsOwnerChat(d, chat.ID) { // the owner's everyday tools are at hand; the rest unlocks by the words he uses (tokens!)
		r.Unlock("system")
		r.Unlock("edit")
	}
	for _, m := range unread {
		if tools.IsOwnerChat(d, chat.ID) && !m.Outgoing && (m.FileID != "" || sysWords.MatchString(m.Text)) {
			r.Unlock("system")
		}
		if m.Media != telegram.MediaNone || mediaWords.MatchString(m.Text) {
			r.Unlock("media")
		}
		if !m.Outgoing && planWords.MatchString(m.Text) {
			r.Unlock("plan")
		}
		if !m.Outgoing && searchWords.MatchString(m.Text) {
			r.Unlock("search")
		}
		if tools.IsOwnerChat(d, chat.ID) && !m.Outgoing && browserWords.MatchString(m.Text) {
			r.Unlock("browser")
		}
		if tools.IsOwnerChat(d, chat.ID) && !m.Outgoing && desktopWords.MatchString(m.Text) {
			r.Unlock("desktop")
		}
		if !m.Outgoing && (m.Media == telegram.MediaDocument || linkWords.MatchString(m.Text)) {
			r.Unlock("read")
		}
		if !m.Outgoing && (m.Media == telegram.MediaPoll || pollWords.MatchString(m.Text)) {
			r.Unlock("polls")
		}
	}
	return r
}

// quickTalk tells whether the unread messages are a short private line: no files, no media, a few words.
func quickTalk(cfg *config.Config, chat telegram.Chat, unread []telegram.Message) bool {
	if cfg.FastShortChars <= 0 || chat.Kind != telegram.ChatPrivate || len(unread) == 0 || len(unread) > 3 {
		return false
	}
	n := 0
	for _, m := range unread {
		if m.Outgoing {
			continue
		}
		if m.Media != telegram.MediaNone || m.FileID != "" || m.Poll != nil || m.ForwardFrom != "" {
			return false
		}
		if errandWords.MatchString(m.Text) || browserWords.MatchString(m.Text) || sysWords.MatchString(m.Text) {
			return false // a request for an action needs her full attention, not a fast first round
		}
		n += len([]rune(m.Text))
	}
	return n > 0 && n <= cfg.FastShortChars
}
