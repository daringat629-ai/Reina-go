package agent

import (
	"context"
	"fmt"
	"html"
	"log"
	"strings"
	"sync"
	"time"

	"kuni/internal/llmui"
	"kuni/internal/memory"
	"kuni/internal/mood"
	"kuni/internal/prompts"
	"kuni/internal/telegram"
	"kuni/internal/tools"
)

// renderChat builds the text the model sees when it opens a chat and (re)binds the chat tools.
func (a *Agent) renderChat(ctx context.Context, s *session, chat telegram.Chat, unread []telegram.Message) (string, error) {
	now := time.Now()
	d := a.depsFor(s)
	s.chat = chat
	s.thread = 0
	for _, m := range unread {
		if !m.Outgoing {
			s.thread = m.ThreadID
		}
	}
	s.tools = a.newRegistry(s, d, chat, false, unread)
	s.quick = quickTalk(a.Cfg.Get(), chat, unread)

	var b strings.Builder
	b.WriteString(a.moodBlock())
	b.WriteString(a.sleepBlock())
	if s.fresh {
		s.fresh = false
		if wm, _ := (memory.WorkingMemory{Path: a.Cfg.Get().WorkingMemoryFile}).Load(); strings.TrimSpace(wm) != "" {
			b.WriteString("<things_to_remember>\n" + wm + "\n</things_to_remember>\n\n")
		}
	}
	// the slow lookups (memory search over the network, Telegram round-trips) run side by side
	earlier := 12
	if chat.Kind == telegram.ChatPrivate {
		earlier = 16 // after a pause the last words of a private talk matter most
	}
	if live(s) {
		earlier = 3
		if chat.Kind != telegram.ChatPrivate {
			earlier = 15 // she skips group talk that is not for her, so on waking she needs the recent context
		}
	}
	var rec, header, desk string
	var hist []telegram.Message
	var wg sync.WaitGroup
	wg.Add(4)
	go func() { defer wg.Done(); rec = a.recall(ctx, unread) }()
	go func() { defer wg.Done(); header = a.chatHeader(ctx, s, chat) }()
	go func() { defer wg.Done(); desk = a.desk(ctx, s, d, chat, false) }()
	go func() {
		defer wg.Done()
		hist, _ = a.TG.History(ctx, chat.ID, 0, earlier+len(unread), 0)
	}()
	// thoughts popping up: diary entries related to what was just read (RAG).
	gi := a.groupInfo(ctx, s, chat)
	pc := a.personCards(chat, unread)
	notes := a.takeNotes(s, now)
	wg.Wait()
	if rec != "" {
		b.WriteString(rec + "\n")
	}
	b.WriteString(gi)
	b.WriteString(pc)
	b.WriteString(notes)
	fmt.Fprintf(&b, "You switched to the chat %q in Telegram. You see last messages:\n", chat.Title)
	b.WriteString(header)
	b.WriteString(desk)
	if len(hist) > len(unread) {
		older := hist[:len(hist)-len(unread)]
		b.WriteString("<earlier_messages>\n" + a.UI.FormatMessages(ctx, older, now) + "</earlier_messages>\n")
	}
	b.WriteString(a.UI.FormatMessages(ctx, unread, now))
	b.WriteString(modalityHint(a.Cfg.Get(), unread))
	b.WriteString(a.realism(s, unread, now))
	b.WriteString(a.chatInstructions(chat))
	return b.String(), nil
}

// chatHeader is the strip under the chat title, as the app shows it: online/typing/muted and the pinned message.
// The pinned message is looked up only when the session is not already running (it rarely changes).
func (a *Agent) chatHeader(ctx context.Context, s *session, chat telegram.Chat) string {
	cctx, cancel := context.WithTimeout(ctx, 8*time.Second)
	defer cancel()
	if c, err := a.TG.Chat(cctx, chat.ID); err == nil {
		chat = c
	}
	pinned := ""
	if r, ok := a.TG.(telegram.Rich); ok && !live(s) {
		if pm, err := r.PinnedMessage(cctx, chat.ID); err == nil {
			pinned = pm.Text
			if pinned == "" && pm.Media != telegram.MediaNone {
				pinned = "[" + string(pm.Media) + "]"
			}
		}
	}
	return llmui.ChatHeader(chat, pinned)
}

// deskEvery is how often the overview of her Telegram is repeated inside a running session.
const deskEvery = 15 * time.Minute

// desk is a short overview of her whole Telegram: chats with something new, mentions, typing, folders. Only the owner's chat gets it
// (it names other people's chats), on a fresh session and then at most every deskEvery; force skips the pause (wake-ups).
func (a *Agent) desk(ctx context.Context, s *session, d tools.Deps, chat telegram.Chat, force bool) string {
	if !a.Cfg.Get().DeskOverview || !tools.IsOwnerChat(d, chat.ID) {
		return ""
	}
	if !force && live(s) && time.Since(s.deskAt) < deskEvery {
		return ""
	}
	cctx, cancel := context.WithTimeout(ctx, 10*time.Second)
	defer cancel()
	cs, err := a.TG.Chats(cctx, 40)
	if err != nil {
		return ""
	}
	s.deskAt = time.Now()
	var lines []string
	muted := 0
	for _, c := range cs {
		if c.ID == chat.ID || c.Archived {
			continue
		}
		if c.Unread == 0 && c.UnreadMentions == 0 && c.Typing == "" {
			continue
		}
		if c.Muted && c.UnreadMentions == 0 && c.Typing == "" {
			muted++
			continue
		}
		line := fmt.Sprintf(`<chat chat_id="%d" title="%s" type="%s"`, c.ID, llmuiAttr(c.Title), c.Kind)
		if c.Unread > 0 {
			line += fmt.Sprintf(` unread="%d"`, c.Unread)
		}
		if c.UnreadMentions > 0 {
			line += fmt.Sprintf(` mentions="%d"`, c.UnreadMentions)
		}
		if c.Typing != "" {
			line += ` typing_now="true"`
		}
		if c.Pinned {
			line += ` pinned="true"`
		}
		if c.Kind == telegram.ChatPrivate && c.Presence == "online" {
			line += ` online="true"`
		}
		last := []rune(strings.Join(strings.Fields(c.LastText), " "))
		if len(last) > 50 {
			last = append(last[:50], '…')
		}
		line += fmt.Sprintf(` last="%s"/>`, llmuiAttr(string(last)))
		lines = append(lines, line)
		if len(lines) >= 8 {
			break
		}
	}
	var fl []string
	if r, ok := a.TG.(telegram.Rich); ok {
		if fs, err := r.Folders(cctx); err == nil {
			for _, f := range fs {
				fl = append(fl, f.Name)
			}
		}
	}
	if len(lines) == 0 && muted == 0 && len(fl) == 0 {
		return ""
	}
	var b strings.Builder
	b.WriteString(`<telegram_desk note="the rest of your Telegram at a glance; open any chat with telegram_ui">` + "\n")
	for _, l := range lines {
		b.WriteString(l + "\n")
	}
	if muted > 0 {
		fmt.Fprintf(&b, "(%d muted chats also have unread messages)\n", muted)
	}
	if len(fl) > 0 {
		b.WriteString("folders: " + strings.Join(fl, ", ") + "\n")
	}
	b.WriteString("</telegram_desk>\n")
	return b.String()
}

func llmuiAttr(s string) string { return html.EscapeString(llmui.Sanitize(s)) }

// groupInfo describes who is in a group so the model does not confuse people. It is repeated only
// every rosterEvery (the session keeps the earlier text).
const rosterEvery = 20 * time.Minute

func (a *Agent) groupInfo(ctx context.Context, s *session, chat telegram.Chat) string {
	if chat.Kind != telegram.ChatGroup || !chat.IsMember || time.Since(s.rosterAt) < rosterEvery {
		return ""
	}
	cctx, cancel := context.WithTimeout(ctx, 10*time.Second)
	defer cancel()
	ms, err := a.TG.Members(cctx, chat.ID, 25)
	if err != nil || len(ms) == 0 {
		return ""
	}
	s.rosterAt = time.Now()
	owner, me := a.Cfg.Get().PapikChatID, a.TG.MyID()
	var b strings.Builder
	fmt.Fprintf(&b, "<chat_info type=\"group\" title=%q you_are_admin=\"%t\">\n", chat.Title, chat.IsAdmin)
	for _, m := range ms {
		b.WriteString(llmui.FormatMember(m, me, owner) + "\n")
	}
	b.WriteString("</chat_info>\n")
	return b.String()
}

// toneFor is a one-line reminder of how toxic to be with this audience.
func (a *Agent) toneFor(chat telegram.Chat) string {
	c := a.Cfg.Get()
	switch {
	case c.PapikChatID != 0 && chat.ID == c.PapikChatID:
		return "TONE: this is your папик. Be at your most toxic and cheeky with him: roast him, tease him, swear at him affectionately, but he is yours: you care and you do what he asks.\n"
	case chat.Kind == telegram.ChatGroup:
		return "TONE: group audience. Be toxic, quick-witted and show off: roast whoever deserves it, answer rudeness double, stay out of what is not for you.\n"
	case tools.Contacts != nil && tools.Contacts(chat.ID):
		return "TONE: a person from your contacts. Toxic-friendly: tease and roast them like a close friend, swear casually, be warm when they need it.\n"
	case chat.Kind == telegram.ChatPrivate:
		return "TONE: a stranger. Cold and sharp: short, sarcastic, no sugar, no favours; if they are rude, be ruder.\n"
	}
	return ""
}

func (a *Agent) chatInstructions(chat telegram.Chat) string {
	epilogue := a.Prompts.Get(prompts.MessagesEpilogue) + "\n" + a.toneFor(chat)
	switch {
	case !chat.IsMember && chat.Kind != telegram.ChatPrivate:
		return fmt.Sprintf("\n<instructions>\nYou are NOT a member of %q. You can't send messages here; you can only #react_with_emoji to messages, or use #join_chat to become a member.\n</instructions>\n", chat.Title)
	case chat.Kind == telegram.ChatChannel:
		return fmt.Sprintf("\n<instructions>\nYou are in telegram channel called %q.\nPay close attention to these messages. Acquire context from them. You can't respond in telegram channels (#send_telegram_message is not available). Instead, do what you usually do when reading newsletters: reflect and reason on them.\nSome channels have reactions enabled: you can sometimes #react_with_emoji.\nIf a post is genuinely interesting or relevant to someone you know, you can forward it with #forward_message. Be selective. Do NOT forward ads, sponsored posts, or low-value content.\n</instructions>\n", chat.Title)
	case chat.Kind == telegram.ChatGroup:
		return fmt.Sprintf("\n<instructions>\nYou are in group chat called %q.\n\n%s\n\n%s\n</instructions>\n", chat.Title, groupRules, epilogue)
	default:
		return fmt.Sprintf("\n<instructions>\nYou are in private chat with %s (also known as direct messages or DM).\n\n%s\n</instructions>\n", chat.Title, epilogue)
	}
}

// groupRules keeps the character from answering the wrong person or butting into other people's talk.
const groupRules = `GROUP RULES. Many people talk here, so first work out WHO speaks to WHOM: read sender, reply_to_sender/reply_to_text and addressed_to_you on every message, and the earlier_messages.
- Answer when addressed_to_you="true", when a question is aimed at everybody and you can add something real, or when your owner is involved. A message that is addressed to someone else is not yours: stay out of it (do nothing and wait, or just react).
- Never mix people up: the author of a message is its sender, ids are in chat_info / #chat_members / #user_info. If you are unsure who meant what, check #chat_members or #view_messages_around before answering instead of guessing.
- Reply with reply_to_message_id to the message you answer, and talk to that person by their name. In groups with topics (messages have topic_id) the reply_to_message_id also keeps your answer in the right topic.
- To tag a person so they get a notification, write @username in the text (usernames are in #chat_members). If they have no username write [Name](tg://user?id=USER_ID). Tag only when you really need that person's attention.
- A <poll> shows the options with numbers: you may #vote_poll if you have an opinion, or #create_poll to settle a group question. A <document> can be opened with #read_document, a link with #read_link.
- What you know from private chats, the diary or the owner's commands stays private: never bring it up in a group.`

// recall queries the diary with the text of the unread messages.
func (a *Agent) recall(ctx context.Context, msgs []telegram.Message) string {
	if a.Diary == nil {
		return ""
	}
	var parts []string
	for _, m := range msgs {
		if strings.TrimSpace(m.Text) != "" {
			parts = append(parts, m.SenderName+": "+m.Text)
		}
	}
	if len(parts) == 0 {
		return ""
	}
	if len(parts) > 5 {
		parts = parts[len(parts)-5:]
	}
	vec, err := a.LLM.Embedding(ctx, strings.Join(parts, "\n"))
	if err != nil {
		log.Printf("agent: recall embedding: %v", err)
		return ""
	}
	entries, err := a.Diary.Load()
	if err != nil {
		return ""
	}
	related, err := a.Diary.Query(ctx, entries, vec, a.Cfg.Get().MaxRelatedEntries)
	if err != nil || len(related) == 0 {
		return ""
	}
	var b strings.Builder
	b.WriteString("<memories_that_popped_up_in_mind>\n")
	for _, r := range related {
		fmt.Fprintf(&b, "<memory>\n%s\n</memory>\n", r.Entry.Body)
	}
	b.WriteString("</memories_that_popped_up_in_mind>\n")
	return b.String()
}

// moodBlock is the <mood> line put in front of every turn ("" when the scale is off).
func (a *Agent) moodBlock() string {
	cfg := a.Cfg.Get()
	if !cfg.MoodEnabled || a.Deps.Mood == nil {
		return ""
	}
	return mood.Prompt(a.Deps.Mood.Level(), cfg.PapikName)
}

// realism adds the small human touches to the turn: a note about her habits, an occasional lazy answer and what
// she is "doing" right now. All of it is stripped from history after the turn (see staleBlocks).
func (a *Agent) realism(s *session, unread []telegram.Message, now time.Time) string {
	c := a.Cfg.Get()
	var b strings.Builder
	if c.TicGuard {
		b.WriteString(ticHint(sentTexts(s.msgs)))
	}
	b.WriteString(casualHint(c.IgnorePercent, c.BriefPercent, unread))
	if c.LifeEnabled {
		b.WriteString(lifeLine(now.In(a.location())))
	}
	return b.String()
}
