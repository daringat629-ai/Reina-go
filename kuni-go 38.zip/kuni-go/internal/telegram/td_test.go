package telegram

import (
	"context"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"
)

// fakeTD scripts tdlib: handle(req) returns the response object for a request
// (nil = {"@type":"ok"}); Push injects unsolicited updates.
type fakeTD struct {
	mu     sync.Mutex
	out    chan []byte
	reqs   []obj
	handle func(req obj) obj
}

func newFakeTD(handle func(req obj) obj) *fakeTD {
	return &fakeTD{out: make(chan []byte, 256), handle: handle}
}

func (f *fakeTD) Send(raw []byte) {
	req, _ := decode(raw)
	f.mu.Lock()
	f.reqs = append(f.reqs, req)
	f.mu.Unlock()
	if str(req, "@type") == "getOption" && req["@extra"] == nil {
		f.Push(obj{"@type": "updateAuthorizationState", "authorization_state": obj{"@type": "authorizationStateWaitTdlibParameters"}})
		return
	}
	var resp obj
	if f.handle != nil {
		resp = f.handle(req)
	}
	if resp == nil {
		resp = obj{"@type": "ok"}
	}
	if extra, ok := req["@extra"]; ok {
		resp["@extra"] = extra
		f.Push(resp)
	}
}

func (f *fakeTD) Push(m obj) {
	b, _ := json.Marshal(m)
	f.out <- b
}

func (f *fakeTD) Receive(timeout time.Duration) []byte {
	select {
	case b := <-f.out:
		return b
	case <-time.After(timeout):
		return nil
	}
}

func (f *fakeTD) requests(typ string) []obj {
	f.mu.Lock()
	defer f.mu.Unlock()
	var out []obj
	for _, r := range f.reqs {
		if str(r, "@type") == typ {
			out = append(out, r)
		}
	}
	return out
}

// loggedIn starts a client against fake and walks the real authorization sequence.
func loggedIn(t *testing.T, f *fakeTD, cfg TDConfig) (*TDClient, context.Context) {
	t.Helper()
	prompts := []string{}
	cfg.Prompt = func(what string) string {
		prompts = append(prompts, what)
		return map[string]string{"phone number": "+79990001122", "verification code": "12345", "cloud password": "pw"}[what]
	}
	if cfg.APIID == 0 {
		cfg.APIID, cfg.APIHash = 777, "hash"
	}
	cfg.DBDir = t.TempDir()
	inner := f.handle
	f.handle = func(req obj) obj {
		switch str(req, "@type") {
		case "setTdlibParameters":
			f.Push(obj{"@type": "updateAuthorizationState", "authorization_state": obj{"@type": "authorizationStateWaitPhoneNumber"}})
		case "setAuthenticationPhoneNumber":
			f.Push(obj{"@type": "updateAuthorizationState", "authorization_state": obj{"@type": "authorizationStateWaitCode"}})
		case "checkAuthenticationCode":
			f.Push(obj{"@type": "updateAuthorizationState", "authorization_state": obj{"@type": "authorizationStateWaitPassword"}})
		case "checkAuthenticationPassword":
			f.Push(obj{"@type": "updateOption", "name": "my_id", "value": obj{"@type": "optionValueInteger", "value": "4242"}})
			f.Push(obj{"@type": "updateAuthorizationState", "authorization_state": obj{"@type": "authorizationStateReady"}})
		default:
			if inner != nil {
				return inner(req)
			}
		}
		return nil
	}
	c := NewTD(f, cfg)
	ctx, cancel := context.WithCancel(context.Background())
	t.Cleanup(cancel)
	go c.Run(ctx)
	select {
	case <-c.ready:
	case <-time.After(3 * time.Second):
		t.Fatalf("never became ready; prompts=%v", prompts)
	}
	if want := []string{"verification code", "cloud password"}; len(prompts) != 2 {
		_ = want
	}
	return c, ctx
}

func TestAuthorizationFlow(t *testing.T) {
	f := newFakeTD(nil)
	c, _ := loggedIn(t, f, TDConfig{AppVersion: "1.2.3"})
	params := f.requests("setTdlibParameters")
	if len(params) != 1 || num(params[0]["api_id"]) != 777 || str(params[0], "api_hash") != "hash" ||
		params[0]["use_message_database"] != true || str(params[0], "application_version") != "1.2.3" {
		t.Fatalf("bad setTdlibParameters: %v", params)
	}
	if ph := f.requests("setAuthenticationPhoneNumber"); len(ph) != 1 || str(ph[0], "phone_number") != "+79990001122" {
		t.Fatalf("phone: %v", ph)
	}
	if code := f.requests("checkAuthenticationCode"); len(code) != 1 || str(code[0], "code") != "12345" {
		t.Fatalf("code: %v", code)
	}
	if c.MyID() != 4242 {
		t.Fatalf("my id = %d", c.MyID())
	}
}

func textMsg(id, chat, user int64, text string) obj {
	return obj{"@type": "message", "id": id, "chat_id": chat, "date": 1700000000 + id, "is_outgoing": false,
		"sender_id": obj{"@type": "messageSenderUser", "user_id": user},
		"content":   obj{"@type": "messageText", "text": obj{"@type": "formattedText", "text": text}}}
}

func TestIncomingMessageResolvesNameAndPreservesBigIDs(t *testing.T) {
	f := newFakeTD(func(req obj) obj {
		if str(req, "@type") == "getUser" {
			return obj{"@type": "user", "id": req["user_id"], "first_name": "Alex", "last_name": "K"}
		}
		return nil
	})
	c, _ := loggedIn(t, f, TDConfig{})
	const bigID = int64(1<<53 + 1) // not representable as float64
	raw, _ := json.Marshal(obj{"@type": "updateNewMessage", "message": textMsg(bigID, -1001234567890, 55, "hello")})
	f.out <- raw
	select {
	case m := <-c.Updates():
		if m.ID != bigID || m.ChatID != -1001234567890 || m.SenderName != "Alex K" || m.Text != "hello" || m.Outgoing {
			t.Fatalf("bad message: %+v", m)
		}
	case <-time.After(3 * time.Second):
		t.Fatal("no update")
	}
}

func TestOutgoingMessagesAreNotDelivered(t *testing.T) {
	f := newFakeTD(nil)
	c, _ := loggedIn(t, f, TDConfig{})
	m := textMsg(1, 5, 4242, "mine")
	m["is_outgoing"] = true
	f.Push(obj{"@type": "updateNewMessage", "message": m})
	select {
	case got := <-c.Updates():
		t.Fatalf("own message echoed: %+v", got)
	case <-time.After(300 * time.Millisecond):
	}
}

func TestSendTextShapeAndErrors(t *testing.T) {
	f := newFakeTD(func(req obj) obj {
		switch str(req, "@type") {
		case "sendMessage":
			if strings.Contains(str(sub(sub(req, "input_message_content"), "text"), "text"), "boom") {
				return obj{"@type": "error", "code": 400, "message": "CHAT_WRITE_FORBIDDEN"}
			}
			return obj{"@type": "message", "id": 900, "chat_id": req["chat_id"], "date": 1, "is_outgoing": true,
				"sender_id": obj{"@type": "messageSenderUser", "user_id": 4242},
				"content":   obj{"@type": "messageText", "text": obj{"text": "hi~"}}}
		}
		return nil
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	m, err := c.SendText(ctx, 5, "hi~", 33)
	if err != nil || m.ID != 900 || !m.Outgoing {
		t.Fatalf("send: %+v err=%v", m, err)
	}
	req := f.requests("sendMessage")[0]
	if str(sub(req, "reply_to"), "@type") != "inputMessageReplyToMessage" || num(sub(req, "reply_to")["message_id"]) != 33 ||
		str(sub(req, "input_message_content"), "@type") != "inputMessageText" {
		t.Fatalf("request shape: %v", req)
	}
	if _, err := c.SendText(ctx, 5, "boom", 0); err == nil || !strings.Contains(err.Error(), "CHAT_WRITE_FORBIDDEN") {
		t.Fatalf("tdlib error must surface to the model, got %v", err)
	}
	if r := f.requests("sendMessage")[1]; r["reply_to"] != nil {
		t.Fatalf("no reply expected: %v", r["reply_to"])
	}
}

func TestHistoryOffsetsAndOrder(t *testing.T) {
	f := newFakeTD(func(req obj) obj {
		if str(req, "@type") == "getChatHistory" {
			// newest first, like tdlib
			return obj{"@type": "messages", "messages": []any{textMsg(30, 5, 1, "c"), textMsg(20, 5, 1, "b"), textMsg(10, 5, 1, "a")}}
		}
		if str(req, "@type") == "getUser" {
			return obj{"@type": "user", "id": 1, "first_name": "U"}
		}
		return nil
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	msgs, err := c.History(ctx, 5, 20, 1, 1)
	if err != nil || len(msgs) != 3 || msgs[0].ID != 10 || msgs[2].ID != 30 {
		t.Fatalf("order: %+v err=%v", msgs, err)
	}
	r := f.requests("getChatHistory")[0]
	if num(r["from_message_id"]) != 20 || num(r["offset"]) != -1 || num(r["limit"]) != 3 {
		t.Fatalf("around request: %v", r)
	}
}

func TestUnreadUsesLastReadInbox(t *testing.T) {
	f := newFakeTD(func(req obj) obj {
		switch str(req, "@type") {
		case "getChat":
			return obj{"@type": "chat", "id": 5, "title": "Alex", "type": obj{"@type": "chatTypePrivate", "user_id": 1},
				"unread_count": 2, "last_read_inbox_message_id": 10}
		case "getChatHistory":
			return obj{"@type": "messages", "messages": []any{textMsg(30, 5, 1, "new2"), textMsg(20, 5, 1, "new1"), textMsg(10, 5, 1, "old")}}
		case "getUser":
			return obj{"@type": "user", "id": 1, "first_name": "Alex"}
		}
		return nil
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	un, err := c.Unread(ctx, 5)
	if err != nil || len(un) != 2 || un[0].Text != "new1" || un[1].Text != "new2" || un[0].Read {
		t.Fatalf("unread: %+v err=%v", un, err)
	}
}

func TestEditPicksTextOrCaption(t *testing.T) {
	f := newFakeTD(func(req obj) obj {
		if str(req, "@type") == "getMessage" {
			if num(req["message_id"]) == 1 {
				return textMsg(1, 5, 1, "t")
			}
			return obj{"@type": "message", "id": 2, "chat_id": 5, "content": obj{"@type": "messagePhoto"}}
		}
		return nil
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	if err := c.Edit(ctx, 5, 1, "x"); err != nil {
		t.Fatal(err)
	}
	if err := c.Edit(ctx, 5, 2, "y"); err != nil {
		t.Fatal(err)
	}
	if len(f.requests("editMessageText")) != 1 || len(f.requests("editMessageCaption")) != 1 {
		t.Fatalf("text edits=%d caption edits=%d", len(f.requests("editMessageText")), len(f.requests("editMessageCaption")))
	}
}

func TestReactionStripsVariationSelectorAndModerationShapes(t *testing.T) {
	f := newFakeTD(nil)
	c, ctx := loggedIn(t, f, TDConfig{})
	if err := c.React(ctx, 5, 9, "⚡️"); err != nil {
		t.Fatal(err)
	}
	if e := str(sub(f.requests("addMessageReaction")[0], "reaction_type"), "emoji"); e != "⚡" {
		t.Fatalf("emoji sent as %q", e)
	}
	if err := c.Ban(ctx, -100, 77, true); err != nil {
		t.Fatal(err)
	}
	ban := f.requests("banChatMember")[0]
	if num(sub(ban, "member_id")["user_id"]) != 77 || ban["revoke_messages"] != true {
		t.Fatalf("ban: %v", ban)
	}
	if err := c.SetMemberTag(ctx, -100, 77, "mod"); err != nil {
		t.Fatal(err)
	}
	if tag := f.requests("setChatMemberTag")[0]; str(tag, "tag") != "mod" || num(tag["user_id"]) != 77 {
		t.Fatalf("tag: %v", tag)
	}
}

func TestChatMembershipAndAdmin(t *testing.T) {
	status := "chatMemberStatusAdministrator"
	f := newFakeTD(func(req obj) obj {
		switch str(req, "@type") {
		case "getChat":
			return obj{"@type": "chat", "id": -100, "title": "Club", "type": obj{"@type": "chatTypeSupergroup", "is_channel": false}, "chat_lists": []any{obj{}}}
		case "getChatMember":
			if status == "ERR" {
				return obj{"@type": "error", "code": 400, "message": "USER_NOT_PARTICIPANT"}
			}
			return obj{"@type": "chatMember", "status": obj{"@type": status}}
		}
		return nil
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	ch, err := c.Chat(ctx, -100)
	if err != nil || !ch.IsAdmin || !ch.IsMember || ch.Kind != ChatGroup {
		t.Fatalf("admin chat: %+v err=%v", ch, err)
	}
	c.cmu.Lock()
	delete(c.chats, -100)
	c.cmu.Unlock()
	status = "chatMemberStatusLeft"
	if ch, _ := c.Chat(ctx, -100); ch.IsMember {
		t.Fatalf("left chat reported as member")
	}
	c.cmu.Lock()
	delete(c.chats, -100)
	c.cmu.Unlock()
	status = "ERR" // fallback: member iff in the chat list
	if ch, _ := c.Chat(ctx, -100); !ch.IsMember {
		t.Fatalf("fallback to chat_lists failed")
	}
}

func TestDownloadAndSendPhotoUsesLocalFile(t *testing.T) {
	dir := t.TempDir()
	file := filepath.Join(dir, "a.jpg")
	os.WriteFile(file, []byte("JPEG"), 0o644)
	f := newFakeTD(func(req obj) obj {
		switch str(req, "@type") {
		case "downloadFile":
			return obj{"@type": "file", "id": req["file_id"], "local": obj{"path": file}}
		case "sendMessage":
			return obj{"@type": "message", "id": 1, "chat_id": 5, "is_outgoing": true, "content": obj{"@type": "messagePhoto"}}
		}
		return nil
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	data, err := c.Download(ctx, "123")
	if err != nil || string(data) != "JPEG" {
		t.Fatalf("download: %q %v", data, err)
	}
	if d := f.requests("downloadFile")[0]; d["synchronous"] != true || num(d["file_id"]) != 123 {
		t.Fatalf("download request: %v", d)
	}
	if _, err := c.SendPhoto(ctx, 5, []byte("PNG"), "cap", 0); err != nil {
		t.Fatal(err)
	}
	in := sub(f.requests("sendMessage")[0], "input_message_content")
	path := str(sub(in, "photo"), "path")
	if b, err := os.ReadFile(path); err != nil || string(b) != "PNG" || !filepath.IsAbs(path) {
		t.Fatalf("photo file %q: %q %v", path, b, err)
	}
}

func TestThrottleLimitsRequestRate(t *testing.T) {
	f := newFakeTD(nil)
	c, ctx := loggedIn(t, f, TDConfig{MaxQPS: 5})
	start := time.Now()
	for i := 0; i < 8; i++ {
		if err := c.Typing(ctx, 5); err != nil {
			t.Fatal(err)
		}
	}
	// setup already used some of the first second's budget, so 8 more calls cannot finish instantly
	if time.Since(start) < 500*time.Millisecond {
		t.Fatalf("not throttled: %v", time.Since(start))
	}
}

func TestSearchRoutesByScope(t *testing.T) {
	f := newFakeTD(func(req obj) obj {
		if strings.HasPrefix(str(req, "@type"), "search") {
			return obj{"@type": "foundMessages", "messages": []any{}}
		}
		return nil
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	c.Search(ctx, SearchQuery{Text: "pizza", ChatID: 5, SenderID: 9})
	c.Search(ctx, SearchQuery{Text: "pizza", Since: time.Unix(1700000000, 0)})
	in := f.requests("searchChatMessages")
	gl := f.requests("searchMessages")
	if len(in) != 1 || num(sub(in[0], "sender_id")["user_id"]) != 9 {
		t.Fatalf("scoped search: %v", in)
	}
	if len(gl) != 1 || num(gl[0]["min_date"]) != 1700000000 {
		t.Fatalf("global search: %v", gl)
	}
}

func TestMembersOfSupergroupAndBasicGroup(t *testing.T) {
	user := func(id int64, first, un string) obj {
		return obj{"@type": "user", "id": id, "first_name": first, "usernames": obj{"active_usernames": []any{un}}, "type": obj{"@type": "userTypeRegular"}}
	}
	member := func(id int64, status string) any {
		return obj{"@type": "chatMember", "member_id": obj{"@type": "messageSenderUser", "user_id": id}, "status": obj{"@type": status}}
	}
	f := newFakeTD(func(req obj) obj {
		switch str(req, "@type") {
		case "getChat":
			if num(req["chat_id"]) == -100 {
				return obj{"@type": "chat", "id": -100, "title": "Club", "type": obj{"@type": "chatTypeSupergroup", "supergroup_id": 100}}
			}
			return obj{"@type": "chat", "id": -7, "title": "Old", "type": obj{"@type": "chatTypeBasicGroup", "basic_group_id": 7}}
		case "getSupergroupMembers":
			if str(sub(req, "filter"), "@type") == "supergroupMembersFilterAdministrators" {
				return obj{"@type": "chatMembers", "members": []any{member(2, "chatMemberStatusAdministrator")}}
			}
			return obj{"@type": "chatMembers", "members": []any{member(3, "chatMemberStatusMember"), member(2, "chatMemberStatusAdministrator")}}
		case "getBasicGroupFullInfo":
			return obj{"@type": "basicGroupFullInfo", "members": []any{member(3, "chatMemberStatusMember"), member(1, "chatMemberStatusCreator")}}
		case "getUser":
			switch num(req["user_id"]) {
			case 1:
				return user(1, "Boss", "boss")
			case 2:
				return user(2, "Adm", "adm")
			}
			return user(3, "Joe", "joe")
		case "getUserFullInfo":
			return obj{"@type": "userFullInfo", "bio": obj{"text": "hi there"}}
		}
		return nil
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	ms, err := c.Members(ctx, -100, 10)
	if err != nil || len(ms) != 2 || ms[0].ID != 2 || ms[0].Role != "admin" || ms[0].Username != "adm" || ms[1].Name != "Joe" {
		t.Fatalf("supergroup members (admins first, deduped): %+v err=%v", ms, err)
	}
	ms, err = c.Members(ctx, -7, 10)
	if err != nil || len(ms) != 2 || ms[0].Role != "owner" || ms[0].Name != "Boss" {
		t.Fatalf("basic group members: %+v err=%v", ms, err)
	}
	u, err := c.UserInfo(ctx, 3)
	if err != nil || u.Name != "Joe" || u.Bio != "hi there" || u.Username != "joe" {
		t.Fatalf("user info: %+v err=%v", u, err)
	}
}

func TestParseDocumentsRoundVideosAndGifs(t *testing.T) {
	f := newFakeTD(func(req obj) obj {
		if str(req, "@type") == "getUser" {
			return obj{"@type": "user", "id": req["user_id"], "first_name": "Bob"}
		}
		return nil
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	mk := func(content obj) Message {
		m := textMsg(9, 5, 55, "")
		m["content"] = content
		return c.parseMessage(ctx, m)
	}
	doc := mk(obj{"@type": "messageDocument", "caption": obj{"text": "report"},
		"document": obj{"file_name": "q3.pdf", "mime_type": "application/pdf", "document": obj{"id": 31, "size": 123456}}})
	if doc.Media != MediaDocument || doc.FileName != "q3.pdf" || doc.FileID != "31" || doc.FileSize != 123456 || doc.Text != "report" {
		t.Fatalf("document: %+v", doc)
	}
	img := mk(obj{"@type": "messageDocument", "document": obj{"file_name": "a.png", "mime_type": "image/png", "document": obj{"id": 32, "size": 10}}})
	if img.Media != MediaPhoto || img.FileID != "32" {
		t.Fatalf("image-as-file must look like a photo: %+v", img)
	}
	round := mk(obj{"@type": "messageVideoNote", "video_note": obj{"video": obj{"id": 33, "size": 999}}})
	if round.Media != MediaVideo || round.MediaDetail != "round" || round.FileSize != 999 {
		t.Fatalf("round: %+v", round)
	}
	gif := mk(obj{"@type": "messageAnimation", "caption": obj{"text": "lol"}, "animation": obj{"animation": obj{"id": 34, "size": 5}}})
	if gif.Media != MediaVideo || gif.MediaDetail != "gif" || gif.Text != "lol" {
		t.Fatalf("gif: %+v", gif)
	}
	if contentPreview(obj{"@type": "messageDocument", "document": obj{"file_name": "q3.pdf"}}) != "[file] q3.pdf" {
		t.Fatal("preview")
	}
}

func recvEvent(t *testing.T, c *TDClient) (Event, bool) {
	t.Helper()
	select {
	case e := <-c.Events():
		return e, true
	case <-time.After(400 * time.Millisecond):
		return Event{}, false
	}
}

func TestEditOfSeenMessageIsReportedWithOldAndNewText(t *testing.T) {
	f := newFakeTD(func(req obj) obj {
		if str(req, "@type") == "getUser" {
			return obj{"@type": "user", "id": req["user_id"], "first_name": "Bob"}
		}
		return nil
	})
	c, _ := loggedIn(t, f, TDConfig{})
	raw, _ := json.Marshal(obj{"@type": "updateNewMessage", "message": textMsg(10, 5, 55, "meet at 5")})
	f.out <- raw
	<-c.Updates()
	edit := func(text string) {
		b, _ := json.Marshal(obj{"@type": "updateMessageContent", "chat_id": 5, "message_id": 10,
			"new_content": obj{"@type": "messageText", "text": obj{"text": text}}})
		f.out <- b
	}
	edit("meet at 6")
	e, ok := recvEvent(t, c)
	if !ok || e.Kind != EventEdit || e.Old != "meet at 5" || e.New != "meet at 6" || e.Actor != "Bob" || e.MsgID != 10 {
		t.Fatalf("edit event: %+v %v", e, ok)
	}
	edit("meet at 6") // same text again (e.g. a link preview refresh): no event
	if _, ok := recvEvent(t, c); ok {
		t.Fatal("unchanged text must not produce an event")
	}
	b, _ := json.Marshal(obj{"@type": "updateMessageContent", "chat_id": 5, "message_id": 999, "new_content": obj{"@type": "messageText", "text": obj{"text": "x"}}})
	f.out <- b // never seen
	if _, ok := recvEvent(t, c); ok {
		t.Fatal("unknown message must not produce an event")
	}
}

func TestOnlyNewReactionsOnHerOwnMessagesAreReported(t *testing.T) {
	f := newFakeTD(func(req obj) obj {
		switch str(req, "@type") {
		case "getUser":
			return obj{"@type": "user", "id": req["user_id"], "first_name": "Bob"}
		case "getMessage":
			return obj{"@type": "message", "id": req["message_id"], "chat_id": req["chat_id"], "is_outgoing": num(req["message_id"]) == 20}
		}
		return nil
	})
	c, _ := loggedIn(t, f, TDConfig{})
	react := func(msg int64, emoji string, count int) {
		b, _ := json.Marshal(obj{"@type": "updateMessageInteractionInfo", "chat_id": 5, "message_id": msg, "interaction_info": obj{
			"reactions": obj{"reactions": []any{obj{"type": obj{"@type": "reactionTypeEmoji", "emoji": emoji}, "total_count": count,
				"recent_sender_ids": []any{obj{"@type": "messageSenderUser", "user_id": 55}}}}}}})
		f.out <- b
	}
	react(20, "❤", 1)
	e, ok := recvEvent(t, c)
	if !ok || e.Kind != EventReaction || e.Emoji != "❤" || e.Actor != "Bob" || e.ActorID != 55 || e.MsgID != 20 {
		t.Fatalf("reaction event: %+v %v", e, ok)
	}
	react(20, "❤", 1) // unchanged
	if _, ok := recvEvent(t, c); ok {
		t.Fatal("same reaction twice must be reported once")
	}
	react(20, "❤", 2) // a second person
	if e, ok = recvEvent(t, c); !ok || e.Emoji != "❤" {
		t.Fatalf("count grew: %+v %v", e, ok)
	}
	react(21, "👍", 1) // someone else's message (not outgoing)
	if _, ok := recvEvent(t, c); ok {
		t.Fatal("reactions to other people's messages are not events")
	}
}

func TestForumTopicIsParsedAndRepliesStayInTheTopic(t *testing.T) {
	f := newFakeTD(func(req obj) obj {
		switch str(req, "@type") {
		case "getUser":
			return obj{"@type": "user", "id": req["user_id"], "first_name": "Bob"}
		case "sendMessage":
			return obj{"@type": "message", "id": 500, "chat_id": req["chat_id"], "is_outgoing": true, "date": 1700000500,
				"sender_id": obj{"@type": "messageSenderUser", "user_id": 4242}, "content": obj{"@type": "messageText", "text": obj{"text": "ok"}}}
		}
		return nil
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	old := textMsg(70, -100500, 55, "in topic")
	old["message_thread_id"] = 12
	_ = c.parseMessage(ctx, old)
	newer := textMsg(71, -100500, 55, "new api")
	newer["topic_id"] = obj{"@type": "messageTopicForum", "forum_topic_id": 13}
	if m := c.parseMessage(ctx, newer); m.ThreadID != 13 {
		t.Fatalf("new topic_id shape: %+v", m)
	}
	if _, err := c.SendText(ctx, -100500, "answer", 70); err != nil {
		t.Fatal(err)
	}
	req := f.requests("sendMessage")[0]
	if num(req["message_thread_id"]) != 12 || num(sub(req, "topic_id")["forum_topic_id"]) != 12 {
		t.Fatalf("reply must go to the topic of the replied message: %v", req)
	}
	// the replied-to message decides even when the session last looked at another topic
	if _, err := c.SendText(WithThread(ctx, 99), -100500, "x", 70); err != nil {
		t.Fatal(err)
	}
	if num(f.requests("sendMessage")[1]["message_thread_id"]) != 12 {
		t.Fatal("reply topic should beat the context topic")
	}
	// without a reply the context topic is used; without any hint nothing is added
	if _, err := c.SendText(WithThread(ctx, 99), -100500, "x", 0); err != nil {
		t.Fatal(err)
	}
	if num(f.requests("sendMessage")[2]["message_thread_id"]) != 99 {
		t.Fatal("context thread should be used")
	}
	if _, err := c.SendText(ctx, -100500, "x", 0); err != nil {
		t.Fatal(err)
	}
	if _, has := f.requests("sendMessage")[3]["message_thread_id"]; has {
		t.Fatal("no thread hint, no thread field")
	}
}

func TestWithMentionsBuildsUTF16Entities(t *testing.T) {
	got := withMentions("привет [Joe 😀](tg://user?id=9)! и [Ann](tg://user?id=10)")
	if got["text"] != "привет Joe 😀! и Ann" {
		t.Fatalf("text: %q", got["text"])
	}
	ents := got["entities"].([]any)
	e0, e1 := ents[0].(obj), ents[1].(obj)
	// "привет " = 7 units; "Joe 😀" = 3+1+2 = 6 units; "! и " = 4 units
	if e0["offset"] != 7 || e0["length"] != 6 || num(sub(e0, "type")["user_id"]) != 9 {
		t.Fatalf("first entity: %v", e0)
	}
	if e1["offset"] != 7+6+4 || e1["length"] != 3 || num(sub(e1, "type")["user_id"]) != 10 {
		t.Fatalf("second entity: %v", e1)
	}
	if plain := withMentions("no mentions [here](https://x.y) @joe"); plain["entities"] != nil || plain["text"] != "no mentions [here](https://x.y) @joe" {
		t.Fatalf("plain text must stay untouched: %v", plain)
	}
}

func TestPollsPinAndParse(t *testing.T) {
	pollMsg := obj{"@type": "message", "id": 600, "chat_id": -100500, "is_outgoing": true, "date": 1700000600,
		"sender_id": obj{"@type": "messageSenderUser", "user_id": 4242},
		"content": obj{"@type": "messagePoll", "poll": obj{"question": obj{"text": "Pizza?"}, "total_voter_count": 3, "is_anonymous": false,
			"type":    obj{"@type": "pollTypeRegular", "allow_multiple_answers": true},
			"options": []any{obj{"text": obj{"text": "yes"}, "voter_count": 2, "is_chosen": true}, obj{"text": obj{"text": "no"}, "voter_count": 1}}}}}
	f := newFakeTD(func(req obj) obj {
		switch str(req, "@type") {
		case "sendMessage":
			return pollMsg
		}
		return nil
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	m, err := c.SendPoll(ctx, -100500, "Pizza?", []string{"yes", "no"}, false, true, 0)
	if err != nil {
		t.Fatal(err)
	}
	if m.Media != MediaPoll || m.Poll == nil || m.Poll.Question != "Pizza?" || !m.Poll.Multiple || m.Poll.Total != 3 ||
		len(m.Poll.Options) != 2 || !m.Poll.Options[0].Chosen || m.Poll.Options[0].Votes != 2 || m.Poll.Options[1].Text != "no" {
		t.Fatalf("poll parse: %+v / %+v", m, m.Poll)
	}
	content := sub(f.requests("sendMessage")[0], "input_message_content")
	if typ(content) != "inputMessagePoll" || content["is_anonymous"] != false || sub(content, "type")["allow_multiple_answers"] != true ||
		typ(sub(content, "question")) != "formattedText" || len(arr(content, "options")) != 2 {
		t.Fatalf("poll request: %v", content)
	}
	if _, err = c.SendPoll(ctx, 1, "q", []string{"only one"}, true, false, 0); err == nil {
		t.Fatal("one option must be rejected")
	}
	if err = c.VotePoll(ctx, -100500, 600, []int{1}); err != nil {
		t.Fatal(err)
	}
	if v := f.requests("setPollAnswer")[0]; len(arr(v, "option_ids")) != 1 || num(arr(v, "option_ids")[0]) != 1 {
		t.Fatalf("vote: %v", v)
	}
	if err = c.Pin(ctx, -100500, 600, true); err != nil || f.requests("pinChatMessage")[0]["disable_notification"] != true {
		t.Fatalf("pin: %v", err)
	}
	if err = c.Unpin(ctx, -100500, 600); err != nil || len(f.requests("unpinChatMessage")) != 1 {
		t.Fatalf("unpin: %v", err)
	}
	// old tdlib shape: plain strings for question/options
	old := parsePoll(obj{"question": "Plain?", "options": []any{obj{"text": "a"}, obj{"text": "b"}}})
	if old.Question != "Plain?" || old.Options[1].Text != "b" {
		t.Fatalf("old shape: %+v", old)
	}
}

func TestPollFallsBackToOldShapeWhenTextsDoNotParse(t *testing.T) {
	n := 0
	f := newFakeTD(func(req obj) obj {
		if str(req, "@type") == "sendMessage" {
			n++
			if n == 1 {
				return obj{"@type": "error", "code": 400, "message": "Can't parse InputMessageContent: Expected String"}
			}
			return obj{"@type": "message", "id": 601, "chat_id": 5, "is_outgoing": true, "date": 1700000600,
				"sender_id": obj{"@type": "messageSenderUser", "user_id": 4242}, "content": obj{"@type": "messageText", "text": obj{"text": "q"}}}
		}
		return nil
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	if _, err := c.SendPoll(ctx, 5, "q", []string{"a", "b"}, true, false, 0); err != nil {
		t.Fatal(err)
	}
	second := sub(f.requests("sendMessage")[1], "input_message_content")
	if _, isStr := second["question"].(string); !isStr {
		t.Fatalf("second attempt must use plain strings: %v", second)
	}
}

func TestFloodWaitIsWaitedOutAndRetried(t *testing.T) {
	n := 0
	f := newFakeTD(func(req obj) obj {
		if str(req, "@type") == "sendMessage" {
			n++
			if n <= 2 {
				return obj{"@type": "error", "code": 429, "message": "Too Many Requests: retry after 7"}
			}
			return obj{"@type": "message", "id": 900, "chat_id": req["chat_id"], "date": 1, "is_outgoing": true,
				"sender_id": obj{"@type": "messageSenderUser", "user_id": 4242}, "content": obj{"@type": "messageText", "text": obj{"text": "ok"}}}
		}
		return nil
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	var slept []time.Duration
	c.sleepFn = func(_ context.Context, d time.Duration) error { slept = append(slept, d); return nil }
	m, err := c.SendText(ctx, 5, "hi", 0)
	if err != nil || m.ID != 900 {
		t.Fatalf("must succeed after the waits: %+v %v", m, err)
	}
	if n != 3 || len(slept) < 2 || slept[0] < 7900*time.Millisecond || slept[0] > 8*time.Second {
		t.Fatalf("attempts=%d slept=%v", n, slept)
	}
	h := c.Health()
	if h.FloodWaits != 2 || len(h.Errors) != 2 || h.Errors[0].Method != "sendMessage" || h.Errors[0].ChatID != 5 || !strings.Contains(h.Errors[0].Message, "retry after 7") {
		t.Fatalf("health: %+v", h)
	}
}

func TestFloodWaitGivesUpAfterTwoRetriesAndCapsTheDelay(t *testing.T) {
	n := 0
	f := newFakeTD(func(req obj) obj {
		if str(req, "@type") == "sendMessage" {
			n++
			return obj{"@type": "error", "code": 429, "message": "Too Many Requests: retry after 3600"}
		}
		return nil
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	var slept []time.Duration
	c.sleepFn = func(_ context.Context, d time.Duration) error { slept = append(slept, d); return nil }
	if _, err := c.SendText(ctx, 5, "hi", 0); err == nil || !strings.Contains(err.Error(), "429") {
		t.Fatalf("want the 429 error, got %v", err)
	}
	if n != 3 {
		t.Fatalf("attempts = %d", n)
	}
	for _, d := range slept {
		if d > 90*time.Second {
			t.Fatalf("delay not capped: %v", d)
		}
	}
	if floodDelay("nonsense") != 6*time.Second {
		t.Fatal("unknown format falls back to a short wait")
	}
}

func TestHealthKeepsOnlyTheLastErrors(t *testing.T) {
	f := newFakeTD(func(req obj) obj {
		if str(req, "@type") == "deleteMessages" {
			return obj{"@type": "error", "code": 400, "message": "Message can't be deleted"}
		}
		return nil
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	for i := 0; i < healthKeep+5; i++ {
		_ = c.Delete(ctx, 5, int64(i))
	}
	h := c.Health()
	if len(h.Errors) != healthKeep || h.FloodWaits != 0 {
		t.Fatalf("health: %d errors, %d waits", len(h.Errors), h.FloodWaits)
	}
}

func TestFreshHealthListsAreEmptyNotNull(t *testing.T) {
	c, _ := loggedIn(t, newFakeTD(func(obj) obj { return nil }), TDConfig{})
	b, _ := json.Marshal(c.Health())
	if !strings.Contains(string(b), `"errors":[]`) {
		t.Fatalf("errors must marshal as [] (the panel calls .slice on it): %s", b)
	}
}

func TestOptimizeStorageAsksTdlibToDropOldMedia(t *testing.T) {
	f := newFakeTD(func(req obj) obj {
		if typ(req) == "optimizeStorage" {
			return obj{"@type": "storageStatistics", "size": json.Number("5242880")}
		}
		return nil
	})
	c, _ := loggedIn(t, f, TDConfig{})
	n, err := c.OptimizeStorage(context.Background(), 3)
	if err != nil || n != 5242880 {
		t.Fatalf("freed %d, %v", n, err)
	}
	f.mu.Lock()
	defer f.mu.Unlock()
	for _, r := range f.reqs {
		if typ(r) == "optimizeStorage" {
			if num(r["ttl"]) != 3*86400 || num(r["size"]) != -1 {
				t.Fatalf("wrong request: %v", r)
			}
			return
		}
	}
	t.Fatal("optimizeStorage was never sent")
}

func TestEmptyFilesAreRefusedBeforeTelegramSeesThem(t *testing.T) {
	c, _ := loggedIn(t, newFakeTD(func(obj) obj { return nil }), TDConfig{DBDir: t.TempDir()})
	if _, err := c.SendDocument(context.Background(), 5, "x.txt", nil, "", 0); err == nil || !strings.Contains(err.Error(), "empty") {
		t.Fatalf("an empty document must be refused locally: %v", err)
	}
	if _, err := c.SendSticker(context.Background(), 5, "0", 0); err == nil {
		t.Fatal("sticker id 0 must be refused")
	}
}
