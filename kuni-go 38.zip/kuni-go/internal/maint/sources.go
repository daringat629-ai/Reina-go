package maint

import (
	"path/filepath"

	"kuni/internal/config"
)

// Sources are the paths a backup contains.
func Sources(c *config.Config, configPath string) []string {
	return []string{
		c.DiaryDir, c.WorkingMemoryFile, c.PromptsDir, configPath,
		filepath.Join(c.DataDir, "mood.json"), filepath.Join(c.DataDir, "autonomy.json"), filepath.Join(c.DataDir, "autonomy.log"),
		filepath.Join(c.DataDir, "usage.json"),
		filepath.Join(c.DataDir, "people"), filepath.Join(c.DataDir, "reminders.json"), filepath.Join(c.DataDir, "work.json"),
	}
}

// SourcesToSend are the sources of the copy that leaves the server (Telegram): everything but the config with its keys.
func SourcesToSend(c *config.Config) []string {
	var out []string
	for _, s := range Sources(c, "") {
		if s != "" && s != "." {
			out = append(out, s)
		}
	}
	return out
}

// BackupDirOf resolves where backups are stored.
func BackupDirOf(c *config.Config) string {
	if c.BackupDir != "" {
		return c.BackupDir
	}
	return filepath.Join(c.DataDir, "backups")
}
