package config

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"
	"sync/atomic"
	"time"

	"kuni/internal/util"
)

// FileName is the runtime configuration file in the working directory.
const FileName = "config.toml"

// Config mirrors the sections of the C++ config.toml.
type Config struct {
	// [general]
	CharacterName   string
	CharacterNick   string
	PapikName       string
	PapikChatID     int64
	TelegramEnabled bool

	// [telegram]
	Mode           string // user | bot
	Phone          string
	TDLibDir       string
	BotToken       string
	TelegramAPI    string
	TelegramAPIID  int64
	TelegramHash   string
	Lockdown       string // none | contacts_only | papik_only
	CanJoinChats   bool
	CanLeaveChats  bool
	SessionIdle    time.Duration
	Proactive      time.Duration // 0 = disabled
	MaxToolRounds  int
	DebounceWindow time.Duration

	// [llm]
	LLMBaseURL       string
	LLMAPIKey        string
	LLMModel         string
	LightModel       string
	VisionModel      string
	PriceIn          float64 // $ per 1M tokens, 0 = unknown
	PriceOut         float64
	LightPriceIn     float64
	LightPriceOut    float64
	DailyTokenLimit  int64
	EmbeddingBaseURL string
	EmbeddingModel   string
	RequestTimeout   time.Duration
	Temperature      float64 // < 0 = unset
	Reasoning        string
	FastRounds       bool
	FastShortChars   int
	CachePrompt      bool

	// [proxy]
	ProxyEnabled bool
	ProxyPort    int

	// [memory]
	DiaryDir          string
	WorkingMemoryFile string
	DiaryTokenTrigger int
	SleepMaxTime      time.Duration
	ConfidenceFactor  float64
	MaxRelatedEntries int

	// [maintenance]
	MaintEnabled    bool
	AlertsEnabled   bool
	ReportEnabled   bool
	ReportHour      int
	DiskWarnPercent int
	CacheDays       int
	BackupEnabled   bool
	BackupKeep      int
	BackupDir       string

	// [autonomy]
	AutonomyEnabled      bool
	AutonomyMinMins      int
	AutonomyMaxMins      int
	AutonomyQuietFrom    string
	AutonomyQuietTo      string
	AutonomyTimezone     string
	AutonomyMaxPerDay    int
	AutonomyChatCooldown int // minutes

	// [presence]
	PresenceEnabled  bool
	ReadDelayMin     int // seconds before she notices a message in a private chat
	ReadDelayMax     int
	LateReplyPercent int // chance (night or asleep) that she answers much later
	LateReplyMinMins int
	LateReplyMaxMins int
	OfflineAfterSecs int
	TypingPerCharMs  int
	TypoChance       float64
	MirrorModality   bool

	// [capabilities]
	WebSearchEnabled     bool
	WebSearchURL         string // SearXNG-compatible JSON endpoint, or https://ollama.com/api/web_search
	WebSearchKey         string
	SDEnabled            bool
	SDURL                string
	STTEnabled           bool
	STTURL               string
	STTModel             string
	TTSBackend           string // none | openai | elevenlabs
	TTSURL               string
	TTSKey               string
	TTSModel             string
	TTSVoice             string
	FFmpegPath           string
	ReadLinks            bool
	LinkMaxChars         int
	DocMaxMB             int
	DocMaxChars          int
	MediaMaxMB           int
	UseStickers          bool
	LazyTools            bool
	OwnerTools           bool
	BrowserEnabled       bool
	BrowserPath          string
	BrowserXvfb          bool
	BrowserNoSandbox     bool
	BrowserWidth         int
	BrowserHeight        int
	BrowserSteps         int
	BrowserIdleSecs      int
	BrowserFast          bool
	BrowserBlockHosts    string
	Services             string
	MailIMAP             string
	MailSMTP             string
	MailUser             string
	MailPassword         string
	MailFrom             string
	MailPerDay           int
	CalendarURLs         string
	DesktopEnabled       bool
	DesktopWidth         int
	DesktopHeight        int
	DesktopSteps         int
	DesktopIdleSecs      int
	WorkEnabled          bool
	WorkEveryMins        int
	WorkMaxRuns          int
	BackupSend           bool
	BrowserPasswords     bool
	MoodEnabled          bool
	StopAfterSend        bool
	TypingThinking       bool
	ShellDir             string
	ShellUser            string
	ShellHardBlock       bool
	ShellTimeout         int64
	ForceTools           bool
	MaxMessageChars      int // a message longer than this is split into several (0 = no limit)
	TypingMinMs          int
	TypingMaxMs          int
	HistoryKeep          int
	ContextChars         int
	AutoPersonCards      bool
	AutoPromises         bool
	TicGuard             bool
	IgnorePercent        int
	BriefPercent         int
	LifeEnabled          bool
	SlowPercent          int
	GroupInterestWords   string
	GroupInterestPercent int
	VoicePercent         int
	ToolResultChars      int
	GroupReplyMode       string // addressed | all
	GroupChime           int
	GroupDebounce        time.Duration

	// [misc]
	MetricsEnabled bool
	DebugUI        bool
	AdminToken     string
	PanelChats     bool
	PanelTakeover  bool
	DeskOverview   bool
	DataDir        string
	DebugPrompt    bool
	PromptsDir     string
}

type field struct {
	section, key, comment string
	def                   any
	ptr                   func(c *Config) any
}

func fields() []field {
	f := func(s, k, comment string, def any, ptr func(c *Config) any) field {
		return field{s, k, comment, def, ptr}
	}
	return []field{
		f("general", "character_name", "the name the character uses for herself", "Reina Veil", func(c *Config) any { return &c.CharacterName }),
		f("general", "character_nickname", "", "@kunii_chan", func(c *Config) any { return &c.CharacterNick }),
		f("general", "papik_name", "the instance owner's nickname", "Alex2772", func(c *Config) any { return &c.PapikName }),
		f("general", "papik_chat_id", "the instance owner's Telegram user ID", int64(0), func(c *Config) any { return &c.PapikChatID }),
		f("general", "telegram_enabled", "set to false to run as a standalone proxy without Telegram", false, func(c *Config) any { return &c.TelegramEnabled }),

		f("telegram", "mode", "user = log in as a regular account via tdlib (like the C++ version; build with -tags tdlib); bot = Bot API", "user", func(c *Config) any { return &c.Mode }),
		f("telegram", "phone_number", "user mode: phone to log in with (asked on stdin if empty)", "", func(c *Config) any { return &c.Phone }),
		f("telegram", "tdlib_dir", "user mode: tdlib database directory (keeps the login)", "tdlib", func(c *Config) any { return &c.TDLibDir }),
		f("telegram", "bot_token", "bot mode: token from @BotFather", "", func(c *Config) any { return &c.BotToken }),
		f("telegram", "api_base", "Bot API base URL", "https://api.telegram.org", func(c *Config) any { return &c.TelegramAPI }),
		f("telegram", "api_id", "user mode: get from https://my.telegram.org", int64(0), func(c *Config) any { return &c.TelegramAPIID }),
		f("telegram", "api_hash", "user mode: get from https://my.telegram.org", "", func(c *Config) any { return &c.TelegramHash }),
		f("telegram", "lockdown", "none = everyone | contacts_only = groups, the owner and contacts | papik_only = only the owner chat", "none", func(c *Config) any { return &c.Lockdown }),
		f("telegram", "can_join_chats", "", false, func(c *Config) any { return &c.CanJoinChats }),
		f("telegram", "can_leave_chats", "", false, func(c *Config) any { return &c.CanLeaveChats }),
		f("telegram", "session_idle_secs", "dump the conversation to the diary after this much silence", int64(900), func(c *Config) any { return &c.SessionIdle }),
		f("telegram", "proactive_interval_secs", "0 disables acting proactively", int64(0), func(c *Config) any { return &c.Proactive }),
		f("telegram", "max_tool_rounds", "max LLM<->tool round-trips per turn", int64(12), func(c *Config) any { return &c.MaxToolRounds }),
		f("telegram", "debounce_ms", "wait for follow-up messages before answering", int64(800), func(c *Config) any { return &c.DebounceWindow }),

		f("llm", "base_url", "OpenAI-compatible endpoint, e.g. http://localhost:11434/v1/", "http://localhost:11434/v1/", func(c *Config) any { return &c.LLMBaseURL }),
		f("llm", "api_key", "bearer key, empty if not needed", "", func(c *Config) any { return &c.LLMAPIKey }),
		f("llm", "model", "chat model name (must support vision to view photos)", "llama3:8b", func(c *Config) any { return &c.LLMModel }),
		f("llm", "light_model", "cheap/fast model for background thinking (ask, sleep, diary, compact); empty = use model. Same endpoint and key as model", "", func(c *Config) any { return &c.LightModel }),
		f("llm", "vision_model", "model that looks at pictures (photos in chats, stickers, browser and desktop screenshots); empty = model. Must support images, e.g. google/gemini-2.5-flash. Same endpoint and key", "", func(c *Config) any { return &c.VisionModel }),
		f("llm", "price_in_per_m", "price of 1M input tokens of `model` in USD (only to show the cost on the panel; 0 = unknown)", 0.0, func(c *Config) any { return &c.PriceIn }),
		f("llm", "price_out_per_m", "price of 1M output tokens of `model` in USD", 0.0, func(c *Config) any { return &c.PriceOut }),
		f("llm", "light_price_in_per_m", "same for light_model", 0.0, func(c *Config) any { return &c.LightPriceIn }),
		f("llm", "light_price_out_per_m", "same for light_model", 0.0, func(c *Config) any { return &c.LightPriceOut }),
		f("llm", "fast_rounds", "think only where it matters: rounds that follow a tool result (and a short private message) are answered with reasoning switched off, several times faster. Turn off if she gets sloppy at multi-step work", true, func(c *Config) any { return &c.FastRounds }),
		f("llm", "fast_short_chars", "a private message up to this many characters (no files, no media) is also answered without reasoning on its first round. 0 = the first round always thinks", int64(220), func(c *Config) any { return &c.FastShortChars }),
		f("llm", "daily_token_limit", "soft daily limit (input+output tokens): past it she stops acting on her own and you get a warning; at 3x every LLM request is refused until tomorrow. 0 = no limit", int64(0), func(c *Config) any { return &c.DailyTokenLimit }),
		f("llm", "embedding_base_url", "endpoint for /embeddings (defaults to base_url if empty)", "", func(c *Config) any { return &c.EmbeddingBaseURL }),
		f("llm", "embedding_model", "embedding model name", "nomic-embed-text", func(c *Config) any { return &c.EmbeddingModel }),
		f("llm", "request_timeout_secs", "", int64(300), func(c *Config) any { return &c.RequestTimeout }),
		f("llm", "cache_prompt", "mark the system prompt cacheable for Claude models (cuts the cost of each request); other models cache a stable prefix by themselves", true, func(c *Config) any { return &c.CachePrompt }),
		f("llm", "reasoning", "OpenRouter reasoning control: empty = default, off = disable (much faster), low|medium|high", "", func(c *Config) any { return &c.Reasoning }),
		f("llm", "temperature", "negative = server default", -1.0, func(c *Config) any { return &c.Temperature }),

		f("maintenance", "enabled", "watch free disk space (warns you in Telegram, clears the image cache) and keep backups", true, func(c *Config) any { return &c.MaintEnabled }),
		f("alerts", "enabled", "she tells you in Telegram when something breaks: the model stops answering (key, balance), Telegram throws errors or slows her down", true, func(c *Config) any { return &c.AlertsEnabled }),
		f("report", "enabled", "once a day she sends you a short report of yesterday's tokens, requests, cost and free disk", true, func(c *Config) any { return &c.ReportEnabled }),
		f("report", "hour", "local hour (0-23, autonomy.timezone) when the daily report is sent", int64(9), func(c *Config) any { return &c.ReportHour }),
		f("maintenance", "disk_warn_percent", "warn when less than this percent of the disk is free (or under 500 MB)", int64(10), func(c *Config) any { return &c.DiskWarnPercent }),
		f("maintenance", "cache_days", "when the disk is low, delete cached image descriptions older than this many days", int64(30), func(c *Config) any { return &c.CacheDays }),
		f("maintenance", "backup_enabled", "daily backup of the diary, memory, prompts, mood and config (config contains your keys: the archive is private, mode 0600)", true, func(c *Config) any { return &c.BackupEnabled }),
		f("maintenance", "backup_keep", "how many daily backups to keep", int64(7), func(c *Config) any { return &c.BackupKeep }),
		f("maintenance", "backup_send", "once a day send a copy of her memory (diary, people, reminders, job queue, mood) to your private chat: the only copy that survives a dead container. The sent copy never contains config.toml (keys and passwords)", true, func(c *Config) any { return &c.BackupSend }),
		f("maintenance", "backup_dir", "where backups go (empty = <data_dir>/backups)", "", func(c *Config) any { return &c.BackupDir }),

		f("autonomy", "enabled", "she acts on her own: writes first to people, speaks her mind, goes to sleep. Respects lockdown, quiet hours and the limits below", false, func(c *Config) any { return &c.AutonomyEnabled }),
		f("autonomy", "min_interval_mins", "shortest pause between her own initiatives", int64(30), func(c *Config) any { return &c.AutonomyMinMins }),
		f("autonomy", "max_interval_mins", "longest pause between her own initiatives (the pause is random between min and max)", int64(120), func(c *Config) any { return &c.AutonomyMaxMins }),
		f("autonomy", "quiet_from", "night starts (HH:MM): no initiatives, she is sleepy. Empty = no night", "01:00", func(c *Config) any { return &c.AutonomyQuietFrom }),
		f("autonomy", "quiet_to", "night ends (HH:MM)", "09:00", func(c *Config) any { return &c.AutonomyQuietTo }),
		f("autonomy", "timezone", "IANA zone for quiet hours, e.g. Asia/Bishkek. Empty = the server's zone (often UTC)", "", func(c *Config) any { return &c.AutonomyTimezone }),
		f("autonomy", "max_messages_per_day", "most messages she may start on her own per day (your own chat is not limited)", int64(20), func(c *Config) any { return &c.AutonomyMaxPerDay }),
		f("autonomy", "chat_cooldown_mins", "minimum gap between her initiative messages to the same chat", int64(90), func(c *Config) any { return &c.AutonomyChatCooldown }),

		f("proxy", "enabled", "run the OpenAI-compatible proxy", true, func(c *Config) any { return &c.ProxyEnabled }),
		f("proxy", "port", "port of the OpenAI-compatible proxy", int64(10434), func(c *Config) any { return &c.ProxyPort }),

		f("memory", "diary_dir", "where diary entries (*.md) are stored", "data/diary", func(c *Config) any { return &c.DiaryDir }),
		f("memory", "working_memory_file", "", "data/working_memory.md", func(c *Config) any { return &c.WorkingMemoryFile }),
		f("memory", "diary_token_count_trigger", "stop merging related entries after this many characters", int64(4000), func(c *Config) any { return &c.DiaryTokenTrigger }),
		f("memory", "sleep_max_time_secs", "how long one sleep consolidation may run", int64(600), func(c *Config) any { return &c.SleepMaxTime }),
		f("memory", "confidence_factor", "weight of an entry's stored confidence in RAG ranking", 0.1, func(c *Config) any { return &c.ConfidenceFactor }),
		f("memory", "max_related_entries", "how many diary entries are injected into a prompt", int64(8), func(c *Config) any { return &c.MaxRelatedEntries }),

		f("presence", "enabled", "living presence: she does not answer instantly (reads after a pause), types as long as the text takes, and sometimes answers late at night", true, func(c *Config) any { return &c.PresenceEnabled }),
		f("presence", "read_delay_min_secs", "shortest pause before she reads a new message in a private chat (groups wait longer, your own chat much less)", int64(2), func(c *Config) any { return &c.ReadDelayMin }),
		f("presence", "read_delay_max_secs", "longest pause before she reads a new message", int64(10), func(c *Config) any { return &c.ReadDelayMax }),
		f("presence", "late_reply_percent", "at night (autonomy quiet hours) this % of messages from others is answered much later; while she is asleep always. Your own chat is never delayed", int64(35), func(c *Config) any { return &c.LateReplyPercent }),
		f("presence", "late_reply_min_mins", "a late answer comes after at least this many minutes", int64(5), func(c *Config) any { return &c.LateReplyMinMins }),
		f("presence", "late_reply_max_mins", "...and at most this many", int64(40), func(c *Config) any { return &c.LateReplyMaxMins }),
		f("presence", "slow_percent", "chance in percent that a normal message is noticed much later (she was busy): minutes in other chats, up to a minute in yours", int64(6), func(c *Config) any { return &c.SlowPercent }),
		f("realism", "tic_guard", "she watches her own last messages and is told to stop repeating habits (the same opening word, 'папик' in every line, a question at the end of everything, emoji in a row)", true, func(c *Config) any { return &c.TicGuard }),
		f("realism", "ignore_percent", "chance in percent that a bare laugh or 'ok' gets only a reaction or silence instead of an answer", int64(30), func(c *Config) any { return &c.IgnorePercent }),
		f("realism", "brief_percent", "chance in percent that a short message gets a one-to-three-word answer", int64(15), func(c *Config) any { return &c.BriefPercent }),
		f("realism", "life", "she knows roughly what she is doing at this hour (breakfast, coding, a series), the same all day, so she never contradicts herself", true, func(c *Config) any { return &c.LifeEnabled }),
		f("presence", "offline_after_secs", "how long after the last turn the account still shows online", int64(20), func(c *Config) any { return &c.OfflineAfterSecs }),

		f("capabilities", "web_search_enabled", "", false, func(c *Config) any { return &c.WebSearchEnabled }),
		f("capabilities", "web_search_url", "SearXNG (…/search) or https://ollama.com/api/web_search", "http://localhost:8888/search", func(c *Config) any { return &c.WebSearchURL }),
		f("capabilities", "web_search_key", "bearer key (ollama web search)", "", func(c *Config) any { return &c.WebSearchKey }),
		f("capabilities", "stable_diffusion_enabled", "photos via Stable Diffusion WebUI (--api)", false, func(c *Config) any { return &c.SDEnabled }),
		f("capabilities", "stable_diffusion_url", "", "http://localhost:7860", func(c *Config) any { return &c.SDURL }),
		f("capabilities", "stt_enabled", "voice/video transcription (Whisper, OpenAI-compatible)", false, func(c *Config) any { return &c.STTEnabled }),
		f("capabilities", "stt_url", "", "http://localhost:9000/v1/", func(c *Config) any { return &c.STTURL }),
		f("capabilities", "stt_model", "", "whisper-1", func(c *Config) any { return &c.STTModel }),
		f("capabilities", "tts_backend", "none | openai | elevenlabs", "none", func(c *Config) any { return &c.TTSBackend }),
		f("capabilities", "tts_url", "OpenAI-compatible base (e.g. OmniVoice http://localhost:8880/v1/) or ElevenLabs base", "http://localhost:8880/v1/", func(c *Config) any { return &c.TTSURL }),
		f("capabilities", "tts_key", "", "", func(c *Config) any { return &c.TTSKey }),
		f("capabilities", "tts_model", "", "tts-1", func(c *Config) any { return &c.TTSModel }),
		f("capabilities", "tts_voice", "voice name / ElevenLabs voice id", "alloy", func(c *Config) any { return &c.TTSVoice }),
		f("capabilities", "read_links", "she can open links people send (public web pages only; never your server, LAN or Tailscale)", true, func(c *Config) any { return &c.ReadLinks }),
		f("capabilities", "link_max_chars", "most characters of a web page that she reads at once (she can read on)", int64(5000), func(c *Config) any { return &c.LinkMaxChars }),
		f("capabilities", "document_max_mb", "documents (txt, md, csv, docx, xlsx, pdf...) from anyone up to this size can be read", int64(10), func(c *Config) any { return &c.DocMaxMB }),
		f("capabilities", "document_max_chars", "most characters of a document that she reads at once (she can read on)", int64(6000), func(c *Config) any { return &c.DocMaxChars }),
		f("capabilities", "media_max_mb", "videos, round videos and gifs larger than this are not watched", int64(25), func(c *Config) any { return &c.MediaMaxMB }),
		f("capabilities", "ffmpeg_path", "needed for video transcription", "ffmpeg", func(c *Config) any { return &c.FFmpegPath }),
		f("telegram", "max_message_chars", "one Telegram message is at most this many characters; longer text is sent as several messages (no limit on their number). 0 = no limit", int64(60), func(c *Config) any { return &c.MaxMessageChars }),
		f("telegram", "typing_min_ms", "how long the 'typing...' status shows before each message (min)", int64(3000), func(c *Config) any { return &c.TypingMinMs }),
		f("telegram", "mirror_modality", "answer the way she was addressed: a voice message for a voice message (when TTS is on), a sticker or reaction for a sticker", true, func(c *Config) any { return &c.MirrorModality }),
		f("telegram", "typo_chance", "chance of a human typo (two letters swapped / a neighbouring key) in a message, for each kind; 0 = never. Links, code, mentions and short texts are never touched", 0.02, func(c *Config) any { return &c.TypoChance }),
		f("telegram", "typing_per_char_ms", "typing time per character (a longer message types longer, between ~1 s and typing_max_ms). 0 = always random between typing_min_ms and typing_max_ms", int64(55), func(c *Config) any { return &c.TypingPerCharMs }),
		f("telegram", "typing_max_ms", "how long the 'typing...' status shows before each message (max)", int64(4000), func(c *Config) any { return &c.TypingMaxMs }),
		f("telegram", "force_tool_call", "require the model to call a tool (reply, react or #wait) on the first round of every turn; fixes models that answer in plain text instead of calling #send_telegram_message", true, func(c *Config) any { return &c.ForceTools }),
		f("capabilities", "mood_enabled", "mood scale 0-100: low = rude and swearing, middle = normal, high = flirty; shifts by events and drifts back to normal", true, func(c *Config) any { return &c.MoodEnabled }),
		f("capabilities", "owner_tools", "give the owner (papik_chat_id) shell, file and read-any-chat tools in his private chat", true, func(c *Config) any { return &c.OwnerTools }),
		f("browser", "enabled", "give the owner a real browser (Chromium) she can drive: open pages, click, type, scroll, send screenshots", true, func(c *Config) any { return &c.BrowserEnabled }),
		f("browser", "path", "browser program (empty = look for chromium / google-chrome in PATH). Alpine: apk add chromium font-noto", "", func(c *Config) any { return &c.BrowserPath }),
		f("browser", "xvfb", "run a full graphical browser on a virtual screen (needs Xvfb: apk add xvfb) instead of headless", false, func(c *Config) any { return &c.BrowserXvfb }),
		f("browser", "no_sandbox", "start Chromium with --no-sandbox (required when the program runs as root, as in containers)", true, func(c *Config) any { return &c.BrowserNoSandbox }),
		f("browser", "width", "viewport width in pixels", int64(1280), func(c *Config) any { return &c.BrowserWidth }),
		f("browser", "height", "viewport height in pixels", int64(800), func(c *Config) any { return &c.BrowserHeight }),
		f("browser", "max_steps", "most browser actions per message of the owner; protects against loops (he can say 'continue' for more)", int64(20), func(c *Config) any { return &c.BrowserSteps }),
		f("browser", "idle_secs", "close the browser after this much inactivity (frees memory; the profile with logins stays)", int64(300), func(c *Config) any { return &c.BrowserIdleSecs }),
		f("browser", "fast", "switch model reasoning off for the rounds that follow a browser step (much faster, fewer loops)", true, func(c *Config) any { return &c.BrowserFast }),
		f("browser", "block_hosts", "sites the browser never opens or stays on (comma-separated): account settings, passwords and payments of a logged-in Google account", "accounts.google.com,myaccount.google.com,payments.google.com,pay.google.com,wallet.google.com,passwords.google.com", func(c *Config) any { return &c.BrowserBlockHosts }),
		f("browser", "allow_passwords", "let her type into password fields. Off by default: she logs in with imported cookies (action=cookies), so no password ever goes through the chat or the model", false, func(c *Config) any { return &c.BrowserPasswords }),
		f("integrations", "services", "services she may call with #http_request, her keys are never shown to the model. Format: name|base url|Header: value, several separated by ;  e.g. github|https://api.github.com|Authorization: Bearer ghp_xxx", "", func(c *Config) any { return &c.Services }),
		f("mail", "imap_host", "IMAP server with the port, e.g. imap.gmail.com:993. Mail is read-only: she never marks, moves or deletes", "", func(c *Config) any { return &c.MailIMAP }),
		f("mail", "smtp_host", "SMTP server with the port, e.g. smtp.gmail.com:587 (STARTTLS) or :465 (TLS)", "", func(c *Config) any { return &c.MailSMTP }),
		f("mail", "user", "mailbox login (usually the address)", "", func(c *Config) any { return &c.MailUser }),
		f("mail", "password", "password of the mailbox. Gmail and most providers need an app password, not the main one", "", func(c *Config) any { return &c.MailPassword }),
		f("mail", "from", "address (or 'Name <address>') in From; empty = the login", "", func(c *Config) any { return &c.MailFrom }),
		f("mail", "send_per_day", "most e-mails she may send per day (0 = she cannot send)", int64(10), func(c *Config) any { return &c.MailPerDay }),
		f("calendar", "ics_urls", "calendars to read: the secret iCal address (Google Calendar: Settings > calendar > Secret address in iCal format). Format name|address, several separated by ;", "", func(c *Config) any { return &c.CalendarURLs }),
		f("desktop", "enabled", "give the owner a virtual desktop (Xvfb) where she can start programs, look at the screen, move the mouse, click and type. Needs Xvfb (Alpine: apk add xvfb)", true, func(c *Config) any { return &c.DesktopEnabled }),
		f("desktop", "width", "screen width in pixels", int64(1280), func(c *Config) any { return &c.DesktopWidth }),
		f("desktop", "height", "screen height in pixels", int64(800), func(c *Config) any { return &c.DesktopHeight }),
		f("desktop", "max_steps", "most desktop actions per message of the owner (loop protection)", int64(25), func(c *Config) any { return &c.DesktopSteps }),
		f("desktop", "idle_secs", "close the desktop and its programs after this much inactivity", int64(600), func(c *Config) any { return &c.DesktopIdleSecs }),
		f("work", "enabled", "background work: she takes jobs from her queue (#work, the owner adds them in chat) on her own, with the browser and the desktop, and reports. Every run costs tokens: set llm.daily_token_limit too", false, func(c *Config) any { return &c.WorkEnabled }),
		f("work", "every_mins", "how often she looks at the queue (minutes, at least 2)", int64(10), func(c *Config) any { return &c.WorkEveryMins }),
		f("work", "max_runs_per_day", "most background runs per day over all jobs (a hard limit of the program)", int64(12), func(c *Config) any { return &c.WorkMaxRuns }),
		f("capabilities", "shell_dir", "working directory for shell commands (empty = <data_dir>/workspace)", "", func(c *Config) any { return &c.ShellDir }),
		f("capabilities", "shell_user", "run shell commands as this unprivileged system user instead of root (create it: adduser -D reina). Empty = same user as the program", "", func(c *Config) any { return &c.ShellUser }),
		f("capabilities", "shell_hard_block", "refuse catastrophic shell commands (rm -rf /, formatting disks, reboot, curl|sh, deleting her own data) even for the owner. Off by default", false, func(c *Config) any { return &c.ShellHardBlock }),
		f("capabilities", "shell_timeout_secs", "default shell command timeout (max 600)", int64(60), func(c *Config) any { return &c.ShellTimeout }),
		f("telegram", "stop_after_send", "end the turn right after a round that only sent messages/reactions (saves one slow LLM call per reply)", true, func(c *Config) any { return &c.StopAfterSend }),
		f("telegram", "typing_while_thinking", "show 'typing' in private chats while the model thinks", true, func(c *Config) any { return &c.TypingThinking }),
		f("misc", "lazy_tools", "hide rarely used tools behind #more_tools (saves ~1.5-2k prompt tokens per request)", true, func(c *Config) any { return &c.LazyTools }),
		f("memory", "auto_person_cards", "when a private conversation ends she files 1-3 lasting facts about the person on their card (one short extra request)", true, func(c *Config) any { return &c.AutoPersonCards }),
		f("memory", "auto_promises", "when a private conversation ends she turns her own concrete promises ('напишу завтра в 10') into reminders that wake her at the time", true, func(c *Config) any { return &c.AutoPromises }),
		f("memory", "context_chars", "most characters of the session history sent with one request; older messages are dropped (cost control; ~4 chars per token)", int64(32000), func(c *Config) any { return &c.ContextChars }),
		f("memory", "old_tool_result_chars", "tool results older than the current turn are cut to this many characters", int64(300), func(c *Config) any { return &c.ToolResultChars }),
		f("telegram", "group_reply_mode", "addressed = in groups she wakes the model only when someone talks to her (reply, her name/@nick, the owner); all = every message", "addressed", func(c *Config) any { return &c.GroupReplyMode }),
		f("telegram", "group_interest_words", "topics she likes, comma-separated: in a group (reply mode addressed) a message with one of them wakes her more often", "нейросет,искусственный интеллект,код,программир,linux,линукс,музык,философи", func(c *Config) any { return &c.GroupInterestWords }),
		f("telegram", "group_interest_percent", "chance in percent that such a message wakes her (0 = off)", int64(25), func(c *Config) any { return &c.GroupInterestPercent }),
		f("telegram", "voice_percent", "when TTS is on: chance in percent that a short answer to a text message is nudged to be a voice message (0 = off)", int64(0), func(c *Config) any { return &c.VoicePercent }),
		f("telegram", "group_chime_percent", "in 'addressed' mode: chance (%) that she still looks at a group message not meant for her", int64(3), func(c *Config) any { return &c.GroupChime }),
		f("telegram", "group_debounce_secs", "groups: wait this long for follow-up messages before reading (fewer, bigger turns)", int64(5), func(c *Config) any { return &c.GroupDebounce }),
		f("memory", "history_keep", "keep this many recent session messages verbatim; older ones are summarised once there are twice as many (0 = never summarise)", int64(30), func(c *Config) any { return &c.HistoryKeep }),
		f("capabilities", "use_stickers", "", true, func(c *Config) any { return &c.UseStickers }),

		f("misc", "metrics_enabled", "Prometheus endpoint at /metrics", true, func(c *Config) any { return &c.MetricsEnabled }),
		f("misc", "panel_chats", "the panel shows her Telegram chats and messages in a Telegram-like window. Turn off if other people's private messages must never appear in the panel", true, func(c *Config) any { return &c.PanelChats }),
		f("misc", "desk_overview", "in the owner's chat (and in her own wake-ups there) she gets a short overview of her whole Telegram: chats with unread messages, mentions, who is typing, folders. Costs a few hundred tokens now and then; off = she looks herself with telegram_ui", true, func(c *Config) any { return &c.DeskOverview }),
		f("misc", "panel_takeover", "take-over mode of the Telegram window: the owner can write, react, press bot buttons, delete and pin from the panel AS HER account (each action asks for confirmation). Off by default: the window is read-only", false, func(c *Config) any { return &c.PanelTakeover }),
		f("misc", "admin_token", "password for the web admin panel at /admin (12+ chars; empty = panel disabled)", "", func(c *Config) any { return &c.AdminToken }),
		f("misc", "debug_ui", "web debug page at /debug (same port as proxy)", true, func(c *Config) any { return &c.DebugUI }),
		f("misc", "debug_prompt", "write what the model saw on its last call (system prompt tail, history, the new chat view, tool names) to <data_dir>/last_prompt.txt. For finding out why she answers off-topic; contains chat texts, turn it off afterwards", false, func(c *Config) any { return &c.DebugPrompt }),
		f("misc", "data_dir", "photos, voice, stickers, telegram state", "data", func(c *Config) any { return &c.DataDir }),
		f("misc", "prompts_dir", "prompt files; edited files are hot-reloaded", "prompts", func(c *Config) any { return &c.PromptsDir }),
	}
}

// ErrNeedsSetup is returned on the first run, after a default config.toml was written.
var ErrNeedsSetup = errors.New("config.toml was created; fill it in and start again")

// Load reads config.toml. If it does not exist, a default one is written and
// ErrNeedsSetup is returned, matching the behaviour of the C++ version.
func Load(path string) (*Config, error) {
	raw, err := os.ReadFile(path)
	if errors.Is(err, os.ErrNotExist) {
		if werr := os.WriteFile(path, []byte(defaultFileContents()), 0o644); werr != nil {
			return nil, werr
		}
		return nil, ErrNeedsSetup
	}
	if err != nil {
		return nil, err
	}
	values, err := parseTOML(string(raw))
	if err != nil {
		return nil, fmt.Errorf("%s: %w", path, err)
	}
	c := &Config{}
	for _, f := range fields() {
		v, ok := values[f.section+"."+f.key]
		if !ok {
			v = f.def
		}
		if err := assign(f.ptr(c), v); err != nil {
			return nil, fmt.Errorf("%s.%s: %w", f.section, f.key, err)
		}
	}
	// debounce_ms is stored as seconds by assign(); convert to milliseconds.
	c.DebounceWindow = c.DebounceWindow / 1000
	if c.LLMBaseURL != "" && c.LLMBaseURL[len(c.LLMBaseURL)-1] != '/' {
		c.LLMBaseURL += "/"
	}
	if c.EmbeddingBaseURL == "" {
		c.EmbeddingBaseURL = c.LLMBaseURL
	} else if c.EmbeddingBaseURL[len(c.EmbeddingBaseURL)-1] != '/' {
		c.EmbeddingBaseURL += "/"
	}
	return c, nil
}

func assign(dst any, v any) error {
	switch p := dst.(type) {
	case *string:
		s, ok := v.(string)
		if !ok {
			return fmt.Errorf("want string, got %T", v)
		}
		*p = s
	case *bool:
		b, ok := v.(bool)
		if !ok {
			return fmt.Errorf("want bool, got %T", v)
		}
		*p = b
	case *int64:
		n, err := toInt(v)
		if err != nil {
			return err
		}
		*p = n
	case *int:
		n, err := toInt(v)
		if err != nil {
			return err
		}
		*p = int(n)
	case *float64:
		switch t := v.(type) {
		case float64:
			*p = t
		case int64:
			*p = float64(t)
		default:
			return fmt.Errorf("want number, got %T", v)
		}
	case *time.Duration:
		// keys are named *_secs (or debounce_ms, handled by the unit below)
		n, err := toInt(v)
		if err != nil {
			return err
		}
		*p = time.Duration(n) * time.Second
	default:
		return fmt.Errorf("unsupported field type %T", dst)
	}
	return nil
}

func toInt(v any) (int64, error) {
	switch t := v.(type) {
	case int64:
		return t, nil
	case float64:
		return int64(t), nil
	}
	return 0, fmt.Errorf("want integer, got %T", v)
}

func defaultFileContents() string {
	var sections []tomlSection
	seen := map[string]int{}
	for _, f := range fields() {
		idx, ok := seen[f.section]
		if !ok {
			idx = len(sections)
			seen[f.section] = idx
			sections = append(sections, tomlSection{name: f.section})
		}
		sections[idx].items = append(sections[idx].items, tomlItem{key: f.key, value: f.def, comment: f.comment})
	}
	return formatTOML(sections)
}

// Holder gives lock-free access to the current config and notifies on reload.
type Holder struct {
	p         atomic.Pointer[Config]
	path      string
	listeners []func(*Config)
}

// NewHolder loads the config once.
func NewHolder(path string) (*Holder, error) {
	c, err := Load(path)
	if err != nil {
		return nil, err
	}
	h := &Holder{path: path}
	h.p.Store(c)
	return h, nil
}

// NewStaticHolder wraps an already-built config (tests).
func NewStaticHolder(c *Config) *Holder {
	h := &Holder{}
	h.p.Store(c)
	return h
}

func (h *Holder) Get() *Config { return h.p.Load() }

// OnChange registers a listener called (on the watcher goroutine) after a successful reload.
// Register before calling Watch.
func (h *Holder) OnChange(f func(*Config)) { h.listeners = append(h.listeners, f) }

// Watch hot-reloads the config file until ctx is done. A broken file keeps the old config.
func (h *Holder) Watch(ctx context.Context) {
	util.Watch(ctx, 2*time.Second, func() []string { return []string{h.path} }, func(string) {
		c, err := Load(h.path)
		if err != nil {
			log.Printf("config: reload failed, keeping old config: %v", err)
			return
		}
		h.p.Store(c)
		log.Printf("config: reloaded")
		for _, l := range h.listeners {
			l(c)
		}
	})
}
