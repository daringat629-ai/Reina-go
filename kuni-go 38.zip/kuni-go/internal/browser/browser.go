// Package browser drives a real Chromium through the DevTools protocol (stdlib only): it opens pages, lists what can be
// clicked (numbered, so the model never guesses coordinates), clicks, types, scrolls and takes screenshots.
// It runs headless or, with Xvfb, as a full graphical browser on a virtual screen nobody sees.
package browser

import (
	"bufio"
	"context"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"
	"unicode/utf8"
)

// Options are the settings of one call (they may change between calls; a running browser keeps what it started with).
type Options struct {
	Path           string // browser binary; empty = look for chromium / chrome
	ProfileDir     string // persistent profile: logins and cookies survive restarts
	Width          int    // viewport
	Height         int
	Xvfb           bool          // graphical browser on a virtual display instead of headless
	NoSandbox      bool          // needed when running as root (containers)
	AllowPasswords bool          // let her type into password fields (off: logins go through imported cookies)
	Idle           time.Duration // close the browser after this much inactivity
}

func (o *Options) defaults() {
	if o.Width < 320 {
		o.Width = 1280
	}
	if o.Height < 240 {
		o.Height = 800
	}
	if o.Idle <= 0 {
		o.Idle = 5 * time.Minute
	}
}

// Browser is one lazily started browser with one working tab.
type Browser struct {
	mu       sync.Mutex
	opt      Options
	cmd      *exec.Cmd
	xvfb     *exec.Cmd
	exited   chan struct{}
	port     int
	livePort atomic.Int32 // the debugging port while the browser runs, readable without the lock (live view)
	frameMu  sync.Mutex
	frameAt  time.Time
	frame    []byte
	page     *cdp
	pageID   string
	known    map[string]bool
	loadCh   chan struct{}
	notes    []string
	idle     *time.Timer
}

func New() *Browser { return &Browser{} }

// Do runs fn with the browser started and the lock held, and re-arms the idle timer.
func (b *Browser) Do(ctx context.Context, opt Options, fn func(s *Session) error) error {
	opt.defaults()
	b.mu.Lock()
	defer b.mu.Unlock()
	if b.idle != nil {
		b.idle.Stop()
	}
	if err := b.ensure(ctx, opt); err != nil {
		b.closeLocked()
		return err
	}
	err := fn(&Session{b: b, passwords: opt.AllowPasswords})
	b.idle = time.AfterFunc(b.opt.Idle, b.Close)
	return err
}

// Running says whether a browser process is alive.
func (b *Browser) Running() bool {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.cmd != nil && !b.isExited()
}

func (b *Browser) isExited() bool {
	select {
	case <-b.exited:
		return true
	default:
		return false
	}
}

// Close stops the browser and the virtual screen.
func (b *Browser) Close() {
	b.mu.Lock()
	defer b.mu.Unlock()
	b.closeLocked()
}

func (b *Browser) closeLocked() {
	b.livePort.Store(0)
	if b.idle != nil {
		b.idle.Stop()
		b.idle = nil
	}
	if b.page != nil {
		b.page.close()
		b.page = nil
	}
	if b.cmd != nil {
		killTree(b.cmd.Process)
		b.cmd = nil
	}
	if b.xvfb != nil {
		killTree(b.xvfb.Process)
		b.xvfb = nil
	}
	b.known = nil
}

// Find returns the browser binary: the configured one or the first of the usual names.
func Find(configured string) string {
	if configured != "" {
		if p, err := exec.LookPath(configured); err == nil {
			return p
		}
		return ""
	}
	for _, n := range []string{"chromium", "chromium-browser", "google-chrome", "google-chrome-stable", "chrome"} {
		if p, err := exec.LookPath(n); err == nil {
			return p
		}
	}
	if root := os.Getenv("PLAYWRIGHT_BROWSERS_PATH"); root != "" {
		if m, _ := filepath.Glob(filepath.Join(root, "chromium-*", "chrome-linux", "chrome")); len(m) > 0 {
			return m[len(m)-1]
		}
	}
	return ""
}

const installHint = "в браузере нет: поставь chromium (Alpine: apk add chromium font-noto; для графического режима ещё apk add xvfb) или укажи browser.path"

func (b *Browser) ensure(ctx context.Context, opt Options) error {
	if b.cmd != nil && !b.isExited() && b.page != nil {
		select {
		case <-b.page.done: // the tab died; take any other one
			b.page = nil
		default:
			return nil
		}
	}
	if b.cmd != nil && !b.isExited() {
		return b.attachAny(ctx)
	}
	b.closeLocked()
	b.opt = opt
	bin := Find(opt.Path)
	if bin == "" {
		return errors.New(installHint)
	}
	if opt.ProfileDir == "" {
		return errors.New("browser: no profile directory")
	}
	if err := os.MkdirAll(opt.ProfileDir, 0o755); err != nil {
		return err
	}
	for _, f := range []string{"DevToolsActivePort", "SingletonLock", "SingletonCookie", "SingletonSocket"} {
		_ = os.Remove(filepath.Join(opt.ProfileDir, f))
	}
	env := os.Environ()
	if opt.Xvfb {
		display, x, err := startXvfb(ctx, opt)
		if err != nil {
			return err
		}
		b.xvfb = x
		env = append(env, "DISPLAY="+display)
	}
	args := []string{
		"--user-data-dir=" + opt.ProfileDir, "--remote-debugging-port=0", "--remote-debugging-address=127.0.0.1",
		"--no-first-run", "--no-default-browser-check", "--disable-gpu", "--disable-dev-shm-usage",
		"--disable-background-networking", "--disable-sync", "--disable-extensions", "--mute-audio",
		"--disable-features=Translate,MediaRouter", "--password-store=basic", "--use-mock-keychain",
		"--disk-cache-size=52428800", "--media-cache-size=1", "--js-flags=--max-old-space-size=384",
		fmt.Sprintf("--window-size=%d,%d", opt.Width, opt.Height), "--lang=ru-RU",
	}
	if !opt.Xvfb {
		args = append(args, "--headless=new")
	}
	if opt.NoSandbox || isRoot() {
		args = append(args, "--no-sandbox")
	}
	args = append(args, "about:blank")
	cmd := exec.Command(bin, args...)
	cmd.Env = env
	ownGroup(cmd)
	if err := cmd.Start(); err != nil {
		return fmt.Errorf("browser: не запустился: %w", err)
	}
	b.cmd = cmd
	b.exited = make(chan struct{})
	exited := b.exited
	go func() { _ = cmd.Wait(); close(exited) }()

	portFile := filepath.Join(opt.ProfileDir, "DevToolsActivePort")
	deadline := time.Now().Add(25 * time.Second)
	for {
		if raw, err := os.ReadFile(portFile); err == nil {
			if first, _, _ := strings.Cut(string(raw), "\n"); first != "" {
				if p, err := strconv.Atoi(strings.TrimSpace(first)); err == nil && p > 0 {
					b.port = p
					b.livePort.Store(int32(p))
					break
				}
			}
		}
		if b.isExited() {
			return errors.New("browser: процесс завершился при запуске (проверь, что chromium работает от этого пользователя)")
		}
		if time.Now().After(deadline) {
			return errors.New("browser: не дождался запуска за 25 с")
		}
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-time.After(100 * time.Millisecond):
		}
	}
	b.known = map[string]bool{}
	b.loadCh = make(chan struct{}, 1)
	return b.attachAny(ctx)
}

type target struct {
	ID    string `json:"id"`
	Type  string `json:"type"`
	URL   string `json:"url"`
	WSURL string `json:"webSocketDebuggerUrl"`
}

func (b *Browser) targets(ctx context.Context) ([]target, error) { return targetsAt(ctx, b.port) }

func targetsAt(ctx context.Context, port int) ([]target, error) {
	req, _ := http.NewRequestWithContext(ctx, "GET", fmt.Sprintf("http://127.0.0.1:%d/json/list", port), nil)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	var all []target
	if err := json.NewDecoder(io.LimitReader(resp.Body, 4<<20)).Decode(&all); err != nil {
		return nil, err
	}
	var pages []target
	for _, t := range all {
		if t.Type == "page" && t.WSURL != "" {
			pages = append(pages, t)
		}
	}
	return pages, nil
}

func (b *Browser) newTab(ctx context.Context) error {
	req, _ := http.NewRequestWithContext(ctx, "PUT", fmt.Sprintf("http://127.0.0.1:%d/json/new?about:blank", b.port), nil)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return err
	}
	resp.Body.Close()
	return nil
}

// attachAny connects to the newest open tab (opening a blank one if the last was closed).
func (b *Browser) attachAny(ctx context.Context) error {
	ts, err := b.targets(ctx)
	if err != nil {
		return fmt.Errorf("browser: %w", err)
	}
	if len(ts) == 0 {
		if err := b.newTab(ctx); err != nil {
			return err
		}
		if ts, err = b.targets(ctx); err != nil || len(ts) == 0 {
			return errors.New("browser: нет ни одной вкладки")
		}
	}
	return b.attach(ctx, ts[0])
}

func (b *Browser) attach(ctx context.Context, t target) error {
	ws, err := dialWS(ctx, t.WSURL)
	if err != nil {
		return err
	}
	if b.page != nil {
		b.page.close()
	}
	if b.loadCh == nil {
		b.loadCh = make(chan struct{}, 1)
	}
	if b.known == nil {
		b.known = map[string]bool{}
	}
	var c *cdp
	c = newCDP(ws, func(method string, params json.RawMessage) {
		switch method {
		case "Page.loadEventFired":
			select {
			case b.loadCh <- struct{}{}:
			default:
			}
		case "Page.javascriptDialogOpening":
			var p struct {
				Message string `json:"message"`
				Type    string `json:"type"`
			}
			_ = json.Unmarshal(params, &p)
			b.notes = append(b.notes, fmt.Sprintf("окно %s: «%s» (закрыто само)", p.Type, p.Message))
			go func() {
				ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
				defer cancel()
				_ = c.call(ctx, "Page.handleJavaScriptDialog", map[string]any{"accept": true}, nil)
			}()
		}
	})
	b.page, b.pageID = c, t.ID
	b.known[t.ID] = true
	for _, m := range []string{"Page.enable", "Runtime.enable"} {
		if err := c.call(ctx, m, nil, nil); err != nil {
			return err
		}
	}
	_ = c.call(ctx, "Emulation.setDeviceMetricsOverride", map[string]any{"width": b.opt.Width, "height": b.opt.Height, "deviceScaleFactor": 1, "mobile": false}, nil)
	_ = c.call(ctx, "Page.setDownloadBehavior", map[string]any{"behavior": "deny"}, nil)
	return nil
}

func startXvfb(ctx context.Context, opt Options) (string, *exec.Cmd, error) {
	bin, err := exec.LookPath("Xvfb")
	if err != nil {
		return "", nil, errors.New("browser: Xvfb не найден (Alpine: apk add xvfb) — или выключи browser.xvfb, тогда браузер запустится без экрана")
	}
	r, w, err := os.Pipe()
	if err != nil {
		return "", nil, err
	}
	defer r.Close()
	cmd := exec.Command(bin, "-displayfd", "3", "-screen", "0", fmt.Sprintf("%dx%dx24", opt.Width+100, opt.Height+100), "-nolisten", "tcp")
	cmd.ExtraFiles = []*os.File{w}
	ownGroup(cmd)
	if err := cmd.Start(); err != nil {
		w.Close()
		return "", nil, err
	}
	w.Close()
	go func() { _ = cmd.Wait() }()
	got := make(chan string, 1)
	go func() {
		line, _ := bufio.NewReader(r).ReadString('\n')
		got <- strings.TrimSpace(line)
	}()
	select {
	case n := <-got:
		if n == "" {
			killTree(cmd.Process)
			return "", nil, errors.New("browser: Xvfb не запустился")
		}
		return ":" + n, cmd, nil
	case <-time.After(10 * time.Second):
		killTree(cmd.Process)
		return "", nil, errors.New("browser: Xvfb не ответил за 10 с")
	case <-ctx.Done():
		killTree(cmd.Process)
		return "", nil, ctx.Err()
	}
}

// Session is the browser while a Do call holds it.
type Session struct {
	b         *Browser
	passwords bool
}

func (s *Session) eval(ctx context.Context, js string, out any) error {
	var r struct {
		Result struct {
			Value json.RawMessage `json:"value"`
		} `json:"result"`
		Exception *struct {
			Text      string `json:"text"`
			Exception struct {
				Description string `json:"description"`
			} `json:"exception"`
		} `json:"exceptionDetails"`
	}
	err := s.b.page.call(ctx, "Runtime.evaluate", map[string]any{"expression": js, "returnByValue": true, "awaitPromise": true, "timeout": 15000}, &r)
	if err != nil {
		return err
	}
	if r.Exception != nil {
		d := r.Exception.Exception.Description
		if d == "" {
			d = r.Exception.Text
		}
		return errors.New("страница: " + firstLine(d))
	}
	if out != nil && len(r.Result.Value) > 0 {
		return json.Unmarshal(r.Result.Value, out)
	}
	return nil
}

func firstLine(s string) string {
	s, _, _ = strings.Cut(s, "\n")
	return s
}

// settle waits until the page stops loading (a click may have started a navigation).
func (s *Session) settle(ctx context.Context) {
	sleep(ctx, 350*time.Millisecond)
	deadline := time.Now().Add(10 * time.Second)
	for time.Now().Before(deadline) {
		var st string
		if err := s.eval(ctx, "document.readyState", &st); err != nil || st == "complete" {
			break
		}
		sleep(ctx, 120*time.Millisecond)
	}
	sleep(ctx, 150*time.Millisecond)
	s.followPopup(ctx)
}

func sleep(ctx context.Context, d time.Duration) {
	select {
	case <-ctx.Done():
	case <-time.After(d):
	}
}

// followPopup switches to a tab the page opened (links with target=_blank, window.open).
func (s *Session) followPopup(ctx context.Context) {
	b := s.b
	ts, err := b.targets(ctx)
	if err != nil {
		return
	}
	for i := len(ts) - 1; i >= 0; i-- {
		if !b.known[ts[i].ID] {
			if b.attach(ctx, ts[i]) == nil {
				b.notes = append(b.notes, "страница открыла новую вкладку, я перешла в неё")
			}
			return
		}
	}
}

// allowedURL accepts only ordinary web addresses (no file:, chrome:, javascript:, data:).
func allowedURL(raw string) (string, error) {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return "", errors.New("нужен адрес")
	}
	if !strings.Contains(raw, "://") && !strings.HasPrefix(raw, "about:") {
		raw = "https://" + raw
	}
	u, err := url.Parse(raw)
	if err != nil || (u.Scheme != "http" && u.Scheme != "https") || u.Host == "" {
		return "", fmt.Errorf("открываю только http/https, а не %q", raw)
	}
	return u.String(), nil
}

// Open navigates the tab to a web address.
func (s *Session) Open(ctx context.Context, raw string) error {
	u, err := allowedURL(raw)
	if err != nil {
		return err
	}
	select {
	case <-s.b.loadCh:
	default:
	}
	var r struct {
		ErrorText string `json:"errorText"`
	}
	if err := s.b.page.call(ctx, "Page.navigate", map[string]any{"url": u}, &r); err != nil {
		return err
	}
	if r.ErrorText != "" {
		return fmt.Errorf("не открылась: %s", r.ErrorText)
	}
	select {
	case <-s.b.loadCh:
	case <-time.After(20 * time.Second):
	case <-ctx.Done():
	}
	s.settle(ctx)
	return nil
}

// Element is something on the page that can be clicked or filled.
type Element struct {
	ID      int    `json:"id"`
	Tag     string `json:"tag"`
	Type    string `json:"type"`
	Label   string `json:"label"`
	Href    string `json:"href"`
	Value   string `json:"value"`
	Checked bool   `json:"checked"`
}

// Snapshot is what the model gets to see after each step.
type Snapshot struct {
	URL      string    `json:"url"`
	Title    string    `json:"title"`
	Els      []Element `json:"els"`
	Text     string    `json:"text"`
	TextLen  int       `json:"textLen"`
	ScrollY  float64   `json:"sy"`
	Height   float64   `json:"sh"`
	Viewport float64   `json:"ih"`
	Notes    []string  `json:"-"`
}

const lookJS = `(()=>{
 const vis=e=>{const r=e.getBoundingClientRect();if(r.width<4||r.height<4)return false;const s=getComputedStyle(e);
  if(s.visibility==='hidden'||s.display==='none'||+s.opacity===0)return false;return r.bottom>0&&r.right>0&&r.top<innerHeight&&r.left<innerWidth};
 document.querySelectorAll('[data-kid]').forEach(e=>e.removeAttribute('data-kid'));
 const sel='a[href],button,input:not([type=hidden]),select,textarea,summary,[role=button],[role=link],[role=tab],[role=menuitem],[role=checkbox],[role=option],[onclick],[contenteditable=""],[contenteditable=true]';
 const out=[];let n=0;
 for(const e of document.querySelectorAll(sel)){
  if(!vis(e))continue;
  if(e.tagName==='A'&&e.target==='_blank')e.target='_self';
  const id=++n;e.setAttribute('data-kid',id);
  const inp=e.tagName==='INPUT'||e.tagName==='TEXTAREA';
  const aria=e.getAttribute('aria-label')||'';
  let label,val='';
  if(e.tagName==='SELECT'){label=(aria||e.name||e.id||'список')+' ['+Array.from(e.options).map(o=>o.text.trim()).join(' | ').slice(0,80)+']';val=e.selectedOptions[0]?e.selectedOptions[0].text.trim():''}
  else if(inp){label=aria||e.placeholder||e.title||e.name||e.id||'';val=e.type!=='password'?String(e.value||'').slice(0,40):''}
  else label=aria||e.innerText||e.value||e.title||e.alt||e.name||'';
  label=label.replace(/\s+/g,' ').trim().slice(0,90);
  if(!label&&e.querySelector('img[alt]'))label=e.querySelector('img[alt]').alt.slice(0,70);
  out.push({id:id,tag:e.tagName.toLowerCase(),type:e.type||'',label:label,href:e.tagName==='A'?e.href:'',value:val,checked:!!e.checked});
  if(n>=` + "45" + `)break;
 }
 const t=document.body?document.body.innerText:'';
 return JSON.stringify({url:location.href,title:document.title,els:out,text:t.slice(0,%d),textLen:t.length,sy:scrollY,sh:document.documentElement.scrollHeight,ih:innerHeight});
})()`

// Look describes the page: address, title, numbered elements on the screen and the start of the visible text.
func (s *Session) Look(ctx context.Context, textChars int) (Snapshot, error) {
	if textChars <= 0 {
		textChars = 1000
	}
	var raw string
	if err := s.eval(ctx, fmt.Sprintf(lookJS, textChars), &raw); err != nil {
		return Snapshot{}, err
	}
	var sn Snapshot
	if err := json.Unmarshal([]byte(raw), &sn); err != nil {
		return Snapshot{}, err
	}
	sn.Notes, s.b.notes = s.b.notes, nil
	return sn, nil
}

// Fingerprint is equal for two snapshots of an unchanged page (used to notice a loop).
func (sn Snapshot) Fingerprint() string {
	var b strings.Builder
	b.WriteString(sn.URL)
	fmt.Fprintf(&b, "|%d|%d|", int(sn.ScrollY), len(sn.Els))
	for _, e := range sn.Els {
		b.WriteString(e.Label + e.Value + ";")
	}
	t := sn.Text
	if len(t) > 300 {
		t = t[:300]
	}
	return b.String() + t
}

// String renders the snapshot compactly for the model.
func (sn Snapshot) String() string {
	var b strings.Builder
	fmt.Fprintf(&b, "%s — «%s»\n", sn.URL, sn.Title)
	pos := "страница целиком на экране"
	if sn.Height > sn.Viewport+8 {
		pct := int((sn.ScrollY + sn.Viewport) * 100 / sn.Height)
		if pct > 100 {
			pct = 100
		}
		pos = fmt.Sprintf("показано до %d%% страницы", pct)
		if sn.ScrollY+sn.Viewport >= sn.Height-8 {
			pos += " (конец)"
		}
	}
	b.WriteString(pos + "\n")
	for _, n := range sn.Notes {
		b.WriteString("! " + n + "\n")
	}
	if len(sn.Els) == 0 {
		b.WriteString("Кликабельных элементов на экране нет.\n")
	} else {
		b.WriteString("Элементы (номер — что это):\n")
		for _, e := range sn.Els {
			kind := e.Tag
			if e.Type != "" && e.Tag == "input" {
				kind += "/" + e.Type
			}
			line := fmt.Sprintf("%d %s «%s»", e.ID, kind, e.Label)
			if e.Value != "" && e.Value != e.Label {
				line += " = «" + e.Value + "»"
			}
			if e.Checked {
				line += " ✓"
			}
			if e.Href != "" {
				line += " → " + shortURL(e.Href)
			}
			b.WriteString(line + "\n")
		}
	}
	if t := strings.TrimSpace(sn.Text); t != "" {
		more := ""
		if sn.TextLen > utf8.RuneCountInString(sn.Text) {
			more = fmt.Sprintf(" …(всего %d символов, остальное: action=text)", sn.TextLen)
		}
		b.WriteString("Текст страницы:\n" + collapse(t) + more + "\n")
	}
	return b.String()
}

func shortURL(s string) string {
	s = strings.TrimPrefix(strings.TrimPrefix(s, "https://"), "http://")
	if r := []rune(s); len(r) > 60 {
		s = string(r[:60]) + "…"
	}
	return s
}

func collapse(t string) string {
	lines := strings.Split(t, "\n")
	out := lines[:0]
	for _, l := range lines {
		if l = strings.TrimSpace(l); l != "" {
			out = append(out, l)
		}
	}
	return strings.Join(out, "\n")
}

func (s *Session) rect(ctx context.Context, id int) (x, y float64, err error) {
	var pt []float64
	js := fmt.Sprintf(`(()=>{const e=document.querySelector('[data-kid="%d"]');if(!e)return null;e.scrollIntoView({block:'center',inline:'center'});
 const r=e.getBoundingClientRect();return [r.x+r.width/2,r.y+r.height/2]})()`, id)
	if err = s.eval(ctx, js, &pt); err != nil {
		return
	}
	if len(pt) != 2 {
		return 0, 0, fmt.Errorf("элемента %d уже нет на странице — сделай look и выбери номер заново", id)
	}
	return pt[0], pt[1], nil
}

// ClickAt clicks at viewport coordinates.
func (s *Session) ClickAt(ctx context.Context, x, y float64) error {
	for _, ev := range []map[string]any{
		{"type": "mouseMoved", "x": x, "y": y},
		{"type": "mousePressed", "x": x, "y": y, "button": "left", "clickCount": 1},
		{"type": "mouseReleased", "x": x, "y": y, "button": "left", "clickCount": 1},
	} {
		if err := s.b.page.call(ctx, "Input.dispatchMouseEvent", ev, nil); err != nil {
			return err
		}
	}
	s.settle(ctx)
	return nil
}

// Click clicks the numbered element from the last Look.
func (s *Session) Click(ctx context.Context, id int) error {
	x, y, err := s.rect(ctx, id)
	if err != nil {
		return err
	}
	return s.ClickAt(ctx, x, y)
}

// Type fills the numbered element (id 0 = whatever is focused). clear replaces the old content; submit presses Enter.
func (s *Session) Type(ctx context.Context, id int, text string, clear, submit bool) error {
	if id > 0 {
		js := fmt.Sprintf(`(()=>{const e=document.querySelector('[data-kid="%d"]');if(!e)return 'gone';e.scrollIntoView({block:'center'});
 if(e.tagName==='INPUT'&&e.type==='password'&&!%t)return 'password';
 if(e.tagName==='SELECT'){const t=%s.toLowerCase();for(const o of e.options){if(o.text.toLowerCase().includes(t)||o.value.toLowerCase()===t){e.value=o.value;
  e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));return 'selected'}}return 'nooption'}
 e.focus();
 if(e.isContentEditable){document.execCommand('selectAll');if(!%t){const r=document.getSelection();r.collapseToEnd()}}
 else if(typeof e.select==='function'){%s}
 return 'ok'})()`, id, s.passwords, jsStr(text), clear, "if("+boolJS(clear)+"){e.select()}else{try{e.setSelectionRange(e.value.length,e.value.length)}catch(_){}}")
		var res string
		if err := s.eval(ctx, js, &res); err != nil {
			return err
		}
		switch res {
		case "gone":
			return fmt.Errorf("элемента %d уже нет на странице — сделай look и выбери номер заново", id)
		case "password":
			return errors.New("в поля пароля я не пишу: войти надо через импорт cookies (action=cookies), пароль в чат слать не нужно")
		case "nooption":
			return errors.New("в списке нет такого варианта")
		case "selected":
			s.settle(ctx)
			return nil
		}
	}
	if text != "" {
		if err := s.b.page.call(ctx, "Input.insertText", map[string]any{"text": text}, nil); err != nil {
			return err
		}
	}
	if submit {
		return s.Key(ctx, "Enter")
	}
	sleep(ctx, 200*time.Millisecond)
	return nil
}

func boolJS(b bool) string {
	if b {
		return "true"
	}
	return "false"
}

func jsStr(s string) string { b, _ := json.Marshal(s); return string(b) }

var keys = map[string]struct {
	code string
	vk   int
	text string
}{
	"Enter": {"Enter", 13, "\r"}, "Tab": {"Tab", 9, ""}, "Escape": {"Escape", 27, ""}, "Backspace": {"Backspace", 8, ""},
	"ArrowDown": {"ArrowDown", 40, ""}, "ArrowUp": {"ArrowUp", 38, ""}, "ArrowLeft": {"ArrowLeft", 37, ""}, "ArrowRight": {"ArrowRight", 39, ""},
	"PageDown": {"PageDown", 34, ""}, "PageUp": {"PageUp", 33, ""}, "End": {"End", 35, ""}, "Home": {"Home", 36, ""}, " ": {"Space", 32, " "},
	"Delete": {"Delete", 46, ""},
}

// Key presses one key (Enter, Tab, Escape, Backspace, arrows, PageDown...).
func (s *Session) Key(ctx context.Context, name string) error {
	k, ok := keys[name]
	if !ok {
		if strings.EqualFold(name, "space") {
			k, ok = keys[" "], true
			name = " "
		}
		for n, v := range keys {
			if strings.EqualFold(n, name) {
				k, ok, name = v, true, n
			}
		}
	}
	if !ok {
		return fmt.Errorf("не знаю клавишу %q (есть Enter, Tab, Escape, Backspace, Delete, ArrowUp/Down/Left/Right, PageUp/Down, Home, End, Space)", name)
	}
	down := map[string]any{"type": "keyDown", "key": name, "code": k.code, "windowsVirtualKeyCode": k.vk}
	if k.text != "" {
		down["text"] = k.text
	}
	if err := s.b.page.call(ctx, "Input.dispatchKeyEvent", down, nil); err != nil {
		return err
	}
	if err := s.b.page.call(ctx, "Input.dispatchKeyEvent", map[string]any{"type": "keyUp", "key": name, "code": k.code, "windowsVirtualKeyCode": k.vk}, nil); err != nil {
		return err
	}
	s.settle(ctx)
	return nil
}

// Scroll moves the page: down, up, top or bottom.
func (s *Session) Scroll(ctx context.Context, dir string) error {
	var js string
	switch strings.ToLower(dir) {
	case "up":
		js = "scrollBy(0,-Math.round(innerHeight*0.85))"
	case "top":
		js = "scrollTo(0,0)"
	case "bottom":
		js = "scrollTo(0,document.documentElement.scrollHeight)"
	default:
		js = "scrollBy(0,Math.round(innerHeight*0.85))"
	}
	if err := s.eval(ctx, js, nil); err != nil {
		return err
	}
	sleep(ctx, 400*time.Millisecond)
	return nil
}

// Back goes one step back in the history.
func (s *Session) Back(ctx context.Context) error {
	if err := s.eval(ctx, "history.back()", nil); err != nil {
		return err
	}
	s.settle(ctx)
	return nil
}

// Text returns a slice of the whole page text starting at offset (in characters) and the total length.
func (s *Session) Text(ctx context.Context, offset, n int) (string, int, error) {
	var t string
	if err := s.eval(ctx, "document.body?document.body.innerText:''", &t); err != nil {
		return "", 0, err
	}
	r := []rune(collapse(t))
	total := len(r)
	if offset < 0 {
		offset = 0
	}
	if offset > total {
		offset = total
	}
	end := offset + n
	if end > total {
		end = total
	}
	return string(r[offset:end]), total, nil
}

// Shot takes a screenshot: the visible part, or the whole page (up to 6000 px) as JPEG.
func (s *Session) Shot(ctx context.Context, full bool) ([]byte, string, error) {
	params := map[string]any{"format": "png"}
	ext := "png"
	if full {
		var m struct {
			Content struct {
				Width, Height float64
			} `json:"cssContentSize"`
		}
		if err := s.b.page.call(ctx, "Page.getLayoutMetrics", nil, &m); err != nil {
			return nil, "", err
		}
		h := m.Content.Height
		if h > 6000 {
			h = 6000
		}
		if h > 0 {
			params = map[string]any{"format": "jpeg", "quality": 80, "captureBeyondViewport": true,
				"clip": map[string]any{"x": 0, "y": 0, "width": float64(s.b.opt.Width), "height": h, "scale": 1}}
			ext = "jpg"
		}
	}
	var r struct {
		Data string `json:"data"`
	}
	if err := s.b.page.call(ctx, "Page.captureScreenshot", params, &r); err != nil {
		return nil, "", err
	}
	data, err := base64.StdEncoding.DecodeString(r.Data)
	if err != nil {
		return nil, "", err
	}
	return data, ext, nil
}

var timeNow = time.Now

// Frame returns the current tab as a JPEG for the live view. It uses its own connection to the tab, so it does not wait
// for (nor disturb) the actions in progress, and frames are cached for 400 ms. ok is false when the browser is not running.
func (b *Browser) Frame(ctx context.Context) (data []byte, ok bool, err error) {
	port := int(b.livePort.Load())
	if port == 0 {
		return nil, false, nil
	}
	b.frameMu.Lock()
	defer b.frameMu.Unlock()
	if b.frame != nil && time.Since(b.frameAt) < 400*time.Millisecond {
		return b.frame, true, nil
	}
	ctx, cancel := context.WithTimeout(ctx, 6*time.Second)
	defer cancel()
	ts, err := targetsAt(ctx, port)
	if err != nil || len(ts) == 0 {
		return nil, false, err
	}
	ws, err := dialWS(ctx, ts[0].WSURL)
	if err != nil {
		return nil, false, err
	}
	c := newCDP(ws, nil)
	defer c.close()
	var r struct {
		Data string `json:"data"`
	}
	if err := c.call(ctx, "Page.captureScreenshot", map[string]any{"format": "jpeg", "quality": 60}, &r); err != nil {
		return nil, false, err
	}
	if data, err = base64.StdEncoding.DecodeString(r.Data); err != nil {
		return nil, false, err
	}
	b.frame, b.frameAt = data, time.Now()
	return data, true, nil
}

// Live says whether the browser is up, without waiting for the actions in progress.
func (b *Browser) Live() bool { return b.livePort.Load() != 0 }
