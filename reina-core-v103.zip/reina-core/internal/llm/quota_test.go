package llm

import "testing"

func TestQuotaSpentIsNotRetried(t *testing.T) {
	if !quotaSpent(429, "68400", "") || !quotaSpent(429, "", `{"error":{"status":"RESOURCE_EXHAUSTED","message":"quota"}}`) {
		t.Fatal("a spent quota must be recognised")
	}
	if quotaSpent(429, "2", "slow down") || quotaSpent(500, "99999", "") {
		t.Fatal("a short rate limit is still retried")
	}
	if (&APIError{Status: 429, Exhausted: true}).Temporary() {
		t.Fatal("exhausted must be permanent")
	}
}
