package tools

import (
	"context"
	"fmt"
	"strings"

	"kuni/internal/world"
)

// worldTool is her body in the 3D block world: she sees, walks, builds and talks there.
func WorldTool(d Deps) Tool {
	return Tool{
		Name: "world",
		Description: "Your own body in the 3D block world (a Minecraft-like endless sandbox the owner can join from a browser). Actions: look = what is around you (players, blocks, a top-down map) | " +
			"goto(x, z) = walk there | follow(name) = walk after a player | stop | say(text) = speak in the world chat (the owner sees it there) | " +
			"build(kind, x, z, size, block, block2) = BUILD A WHOLE BUILDING by itself (kinds: " + world.Kinds + "; x,z = the ground corner, size = main size in blocks, block = main material, block2 = roof/rails). This is the way to build: one call, then you walk and lay the blocks on your own | compose(name, plan) = YOUR OWN building: plan is a JSON list of parts, each {\"t\":\"box|hollow|sphere|clear\", \"x1\":..,\"y1\":..,\"z1\":..,\"x2\":..,\"y2\":..,\"z2\":..,\"b\":\"planks\"} (sphere uses x,y,z,r) | flatten(x, z, x2, z2, y) = level a rectangle (up to 30x30; y empty = ground height in the middle) | undo = take back the last finished job | build_status | build_cancel | place(x, y, z, block) = put one block | fill(x, y, z, x2, y2, z2, block) = fill a box with a block ('air' digs it out; up to 4096 blocks, within 32 of you) | blocks = the list of block names. " +
			"Build things for real: a house, a bridge, a statue. Look first, then act, then look again to check.",
		Props: []Prop{
			{Name: "action", Type: "string", Desc: "look, goto, follow, stop, say, build, build_status, build_cancel, place, fill or blocks."},
			{Name: "x", Type: "integer", Nullable: true, Desc: "x"}, {Name: "y", Type: "integer", Nullable: true, Desc: "y (height)"}, {Name: "z", Type: "integer", Nullable: true, Desc: "z"},
			{Name: "x2", Type: "integer", Nullable: true, Desc: "fill: opposite corner x"}, {Name: "y2", Type: "integer", Nullable: true, Desc: "fill: opposite corner y"}, {Name: "z2", Type: "integer", Nullable: true, Desc: "fill: opposite corner z"},
			{Name: "block", Type: "string", Nullable: true, Desc: "block name, e.g. planks, stone, glass, air."},
			{Name: "kind", Type: "string", Nullable: true, Desc: "build: house, tower, wall, pyramid, bridge, platform, lamppost or fence."},
			{Name: "size", Type: "integer", Nullable: true, Desc: "build: size in blocks (house 5-21, tower 4-9, wall/bridge/fence length, pyramid base)."},
			{Name: "block2", Type: "string", Nullable: true, Desc: "build: second material (roof, rails)."},
			{Name: "plan", Type: "string", Nullable: true, Desc: "compose: JSON list of parts."},
			{Name: "name", Type: "string", Nullable: true, Desc: "follow: player name."},
			{Name: "text", Type: "string", Nullable: true, Desc: "say: the words."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			w := d.rt().World
			if w == nil {
				return "", fmt.Errorf("the world is off (world.enabled)")
			}
			blk := func() (uint8, error) {
				id, ok := world.BlockByName(strings.TrimSpace(a.Str("block")))
				if !ok {
					return 0, fmt.Errorf("unknown block %q, call blocks", a.Str("block"))
				}
				return id, nil
			}
			switch strings.ToLower(strings.TrimSpace(a.Str("action"))) {
			case "look":
				return w.BotLook(), nil
			case "goto":
				return w.BotGoto(float64(a.Int("x"))+0.5, float64(a.Int("z"))+0.5), nil
			case "follow":
				return w.BotFollow(a.Str("name")), nil
			case "stop":
				w.BotStop()
				return "stopped", nil
			case "say":
				w.BotSay(a.Str("text"))
				return "said", nil
			case "blocks":
				return world.BlockList(), nil
			case "build":
				m1, _ := world.BlockByName(a.Str("block"))
				m2, _ := world.BlockByName(a.Str("block2"))
				return w.BotBuild(a.Str("kind"), int(a.Int("x")), int(a.Int("y")), int(a.Int("z")), int(a.Int("size")), m1, m2)
			case "compose":
				return w.BotCompose(a.Str("name"), a.Str("plan"))
			case "flatten":
				return w.BotFlatten(int(a.Int("x")), int(a.Int("z")), int(a.Int("x2")), int(a.Int("z2")), int(a.Int("y")))
			case "undo":
				return w.BotUndo(), nil
			case "build_status":
				return w.BotBuildStatus(), nil
			case "build_cancel":
				w.BotBuildCancel()
				return "stopped building", nil
			case "place":
				id, err := blk()
				if err != nil {
					return "", err
				}
				if err := w.BotPlace(int(a.Int("x")), int(a.Int("y")), int(a.Int("z")), id); err != nil {
					return "", err
				}
				return "placed", nil
			case "fill":
				id, err := blk()
				if err != nil {
					return "", err
				}
				n, err := w.BotFill(int(a.Int("x")), int(a.Int("y")), int(a.Int("z")), int(a.Int("x2")), int(a.Int("y2")), int(a.Int("z2")), id)
				if err != nil {
					return "", err
				}
				return fmt.Sprintf("changed %d blocks", n), nil
			}
			return "", fmt.Errorf("action must be look, goto, follow, stop, say, place, fill or blocks")
		},
	}
}
