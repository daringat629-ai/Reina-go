package tools

import (
	"strings"
	"unicode"
)

// Human typos (taken from the original Kuni): now and then a message has two neighbouring letters swapped or one
// letter replaced by a key next to it on the keyboard (QWERTY and ЙЦУКЕН). Links, code, mentions and short
// texts are never touched.

var keyRows = [][]string{
	{"qwertyuiop", "asdfghjkl", "zxcvbnm"},
	{"йцукенгшщзхъ", "фывапролджэ", "ячсмитьбю"},
}

var neighbors = func() map[rune][]rune {
	m := map[rune][]rune{}
	for _, layout := range keyRows {
		rows := make([][]rune, len(layout))
		for i, r := range layout {
			rows[i] = []rune(r)
		}
		for ri, r := range rows {
			for ci, k := range r {
				var n []rune
				if ci > 0 {
					n = append(n, r[ci-1])
				}
				if ci+1 < len(r) {
					n = append(n, r[ci+1])
				}
				if ri > 0 && ci < len(rows[ri-1]) {
					n = append(n, rows[ri-1][ci])
				}
				if ri+1 < len(rows) && ci < len(rows[ri+1]) {
					n = append(n, rows[ri+1][ci])
				}
				m[k] = n
			}
		}
	}
	return m
}()

func typoSafe(s string) bool {
	if len([]rune(s)) < 8 {
		return false
	}
	for _, bad := range []string{"http", "://", "`", "@", "tg:", "www."} {
		if strings.Contains(s, bad) {
			return false
		}
	}
	return true
}

// TypoFix is the "*word" a person sends right after a typo: the first word that differs between what she meant
// and what went out, in its correct form. "" when nothing differs.
func TypoFix(meant, sent string) string {
	a, b := strings.Fields(meant), strings.Fields(sent)
	if len(a) != len(b) {
		return ""
	}
	for i := range a {
		if a[i] != b[i] {
			w := strings.TrimFunc(a[i], func(r rune) bool { return !unicode.IsLetter(r) && !unicode.IsDigit(r) })
			if w == "" {
				return ""
			}
			return "*" + w
		}
	}
	return ""
}

// MaybeTypo may return s with one human typo. chance is the probability for each of the two kinds (0 = never);
// rnd returns a float in [0,1).
func MaybeTypo(s string, chance float64, rnd func() float64) string {
	if chance <= 0 || !typoSafe(s) {
		return s
	}
	r := []rune(s)
	if rnd() < chance { // swap two adjacent letters
		var idx []int
		for i := 0; i+1 < len(r); i++ {
			if unicode.IsLetter(r[i]) && unicode.IsLetter(r[i+1]) && r[i] != r[i+1] {
				idx = append(idx, i)
			}
		}
		if len(idx) > 0 {
			i := idx[int(rnd()*float64(len(idx)))%len(idx)]
			r[i], r[i+1] = r[i+1], r[i]
		}
	}
	if rnd() < chance { // a neighbouring key
		var idx []int
		for i, c := range r {
			if _, ok := neighbors[unicode.ToLower(c)]; ok {
				idx = append(idx, i)
			}
		}
		if len(idx) > 0 {
			i := idx[int(rnd()*float64(len(idx)))%len(idx)]
			ns := neighbors[unicode.ToLower(r[i])]
			n := ns[int(rnd()*float64(len(ns)))%len(ns)]
			if unicode.IsUpper(r[i]) {
				n = unicode.ToUpper(n)
			}
			r[i] = n
		}
	}
	return string(r)
}
