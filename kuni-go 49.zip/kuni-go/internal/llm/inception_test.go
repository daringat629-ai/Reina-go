package llm

import (
	"context"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"
)

// Inception (mercury-*) takes a flat reasoning_effort; "off" becomes its fastest level, instant.
func TestInceptionGetsReasoningEffort(t *testing.T) {
	var bodies []string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		b, _ := io.ReadAll(r.Body)
		bodies = append(bodies, string(b))
		_, _ = w.Write([]byte(`{"choices":[{"message":{"role":"assistant","content":"ok"}}]}`))
	}))
	defer srv.Close()
	c := New(srv.URL+"/", srv.URL+"/", "k", "mercury-3", "e", 5*time.Second)
	c.Update(Settings{BaseURL: srv.URL + "/", APIKey: "k", Model: "mercury-3", Reasoning: "high"})
	ask := func(r string) {
		if _, err := c.Complete(context.Background(), Request{Messages: []Message{{Role: "user", Content: "hi"}}, Reasoning: r}); err != nil {
			t.Fatal(err)
		}
	}
	ask("")
	ask("off")
	if !strings.Contains(bodies[0], `"reasoning_effort":"high"`) || strings.Contains(bodies[0], `"reasoning":`) {
		t.Fatalf("global effort: %s", bodies[0])
	}
	if !strings.Contains(bodies[1], `"reasoning_effort":"instant"`) {
		t.Fatalf("fast round: %s", bodies[1])
	}
	// any other endpoint keeps the OpenRouter-style object
	c.Update(Settings{BaseURL: srv.URL + "/", APIKey: "k", Model: "some/model"})
	ask("off")
	if !strings.Contains(bodies[2], `"reasoning":{"enabled":false`) || strings.Contains(bodies[2], "reasoning_effort") {
		t.Fatalf("other provider: %s", bodies[2])
	}
}

// Diary and memory (light_model) can live on OpenRouter while the replies go through Inception.
func TestLightModelAndEmbeddingsOnTheirOwnEndpoint(t *testing.T) {
	type hit struct{ path, auth, body string }
	serve := func(hits *[]hit) *httptest.Server {
		return httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			b, _ := io.ReadAll(r.Body)
			*hits = append(*hits, hit{r.URL.Path, r.Header.Get("Authorization"), string(b)})
			if strings.HasSuffix(r.URL.Path, "embeddings") {
				_, _ = w.Write([]byte(`{"data":[{"embedding":[0.1,0.2,0.3]}]}`))
				return
			}
			_, _ = w.Write([]byte(`{"choices":[{"message":{"role":"assistant","content":"ok"}}]}`))
		}))
	}
	var main, or []hit
	ms, os := serve(&main), serve(&or)
	defer ms.Close()
	defer os.Close()
	c := New(ms.URL+"/", ms.URL+"/", "k", "mercury-3", "e", 5*time.Second)
	c.Update(Settings{BaseURL: ms.URL + "/", APIKey: "INC", Model: "mercury-3", LightModel: "google/gemini-2.5-flash",
		LightBaseURL: os.URL + "/", LightAPIKey: "OR", EmbeddingBaseURL: os.URL + "/", EmbeddingAPIKey: "OR",
		EmbeddingModel: "openai/text-embedding-3-small", Reasoning: "high"})
	ctx := context.Background()
	if _, err := c.Chat(WithPurpose(ctx, "reply"), "s", []Message{{Role: "user", Content: "hi"}}); err != nil {
		t.Fatal(err)
	}
	if _, err := c.Chat(WithPurpose(ctx, "diary"), "s", []Message{{Role: "user", Content: "hi"}}); err != nil {
		t.Fatal(err)
	}
	if _, err := c.Embedding(ctx, "hi"); err != nil {
		t.Fatal(err)
	}
	if len(main) != 1 || main[0].auth != "Bearer INC" || !strings.Contains(main[0].body, "mercury-3") {
		t.Fatalf("reply must go to Inception: %+v", main)
	}
	if len(or) != 2 || or[0].auth != "Bearer OR" || !strings.Contains(or[0].body, "gemini") || !strings.Contains(or[0].body, `"reasoning":{"effort":"high"`) {
		t.Fatalf("diary must go to OpenRouter in its dialect: %+v", or)
	}
	if or[1].path != "/embeddings" || or[1].auth != "Bearer OR" {
		t.Fatalf("embeddings: %+v", or[1])
	}
}
