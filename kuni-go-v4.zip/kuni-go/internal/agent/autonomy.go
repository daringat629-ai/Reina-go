package agent

import (
	"context"
	"fmt"
	"strconv"
	"strings"
	"time"

	"kuni/internal/autonomy"
	"kuni/internal/llm"
	"kuni/internal/memory"
	"kuni/internal/prompts"
	"kuni/internal/telegram"
	"kuni/internal/tools"
)

// Her own initiative. In her free time (autonomy.enabled) she may write first, speak her mind, go to sleep or do
// nothing; nights, sleep and the daily cap are checked before a round, the per-message limits on every message she
// starts (calls.go). Without autonomy, telegram.proactive_interval_secs gives the older, simpler "look around".

// isNight reports whether the configured quiet hours are on right now.
func (a *Agent) isNight(now time.Time) bool {
	c := a.cfg()
	return c.AutonomyEnabled && autonomy.InQuietHours(now, c.AutonomyQuietFrom, c.AutonomyQuietTo, c.Location())
}

// goToSleep is the go_to_sleep tool backend.
func (a *Agent) goToSleep(minutes int, reason string) string {
	if minutes <= 0 {
		minutes = 360
	}
	loc := a.cfg().Location()
	until := a.Auto.Sleep(time.Duration(minutes)*time.Minute, reason)
	a.Auto.Log(fmt.Sprintf("went to sleep until %s (%s)", until.In(loc).Format("15:04"), strings.TrimSpace(reason)))
	a.Metrics.Inc("kuni_autonomy_sleeps_total", 1, nil)
	if a.Diary != nil {
		a.spawn("sleep consolidation", func() { // sleep consolidates memories (one cycle at a time, see Diary.Consolidate)
			_ = a.Diary.Consolidate(a.life, a.cfg().SleepMaxTime)
		})
	}
	return fmt.Sprintf("You fall asleep until about %s.", until.In(loc).Format("15:04"))
}

// sleepBlock tells the model it is drowsy when it is night or it went to sleep.
func (a *Agent) sleepBlock() string {
	cfg := a.cfg()
	if !cfg.AutonomyEnabled || a.Auto == nil {
		return ""
	}
	loc := cfg.Location()
	if asleep, until := a.Auto.Asleep(); asleep {
		return fmt.Sprintf("<state>You are asleep until about %s. This message woke you up: answer drowsy and brief, or stay silent if it is not important or not meant for you. Your owner always matters.</state>\n", until.In(loc).Format("15:04"))
	}
	if a.isNight(time.Now()) {
		return fmt.Sprintf("<state>It is night for you (%s). You are drowsy; short sleepy replies are natural.</state>\n", time.Now().In(loc).Format("15:04"))
	}
	return ""
}

// ownSession prepares the session of her own initiative (id 0) for a new round (s.mu held).
func (a *Agent) ownSession(s *session) {
	d := a.depsFor(s)
	s.chat.ID = 0
	s.tools = tools.NewRegistry(a.baseTools(d, true)...)
}

// workingMemory is the <things_to_remember> block for the first turn of a session ("" afterwards or when empty).
func (a *Agent) workingMemory(s *session) string {
	if !s.fresh {
		return ""
	}
	s.fresh = false
	if wm, _ := (memory.WorkingMemory{Path: a.cfg().WorkingMemoryFile}).Load(); strings.TrimSpace(wm) != "" {
		return "<things_to_remember>\n" + wm + "\n</things_to_remember>\n\n"
	}
	return ""
}

// ActAutonomously is one round of her own initiative: she decides whether to write first, speak her mind,
// go to sleep or do nothing. Nights, sleep and the daily cap are checked here; the per-message limits in calls.go.
func (a *Agent) ActAutonomously(ctx context.Context) error {
	cfg := a.cfg()
	if a.paused.Load() || a.Auto == nil || a.Usage.Over(cfg.DailyTokenLimit) {
		return nil
	}
	now := time.Now()
	if asleep, _ := a.Auto.Asleep(); asleep {
		return nil
	}
	if a.isNight(now) {
		return nil
	}
	left := cfg.AutonomyMaxPerDay - a.Auto.SentToday()
	if left <= 0 {
		return nil
	}
	a.Auto.Ran()
	before := a.Auto.Entries()
	s := a.getSession(0)
	s.mu.Lock()
	defer s.mu.Unlock()
	a.ownSession(s)
	loc := cfg.Location()
	var b strings.Builder
	b.WriteString(a.workingMemory(s))
	fmt.Fprintf(&b, "It is %s (%s).\n%s", now.In(loc).Format("Mon 2 Jan 15:04"), partOfDay(now.In(loc)), a.moodBlock()+a.bondBlock(telegram.Chat{})+a.brainBlock(telegram.Chat{}, true, "")+a.selfBlock()+a.selfCheck())
	if recent := a.Auto.Recent(6); len(recent) > 0 {
		b.WriteString("<your_recent_initiatives>\n" + strings.Join(recent, "\n") + "\n</your_recent_initiatives>\n")
	}
	b.WriteString(a.Prompts.Text(prompts.Autonomy, map[string]string{"LEFT": strconv.Itoa(left)}))
	s.msgs = append(s.msgs, llm.Message{Role: "user", Content: b.String()})
	err := a.runTurn(ctx, s)
	if a.Auto.Entries() == before {
		a.Auto.Log("looked around, did nothing")
	}
	return err
}

// ActProactively runs a session in which the model decides whom to write to.
func (a *Agent) ActProactively(ctx context.Context) error {
	if a.paused.Load() || a.Usage.Over(a.cfg().DailyTokenLimit) {
		return nil
	}
	s := a.getSession(0)
	s.mu.Lock()
	defer s.mu.Unlock()
	a.ownSession(s)
	msg := a.workingMemory(s) + a.Prompts.Text(prompts.Proactive, nil)
	msg = fmt.Sprintf("It is %s.\n%s%s", time.Now().In(a.cfg().Location()).Format("Mon Jan 2 15:04"), a.moodBlock(), msg)
	s.msgs = append(s.msgs, llm.Message{Role: "user", Content: msg})
	return a.runTurn(ctx, s)
}

func partOfDay(t time.Time) string {
	switch h := t.Hour(); {
	case h < 5:
		return "deep night"
	case h < 12:
		return "morning"
	case h < 18:
		return "afternoon"
	case h < 23:
		return "evening"
	}
	return "late evening"
}
