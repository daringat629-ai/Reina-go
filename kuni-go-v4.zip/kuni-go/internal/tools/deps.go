package tools

import (
	"context"
	"net/http"
	"os"
	"path/filepath"
	"strings"

	"kuni/internal/allow"
	"kuni/internal/bond"
	"kuni/internal/brain"
	"kuni/internal/config"
	"kuni/internal/dates"
	"kuni/internal/diary"
	"kuni/internal/ignore"
	"kuni/internal/imagegen"
	"kuni/internal/ledger"
	"kuni/internal/llm"
	"kuni/internal/llmui"
	"kuni/internal/media"
	"kuni/internal/metrics"
	"kuni/internal/mood"
	"kuni/internal/people"
	"kuni/internal/prompts"
	"kuni/internal/reminders"
	"kuni/internal/sched"
	"kuni/internal/selfmodel"
	"kuni/internal/telegram"
	"kuni/internal/tracker"
	"kuni/internal/web"
	"kuni/internal/work"
)

// Deps is everything tools need; shared between the agent and the proxy.
type Deps struct {
	TG      telegram.Client
	LLM     *llm.Client
	Diary   *diary.Diary
	Prompts *prompts.Store
	Media   func() media.Services
	Cfg     func() *config.Config
	UI      *llmui.Env
	Metrics *metrics.Registry
	Images  *imagegen.Generator
	Mood    *mood.Mood       // nil = mood scale off
	Bond    *bond.Bond       // nil = no attachment feature
	Brain   *brain.Brain     // nil = no neural substrate
	Self    *selfmodel.Self  // nil = no self-model
	Focus   *brain.Workspace // nil = no global workspace
	// OpenChat is supplied by the agent: it switches the session to a chat and returns the rendered view.
	OpenChat func(ctx context.Context, chatID int64) (string, error)
	// FetchPage opens a link for read_link (nil = the real, SSRF-safe web fetcher).
	FetchPage func(ctx context.Context, url string) (web.Page, error)
	// Reminders and People are the persistent stores behind #remind and the person cards (nil = feature off).
	Reminders *reminders.Store
	People    *people.Store
	// Work is the queue of background jobs behind #work (nil = a private empty one in memory).
	Work *work.Store
	// Sched holds recurring tasks and monitors behind #schedule and #monitor (nil = those tools answer that the scheduler is off).
	Sched *sched.Store
	// Allow is the white list of people who may use her slash commands (nil = only the owner).
	Allow *allow.Store
	// Ignore is the list of chats and people she does not react to (nil = nobody is ignored and #ignore says it is off).
	Ignore *ignore.Store
	// ConfigPath is config.toml: #settings changes it, #backup includes it. Empty = those tools say they cannot.
	ConfigPath string
	// Wake starts a turn of hers in a chat because of an outside event (a finished background job...). Supplied by the agent.
	Wake func(chatID int64, text string)
	// UpdateDir and Restart serve #self_update; empty/nil = the real program directory and a real restart.
	UpdateDir string
	Restart   func()
	// MailPlain and CalendarHTTP are for tests: a mail server without TLS, an HTTP client that may reach local addresses.
	MailPlain    bool
	CalendarHTTP *http.Client
	// Searcher overrides the web search of #web_search (tests).
	Searcher media.Searcher
	// RT is the state shared by all tools (browser, desktop, background jobs...). Required.
	RT *Runtime
	// Contacts reports whether a user is in the account's contact list (lockdown = contacts_only); nil = nobody is.
	Contacts func(userID int64) bool
	// GoToSleep is supplied by the agent when autonomy is on: it starts a sleep and returns a message for the model.
	GoToSleep func(minutes int, reason string) string
	// Ledger, Tracker and Dates are the owner's money book, habits and measurements, and yearly dates (nil = off).
	Ledger  *ledger.Store
	Tracker *tracker.Store
	Dates   *dates.Store
	// Places overrides the OpenStreetMap services of #places (tests); zero = the public ones.
	Places PlacesAPI
}

// prompt is a prompt text without its surrounding blank lines ("" without a prompt store).
func (d Deps) prompt(name string) string {
	if d.Prompts == nil {
		return ""
	}
	return d.Prompts.Text(name, nil)
}

// rt is the shared runtime; a Deps without one is a programming error, said plainly.
func (d Deps) rt() *Runtime {
	if d.RT == nil {
		panic("tools: Deps.RT is nil (make one with tools.NewRuntime)")
	}
	return d.RT
}

func (d Deps) dataPath(sub ...string) string {
	return filepath.Join(append([]string{d.Cfg().DataDir}, sub...)...)
}

// safeJoin resolves a model-supplied filename inside dir and rejects path traversal.
func safeJoin(dir, name string) (string, error) {
	clean := filepath.Base(strings.TrimSpace(name))
	if clean == "." || clean == ".." || clean == string(filepath.Separator) || clean != strings.TrimSpace(name) {
		return "", os.ErrInvalid
	}
	return filepath.Join(dir, clean), nil
}

// Accessible implements util::isAccessibleFromLockdown: may Kuni touch this chat? contacts tells whether a user is
// in the account's contact list (nil = nobody is: the Bot API has no contact list).
func Accessible(c *config.Config, chatID int64, contacts func(int64) bool) bool {
	switch c.Lockdown {
	case "papik_only":
		return chatID == c.PapikChatID
	case "contacts_only":
		// groups (negative IDs) and the owner are allowed; private chats need to be contacts
		return chatID < 0 || chatID == c.PapikChatID || (contacts != nil && contacts(chatID))
	}
	return true
}

// Accessible is the lockdown rule with the current config and the account's contacts.
func (d Deps) Accessible(chatID int64) bool { return Accessible(d.Cfg(), chatID, d.Contacts) }

// IsContact reports whether the user is in the account's contacts.
func (d Deps) IsContact(id int64) bool { return d.Contacts != nil && d.Contacts(id) }
