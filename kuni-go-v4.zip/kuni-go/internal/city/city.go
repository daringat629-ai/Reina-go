// Package city is the third world: a big working city and Reina's room at the top of one tower, running in real time in the browser.
// The page simulates everything itself (day and night by the viewer's clock, traffic and its lights, people on the pavements, the lit
// windows); the server only says what her brain wants now, so that she lives in it: sleeps in her bed, works at the desk, looks out of
// the window at the city, reads, or goes out and walks the streets, by her real drives.
package city

import (
	_ "embed"
	"encoding/json"
	"net/http"
	"time"
)

//go:embed index.html
var page []byte

// Drive is one output of her brain, 0..1.
type Drive struct {
	Name  string  `json:"name"`
	Value float64 `json:"value"`
}

// Event is one line of what she does (the panel's feed): what the monitor and the phone in her room show.
type Event struct {
	ID     int64  `json:"id"`
	At     int64  `json:"at"` // unix milliseconds
	Kind   string `json:"kind"`
	Chat   string `json:"chat,omitempty"`
	Text   string `json:"text"`
	Typing string `json:"typing,omitempty"`
}

// State is what the page needs to know about her now.
type State struct {
	Drives []Drive `json:"drives"`
	Mood   int     `json:"mood"` // 0..100, -1 when unknown
	Now    int64   `json:"now"`  // unix milliseconds on the server
	Feed   []Event `json:"feed"` // the last events of her feed, oldest first
}

// Handler serves the page (GET /) and state.json. The state function is called on every poll, so it must be cheap.
func Handler(state func() State) http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("/state.json", func(w http.ResponseWriter, r *http.Request) {
		st := State{Mood: -1}
		if state != nil {
			st = state()
		}
		st.Now = time.Now().UnixMilli()
		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("Cache-Control", "no-store")
		_ = json.NewEncoder(w).Encode(st)
	})
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Header().Set("Cache-Control", "no-store")
		_, _ = w.Write(page)
	})
	return mux
}
