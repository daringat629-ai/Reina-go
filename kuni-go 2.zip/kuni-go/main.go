// Command kuni is the Go port of the Kuni character AI: Telegram client, tools,
// RAG diary with sleep consolidation, working memory, and an OpenAI-compatible
// proxy that gives any LLM client the same memory.
package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"path/filepath"
	"sync"
	"syscall"
	"time"

	"kuni/internal/agent"
	"kuni/internal/config"
	"kuni/internal/debugui"
	"kuni/internal/diary"
	"kuni/internal/imagegen"
	"kuni/internal/llm"
	"kuni/internal/llmui"
	"kuni/internal/media"
	"kuni/internal/memory"
	"kuni/internal/metrics"
	"kuni/internal/prompts"
	"kuni/internal/proxy"
	"kuni/internal/telegram"
	"kuni/internal/tools"
	"kuni/internal/util"
)

func main() {
	if err := run(); err != nil {
		if errors.Is(err, config.ErrNeedsSetup) {
			fmt.Println(err)
			return
		}
		log.Fatal(err)
	}
}

func llmSettings(c *config.Config) llm.Settings {
	s := llm.Settings{BaseURL: c.LLMBaseURL, EmbeddingBaseURL: c.EmbeddingBaseURL, APIKey: c.LLMAPIKey, Model: c.LLMModel, EmbeddingModel: c.EmbeddingModel}
	if c.Temperature >= 0 {
		t := c.Temperature
		s.Temperature = &t
	}
	return s
}

func promptVars(c *config.Config) prompts.Vars {
	return prompts.Vars{CharacterName: c.CharacterName, CharacterNickname: c.CharacterNick, PapikName: c.PapikName}
}

func run() error {
	holder, err := config.NewHolder(config.FileName)
	if err != nil {
		return err
	}
	cfg := holder.Get()

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	var wg sync.WaitGroup
	goRun := func(f func()) { wg.Add(1); go func() { defer wg.Done(); f() }() }

	// --- core services ---
	reg := metrics.New()
	reg.Help("kuni_llm_requests_total", "LLM requests by kind and outcome")
	reg.Help("kuni_tool_calls_total", "Tool calls executed")
	reg.Help("kuni_llm_tokens_total", "LLM tokens by model, purpose (reply/ask/diary/sleep/compact/image) and direction")
	reg.Help("kuni_llm_last_prompt_tokens", "Prompt size of the last LLM request by purpose")
	reg.Help("kuni_sessions_active", "Open conversation sessions")

	client := llm.New("", "", "", "", "", cfg.RequestTimeout)
	client.Update(llmSettings(cfg))
	client.Observe = func(kind string, d time.Duration, err error) {
		outcome := "ok"
		if err != nil {
			outcome = "error"
		}
		reg.Inc("kuni_llm_requests_total", 1, map[string]string{"kind": kind, "outcome": outcome})
		reg.Observe("kuni_llm_request_seconds", d.Seconds(), map[string]string{"kind": kind})
	}

	client.OnUsage = func(model, purpose string, in, out int) {
		pl := map[string]string{"model": model, "purpose": purpose}
		reg.Inc("kuni_llm_tokens_total", float64(in), map[string]string{"model": model, "purpose": purpose, "direction": "input"})
		reg.Inc("kuni_llm_tokens_total", float64(out), map[string]string{"model": model, "purpose": purpose, "direction": "output"})
		reg.Set("kuni_llm_last_prompt_tokens", float64(in), pl)
		l := map[string]string{"model": model}
		reg.Inc("llm_usage_input", float64(in), l) // names used by the original Grafana dashboard
		reg.Inc("llm_usage_output", float64(out), l)
		reg.Set("llm_usage_input_gauge", float64(in), l)
		reg.Set("llm_usage_output_gauge", float64(out), l)
	}

	ps, err := prompts.NewStore(cfg.PromptsDir, promptVars(cfg))
	if err != nil {
		return err
	}
	d, err := diary.New(cfg.DiaryDir, client, cfg.ConfidenceFactor, cfg.DiaryTokenTrigger)
	if err != nil {
		return err
	}
	d.SleepPrompt = func() string { return ps.Get(prompts.SleepConsolidator) }

	// hot reload: config.toml and prompt files.
	holder.OnChange(func(c *config.Config) {
		client.Update(llmSettings(c))
		client.HTTP.Timeout = c.RequestTimeout
		d.ConfidenceFactor, d.TokenTrigger = c.ConfidenceFactor, c.DiaryTokenTrigger
		if err := ps.SetVars(promptVars(c)); err != nil {
			log.Printf("prompts: %v", err)
		}
	})
	goRun(func() { holder.Watch(ctx) })
	goRun(func() {
		util.Watch(ctx, 2*time.Second, ps.Files, func(path string) {
			if err := ps.Reload(); err != nil {
				log.Printf("prompts: reload: %v", err)
				return
			}
			log.Printf("prompts: reloaded (%s changed)", filepath.Base(path))
		})
	})

	getCfg := holder.Get
	mediaSvc := func() media.Services { return media.FromConfig(getCfg()) }

	var tg telegram.Client
	if cfg.TelegramEnabled {
		_ = os.MkdirAll(cfg.DataDir, 0o755)
		switch cfg.Mode {
		case "bot":
			if cfg.BotToken == "" {
				return errors.New("[telegram] mode = \"bot\" needs bot_token")
			}
			bot := telegram.NewBot(cfg.BotToken, cfg.TelegramAPI)
			bot.StatePath = filepath.Join(cfg.DataDir, "telegram_state.json")
			tg = bot
		case "user":
			if cfg.TelegramAPIID == 0 || cfg.TelegramHash == "" {
				return errors.New("[telegram] mode = \"user\" needs api_id and api_hash from https://my.telegram.org")
			}
			tr, err := telegram.NewTDJSONTransport()
			if err != nil {
				return err
			}
			td := telegram.NewTD(tr, telegram.TDConfig{APIID: cfg.TelegramAPIID, APIHash: cfg.TelegramHash, Phone: cfg.Phone,
				DBDir: cfg.TDLibDir, AppVersion: "kuni-go"})
			tools.Contacts = func(id int64) bool {
				c, cancel := context.WithTimeout(context.Background(), 15*time.Second)
				defer cancel()
				return td.Contacts(c)[id]
			}
			tg = td
		default:
			return fmt.Errorf("[telegram] mode must be \"user\" or \"bot\", got %q", cfg.Mode)
		}
	} else {
		tg = telegram.NewFake() // keeps tools constructible; nothing ever arrives
	}

	ui := &llmui.Env{TG: tg, LLM: client, Prompts: ps, Media: mediaSvc, Cfg: getCfg}
	gen := &imagegen.Generator{LLM: client, Prompts: ps, Media: mediaSvc, CharacterName: func() string { return getCfg().CharacterName }}
	deps := tools.Deps{TG: tg, LLM: client, Diary: d, Prompts: ps, Media: mediaSvc, Cfg: getCfg, UI: ui, Metrics: reg, Images: gen}
	dumper := &memory.Dumper{LLM: client, Diary: d, Prompts: ps, CharacterName: func() string { return getCfg().CharacterName },
		WM: memory.WorkingMemory{Path: cfg.WorkingMemoryFile}}

	var ag *agent.Agent
	if cfg.TelegramEnabled {
		ag = agent.New(&agent.Agent{Cfg: holder, LLM: client, TG: tg, Diary: d, Prompts: ps, UI: ui, Dumper: dumper, Metrics: reg, Deps: deps})
		goRun(func() {
			if err := tg.Run(ctx); err != nil {
				log.Printf("telegram: %v", err)
				stop()
			}
		})
		goRun(func() { ag.Run(ctx) })
	}

	// --- HTTP: proxy + metrics + debug ---
	dbg := &debugui.UI{Cfg: getCfg, Diary: d, Client: client}
	if ag != nil {
		dbg.Sessions = ag.SessionSummaries
	}
	mount := func(mux *http.ServeMux) {
		if cfg.MetricsEnabled {
			mux.Handle("/metrics", reg.Handler())
		}
		if cfg.DebugUI {
			dbg.Mount(mux)
		}
	}
	addr := fmt.Sprintf(":%d", cfg.ProxyPort)
	if cfg.ProxyEnabled {
		bridge := proxy.NewBridge(dumper, func() string {
			return ps.Get(prompts.CharacterBase)
		}, func() time.Duration { return getCfg().SessionIdle })
		goRun(func() { bridge.Run(ctx) })
		srv := &proxy.Server{
			Cfg: getCfg, Diary: d, Prompts: ps, Client: client, Metrics: reg, Bridge: bridge, HijackSystem: true,
			HTTP: &http.Client{Timeout: 10 * time.Minute},
			Tools: func(lastUser string) *tools.Registry {
				return tools.NewRegistry(tools.AskTool(deps))
			},
			Mount: mount,
		}
		goRun(func() {
			log.Printf("kuni: proxy listening on %s (upstream %s)", addr, cfg.LLMBaseURL)
			if err := srv.ListenAndServe(ctx, addr); err != nil {
				log.Printf("proxy: %v", err)
				stop()
			}
		})
	} else if cfg.MetricsEnabled || cfg.DebugUI {
		mux := http.NewServeMux()
		mount(mux)
		hs := &http.Server{Addr: addr, Handler: mux, ReadHeaderTimeout: 10 * time.Second}
		goRun(func() { _ = hs.ListenAndServe() })
		goRun(func() { <-ctx.Done(); _ = hs.Close() })
	}

	goRun(func() { sleepLoop(ctx, d, getCfg) })

	log.Printf("kuni: %s is up (telegram=%v, proxy=%v). Ctrl+C to stop gracefully.", cfg.CharacterName, cfg.TelegramEnabled, cfg.ProxyEnabled)
	<-ctx.Done()
	log.Printf("kuni: shutting down, dumping remaining context…")
	wg.Wait()
	return nil
}

// sleepLoop runs one consolidation cycle a minute after start and then every 6 hours.
func sleepLoop(ctx context.Context, d *diary.Diary, cfg func() *config.Config) {
	timer := time.NewTimer(time.Minute)
	defer timer.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-timer.C:
			if err := d.Consolidate(ctx, cfg().SleepMaxTime); err != nil && !errors.Is(err, context.Canceled) {
				log.Printf("kuni: sleep consolidation: %v", err)
			}
			timer.Reset(6 * time.Hour)
		}
	}
}
