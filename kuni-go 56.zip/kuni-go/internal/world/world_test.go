package world

import (
	"bufio"
	"bytes"
	"context"
	"crypto/rand"
	"encoding/base64"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"
)

func TestTerrainIsSane(t *testing.T) {
	g := NewGen(42)
	land, n := 0, 0
	biomes := map[int]int{}
	for x := -600; x < 600; x += 12 {
		for z := -600; z < 600; z += 12 {
			h := g.Height(x, z)
			if h < 1 || h >= CY-2 {
				t.Fatalf("height %d out of range at %d,%d", h, x, z)
			}
			n++
			if h > SeaLevel {
				land++
			}
			biomes[g.BiomeAt(x, z, h)]++
		}
	}
	if f := float64(land) / float64(n); f < 0.35 || f > 0.9 {
		t.Fatalf("land is %.0f%% of the map", f*100)
	}
	for _, b := range []int{Plains, Forest, Desert, Snowy, Ocean} {
		if biomes[b] == 0 {
			t.Errorf("no %s in 1200x1200 blocks", BiomeNames[b])
		}
	}
}

func TestChunkIsDeterministicAndHasBedrock(t *testing.T) {
	g := NewGen(7)
	a, b := g.Generate(3, -2), g.Generate(3, -2)
	if a.B != b.B {
		t.Fatal("the same chunk generated twice differs")
	}
	if a.B[idx(5, 0, 5)] != Bedrock {
		t.Fatal("no bedrock at the bottom")
	}
	ores := 0
	for _, id := range g.Generate(0, 0).B {
		if id >= CoalOre && id <= CopperOre {
			ores++
		}
	}
	if ores == 0 {
		t.Fatal("no ore in a chunk")
	}
}

func TestChunkEncodingRoundTrip(t *testing.T) {
	c := NewGen(1).Generate(-4, 9)
	cx, cz, blocks, err := DecodeChunk(encodeChunk(c))
	if err != nil || cx != -4 || cz != 9 || !bytes.Equal(blocks, c.B[:]) {
		t.Fatalf("round trip failed: %v %d %d", err, cx, cz)
	}
	if n := len(encodeChunk(c)); n > 20000 {
		t.Fatalf("a chunk takes %d bytes", n)
	}
}

func TestEditsAreSavedAndLoaded(t *testing.T) {
	dir := t.TempDir()
	w, err := Open(dir)
	if err != nil {
		t.Fatal(err)
	}
	if !w.SetBlock(-3, 70, 21, GoldBlock) || w.Block(-3, 70, 21) != GoldBlock {
		t.Fatal("set/get failed")
	}
	seed := w.Seed()
	if err := w.Save(); err != nil {
		t.Fatal(err)
	}
	w2, err := Open(dir)
	if err != nil {
		t.Fatal(err)
	}
	if w2.Seed() != seed || w2.Block(-3, 70, 21) != GoldBlock {
		t.Fatal("the edit or the seed was lost")
	}
	w2.Unload(func(int, int) bool { return false })
	if w2.Loaded() != 0 {
		t.Fatal("unload kept chunks")
	}
}

func TestBotWalksAndBuilds(t *testing.T) {
	w, _ := Open(t.TempDir())
	s := &Server{W: w, Key: func() string { return "k" }}
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go s.Run(ctx)
	time.Sleep(100 * time.Millisecond)
	x0, _, z0 := s.botPos()
	s.BotGoto(x0+12, z0)
	time.Sleep(1800 * time.Millisecond)
	if x, _, _ := s.botPos(); x < x0+5 {
		t.Fatalf("she did not walk: x %.1f -> %.1f\n%s", x0, x, s.BotLook())
	}
	bx, by, bz := s.botPos()
	n, err := s.BotFill(int(bx)-1, int(by), int(bz)+2, int(bx)+1, int(by)+1, int(bz)+2, Brick)
	if err != nil || n == 0 {
		t.Fatalf("fill: %d %v", n, err)
	}
	if w.Block(int(bx), int(by), int(bz)+2) != Brick {
		t.Fatal("the wall is not there")
	}
	if _, err := s.BotFill(0, 1, 0, 40, 40, 40, Stone); err == nil {
		t.Fatal("a huge fill must be refused")
	}
	if err := s.BotPlace(int(bx)+200, 60, int(bz), Stone); err == nil {
		t.Fatal("placing far away must be refused")
	}
	if look := s.BotLook(); !strings.Contains(look, "Карта сверху") || !strings.Contains(look, "@") {
		t.Fatalf("look is empty: %s", look)
	}
}

// a bare-bones client for the websocket
type tc struct {
	c  net.Conn
	br *bufio.Reader
}

func dial(t *testing.T, url string) *tc {
	t.Helper()
	host := strings.TrimPrefix(strings.SplitN(url, "/world", 2)[0], "http://")
	c, err := net.Dial("tcp", host)
	if err != nil {
		t.Fatal(err)
	}
	key := make([]byte, 16)
	rand.Read(key)
	path := "/world" + strings.SplitN(url, "/world", 2)[1]
	io.WriteString(c, "GET "+path+" HTTP/1.1\r\nHost: "+host+"\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: "+base64.StdEncoding.EncodeToString(key)+"\r\nSec-WebSocket-Version: 13\r\n\r\n")
	br := bufio.NewReader(c)
	line, _ := br.ReadString('\n')
	if !strings.Contains(line, "101") {
		t.Fatalf("handshake: %q", line)
	}
	for {
		l, _ := br.ReadString('\n')
		if l == "\r\n" || l == "" {
			break
		}
	}
	return &tc{c, br}
}

func (c *tc) send(t *testing.T, v any) {
	raw, _ := json.Marshal(v)
	mask := []byte{1, 2, 3, 4}
	hdr := []byte{0x81, 0x80 | byte(len(raw))}
	if len(raw) >= 126 {
		hdr = []byte{0x81, 0x80 | 126, byte(len(raw) >> 8), byte(len(raw))}
	}
	p := make([]byte, len(raw))
	for i := range raw {
		p[i] = raw[i] ^ mask[i%4]
	}
	c.c.Write(append(append(hdr, mask...), p...))
}

func (c *tc) recv(t *testing.T) (op byte, data []byte) {
	t.Helper()
	c.c.SetReadDeadline(time.Now().Add(5 * time.Second))
	var h [2]byte
	if _, err := io.ReadFull(c.br, h[:]); err != nil {
		t.Fatal(err)
	}
	n := int(h[1] & 0x7f)
	if n == 126 {
		var b [2]byte
		io.ReadFull(c.br, b[:])
		n = int(binary.BigEndian.Uint16(b[:]))
	} else if n == 127 {
		var b [8]byte
		io.ReadFull(c.br, b[:])
		n = int(binary.BigEndian.Uint64(b[:]))
	}
	data = make([]byte, n)
	io.ReadFull(c.br, data)
	return h[0] & 0x0f, data
}

func TestWebsocketSession(t *testing.T) {
	w, _ := Open(t.TempDir())
	s := &Server{W: w, Key: func() string { return "secret" }, BotName: "Рейна"}
	var heard string
	s.OnChat = func(from, text string) { heard = from + ":" + text }
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go s.Run(ctx)
	mux := http.NewServeMux()
	s.Mount(mux)
	srv := httptest.NewServer(mux)
	defer srv.Close()

	if resp, err := http.Get(srv.URL + "/world/ws?key=nope"); err != nil || resp.StatusCode != 401 {
		t.Fatalf("a wrong key must be refused: %v %v", resp, err)
	}
	if resp, err := http.Get(srv.URL + "/world"); err != nil || resp.StatusCode != 200 {
		t.Fatalf("page: %v", err)
	}
	c := dial(t, srv.URL+"/world/ws?key=secret&name=Tester")
	defer c.c.Close()
	_, first := c.recv(t)
	var hello struct {
		T       string `json:"t"`
		X, Y, Z float64
		Blocks  []Block `json:"blocks"`
	}
	if err := json.Unmarshal(first, &hello); err != nil || hello.T != "hello" || len(hello.Blocks) < 40 {
		t.Fatalf("hello: %v %s", err, first[:min(len(first), 200)])
	}
	chunks := 0
	var sawBot, sawBlock bool
	c.send(t, map[string]any{"t": "pos", "x": hello.X, "y": hello.Y, "z": hello.Z, "a": 0, "b": 0})
	px, pz := int(hello.X), int(hello.Z)
	var free [][3]int // empty cells close to her (a tree may stand right where she spawns)
	for dx := -3; dx <= 3; dx++ {
		for dz := -3; dz <= 3; dz++ {
			for dy := 0; dy <= 2; dy++ {
				if (dx != 0 || dz != 0) && w.Block(px+dx, int(hello.Y)+dy, pz+dz) == Air && isSolid(w.Block(px+dx, int(hello.Y)+dy-1, pz+dz)) {
					free = append(free, [3]int{px + dx, int(hello.Y) + dy, pz + dz})
				}
			}
		}
	}
	if len(free) < 2 {
		t.Skip("no free cells near the spawn")
	}
	target := free[0]
	second := free[len(free)-1]
	c.send(t, map[string]any{"t": "set", "x": target[0], "y": target[1], "z": target[2], "id": Planks})
	c.send(t, map[string]any{"t": "chat", "text": "привет"})
	deadline := time.Now().Add(6 * time.Second)
	again := false
	for time.Now().Before(deadline) && !(chunks >= 9 && sawBot && sawBlock) {
		if chunks >= 9 && !again { // the first edit came before any chunk was sent; now the client has the chunk and must hear about edits
			again = true
			c.send(t, map[string]any{"t": "set", "x": second[0], "y": second[1], "z": second[2], "id": Planks})
		}
		op, data := c.recv(t)
		if op == opBinary {
			if _, _, _, err := DecodeChunk(data); err != nil {
				t.Fatal(err)
			}
			chunks++
			continue
		}
		var m map[string]any
		json.Unmarshal(data, &m)
		switch m["t"] {
		case "p":
			if strings.Contains(string(data), `"bot":true`) {
				sawBot = true
			}
		case "b":
			if int(m["id"].(float64)) == int(Planks) {
				sawBlock = true
			}
		}
	}
	if chunks < 9 || !sawBot || !sawBlock {
		t.Fatalf("chunks=%d bot=%v block=%v", chunks, sawBot, sawBlock)
	}
	if w.Block(target[0], target[1], target[2]) != Planks {
		t.Fatal("the server did not keep the block")
	}
	time.Sleep(50 * time.Millisecond)
	if heard != "Tester:привет" {
		t.Fatalf("chat was not passed on: %q", heard)
	}
	// too far to build
	c.send(t, map[string]any{"t": "set", "x": px + 60, "y": 60, "z": pz, "id": Stone})
	time.Sleep(200 * time.Millisecond)
	if w.Block(px+60, 60, pz) == Stone && g0(w, px+60, 60, pz) {
		t.Fatal("a block far out of reach was placed")
	}
}

func g0(w *World, x, y, z int) bool {
	return w.gen.Generate(floorDiv(x, CX), floorDiv(z, CZ)).B[idx(floorMod(x, CX), y, floorMod(z, CZ))] != Stone
}

func TestBotBuildsAHouseByItself(t *testing.T) {
	w, _ := Open(t.TempDir())
	s := &Server{W: w, Key: func() string { return "k" }}
	ctx, cancel := context.WithCancel(context.Background())
	defer func() { cancel(); time.Sleep(400 * time.Millisecond) }()
	go s.Run(ctx)
	time.Sleep(100 * time.Millisecond)
	bx, _, bz := s.botPos()
	x, z := int(bx)+4, int(bz)+4
	y := w.Ground(x, z, CY-1)
	if _, err := s.BotBuild("house", x, y, z, 7, Planks, Cobble); err != nil {
		t.Fatal(err)
	}
	deadline := time.Now().Add(40 * time.Second)
	for time.Now().Before(deadline) && !strings.HasPrefix(s.BotBuildStatus(), "сейчас ничего") {
		time.Sleep(200 * time.Millisecond)
	}
	if st := s.BotBuildStatus(); !strings.HasPrefix(st, "сейчас ничего") {
		t.Fatalf("not finished: %s", st)
	}
	if got := w.Block(x+1, y+4, z+1); got != Cobble {
		t.Fatalf("roof block = %d", got)
	}
}

func TestBlueprintsAreBounded(t *testing.T) {
	for _, k := range strings.Split(Kinds, ", ") {
		o, err := blueprint(k, 0, 40, 0, 99, Planks, Cobble)
		if err != nil || len(o) == 0 || len(o) > maxPlan {
			t.Fatalf("%s: %d ops, %v", k, len(o), err)
		}
	}
	if _, err := blueprint("ufo", 0, 40, 0, 5, Planks, Cobble); err == nil {
		t.Fatal("unknown kind accepted")
	}
}

func stepUntilIdle(s *Server, max int) {
	for i := 0; i < max; i++ {
		s.mu.Lock()
		s.ticks++
		s.stepBot(s.bot, tickEvery.Seconds())
		s.stepBuild(s.bot)
		idle := s.build == nil
		s.mu.Unlock()
		if idle {
			return
		}
	}
}

func TestComposeQueueFlattenAndUndo(t *testing.T) {
	w, _ := Open(t.TempDir())
	s := &Server{W: w, players: map[int]*Player{}}
	x, _, z := w.Spawn()
	y := w.Ground(x, z, CY-1)
	s.bot = &Player{ID: 1, Name: "R", Bot: true, X: float64(x) + 0.5, Y: float64(y), Z: float64(z) + 0.5}
	s.players[1] = s.bot
	if _, err := s.BotCompose("x", `[{"t":"nope"}]`); err == nil {
		t.Fatal("bad part accepted")
	}
	spec := fmt.Sprintf(`[{"t":"hollow","x1":%d,"y1":%d,"z1":%d,"x2":%d,"y2":%d,"z2":%d,"b":"brick"},{"t":"sphere","x":%d,"y":%d,"z":%d,"r":2,"b":"glass"}]`,
		x+3, y+30, z+3, x+7, y+34, z+7, x+5, y+36, z+5)
	if _, err := s.BotCompose("башня", spec); err != nil {
		t.Fatal(err)
	}
	if _, err := s.BotFlatten(x+10, z+10, x+14, z+14, 0); err != nil {
		t.Fatal(err)
	}
	if len(s.queue) != 1 {
		t.Fatalf("queue = %d", len(s.queue))
	}
	// an enormous job is refused
	if _, err := s.BotFlatten(0, 0, 100, 100, 0); err == nil {
		t.Fatal("huge flatten accepted")
	}
	stepUntilIdle(s, 20*120)
	for i := 0; i < 3 && s.build != nil; i++ {
		stepUntilIdle(s, 20*120)
	}
	if got := w.Block(x+3, y+32, z+3); got != Brick {
		t.Fatalf("wall = %d", got)
	}
	t.Logf("before undo hist=%d build=%v", len(s.history), s.build != nil)
	s.BotUndo() // the last job was the leveling
	s.BotUndo()
	for i := 0; i < 4; i++ {
		stepUntilIdle(s, 20*120)
	}
	t.Logf("hist=%d queue=%d build=%v status=%s", len(s.history), len(s.queue), s.build != nil, s.BotBuildStatus())
	if got := w.Block(x+3, y+32, z+3); got == Brick {
		t.Fatal("undo did not remove the wall")
	}
}
