// Package app assembles the program: it reads the config, builds every service once, runs the long-lived parts
// under a Supervisor and shuts them down in order. Nothing else in the program creates services or holds global
// state; main only picks the subcommand.
package app

import (
	"context"
	"errors"
	"fmt"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync/atomic"
	"time"

	"kuni/internal/admin"
	"kuni/internal/agent"
	"kuni/internal/allow"
	"kuni/internal/autonomy"
	"kuni/internal/config"
	"kuni/internal/dates"
	"kuni/internal/debugui"
	"kuni/internal/diary"
	"kuni/internal/ignore"
	"kuni/internal/imagegen"
	"kuni/internal/ledger"
	"kuni/internal/live"
	"kuni/internal/llm"
	"kuni/internal/llmui"
	"kuni/internal/media"
	"kuni/internal/memory"
	"kuni/internal/metrics"
	"kuni/internal/mood"
	"kuni/internal/netguard"
	"kuni/internal/people"
	"kuni/internal/prompts"
	"kuni/internal/proxy"
	"kuni/internal/reminders"
	"kuni/internal/run"
	"kuni/internal/sched"
	"kuni/internal/telegram"
	"kuni/internal/tools"
	habits "kuni/internal/tracker"
	"kuni/internal/update"
	"kuni/internal/usage"
	"kuni/internal/util"
	"kuni/internal/work"
	"kuni/internal/world"
)

// Options are what main knows before the program starts.
type Options struct {
	ConfigPath string
	Log        *util.LogBuf // the recent log for the panel
	Started    time.Time
}

// LLMSettings are the connection settings of the LLM client from the config.
func LLMSettings(c *config.Config) llm.Settings {
	s := llm.Settings{CachePrompt: c.CachePrompt, BaseURL: c.LLMBaseURL, EmbeddingBaseURL: c.EmbeddingBaseURL, APIKey: c.LLMAPIKey,
		Model: c.LLMModel, EmbeddingModel: c.EmbeddingModel, Reasoning: c.Reasoning, LightModel: c.LightModel, FastModel: c.FastModel,
		VisionModel: c.VisionModel, LightBaseURL: c.LightBaseURL, LightAPIKey: c.LightAPIKey, EmbeddingAPIKey: c.EmbeddingAPIKey}
	if c.Temperature >= 0 {
		t := c.Temperature
		s.Temperature = &t
	}
	return s
}

func promptVars(c *config.Config) prompts.Vars {
	return prompts.Vars{CharacterName: c.CharacterName, CharacterNickname: c.CharacterNick, PapikName: c.PapikName}
}

// Run starts everything and blocks until ctx ends (Ctrl+C, SIGTERM, a restart after an update), then stops it all in
// order: the agent dumps her open conversations to the diary, tdlib flushes its database.
func Run(ctx context.Context, o Options) error {
	if added, err := config.FillMissing(o.ConfigPath); err != nil {
		log.Printf("kuni: config: could not write the missing settings: %v", err)
	} else if len(added) > 0 {
		log.Printf("kuni: config: wrote %d missing settings with their defaults into %s (old file kept as %s.bak): %s", len(added), o.ConfigPath, o.ConfigPath, strings.Join(added, ", "))
	}
	holder, err := config.NewHolder(o.ConfigPath)
	if err != nil {
		return err
	}
	cfg := holder.Get()
	for _, w := range cfg.Warnings {
		log.Printf("config: %s", w)
	}
	getCfg := holder.Get
	ctx, stop := context.WithCancel(ctx)
	defer stop()
	update.OnRestart(stop)

	sup := &run.Supervisor{}
	reg := metrics.New()
	for name, text := range helpTexts {
		reg.Help(name, text)
	}
	sup.OnCrash = func(name string) { reg.Inc("kuni_app_restarts_total", 1, map[string]string{"loop": name}) }
	feed := &live.Feed{}

	// --- the model, the budget and the owner's alerts ---
	client := llm.New("", "", "", "", "", cfg.RequestTimeout)
	client.Update(LLMSettings(cfg))
	var owner ownerLine // filled once Telegram exists
	_ = os.MkdirAll(cfg.DataDir, 0o700)
	tracker := usage.New(filepath.Join(cfg.DataDir, "usage.json"))
	tracker.SetZone(cfg.Location()) // usage days follow the owner's clock
	client.Guard = func() error { return tracker.Guard(holder.Get().DailyTokenLimit) }
	client.Observer = newLLMWatch(getCfg, reg, tracker, owner.Send)

	if cfg.SDEnabled { // her reference picture: written once, then it is the owner's file
		if p := media.ReferencePath(cfg); p != "" {
			if err := media.SeedReference(p); err != nil {
				log.Printf("reference picture: %v", err)
			}
		}
	}

	ps, err := prompts.NewStore(cfg.PromptsDir, promptVars(cfg))
	if err != nil {
		return err
	}
	d, err := diary.New(cfg.DiaryDir, client, cfg.ConfidenceFactor, cfg.DiaryTokenTrigger)
	if err != nil {
		return err
	}
	d.SleepPrompt = func() string { return ps.Get(prompts.SleepConsolidator) }

	// hot reload: config.toml and prompt files.
	holder.OnChange(func(c *config.Config) {
		client.Update(LLMSettings(c))
		client.SetTimeout(c.RequestTimeout)
		d.SetTuning(c.ConfidenceFactor, c.DiaryTokenTrigger)
		tracker.SetZone(c.Location())
		if err := ps.SetVars(promptVars(c)); err != nil {
			log.Printf("prompts: %v", err)
		}
	})
	sup.Go(ctx, "config watch", holder.Watch)
	sup.Go(ctx, "prompt watch", func(ctx context.Context) {
		util.Watch(ctx, 2*time.Second, ps.Files, func(path string) {
			if err := ps.Reload(); err != nil {
				log.Printf("prompts: reload: %v", err)
				return
			}
			log.Printf("prompts: reloaded (%s changed)", filepath.Base(path))
		})
	})

	mediaSvc := func() media.Services { return media.FromConfig(getCfg()) }

	// --- Telegram ---
	tg, err := newTelegram(cfg)
	if err != nil {
		return err
	}
	if cfg.TelegramEnabled {
		owner.set(getCfg, tg)
	}

	ui := &llmui.Env{TG: tg, LLM: client, Prompts: ps, Media: mediaSvc, Cfg: getCfg}
	gen := &imagegen.Generator{LLM: client, Prompts: ps, Media: mediaSvc, CharacterName: func() string { return getCfg().CharacterName }}
	auto := autonomy.New(filepath.Join(cfg.DataDir, "autonomy.json"), filepath.Join(cfg.DataDir, "autonomy.log"))
	auto.SetZone(cfg.Location())
	rt := tools.NewRuntime(feed) // one browser, one desktop, her background jobs: shared by every chat
	defer rt.Close()
	deps := tools.Deps{RT: rt, TG: tg, LLM: client, Diary: d, Prompts: ps, Media: mediaSvc, Cfg: getCfg, UI: ui, Metrics: reg, Images: gen,
		Mood:      mood.New(filepath.Join(cfg.DataDir, "mood.json")),
		Reminders: reminders.New(filepath.Join(cfg.DataDir, "reminders.json")), People: people.New(filepath.Join(cfg.DataDir, "people")),
		Work: work.New(filepath.Join(cfg.DataDir, "work.json")), ConfigPath: o.ConfigPath,
		Allow: allow.New(filepath.Join(cfg.DataDir, "allow.json")), Ignore: ignore.New(filepath.Join(cfg.DataDir, "ignore.json")),
		Sched:  sched.New(filepath.Join(cfg.DataDir, "sched.json"), cfg.Location()),
		Ledger: ledger.New(filepath.Join(cfg.DataDir, "ledger.json")), Tracker: habits.New(filepath.Join(cfg.DataDir, "tracker.json")),
		Dates: dates.New(filepath.Join(cfg.DataDir, "dates.json"))}
	if c, ok := tg.(interface {
		Contacts(context.Context) map[int64]bool
	}); ok && cfg.Mode == "user" {
		deps.Contacts = func(id int64) bool {
			cc, cancel := context.WithTimeout(context.Background(), 15*time.Second)
			defer cancel()
			return c.Contacts(cc)[id]
		}
	}
	dumper := &memory.Dumper{LLM: client, Diary: d, Prompts: ps, CharacterName: func() string { return getCfg().CharacterName },
		WM: memory.WorkingMemory{Path: cfg.WorkingMemoryFile}}

	var ag *agent.Agent
	var wsrv *world.Server
	if cfg.WorldEnabled {
		if wd, err := world.Open(filepath.Join(cfg.DataDir, "world")); err != nil {
			log.Printf("kuni: world: %v", err)
		} else {
			wsrv = &world.Server{W: wd, BotName: cfg.CharacterName, Key: func() string {
				if k := getCfg().WorldKey; k != "" {
					return k
				}
				return getCfg().AdminToken
			}}
			rt.World = wsrv
			wsrv.BotAutobuild(cfg.WorldAutobuild)
			sup.Go(ctx, "world", wsrv.Run)
		}
	}
	if cfg.TelegramEnabled {
		ag = agent.New(&agent.Agent{Price: func(m string) usage.Prices { return PriceOf(holder.Get())(m) }, Cfg: holder, LLM: client, TG: tg,
			Diary: d, Prompts: ps, UI: ui, Dumper: dumper, Metrics: reg, Deps: deps, Auto: auto, Usage: tracker, ConfigPath: o.ConfigPath, Started: o.Started,
			Feed: feed})
		sup.Go(ctx, "telegram", func(ctx context.Context) {
			if err := tg.Run(ctx); err != nil {
				log.Printf("telegram: %v", err)
				stop()
			}
		})
		sup.Go(ctx, "agent", ag.Run)
		if wsrv != nil && cfg.WorldModel != "" {
			wp := newWorldPlayer(wsrv, client, ps, getCfg, deps, filepath.Join(cfg.DataDir, "world"))
			wsrv.OnChat = wp.Hear
			sup.Go(ctx, "world player", wp.Run)
		} else if wsrv != nil {
			wsrv.OnChat = func(from, text string) {
				if id := getCfg().PapikChatID; id != 0 {
					_ = ag.Wake(ctx, id, fmt.Sprintf("[Мир] %s пишет в чате мира: «%s». Ответь ему инструментом world (say), при желании посмотри вокруг (look).", from, text))
				}
			}
		}
	}

	// --- HTTP: the panel, the proxy, /metrics and /debug share one port ---
	panel := &admin.Panel{Cfg: getCfg, ConfigPath: o.ConfigPath, Prompts: ps, Diary: d, Metrics: reg, Log: o.Log, Started: o.Started, TG: tg,
		Frame: rt.Frame, Stream: rt.Stream, Pointer: rt.PointerOf, Screens: rt.Screens, Feed: feed, Mood: deps.Mood, Auto: auto, Usage: tracker, People: deps.People,
		Ignore: deps.Ignore, Allow: deps.Allow, Sched: deps.Sched}
	if ag != nil {
		panel.Ctl = adminCtl{ag}
	}
	panel.Compare = func(ctx context.Context, model, phrase string) (string, error) {
		sys := ps.Get(prompts.System) + "\n\n" + ps.Get(prompts.CharacterBase) + "\n\n<your_appearance>\n" + ps.Get(prompts.CharacterAppearance) + "\n</your_appearance>\n\n" +
			ps.Text(prompts.ToneOwner, nil) + "\n" +
			"This is a test of your voice: answer with ONLY the exact text of your next Telegram message to him (several short lines are fine). No tools, no explanations."
		m, err := client.Complete(llm.WithPurpose(ctx, "compare"), llm.Request{System: sys, Messages: []llm.Message{{Role: "user", Content: phrase}}, Model: model})
		return m.Content, err
	}
	clean := cleaner{cfg: getCfg, tg: tg, LogFile: filepath.Join(update.Dir(), "reina.log")}
	panel.Clean = func() string { return clean.Run(context.Background(), true) }
	if admin.Enabled(cfg) {
		log.Printf("kuni: admin panel on /admin (port %d)", cfg.ProxyPort)
	} else {
		log.Printf("kuni: admin panel is off (set misc.admin_token, 12+ chars, to turn it on)")
	}

	mux := http.NewServeMux()
	panel.Mount(mux)
	if wsrv != nil {
		wsrv.Mount(mux)
	}
	// who may use the endpoints next to the panel: the panel has its own login; the rest is local-only unless a key is sent
	adminKey := func() []string { return []string{getCfg().AdminToken} }
	if cfg.MetricsEnabled {
		guard := netguard.Policy{Keys: adminKey, Scope: netguard.Private, Hint: "only this machine and private networks (Prometheus in Docker), or send Authorization: Bearer <misc.admin_token>"}
		mux.Handle("/metrics", guard.Wrap(reg.Handler()))
	}
	if cfg.DebugUI {
		dbg := &debugui.UI{Cfg: getCfg, Diary: d, Client: client}
		if ag != nil {
			dbg.Sessions = ag.SessionSummaries
		}
		dmux := http.NewServeMux()
		dbg.Mount(dmux)
		guard := netguard.Policy{Keys: adminKey, Scope: netguard.Loopback, Hint: "only from this machine, or send Authorization: Bearer <misc.admin_token>"}
		mux.Handle("/debug", guard.Wrap(dmux))
		mux.Handle("/debug/", guard.Wrap(dmux))
	}
	if cfg.ProxyEnabled {
		bridge := proxy.NewBridge(dumper, func() string { return ps.Get(prompts.CharacterBase) }, func() time.Duration { return getCfg().SessionIdle })
		sup.Go(ctx, "proxy bridge", bridge.Run)
		guard := netguard.Policy{Keys: func() []string { return []string{getCfg().ProxyAPIKey} }, Scope: netguard.Loopback, KeyOnly: true,
			Hint: "set proxy.api_key in config.toml and send it as Authorization: Bearer <key> (without a key only this machine may use the proxy)"}
		srv := &proxy.Server{Cfg: getCfg, Diary: d, Prompts: ps, Client: client, Metrics: reg, Bridge: bridge, HijackSystem: true,
			HTTP: &http.Client{Timeout: 10 * time.Minute}, Guard: guard.Wrap,
			Tools: func(string) *tools.Registry { return tools.NewRegistry(tools.AskTool(deps)) }}
		srv.Mount(mux)
		if cfg.ProxyAPIKey == "" {
			log.Printf("kuni: proxy: no proxy.api_key, so /v1 answers only this machine; set a key to use it from elsewhere")
		}
		log.Printf("kuni: proxy on /v1 (upstream %s)", cfg.LLMBaseURL)
	}
	if cfg.ProxyEnabled || cfg.MetricsEnabled || cfg.DebugUI || admin.Enabled(cfg) || wsrv != nil {
		addr := fmt.Sprintf(":%d", cfg.ProxyPort)
		hs := &http.Server{Addr: addr, Handler: mux, ReadHeaderTimeout: 10 * time.Second, IdleTimeout: 2 * time.Minute}
		sup.Go(ctx, "http", func(ctx context.Context) { serveHTTP(ctx, hs, stop) })
	}

	// --- housekeeping ---
	sup.Go(ctx, "sleep", func(ctx context.Context) { sleepLoop(ctx, d, getCfg) })
	sup.Go(ctx, "maintenance", func(ctx context.Context) { maintLoop(ctx, getCfg, o.ConfigPath, owner.Send, clean.Run) })
	sup.Go(ctx, "daily report", func(ctx context.Context) { reportLoop(ctx, getCfg, tracker, owner.Send) })
	sup.Go(ctx, "telegram watch", func(ctx context.Context) { watchLoop(ctx, getCfg, tg, owner.Send) })
	if update.Pending(update.Dir()) {
		sup.Go(ctx, "update confirm", func(ctx context.Context) { // a freshly installed build proves itself by staying up
			select {
			case <-time.After(update.ConfirmAfter):
				update.Confirm(update.Dir())
				log.Printf("kuni: the new build is confirmed")
				owner.Send("Папик, обновилась и работаю на новой сборке. Если что-то не так, откат в панели, вкладка «Обновление».")
			case <-ctx.Done():
			}
		})
	}

	log.Printf("kuni: %s is up (telegram=%v, proxy=%v). Ctrl+C to stop gracefully.", cfg.CharacterName, cfg.TelegramEnabled, cfg.ProxyEnabled)
	<-ctx.Done()
	log.Printf("kuni: shutting down, dumping remaining context…")
	sup.Wait()
	owner.Wait(10 * time.Second)
	return nil
}

// newTelegram builds the Telegram client the config asks for (a fake that never receives anything when Telegram is
// off, so the tools stay constructible for the proxy).
func newTelegram(cfg *config.Config) (telegram.Client, error) {
	if !cfg.TelegramEnabled {
		return telegram.NewFake(), nil
	}
	switch cfg.Mode {
	case "bot":
		if cfg.BotToken == "" {
			return nil, errors.New(`[telegram] mode = "bot" needs bot_token`)
		}
		bot := telegram.NewBot(cfg.BotToken, cfg.TelegramAPI)
		bot.StatePath = filepath.Join(cfg.DataDir, "telegram_state.json")
		return bot, nil
	default:
		if cfg.TelegramAPIID == 0 || cfg.TelegramHash == "" {
			return nil, errors.New(`[telegram] mode = "user" needs api_id and api_hash from https://my.telegram.org`)
		}
		tr, err := telegram.NewTDJSONTransport()
		if err != nil {
			return nil, err
		}
		return telegram.NewTD(tr, telegram.TDConfig{APIID: cfg.TelegramAPIID, APIHash: cfg.TelegramHash, Phone: cfg.Phone, QR: cfg.TelegramQR, Password: cfg.TelegramPass,
			DBDir: cfg.TDLibDir, AppVersion: "kuni-go"}), nil
	}
}

// serveHTTP runs the server until ctx ends; a port that cannot be opened stops the program (she would be unreachable).
func serveHTTP(ctx context.Context, hs *http.Server, stop func()) {
	errc := make(chan error, 1)
	go func() { errc <- hs.ListenAndServe() }()
	select {
	case err := <-errc:
		if err != nil && !errors.Is(err, http.ErrServerClosed) {
			log.Printf("http: %v", err)
			stop()
		}
	case <-ctx.Done():
		sctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		_ = hs.Shutdown(sctx)
	}
}

// ownerLine sends the program's own messages (alerts, reports) to the owner's private chat. Until Telegram is set up,
// and when no owner is configured, messages are only logged.
type ownerLine struct {
	send     atomic.Pointer[func(string)]
	inflight atomic.Int32
}

func (o *ownerLine) set(cfg func() *config.Config, tg telegram.Client) {
	f := func(text string) {
		c := cfg()
		if c.PapikChatID == 0 {
			log.Printf("kuni: (no owner to tell) %s", text)
			return
		}
		o.inflight.Add(1)
		go func() {
			defer o.inflight.Add(-1)
			sctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
			defer cancel()
			if _, err := tg.SendText(sctx, c.PapikChatID, text, 0); err != nil {
				log.Printf("kuni: could not notify the owner: %v", err)
			}
		}()
	}
	o.send.Store(&f)
}

// Send delivers text to the owner (asynchronously).
func (o *ownerLine) Send(text string) {
	if f := o.send.Load(); f != nil {
		(*f)(text)
		return
	}
	log.Printf("kuni: (to the owner, Telegram is not up) %s", text)
}

// Wait gives the messages still being sent up to d to go out.
func (o *ownerLine) Wait(d time.Duration) {
	deadline := time.Now().Add(d)
	for o.inflight.Load() > 0 && time.Now().Before(deadline) {
		time.Sleep(50 * time.Millisecond)
	}
}

// adminCtl adapts the agent to the admin panel.
type adminCtl struct{ a *agent.Agent }

func (c adminCtl) Paused() bool                            { return c.a.Paused() }
func (c adminCtl) SetPaused(p bool)                        { c.a.SetPaused(p) }
func (c adminCtl) SessionSummaries() []string              { return c.a.SessionSummaries() }
func (c adminCtl) QueueInfo() any                          { return c.a.QueueInfo() }
func (c adminCtl) NoteOwnerAction(chat int64, text string) { c.a.NoteOwnerAction(chat, text) }
func (c adminCtl) Actions(q string, n int) any             { return c.a.Actions(q, n) }
func (c adminCtl) DescribePerson(ctx context.Context, id int64) (people.Card, error) {
	return c.a.DescribePerson(ctx, id)
}
func (c adminCtl) DialogList() any                      { return c.a.DialogList() }
func (c adminCtl) DialogMessages(id int64) (any, error) { return c.a.DialogMessages(id) }
