package main

import (
	"io"
	"path/filepath"
	"testing"

	"kuni/internal/config"
)

func TestMaxPresetApplies(t *testing.T) {
	p := filepath.Join(t.TempDir(), "config.toml")
	_, _ = config.Load(p) // first run writes the defaults
	if err := runMax(p, io.Discard); err != nil {
		t.Fatal(err)
	}
	c, err := config.Load(p)
	if err != nil {
		t.Fatal(err)
	}
	if c.Reasoning != "high" || c.FastRounds || c.MaxToolRounds != 40 || c.ContextChars != 200000 || c.LazyTools || len(c.Warnings) != 0 {
		t.Fatalf("%+v warnings=%v", c, c.Warnings)
	}
	if err := runSet(p, "llm.nonsense", "1", io.Discard); err == nil {
		t.Fatal("an unknown key must be refused")
	}
}
