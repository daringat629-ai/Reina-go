#!/bin/sh
# Установить программу из репозитория Alpine и запомнить её в apps.txt, чтобы она вернулась после пересоздания контейнера.
#   sh /opt/reina/app-add.sh firefox
# Запускается внутри контейнера (от root). Только имена пакетов Alpine: буквы, цифры, - _ . +
cd "$(dirname "$0")" || exit 1
[ $# -ge 1 ] || { echo "укажи имя пакета, например: sh $0 firefox"; exit 1; }
for p in "$@"; do
	case "$p" in
	*[!a-zA-Z0-9._+-]*|-*) echo "✘ странное имя пакета: $p"; exit 1 ;;
	esac
done
apk add --no-cache "$@" || { echo "✘ не удалось установить (проверь имя: apk search имя)"; exit 1; }
for p in "$@"; do grep -qx "$p" apps.txt 2>/dev/null || echo "$p" >> apps.txt; done
echo "✔ установлено и записано в apps.txt: $*"
