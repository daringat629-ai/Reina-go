#!/bin/sh
# Голос Рейны на этом компьютере: Piper + маленький сервер, который Рейна использует как OpenAI-совместимую озвучку.
#   sh install.sh            поставить и запустить (Piper и голос уже должны стоять: ~/piper и ~/voices)
#   PITCH=1.2 sh install.sh  то же, но с более высоким, «няшным» тоном (1.0 = как есть)
set -e
cd "$(dirname "$0")"
D="$HOME/voice"
mkdir -p "$D"
cp server.py "$D/server.py"
[ -x "$HOME/piper/bin/python" ] || { echo "✘ нет ~/piper (python3 -m venv ~/piper && ~/piper/bin/pip install piper-tts)"; exit 1; }
ls "$HOME/voices"/*.onnx >/dev/null 2>&1 || { echo "✘ нет голоса в ~/voices (cd ~/voices && ~/piper/bin/python -m piper.download_voices ru_RU-irina-medium)"; exit 1; }
sudo tee /etc/systemd/system/reina-voice.service >/dev/null <<EOF
[Unit]
Description=Reina voice (Piper)
After=network.target

[Service]
User=$(id -un)
Environment=PITCH=${PITCH:-1.0}
Environment=VOICE=${VOICE:-ru_RU-irina-medium}
ExecStart=/usr/bin/python3 $D/server.py
Restart=always
MemoryMax=600M

[Install]
WantedBy=multi-user.target
EOF
sudo systemctl daemon-reload
sudo systemctl enable --now reina-voice
sleep 2
curl -s http://127.0.0.1:8880/ && echo " ← сервер голоса работает"
echo
echo "Теперь включи её озвучку (один раз):"
echo "  cd /opt/reina && sudo docker run --rm -v /opt/reina:/opt/reina reina ./reina-tdlib set capabilities.tts_backend openai"
echo "  sudo docker run --rm -v /opt/reina:/opt/reina reina ./reina-tdlib set capabilities.tts_url http://localhost:8880/v1/"
echo "  sudo docker restart reina"
