"""Tiny OpenAI-compatible /v1/audio/speech on top of Piper (local, CPU). Answers ogg/opus: what Telegram voice messages are.

Environment: VOICE (default ru_RU-irina-medium), VOICES_DIR (where the .onnx lives), PIPER_PY (python with piper-tts),
PITCH (1.0 = as is, 1.2 = a higher, softer "cute" voice), SR (sample rate of the voice, 22050 for medium), PORT.
"""
import json, os, subprocess, tempfile, threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HOME = os.path.expanduser("~")
VOICE = os.environ.get("VOICE", "ru_RU-irina-medium")
VOICES = os.environ.get("VOICES_DIR", os.path.join(HOME, "voices"))
PIPER = os.environ.get("PIPER_PY", os.path.join(HOME, "piper", "bin", "python"))
PITCH = float(os.environ.get("PITCH", "1.0"))
SR = int(os.environ.get("SR", "22050"))
LOCK = threading.Lock()  # one synthesis at a time: keeps memory low on a 2 GB machine


def synth(text, speed, pitch):
    with tempfile.TemporaryDirectory() as d:
        wav = os.path.join(d, "a.wav")
        cmd = [PIPER, "-m", "piper", "-m", VOICE, "--data-dir", VOICES, "-f", wav,
               "--length-scale", str(round(1.0 / max(0.5, min(2.0, speed)), 2)), "--", text]
        with LOCK:
            subprocess.run(cmd, check=True, timeout=120, capture_output=True)
        af = []
        if abs(pitch - 1.0) > 0.01:  # raise the pitch, then give the speed back
            af = ["-af", f"asetrate={int(SR * pitch)},aresample={SR},atempo={round(1.0 / pitch, 4)}"]
        out = subprocess.run(["ffmpeg", "-v", "error", "-i", wav] + af + ["-c:a", "libopus", "-b:a", "32k", "-f", "ogg", "-"],
                             check=True, timeout=60, capture_output=True)
        return out.stdout


class H(BaseHTTPRequestHandler):
    def _send(self, code, body, ctype="application/json"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        self._send(200, b'{"ok":true}')

    def do_POST(self):
        if not self.path.rstrip("/").endswith("/audio/speech"):
            return self._send(404, b'{"error":"not found"}')
        try:
            n = int(self.headers.get("Content-Length", "0"))
            req = json.loads(self.rfile.read(n) or b"{}")
            text = (req.get("input") or "").strip()
            if not text:
                return self._send(400, b'{"error":"empty input"}')
            audio = synth(text[:4000], float(req.get("speed") or 1.0), PITCH)
            self._send(200, audio, "audio/ogg")
        except Exception as e:
            self._send(500, json.dumps({"error": str(e)}).encode())

    def log_message(self, *a):
        pass


if __name__ == "__main__":
    ThreadingHTTPServer(("127.0.0.1", int(os.environ.get("PORT", "8880"))), H).serve_forever()
