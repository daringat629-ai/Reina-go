package mir

import (
	"fmt"
	"math"
	"strings"
)

type Slot struct {
	I int `json:"i"` // item id
	N int `json:"n"` // count
	D int `json:"d"` // damage taken (tools/armour)
}

type ItemEnt struct {
	id       int
	item, n  int
	dmg      int
	x, y, z  float64
	vx, vy   float64
	vz       float64
	age      float64
	noPickup float64
}

func ckeyStr(x, y, z int) string { return fmt.Sprintf("%d,%d,%d", x, y, z) }

func (s *Server) dropItemL(item, n, dmg int, x, y, z float64) {
	if !validItem(item) || n <= 0 {
		return
	}
	r := s.mobs.r
	s.items = append(s.items, &ItemEnt{id: s.nextItem, item: item, n: n, dmg: dmg, x: x, y: y, z: z, vx: (r.Float64() - .5) * 2, vy: 3, vz: (r.Float64() - .5) * 2, noPickup: .6})
	s.nextItem++
	if len(s.items) > 400 {
		s.items = s.items[len(s.items)-400:]
	}
}

func (s *Server) itemsStepL(dt float64) {
	keep := s.items[:0]
	for _, it := range s.items {
		it.age += dt
		if it.noPickup > 0 {
			it.noPickup -= dt
		}
		if it.age > 300 {
			continue
		}
		// physics
		it.vy -= 20 * dt
		nx, nz := it.x+it.vx*dt, it.z+it.vz*dt
		if !s.solidAt(nx, it.y+.1, nz) {
			it.x, it.z = nx, nz
		}
		it.vx *= math.Max(0, 1-dt*3)
		it.vz *= math.Max(0, 1-dt*3)
		ny := it.y + it.vy*dt
		if it.vy < 0 && s.solidAt(it.x, ny, it.z) {
			it.y = math.Floor(ny) + 1
			it.vy = 0
		} else if s.solidAt(it.x, ny, it.z) {
			it.vy = 0
		} else {
			it.y = ny
		}
		if it.y < -20 {
			continue
		}
		taken := false
		if it.noPickup <= 0 {
			for _, p := range s.players {
				if p.mode != "survival" || !p.alive {
					continue
				}
				if math.Abs(p.x-it.x) < 1.4 && math.Abs(p.z-it.z) < 1.4 && it.y > p.y-.6 && it.y < p.y+2.2 {
					s.sendL(p, map[string]any{"t": "give", "i": it.item, "n": it.n, "d": it.dmg})
					taken = true
					break
				}
			}
		}
		if !taken {
			keep = append(keep, it)
		}
	}
	s.items = keep
}

func (s *Server) itemsSnapshotL() [][]float64 {
	out := make([][]float64, 0, len(s.items))
	for _, it := range s.items {
		out = append(out, []float64{float64(it.id), float64(it.item), math.Round(it.x*100) / 100, math.Round(it.y*100) / 100, math.Round(it.z*100) / 100, float64(it.n)})
	}
	return out
}

func (s *Server) spillChestL(x, y, z int) {
	k := ckeyStr(x, y, z)
	for _, sl := range s.w.meta.Chests[k] {
		if sl.I > 0 && sl.N > 0 {
			s.dropItemL(sl.I, sl.N, sl.D, float64(x)+.5, float64(y)+.5, float64(z)+.5)
		}
	}
	delete(s.w.meta.Chests, k)
}

// hurtL damages a survival player; the client applies armour and knockback.
func (s *Server) hurtL(p *Player, dmg, kx, kz float64, from string) {
	if p.mode != "survival" || !p.alive || dmg <= 0 {
		return
	}
	s.sendL(p, map[string]any{"t": "hurt", "d": dmg, "kx": kx, "kz": kz, "from": from})
}

func sanitizeSlots(arr []any, max int) []Slot {
	out := make([]Slot, 0, max)
	for _, v := range arr {
		if len(out) >= max {
			break
		}
		a, ok := v.([]any)
		if !ok || len(a) < 2 {
			out = append(out, Slot{})
			continue
		}
		f := func(i int) int {
			if i < len(a) {
				if x, ok := a[i].(float64); ok {
					return int(x)
				}
			}
			return 0
		}
		sl := Slot{f(0), f(1), f(2)}
		if !validItem(sl.I) || sl.N <= 0 {
			sl = Slot{}
		}
		if sl.N > 64 {
			sl.N = 64
		}
		out = append(out, sl)
	}
	return out
}

func (s *Server) respawnPointL(p *Player) (float64, float64, float64) {
	sv := s.w.meta.Players[p.name]
	if sv != nil && sv.HasBed {
		bx, by, bz := int(sv.BedX), int(sv.BedY), int(sv.BedZ)
		if s.w.Block(bx, by, bz) == B("bed") {
			return sv.BedX + .5, float64(s.w.Ground(bx, bz)), sv.BedZ + .5
		}
		sv.HasBed = false
		s.sysTo(p, "Твоя кровать пропала — появляешься на точке спавна.")
	}
	sp := s.w.spawn
	return float64(sp[0]) + .5, float64(s.w.Ground(sp[0], sp[2])), float64(sp[2]) + .5
}

// handleSurvival processes survival-only messages. Returns true if handled.
func (s *Server) handleSurvival(p *Player, t string, m map[string]any) bool {
	switch t {
	case "hit":
		s.mu.Lock()
		s.hitL(p, int(num(m, "id")), num(m, "dmg"))
		s.mu.Unlock()
	case "state":
		s.mu.Lock()
		if sv := s.w.meta.Players[p.name]; sv != nil && p.mode == "survival" {
			inv, _ := m["inv"].([]any)
			arm, _ := m["arm"].([]any)
			sv.Inv = sanitizeSlots(inv, 36)
			sv.Armor = sanitizeSlots(arm, 4)
			sv.HP = math.Max(0, math.Min(20, num(m, "hp")))
			sv.Food = math.Max(0, math.Min(20, num(m, "food")))
			sv.Sat = math.Max(0, math.Min(20, num(m, "sat")))
		}
		s.mu.Unlock()
	case "die":
		s.mu.Lock()
		if p.alive && p.mode == "survival" {
			p.alive = false
			inv, _ := m["inv"].([]any)
			arm, _ := m["arm"].([]any)
			for _, sl := range append(sanitizeSlots(inv, 36), sanitizeSlots(arm, 4)...) {
				if sl.I > 0 {
					s.dropItemL(sl.I, sl.N, sl.D, p.x, p.y+.6, p.z)
				}
			}
			cause, _ := m["cause"].(string)
			if len([]rune(cause)) > 60 {
				cause = string([]rune(cause)[:60])
			}
			s.sayL("", "☠ "+p.name+" "+cause)
			if sv := s.w.meta.Players[p.name]; sv != nil {
				sv.Inv, sv.Armor, sv.HP, sv.Food, sv.Sat = nil, nil, 20, 20, 5
			}
		}
		s.mu.Unlock()
	case "respawn":
		s.mu.Lock()
		p.alive = true
		x, y, z := s.respawnPointL(p)
		s.tpL(p, x, y, z)
		s.mu.Unlock()
	case "drop":
		s.mu.Lock()
		it, n, d := int(num(m, "i")), int(num(m, "n")), int(num(m, "d"))
		if n > 0 && n <= 64 && validItem(it) {
			yaw := p.yaw
			s.dropItemL(it, n, d, p.x-math.Sin(yaw)*.6, p.y+1.3, p.z-math.Cos(yaw)*.6)
			last := s.items[len(s.items)-1]
			last.vx, last.vz, last.vy = -math.Sin(yaw)*4, -math.Cos(yaw)*4, 2.5
			last.noPickup = 1.5
			if num(m, "back") > 0 { // inventory full: put it right at the feet
				last.x, last.y, last.z, last.vx, last.vz = p.x, p.y+.3, p.z, 0, 0
				last.noPickup = 3
			}
		}
		s.mu.Unlock()
	case "chest":
		x, y, z := int(num(m, "x")), int(num(m, "y")), int(num(m, "z"))
		s.mu.Lock()
		if s.w.Block(x, y, z) == B("chest") {
			sl := s.w.meta.Chests[ckeyStr(x, y, z)]
			if sl == nil {
				sl = make([]Slot, 27)
			}
			s.sendL(p, map[string]any{"t": "chest", "x": x, "y": y, "z": z, "s": sl})
		}
		s.mu.Unlock()
	case "chestput":
		x, y, z := int(num(m, "x")), int(num(m, "y")), int(num(m, "z"))
		arr, _ := m["s"].([]any)
		s.mu.Lock()
		if s.w.Block(x, y, z) == B("chest") {
			s.w.meta.Chests[ckeyStr(x, y, z)] = sanitizeSlots(arr, 27)
		}
		s.mu.Unlock()
	case "sleep":
		x, y, z := int(num(m, "x")), int(num(m, "y")), int(num(m, "z"))
		s.mu.Lock()
		if s.w.Block(x, y, z) == B("bed") {
			if sv := s.w.meta.Players[p.name]; sv != nil {
				sv.BedX, sv.BedY, sv.BedZ, sv.HasBed = float64(x), float64(y), float64(z), true
			}
			if s.isNight() {
				near := false
				for _, o := range s.mobs.list {
					if o.hostile() && math.Hypot(o.x-p.x, o.z-p.z) < 8 {
						near = true
					}
				}
				if near {
					s.sysTo(p, "Нельзя спать: рядом монстры!")
				} else {
					s.w.meta.Time = .02
					s.broadcastL(map[string]any{"t": "time", "v": s.w.meta.Time}, -1)
					s.sayL("", "🌙 "+p.name+" поспал — наступило утро")
				}
			} else {
				s.sysTo(p, "Точка возрождения сохранена. Спать можно только ночью.")
			}
		}
		s.mu.Unlock()
	case "grow":
		x, y, z := int(num(m, "x")), int(num(m, "y")), int(num(m, "z"))
		s.mu.Lock()
		if math.Hypot(float64(x)-p.x, float64(z)-p.z) < 8 {
			s.growL(x, y, z, true)
		}
		s.mu.Unlock()
	default:
		return false
	}
	return true
}

// growL advances a crop or sapling.
func (s *Server) growL(x, y, z int, boost bool) {
	id := s.w.Block(x, y, z)
	name := Blocks[id].Name
	switch {
	case strings.HasPrefix(name, "wheat_"):
		st := int(name[6] - '0')
		if st >= 3 {
			return
		}
		if s.w.Block(x, y-1, z) != B("farmland") {
			return
		}
		st++
		if boost && st < 3 {
			st++
		}
		s.setL(x, y, z, B(fmt.Sprintf("wheat_%d", st)))
	case name == "sapling":
		if !boost && s.mobs.r.Float64() < .5 {
			return
		}
		below := s.w.Block(x, y-1, z)
		if !isSolid(below) {
			return
		}
		kind := tOak
		bn := Blocks[below].Name
		switch {
		case bn == "snow_grass" || bn == "podzol":
			kind = tSpruce
		case s.mobs.r.Float64() < .25:
			kind = tBirch
		}
		s.setL(x, y, z, 0)
		for _, b := range s.w.gen.treeBlocks(x, z, kind, y-1, nil) {
			cur := s.w.Block(b.x, b.y, b.z)
			if cur == 0 || Blocks[cur].Cross || !b.weak && Blocks[cur].Trans {
				s.setL(b.x, b.y, b.z, b.id)
			}
		}
	}
}

// growthTickL: crops and saplings grow in loaded chunks near players.
func (s *Server) growthTickL() {
	w := s.w
	var wheat [3]byte
	for i := range wheat {
		wheat[i] = B(fmt.Sprintf("wheat_%d", i))
	}
	sap := B("sapling")
	type pos struct{ x, y, z int }
	var grow []pos
	seen := map[ckey]bool{}
	w.mu.Lock()
	for _, p := range s.players {
		pcx, pcz := floorDiv(int(p.x), CX), floorDiv(int(p.z), CZ)
		for dx := -4; dx <= 4; dx++ {
			for dz := -4; dz <= 4; dz++ {
				k := ckey{pcx + dx, pcz + dz}
				if seen[k] {
					continue
				}
				seen[k] = true
				c := w.chunks[k]
				if c == nil {
					continue
				}
				for i, v := range c.b {
					if v == wheat[0] || v == wheat[1] || v == wheat[2] || v == sap {
						chance := 1.0 / 40
						if v == sap {
							chance = 1.0 / 90
						}
						if s.mobs.r.Float64() < chance {
							x := i % CX
							z := (i / CX) % CZ
							y := i / (CX * CZ)
							grow = append(grow, pos{k.x*CX + x, y, k.z*CZ + z})
						}
					}
				}
			}
		}
	}
	w.mu.Unlock()
	for _, g := range grow {
		s.growL(g.x, g.y, g.z, false)
	}
}

// Rayna protects her friends: she swats monsters next to her.
func (b *Bot) defendL(dt float64) {
	for _, o := range b.s.mobs.list {
		if !o.hostile() || o.hp <= 0 {
			continue
		}
		if math.Hypot(o.x-b.p.x, o.z-b.p.z) < 3.5 && math.Abs(o.y-b.p.y) < 3 {
			if b.s.mobs.r.Float64() < dt*1.5 {
				o.hp -= 6
				o.hurt = .35
				d := math.Hypot(o.x-b.p.x, o.z-b.p.z) + .01
				o.vx, o.vz, o.vy = (o.x-b.p.x)/d*8, (o.z-b.p.z)/d*8, 5
				o.fuse = 0
				b.p.anim = 3
				if o.hp <= 0 && b.s.mobs.r.Float64() < .4 {
					b.s.sayL(b.p.name, []string{"Кыш отсюда! 💥", "Не трогай моих друзей!", "Ещё один монстр побеждён ✨"}[b.r.Intn(3)])
				}
			}
		}
	}
}
