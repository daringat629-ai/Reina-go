package mir

// Minimal RFC 6455 WebSocket server side (stdlib only).

import (
	"bufio"
	"crypto/sha1"
	"encoding/base64"
	"encoding/binary"
	"errors"
	"io"
	"net"
	"net/http"
	"strings"
	"sync"
	"time"
)

type wsConn struct {
	c   net.Conn
	br  *bufio.Reader
	wmu sync.Mutex
}

const wsGUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

func wsUpgrade(w http.ResponseWriter, r *http.Request) (*wsConn, error) {
	if !strings.EqualFold(r.Header.Get("Upgrade"), "websocket") {
		http.Error(w, "websocket expected", http.StatusBadRequest)
		return nil, errors.New("not websocket")
	}
	key := r.Header.Get("Sec-WebSocket-Key")
	if key == "" {
		http.Error(w, "bad key", http.StatusBadRequest)
		return nil, errors.New("no key")
	}
	hj, ok := w.(http.Hijacker)
	if !ok {
		return nil, errors.New("no hijack")
	}
	conn, brw, err := hj.Hijack()
	if err != nil {
		return nil, err
	}
	h := sha1.Sum([]byte(key + wsGUID))
	acc := base64.StdEncoding.EncodeToString(h[:])
	resp := "HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: " + acc + "\r\n\r\n"
	if _, err := conn.Write([]byte(resp)); err != nil {
		conn.Close()
		return nil, err
	}
	return &wsConn{c: conn, br: brw.Reader}, nil
}

// read returns the next complete text/binary message.
func (ws *wsConn) read() (op byte, data []byte, err error) {
	var msg []byte
	var msgOp byte
	for {
		ws.c.SetReadDeadline(time.Now().Add(90 * time.Second))
		var hdr [2]byte
		if _, err = io.ReadFull(ws.br, hdr[:]); err != nil {
			return
		}
		fin := hdr[0]&0x80 != 0
		opc := hdr[0] & 0x0f
		masked := hdr[1]&0x80 != 0
		n := uint64(hdr[1] & 0x7f)
		switch n {
		case 126:
			var b [2]byte
			if _, err = io.ReadFull(ws.br, b[:]); err != nil {
				return
			}
			n = uint64(binary.BigEndian.Uint16(b[:]))
		case 127:
			var b [8]byte
			if _, err = io.ReadFull(ws.br, b[:]); err != nil {
				return
			}
			n = binary.BigEndian.Uint64(b[:])
		}
		if n > 1<<20 || len(msg)+int(n) > 1<<20 {
			return 0, nil, errors.New("frame too big")
		}
		var mask [4]byte
		if masked {
			if _, err = io.ReadFull(ws.br, mask[:]); err != nil {
				return
			}
		}
		payload := make([]byte, n)
		if _, err = io.ReadFull(ws.br, payload); err != nil {
			return
		}
		if masked {
			for i := range payload {
				payload[i] ^= mask[i&3]
			}
		}
		switch opc {
		case 0x8:
			ws.writeFrame(0x8, nil)
			return 0, nil, io.EOF
		case 0x9:
			ws.writeFrame(0xA, payload)
			continue
		case 0xA:
			continue
		case 0x0:
			msg = append(msg, payload...)
		default:
			msgOp = opc
			msg = payload
		}
		if fin {
			return msgOp, msg, nil
		}
	}
}

func (ws *wsConn) writeFrame(op byte, data []byte) error {
	ws.wmu.Lock()
	defer ws.wmu.Unlock()
	var hdr [10]byte
	hdr[0] = 0x80 | op
	n := len(data)
	hl := 2
	switch {
	case n < 126:
		hdr[1] = byte(n)
	case n < 65536:
		hdr[1] = 126
		binary.BigEndian.PutUint16(hdr[2:], uint16(n))
		hl = 4
	default:
		hdr[1] = 127
		binary.BigEndian.PutUint64(hdr[2:], uint64(n))
		hl = 10
	}
	ws.c.SetWriteDeadline(time.Now().Add(20 * time.Second))
	if _, err := ws.c.Write(hdr[:hl]); err != nil {
		return err
	}
	_, err := ws.c.Write(data)
	return err
}

func (ws *wsConn) close() { ws.c.Close() }
