package mir

import (
	"bytes"
	"compress/gzip"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"io"
	"math/rand"
	"os"
	"path/filepath"
	"sync"
	"time"
)

type Chunk struct {
	cx, cz   int
	b        [CX * CY * CZ]byte
	dirty    bool // needs saving
	lastUsed time.Time
	enc      []byte // cached network encoding
}

type ckey struct{ x, z int }

type PlayerSave struct {
	X, Y, Z  float64
	Yaw      float64
	Hotbar   []int
	HomeX    float64
	HomeY    float64
	HomeZ    float64
	HasHome  bool
	Color    int
	LastSeen int64
	Mode     string
	Inv      []Slot
	Armor    []Slot
	HP       float64
	Food     float64
	Sat      float64
	BedX     float64
	BedY     float64
	BedZ     float64
	HasBed   bool
	Started  bool
}

type Meta struct {
	Seed    int64
	Time    float64
	Players map[string]*PlayerSave
	Builds  int
	Version int
	Chests  map[string][]Slot
}

type World struct {
	mu     sync.Mutex
	dir    string
	gen    *Gen
	chunks map[ckey]*Chunk
	meta   Meta
	spawn  [3]int
}

func OpenWorld(dir string) (*World, error) {
	if err := os.MkdirAll(filepath.Join(dir, "chunks"), 0o755); err != nil {
		return nil, err
	}
	w := &World{dir: dir, chunks: map[ckey]*Chunk{}}
	mb, err := os.ReadFile(filepath.Join(dir, "meta.json"))
	if err == nil {
		json.Unmarshal(mb, &w.meta)
	}
	if w.meta.Seed == 0 {
		w.meta.Seed = rand.Int63()
		w.meta.Time = .25
	}
	if w.meta.Chests == nil {
		w.meta.Chests = map[string][]Slot{}
	}
	if w.meta.Players == nil {
		w.meta.Players = map[string]*PlayerSave{}
	}
	w.meta.Version = 2
	w.gen = NewGen(w.meta.Seed)
	x, y, z := w.gen.Spawn()
	w.spawn = [3]int{x, y, z}
	return w, nil
}

func (w *World) chunkFile(cx, cz int) string {
	return filepath.Join(w.dir, "chunks", fmt.Sprintf("c.%d.%d.gz", cx, cz))
}

func (w *World) ensure(cx, cz int) *Chunk {
	k := ckey{cx, cz}
	if c, ok := w.chunks[k]; ok {
		c.lastUsed = time.Now()
		return c
	}
	c := w.loadChunk(cx, cz)
	if c == nil {
		c = w.gen.Generate(cx, cz)
	}
	c.lastUsed = time.Now()
	w.chunks[k] = c
	return c
}

func (w *World) loadChunk(cx, cz int) *Chunk {
	f, err := os.Open(w.chunkFile(cx, cz))
	if err != nil {
		return nil
	}
	defer f.Close()
	zr, err := gzip.NewReader(f)
	if err != nil {
		return nil
	}
	data, err := io.ReadAll(zr)
	if err != nil || len(data) != CX*CY*CZ {
		return nil
	}
	c := &Chunk{cx: cx, cz: cz}
	copy(c.b[:], data)
	for i, v := range c.b {
		if int(v) >= len(Blocks) {
			c.b[i] = 0
		}
	}
	return c
}

func (w *World) saveChunk(c *Chunk) error {
	var buf bytes.Buffer
	zw, _ := gzip.NewWriterLevel(&buf, gzip.BestSpeed)
	zw.Write(c.b[:])
	zw.Close()
	tmp := w.chunkFile(c.cx, c.cz) + ".tmp"
	if err := os.WriteFile(tmp, buf.Bytes(), 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, w.chunkFile(c.cx, c.cz))
}

func (w *World) Block(x, y, z int) byte {
	if y < 0 {
		return B("bedrock")
	}
	if y >= CY {
		return 0
	}
	w.mu.Lock()
	defer w.mu.Unlock()
	c := w.ensure(floorDiv(x, CX), floorDiv(z, CZ))
	return c.b[idx(floorMod(x, CX), y, floorMod(z, CZ))]
}

func (w *World) SetBlock(x, y, z int, id byte) bool {
	if y < 0 || y >= CY {
		return false
	}
	w.mu.Lock()
	defer w.mu.Unlock()
	c := w.ensure(floorDiv(x, CX), floorDiv(z, CZ))
	i := idx(floorMod(x, CX), y, floorMod(z, CZ))
	if c.b[i] == id {
		return false
	}
	c.b[i] = id
	c.dirty = true
	c.enc = nil
	return true
}

// Ground returns the y of the first free (non-solid) block above the surface at x,z.
func (w *World) Ground(x, z int) int {
	w.mu.Lock()
	defer w.mu.Unlock()
	c := w.ensure(floorDiv(x, CX), floorDiv(z, CZ))
	lx, lz := floorMod(x, CX), floorMod(z, CZ)
	for y := CY - 2; y > 0; y-- {
		id := c.b[idx(lx, y, lz)]
		if isSolid(id) || Blocks[id].Liquid {
			return y + 1
		}
	}
	return 1
}

// SurfaceAt returns the top block id and its y.
func (w *World) SurfaceAt(x, z int) (byte, int) {
	y := w.Ground(x, z) - 1
	return w.Block(x, y, z), y
}

func encodeChunk(c *Chunk) []byte {
	out := make([]byte, 9, 4096)
	out[0] = 1
	binary.LittleEndian.PutUint32(out[1:], uint32(int32(c.cx)))
	binary.LittleEndian.PutUint32(out[5:], uint32(int32(c.cz)))
	n := len(c.b)
	for i := 0; i < n; {
		v := c.b[i]
		j := i + 1
		for j < n && c.b[j] == v && j-i < 65535 {
			j++
		}
		run := j - i
		out = append(out, byte(run), byte(run>>8), v)
		i = j
	}
	return out
}

func (w *World) EncodeChunk(cx, cz int) []byte {
	w.mu.Lock()
	defer w.mu.Unlock()
	c := w.ensure(cx, cz)
	if c.enc == nil {
		c.enc = encodeChunk(c)
	}
	return c.enc
}

func (w *World) Save() {
	w.mu.Lock()
	var dirty []*Chunk
	for _, c := range w.chunks {
		if c.dirty {
			dirty = append(dirty, c)
			c.dirty = false
		}
	}
	mb, _ := json.MarshalIndent(&w.meta, "", " ")
	w.mu.Unlock()
	for _, c := range dirty {
		w.mu.Lock()
		cp := *c
		w.mu.Unlock()
		if err := w.saveChunk(&cp); err != nil {
			fmt.Println("не удалось сохранить чанк:", err)
		}
	}
	tmp := filepath.Join(w.dir, "meta.json.tmp")
	if os.WriteFile(tmp, mb, 0o644) == nil {
		os.Rename(tmp, filepath.Join(w.dir, "meta.json"))
	}
}

// Unload drops chunks nobody used for a while (saving them first).
func (w *World) Unload(keep func(cx, cz int) bool) {
	w.mu.Lock()
	defer w.mu.Unlock()
	for k, c := range w.chunks {
		if time.Since(c.lastUsed) > 2*time.Minute && !keep(k.x, k.z) {
			if c.dirty {
				w.saveChunk(c)
			}
			delete(w.chunks, k)
		}
	}
}
