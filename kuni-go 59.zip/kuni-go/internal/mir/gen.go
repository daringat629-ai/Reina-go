package mir

import "math"

const (
	CX, CY, CZ = 16, 128, 16
	SEA        = 46
)

const (
	bOcean = iota
	bBeach
	bPlains
	bForest
	bBirch
	bTaiga
	bDesert
	bMesa
	bMountain
	bCherry
	bSnowPlains
)

var biomeNames = []string{"океан", "пляж", "равнины", "лес", "березняк", "тайга", "пустыня", "каньоны", "горы", "вишнёвая роща", "снежная равнина"}

type Gen struct{ seed int64 }

func NewGen(seed int64) *Gen { return &Gen{seed: seed} }

func (g *Gen) hash(x, y, z int64) uint64 {
	h := uint64(g.seed)*0x9E3779B97F4A7C15 ^ uint64(x)*0xBF58476D1CE4E5B9 ^ uint64(y)*0x94D049BB133111EB ^ uint64(z)*0xD6E8FEB86659FD93
	h ^= h >> 31
	h *= 0x7FB5D329728EA185
	h ^= h >> 27
	h *= 0x81DADEF4BC2DD44D
	h ^= h >> 33
	return h
}
func (g *Gen) unit(x, y, z int64) float64 { return float64(g.hash(x, y, z)>>11) / float64(1<<53) }

func smooth(t float64) float64     { return t * t * t * (t*(t*6-15) + 10) }
func lerp(a, b, t float64) float64 { return a + (b-a)*t }

// gradient noise 2D in [-1,1]
func (g *Gen) grad2(ix, iz int64, fx, fz float64, salt int64) float64 {
	a := g.unit(ix, salt, iz) * 2 * math.Pi
	return math.Cos(a)*fx + math.Sin(a)*fz
}
func (g *Gen) noise2(x, z float64, salt int64) float64 {
	x0, z0 := math.Floor(x), math.Floor(z)
	fx, fz := x-x0, z-z0
	ix, iz := int64(x0), int64(z0)
	u, v := smooth(fx), smooth(fz)
	n00 := g.grad2(ix, iz, fx, fz, salt)
	n10 := g.grad2(ix+1, iz, fx-1, fz, salt)
	n01 := g.grad2(ix, iz+1, fx, fz-1, salt)
	n11 := g.grad2(ix+1, iz+1, fx-1, fz-1, salt)
	return lerp(lerp(n00, n10, u), lerp(n01, n11, u), v) * 1.41
}
func (g *Gen) fbm2(x, z float64, oct int, salt int64) float64 {
	s, a, f, n := 0.0, 1.0, 1.0, 0.0
	for i := 0; i < oct; i++ {
		s += g.noise2(x*f, z*f, salt+int64(i)*101) * a
		n += a
		a *= .5
		f *= 2.03
	}
	return s / n
}
func (g *Gen) noise3(x, y, z float64, salt int64) float64 {
	x0, y0, z0 := math.Floor(x), math.Floor(y), math.Floor(z)
	fx, fy, fz := x-x0, y-y0, z-z0
	ix, iy, iz := int64(x0), int64(y0), int64(z0)
	c := func(dx, dy, dz int64) float64 {
		h := g.hash(ix+dx, iy+dy+salt*7919, iz+dz)
		gx := float64(int64(h&0xff)-128) / 128
		gy := float64(int64((h>>8)&0xff)-128) / 128
		gz := float64(int64((h>>16)&0xff)-128) / 128
		return gx*(fx-float64(dx)) + gy*(fy-float64(dy)) + gz*(fz-float64(dz))
	}
	u, v, w := smooth(fx), smooth(fy), smooth(fz)
	return lerp(
		lerp(lerp(c(0, 0, 0), c(1, 0, 0), u), lerp(c(0, 1, 0), c(1, 1, 0), u), v),
		lerp(lerp(c(0, 0, 1), c(1, 0, 1), u), lerp(c(0, 1, 1), c(1, 1, 1), u), v), w) * 1.6
}

type column struct {
	h     int
	biome int
	temp  float64
	moist float64
}

func (g *Gen) column(x, z int) column {
	fx, fz := float64(x), float64(z)
	// domain warp for less grid-like coasts
	wx := fx + g.fbm2(fx/200, fz/200, 2, 900)*40
	wz := fz + g.fbm2(fx/200, fz/200, 2, 901)*40
	cont := g.fbm2(wx/700, wz/700, 4, 1) + .12
	temp := g.fbm2(fx/1100, fz/1100, 3, 2) * 1.7
	moist := g.fbm2(fx/900, fz/900, 3, 3) * 1.7
	detail := g.fbm2(fx/90, fz/90, 4, 4)
	var h float64
	if cont < -.12 {
		h = SEA - 2 + (cont+.12)*90 + detail*4
	} else {
		land := math.Min(1, (cont+.12)/.5)
		h = SEA + 1 + land*14 + detail*(4+land*6)
		ridge := 1 - math.Abs(g.fbm2(fx/260, fz/260, 4, 5))
		m := math.Max(0, (cont-.1)/.35)
		if m > 1 {
			m = 1
		}
		m = m * m * (3 - 2*m)
		h += math.Pow(ridge, 2.2) * m * 62
		// gentle hills in plains
		h += math.Max(0, g.fbm2(fx/160, fz/160, 2, 6)) * 8 * (1 - m)
	}
	hi := int(h)
	if hi < 6 {
		hi = 6
	}
	if hi > CY-12 {
		hi = CY - 12
	}
	b := bPlains
	switch {
	case hi < SEA-1:
		b = bOcean
	case hi <= SEA+1 && cont < .05:
		b = bBeach
	case hi > 86:
		b = bMountain
	case temp < -.3:
		if moist > -.05 {
			b = bTaiga
		} else {
			b = bSnowPlains
		}
	case temp > .32 && moist < -.18:
		if g.fbm2(fx/400, fz/400, 2, 7) > .15 {
			b = bMesa
		} else {
			b = bDesert
		}
	case moist > .1 && temp > 0 && temp < .45 && g.fbm2(fx/300, fz/300, 2, 8) > .18:
		b = bCherry
	case moist > .12:
		if temp < .05 {
			b = bBirch
		} else {
			b = bForest
		}
	}
	return column{hi, b, temp, moist}
}

func (g *Gen) Height(x, z int) int  { return g.column(x, z).h }
func (g *Gen) BiomeAt(x, z int) int { return g.column(x, z).biome }

func (g *Gen) cave(x, y, z int, h int) bool {
	if y < 4 || y > h-1 {
		return false
	}
	// keep sea floors and shores sealed so caves don't swallow oceans
	if h <= SEA+3 && y > h-7 {
		return false
	}
	fx, fy, fz := float64(x), float64(y), float64(z)
	a := g.noise3(fx/34, fy/20, fz/34, 11)
	b := g.noise3(fx/34, fy/20, fz/34, 12)
	if math.Abs(a) < .075 && math.Abs(b) < .075 {
		return true
	}
	if y < 40 {
		ch := g.noise3(fx/60, fy/26, fz/60, 13)
		if ch > .52 {
			return true
		}
	}
	return false
}

func (g *Gen) stoneOrOre(x, y, z int) byte {
	fx, fy, fz := float64(x), float64(y), float64(z)
	n := g.noise3(fx/3.2, fy/3.2, fz/3.2, 21)
	r := g.unit(int64(x), int64(y), int64(z))
	if n > .55 {
		switch {
		case y < 16 && r < .25:
			return B("diamond_ore")
		case y < 22 && r < .35:
			return B("redstone_ore")
		case y < 30 && r < .45:
			return B("gold_ore")
		case y < 34 && r < .5:
			return B("lapis_ore")
		case y < 64 && r < .7:
			return B("iron_ore")
		case r < .82:
			return B("copper_ore")
		default:
			return B("coal_ore")
		}
	}
	if n < -.6 && y > 20 {
		return B("coal_ore")
	}
	if y < 60 && g.noise3(fx/3, fy/3, fz/3, 23) > .78 {
		return B("emerald_ore")
	}
	v := g.noise3(fx/24, fy/16, fz/24, 22)
	switch {
	case v > .5:
		return B("granite")
	case v < -.55:
		return B("diorite")
	case v > .38 && v < .42:
		return B("andesite")
	case y < 14 && g.noise3(fx/9, fy/9, fz/9, 24) > .62:
		return B("amethyst")
	}
	return B("stone")
}

type treeKind int

const (
	tOak treeKind = iota
	tBirch
	tSpruce
	tCherry
	tBigOak
	tCactus
)

// treeAt reports whether a tree trunk stands at column x,z.
func (g *Gen) treeAt(x, z int) (bool, treeKind, int) {
	cell := 5
	cx, cz := floorDiv(x, cell), floorDiv(z, cell)
	ox := int(g.unit(int64(cx), 77, int64(cz)) * float64(cell))
	oz := int(g.unit(int64(cx), 78, int64(cz)) * float64(cell))
	if cx*cell+ox != x || cz*cell+oz != z {
		return false, 0, 0
	}
	col := g.column(x, z)
	if col.h <= SEA {
		return false, 0, 0
	}
	r := g.unit(int64(x), 79, int64(z))
	dens := g.fbm2(float64(x)/120, float64(z)/120, 2, 30)
	switch col.biome {
	case bForest:
		if r < .7+dens*.3 {
			if g.unit(int64(x), 80, int64(z)) < .12 {
				return true, tBigOak, col.h
			}
			if g.unit(int64(x), 81, int64(z)) < .2 {
				return true, tBirch, col.h
			}
			return true, tOak, col.h
		}
	case bBirch:
		if r < .65 {
			return true, tBirch, col.h
		}
	case bTaiga, bSnowPlains:
		lim := .7
		if col.biome == bSnowPlains {
			lim = .12
		}
		if r < lim {
			return true, tSpruce, col.h
		}
	case bCherry:
		if r < .45 {
			return true, tCherry, col.h
		}
	case bPlains:
		if r < .05+math.Max(0, dens)*.25 {
			return true, tOak, col.h
		}
	case bMountain:
		if col.h < 98 && r < .15 {
			return true, tSpruce, col.h
		}
	case bDesert:
		if r < .18 {
			return true, tCactus, col.h
		}
	}
	return false, 0, 0
}

type pb struct {
	x, y, z int
	id      byte
	weak    bool // only replace air
}

func (g *Gen) treeBlocks(x, z int, k treeKind, h int, out []pb) []pb {
	r := func(i int64) float64 { return g.unit(int64(x), 200+i, int64(z)) }
	base := h + 1
	switch k {
	case tCactus:
		th := 1 + int(r(1)*3)
		for i := 0; i < th; i++ {
			out = append(out, pb{x, base + i, z, B("cactus"), true})
		}
	case tOak, tBirch, tCherry:
		log, leaf := B("log"), B("leaves")
		th := 4 + int(r(1)*3)
		if k == tBirch {
			log, leaf = B("birch_log"), B("birch_leaves")
			th++
		}
		if k == tCherry {
			log, leaf = B("cherry_log"), B("cherry_leaves")
		}
		top := base + th
		for dy := -3; dy <= 1; dy++ {
			rad := 2
			if dy >= 0 {
				rad = 1
			}
			if k == tCherry && dy <= -1 {
				rad = 3
			}
			for dx := -rad; dx <= rad; dx++ {
				for dz := -rad; dz <= rad; dz++ {
					if iabs(dx) == rad && iabs(dz) == rad && (dy == 1 || r(int64(dx*7+dz*13+dy*31+50)) < .5) {
						continue
					}
					out = append(out, pb{x + dx, top + dy, z + dz, leaf, true})
				}
			}
		}
		for i := 0; i < th; i++ {
			out = append(out, pb{x, base + i, z, log, false})
		}
	case tBigOak:
		log, leaf := B("log"), B("leaves")
		th := 7 + int(r(1)*4)
		top := base + th
		for dy := -4; dy <= 2; dy++ {
			rad := 4 - iabs(dy+1)/2
			for dx := -rad; dx <= rad; dx++ {
				for dz := -rad; dz <= rad; dz++ {
					d := dx*dx + dz*dz + (dy+1)*(dy+1)
					if d > rad*rad+2 || r(int64(dx*7+dz*13+dy*31+90)) < .12 {
						continue
					}
					out = append(out, pb{x + dx, top + dy, z + dz, leaf, true})
				}
			}
		}
		for i := 0; i < th; i++ {
			out = append(out, pb{x, base + i, z, log, false})
			if i == th-3 {
				out = append(out, pb{x + 1, base + i, z, log, false}, pb{x - 1, base + i + 1, z, log, false})
			}
		}
	case tSpruce:
		log, leaf := B("spruce_log"), B("spruce_leaves")
		th := 6 + int(r(1)*5)
		top := base + th
		for dy := 0; dy <= th-2; dy++ {
			y := top - dy
			rad := (dy + 1) / 2
			if rad > 3 {
				rad = 3
			}
			if dy%2 == 1 && dy > 2 {
				rad--
			}
			for dx := -rad; dx <= rad; dx++ {
				for dz := -rad; dz <= rad; dz++ {
					if iabs(dx)+iabs(dz) > rad+1 {
						continue
					}
					out = append(out, pb{x + dx, y, z + dz, leaf, true})
				}
			}
		}
		out = append(out, pb{x, top + 1, z, leaf, true})
		for i := 0; i < th; i++ {
			out = append(out, pb{x, base + i, z, log, false})
		}
	}
	return out
}

func (g *Gen) Generate(cx, cz int) *Chunk {
	c := &Chunk{cx: cx, cz: cz}
	ox, oz := cx*CX, cz*CZ
	var cols [CX][CZ]column
	for lx := 0; lx < CX; lx++ {
		for lz := 0; lz < CZ; lz++ {
			cols[lx][lz] = g.column(ox+lx, oz+lz)
		}
	}
	grass, dirt, sand, water := B("grass"), B("dirt"), B("sand"), B("water")
	for lx := 0; lx < CX; lx++ {
		for lz := 0; lz < CZ; lz++ {
			x, z := ox+lx, oz+lz
			col := cols[lx][lz]
			h := col.h
			top, fill := grass, dirt
			depth := 3 + int(g.unit(int64(x), 5, int64(z))*2)
			switch col.biome {
			case bOcean:
				top, fill = sand, sand
				if h < SEA-8 {
					if g.unit(int64(x), 6, int64(z)) < .5 {
						top = B("gravel")
					} else {
						top = B("clay")
					}
				}
			case bBeach, bDesert:
				top, fill = sand, sand
				depth = 5
			case bMesa:
				top, fill = B("red_sand"), B("terracotta")
				depth = 4
			case bTaiga:
				top = B("snow_grass")
				if g.unit(int64(x), 7, int64(z)) < .3 {
					top = B("podzol")
				}
			case bSnowPlains:
				top = B("snow_grass")
			case bMountain:
				top, fill = B("stone"), B("stone")
				if h > 100 {
					top, fill = B("snow"), B("snow")
				} else if h < 94 && g.noise2(float64(x)/9, float64(z)/9, 40) > .1 {
					top, fill = grass, dirt
				} else if g.unit(int64(x), 8, int64(z)) < .15 {
					top = B("gravel")
				}
			}
			for y := 0; y < CY; y++ {
				var id byte
				switch {
				case y == 0:
					id = B("bedrock")
				case y < 3 && g.unit(int64(x), int64(y), int64(z)) < .5:
					id = B("bedrock")
				case y < h-depth:
					id = g.stoneOrOre(x, y, z)
					if col.biome == bDesert && y > h-depth-4 {
						id = B("sandstone")
					}
					if col.biome == bMesa && y > h-14 {
						bands := []byte{B("terracotta"), B("terracotta_orange"), B("terracotta_white"), B("terracotta"), B("red_sand")}
						id = bands[((y%5)+5)%5]
					}
				case y < h:
					id = fill
				case y == h:
					id = top
					if h < SEA && col.biome != bOcean && col.biome != bBeach {
						id = dirt
						if col.biome == bDesert || col.biome == bMesa {
							id = sand
						}
					}
				case y <= SEA:
					id = water
					if y == SEA && (col.biome == bTaiga || col.biome == bSnowPlains || col.temp < -.42) {
						id = B("ice")
					}
				}
				if id != 0 && id != water && y <= h && g.cave(x, y, z, h) {
					if y < 11 {
						id = B("lava")
					} else {
						id = 0
					}
				}
				c.b[idx(lx, y, lz)] = id
			}
		}
	}
	// trees, including neighbours' crowns that hang into this chunk
	var buf []pb
	for x := ox - 4; x < ox+CX+4; x++ {
		for z := oz - 4; z < oz+CZ+4; z++ {
			ok, k, h := g.treeAt(x, z)
			if !ok {
				continue
			}
			// the trunk must stand on its own surface block (not carved away)
			if x >= ox && x < ox+CX && z >= oz && z < oz+CZ {
				gid := c.b[idx(x-ox, h, z-oz)]
				if gid == 0 || gid == water || Blocks[gid].Liquid {
					continue
				}
			}
			buf = g.treeBlocks(x, z, k, h, buf[:0])
			for _, p := range buf {
				lx, lz := p.x-ox, p.z-oz
				if lx < 0 || lx >= CX || lz < 0 || lz >= CZ || p.y < 1 || p.y >= CY {
					continue
				}
				i := idx(lx, p.y, lz)
				if p.weak && c.b[i] != 0 {
					continue
				}
				c.b[i] = p.id
			}
		}
	}
	g.decorate(c, &cols)
	return c
}

func (g *Gen) decorate(c *Chunk, cols *[CX][CZ]column) {
	ox, oz := c.cx*CX, c.cz*CZ
	for lx := 0; lx < CX; lx++ {
		for lz := 0; lz < CZ; lz++ {
			x, z := ox+lx, oz+lz
			col := cols[lx][lz]
			h := col.h
			if h+1 >= CY || h <= SEA {
				continue
			}
			ground := c.b[idx(lx, h, lz)]
			if c.b[idx(lx, h+1, lz)] != 0 {
				continue
			}
			r := g.unit(int64(x), 300, int64(z))
			fl := g.fbm2(float64(x)/40, float64(z)/40, 2, 301)
			put := func(id byte) { c.b[idx(lx, h+1, lz)] = id }
			isGrass := ground == B("grass")
			switch {
			case isGrass && nearWater(c, lx, h, lz) && r < .25:
				th := 1 + int(g.unit(int64(x), 302, int64(z))*3)
				for i := 1; i <= th && h+i < CY; i++ {
					c.b[idx(lx, h+i, lz)] = B("sugar_cane")
				}
			case isGrass && col.biome == bPlains && r < .22:
				put(B("tall_grass"))
			case isGrass && fl > .35 && r < .35:
				fls := []string{"flower_red", "flower_yellow", "flower_blue", "flower_white", "flower_pink"}
				put(B(fls[int(g.unit(int64(x/8), 303, int64(z/8))*5)]))
			case isGrass && (col.biome == bForest || col.biome == bBirch) && r < .12:
				put(B("fern"))
			case isGrass && r < .1:
				put(B("tall_grass"))
			case isGrass && col.biome == bCherry && r < .2:
				put(B("flower_pink"))
			case (col.biome == bForest || col.biome == bTaiga) && r > .993:
				if g.unit(int64(x), 304, int64(z)) < .5 {
					put(B("mushroom_red"))
				} else {
					put(B("mushroom_brown"))
				}
			case isGrass && r > .997:
				put(B("pumpkin"))
			case isGrass && col.biome == bForest && r > .994:
				put(B("melon"))
			case (col.biome == bDesert || col.biome == bMesa) && r < .02:
				put(B("dead_bush"))
			case col.biome == bTaiga && ground == B("snow_grass") && r < .08:
				put(B("fern"))
			}
		}
	}
}

func nearWater(c *Chunk, lx, y, lz int) bool {
	w := B("water")
	for _, d := range [][2]int{{1, 0}, {-1, 0}, {0, 1}, {0, -1}} {
		x, z := lx+d[0], lz+d[1]
		if x < 0 || z < 0 || x >= CX || z >= CZ {
			continue
		}
		if c.b[idx(x, y, z)] == w {
			return true
		}
	}
	return false
}

// Spawn finds a dry, grassy place near the origin.
func (g *Gen) Spawn() (int, int, int) {
	for r := 0; r < 4000; r += 16 {
		for a := 0; a < 16; a++ {
			x := int(float64(r) * math.Cos(float64(a)*math.Pi/8))
			z := int(float64(r) * math.Sin(float64(a)*math.Pi/8))
			col := g.column(x, z)
			if col.h > SEA+1 && col.h < 80 && col.biome != bOcean && col.biome != bBeach {
				return x, col.h + 1, z
			}
		}
	}
	return 0, 80, 0
}

func floorDiv(a, b int) int {
	q := a / b
	if (a%b != 0) && ((a < 0) != (b < 0)) {
		q--
	}
	return q
}
func floorMod(a, b int) int { return a - floorDiv(a, b)*b }
func iabs(a int) int {
	if a < 0 {
		return -a
	}
	return a
}
func idx(x, y, z int) int { return (y*CZ+z)*CX + x }
