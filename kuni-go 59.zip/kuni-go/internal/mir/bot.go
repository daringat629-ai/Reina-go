package mir

import (
	"fmt"
	"math"
	"math/rand"
	"strings"
	"time"
)

type botMode int

const (
	mWander botMode = iota
	mFollow
	mGoto
	mBuild
	mDance
)

type Bot struct {
	s        *Server
	p        *Player
	r        *rand.Rand
	mode     botMode
	follow   string
	tx, tz   float64
	plan     *plan
	queue    []pb
	ox, oy   int
	oz       int
	placeAcc float64
	idleFor  float64
	nextAuto float64
	danceT   float64
	forName  string
	built    int
}

func newBot(s *Server) *Bot {
	sp := s.w.spawn
	p := &Player{id: 0, name: "Рейна", bot: true, x: float64(sp[0]) + 2.5, z: float64(sp[2]) + 2.5, color: 310, view: 2}
	p.y = float64(sp[1])
	return &Bot{s: s, p: p, r: rand.New(rand.NewSource(time.Now().UnixNano())), nextAuto: 60}
}

var greetings = []string{"Привет, %s! Рада тебя видеть ✨", "О, %s пришёл! Давай что-нибудь построим?", "%s, привет! Я как раз гуляю.", "Хэй, %s! Напиши /help, если что-то нужно."}
var welcomeBack = []string{"С возвращением, %s! Я тут кое-что построила, пока тебя не было.", "%s, ты вернулся! Скучала 💖"}
var jokes = []string{
	"Почему крипер не ходит на вечеринки? Он всё взрывает 💥",
	"Мой любимый блок — стекло. Через него всё видно, но ничего не понятно.",
	"Я хотела построить лестницу в небо, но доски кончились на облаке.",
	"Сколько блоков нужно, чтобы построить дом? Все, что я найду!",
	"Почему кактус одинокий? Его никто не обнимает 🌵",
}
var smalltalk = []string{"Ага!", "Интересно…", "Здорово!", "Я тебя слышу 🙂", "Хи-хи", "Давай построим что-нибудь большое?", "Обожаю этот мир.", "Смотри, какое небо!"}

func (b *Bot) sayLater(d time.Duration, text string) {
	time.Sleep(d)
	b.s.mu.Lock()
	b.s.sayL(b.p.name, text)
	b.s.mu.Unlock()
}

func (b *Bot) greet(name string, lastSeen int64) {
	b.s.mu.Lock()
	var t string
	if lastSeen > 0 && time.Since(time.Unix(lastSeen, 0)) > 10*time.Minute {
		t = fmt.Sprintf(welcomeBack[b.r.Intn(len(welcomeBack))], name)
	} else if lastSeen == 0 {
		t = fmt.Sprintf(greetings[b.r.Intn(len(greetings))], name)
	}
	b.s.mu.Unlock()
	if t != "" {
		b.sayLater(1500*time.Millisecond, t)
	}
}

func has(s string, subs ...string) bool {
	for _, x := range subs {
		if strings.Contains(s, x) {
			return true
		}
	}
	return false
}

// hear reacts to normal chat.
func (b *Bot) hear(name, text string) {
	t := strings.ToLower(text)
	b.s.mu.Lock()
	alone := len(b.s.players) <= 1
	b.s.mu.Unlock()
	addressed := has(t, "рейн", "rein", "rayn")
	if !addressed && !alone {
		return
	}
	b.request(name, t)
}

func (b *Bot) request(name, t string) {
	t = strings.ToLower(t)
	time.Sleep(time.Duration(600+b.r.Intn(900)) * time.Millisecond)
	s := b.s
	s.mu.Lock()
	defer s.mu.Unlock()
	say := func(f string, a ...any) { s.sayL(b.p.name, fmt.Sprintf(f, a...)) }
	who := s.findPlayerL(name)
	switch {
	case has(t, "построй", "построить", "строй", "build", "сделай"):
		var mk func(*rand.Rand) plan
		for k, f := range blueprints {
			if strings.Contains(t, k) {
				mk = f
				break
			}
		}
		if who == nil {
			return
		}
		var pl plan
		if mk != nil {
			pl = mk(b.r)
		} else {
			pl = autoPlan(b.r, s.w.gen.BiomeAt(int(who.x), int(who.z)))
		}
		if b.startBuildNearL(pl, who.x, who.z, who.yaw, name) {
			say("Хорошо, %s! Строю %s прямо перед тобой 🔨", name, pl.name)
		} else {
			say("Тут неровно, %s… Отойди на место поровнее, и я построю.", name)
		}
	case has(t, "иди сюда", "ко мне", "приди", "подойди", "come", "сюда"):
		if who != nil {
			b.mode, b.tx, b.tz = mGoto, who.x+1, who.z+1
			say("Бегу, %s!", name)
		}
	case has(t, "за мной", "следуй", "follow", "пошли", "пойдём", "идём"):
		b.mode, b.follow = mFollow, name
		say("Иду за тобой, %s 👣", name)
	case has(t, "гуляй", "стой", "отстань", "stay", "свобод", "хватит", "стоп"):
		if b.mode == mBuild {
			b.queue = nil
			b.plan = nil
			say("Ладно, бросаю стройку.")
		} else {
			say("Хорошо, пойду погуляю.")
		}
		b.mode = mWander
	case has(t, "танцу", "dance", "потанцуй"):
		b.mode, b.danceT = mDance, 6
		say("💃 Ля-ля-ля!")
	case has(t, "что строишь", "что делаешь", "чем занята"):
		if b.mode == mBuild && b.plan != nil {
			say("Строю %s, осталось %d блоков.", b.plan.name, len(b.queue))
		} else {
			say("Гуляю и смотрю, где бы что-нибудь построить.")
		}
	case has(t, "анекдот", "шутк", "пошути", "смешн"):
		say(jokes[b.r.Intn(len(jokes))])
	case has(t, "кто ты", "ты кто", "расскажи о себе"):
		say("Я Рейна! Живу в этом мире, гуляю и строю. Попроси: «Рейна, построй замок».")
	case has(t, "как дела", "как ты"):
		say([]string{"Отлично! Уже %d построек в этом мире.", "Прекрасно, у меня %d построек и куча идей!"}[b.r.Intn(2)], s.w.meta.Builds)
	case has(t, "привет", "здравств", "хай", "hello", "hi ", "салам", "добрый"):
		say("Привет, %s! 👋", name)
	case has(t, "спасиб", "thanks", "круто", "класс", "красив"):
		say([]string{"Пожалуйста! 💖", "Рада, что нравится!", "Обращайся 😊"}[b.r.Intn(3)])
	case has(t, "пока", "до свидан", "bye"):
		say("Пока, %s! Возвращайся скорее.", name)
	case has(t, "люблю", "нравишься"):
		say("Ой 🥰 Ты тоже классный!")
	case has(t, "помог", "help", "умеешь"):
		say("Я умею строить: дом, башню, пирамиду, замок, маяк, фонтан, сад, мельницу, иглу, мост, статую, храм, дерево. Ещё могу ходить за тобой и танцевать!")
	default:
		say(smalltalk[b.r.Intn(len(smalltalk))])
	}
}

// startBuildNearL finds a level spot a few blocks in front of x,z (looking along yaw).
func (b *Bot) startBuildNearL(pl plan, x, z, yaw float64, forName string) bool {
	fx, fz := -math.Sin(yaw), -math.Cos(yaw)
	for _, dist := range []float64{6, 9, 13, 18, 24} {
		for _, side := range []float64{0, -8, 8} {
			cx := x + fx*(dist+float64(pl.w)/2) + fz*side
			cz := z + fz*(dist+float64(pl.d)/2) - fx*side
			ox, oz := int(math.Floor(cx))-pl.w/2, int(math.Floor(cz))-pl.d/2
			if y, ok := b.siteOK(pl, ox, oz); ok {
				b.beginL(pl, ox, y, oz, forName)
				return true
			}
		}
	}
	return false
}

func (b *Bot) siteOK(pl plan, ox, oz int) (int, bool) {
	w := b.s.w
	minY, maxY, water := 999, -1, 0
	var hs []int
	for x := -2; x < pl.w+2; x += 2 {
		for z := -2; z < pl.d+2; z += 2 {
			id, y := w.SurfaceAt(ox+x, oz+z)
			// ignore leaves/logs of trees: look for real ground
			for y > 1 && (Blocks[id].Trans && !Blocks[id].Liquid || strings.Contains(Blocks[id].Name, "log") || strings.Contains(Blocks[id].Name, "leaves") || Blocks[id].Cross) {
				y--
				id = w.Block(ox+x, y, oz+z)
			}
			if Blocks[id].Liquid {
				water++
			} else if !natural[Blocks[id].Name] {
				return 0, false // someone already built here
			}
			hs = append(hs, y)
			if y < minY {
				minY = y
			}
			if y > maxY {
				maxY = y
			}
		}
	}
	if water > len(hs)/4 && pl.name != "мостик" && pl.name != "маяк" {
		return 0, false
	}
	if maxY-minY > 5 || maxY+30 >= CY {
		return 0, false
	}
	// median
	sum := 0
	for _, h := range hs {
		sum += h
	}
	return sum/len(hs) + 1, true
}

func (b *Bot) beginL(pl plan, ox, oy, oz int, forName string) {
	w := b.s.w
	maxY := 0
	in := map[[3]int]bool{}
	for _, p := range pl.blocks {
		if p.y > maxY {
			maxY = p.y
		}
		in[[3]int{p.x, p.y, p.z}] = true
	}
	var q []pb
	// level the ground: fill dips under the footprint, clear the space above
	for x := -1; x <= pl.w; x++ {
		for z := -1; z <= pl.d; z++ {
			for y := -5; y < 0; y++ {
				if in[[3]int{x, y, z}] {
					continue
				}
				id := w.Block(ox+x, oy+y, oz+z)
				if !isSolid(id) {
					fill := B("dirt")
					if y == -1 {
						fill = B("grass")
					}
					q = append(q, pb{ox + x, oy + y, oz + z, fill, false})
				}
			}
			for y := 0; y <= maxY+2; y++ {
				if in[[3]int{x, y, z}] {
					continue
				}
				if w.Block(ox+x, oy+y, oz+z) != 0 {
					q = append(q, pb{ox + x, oy + y, oz + z, 0, false})
				}
			}
		}
	}
	for _, p := range pl.blocks {
		q = append(q, pb{ox + p.x, oy + p.y, oz + p.z, p.id, false})
	}
	b.plan = &pl
	b.queue = q
	b.ox, b.oy, b.oz = ox, oy, oz
	b.mode = mBuild
	b.forName = forName
}

func (b *Bot) moveToward(tx, tz, speed, dt float64) bool {
	p := b.p
	dx, dz := tx-p.x, tz-p.z
	d := math.Hypot(dx, dz)
	if d < .6 {
		return true
	}
	if d > 60 {
		speed *= 4
	}
	st := math.Min(d, speed*dt)
	nx, nz := p.x+dx/d*st, p.z+dz/d*st
	gy := float64(b.s.w.Ground(int(math.Floor(nx)), int(math.Floor(nz))))
	// she can hop up to 2 blocks; higher walls she simply climbs over (it's her world)
	p.x, p.z = nx, nz
	p.y += (gy - p.y) * math.Min(1, dt*10)
	if math.Abs(gy-p.y) > 3 {
		p.y = gy
	}
	p.yaw = math.Atan2(-dx, -dz)
	return false
}

func (b *Bot) step(dt float64) {
	s := b.s
	s.mu.Lock()
	defer s.mu.Unlock()
	b.p.anim = 0
	b.defendL(dt)
	switch b.mode {
	case mWander:
		b.idleFor += dt
		if b.moveToward(b.tx, b.tz, 2.6, dt) || b.idleFor > 14 {
			b.idleFor = 0
			ang := b.r.Float64() * math.Pi * 2
			cx, cz := b.p.x, b.p.z
			// stay around people
			var near *Player
			best := math.Inf(1)
			for _, o := range s.players {
				d := math.Hypot(o.x-cx, o.z-cz)
				if d < best {
					best, near = d, o
				}
			}
			if near != nil && best > 30 {
				cx, cz = near.x, near.z
			}
			r := 6 + b.r.Float64()*12
			b.tx, b.tz = cx+math.Cos(ang)*r, cz+math.Sin(ang)*r
		} else {
			b.p.anim = 1
		}
		b.nextAuto -= dt
		if b.nextAuto <= 0 && len(s.players) > 0 && !s.autoOff {
			b.nextAuto = 90 + b.r.Float64()*120
			biome := s.w.gen.BiomeAt(int(b.p.x), int(b.p.z))
			pl := autoPlan(b.r, biome)
			if b.startBuildNearL(pl, b.p.x, b.p.z, b.r.Float64()*6.28, "") {
				s.sayL(b.p.name, fmt.Sprintf("Придумала! Строю %s у координат %d, %d — приходите смотреть ✨", pl.name, b.ox, b.oz))
			}
		}
	case mGoto:
		if b.moveToward(b.tx, b.tz, 6, dt) {
			b.mode = mWander
			b.tx, b.tz = b.p.x, b.p.z
		} else {
			b.p.anim = 1
		}
	case mFollow:
		o := s.findPlayerL(b.follow)
		if o == nil || o.bot {
			b.mode = mWander
			break
		}
		if math.Hypot(o.x-b.p.x, o.z-b.p.z) > 3 {
			b.moveToward(o.x, o.z, 5.5, dt)
			b.p.anim = 1
		} else {
			b.p.yaw = math.Atan2(-(o.x - b.p.x), -(o.z - b.p.z))
		}
	case mDance:
		b.danceT -= dt
		b.p.yaw += dt * 6
		b.p.anim = 2
		if b.danceT <= 0 {
			b.mode = mWander
		}
	case mBuild:
		if len(b.queue) == 0 {
			s.w.meta.Builds++
			b.built++
			if b.forName != "" {
				s.sayL(b.p.name, fmt.Sprintf("Готово, %s! Как тебе %s? 💖", b.forName, b.plan.name))
			} else {
				s.sayL(b.p.name, "Готово! Это моя постройка №"+fmt.Sprint(s.w.meta.Builds)+" 💖")
			}
			b.mode, b.plan = mWander, nil
			b.tx, b.tz = b.p.x+3, b.p.z+3
			break
		}
		next := b.queue[0]
		// walk next to the block she places
		if math.Hypot(float64(next.x)+.5-b.p.x, float64(next.z)+.5-b.p.z) > 7 {
			b.moveToward(float64(next.x)+.5, float64(next.z)-1.5, 7, dt)
			b.p.anim = 1
			break
		}
		b.p.anim = 3
		b.placeAcc += dt
		rate := 0.05
		for b.placeAcc > rate && len(b.queue) > 0 {
			b.placeAcc -= rate
			n := b.queue[0]
			b.queue = b.queue[1:]
			s.setL(n.x, n.y, n.z, n.id)
			b.p.yaw = math.Atan2(-(float64(n.x) + .5 - b.p.x), -(float64(n.z) + .5 - b.p.z))
			if n.id == 0 {
				b.placeAcc += rate * .8 // clearing is quick
				continue
			}
			if math.Hypot(float64(n.x)+.5-b.p.x, float64(n.z)+.5-b.p.z) > 7 {
				break
			}
		}
	}
}

var natural = map[string]bool{}

func init() {
	for _, n := range []string{"grass", "dirt", "stone", "sand", "gravel", "snow", "snow_grass", "sandstone", "red_sand", "terracotta", "terracotta_orange", "terracotta_white", "clay", "podzol", "moss", "ice", "packed_ice", "granite", "diorite", "andesite", "bedrock", "coal_ore", "iron_ore", "copper_ore", "gold_ore", "lapis_ore", "emerald_ore", "redstone_ore", "diamond_ore", "amethyst", "obsidian"} {
		natural[n] = true
	}
}
