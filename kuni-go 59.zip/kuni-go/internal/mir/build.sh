#!/bin/sh
# assembles index.html from client/ (run after changing the client files)
set -e
cd "$(dirname "$0")"
python3 - <<'P'
s=open('client/index.src.html').read()
s=s.replace('/*WORKER*/',open('client/worker.js').read()).replace('/*TEXTURES*/',open('client/textures.js').read()).replace('/*GAME*/',open('client/game.js').read()).replace('/*ITEMTEX*/',open('client/itemtex.js').read()).replace('/*SURVIVAL*/',open('client/survival.js').read())
open('index.html','w').write(s)
P
