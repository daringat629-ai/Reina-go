package mir

// Non-block items live at ids >= 256. Block items use the block id.

type Item struct {
	ID    int     `json:"id"`
	Name  string  `json:"name"`
	Label string  `json:"label"`
	Stack int     `json:"stack"`
	Food  int     `json:"food,omitempty"`
	Sat   float64 `json:"sat,omitempty"`
	Tool  string  `json:"tool,omitempty"`
	Tier  int     `json:"tier,omitempty"`
	Dur   int     `json:"dur,omitempty"`
	Dmg   float64 `json:"dmg,omitempty"`
	Slot  int     `json:"slot,omitempty"` // armour: 1 head .. 4 feet
	Def   int     `json:"def,omitempty"`
}

var Items []Item
var itemByName = map[string]int{}

const ItemBase = 256

func addItem(it Item) {
	it.ID = ItemBase + len(Items)
	if it.Stack == 0 {
		it.Stack = 64
	}
	Items = append(Items, it)
	itemByName[it.Name] = it.ID
}

// IT returns an item id by name: block names give block ids.
func IT(name string) int {
	if id, ok := itemByName[name]; ok {
		return id
	}
	if id, ok := byName[name]; ok {
		return id
	}
	return 0
}

func init() {
	for _, s := range [][2]string{{"stick", "Палка"}, {"coal", "Уголь"}, {"charcoal", "Древесный уголь"}, {"iron_ingot", "Железный слиток"}, {"gold_ingot", "Золотой слиток"}, {"copper_ingot", "Медный слиток"},
		{"diamond", "Алмаз"}, {"emerald", "Изумруд"}, {"redstone", "Красная пыль"}, {"lapis", "Лазурит"}, {"wheat", "Пшеница"}, {"seeds", "Семена"},
		{"bone", "Кость"}, {"bone_meal", "Костная мука"}, {"string", "Нить"}, {"gunpowder", "Порох"}, {"leather", "Кожа"}, {"feather", "Перо"}, {"flint", "Кремень"}} {
		addItem(Item{Name: s[0], Label: s[1]})
	}
	food := func(n, l string, f int, sat float64) { addItem(Item{Name: n, Label: l, Food: f, Sat: sat}) }
	food("apple", "Яблоко", 4, 2.4)
	food("bread", "Хлеб", 5, 6)
	food("porkchop", "Сырая свинина", 3, 1.8)
	food("cooked_porkchop", "Жареная свинина", 8, 12.8)
	food("beef", "Сырая говядина", 3, 1.8)
	food("steak", "Стейк", 8, 12.8)
	food("chicken", "Сырая курица", 2, 1.2)
	food("cooked_chicken", "Жареная курица", 6, 7.2)
	food("mutton", "Сырая баранина", 2, 1.2)
	food("cooked_mutton", "Жареная баранина", 6, 9.6)
	food("rotten_flesh", "Гнилая плоть", 4, .8)
	food("golden_apple", "Золотое яблоко", 4, 9.6)
	food("mushroom_stew", "Грибной суп", 6, 7.2)
	mats := []struct {
		n, l string
		tier int
		dur  int
	}{{"wood", "Деревянн", 1, 60}, {"stone", "Каменн", 2, 132}, {"iron", "Железн", 3, 251}, {"diamond", "Алмазн", 4, 1562}}
	for _, m := range mats {
		addItem(Item{Name: m.n + "_pickaxe", Label: m.l + "ая кирка", Stack: 1, Tool: "pickaxe", Tier: m.tier, Dur: m.dur, Dmg: float64(m.tier) + 1})
		addItem(Item{Name: m.n + "_axe", Label: m.l + "ый топор", Stack: 1, Tool: "axe", Tier: m.tier, Dur: m.dur, Dmg: float64(m.tier) + 3})
		addItem(Item{Name: m.n + "_shovel", Label: m.l + "ая лопата", Stack: 1, Tool: "shovel", Tier: m.tier, Dur: m.dur, Dmg: float64(m.tier) + .5})
		addItem(Item{Name: m.n + "_sword", Label: m.l + "ый меч", Stack: 1, Tool: "sword", Tier: m.tier, Dur: m.dur, Dmg: float64(m.tier) + 3})
		addItem(Item{Name: m.n + "_hoe", Label: m.l + "ая мотыга", Stack: 1, Tool: "hoe", Tier: m.tier, Dur: m.dur, Dmg: 1})
	}
	arm := []struct {
		n, l string
		def  [4]int
		dur  int
	}{{"leather", "Кожан", [4]int{1, 3, 2, 1}, 60}, {"iron", "Железн", [4]int{2, 6, 5, 2}, 200}, {"diamond", "Алмазн", [4]int{3, 8, 6, 3}, 450}}
	for _, a := range arm {
		addItem(Item{Name: a.n + "_helmet", Label: a.l + "ый шлем", Stack: 1, Slot: 1, Def: a.def[0], Dur: a.dur})
		addItem(Item{Name: a.n + "_chestplate", Label: a.l + "ый нагрудник", Stack: 1, Slot: 2, Def: a.def[1], Dur: a.dur})
		addItem(Item{Name: a.n + "_leggings", Label: a.l + "ые поножи", Stack: 1, Slot: 3, Def: a.def[2], Dur: a.dur})
		addItem(Item{Name: a.n + "_boots", Label: a.l + "ые ботинки", Stack: 1, Slot: 4, Def: a.def[3], Dur: a.dur})
	}
}

func itemStack(id int) int {
	if id >= ItemBase && id-ItemBase < len(Items) {
		return Items[id-ItemBase].Stack
	}
	return 64
}

func validItem(id int) bool {
	return (id > 0 && id < len(Blocks)) || (id >= ItemBase && id-ItemBase < len(Items))
}
