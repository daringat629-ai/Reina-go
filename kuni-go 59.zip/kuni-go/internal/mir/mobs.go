package mir

import (
	"fmt"
	"math"
	"math/rand"
	"time"
)

const (
	kPig = iota
	kSheep
	kChicken
	kCow
	kZombie
	kSkeleton
	kCreeper
	kSpider
)

var mobHP = []float64{10, 8, 4, 10, 20, 20, 20, 16}
var mobNames = []string{"Свинья", "Овца", "Курица", "Корова", "Зомби", "Скелет", "Крипер", "Паук"}

type Mob struct {
	id       int
	kind     int
	x, y, z  float64
	vx, vy   float64
	vz       float64
	yaw      float64
	tx, tz   float64
	wait     float64
	color    int
	moving   bool
	hp       float64
	hurt     float64
	cd       float64
	fuse     float64
	flee     float64
	target   *Player
	onGround bool
}

func (m *Mob) hostile() bool { return m.kind >= kZombie }
func (m *Mob) height() float64 {
	switch m.kind {
	case kChicken:
		return .7
	case kSpider:
		return .9
	case kPig, kSheep:
		return 1
	case kCow:
		return 1.4
	}
	return 1.9
}

type Mobs struct {
	s    *Server
	r    *rand.Rand
	list []*Mob
	next int
	acc  float64
}

func newMobs(s *Server) *Mobs {
	return &Mobs{s: s, r: rand.New(rand.NewSource(time.Now().UnixNano() + 7)), next: 1}
}

func (m *Mobs) snapshotL() [][]float64 {
	out := make([][]float64, 0, len(m.list))
	r := func(v float64) float64 { return math.Round(v*100) / 100 }
	b := func(c bool) float64 {
		if c {
			return 1
		}
		return 0
	}
	for _, o := range m.list {
		out = append(out, []float64{float64(o.id), float64(o.kind), r(o.x), r(o.y), r(o.z), r(o.yaw), float64(o.color), b(o.moving), b(o.hurt > 0), r(o.fuse)})
	}
	return out
}

func (s *Server) solidAt(x, y, z float64) bool {
	id := s.w.Block(int(math.Floor(x)), int(math.Floor(y)), int(math.Floor(z)))
	return isSolid(id)
}

func (s *Server) isNight() bool { return s.w.meta.Time > .52 && s.w.meta.Time < .98 }

// skyOpen: nothing solid above this point.
func (s *Server) skyOpen(x, y, z int) bool {
	for yy := y; yy < CY; yy++ {
		id := s.w.Block(x, yy, z)
		if isSolid(id) && !Blocks[id].Trans {
			return false
		}
	}
	return true
}

func (s *Server) nearLight(x, y, z, r int) bool {
	for dx := -r; dx <= r; dx += 1 {
		for dz := -r; dz <= r; dz += 1 {
			for dy := -2; dy <= 3; dy++ {
				if Blocks[s.w.Block(x+dx, y+dy, z+dz)].Light > 0 {
					return true
				}
			}
		}
	}
	return false
}

func (m *Mobs) spawnAnimalsL() {
	s := m.s
	animals, hostiles, surv := 0, 0, 0
	for _, o := range m.list {
		if o.hostile() {
			hostiles++
		} else {
			animals++
		}
	}
	for _, p := range s.players {
		if p.mode == "survival" && p.alive {
			surv++
		}
	}
	limit := 8 * len(s.players)
	if limit > 32 {
		limit = 32
	}
	for _, p := range s.players {
		if animals >= limit {
			break
		}
		ang := m.r.Float64() * math.Pi * 2
		d := 20 + m.r.Float64()*30
		x, z := int(p.x+math.Cos(ang)*d), int(p.z+math.Sin(ang)*d)
		id, y := s.w.SurfaceAt(x, z)
		if id != B("grass") && id != B("snow_grass") {
			continue
		}
		k := m.r.Intn(4)
		if id == B("snow_grass") {
			k = kSheep
		}
		n := 1 + m.r.Intn(3)
		for i := 0; i < n && animals < limit; i++ {
			mx, mz := float64(x)+.5+float64(i), float64(z)+.5
			col := 0
			if k == kSheep {
				cols := []int{0, 0, 0, 0, 1, 2, 3, 4, 15}
				col = cols[m.r.Intn(len(cols))]
			}
			m.add(k, mx, float64(y+1), mz, col)
			animals++
		}
		break
	}
	// monsters: only when someone plays survival
	if surv == 0 {
		return
	}
	hlimit := 7 * surv
	if hlimit > 28 {
		hlimit = 28
	}
	for _, p := range s.players {
		if p.mode != "survival" || !p.alive || hostiles >= hlimit {
			continue
		}
		for try := 0; try < 4; try++ {
			ang := m.r.Float64() * math.Pi * 2
			d := 16 + m.r.Float64()*24
			x, z := int(math.Floor(p.x+math.Cos(ang)*d)), int(math.Floor(p.z+math.Sin(ang)*d))
			var y int
			cave := m.r.Intn(2) == 0
			if cave {
				y = int(p.y) + m.r.Intn(16) - 10
				if y < 3 || y > CY-4 {
					continue
				}
				if !isSolid(s.w.Block(x, y-1, z)) || isSolid(s.w.Block(x, y, z)) || isSolid(s.w.Block(x, y+1, z)) || Blocks[s.w.Block(x, y, z)].Liquid {
					continue
				}
				if s.skyOpen(x, y, z) && !s.isNight() {
					continue
				}
			} else {
				if !s.isNight() {
					continue
				}
				top, ty := s.w.SurfaceAt(x, z)
				if Blocks[top].Liquid || top == B("leaves") {
					continue
				}
				y = ty + 1
			}
			if s.nearLight(x, y, z, 5) {
				continue
			}
			k := kZombie + m.r.Intn(4)
			m.add(k, float64(x)+.5, float64(y), float64(z)+.5, 0)
			hostiles++
			break
		}
	}
}

func (m *Mobs) add(kind int, x, y, z float64, col int) *Mob {
	o := &Mob{id: m.next, kind: kind, x: x, y: y, z: z, tx: x, tz: z, color: col, wait: m.r.Float64() * 3, hp: mobHP[kind]}
	m.next++
	m.list = append(m.list, o)
	return o
}

// moveMob walks a mob with simple block collisions; returns whether it got blocked.
func (m *Mobs) moveMob(o *Mob, dx, dz, dt float64) bool {
	s := m.s
	h := o.height()
	free := func(x, y, z float64) bool {
		for yy := 0.0; yy < h; yy += 1 {
			if s.solidAt(x, y+yy+.05, z) {
				return false
			}
		}
		return true
	}
	blocked := false
	nx, nz := o.x+dx, o.z+dz
	r := .3
	px, pz := nx+math.Copysign(r, dx), nz+math.Copysign(r, dz)
	if dx != 0 && !free(px, o.y, o.z) {
		if o.onGround && free(px, o.y+1, o.z) && free(o.x, o.y+1, o.z) || o.kind == kSpider {
			o.vy = 7.2
			if o.kind == kSpider {
				o.vy = 4
			}
		}
		blocked = true
		nx = o.x
	}
	if dz != 0 && !free(nx, o.y, pz) {
		if o.onGround && free(nx, o.y+1, pz) && free(nx, o.y+1, o.z) || o.kind == kSpider {
			o.vy = 7.2
			if o.kind == kSpider {
				o.vy = 4
			}
		}
		blocked = true
		nz = o.z
	}
	o.x, o.z = nx, nz
	// gravity
	o.vy -= 26 * dt
	if o.vy < -30 {
		o.vy = -30
	}
	ny := o.y + o.vy*dt
	o.onGround = false
	if o.vy <= 0 && s.solidAt(o.x, ny, o.z) {
		o.y = math.Floor(ny) + 1
		o.vy = 0
		o.onGround = true
	} else if o.vy > 0 && s.solidAt(o.x, ny+h, o.z) {
		o.vy = 0
	} else {
		o.y = ny
	}
	if Blocks[s.w.Block(int(math.Floor(o.x)), int(math.Floor(o.y+.2)), int(math.Floor(o.z)))].Liquid {
		o.vy = math.Max(o.vy, 2) // swim up
		o.onGround = true
	}
	return blocked
}

func (m *Mobs) step(dt float64) {
	s := m.s
	s.mu.Lock()
	defer s.mu.Unlock()
	if len(s.players) == 0 {
		return
	}
	m.acc += dt
	if m.acc > 2 {
		m.acc = 0
		keep := m.list[:0]
		for _, o := range m.list {
			best := math.Inf(1)
			for _, p := range s.players {
				best = math.Min(best, math.Hypot(p.x-o.x, p.z-o.z))
			}
			lim := 90.0
			if o.hostile() {
				lim = 64
			}
			if best < lim && o.y > -10 {
				keep = append(keep, o)
			}
		}
		m.list = keep
		m.spawnAnimalsL()
	}
	day := !s.isNight()
	keep := m.list[:0]
	for _, o := range m.list {
		if o.hurt > 0 {
			o.hurt -= dt
		}
		if o.cd > 0 {
			o.cd -= dt
		}
		// zombies and skeletons burn in the sun
		if day && (o.kind == kZombie || o.kind == kSkeleton) && s.skyOpen(int(math.Floor(o.x)), int(math.Floor(o.y+1.8)), int(math.Floor(o.z))) {
			o.hp -= dt * 1.5
			o.hurt = .1
		}
		if o.hp <= 0 {
			m.dieL(o, nil)
			continue
		}
		keep = append(keep, o)
		o.moving = false
		// knockback
		if math.Abs(o.vx)+math.Abs(o.vz) > .05 {
			m.moveMob(o, o.vx*dt, o.vz*dt, dt)
			o.vx *= math.Max(0, 1-dt*6)
			o.vz *= math.Max(0, 1-dt*6)
			continue
		}
		if o.hostile() {
			m.hostileStep(o, dt)
			continue
		}
		if o.flee > 0 {
			o.flee -= dt
		}
		if o.wait > 0 && o.flee <= 0 {
			o.wait -= dt
			m.moveMob(o, 0, 0, dt)
			continue
		}
		dx, dz := o.tx-o.x, o.tz-o.z
		d := math.Hypot(dx, dz)
		if d < .3 {
			o.wait = 2 + m.r.Float64()*6
			if o.flee > 0 {
				o.wait = 0
			}
			a := m.r.Float64() * math.Pi * 2
			r := 2 + m.r.Float64()*6
			o.tx, o.tz = o.x+math.Cos(a)*r, o.z+math.Sin(a)*r
			continue
		}
		sp := 1.1
		if o.kind == kChicken {
			sp = 1.4
		}
		if o.flee > 0 {
			sp *= 3
		}
		st := math.Min(d, sp*dt)
		// animals avoid cliffs and water
		nx, nz := o.x+dx/d*st*3, o.z+dz/d*st*3
		gy := float64(s.w.Ground(int(math.Floor(nx)), int(math.Floor(nz))))
		ground := s.w.Block(int(math.Floor(nx)), int(gy)-1, int(math.Floor(nz)))
		if o.y-gy > 3 || Blocks[ground].Liquid {
			o.tx, o.tz = o.x, o.z
			continue
		}
		if m.moveMob(o, dx/d*st, dz/d*st, dt) && !o.onGround {
			o.tx, o.tz = o.x, o.z
		}
		o.yaw = math.Atan2(-dx, -dz)
		o.moving = true
	}
	m.list = keep
}

func (m *Mobs) hostileStep(o *Mob, dt float64) {
	s := m.s
	// pick the closest living survival player
	var tgt *Player
	best := 20.0
	if o.kind == kSpider && !s.isNight() {
		best = 6 // spiders are calm in daylight unless you're close
	}
	for _, p := range s.players {
		if p.mode != "survival" || !p.alive {
			continue
		}
		d := math.Hypot(p.x-o.x, p.z-o.z)
		if d < best && math.Abs(p.y-o.y) < 12 {
			best, tgt = d, p
		}
	}
	if tgt == nil {
		if o.fuse > 0 {
			o.fuse = math.Max(0, o.fuse-dt)
		}
		// wander slowly
		dx, dz := o.tx-o.x, o.tz-o.z
		d := math.Hypot(dx, dz)
		if d < .4 || o.wait > 0 {
			o.wait -= dt
			if o.wait <= 0 {
				a := m.r.Float64() * math.Pi * 2
				o.tx, o.tz = o.x+math.Cos(a)*5, o.z+math.Sin(a)*5
				o.wait = 3 + m.r.Float64()*4
			}
			m.moveMob(o, 0, 0, dt)
			return
		}
		st := math.Min(d, .8*dt)
		m.moveMob(o, dx/d*st, dz/d*st, dt)
		o.yaw = math.Atan2(-dx, -dz)
		o.moving = true
		return
	}
	dx, dz := tgt.x-o.x, tgt.z-o.z
	d := math.Hypot(dx, dz)
	o.yaw = math.Atan2(-dx, -dz)
	sp := map[int]float64{kZombie: 2.6, kSkeleton: 2.4, kCreeper: 2.3, kSpider: 3.6}[o.kind]
	want := .9
	if o.kind == kSkeleton {
		want = 7
	}
	if o.kind == kCreeper && o.fuse > 0 {
		sp = 0
	}
	if d > want && d > .01 {
		st := math.Min(d-want, sp*dt)
		m.moveMob(o, dx/d*st, dz/d*st, dt)
		o.moving = true
	} else {
		m.moveMob(o, 0, 0, dt)
	}
	dy := tgt.y - o.y
	switch o.kind {
	case kZombie, kSpider:
		if d < 1.4 && math.Abs(dy) < 1.8 && o.cd <= 0 {
			dmg := 3.0
			if o.kind == kSpider {
				dmg = 2
			}
			o.cd = 1
			s.hurtL(tgt, dmg, dx/d, dz/d, mobNames[o.kind])
		}
	case kSkeleton:
		if d < 14 && o.cd <= 0 {
			o.cd = 2 + m.r.Float64()
			s.broadcastL(map[string]any{"t": "shot", "a": []float64{o.x, o.y + 1.5, o.z}, "b": []float64{tgt.x, tgt.y + 1.2, tgt.z}}, -1)
			if m.r.Float64() < .7 {
				s.hurtL(tgt, 2+float64(m.r.Intn(3)), dx/d*.5, dz/d*.5, "Скелет")
			}
		}
	case kCreeper:
		if d < 2.6 {
			if o.fuse == 0 {
				s.broadcastL(map[string]any{"t": "hiss", "x": o.x, "y": o.y, "z": o.z}, -1)
			}
			o.fuse += dt
			if o.fuse > 1.5 {
				m.explodeL(o)
			}
		} else if o.fuse > 0 {
			o.fuse = math.Max(0, o.fuse-dt)
		}
	}
}

func (m *Mobs) explodeL(o *Mob) {
	s := m.s
	o.hp = -1
	cx, cy, cz := o.x, o.y+.5, o.z
	r := 2.8
	for x := int(cx - r); x <= int(cx+r)+1; x++ {
		for y := int(cy - r); y <= int(cy+r)+1; y++ {
			for z := int(cz - r); z <= int(cz+r)+1; z++ {
				dd := math.Pow(float64(x)+.5-cx, 2) + math.Pow(float64(y)+.5-cy, 2) + math.Pow(float64(z)+.5-cz, 2)
				if dd > r*r || m.r.Float64() < .15 {
					continue
				}
				id := s.w.Block(x, y, z)
				if id == 0 || Blocks[id].Hard < 0 || Blocks[id].Liquid || Blocks[id].Name == "obsidian" {
					continue
				}
				if id == B("chest") {
					s.spillChestL(x, y, z)
				}
				s.setL(x, y, z, 0)
				if m.r.Float64() < .3 {
					s.dropItemL(dropOf(id), 1, 0, float64(x)+.5, float64(y)+.3, float64(z)+.5)
				}
			}
		}
	}
	s.broadcastL(map[string]any{"t": "boom", "x": cx, "y": cy, "z": cz}, -1)
	for _, p := range s.players {
		d := math.Sqrt(math.Pow(p.x-cx, 2) + math.Pow(p.y+.9-cy, 2) + math.Pow(p.z-cz, 2))
		if d < 6 && p.mode == "survival" {
			k := 1 - d/6
			kx, kz := (p.x-cx)/(d+.01), (p.z-cz)/(d+.01)
			s.hurtL(p, math.Round(k*k*22), kx*2.5, kz*2.5, "Крипер")
		}
	}
	for _, q := range m.list {
		if q != o && math.Hypot(q.x-cx, q.z-cz) < 4 {
			q.hp -= 10
			q.hurt = .3
		}
	}
}

// dropOf: what a block turns into when blown up.
func dropOf(id byte) int {
	switch Blocks[id].Name {
	case "grass", "farmland", "snow_grass", "podzol":
		return IT("dirt")
	case "stone":
		return IT("cobble")
	case "leaves", "birch_leaves", "spruce_leaves", "cherry_leaves":
		return IT("sapling")
	}
	return int(id)
}

func (m *Mobs) dieL(o *Mob, killer *Player) {
	s := m.s
	o.hp = -1
	r := m.r
	n := func(a, b int) int { return a + r.Intn(b-a+1) }
	drops := map[int]int{}
	switch o.kind {
	case kPig:
		drops[IT("porkchop")] = n(1, 3)
	case kCow:
		drops[IT("beef")] = n(1, 3)
		drops[IT("leather")] = n(0, 2)
	case kSheep:
		drops[IT("mutton")] = n(1, 2)
		wool := []string{"wool_white", "wool_light_gray", "wool_gray", "wool_black", "wool_brown"}
		w := "wool_white"
		if o.color < len(wool) {
			w = wool[o.color]
		}
		if o.color == 15 {
			w = "wool_pink"
		}
		drops[IT(w)] = 1
	case kChicken:
		drops[IT("chicken")] = 1
		drops[IT("feather")] = n(0, 2)
	case kZombie:
		drops[IT("rotten_flesh")] = n(0, 2)
		if r.Float64() < .05 {
			drops[IT("iron_ingot")] = 1
		}
	case kSkeleton:
		drops[IT("bone")] = n(0, 2)
		drops[IT("flint")] = n(0, 1)
	case kCreeper:
		drops[IT("gunpowder")] = n(0, 2)
	case kSpider:
		drops[IT("string")] = n(0, 2)
	}
	for it, c := range drops {
		if c > 0 {
			s.dropItemL(it, c, 0, o.x, o.y+.4, o.z)
		}
	}
	if killer != nil && o.hostile() {
		s.sysTo(killer, fmt.Sprintf("Побеждён: %s", mobNames[o.kind]))
	}
}

// hitL: a player strikes a mob.
func (s *Server) hitL(p *Player, id int, dmg float64) {
	m := s.mobs
	for _, o := range m.list {
		if o.id != id || o.hp <= 0 {
			continue
		}
		if math.Hypot(o.x-p.x, o.z-p.z) > 6 {
			return
		}
		if dmg > 12 {
			dmg = 12
		}
		o.hp -= dmg
		o.hurt = .35
		d := math.Hypot(o.x-p.x, o.z-p.z) + .01
		o.vx, o.vz = (o.x-p.x)/d*7, (o.z-p.z)/d*7
		o.vy = 5
		o.fuse = 0
		if !o.hostile() {
			o.flee = 4
			a := m.r.Float64() * math.Pi * 2
			o.tx, o.tz = o.x+(o.x-p.x)*4+math.Cos(a)*3, o.z+(o.z-p.z)*4+math.Sin(a)*3
		}
		if o.hp <= 0 {
			m.dieL(o, p)
			keep := m.list[:0]
			for _, q := range m.list {
				if q != o {
					keep = append(keep, q)
				}
			}
			m.list = keep
		}
		return
	}
}
