package mir

type Block struct {
	ID     int     `json:"id"`
	Name   string  `json:"name"`
	Label  string  `json:"label"`
	Solid  bool    `json:"solid"`
	Trans  bool    `json:"trans"`
	Liquid bool    `json:"liquid"`
	Cross  bool    `json:"cross"`
	Glassy bool    `json:"glassy,omitempty"`
	Hard   float64 `json:"hard"`
	Top    string  `json:"top"`
	Side   string  `json:"side"`
	Bottom string  `json:"bottom"`
	Light  int     `json:"light,omitempty"`
	Cat    string  `json:"cat,omitempty"`
}

var Blocks []Block
var byName = map[string]int{}

func B(name string) byte { return byte(byName[name]) }

func addBlock(b Block) {
	b.ID = len(Blocks)
	if b.Side == "" {
		b.Side = b.Name
	}
	if b.Top == "" {
		b.Top = b.Side
	}
	if b.Bottom == "" {
		b.Bottom = b.Top
	}
	Blocks = append(Blocks, b)
	byName[b.Name] = b.ID
}

func cube(name, label string, hard float64, cat string) Block {
	return Block{Name: name, Label: label, Solid: true, Hard: hard, Cat: cat}
}
func plant(name, label string) Block {
	return Block{Name: name, Label: label, Cross: true, Trans: true, Hard: 0.05, Cat: "Растения"}
}

func init() {
	addBlock(Block{Name: "air", Label: "Воздух", Trans: true, Top: "", Side: "", Bottom: ""})
	g := cube("grass", "Трава", .6, "Природа")
	g.Top, g.Side, g.Bottom = "grass_top", "grass_side", "dirt"
	addBlock(g)
	addBlock(cube("dirt", "Земля", .5, "Природа"))
	addBlock(cube("stone", "Камень", 1.5, "Природа"))
	addBlock(cube("cobble", "Булыжник", 2, "Строительные"))
	addBlock(cube("sand", "Песок", .5, "Природа"))
	addBlock(cube("gravel", "Гравий", .6, "Природа"))
	l := cube("log", "Дубовое бревно", 2, "Дерево")
	l.Top, l.Side = "log_top", "log_side"
	addBlock(l)
	lv := cube("leaves", "Дубовая листва", .2, "Растения")
	lv.Trans = true
	addBlock(lv)
	addBlock(cube("planks", "Дубовые доски", 2, "Дерево"))
	addBlock(Block{Name: "water", Label: "Вода", Trans: true, Liquid: true, Cat: "Природа"})
	addBlock(cube("snow", "Снег", .4, "Природа"))
	sg := cube("snow_grass", "Снежная земля", .6, "Природа")
	sg.Top, sg.Side, sg.Bottom = "snow", "snow_side", "dirt"
	addBlock(sg)
	ss := cube("sandstone", "Песчаник", 1.2, "Строительные")
	ss.Top = "sandstone_top"
	ss.Side = "sandstone"
	ss.Bottom = "sandstone_top"
	addBlock(ss)
	br := cube("bedrock", "Коренная порода", -1, "")
	addBlock(br)
	gl := cube("glass", "Стекло", .3, "Стекло")
	gl.Trans = true
	addBlock(gl)
	addBlock(cube("brick", "Кирпич", 2, "Строительные"))
	for _, o := range [][2]string{{"coal_ore", "Угольная руда"}, {"iron_ore", "Железная руда"}, {"gold_ore", "Золотая руда"}, {"diamond_ore", "Алмазная руда"}, {"copper_ore", "Медная руда"}, {"emerald_ore", "Изумрудная руда"}, {"lapis_ore", "Лазуритовая руда"}, {"redstone_ore", "Красная руда"}} {
		addBlock(cube(o[0], o[1], 3, "Руды и металлы"))
	}
	c := cube("cactus", "Кактус", .4, "Растения")
	c.Top, c.Side = "cactus_top", "cactus_side"
	addBlock(c)
	for _, w := range [][2]string{{"white", "Белая"}, {"light_gray", "Светло-серая"}, {"gray", "Серая"}, {"black", "Чёрная"}, {"brown", "Коричневая"}, {"red", "Красная"}, {"orange", "Оранжевая"}, {"yellow", "Жёлтая"}, {"lime", "Лаймовая"}, {"green", "Зелёная"}, {"cyan", "Бирюзовая"}, {"light_blue", "Голубая"}, {"blue", "Синяя"}, {"purple", "Фиолетовая"}, {"magenta", "Пурпурная"}, {"pink", "Розовая"}} {
		addBlock(cube("wool_"+w[0], w[1]+" шерсть", .8, "Цветные"))
	}
	for _, w := range [][2]string{{"white", "Белый"}, {"black", "Чёрный"}, {"red", "Красный"}, {"orange", "Оранжевый"}, {"yellow", "Жёлтый"}, {"lime", "Лаймовый"}, {"cyan", "Бирюзовый"}, {"blue", "Синий"}, {"purple", "Фиолетовый"}, {"pink", "Розовый"}} {
		addBlock(cube("concrete_"+w[0], w[1]+" бетон", 1.8, "Цветные"))
	}
	bs := cube("bookshelf", "Книжная полка", 1.5, "Дерево")
	bs.Top, bs.Side = "planks", "bookshelf"
	addBlock(bs)
	ct := cube("crafting_table", "Верстак", 2.5, "Дерево")
	ct.Top, ct.Side, ct.Bottom = "craft_top", "craft_side", "planks"
	addBlock(ct)
	fu := cube("furnace", "Печь", 3.5, "Строительные")
	fu.Top, fu.Side = "stone", "furnace_side"
	fu.Bottom = "stone"
	addBlock(fu)
	lp := cube("lamp", "Лампа", .5, "Свет")
	lp.Light = 15
	addBlock(lp)
	addBlock(cube("obsidian", "Обсидиан", 10, "Строительные"))
	ic := cube("ice", "Лёд", .5, "Природа")
	addBlock(ic)
	addBlock(cube("clay", "Глина", .6, "Природа"))
	ms := cube("mossy", "Замшелый булыжник", 2, "Строительные")
	addBlock(ms)
	addBlock(plant("flower_red", "Мак"))
	addBlock(plant("flower_yellow", "Одуванчик"))
	addBlock(plant("flower_blue", "Василёк"))
	addBlock(plant("flower_white", "Ромашка"))
	addBlock(plant("flower_pink", "Тюльпан"))
	addBlock(plant("tall_grass", "Высокая трава"))
	addBlock(plant("fern", "Папоротник"))
	addBlock(plant("dead_bush", "Сухой куст"))
	addBlock(plant("mushroom_red", "Мухомор"))
	addBlock(plant("mushroom_brown", "Гриб"))
	addBlock(plant("sugar_cane", "Тростник"))
	addBlock(cube("stone_bricks", "Каменные кирпичи", 1.5, "Строительные"))
	addBlock(cube("mossy_bricks", "Замшелые кирпичи", 1.5, "Строительные"))
	addBlock(cube("iron_block", "Железный блок", 5, "Руды и металлы"))
	addBlock(cube("gold_block", "Золотой блок", 3, "Руды и металлы"))
	addBlock(cube("diamond_block", "Алмазный блок", 5, "Руды и металлы"))
	addBlock(cube("emerald_block", "Изумрудный блок", 5, "Руды и металлы"))
	addBlock(cube("lapis_block", "Лазуритовый блок", 3, "Руды и металлы"))
	addBlock(cube("copper_block", "Медный блок", 3, "Руды и металлы"))
	bl := cube("birch_log", "Берёзовое бревно", 2, "Дерево")
	bl.Top, bl.Side = "birch_top", "birch_side"
	addBlock(bl)
	blv := cube("birch_leaves", "Берёзовая листва", .2, "Растения")
	blv.Trans = true
	addBlock(blv)
	addBlock(cube("birch_planks", "Берёзовые доски", 2, "Дерево"))
	sl := cube("spruce_log", "Еловое бревно", 2, "Дерево")
	sl.Top, sl.Side = "spruce_top", "spruce_side"
	addBlock(sl)
	slv := cube("spruce_leaves", "Хвоя", .2, "Растения")
	slv.Trans = true
	addBlock(slv)
	addBlock(cube("spruce_planks", "Еловые доски", 2, "Дерево"))
	addBlock(cube("dark_planks", "Тёмные доски", 2, "Дерево"))
	addBlock(Block{Name: "lava", Label: "Лава", Trans: true, Liquid: true, Light: 15, Cat: "Природа"})
	gs := cube("glowstone", "Светокамень", .3, "Свет")
	gs.Light = 15
	addBlock(gs)
	to := plant("torch", "Факел")
	to.Light = 14
	to.Cat = "Свет"
	addBlock(to)
	pu := cube("pumpkin", "Тыква", 1, "Растения")
	pu.Top, pu.Side = "pumpkin_top", "pumpkin_side"
	addBlock(pu)
	jl := cube("jack_o_lantern", "Светильник Джека", 1, "Свет")
	jl.Top, jl.Side, jl.Light = "pumpkin_top", "jack_side", 15
	addBlock(jl)
	me := cube("melon", "Арбуз", 1, "Растения")
	me.Top, me.Side = "melon_top", "melon_side"
	addBlock(me)
	hy := cube("hay", "Сено", .5, "Растения")
	hy.Top, hy.Side = "hay_top", "hay_side"
	addBlock(hy)
	addBlock(cube("granite", "Гранит", 1.5, "Природа"))
	addBlock(cube("diorite", "Диорит", 1.5, "Природа"))
	addBlock(cube("andesite", "Андезит", 1.5, "Природа"))
	addBlock(cube("red_sand", "Красный песок", .5, "Природа"))
	addBlock(cube("terracotta", "Терракота", 1.2, "Строительные"))
	addBlock(cube("terracotta_orange", "Оранжевая терракота", 1.2, "Строительные"))
	addBlock(cube("terracotta_white", "Белая терракота", 1.2, "Строительные"))
	q := cube("quartz", "Кварц", 1, "Строительные")
	addBlock(q)
	qp := cube("quartz_pillar", "Кварцевая колонна", 1, "Строительные")
	qp.Top, qp.Side = "quartz", "quartz_pillar"
	addBlock(qp)
	addBlock(cube("prismarine", "Призмарин", 1.5, "Строительные"))
	sl2 := cube("sea_lantern", "Морской фонарь", .3, "Свет")
	sl2.Light = 15
	addBlock(sl2)
	addBlock(cube("mud_bricks", "Глиняные кирпичи", 1.5, "Строительные"))
	addBlock(cube("snow_bricks", "Снежные кирпичи", .6, "Строительные"))
	addBlock(cube("packed_ice", "Плотный лёд", .5, "Природа"))
	tn := cube("tnt", "Динамит (просто красивый)", .1, "Строительные")
	tn.Top, tn.Side, tn.Bottom = "tnt_top", "tnt_side", "tnt_top"
	addBlock(tn)
	for _, w := range [][2]string{{"red", "Красное"}, {"orange", "Оранжевое"}, {"yellow", "Жёлтое"}, {"lime", "Лаймовое"}, {"cyan", "Бирюзовое"}, {"blue", "Синее"}, {"purple", "Фиолетовое"}, {"pink", "Розовое"}, {"white", "Белое"}, {"black", "Тонированное"}} {
		addBlock(Block{Name: "sglass_" + w[0], Label: w[1] + " стекло", Solid: true, Trans: true, Glassy: true, Hard: .3, Cat: "Стекло"})
	}
	mg := cube("moss", "Мох", .2, "Природа")
	addBlock(mg)
	addBlock(cube("podzol", "Подзол", .5, "Природа"))
	addBlock(cube("cherry_planks", "Вишнёвые доски", 2, "Дерево"))
	cl := cube("cherry_leaves", "Вишнёвая листва", .2, "Растения")
	cl.Trans = true
	addBlock(cl)
	chl := cube("cherry_log", "Вишнёвое бревно", 2, "Дерево")
	chl.Top, chl.Side = "cherry_top", "cherry_side"
	addBlock(chl)
	addBlock(cube("amethyst", "Аметист", 1.5, "Руды и металлы"))
	lan := cube("lantern_block", "Бумажный фонарь", .3, "Свет")
	lan.Light = 15
	addBlock(lan)
	// survival blocks
	fl := cube("farmland", "Грядка", .6, "Природа")
	fl.Top, fl.Side, fl.Bottom = "farmland", "dirt", "dirt"
	addBlock(fl)
	for i := 0; i < 4; i++ {
		w := plant("wheat_"+string(rune('0'+i)), "Пшеница (росток)")
		w.Cat = ""
		addBlock(w)
	}
	addBlock(plant("sapling", "Саженец"))
	ch := cube("chest", "Сундук", 2.5, "Дерево")
	ch.Top, ch.Side, ch.Bottom = "chest_top", "chest_side", "chest_top"
	addBlock(ch)
	bd := cube("bed", "Кровать", .3, "Дерево")
	bd.Top, bd.Side, bd.Bottom = "bed_top", "bed_side", "planks"
	addBlock(bd)
	addBlock(Block{Name: "ladder", Label: "Лестница", Trans: true, Hard: .4, Cat: "Дерево"})
	addBlock(Block{Name: "cobweb", Label: "Паутина", Cross: true, Trans: true, Hard: 4, Cat: "Растения"})
}

func validBlock(id int) bool { return id >= 0 && id < len(Blocks) && Blocks[id].Name != "bedrock" }

func isSolid(id byte) bool { return int(id) < len(Blocks) && Blocks[id].Solid }
