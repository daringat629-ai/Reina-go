package mir

import (
	"math"
	"math/rand"
	"sort"
)

// A blueprint is a list of blocks relative to (0,0,0) = ground level at the site's corner.
type plan struct {
	name   string
	w, d   int // footprint size
	blocks []pb
}

type bp struct {
	m map[[3]int]byte
	r *rand.Rand
}

func newBP(r *rand.Rand) *bp           { return &bp{m: map[[3]int]byte{}, r: r} }
func (b *bp) set(x, y, z int, id byte) { b.m[[3]int{x, y, z}] = id }
func (b *bp) box(x0, y0, z0, x1, y1, z1 int, id byte) {
	for x := x0; x <= x1; x++ {
		for y := y0; y <= y1; y++ {
			for z := z0; z <= z1; z++ {
				b.set(x, y, z, id)
			}
		}
	}
}
func (b *bp) walls(x0, y0, z0, x1, y1, z1 int, id byte) {
	for x := x0; x <= x1; x++ {
		for y := y0; y <= y1; y++ {
			for z := z0; z <= z1; z++ {
				if x == x0 || x == x1 || z == z0 || z == z1 {
					b.set(x, y, z, id)
				}
			}
		}
	}
}
func (b *bp) cyl(cx, cz, y0, y1 int, r float64, id byte, hollow bool) {
	ir := int(math.Ceil(r))
	for x := -ir; x <= ir; x++ {
		for z := -ir; z <= ir; z++ {
			d := math.Sqrt(float64(x*x + z*z))
			if d > r+.3 {
				continue
			}
			if hollow && d < r-.7 {
				continue
			}
			for y := y0; y <= y1; y++ {
				b.set(cx+x, y, cz+z, id)
			}
		}
	}
}
func (b *bp) pick(names ...string) byte { return B(names[b.r.Intn(len(names))]) }

func (b *bp) done(name string, w, d int) plan {
	p := plan{name: name, w: w, d: d}
	for k, v := range b.m {
		p.blocks = append(p.blocks, pb{k[0], k[1], k[2], v, false})
	}
	// bottom-up, solid blocks first, then decorations; air (clearing) before everything on its layer
	sort.Slice(p.blocks, func(i, j int) bool {
		a, c := p.blocks[i], p.blocks[j]
		if a.y != c.y {
			return a.y < c.y
		}
		ac, cc := Blocks[a.id].Cross || Blocks[a.id].Light > 0, Blocks[c.id].Cross || Blocks[c.id].Light > 0
		if ac != cc {
			return !ac
		}
		if a.x != c.x {
			return a.x < c.x
		}
		return a.z < c.z
	})
	return p
}

func roofGable(b *bp, x0, z0, x1, z1, y int, id byte) {
	// roof along x axis
	for k := 0; ; k++ {
		za, zb := z0-1+k, z1+1-k
		if za > zb {
			break
		}
		for x := x0 - 1; x <= x1+1; x++ {
			b.set(x, y+k, za, id)
			b.set(x, y+k, zb, id)
		}
		if za == zb || za+1 == zb {
			for x := x0 - 1; x <= x1+1; x++ {
				for z := za; z <= zb; z++ {
					b.set(x, y+k, z, id)
				}
			}
			break
		}
		// fill gable ends
		for z := za + 1; z < zb; z++ {
			b.set(x0, y+k, z, B("planks"))
			b.set(x1, y+k, z, B("planks"))
		}
	}
}

func bpHouse(r *rand.Rand) plan {
	b := newBP(r)
	w, d := 7+r.Intn(3)*2, 7+r.Intn(2)*2
	wall := b.pick("planks", "birch_planks", "spruce_planks", "cherry_planks", "brick", "stone_bricks", "mud_bricks")
	frame := b.pick("log", "spruce_log", "birch_log", "cobble", "dark_planks")
	roof := b.pick("brick", "dark_planks", "spruce_planks", "terracotta", "stone_bricks", "wool_red")
	h := 4
	b.box(-1, -1, -1, w, -1, d, B("cobble"))
	b.box(0, 0, 0, w-1, h+w/2+2, d-1, 0)
	b.box(0, 0, 0, w-1, 0, d-1, b.pick("planks", "spruce_planks", "dark_planks"))
	b.walls(0, 1, 0, w-1, h, d-1, wall)
	for _, c := range [][2]int{{0, 0}, {w - 1, 0}, {0, d - 1}, {w - 1, d - 1}} {
		b.box(c[0], 1, c[1], c[0], h, c[1], frame)
	}
	// windows
	for x := 2; x < w-2; x += 3 {
		b.box(x, 2, 0, x+1, 3, 0, B("glass"))
		b.box(x, 2, d-1, x+1, 3, d-1, B("glass"))
	}
	b.box(0, 2, d/2, 0, 3, d/2, B("glass"))
	b.box(w-1, 2, d/2, w-1, 3, d/2, B("glass"))
	// door
	dx := w / 2
	b.box(dx, 1, 0, dx, 2, 0, 0)
	b.set(dx-1, 3, -1, B("torch"))
	b.set(dx+1, 3, -1, B("torch"))
	// ceiling + roof
	b.box(0, h+1, 0, w-1, h+1, d-1, wall)
	roofGable(b, 0, 0, w-1, d-1, h+1, roof)
	// inside
	b.set(1, 1, d-2, B("crafting_table"))
	b.set(2, 1, d-2, B("furnace"))
	b.set(w-2, 1, d-2, B("bookshelf"))
	b.set(w-2, 2, d-2, B("bookshelf"))
	b.set(w-2, 1, d-3, B("wool_red"))
	b.set(w-2, 1, d-4, B("wool_white"))
	b.set(w/2, h, d/2, B("lamp"))
	// garden path and flowers
	for z := -2; z < 0; z++ {
		b.set(dx, -1, z, B("gravel"))
	}
	for x := 0; x < w; x += 2 {
		if x != dx {
			b.set(x, 0, -2, b.pick("flower_red", "flower_yellow", "flower_blue", "flower_pink"))
		}
	}
	return b.done("домик", w, d)
}

func bpTower(r *rand.Rand) plan {
	b := newBP(r)
	mat := b.pick("stone_bricks", "cobble", "quartz", "sandstone", "brick", "mossy_bricks")
	h := 14 + r.Intn(8)
	b.box(0, 0, 0, 6, h+4, 6, 0)
	b.box(-1, -1, -1, 7, -1, 7, B("cobble"))
	b.cyl(3, 3, 0, h, 3, mat, true)
	b.cyl(3, 3, 0, 0, 2.5, B("planks"), false)
	for y := 4; y < h; y += 4 {
		b.cyl(3, 3, y, y, 2.5, B("planks"), false)
		b.set(3, y, 3, 0)
		b.set(0, y-1, 3, B("glass"))
		b.set(6, y-1, 3, B("glass"))
		b.set(3, y-1, 0, B("glass"))
		b.set(3, y-1, 6, B("glass"))
	}
	// ladder-ish column (spiral of slabs is hard; use a glass shaft with lamps)
	for y := 1; y < h; y += 4 {
		b.set(3, y+1, 3, B("lamp"))
	}
	b.cyl(3, 3, h+1, h+1, 4, mat, false)
	for a := 0; a < 16; a++ {
		x := 3 + int(math.Round(4*math.Cos(float64(a)*math.Pi/8)))
		z := 3 + int(math.Round(4*math.Sin(float64(a)*math.Pi/8)))
		if a%2 == 0 {
			b.set(x, h+2, z, mat)
		}
	}
	flag := b.pick("wool_red", "wool_blue", "wool_yellow", "wool_purple", "wool_pink")
	b.box(3, h+2, 3, 3, h+6, 3, B("spruce_log"))
	b.box(4, h+4, 3, 6, h+6, 3, flag)
	b.box(3, 0, 0, 3, 2, 0, 0)
	return b.done("башню", 7, 7)
}

func bpPyramid(r *rand.Rand) plan {
	b := newBP(r)
	n := 15 + r.Intn(3)*2
	mat := b.pick("sandstone", "sandstone", "quartz", "terracotta_orange", "gold_block")
	b.box(-1, -1, -1, n, -1, n, B("sandstone"))
	for k := 0; k <= n/2; k++ {
		b.box(k, k, k, n-1-k, k, n-1-k, mat)
	}
	// inner chamber and entrance
	b.box(n/2-2, 1, n/2-2, n/2+2, 3, n/2+2, 0)
	b.set(n/2, 1, n/2, B("gold_block"))
	b.set(n/2, 2, n/2, B("torch"))
	b.box(n/2, 1, 0, n/2, 2, n/2-2, 0)
	b.set(n/2, n/2+1, n/2, B("glowstone"))
	return b.done("пирамиду", n, n)
}

func bpCastle(r *rand.Rand) plan {
	b := newBP(r)
	n := 17
	mat := b.pick("stone_bricks", "cobble", "mossy_bricks", "andesite")
	b.box(-1, -1, -1, n, -1, n, B("cobble"))
	b.box(0, 0, 0, n-1, 12, n-1, 0)
	b.box(0, 0, 0, n-1, 0, n-1, B("gravel"))
	b.walls(0, 1, 0, n-1, 6, n-1, mat)
	for x := 0; x < n; x += 2 {
		b.set(x, 7, 0, mat)
		b.set(x, 7, n-1, mat)
		b.set(0, 7, x, mat)
		b.set(n-1, 7, x, mat)
	}
	for _, c := range [][2]int{{0, 0}, {n - 1, 0}, {0, n - 1}, {n - 1, n - 1}} {
		b.cyl(c[0], c[1], 0, 10, 2, mat, false)
		b.cyl(c[0], c[1], 1, 9, 1, 0, false)
		b.cyl(c[0], c[1], 11, 11, 2.4, mat, false)
		b.set(c[0], 12, c[1], B("lamp"))
	}
	// keep
	b.box(5, 1, 6, 11, 9, 12, mat)
	b.box(6, 1, 7, 10, 8, 11, 0)
	b.box(8, 1, 6, 8, 3, 6, 0)
	b.set(8, 8, 9, B("lamp"))
	b.box(6, 1, 11, 10, 1, 11, B("wool_red"))
	b.box(5, 10, 6, 11, 10, 12, B("dark_planks"))
	b.box(8, 10, 9, 8, 14, 9, B("spruce_log"))
	b.box(9, 12, 9, 11, 14, 9, b.pick("wool_red", "wool_blue", "wool_purple"))
	// gate
	b.box(7, 1, 0, 9, 4, 0, 0)
	b.set(6, 4, -1, B("torch"))
	b.set(10, 4, -1, B("torch"))
	return b.done("замок", n, n)
}

func bpLighthouse(r *rand.Rand) plan {
	b := newBP(r)
	h := 20
	b.box(-1, -1, -1, 7, -1, 7, B("stone_bricks"))
	b.box(0, 0, 0, 6, h+6, 6, 0)
	for y := 0; y <= h; y++ {
		id := B("concrete_white")
		if (y/4)%2 == 1 {
			id = B("concrete_red")
		}
		rad := 3 - float64(y)/float64(h)*1.2
		b.cyl(3, 3, y, y, rad, id, true)
	}
	b.box(3, 0, 1, 3, 2, 1, 0)
	b.box(3, 0, 0, 3, 2, 0, 0)
	b.cyl(3, 3, h+1, h+1, 3, B("stone_bricks"), false)
	b.box(2, h+2, 2, 4, h+4, 4, B("glass"))
	b.set(3, h+3, 3, B("sea_lantern"))
	b.set(3, h+2, 3, B("glowstone"))
	b.box(2, h+5, 2, 4, h+5, 4, B("concrete_red"))
	b.set(3, h+6, 3, B("concrete_red"))
	return b.done("маяк", 7, 7)
}

func bpFountain(r *rand.Rand) plan {
	b := newBP(r)
	b.box(0, 0, 0, 8, 6, 8, 0)
	b.box(0, -1, 0, 8, -1, 8, B("stone_bricks"))
	b.walls(0, 0, 0, 8, 0, 8, B("quartz"))
	b.box(1, 0, 1, 7, 0, 7, B("water"))
	b.box(3, 0, 3, 5, 0, 5, B("quartz"))
	b.box(4, 1, 4, 4, 3, 4, B("quartz_pillar"))
	b.box(3, 4, 3, 5, 4, 5, B("quartz"))
	b.set(4, 5, 4, B("water"))
	b.set(4, 4, 4, B("sea_lantern"))
	for _, c := range [][2]int{{0, 0}, {8, 0}, {0, 8}, {8, 8}} {
		b.set(c[0], 1, c[1], B("lamp"))
	}
	return b.done("фонтан", 9, 9)
}

func bpGarden(r *rand.Rand) plan {
	b := newBP(r)
	n := 11
	b.box(0, 0, 0, n-1, 4, n-1, 0)
	b.box(0, -1, 0, n-1, -1, n-1, B("grass"))
	hedge := B("leaves")
	b.walls(0, 0, 0, n-1, 0, n-1, hedge)
	b.box(n/2, 0, 0, n/2, 0, 0, 0)
	for x := 1; x < n-1; x++ {
		b.set(x, -1, n/2, B("gravel"))
		b.set(n/2, -1, x, B("gravel"))
	}
	fl := []string{"flower_red", "flower_yellow", "flower_blue", "flower_white", "flower_pink"}
	for x := 1; x < n-1; x++ {
		for z := 1; z < n-1; z++ {
			if x == n/2 || z == n/2 {
				continue
			}
			b.set(x, 0, z, B(fl[(x/2+z/2)%len(fl)]))
		}
	}
	b.set(n/2, -1, n/2, B("water"))
	for _, c := range [][2]int{{2, 2}, {n - 3, 2}, {2, n - 3}, {n - 3, n - 3}} {
		b.set(c[0], 0, c[1], B("lamp"))
	}
	b.set(n/2-1, 0, n/2-1, B("cherry_leaves"))
	return b.done("сад", n, n)
}

func bpWindmill(r *rand.Rand) plan {
	b := newBP(r)
	h := 12
	b.box(0, 0, 0, 7, h+6, 7, 0)
	b.box(-1, -1, -1, 8, -1, 8, B("cobble"))
	for y := 0; y <= h; y++ {
		rad := 3.2 - float64(y)/float64(h)*1.0
		b.cyl(4, 4, y, y, rad, B("concrete_white"), true)
	}
	b.box(4, 0, 1, 4, 2, 1, 0)
	b.cyl(4, 4, h+1, h+3, 2.2, B("dark_planks"), false)
	b.set(4, h+4, 4, B("dark_planks"))
	// sails on the -z side
	hy := h + 1
	for i := -6; i <= 6; i++ {
		b.set(4+i, hy, 0, B("wool_white"))
		b.set(4, hy+i, 0, B("wool_white"))
		if i != 0 {
			b.set(4+i, hy+1*sign(i), 0, B("spruce_planks"))
			b.set(4-1*sign(i), hy+i, 0, B("spruce_planks"))
		}
	}
	b.set(4, hy, 0, B("spruce_log"))
	b.set(4, hy, 1, B("spruce_log"))
	return b.done("ветряную мельницу", 8, 8)
}

func sign(i int) int {
	if i < 0 {
		return -1
	}
	return 1
}

func bpIgloo(r *rand.Rand) plan {
	b := newBP(r)
	b.box(0, 0, 0, 8, 5, 8, 0)
	for x := 0; x <= 8; x++ {
		for y := 0; y <= 4; y++ {
			for z := 0; z <= 8; z++ {
				d := math.Sqrt(float64((x-4)*(x-4)+(z-4)*(z-4)) + float64(y*y)*1.6)
				if d <= 4.4 && d > 3.3 {
					b.set(x, y, z, B("snow_bricks"))
				}
			}
		}
	}
	b.box(4, 0, 0, 4, 1, 1, 0)
	b.set(4, 0, 4, B("lantern_block"))
	b.set(5, 1, 3, B("packed_ice"))
	b.set(2, 0, 4, B("wool_white"))
	return b.done("иглу", 9, 9)
}

func bpBridge(r *rand.Rand) plan {
	b := newBP(r)
	l := 21
	b.box(0, 0, 0, l-1, 6, 4, 0)
	for x := 0; x < l; x++ {
		y := int(4 - math.Abs(float64(x-l/2))/float64(l/2)*4)
		b.box(x, y, 1, x, y, 3, B("spruce_planks"))
		b.set(x, y+1, 0, B("dark_planks"))
		b.set(x, y+1, 4, B("dark_planks"))
		if x%5 == 0 {
			b.box(x, 0, 0, x, y+2, 0, B("spruce_log"))
			b.box(x, 0, 4, x, y+2, 4, B("spruce_log"))
			b.set(x, y+3, 0, B("lantern_block"))
			b.set(x, y+3, 4, B("lantern_block"))
		}
	}
	return b.done("мостик", l, 5)
}

func bpStatue(r *rand.Rand) plan {
	b := newBP(r)
	// a big pink heart on a pedestal
	b.box(0, 0, 0, 12, 14, 3, 0)
	b.box(3, 0, 0, 9, 1, 3, B("quartz"))
	heart := []string{
		"..XXX...XXX..",
		".XXXXX.XXXXX.",
		"XXXXXXXXXXXXX",
		"XXXXXXXXXXXXX",
		"XXXXXXXXXXXXX",
		".XXXXXXXXXXX.",
		"..XXXXXXXXX..",
		"...XXXXXXX...",
		"....XXXXX....",
		".....XXX.....",
		"......X......",
	}
	for row, line := range heart {
		y := 2 + len(heart) - row
		for x, ch := range line {
			if ch == 'X' {
				id := B("wool_pink")
				if (row == 1 && (x == 2 || x == 3)) || (row == 2 && x == 2) {
					id = B("wool_white")
				}
				b.set(x, y, 1, id)
				b.set(x, y, 2, B("wool_magenta"))
			}
		}
	}
	b.set(6, 1, -1, B("lamp"))
	return b.done("статую сердца", 13, 4)
}

func bpTemple(r *rand.Rand) plan {
	b := newBP(r)
	w, d := 11, 15
	b.box(0, 0, 0, w-1, 12, d-1, 0)
	b.box(-1, -1, -1, w, -1, d, B("quartz"))
	b.box(0, 0, 0, w-1, 0, d-1, B("quartz"))
	for x := 0; x < w; x += 2 {
		for _, z := range []int{0, d - 1} {
			b.box(x, 1, z, x, 6, z, B("quartz_pillar"))
		}
	}
	for z := 0; z < d; z += 2 {
		b.box(0, 1, z, 0, 6, z, B("quartz_pillar"))
		b.box(w-1, 1, z, w-1, 6, z, B("quartz_pillar"))
	}
	b.box(0, 7, 0, w-1, 7, d-1, B("quartz"))
	for k := 1; k <= w/2; k++ {
		b.box(k-1, 7+k, 0, w-k, 7+k, d-1, B("quartz"))
		b.box(k, 7+k, 1, w-1-k, 7+k, d-2, 0)
	}
	b.set(w/2, 1, d-3, B("gold_block"))
	b.set(w/2, 2, d-3, B("sea_lantern"))
	b.set(w/2, 6, d/2, B("glowstone"))
	return b.done("храм", w, d)
}

func bpGiantTree(r *rand.Rand) plan {
	b := newBP(r)
	log, leaf := B("log"), B("leaves")
	if r.Intn(2) == 0 {
		log, leaf = B("cherry_log"), B("cherry_leaves")
	}
	h := 14
	b.box(0, 0, 0, 12, h+8, 12, 0)
	b.box(5, 0, 5, 7, h, 7, log)
	for y := h - 4; y <= h+6; y++ {
		rad := 6.0 - math.Abs(float64(y-(h+1)))*.6
		for x := -7; x <= 7; x++ {
			for z := -7; z <= 7; z++ {
				if float64(x*x+z*z) <= rad*rad && r.Float64() > .08 {
					if b.m[[3]int{6 + x, y, 6 + z}] == 0 {
						b.set(6+x, y, 6+z, leaf)
					}
				}
			}
		}
	}
	b.box(5, 0, 5, 7, h, 7, log)
	b.set(6, 0, 4, B("lamp"))
	return b.done("огромное дерево", 13, 13)
}

var blueprints = map[string]func(*rand.Rand) plan{
	"дом": bpHouse, "домик": bpHouse, "башн": bpTower, "пирамид": bpPyramid, "замок": bpCastle, "крепост": bpCastle,
	"маяк": bpLighthouse, "фонтан": bpFountain, "сад": bpGarden, "мельниц": bpWindmill, "ветряк": bpWindmill,
	"иглу": bpIgloo, "мост": bpBridge, "статую": bpStatue, "статуя": bpStatue, "сердц": bpStatue, "храм": bpTemple,
	"дерев": bpGiantTree,
	"house": bpHouse, "tower": bpTower, "pyramid": bpPyramid, "castle": bpCastle, "lighthouse": bpLighthouse,
	"fountain": bpFountain, "garden": bpGarden, "windmill": bpWindmill, "igloo": bpIgloo, "bridge": bpBridge,
	"statue": bpStatue, "temple": bpTemple, "tree": bpGiantTree,
}

// autoPlan picks something fitting the biome.
func autoPlan(r *rand.Rand, biome int) plan {
	switch biome {
	case bDesert, bMesa:
		return []func(*rand.Rand) plan{bpPyramid, bpTemple, bpFountain, bpHouse}[r.Intn(4)](r)
	case bTaiga, bSnowPlains, bMountain:
		return []func(*rand.Rand) plan{bpIgloo, bpTower, bpHouse, bpCastle}[r.Intn(4)](r)
	case bBeach:
		return []func(*rand.Rand) plan{bpLighthouse, bpHouse, bpFountain}[r.Intn(3)](r)
	case bCherry:
		return []func(*rand.Rand) plan{bpGarden, bpTemple, bpGiantTree, bpHouse}[r.Intn(4)](r)
	}
	all := []func(*rand.Rand) plan{bpHouse, bpHouse, bpTower, bpCastle, bpFountain, bpGarden, bpWindmill, bpStatue, bpGiantTree, bpLighthouse, bpTemple, bpBridge}
	return all[r.Intn(len(all))](r)
}
