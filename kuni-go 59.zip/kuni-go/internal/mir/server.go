package mir

import (
	"context"
	"crypto/subtle"
	"encoding/json"
	"fmt"
	"math"
	"net/http"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
	"unicode/utf8"
)

const MaxView = 10

type Player struct {
	id         int
	name       string
	x, y, z    float64
	yaw, pitch float64
	view       int
	color      int
	bot        bool
	conn       *wsConn
	out        chan []byte
	outBin     chan []byte
	sent       map[ckey]bool
	setTokens  float64
	lastTok    time.Time
	chatTokens float64
	joined     time.Time
	gone       bool
	held       int
	anim       int
	mode       string
	alive      bool
}

type ChatLine struct {
	From string `json:"from"`
	Text string `json:"text"`
}

type Server struct {
	mu        sync.Mutex
	w         *World
	key       string
	players   map[int]*Player
	nextID    int
	bot       *Bot
	mobs      *Mobs
	history   []ChatLine
	started   time.Time
	items     []*ItemEnt
	nextItem  int
	forceMode string

	// Set by the host program (Reina). Key returns the world password; NoPassword lets anybody in.
	Key        func() string
	NoPassword bool
	// OnChat, when set, receives what people say in the world; the built-in phrase bot then stays quiet
	// and the model answers through the world tool.
	OnChat   func(from, text string)
	autoOff  bool
	ticks    int
	undoList []undoJob
}

func NewServer(w *World, key string) *Server {
	s := &Server{w: w, key: key, players: map[int]*Player{}, nextID: 1, started: time.Now()}
	s.Key = func() string { return key }
	s.NoPassword = key == ""
	s.bot = newBot(s)
	s.mobs = newMobs(s)
	return s
}

func cleanName(n string) string {
	n = strings.TrimSpace(n)
	var b strings.Builder
	for _, r := range n {
		if r < 32 || r == '<' || r == '>' {
			continue
		}
		b.WriteRune(r)
	}
	n = b.String()
	for utf8.RuneCountInString(n) > 20 {
		_, sz := utf8.DecodeLastRuneInString(n)
		n = n[:len(n)-sz]
	}
	if n == "" {
		n = "Игрок"
	}
	return n
}

func finite(v ...float64) bool {
	for _, f := range v {
		if math.IsNaN(f) || math.IsInf(f, 0) {
			return false
		}
	}
	return true
}

func (s *Server) keyWanted() string {
	if s.Key != nil {
		return s.Key()
	}
	return s.key
}

// keyOK: with a password set, the guest must know it; NoPassword (or no key at all in the standalone world) lets anybody in.
func (s *Server) keyOK(got string) bool {
	if s.NoPassword {
		return true
	}
	want := s.keyWanted()
	if want == "" {
		return false
	}
	return subtle.ConstantTimeCompare([]byte(got), []byte(want)) == 1
}

func (s *Server) handleWS(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()
	if !s.keyOK(q.Get("key")) {
		http.Error(w, "wrong key", http.StatusForbidden)
		return
	}
	ws, err := wsUpgrade(w, r)
	if err != nil {
		return
	}
	name := cleanName(q.Get("name"))
	p := s.join(ws, name, q.Get("mode"))
	go func() {
		for {
			select {
			case m, ok := <-p.out:
				if !ok {
					return
				}
				if ws.writeFrame(0x1, m) != nil {
					ws.close()
					return
				}
			case m, ok := <-p.outBin:
				if !ok {
					return
				}
				if ws.writeFrame(0x2, m) != nil {
					ws.close()
					return
				}
			}
		}
	}()
	defer s.leave(p)
	for {
		op, data, err := ws.read()
		if err != nil {
			return
		}
		if op != 0x1 {
			continue
		}
		var m map[string]any
		if json.Unmarshal(data, &m) != nil {
			continue
		}
		s.handle(p, m)
	}
}

func (s *Server) sendL(p *Player, v any) {
	if p.bot || p.gone {
		return
	}
	b, _ := json.Marshal(v)
	select {
	case p.out <- b:
	default:
		// slow client: drop non-critical updates
	}
}

func (s *Server) broadcastL(v any, except int) {
	b, _ := json.Marshal(v)
	for _, p := range s.players {
		if p.bot || p.gone || p.id == except {
			continue
		}
		select {
		case p.out <- b:
		default:
		}
	}
}

func (s *Server) sayL(from, text string) {
	s.history = append(s.history, ChatLine{from, text})
	if len(s.history) > 30 {
		s.history = s.history[1:]
	}
	s.broadcastL(map[string]any{"t": "chat", "from": from, "text": text}, -1)
}

func (s *Server) sysTo(p *Player, text string) {
	s.sendL(p, map[string]any{"t": "chat", "from": "", "text": text})
}

func (s *Server) join(ws *wsConn, name, mode string) *Player {
	s.mu.Lock()
	defer s.mu.Unlock()
	// unique name among those online
	base := name
	for i := 2; ; i++ {
		taken := name == s.bot.p.name
		for _, o := range s.players {
			if o.name == name {
				taken = true
			}
		}
		if !taken {
			break
		}
		name = fmt.Sprintf("%s%d", base, i)
	}
	p := &Player{id: s.nextID, name: name, view: 5, conn: ws, out: make(chan []byte, 512), outBin: make(chan []byte, 64), sent: map[ckey]bool{}, joined: time.Now(), setTokens: 40, chatTokens: 5, lastTok: time.Now()}
	s.nextID++
	sp := s.w.spawn
	p.x, p.y, p.z = float64(sp[0])+.5, float64(sp[1]), float64(sp[2])+.5
	save := s.w.meta.Players[name]
	if save != nil && finite(save.X, save.Y, save.Z) {
		p.x, p.y, p.z, p.yaw = save.X, save.Y, save.Z, save.Yaw
		p.color = save.Color
	} else {
		save = &PlayerSave{Color: int(s.w.gen.unit(int64(len(s.w.meta.Players)), 9, 9) * 360)}
		s.w.meta.Players[name] = save
		p.color = save.Color
	}
	if s.forceMode != "" {
		mode = s.forceMode
	}
	if mode != "survival" && mode != "creative" {
		mode = save.Mode
	}
	if mode == "" {
		mode = "creative"
	}
	p.mode, p.alive = mode, true
	save.Mode = mode
	if mode == "survival" && !save.Started {
		save.Started, save.HP, save.Food, save.Sat = true, 20, 20, 5
	}
	if save.HP <= 0 && mode == "survival" {
		save.HP, save.Food = 20, 20
	}
	// make sure we don't spawn inside a block
	gy := float64(s.w.Ground(int(math.Floor(p.x)), int(math.Floor(p.z))))
	if p.y < gy || isSolid(s.w.Block(int(math.Floor(p.x)), int(math.Floor(p.y)), int(math.Floor(p.z)))) {
		p.y = gy
	}
	s.players[p.id] = p
	s.sendL(p, map[string]any{
		"t": "hello", "id": p.id, "name": p.name, "x": p.x, "y": p.y, "z": p.z, "yaw": p.yaw,
		"blocks": Blocks, "bot": s.bot.p.name, "time": s.w.meta.Time, "maxView": MaxView,
		"hotbar": save.Hotbar, "seed": s.w.meta.Seed, "color": p.color, "history": s.history,
		"spawn": sp, "keyed": !s.NoPassword && s.keyWanted() != "",
		"items": Items, "mode": p.mode, "forced": s.forceMode != "",
		"surv": map[string]any{"inv": save.Inv, "arm": save.Armor, "hp": save.HP, "food": save.Food, "sat": save.Sat},
	})
	if mode == "survival" && len(save.Inv) == 0 {
		go func() {
			time.Sleep(3 * time.Second)
			s.mu.Lock()
			s.sysTo(p, "Выживание: добудь дерево (держи ЛКМ на бревне), сделай доски и верстак (E). Ночью приходят монстры — построй укрытие и факелы!")
			s.mu.Unlock()
		}()
	}
	s.sayL("", p.name+" зашёл в мир")
	if s.OnChat == nil {
		go s.bot.greet(p.name, save.LastSeen)
	}
	return p
}

func (s *Server) leave(p *Player) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if p.gone {
		return
	}
	p.gone = true
	if sv := s.w.meta.Players[p.name]; sv != nil {
		sv.X, sv.Y, sv.Z, sv.Yaw = p.x, p.y, p.z, p.yaw
		sv.LastSeen = time.Now().Unix()
	}
	delete(s.players, p.id)
	p.conn.close()
	s.sayL("", p.name+" вышел из мира")
}

func num(m map[string]any, k string) float64 {
	switch v := m[k].(type) {
	case float64:
		return v
	case string:
		f, _ := strconv.ParseFloat(v, 64)
		return f
	}
	return 0
}

func (s *Server) handle(p *Player, m map[string]any) {
	t, _ := m["t"].(string)
	if s.handleSurvival(p, t, m) {
		return
	}
	switch t {
	case "pos":
		x, y, z, a, b := num(m, "x"), num(m, "y"), num(m, "z"), num(m, "a"), num(m, "b")
		if !finite(x, y, z, a, b) || math.Abs(x) > 3e7 || math.Abs(z) > 3e7 || y < -100 || y > 400 {
			return
		}
		s.mu.Lock()
		p.x, p.y, p.z, p.yaw, p.pitch = x, y, z, a, b
		p.held = int(num(m, "h"))
		p.anim = int(num(m, "s"))
		s.mu.Unlock()
	case "view":
		v := int(num(m, "view"))
		if v < 2 {
			v = 2
		}
		if v > MaxView {
			v = MaxView
		}
		s.mu.Lock()
		p.view = v
		s.mu.Unlock()
	case "hot":
		arr, _ := m["h"].([]any)
		var h []int
		for _, v := range arr {
			if f, ok := v.(float64); ok && validBlock(int(f)) && len(h) < 9 {
				h = append(h, int(f))
			}
		}
		s.mu.Lock()
		if sv := s.w.meta.Players[p.name]; sv != nil {
			sv.Hotbar = h
		}
		s.mu.Unlock()
	case "set":
		x, y, z, id := int(num(m, "x")), int(num(m, "y")), int(num(m, "z")), int(num(m, "id"))
		old := s.w.Block(x, y, z)
		if s.humanSet(p, x, y, z, id) {
			s.mu.Lock()
			if old == B("chest") && id != int(old) {
				s.spillChestL(x, y, z)
			}
			if p.mode == "survival" {
				if arr, ok := m["drop"].([]any); ok {
					for i := 0; i+1 < len(arr); i += 2 {
						it, _ := arr[i].(float64)
						n, _ := arr[i+1].(float64)
						if n > 0 && n <= 9 {
							s.dropItemL(int(it), int(n), 0, float64(x)+.5, float64(y)+.3, float64(z)+.5)
						}
					}
				}
			}
			s.mu.Unlock()
		}
	case "chat":
		text, _ := m["text"].(string)
		text = strings.TrimSpace(text)
		if text == "" {
			return
		}
		if utf8.RuneCountInString(text) > 300 {
			text = string([]rune(text)[:300])
		}
		s.mu.Lock()
		now := time.Now()
		p.chatTokens = math.Min(5, p.chatTokens+now.Sub(p.lastTok).Seconds()*.8)
		if p.chatTokens < 1 {
			s.mu.Unlock()
			return
		}
		p.chatTokens--
		if strings.HasPrefix(text, "/") {
			s.command(p, text)
			s.mu.Unlock()
			return
		}
		s.sayL(p.name, text)
		s.mu.Unlock()
		if s.OnChat != nil {
			go s.OnChat(p.name, text)
		} else {
			go s.bot.hear(p.name, text)
		}
	}
}

func (s *Server) humanSet(p *Player, x, y, z, id int) bool {
	if !validBlock(id) || y < 1 || y >= CY {
		return false
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	now := time.Now()
	p.setTokens = math.Min(40, p.setTokens+now.Sub(p.lastTok).Seconds()*20)
	p.lastTok = now
	if p.setTokens < 1 {
		return false
	}
	p.setTokens--
	dx, dy, dz := float64(x)+.5-p.x, float64(y)+.5-(p.y+1.6), float64(z)+.5-p.z
	if dx*dx+dy*dy+dz*dz > 12*12 {
		return false
	}
	cur := s.w.Block(x, y, z)
	if Blocks[cur].Name == "bedrock" {
		return false
	}
	ok := s.w.SetBlock(x, y, z, byte(id))
	if ok {
		s.broadcastL(map[string]any{"t": "b", "x": x, "y": y, "z": z, "id": id, "by": p.id}, -1)
		// plants fall off when the ground beneath them goes
		if id == 0 && y+1 < CY {
			above := s.w.Block(x, y+1, z)
			if Blocks[above].Cross {
				s.w.SetBlock(x, y+1, z, 0)
				s.broadcastL(map[string]any{"t": "b", "x": x, "y": y + 1, "z": z, "id": 0}, -1)
				if p.mode == "survival" && Blocks[above].Name == "wheat_3" {
					s.dropItemL(IT("wheat"), 1, 0, float64(x)+.5, float64(y)+1.3, float64(z)+.5)
				}
			}
		}
	}
	return ok
}

// setL places a block on behalf of the server (bot, structures). Caller holds s.mu.
func (s *Server) setL(x, y, z int, id byte) {
	if y < 1 || y >= CY {
		return
	}
	if s.w.SetBlock(x, y, z, id) {
		s.broadcastL(map[string]any{"t": "b", "x": x, "y": y, "z": z, "id": int(id)}, -1)
	}
}

func (s *Server) findPlayerL(name string) *Player {
	name = strings.ToLower(strings.TrimSpace(name))
	for _, o := range s.players {
		if strings.ToLower(o.name) == name {
			return o
		}
	}
	for _, o := range s.players {
		if strings.HasPrefix(strings.ToLower(o.name), name) {
			return o
		}
	}
	if strings.HasPrefix(strings.ToLower(s.bot.p.name), name) && name != "" {
		return s.bot.p
	}
	return nil
}

func (s *Server) tpL(p *Player, x, y, z float64) {
	p.x, p.y, p.z = x, y, z
	s.sendL(p, map[string]any{"t": "tp", "x": x, "y": y, "z": z})
}

const helpText = `Команды:
/who — кто в мире
/tp <имя> — к игроку (или к Рейне)
/spawn — на точку появления
/sethome, /home — свой дом
/day, /night, /time <0-24> — время суток
/build <что> — попросить Рейну построить рядом: дом, башню, пирамиду, замок, маяк, фонтан, сад, ветряк, иглу, мост, статую, храм, дерево
/come — позвать Рейну, /follow — чтобы ходила за тобой, /stay — пусть гуляет сама
/biome — где ты сейчас
/seed — номер мира
/survival или /creative — сменить режим`

func (s *Server) command(p *Player, text string) {
	parts := strings.Fields(text)
	cmd := strings.ToLower(parts[0])
	arg := ""
	if len(parts) > 1 {
		arg = strings.Join(parts[1:], " ")
	}
	if p.mode == "survival" {
		switch cmd {
		case "/tp", "/spawn", "/home", "/day", "/день", "/night", "/ночь", "/time":
			s.sysTo(p, "В выживании эта команда не работает 🙂 (кровать — чтобы проспать ночь и вернуться домой)")
			return
		}
	}
	switch cmd {
	case "/survival", "/выживание", "/creative", "/творчество":
		if s.forceMode != "" {
			s.sysTo(p, "На этом сервере режим задан хозяином мира.")
			return
		}
		nm := "creative"
		if cmd == "/survival" || cmd == "/выживание" {
			nm = "survival"
		}
		if nm == p.mode {
			return
		}
		sv := s.w.meta.Players[p.name]
		p.mode, p.alive, sv.Mode = nm, true, nm
		if nm == "survival" && !sv.Started {
			sv.Started, sv.HP, sv.Food, sv.Sat = true, 20, 20, 5
		}
		s.sendL(p, map[string]any{"t": "mode", "mode": nm, "surv": map[string]any{"inv": sv.Inv, "arm": sv.Armor, "hp": sv.HP, "food": sv.Food, "sat": sv.Sat}})
		s.sayL("", p.name+map[string]string{"survival": " теперь в режиме выживания ⚔", "creative": " теперь в творческом режиме ✨"}[nm])
	case "/help", "/помощь", "/?":
		for _, l := range strings.Split(helpText, "\n") {
			s.sysTo(p, l)
		}
	case "/who", "/кто":
		var names []string
		for _, o := range s.players {
			names = append(names, o.name)
		}
		sort.Strings(names)
		s.sysTo(p, fmt.Sprintf("В мире (%d): %s и %s", len(names), strings.Join(names, ", "), s.bot.p.name))
	case "/tp":
		o := s.findPlayerL(arg)
		if o == nil {
			s.sysTo(p, "Нет такого игрока: "+arg)
			return
		}
		s.tpL(p, o.x+.6, o.y+.1, o.z+.6)
		s.sysTo(p, "Перенос к "+o.name)
	case "/spawn":
		sp := s.w.spawn
		s.tpL(p, float64(sp[0])+.5, float64(s.w.Ground(sp[0], sp[2])), float64(sp[2])+.5)
	case "/sethome":
		if sv := s.w.meta.Players[p.name]; sv != nil {
			sv.HomeX, sv.HomeY, sv.HomeZ, sv.HasHome = p.x, p.y, p.z, true
		}
		s.sysTo(p, "Дом запомнен. /home — вернуться сюда.")
	case "/home":
		sv := s.w.meta.Players[p.name]
		if sv == nil || !sv.HasHome {
			s.sysTo(p, "Дом ещё не задан: /sethome")
			return
		}
		s.tpL(p, sv.HomeX, sv.HomeY+.05, sv.HomeZ)
	case "/day", "/день":
		s.w.meta.Time = .27
		s.broadcastL(map[string]any{"t": "time", "v": s.w.meta.Time}, -1)
		s.sayL("", p.name+" включил день")
	case "/night", "/ночь":
		s.w.meta.Time = .75
		s.broadcastL(map[string]any{"t": "time", "v": s.w.meta.Time}, -1)
		s.sayL("", p.name+" включил ночь")
	case "/time":
		h, err := strconv.ParseFloat(arg, 64)
		if err != nil || h < 0 || h > 24 {
			s.sysTo(p, "Например: /time 18")
			return
		}
		// time 0 is sunrise (6:00)
		s.w.meta.Time = math.Mod((h-6)/24+1, 1)
		s.broadcastL(map[string]any{"t": "time", "v": s.w.meta.Time}, -1)
	case "/seed":
		s.sysTo(p, fmt.Sprintf("Номер мира: %d", s.w.meta.Seed))
	case "/biome":
		b := s.w.gen.BiomeAt(int(math.Floor(p.x)), int(math.Floor(p.z)))
		s.sysTo(p, "Ты в биоме: "+biomeNames[b])
	case "/build", "/построй":
		go s.bot.request(p.name, "построй "+arg)
	case "/come":
		go s.bot.request(p.name, "иди сюда")
	case "/follow":
		go s.bot.request(p.name, "за мной")
	case "/stay":
		go s.bot.request(p.name, "гуляй")
	default:
		s.sysTo(p, "Не знаю такую команду. /help — список.")
	}
}

// Run drives the world (physics, mobs, the builder) until ctx ends, then saves it.
func (s *Server) Run(ctx context.Context) {
	tick := time.NewTicker(50 * time.Millisecond)
	defer tick.Stop()
	defer s.Shutdown()
	last := time.Now()
	n := 0
	for {
		var now time.Time
		select {
		case <-ctx.Done():
			return
		case now = <-tick.C:
		}
		dt := now.Sub(last).Seconds()
		last = now
		n++
		s.mu.Lock()
		s.w.meta.Time = math.Mod(s.w.meta.Time+dt/1200, 1)
		s.streamChunksL()
		s.itemsStepL(dt)
		if n%20 == 0 {
			s.growthTickL()
		}
		if n%2 == 0 {
			s.broadcastPositionsL()
		}
		if n%100 == 0 {
			s.broadcastL(map[string]any{"t": "time", "v": s.w.meta.Time}, -1)
		}
		s.mu.Unlock()
		s.bot.step(dt)
		s.mobs.step(dt)
		if n%600 == 0 { // every 30 s
			s.housekeeping()
		}
	}
}

func (s *Server) streamChunksL() {
	for _, p := range s.players {
		pcx, pcz := floorDiv(int(math.Floor(p.x)), CX), floorDiv(int(math.Floor(p.z)), CZ)
		for k := range p.sent {
			if iabs(k.x-pcx) > p.view+2 || iabs(k.z-pcz) > p.view+2 {
				delete(p.sent, k)
			}
		}
		type cand struct {
			k ckey
			d int
		}
		var want []cand
		for dx := -p.view; dx <= p.view; dx++ {
			for dz := -p.view; dz <= p.view; dz++ {
				k := ckey{pcx + dx, pcz + dz}
				if !p.sent[k] {
					want = append(want, cand{k, dx*dx + dz*dz})
				}
			}
		}
		if len(want) == 0 {
			continue
		}
		sort.Slice(want, func(i, j int) bool { return want[i].d < want[j].d })
		budget := 3
		if len(p.sent) < 9 {
			budget = 9
		}
		for i := 0; i < len(want) && i < budget; i++ {
			if len(p.outBin) > 40 {
				break
			}
			data := s.w.EncodeChunk(want[i].k.x, want[i].k.z)
			p.outBin <- data
			p.sent[want[i].k] = true
		}
	}
}

func (s *Server) broadcastPositionsL() {
	type pl struct {
		I   int     `json:"i"`
		N   string  `json:"n"`
		X   float64 `json:"x"`
		Y   float64 `json:"y"`
		Z   float64 `json:"z"`
		A   float64 `json:"a"`
		B   float64 `json:"b"`
		Bot bool    `json:"bot,omitempty"`
		C   int     `json:"c"`
		H   int     `json:"h,omitempty"`
		S   int     `json:"s,omitempty"`
	}
	r := func(v float64) float64 { return math.Round(v*100) / 100 }
	var l []pl
	all := []*Player{s.bot.p}
	for _, p := range s.players {
		all = append(all, p)
	}
	for _, p := range all {
		l = append(l, pl{p.id, p.name, r(p.x), r(p.y), r(p.z), r(p.yaw), r(p.pitch), p.bot, p.color, p.held, p.anim})
	}
	s.broadcastL(map[string]any{"t": "p", "l": l, "m": s.mobs.snapshotL(), "it": s.itemsSnapshotL()}, -1)
}

func (s *Server) housekeeping() {
	s.mu.Lock()
	for _, p := range s.players {
		if sv := s.w.meta.Players[p.name]; sv != nil {
			sv.X, sv.Y, sv.Z, sv.Yaw = p.x, p.y, p.z, p.yaw
			sv.LastSeen = time.Now().Unix()
		}
	}
	type pos struct{ x, z, v int }
	var ps []pos
	for _, p := range s.players {
		ps = append(ps, pos{floorDiv(int(p.x), CX), floorDiv(int(p.z), CZ), p.view + 3})
	}
	bx, bz := floorDiv(int(s.bot.p.x), CX), floorDiv(int(s.bot.p.z), CZ)
	ps = append(ps, pos{bx, bz, 3})
	s.w.Save()
	s.mu.Unlock()
	s.w.Unload(func(cx, cz int) bool {
		for _, p := range ps {
			if iabs(cx-p.x) <= p.v && iabs(cz-p.z) <= p.v {
				return true
			}
		}
		return false
	})
}

func (s *Server) Shutdown() {
	s.mu.Lock()
	for _, p := range s.players {
		if sv := s.w.meta.Players[p.name]; sv != nil {
			sv.X, sv.Y, sv.Z, sv.Yaw = p.x, p.y, p.z, p.yaw
			sv.LastSeen = time.Now().Unix()
		}
	}
	s.w.Save()
	s.mu.Unlock()
}
