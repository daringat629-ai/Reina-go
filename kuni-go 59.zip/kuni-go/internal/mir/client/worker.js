"use strict";
// Mesher + light engine. Runs in a Web Worker so the game never stutters while chunks build.
const CY = 128;
let I = null; // block info arrays
const chunks = new Map();
const K = (x, z) => x + "," + z;

onmessage = (e) => {
  const m = e.data;
  if (m.t === "info") I = m;
  else if (m.t === "chunk") chunks.set(K(m.cx, m.cz), new Uint8Array(m.b));
  else if (m.t === "drop") chunks.delete(K(m.cx, m.cz));
  else if (m.t === "set") {
    const c = chunks.get(K(Math.floor(m.x / 16), Math.floor(m.z / 16)));
    if (c) c[(m.y * 16 + (m.z & 15)) * 16 + (m.x & 15)] = m.id;
  } else if (m.t === "mesh") {
    if (!I || !chunks.has(K(m.cx, m.cz))) { postMessage({ t: "mesh", cx: m.cx, cz: m.cz, seq: m.seq, none: true }); return; }
    const out = mesh(m.cx, m.cz);
    out.t = "mesh"; out.seq = m.seq;
    const tr = [];
    for (const l of [out.solid, out.trans]) for (const b of l) tr.push(b.v.buffer, b.i.buffer);
    postMessage(out, tr);
  }
};

const RW = 48;
let regB = null, regS = null, regL = null, regH = 0;
let queue = new Int32Array(1 << 16);

function mesh(cx, cz) {
  const { opaque, liquid, cross, trans, glassy, light, tt, ts, tb, special, atten } = I;
  // ---------- gather a 3x3 chunk region
  let H = 0;
  const N = [];
  for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) N.push(chunks.get(K(cx + dx, cz + dz)) || null);
  for (const c of N) {
    if (!c) continue;
    for (let y = CY - 1; y > H; y--) {
      const o = y * 256;
      let any = false;
      for (let i = 0; i < 256; i++) if (c[o + i]) { any = true; break; }
      if (any) { H = y; break; }
    }
  }
  H = Math.min(CY, H + 3);
  const S = RW * RW * H;
  if (!regB || regB.length < S) { regB = new Uint8Array(S); regS = new Uint8Array(S); regL = new Uint8Array(S); }
  regH = H;
  const R = regB, SK = regS, BL = regL;
  for (let n = 0; n < 9; n++) {
    const c = N[n], bx = (n % 3) * 16, bz = Math.floor(n / 3) * 16;
    for (let y = 0; y < H; y++) for (let z = 0; z < 16; z++) {
      const ro = (y * RW + bz + z) * RW + bx, co = (y * 16 + z) * 16;
      if (c) for (let x = 0; x < 16; x++) R[ro + x] = c[co + x];
      else for (let x = 0; x < 16; x++) R[ro + x] = 255;
    }
  }
  const OPQ = (id) => id === 255 || opaque[id] === 1;
  // ---------- sky light: straight down, then flood sideways
  SK.fill(0, 0, S); BL.fill(0, 0, S);
  const top = new Int16Array(RW * RW);
  for (let z = 0; z < RW; z++) for (let x = 0; x < RW; x++) {
    let l = 15, t = H;
    for (let y = H - 1; y >= 0; y--) {
      const i = (y * RW + z) * RW + x, id = R[i];
      if (OPQ(id)) { l = 0; }
      else if (atten[id]) { l = Math.max(0, l - atten[id]); }
      if (l === 15) t = y;
      SK[i] = l;
      if (l === 0) break;
    }
    top[z * RW + x] = t;
  }
  let qh = 0, qt = 0;
  const push = (i) => { if (qt >= queue.length) { const nq = new Int32Array(queue.length * 2); nq.set(queue); queue = nq; } queue[qt++] = i; };
  for (let z = 1; z < RW - 1; z++) for (let x = 1; x < RW - 1; x++) {
    const t = top[z * RW + x];
    const m = Math.max(top[z * RW + x - 1], top[z * RW + x + 1], top[(z - 1) * RW + x], top[(z + 1) * RW + x]);
    for (let y = t; y < m && y < H; y++) push((y * RW + z) * RW + x);
  }
  flood(SK, push, qh, () => qt, (v) => (qh = v));
  // ---------- block light
  qh = 0; qt = 0;
  for (let i = 0; i < S; i++) { const id = R[i]; if (id !== 255 && light[id]) { BL[i] = light[id]; push(i); } }
  flood(BL, push, qh, () => qt, (v) => (qh = v));

  function flood(A, push, h0, getT, setH) {
    let h = h0;
    const L = RW * RW;
    while (h < getT()) {
      const i = queue[h++];
      const l = A[i];
      if (l <= 1) continue;
      const x = i % RW, z = Math.floor(i / RW) % RW, y = Math.floor(i / L);
      for (let k = 0; k < 6; k++) {
        let n;
        if (k === 0) { if (x === RW - 1) continue; n = i + 1; }
        else if (k === 1) { if (x === 0) continue; n = i - 1; }
        else if (k === 2) { if (z === RW - 1) continue; n = i + RW; }
        else if (k === 3) { if (z === 0) continue; n = i - RW; }
        else if (k === 4) { if (y === H - 1) continue; n = i + L; }
        else { if (y === 0) continue; n = i - L; }
        const id = R[n];
        if (OPQ(id)) continue;
        const nl = l - 1 - (atten[id] || 0);
        if (A[n] < nl) { A[n] = nl; push(n); }
      }
    }
    setH(h);
  }

  // ---------- meshing
  const solid = [], transL = [];
  let minY = CY, maxY = 0;
  const newB = () => ({ v: new Float32Array(9 * 4 * 2048), i: new Uint16Array(6 * 2048), nv: 0, ni: 0 });
  const curB = (list) => {
    let b = list[list.length - 1];
    if (!b || b.nv + 8 > 65000) { b = newB(); list.push(b); }
    if ((b.nv + 8) * 9 > b.v.length) { const nv = new Float32Array(b.v.length * 2); nv.set(b.v); b.v = nv; }
    if (b.ni + 12 > b.i.length) { const ni = new Uint16Array(b.i.length * 2); ni.set(b.i); b.i = ni; }
    return b;
  };
  const vtx = (b, x, y, z, u, v, sh, sk, bl, fl) => { const o = b.nv * 9, V = b.v; V[o] = x; V[o + 1] = y; V[o + 2] = z; V[o + 3] = u; V[o + 4] = v; V[o + 5] = sh; V[o + 6] = sk; V[o + 7] = bl; V[o + 8] = fl; b.nv++; };
  const quadI = (b, flip, both) => {
    const s = b.nv - 4, I2 = b.i;
    if (flip) { I2[b.ni++] = s + 1; I2[b.ni++] = s + 2; I2[b.ni++] = s + 3; I2[b.ni++] = s + 1; I2[b.ni++] = s + 3; I2[b.ni++] = s; }
    else { I2[b.ni++] = s; I2[b.ni++] = s + 1; I2[b.ni++] = s + 2; I2[b.ni++] = s; I2[b.ni++] = s + 2; I2[b.ni++] = s + 3; }
    if (both) { I2[b.ni++] = s; I2[b.ni++] = s + 2; I2[b.ni++] = s + 1; I2[b.ni++] = s; I2[b.ni++] = s + 3; I2[b.ni++] = s + 2; }
  };
  const ATL = 16;
  const uvr = (t) => { const e = 0.0008; const u0 = (t % ATL) / ATL, v0 = Math.floor(t / ATL) / ATL; return [u0 + e, v0 + e, u0 + 1 / ATL - e, v0 + 1 / ATL - e]; };
  const at = (rx, y, rz) => (y < 0 ? 3 : y >= H ? 0 : R[(y * RW + rz) * RW + rx]);
  const skyAt = (rx, y, rz) => (y >= H ? 15 : y < 0 ? 0 : SK[(y * RW + rz) * RW + rx]);
  const blAt = (rx, y, rz) => (y >= H || y < 0 ? 0 : BL[(y * RW + rz) * RW + rx]);
  const FACES = [
    { n: [1, 0, 0], u: [0, 1, 0], v: [0, 0, 1], up: "u", sh: 0.7, tx: 1 },
    { n: [-1, 0, 0], u: [0, 0, 1], v: [0, 1, 0], up: "v", sh: 0.7, tx: 1 },
    { n: [0, 1, 0], u: [0, 0, 1], v: [1, 0, 0], up: null, sh: 1, tx: 0 },
    { n: [0, -1, 0], u: [1, 0, 0], v: [0, 0, 1], up: null, sh: 0.5, tx: 2 },
    { n: [0, 0, 1], u: [1, 0, 0], v: [0, 1, 0], up: "v", sh: 0.84, tx: 1 },
    { n: [0, 0, -1], u: [0, 1, 0], v: [1, 0, 0], up: "u", sh: 0.84, tx: 1 },
  ];
  const CORN = [[-1, -1], [1, -1], [1, 1], [-1, 1]];
  const AOF = [0.45, 0.65, 0.82, 1];
  const ox = cx * 16, oz = cz * 16;
  for (let y = 0; y < H; y++) for (let lz = 0; lz < 16; lz++) for (let lx = 0; lx < 16; lx++) {
    const rx = lx + 16, rz = lz + 16;
    const id = R[(y * RW + rz) * RW + rx];
    if (id === 0 || id === 255) continue;
    if (y < minY) minY = y;
    if (y > maxY) maxY = y;
    const x = ox + lx, z = oz + lz;
    const ownS = skyAt(rx, y, rz) / 15, ownB = Math.max(blAt(rx, y, rz), light[id]) / 15;
    if (special[id] === 1) { // torch: a slim stick
      const r = uvr(ts[id]);
      const b = curB(solid);
      const s0 = 7 / 16, s1 = 9 / 16, hgt = 10 / 16;
      const U = (f) => r[0] + (r[2] - r[0]) * f, Vv = (f) => r[1] + (r[3] - r[1]) * f;
      const sides = [
        [[x + s1, y, z + s0], [x + s1, y, z + s1], [x + s1, y + hgt, z + s1], [x + s1, y + hgt, z + s0], 0.75],
        [[x + s0, y, z + s1], [x + s0, y, z + s0], [x + s0, y + hgt, z + s0], [x + s0, y + hgt, z + s1], 0.75],
        [[x + s0, y, z + s0], [x + s1, y, z + s0], [x + s1, y + hgt, z + s0], [x + s0, y + hgt, z + s0], 0.85],
        [[x + s1, y, z + s1], [x + s0, y, z + s1], [x + s0, y + hgt, z + s1], [x + s1, y + hgt, z + s1], 0.85],
      ];
      for (const [p0, p1, p2, p3, sh] of sides) {
        const bb = curB(solid);
        vtx(bb, ...p0, U(s0), Vv(1), sh, ownS, 1, 0); vtx(bb, ...p1, U(s1), Vv(1), sh, ownS, 1, 0);
        vtx(bb, ...p2, U(s1), Vv(6 / 16), sh, ownS, 1, 0); vtx(bb, ...p3, U(s0), Vv(6 / 16), sh, ownS, 1, 0);
        quadI(bb, false, false);
      }
      const bb = curB(solid);
      vtx(bb, x + s0, y + hgt, z + s0, U(s0), Vv(6 / 16), 1, ownS, 1, 0); vtx(bb, x + s0, y + hgt, z + s1, U(s0), Vv(8 / 16), 1, ownS, 1, 0);
      vtx(bb, x + s1, y + hgt, z + s1, U(s1), Vv(8 / 16), 1, ownS, 1, 0); vtx(bb, x + s1, y + hgt, z + s0, U(s1), Vv(6 / 16), 1, ownS, 1, 0);
      quadI(bb, false, false);
      continue;
    }
    if (cross[id]) {
      const r = uvr(ts[id]);
      const j = ((x * 73856093) ^ (z * 19349663)) >>> 0;
      const jx = ((j & 15) / 15 - 0.5) * 0.3, jz = (((j >> 4) & 15) / 15 - 0.5) * 0.3;
      const q = [[0.15, 0.15, 0.85, 0.85], [0.85, 0.15, 0.15, 0.85]];
      for (const [ax, az, bx, bz] of q) {
        const b = curB(solid);
        vtx(b, x + ax + jx, y, z + az + jz, r[0], r[3], 0.9, ownS, ownB, 4);
        vtx(b, x + bx + jx, y, z + bz + jz, r[2], r[3], 0.9, ownS, ownB, 4);
        vtx(b, x + bx + jx, y + 1, z + bz + jz, r[2], r[1], 0.9, ownS, ownB, 3);
        vtx(b, x + ax + jx, y + 1, z + az + jz, r[0], r[1], 0.9, ownS, ownB, 3);
        quadI(b, false, true);
      }
      continue;
    }
    const isLiq = liquid[id] === 1, isGlassy = glassy[id] === 1, isTrans = trans[id] === 1;
    const isLava = isLiq && light[id] > 0;
    const list = (isLiq && !isLava) || isGlassy ? transL : solid;
    const leafy = isTrans && !isLiq && !isGlassy && atten[id] === 1;
    const aboveLiq = isLiq && at(rx, y + 1, rz) === id;
    for (let f = 0; f < 6; f++) {
      const F = FACES[f];
      const nrx = rx + F.n[0], ny = y + F.n[1], nrz = rz + F.n[2];
      const nid = at(nrx, ny, nrz);
      let show;
      if (isLiq) show = nid !== id && nid !== 255 && !OPQ(nid) && !(liquid[nid] && F.n[1] !== 1);
      else if (isTrans) show = nid !== 255 && !OPQ(nid) && (nid !== id || leafy);
      else show = !OPQ(nid);
      if (!show) continue;
      const b = curB(list);
      const tex = F.tx === 0 ? tt[id] : F.tx === 1 ? ts[id] : tb[id];
      const r = uvr(tex);
      const ao = [3, 3, 3, 3];
      for (let k = 0; k < 4; k++) {
        const su = CORN[k][0], sv = CORN[k][1];
        let px = x + 0.5 + F.n[0] * 0.5 + F.u[0] * su * 0.5 + F.v[0] * sv * 0.5;
        let py = y + 0.5 + F.n[1] * 0.5 + F.u[1] * su * 0.5 + F.v[1] * sv * 0.5;
        let pz = z + 0.5 + F.n[2] * 0.5 + F.u[2] * su * 0.5 + F.v[2] * sv * 0.5;
        let flag = 0;
        if (isLiq && !aboveLiq && py > y + 0.5) { py = y + 0.875; flag = isLava ? 5 : 1; }
        else if (isLava) flag = 5;
        if (leafy) flag = 2;
        let sh = F.sh, sk, bl;
        // smooth light + ambient occlusion from the 4 cells touching this corner
        const ux = F.u[0] * su, uy = F.u[1] * su, uz = F.u[2] * su, vx = F.v[0] * sv, vy = F.v[1] * sv, vz = F.v[2] * sv;
        const c0 = [nrx, ny, nrz], c1 = [nrx + ux, ny + uy, nrz + uz], c2 = [nrx + vx, ny + vy, nrz + vz], c3 = [nrx + ux + vx, ny + uy + vy, nrz + uz + vz];
        const o1 = OPQ(at(...c1)), o2 = OPQ(at(...c2)), o3 = OPQ(at(...c3));
        if (!isLiq && !isTrans) {
          const a = o1 && o2 ? 0 : 3 - (o1 + o2 + o3);
          ao[k] = a; sh *= AOF[a];
        }
        let ss = skyAt(...c0), bs = blAt(...c0), cnt = 1;
        if (OPQ(at(...c0))) { ss = 0; bs = 0; cnt = 0; }
        if (!o1) { ss += skyAt(...c1); bs += blAt(...c1); cnt++; }
        if (!o2) { ss += skyAt(...c2); bs += blAt(...c2); cnt++; }
        if (!o3 && !(o1 && o2)) { ss += skyAt(...c3); bs += blAt(...c3); cnt++; }
        if (cnt === 0) { sk = ownS; bl = ownB; } else { sk = ss / cnt / 15; bl = bs / cnt / 15; }
        if (light[id]) bl = 1;
        let tu, tv;
        if (F.up === "u") { tv = su > 0 ? r[1] : r[3]; tu = sv > 0 ? r[2] : r[0]; }
        else if (F.up === "v") { tv = sv > 0 ? r[1] : r[3]; tu = su > 0 ? r[2] : r[0]; }
        else { tu = su > 0 ? r[2] : r[0]; tv = sv > 0 ? r[3] : r[1]; }
        vtx(b, px, py, pz, tu, tv, sh, sk, bl, flag);
      }
      quadI(b, ao[0] + ao[2] < ao[1] + ao[3], isLiq && F.n[1] === 1);
    }
  }
  const pack = (l) => l.filter((b) => b.nv > 0).map((b) => ({ v: b.v.slice(0, b.nv * 9), i: b.i.slice(0, b.ni) }));
  return { cx, cz, solid: pack(solid), trans: pack(transL), minY, maxY: maxY + 1 };
}
