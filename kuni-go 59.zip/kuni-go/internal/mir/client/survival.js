/* ================================================================== SURVIVAL */
const GM={mode:'creative',forced:false};
const SV={inv:new Array(36).fill(null),arm:new Array(4).fill(null),hp:20,food:20,sat:5,exh:0,air:10,dead:false,inv0:0,regenT:0,starveT:0,envT:0,fallTop:null,dirty:false,saveT:0,flash:0,atkCd:0,mine:null,eatCd:0,placeCd:0,lastAtk:0,wasGround:true,cursor:null,chest:null,station:{table:false,furnace:false}};
const ITEMS=[]; const IBN={};
const isSurv=()=>GM.mode==='survival';
function itemDef(id){ if(id>=256) return ITEMS[id-256]||{id,name:'?',label:'?',stack:64}; const b=W.blocks[id]; return b?{id,name:b.name,label:b.label,stack:64,block:true}:{id,name:'?',label:'?',stack:64}; }
function itemTile(id){ if(id>=256) return itemDef(id).name; const b=W.blocks[id]; return b?(b.cross?b.side:b.side):''; }
const iid=n=>IBN[n]??W.byName[n]??0;
function initItems(list){ ITEMS.length=0; for(const it of list||[]){ ITEMS[it.id-256]=it; IBN[it.name]=it.id; } }

/* ---------------- inventory helpers */
function maxStack(id){ return itemDef(id).stack||64; }
function addItem(i,n,d=0){
  const st=maxStack(i);
  if(st>1) for(const order of [[0,9],[9,36]]) for(let k=order[0];k<order[1]&&n>0;k++){ const s=SV.inv[k]; if(s&&s.i===i&&s.n<st&&!s.d){ const m=Math.min(n,st-s.n); s.n+=m; n-=m; } }
  for(const order of [[0,9],[9,36]]) for(let k=order[0];k<order[1]&&n>0;k++){ if(!SV.inv[k]){ const m=Math.min(n,st); SV.inv[k]={i,n:m,d}; n-=m; } }
  invChanged(); return n; }
function countItem(test){ let c=0; for(const s of SV.inv) if(s&&test(s.i)) c+=s.n; return c; }
function takeItem(test,n){ for(let k=SV.inv.length-1;k>=0&&n>0;k--){ const s=SV.inv[k]; if(s&&test(s.i)){ const m=Math.min(n,s.n); s.n-=m; n-=m; if(s.n<=0) SV.inv[k]=null; } } invChanged(); return n===0; }
function held(){ return isSurv()?SV.inv[sel]:(hotbar[sel]?{i:hotbar[sel],n:64,d:0}:null); }
function useHeld(n=1){ if(!isSurv()) return; const s=SV.inv[sel]; if(!s) return; s.n-=n; if(s.n<=0) SV.inv[sel]=null; invChanged(); }
function wearHeld(k=1){ if(!isSurv()) return; const s=SV.inv[sel]; if(!s) return; const d=itemDef(s.i); if(!d.dur) return; s.d=(s.d||0)+k; if(s.d>=d.dur){ SV.inv[sel]=null; sfx('break',W.byName.planks||1,1); toast('💥 '+d.label+' сломался'); } invChanged(); }
function invChanged(){ SV.dirty=true; if(isSurv()){ for(let i=0;i<9;i++) hotbar[i]=SV.inv[i]?SV.inv[i].i:0; buildHot(); if($('sinv').style.display==='grid') renderSInv(); } }
function armorDef(){ let d=0; for(const a of SV.arm) if(a) d+=itemDef(a.i).def||0; return d; }

/* ---------------- block rules: tools, time, drops */
function blockTool(name){
  if(/^(stone|cobble|.*_ore|.*brick.*|sandstone|furnace|obsidian|.*_block|terracotta.*|quartz.*|prismarine|granite|diorite|andesite|amethyst|mossy|concrete_.*|sea_lantern|glowstone|lamp)$/.test(name)&&name!=='lantern_block') return 'pickaxe';
  if(/log|planks|bookshelf|crafting_table|chest|pumpkin|melon|jack_o_lantern|ladder|lantern_block/.test(name)) return 'axe';
  if(/^(dirt|grass|sand|red_sand|gravel|snow|snow_grass|clay|farmland|podzol|moss)$/.test(name)) return 'shovel';
  return ''; }
function needTier(name){ if(name==='obsidian') return 4; if(/^(gold_ore|diamond_ore|emerald_ore|redstone_ore|diamond_block|gold_block|emerald_block)$/.test(name)) return 3; if(/^(iron_ore|copper_ore|lapis_ore|iron_block|copper_block|lapis_block)$/.test(name)) return 2; return blockTool(name)==='pickaxe'?1:0; }
function breakInfo(id){
  const b=W.blocks[id]; const h=held(); const d=h?itemDef(h.i):{};
  const tool=blockTool(b.name), tier=d.tool===tool?d.tier||0:0;
  const can=needTier(b.name)<=tier||needTier(b.name)===0;
  let speed=d.tool&&d.tool===tool?[1,2,4,6,8][d.tier||0]:1;
  if(b.name==='cobweb'&&d.tool==='sword') speed=15;
  if(d.tool==='sword'&&/leaves/.test(b.name)) speed=1.5;
  let t=b.hard*(can?1.5:5)/speed; if(P.inWater) t*=3; if(!P.onGround&&!P.fly) t*=2;
  return {time:Math.max(0,t),can,usesTool:!!(d.tool&&d.tool===tool)}; }
function dropsFor(id,can){
  const n=W.blocks[id].name, r=Math.random(), R=(a,b)=>a+Math.floor(Math.random()*(b-a+1));
  if(!can) return [];
  switch(n){
  case 'grass': case 'farmland': case 'snow_grass': case 'podzol': return [[iid('dirt'),1]];
  case 'stone': return [[iid('cobble'),1]];
  case 'coal_ore': return [[iid('coal'),1]]; case 'diamond_ore': return [[iid('diamond'),1]]; case 'emerald_ore': return [[iid('emerald'),1]];
  case 'redstone_ore': return [[iid('redstone'),R(3,5)]]; case 'lapis_ore': return [[iid('lapis'),R(3,6)]];
  case 'glass': case 'ice': case 'packed_ice': case 'water': case 'lava': return [];
  case 'leaves': return r<.06?[[iid('sapling'),1]]:r<.11?[[iid('apple'),1]]:[];
  case 'birch_leaves': case 'spruce_leaves': case 'cherry_leaves': return r<.07?[[iid('sapling'),1]]:[];
  case 'tall_grass': case 'fern': return r<.15?[[iid('seeds'),1]]:[];
  case 'wheat_3': return [[iid('wheat'),1],[iid('seeds'),R(1,2)]];
  case 'wheat_0': case 'wheat_1': case 'wheat_2': return [[iid('seeds'),1]];
  case 'gravel': return r<.12?[[iid('flint'),1]]:[[id,1]];
  case 'dead_bush': return [[iid('stick'),R(0,2)]];
  case 'cobweb': return [[iid('string'),1]];
  case 'bookshelf': return [[iid('planks'),3]];
  case 'melon': return [[iid('melon'),1]];
  case 'glowstone': return [[id,1]];
  }
  if(/^sglass_/.test(n)) return [];
  return [[id,1]]; }

/* ---------------- recipes */
const TAG={ '#planks':n=>/planks$/.test(n), '#log':n=>/(^log$|_log$)/.test(n), '#wool':n=>/^wool_/.test(n), '#coal':n=>n==='coal'||n==='charcoal' };
const TAGL={'#planks':'Доски','#log':'Бревно','#wool':'Шерсть','#coal':'Уголь'};
const RECIPES=[];
function R(out,n,ing,st){ RECIPES.push({out,n,ing,st:st||''}); }
function defineRecipes(){
  RECIPES.length=0;
  for(const [l,p] of [['log','planks'],['birch_log','birch_planks'],['spruce_log','spruce_planks'],['cherry_log','cherry_planks']]) R(p,4,{[l]:1});
  R('stick',4,{'#planks':2}); R('crafting_table',1,{'#planks':4}); R('torch',4,{stick:1,'#coal':1});
  R('chest',1,{'#planks':8},'table'); R('furnace',1,{cobble:8},'table'); R('ladder',3,{stick:7},'table'); R('bed',1,{'#wool':3,'#planks':3},'table');
  for(const [m,mat] of [['wood','#planks'],['stone','cobble'],['iron','iron_ingot'],['diamond','diamond']]){
    R(m+'_pickaxe',1,{[mat]:3,stick:2},'table'); R(m+'_axe',1,{[mat]:3,stick:2},'table'); R(m+'_shovel',1,{[mat]:1,stick:2},'table'); R(m+'_sword',1,{[mat]:2,stick:1},'table'); R(m+'_hoe',1,{[mat]:2,stick:2},'table'); }
  for(const [m,mat] of [['leather','leather'],['iron','iron_ingot'],['diamond','diamond']]){ R(m+'_helmet',1,{[mat]:5},'table'); R(m+'_chestplate',1,{[mat]:8},'table'); R(m+'_leggings',1,{[mat]:7},'table'); R(m+'_boots',1,{[mat]:4},'table'); }
  R('bread',1,{wheat:3}); R('hay',1,{wheat:9}); R('wheat',9,{hay:1}); R('mushroom_stew',1,{mushroom_red:1,mushroom_brown:1}); R('golden_apple',1,{apple:1,gold_ingot:8},'table');
  R('bone_meal',3,{bone:1}); R('wool_white',1,{string:4}); R('tnt',1,{gunpowder:5,sand:4},'table'); R('sandstone',1,{sand:4}); R('stone_bricks',4,{stone:4}); R('mossy',1,{cobble:1,moss:1});
  R('lamp',1,{torch:2,glass:1},'table'); R('lantern_block',1,{torch:1,string:2,'#planks':1}); R('jack_o_lantern',1,{pumpkin:1,torch:1}); R('bookshelf',1,{'#planks':6,leather:3},'table');
  R('snow_bricks',4,{snow:4}); R('glowstone',1,{redstone:4,torch:1},'table');
  for(const [b,i] of [['iron_block','iron_ingot'],['gold_block','gold_ingot'],['diamond_block','diamond'],['emerald_block','emerald'],['lapis_block','lapis'],['copper_block','copper_ingot']]){ R(b,1,{[i]:9},'table'); R(i,9,{[b]:1}); }
  for(const [a,b] of [['iron_ore','iron_ingot'],['gold_ore','gold_ingot'],['copper_ore','copper_ingot'],['sand','glass'],['red_sand','glass'],['cobble','stone'],['#log','charcoal'],['porkchop','cooked_porkchop'],['beef','steak'],['chicken','cooked_chicken'],['mutton','cooked_mutton'],['clay','brick'],['stone','stone_bricks']]) R(b,1,{[a]:1},'furnace');
}
const ingTest=k=>k[0]==='#'?(id=>TAG[k](itemDef(id).name)):(id=>id===iid(k));
const ingLabel=k=>k[0]==='#'?TAGL[k]:itemDef(iid(k)).label;
function hasFuel(){ return countItem(ingTest('#coal'))>=1||countItem(ingTest('#log'))>=1||countItem(ingTest('#planks'))>=2||countItem(id=>id===iid('stick'))>=4; }
function takeFuel(){ if(countItem(ingTest('#coal'))>=1) return takeItem(ingTest('#coal'),1); if(countItem(ingTest('#planks'))>=2) return takeItem(ingTest('#planks'),2); if(countItem(id=>id===iid('stick'))>=4) return takeItem(id=>id===iid('stick'),4); return takeItem(ingTest('#log'),1); }
function canCraft(r){ if(r.st==='table'&&!SV.station.table) return false; if(r.st==='furnace'&&(!SV.station.furnace||!hasFuel())) return false;
  for(const [k,n] of Object.entries(r.ing)){ const need=n+(r.st==='furnace'&&k==='#log'&&countItem(ingTest('#coal'))<1&&countItem(ingTest('#planks'))<2?1:0); if(countItem(ingTest(k))<need) return false; } return true; }
function craft(r,times=1){ let done=0; for(let t=0;t<times;t++){ if(!canCraft(r)) break; for(const [k,n] of Object.entries(r.ing)) takeItem(ingTest(k),n); if(r.st==='furnace') takeFuel(); const left=addItem(iid(r.out),r.n); if(left>0) net({t:'drop',i:iid(r.out),n:left,back:1}); done++; }
  if(done){ sfx(r.st==='furnace'?'place':'pop',W.byName.planks); SV.exh+=.05; } return done; }
function scanStations(){ const x0=Math.floor(P.x),y0=Math.floor(P.y),z0=Math.floor(P.z); const t=W.byName.crafting_table, f=W.byName.furnace; let a=false,b=false;
  for(let dx=-4;dx<=4;dx++)for(let dy=-2;dy<=3;dy++)for(let dz=-4;dz<=4;dz++){ const id=getBlock(x0+dx,y0+dy,z0+dz); if(id===t) a=true; if(id===f) b=true; } SV.station={table:a,furnace:b}; }

/* ---------------- survival inventory UI */
let rfilter='all', rsearch='';
function slotEl(s,onclick,cls){ const d=document.createElement('div'); d.className='sl'+(cls?' '+cls:''); if(s&&s.i){ d.appendChild(slotCanvas(s.i)); if(s.n>1){ const n=document.createElement('b'); n.textContent=s.n; d.appendChild(n); } const df=itemDef(s.i); if(df.dur&&s.d){ const bar=document.createElement('u'); const f=1-s.d/df.dur; bar.style.width=(f*80)+'%'; bar.style.background=`hsl(${f*120},80%,50%)`; d.appendChild(bar); } d.title=df.label; }
  d.addEventListener('pointerdown',e=>{ e.preventDefault(); onclick(e.button===2||e.ctrlKey?2:(e.shiftKey?3:0)); }); d.addEventListener('contextmenu',e=>e.preventDefault()); return d; }
function slotClick(arr,k,btn,filter){
  let s=arr[k], c=SV.cursor;
  if(btn===3&&s){ // shift: quick move
    const moveTo=(from,ranges)=>{ for(const [a,b,target] of ranges){ for(let j=a;j<b&&from.n>0;j++){ const t=target[j]; if(t&&t.i===from.i&&t.n<maxStack(t.i)&&!t.d&&!from.d){ const m=Math.min(from.n,maxStack(t.i)-t.n); t.n+=m; from.n-=m; } } for(let j=a;j<b&&from.n>0;j++){ if(!target[j]){ target[j]={...from}; from.n=0; } } } };
    if(arr===SV.arm){ moveTo(s,[[9,36,SV.inv],[0,9,SV.inv]]); }
    else if(SV.chest&&arr===SV.chest.s){ moveTo(s,[[0,9,SV.inv],[9,36,SV.inv]]); }
    else if(SV.chest){ moveTo(s,[[0,27,SV.chest.s]]); }
    else { const d=itemDef(s.i); if(d.slot&&!SV.arm[d.slot-1]){ SV.arm[d.slot-1]={...s}; s.n=0; } else moveTo(s,k<9?[[9,36,SV.inv]]:[[0,9,SV.inv]]); }
    if(s.n<=0) arr[k]=null; afterSlots(arr); return; }
  if(filter&&c&&!filter(c.i)) return;
  if(btn===2){ if(!c&&s){ const h=Math.ceil(s.n/2); SV.cursor={...s,n:h}; s.n-=h; if(s.n<=0) arr[k]=null; }
    else if(c&&(!s||(s.i===c.i&&s.n<maxStack(s.i)&&!s.d&&!c.d))){ if(!s) arr[k]={i:c.i,n:1,d:c.d}; else s.n++; c.n--; if(c.n<=0) SV.cursor=null; } }
  else { if(!c){ SV.cursor=s; arr[k]=null; }
    else if(!s){ arr[k]=c; SV.cursor=null; }
    else if(s.i===c.i&&maxStack(s.i)>1&&!s.d&&!c.d){ const m=Math.min(c.n,maxStack(s.i)-s.n); s.n+=m; c.n-=m; if(c.n<=0) SV.cursor=null; }
    else { arr[k]=c; SV.cursor=s; } }
  afterSlots(arr); }
function afterSlots(arr){ if(SV.chest&&arr===SV.chest.s) net({t:'chestput',x:SV.chest.x,y:SV.chest.y,z:SV.chest.z,s:SV.chest.s.map(s=>s?[s.i,s.n,s.d||0]:[0,0,0])}); invChanged(); renderSInv(); }
function renderSInv(){
  const box=$('sinvL'); box.innerHTML='';
  const row=(title)=>{ const h=document.createElement('div'); h.className='sh'; h.textContent=title; box.appendChild(h); };
  if(SV.chest){ row('Сундук'); const g=document.createElement('div'); g.className='sg'; SV.chest.s.forEach((s,k)=>g.appendChild(slotEl(s,b=>slotClick(SV.chest.s,k,b)))); box.appendChild(g); }
  const top=document.createElement('div'); top.className='armrow';
  const al=['Шлем','Нагрудник','Поножи','Ботинки'];
  SV.arm.forEach((s,k)=>{ const e=slotEl(s,b=>slotClick(SV.arm,k,b,id=>itemDef(id).slot===k+1),'arm'); if(!s){ const t=document.createElement('i'); t.textContent=al[k]; e.appendChild(t); } top.appendChild(e); });
  const st=document.createElement('div'); st.className='stat'; st.innerHTML=`❤ ${Math.ceil(SV.hp)}/20 &nbsp; 🍗 ${Math.ceil(SV.food)}/20 &nbsp; 🛡 ${armorDef()}`; top.appendChild(st);
  if(!SV.chest) box.appendChild(top);
  row('Рюкзак'); const g=document.createElement('div'); g.className='sg'; for(let k=9;k<36;k++) g.appendChild(slotEl(SV.inv[k],b=>slotClick(SV.inv,k,b))); box.appendChild(g);
  row('Под рукой'); const h=document.createElement('div'); h.className='sg'; for(let k=0;k<9;k++) h.appendChild(slotEl(SV.inv[k],b=>slotClick(SV.inv,k,b),k===sel?'cur':'')); box.appendChild(h);
  const tr=document.createElement('div'); tr.className='row'; tr.style.marginTop='10px';
  const bt=document.createElement('button'); bt.className='sec'; bt.textContent='🗑 Выбросить то, что в руке'; bt.onclick=()=>{ if(SV.cursor){ net({t:'drop',i:SV.cursor.i,n:SV.cursor.n,d:SV.cursor.d||0}); SV.cursor=null; renderSInv(); } else toast('Сначала возьми предмет из ячейки'); }; tr.appendChild(bt); box.appendChild(tr);
  // recipes
  const rb=$('sinvR'); rb.innerHTML='';
  if(SV.chest){ rb.style.display='none'; } else { rb.style.display='';
    const hd=document.createElement('div'); hd.className='sh'; hd.textContent='Создание'+(SV.station.table?' · верстак ✔':'')+(SV.station.furnace?' · печь ✔':''); rb.appendChild(hd);
    const tools=document.createElement('div'); tools.className='rtools';
    const inp=document.createElement('input'); inp.placeholder='Поиск рецепта…'; inp.value=rsearch; inp.oninput=()=>{ rsearch=inp.value; renderSInv(); setTimeout(()=>{ const i=$('sinvR').querySelector('input'); if(i){ i.focus(); i.setSelectionRange(i.value.length,i.value.length);} },0); }; inp.addEventListener('keydown',e=>{ e.stopPropagation(); if(e.key==='Escape') closePanels(); });
    tools.appendChild(inp);
    for(const [k,l] of [['all','Все'],['can','Могу'],['furnace','Печь']]){ const b=document.createElement('button'); b.textContent=l; b.className='pill'+(rfilter===k?' on':''); b.onclick=()=>{ rfilter=k; renderSInv(); }; tools.appendChild(b); }
    rb.appendChild(tools);
    if(!SV.station.table) { const n=document.createElement('div'); n.className='note'; n.textContent='Поставь верстак рядом, чтобы открыть больше рецептов (инструменты, сундук, печь…).'; rb.appendChild(n); }
    const list=document.createElement('div'); list.className='rlist';
    const q=rsearch.trim().toLowerCase();
    const arr=RECIPES.map(r=>({r,ok:canCraft(r)})).filter(({r,ok})=>{ if(!iid(r.out)) return false; if(rfilter==='can'&&!ok) return false; if(rfilter==='furnace'&&r.st!=='furnace') return false; if(rfilter!=='furnace'&&r.st==='furnace'&&!SV.station.furnace&&rfilter!=='all') return false; if(q&&!itemDef(iid(r.out)).label.toLowerCase().includes(q)) return false; return true; });
    arr.sort((a,b)=>(b.ok-a.ok));
    for(const {r,ok} of arr){ const d=document.createElement('button'); d.className='rec'+(ok?' ok':''); d.appendChild(slotCanvas(iid(r.out)));
      const t=document.createElement('div'); const nm=document.createElement('b'); nm.textContent=itemDef(iid(r.out)).label+(r.n>1?' ×'+r.n:''); t.appendChild(nm);
      const ig=document.createElement('small'); ig.textContent=Object.entries(r.ing).map(([k,n])=>n+'× '+ingLabel(k)).join(', ')+(r.st==='table'?' · верстак':r.st==='furnace'?' · печь + топливо':''); t.appendChild(ig); d.appendChild(t);
      d.onclick=e=>{ const c=craft(r,e.shiftKey?16:1); if(!c) toast(r.st==='table'&&!SV.station.table?'Нужен верстак рядом':r.st==='furnace'&&!SV.station.furnace?'Нужна печь рядом':r.st==='furnace'&&!hasFuel()?'Нужно топливо: уголь, доски или бревно':'Не хватает материалов'); renderSInv(); };
      list.appendChild(d); }
    rb.appendChild(list); }
  const cur=$('cursor'); cur.innerHTML=''; if(SV.cursor){ cur.appendChild(slotCanvas(SV.cursor.i)); if(SV.cursor.n>1){ const b=document.createElement('b'); b.textContent=SV.cursor.n; cur.appendChild(b); } cur.style.display='block'; } else cur.style.display='none';
}
document.addEventListener('pointermove',e=>{ const c=$('cursor'); if(c){ c.style.left=e.clientX+'px'; c.style.top=e.clientY+'px'; } });
function openSInv(chest){ SV.chest=chest||null; scanStations(); openPanel('sinv'); renderSInv(); }
function closeSInv(){ if(SV.cursor){ const left=addItem(SV.cursor.i,SV.cursor.n,SV.cursor.d); if(left) net({t:'drop',i:SV.cursor.i,n:left,d:SV.cursor.d||0}); SV.cursor=null; } SV.chest=null; $('cursor').style.display='none'; }

/* ---------------- HUD: hearts, hunger, armour, air */
const hudc=$('shud'), hctx=hudc.getContext('2d');
const HEART=['.XX.XX.','XXXXXXX','XXXXXXX','.XXXXX.','..XXX..','...X...'];
const LEG=['...XXX','..XXXX','..XXXX','.XXX..','X.X...','XX....'];
const SHIELD=['XXXXXXX','XXXXXXX','XXXXXXX','.XXXXX.','..XXX..'];
function pix(pat,x,y,s,col,half){ hctx.fillStyle=col; pat.forEach((row,j)=>{ for(let i=0;i<row.length;i++) if(row[i]==='X'&&(!half||i<row.length/2)) hctx.fillRect(x+i*s,y+j*s,s,s); }); }
let hudKey='';
function drawHud(){
  const key=[Math.ceil(SV.hp),Math.ceil(SV.food),armorDef(),Math.ceil(SV.air),P.headWater?1:0,SV.flash>0?1:0].join();
  if(key===hudKey&&!(SV.hp<=4)) return; hudKey=key;
  const s=2, W2=hudc.width; hctx.clearRect(0,0,W2,hudc.height);
  const shake=SV.hp<=4?()=>Math.round(Math.random()*2-1):()=>0;
  const hp=Math.ceil(SV.hp), fd=Math.ceil(SV.food), ar=armorDef();
  for(let i=0;i<10;i++){ const x=i*17, y=22+shake(); pix(HEART,x,y,s,'#2a0a12'); if(hp>=i*2+2) pix(HEART,x,y,s,SV.flash>0?'#ffb3bf':'#ff3355'); else if(hp===i*2+1) pix(HEART,x,y,s,'#ff3355',true); }
  for(let i=0;i<10;i++){ const x=W2-14-i*17, y=22; pix(LEG,x,y,s,'#2a1a0a'); if(fd>=i*2+2) pix(LEG,x,y,s,'#e0a050'); else if(fd===i*2+1) pix(LEG,x+6,y,s,'#e0a050'); }
  if(ar>0) for(let i=0;i<10;i++){ const x=i*17, y=4; pix(SHIELD,x,y,s,'#222a33'); if(ar>=i*2+1) pix(SHIELD,x,y,s,'#c9d3df',ar===i*2+1); }
  if(P.headWater&&!P.headLava||SV.air<10) for(let i=0;i<10;i++){ if(SV.air>i){ hctx.fillStyle='#6cc6ff'; hctx.beginPath(); hctx.arc(W2-8-i*17,10,6,0,7); hctx.fill(); hctx.fillStyle='#fff'; hctx.fillRect(W2-11-i*17,6,2,2); } }
}

/* ---------------- damage, death */
function damage(amount,cause,kx=0,kz=0){
  if(!isSurv()||SV.dead||amount<=0) return;
  if(SV.inv0>0&&amount<50) return;
  const def=armorDef(); amount=amount*(1-Math.min(20,def)*.04);
  for(let k=0;k<4;k++){ const a=SV.arm[k]; if(!a) continue; a.d=(a.d||0)+1; if(a.d>=itemDef(a.i).dur){ SV.arm[k]=null; toast('💥 '+itemDef(a.i).label+' сломался'); } }
  SV.hp=Math.max(0,SV.hp-amount); SV.inv0=.5; SV.flash=.35; SV.exh+=.1; SV.dirty=true;
  if(kx||kz){ P.vx+=kx*7; P.vz+=kz*7; P.vy=Math.max(P.vy,5.5); }
  sfx('hurt'); $('hurt').style.opacity=.55; setTimeout(()=>$('hurt').style.opacity=0,180);
  if(SV.hp<=0) die(cause); }
function die(cause){
  if(SV.dead) return; SV.dead=true; P.fly=false;
  net({t:'die',cause:cause||'погиб',inv:SV.inv.map(s=>s?[s.i,s.n,s.d||0]:[0,0,0]),arm:SV.arm.map(s=>s?[s.i,s.n,s.d||0]:[0,0,0])});
  SV.inv.fill(null); SV.arm.fill(null); invChanged();
  $('deadmsg').textContent='Ты '+(cause||'погиб'); closePanels(true); $('dead').style.display='grid'; if(document.pointerLockElement) document.exitPointerLock(); }
function respawn(){ $('dead').style.display='none'; SV.dead=false; SV.hp=20; SV.food=20; SV.sat=5; SV.air=10; SV.exh=0; SV.fallTop=null; P.vx=P.vy=P.vz=0; net({t:'respawn'}); saveState(true); if(!touchDevice) canvas.requestPointerLock?.(); }
$('respawn').onclick=respawn;
function saveState(force){ if(!isSurv()) return; if(!force&&!SV.dirty) return; SV.dirty=false; net({t:'state',hp:SV.hp,food:SV.food,sat:SV.sat,inv:SV.inv.map(s=>s?[s.i,s.n,s.d||0]:[0,0,0]),arm:SV.arm.map(s=>s?[s.i,s.n,s.d||0]:[0,0,0])}); }
function loadSurv(sv){ SV.inv=new Array(36).fill(null); SV.arm=new Array(4).fill(null);
  (sv&&sv.inv||[]).forEach((s,k)=>{ if(s&&s.i&&k<36) SV.inv[k]={i:s.i,n:s.n,d:s.d||0}; }); (sv&&sv.arm||[]).forEach((s,k)=>{ if(s&&s.i&&k<4) SV.arm[k]={i:s.i,n:s.n,d:s.d||0}; });
  SV.hp=sv&&sv.hp>0?sv.hp:20; SV.food=sv&&sv.food>0?sv.food:20; SV.sat=sv?sv.sat||0:5; SV.dead=false; SV.air=10; }
function setMode(mode,sv){
  GM.mode=mode; document.body.classList.toggle('surv',mode==='survival');
  if(mode==='survival'){ loadSurv(sv); P.fly=false; $('bFly').classList.remove('on'); invChanged(); hudKey=''; }
  else { const saved=W.savedHot; if(saved) for(let i=0;i<9;i++) hotbar[i]=saved[i]||0; buildHot(); }
}

/* ---------------- interaction */
function mobRay(maxD){
  const ox=P.x,oy=P.y+EYE,oz=P.z; const cp=Math.cos(P.pitch); const dx=-Math.sin(P.yaw)*cp, dy=Math.sin(P.pitch), dz=-Math.cos(P.yaw)*cp;
  let best=null;
  for(const [id,o] of mobs){ const w=o.kind===7?.7:o.kind>=4?.35:o.kind===2?.3:.5, h=MOBH[o.kind]||1;
    const b0=[o.x-w,o.y,o.z-w], b1=[o.x+w,o.y+h,o.z+w]; let t0=0,t1=maxD; const O=[ox,oy,oz], D=[dx,dy,dz]; let ok=true;
    for(let a=0;a<3;a++){ if(Math.abs(D[a])<1e-9){ if(O[a]<b0[a]||O[a]>b1[a]){ ok=false; break; } continue; } let u=(b0[a]-O[a])/D[a], v=(b1[a]-O[a])/D[a]; if(u>v) [u,v]=[v,u]; t0=Math.max(t0,u); t1=Math.min(t1,v); if(t0>t1){ ok=false; break; } }
    if(ok&&(!best||t0<best.t)) best={id,t:t0,o}; }
  return best; }
const MOBH=[1,1.1,.75,1.5,1.95,1.95,1.7,.9];
function attackMob(m){
  const now=performance.now(); if(now-SV.lastAtk<420) return; SV.lastAtk=now; swing=1;
  const h=held(), d=h?itemDef(h.i):{}; let dmg=isSurv()?(d.dmg||1):20;
  if(isSurv()&&!P.onGround&&P.vy<0) dmg*=1.5;
  net({t:'hit',id:m.id,dmg}); sfx('hit'); if(isSurv()){ SV.exh+=.1; if(d.dur) wearHeld(d.tool==='sword'?1:2); }
  const c=m.o; burst(c.x-.5,c.y+.3,c.z-.5,W.byName.wool_red||1,5); }
function blockDist(t){ return Math.hypot(t.x+.5-P.x,t.y+.5-(P.y+EYE),t.z+.5-P.z); }
// returns true if it handled the click as an interaction
function interact(){
  if(!target||P.sneak) return false; const n=W.blocks[target.id].name;
  if(n==='chest'){ net({t:'chest',x:target.x,y:target.y,z:target.z}); return true; }
  if(n==='bed'){ net({t:'sleep',x:target.x,y:target.y,z:target.z}); return true; }
  if(isSurv()&&(n==='crafting_table'||n==='furnace')){ openSInv(); return true; }
  return false; }
function survUse(){
  const h=SV.inv[sel]; const d=h?itemDef(h.i):null;
  if(d&&d.food&&(SV.food<20||d.name==='golden_apple')){ if(SV.eatCd>0) return true; SV.eatCd=.6; SV.food=Math.min(20,SV.food+d.food); SV.sat=Math.min(SV.food,SV.sat+d.sat); if(d.name==='golden_apple') SV.hp=Math.min(20,SV.hp+8); if(d.name==='rotten_flesh'&&Math.random()<.5) SV.exh+=8;
    useHeld(); sfx('eat'); burst(P.x-.5-Math.sin(P.yaw)*.5,P.y+1,P.z-.5-Math.cos(P.yaw)*.5,W.byName.wool_brown||1,6); swing=1; SV.dirty=true; hudKey=''; return true; }
  if(!target||!d) return false;
  const tn=W.blocks[target.id].name;
  if(d.tool==='hoe'&&(tn==='grass'||tn==='dirt')&&getBlock(target.x,target.y+1,target.z)===0){ setBlockLocal(target.x,target.y,target.z,W.byName.farmland); net({t:'set',x:target.x,y:target.y,z:target.z,id:W.byName.farmland}); wearHeld(); sfx('place',target.id); swing=1; return true; }
  if(d.name==='seeds'){ if(tn==='farmland'&&getBlock(target.x,target.y+1,target.z)===0){ const id=W.byName.wheat_0; setBlockLocal(target.x,target.y+1,target.z,id); net({t:'set',x:target.x,y:target.y+1,z:target.z,id}); useHeld(); swing=1; } else toast('Семена сажают на грядку (вспаши землю мотыгой)'); return true; }
  if(d.name==='bone_meal'&&(/^wheat_[012]$/.test(tn)||tn==='sapling')){ net({t:'grow',x:target.x,y:target.y,z:target.z}); useHeld(); swing=1; burst(target.x,target.y,target.z,W.byName.lime||W.byName.wool_lime,8); return true; }
  if(d.slot){ const k=d.slot-1; const old=SV.arm[k]; SV.arm[k]=h; SV.inv[sel]=old; invChanged(); sfx('pop'); toast('Надето: '+d.label); return true; }
  if(!d.block) return true; // items can't be placed
  return false; }

/* ---------------- per-frame survival logic */
let mobTarget=null;
function survFrame(dt,now){
  if(SV.inv0>0) SV.inv0-=dt; if(SV.flash>0) SV.flash-=dt; if(SV.eatCd>0) SV.eatCd-=dt;
  if(SV.dead){ drawHud(); return; }
  // mining
  if(holdBreak&&!mobTarget&&target){ const k=target.x+','+target.y+','+target.z;
    if(!SV.mine||SV.mine.k!==k){ SV.mine={k,p:0,info:breakInfo(target.id),id:target.id,snd:0}; }
    const m=SV.mine; if(m.info.time<=0) m.p=1; else m.p+=dt/m.info.time; m.snd+=dt; if(m.snd>.25){ m.snd=0; sfx('step',target.id,.9); swing=1; }
    if(m.p>=1){ const {x,y,z,id}=target; if(W.blocks[id].hard>=0){ const drops=dropsFor(id,m.info.can); const flat=[]; for(const [i,n] of drops) if(i&&n>0) flat.push(i,n);
        setBlockLocal(x,y,z,0); net({t:'set',x,y,z,id:0,drop:flat}); burst(x,y,z,id); sfx('break',id); SV.exh+=.01; if(m.info.usesTool) wearHeld();
        const up=getBlock(x,y+1,z); if(up!==255&&W.cross[up]) setBlockLocal(x,y+1,z,0); }
      SV.mine=null; } }
  else if(!holdBreak) SV.mine=null;
  if(holdBreak&&mobTarget&&now-lastAct>420){ lastAct=now; attackMob(mobTarget); }
  if(holdPlace&&now-lastAct>260){ lastAct=now; doPlace(); }
  // hunger & regeneration
  const hsp=Math.hypot(P.vx,P.vz); if(P.onGround) SV.exh+=hsp*dt*(P.sprint||keys.ControlLeft?.12:.02);
  if(SV.exh>=4){ SV.exh-=4; if(SV.sat>0) SV.sat=Math.max(0,SV.sat-1); else SV.food=Math.max(0,SV.food-1); SV.dirty=true; }
  SV.regenT+=dt; if(SV.food>=18&&SV.hp<20&&SV.regenT>3){ SV.regenT=0; SV.hp=Math.min(20,SV.hp+1); SV.exh+=3; SV.dirty=true; }
  if(SV.food<=0){ SV.starveT+=dt; if(SV.starveT>4){ SV.starveT=0; if(SV.hp>1) damage(1,'умер от голода'); } }
  // environment
  SV.envT+=dt;
  if(P.inLava&&SV.envT>.5){ SV.envT=0; damage(4,'сгорел в лаве'); }
  const fb=getBlock(Math.floor(P.x),Math.floor(P.y+.5),Math.floor(P.z));
  if(SV.envT>.5){ let cactus=false; const c=W.byName.cactus; for(const [dx,dz] of [[.36,0],[-.36,0],[0,.36],[0,-.36]]) if(getBlock(Math.floor(P.x+dx),Math.floor(P.y+.3),Math.floor(P.z+dz))===c) cactus=true; if(cactus){ SV.envT=0; damage(1,'укололся о кактус'); } }
  if(P.headWater&&!P.headLava){ SV.air-=dt; if(SV.air<=0){ SV.air=0; if(SV.envT>1){ SV.envT=0; damage(2,'утонул'); } } } else SV.air=Math.min(10,SV.air+dt*4);
  // falling
  const onLadder=fb===W.byName.ladder||getBlock(Math.floor(P.x),Math.floor(P.y+1.2),Math.floor(P.z))===W.byName.ladder;
  if(P.onGround||P.inWater||onLadder||P.fly){ if(SV.fallTop!==null&&P.onGround&&!P.inWater&&!onLadder){ const dist=SV.fallTop-P.y; if(dist>3.4) damage(Math.floor(dist-3),dist>12?'разбился насмерть':'упал с высоты'); } SV.fallTop=null; }
  else { if(SV.fallTop===null||P.y>SV.fallTop) SV.fallTop=P.y; }
  if(P.y<-25) die('выпал из мира');
  SV.saveT+=dt; if(SV.saveT>5){ SV.saveT=0; saveState(); }
  drawHud();
}
// ladders: climb when touching one
function ladderPhysics(dt){ const l=W.byName.ladder; if(!l) return; const a=getBlock(Math.floor(P.x),Math.floor(P.y+.3),Math.floor(P.z)), b=getBlock(Math.floor(P.x),Math.floor(P.y+1.2),Math.floor(P.z));
  if(a===l||b===l){ const up=keys.Space||keys.KeyW||wantJump||mv.z<-.3; P.vy=up?3.2:(P.sneak?0:Math.max(P.vy,-2)); } }

/* ---------------- dropped items, arrows, effects */
const ground=new Map(); const shots=[];
function onItems(list){ const seen=new Set(); for(const a of list||[]){ seen.add(a[0]); let e=ground.get(a[0]); if(!e){ e={i:a[1],x:a[2],y:a[3],z:a[4],n:a[5],ph:Math.random()*6}; ground.set(a[0],e); } e.tx=a[2]; e.ty=a[3]; e.tz=a[4]; e.n=a[5]; } for(const id of [...ground.keys()]) if(!seen.has(id)) ground.delete(id); }
function drawGround(vp,dt,T,PW,draw,aP,aU,aL){
  if(!ground.size) return; gl.useProgram(PW.p); gl.enableVertexAttribArray(aP); gl.enableVertexAttribArray(aU); gl.enableVertexAttribArray(aL); gl.uniform1f(PW.u.uCut,.5); gl.disable(gl.CULL_FACE);
  for(const e of ground.values()){ const k=Math.min(1,dt*10); e.x+=(e.tx-e.x)*k; e.y+=(e.ty-e.y)*k; e.z+=(e.tz-e.z)*k; if(Math.hypot(e.x-P.x,e.z-P.z)>48) continue;
    const m=heldMesh(e.i); const blk=e.i<256&&!W.blocks[e.i].cross; const sc=blk?.26:.4;
    const copies=e.n>1?2:1; for(let c=0;c<copies;c++){ const mm=M.chain(vp,M.T(e.x+c*.08,e.y+.22+Math.sin(T*2+e.ph)*.06+c*.06,e.z+c*.06),M.Ry(T*1.5+e.ph),M.S(sc,sc,sc)); gl.uniformMatrix4fv(PW.u.uMVP,false,mm); draw(m); } }
}
function drawShots(vp,dt){ if(!shots.length) return; gl.useProgram(progL.p); gl.bindBuffer(gl.ARRAY_BUFFER,shotVB); gl.enableVertexAttribArray(progL.a.aPos); gl.vertexAttribPointer(progL.a.aPos,3,gl.FLOAT,false,0,0); gl.uniformMatrix4fv(progL.u.uMVP,false,vp); gl.uniform4f(progL.u.uColor,.85,.8,.7,1);
  for(let i=shots.length-1;i>=0;i--){ const s=shots[i]; s.t+=dt*3; if(s.t>1){ shots.splice(i,1); continue; } const p=t=>s.a.map((v,k)=>v+(s.b[k]-v)*t); const a=p(Math.max(0,s.t-.15)), b=p(s.t); gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([...a,...b]),gl.DYNAMIC_DRAW); gl.drawArrays(gl.LINES,0,2); }
  gl.disableVertexAttribArray(progL.a.aPos); }
const shotVB=gl.createBuffer();
function drawCrack(vp){ if(!SV.mine||!target||SV.mine.p<=0) return; useE(vp,[0,0,0],[1e4,2e4]); gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA); EVP=vp;
  const m=M.mul(M.T(target.x+.5,target.y+.5,target.z+.5),M.S(1.012,1.012,1.012)); gl.uniformMatrix4fv(progE.u.uModel,false,m); gl.uniformMatrix4fv(progE.u.uMVP,false,M.mul(vp,m)); gl.uniform4f(progE.u.uColor,0,0,0,.12+SV.mine.p*.5); gl.uniform1f(progE.u.uLight,1); gl.drawElements(gl.TRIANGLES,36,gl.UNSIGNED_SHORT,0);
  gl.disable(gl.BLEND); gl.disableVertexAttribArray(progE.a.aN); gl.disableVertexAttribArray(progE.a.aPos); }

/* ---------------- monsters */
function humanoid(base,o,sk,sh,pa,opt={}){
  const sw=Math.sin(o.walk)*0.7*(o.moving?1:0), w=opt.thin?.13:.24;
  part(base,-.125,.75,0,sw,w,.75,w,pa,true); part(base,.125,.75,0,-sw,w,.75,w,pa,true);
  part(base,0,1.125,0,0,opt.thin?.36:.5,.75,opt.thin?.16:.26,sh);
  const arm=opt.reach?-1.45:sw; part(base,-.37,1.45,0,arm+(opt.reach?Math.sin(o.walk)*.15:0),opt.thin?.12:.22,.72,opt.thin?.12:.22,opt.armc||sh,true); part(base,.37,1.45,0,opt.reach?arm-Math.sin(o.walk)*.15:-sw,opt.thin?.12:.22,.72,opt.thin?.12:.22,opt.armc||sh,true);
  const head=M.mul(base,M.T(0,1.5,0)); part(head,0,.23,0,0,.46,.46,.46,sk); part(head,-.1,.25,-.232,0,.09,.07,.02,opt.eye||[.1,.1,.1]); part(head,.1,.25,-.232,0,.09,.07,.02,opt.eye||[.1,.1,.1]);
  if(opt.bow) part(M.mul(M.mul(base,M.T(.37,1.45,0)),M.Rx(arm)),0,-.7,-.1,0,.05,.05,.8,[.45,.3,.15]); }
function drawMonster(o){
  const base=M.mul(M.T(o.x,o.y,o.z),M.Ry(o.yaw));
  if(o.kind===4) humanoid(base,o,[.38,.6,.32],[.2,.55,.62],[.27,.24,.55],{reach:true,armc:[.38,.6,.32]});
  else if(o.kind===5) humanoid(base,o,[.82,.82,.8],[.75,.75,.72],[.7,.7,.68],{thin:true,bow:true,eye:[.15,.15,.15]});
  else if(o.kind===6){ const g=[.35,.72,.3], fl=o.fuse>0&&Math.sin(performance.now()/40)>0; const c=fl?[1,1,1]:g; const sw=Math.sin(o.walk)*.5*(o.moving?1:0);
    for(const [x,z,s] of [[-.13,-.18,1],[.13,-.18,-1],[-.13,.18,-1],[.13,.18,1]]) part(base,x,.35,z,sw*s,.24,.35,.24,c,true);
    const sc=1+Math.min(o.fuse,1.5)*.12; part(base,0,.35+.45,0,0,.48*sc,.9,.3*sc,c); const head=M.mul(base,M.T(0,1.25,0)); part(head,0,.23,0,0,.5*sc,.5,.5*sc,c);
    part(head,-.11,.3,-.252,0,.11,.11,.02,[.05,.05,.05]); part(head,.11,.3,-.252,0,.11,.11,.02,[.05,.05,.05]); part(head,0,.15,-.252,0,.1,.16,.02,[.05,.05,.05]); }
  else { const c=[.2,.16,.14], sw=Math.sin(o.walk*1.6)*.35*(o.moving?1:0);
    part(base,0,.45,.25,0,.8,.5,.8,c); part(base,0,.45,-.32,0,.5,.42,.45,[.24,.2,.18]); part(base,-.12,.52,-.55,0,.09,.09,.02,[.9,.1,.1]); part(base,.12,.52,-.55,0,.09,.09,.02,[.9,.1,.1]); part(base,-.06,.42,-.55,0,.06,.06,.02,[.9,.1,.1]); part(base,.06,.42,-.55,0,.06,.06,.02,[.9,.1,.1]);
    for(let i=0;i<4;i++) for(const s of [-1,1]){ const lm=M.chain(base,M.T(s*.3,.45,-.25+i*.17),M.Ry(s*(.3-i*.2)+sw*(i%2?1:-1)),M.Rz(s*.6)); part(lm,s*.4,0,0,0,.8,.08,.08,c); } }
}

window.__s={SV,GM,ITEMS,RECIPES,addItem,craft,openSInv,iid,damage,setHold:(b,p)=>{ holdBreak=b; holdPlace=p; },aim:(x,y,z)=>{ const dx=x-P.x, dy=y-(P.y+EYE), dz=z-P.z; P.yaw=Math.atan2(-dx,-dz); P.pitch=Math.atan2(dy,Math.hypot(dx,dz)); },get mobTarget(){return mobTarget;}};
