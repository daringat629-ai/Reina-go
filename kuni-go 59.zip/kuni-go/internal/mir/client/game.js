const $ = id => document.getElementById(id);
const CY = 128;
const store = { get(k){ try { return localStorage.getItem('w2_'+k); } catch { return null; } }, set(k,v){ try { localStorage.setItem('w2_'+k,v); } catch {} } };
const touchDevice = ('ontouchstart' in window) || navigator.maxTouchPoints > 0;
if (touchDevice) document.body.classList.add('touch');
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const fdiv=(a,b)=>Math.floor(a/b);
const key=(cx,cz)=>cx+','+cz;
const mixc=(a,b,t)=>[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,a[2]+(b[2]-a[2])*t];
const sstep=(a,b,x)=>{ const t=clamp((x-a)/(b-a),0,1); return t*t*(3-2*t); };

/* ------------------------------------------------------------------ settings */
const CFG = Object.assign({ view: touchDevice?4:6, fov: 75, sens: 40, vol: 60, clouds: true, map: !touchDevice, bob: true, debug: false }, (()=>{ try { return JSON.parse(store.get('cfg')||'{}'); } catch { return {}; } })());
const saveCfg=()=>store.set('cfg',JSON.stringify(CFG));

/* ------------------------------------------------------------------ matrices (column-major) */
const M = {
  persp(fov,asp,n,f){ const t=1/Math.tan(fov/2); return new Float32Array([t/asp,0,0,0, 0,t,0,0, 0,0,(f+n)/(n-f),-1, 0,0,2*f*n/(n-f),0]); },
  look(ex,ey,ez,fx,fy,fz){ let l=Math.hypot(fx,fy,fz); fx/=l;fy/=l;fz/=l; let sx=-fz, sz=fx; l=Math.hypot(sx,sz)||1; sx/=l; sz/=l; const sy=0;
    const ux=sy*fz-sz*fy, uy=sz*fx-sx*fz, uz=sx*fy-sy*fx;
    return new Float32Array([sx,ux,-fx,0, sy,uy,-fy,0, sz,uz,-fz,0, -(sx*ex+sy*ey+sz*ez),-(ux*ex+uy*ey+uz*ez),(fx*ex+fy*ey+fz*ez),1]); },
  mul(a,b){ const o=new Float32Array(16); for(let i=0;i<4;i++)for(let j=0;j<4;j++){ let s=0; for(let k=0;k<4;k++) s+=a[k*4+j]*b[i*4+k]; o[i*4+j]=s; } return o; },
  I(){ return new Float32Array([1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1]); },
  T(x,y,z){ const m=M.I(); m[12]=x; m[13]=y; m[14]=z; return m; },
  S(x,y,z){ const m=M.I(); m[0]=x; m[5]=y; m[10]=z; return m; },
  Ry(a){ const c=Math.cos(a),s=Math.sin(a); return new Float32Array([c,0,-s,0, 0,1,0,0, s,0,c,0, 0,0,0,1]); },
  Rx(a){ const c=Math.cos(a),s=Math.sin(a); return new Float32Array([1,0,0,0, 0,c,s,0, 0,-s,c,0, 0,0,0,1]); },
  Rz(a){ const c=Math.cos(a),s=Math.sin(a); return new Float32Array([c,s,0,0, -s,c,0,0, 0,0,1,0, 0,0,0,1]); },
  chain(...ms){ let r=ms[0]; for(let i=1;i<ms.length;i++) r=M.mul(r,ms[i]); return r; },
  inv(m){ const o=new Float32Array(16);
    const a00=m[0],a01=m[1],a02=m[2],a03=m[3],a10=m[4],a11=m[5],a12=m[6],a13=m[7],a20=m[8],a21=m[9],a22=m[10],a23=m[11],a30=m[12],a31=m[13],a32=m[14],a33=m[15];
    const b00=a00*a11-a01*a10,b01=a00*a12-a02*a10,b02=a00*a13-a03*a10,b03=a01*a12-a02*a11,b04=a01*a13-a03*a11,b05=a02*a13-a03*a12,b06=a20*a31-a21*a30,b07=a20*a32-a22*a30,b08=a20*a33-a23*a30,b09=a21*a32-a22*a31,b10=a21*a33-a23*a31,b11=a22*a33-a23*a32;
    let d=b00*b11-b01*b10+b02*b09+b03*b08-b04*b07+b05*b06; if(!d) return M.I(); d=1/d;
    o[0]=(a11*b11-a12*b10+a13*b09)*d; o[1]=(a02*b10-a01*b11-a03*b09)*d; o[2]=(a31*b05-a32*b04+a33*b03)*d; o[3]=(a22*b04-a21*b05-a23*b03)*d;
    o[4]=(a12*b08-a10*b11-a13*b07)*d; o[5]=(a00*b11-a02*b08+a03*b07)*d; o[6]=(a32*b02-a30*b05-a33*b01)*d; o[7]=(a20*b05-a22*b02+a23*b01)*d;
    o[8]=(a10*b10-a11*b08+a13*b06)*d; o[9]=(a01*b08-a00*b10-a03*b06)*d; o[10]=(a30*b04-a31*b02+a33*b00)*d; o[11]=(a21*b02-a20*b04-a23*b00)*d;
    o[12]=(a11*b07-a10*b09-a12*b06)*d; o[13]=(a00*b09-a01*b07+a02*b06)*d; o[14]=(a31*b01-a30*b03-a32*b00)*d; o[15]=(a20*b03-a21*b01+a22*b00)*d; return o; },
};

/* ------------------------------------------------------------------ world state */
const W = { blocks:[], solid:new Uint8Array(256), opaque:new Uint8Array(256), liquid:new Uint8Array(256), cross:new Uint8Array(256), trans:new Uint8Array(256), light:new Uint8Array(256),
  tileOf:{}, tilePix:{}, color:[], chunks:new Map(), pending:new Map(), time:0.25, bot:'Рейна', view:CFG.view, byName:{} };
function getBlock(x,y,z){ if(y<0) return 3; if(y>=CY) return 0; const c=W.chunks.get(key(fdiv(x,16),fdiv(z,16))); if(!c) return 255; return c.b[(y*16+(z&15))*16+(x&15)]; }
function isSolidAt(x,y,z){ const b=getBlock(x,y,z); return b===255 ? true : !!W.solid[b]; }
function setBlockLocal(x,y,z,id){
  const cx=fdiv(x,16),cz=fdiv(z,16),c=W.chunks.get(key(cx,cz));
  if(!c){ const k=key(cx,cz); if(!W.pending.has(k)) W.pending.set(k,[]); W.pending.get(k).push([x,y,z,id]); return; }
  const i=(y*16+(z&15))*16+(x&15); const old=c.b[i]; if(old===id) return; c.b[i]=id;
  worker.postMessage({t:'set',x,y,z,id});
  const lightChange=W.light[old]||W.light[id];
  markDirty(cx,cz,true);
  const lx=x&15, lz=z&15;
  if(lightChange){ for(let dx=-1;dx<=1;dx++)for(let dz=-1;dz<=1;dz++) markDirty(cx+dx,cz+dz,true); }
  else { if(lx===0) markDirty(cx-1,cz,true); if(lx===15) markDirty(cx+1,cz,true); if(lz===0) markDirty(cx,cz-1,true); if(lz===15) markDirty(cx,cz+1,true);
    // shadows and light leak a little into neighbours
    if(lx<2) markDirty(cx-1,cz); if(lx>13) markDirty(cx+1,cz); if(lz<2) markDirty(cx,cz-1); if(lz>13) markDirty(cx,cz+1); }
}
function markDirty(cx,cz,urgent){ const c=W.chunks.get(key(cx,cz)); if(c){ c.dirty=true; if(urgent) c.urgent=true; } }
function decodeChunk(buf){
  const dv=new DataView(buf); const cx=dv.getInt32(1,true), cz=dv.getInt32(5,true); const b=new Uint8Array(16*CY*16); let p=9,o=0;
  while(p+2<buf.byteLength && o<b.length){ const n=dv.getUint8(p)|(dv.getUint8(p+1)<<8), v=dv.getUint8(p+2); b.fill(v,o,o+n); o+=n; p+=3; }
  const k=key(cx,cz); const old=W.chunks.get(k); if(old) freeChunk(old);
  const c={cx,cz,b,dirty:true,meshes:[],trans:[],minY:0,maxY:CY,seq:0,got:-1};
  W.chunks.set(k,c);
  const pe=W.pending.get(k); if(pe){ W.pending.delete(k); for(const e of pe){ c.b[(e[1]*16+(e[2]&15))*16+(e[0]&15)]=e[3]; } }
  worker.postMessage({t:'chunk',cx,cz,b:b.buffer.slice(0)});
  for(const [dx,dz] of [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]]) markDirty(cx+dx,cz+dz);
}

/* ------------------------------------------------------------------ GL */
const canvas=$('gl');
const gl=canvas.getContext('webgl',{antialias:!touchDevice,alpha:false,powerPreference:'high-performance',preserveDrawingBuffer:false})||canvas.getContext('experimental-webgl');
if(!gl){ document.body.innerHTML='<div style="padding:30px;color:#fff">Браузер не поддерживает WebGL.</div>'; throw new Error('no webgl'); }
function shader(type,src){ const s=gl.createShader(type); gl.shaderSource(s,src); gl.compileShader(s); if(!gl.getShaderParameter(s,gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s)); return s; }
function program(vs,fs){ const p=gl.createProgram(); gl.attachShader(p,shader(gl.VERTEX_SHADER,vs)); gl.attachShader(p,shader(gl.FRAGMENT_SHADER,fs)); gl.linkProgram(p); if(!gl.getProgramParameter(p,gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
  const n=gl.getProgramParameter(p,gl.ACTIVE_UNIFORMS), u={}; for(let i=0;i<n;i++){ const a=gl.getActiveUniform(p,i); u[a.name]=gl.getUniformLocation(p,a.name); }
  const na=gl.getProgramParameter(p,gl.ACTIVE_ATTRIBUTES), a={}; for(let i=0;i<na;i++){ const x=gl.getActiveAttrib(p,i); a[x.name]=gl.getAttribLocation(p,x.name); }
  return {p,u,a}; }
const FOGFN=`float fogf(float d){ return clamp((d-uFog.x)/(uFog.y-uFog.x),0.0,1.0); }`;
const progW=program(`precision highp float;
attribute vec3 aPos;attribute vec2 aUV;attribute vec4 aL;uniform mat4 uMVP;uniform vec3 uCam;uniform float uTime;
varying vec2 vUV;varying float vShade;varying float vSky;varying float vBlk;varying float vDist;varying float vFlag;varying vec3 vW;
void main(){ vec3 p=aPos; float fl=aL.w;
  if(fl>0.5&&fl<1.5){ p.y+=sin(uTime*1.7+p.x*.9+p.z*.6)*.035+cos(uTime*1.3+p.z*.8)*.03-.03; }
  else if(fl>1.5&&fl<2.5){ float w=sin(uTime*1.4+p.x*.6+p.y*.4+p.z*.5)*.022; p.x+=w; p.z+=w*.6; }
  else if(fl>2.5&&fl<3.5){ float w=sin(uTime*2.0+p.x*.7+p.z*.9); p.x+=w*.06; p.z+=cos(uTime*1.7+p.x)*.05; }
  gl_Position=uMVP*vec4(p,1.0); vUV=aUV; vShade=aL.x; vSky=aL.y; vBlk=aL.z; vFlag=fl; vW=p; vDist=length(p-uCam); }`,
`precision highp float;uniform sampler2D uTex;uniform vec3 uFogC;uniform vec2 uFog;uniform float uDay;uniform vec3 uSunC;uniform float uCut;uniform float uTime;uniform float uGlow;
varying vec2 vUV;varying float vShade;varying float vSky;varying float vBlk;varying float vDist;varying float vFlag;varying vec3 vW;
${FOGFN}
void main(){ vec4 t=texture2D(uTex,vUV); if(t.a<uCut) discard;
  float s=vSky*vSky*uDay; float b=vBlk*vBlk;
  vec3 L=max(uSunC*s, vec3(1.0,.82,.6)*b*1.05)+vec3(.035,.04,.06);
  vec3 c=t.rgb*vShade*L;
  if(vFlag>0.5&&vFlag<1.5){ float sh=sin(vW.x*1.7+uTime*2.1)+sin(vW.z*2.3-uTime*1.6); c+=vec3(.06,.08,.1)*max(sh,0.0)*(.3+s); }
  if(vFlag>4.5){ float f=sin(vW.x*2.1+uTime*1.3)*sin(vW.z*1.7-uTime)*.5+.5; c=t.rgb*(1.0+f*.35); }
  c+=t.rgb*uGlow;
  gl_FragColor=vec4(mix(c,uFogC,fogf(vDist)),t.a); }`);
const progE=program(`precision highp float;attribute vec3 aPos;attribute vec3 aN;uniform mat4 uMVP;uniform mat4 uModel;uniform vec3 uCam;varying vec3 vN;varying float vDist;
void main(){ vec4 w=uModel*vec4(aPos,1.0); gl_Position=uMVP*vec4(aPos,1.0); vN=normalize(mat3(uModel)*aN); vDist=length(w.xyz-uCam); }`,
`precision highp float;uniform vec4 uColor;uniform float uLight;uniform vec3 uFogC;uniform vec2 uFog;varying vec3 vN;varying float vDist;${FOGFN}
void main(){ float d=.62+.28*max(dot(vN,normalize(vec3(.4,.9,.3))),0.0)+.1*vN.y; vec3 c=uColor.rgb*d*uLight; gl_FragColor=vec4(mix(c,uFogC,fogf(vDist)),uColor.a); }`);
const progSky=program(`attribute vec2 aPos;varying vec2 vP;void main(){ vP=aPos; gl_Position=vec4(aPos,.9999,1.0); }`,
`precision highp float;uniform mat4 uInv;uniform vec3 uZen;uniform vec3 uHor;uniform vec3 uSun;uniform vec3 uDusk;uniform float uNight;uniform float uUnder;varying vec2 vP;
float h(vec3 p){ return fract(sin(dot(p,vec3(12.9898,78.233,45.164)))*43758.5453); }
void main(){ vec4 p=uInv*vec4(vP,1.0,1.0); vec3 d=normalize(p.xyz/p.w);
  float y=d.y; vec3 c=mix(uHor,uZen,pow(clamp(y,0.0,1.0),.55)); if(y<0.0) c=mix(uHor,uHor*.55,clamp(-y*3.0,0.0,1.0));
  float sd=dot(d,uSun); float tow=max(dot(normalize(d.xz+1e-4),normalize(uSun.xz+1e-4)),0.0);
  c=mix(c,uDusk,pow(tow,3.0)*(1.0-clamp(abs(y)*2.2,0.0,1.0))*.85);
  c+=vec3(1.0,.85,.55)*pow(max(sd,0.0),180.0)*.9+vec3(1.0,.8,.5)*pow(max(sd,0.0),8.0)*.12*(1.0-uNight);
  vec3 a=abs(d-uSun); if(max(a.x,max(a.y,a.z))<.045) c=vec3(1.0,.97,.82)*1.15;
  vec3 m=abs(d+uSun); if(max(m.x,max(m.y,m.z))<.03){ c=mix(c,vec3(.86,.89,.98),.95); }
  if(uNight>0.01&&y>0.0){ vec3 g=floor(d*170.0); float s=h(g); if(s>.9965) c+=vec3(.9,.9,1.0)*uNight*(s-.9965)*285.0*(.6+.4*sin(g.x*7.0+g.y)); }
  c=mix(c,vec3(.05,.17,.42),uUnder);
  gl_FragColor=vec4(c,1.0); }`);
const progC=program(`precision highp float;attribute vec2 aPos;uniform mat4 uVP;uniform vec3 uCam;uniform float uH;varying vec3 vW;void main(){ vW=vec3(uCam.x+aPos.x*900.0,uH,uCam.z+aPos.y*900.0); gl_Position=uVP*vec4(vW,1.0); }`,
`precision highp float;uniform float uT;uniform vec3 uCam;uniform vec3 uCol;uniform vec3 uFogC;varying vec3 vW;
float h(vec2 p){ return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453); }
float n(vec2 p){ vec2 i=floor(p),f=fract(p); f=f*f*(3.0-2.0*f); return mix(mix(h(i),h(i+vec2(1,0)),f.x),mix(h(i+vec2(0,1)),h(i+vec2(1,1)),f.x),f.y); }
void main(){ vec2 q=(vW.xz+vec2(uT*1.6,uT*.4))/12.0; vec2 cell=floor(q); float v=n(cell*.18)*.65+n(cell*.5)*.35; if(v<.56) discard;
  float d=length(vW.xz-uCam.xz); float a=.8*(1.0-clamp((d-180.0)/380.0,0.0,1.0)); gl_FragColor=vec4(mix(uCol,uFogC,clamp(d/900.0,0.0,.6)),a); }`);
const progP=program(`attribute vec3 aPos;attribute vec3 aCol;uniform mat4 uVP;uniform float uSize;varying vec3 vC;void main(){ gl_Position=uVP*vec4(aPos,1.0); gl_PointSize=uSize/gl_Position.w; vC=aCol; }`,
`precision mediump float;varying vec3 vC;void main(){ gl_FragColor=vec4(vC,1.0); }`);
const progL=program(`attribute vec3 aPos;uniform mat4 uMVP;void main(){ gl_Position=uMVP*vec4(aPos,1.0); }`,`precision mediump float;uniform vec4 uColor;void main(){ gl_FragColor=uColor; }`);
function buf(type,data,usage){ const b=gl.createBuffer(); gl.bindBuffer(type,b); gl.bufferData(type,data,usage||gl.STATIC_DRAW); return b; }
// entity cube with normals
const ecube=(()=>{ const v=[],i=[]; const F=[[[1,0,0],[0,1,0],[0,0,1]],[[-1,0,0],[0,0,1],[0,1,0]],[[0,1,0],[0,0,1],[1,0,0]],[[0,-1,0],[1,0,0],[0,0,1]],[[0,0,1],[1,0,0],[0,1,0]],[[0,0,-1],[0,1,0],[1,0,0]]];
  for(const [n,u,w] of F){ const b=v.length/6; for(const [a,c] of [[-1,-1],[1,-1],[1,1],[-1,1]]) v.push(n[0]*.5+u[0]*a*.5+w[0]*c*.5,n[1]*.5+u[1]*a*.5+w[1]*c*.5,n[2]*.5+u[2]*a*.5+w[2]*c*.5,n[0],n[1],n[2]); i.push(b,b+1,b+2,b,b+2,b+3); }
  return {vb:buf(gl.ARRAY_BUFFER,new Float32Array(v)),ib:buf(gl.ELEMENT_ARRAY_BUFFER,new Uint16Array(i))}; })();
const edgeVB=buf(gl.ARRAY_BUFFER,new Float32Array([0,0,0,1,0,0, 1,0,0,1,0,1, 1,0,1,0,0,1, 0,0,1,0,0,0, 0,1,0,1,1,0, 1,1,0,1,1,1, 1,1,1,0,1,1, 0,1,1,0,1,0, 0,0,0,0,1,0, 1,0,0,1,1,0, 1,0,1,1,1,1, 0,0,1,0,1,1]));
const quadVB=buf(gl.ARRAY_BUFFER,new Float32Array([-1,-1, 1,-1, 1,1, -1,-1, 1,1, -1,1]));
const partVB=buf(gl.ARRAY_BUFFER,new Float32Array(6*400),gl.DYNAMIC_DRAW);
let atlasTex=null; const ATL=16;

/* ------------------------------------------------------------------ atlas & icons */
function buildAtlas(names){
  const c=document.createElement('canvas'); c.width=c.height=ATL*16; const ctx=c.getContext('2d');
  names.forEach((n,i)=>{ const t=paintTile(n); W.tileOf[n]=i; W.tilePix[n]=t.d; ctx.putImageData(new ImageData(t.d,16,16),(i%ATL)*16,Math.floor(i/ATL)*16); });
  atlasTex=gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D,atlasTex); gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,false);
  gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,c);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST); gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
}
function avgColor(name){ const p=W.tilePix[name]; if(!p) return [128,128,128]; let r=0,g=0,b=0,n=0; for(let i=0;i<p.length;i+=4){ if(p[i+3]<100) continue; r+=p[i]; g+=p[i+1]; b+=p[i+2]; n++; } return n?[r/n,g/n,b/n]:[128,128,128]; }
const iconCache=new Map();
function iconOf(id){
  if(iconCache.has(id)) return iconCache.get(id);
  const b=W.blocks[id]; const c=document.createElement('canvas'); c.width=c.height=48; const ctx=c.getContext('2d'); ctx.imageSmoothingEnabled=false;
  const tile=n=>{ const t=document.createElement('canvas'); t.width=t.height=16; const px=W.tilePix[n]; if(px) t.getContext('2d').putImageData(new ImageData(new Uint8ClampedArray(px),16,16),0,0); return t; };
  if(id>=256){ ctx.drawImage(tile(itemDef(id).name),4,4,40,40); iconCache.set(id,c); return c; }
  if(!b||!b.name){ iconCache.set(id,c); return c; }
  if(b.cross){ ctx.drawImage(tile(b.side),4,4,40,40); }
  else {
    const top=tile(b.top), side=tile(b.side);
    const s=1.32;
    ctx.save(); ctx.setTransform(s,s*.5,-s,s*.5,24,2); ctx.drawImage(top,0,0,16,16); ctx.restore(); // top rhombus
    ctx.save(); ctx.setTransform(s,s*.5,0,s,24-16*s,2+8*s); ctx.globalAlpha=1; ctx.drawImage(side,0,0,16,16); ctx.fillStyle='rgba(0,0,0,.22)'; ctx.fillRect(0,0,16,16); ctx.restore();
    ctx.save(); ctx.setTransform(s,-s*.5,0,s,24,2+16*s); ctx.drawImage(side,0,0,16,16); ctx.fillStyle='rgba(0,0,0,.4)'; ctx.fillRect(0,0,16,16); ctx.restore();
  }
  iconCache.set(id,c); return c;
}

/* ------------------------------------------------------------------ mesher worker */
const worker=new Worker(URL.createObjectURL(new Blob([$('wsrc').textContent],{type:'text/javascript'})));
let inflight=0;
worker.onmessage=e=>{ const m=e.data; if(m.t!=='mesh') return; inflight--; const c=W.chunks.get(key(m.cx,m.cz)); if(!c||m.none) return;
  if(m.seq<c.got) return; c.got=m.seq;
  freeChunk(c); c.meshes=upload(m.solid); c.trans=upload(m.trans); c.minY=m.minY; c.maxY=m.maxY; c.built=true; };
function upload(list){ return list.map(b=>{ const vb=gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER,vb); gl.bufferData(gl.ARRAY_BUFFER,b.v,gl.STATIC_DRAW); const ib=gl.createBuffer(); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,ib); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,b.i,gl.STATIC_DRAW); return {vb,ib,count:b.i.length}; }); }
function freeChunk(c){ for(const m of c.meshes||[]){ gl.deleteBuffer(m.vb); gl.deleteBuffer(m.ib); } for(const m of c.trans||[]){ gl.deleteBuffer(m.vb); gl.deleteBuffer(m.ib); } c.meshes=[]; c.trans=[]; }
let meshSeq=1;
function scheduleMeshes(pcx,pcz){
  const max=touchDevice?2:4; if(inflight>=max) return;
  let best=[];
  for(const c of W.chunks.values()){ if(!c.dirty) continue;
    // only mesh when neighbours are here (avoids walls at the edge), unless it's the far edge
    const d=Math.max(Math.abs(c.cx-pcx),Math.abs(c.cz-pcz));
    const score=(c.urgent?-1000:0)+d*d+(c.built?0:-.5);
    best.push([score,c]); }
  if(!best.length) return; best.sort((a,b)=>a[0]-b[0]);
  for(let i=0;i<best.length&&inflight<max;i++){ const c=best[i][1]; c.dirty=false; c.urgent=false; c.seq=meshSeq++; inflight++; worker.postMessage({t:'mesh',cx:c.cx,cz:c.cz,seq:c.seq}); }
}

/* ------------------------------------------------------------------ audio */
const AU={ctx:null,noise:null};
function audio(){ if(AU.ctx) return AU.ctx; try{ const C=window.AudioContext||window.webkitAudioContext; AU.ctx=new C(); const n=AU.ctx.createBuffer(1,AU.ctx.sampleRate*.5,AU.ctx.sampleRate); const d=n.getChannelData(0); for(let i=0;i<d.length;i++) d[i]=Math.random()*2-1; AU.noise=n; }catch{} return AU.ctx; }
function matOf(id){ const n=(W.blocks[id]||{}).name||''; if(/glass|ice/.test(n)) return 'glass'; if(/wool|leaves|snow|moss|hay|grass_|flower|tall|fern|cane|mushroom|bush/.test(n)) return 'soft'; if(/plank|log|book|craft|pumpkin|melon/.test(n)) return 'wood'; if(/sand|gravel|dirt|grass|clay|podzol/.test(n)) return 'dirt'; return 'stone'; }
function sfx(kind,id,vol=1,x,y,z){
  const ctx=audio(); if(!ctx||CFG.vol<=0) return; if(ctx.state==='suspended') ctx.resume();
  let v=vol*CFG.vol/100; if(x!==undefined){ const d=Math.hypot(x-P.x,y-P.y,z-P.z); v*=clamp(1-d/24,0,1); if(v<=0.01) return; }
  const t=ctx.currentTime, g=ctx.createGain(); g.connect(ctx.destination);
  if(kind==='chat'){ const o=ctx.createOscillator(); o.type='sine'; o.frequency.setValueAtTime(880,t); o.frequency.exponentialRampToValueAtTime(1320,t+.08); g.gain.setValueAtTime(.06*v,t); g.gain.exponentialRampToValueAtTime(.0001,t+.18); o.connect(g); o.start(t); o.stop(t+.2); return; }
  if(kind==='hurt'){ const o=ctx.createOscillator(); o.type='sawtooth'; o.frequency.setValueAtTime(220,t); o.frequency.exponentialRampToValueAtTime(90,t+.2); g.gain.setValueAtTime(.12*v,t); g.gain.exponentialRampToValueAtTime(.0001,t+.22); o.connect(g); o.start(t); o.stop(t+.23); return; }
  if(kind==='boom'||kind==='hiss'||kind==='eat'||kind==='hit'){ const src=ctx.createBufferSource(); src.buffer=AU.noise; const f=ctx.createBiquadFilter(); const P2={boom:['lowpass',300,.9,.9],hiss:['highpass',3000,1.4,.08],eat:['bandpass',900,.25,.35],hit:['bandpass',600,.12,.4]}[kind]; f.type=P2[0]; f.frequency.value=P2[1]; g.gain.setValueAtTime(P2[3]*v,t); g.gain.exponentialRampToValueAtTime(.0001,t+P2[2]); src.connect(f); f.connect(g); src.start(t,0,P2[2]+.05); if(kind==='eat'){ setTimeout(()=>sfx('hit',0,.5),150); } return; }
  if(kind==='pop'){ const o=ctx.createOscillator(); o.type='triangle'; o.frequency.setValueAtTime(520,t); o.frequency.exponentialRampToValueAtTime(260,t+.1); g.gain.setValueAtTime(.08*v,t); g.gain.exponentialRampToValueAtTime(.0001,t+.12); o.connect(g); o.start(t); o.stop(t+.13); return; }
  const m=matOf(id); const src=ctx.createBufferSource(); src.buffer=AU.noise; src.playbackRate.value=.8+Math.random()*.4;
  const f=ctx.createBiquadFilter(); f.type='bandpass';
  const F={stone:[1100,2.2],wood:[520,3],dirt:[420,1.2],soft:[260,0.8],glass:[3200,4]}[m];
  f.frequency.value=F[0]*(kind==='place'?.8:1)*(.9+Math.random()*.2); f.Q.value=F[1];
  const dur=kind==='step'?.07:kind==='place'?.09:.16; const amp=(kind==='step'?.18:.6)*v*(m==='glass'&&kind==='break'?1.3:1);
  g.gain.setValueAtTime(amp,t); g.gain.exponentialRampToValueAtTime(.0001,t+dur);
  src.connect(f); f.connect(g); src.start(t,Math.random()*.3,dur+.02);
  if(m==='glass'&&kind==='break'){ const o=ctx.createOscillator(); const g2=ctx.createGain(); o.frequency.value=2400+Math.random()*900; g2.gain.setValueAtTime(.05*v,t); g2.gain.exponentialRampToValueAtTime(.0001,t+.25); o.connect(g2); g2.connect(ctx.destination); o.start(t); o.stop(t+.26); }
}

/* ------------------------------------------------------------------ player and physics */
const P={x:0,y:80,z:0,vx:0,vy:0,vz:0,yaw:0,pitch:0,onGround:false,fly:false,inWater:false,inLava:false,sprint:false,sneak:false,id:0,name:'',walk:0,stepAcc:0,fov:75,color:0};
const EYE=1.62;
function hit(x,y,z,h=1.8){ const hw=.3; const x0=Math.floor(x-hw),x1=Math.floor(x+hw-1e-4),y0=Math.floor(y),y1=Math.floor(y+h-1e-4),z0=Math.floor(z-hw),z1=Math.floor(z+hw-1e-4);
  for(let by=y0;by<=y1;by++)for(let bz=z0;bz<=z1;bz++)for(let bx=x0;bx<=x1;bx++) if(isSolidAt(bx,by,bz)) return true; return false; }
function groundUnder(x,z){ const y=Math.floor(P.y-.05); for(const [dx,dz] of [[-.29,-.29],[.29,-.29],[-.29,.29],[.29,.29]]) if(isSolidAt(Math.floor(x+dx),y,Math.floor(z+dz))) return true; return false; }
let blockedH=false;
function moveBody(dx,dy,dz){
  const wasGround=P.onGround; P.onGround=false; blockedH=false; let rem=dy;
  while(Math.abs(rem)>1e-6){ const s=Math.abs(rem)>.25?.25*Math.sign(rem):rem; if(hit(P.x,P.y+s,P.z)){ if(dy<0) P.onGround=true; P.vy=0; break; } P.y+=s; rem-=s; }
  const edge=P.sneak&&!P.fly&&wasGround;
  rem=dx; while(Math.abs(rem)>1e-6){ const s=Math.abs(rem)>.25?.25*Math.sign(rem):rem; if(hit(P.x+s,P.y,P.z)||(edge&&!groundUnder(P.x+s,P.z))){ P.vx=0; blockedH=true; break; } P.x+=s; rem-=s; }
  rem=dz; while(Math.abs(rem)>1e-6){ const s=Math.abs(rem)>.25?.25*Math.sign(rem):rem; if(hit(P.x,P.y,P.z+s)||(edge&&!groundUnder(P.x,P.z+s))){ P.vz=0; blockedH=true; break; } P.z+=s; rem-=s; }
  if(edge) P.onGround=true;
}
const keys={}; const mv={x:0,z:0}; let wantJump=false, wantDown=false, lastW=0;
function physics(dt){
  dt=Math.min(dt,.05);
  const feet=getBlock(Math.floor(P.x),Math.floor(P.y+.3),Math.floor(P.z)), head=getBlock(Math.floor(P.x),Math.floor(P.y+EYE),Math.floor(P.z));
  P.inWater=feet!==255&&!!W.liquid[feet]; P.headWater=head!==255&&!!W.liquid[head]; P.headLava=P.headWater&&!!W.light[head]; P.inLava=P.inWater&&!!W.light[feet];
  let fw=(keys.KeyW||keys.ArrowUp?1:0)-(keys.KeyS||keys.ArrowDown?1:0)+(-mv.z), st=(keys.KeyD||keys.ArrowRight?1:0)-(keys.KeyA||keys.ArrowLeft?1:0)+mv.x;
  const l=Math.hypot(fw,st); if(l>1){ fw/=l; st/=l; }
  P.sneak=!!keys.ShiftLeft&&!P.fly;
  if(fw<=0) P.sprint=P.sprint&&touchDevice&&l>0;
  const sprint=(P.sprint||keys.ControlLeft||keys.ControlRight)&&fw>0&&!(isSurv()&&SV.food<=6);
  let sp=P.fly?(sprint?20:10):(sprint?5.9:4.3); if(P.sneak) sp=1.5; if(P.inWater&&!P.fly) sp*=P.inLava?.35:.55;
  const fx=-Math.sin(P.yaw), fz=-Math.cos(P.yaw), rx=Math.cos(P.yaw), rz=-Math.sin(P.yaw);
  const tx=(fx*fw+rx*st)*sp, tz=(fz*fw+rz*st)*sp; const k=Math.min(1,dt*(P.onGround||P.fly?14:3.5));
  P.vx+=(tx-P.vx)*k; P.vz+=(tz-P.vz)*k;
  const jump=keys.Space||wantJump, down=(keys.ShiftLeft&&P.fly)||wantDown;
  if(P.fly){ P.vy+=(((jump?1:0)-(down?1:0))*sp*.8-P.vy)*Math.min(1,dt*10); }
  else if(P.inWater){ P.vy+=(jump?18:-6)*dt; P.vy=clamp(P.vy,-4,3.8); if(!P.headWater&&jump&&P.vy>2.6) P.vy=2.6; }
  else { P.vy=Math.max(-55,P.vy-28*dt); if(jump&&P.onGround){ P.vy=8.6; P.onGround=false; if(isSurv()) SV.exh+=.1; } }
  if(isSurv()) ladderPhysics(dt);
  moveBody(P.vx*dt,P.vy*dt,P.vz*dt);
  // auto-jump on touch screens: step up single blocks while walking
  if(touchDevice&&blockedH&&P.onGround&&l>.3&&!P.fly){ const ax=P.x+fx*.45, az=P.z+fz*.45; if(!hit(ax,P.y+1.05,az)) P.vy=8.6; }
  const hsp=Math.hypot(P.vx,P.vz);
  if(P.onGround&&hsp>.5){ P.walk+=hsp*dt*1.9; P.stepAcc+=hsp*dt; if(P.stepAcc>(sprint?2.2:1.7)){ P.stepAcc=0; sfx('step',getBlock(Math.floor(P.x),Math.floor(P.y-.1),Math.floor(P.z)),.7); } }
  if(P.y<-30&&!isSurv()){ P.y=110; P.vy=0; }
  const targetFov=CFG.fov+(sprint&&hsp>5?8:0)+(P.fly&&hsp>8?6:0);
  P.fov+=(targetFov-P.fov)*Math.min(1,dt*8);
}

/* ------------------------------------------------------------------ picking, breaking, placing */
let target=null;
function raycast(maxD){
  const ox=P.x,oy=P.y+EYE,oz=P.z; const cp=Math.cos(P.pitch); const dx=-Math.sin(P.yaw)*cp, dy=Math.sin(P.pitch), dz=-Math.cos(P.yaw)*cp;
  let x=Math.floor(ox),y=Math.floor(oy),z=Math.floor(oz); const sx=dx>0?1:-1,sy=dy>0?1:-1,sz=dz>0?1:-1;
  const tdx=Math.abs(1/(dx||1e-9)),tdy=Math.abs(1/(dy||1e-9)),tdz=Math.abs(1/(dz||1e-9));
  let tmx=(dx>0?x+1-ox:ox-x)*tdx, tmy=(dy>0?y+1-oy:oy-y)*tdy, tmz=(dz>0?z+1-oz:oz-z)*tdz; let nx=0,ny=0,nz=0,t=0;
  for(let i=0;i<80;i++){
    const id=getBlock(x,y,z); if(id!==0&&id!==255&&!W.liquid[id]) return {x,y,z,nx,ny,nz,id};
    if(tmx<tmy&&tmx<tmz){ t=tmx; if(t>maxD) return null; x+=sx; tmx+=tdx; nx=-sx;ny=0;nz=0; }
    else if(tmy<tmz){ t=tmy; if(t>maxD) return null; y+=sy; tmy+=tdy; nx=0;ny=-sy;nz=0; }
    else { t=tmz; if(t>maxD) return null; z+=sz; tmz+=tdz; nx=0;ny=0;nz=-sz; }
  }
  return null;
}
const hotbar=[]; let sel=0, swing=0;
function overlapsMe(x,y,z){ return x<P.x+.3&&x+1>P.x-.3&&z<P.z+.3&&z+1>P.z-.3&&y<P.y+1.8&&y+1>P.y; }
const parts=[];
function burst(x,y,z,id,n=14){ const c=W.color[id]||[128,128,128]; for(let i=0;i<n;i++){ const f=.75+Math.random()*.4; parts.push({x:x+Math.random(),y:y+Math.random(),z:z+Math.random(),vx:(Math.random()-.5)*3,vy:Math.random()*3.5,vz:(Math.random()-.5)*3,life:.5+Math.random()*.5,c:[c[0]*f/255,c[1]*f/255,c[2]*f/255]}); } if(parts.length>380) parts.splice(0,parts.length-380); }
function doBreak(){ swing=1; if(mobTarget){ attackMob(mobTarget); return; } if(isSurv()) return; if(!target) return; const {x,y,z,id}=target; if(W.blocks[id].hard<0) return; setBlockLocal(x,y,z,0); net({t:'set',x,y,z,id:0}); burst(x,y,z,id); sfx('break',id);
  const up=getBlock(x,y+1,z); if(up!==255&&W.cross[up]){ setBlockLocal(x,y+1,z,0); } }
function doPlace(){ if(SV.dead) return; if(interact()){ swing=1; return; } if(isSurv()&&survUse()) return; swing=1; if(!target) return; let x=target.x+target.nx,y=target.y+target.ny,z=target.z+target.nz;
  if(W.cross[target.id]&&!W.light[target.id]){ x=target.x; y=target.y; z=target.z; }
  const cur=getBlock(x,y,z); if(cur===255||y<1||y>=CY) return; if(!(cur===0||W.liquid[cur]||W.cross[cur])) return; const id=hotbar[sel]; if(!id) return; if(W.solid[id]&&overlapsMe(x,y,z)) return;
  if(isSurv()&&(id>=256||!W.blocks[id]||!W.blocks[id].name||(W.blocks[id].name==='bed'&&false))) return;
  setBlockLocal(x,y,z,id); net({t:'set',x,y,z,id}); sfx('place',id); if(isSurv()) useHeld(); }
function pickBlock(){ if(!target) return; const i=hotbar.indexOf(target.id); if(i>=0) selectSlot(i); else if(isSurv()) return; else { hotbar[sel]=target.id; buildHot(); saveHot(); selectSlot(sel); } }

/* ------------------------------------------------------------------ network */
let ws=null, joined=false, others=new Map(), mobs=new Map(), lastSend=0, chatLines=[], chatHist=[], histIdx=-1;
function net(o){ if(ws&&ws.readyState===1) ws.send(JSON.stringify(o)); }
function addChat(from,text){ chatLines.push({from,text,at:performance.now()}); if(chatLines.length>60) chatLines.shift(); renderChat();
  if(from){ for(const o of others.values()) if(o.name===from){ o.say=text; o.sayAt=performance.now(); } if(from!==P.name) sfx('chat',0,.6); } }
function renderChat(){ const box=$('chat'); const now=performance.now(); const open=$('chatbox').style.display==='block'; box.innerHTML=''; for(const l of chatLines.slice(open?-14:-8)){ if(!open&&now-l.at>15000) continue; const d=document.createElement('div'); if(!l.from){ d.className='sys'; d.textContent=l.text; } else { if(l.from===W.bot) d.className='bot'; const b=document.createElement('b'); b.textContent=l.from+': '; d.appendChild(b); d.appendChild(document.createTextNode(l.text)); } box.appendChild(d); } }
function connect(name,keyv){
  const url=(location.protocol==='https:'?'wss://':'ws://')+location.host+'/world/ws?key='+encodeURIComponent(keyv)+'&name='+encodeURIComponent(name)+'&mode='+(store.get('mode')||'');
  ws=new WebSocket(url); ws.binaryType='arraybuffer'; let opened=false;
  ws.onopen=()=>{ opened=true; };
  ws.onmessage=ev=>{ if(typeof ev.data!=='string'){ decodeChunk(ev.data); return; } onMsg(JSON.parse(ev.data)); };
  ws.onclose=()=>{ if(!joined){ $('err').textContent=opened?'Связь оборвалась. Попробуй ещё раз.':'Не удалось войти: проверь пароль мира и адрес.'; $('login').style.display='grid'; } else { showMsg('Связь потеряна. Переподключаюсь…',true); setTimeout(()=>location.reload(),2500); } };
}
function onMsg(m){
  switch(m.t){
  case 'hello': {
    W.blocks=m.blocks; W.bot=m.bot; W.time=m.time; const names=[]; initItems(m.items); GM.forced=!!m.forced; defineRecipes();
    for(const b of W.blocks){ W.byName[b.name]=b.id; W.solid[b.id]=b.solid?1:0; W.liquid[b.id]=b.liquid?1:0; W.cross[b.id]=b.cross?1:0; W.trans[b.id]=b.trans?1:0; W.opaque[b.id]=(b.solid&&!b.trans)?1:0; W.light[b.id]=b.light||0; for(const t of [b.top,b.side,b.bottom]) if(t&&!names.includes(t)) names.push(t); }
    for(const it of ITEMS) if(it&&!names.includes(it.name)) names.push(it.name);
    buildAtlas(names);
    for(const b of W.blocks) W.color[b.id]=avgColor(b.cross?b.side:b.top);
    for(const it of ITEMS) if(it) W.color[it.id]=avgColor(it.name);
    const n=W.blocks.length, A=k=>new Uint8Array(256);
    const info={t:'info',opaque:A(),liquid:A(),cross:A(),trans:A(),glassy:A(),light:A(),tt:A(),ts:A(),tb:A(),special:A(),atten:A()};
    for(const b of W.blocks){ const i=b.id; info.opaque[i]=W.opaque[i]; info.liquid[i]=W.liquid[i]; info.cross[i]=W.cross[i]&&b.name!=='torch'?1:0; info.trans[i]=W.trans[i]; info.glassy[i]=b.glassy?1:0; info.light[i]=W.light[i];
      info.tt[i]=W.tileOf[b.top]||0; info.ts[i]=W.tileOf[b.side]||0; info.tb[i]=W.tileOf[b.bottom]||0; info.special[i]=b.name==='torch'?1:0; info.atten[i]=/leaves/.test(b.name)?1:(b.liquid?2:(b.glassy?1:0)); }
    worker.postMessage(info);
    P.id=m.id; P.name=m.name; P.x=m.x; P.y=m.y; P.z=m.z; P.yaw=m.yaw||0; P.vy=0; P.color=m.color; joined=true; $('login').style.display='none';
    const want=['grass','dirt','stone','planks','log','glass','brick','lamp','torch']; hotbar.length=0;
    const saved=Array.isArray(m.hotbar)&&m.hotbar.length?m.hotbar:null;
    for(let i=0;i<9;i++){ const id=saved&&saved[i]!==undefined?saved[i]:W.byName[want[i]]; hotbar.push(id||0); }
    W.savedHot=hotbar.slice(); buildHot(); buildInv(); applyView(); setMode(m.mode||'creative',m.surv);
    for(const h of m.history||[]) chatLines.push({from:h.from,text:h.text,at:performance.now()-10000});
    addChat('',(isSurv()?'⚔ Режим выживания. ':'✨ Творческий режим. ')+'Добро пожаловать в Мир Рейны 2.0! '+(touchDevice?'Джойстик — идти, правая половина — смотреть.':'Нажми Esc — настройки и подсказки, T — чат, /help — команды.'));
    $('loading').style.display='block'; loadStart=performance.now();
    break; }
  case 'p': { const seen=new Set(); for(const o of m.l){ if(o.i===P.id) continue; seen.add(o.i); let e=others.get(o.i); if(!e){ e={name:o.n,bot:!!o.bot,x:o.x,y:o.y,z:o.z,yaw:o.a,pitch:o.b,walk:0}; others.set(o.i,e); } e.tx=o.x; e.ty=o.y; e.tz=o.z; e.tyaw=o.a; e.pitch=o.b; e.name=o.n; e.color=o.c; e.held=o.h||0; e.s=o.s||0; }
    for(const id of [...others.keys()]) if(!seen.has(id)) others.delete(id);
    const ms=new Set(); for(const a of m.m||[]){ const id=a[0]; ms.add(id); let e=mobs.get(id); if(!e){ e={kind:a[1],x:a[2],y:a[3],z:a[4],yaw:a[5],walk:0}; mobs.set(id,e); } e.tx=a[2]; e.ty=a[3]; e.tz=a[4]; e.tyaw=a[5]; e.color=a[6]; e.moving=a[7]; e.hurt=a[8]; e.fuse=a[9]||0; }
    onItems(m.it);
    for(const id of [...mobs.keys()]) if(!ms.has(id)) mobs.delete(id);
    break; }
  case 'b': { const old=getBlock(m.x,m.y,m.z); if(m.by===P.id) break; setBlockLocal(m.x,m.y,m.z,m.id);
    if(old!==255){ if(m.id===0&&old!==0){ burst(m.x,m.y,m.z,old,8); sfx('break',old,.6,m.x,m.y,m.z); } else if(m.id) sfx('place',m.id,.5,m.x,m.y,m.z); } break; }
  case 'chat': addChat(m.from,m.text); break;
  case 'time': W.time=m.v; break;
  case 'give': { if(!isSurv()) break; const left=addItem(m.i,m.n,m.d||0); if(left>0) net({t:'drop',i:m.i,n:left,d:m.d||0,back:1}); sfx('pop',0,.5); break; }
  case 'hurt': damage(m.d,'погиб: '+(m.from||'монстр'),m.kx,m.kz); break;
  case 'shot': shots.push({a:m.a,b:m.b,t:0}); sfx('hit',0,.5,m.a[0],m.a[1],m.a[2]); break;
  case 'boom': for(let i=0;i<4;i++) burst(m.x-1.5+Math.random()*3,m.y-1+Math.random()*2,m.z-1.5+Math.random()*3,W.byName.gravel||1,14); sfx('boom',0,1,m.x,m.y,m.z); break;
  case 'hiss': sfx('hiss',0,1,m.x,m.y,m.z); break;
  case 'chest': SV.chest={x:m.x,y:m.y,z:m.z,s:(m.s||[]).map(q=>q&&q.i?{i:q.i,n:q.n,d:q.d||0}:null)}; while(SV.chest.s.length<27) SV.chest.s.push(null); openSInv(SV.chest); break;
  case 'mode': setMode(m.mode,m.surv); toast(isSurv()?'⚔ Выживание':'✨ Творчество'); break;
  case 'tp': P.x=m.x; P.y=m.y; P.z=m.z; P.vx=P.vy=P.vz=0; showMsg('Телепорт ✨'); break;
  }
}
function showMsg(t,sticky){ const e=$('msg'); e.textContent=t; e.style.display='block'; clearTimeout(showMsg.t); if(!sticky) showMsg.t=setTimeout(()=>e.style.display='none',2000); }
function toast(t){ const e=$('toast'); e.textContent=t; e.style.opacity=1; clearTimeout(toast.t); toast.t=setTimeout(()=>e.style.opacity=0,1800); }

/* ------------------------------------------------------------------ UI */
function slotCanvas(id){ const c=iconOf(id); const d=document.createElement('canvas'); d.width=d.height=48; d.getContext('2d').drawImage(c,0,0); return d; }
function buildHot(){ const h=$('hot'); h.innerHTML=''; hotbar.forEach((id,i)=>{ const d=document.createElement('div'); d.className='slot'+(i===sel?' sel':''); const n=document.createElement('i'); n.textContent=i+1; d.appendChild(n); if(id) d.appendChild(slotCanvas(id)); if(isSurv()&&SV.inv[i]){ const s=SV.inv[i]; if(s.n>1){ const b=document.createElement('b'); b.textContent=s.n; d.appendChild(b); } const df=itemDef(s.i); if(df.dur&&s.d){ const u=document.createElement('u'); const f=1-s.d/df.dur; u.style.width=(f*80)+'%'; u.style.background=`hsl(${f*120},80%,50%)`; d.appendChild(u); } } d.addEventListener('pointerdown',e=>{ e.preventDefault(); if(i===sel&&touchDevice) openInvAny(); else selectSlot(i); }); h.appendChild(d); }); }
function selectSlot(i){ sel=(i+hotbar.length)%hotbar.length; const slots=$('hot').children; for(let k=0;k<slots.length;k++) slots[k].classList.toggle('sel',k===sel); const b=hotbar[sel]?itemDef(hotbar[sel]):null; const e=$('bname'); e.textContent=b&&b.label?b.label:'Пусто'; e.style.opacity=1; clearTimeout(selectSlot.t); selectSlot.t=setTimeout(()=>e.style.opacity=0,1400); }
function saveHot(){ if(isSurv()) return; W.savedHot=hotbar.slice(); net({t:'hot',h:hotbar}); }
function openInvAny(){ if(isSurv()) openSInv(); else openPanel('inv'); }
let invCat='Все';
function buildInv(){
  const cats=['Все']; for(const b of W.blocks) if(b.cat&&!cats.includes(b.cat)) cats.push(b.cat);
  const cb=$('cats'); cb.innerHTML=''; for(const c of cats){ const b=document.createElement('button'); b.textContent=c; b.className=c===invCat?'on':''; b.onclick=()=>{ invCat=c; buildInv(); }; cb.appendChild(b); }
  const q=$('search').value.trim().toLowerCase(); const g=$('grid'); g.innerHTML='';
  for(const b of W.blocks){ if(!b.name||b.id===0||!b.cat) continue; if(invCat!=='Все'&&b.cat!==invCat) continue; if(q&&!b.label.toLowerCase().includes(q)&&!b.name.includes(q)) continue;
    const btn=document.createElement('button'); btn.title=b.label; btn.appendChild(slotCanvas(b.id)); const s=document.createElement('span'); s.textContent=b.label; btn.appendChild(s);
    btn.onclick=()=>{ hotbar[sel]=b.id; buildHot(); saveHot(); closePanels(); selectSlot(sel); sfx('pop'); }; g.appendChild(btn); }
}
$('search').addEventListener('input',buildInv); $('search').addEventListener('keydown',e=>{ e.stopPropagation(); if(e.key==='Escape') closePanels(); });
const panels=['inv','menu','players','sinv'];
function openPanel(id){ closePanels(true); $(id).style.display='grid'; if(document.pointerLockElement) document.exitPointerLock(); if(id==='inv'&&!touchDevice) setTimeout(()=>$('search').focus(),30); if(id==='players') buildPlayers(); if(id==='menu') syncMenu(); }
function closePanels(keep){ if($('sinv').style.display==='grid') closeSInv(); for(const p of panels) $(p).style.display='none'; $('search').blur(); if(!keep&&!touchDevice&&joined) setTimeout(()=>canvas.requestPointerLock?.(),0); }
const panelOpen=()=>panels.some(p=>$(p).style.display==='grid');
for(const p of panels) $(p).addEventListener('pointerdown',e=>{ if(e.target===$(p)) closePanels(); });
function buildPlayers(){ const t=$('ptab'); t.innerHTML=''; const row=(n,d,bot)=>{ const tr=document.createElement('tr'); const a=document.createElement('td'); a.textContent=(bot?'💖 ':'🧑 ')+n; const b=document.createElement('td'); b.textContent=d; tr.append(a,b); t.appendChild(tr); };
  row(P.name+' (ты)','',false); for(const o of others.values()) row(o.name,Math.round(Math.hypot(o.x-P.x,o.z-P.z))+' бл.',o.bot); }
function syncMenu(){ const s=[['sView','oView','view',v=>v+' чанк.'],['sFov','oFov','fov',v=>v+'°'],['sSens','oSens','sens',v=>v],['sVol','oVol','vol',v=>v+'%']];
  for(const [i,o,k,f] of s){ $(i).value=CFG[k]; $(o).textContent=f(CFG[k]); $(i).oninput=()=>{ CFG[k]=+$(i).value; $(o).textContent=f(CFG[k]); saveCfg(); if(k==='view') applyView(); }; }
  for(const [i,k] of [['cClouds','clouds'],['cMap','map'],['cBob','bob'],['cDebug','debug']]){ $(i).checked=!!CFG[k]; $(i).onchange=()=>{ CFG[k]=$(i).checked; saveCfg(); applyCfg(); }; } }
function applyView(){ W.view=CFG.view; net({t:'view',view:W.view}); }
function applyCfg(){ $('map').style.display=CFG.map?'block':'none'; $('info').classList.toggle('mini',!CFG.debug); }
applyCfg();
$('mResume').onclick=()=>closePanels(); $('mPlayers').onclick=()=>openPanel('players'); $('mShot').onclick=()=>{ closePanels(); setTimeout(()=>shot=true,300); };
function openChat(prefix){ $('chatbox').style.display='block'; $('chatin').value=prefix||''; $('chatin').focus(); renderChat(); histIdx=-1; if(document.pointerLockElement) document.exitPointerLock(); }
function closeChat(){ $('chatbox').style.display='none'; $('chatin').blur(); renderChat(); if(!touchDevice&&joined) setTimeout(()=>canvas.requestPointerLock?.(),0); }
$('chatin').addEventListener('keydown',e=>{ e.stopPropagation();
  if(e.key==='Enter'){ const v=$('chatin').value.trim(); if(v){ net({t:'chat',text:v}); chatHist.unshift(v); if(chatHist.length>30) chatHist.pop(); } $('chatin').value=''; closeChat(); }
  else if(e.key==='Escape') closeChat();
  else if(e.key==='ArrowUp'){ if(histIdx<chatHist.length-1){ histIdx++; $('chatin').value=chatHist[histIdx]; } e.preventDefault(); }
  else if(e.key==='ArrowDown'){ if(histIdx>0){ histIdx--; $('chatin').value=chatHist[histIdx]; } else { histIdx=-1; $('chatin').value=''; } e.preventDefault(); } });
const typing=()=>document.activeElement&&(document.activeElement.tagName==='INPUT');
function toggleFly(){ if(isSurv()){ P.fly=false; return; } P.fly=!P.fly; $('bFly').classList.toggle('on',P.fly); toast(P.fly?'✈ Полёт включён':'Полёт выключен'); }

/* ------------------------------------------------------------------ input */
let lock=false;
document.addEventListener('pointerlockchange',()=>{ const was=lock; lock=document.pointerLockElement===canvas; if(was&&!lock&&joined&&!panelOpen()&&!typing()&&!touchDevice&&!SV.dead) openPanel('menu'); });
canvas.addEventListener('click',()=>{ audio(); if(!touchDevice&&joined&&!lock&&!panelOpen()&&!typing()) canvas.requestPointerLock?.(); });
document.addEventListener('mousemove',e=>{ if(!lock) return; const s=CFG.sens/40*.0024; P.yaw-=e.movementX*s; P.pitch=clamp(P.pitch-e.movementY*s,-1.55,1.55); });
let holdBreak=false,holdPlace=false,lastAct=0;
canvas.addEventListener('mousedown',e=>{ if(!lock) return; if(e.button===0){ doBreak(); holdBreak=true; lastAct=performance.now(); } else if(e.button===2){ doPlace(); holdPlace=true; lastAct=performance.now(); } else if(e.button===1){ e.preventDefault(); pickBlock(); } });
document.addEventListener('mouseup',()=>{ holdBreak=holdPlace=false; });
canvas.addEventListener('contextmenu',e=>e.preventDefault());
document.addEventListener('wheel',e=>{ if(lock) selectSlot(sel+(e.deltaY>0?1:-1)); },{passive:true});
let lastSpace=0, shot=false;
document.addEventListener('keydown',e=>{
  if(typing()||!joined) return;
  if(e.code==='Escape'&&panelOpen()){ closePanels(); return; }
  if(SV.dead) return;
  if(e.code==='KeyE'){ (panelOpen()&&($('inv').style.display==='grid'||$('sinv').style.display==='grid'))?closePanels():openInvAny(); e.preventDefault(); return; }
  if(e.code==='Tab'){ e.preventDefault(); if(!e.repeat) openPanel('players'); return; }
  if(panelOpen()) return;
  if(e.code==='KeyT'||e.code==='Enter'){ e.preventDefault(); openChat(); return; }
  if(e.code==='Slash'){ e.preventDefault(); openChat('/'); return; }
  if(e.code==='KeyF'){ toggleFly(); return; }
  if(e.code==='KeyM'){ CFG.map=!CFG.map; saveCfg(); applyCfg(); return; }
  if(e.code==='F1'){ e.preventDefault(); document.body.classList.toggle('nohud'); return; }
  if(e.code==='F2'){ e.preventDefault(); shot=true; return; }
  if(e.code==='F3'){ e.preventDefault(); CFG.debug=!CFG.debug; saveCfg(); applyCfg(); return; }
  if(e.code==='KeyQ'){ if(isSurv()){ const h=SV.inv[sel]; if(h){ const n=e.ctrlKey?h.n:1; net({t:'drop',i:h.i,n,d:h.d||0}); useHeld(n); } } else pickBlock(); return; }
  if(e.code==='Space'){ const n=performance.now(); if(!e.repeat&&n-lastSpace<280) toggleFly(); if(!e.repeat) lastSpace=n; }
  if(e.code==='KeyW'&&!e.repeat){ const n=performance.now(); if(n-lastW<260) P.sprint=true; lastW=n; }
  if(/^Digit[1-9]$/.test(e.code)) selectSlot(+e.code.slice(5)-1);
  if(['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code)) e.preventDefault();
  keys[e.code]=true;
});
document.addEventListener('keyup',e=>{ keys[e.code]=false; if(e.code==='Tab'&&$('players').style.display==='grid') closePanels(); if(e.code==='KeyW') P.sprint=false; });
window.addEventListener('blur',()=>{ for(const k in keys) keys[k]=false; });

{ const stick=$('stick'),knob=$('knob'); let sid=null,lid=null,lx=0,ly=0,lt=0,moved=0;
  const R=44;
  function stickMove(t){ const r=stick.getBoundingClientRect(); const cx=r.left+r.width/2, cy=r.top+r.height/2; let dx=t.clientX-cx, dy=t.clientY-cy; const l=Math.hypot(dx,dy); if(l>R){ dx=dx/l*R; dy=dy/l*R; } knob.style.transform=`translate(${dx}px,${dy}px)`; mv.x=dx/R; mv.z=-dy/R; P.sprint=l>R*1.45; }
  document.addEventListener('touchstart',e=>{ if(!joined) return; audio(); for(const t of e.changedTouches){ const el=document.elementFromPoint(t.clientX,t.clientY); if(el&&(el.closest('#stick'))&&sid===null){ sid=t.identifier; stickMove(t); } else if(el&&(el.tagName==='CANVAS'||el.id==='hud'||el.id==='chat'||el.closest('#tags'))&&lid===null){ lid=t.identifier; lx=t.clientX; ly=t.clientY; lt=performance.now(); moved=0; } } },{passive:true});
  document.addEventListener('touchmove',e=>{ for(const t of e.changedTouches){ if(t.identifier===sid) stickMove(t); else if(t.identifier===lid){ const s=CFG.sens/40*.0055; P.yaw-=(t.clientX-lx)*s; P.pitch=clamp(P.pitch-(t.clientY-ly)*s,-1.55,1.55); moved+=Math.abs(t.clientX-lx)+Math.abs(t.clientY-ly); lx=t.clientX; ly=t.clientY; } } if(!panelOpen()&&!typing()) e.preventDefault(); },{passive:false});
  const end=e=>{ for(const t of e.changedTouches){ if(t.identifier===sid){ sid=null; knob.style.transform=''; mv.x=mv.z=0; P.sprint=false; } if(t.identifier===lid){ lid=null; if(moved<10&&performance.now()-lt<250) doPlace(); } } };
  document.addEventListener('touchend',end); document.addEventListener('touchcancel',end);
  const hold=(id,on,off)=>{ const b=$(id); b.addEventListener('pointerdown',e=>{ e.preventDefault(); e.stopPropagation(); b.setPointerCapture?.(e.pointerId); on(); }); const up=()=>off&&off(); b.addEventListener('pointerup',up); b.addEventListener('pointercancel',up); };
  hold('bJump',()=>{ wantJump=true; const n=performance.now(); if(n-lastSpace<280) toggleFly(); lastSpace=n; },()=>{ wantJump=false; });
  hold('bDown',()=>{ wantDown=true; },()=>{ wantDown=false; });
  hold('bBreak',()=>{ doBreak(); holdBreak=true; lastAct=performance.now(); },()=>{ holdBreak=false; });
  hold('bPlace',()=>{ doPlace(); holdPlace=true; lastAct=performance.now(); },()=>{ holdPlace=false; });
  hold('bFly',()=>toggleFly()); hold('bInv',()=>openInvAny()); hold('bChat',()=>openChat()); hold('bMenu',()=>openPanel('menu'));
}

/* ------------------------------------------------------------------ entities */
function useE(vp,fogC,fog){ gl.useProgram(progE.p); gl.bindBuffer(gl.ARRAY_BUFFER,ecube.vb); gl.enableVertexAttribArray(progE.a.aPos); gl.vertexAttribPointer(progE.a.aPos,3,gl.FLOAT,false,24,0); gl.enableVertexAttribArray(progE.a.aN); gl.vertexAttribPointer(progE.a.aN,3,gl.FLOAT,false,24,12); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,ecube.ib);
  gl.uniform3fv(progE.u.uFogC,fogC); gl.uniform2fv(progE.u.uFog,fog); }
let EVP=null, ELIGHT=1, ETINT=0;
function part(base,px,py,pz,rx,sx,sy,sz,col,hang){ let m=M.mul(base,M.T(px,py,pz)); if(rx) m=M.mul(m,M.Rx(rx)); if(hang) m=M.mul(m,M.T(0,-sy/2,0)); m=M.mul(m,M.S(sx,sy,sz));
  gl.uniformMatrix4fv(progE.u.uModel,false,m); gl.uniformMatrix4fv(progE.u.uMVP,false,M.mul(EVP,m)); gl.uniform4f(progE.u.uColor,col[0]+(1-col[0])*ETINT,col[1]*(1-ETINT*.7),col[2]*(1-ETINT*.7),1); gl.uniform1f(progE.u.uLight,ELIGHT); gl.drawElements(gl.TRIANGLES,36,gl.UNSIGNED_SHORT,0); }
function hsl(h,s,l){ h=((h%360)+360)%360/360; const f=n=>{ const k=(n+h*12)%12, a=s*Math.min(l,1-l); return l-a*Math.max(-1,Math.min(k-3,9-k,1)); }; return [f(0),f(8),f(4)]; }
function drawHuman(o){
  const base=M.mul(M.T(o.x,o.y,o.z),M.Ry(o.yaw));
  const sw=Math.sin(o.walk)*0.7*(o.moving?1:0);
  const skin=[.93,.76,.62], shirt=o.bot?[1,.3,.78]:hsl(o.color||200,.55,.5), pants=o.bot?[.36,.24,.62]:hsl((o.color||200)+40,.35,.28);
  const dance=o.s===2, build=o.s===3, t=performance.now()/1000;
  const armA=build?-1.2+Math.sin(t*14)*.5:dance?Math.sin(t*8)*2.6:sw, armB=build?Math.sin(t*3)*.1:dance?-Math.sin(t*8)*2.6:-sw;
  part(base,-.125,.75,0,sw,.24,.75,.24,pants,true); part(base,.125,.75,0,-sw,.24,.75,.24,pants,true);
  part(base,0,1.125,0,0,.5,.75,.26,shirt);
  part(base,-.37,1.45,0,armA,.22,.72,.22,shirt,true); part(base,.37,1.45,0,armB,.22,.72,.22,shirt,true);
  const head=M.mul(M.mul(base,M.T(0,1.5,0)),M.Rx(clamp(-(o.pitch||0),-.8,.8)));
  part(head,0,.23,0,0,.46,.46,.46,skin);
  part(head,-.1,.27,-.232,0,.08,.08,.02,[.15,.1,.25]); part(head,.1,.27,-.232,0,.08,.08,.02,[.15,.1,.25]);
  if(o.bot){ const hair=[.55,.2,.75]; part(head,0,.44,.03,0,.5,.1,.52,hair); part(head,0,.14,.2,0,.5,.62,.12,hair); part(head,0,-.1,.22,0,.42,.4,.08,hair);
    part(head,-.24,.25,0,0,.06,.4,.46,hair); part(head,.24,.25,0,0,.06,.4,.46,hair); part(head,.12,.52,0,0,.18,.1,.1,[1,.85,.2]); part(head,-.12,.52,0,0,.18,.1,.1,[1,.85,.2]); }
  else part(head,0,.43,.02,0,.48,.08,.5,hsl((o.color||0)+180,.3,.22));
  if(o.held&&W.color[o.held]){ const c=W.color[o.held]; const hm=M.mul(M.mul(base,M.T(.37,1.45,0)),M.Rx(armB)); part(hm,0,-.72,-.12,0,.22,.22,.22,[c[0]/255,c[1]/255,c[2]/255]); }
}
function drawMob(o){
  ETINT=o.hurt?.6:0; if(o.kind>=4){ drawMonster(o); ETINT=0; return; }
  const base=M.mul(M.T(o.x,o.y,o.z),M.Ry(o.yaw)); const sw=Math.sin(o.walk)*.6*(o.moving?1:0);
  const L=(x,z,h,w,c)=>{ part(base,x,h,z,(x*z>0?1:-1)*sw,w,h,w,c,true); };
  if(o.kind===0){ const pk=[.94,.62,.66]; L(-.2,-.3,.35,.2,pk); L(.2,-.3,.35,.2,pk); L(-.2,.3,.35,.2,pk); L(.2,.3,.35,.2,pk);
    part(base,0,.6,0,0,.6,.5,.9,pk); part(base,0,.72,-.6,0,.48,.46,.42,pk); part(base,0,.66,-.84,0,.24,.16,.06,[.86,.5,.55]); part(base,-.12,.82,-.82,0,.07,.07,.02,[.1,.1,.1]); part(base,.12,.82,-.82,0,.07,.07,.02,[.1,.1,.1]); }
  else if(o.kind===1){ const wc=[[.94,.94,.94],[.6,.6,.6],[.3,.3,.32],[.12,.12,.14],[.45,.3,.18]][o.color]||hsl(330,.6,.75); const face=[.86,.74,.64]; const lg=[.86,.74,.64];
    L(-.2,-.3,.4,.18,lg); L(.2,-.3,.4,.18,lg); L(-.2,.3,.4,.18,lg); L(.2,.3,.4,.18,lg);
    part(base,0,.72,0,0,.72,.62,1,wc); part(base,0,.92,-.6,0,.4,.4,.4,face); part(base,0,1.0,-.56,0,.44,.24,.3,wc); part(base,-.1,.94,-.81,0,.07,.07,.02,[.1,.1,.1]); part(base,.1,.94,-.81,0,.07,.07,.02,[.1,.1,.1]); }
  else if(o.kind===2){ const wh=[.97,.97,.95], yl=[.95,.75,.2];
    part(base,-.08,.22,0,sw,.05,.22,.05,yl,true); part(base,.08,.22,0,-sw,.05,.22,.05,yl,true);
    part(base,0,.38,0,0,.36,.34,.46,wh); part(base,-.2,.4,0,0,.06,.24,.34,wh); part(base,.2,.4,0,0,.06,.24,.34,wh);
    part(base,0,.66,-.2,0,.24,.3,.2,wh); part(base,0,.66,-.34,0,.14,.08,.1,yl); part(base,0,.56,-.32,0,.08,.1,.06,[.85,.1,.1]); part(base,-.08,.72,-.31,0,.05,.05,.02,[.05,.05,.05]); part(base,.08,.72,-.31,0,.05,.05,.02,[.05,.05,.05]); }
  else { const br=[.33,.22,.14], wh=[.9,.9,.88];
    L(-.26,-.4,.6,.24,br); L(.26,-.4,.6,.24,br); L(-.26,.4,.6,.24,br); L(.26,.4,.6,.24,br);
    part(base,0,1.0,0,0,.8,.72,1.2,br); part(base,.2,1.08,.1,0,.42,.5,.6,wh); part(base,0,1.2,-.74,0,.5,.5,.36,br); part(base,0,1.06,-.93,0,.34,.2,.04,[.85,.7,.65]);
    part(base,-.3,1.42,-.74,0,.12,.1,.08,wh); part(base,.3,1.42,-.74,0,.12,.1,.08,wh); part(base,-.12,1.3,-.93,0,.07,.07,.02,[.05,.05,.05]); part(base,.12,1.3,-.93,0,.07,.07,.02,[.05,.05,.05]); }
  ETINT=0;
}
// held block mesh for first person
const heldCache=new Map();
function heldMesh(id){
  if(heldCache.has(id)) return heldCache.get(id); const b=id>=256?{cross:true,side:itemDef(id).name}:W.blocks[id]; const v=[], idx=[];
  const uvr=(n)=>{ const i=W.tileOf[n]??0; const u0=(i%ATL)/ATL, v0=Math.floor(i/ATL)/ATL; return [u0,v0,u0+1/ATL,v0+1/ATL]; };
  if(b.cross){ const r=uvr(b.side); v.push(-.5,-.5,0,r[0],r[3],1,1,0,0, .5,-.5,0,r[2],r[3],1,1,0,0, .5,.5,0,r[2],r[1],1,1,0,0, -.5,.5,0,r[0],r[1],1,1,0,0); idx.push(0,1,2,0,2,3,0,2,1,0,3,2); }
  else { const F=[[[1,0,0],[0,0,-1],[0,1,0],'side',.7],[[-1,0,0],[0,0,1],[0,1,0],'side',.7],[[0,1,0],[1,0,0],[0,0,-1],'top',1],[[0,-1,0],[1,0,0],[0,0,1],'bottom',.5],[[0,0,1],[1,0,0],[0,1,0],'side',.85],[[0,0,-1],[-1,0,0],[0,1,0],'side',.85]];
    for(const [n,u,w,t,sh] of F){ const r=uvr(b[t]); const s=v.length/9; for(const [a,c,uu,vv] of [[-1,-1,r[0],r[3]],[1,-1,r[2],r[3]],[1,1,r[2],r[1]],[-1,1,r[0],r[1]]]) v.push(n[0]*.5+u[0]*a*.5+w[0]*c*.5,n[1]*.5+u[1]*a*.5+w[1]*c*.5,n[2]*.5+u[2]*a*.5+w[2]*c*.5,uu,vv,sh,1,b.light?1:0,0); idx.push(s,s+1,s+2,s,s+2,s+3); } }
  const m={vb:buf(gl.ARRAY_BUFFER,new Float32Array(v)),ib:buf(gl.ELEMENT_ARRAY_BUFFER,new Uint16Array(idx)),count:idx.length}; heldCache.set(id,m); return m;
}

/* ------------------------------------------------------------------ minimap */
const mapc=$('mapc'), mctx=mapc.getContext('2d'), mimg=mctx.createImageData(128,128);
function drawMap(){
  const px=Math.floor(P.x), pz=Math.floor(P.z); const d=mimg.data;
  for(let j=0;j<128;j++)for(let i=0;i<128;i++){ const x=px-64+i, z=pz-64+j; const c=W.chunks.get(key(fdiv(x,16),fdiv(z,16))); const o=(j*128+i)*4;
    if(!c){ d[o]=d[o+1]=d[o+2]=12; d[o+3]=255; continue; }
    const lx=x&15, lz=z&15; let y=CY-1, id=0; for(;y>0;y--){ id=c.b[(y*16+lz)*16+lx]; if(id&&!W.cross[id]) break; }
    let col=W.color[id]||[0,0,0];
    let hn=y; { const z2=z-1, c2=W.chunks.get(key(fdiv(x,16),fdiv(z2,16))); if(c2){ for(hn=CY-1;hn>0;hn--){ const k=c2.b[(hn*16+(z2&15))*16+lx]; if(k&&!W.cross[k]) break; } } }
    let f=1+clamp((y-hn)*.12,-.3,.3); if(W.liquid[id]&&!W.light[id]){ let dpt=0; for(let yy=y-1;yy>0&&W.liquid[c.b[(yy*16+lz)*16+lx]];yy--) dpt++; f=1-Math.min(dpt,10)*.05; }
    d[o]=col[0]*f; d[o+1]=col[1]*f; d[o+2]=col[2]*f; d[o+3]=255; }
  mctx.putImageData(mimg,0,0);
  for(const o of others.values()){ const x=o.x-P.x+64, z=o.z-P.z+64; if(x<2||z<2||x>126||z>126) continue; mctx.fillStyle=o.bot?'#ff2bd6':'#fff'; mctx.fillRect(x-2,z-2,4,4); }
  mctx.save(); mctx.translate(64,64); mctx.rotate(-P.yaw); mctx.fillStyle='#ffe04a'; mctx.strokeStyle='#000'; mctx.beginPath(); mctx.moveTo(0,-6); mctx.lineTo(4,4); mctx.lineTo(0,2); mctx.lineTo(-4,4); mctx.closePath(); mctx.fill(); mctx.stroke(); mctx.restore();
}

/* ------------------------------------------------------------------ drawing */
let dpr=1;
function resize(){ dpr=Math.min(window.devicePixelRatio||1,touchDevice?1.5:2); const w=Math.floor(innerWidth*dpr),h=Math.floor(innerHeight*dpr); if(canvas.width!==w||canvas.height!==h){ canvas.width=w; canvas.height=h; } }
addEventListener('resize',resize); resize();
function skyState(){ const ang=W.time*Math.PI*2; const sun=Math.sin(ang); const day=sstep(-.18,.22,sun);
  let sd=[Math.cos(ang),sun,.28]; const l=Math.hypot(...sd); sd=sd.map(v=>v/l);
  const zen=mixc([3,5,16],[78,140,236],day), hor0=mixc([12,14,34],[170,206,255],day);
  const dusk=Math.max(0,1-Math.abs(sun)/.32);
  const duskC=mixc(hor0,[255,128,72],dusk*.9);
  const hor=mixc(hor0,[240,150,110],dusk*.35);
  const sunC=mixc([1,1,1],[1,.72,.5],dusk*.8).map(v=>v);
  return {zen:zen.map(v=>v/255),hor:hor.map(v=>v/255),dusk:duskC.map(v=>v/255),sun:sd,day:.2+.8*day,night:1-day,sunC:mixc(sunC,[.62,.72,1],1-day)}; }
function frustum(vp){ const p=[]; const r=(a,b,c,d)=>{ const l=Math.hypot(a,b,c); p.push([a/l,b/l,c/l,d/l]); };
  r(vp[3]+vp[0],vp[7]+vp[4],vp[11]+vp[8],vp[15]+vp[12]); r(vp[3]-vp[0],vp[7]-vp[4],vp[11]-vp[8],vp[15]-vp[12]);
  r(vp[3]+vp[1],vp[7]+vp[5],vp[11]+vp[9],vp[15]+vp[13]); r(vp[3]-vp[1],vp[7]-vp[5],vp[11]-vp[9],vp[15]-vp[13]); return p; }
function boxVisible(F,x0,y0,z0,x1,y1,z1){ for(const [a,b,c,d] of F){ const x=a>0?x1:x0, y=b>0?y1:y0, z=c>0?z1:z0; if(a*x+b*y+c*z+d<0) return false; } return true; }
let loadStart=0, mapT=0, infoT=0;
function frame(now){
  requestAnimationFrame(frame);
  if(!joined||!atlasTex){ gl.clearColor(.05,.03,.1,1); gl.clear(gl.COLOR_BUFFER_BIT); return; }
  const dt=Math.min(.1,(now-(frame.t||now))/1000); frame.t=now; frame.fps=(frame.fps||60)*.95+(1/Math.max(dt,.001))*.05; const T=now/1000;
  resize();
  const pcx=fdiv(Math.floor(P.x),16), pcz=fdiv(Math.floor(P.z),16);
  // wait for the ground before falling
  const here=W.chunks.get(key(pcx,pcz));
  if($('loading').style.display==='block'){ let ready=0,total=0; for(let dx=-2;dx<=2;dx++)for(let dz=-2;dz<=2;dz++){ total++; const c=W.chunks.get(key(pcx+dx,pcz+dz)); if(c&&c.built) ready++; } $('lbar').style.width=(ready/total*100)+'%'; if(ready===total||now-loadStart>15000) $('loading').style.display='none'; }
  if(here&&here.built&&!SV.dead) physics(dt);
  W.time=(W.time+dt/1200)%1;
  if(now-lastSend>100){ lastSend=now; const hsp=Math.hypot(P.vx,P.vz); net({t:'pos',x:+P.x.toFixed(2),y:+P.y.toFixed(2),z:+P.z.toFixed(2),a:+P.yaw.toFixed(3),b:+P.pitch.toFixed(3),h:hotbar[sel]||0,s:swing>0?3:(hsp>.5?1:0)}); renderChat(); }
  target=raycast(isSurv()?5:7); mobTarget=mobRay(isSurv()?3.6:5); if(mobTarget&&target&&blockDist(target)<mobTarget.t) mobTarget=null; if(mobTarget) target=null;
  if(isSurv()) survFrame(dt,now);
  else if((holdBreak||holdPlace)&&now-lastAct>200){ lastAct=now; holdBreak?doBreak():doPlace(); }
  for(const [k,c] of W.chunks){ const d=Math.max(Math.abs(c.cx-pcx),Math.abs(c.cz-pcz)); if(d>W.view+3){ freeChunk(c); W.chunks.delete(k); worker.postMessage({t:'drop',cx:c.cx,cz:c.cz}); } }
  scheduleMeshes(pcx,pcz);
  const S=skyState(); const under=!!P.headWater; const lava=!!P.headLava;
  const fogEnd=lava?3:under?18:Math.max(32,W.view*16-4), fogStart=lava?0:under?1:fogEnd*.62;
  const fogC=lava?[.9,.3,.05]:under?[.05,.18,.42].map(v=>v*(.4+.6*S.day)):mixc(S.hor,S.dusk,.25);
  $('water').style.display=under?'block':'none'; $('water').classList.toggle('lava',lava);
  gl.viewport(0,0,canvas.width,canvas.height); gl.clearColor(fogC[0],fogC[1],fogC[2],1); gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
  const asp=canvas.width/canvas.height, proj=M.persp(P.fov*Math.PI/180,asp,.08,1400);
  const cp=Math.cos(P.pitch); const fx=-Math.sin(P.yaw)*cp, fy=Math.sin(P.pitch), fz=-Math.cos(P.yaw)*cp;
  const hsp=Math.hypot(P.vx,P.vz); const bob=CFG.bob&&P.onGround&&!P.fly?Math.min(1,hsp/4):0;
  const ex=P.x+Math.cos(P.yaw)*Math.sin(P.walk)*.04*bob, ey=P.y+(P.sneak?EYE-.12:EYE)+Math.abs(Math.cos(P.walk))*.07*bob-.035*bob, ez=P.z-Math.sin(P.yaw)*Math.sin(P.walk)*.04*bob;
  const view=M.look(ex,ey,ez,fx,fy,fz), vp=M.mul(proj,view);
  // sky
  gl.disable(gl.DEPTH_TEST); gl.useProgram(progSky.p); gl.bindBuffer(gl.ARRAY_BUFFER,quadVB); gl.enableVertexAttribArray(progSky.a.aPos); gl.vertexAttribPointer(progSky.a.aPos,2,gl.FLOAT,false,0,0);
  gl.uniformMatrix4fv(progSky.u.uInv,false,M.inv(M.mul(proj,M.look(0,0,0,fx,fy,fz)))); gl.uniform3fv(progSky.u.uZen,S.zen); gl.uniform3fv(progSky.u.uHor,S.hor); gl.uniform3fv(progSky.u.uSun,S.sun); gl.uniform3fv(progSky.u.uDusk,S.dusk); gl.uniform1f(progSky.u.uNight,S.night); gl.uniform1f(progSky.u.uUnder,under?1:0);
  if(!lava) gl.drawArrays(gl.TRIANGLES,0,6);
  gl.disableVertexAttribArray(progSky.a.aPos); gl.enable(gl.DEPTH_TEST);
  // world
  const F=frustum(vp);
  const vis=[]; for(const c of W.chunks.values()){ if(!c.built) continue; const x0=c.cx*16, z0=c.cz*16; const d=Math.hypot(x0+8-ex,z0+8-ez); if(d>(W.view+1.2)*16) continue; if(!boxVisible(F,x0,c.minY,z0,x0+16,c.maxY,z0+16)) continue; vis.push([d,c]); }
  vis.sort((a,b)=>a[0]-b[0]);
  const PW=progW; gl.useProgram(PW.p); gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D,atlasTex); gl.uniform1i(PW.u.uTex,0); gl.uniformMatrix4fv(PW.u.uMVP,false,vp); gl.uniform3f(PW.u.uCam,ex,ey,ez);
  gl.uniform3fv(PW.u.uFogC,fogC); gl.uniform2f(PW.u.uFog,fogStart,fogEnd); gl.uniform1f(PW.u.uDay,S.day); gl.uniform3fv(PW.u.uSunC,S.sunC); gl.uniform1f(PW.u.uCut,.5); gl.uniform1f(PW.u.uTime,T); gl.uniform1f(PW.u.uGlow,0);
  const aP=PW.a.aPos,aU=PW.a.aUV,aL=PW.a.aL; gl.enableVertexAttribArray(aP); gl.enableVertexAttribArray(aU); gl.enableVertexAttribArray(aL); gl.enable(gl.CULL_FACE); gl.cullFace(gl.BACK);
  const draw=(m)=>{ gl.bindBuffer(gl.ARRAY_BUFFER,m.vb); gl.vertexAttribPointer(aP,3,gl.FLOAT,false,36,0); gl.vertexAttribPointer(aU,2,gl.FLOAT,false,36,12); gl.vertexAttribPointer(aL,4,gl.FLOAT,false,36,20); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,m.ib); gl.drawElements(gl.TRIANGLES,m.count,gl.UNSIGNED_SHORT,0); };
  let tris=0; for(const [,c] of vis) for(const m of c.meshes){ draw(m); tris+=m.count/3; }
  gl.disableVertexAttribArray(aU); gl.disableVertexAttribArray(aL); gl.disable(gl.CULL_FACE);
  // players and animals
  EVP=vp; useE(vp,fogC,[fogStart,fogEnd]); gl.uniform3f(progE.u.uCam,ex,ey,ez);
  const tags=$('tags'); const have=new Set(); const sw=innerWidth, sh=innerHeight;
  const lerpE=(o,k)=>{ if(o.tx===undefined) return; const ox=o.x, oz=o.z; o.x+=(o.tx-o.x)*k; o.y+=(o.ty-o.y)*k; o.z+=(o.tz-o.z)*k; let d=o.tyaw-o.yaw; d=Math.atan2(Math.sin(d),Math.cos(d)); o.yaw+=d*k; const mvd=Math.hypot(o.x-ox,o.z-oz); o.walk+=mvd*3.2; if(o.moving===undefined||o.isP) o.moving=mvd>.004; };
  const k=Math.min(1,dt*10);
  ELIGHT=Math.max(.25,S.day);
  for(const [id,o] of others){ o.isP=true; lerpE(o,k); if(Math.hypot(o.x-ex,o.z-ez)>W.view*16+8) continue; drawHuman(o);
    have.add('p'+id); let el=document.getElementById('tagp'+id); if(!el){ el=document.createElement('div'); el.id='tagp'+id; tags.appendChild(el); }
    const showSay=o.say&&now-o.sayAt<6000; const txt=showSay?o.name+': '+o.say:o.name;
    if(el.textContent!==txt){ el.textContent=txt; el.className=showSay?'say':(o.bot?'bot':''); }
    const p=[o.x,o.y+2.15,o.z]; const cx=vp[0]*p[0]+vp[4]*p[1]+vp[8]*p[2]+vp[12], cy=vp[1]*p[0]+vp[5]*p[1]+vp[9]*p[2]+vp[13], cw=vp[3]*p[0]+vp[7]*p[1]+vp[11]*p[2]+vp[15];
    const dist=Math.hypot(o.x-ex,o.z-ez); if(cw>.1&&(dist<64||o.bot)){ el.style.display='block'; el.style.left=((cx/cw)*.5+.5)*sw+'px'; el.style.top=(1-((cy/cw)*.5+.5))*sh+'px'; el.style.opacity=dist>40?.6:1; } else el.style.display='none'; }
  for(const el of [...tags.children]) if(!have.has(el.id.slice(3))) el.remove();
  for(const o of mobs.values()){ lerpE(o,Math.min(1,dt*6)); if(Math.hypot(o.x-ex,o.z-ez)>W.view*16) continue; drawMob(o); }
  gl.disableVertexAttribArray(progE.a.aN); gl.disableVertexAttribArray(progE.a.aPos);
  // block outline
  if(target){ gl.useProgram(progL.p); gl.bindBuffer(gl.ARRAY_BUFFER,edgeVB); gl.enableVertexAttribArray(progL.a.aPos); gl.vertexAttribPointer(progL.a.aPos,3,gl.FLOAT,false,0,0);
    const m=M.mul(M.T(target.x-.002,target.y-.002,target.z-.002),M.S(1.004,1.004,1.004)); gl.uniformMatrix4fv(progL.u.uMVP,false,M.mul(vp,m)); gl.uniform4f(progL.u.uColor,0,0,0,.8); gl.drawArrays(gl.LINES,0,24); gl.disableVertexAttribArray(progL.a.aPos); }
  // particles
  if(parts.length){ const arr=new Float32Array(parts.length*6); let n=0;
    for(let i=parts.length-1;i>=0;i--){ const q=parts[i]; q.life-=dt; if(q.life<=0){ parts.splice(i,1); continue; } q.vy-=14*dt; const nx=q.x+q.vx*dt, ny=q.y+q.vy*dt, nz=q.z+q.vz*dt; if(isSolidAt(Math.floor(nx),Math.floor(ny),Math.floor(nz))){ q.vx*=.3; q.vz*=.3; q.vy=0; } else { q.x=nx; q.y=ny; q.z=nz; } const l=S.day; arr.set([q.x,q.y,q.z,q.c[0]*l,q.c[1]*l,q.c[2]*l],n*6); n++; }
    if(n){ gl.useProgram(progP.p); gl.bindBuffer(gl.ARRAY_BUFFER,partVB); gl.bufferData(gl.ARRAY_BUFFER,arr,gl.DYNAMIC_DRAW); gl.enableVertexAttribArray(progP.a.aPos); gl.enableVertexAttribArray(progP.a.aCol); gl.vertexAttribPointer(progP.a.aPos,3,gl.FLOAT,false,24,0); gl.vertexAttribPointer(progP.a.aCol,3,gl.FLOAT,false,24,12);
      gl.uniformMatrix4fv(progP.u.uVP,false,vp); gl.uniform1f(progP.u.uSize,canvas.height*.012); gl.drawArrays(gl.POINTS,0,n); gl.disableVertexAttribArray(progP.a.aPos); gl.disableVertexAttribArray(progP.a.aCol); } }
  drawCrack(vp); drawShots(vp,dt);
  drawGround(vp,dt,T,PW,draw,aP,aU,aL);
  // see-through: water and stained glass, far to near
  gl.useProgram(PW.p); gl.enableVertexAttribArray(aP); gl.enableVertexAttribArray(aU); gl.enableVertexAttribArray(aL); gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA); gl.depthMask(false); gl.uniform1f(PW.u.uCut,.02);
  for(let i=vis.length-1;i>=0;i--) for(const m of vis[i][1].trans) draw(m);
  // clouds
  if(CFG.clouds&&!under){ gl.disableVertexAttribArray(aU); gl.disableVertexAttribArray(aL); gl.disableVertexAttribArray(aP); gl.useProgram(progC.p); gl.bindBuffer(gl.ARRAY_BUFFER,quadVB); gl.enableVertexAttribArray(progC.a.aPos); gl.vertexAttribPointer(progC.a.aPos,2,gl.FLOAT,false,0,0);
    gl.uniformMatrix4fv(progC.u.uVP,false,vp); gl.uniform3f(progC.u.uCam,ex,ey,ez); gl.uniform1f(progC.u.uH,124); gl.uniform1f(progC.u.uT,T); const cl=mixc([.18,.19,.26],[1,1,1],S.day); gl.uniform3fv(progC.u.uCol,mixc(cl,S.dusk,.25*S.night*0+.15*(1-Math.abs(Math.sin(W.time*Math.PI*2))))); gl.uniform3fv(progC.u.uFogC,fogC);
    gl.drawArrays(gl.TRIANGLES,0,6); gl.disableVertexAttribArray(progC.a.aPos); }
  gl.depthMask(true); gl.disable(gl.BLEND);
  // first-person hand
  swing=Math.max(0,swing-dt*4);
  if(!document.body.classList.contains('nohud')){ gl.clear(gl.DEPTH_BUFFER_BIT); const hp=M.persp(70*Math.PI/180,asp,.05,10); const id=hotbar[sel]; const sa=Math.sin(swing*Math.PI);
    const bx=Math.sin(P.walk)*.03*bob, by=Math.abs(Math.cos(P.walk))*.03*bob;
    if(id&&W.blocks[id]){ const hm=heldMesh(id); const m=M.chain(hp,M.T(.56+bx-sa*.2,-.52+by-sa*.15,-1.0-sa*.1),M.Ry(.75-sa*.4),M.Rx(-sa*.8+.08),M.S(.32,.32,.32));
      gl.useProgram(PW.p); gl.enableVertexAttribArray(aP); gl.enableVertexAttribArray(aU); gl.enableVertexAttribArray(aL); gl.uniformMatrix4fv(PW.u.uMVP,false,m); gl.uniform3f(PW.u.uCam,0,0,0); gl.uniform2f(PW.u.uFog,1e4,2e4); gl.uniform1f(PW.u.uCut,.1); gl.uniform1f(PW.u.uDay,Math.max(.35,S.day)); gl.uniform1f(PW.u.uGlow,0);
      gl.enable(gl.BLEND); draw(hm); gl.disable(gl.BLEND); gl.disableVertexAttribArray(aU); gl.disableVertexAttribArray(aL); gl.disableVertexAttribArray(aP); }
    else { EVP=hp; useE(hp,[0,0,0],[1e4,2e4]); gl.uniform3f(progE.u.uCam,0,0,0); ELIGHT=Math.max(.4,S.day); part(M.I(),.55+bx,-.45+by-sa*.2,-.7,-1.1-sa,.16,.6,.16,[.93,.76,.62],true); gl.disableVertexAttribArray(progE.a.aN); gl.disableVertexAttribArray(progE.a.aPos); } }
  if(shot){ shot=false; canvas.toBlob(b=>{ if(!b) return; const a=document.createElement('a'); a.href=URL.createObjectURL(b); a.download='mir-'+new Date().toISOString().slice(0,19).replace(/[:T]/g,'-')+'.png'; a.click(); toast('📷 Снимок сохранён'); },'image/png'); }
  if(CFG.map&&now-mapT>400){ mapT=now; drawMap(); }
  if(now-infoT>250){ infoT=now; const b=target?W.blocks[target.id]:null; const hrs=(W.time*24+6)%24; const hh=Math.floor(hrs), mm=Math.floor((hrs-hh)*60);
    const dirs=['С','СЗ','З','ЮЗ','Ю','ЮВ','В','СВ']; const dir=dirs[((Math.round(P.yaw/(Math.PI/4))%8)+8)%8];
    const clock=`${String(hh).padStart(2,'0')}:${String(mm).padStart(2,'0')} ${hh>=6&&hh<20?'☀':'☾'}`;
    let s=`${Math.floor(P.x)} ${Math.floor(P.y)} ${Math.floor(P.z)} · ${dir} · ${clock}${P.fly?' · ✈':''}`;
    if(CFG.debug){ let q=0; for(const c of W.chunks.values()) if(c.dirty) q++; s+=`\n${Math.round(frame.fps)} fps · чанков ${W.chunks.size} (видно ${vis.length}) · очередь ${q}\nтреугольников ${(tris/1000).toFixed(0)}k · игроков ${others.size+1} · животных ${mobs.size}${b?'\n▸ '+b.label+' ('+target.x+' '+target.y+' '+target.z+')':''}`; }
    $('info').textContent=s; }
}
requestAnimationFrame(frame);

/* ------------------------------------------------------------------ login */
{ const sp=new URLSearchParams(location.search); $('nm').value=store.get('name')||''; $('ky').value=sp.get('key')||sp.get('token')||store.get('key')||'';
  $('lf').addEventListener('submit',e=>{ e.preventDefault(); audio(); const n=$('nm').value.trim()||'Игрок', k=$('ky').value.trim(); store.set('name',n); store.set('key',k); $('err').textContent='Заходим…'; if(ws) try{ ws.onclose=null; ws.close(); }catch{} connect(n,k); if(!touchDevice) canvas.requestPointerLock?.(); });
  if($('nm').value&&sp.get('auto')==='1') setTimeout(()=>$('lf').requestSubmit(),50); }
window.addEventListener('error',e=>{ const m=document.getElementById('msg'); m.textContent='Ошибка: '+e.message; m.style.display='block'; });
window.__w={W,P,others,mobs,hotbar,get target(){return target;},get ws(){return ws;},raycast,setBlockLocal,getBlock,CFG};
