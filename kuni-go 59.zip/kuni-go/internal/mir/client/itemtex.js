/* ------------------------------------------------------------------ survival textures: new blocks and items */
const MATC={wood:[150,112,62],stone:[128,128,128],iron:[220,220,226],diamond:[90,226,214],leather:[150,90,50],gold:[250,214,60]};
const HANDLE=[112,80,44];
function diag(t,from,to,c){ for(let i=from;i<=to;i++){ t.set(i,15-i,c); } }
const toolOf=(kind,c)=>t=>{ t.clear(); const d=c.map(v=>v*.65);
  diag(t,1,9,HANDLE); diag(t,2,9,HANDLE.map(v=>v*.8)); for(let i=1;i<=9;i++) t.set(i+1,15-i,HANDLE.map(v=>v*.7));
  if(kind==='pickaxe'){ for(let i=0;i<9;i++){ t.set(4+i,2+Math.abs(i-4)*0+ (i<2||i>6?1:0),c); t.set(4+i,3+(i<2||i>6?1:0),d);} t.rect(3,4,2,2,c); t.rect(12,4,2,2,c); t.rect(8,2,2,3,d); }
  else if(kind==='axe'){ t.rect(7,2,5,6,c); t.rect(6,3,1,4,c); t.rect(11,3,2,3,d); t.rect(7,7,4,1,d); }
  else if(kind==='shovel'){ t.rect(10,1,4,4,c); t.rect(11,5,2,1,d); t.set(13,1,d); }
  else if(kind==='sword'){ t.clear(); for(let i=0;i<10;i++){ t.set(5+i,10-i,c); t.set(6+i,10-i,d); t.set(5+i,9-i,c.map(v=>Math.min(255,v*1.15))); } t.rect(3,10,5,2,[90,70,40]); t.rect(5,8,2,6,[90,70,40]); t.rect(2,13,2,2,HANDLE); t.set(4,12,HANDLE); }
  else if(kind==='hoe'){ t.rect(7,2,6,2,c); t.rect(11,4,2,1,d); }
  return t; };
const armorOf=(slot,c)=>t=>{ t.clear(); const d=c.map(v=>v*.7);
  if(slot===1){ t.rect(3,4,10,3,c); t.rect(3,7,3,4,c); t.rect(10,7,3,4,c); t.rect(4,5,8,1,d); }
  else if(slot===2){ t.rect(2,2,4,4,c); t.rect(10,2,4,4,c); t.rect(4,4,8,10,c); t.rect(7,4,2,3,[0,0,0],0); t.rect(5,8,6,1,d); }
  else if(slot===3){ t.rect(3,2,10,3,c); t.rect(3,5,4,9,c); t.rect(9,5,4,9,c); t.rect(3,3,10,1,d); }
  else { t.rect(2,8,4,5,c); t.rect(10,8,4,5,c); t.rect(1,12,5,2,d); t.rect(10,12,5,2,d); }
  return t; };
const gem=(c)=>t=>{ t.clear(); const d=c.map(v=>v*.6), l=c.map(v=>Math.min(255,v*1.3)); t.rect(5,3,6,10,c); t.rect(3,5,10,6,c); t.rect(4,4,8,8,c); t.rect(5,4,2,2,l); t.rect(9,10,3,2,d); t.rect(11,6,1,4,d); return t; };
const ingot=(c)=>t=>{ t.clear(); const d=c.map(v=>v*.65), l=c.map(v=>Math.min(255,v*1.2)); t.rect(2,7,12,5,c); t.rect(4,5,10,2,l); t.rect(2,11,12,1,d); t.rect(13,6,1,6,d); return t; };
const lump=(c,n=7)=>t=>{ t.clear(); for(let i=0;i<n;i++){ const x=3+Math.floor(t.r(i,0,4)*9), y=3+Math.floor(t.r(i,1,4)*9); t.rect(x,y,3,3,c.map(v=>v*(.8+t.r(i,2,4)*.4))); } return t; };
const meat=(c,fat,bone)=>t=>{ t.clear(); t.rect(3,4,9,8,c); t.rect(4,3,7,10,c); t.rect(4,4,3,2,fat); t.rect(9,9,2,2,fat); if(bone){ t.rect(11,10,4,2,[240,236,220]); t.rect(13,9,2,4,[240,236,220]); } for(let i=0;i<10;i++) t.set(4+Math.floor(t.r(i,0,6)*7),4+Math.floor(t.r(i,1,6)*7),c.map(v=>v*.8)); return t; };
Object.assign(PAINT,{
  farmland:t=>{ t.fill([100,66,40],16); for(let y=1;y<16;y+=3) t.rect(0,y,16,1,[76,48,30]); return t; },
  wheat_0:t=>{ t.clear(); for(const x of [3,7,11]) t.rect(x,12,1,4,[80,170,50]); return t; },
  wheat_1:t=>{ t.clear(); for(const x of [2,5,8,11,13]) t.rect(x,9,1,7,[90,170,50]); return t; },
  wheat_2:t=>{ t.clear(); for(const x of [1,4,7,10,13]){ t.rect(x,5,1,11,[130,170,50]); t.rect(x,5,2,3,[160,170,60]); } return t; },
  wheat_3:t=>{ t.clear(); for(const x of [1,4,7,10,13]){ t.rect(x,4,1,12,[180,150,50]); t.rect(x-1,2,3,5,[220,190,80]); t.set(x,1,[230,200,90]); } return t; },
  sapling:t=>{ t.clear(); t.rect(7,9,2,7,[100,70,40]); t.rect(4,3,8,6,[60,140,40]); t.rect(5,1,6,2,[70,150,50]); t.rect(3,5,2,3,[50,120,35]); t.speckle([0,0,0],0); return t; },
  chest_side:t=>{ planksOf([160,112,48])(t); t.border([80,52,20]); t.rect(0,5,16,1,[80,52,20]); t.rect(7,4,2,3,[200,200,210]); return t; },
  chest_top:t=>{ planksOf([160,112,48])(t); t.border([80,52,20]); return t; },
  bed_top:t=>{ t.fill([180,40,40],10); t.rect(0,0,16,5,[236,236,236]); t.border([120,30,30]); return t; },
  bed_side:t=>{ t.clear(); t.rect(0,4,16,6,[180,40,40]); t.rect(0,4,5,6,[236,236,236]); t.rect(0,10,16,3,[150,110,60]); t.rect(0,13,2,3,[120,86,46]); t.rect(14,13,2,3,[120,86,46]); return t; },
  ladder:t=>{ t.clear(); t.rect(2,0,2,16,[130,96,52]); t.rect(12,0,2,16,[130,96,52]); for(const y of [2,6,10,14]) t.rect(2,y,12,2,[150,112,62]); return t; },
  cobweb:t=>{ t.clear(); const c=[230,230,236]; for(let i=0;i<16;i++){ t.set(i,i,c); t.set(15-i,i,c); t.set(8,i,c); t.set(i,8,c); } for(const r of [3,6]){ for(let a=0;a<24;a++){ const an=a/24*Math.PI*2; t.set(8+Math.round(Math.cos(an)*r),8+Math.round(Math.sin(an)*r),c); } } return t; },
  stick:t=>{ t.clear(); diag(t,2,13,HANDLE); diag(t,3,13,HANDLE.map(v=>v*.75)); return t; },
  coal:lump([40,40,44]), charcoal:lump([60,50,40]), flint:lump([70,70,76],5),
  iron_ingot:ingot([216,216,222]), gold_ingot:ingot([250,214,60]), copper_ingot:ingot([214,120,80]),
  diamond:gem([90,226,214]), emerald:gem([60,210,100]), lapis:gem([40,70,190]), redstone:lump([220,20,20],9),
  wheat:t=>{ t.clear(); for(let i=0;i<5;i++){ diag(t,2+i,12,[200,170,70]); } t.rect(10,1,5,5,[220,190,80]); return t; },
  seeds:t=>{ t.clear(); for(let i=0;i<8;i++) t.rect(3+Math.floor(t.r(i,0,1)*10),4+Math.floor(t.r(i,1,1)*9),2,1,[80,160,50]); return t; },
  bone:t=>{ t.clear(); diag(t,3,12,[240,236,220]); diag(t,4,12,[220,216,200]); t.rect(1,12,3,3,[240,236,220]); t.rect(12,1,3,3,[240,236,220]); return t; },
  bone_meal:lump([240,240,236],9), string:t=>{ t.clear(); for(let i=0;i<14;i++) t.set(1+i,8+Math.round(Math.sin(i*.8)*3),[240,240,240]); return t; },
  gunpowder:lump([90,90,90],10), leather:t=>{ t.clear(); t.rect(3,3,10,10,[150,90,50]); t.rect(2,5,12,6,[150,90,50]); t.speckle([120,70,40],.15); for(let i=0;i<256;i++) if(t.d[i*4+3]===255&&(i%16<2||i%16>13)&&(i<48||i>207)) t.d[i*4+3]=0; return t; },
  feather:t=>{ t.clear(); diag(t,2,13,[230,230,230]); for(let i=4;i<13;i++){ t.set(i-1,15-i-1,[245,245,245]); t.set(i+1,15-i+1,[220,220,220]); } return t; },
  apple:t=>{ t.clear(); t.rect(4,5,8,8,[210,30,30]); t.rect(3,6,10,6,[210,30,30]); t.rect(5,6,2,2,[255,120,120]); t.rect(7,2,1,3,[100,70,40]); t.rect(8,2,3,2,[60,150,40]); return t; },
  golden_apple:t=>{ PAINT.apple(t); for(let i=0;i<t.d.length;i+=4) if(t.d[i]===210){ t.d[i]=250; t.d[i+1]=210; t.d[i+2]=50; } return t; },
  bread:t=>{ t.clear(); t.rect(2,6,12,6,[190,130,60]); t.rect(3,5,10,1,[210,150,70]); for(const x of [5,8,11]) t.rect(x,6,1,3,[150,100,40]); return t; },
  mushroom_stew:t=>{ t.clear(); t.rect(2,7,12,5,[120,86,46]); t.rect(3,12,10,2,[100,70,40]); t.rect(3,6,10,2,[190,140,90]); t.rect(5,5,2,2,[210,40,40]); return t; },
  porkchop:meat([240,140,150],[255,220,220]), cooked_porkchop:meat([200,140,90],[240,210,160]),
  beef:meat([200,50,50],[240,200,200],1), steak:meat([130,80,50],[200,160,120],1),
  chicken:meat([240,200,180],[255,240,230],1), cooked_chicken:meat([210,150,80],[240,200,140],1),
  mutton:meat([210,70,70],[240,220,220]), cooked_mutton:meat([150,90,60],[210,170,120]),
  rotten_flesh:meat([130,120,60],[90,120,60]),
});
for(const [m,c] of Object.entries(MATC)) for(const k of ['pickaxe','axe','shovel','sword','hoe']) PAINT[m+'_'+k]=toolOf(k,c);
for(const m of ['leather','iron','diamond']) ['helmet','chestplate','leggings','boots'].forEach((n,i)=>PAINT[m+'_'+n]=armorOf(i+1,MATC[m]));
