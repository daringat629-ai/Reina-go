/* ------------------------------------------------------------------ textures: every picture is painted here, 16x16 */
function hash32(n){ n=(n^61)^(n>>>16); n=(n+(n<<3))|0; n=n^(n>>>4); n=Math.imul(n,0x27d4eb2d); n=n^(n>>>15); return (n>>>0)/4294967296; }
function seedOf(s){ let h=2166136261; for (let i=0;i<s.length;i++){ h^=s.charCodeAt(i); h=Math.imul(h,16777619); } return h>>>0; }
class Tile {
  constructor(name){ this.d=new Uint8ClampedArray(16*16*4); this.s=seedOf(name); }
  r(x,y,k=0){ return hash32(this.s + x*73856093 + y*19349663 + k*83492791); }
  set(x,y,c,a=255){ x|=0; y|=0; if(x<0||y<0||x>15||y>15)return; const i=(y*16+x)*4; this.d[i]=c[0]; this.d[i+1]=c[1]; this.d[i+2]=c[2]; this.d[i+3]=a; }
  get(x,y){ const i=(y*16+x)*4; return [this.d[i],this.d[i+1],this.d[i+2],this.d[i+3]]; }
  fill(b,v=20,k=1){ for(let y=0;y<16;y++)for(let x=0;x<16;x++){ const o=(this.r(x,y,k)-.5)*v; this.set(x,y,[b[0]+o,b[1]+o,b[2]+o]); } return this; }
  clear(){ this.d.fill(0); return this; }
  rect(x0,y0,w,h,c,a=255){ for(let y=y0;y<y0+h;y++)for(let x=x0;x<x0+w;x++) this.set(x,y,c,a); return this; }
  speckle(c,p,k=5){ for(let y=0;y<16;y++)for(let x=0;x<16;x++) if(this.r(x,y,k)<p) this.set(x,y,c); return this; }
  blobs(c,n,k=9){ for(let i=0;i<n;i++){ const x=Math.floor(this.r(i,0,k)*13)+1,y=Math.floor(this.r(i,1,k)*13)+1; for(const [dx,dy] of [[0,0],[1,0],[0,1],[1,1],[-1,0]]) if(this.r(i,dx*3+dy,k+1)<.85){ const o=(this.r(i,dx+dy*5,k+2)-.5)*40; this.set(x+dx,y+dy,[c[0]+o,c[1]+o,c[2]+o]); } } return this; }
  lines(h,c,off=0){ for(let y=off;y<16;y+=h)for(let x=0;x<16;x++) this.set(x,y,c); return this; }
  border(c){ for(let i=0;i<16;i++){ this.set(i,0,c); this.set(i,15,c); this.set(0,i,c); this.set(15,i,c); } return this; }
  shade(f){ for(let i=0;i<this.d.length;i+=4){ this.d[i]*=f; this.d[i+1]*=f; this.d[i+2]*=f; } return this; }
}
const dirtC=[134,96,67], stoneC=[125,125,125];
const COLORS={white:[234,236,237],light_gray:[142,142,135],gray:[62,68,72],black:[22,22,27],brown:[114,72,40],red:[160,39,34],orange:[240,118,19],yellow:[248,198,39],lime:[112,185,25],green:[84,109,27],cyan:[21,137,145],light_blue:[58,175,217],blue:[53,57,157],purple:[121,42,172],magenta:[189,68,179],pink:[237,141,172]};
const ore=(c)=>t=>t.fill(stoneC,22).blobs(c,7);
const planksOf=(c)=>t=>{ t.fill(c,12); t.lines(4,c.map(v=>v*.68),3); for(let r=0;r<4;r++){ const sx=Math.floor(t.r(r,0,2)*14)+1; for(let y=r*4;y<r*4+3;y++) t.set(sx,y,c.map(v=>v*.75)); } for(let y=0;y<16;y++)for(let x=0;x<16;x++) if(t.r(x,y,4)<.1) t.set(x,y,c.map(v=>v*.88)); return t; };
const logSideOf=(c,stripe)=>t=>{ for(let y=0;y<16;y++)for(let x=0;x<16;x++){ const o=(hash32(t.s+x*7)-.5)*30+(t.r(x,y,1)-.5)*10; t.set(x,y,[c[0]+o,c[1]+o,c[2]+o]); } if(stripe) for(let i=0;i<14;i++){ const x=Math.floor(t.r(i,0,3)*14), y=Math.floor(t.r(i,1,3)*16); t.rect(x,y,2+Math.floor(t.r(i,2,3)*2),1,stripe); } return t; };
const logTopOf=(bark,a,b)=>t=>{ for(let y=0;y<16;y++)for(let x=0;x<16;x++){ const d=Math.max(Math.abs(x-7.5),Math.abs(y-7.5)); const ring=Math.floor(d)%2; const o=(t.r(x,y,1)-.5)*10; const c=d>6.6?bark:ring?a:b; t.set(x,y,[c[0]+o,c[1]+o,c[2]+o]); } return t; };
const leavesOf=(c,hole=.18)=>t=>{ for(let y=0;y<16;y++)for(let x=0;x<16;x++){ const o=(t.r(x,y,1)-.5)*55; if(t.r(x,y,2)<hole) t.set(x,y,[0,0,0],0); else t.set(x,y,[c[0]+o,c[1]+o,c[2]+o*.6]); } return t; };
const blockOf=(c,edge)=>t=>{ t.fill(c,14); t.border(edge); for(let i=2;i<6;i++) t.set(i,2,c.map(v=>Math.min(255,v*1.18))); t.set(2,3,c.map(v=>Math.min(255,v*1.18))); return t; };
const bricksOf=(c,m,rows=4,len=8)=>t=>{ for(let y=0;y<16;y++)for(let x=0;x<16;x++){ const row=Math.floor(y/rows),mx=(x+(row%2)*(len/2))%len; const mortar=y%rows===rows-1||mx===len-1; const o=(t.r(x,y,1)-.5)*22; t.set(x,y,mortar?m:[c[0]+o,c[1]+o*.6,c[2]+o*.6]); } return t; };
const flowerOf=(petal,center,stem=[58,150,48])=>t=>{ t.clear(); t.rect(7,8,2,8,stem); t.rect(9,11,2,2,stem); t.rect(5,12,2,2,stem); t.rect(5,3,6,5,petal); t.rect(4,4,8,3,petal); t.set(4,3,[0,0,0],0); t.rect(7,4,2,3,center); return t; };
const glassOf=(c,a)=>t=>{ t.rect(0,0,16,16,c,a); t.border(c.map(v=>v*.8)); for(let i=0;i<16;i++){ t.set(i,0,c.map(v=>v*.8),235); t.set(i,15,c.map(v=>v*.8),235); t.set(0,i,c.map(v=>v*.8),235); t.set(15,i,c.map(v=>v*.8),235);} for(const [x,y] of [[3,3],[4,4],[5,5],[10,9],[11,10]]) t.set(x,y,[255,255,255],Math.min(255,a+80)); return t; };
const PAINT={
  dirt:t=>t.fill(dirtC,26).speckle([110,78,52],.12),
  stone:t=>t.fill(stoneC,20).speckle([105,105,105],.15,7).speckle([145,145,145],.08,8),
  cobble:t=>{ t.fill([120,120,120],18); for(let y=0;y<16;y++)for(let x=0;x<16;x++){ const sx=x+(Math.floor(y/4)%2)*2; const cx=Math.floor(sx/4),cy=Math.floor(y/4); const edge=(sx%4===0)||y%4===0; const o=(hash32(cx*31+cy*17+5)-.5)*34+(t.r(x,y,3)-.5)*12; t.set(x,y,edge?[74,74,74]:[132+o,132+o,132+o]); } return t; },
  sand:t=>t.fill([219,207,163],14).speckle([196,182,140],.12),
  red_sand:t=>t.fill([190,102,33],14).speckle([160,82,26],.15),
  gravel:t=>t.fill([134,130,128],30).speckle([96,94,94],.18).speckle([170,166,164],.1,6),
  grass_top:t=>t.fill([95,159,53],28).speckle([80,140,44],.2,3).speckle([115,178,66],.1,4),
  grass_side:t=>{ t.fill(dirtC,26); for(let x=0;x<16;x++){ const h=3+(t.r(x,0,3)<.5?1:0)+(t.r(x,0,4)<.25?2:0); for(let y=0;y<h;y++){ const o=(t.r(x,y,2)-.5)*26; t.set(x,y,[95+o,159+o,53+o]); } } return t; },
  podzol:t=>t.fill([106,70,30],26).speckle([80,52,20],.25).speckle([128,92,40],.1,6),
  moss:t=>t.fill([89,109,45],26).speckle([70,92,34],.25),
  log_side:logSideOf([104,82,52]), log_top:logTopOf([84,66,40],[176,142,92],[160,126,78]),
  birch_side:t=>{ t.fill([216,214,208],10); for(let i=0;i<10;i++){ const x=Math.floor(t.r(i,0,3)*13), y=Math.floor(t.r(i,1,3)*16); t.rect(x,y,2+Math.floor(t.r(i,2,3)*3),1,[40,40,36]); } return t; },
  birch_top:logTopOf([216,214,208],[200,180,126],[186,166,112]),
  spruce_side:logSideOf([60,42,24],[44,30,16]), spruce_top:logTopOf([60,42,24],[124,92,54],[110,80,46]),
  cherry_side:logSideOf([62,32,40],[44,22,30]), cherry_top:logTopOf([62,32,40],[222,160,160],[200,140,140]),
  planks:planksOf([164,131,79]), birch_planks:planksOf([196,178,122]), spruce_planks:planksOf([114,84,48]), dark_planks:planksOf([66,43,20]), cherry_planks:planksOf([226,178,172]),
  leaves:leavesOf([56,128,40]), birch_leaves:leavesOf([108,150,64]), spruce_leaves:leavesOf([48,86,52],.12), cherry_leaves:leavesOf([238,160,200],.15),
  water:t=>{ t.fill([44,96,206],14); for(let y=0;y<16;y++)for(let x=0;x<16;x++){ const w=Math.sin((x+y*.5)*0.9)+Math.sin(y*1.3-x*.4); if(w>1.2) t.set(x,y,[90,140,230]); } for(let i=0;i<t.d.length;i+=4) t.d[i+3]=180; return t; },
  lava:t=>{ t.fill([220,90,20],30); for(let y=0;y<16;y++)for(let x=0;x<16;x++){ const w=Math.sin(x*.8+y*.3)+Math.cos(y*.9-x*.5); if(w>.9) t.set(x,y,[255,190,60]); else if(w<-1.2) t.set(x,y,[160,40,10]); } return t; },
  snow:t=>t.fill([244,249,255],8), snow_bricks:bricksOf([236,242,250],[200,212,228],8,8),
  snow_side:t=>{ t.fill(dirtC,26); for(let x=0;x<16;x++){ const h=4+(t.r(x,0,3)<.5?1:0); for(let y=0;y<h;y++) t.set(x,y,[244-t.r(x,y,2)*10,249-t.r(x,y,2)*8,255]); } return t; },
  sandstone:t=>{ t.fill([216,201,150],12); t.lines(5,[196,181,130],4); t.rect(0,0,16,2,[226,212,162]); return t; },
  sandstone_top:t=>t.fill([218,204,154],10),
  bedrock:t=>t.fill([70,70,72],48).blobs([30,30,32],9),
  glass:glassOf([200,230,240],40),
  brick:bricksOf([156,78,62],[190,184,176]),
  mud_bricks:bricksOf([138,104,80],[110,82,62]),
  stone_bricks:bricksOf([128,128,128],[84,84,84],8,8),
  mossy_bricks:t=>{ bricksOf([128,128,128],[84,84,84],8,8)(t); for(let y=0;y<16;y++)for(let x=0;x<16;x++) if(t.r(x,y,8)<.3) t.set(x,y,[70+t.r(x,y,1)*30,110+t.r(x,y,2)*30,50]); return t; },
  coal_ore:ore([36,36,40]), iron_ore:ore([216,176,148]), gold_ore:ore([252,224,72]), diamond_ore:ore([92,228,216]), copper_ore:ore([208,116,72]), emerald_ore:ore([60,210,100]), lapis_ore:ore([40,70,190]), redstone_ore:ore([220,20,20]),
  cactus_side:t=>{ t.fill([32,122,52],18); for(let y=1;y<16;y+=3)for(let x=1;x<16;x+=4) t.set(x,y,[210,230,160]); for(let y=0;y<16;y++){ t.set(0,y,[20,84,36]); t.set(15,y,[20,84,36]); t.set(5,y,[26,104,44]); t.set(10,y,[26,104,44]); } return t; },
  cactus_top:t=>{ t.fill([40,140,60],14); t.border([20,84,36]); t.rect(6,6,4,4,[60,160,80]); return t; },
  bookshelf:t=>{ planksOf([164,131,79])(t); t.rect(0,2,16,5,[60,42,24]); t.rect(0,9,16,5,[60,42,24]); const cols=[[170,50,50],[50,100,170],[60,150,70],[200,170,60],[130,60,160],[200,200,190]]; for(let r=0;r<2;r++)for(let x=1;x<15;x++){ if(t.r(x,r,6)<.15) continue; const c=cols[Math.floor(t.r(x,r,5)*cols.length)]; const h=3+Math.floor(t.r(x,r,7)*2); t.rect(x,2+r*7+(5-h),1,h,c); } return t; },
  craft_top:t=>{ planksOf([164,131,79])(t); t.border([90,66,36]); for(const p of [5,10]){ t.rect(p,1,1,14,[110,84,48]); t.rect(1,p,14,1,[110,84,48]); } return t; },
  craft_side:t=>{ planksOf([164,131,79])(t); t.rect(0,0,16,2,[96,70,40]); t.rect(2,5,4,6,[70,70,78]); t.rect(9,4,5,3,[190,190,200]); t.rect(10,8,3,5,[120,86,50]); return t; },
  furnace_side:t=>{ t.fill([112,112,112],20); t.rect(3,4,10,8,[40,40,44]); t.rect(4,5,8,6,[20,20,24]); t.rect(5,9,6,2,[250,150,40]); t.rect(6,8,4,1,[255,210,80]); return t; },
  lamp:t=>{ t.fill([255,214,110],18); t.lines(4,[214,160,60],3); for(let x=3;x<16;x+=4) t.rect(x,0,1,16,[214,160,60]); return t; },
  glowstone:t=>{ t.fill([220,170,90],30); t.speckle([255,240,170],.3).speckle([170,120,60],.15,8); return t; },
  sea_lantern:t=>{ t.fill([200,230,224],14); t.border([160,200,196]); t.rect(4,4,8,8,[240,255,250]); t.speckle([170,220,210],.1); return t; },
  lantern_block:t=>{ t.fill([230,80,60],14); t.rect(0,0,16,2,[60,40,30]); t.rect(0,14,16,2,[60,40,30]); t.rect(3,4,10,8,[255,200,120]); t.lines(3,[200,60,40],3); return t; },
  torch:t=>{ t.clear(); t.rect(7,8,2,8,[110,80,45]); t.rect(7,6,2,2,[255,220,90]); t.set(7,6,[255,255,200]); return t; },
  obsidian:t=>t.fill([24,16,38],14).speckle([86,50,140],.07),
  ice:t=>{ t.fill([150,196,244],16).speckle([220,240,255],.08); for(let i=0;i<t.d.length;i+=4) t.d[i+3]=255; return t; },
  packed_ice:t=>t.fill([140,180,236],10).speckle([180,210,250],.12),
  clay:t=>t.fill([160,166,178],10),
  mossy:t=>{ PAINT.cobble(t); for(let y=0;y<16;y++)for(let x=0;x<16;x++) if(t.r(x,y,8)<.28) t.set(x,y,[60+t.r(x,y,1)*30,110+t.r(x,y,2)*30,50]); return t; },
  flower_red:flowerOf([210,40,50],[40,30,30]), flower_yellow:flowerOf([246,208,50],[200,120,30]), flower_blue:flowerOf([70,110,230],[240,240,120]), flower_white:flowerOf([240,240,240],[250,200,40]), flower_pink:t=>{ t.clear(); t.rect(7,7,2,9,[58,150,48]); t.rect(5,9,2,3,[58,150,48]); t.rect(6,2,4,6,[240,120,170]); t.rect(5,3,6,3,[240,120,170]); t.rect(7,2,2,1,[250,180,210]); return t; },
  tall_grass:t=>{ t.clear(); for(let x=1;x<15;x+=1){ if(t.r(x,0,9)<.35) continue; const h=5+Math.floor(t.r(x,0,1)*10); for(let y=16-h;y<16;y++){ const xx=x+Math.round((16-y)/h*(t.r(x,1,1)-.5)*3); t.set(xx,y,[70+t.r(x,y,2)*40,150+t.r(x,y,3)*30,50]); } } return t; },
  fern:t=>{ t.clear(); for(let y=2;y<16;y++){ t.set(8,y,[50,120,40]); const w=Math.floor((16-y)/3)+1; if(y%2===0) for(let i=1;i<=w;i++){ t.set(8-i,y-i/2,[60,140,50]); t.set(8+i,y-i/2,[60,140,50]); } } return t; },
  dead_bush:t=>{ t.clear(); const c=[112,80,40]; for(let y=6;y<16;y++) t.set(8,y,c); for(let i=0;i<5;i++){ t.set(8-i,7+i%2-(i>2?1:0),c); t.set(9+i,6+i%2,c); t.set(6-i/2|0,10-i,c); } return t; },
  mushroom_red:t=>{ t.clear(); t.rect(7,9,2,7,[230,220,200]); t.rect(4,5,8,4,[210,30,30]); t.rect(5,4,6,1,[210,30,30]); t.set(5,6,[255,255,255]); t.set(9,5,[255,255,255]); t.set(10,7,[255,255,255]); return t; },
  mushroom_brown:t=>{ t.clear(); t.rect(7,10,2,6,[220,210,190]); t.rect(4,7,8,3,[150,110,80]); t.rect(5,6,6,1,[150,110,80]); return t; },
  sugar_cane:t=>{ t.clear(); for(const x of [3,8,12]){ for(let y=0;y<16;y++) t.set(x,y,[140,190,90]); t.set(x+1,(x*3)%16,[100,160,70]); for(let y=x%5;y<16;y+=5) t.set(x,y,[180,220,120]); } return t; },
  iron_block:blockOf([222,222,226],[170,170,176]), gold_block:blockOf([250,222,74],[200,160,30]), diamond_block:blockOf([100,230,222],[50,170,170]), emerald_block:blockOf([60,210,110],[30,150,70]), lapis_block:blockOf([40,70,190],[24,44,130]), copper_block:blockOf([200,110,76],[150,80,56]),
  amethyst:t=>{ t.fill([140,90,200],30); t.speckle([200,160,250],.2).speckle([100,60,160],.2,8); return t; },
  pumpkin_side:t=>{ t.fill([220,130,30],14); for(let x=1;x<16;x+=4) t.rect(x,0,1,16,[180,100,20]); return t; },
  pumpkin_top:t=>{ t.fill([210,124,28],14); t.rect(7,7,2,2,[90,70,30]); return t; },
  jack_side:t=>{ PAINT.pumpkin_side(t); const f=[255,210,80]; t.rect(3,4,3,3,f); t.rect(10,4,3,3,f); t.rect(3,10,10,2,f); t.rect(5,12,2,1,f); t.rect(9,12,2,1,f); return t; },
  melon_side:t=>{ t.fill([110,160,30],14); for(let x=0;x<16;x+=3) t.rect(x,0,1,16,[60,110,20]); return t; },
  melon_top:t=>{ t.fill([110,160,30],14); t.border([80,130,20]); t.rect(7,7,2,2,[140,110,50]); return t; },
  hay_side:t=>{ t.fill([200,170,40],20); t.lines(2,[170,140,30],1); t.rect(0,3,16,2,[140,80,30]); t.rect(0,11,16,2,[140,80,30]); return t; },
  hay_top:t=>{ t.fill([190,160,40],30); t.speckle([150,120,20],.2); return t; },
  granite:t=>t.fill([150,104,86],20).speckle([180,130,110],.2).speckle([110,70,60],.15,7),
  diorite:t=>t.fill([200,200,200],20).speckle([140,140,140],.2).speckle([240,240,240],.15,7),
  andesite:t=>t.fill([132,134,132],16).speckle([100,102,100],.25).speckle([160,160,160],.1,7),
  terracotta:t=>t.fill([152,94,68],8), terracotta_orange:t=>t.fill([162,84,38],8), terracotta_white:t=>t.fill([210,178,162],8),
  quartz:t=>t.fill([236,230,222],5), quartz_pillar:t=>{ t.fill([236,230,222],5); t.rect(3,0,1,16,[210,204,196]); t.rect(12,0,1,16,[210,204,196]); return t; },
  prismarine:t=>{ t.fill([90,160,150],24); t.speckle([60,120,140],.25).speckle([130,200,180],.12,7); return t; },
  tnt_side:t=>{ t.fill([200,50,40],14); t.rect(0,5,16,6,[230,230,220]); for(const [x,ch] of [[2,0],[6,1],[10,0]]){ t.rect(x,6,3,1,[20,20,20]); t.rect(x+1,6,1,4,[20,20,20]); } return t; },
  tnt_top:t=>{ t.fill([200,50,40],10); t.rect(6,6,4,4,[60,60,60]); return t; },
};
for (const [n,c] of Object.entries(COLORS)){ PAINT['wool_'+n]=t=>{ t.fill(c,12); for(let y=0;y<16;y++)for(let x=0;x<16;x++) if((x+y*3)%7===0) t.set(x,y,c.map(v=>v*.88)); return t; }; PAINT['concrete_'+n]=t=>t.fill(c,5); PAINT['sglass_'+n]=glassOf(c,140); }
PAINT.sglass_black=glassOf([30,30,36],170); PAINT.sglass_white=glassOf([250,250,250],110);
function paintTile(name){ const t=new Tile(name); const f=PAINT[name]; if(f) f(t); else { for(let y=0;y<16;y++)for(let x=0;x<16;x++) t.set(x,y,((x>>2)+(y>>2))%2?[255,0,255]:[20,20,20]); } return t; }
