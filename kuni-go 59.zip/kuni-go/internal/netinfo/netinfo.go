// Package netinfo looks at a site's TLS certificate (who issued it, until when, for which names) and at the WHOIS
// record of a domain (registrar, dates, name servers). #netcheck shows them; the monitors use the certificate to warn
// before it expires.
package netinfo

import (
	"bufio"
	"context"
	"crypto/tls"
	"crypto/x509"
	"errors"
	"fmt"
	"io"
	"net"
	"regexp"
	"strings"
	"time"
)

// Cert is what a server's certificate says.
type Cert struct {
	Host      string
	Subject   string
	Issuer    string
	Names     []string
	NotBefore time.Time
	NotAfter  time.Time
	Version   string // TLS version of the connection
	VerifyErr string // why the certificate is not trusted ("" = trusted)
}

// DaysLeft is how many days the certificate still has (negative = expired).
func (c Cert) DaysLeft(now time.Time) int { return int(c.NotAfter.Sub(now).Hours() / 24) }

// String is a short report.
func (c Cert) String() string {
	s := fmt.Sprintf("%s: certificate for %s, issued by %s, valid %s — %s (%d days left), %s",
		c.Host, c.Subject, c.Issuer, c.NotBefore.Format("2006-01-02"), c.NotAfter.Format("2006-01-02"), c.DaysLeft(time.Now()), c.Version)
	if len(c.Names) > 0 {
		names := c.Names
		if len(names) > 8 {
			names = append(names[:8:8], fmt.Sprintf("… +%d", len(c.Names)-8))
		}
		s += "; names: " + strings.Join(names, ", ")
	}
	if c.VerifyErr != "" {
		s += "\nNOT TRUSTED: " + c.VerifyErr
	} else {
		s += "\ntrusted"
	}
	return s
}

// CertOf connects to host[:port] (443 by default) and reads its certificate. An untrusted certificate is still read
// (the reason is in VerifyErr); only a failed connection is an error.
func CertOf(ctx context.Context, hostport string, roots *x509.CertPool) (Cert, error) {
	hostport = strings.TrimSpace(hostport)
	hostport = strings.TrimPrefix(strings.TrimPrefix(hostport, "https://"), "http://")
	if i := strings.IndexByte(hostport, '/'); i >= 0 {
		hostport = hostport[:i]
	}
	host, port, err := net.SplitHostPort(hostport)
	if err != nil {
		host, port = hostport, "443"
	}
	if host == "" {
		return Cert{}, errors.New("which host?")
	}
	dial := func(skip bool) (*tls.Conn, error) {
		d := tls.Dialer{NetDialer: &net.Dialer{Timeout: 10 * time.Second}, Config: &tls.Config{ServerName: host, RootCAs: roots, InsecureSkipVerify: skip}}
		c, err := d.DialContext(ctx, "tcp", net.JoinHostPort(host, port))
		if err != nil {
			return nil, err
		}
		return c.(*tls.Conn), nil
	}
	verifyErr := ""
	conn, err := dial(false)
	if err != nil {
		var verr *tls.CertificateVerificationError
		if !errors.As(err, &verr) && !strings.Contains(err.Error(), "certificate") {
			return Cert{}, err
		}
		verifyErr = err.Error()
		if conn, err = dial(true); err != nil {
			return Cert{}, err
		}
	}
	defer conn.Close()
	st := conn.ConnectionState()
	if len(st.PeerCertificates) == 0 {
		return Cert{}, errors.New("the server sent no certificate")
	}
	leaf := st.PeerCertificates[0]
	issuer := leaf.Issuer.CommonName
	if len(leaf.Issuer.Organization) > 0 {
		issuer = leaf.Issuer.Organization[0] + " (" + issuer + ")"
	}
	return Cert{Host: net.JoinHostPort(host, port), Subject: leaf.Subject.CommonName, Issuer: issuer, Names: leaf.DNSNames,
		NotBefore: leaf.NotBefore, NotAfter: leaf.NotAfter, Version: tls.VersionName(st.Version), VerifyErr: verifyErr}, nil
}

var (
	reRefer  = regexp.MustCompile(`(?im)^\s*(?:refer|whois|registrar whois server)\s*:\s*(\S+)\s*$`)
	reDomain = regexp.MustCompile(`^[a-z0-9\p{L}.-]+\.[a-z\p{L}]{2,}$`)
	keep     = regexp.MustCompile(`(?i)^\s*(domain name|domain|registrar|sponsoring registrar|creation date|created|registered|registration time|` +
		`registry expiry date|registrar registration expiration date|expiration date|expires|expiry date|paid-till|free-date|updated date|changed|` +
		`name server|nserver|domain status|status|state|registrant organization|registrant|org|admin-contact)\s*:`)
)

// Whois returns the useful lines of a domain's WHOIS record. server is the first server to ask ("" = whois.iana.org,
// which names the registry); a referral is followed twice at most.
func Whois(ctx context.Context, domain, server string) (string, error) {
	domain = strings.ToLower(strings.TrimSpace(strings.TrimSuffix(domain, ".")))
	domain = strings.TrimPrefix(strings.TrimPrefix(domain, "https://"), "http://")
	if i := strings.IndexByte(domain, '/'); i >= 0 {
		domain = domain[:i]
	}
	domain = strings.TrimPrefix(domain, "www.")
	if !reDomain.MatchString(domain) {
		return "", fmt.Errorf("%q is not a domain name", domain)
	}
	if server == "" {
		server = "whois.iana.org:43"
	}
	var last string
	for hop := 0; hop < 3; hop++ {
		text, err := query(ctx, server, domain)
		if err != nil {
			if last != "" {
				break
			}
			return "", err
		}
		last = text
		m := reRefer.FindStringSubmatch(text)
		if m == nil {
			break
		}
		next := m[1]
		if !strings.Contains(next, ":") {
			next += ":43"
		}
		if strings.EqualFold(next, server) {
			break
		}
		server = next
	}
	var lines []string
	seen := map[string]bool{}
	for _, l := range strings.Split(last, "\n") {
		l = strings.TrimRight(l, "\r ")
		if keep.MatchString(l) && !seen[strings.ToLower(l)] {
			seen[strings.ToLower(l)] = true
			lines = append(lines, strings.TrimSpace(l))
		}
	}
	if len(lines) == 0 {
		all := strings.Split(strings.TrimSpace(last), "\n")
		if len(all) > 40 {
			all = all[:40]
		}
		return strings.Join(all, "\n"), nil
	}
	if len(lines) > 40 {
		lines = lines[:40]
	}
	return strings.Join(lines, "\n"), nil
}

func query(ctx context.Context, server, domain string) (string, error) {
	ctx, cancel := context.WithTimeout(ctx, 15*time.Second)
	defer cancel()
	c, err := (&net.Dialer{}).DialContext(ctx, "tcp", server)
	if err != nil {
		return "", fmt.Errorf("whois %s: %w", server, err)
	}
	defer c.Close()
	if dl, ok := ctx.Deadline(); ok {
		_ = c.SetDeadline(dl)
	}
	if _, err := io.WriteString(c, domain+"\r\n"); err != nil {
		return "", err
	}
	var b strings.Builder
	r := bufio.NewReader(io.LimitReader(c, 256<<10))
	_, err = io.Copy(&b, r)
	if err != nil && b.Len() == 0 {
		return "", err
	}
	return b.String(), nil
}
