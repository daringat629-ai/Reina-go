package netinfo

import (
	"bufio"
	"context"
	"crypto/x509"
	"fmt"
	"net"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"
)

func TestCert(t *testing.T) {
	srv := httptest.NewTLSServer(http.HandlerFunc(func(http.ResponseWriter, *http.Request) {}))
	defer srv.Close()
	host := strings.TrimPrefix(srv.URL, "https://")
	c, err := CertOf(context.Background(), host, nil)
	if err != nil || c.VerifyErr == "" {
		t.Fatalf("untrusted cert must still be read: %+v %v", c, err)
	}
	pool := x509.NewCertPool()
	pool.AddCert(srv.Certificate())
	c, err = CertOf(context.Background(), "https://"+host+"/path", pool)
	if err != nil || c.VerifyErr != "" || c.DaysLeft(time.Now()) < 100 || !strings.Contains(c.String(), "trusted") {
		t.Fatalf("%+v %v", c, err)
	}
	if _, err := CertOf(context.Background(), "127.0.0.1:1", nil); err == nil {
		t.Fatal("a closed port is an error")
	}
}

// fake whois servers: the root refers to the registry, the registry answers.
func whoisServer(t *testing.T, answer func(q string) string) string {
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { ln.Close() })
	go func() {
		for {
			c, err := ln.Accept()
			if err != nil {
				return
			}
			q, _ := bufio.NewReader(c).ReadString('\n')
			fmt.Fprint(c, answer(strings.TrimSpace(q)))
			c.Close()
		}
	}()
	return ln.Addr().String()
}

func TestWhoisFollowsTheReferral(t *testing.T) {
	registry := whoisServer(t, func(q string) string {
		return "% registry\r\nDomain Name: " + strings.ToUpper(q) + "\r\nRegistrar: Example Registrar\r\nCreation Date: 2001-01-01\r\n" +
			"Registry Expiry Date: 2030-01-01\r\nName Server: NS1.EXAMPLE.KG\r\nboring: line\r\n"
	})
	root := whoisServer(t, func(q string) string { return "domain: KG\nrefer: " + registry + "\n" })
	out, err := Whois(context.Background(), "https://www.Example.KG/x", root)
	if err != nil {
		t.Fatal(err)
	}
	for _, want := range []string{"Domain Name: EXAMPLE.KG", "Registrar: Example Registrar", "Registry Expiry Date: 2030-01-01", "Name Server: NS1.EXAMPLE.KG"} {
		if !strings.Contains(out, want) {
			t.Errorf("no %q in\n%s", want, out)
		}
	}
	if strings.Contains(out, "boring") {
		t.Error("noise kept")
	}
	if _, err := Whois(context.Background(), "not a domain", root); err == nil {
		t.Error("bad domain")
	}
}
