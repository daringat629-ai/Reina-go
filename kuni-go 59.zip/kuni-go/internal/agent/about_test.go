package agent

import (
	"context"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"kuni/internal/people"
	"kuni/internal/telegram"
)

func TestDescribePersonWritesTheCardAndFilesTheProfile(t *testing.T) {
	f := newFakeLLM(t, sendCall)
	r := newRig(t, f)
	r.ag.Deps.People = people.New(filepath.Join(r.dir, "people"))
	r.tg.Users = map[int64]telegram.User{7: {ID: 7, Name: "Вася", Username: "vasya", Bio: "пишу на asm"}}
	ctx := context.Background()
	r.ag.Deps.People.Add(7, "Вася", "любит ассемблер", true, time.Now())
	r.ag.Deps.People.Add(7, "", "живёт в Бишкеке", true, time.Now())
	c, err := r.ag.DescribePerson(ctx, 7)
	if err != nil {
		t.Fatal(err)
	}
	if c.About == "" || c.Username != "vasya" || c.Bio != "пишу на asm" || len(c.Facts) != 2 || c.AboutAt.IsZero() {
		t.Fatalf("%+v", c)
	}
	p := lastUserPrompt(f)
	if !strings.Contains(p, "любит ассемблер") || !strings.Contains(p, "пишу на asm") || !strings.Contains(p, "@vasya") {
		t.Fatal("the model was not given the facts and the profile")
	}
	if _, err := r.ag.DescribePerson(ctx, -5); err == nil {
		t.Fatal("a group id accepted")
	}
	// nobody known, nothing to say: an honest error instead of an invented person
	if _, err := r.ag.DescribePerson(ctx, 99); err == nil {
		t.Fatal("described a stranger out of thin air")
	}
	r.ag.Deps.People = nil
	if _, err := r.ag.DescribePerson(ctx, 7); err == nil {
		t.Fatal("cards are off")
	}
}

func TestDescriptionIsWrittenOnlyWhenWorthIt(t *testing.T) {
	f := newFakeLLM(t, sendCall)
	r := newRig(t, f)
	r.ag.Deps.People = people.New(filepath.Join(r.dir, "people"))
	cfg := r.ag.Cfg.Get()
	cfg.AutoPersonAbout = true
	now := time.Now()
	calls := func() int { f.mu.Lock(); defer f.mu.Unlock(); return len(f.calls) }
	for i, fact := range []string{"один", "два"} {
		r.ag.Deps.People.Add(7, "Вася", fact, true, now.Add(time.Duration(i)))
	}
	r.ag.maybeDescribe(7) // only two facts
	time.Sleep(200 * time.Millisecond)
	if calls() != 0 {
		t.Fatal("described too early")
	}
	r.ag.Deps.People.Add(7, "Вася", "три", true, now)
	r.ag.maybeDescribe(7)
	waitFor(t, "the description", func() bool { return r.ag.Deps.People.Get(7).About != "" })
	n := calls()
	r.ag.maybeDescribe(7) // fresh: not rewritten
	time.Sleep(200 * time.Millisecond)
	if calls() != n {
		t.Fatal("rewritten at once")
	}
	cfg.AutoPersonAbout = false
	r.ag.Deps.People.SetAbout(7, "", "старое", now.Add(-10*24*time.Hour))
	r.ag.maybeDescribe(7)
	time.Sleep(200 * time.Millisecond)
	if r.ag.Deps.People.Get(7).About != "старое" {
		t.Fatal("rewritten although switched off")
	}
}
