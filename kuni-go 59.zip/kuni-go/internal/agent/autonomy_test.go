package agent

import (
	"context"
	"fmt"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"kuni/internal/autonomy"
	"kuni/internal/llm"
	"kuni/internal/telegram"
	"kuni/internal/usage"
)

func autoRig(t *testing.T) (*rig, *fakeLLM) {
	f := newFakeLLM(t, sendCall)
	r := newRig(t, f)
	c := r.ag.Cfg.Get()
	c.AutonomyEnabled, c.AutonomyMaxPerDay, c.AutonomyChatCooldown = true, 2, 90
	c.AutonomyMinMins, c.AutonomyMaxMins = 1, 1
	c.AutonomyTimezone = "UTC"
	c.AutonomyQuietFrom, c.AutonomyQuietTo = "", "" // no night unless a test asks for it
	r.ag.Auto = autonomy.New(filepath.Join(r.dir, "a.json"), filepath.Join(r.dir, "a.log"))
	return r, f
}

func sendTo(chatID int64) (*session, llm.ToolCall) {
	return &session{id: 0, chat: telegram.Chat{ID: chatID, Title: "chat"}},
		llm.ToolCall{Function: llm.FunctionCall{Name: "send_telegram_message", Arguments: `{"text":"hello there"}`}}
}

func TestAutonomousSendsAreLimitedInCode(t *testing.T) {
	r, _ := autoRig(t)
	a := r.ag
	s1, c := sendTo(11)
	if why := a.autoDenied(s1, c); why != "" {
		t.Fatalf("first message must pass: %s", why)
	}
	a.autoRecord(s1, c, "sent")
	if why := a.autoDenied(s1, c); !strings.Contains(why, "minutes ago") {
		t.Fatalf("same chat again must hit the cooldown: %q", why)
	}
	s2, _ := sendTo(12)
	a.autoRecord(s2, c, "sent")
	s3, _ := sendTo(13)
	if why := a.autoDenied(s3, c); !strings.Contains(why, "daily limit") {
		t.Fatalf("the cap of 2 must stop the third: %q", why)
	}
	// the owner (chat 100 in the rig) is never limited, and failed sends are not counted
	so, _ := sendTo(100)
	if why := a.autoDenied(so, c); why != "" {
		t.Fatalf("owner exempt: %q", why)
	}
	s4, _ := sendTo(14)
	a.autoRecord(s4, c, "Error: boom")
	if a.Auto.SentToday() != 2 {
		t.Fatalf("an error must not count: %d", a.Auto.SentToday())
	}
	// normal chats (id != 0) are never touched by the limits, and neither are non-sending tools
	norm := &session{id: 55, chat: telegram.Chat{ID: 55}}
	if a.autoDenied(norm, c) != "" {
		t.Fatal("answering a person is not an initiative")
	}
	if a.autoDenied(s3, llm.ToolCall{Function: llm.FunctionCall{Name: "get_telegram_chats"}}) != "" {
		t.Fatal("reading is free")
	}
	// autonomy off = no limits at all
	a.Cfg.Get().AutonomyEnabled = false
	if a.autoDenied(s3, c) != "" {
		t.Fatal("limits only apply while autonomy is on")
	}
}

func TestActAutonomouslyRespectsSleepNightCapAndPause(t *testing.T) {
	r, f := autoRig(t)
	a := r.ag
	calls := func() int { f.mu.Lock(); defer f.mu.Unlock(); return len(f.calls) }
	ctx := context.Background()

	a.Auto.Sleep(time.Hour, "tired")
	_ = a.ActAutonomously(ctx)
	if calls() != 0 {
		t.Fatal("asleep: no LLM round")
	}
	a.Auto.Wake()

	c := a.Cfg.Get()
	now := time.Now().UTC()
	c.AutonomyQuietFrom = now.Add(-time.Hour).Format("15:04")
	c.AutonomyQuietTo = now.Add(time.Hour).Format("15:04")
	_ = a.ActAutonomously(ctx)
	if calls() != 0 {
		t.Fatal("night: no LLM round")
	}
	c.AutonomyQuietFrom, c.AutonomyQuietTo = "", ""

	a.paused.Store(true)
	_ = a.ActAutonomously(ctx)
	if calls() != 0 {
		t.Fatal("paused: no LLM round")
	}
	a.paused.Store(false)

	c.AutonomyMaxPerDay = 0
	_ = a.ActAutonomously(ctx)
	if calls() != 0 {
		t.Fatal("cap reached: no LLM round")
	}
	c.AutonomyMaxPerDay = 5

	if err := a.ActAutonomously(ctx); err != nil {
		t.Fatal(err)
	}
	if calls() == 0 {
		t.Fatal("a normal round must ask the model")
	}
	// the prompt offers the choices and states the remaining quota
	s := a.getSession(0)
	var prompt string
	for _, m := range s.msgs {
		if m.Role == "user" {
			prompt = m.Content
		}
	}
	for _, want := range []string{"Write first", "#go_to_sleep", "(#wait)", "at most 5 more"} {
		if !strings.Contains(prompt, want) {
			t.Fatalf("autonomous prompt lacks %q:\n%s", want, prompt)
		}
	}
	if !s.tools.Has("go_to_sleep") || !s.tools.Has("open_chat") {
		t.Fatalf("tools: %v", s.tools.Names())
	}
}

func TestGoToSleepToolAndDrowsyBlock(t *testing.T) {
	r, _ := autoRig(t)
	a := r.ag
	if a.sleepBlock() != "" {
		t.Fatal("awake by day: no block")
	}
	msg := a.goToSleep(120, "tired")
	if !strings.Contains(msg, "fall asleep") {
		t.Fatal(msg)
	}
	if asleep, _ := a.Auto.Asleep(); !asleep || !strings.Contains(a.sleepBlock(), "asleep until") {
		t.Fatal("sleep must show up in the prompt")
	}
	if got := a.Auto.Recent(3); len(got) == 0 || !strings.Contains(got[len(got)-1], "went to sleep") {
		t.Fatalf("journal: %q", got)
	}
	a.Auto.Wake()
	c := a.Cfg.Get()
	now := time.Now().UTC()
	c.AutonomyQuietFrom, c.AutonomyQuietTo = now.Add(-time.Hour).Format("15:04"), now.Add(time.Hour).Format("15:04")
	if !strings.Contains(a.sleepBlock(), "night") {
		t.Fatal("night block")
	}
	c.AutonomyEnabled = false
	if a.sleepBlock() != "" {
		t.Fatal("autonomy off: nothing is injected")
	}
}

func TestDailyTokenLimitStopsInitiative(t *testing.T) {
	r, f := autoRig(t)
	a := r.ag
	a.Usage = usage.New("")
	a.Cfg.Get().DailyTokenLimit = 1000
	a.Usage.Add("m", 900, 200, 1000)
	calls := func() int { f.mu.Lock(); defer f.mu.Unlock(); return len(f.calls) }
	_ = a.ActAutonomously(context.Background())
	_ = a.ActProactively(context.Background())
	if calls() != 0 {
		t.Fatal("over the daily limit she must not start anything on her own")
	}
	a.Cfg.Get().DailyTokenLimit = 0
	_ = a.ActAutonomously(context.Background())
	if calls() == 0 {
		t.Fatal("no limit: normal behaviour")
	}
}

// The limits used to be checked only in unit tests: during a real autonomous round nothing called them, so she
// could write to as many people as she liked. Now every message she starts herself goes through them.
func TestAutonomousRoundCannotPassTheDailyCap(t *testing.T) {
	open := func(id int64) llm.ToolCall {
		return llm.ToolCall{ID: fmt.Sprint("o", id), Type: "function", Function: llm.FunctionCall{Name: "open_chat", Arguments: fmt.Sprintf(`{"chat_id":%d}`, id)}}
	}
	f := newScript(t, open(11), say("привет, вспомнила про тебя"), open(12), say("эй, как ты там вообще"), open(13), say("скучно мне, напиши"))
	r := newRig(t, &fakeLLM{srv: f.srv})
	c := r.ag.Cfg.Get()
	c.AutonomyEnabled, c.AutonomyMaxPerDay, c.AutonomyChatCooldown = true, 2, 90
	c.AutonomyTimezone, c.AutonomyQuietFrom, c.AutonomyQuietTo = "UTC", "", ""
	c.MaxToolRounds = 10
	r.ag.Auto = autonomy.New(filepath.Join(r.dir, "a.json"), filepath.Join(r.dir, "a.log"))
	for _, id := range []int64{11, 12, 13} {
		r.tg.S.Put(telegram.Message{ID: 1, ChatID: id, SenderID: id, SenderName: "friend", Date: time.Now(), Text: "old", Read: true},
			&telegram.Chat{ID: id, Title: fmt.Sprint("friend ", id), Kind: telegram.ChatPrivate, IsMember: true})
	}
	if err := r.ag.ActAutonomously(context.Background()); err != nil {
		t.Fatal(err)
	}
	if got := r.tg.SentTexts(); len(got) != 2 {
		t.Fatalf("the cap of 2 was not enforced in a real round: %q", got)
	}
	if r.ag.Auto.SentToday() != 2 {
		t.Fatalf("sends were not counted: %d", r.ag.Auto.SentToday())
	}
	f.mu.Lock()
	last := f.reqs[len(f.reqs)-1]
	f.mu.Unlock()
	if !strings.Contains(last, "daily limit") {
		t.Fatal("the model was not told why the third message was not sent")
	}
	if log := strings.Join(r.ag.Auto.Recent(10), "\n"); !strings.Contains(log, "wrote to friend 11") || !strings.Contains(log, "wrote to friend 12") {
		t.Fatalf("her initiatives must be journaled: %s", log)
	}
}
