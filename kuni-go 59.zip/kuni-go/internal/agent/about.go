package agent

import (
	"context"
	"fmt"
	"log"
	"strings"
	"time"

	"kuni/internal/llm"
	"kuni/internal/people"
	"kuni/internal/prompts"
)

// aboutEvery is how often a description is rewritten at the earliest.
const aboutEvery = 3 * 24 * time.Hour

// DescribePerson writes (or rewrites) her description of a person from the Telegram profile, the card's facts and the
// latest private messages, files it on the card and returns the card.
func (a *Agent) DescribePerson(ctx context.Context, id int64) (people.Card, error) {
	if a.Deps.People == nil {
		return people.Card{}, fmt.Errorf("person cards are off")
	}
	if id <= 0 {
		return people.Card{}, fmt.Errorf("a person's id is needed (positive number)")
	}
	cctx, cancel := context.WithTimeout(context.WithoutCancel(ctx), 90*time.Second)
	defer cancel()
	card := a.Deps.People.Get(id)
	name, username, bio := card.Name, "", ""
	if u, err := a.TG.UserInfo(cctx, id); err == nil {
		if u.Name != "" {
			name = u.Name
		}
		username, bio = u.Username, u.Bio
	}
	var b strings.Builder
	fmt.Fprintf(&b, "Person: %s (user id %d)", name, id)
	if username != "" {
		b.WriteString(", @" + username)
	}
	if a.cfg().IsOwner(id) {
		b.WriteString(" — this is your owner")
	}
	b.WriteString("\n")
	if bio != "" {
		b.WriteString("Their Telegram bio: " + bio + "\n")
	}
	if len(card.Facts) > 0 {
		b.WriteString("What you know:\n")
		for _, f := range card.Facts {
			b.WriteString("- " + f.Text + "\n")
		}
	}
	if card.About != "" {
		b.WriteString("Your previous description (improve it, keep what is still true): " + card.About + "\n")
	}
	if hist, err := a.TG.History(cctx, id, 0, 30, 0); err == nil && len(hist) > 0 {
		b.WriteString("Your latest messages with them:\n")
		for _, m := range hist {
			if strings.TrimSpace(m.Text) == "" {
				continue
			}
			who := name
			if m.Outgoing {
				who = "you"
			}
			b.WriteString(who + ": " + oneLine(m.Text, 200) + "\n")
		}
	}
	if len(card.Facts) == 0 && bio == "" && !strings.Contains(b.String(), "Your latest messages") {
		return card, fmt.Errorf("she knows nothing about this person yet: no facts, no bio, no messages")
	}
	out, err := a.LLM.Chat(llm.WithChat(llm.WithPurpose(cctx, "people"), id), a.SystemPrompt()+"\n\n"+a.Prompts.Text(prompts.DescribePerson, nil), []llm.Message{{Role: "user", Content: b.String()}})
	if err != nil {
		return card, err
	}
	about := strings.Trim(strings.TrimSpace(out), "\"«»")
	if about == "" {
		return card, fmt.Errorf("the model returned nothing")
	}
	if err := a.Deps.People.SetAbout(id, name, about, time.Now()); err != nil {
		return card, err
	}
	_ = a.Deps.People.SetProfile(id, username, bio)
	return a.Deps.People.Get(id), nil
}

// maybeDescribe runs after she learned something about a person: a card with enough facts gets a description, an old
// one gets rewritten now and then. It never blocks the caller.
func (a *Agent) maybeDescribe(id int64) {
	cfg := a.cfg()
	if !cfg.AutoPersonAbout || a.Deps.People == nil || id <= 0 {
		return
	}
	c := a.Deps.People.Get(id)
	if len(c.Facts) < 3 || (c.About != "" && time.Since(c.AboutAt) < aboutEvery) {
		return
	}
	a.spawn(fmt.Sprintf("describing %d", id), func() {
		if _, err := a.DescribePerson(a.life, id); err != nil {
			log.Printf("agent: describing %d: %v", id, err)
		}
	})
}
