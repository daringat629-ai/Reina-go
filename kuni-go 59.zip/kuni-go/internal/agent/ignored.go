package agent

import "kuni/internal/telegram"

// The ignore list never touches the owner: his chat and his messages always get through.

func (a *Agent) isOwner(id int64) bool { return a.cfg().IsOwner(id) }

// ignoredChat: the whole chat is on the list.
func (a *Agent) ignoredChat(chatID int64) bool {
	return a.Deps.Ignore.Chat(chatID) && !a.isOwner(chatID)
}

// ignoredMessage: the chat or the sender of an incoming message is on the list.
func (a *Agent) ignoredMessage(m telegram.Message) bool {
	if m.Outgoing || a.isOwner(m.SenderID) || a.isOwner(m.ChatID) {
		return false
	}
	return a.Deps.Ignore.Chat(m.ChatID) || a.Deps.Ignore.User(m.SenderID)
}

// withoutIgnored drops the messages of ignored people, so a group batch is read without them.
func (a *Agent) withoutIgnored(msgs []telegram.Message) []telegram.Message {
	if len(a.Deps.Ignore.List()) == 0 {
		return msgs
	}
	kept := make([]telegram.Message, 0, len(msgs))
	for _, m := range msgs {
		if !m.Outgoing && a.ignoredMessage(m) {
			continue
		}
		kept = append(kept, m)
	}
	return kept
}
