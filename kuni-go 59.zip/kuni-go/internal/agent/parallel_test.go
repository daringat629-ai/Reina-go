package agent

import (
	"context"
	"testing"
	"time"

	"kuni/internal/llm"
	"kuni/internal/tools"
)

func slowTool(name string) tools.Tool {
	return tools.Tool{Name: name, Run: func(ctx context.Context, a tools.Args) (string, error) {
		time.Sleep(200 * time.Millisecond)
		return name + " done", nil
	}}
}

func mkCall(id, name, args string) llm.ToolCall {
	var c llm.ToolCall
	c.ID = id
	c.Function.Name = name
	c.Function.Arguments = args
	return c
}

func TestIndependentReadsRunAtTheSameTime(t *testing.T) {
	r := newRig(t, newFakeLLM(t, sendCall))
	r.ag.Cfg.Get().ParallelTools = true
	s := &session{tools: tools.NewRegistry(slowTool("web_search"), slowTool("lookup"), slowTool("shell"))}
	calls := []llm.ToolCall{mkCall("1", "web_search", `{"q":"a"}`), mkCall("2", "lookup", `{}`), mkCall("3", "shell", `{}`), mkCall("4", "web_search", `{"q":"a"}`)}
	start := time.Now()
	got := r.ag.runParallel(context.Background(), s, calls, map[string]bool{})
	if el := time.Since(start); el > 350*time.Millisecond {
		t.Fatalf("took %v: not parallel", el)
	}
	if len(got) != 2 || got[0].Text != "web_search done" || got[1].Text != "lookup done" {
		t.Fatalf("results: %v", got)
	}
	// the shell call and the duplicate stay for the ordered loop
	if _, ok := got[2]; ok {
		t.Fatal("shell must not run in parallel")
	}
	if _, ok := got[3]; ok {
		t.Fatal("duplicate must not run twice")
	}
	r.ag.Cfg.Get().ParallelTools = false
	if r.ag.runParallel(context.Background(), s, calls, map[string]bool{}) != nil {
		t.Fatal("switch is off, nothing should run")
	}
}
