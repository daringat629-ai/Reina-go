package agent

import (
	"log"
	"runtime/debug"
	"sync"
	"time"
)

// Turns that something else starts (a chat whose time has come, a due reminder, a monitor alert, a scheduled task,
// the owner's yes to a risky action, a slash command, a finished background job) run in goroutines of their own.
// They used to be fire-and-forget: on shutdown they could still be talking to the model and writing files after the
// final dump of the sessions. background tracks them, and Run waits for them (they share its context, so they end
// quickly) before dumping.
type background struct {
	mu     sync.Mutex
	wg     sync.WaitGroup
	closed bool
}

// run runs f in the calling goroutine, tracked and with a panic contained to it. After shutdown has begun, f is
// dropped (and logged).
func (b *background) run(what string, f func()) {
	if !b.add(what) {
		return
	}
	defer b.wg.Done()
	defer func() {
		if r := recover(); r != nil {
			log.Printf("agent: %s: PANIC recovered: %v\n%s", what, r, debug.Stack())
		}
	}()
	f()
}

func (b *background) add(what string) bool {
	b.mu.Lock()
	defer b.mu.Unlock()
	if b.closed {
		log.Printf("agent: shutting down, %s dropped", what)
		return false
	}
	b.wg.Add(1)
	return true
}

// wait stops accepting new work and waits up to d for what is running. It reports whether everything finished.
func (b *background) wait(d time.Duration) bool {
	b.mu.Lock()
	b.closed = true
	b.mu.Unlock()
	done := make(chan struct{})
	go func() { b.wg.Wait(); close(done) }()
	select {
	case <-done:
		return true
	case <-time.After(d):
		log.Printf("agent: background turns still running after %s; going on with the shutdown", d)
		return false
	}
}

// spawn runs f in a tracked goroutine of its own.
func (a *Agent) spawn(what string, f func()) {
	if !a.bg.add(what) {
		return
	}
	go func() {
		defer a.bg.wg.Done()
		defer func() {
			if r := recover(); r != nil {
				log.Printf("agent: %s: PANIC recovered: %v\n%s", what, r, debug.Stack())
			}
		}()
		f()
	}()
}

// WaitBackground stops accepting new background turns and waits up to d for the running ones.
// It reports whether they all finished.
func (a *Agent) WaitBackground(d time.Duration) bool { return a.bg.wait(d) }
