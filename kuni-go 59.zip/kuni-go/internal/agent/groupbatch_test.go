package agent

import (
	"context"
	"strconv"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"kuni/internal/llm"
	"kuni/internal/telegram"
)

func TestGroupFire(t *testing.T) {
	now := time.Now()
	s := time.Second
	cases := []struct {
		name                          string
		first, lastEnd                time.Time
		quiet, maxWait, cooldown, exp time.Duration
	}{
		{"quiet window only", now, time.Time{}, 8 * s, 0, 0, 8 * s},
		{"a chatty group is cut off by max wait", now.Add(-25 * s), time.Time{}, 8 * s, 30 * s, 0, 5 * s},
		{"max wait already passed: read now", now.Add(-40 * s), time.Time{}, 8 * s, 30 * s, 0, 0},
		{"cooldown pushes the read later", now, now.Add(-2 * s), 3 * s, 30 * s, 12 * s, 10 * s},
		{"cooldown over", now, now.Add(-60 * s), 3 * s, 30 * s, 12 * s, 3 * s},
		{"cooldown beats max wait", now.Add(-29 * s), now.Add(-1 * s), 8 * s, 30 * s, 12 * s, 11 * s},
		{"all off", now, now, 0, 0, 0, 0},
	}
	for _, c := range cases {
		if got := groupFire(now, c.first, c.lastEnd, c.quiet, c.maxWait, c.cooldown); got != c.exp {
			t.Errorf("%s: %v, want %v", c.name, got, c.exp)
		}
	}
}

func TestGroupBatchHint(t *testing.T) {
	g := telegram.Chat{ID: -5, Kind: telegram.ChatGroup}
	msgs := []telegram.Message{{SenderName: "A"}, {SenderName: "B"}, {SenderName: "A"}, {SenderName: "me", Outgoing: true}}
	h := groupBatchHint(g, msgs)
	if !strings.Contains(h, "3 new messages from 2 people") || !strings.Contains(h, "reply_to_message_id") {
		t.Fatal(h)
	}
	if groupBatchHint(g, msgs[:1]) != "" {
		t.Fatal("one message is not a batch")
	}
	if groupBatchHint(telegram.Chat{Kind: telegram.ChatPrivate}, msgs) != "" {
		t.Fatal("private chats are not batched")
	}
}

func groupRig(t *testing.T, quiet, maxWait, cooldown time.Duration) (*rig, telegram.Chat, func()) {
	var n atomic.Int32
	r := newRig(t, newFakeLLM(t, func(int64) llm.ToolCall { // every answer differs: the repeat guard must not eat the second one
		c := sendCall(0)
		c.Function.Arguments = strings.Replace(c.Function.Arguments, "hi~", "answer number "+strconv.Itoa(int(n.Add(1))), 1)
		return c
	}))
	cfg := r.ag.Cfg.Get()
	cfg.GroupDebounce, cfg.GroupMaxWait, cfg.GroupCooldown = quiet, maxWait, cooldown
	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan struct{})
	go func() { r.ag.Run(ctx); close(done) }()
	chat := telegram.Chat{ID: -500, Title: "Club", Kind: telegram.ChatGroup, IsMember: true}
	return r, chat, func() { cancel(); <-done }
}

func TestGroupBurstIsReadAsOneBatch(t *testing.T) {
	r, chat, stop := groupRig(t, 250*time.Millisecond, 0, 0)
	defer stop()
	for i, who := range []string{"Ann", "Bob", "Ann", "Cid"} {
		r.tg.Incoming(chat, int64(200+i), who, "message "+who)
		time.Sleep(60 * time.Millisecond) // each message arrives before the quiet window ends
	}
	waitFor(t, "one answer", func() bool { return len(r.tg.SentTexts()) >= 1 })
	time.Sleep(700 * time.Millisecond)
	if n := len(r.tg.SentTexts()); n != 1 {
		t.Fatalf("%d answers for one burst, want 1", n)
	}
}

func TestGroupMaxWaitCutsOffAnEndlessChat(t *testing.T) {
	r, chat, stop := groupRig(t, 400*time.Millisecond, 700*time.Millisecond, 0)
	defer stop()
	start := time.Now()
	go func() { // a message every 100 ms: the quiet window never comes
		for i := 0; i < 30; i++ {
			r.tg.Incoming(chat, 201, "Ann", "still talking")
			time.Sleep(100 * time.Millisecond)
		}
	}()
	waitFor(t, "an answer despite the endless chat", func() bool { return len(r.tg.SentTexts()) >= 1 })
	if d := time.Since(start); d > 2500*time.Millisecond {
		t.Fatalf("took %v", d)
	}
}

func TestGroupCooldownHoldsTheNextTurn(t *testing.T) {
	r, chat, stop := groupRig(t, 50*time.Millisecond, 0, 1500*time.Millisecond)
	defer stop()
	r.tg.Incoming(chat, 201, "Ann", "first")
	waitFor(t, "first answer", func() bool { return len(r.tg.SentTexts()) == 1 })
	answered := time.Now()
	r.tg.Incoming(chat, 202, "Bob", "second")
	time.Sleep(600 * time.Millisecond)
	if n := len(r.tg.SentTexts()); n != 1 {
		t.Fatalf("answered again during the cooldown (%d)", n)
	}
	waitFor(t, "second answer after the cooldown", func() bool { return len(r.tg.SentTexts()) == 2 })
	if d := time.Since(answered); d < 1200*time.Millisecond {
		t.Fatalf("cooldown too short: %v", d)
	}
}

func TestPrivateChatIsNotBatched(t *testing.T) {
	r, _, stop := groupRig(t, 5*time.Second, 5*time.Second, 5*time.Second)
	defer stop()
	r.tg.Incoming(telegram.Chat{ID: 100, Title: "Alex", Kind: telegram.ChatPrivate, IsMember: true}, 100, "Alex", "hi")
	waitFor(t, "a private answer without group delays", func() bool { return len(r.tg.SentTexts()) == 1 })
}
