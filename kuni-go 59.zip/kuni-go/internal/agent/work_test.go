package agent

import (
	"context"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"kuni/internal/llm"
	"kuni/internal/telegram"
	"kuni/internal/work"
)

func workCall(args string) func(int64) llm.ToolCall {
	return func(int64) llm.ToolCall {
		return llm.ToolCall{ID: "w1", Type: "function", Function: llm.FunctionCall{Name: "work", Arguments: args}}
	}
}

func TestBackgroundRunWorksTheQueueWithinLimits(t *testing.T) {
	f := newFakeLLM(t, workCall(`{"action":"done","id":1,"text":"перевод сдан, 1200 руб"}`))
	r := newRig(t, f)
	cfg := r.ag.Cfg.Get()
	cfg.PapikChatID, cfg.OwnerTools = 100, true
	chat := telegram.Chat{ID: 100, Title: "Alex", Kind: telegram.ChatPrivate, IsMember: true}
	r.tg.S.Put(telegram.Message{ID: 1, ChatID: 100, SenderID: 100, SenderName: "Alex", Date: time.Now(), Text: "hi", Read: true}, &chat)
	r.ag.Deps.Work = work.New(filepath.Join(r.dir, "work.json"))
	r.ag.Deps.Work.Add("Перевод статьи", "Kwork, 3000 знаков", 0)
	r.ag.Deps.Work.Add("Вторая", "", 0)
	ctx := context.Background()

	// switched off: nothing happens
	if err := r.ag.workOnce(ctx); err != nil {
		t.Fatal(err)
	}
	if r.ag.Deps.Work.RunsToday(time.Now()) != 0 || len(f.calls) != 0 {
		t.Fatal("work ran while switched off")
	}

	cfg.WorkEnabled, cfg.WorkMaxRuns = true, 1
	if err := r.ag.workOnce(ctx); err != nil {
		t.Fatal(err)
	}
	p := lastUserPrompt(f)
	if !strings.Contains(p, "BACKGROUND WORK RUN") || !strings.Contains(p, "Перевод статьи") || !strings.Contains(p, "Kwork") {
		t.Fatal("the job is missing from the prompt")
	}
	waitFor(t, "the owner is told it is done", func() bool {
		for _, s := range r.tg.SentTexts() {
			if strings.Contains(s, "Готово: задача #1") && strings.Contains(s, "1200") {
				return true
			}
		}
		return false
	})
	if j, _ := r.ag.Deps.Work.Get(1); j.Status != work.Done {
		t.Fatalf("job not closed: %+v", j)
	}
	// the daily limit of 1 run holds
	n := len(f.calls)
	_ = r.ag.workOnce(ctx)
	if len(f.calls) != n {
		t.Fatal("a second run started past the daily limit")
	}
	// paused: nothing runs even with room left
	cfg.WorkMaxRuns = 5
	r.ag.SetPaused(true)
	_ = r.ag.workOnce(ctx)
	if len(f.calls) != n {
		t.Fatal("work ran while paused")
	}
}
