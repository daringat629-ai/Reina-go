package agent

import (
	"context"
	"errors"
	"log"
	"regexp"
	"time"

	"kuni/internal/llm"
	"kuni/internal/telegram"
	"kuni/internal/usage"
)

// A turn that fails because the model is unreachable (provider outage, 5xx, rate limit, timeout) used to be the end
// of it: the messages were already marked read, so nobody would ever answer them. Now the turn is repeated a few
// times with growing pauses (Agent.retryDelays). The person's messages are already in the session, so a retry simply
// asks the model again; a new message in the chat supersedes the retry (that turn sees everything anyway).

// clientErr matches an upstream answer in plain text that retrying cannot fix (bad key, no credit, bad request,
// unknown model); typed errors of the LLM client are judged by llm.Permanent.
var clientErr = regexp.MustCompile(`HTTP 4(0[0-9]|1[0-9]|2[0-8])\b`)

// transient tells whether a failed turn is worth repeating later.
func transient(err error) bool {
	var ae *llm.APIError
	switch {
	case err == nil, errors.Is(err, context.Canceled), errors.Is(err, usage.ErrHardLimit):
		return false
	case errors.As(err, &ae):
		return ae.Temporary()
	case clientErr.MatchString(err.Error()):
		return false
	}
	return true
}

// scheduleRetryLocked plans a repeat of the session's failed turn. s.mu must be held.
func (a *Agent) scheduleRetryLocked(ctx context.Context, s *session, err error) {
	if !transient(err) || ctx.Err() != nil || s.retries >= len(a.retryDelays) {
		if s.retries >= len(a.retryDelays) {
			log.Printf("agent: chat %d: giving up after %d retries: %v", s.id, s.retries, err)
			a.Metrics.Inc("kuni_turn_retry_gave_up_total", 1, nil)
		}
		s.retries = 0
		s.retrying.Store(false)
		return
	}
	d := a.retryDelays[s.retries]
	s.retries++
	s.retryGen++
	gen := s.retryGen
	log.Printf("agent: chat %d: the turn failed (%v); trying again in %s (%d/%d)", s.id, err, d, s.retries, len(a.retryDelays))
	a.Metrics.Inc("kuni_turn_retries_total", 1, nil)
	s.retrying.Store(true)
	s.retryTimer = time.AfterFunc(d, func() { a.bg.run("retry", func() { a.retryTurn(ctx, s, gen) }) })
}

// supersedeRetryLocked cancels a planned retry: a new turn is about to run. s.mu must be held.
func (s *session) supersedeRetryLocked() {
	s.retryGen++
	s.retrying.Store(false)
	if s.retryTimer != nil {
		s.retryTimer.Stop()
		s.retryTimer = nil
	}
}

func (a *Agent) retryTurn(ctx context.Context, s *session, gen int) {
	if ctx.Err() != nil {
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.retryGen != gen {
		return // a newer turn already ran
	}
	s.retryTimer = nil
	s.retrying.Store(false) // set again below if this attempt fails too
	if a.paused.Load() {
		s.retries = 0 // resuming schedules every chat with unread messages; these are read already, so say it in the log
		log.Printf("agent: chat %d: retry dropped, the agent is paused", s.id)
		return
	}
	defer a.goOnline(ctx)()
	a.inbox.setPhase(s.id, "thinking", time.Time{})
	defer a.inbox.endPhase(s.id)
	if err := a.runTurn(ctx, s); err != nil {
		a.scheduleRetryLocked(ctx, s, err)
		return
	}
	s.retries = 0
}

// --- the queue for the panel ---

// Queue lists the chats being waited for, oldest first.
func (a *Agent) Queue() []QueueItem { return a.inbox.queue() }

// QueueInfo is the panel's view: her queue plus the state of the Telegram connection.
func (a *Agent) QueueInfo() any {
	info := struct {
		Items    []QueueItem     `json:"items"`
		Telegram telegram.Health `json:"telegram"`
	}{Items: a.Queue()}
	if h, ok := a.TG.(telegram.HealthSource); ok {
		info.Telegram = h.Health()
	}
	if info.Telegram.Errors == nil {
		info.Telegram.Errors = []telegram.ErrorRecord{}
	}
	return info
}
