package agent

import (
	"context"
	"fmt"
	"strings"
	"testing"
	"time"

	"kuni/internal/llm"
	"kuni/internal/prompts"
)

func head(text string) llm.Message {
	return llm.Message{Role: "user", Content: summaryOpen + "\n" + text + "\n" + summaryClose}
}

func TestSummaryIsPinnedInBudgetAndTrim(t *testing.T) {
	msgs := []llm.Message{head("Jaabir owns a cat named Biscuit")}
	for i := 0; i < 200; i++ {
		msgs = append(msgs, llm.Message{Role: "user", Content: strings.Repeat("x", 400)}, llm.Message{Role: "assistant", Content: "ok"})
	}
	out := fitBudget(trim(msgs, 80), 10000)
	if !isSummary(out[0]) || !strings.Contains(out[0].Content, "Biscuit") {
		t.Fatal("the rolling summary must survive both trim and the character budget")
	}
	total := 0
	for _, m := range out {
		total += msgSize(m)
	}
	if total > 10500 || len(out) < 4 {
		t.Fatalf("budget not kept or history gone: %d chars, %d msgs", total, len(out))
	}
}

func TestCompactFoldsPreviousSummaryAndKeepsItWhenSummarisingFails(t *testing.T) {
	f := newFakeLLM(t, sendCall)
	r := newRig(t, f)
	r.ag.Cfg.Get().HistoryKeep = 2
	s := r.ag.getSession(7)
	s.msgs = []llm.Message{head("FACT: Jaabir owns a cat named Biscuit")}
	for i := 0; i < 8; i++ {
		s.msgs = append(s.msgs, llm.Message{Role: "user", Content: fmt.Sprintf("message %d", i)}, llm.Message{Role: "assistant", Content: "ok"})
	}
	r.ag.compact(context.Background(), s)
	f.mu.Lock()
	var seen bool
	for _, c := range f.calls {
		if b, _ := c["messages"].([]any); len(b) > 0 && strings.Contains(fmt.Sprint(b), "Biscuit") {
			seen = true
		}
	}
	f.mu.Unlock()
	if !seen {
		t.Fatal("the previous summary must be handed to the summariser, or old facts get lost one round at a time")
	}
	if cs := r.ag.Prompts.Text(prompts.Compact, nil); !strings.Contains(cs, "previous summary") || !strings.Contains(cs, "PROMISES") {
		t.Fatal("the summary prompt must say how to fold the old summary and what to keep")
	}

	// the model dies: the earlier summary still has to be there
	s.msgs[0] = head("FACT: Jaabir owns a cat named Biscuit")
	for i := 0; i < 8; i++ {
		s.msgs = append(s.msgs, llm.Message{Role: "user", Content: fmt.Sprintf("later %d", i)}, llm.Message{Role: "assistant", Content: "ok"})
	}
	f.srv.Close()
	r.ag.compact(context.Background(), s)
	if !isSummary(s.msgs[0]) || !strings.Contains(s.msgs[0].Content, "Biscuit") {
		t.Fatalf("a failed summary must not erase the old one: %q", s.msgs[0].Content)
	}
}

func TestSummaryCarriesOverAQuietPeriod(t *testing.T) {
	r := newRig(t, newFakeLLM(t, sendCall))
	s := r.ag.getSession(9)
	s.msgs = []llm.Message{head("PLAN: call Jaabir on Friday"), {Role: "user", Content: "hi"}, {Role: "assistant", Content: "yo"}}
	s.touch(time.Now())
	if !started(s) {
		t.Fatal("a session with real messages is live")
	}
	if err := r.ag.dump(context.Background(), 9); err != nil {
		t.Fatal(err)
	}
	n := r.ag.getSession(9)
	if len(n.msgs) != 1 || !isSummary(n.msgs[0]) || started(n) {
		t.Fatalf("the new session must start from a summary only: %+v", n.msgs)
	}
	kept := n.msgs[0].Content
	// nothing happened in it, so it dumps nothing new but keeps the summary for later
	if err := r.ag.dump(context.Background(), 9); err != nil {
		t.Fatal(err)
	}
	if again := r.ag.getSession(9); len(again.msgs) != 1 || again.msgs[0].Content != kept {
		t.Fatal("an untouched carried summary must survive another dump")
	}
	// too old: forgotten
	r.ag.sessions.mu.Lock()
	delete(r.ag.sessions.open, 9)
	r.ag.sessions.carry[9] = carried{head: head("old"), at: time.Now().Add(-2 * carryTTL)}
	r.ag.sessions.mu.Unlock()
	if x := r.ag.getSession(9); len(x.msgs) != 0 {
		t.Fatal("a summary older than carryTTL must not be used")
	}
}

// 300 exchanges: the request never grows beyond the budget, and the first fact is still in front of the model.
func TestLongConversationStaysBoundedAndRemembersTheStart(t *testing.T) {
	f := newFakeLLM(t, sendCall)
	r := newRig(t, f)
	cfg := r.ag.Cfg.Get()
	cfg.HistoryKeep, cfg.ContextChars = 6, 3000
	s := r.ag.getSession(11)
	worst := 0
	for i := 0; i < 300; i++ {
		s.msgs = append(s.msgs, llm.Message{Role: "user", Content: fmt.Sprintf("msg %d %s", i, strings.Repeat("blah ", 20))}, llm.Message{Role: "assistant", Content: "ok"})
		if i == 0 {
			s.msgs[0].Content = "my name is Zoya and I hate olives"
		}
		r.ag.compact(context.Background(), s)
		size := 0
		for _, m := range r.ag.outgoing(s) {
			size += msgSize(m)
		}
		if size > worst {
			worst = size
		}
	}
	if worst > 3500 {
		t.Fatalf("a long talk must stay inside the budget, worst request was %d chars", worst)
	}
	if len(s.msgs) > 2*cfg.HistoryKeep+2 {
		t.Fatalf("history not compacted: %d msgs", len(s.msgs))
	}
	if !isSummary(s.msgs[0]) {
		t.Fatal("after 300 exchanges the session must begin with a summary")
	}
}

func TestOldBrowserPagesShrinkButTheNewestStaysWhole(t *testing.T) {
	page := func(n int) string {
		return fmt.Sprintf("[браузер, шаг %d/20]\n<web_page>\nhttps://x.test/%d — «T%d»\nпоказано до 40%% страницы\nЭлементы:\n%s", n, n, n, strings.Repeat("1 a «длинная ссылка» → x.test/very/long\n", 40))
	}
	var msgs []llm.Message
	msgs = append(msgs, llm.Message{Role: "user", Content: "зайди на сайт"})
	for i := 1; i <= 5; i++ {
		id := fmt.Sprint("c", i)
		msgs = append(msgs,
			llm.Message{Role: "assistant", ToolCalls: []llm.ToolCall{{ID: id, Type: "function", Function: llm.FunctionCall{Name: "browser", Arguments: "{}"}}}},
			llm.Message{Role: "tool", ToolCallID: id, Content: page(i)})
	}
	before := 0
	for _, m := range msgs {
		before += msgSize(m)
	}
	out := slimBrowser(msgs)
	after := 0
	for _, m := range out {
		after += msgSize(m)
	}
	if after > before/3 {
		t.Fatalf("old pages not cut: %d -> %d", before, after)
	}
	if out[len(out)-1].Content != msgs[len(msgs)-1].Content {
		t.Fatal("the newest page must stay whole")
	}
	if !strings.Contains(out[2].Content, "https://x.test/1") || !strings.Contains(out[2].Content, "шаг 1/20") {
		t.Fatalf("an old page must keep its address: %q", out[2].Content)
	}
	if msgs[2].Content != page(1) {
		t.Fatal("the stored session must not be modified")
	}
}

func TestCarriedSummarySurvivesARestart(t *testing.T) {
	r := newRig(t, newFakeLLM(t, sendCall)) // the rig's data dir is a fresh temp dir
	s := r.ag.getSession(9)
	s.msgs = []llm.Message{head("PLAN: call Jaabir on Friday"), {Role: "user", Content: "hi"}, {Role: "assistant", Content: "yo"}}
	s.touch(time.Now())
	if err := r.ag.dump(context.Background(), 9); err != nil {
		t.Fatal(err)
	}
	r.ag.sessions.mu.Lock()
	want := r.ag.sessions.carry[9].head.Content
	r.ag.sessions.mu.Unlock()
	if want == "" {
		t.Fatal("nothing carried")
	}
	// a new process: empty memory, the same data dir
	fresh := &Agent{Cfg: r.ag.Cfg}
	New(fresh)
	if got := fresh.getSession(9); len(got.msgs) != 1 || got.msgs[0].Content != want {
		t.Fatalf("summary lost across a restart: %+v", got.msgs)
	}
}
