package agent

import "testing"

func TestLiveTargetFindsTheChatAndTheTextSheWrites(t *testing.T) {
	cases := []struct {
		name, args string
		current    int64
		chat       int64
		typing     string
	}{
		{"send_telegram_message", `{"text":"привет"}`, 5, 5, "привет"},
		{"open_chat", `{"chat_id":-100123}`, 5, -100123, ""},
		{"tg_api", `{"action":"send","chat":"777","text":"йо"}`, 5, 777, "йо"},
		{"tg_api", `{"action":"history","chat":"Алина"}`, 5, 5, ""},
		{"send_to_chat", `{"chat":"-42","text":"x"}`, 5, -42, "x"},
		{"browser", `{"action":"open","url":"https://a.b"}`, 5, 5, ""},
		{"shell", `not json`, 9, 9, ""},
	}
	for _, c := range cases {
		chat, typing := liveTarget(c.name, c.args, c.current)
		if chat != c.chat || typing != c.typing {
			t.Errorf("%s %s: got %d %q, want %d %q", c.name, c.args, chat, typing, c.chat, c.typing)
		}
	}
}

func TestTelegramUIReportsItsOwnTarget(t *testing.T) {
	if id, typing := liveTarget("telegram_ui", `{"action":"open","chat":"3"}`, 5); id != 0 || typing != "" {
		t.Fatalf("a list number became chat %d / %q", id, typing)
	}
}
