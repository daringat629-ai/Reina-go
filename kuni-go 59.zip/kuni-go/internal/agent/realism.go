package agent

import (
	"encoding/json"
	"fmt"
	"hash/fnv"
	"regexp"
	"strings"
	"time"
	"unicode"

	"kuni/internal/llm"
	"kuni/internal/telegram"
)

// sentTexts returns what she wrote in this session (oldest first), read from her #send_telegram_message calls.
func sentTexts(msgs []llm.Message) []string {
	var out []string
	for _, m := range msgs {
		if m.Role != "assistant" {
			continue
		}
		for _, c := range m.ToolCalls {
			if c.Function.Name != "send_telegram_message" {
				continue
			}
			var a struct {
				Text string `json:"text"`
			}
			if json.Unmarshal([]byte(c.Function.Arguments), &a) == nil && strings.TrimSpace(a.Text) != "" {
				out = append(out, strings.TrimSpace(a.Text))
			}
		}
	}
	return out
}

func words(s string) []string {
	return strings.FieldsFunc(strings.ToLower(s), func(r rune) bool { return !unicode.IsLetter(r) && !unicode.IsDigit(r) })
}

func hasEmoji(s string) bool {
	for _, r := range s {
		if r >= 0x1F000 || (r >= 0x2600 && r <= 0x27BF) {
			return true
		}
	}
	return false
}

// ticHint spots habits in what she wrote lately (the same first word, "папик" in every message, the same frame,
// a question at the end of everything, emoji in a row) and tells the model to drop them. "" when she sounds fine.
func ticHint(texts []string) string {
	const window = 8
	if len(texts) > window {
		texts = texts[len(texts)-window:]
	}
	if len(texts) < 3 {
		return ""
	}
	var issues []string
	first, pair := map[string]int{}, map[string]int{}
	papik, questions, emoji, frame := 0, 0, 0, 0
	for _, t := range texts {
		w := words(t)
		if len(w) > 0 && len([]rune(w[0])) >= 2 {
			first[w[0]]++
		}
		if len(w) > 1 {
			pair[w[0]+" "+w[1]]++
		}
		if strings.Contains(strings.ToLower(t), "папик") {
			papik++
		}
		if strings.HasSuffix(strings.TrimRightFunc(t, func(r rune) bool { return unicode.IsSpace(r) || hasEmoji(string(r)) }), "?") {
			questions++
		}
		if hasEmoji(t) {
			emoji++
		}
		if strings.Contains(strings.ToLower(t), ", а не ") || strings.Contains(strings.ToLower(t), " а не ") {
			frame++
		}
	}
	for w, n := range first {
		if n >= 3 {
			issues = append(issues, fmt.Sprintf("you began %d of your last %d messages with «%s»: begin differently", n, len(texts), w))
		}
	}
	for p, n := range pair {
		if n >= 2 && !strings.HasPrefix(p, "а ") {
			issues = append(issues, fmt.Sprintf("you opened twice with «%s»: find another way in", p))
		}
	}
	if papik >= 3 {
		issues = append(issues, fmt.Sprintf("you said «папик» in %d of your last %d messages: leave it out for a while", papik, len(texts)))
	}
	if questions >= 4 {
		issues = append(issues, "almost every message of yours ends with a question: end some with a statement or a jab")
	}
	if emoji >= 3 {
		issues = append(issues, "too many emoji lately: none for the next few messages")
	}
	if frame >= 3 {
		issues = append(issues, "you keep using the «X, а не Y» frame: say it another way")
	}
	if len(issues) == 0 {
		return ""
	}
	return "<style_check>You are getting repetitive: " + strings.Join(issues, "; ") + ". Sound like a person, not a pattern.</style_check>\n"
}

var ackRe = regexp.MustCompile(`^([ахеиоыh]*[хh][ахеиоыa]*|кхм|лол|lol|лмао|кек|ок|окей|окэй|ага|угу|ясно|понял|понятно|норм|збс|ладно|лады|гы+|\+|\)+|ыы+)$`)

// casualHint makes her a little less eager: to a bare laugh or "ok" she may only react or stay silent, to a short
// message she may answer in a few words. The chances come from config (realism.ignore_percent / brief_percent);
// roll is rand.Intn (tests pass a fixed one).
func casualHint(ignorePct, briefPct int, unread []telegram.Message, roll func(int) int) string {
	var last *telegram.Message
	for i := len(unread) - 1; i >= 0; i-- {
		if !unread[i].Outgoing {
			last = &unread[i]
			break
		}
	}
	if last == nil || last.Media != telegram.MediaNone {
		return ""
	}
	t := strings.TrimFunc(strings.ToLower(strings.TrimSpace(last.Text)), func(r rune) bool { return unicode.IsSpace(r) || strings.ContainsRune(".!,", r) })
	n := len([]rune(t))
	switch {
	case n > 0 && n <= 14 && ackRe.MatchString(t) && ignorePct > 0 && roll(100) < ignorePct:
		return "<hint>This is only a laugh or a nod; it does not need an answer. You may put a reaction (#react_with_emoji) and then #wait, or throw in two or three words. No new question, no explaining the joke.</hint>\n"
	case n > 0 && n <= 25 && briefPct > 0 && roll(100) < briefPct:
		return "<hint>Answer this in one to three words, the way people do when they are busy.</hint>\n"
	}
	return ""
}

var lifeBands = []struct {
	from, to int
	things   []string
}{
	{0, 6, []string{"lying in bed with the phone, can't sleep", "up at night poking at some code", "watching a night video instead of sleeping"}},
	{6, 9, []string{"just woke up, grumpy without coffee", "having breakfast and coffee", "getting ready to go out"}},
	{9, 13, []string{"at the laptop, digging into code", "out for a walk with music", "tidying the flat"}},
	{13, 15, []string{"having lunch", "lazing around with the phone after lunch"}},
	{15, 19, []string{"busy with her own stuff, distracted by the phone", "out to the shop", "drawing some digital art"}},
	{19, 23, []string{"having dinner and watching a series", "sitting with music, zoning out", "evening at the laptop"}},
	{23, 24, []string{"supposed to be going to bed but stuck in the phone"}},
}

// lifeLine is a believable, consistent answer to "what are you doing": it depends on the hour and the date only, so
// she never contradicts herself within the same part of the day.
func lifeLine(now time.Time) string {
	h := now.Hour()
	for _, b := range lifeBands {
		if h >= b.from && h < b.to {
			f := fnv.New32a()
			fmt.Fprintf(f, "%s/%d", now.Format("2006-01-02"), b.from)
			return fmt.Sprintf("<life>It is about %02d:00 for you. Right now you are: %s. Say it only if asked what you are up to, or when it fits; do not invent more than this.</life>\n",
				h, b.things[int(f.Sum32())%len(b.things)])
		}
	}
	return ""
}
