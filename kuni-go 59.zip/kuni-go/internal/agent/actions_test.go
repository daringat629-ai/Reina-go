package agent

import (
	"context"
	"encoding/json"
	"os"
	"strings"
	"testing"
	"time"

	"kuni/internal/telegram"
)

func TestJournalKeepsDeedsNotLookups(t *testing.T) {
	r := newRig(t, newFakeLLM(t, sendCall))
	s := &session{id: 5, chat: telegram.Chat{ID: 5, Title: "Friend"}}
	r.ag.noteAction(s, "shell", `{"command":"ls /mnt"}`, "calc\ncalc.asm")
	r.ag.noteAction(s, "web_search", `{"query":"x"}`, "results")       // a lookup: not a deed
	r.ag.noteAction(s, "wait", `{}`, "Ok, waiting.")                   // nothing done
	r.ag.noteAction(s, "files", `{"action":"write"}`, "Error: denied") // a failure is remembered too
	r.ag.noteAction(s, "send_telegram_message", `{"text":"держи файл"}`, "Message sent (message_id=3)")
	acts := r.ag.journal.entries
	if len(acts) != 3 {
		t.Fatalf("%+v", acts)
	}
	if acts[1].OK || !acts[0].OK || acts[2].What != "держи файл" {
		t.Fatalf("%+v", acts)
	}
	// it is on disk and survives a restart
	raw, err := os.ReadFile(r.ag.journal.path)
	if err != nil {
		t.Fatal(err)
	}
	var saved []action
	if json.Unmarshal(raw, &saved) != nil || len(saved) != 3 {
		t.Fatal(string(raw))
	}
	r.ag.journal = newJournal(r.ag.journal.path)
	if len(r.ag.journal.entries) != 3 {
		t.Fatal("not restored")
	}
}

func TestJournalIsCappedAndSearchable(t *testing.T) {
	r := newRig(t, newFakeLLM(t, sendCall))
	s := &session{id: 5, chat: telegram.Chat{ID: 5, Title: "Friend"}}
	for i := 0; i < maxActions+20; i++ {
		r.ag.noteAction(s, "shell", `{"command":"echo n"}`, "ok")
	}
	r.ag.noteAction(s, "schedule", `{"action":"add","text":"weather every morning"}`, "task 1 added")
	if len(r.ag.journal.entries) != maxActions {
		t.Fatal(len(r.ag.journal.entries))
	}
	if got := r.ag.searchActions("weather morning", 10); !strings.Contains(got, "#schedule") || strings.Count(got, "\n") != 0 {
		t.Fatal(got)
	}
	if got := r.ag.searchActions("", 3); strings.Count(got, "\n") != 2 {
		t.Fatal(got)
	}
	if got := r.ag.searchActions("nothing like this", 5); !strings.Contains(got, "Nothing") {
		t.Fatal(got)
	}
}

func TestActionsBlockShowsDeedsOfThisAndOtherChats(t *testing.T) {
	r := newRig(t, newFakeLLM(t, sendCall))
	a, b := &session{id: 5, chat: telegram.Chat{ID: 5, Title: "Friend"}}, &session{id: 6, chat: telegram.Chat{ID: 6, Title: "Alex"}}
	r.ag.noteAction(a, "send_file", `{"path":"/mnt/calc"}`, "sent calc")
	r.ag.noteAction(a, "send_telegram_message", `{"text":"держи"}`, "Message sent (message_id=1)")
	blk := r.ag.actionsBlock(b, true)
	if !strings.Contains(blk, "<your_recent_actions>") || !strings.Contains(blk, "Elsewhere") || !strings.Contains(blk, `"Friend"`) || !strings.Contains(blk, "/mnt/calc") {
		t.Fatal(blk)
	}
	// in the chat where she wrote the message, the message itself is in the history: not repeated
	here := r.ag.actionsBlock(a, true)
	if strings.Contains(here, "держи") || !strings.Contains(here, "send_file") || strings.Contains(here, "Elsewhere") {
		t.Fatal(here)
	}
	// shown once, then left alone until the refresh time passes
	if r.ag.actionsBlock(b, false) != "" {
		t.Fatal("repeated at once")
	}
	b.actionsAt = time.Now().Add(-actionsRefresh - time.Minute)
	if r.ag.actionsBlock(b, false) == "" {
		t.Fatal("not refreshed")
	}
	// old deeds fall out
	r.ag.journal.entries[0].At = time.Now().Add(-actionsWindow - time.Hour)
	r.ag.journal.entries[1].At = r.ag.journal.entries[0].At
	if r.ag.actionsBlock(&session{id: 9}, true) != "" {
		t.Fatal("stale deeds shown")
	}
}

func TestAChatOpenedLaterRemembersWhatWasDoneInAnotherOne(t *testing.T) {
	f := newFakeLLM(t, sendCall)
	r := newRig(t, f)
	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan struct{})
	go func() { r.ag.Run(ctx); close(done) }()
	defer func() { cancel(); <-done }()

	r.ag.noteAction(&session{id: 5, chat: telegram.Chat{ID: 5, Title: "Friend"}}, "shell", `{"command":"cp calc /mnt/pub"}`, "done")
	r.tg.Incoming(telegram.Chat{ID: 100, Title: "Alex", Kind: telegram.ChatPrivate, IsMember: true}, 100, "Alex", "что ты делала?")
	waitFor(t, "an answer", func() bool { return len(r.tg.SentTexts()) == 1 })
	p := lastUserPrompt(f)
	if !strings.Contains(p, "your_recent_actions") || !strings.Contains(p, "cp calc /mnt/pub") {
		t.Fatal("she was not reminded of her own deed")
	}
}

func TestCodeRulesAreInEveryChatYouCanWriteIn(t *testing.T) {
	r := newRig(t, newFakeLLM(t, sendCall))
	for _, c := range []telegram.Chat{
		{ID: 1, Title: "A", Kind: telegram.ChatPrivate, IsMember: true},
		{ID: -2, Title: "G", Kind: telegram.ChatGroup, IsMember: true},
	} {
		in := r.ag.chatInstructions(c)
		if !strings.Contains(in, "CODE AND FILES") || !strings.Contains(in, "share_file") || !strings.HasSuffix(strings.TrimSpace(in), "</instructions>") {
			t.Fatalf("%v: %s", c.Kind, in)
		}
	}
	if in := r.ag.chatInstructions(telegram.Chat{ID: -3, Title: "News", Kind: telegram.ChatChannel, IsMember: true}); strings.Contains(in, "CODE AND FILES") {
		t.Fatal("rules in a channel she cannot write in")
	}
}
