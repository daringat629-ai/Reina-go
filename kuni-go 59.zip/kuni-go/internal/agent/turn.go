package agent

import (
	"context"
	"encoding/json"
	"log"
	"regexp"
	"strings"
	"time"

	"kuni/internal/config"
	"kuni/internal/live"
	"kuni/internal/llm"
	"kuni/internal/prompts"
	"kuni/internal/telegram"
	"kuni/internal/util"
)

// A turn is one answer of hers: rounds of "the model thinks, the tools act" until she is done. The model's plain
// text is only her private thought; everything she does goes through tools (calls.go).
//
// A turn ends when
//   - a round has no tool calls (or only idle ones: wait, pause, skip),
//   - stop_after_send is on and the round only sent messages (no extra round just to hear "done"),
//   - the round limit is reached (telegram.max_tool_rounds; a browsing job gets browser.max_steps more).
//
// In a private chat two nudges keep her honest: a promise like "щас гляну" is not the end of a turn (she is sent to
// do it), and after working with tools she must tell the person what came of it.
type turn struct {
	a      *Agent
	s      *session
	cfg    *config.Config
	system string

	label     string // the chat as the feed and the metrics name it
	private   bool
	maxRounds int

	browsing     bool // a browser step happened in this turn: it gets the browser's step budget
	afterBrowser bool // the last round had a browser step: the next one needs no long thinking

	worked        bool // she did something besides talking (a lookup, a command...)
	reported      bool // and has told the person about it since
	promiseNudges int
	reportNudges  int

	seen    map[string]bool // name|args of the calls made in this turn
	askDone bool
}

// runTurn is the LLM <-> tools loop of a session (s.mu held).
func (a *Agent) runTurn(ctx context.Context, s *session) error {
	t := &turn{a: a, s: s, cfg: a.cfg(), seen: map[string]bool{}, reported: true}
	a.Metrics.Inc("kuni_agent_turns_total", 1, nil)
	ctx = llm.WithChat(ctx, s.id) // so the panel can show what each chat costs
	t.system = a.SystemPromptFor(s)
	a.compact(ctx, s)
	t.private = s.chat.Kind == telegram.ChatPrivate
	t.maxRounds = t.cfg.MaxToolRounds
	t.label = s.chat.Title
	if s.id == 0 {
		t.label = "proactive"
	}
	for round := 0; round < t.maxRounds; round++ {
		done, err := t.round(ctx, round)
		if err != nil || done {
			return err
		}
	}
	log.Printf("agent: chat %d: tool round limit (%d) reached", s.id, t.cfg.MaxToolRounds)
	return nil
}

// round asks the model once and carries out what it decided. done = the turn is over.
func (t *turn) round(ctx context.Context, round int) (done bool, err error) {
	reply, err := t.ask(ctx, round)
	if err != nil {
		return true, err
	}
	s := t.s
	if strings.TrimSpace(reply.Content) == "" && len(reply.ToolCalls) == 0 {
		log.Printf("agent: chat %d round %d: empty answer from the model, retrying", s.id, round)
		return false, nil // blank answer from a local model: ask again
	}
	s.msgs = append(s.msgs, reply)
	s.touch(time.Now())
	names := make([]string, len(reply.ToolCalls))
	for i, c := range reply.ToolCalls {
		names[i] = c.Function.Name
	}
	log.Printf("agent: chat %d round %d: tools=%v thought=%q", s.id, round, names, util.Trunc(reply.Content, 160))
	if strings.TrimSpace(reply.Content) != "" {
		t.a.feed(live.Event{Kind: "thought", Chat: t.label, Text: reply.Content})
	}
	if len(reply.ToolCalls) == 0 {
		return !t.nudge(prompts.HintReport, t.owesReport(), &t.reportNudges, 1), nil
	}
	idleOnly := t.execute(ctx, reply.ToolCalls)
	switch {
	case idleOnly:
		// she chose to stay silent; but if she looked into something, she owes them the result
		return !t.nudge(prompts.HintReport, t.owesReport(), &t.reportNudges, 1), nil
	case t.private && sentOnly(reply.ToolCalls, s.msgs) && promisesWork(reply.ToolCalls) && t.nudge(prompts.HintPromise, true, &t.promiseNudges, 2):
		return false, nil // "щас гляну" is not the end of the turn: she has to go and look
	case t.cfg.StopAfterSend && sentOnly(reply.ToolCalls, s.msgs):
		return true, nil // said what it wanted; no extra round just to hear "done"
	}
	return false, nil
}

// owesReport: in a private chat she worked with tools and has not told the person anything since.
func (t *turn) owesReport() bool { return t.private && t.worked && !t.reported }

// nudge adds a hint for the next round when cond holds and the nudge was given fewer than limit times.
func (t *turn) nudge(name string, cond bool, count *int, limit int) bool {
	if !cond || *count >= limit {
		return false
	}
	*count++
	t.s.msgs = append(t.s.msgs, llm.Message{Role: "user", Content: "<hint>" + t.a.Prompts.Text(name, nil) + "</hint>"})
	return true
}

// ask makes the model call of one round. A browser step needs the next action, not a long think; so does any round
// after a tool result, and a short chat line: those rounds run with reasoning off (and on llm.fast_model when set).
// When such a round fails it is repeated the normal way; a provider that refuses tool_choice gets the request
// without it.
func (t *turn) ask(ctx context.Context, round int) (llm.Message, error) {
	cfg, s := t.cfg, t.s
	rctx := llm.WithPurpose(ctx, "reply")
	req := llm.Request{System: t.system, Messages: t.a.outgoing(s), Tools: s.tools.Defs()}
	fast := (cfg.BrowserFast && t.afterBrowser) || (cfg.FastRounds && (round > 0 || s.quick))
	if cfg.FastModel != "" && cfg.FastGroups && round == 0 && s.chat.Kind != telegram.ChatPrivate && s.id != 0 {
		fast = true // group banter does not need the slow thinker
	}
	forced := cfg.ForceTools // every round: plain-text answers are never delivered to Telegram
	if forced {
		req.ToolChoice = "required"
	}
	normal := req
	if fast {
		req.Reasoning = "off"
		req.Model = cfg.FastModel // a model that does not think for ages; the retry below falls back to the main one
	}
	stopTyping := t.a.typeWhileThinking(ctx, s)
	if cfg.DebugPrompt {
		t.a.dumpPrompt(cfg, t.system, req.Messages, s.tools.Names(), fast, round)
	}
	reply, err := t.a.LLM.Complete(rctx, req)
	stopTyping()
	switch {
	case err == nil || ctx.Err() != nil:
	case fast:
		log.Printf("agent: chat %d: fast round failed (%v), retrying with normal reasoning", s.id, err)
		reply, err = t.a.LLM.Complete(rctx, normal)
	case forced:
		// the provider may not support tool_choice: retry without forcing
		log.Printf("agent: chat %d: forced tool call failed (%v), retrying without", s.id, err)
		normal.ToolChoice = ""
		reply, err = t.a.LLM.Complete(rctx, normal)
	}
	return reply, err
}

var rePromise = regexp.MustCompile(`(?i)(гляну|глянуть|посмотрю|проверю|чекну|поищу|найду|открою|скачаю|прочитаю|изучу|узнаю|разберусь|загляну|пойду проверю|(^|\s)(щас|сейчас)\s*,?\s*(секунд|сек\b|минут|погоди)|(^|\s)(секунду|секундочку|минутку|погоди|подожди)[\s.!,…~]*$|\blet me (check|look|see|find|read)|\bone sec|\bhold on|\bi'll (check|look|find|see|read))`)

// promisesWork: a sent message says that she is about to go and do something ("щас гляну", "секунду").
func promisesWork(calls []llm.ToolCall) bool {
	for _, c := range calls {
		if c.Function.Name != "send_telegram_message" {
			continue
		}
		var v struct {
			Text string `json:"text"`
		}
		if json.Unmarshal([]byte(c.Function.Arguments), &v) == nil && rePromise.MatchString(v.Text) {
			return true
		}
	}
	return false
}

// sentOnly: the round consisted of sent messages (and reactions) that all succeeded.
func sentOnly(calls []llm.ToolCall, msgs []llm.Message) bool {
	sent := false
	for _, c := range calls {
		switch c.Function.Name {
		case "send_telegram_message":
			sent = true
		case "react_with_emoji", "change_mood":
		default:
			return false
		}
	}
	if !sent {
		return false
	}
	for i := len(msgs) - 1; i >= 0 && len(msgs)-i <= len(calls); i-- {
		if msgs[i].Role == "tool" && strings.Contains(strings.ToLower(msgs[i].Content), "error") {
			return false
		}
	}
	return true
}
