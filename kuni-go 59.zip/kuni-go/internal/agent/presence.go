package agent

import (
	"context"
	"math/rand"
	"time"

	"kuni/internal/telegram"
)

// Living presence: she does not answer the instant a message lands. She notices it after a pause, a group later than
// a private chat, a live conversation at once; at night (or asleep) and in a busy moment she may come back to it
// only minutes later. The owner's chat is never postponed.

// presenceIn is everything that decides how quickly she notices a message.
type presenceIn struct {
	Owner      bool          // the owner's private chat: always quick, never postponed
	Group      bool          // groups are noticed more slowly
	Asleep     bool          // she went to sleep (go_to_sleep)
	Night      bool          // quiet hours
	SinceLast  time.Duration // time since the last turn in this chat; a live conversation needs no warm-up
	ReadMin    time.Duration
	ReadMax    time.Duration
	LateChance float64 // 0..1, applied at night
	LateMin    time.Duration
	LateMax    time.Duration
	SlowChance float64 // 0..1: she was busy and notices this one much later
}

type presencePlan struct {
	Late time.Duration // >0: do not look at the chat for this long (messages stay unread)
	Read time.Duration // pause before opening the chat
}

// planPresence is pure (rnd injected) so it can be tested.
func planPresence(in presenceIn, rnd func() float64) presencePlan {
	span := func(lo, hi time.Duration) time.Duration {
		if hi <= lo {
			return lo
		}
		return lo + time.Duration(rnd()*float64(hi-lo))
	}
	if in.Owner {
		p := presencePlan{Read: span(0, 1500*time.Millisecond)}
		if in.SlowChance > 0 && rnd() < in.SlowChance && in.SinceLast > 90*time.Second {
			p.Read = span(15*time.Second, 55*time.Second) // busy for a moment; never minutes for him
		}
		return p
	}
	var p presencePlan
	if in.Asleep || (in.Night && rnd() < in.LateChance) {
		p.Late = span(in.LateMin, in.LateMax)
	} else if in.SlowChance > 0 && in.SinceLast > 90*time.Second && rnd() < in.SlowChance {
		p.Late = span(2*time.Minute, 12*time.Minute) // a busy moment in the middle of the day
	}
	read := span(in.ReadMin, in.ReadMax)
	if in.Group {
		read += span(in.ReadMin, in.ReadMax) // groups: notice later
	}
	if in.SinceLast > 0 && in.SinceLast < 90*time.Second {
		read /= 4 // already talking
	}
	p.Read = read
	return p
}

func (a *Agent) presenceFor(chat telegram.Chat, s *session, now time.Time) presencePlan {
	cfg := a.cfg()
	if !cfg.PresenceEnabled {
		return presencePlan{}
	}
	in := presenceIn{
		Owner:      cfg.IsOwner(chat.ID),
		Group:      chat.Kind != telegram.ChatPrivate,
		Night:      a.isNight(now),
		ReadMin:    time.Duration(cfg.ReadDelayMin) * time.Second,
		ReadMax:    time.Duration(cfg.ReadDelayMax) * time.Second,
		LateChance: float64(cfg.LateReplyPercent) / 100,
		LateMin:    time.Duration(cfg.LateReplyMinMins) * time.Minute,
		LateMax:    time.Duration(cfg.LateReplyMaxMins) * time.Minute,
		SlowChance: float64(cfg.SlowPercent) / 100,
	}
	if a.Auto != nil && cfg.AutonomyEnabled {
		in.Asleep, _ = a.Auto.Asleep()
	}
	if last := s.lastTime(); !last.IsZero() {
		in.SinceLast = now.Sub(last)
	}
	return planPresence(in, rand.Float64)
}

// readPause waits before the chat is opened. false = interrupted.
func (a *Agent) readPause(ctx context.Context, d time.Duration) bool {
	if d <= 0 {
		return true
	}
	t := time.NewTimer(d)
	defer t.Stop()
	select {
	case <-t.C:
		return true
	case <-ctx.Done():
		return false
	}
}

// offlineAfter is how long the account stays "online" after the last turn.
func (a *Agent) offlineAfter() time.Duration {
	if s := a.cfg().OfflineAfterSecs; s > 0 {
		return time.Duration(s) * time.Second
	}
	return 20 * time.Second
}
