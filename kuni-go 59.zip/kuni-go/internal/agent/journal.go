package agent

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"
	"sync"
	"time"

	"kuni/internal/store"
	"kuni/internal/tools"
	"kuni/internal/util"
)

// The action journal: what she DID (ran, wrote, sent elsewhere, scheduled, changed), kept on disk. A session's
// history is cut, summarised and thrown away; this list is what keeps her from saying "I never did that" or doing
// the same job twice. It is shown to her when a session starts and now and then in a long one, and #my_actions
// searches it. It has its own lock: writing it never makes a new message wait.

const (
	maxActions      = 300
	actionsShown    = 12 // from this chat
	actionsShownOth = 8  // from the other chats and her own business
	actionsRefresh  = 30 * time.Minute
	actionsWindow   = 48 * time.Hour
)

type action struct {
	At    time.Time `json:"at"`
	Chat  int64     `json:"chat"`
	Title string    `json:"title,omitempty"`
	Tool  string    `json:"tool"`
	What  string    `json:"what"`
	Out   string    `json:"out,omitempty"`
	OK    bool      `json:"ok"`
}

type journal struct {
	mu      sync.Mutex
	entries []action
	path    string // "" = in memory only
	saver   store.Saver
}

func newJournal(path string) *journal {
	j := &journal{path: path, saver: store.Saver{What: "agent: action journal"}}
	if path != "" {
		store.Load("agent: action journal", path, &j.entries)
	}
	return j
}

// oneLine squeezes whitespace and cuts to n runes.
func oneLine(s string, n int) string { return util.Trunc(strings.Join(strings.Fields(s), " "), n) }

// journaled says whether a call of the tool is a deed worth remembering: looking, thinking and waiting are not.
func journaled(m tools.Meta) bool { return !m.Quiet && !m.ReadOnly }

// add puts one finished tool call into the journal.
func (j *journal) add(chat int64, title, tool, args, out string, failed bool) {
	what := oneLine(args, 160)
	if tool == "send_telegram_message" {
		var v struct {
			Text string `json:"text"`
		}
		if json.Unmarshal([]byte(args), &v) == nil && v.Text != "" {
			what = oneLine(v.Text, 140)
		}
	}
	e := action{At: time.Now(), Chat: chat, Title: title, Tool: tool, What: what, Out: oneLine(out, 100), OK: !failed}
	j.mu.Lock()
	defer j.mu.Unlock()
	j.entries = append(j.entries, e)
	if len(j.entries) > maxActions {
		j.entries = append([]action(nil), j.entries[len(j.entries)-maxActions:]...)
	}
	_ = j.saver.Save(j.path, j.entries)
}

// recent returns her recent deeds in chat (without the messages she wrote there: those are in the chat's history)
// and elsewhere, newest first.
func (j *journal) recent(chat int64, now time.Time) (here, other []action) {
	j.mu.Lock()
	defer j.mu.Unlock()
	for i := len(j.entries) - 1; i >= 0; i-- {
		e := j.entries[i]
		if now.Sub(e.At) > actionsWindow {
			break
		}
		if e.Chat == chat {
			if e.Tool == "send_telegram_message" && e.OK {
				continue
			}
			if len(here) < actionsShown {
				here = append(here, e)
			}
		} else if len(other) < actionsShownOth {
			other = append(other, e)
		}
	}
	return here, other
}

// find lists entries matching every word of the query (any when empty), newest first.
func (j *journal) find(query string, limit int) []action {
	words := strings.Fields(strings.ToLower(query))
	j.mu.Lock()
	defer j.mu.Unlock()
	out := []action{}
	for i := len(j.entries) - 1; i >= 0 && len(out) < limit; i-- {
		e := j.entries[i]
		hay := strings.ToLower(e.Tool + " " + e.What + " " + e.Out + " " + e.Title)
		match := true
		for _, w := range words {
			if !strings.Contains(hay, w) {
				match = false
				break
			}
		}
		if match {
			out = append(out, e)
		}
	}
	return out
}

func formatAction(e action, now time.Time) string {
	var b strings.Builder
	fmt.Fprintf(&b, "- %s", util.TimeAgo(e.At, now))
	if e.Title != "" {
		fmt.Fprintf(&b, " in %q", safeName(e.Title))
	}
	fmt.Fprintf(&b, ": #%s %s", e.Tool, e.What)
	if !e.OK {
		b.WriteString(" -> FAILED")
	}
	if e.Out != "" {
		b.WriteString(" -> " + e.Out)
	}
	return b.String()
}

// noteAction puts one finished tool call of a session into the journal (when it is a deed at all).
func (a *Agent) noteAction(s *session, name, args, out string) {
	a.noteCall(s, name, tools.MetaOf(name), args, out, strings.HasPrefix(out, "Error"))
}

func (a *Agent) noteCall(s *session, name string, m tools.Meta, args, out string, failed bool) {
	if !journaled(m) {
		return
	}
	var id int64
	title := ""
	if s != nil {
		id, title = s.id, s.chat.Title
	}
	a.journal.add(id, title, name, args, out, failed)
}

// actionsBlock is what she is reminded of when a chat is opened: her recent deeds here and elsewhere. Empty when
// there is nothing, or when it was shown recently in this session (force skips that pause).
func (a *Agent) actionsBlock(s *session, force bool) string {
	now := time.Now()
	if !force && !s.actionsAt.IsZero() && now.Sub(s.actionsAt) < actionsRefresh {
		return ""
	}
	here, other := a.journal.recent(s.id, now)
	if len(here)+len(other) == 0 {
		return ""
	}
	s.actionsAt = now
	var b strings.Builder
	b.WriteString("<your_recent_actions>\nThings YOU did (newest first). They happened: do not deny them, do not redo them without a reason; #my_actions searches older ones.\n")
	for _, e := range here {
		b.WriteString(formatAction(e, now) + "\n")
	}
	if len(other) > 0 {
		b.WriteString("Elsewhere:\n")
		for _, e := range other {
			b.WriteString(formatAction(e, now) + "\n")
		}
	}
	b.WriteString("</your_recent_actions>\n")
	return b.String()
}

// searchActions is the text #my_actions returns.
func (a *Agent) searchActions(query string, limit int) string {
	if limit <= 0 || limit > 50 {
		limit = 15
	}
	found := a.journal.find(query, limit)
	if len(found) == 0 {
		return "Nothing in your action journal matches."
	}
	now := time.Now()
	lines := make([]string, len(found))
	for i, e := range found {
		lines[i] = formatAction(e, now)
	}
	return strings.Join(lines, "\n")
}

// myActionsTool lets her look up what she did: by words (a tool name, a file, a chat, a command) or just the latest.
func (a *Agent) myActionsTool() tools.Tool {
	return tools.Tool{
		Name:        "my_actions",
		Description: "Your own action journal: what you actually DID (commands run, files written, messages sent to other chats, tasks scheduled, settings changed), newest first. Look here before you say you did not do something, or before you do a job again.",
		Props: []tools.Prop{
			{Name: "query", Type: "string", Nullable: true, Desc: "Words that must all appear (a tool name, a file name, a chat, a word from the command). Empty = the latest."},
			{Name: "limit", Type: "integer", Nullable: true, Desc: "How many entries (default 15, at most 50)."},
		},
		Run: func(ctx context.Context, args tools.Args) (string, error) {
			return a.searchActions(args.Str("query"), int(args.Int("limit"))), nil
		},
	}
}

// Actions is the journal for the panel: entries matching every word of query, newest first.
func (a *Agent) Actions(query string, limit int) any {
	if limit <= 0 || limit > 300 {
		limit = 60
	}
	return a.journal.find(query, limit)
}
