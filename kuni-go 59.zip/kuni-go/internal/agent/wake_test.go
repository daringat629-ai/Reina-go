package agent

import (
	"context"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"kuni/internal/people"
	"kuni/internal/reminders"
	"kuni/internal/telegram"
)

func TestDueReminderWakesHerAndSheWrites(t *testing.T) {
	f := newFakeLLM(t, sendCall)
	r := newRig(t, f)
	r.ag.Cfg.Get().PapikChatID = 100
	r.ag.Deps.Reminders = reminders.New(filepath.Join(r.dir, "rem.json"))
	now := time.Now()
	chat := telegram.Chat{ID: 100, Title: "Alex", Kind: telegram.ChatPrivate, IsMember: true}
	r.tg.S.Put(telegram.Message{ID: 1, ChatID: 100, SenderID: 100, SenderName: "Alex", Date: now, Text: "hi", Read: true}, &chat)
	if _, err := r.ag.Deps.Reminders.Add(now.Add(-time.Second), 100, "call the dentist", now.Add(-time.Hour)); err != nil {
		t.Fatal(err)
	}
	r.ag.fireDue(context.Background())
	waitFor(t, "her message after the reminder", func() bool { return len(r.tg.SentTexts()) == 1 })
	p := lastUserPrompt(f)
	if !strings.Contains(p, "call the dentist") || !strings.Contains(p, "has come due") {
		t.Fatalf("the event is missing from her prompt (%d bytes)", len(p))
	}
	if len(r.ag.Deps.Reminders.List(0)) != 0 {
		t.Fatal("a fired reminder is gone")
	}
	// paused: nothing fires, the reminder waits
	if _, err := r.ag.Deps.Reminders.Add(now.Add(-time.Second), 100, "later", now); err != nil {
		t.Fatal(err)
	}
	r.ag.SetPaused(true)
	r.ag.fireDue(context.Background())
	if len(r.ag.Deps.Reminders.List(0)) != 1 {
		t.Fatal("while paused reminders must wait")
	}
}

func TestPersonCardsShowOnlyWhatMayBeSaid(t *testing.T) {
	r := newRig(t, newFakeLLM(t, sendCall))
	r.ag.Deps.People = people.New(filepath.Join(r.dir, "people"))
	now := time.Now()
	_ = r.ag.Deps.People.Add(9, "Joe", "told me about his divorce", true, now)
	_ = r.ag.Deps.People.Add(9, "Joe", "plays chess", false, now)

	dm := telegram.Chat{ID: 9, Title: "Joe", Kind: telegram.ChatPrivate, IsMember: true}
	if got := r.ag.personCards(dm, nil); !strings.Contains(got, "divorce") || !strings.Contains(got, "chess") {
		t.Fatalf("a private chat sees everything: %q", got)
	}
	group := telegram.Chat{ID: -3, Title: "G", Kind: telegram.ChatGroup, IsMember: true}
	got := r.ag.personCards(group, []telegram.Message{{SenderID: 9}, {SenderID: 9}})
	if strings.Contains(got, "divorce") || !strings.Contains(got, "chess") || strings.Count(got, "<person_card") != 1 {
		t.Fatalf("a group must not hear private facts: %q", got)
	}
	// the card is shown once per turn, not dragged along in the history
	if out := slimUser("<person_card user_id=\"9\" name=\"Joe\">\n- x\n</person_card>\n<message>hi</message>"); strings.Contains(out, "person_card") {
		t.Fatal("old cards must be slimmed out of the history")
	}
}
