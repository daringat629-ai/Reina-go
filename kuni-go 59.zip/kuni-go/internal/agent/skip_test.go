package agent

import (
	"context"
	"testing"
	"time"

	"kuni/internal/llm"
	"kuni/internal/telegram"
)

func TestSkipEndsTheTurnWithoutAnswerAndWithoutExtraRound(t *testing.T) {
	f := newFakeLLM(t, func(int64) llm.ToolCall {
		return llm.ToolCall{ID: "s1", Type: "function", Function: llm.FunctionCall{Name: "skip", Arguments: `{"reason":"small talk between others"}`}}
	})
	r := newRig(t, f)
	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan struct{})
	go func() { r.ag.Run(ctx); close(done) }()
	defer func() { cancel(); <-done }()

	g := telegram.Chat{ID: -700, Title: "Club", Kind: telegram.ChatGroup, IsMember: true}
	r.tg.Incoming(g, 301, "Ann", "lol that was so funny")
	waitFor(t, "her skip", func() bool { return r.ag.Metrics.Get("kuni_tool_calls_total", map[string]string{"tool": "skip"}) == 1 })
	time.Sleep(300 * time.Millisecond)
	if n := len(r.tg.SentTexts()); n != 0 {
		t.Fatalf("she answered although she skipped: %v", r.tg.SentTexts())
	}
	// one round only: the model was asked once with tools (the later calls are the shutdown diary, not this chat)
	f.mu.Lock()
	withTools := 0
	for _, c := range f.calls {
		if _, ok := c["tools"]; ok {
			withTools++
		}
	}
	f.mu.Unlock()
	if withTools != 1 {
		t.Fatalf("%d rounds, want 1", withTools)
	}
	if un, _ := r.tg.Unread(ctx, -700); len(un) != 0 {
		t.Fatal("skipped messages must still count as read")
	}
}
