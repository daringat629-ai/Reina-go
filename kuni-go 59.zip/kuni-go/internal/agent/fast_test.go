package agent

import (
	"context"
	"strings"
	"testing"
	"time"

	"kuni/internal/telegram"
)

func reasoningOff(call map[string]any) bool {
	r, _ := call["reasoning"].(map[string]any)
	return r != nil && r["enabled"] == false
}

func runOnce(t *testing.T, text string, fastRounds bool, media telegram.MediaKind) []map[string]any {
	t.Helper()
	f := newFakeLLM(t, sendCall)
	r := newRig(t, f)
	cfg := r.ag.Cfg.Get()
	cfg.FastRounds, cfg.FastShortChars = fastRounds, 220
	chat := telegram.Chat{ID: 100, Title: "Alex", Kind: telegram.ChatPrivate, IsMember: true}
	r.tg.S.Put(telegram.Message{ID: 1, ChatID: 100, SenderID: 100, SenderName: "Alex", Date: time.Now(), Text: text, Media: media}, &chat)
	if err := r.ag.HandleChat(context.Background(), 100); err != nil {
		t.Fatal(err)
	}
	var calls []map[string]any
	f.mu.Lock()
	for _, c := range f.calls {
		if _, ok := c["tools"]; ok { // the turn's rounds (not diary or embedding calls)
			calls = append(calls, c)
		}
	}
	f.mu.Unlock()
	if len(calls) < 2 {
		t.Fatalf("expected a tool round and a follow-up, got %d calls", len(calls))
	}
	return calls
}

func TestThinkingOnlyWhereItMatters(t *testing.T) {
	// a short private line: no long thinking at all
	c := runOnce(t, "привет, как дела?", true, telegram.MediaNone)
	if !reasoningOff(c[0]) || !reasoningOff(c[1]) {
		t.Fatalf("short talk must be answered without reasoning: %v %v", c[0]["reasoning"], c[1]["reasoning"])
	}
	// a long message: the first round thinks, the follow-up after the tool result does not
	c = runOnce(t, strings.Repeat("длинное сообщение с подробностями ", 12), true, telegram.MediaNone)
	if reasoningOff(c[0]) || !reasoningOff(c[1]) {
		t.Fatalf("long message: first round thinks, follow-up is fast: %v %v", c[0]["reasoning"], c[1]["reasoning"])
	}
	// a photo is never treated as quick talk
	c = runOnce(t, "глянь", true, telegram.MediaPhoto)
	if reasoningOff(c[0]) {
		t.Fatal("a photo needs thinking")
	}
	// switched off: nothing is overridden
	c = runOnce(t, "привет", false, telegram.MediaNone)
	if reasoningOff(c[0]) || reasoningOff(c[1]) {
		t.Fatal("fast_rounds=false must leave the model's own reasoning alone")
	}
}
