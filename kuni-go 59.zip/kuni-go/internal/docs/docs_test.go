package docs

import (
	"archive/zip"
	"bytes"
	"context"
	"strings"
	"testing"
)

func makeZip(t *testing.T, files map[string]string) []byte {
	t.Helper()
	var buf bytes.Buffer
	w := zip.NewWriter(&buf)
	for n, c := range files {
		f, _ := w.Create(n)
		f.Write([]byte(c))
	}
	w.Close()
	return buf.Bytes()
}

func TestPlainTextEncodings(t *testing.T) {
	ctx := context.Background()
	got, err := Extract(ctx, "a.txt", []byte("\xEF\xBB\xBFпривет"))
	if err != nil || got != "привет" {
		t.Fatalf("bom: %q %v", got, err)
	}
	// windows-1251 "Привет, Ёж"
	got, err = Extract(ctx, "old.txt", []byte{0xCF, 0xF0, 0xE8, 0xE2, 0xE5, 0xF2, ',', ' ', 0xA8, 0xE6})
	if err != nil || got != "Привет, Ёж" {
		t.Fatalf("cp1251: %q %v", got, err)
	}
	// utf-16le
	got, err = Extract(ctx, "u.txt", []byte{0xFF, 0xFE, 'h', 0, 'i', 0})
	if err != nil || got != "hi" {
		t.Fatalf("utf16: %q %v", got, err)
	}
	if _, err = Extract(ctx, "x.bin", []byte{1, 2, 0, 3}); err == nil {
		t.Fatal("binary must be rejected")
	}
	if _, err = Extract(ctx, "x.txt", []byte{'a', 0, 'b', 'c'}); err == nil {
		t.Fatal("NUL inside .txt is binary")
	}
	if got, err = Extract(ctx, "README", []byte("no extension but text")); err != nil || !strings.Contains(got, "text") {
		t.Fatalf("unknown ext text: %q %v", got, err)
	}
}

func TestDocxOdtXlsx(t *testing.T) {
	ctx := context.Background()
	dx := makeZip(t, map[string]string{"word/document.xml": `<w:document xmlns:w="x"><w:body><w:p><w:r><w:t>Hello</w:t></w:r><w:r><w:tab/><w:t>world</w:t></w:r></w:p><w:p><w:r><w:t>Second</w:t></w:r></w:p></w:body></w:document>`})
	got, err := Extract(ctx, "r.docx", dx)
	if err != nil || got != "Hello\tworld\nSecond" {
		t.Fatalf("docx: %q %v", got, err)
	}
	od := makeZip(t, map[string]string{"content.xml": `<o:text xmlns:o="x"><o:p>one</o:p><o:h>two</o:h></o:text>`})
	if got, err = Extract(ctx, "r.odt", od); err != nil || got != "one\ntwo" {
		t.Fatalf("odt: %q %v", got, err)
	}
	xl := makeZip(t, map[string]string{
		"xl/sharedStrings.xml":     `<sst><si><t>name</t></si><si><t>age</t></si><si><t>Bob</t></si></sst>`,
		"xl/worksheets/sheet1.xml": `<worksheet><sheetData><row r="1"><c r="A1" t="s"><v>0</v></c><c r="C1" t="s"><v>1</v></c></row><row r="2"><c r="A2" t="s"><v>2</v></c><c r="C2"><v>31</v></c></row></sheetData></worksheet>`,
	})
	if got, err = Extract(ctx, "t.xlsx", xl); err != nil || !strings.Contains(got, "name\t\tage") || !strings.Contains(got, "Bob\t\t31") {
		t.Fatalf("xlsx: %q %v", got, err)
	}
	if _, err = Extract(ctx, "bad.docx", []byte("not a zip")); err == nil {
		t.Fatal("garbage docx must error")
	}
}

func TestZipBombIsRefused(t *testing.T) {
	big := strings.Repeat("a", MaxInflate+10)
	z := makeZip(t, map[string]string{"word/document.xml": big})
	if _, err := Extract(context.Background(), "b.docx", z); err == nil || !strings.Contains(err.Error(), "too large") {
		t.Fatalf("zip bomb: %v", err)
	}
}

func TestPDFWithoutToolIsAClearError(t *testing.T) {
	t.Setenv("PATH", t.TempDir())
	if _, err := Extract(context.Background(), "a.pdf", []byte("%PDF-1.4")); err != ErrNoPDF {
		t.Fatalf("want ErrNoPDF, got %v", err)
	}
}

func TestReadable(t *testing.T) {
	for _, n := range []string{"a.PDF", "b.docx", "c.csv", "d.md", "e.xlsx", "x/y/f.JSON"} {
		if !Readable(n) {
			t.Errorf("%s should be readable", n)
		}
	}
	for _, n := range []string{"a.exe", "b.zip", "c.mp4", "noext"} {
		if Readable(n) {
			t.Errorf("%s should not be readable", n)
		}
	}
}

func TestHTMLToText(t *testing.T) {
	src := `<html><head><title> Hi &amp; bye </title><meta name="description" content="A &quot;nice&quot; page"><style>p{color:red}</style></head>
<body><nav>menu menu</nav><script>alert(1)</script><h1>Header</h1><p>Para <b>one</b>&nbsp;here</p><!-- c --><p>Two</p><footer>foot</footer></body></html>`
	title, desc := HTMLTitle(src)
	if title != "Hi & bye" || desc != `A "nice" page` {
		t.Fatalf("title=%q desc=%q", title, desc)
	}
	got := HTMLToText(src)
	if got != "Header\n\nPara one here\n\nTwo" {
		t.Fatalf("text=%q", got)
	}
}
