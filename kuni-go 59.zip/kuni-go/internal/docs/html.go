package docs

import (
	"html"
	"regexp"
	"strings"
)

var (
	reDrop    = regexp.MustCompile(`(?is)<(script|style|noscript|svg|template|iframe|head|nav|footer|form)\b.*?</(script|style|noscript|svg|template|iframe|head|nav|footer|form)\s*>`)
	reComment = regexp.MustCompile(`(?s)<!--.*?-->`)
	reBlock   = regexp.MustCompile(`(?i)</?(p|div|section|article|main|header|h[1-6]|li|ul|ol|tr|table|blockquote|pre|br|hr|dt|dd|figure|figcaption)\b[^>]*>`)
	reTag     = regexp.MustCompile(`(?s)<[^>]*>`)
	reSpaces  = regexp.MustCompile(`[ \t\f\v\x{a0}]+`)
	reTitle   = regexp.MustCompile(`(?is)<title[^>]*>(.*?)</title>`)
	reMeta    = regexp.MustCompile(`(?is)<meta[^>]+(?:name|property)\s*=\s*["'](?:description|og:description)["'][^>]*>`)
	reContent = regexp.MustCompile(`(?is)content\s*=\s*"([^"]*)"|content\s*=\s*'([^']*)'`)
)

// HTMLTitle returns the page title and meta description (either may be empty).
func HTMLTitle(src string) (title, desc string) {
	if m := reTitle.FindStringSubmatch(src); m != nil {
		title = strings.Join(strings.Fields(html.UnescapeString(reTag.ReplaceAllString(m[1], ""))), " ")
	}
	if m := reMeta.FindString(src); m != "" {
		if c := reContent.FindStringSubmatch(m); c != nil {
			desc = strings.Join(strings.Fields(html.UnescapeString(c[1]+c[2])), " ")
		}
	}
	return
}

// HTMLToText strips markup, keeps paragraph structure and drops scripts, styles and page chrome.
func HTMLToText(src string) string {
	src = reComment.ReplaceAllString(src, "")
	src = reDrop.ReplaceAllString(src, "")
	src = reBlock.ReplaceAllString(src, "\n")
	src = reTag.ReplaceAllString(src, "")
	src = html.UnescapeString(src)
	lines := strings.Split(src, "\n")
	for i, l := range lines {
		lines[i] = strings.TrimSpace(reSpaces.ReplaceAllString(l, " "))
	}
	return clean(strings.Join(lines, "\n"))
}
