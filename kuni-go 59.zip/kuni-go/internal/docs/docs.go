// Package docs turns files people send her (txt, md, csv, json, docx, xlsx, odt, pdf) into plain text.
// Everything is read in memory with hard size limits; nothing is executed except pdftotext (when installed).
package docs

import (
	"archive/zip"
	"bytes"
	"context"
	"encoding/xml"
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path"
	"sort"
	"strconv"
	"strings"
	"time"
	"unicode/utf16"
	"unicode/utf8"
)

// MaxInflate bounds what an archive-based format (docx...) may expand to, against zip bombs.
const MaxInflate = 20 << 20

// ErrNoPDF is returned when pdftotext is not installed.
var ErrNoPDF = errors.New("reading PDF needs the pdftotext program on the server (Alpine: apk add poppler-utils)")

var textExt = map[string]bool{
	".txt": true, ".md": true, ".markdown": true, ".csv": true, ".tsv": true, ".json": true, ".jsonl": true, ".xml": true,
	".yaml": true, ".yml": true, ".toml": true, ".ini": true, ".conf": true, ".cfg": true, ".log": true, ".html": true, ".htm": true,
	".go": true, ".py": true, ".js": true, ".ts": true, ".java": true, ".kt": true, ".c": true, ".h": true, ".cpp": true, ".cs": true,
	".rs": true, ".sh": true, ".sql": true, ".css": true, ".tex": true, ".srt": true, ".vtt": true, ".env": true, ".rb": true, ".php": true,
}

// Readable reports whether Extract understands the file by its name.
func Readable(name string) bool {
	e := ext(name)
	switch e {
	case ".docx", ".xlsx", ".odt", ".pdf":
		return true
	}
	return textExt[e]
}

func ext(name string) string { return strings.ToLower(path.Ext(strings.ReplaceAll(name, "\\", "/"))) }

// Extract returns the text of a file.
func Extract(ctx context.Context, name string, data []byte) (string, error) {
	switch ext(name) {
	case ".docx":
		return docx(data)
	case ".odt":
		return odt(data)
	case ".xlsx":
		return xlsx(data)
	case ".pdf":
		return pdf(ctx, data)
	}
	if !Readable(name) && !looksText(data) {
		return "", fmt.Errorf("can't read %q: unsupported file type", name)
	}
	s, err := decodeText(data)
	if err != nil {
		return "", err
	}
	if e := ext(name); e == ".html" || e == ".htm" {
		return HTMLToText(s), nil
	}
	return s, nil
}

func looksText(b []byte) bool {
	if len(b) > 4096 {
		b = b[:4096]
	}
	return len(b) > 0 && !bytes.Contains(b, []byte{0})
}

// DecodeText turns bytes of a text file (UTF-8, UTF-16, old windows-1251) into a string.
func DecodeText(b []byte) (string, error) { return decodeText(b) }

// decodeText handles UTF-8 (with BOM), UTF-16 (with BOM) and, as a fallback for old Russian files, windows-1251.
func decodeText(b []byte) (string, error) {
	switch {
	case bytes.HasPrefix(b, []byte{0xEF, 0xBB, 0xBF}):
		b = b[3:]
	case bytes.HasPrefix(b, []byte{0xFF, 0xFE}), bytes.HasPrefix(b, []byte{0xFE, 0xFF}):
		le := b[0] == 0xFF
		u := make([]uint16, 0, len(b)/2)
		for i := 2; i+1 < len(b); i += 2 {
			if le {
				u = append(u, uint16(b[i])|uint16(b[i+1])<<8)
			} else {
				u = append(u, uint16(b[i+1])|uint16(b[i])<<8)
			}
		}
		return string(utf16.Decode(u)), nil
	}
	if bytes.IndexByte(b[:min(len(b), 4096)], 0) >= 0 {
		return "", errors.New("this looks like a binary file, not text")
	}
	if utf8.Valid(b) {
		return string(b), nil
	}
	var sb strings.Builder
	for _, c := range b {
		switch {
		case c < 0x80:
			sb.WriteByte(c)
		case c >= 0xC0:
			sb.WriteRune(rune(0x410 + int(c) - 0xC0))
		case c == 0xA8:
			sb.WriteRune('Ё')
		case c == 0xB8:
			sb.WriteRune('ё')
		default:
			sb.WriteRune('?')
		}
	}
	return sb.String(), nil
}

func openZip(data []byte) (*zip.Reader, error) {
	z, err := zip.NewReader(bytes.NewReader(data), int64(len(data)))
	if err != nil {
		return nil, fmt.Errorf("not a valid document: %w", err)
	}
	return z, nil
}

func zipFile(z *zip.Reader, name string) (io.ReadCloser, error) {
	for _, f := range z.File {
		if f.Name == name {
			if f.UncompressedSize64 > MaxInflate {
				return nil, errors.New("document is too large when unpacked")
			}
			rc, err := f.Open()
			if err != nil {
				return nil, err
			}
			return struct {
				io.Reader
				io.Closer
			}{io.LimitReader(rc, MaxInflate), rc}, nil
		}
	}
	return nil, fmt.Errorf("%s is missing in the document", name)
}

func docx(data []byte) (string, error) {
	z, err := openZip(data)
	if err != nil {
		return "", err
	}
	r, err := zipFile(z, "word/document.xml")
	if err != nil {
		return "", err
	}
	defer r.Close()
	var b strings.Builder
	d := xml.NewDecoder(r)
	inText := false
	for {
		tok, err := d.Token()
		if err == io.EOF {
			break
		}
		if err != nil {
			return clean(b.String()), nil // keep what was read
		}
		switch t := tok.(type) {
		case xml.StartElement:
			switch t.Name.Local {
			case "t":
				inText = true
			case "tab":
				b.WriteByte('\t')
			case "br", "cr":
				b.WriteByte('\n')
			}
		case xml.EndElement:
			switch t.Name.Local {
			case "t":
				inText = false
			case "p":
				b.WriteByte('\n')
			}
		case xml.CharData:
			if inText {
				b.Write(t)
			}
		}
	}
	return clean(b.String()), nil
}

func odt(data []byte) (string, error) {
	z, err := openZip(data)
	if err != nil {
		return "", err
	}
	r, err := zipFile(z, "content.xml")
	if err != nil {
		return "", err
	}
	defer r.Close()
	var b strings.Builder
	d := xml.NewDecoder(r)
	for {
		tok, err := d.Token()
		if err != nil {
			break
		}
		switch t := tok.(type) {
		case xml.StartElement:
			switch t.Name.Local {
			case "tab":
				b.WriteByte('\t')
			case "line-break":
				b.WriteByte('\n')
			}
		case xml.EndElement:
			if t.Name.Local == "p" || t.Name.Local == "h" {
				b.WriteByte('\n')
			}
		case xml.CharData:
			b.Write(t)
		}
	}
	return clean(b.String()), nil
}

func xlsx(data []byte) (string, error) {
	z, err := openZip(data)
	if err != nil {
		return "", err
	}
	var shared []string
	if r, err := zipFile(z, "xl/sharedStrings.xml"); err == nil {
		shared = sharedStrings(r)
		r.Close()
	}
	var sheets []string
	for _, f := range z.File {
		if strings.HasPrefix(f.Name, "xl/worksheets/sheet") && strings.HasSuffix(f.Name, ".xml") {
			sheets = append(sheets, f.Name)
		}
	}
	sort.Strings(sheets)
	if len(sheets) == 0 {
		return "", errors.New("the workbook has no sheets")
	}
	var out strings.Builder
	for i, name := range sheets {
		if i >= 3 {
			out.WriteString("(more sheets omitted)\n")
			break
		}
		r, err := zipFile(z, name)
		if err != nil {
			continue
		}
		fmt.Fprintf(&out, "# sheet %d\n", i+1)
		sheetText(r, shared, &out)
		r.Close()
	}
	return clean(out.String()), nil
}

func sharedStrings(r io.Reader) []string {
	var res []string
	d := xml.NewDecoder(r)
	var cur strings.Builder
	inT := false
	for {
		tok, err := d.Token()
		if err != nil {
			break
		}
		switch t := tok.(type) {
		case xml.StartElement:
			switch t.Name.Local {
			case "si":
				cur.Reset()
			case "t":
				inT = true
			}
		case xml.EndElement:
			switch t.Name.Local {
			case "t":
				inT = false
			case "si":
				res = append(res, cur.String())
			}
		case xml.CharData:
			if inT {
				cur.Write(t)
			}
		}
	}
	return res
}

func colIndex(ref string) int {
	n := 0
	for _, c := range ref {
		if c < 'A' || c > 'Z' {
			break
		}
		n = n*26 + int(c-'A') + 1
	}
	return n - 1
}

func sheetText(r io.Reader, shared []string, out *strings.Builder) {
	d := xml.NewDecoder(r)
	var (
		row     []string
		col     = -1
		typ     string
		inV     bool
		inT     bool
		val     strings.Builder
		rows    int
		trimEnd = func(r []string) []string {
			for len(r) > 0 && r[len(r)-1] == "" {
				r = r[:len(r)-1]
			}
			return r
		}
	)
	for {
		tok, err := d.Token()
		if err != nil || rows >= 500 {
			return
		}
		switch t := tok.(type) {
		case xml.StartElement:
			switch t.Name.Local {
			case "row":
				row = row[:0]
			case "c":
				col, typ = -1, ""
				for _, a := range t.Attr {
					switch a.Name.Local {
					case "r":
						col = colIndex(a.Value)
					case "t":
						typ = a.Value
					}
				}
				val.Reset()
			case "v":
				inV = true
			case "t":
				inT = true
			}
		case xml.EndElement:
			switch t.Name.Local {
			case "v":
				inV = false
			case "t":
				inT = false
			case "c":
				s := val.String()
				if typ == "s" {
					if i, err := strconv.Atoi(strings.TrimSpace(s)); err == nil && i >= 0 && i < len(shared) {
						s = shared[i]
					}
				}
				if col < 0 {
					col = len(row)
				}
				for len(row) < col {
					row = append(row, "")
				}
				if col < 200 {
					row = append(row[:col], s)
				}
			case "row":
				if r := trimEnd(row); len(r) > 0 {
					out.WriteString(strings.Join(r, "\t") + "\n")
				}
				rows++
			}
		case xml.CharData:
			if inV || inT {
				val.Write(t)
			}
		}
	}
}

func pdf(ctx context.Context, data []byte) (string, error) {
	bin, err := exec.LookPath("pdftotext")
	if err != nil {
		return "", ErrNoPDF
	}
	f, err := os.CreateTemp("", "kuni-*.pdf")
	if err != nil {
		return "", err
	}
	defer os.Remove(f.Name())
	if _, err := f.Write(data); err != nil {
		f.Close()
		return "", err
	}
	f.Close()
	ctx, cancel := context.WithTimeout(ctx, 30*time.Second)
	defer cancel()
	var out, stderr bytes.Buffer
	cmd := exec.CommandContext(ctx, bin, "-layout", "-enc", "UTF-8", "-l", "60", f.Name(), "-")
	cmd.Stdout, cmd.Stderr = &limited{w: &out, n: 4 << 20}, &stderr
	if err := cmd.Run(); err != nil {
		return "", fmt.Errorf("pdftotext: %v %.200s", err, stderr.String())
	}
	s := clean(out.String())
	if strings.TrimSpace(s) == "" {
		return "", errors.New("the PDF has no text layer (it is probably a scan)")
	}
	return s, nil
}

type limited struct {
	w *bytes.Buffer
	n int
}

func (l *limited) Write(p []byte) (int, error) {
	if room := l.n - l.w.Len(); room > 0 {
		if len(p) > room {
			l.w.Write(p[:room])
		} else {
			l.w.Write(p)
		}
	}
	return len(p), nil
}

// clean collapses runs of blank lines and trailing spaces.
func clean(s string) string {
	lines := strings.Split(strings.ReplaceAll(s, "\r", ""), "\n")
	var b strings.Builder
	blank := 0
	for _, l := range lines {
		l = strings.TrimRight(l, " \t\f")
		if l == "" {
			blank++
			if blank > 1 {
				continue
			}
		} else {
			blank = 0
		}
		b.WriteString(l + "\n")
	}
	return strings.TrimSpace(b.String())
}
