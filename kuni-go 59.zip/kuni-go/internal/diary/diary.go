// Package diary is Kuni's long-term memory: markdown files with a JSON prologue
// (confidence + embedding), RAG-style retrieval by cosine similarity, and the
// "sleep" consolidation loop. Port of src/Diary.cpp.
//
// File format (same as the C++ version):
//
//	---
//	{"confidence":0.5,"embedding":[...]}
//	---
//	free-form body
//
// The files on disk stay the source of truth (they can be edited by hand), but they are not read again for every
// question: the diary keeps an index in memory and re-reads only the files whose size or time changed. Recalling a
// memory used to parse every file with its embedding (tens of kilobytes of JSON each) on every turn of every chat.
package diary

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"math/rand"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"kuni/internal/llm"
	"kuni/internal/store"
	"kuni/internal/util"
)

const ext = ".md"

type Metadata struct {
	Confidence float64   `json:"confidence"`
	Embedding  []float64 `json:"embedding,omitempty"`
}

type Entry struct {
	ID   string
	Meta Metadata
	Body string
}

// Related is an entry together with its relevance score for a query.
type Related struct {
	Entry     Entry
	Relevance float64
}

// inlineEmbeds is how many entries without a usable embedding a single query may embed on the spot. The rest are
// skipped and get their vectors from Reindex in the background: a changed embedding model must not turn the next
// message into hundreds of requests while the person waits.
const inlineEmbeds = 3

// rescanEvery is how often Load looks at the directory for files changed by someone else.
const rescanEvery = 10 * time.Second

type Diary struct {
	Dir              string
	LLM              *llm.Client
	ConfidenceFactor float64
	TokenTrigger     int
	// SleepPrompt returns the sleep_consolidator system prompt (hot-reloadable).
	SleepPrompt func() string
	rnd         *rand.Rand
	consMu      sync.Mutex   // one sleep consolidation at a time
	tuneMu      sync.RWMutex // guards ConfidenceFactor and TokenTrigger once the diary is in use (SetTuning)

	mu      sync.Mutex // the index and the id allocator
	index   map[string]*indexed
	scanned time.Time
	lastID  int64
}

// indexed is one file as last read.
type indexed struct {
	e    Entry
	size int64
	mod  time.Time
}

// SetTuning changes the ranking weight and the merge trigger while the diary is in use (config hot reload).
func (d *Diary) SetTuning(confidenceFactor float64, tokenTrigger int) {
	d.tuneMu.Lock()
	d.ConfidenceFactor, d.TokenTrigger = confidenceFactor, tokenTrigger
	d.tuneMu.Unlock()
}

func (d *Diary) tuning() (float64, int) {
	d.tuneMu.RLock()
	defer d.tuneMu.RUnlock()
	return d.ConfidenceFactor, d.TokenTrigger
}

func New(dir string, client *llm.Client, confidenceFactor float64, tokenTrigger int) (*Diary, error) {
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return nil, err
	}
	return &Diary{
		Dir:              dir,
		LLM:              client,
		ConfidenceFactor: confidenceFactor,
		TokenTrigger:     tokenTrigger,
		rnd:              rand.New(rand.NewSource(time.Now().UnixNano())),
		index:            map[string]*indexed{},
	}, nil
}

// Parse splits a raw file into metadata and body. Files without a valid
// prologue are returned as body-only entries, as in the C++ parser.
func Parse(id, text string) Entry {
	text = strings.Trim(text, "\n")
	e := Entry{ID: id, Body: text}
	if !strings.HasPrefix(text, "---") {
		return e
	}
	end := strings.Index(text[3:], "---")
	if end < 0 {
		return e
	}
	end += 3
	var meta Metadata
	if err := json.Unmarshal([]byte(strings.TrimSpace(text[3:end])), &meta); err != nil {
		log.Printf("diary: can't parse metadata of %s: %v", id, err)
		return e
	}
	e.Meta = meta
	e.Body = strings.TrimLeft(text[end+3:], "\n")
	return e
}

// Format is the inverse of Parse.
func Format(e Entry) (string, error) {
	js, err := json.Marshal(e.Meta)
	if err != nil {
		return "", err
	}
	return fmt.Sprintf("---\n%s\n---\n%s\n", js, e.Body), nil
}

// Load returns every entry, ordered by file name (as the directory lists them). The slice is the caller's; the
// embeddings inside are shared and must not be modified in place.
func (d *Diary) Load() ([]Entry, error) {
	d.mu.Lock()
	defer d.mu.Unlock()
	if err := d.refreshLocked(false); err != nil {
		return nil, err
	}
	ids := make([]string, 0, len(d.index))
	for id := range d.index {
		ids = append(ids, id)
	}
	sort.Strings(ids)
	out := make([]Entry, len(ids))
	for i, id := range ids {
		out[i] = d.index[id].e
	}
	return out, nil
}

// refreshLocked brings the index up to date with the directory: new and changed files are read, removed ones
// forgotten. Unless force, it runs at most every rescanEvery (her own writes keep the index current anyway).
func (d *Diary) refreshLocked(force bool) error {
	if !force && d.scanned.After(time.Now().Add(-rescanEvery)) {
		return nil
	}
	files, err := os.ReadDir(d.Dir)
	if err != nil {
		return err
	}
	seen := make(map[string]bool, len(files))
	for _, f := range files {
		if f.IsDir() || filepath.Ext(f.Name()) != ext || strings.HasPrefix(f.Name(), ".") {
			continue
		}
		id := strings.TrimSuffix(f.Name(), ext)
		seen[id] = true
		info, err := f.Info()
		if err != nil {
			continue // removed in the meantime
		}
		if c := d.index[id]; c != nil && c.size == info.Size() && c.mod.Equal(info.ModTime()) {
			continue
		}
		raw, err := os.ReadFile(filepath.Join(d.Dir, f.Name()))
		if err != nil {
			if os.IsNotExist(err) {
				continue
			}
			return err
		}
		d.index[id] = &indexed{e: Parse(id, string(raw)), size: info.Size(), mod: info.ModTime()}
	}
	for id := range d.index {
		if !seen[id] {
			delete(d.index, id)
		}
	}
	d.scanned = time.Now()
	return nil
}

// Save writes an entry to <dir>/<id>.md (and into the index).
func (d *Diary) Save(e Entry) error {
	s, err := Format(e)
	if err != nil {
		return err
	}
	path := filepath.Join(d.Dir, e.ID+ext)
	d.mu.Lock()
	defer d.mu.Unlock()
	if err := store.WriteFile(path, []byte(s), store.Private); err != nil {
		return err
	}
	c := &indexed{e: e}
	if info, err := os.Stat(path); err == nil {
		c.size, c.mod = info.Size(), info.ModTime()
	}
	d.index[e.ID] = c
	return nil
}

// update saves e only if its file still exists: an embedding computed for an entry that the sleep removed in the
// meantime must not bring it back.
func (d *Diary) update(e Entry) error {
	d.mu.Lock()
	_, ok := d.index[e.ID]
	d.mu.Unlock()
	if !ok {
		return nil
	}
	if _, err := os.Stat(filepath.Join(d.Dir, e.ID+ext)); os.IsNotExist(err) {
		return nil
	}
	return d.Save(e)
}

// Remove deletes an entry file if it exists.
func (d *Diary) Remove(id string) error {
	d.mu.Lock()
	defer d.mu.Unlock()
	delete(d.index, id)
	err := os.Remove(filepath.Join(d.Dir, id+ext))
	if os.IsNotExist(err) {
		return nil
	}
	return err
}

// NewID returns a fresh entry id: the unix time in seconds, moved forward when that id is taken. Every writer of
// the diary (session dumps, the sleep) takes its ids here, so two of them can never overwrite each other's page.
func (d *Diary) NewID() string {
	d.mu.Lock()
	defer d.mu.Unlock()
	_ = d.refreshLocked(false)
	id := max(time.Now().Unix(), d.lastID+1)
	for {
		s := strconv.FormatInt(id, 10)
		if _, taken := d.index[s]; !taken {
			if _, err := os.Stat(filepath.Join(d.Dir, s+ext)); os.IsNotExist(err) {
				d.lastID = id
				return s
			}
		}
		id++
	}
}

// Recall finds the n entries most related to text (the memories that "pop up" when she reads something).
func (d *Diary) Recall(ctx context.Context, text string, n int) ([]Related, error) {
	vec, err := d.LLM.Embedding(ctx, text)
	if err != nil {
		return nil, fmt.Errorf("embedding: %w", err)
	}
	entries, err := d.Load()
	if err != nil {
		return nil, err
	}
	return d.Query(ctx, entries, vec, n)
}

// Query returns the top-n entries most related to vec. A few entries without a usable embedding get one computed
// (and saved) on the fly; the others are left out until Reindex has done them.
func (d *Diary) Query(ctx context.Context, entries []Entry, vec []float64, n int) ([]Related, error) {
	cf, _ := d.tuning()
	var out []Related
	budget := inlineEmbeds
	for i := range entries {
		e := &entries[i]
		if e.Body == "" {
			continue
		}
		if len(e.Meta.Embedding) != len(vec) {
			if budget <= 0 {
				continue
			}
			budget--
			emb, err := d.LLM.Embedding(ctx, strings.ReplaceAll(e.Body, "\t", "  "))
			if err != nil {
				if ctx.Err() != nil {
					return nil, ctx.Err()
				}
				log.Printf("diary: embedding for %s: %v", e.ID, err)
				continue
			}
			e.Meta.Embedding = emb
			if err := d.update(*e); err != nil {
				log.Printf("diary: saving %s: %v", e.ID, err)
			}
		}
		cos, err := util.CosineSimilarity(vec, e.Meta.Embedding)
		if err != nil {
			continue
		}
		rel := (cos+1)/2 + e.Meta.Confidence*cf
		out = append(out, Related{Entry: *e, Relevance: rel})
	}
	sort.SliceStable(out, func(i, j int) bool { return out[i].Relevance > out[j].Relevance })
	if len(out) > n {
		out = out[:n]
	}
	return out, nil
}

// Reindex gives up to max entries the embedding of the current model (entries written by the sleep, or made before
// the embedding model changed). It returns how many it did.
func (d *Diary) Reindex(ctx context.Context, max int) (int, error) {
	probe, err := d.LLM.Embedding(ctx, "dimension probe") // cached: one request per process and model
	if err != nil {
		return 0, err
	}
	entries, err := d.Load()
	if err != nil {
		return 0, err
	}
	sort.SliceStable(entries, func(i, j int) bool { return idLess(entries[j].ID, entries[i].ID) }) // newest first
	n := 0
	for _, e := range entries {
		if n >= max || ctx.Err() != nil {
			break
		}
		if strings.TrimSpace(e.Body) == "" || len(e.Meta.Embedding) == len(probe) {
			continue
		}
		emb, err := d.LLM.Embedding(ctx, strings.ReplaceAll(e.Body, "\t", "  "))
		if err != nil {
			return n, err
		}
		e.Meta.Embedding = emb
		if err := d.update(e); err != nil {
			return n, err
		}
		n++
	}
	return n, ctx.Err()
}

// Consolidate runs one "sleep" cycle, bounded by maxTime. For each chosen chunk
// it finds related entries, asks the LLM to compress/merge them, writes the
// result back under fresh IDs (so they become "recent" again) and deletes the
// superseded low-confidence files.
func (d *Diary) Consolidate(ctx context.Context, maxTime time.Duration) error {
	_, trigger := d.tuning()
	if !d.consMu.TryLock() { // another sleep cycle is already running
		return nil
	}
	defer d.consMu.Unlock()
	deadline := time.Now().Add(maxTime)
	entries, err := d.Load()
	if err != nil {
		return err
	}
	sort.SliceStable(entries, func(i, j int) bool { return idLess(entries[j].ID, entries[i].ID) }) // recent first

	for len(entries) > 0 && time.Now().Before(deadline) && ctx.Err() == nil {
		// 80%: most recent; 20%: random old memory surfaces too.
		idx := 0
		if d.rnd.Float64() >= 0.8 {
			idx = d.rnd.Intn(len(entries))
		}
		target := entries[idx]
		entries = append(entries[:idx], entries[idx+1:]...)
		if target.Body == "" {
			continue
		}
		if len(target.Meta.Embedding) == 0 {
			emb, err := d.LLM.Embedding(ctx, target.Body)
			if err != nil {
				log.Printf("diary: sleep: embedding %s: %v", target.ID, err)
				continue
			}
			target.Meta.Embedding = emb
		}

		results, err := d.Query(ctx, entries, target.Meta.Embedding, 16)
		if err != nil {
			log.Printf("diary: sleep: query: %v", err)
			continue
		}

		// Build the prompt: target first, then related entries until the token trigger.
		var body strings.Builder
		ids := []string{target.ID}
		idsToRemove := []string{}
		// the target itself is superseded by the consolidated entries too (unless it is a pinned fact, confidence ~1).
		if target.Meta.Confidence < 0.9999999 {
			idsToRemove = append(idsToRemove, target.ID)
		}
		writeEntry := func(e Entry) {
			if body.Len() > 0 {
				body.WriteString("\n\n---\n\n")
			}
			meta, _ := json.Marshal(map[string]float64{"confidence": e.Meta.Confidence})
			body.Write(meta)
			body.WriteString(e.Body)
			body.WriteString("\n")
		}
		writeEntry(target)
		consumed := map[string]bool{target.ID: true}
		for i, r := range results {
			if body.Len() > trigger && i >= 2 {
				break
			}
			writeEntry(r.Entry)
			ids = append(ids, r.Entry.ID)
			consumed[r.Entry.ID] = true
			if r.Entry.Meta.Confidence < 0.9999999 {
				idsToRemove = append(idsToRemove, r.Entry.ID)
			}
		}
		entries = removeIDs(entries, consumed)
		log.Printf("diary: sleep: consolidating %v", ids)

		var answer string
		for attempt := 0; attempt < 3; attempt++ {
			answer, err = d.LLM.Chat(llm.WithPurpose(ctx, "sleep"), d.sleepPrompt(), []llm.Message{{Role: "user", Content: body.String()}})
			if err == nil {
				break
			}
			log.Printf("diary: sleep: chat attempt %d: %v", attempt+1, err)
		}
		if err != nil {
			continue
		}

		saved := 0
		for _, block := range strings.Split(answer, "\n---") {
			if len(strings.TrimSpace(block)) < 10 {
				continue
			}
			brace := strings.Index(block, "}")
			if brace < 0 {
				continue
			}
			var m struct {
				Confidence float64 `json:"confidence"`
			}
			if err := json.Unmarshal([]byte(block[:brace+1]), &m); err != nil {
				log.Printf("diary: sleep: can't parse block: %v", err)
				continue
			}
			if m.Confidence < -0.99999 {
				saved++ // dropped by the model on purpose: an answer, not a failure
				continue
			}
			newEntry := Entry{
				ID:   d.NewID(),
				Meta: Metadata{Confidence: clamp(m.Confidence, -0.99, 0.99)},
				Body: strings.Trim(block[brace+1:], "\n"),
			}
			// the new page is recalled right away, not only after the next reindex
			if emb, err := d.LLM.Embedding(ctx, strings.ReplaceAll(newEntry.Body, "\t", "  ")); err == nil {
				newEntry.Meta.Embedding = emb
			}
			if err := d.Save(newEntry); err != nil {
				return err
			}
			saved++
		}
		if saved == 0 {
			// the answer had no usable block: deleting the sources now would lose them
			log.Printf("diary: sleep: the answer for %v had nothing usable; keeping the entries", ids)
			continue
		}
		for _, id := range idsToRemove {
			if err := d.Remove(id); err != nil {
				return err
			}
		}
	}
	return ctx.Err()
}

// idLess compares diary IDs numerically when possible (unix timestamps), else lexically.
func idLess(a, b string) bool {
	ai, aerr := strconv.ParseInt(a, 10, 64)
	bi, berr := strconv.ParseInt(b, 10, 64)
	if aerr == nil && berr == nil {
		return ai < bi
	}
	return a < b
}

func removeIDs(entries []Entry, ids map[string]bool) []Entry {
	out := entries[:0]
	for _, e := range entries {
		if !ids[e.ID] {
			out = append(out, e)
		}
	}
	return out
}

func clamp(v, lo, hi float64) float64 {
	if v < lo {
		return lo
	}
	if v > hi {
		return hi
	}
	return v
}

func (d *Diary) sleepPrompt() string {
	if d.SleepPrompt != nil {
		if p := d.SleepPrompt(); p != "" {
			return p
		}
	}
	return `Merge, compress or rewrite the given diary entries into fewer, cleaner ones. Each entry starts with a JSON object {"confidence": x}; separate output entries with a line "---"; use confidence -1 to drop an entry.`
}
