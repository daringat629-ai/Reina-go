package diary

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"testing"
	"time"

	"kuni/internal/llm"
)

func TestParseFormatRoundTrip(t *testing.T) {
	in := Entry{ID: "1700000000", Meta: Metadata{Confidence: 0.5, Embedding: []float64{0.1, 0.2}}, Body: "Alex got a raise."}
	s, err := Format(in)
	if err != nil {
		t.Fatal(err)
	}
	out := Parse(in.ID, s)
	if out.Body != in.Body || out.Meta.Confidence != 0.5 || len(out.Meta.Embedding) != 2 {
		t.Fatalf("round trip mismatch: %+v", out)
	}
}

func TestParseWithoutPrologue(t *testing.T) {
	e := Parse("42", "just text\n")
	if e.Body != "just text" || e.Meta.Confidence != 0 {
		t.Fatalf("got %+v", e)
	}
}

func TestParseBrokenJSONKeepsBody(t *testing.T) {
	e := Parse("42", "---\n{not json}\n---\nbody")
	if !strings.Contains(e.Body, "not json") {
		t.Fatalf("broken prologue should fall back to whole text, got %q", e.Body)
	}
}

// fakeLLM serves /embeddings with a vector derived from the input length, and
// /chat/completions with a fixed consolidation answer.
func fakeLLM(t *testing.T, answer string) *httptest.Server {
	return httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		var req map[string]any
		_ = json.NewDecoder(r.Body).Decode(&req)
		switch {
		case strings.HasSuffix(r.URL.Path, "/embeddings"):
			input, _ := req["input"].(string)
			v := []float64{1, float64(len(input) % 3)}
			_ = json.NewEncoder(w).Encode(map[string]any{"data": []any{map[string]any{"embedding": v}}})
		case strings.HasSuffix(r.URL.Path, "/chat/completions"):
			_ = json.NewEncoder(w).Encode(map[string]any{"choices": []any{map[string]any{"message": map[string]any{"role": "assistant", "content": answer}}}})
		default:
			http.NotFound(w, r)
		}
	}))
}

func TestQueryRanksByCosine(t *testing.T) {
	srv := fakeLLM(t, "")
	defer srv.Close()
	dir := t.TempDir()
	c := llm.New(srv.URL+"/", srv.URL+"/", "", "m", "e", 5*time.Second)
	d, err := New(dir, c, 0, 1000)
	if err != nil {
		t.Fatal(err)
	}
	entries := []Entry{
		{ID: "1", Body: "aaaa", Meta: Metadata{Embedding: []float64{1, 0}}},
		{ID: "2", Body: "bb", Meta: Metadata{Embedding: []float64{0, 1}}},
	}
	got, err := d.Query(context.Background(), entries, []float64{1, 0}, 1)
	if err != nil {
		t.Fatal(err)
	}
	if len(got) != 1 || got[0].Entry.ID != "1" {
		t.Fatalf("expected entry 1 as best match, got %+v", got)
	}
}

func TestConsolidateReplacesLowConfidenceFiles(t *testing.T) {
	answer := `{"confidence": 0.7}
Merged memory about the raise.
---
{"confidence": -1}
trash that should be dropped`
	srv := fakeLLM(t, answer)
	defer srv.Close()
	dir := t.TempDir()
	c := llm.New(srv.URL+"/", srv.URL+"/", "", "m", "e", 5*time.Second)
	d, _ := New(dir, c, 0, 1000)

	mustSave := func(e Entry) {
		if err := d.Save(e); err != nil {
			t.Fatal(err)
		}
	}
	mustSave(Entry{ID: "1000", Body: "Alex got a raise and was happy."})
	mustSave(Entry{ID: "2000", Body: "Alex mentioned the raise again.", Meta: Metadata{Confidence: 0.9999999}})

	if err := d.Consolidate(context.Background(), 3*time.Second); err != nil {
		t.Fatal(err)
	}
	files, _ := filepath.Glob(filepath.Join(dir, "*.md"))
	var bodies []string
	for _, f := range files {
		raw, _ := os.ReadFile(f)
		bodies = append(bodies, Parse(strings.TrimSuffix(filepath.Base(f), ".md"), string(raw)).Body)
	}
	joined := strings.Join(bodies, "|")
	if !strings.Contains(joined, "Merged memory about the raise.") {
		t.Fatalf("consolidated entry missing: %v", bodies)
	}
	if strings.Contains(joined, "trash") {
		t.Fatalf("dropped block was saved: %v", bodies)
	}
	if _, err := os.Stat(filepath.Join(dir, "1000.md")); !os.IsNotExist(err) {
		t.Fatalf("low-confidence source entry should be removed (whether it was the target or a related entry)")
	}
	if _, err := os.Stat(filepath.Join(dir, "2000.md")); err != nil {
		t.Fatalf("entry with confidence=1 is a pinned fact and must never be deleted: %v", err)
	}
}

func newTestDiary(t *testing.T, answer string) (*Diary, *httptest.Server) {
	t.Helper()
	srv := fakeLLM(t, answer)
	t.Cleanup(srv.Close)
	c := llm.New(srv.URL+"/", srv.URL+"/", "", "m", "e", 5*time.Second)
	d, err := New(t.TempDir(), c, 0, 1000)
	if err != nil {
		t.Fatal(err)
	}
	return d, srv
}

func TestIndexSeesFilesChangedOnDisk(t *testing.T) {
	d, _ := newTestDiary(t, "")
	if err := d.Save(Entry{ID: "10", Body: "first"}); err != nil {
		t.Fatal(err)
	}
	es, _ := d.Load()
	if len(es) != 1 || es[0].Body != "first" {
		t.Fatalf("after save: %+v", es)
	}
	// someone edits the folder by hand: a new file, a changed one
	os.WriteFile(filepath.Join(d.Dir, "20.md"), []byte("written by hand"), 0o600)
	os.WriteFile(filepath.Join(d.Dir, "10.md"), []byte("first, corrected by hand"), 0o600)
	d.mu.Lock()
	d.scanned = time.Time{} // as if rescanEvery had passed
	d.mu.Unlock()
	es, _ = d.Load()
	if len(es) != 2 || es[0].Body != "first, corrected by hand" || es[1].Body != "written by hand" {
		t.Fatalf("external changes not seen: %+v", es)
	}
	os.Remove(filepath.Join(d.Dir, "20.md"))
	d.mu.Lock()
	d.scanned = time.Time{}
	d.mu.Unlock()
	if es, _ = d.Load(); len(es) != 1 {
		t.Fatalf("a removed file must leave the index: %+v", es)
	}
}

func TestNewIDNeverCollides(t *testing.T) {
	d, _ := newTestDiary(t, "")
	now := strconv.FormatInt(time.Now().Unix(), 10)
	d.Save(Entry{ID: now, Body: "taken"})
	seen := map[string]bool{now: true}
	for i := 0; i < 50; i++ {
		id := d.NewID()
		if seen[id] {
			t.Fatalf("id %s handed out twice", id)
		}
		seen[id] = true
		d.Save(Entry{ID: id, Body: "x"})
	}
}

func TestQueryEmbedsOnlyAFewMissingInline(t *testing.T) {
	d, _ := newTestDiary(t, "")
	var entries []Entry
	for i := 0; i < 10; i++ {
		e := Entry{ID: strconv.Itoa(100 + i), Body: "memory number " + strconv.Itoa(i)}
		d.Save(e)
		entries = append(entries, e)
	}
	got, err := d.Query(context.Background(), entries, []float64{1, 0}, 10)
	if err != nil {
		t.Fatal(err)
	}
	if len(got) != inlineEmbeds {
		t.Fatalf("%d entries embedded inline, want %d", len(got), inlineEmbeds)
	}
	n, err := d.Reindex(context.Background(), 100)
	if err != nil || n != 10-inlineEmbeds {
		t.Fatalf("reindex did %d (%v), want %d", n, err, 10-inlineEmbeds)
	}
	all, _ := d.Load()
	for _, e := range all {
		if len(e.Meta.Embedding) != 2 {
			t.Fatalf("entry %s still without embedding", e.ID)
		}
	}
	if n, _ := d.Reindex(context.Background(), 100); n != 0 {
		t.Fatalf("second reindex did %d", n)
	}
}

func TestRecall(t *testing.T) {
	d, _ := newTestDiary(t, "")
	d.Save(Entry{ID: "1", Body: "Alex likes tea", Meta: Metadata{Embedding: []float64{1, 0}}})
	got, err := d.Recall(context.Background(), "tea?", 3)
	if err != nil || len(got) != 1 || got[0].Entry.ID != "1" {
		t.Fatalf("recall: %+v %v", got, err)
	}
}

func TestConsolidateKeepsSourcesWhenTheAnswerIsUnusable(t *testing.T) {
	d, _ := newTestDiary(t, "I am sorry, I cannot do that.")
	d.Save(Entry{ID: "1000", Body: "Alex got a raise and was happy."})
	d.Save(Entry{ID: "2000", Body: "Alex mentioned the raise again."})
	if err := d.Consolidate(context.Background(), 2*time.Second); err != nil {
		t.Fatal(err)
	}
	for _, id := range []string{"1000", "2000"} {
		if _, err := os.Stat(filepath.Join(d.Dir, id+".md")); err != nil {
			t.Fatalf("entry %s was lost although nothing replaced it", id)
		}
	}
}

func TestConsolidatedEntriesAreEmbeddedAndPrivate(t *testing.T) {
	d, _ := newTestDiary(t, "{\"confidence\": 0.5}\nA merged and long enough memory.")
	d.Save(Entry{ID: "1000", Body: "something that happened"})
	if err := d.Consolidate(context.Background(), 2*time.Second); err != nil {
		t.Fatal(err)
	}
	es, _ := d.Load()
	if len(es) != 1 || len(es[0].Meta.Embedding) == 0 {
		t.Fatalf("the new page must come with its embedding: %+v", es)
	}
	st, _ := os.Stat(filepath.Join(d.Dir, es[0].ID+".md"))
	if st.Mode().Perm() != 0o600 {
		t.Fatalf("diary page mode %v", st.Mode().Perm())
	}
}
