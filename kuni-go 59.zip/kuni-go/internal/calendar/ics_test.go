package calendar

import (
	"context"
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"
)

const feed = "BEGIN:VCALENDAR\r\nVERSION:2.0\r\n" +
	"BEGIN:VEVENT\r\nUID:1\r\nDTSTART;TZID=Asia/Bishkek:20261021T150000\r\nDTEND;TZID=Asia/Bishkek:20261021T160000\r\nSUMMARY:Встреча с Анной\\, кофе\r\nLOCATION:Кафе «Лето»\r\nDESCRIPTION:Обсудить\r\n  проект\r\nEND:VEVENT\r\n" +
	"BEGIN:VEVENT\r\nUID:2\r\nDTSTART;TZID=Asia/Bishkek:20261019T100000\r\nDTEND;TZID=Asia/Bishkek:20261019T103000\r\nRRULE:FREQ=WEEKLY;BYDAY=MO,WE\r\nEXDATE;TZID=Asia/Bishkek:20261021T100000\r\nSUMMARY:Планёрка\r\nEND:VEVENT\r\n" +
	"BEGIN:VEVENT\r\nUID:3\r\nDTSTART;VALUE=DATE:20261023\r\nDTEND;VALUE=DATE:20261024\r\nSUMMARY:День рождения мамы\r\nEND:VEVENT\r\n" +
	"BEGIN:VEVENT\r\nUID:4\r\nDTSTART:20261022T060000Z\r\nDURATION:PT1H30M\r\nSUMMARY:Созвон (UTC)\r\nEND:VEVENT\r\n" +
	"BEGIN:VEVENT\r\nUID:5\r\nDTSTART:20261021T080000Z\r\nSUMMARY:Отменённое\r\nSTATUS:CANCELLED\r\nEND:VEVENT\r\n" +
	"BEGIN:VEVENT\r\nUID:6\r\nDTSTART;VALUE=DATE:20261001\r\nRRULE:FREQ=MONTHLY;COUNT=3\r\nSUMMARY:Платёж за аренду\r\nEND:VEVENT\r\n" +
	"BEGIN:VEVENT\r\nUID:7\r\nDTSTART;VALUE=DATE:20261020\r\nRRULE:FREQ=DAILY;INTERVAL=2;UNTIL=20261024\r\nSUMMARY:Таблетки\r\nEND:VEVENT\r\n" +
	"END:VCALENDAR\r\n"

func TestAgendaExpandsRecurringAndTimezones(t *testing.T) {
	loc, _ := time.LoadLocation("Asia/Bishkek")
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/bad" {
			fmt.Fprint(w, "<html>not a calendar</html>")
			return
		}
		fmt.Fprint(w, feed)
	}))
	defer srv.Close()
	from := time.Date(2026, 10, 19, 0, 0, 0, 0, loc)
	to := from.AddDate(0, 0, 7)
	evs, problems := Agenda(context.Background(), srv.Client(), []Feed{{"личный", srv.URL}, {"сломанный", srv.URL + "/bad"}, {"нет", "http://127.0.0.1:1/x"}}, from, to, loc)
	if len(problems) != 2 {
		t.Fatalf("a broken feed must be reported, not break the rest: %v", problems)
	}
	out := Format(evs, loc, true)
	for _, want := range []string{
		"Mon 19 Oct:", "10:00–10:30  Планёрка", // the weekly rule starts on Monday
		"Wed 21 Oct:", "15:00–16:00  Встреча с Анной, кофе @ Кафе «Лето» [личный] — Обсудить проект",
		"Thu 22 Oct:", "12:00–13:30  Созвон (UTC)", // 06:00 UTC is 12:00 in Bishkek (UTC+6), DURATION PT1H30M
		"Fri 23 Oct:", "весь день  День рождения мамы",
		"Таблетки",
	} {
		if !strings.Contains(out, want) {
			t.Errorf("missing %q in:\n%s", want, out)
		}
	}
	if strings.Contains(out, "Отменённое") {
		t.Fatal("cancelled events are hidden")
	}
	if strings.Count(out, "Планёрка") != 1 {
		t.Fatalf("EXDATE removes Wednesday's meeting, and the next Monday is outside the window:\n%s", out)
	}
	if strings.Count(out, "Таблетки") != 3 { // 20, 22, 24 (until is inclusive)
		t.Fatalf("every second day until the 24th:\n%s", out)
	}
	if strings.Contains(out, "Платёж за аренду") {
		t.Fatal("the monthly payment is on the 1st: not in this window")
	}
	// the monthly rule in its own window, COUNT=3 means Oct, Nov, Dec
	w := time.Date(2026, 10, 1, 0, 0, 0, 0, loc)
	m, _ := Agenda(context.Background(), srv.Client(), []Feed{{"x", srv.URL}}, w, w.AddDate(0, 4, 0), loc)
	n := 0
	for _, e := range m {
		if e.Title == "Платёж за аренду" {
			n++
		}
	}
	if n != 3 {
		t.Fatalf("COUNT=3 gives 3 payments, got %d", n)
	}
}

func TestParseFeedsAndUnfold(t *testing.T) {
	fs := ParseFeeds("работа|https://x/a.ics; https://y/b.ics ;; webcal://z/c.ics")
	if len(fs) != 3 || fs[0].Name != "работа" || fs[1].Name != "calendar" {
		t.Fatalf("%+v", fs)
	}
	if got := unfold("A:one\r\n  two\r\nB:3"); len(got) != 2 || got[0] != "A:one two" {
		t.Fatalf("%q", got)
	}
	if _, err := Parse("<html>", "x", time.UTC); err == nil {
		t.Fatal("not iCal")
	}
}
