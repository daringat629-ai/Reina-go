// Package calendar reads iCalendar feeds (the "secret address in iCal format" of Google Calendar, Nextcloud, Outlook...)
// and answers "what is on my schedule": recurring events are expanded for the window asked.
package calendar

import (
	"context"
	"fmt"
	"io"
	"net/http"
	"sort"
	"strconv"
	"strings"
	"time"
)

// Event is one occurrence.
type Event struct {
	Start, End time.Time
	AllDay     bool
	Title      string
	Location   string
	Notes      string
	Calendar   string
}

type rawEvent struct {
	props map[string][]prop
}

type prop struct {
	params map[string]string
	value  string
}

func (r rawEvent) first(name string) (prop, bool) {
	if p := r.props[name]; len(p) > 0 {
		return p[0], true
	}
	return prop{}, false
}

// unfold joins continuation lines and splits the feed into content lines.
func unfold(s string) []string {
	s = strings.ReplaceAll(strings.ReplaceAll(s, "\r\n", "\n"), "\r", "\n")
	var out []string
	for _, l := range strings.Split(s, "\n") {
		if (strings.HasPrefix(l, " ") || strings.HasPrefix(l, "\t")) && len(out) > 0 {
			out[len(out)-1] += l[1:]
			continue
		}
		out = append(out, l)
	}
	return out
}

func parseLine(l string) (name string, p prop, ok bool) {
	i := strings.Index(l, ":")
	if i < 0 {
		return
	}
	head, val := l[:i], l[i+1:]
	parts := strings.Split(head, ";")
	name = strings.ToUpper(parts[0])
	p = prop{params: map[string]string{}, value: val}
	for _, kv := range parts[1:] {
		if k, v, ok2 := strings.Cut(kv, "="); ok2 {
			p.params[strings.ToUpper(k)] = strings.Trim(v, `"`)
		}
	}
	return name, p, true
}

func unescape(s string) string {
	return strings.NewReplacer(`\n`, "\n", `\N`, "\n", `\,`, ",", `\;`, ";", `\\`, `\`).Replace(s)
}

func parseTime(p prop, def *time.Location) (t time.Time, allDay bool, err error) {
	v := strings.TrimSpace(p.value)
	if p.params["VALUE"] == "DATE" || len(v) == 8 {
		t, err = time.ParseInLocation("20060102", v, def)
		return t, true, err
	}
	if strings.HasSuffix(v, "Z") {
		t, err = time.Parse("20060102T150405Z", v)
		return t, false, err
	}
	loc := def
	if tz := p.params["TZID"]; tz != "" {
		if l, e := time.LoadLocation(tz); e == nil {
			loc = l
		}
	}
	t, err = time.ParseInLocation("20060102T150405", v, loc)
	return t, false, err
}

// Parse reads the events of one feed. loc is used for floating times and all-day dates.
func Parse(feed, name string, loc *time.Location) ([]rawEvent, error) {
	var evs []rawEvent
	var cur *rawEvent
	for _, l := range unfold(feed) {
		switch strings.ToUpper(strings.TrimSpace(l)) {
		case "BEGIN:VEVENT":
			cur = &rawEvent{props: map[string][]prop{}}
			continue
		case "END:VEVENT":
			if cur != nil {
				evs = append(evs, *cur)
			}
			cur = nil
			continue
		}
		if cur == nil {
			continue
		}
		if n, p, ok := parseLine(l); ok {
			cur.props[n] = append(cur.props[n], p)
		}
	}
	if len(evs) == 0 && !strings.Contains(strings.ToUpper(feed), "BEGIN:VCALENDAR") {
		return nil, fmt.Errorf("это не календарь iCal")
	}
	return evs, nil
}

// Expand returns the occurrences between from and to, sorted.
func Expand(raws []rawEvent, name string, from, to time.Time, loc *time.Location) []Event {
	var out []Event
	for _, r := range raws {
		sp, ok := r.first("DTSTART")
		if !ok {
			continue
		}
		start, allDay, err := parseTime(sp, loc)
		if err != nil {
			continue
		}
		dur := time.Hour
		if dp, ok := r.first("DURATION"); ok {
			if d := parseDuration(dp.value); d > 0 {
				dur = d
			}
		}
		if ep, ok := r.first("DTEND"); ok {
			if end, _, err := parseTime(ep, loc); err == nil && end.After(start) {
				dur = end.Sub(start)
			}
		} else if allDay {
			dur = 24 * time.Hour
		}
		if st, ok := r.first("STATUS"); ok && strings.EqualFold(st.value, "CANCELLED") {
			continue
		}
		ev := Event{AllDay: allDay, Calendar: name}
		if p, ok := r.first("SUMMARY"); ok {
			ev.Title = unescape(p.value)
		}
		if p, ok := r.first("LOCATION"); ok {
			ev.Location = unescape(p.value)
		}
		if p, ok := r.first("DESCRIPTION"); ok {
			ev.Notes = unescape(p.value)
		}
		skip := map[int64]bool{}
		for _, ex := range r.props["EXDATE"] {
			for _, v := range strings.Split(ex.value, ",") {
				if t, _, err := parseTime(prop{params: ex.params, value: v}, loc); err == nil {
					skip[t.Unix()] = true
				}
			}
		}
		add := func(s time.Time) {
			if skip[s.Unix()] {
				return
			}
			e := ev
			e.Start, e.End = s, s.Add(dur)
			if e.End.After(from) && e.Start.Before(to) {
				out = append(out, e)
			}
		}
		rule, hasRule := r.first("RRULE")
		if !hasRule {
			add(start)
			continue
		}
		for _, s := range occurrences(rule.value, start, to, loc) {
			add(s)
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Start.Before(out[j].Start) })
	return out
}

var weekdays = map[string]time.Weekday{"SU": time.Sunday, "MO": time.Monday, "TU": time.Tuesday, "WE": time.Wednesday, "TH": time.Thursday, "FR": time.Friday, "SA": time.Saturday}

// occurrences expands the common RRULE forms (DAILY, WEEKLY with BYDAY, MONTHLY, YEARLY; INTERVAL, COUNT, UNTIL).
func occurrences(rule string, start, limit time.Time, loc *time.Location) []time.Time {
	kv := map[string]string{}
	for _, part := range strings.Split(rule, ";") {
		if k, v, ok := strings.Cut(part, "="); ok {
			kv[strings.ToUpper(k)] = v
		}
	}
	interval := 1
	if n, err := strconv.Atoi(kv["INTERVAL"]); err == nil && n > 0 {
		interval = n
	}
	count := 0
	if n, err := strconv.Atoi(kv["COUNT"]); err == nil {
		count = n
	}
	until := limit
	if u := kv["UNTIL"]; u != "" {
		if t, _, err := parseTime(prop{params: map[string]string{}, value: u}, loc); err == nil && t.Before(until) {
			until = t.Add(24 * time.Hour)
		}
	}
	var days []time.Weekday
	for _, d := range strings.Split(kv["BYDAY"], ",") {
		d = strings.TrimLeft(strings.TrimSpace(d), "+-0123456789")
		if w, ok := weekdays[d]; ok {
			days = append(days, w)
		}
	}
	var out []time.Time
	emit := func(t time.Time) bool { // false = stop
		if t.After(until) || (count > 0 && len(out) >= count) {
			return false
		}
		if !t.Before(start) {
			out = append(out, t)
		}
		return true
	}
	switch kv["FREQ"] {
	case "DAILY":
		for t := start; ; t = t.AddDate(0, 0, interval) {
			if !emit(t) {
				break
			}
		}
	case "WEEKLY":
		if len(days) == 0 {
			days = []time.Weekday{start.Weekday()}
		}
		weekStart := start.AddDate(0, 0, -int((start.Weekday()+6)%7)) // Monday of the first week
	weeks:
		for w := weekStart; !w.After(until); w = w.AddDate(0, 0, 7*interval) {
			for _, wd := range days {
				t := w.AddDate(0, 0, int((wd+6)%7))
				if t.Before(start) {
					continue
				}
				if !emit(t) {
					break weeks
				}
			}
		}
	case "MONTHLY":
		for i := 0; ; i += interval {
			t := start.AddDate(0, i, 0)
			if t.Day() != start.Day() { // 31st in a short month: skipped, as in the standard
				continue
			}
			if !emit(t) {
				break
			}
			if i > 12*60 {
				break
			}
		}
	case "YEARLY":
		for i := 0; ; i += interval {
			if !emit(start.AddDate(i, 0, 0)) || i > 60 {
				break
			}
		}
	default:
		emit(start)
	}
	return out
}

// Feed is one calendar address.
type Feed struct{ Name, URL string }

// ParseFeeds reads "name|url; name2|url2" (a bare url gets the name "calendar").
func ParseFeeds(s string) []Feed {
	var out []Feed
	for _, part := range strings.FieldsFunc(s, func(r rune) bool { return r == ';' || r == '\n' }) {
		part = strings.TrimSpace(part)
		if part == "" {
			continue
		}
		if n, u, ok := strings.Cut(part, "|"); ok {
			out = append(out, Feed{Name: strings.TrimSpace(n), URL: strings.TrimSpace(u)})
		} else {
			out = append(out, Feed{Name: "calendar", URL: part})
		}
	}
	return out
}

// Agenda downloads the feeds and lists the occurrences between from and to.
func Agenda(ctx context.Context, client *http.Client, feeds []Feed, from, to time.Time, loc *time.Location) ([]Event, []string) {
	var all []Event
	var problems []string
	for _, f := range feeds {
		u := strings.Replace(f.URL, "webcal://", "https://", 1)
		req, err := http.NewRequestWithContext(ctx, http.MethodGet, u, nil)
		if err != nil {
			problems = append(problems, f.Name+": "+err.Error())
			continue
		}
		resp, err := client.Do(req)
		if err != nil {
			problems = append(problems, f.Name+": "+strings.ReplaceAll(err.Error(), f.URL, "(address)"))
			continue
		}
		body, _ := io.ReadAll(io.LimitReader(resp.Body, 20<<20))
		resp.Body.Close()
		if resp.StatusCode/100 != 2 {
			problems = append(problems, fmt.Sprintf("%s: HTTP %d", f.Name, resp.StatusCode))
			continue
		}
		raws, err := Parse(string(body), f.Name, loc)
		if err != nil {
			problems = append(problems, f.Name+": "+err.Error())
			continue
		}
		all = append(all, Expand(raws, f.Name, from, to, loc)...)
	}
	sort.Slice(all, func(i, j int) bool { return all[i].Start.Before(all[j].Start) })
	return all, problems
}

// Format renders events as lines for the model.
func Format(evs []Event, loc *time.Location, multi bool) string {
	var b strings.Builder
	day := ""
	for _, e := range evs {
		s := e.Start.In(loc)
		if d := s.Format("Mon 2 Jan"); d != day {
			day = d
			fmt.Fprintf(&b, "%s:\n", d)
		}
		when := s.Format("15:04") + "–" + e.End.In(loc).Format("15:04")
		if e.AllDay {
			when = "весь день"
		}
		fmt.Fprintf(&b, "  %s  %s", when, e.Title)
		if e.Location != "" {
			b.WriteString(" @ " + e.Location)
		}
		if multi && e.Calendar != "" {
			b.WriteString(" [" + e.Calendar + "]")
		}
		if n := strings.Join(strings.Fields(e.Notes), " "); n != "" {
			if r := []rune(n); len(r) > 120 {
				n = string(r[:120]) + "…"
			}
			b.WriteString(" — " + n)
		}
		b.WriteString("\n")
	}
	return b.String()
}

// parseDuration reads ISO 8601 durations like PT1H30M, P1D, P1W.
func parseDuration(v string) time.Duration {
	v = strings.ToUpper(strings.TrimSpace(v))
	if !strings.HasPrefix(v, "P") {
		return 0
	}
	var total time.Duration
	inTime := false
	num := ""
	for _, r := range v[1:] {
		switch {
		case r == 'T':
			inTime = true
		case r >= '0' && r <= '9':
			num += string(r)
		default:
			n, _ := strconv.Atoi(num)
			num = ""
			switch {
			case r == 'W':
				total += time.Duration(n) * 7 * 24 * time.Hour
			case r == 'D':
				total += time.Duration(n) * 24 * time.Hour
			case r == 'H' && inTime:
				total += time.Duration(n) * time.Hour
			case r == 'M' && inTime:
				total += time.Duration(n) * time.Minute
			case r == 'S' && inTime:
				total += time.Duration(n) * time.Second
			}
		}
	}
	return total
}
