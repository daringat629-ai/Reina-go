package calendar

import (
	"strings"
	"testing"
	"time"
)

func TestInviteRoundTrip(t *testing.T) {
	loc, _ := time.LoadLocation("Asia/Bishkek")
	start := time.Date(2026, 10, 25, 18, 30, 0, 0, loc)
	ics, err := Invite{Title: "Ужин с Аней; столик, у окна", Start: start, Location: "Бишкек, ул. Киевская 1", Description: "взять подарок\nи цветы " + strings.Repeat("очень длинное описание ", 10), AlarmMins: 30, Repeat: "weekly", Count: 3}.ICS(time.Now())
	if err != nil {
		t.Fatal(err)
	}
	for _, l := range strings.Split(ics, "\r\n") {
		if len(l) > 75 {
			t.Fatalf("line longer than 75 bytes: %q", l)
		}
	}
	for _, want := range []string{"DTSTART:20261025T123000Z", "DTEND:20261025T133000Z", `SUMMARY:Ужин с Аней\; столик\, у окна`, "TRIGGER:-PT30M", "RRULE:FREQ=WEEKLY;COUNT=3", "METHOD:PUBLISH"} {
		if !strings.Contains(strings.ReplaceAll(ics, "\r\n ", ""), want) {
			t.Errorf("no %s in\n%s", want, ics)
		}
	}
	raws, err := Parse(ics, "test", loc)
	if err != nil || len(raws) != 1 {
		t.Fatalf("own parser: %v %d", err, len(raws))
	}
	evs := Expand(raws, "test", start.Add(-time.Hour), start.AddDate(0, 0, 30), loc)
	if len(evs) != 3 || !evs[0].Start.Equal(start) || evs[0].Title != "Ужин с Аней; столик, у окна" || !strings.Contains(evs[0].Location, "Киевская") {
		t.Fatalf("events: %+v", evs)
	}
}

func TestInviteAllDayAndErrors(t *testing.T) {
	ics, err := Invite{Title: "ДР мамы", Start: time.Date(2026, 3, 12, 15, 0, 0, 0, time.UTC), AllDay: true, AlarmMins: -1}.ICS(time.Now())
	if err != nil || !strings.Contains(ics, "DTSTART;VALUE=DATE:20260312") || !strings.Contains(ics, "DTEND;VALUE=DATE:20260313") || strings.Contains(ics, "VALARM") {
		t.Fatalf("%v\n%s", err, ics)
	}
	if _, err := (Invite{Title: "x", Start: time.Now(), End: time.Now().Add(-time.Hour)}).ICS(time.Now()); err == nil {
		t.Fatal("end before start")
	}
	if _, err := (Invite{Title: "x", Start: time.Now(), Repeat: "hourly"}).ICS(time.Now()); err == nil {
		t.Fatal("bad repeat")
	}
}
