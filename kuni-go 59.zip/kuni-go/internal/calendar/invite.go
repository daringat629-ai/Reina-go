package calendar

import (
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"strings"
	"time"
	"unicode/utf8"
)

// Invite is an event to hand over as an .ics file: opened on a phone or a computer, it goes into whatever calendar
// the person uses (Google, Apple, Outlook...), with its reminder.
type Invite struct {
	Title       string
	Start       time.Time
	End         time.Time // zero = Start + 1 hour (+1 day for an all-day event)
	AllDay      bool
	Location    string
	Description string
	URL         string
	AlarmMins   int    // reminder before the start, minutes; <0 = none
	Repeat      string // "", daily, weekly, monthly, yearly
	Count       int    // repetitions (0 = without end)
}

// ICS renders the event. Times are written in UTC, which every calendar understands without time zone tables.
func (in Invite) ICS(now time.Time) (string, error) {
	if strings.TrimSpace(in.Title) == "" {
		return "", fmt.Errorf("the event needs a title")
	}
	if in.Start.IsZero() {
		return "", fmt.Errorf("the event needs a start")
	}
	end := in.End
	if in.AllDay {
		s := time.Date(in.Start.Year(), in.Start.Month(), in.Start.Day(), 0, 0, 0, 0, time.UTC)
		in.Start = s
		if end.IsZero() || !end.After(s) {
			end = s.AddDate(0, 0, 1)
		} else {
			end = time.Date(end.Year(), end.Month(), end.Day(), 0, 0, 0, 0, time.UTC).AddDate(0, 0, 1)
		}
	} else if end.IsZero() {
		end = in.Start.Add(time.Hour)
	}
	if !end.After(in.Start) {
		return "", fmt.Errorf("the end must be after the start")
	}
	uid := make([]byte, 12)
	_, _ = rand.Read(uid)
	var b strings.Builder
	line := func(s string) { b.WriteString(fold(s) + "\r\n") }
	utc := func(t time.Time) string { return t.UTC().Format("20060102T150405Z") }
	line("BEGIN:VCALENDAR")
	line("VERSION:2.0")
	line("PRODID:-//kuni-go//Kuni//RU")
	line("CALSCALE:GREGORIAN")
	line("METHOD:PUBLISH")
	line("BEGIN:VEVENT")
	line("UID:" + hex.EncodeToString(uid) + "@kuni")
	line("DTSTAMP:" + utc(now))
	if in.AllDay {
		line("DTSTART;VALUE=DATE:" + in.Start.Format("20060102"))
		line("DTEND;VALUE=DATE:" + end.Format("20060102"))
	} else {
		line("DTSTART:" + utc(in.Start))
		line("DTEND:" + utc(end))
	}
	line("SUMMARY:" + text(in.Title))
	if in.Location != "" {
		line("LOCATION:" + text(in.Location))
	}
	if in.Description != "" {
		line("DESCRIPTION:" + text(in.Description))
	}
	if in.URL != "" {
		line("URL:" + strings.TrimSpace(in.URL))
	}
	if r := strings.ToUpper(strings.TrimSpace(in.Repeat)); r != "" {
		switch r {
		case "DAILY", "WEEKLY", "MONTHLY", "YEARLY":
		default:
			return "", fmt.Errorf("repeat is daily, weekly, monthly or yearly")
		}
		rule := "RRULE:FREQ=" + r
		if in.Count > 0 {
			rule += fmt.Sprintf(";COUNT=%d", in.Count)
		}
		line(rule)
	}
	if in.AlarmMins >= 0 {
		line("BEGIN:VALARM")
		line("ACTION:DISPLAY")
		line("DESCRIPTION:" + text(in.Title))
		line(fmt.Sprintf("TRIGGER:-PT%dM", in.AlarmMins))
		line("END:VALARM")
	}
	line("END:VEVENT")
	line("END:VCALENDAR")
	return b.String(), nil
}

// text escapes a value of an iCalendar text property.
func text(s string) string {
	return strings.NewReplacer(`\`, `\\`, ";", `\;`, ",", `\,`, "\r\n", `\n`, "\n", `\n`, "\r", `\n`).Replace(s)
}

// fold splits a line into pieces of at most 75 bytes (never inside a character), as the format asks.
func fold(s string) string {
	if len(s) <= 75 {
		return s
	}
	var b strings.Builder
	n := 0
	limit := 75
	for _, r := range s {
		size := utf8.RuneLen(r)
		if n+size > limit {
			b.WriteString("\r\n ")
			n = 0
			limit = 74 // the leading space counts
		}
		b.WriteRune(r)
		n += size
	}
	return b.String()
}
