package work

import (
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestQueueLifecycle(t *testing.T) {
	p := filepath.Join(t.TempDir(), "w.json")
	s := New(p)
	if _, err := s.Add(" ", "x", 0); err == nil {
		t.Fatal("empty title accepted")
	}
	a, _ := s.Add("Перевод статьи", "на Kwork, 3000 знаков", 2)
	b, _ := s.Add("Парсинг цен", "", 0)
	now := time.Now()

	got, ok := s.Take(now, 10)
	if !ok || got.ID != a.ID || got.Runs != 1 || got.Status != Running {
		t.Fatalf("first take: %+v", got)
	}
	// a running task is continued before a new one is started
	if got, _ = s.Take(now, 10); got.ID != a.ID || got.Runs != 2 {
		t.Fatalf("second take: %+v", got)
	}
	// out of runs: parked with a question, the next task is taken
	got, ok = s.Take(now, 10)
	if !ok || got.ID != b.ID {
		t.Fatalf("third take: %+v", got)
	}
	ta, _ := s.Get(a.ID)
	if ta.Status != Blocked || ta.Question == "" {
		t.Fatalf("expected parked: %+v", ta)
	}
	if err := s.Answer(a.ID, "продолжай"); err != nil {
		t.Fatal(err)
	}
	ta, _ = s.Get(a.ID)
	if ta.Status != Queued || ta.MaxRuns != 5 || !strings.Contains(ta.Notes[0].Text, "продолжай") {
		t.Fatalf("answer: %+v", ta)
	}
	if err := s.Finish(a.ID, "готово, 1200 ₽"); err != nil {
		t.Fatal(err)
	}
	if err := s.Cancel(a.ID); err == nil {
		t.Fatal("a done task cannot be cancelled")
	}
	if err := s.Block(b.ID, ""); err == nil {
		t.Fatal("block without a question")
	}
	if err := s.Block(b.ID, "Заказчик просит предоплату. Согласен?"); err != nil {
		t.Fatal(err)
	}
	if _, ok := s.Take(now, 10); ok {
		t.Fatal("a blocked task must not run")
	}

	// restart keeps everything
	s2 := New(p)
	if tb, ok := s2.Get(b.ID); !ok || tb.Status != Blocked {
		t.Fatalf("not persisted: %+v", tb)
	}
	if s2.RunsToday(now) != 3 {
		t.Fatalf("runs today: %d", s2.RunsToday(now))
	}
	if c, _ := s2.Add("ещё", "", 0); c.ID != 3 {
		t.Fatalf("ids must continue: %d", c.ID)
	}
}

func TestDailyLimitAndNewDay(t *testing.T) {
	s := New("")
	s.Add("a", "", 100)
	now := time.Date(2026, 10, 20, 12, 0, 0, 0, time.UTC)
	for i := 0; i < 3; i++ {
		if _, ok := s.Take(now, 3); !ok {
			t.Fatal("run", i)
		}
	}
	if _, ok := s.Take(now, 3); ok {
		t.Fatal("the daily limit must stop the fourth run")
	}
	if _, ok := s.Take(now.Add(24*time.Hour), 3); !ok {
		t.Fatal("a new day starts again")
	}
}
