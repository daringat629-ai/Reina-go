// Package run keeps the long-lived loops of the program alive: every loop has a name, a panic in it is logged with
// its stack and the loop starts again after a pause, and shutdown waits for all of them.
package run

import (
	"context"
	"log"
	"runtime/debug"
	"sync"
	"time"
)

// Supervisor runs long-lived loops (the Telegram client, the agent and its own loops, the HTTP server, the
// housekeeping) and waits for all of them on shutdown.
//
// A background loop used to be a bare goroutine: one panic in, say, the daily report took the whole process down,
// and a loop that died quietly (a returned error nobody looked at) simply stopped working until the next restart.
// Here every loop has a name; a panic is logged with its stack and the loop is started again after a pause that
// grows with each crash (1 s .. 1 min), so a bug costs one round of that loop, not her whole life.
type Supervisor struct {
	wg sync.WaitGroup
	// Backoff is the first pause after a crash (doubled each time, capped at a minute). Tests shorten it.
	Backoff time.Duration
	// OnCrash, if set, is told about every crash (metrics).
	OnCrash func(name string)
}

// Go runs f until ctx ends. f is expected to block until ctx is done; if it returns on its own, it is not restarted
// (a loop with nothing to do may just return). If it panics, it is restarted after a pause.
func (s *Supervisor) Go(ctx context.Context, name string, f func(ctx context.Context)) {
	s.wg.Add(1)
	go func() {
		defer s.wg.Done()
		pause := s.Backoff
		if pause <= 0 {
			pause = time.Second
		}
		for ctx.Err() == nil {
			if !s.runOnce(ctx, name, f) {
				return // returned normally
			}
			log.Printf("app: %s crashed; starting it again in %s", name, pause)
			if s.OnCrash != nil {
				s.OnCrash(name)
			}
			select {
			case <-ctx.Done():
				return
			case <-time.After(pause):
			}
			pause = min(pause*2, time.Minute)
		}
	}()
}

// runOnce calls f and reports whether it panicked.
func (s *Supervisor) runOnce(ctx context.Context, name string, f func(context.Context)) (crashed bool) {
	defer func() {
		if r := recover(); r != nil {
			log.Printf("app: PANIC in %s: %v\n%s", name, r, debug.Stack())
			crashed = true
		}
	}()
	f(ctx)
	return false
}

// Wait blocks until every loop has returned.
func (s *Supervisor) Wait() { s.wg.Wait() }
