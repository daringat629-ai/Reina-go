package run

import (
	"context"
	"sync/atomic"
	"testing"
	"time"
)

func TestSupervisorRestartsACrashedLoop(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	sup := &Supervisor{Backoff: 10 * time.Millisecond}
	var crashes atomic.Int32
	sup.OnCrash = func(string) { crashes.Add(1) }
	var runs atomic.Int32
	sup.Go(ctx, "flaky", func(ctx context.Context) {
		if runs.Add(1) <= 2 {
			panic("boom")
		}
		<-ctx.Done()
	})
	deadline := time.Now().Add(3 * time.Second)
	for runs.Load() < 3 && time.Now().Before(deadline) {
		time.Sleep(5 * time.Millisecond)
	}
	if runs.Load() != 3 || crashes.Load() != 2 {
		t.Fatalf("runs=%d crashes=%d", runs.Load(), crashes.Load())
	}
	cancel()
	sup.Wait()
}

func TestSupervisorDoesNotRestartALoopThatReturned(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	sup := &Supervisor{Backoff: time.Millisecond}
	var runs atomic.Int32
	sup.Go(ctx, "idle", func(context.Context) { runs.Add(1) })
	sup.Wait()
	if runs.Load() != 1 {
		t.Fatalf("runs=%d", runs.Load())
	}
}
