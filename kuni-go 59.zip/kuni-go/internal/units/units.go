// Package units converts measures exactly: length, mass, volume, area, speed, temperature, data, time, energy,
// pressure, power and fuel use, with Russian and English names. Models get "how many miles in 42 km" roughly right
// and "°F to °C" wrong surprisingly often; a table does not.
package units

import (
	"fmt"
	"math"
	"strings"
)

type unit struct {
	dim    string
	factor float64 // to the base unit of the dimension
	offset float64 // temperature: base = value*factor + offset
	name   string  // how it is written in answers
}

var table = map[string]unit{}

func add(dim string, factor float64, name string, aliases ...string) {
	u := unit{dim: dim, factor: factor, name: name}
	for _, a := range append(aliases, name) {
		table[strings.ToLower(a)] = u
	}
}

func init() {
	// length, base metre
	add("length", 1e-3, "mm", "миллиметр", "миллиметров", "миллиметра", "мм", "millimeter", "millimeters")
	add("length", 1e-2, "cm", "сантиметр", "сантиметров", "сантиметра", "см", "centimeter", "centimeters")
	add("length", 0.1, "dm", "дециметр", "дм")
	add("length", 1, "m", "метр", "метров", "метра", "м", "meter", "meters", "metre")
	add("length", 1000, "km", "километр", "километров", "километра", "км", "kilometer", "kilometers")
	add("length", 0.0254, "in", "дюйм", "дюймов", "дюйма", "inch", "inches", "\"")
	add("length", 0.3048, "ft", "фут", "футов", "фута", "foot", "feet", "'")
	add("length", 0.9144, "yd", "ярд", "ярдов", "ярда", "yard", "yards")
	add("length", 1609.344, "mi", "миля", "миль", "мили", "mile", "miles")
	add("length", 1852, "nmi", "морская миля", "морских миль", "nautical mile", "nm")
	add("length", 1e-6, "µm", "микрон", "микрометр", "um", "micron")
	add("length", 9.4607304725808e15, "ly", "световой год", "световых лет", "light year")
	// mass, base kilogram
	add("mass", 1e-6, "mg", "миллиграмм", "мг", "milligram")
	add("mass", 1e-3, "g", "грамм", "граммов", "грамма", "г", "гр", "gram", "grams")
	add("mass", 1, "kg", "килограмм", "килограммов", "килограмма", "кг", "kilo", "kilogram", "kilograms")
	add("mass", 1000, "t", "тонна", "тонн", "тонны", "т", "tonne", "ton")
	add("mass", 100, "ц", "центнер", "центнеров")
	add("mass", 0.028349523125, "oz", "унция", "унций", "унции", "ounce", "ounces")
	add("mass", 0.45359237, "lb", "фунт", "фунтов", "фунта", "pound", "pounds", "lbs")
	add("mass", 6.35029318, "st", "стоун", "stone")
	add("mass", 0.0002, "ct", "карат", "каратов", "carat")
	// volume, base litre
	add("volume", 1e-3, "ml", "миллилитр", "миллилитров", "мл", "milliliter")
	add("volume", 1, "l", "литр", "литров", "литра", "л", "liter", "liters", "litre")
	add("volume", 1000, "m3", "кубометр", "кубометров", "м3", "м³", "куб", "кубов", "cubic meter")
	add("volume", 0.00492892159375, "tsp", "чайная ложка", "чайных ложек", "ч.л.", "teaspoon")
	add("volume", 0.01478676478125, "tbsp", "столовая ложка", "столовых ложек", "ст.л.", "tablespoon")
	add("volume", 0.2365882365, "cup", "чашка", "чашек", "cups", "us cup")
	add("volume", 0.0295735295625, "fl oz", "жидкая унция", "floz", "fluid ounce")
	add("volume", 0.473176473, "pt", "пинта", "пинт", "pint", "us pint")
	add("volume", 0.56826125, "uk pint", "британская пинта")
	add("volume", 0.946352946, "qt", "кварта", "quart")
	add("volume", 3.785411784, "gal", "галлон", "галлонов", "gallon", "us gallon")
	add("volume", 4.54609, "uk gal", "британский галлон", "imperial gallon")
	add("volume", 158.987294928, "bbl", "баррель", "баррелей", "barrel")
	add("volume", 0.25, "стакан", "стаканов", "стакана")
	// area, base square metre
	add("area", 1e-4, "cm2", "см2", "см²", "кв см", "square centimeter")
	add("area", 1, "m2", "м2", "м²", "кв м", "кв.м", "квадратный метр", "квадратных метров", "square meter", "sqm")
	add("area", 100, "сотка", "соток", "сотки", "ар", "are")
	add("area", 1e4, "ha", "гектар", "гектаров", "га", "hectare")
	add("area", 1e6, "km2", "км2", "км²", "кв км", "square kilometer")
	add("area", 0.09290304, "ft2", "кв фут", "square foot", "sq ft", "sqft")
	add("area", 0.00064516, "in2", "кв дюйм", "square inch")
	add("area", 4046.8564224, "acre", "акр", "акров", "acres")
	add("area", 2589988.110336, "mi2", "кв миля", "square mile")
	// speed, base m/s
	add("speed", 1, "m/s", "м/с", "метров в секунду")
	add("speed", 1/3.6, "km/h", "км/ч", "кмч", "kmh", "kph", "километров в час")
	add("speed", 0.44704, "mph", "миль в час", "mi/h")
	add("speed", 0.514444444444, "kn", "узел", "узлов", "knot", "knots", "kt")
	add("speed", 0.3048, "ft/s", "футов в секунду", "fps")
	add("speed", 340.29, "mach", "мах", "маха")
	// data, base byte (decimal and binary prefixes)
	add("data", 0.125, "bit", "бит", "битов", "bits")
	add("data", 1, "B", "байт", "байтов", "byte", "bytes")
	add("data", 1e3, "KB", "кб", "килобайт", "kilobyte")
	add("data", 1e6, "MB", "мб", "мегабайт", "megabyte")
	add("data", 1e9, "GB", "гб", "гигабайт", "gigabyte")
	add("data", 1e12, "TB", "тб", "терабайт", "terabyte")
	add("data", 1024, "KiB", "кибибайт")
	add("data", 1048576, "MiB", "мебибайт")
	add("data", 1073741824, "GiB", "гибибайт")
	add("data", 1099511627776, "TiB", "тебибайт")
	add("data", 125, "kbit", "кбит", "kilobit")
	add("data", 125000, "Mbit", "мбит", "megabit", "mbps", "мбит/с")
	add("data", 125000000, "Gbit", "гбит", "gigabit", "gbps")
	// time, base second
	add("time", 1e-3, "ms", "мс", "миллисекунда", "миллисекунд", "millisecond")
	add("time", 1, "s", "сек", "секунда", "секунд", "секунды", "с.", "sec", "second", "seconds")
	add("time", 60, "min", "мин", "минута", "минут", "минуты", "minute", "minutes")
	add("time", 3600, "h", "ч", "час", "часов", "часа", "hour", "hours", "hr")
	add("time", 86400, "day", "сутки", "суток", "день", "дней", "дня", "days", "d")
	add("time", 604800, "week", "неделя", "недель", "недели", "weeks", "wk")
	add("time", 2629746, "month", "месяц", "месяцев", "месяца", "months")
	add("time", 31556952, "year", "год", "лет", "года", "years", "yr")
	// energy, base joule
	add("energy", 1, "J", "дж", "джоуль", "джоулей", "joule")
	add("energy", 1000, "kJ", "кдж", "килоджоуль", "kilojoule")
	add("energy", 4.184, "cal", "кал", "калория", "калорий", "calorie")
	add("energy", 4184, "kcal", "ккал", "килокалория", "килокалорий", "kilocalorie")
	add("energy", 3600, "Wh", "вт·ч", "втч", "ватт-час")
	add("energy", 3.6e6, "kWh", "квт·ч", "квтч", "киловатт-час", "киловатт-часов")
	add("energy", 1055.05585262, "BTU", "бте")
	add("energy", 1.602176634e-19, "eV", "эв", "электронвольт")
	// pressure, base pascal
	add("pressure", 1, "Pa", "па", "паскаль", "паскалей", "pascal")
	add("pressure", 1000, "kPa", "кпа", "килопаскаль")
	add("pressure", 1e6, "MPa", "мпа", "мегапаскаль")
	add("pressure", 1e5, "bar", "бар", "бара")
	add("pressure", 101325, "atm", "атм", "атмосфера", "атмосфер", "atmosphere")
	add("pressure", 98066.5, "at", "техническая атмосфера", "кгс/см2", "кгс/см²")
	add("pressure", 133.322387415, "mmHg", "мм рт ст", "мм рт. ст.", "мм.рт.ст", "торр", "torr")
	add("pressure", 6894.757293168, "psi", "фунт на кв дюйм")
	// power, base watt
	add("power", 1, "W", "вт", "ватт", "ваттов", "watt", "watts")
	add("power", 1000, "kW", "квт", "киловатт", "kilowatt")
	add("power", 1e6, "MW", "мвт", "мегаватт", "megawatt")
	add("power", 735.49875, "hp", "лс", "л.с.", "лошадиная сила", "лошадиных сил", "лошадиных", "horsepower", "ps")
	add("power", 745.69987158227, "bhp", "imperial hp", "mechanical hp")
	// temperature: value*factor + offset = kelvin
	for _, a := range []string{"c", "°c", "с°", "℃", "цельсий", "цельсия", "градус", "градусов", "градуса", "celsius"} {
		table[a] = unit{dim: "temperature", factor: 1, offset: 273.15, name: "°C"}
	}
	for _, a := range []string{"f", "°f", "℉", "фаренгейт", "фаренгейта", "fahrenheit"} {
		table[a] = unit{dim: "temperature", factor: 5.0 / 9, offset: 273.15 - 32*5.0/9, name: "°F"}
	}
	for _, a := range []string{"k", "°k", "кельвин", "кельвина", "кельвинов", "kelvin"} {
		table[a] = unit{dim: "temperature", factor: 1, name: "K"}
	}
	// fuel use: handled apart (l/100km is the inverse of mpg)
	for _, a := range []string{"l/100km", "л/100км", "л/100 км", "литров на сотню"} {
		table[a] = unit{dim: "fuel", factor: 1, name: "l/100km"}
	}
	for _, a := range []string{"mpg", "miles per gallon", "миль на галлон"} {
		table[a] = unit{dim: "fuel", factor: -1, name: "mpg"} // US gallon
	}
	for _, a := range []string{"km/l", "км/л", "kmpl"} {
		table[a] = unit{dim: "fuel", factor: -2, name: "km/l"}
	}
}

func lookup(name string) (unit, bool) {
	n := strings.ToLower(strings.TrimSpace(name))
	n = strings.TrimSuffix(n, ".")
	if u, ok := table[n]; ok {
		return u, true
	}
	if u, ok := table[strings.ReplaceAll(n, " ", "")]; ok {
		return u, true
	}
	// "кв. м", "м^2", "m^3"
	n = strings.NewReplacer("^2", "2", "^3", "3", "кв. ", "кв ", "куб. ", "куб ").Replace(n)
	u, ok := table[n]
	return u, ok
}

// Convert turns value of unit from into unit to. The case of the unit matters only for data ("Mb" bits vs "MB"
// bytes is read from the name: mbit/mb).
func Convert(value float64, from, to string) (float64, string, error) {
	a, ok := lookup(from)
	if !ok {
		return 0, "", fmt.Errorf("unknown unit %q", from)
	}
	b, ok := lookup(to)
	if !ok {
		return 0, "", fmt.Errorf("unknown unit %q", to)
	}
	if a.dim != b.dim {
		return 0, "", fmt.Errorf("%s (%s) and %s (%s) measure different things", from, a.dim, to, b.dim)
	}
	if a.dim == "fuel" {
		l100 := fuelTo(value, a.factor)
		if math.IsInf(l100, 0) || math.IsNaN(l100) {
			return 0, "", fmt.Errorf("fuel use of 0 cannot be converted")
		}
		return fuelFrom(l100, b.factor), b.name, nil
	}
	base := value*a.factor + a.offset
	return (base - b.offset) / b.factor, b.name, nil
}

const kmPerMile, litresPerGallon = 1.609344, 3.785411784

func fuelTo(v, kind float64) float64 { // to l/100km
	switch kind {
	case -1: // mpg
		return 100 * litresPerGallon / (v * kmPerMile)
	case -2: // km/l
		return 100 / v
	}
	return v
}

func fuelFrom(l100, kind float64) float64 {
	switch kind {
	case -1:
		return 100 * litresPerGallon / (l100 * kmPerMile)
	case -2:
		return 100 / l100
	}
	return l100
}

// Dimension tells what a unit measures ("" = unknown unit).
func Dimension(name string) string {
	u, ok := lookup(name)
	if !ok {
		return ""
	}
	return u.dim
}

// Format prints a result with sensible precision: up to 6 significant digits, no trailing zeros.
func Format(v float64) string {
	if v == 0 {
		return "0"
	}
	a := math.Abs(v)
	if a >= 1e15 || a < 1e-6 {
		return strings.Replace(fmt.Sprintf("%.6g", v), "e+", "e", 1)
	}
	digits := 6 - int(math.Floor(math.Log10(a))) - 1
	digits = max(0, min(digits, 10))
	s := fmt.Sprintf("%.*f", digits, v)
	if strings.Contains(s, ".") {
		s = strings.TrimRight(strings.TrimRight(s, "0"), ".")
	}
	return s
}
