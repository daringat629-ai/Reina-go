package units

import (
	"math"
	"testing"
)

func TestConvert(t *testing.T) {
	cases := []struct {
		v        float64
		from, to string
		want     float64
	}{
		{42.195, "km", "mi", 26.218757},
		{1, "миля", "км", 1.609344},
		{100, "°F", "°C", 37.777778},
		{-40, "цельсия", "фаренгейт", -40},
		{0, "K", "C", -273.15},
		{2, "фунта", "кг", 0.907185},
		{1, "GB", "MiB", 953.674316},
		{100, "мбит", "MB", 12.5},
		{3, "сотки", "м2", 300},
		{1, "га", "соток", 100},
		{60, "км/ч", "м/с", 16.666667},
		{2, "стакана", "мл", 500},
		{1, "ккал", "кдж", 4.184},
		{750, "мм рт ст", "кпа", 99.99179},
		{150, "лс", "квт", 110.324813},
		{8, "л/100км", "mpg", 29.4018},
		{30, "mpg", "л/100км", 7.840486},
		{2, "часа", "мин", 120},
		{1.5, "сутки", "ч", 36},
		{500, "мс", "сек", 0.5},
	}
	for _, c := range cases {
		got, _, err := Convert(c.v, c.from, c.to)
		if err != nil || math.Abs(got-c.want) > 1e-4*math.Max(1, math.Abs(c.want)) {
			t.Errorf("%v %s -> %s = %v (%v), want %v", c.v, c.from, c.to, got, err, c.want)
		}
	}
	if _, _, err := Convert(1, "kg", "km"); err == nil {
		t.Error("kg to km must be refused")
	}
	if _, _, err := Convert(1, "попугаев", "km"); err == nil {
		t.Error("unknown unit")
	}
}

func TestFormat(t *testing.T) {
	for v, want := range map[float64]string{26.21875744: "26.2188", 0.5: "0.5", 1234567.891: "1234568", 3e-9: "3e-09", 100: "100", -40: "-40"} {
		if got := Format(v); got != want {
			t.Errorf("Format(%v) = %q, want %q", v, got, want)
		}
	}
}
