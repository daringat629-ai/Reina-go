package web

import (
	"context"
	"net/http"
	"net/http/httptest"
	"net/netip"
	"strings"
	"testing"
)

func TestBlockedIP(t *testing.T) {
	blocked := []string{"127.0.0.1", "10.1.2.3", "192.168.0.5", "172.20.0.1", "169.254.169.254", "100.119.27.25", "100.64.0.1", "::1",
		"fe80::1", "fd00::1", "0.0.0.0", "224.0.0.1", "::ffff:127.0.0.1", "::ffff:10.0.0.1"}
	for _, s := range blocked {
		if !BlockedIP(netip.MustParseAddr(s)) {
			t.Errorf("%s must be blocked", s)
		}
	}
	for _, s := range []string{"8.8.8.8", "1.1.1.1", "93.184.216.34", "2606:4700:4700::1111"} {
		if BlockedIP(netip.MustParseAddr(s)) {
			t.Errorf("%s is public", s)
		}
	}
}

func TestPrivateTargetsAreRefusedIncludingRedirects(t *testing.T) {
	hit := false
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { hit = true; w.Write([]byte("secret")) }))
	defer srv.Close()
	_, err := Fetcher{}.Fetch(context.Background(), srv.URL) // 127.0.0.1
	if err != ErrBlocked {
		t.Fatalf("want ErrBlocked, got %v", err)
	}
	if hit {
		t.Fatal("the server must not even be contacted")
	}
	for _, u := range []string{"http://localhost:1/", "http://[::1]:80/", "http://169.254.169.254/latest/meta-data/", "http://100.119.27.25:10434/admin"} {
		if _, err := (Fetcher{}).Fetch(context.Background(), u); err == nil {
			t.Errorf("%s must fail", u)
		}
	}
	for _, u := range []string{"file:///etc/passwd", "ftp://example.com/x", "gopher://x", "http://user:pw@example.com/"} {
		if _, err := (Fetcher{}).Fetch(context.Background(), u); err == nil {
			t.Errorf("%s must be rejected", u)
		}
	}
}

func TestFetchHTMLTextPDFAndErrors(t *testing.T) {
	mux := http.NewServeMux()
	mux.HandleFunc("/page", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Write([]byte(`<html><head><title>Новости</title></head><body><script>x()</script><p>Первый абзац</p></body></html>`))
	})
	mux.HandleFunc("/r", func(w http.ResponseWriter, r *http.Request) { http.Redirect(w, r, "/page", http.StatusFound) })
	mux.HandleFunc("/json", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.Write([]byte(`{"a":1}`))
	})
	mux.HandleFunc("/img", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "image/png")
		w.Write([]byte("\x89PNG"))
	})
	mux.HandleFunc("/404", http.NotFound)
	mux.HandleFunc("/empty", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/html")
		w.Write([]byte(`<html><body><script>app()</script></body></html>`))
	})
	mux.HandleFunc("/big", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/plain")
		w.Write([]byte(strings.Repeat("z", 5000)))
	})
	srv := httptest.NewServer(mux)
	defer srv.Close()
	f := Fetcher{AllowPrivate: true, MaxBytes: 2000}
	ctx := context.Background()

	p, err := f.Fetch(ctx, srv.URL+"/r")
	if err != nil || p.Title != "Новости" || p.Text != "Первый абзац" || !strings.HasSuffix(p.URL, "/page") {
		t.Fatalf("html via redirect: %+v %v", p, err)
	}
	if p, err = f.Fetch(ctx, srv.URL+"/json"); err != nil || p.Text != `{"a":1}` {
		t.Fatalf("json: %+v %v", p, err)
	}
	if _, err = f.Fetch(ctx, srv.URL+"/img"); err == nil || !strings.Contains(err.Error(), "image/png") {
		t.Fatalf("image: %v", err)
	}
	if _, err = f.Fetch(ctx, srv.URL+"/404"); err == nil || !strings.Contains(err.Error(), "404") {
		t.Fatalf("404: %v", err)
	}
	if _, err = f.Fetch(ctx, srv.URL+"/empty"); err == nil || !strings.Contains(err.Error(), "no readable text") {
		t.Fatalf("empty: %v", err)
	}
	if p, err = f.Fetch(ctx, srv.URL+"/big"); err != nil || len(p.Text) != 2000 {
		t.Fatalf("body limit: len=%d err=%v", len(p.Text), err)
	}
}
