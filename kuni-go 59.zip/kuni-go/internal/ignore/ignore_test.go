package ignore

import (
	"path/filepath"
	"testing"
	"time"
)

func TestIgnoreListLifecycle(t *testing.T) {
	p := filepath.Join(t.TempDir(), "d", "ignore.json")
	s := New(p)
	s.Add("user", 7, "Spammer", "spam", 0)
	s.Add("chat", -9, "Noise", "", time.Hour)
	if !s.User(7) || !s.Chat(-9) || s.User(8) || s.Chat(7) || s.User(0) {
		t.Fatal("lookup wrong")
	}
	// survives a restart
	s2 := New(p)
	if !s2.User(7) || !s2.Chat(-9) || len(s2.List()) != 2 {
		t.Fatalf("%+v", s2.List())
	}
	// adding again only changes the term and keeps the name
	e := s2.Add("user", 7, "", "", time.Minute)
	if e.Name != "Spammer" || e.Until.IsZero() || len(s2.List()) != 2 {
		t.Fatalf("%+v", e)
	}
	if !s2.Remove("user", 7) || s2.Remove("user", 7) || s2.User(7) {
		t.Fatal("remove")
	}
	// a nil store ignores nobody
	var n *Store
	if n.User(1) || n.Chat(1) || n.List() != nil {
		t.Fatal("nil store")
	}
}

func TestIgnoreExpires(t *testing.T) {
	s := New("")
	s.Add("user", 1, "", "", 30*time.Millisecond)
	if !s.User(1) {
		t.Fatal("not ignored")
	}
	time.Sleep(60 * time.Millisecond)
	if s.User(1) || len(s.List()) != 0 {
		t.Fatal("did not expire")
	}
}
