package tgui

import (
	"context"
	"errors"
	"fmt"
	"strconv"
	"strings"
	"sync"
	"time"

	"kuni/internal/live"
	"kuni/internal/telegram"
)

const pageSize = 25

// Params are the arguments of one action.
type Params struct {
	Action   string
	Folder   string // list: all, archive or a folder name
	Chat     string // open/send...: number from the list, chat id, @username or part of a name
	N        int    // message number on screen (or a message id)
	Text     string
	Emoji    string
	Button   string // press: "row.col", a flat number or the button's text
	To       string // forward: the chat to forward to
	Options  string // vote: "1,3"
	Silent   bool
	Markdown bool
	At       string // send: a time (RFC3339 or 2006-01-02 15:04 in her time zone) or +30m
	Lat, Lon float64
	Scope    string // search: chat (default when a chat is open) or all
}

// UI is her Telegram app: one screen at a time, like a person's phone.
type UI struct {
	TG   telegram.Client
	Body func(ctx context.Context, m telegram.Message) string // media description (nil = placeholders)
	Feed *live.Feed
	Loc  *time.Location
	Now  func() time.Time

	mu     sync.Mutex
	screen string // list, chat, search
	list   telegram.ChatList
	label  string
	chats  []telegram.Chat
	chat   telegram.Chat
	msgs   []telegram.Message // the window of the open chat, oldest first; numbers on screen are index+1
	found  []telegram.Message // search results
	query  string
}

func New(tg telegram.Client) *UI {
	return &UI{TG: tg, Loc: time.Local, Now: time.Now, screen: "list", label: "Все чаты"}
}

func (u *UI) rich() (telegram.Rich, error) {
	r, ok := u.TG.(telegram.Rich)
	if !ok {
		return nil, errors.New("this needs the user account (the bot account has no folders, buttons or mute)")
	}
	return r, nil
}

func (u *UI) emit(act string, chatID, msgID int64, text string) {
	u.emitTyping(act, chatID, msgID, text, "")
}

// emitTyping also shows the text she is writing, so the panel can type it in the message field before it is sent.
func (u *UI) emitTyping(act string, chatID, msgID int64, text, typing string) {
	if u.Feed != nil {
		u.Feed.AddEvent(live.Event{Kind: "ui", Chat: u.chat.Title, ChatID: chatID, MsgID: msgID, Act: act, Text: text, Typing: typing})
	}
}

// Do runs one action and returns the screen she should look at next.
func (u *UI) Do(ctx context.Context, p Params) (string, error) {
	u.mu.Lock()
	defer u.mu.Unlock()
	act := strings.ToLower(strings.TrimSpace(p.Action))
	switch act {
	case "", "screen":
		return u.render(ctx), nil
	case "folders":
		return u.foldersText(ctx)
	case "list":
		return u.openList(ctx, p.Folder)
	case "back":
		if u.screen == "chat" || u.screen == "search" {
			u.screen = "list"
			u.emit("back", 0, 0, "вернулась к списку чатов")
			return u.reloadList(ctx)
		}
		return u.render(ctx), nil
	case "open":
		return u.open(ctx, p.Chat, p.N)
	case "up", "down":
		return u.scroll(ctx, act)
	case "search":
		return u.search(ctx, p)
	case "send", "reply", "edit", "delete", "react", "press", "forward", "pin", "unpin", "vote", "view", "read", "mute", "unmute", "dice", "location":
		return u.act(ctx, act, p)
	}
	return "", fmt.Errorf("unknown action %q: screen, folders, list, open, back, up, down, search, send, reply, edit, delete, react, press, forward, pin, unpin, vote, view, read, mute, unmute, dice, location", p.Action)
}

// ---- screens ----

func (u *UI) render(ctx context.Context) string {
	switch u.screen {
	case "chat":
		return u.renderChat(ctx)
	case "search":
		return u.renderSearch()
	}
	return u.renderList()
}

func (u *UI) renderList() string {
	var b strings.Builder
	unread := 0
	for _, c := range u.chats {
		if !c.Muted {
			unread += c.Unread
		}
	}
	fmt.Fprintf(&b, "┌ Telegram · %s · непрочитано (без мьюта): %d\n", u.label, unread)
	if len(u.chats) == 0 {
		b.WriteString("│ (чатов нет)\n")
	}
	now := u.Now()
	for i, c := range u.chats {
		b.WriteString("│ " + ChatLine(i+1, c, now, u.Loc) + "\n")
	}
	b.WriteString("└ open(chat = номер) · folders · list(folder) · search(text)")
	return b.String()
}

func (u *UI) reloadList(ctx context.Context) (string, error) {
	var cs []telegram.Chat
	var err error
	if r, ok := u.TG.(telegram.Rich); ok {
		cs, err = r.ChatsIn(ctx, u.list, 30)
	} else {
		cs, err = u.TG.Chats(ctx, 30)
	}
	if err != nil {
		return "", err
	}
	// pinned first, then the newest, as the app sorts them
	sortChats(cs)
	u.chats, u.screen = cs, "list"
	u.emit("list", 0, 0, u.label)
	return u.renderList(), nil
}

func sortChats(cs []telegram.Chat) {
	for i := 1; i < len(cs); i++ {
		for j := i; j > 0; j-- {
			a, b := cs[j-1], cs[j]
			if (b.Pinned && !a.Pinned) || (b.Pinned == a.Pinned && b.LastDate.After(a.LastDate)) {
				cs[j-1], cs[j] = b, a
			} else {
				break
			}
		}
	}
}

func (u *UI) foldersText(ctx context.Context) (string, error) {
	r, err := u.rich()
	if err != nil {
		return "", err
	}
	fs, err := r.Folders(ctx)
	if err != nil {
		return "", err
	}
	var b strings.Builder
	b.WriteString("Папки: «all» (все чаты)")
	for _, f := range fs {
		b.WriteString(", «" + f.Name + "»")
	}
	b.WriteString(", «archive» (архив). Открыть: list(folder = название).")
	return b.String(), nil
}

func (u *UI) openList(ctx context.Context, folder string) (string, error) {
	f := strings.TrimSpace(folder)
	u.list, u.label = telegram.ChatList{}, "Все чаты"
	switch strings.ToLower(f) {
	case "", "all", "все", "все чаты":
	case "archive", "архив":
		u.list, u.label = telegram.ChatList{Archive: true}, "Архив"
	default:
		r, err := u.rich()
		if err != nil {
			return "", err
		}
		fs, err := r.Folders(ctx)
		if err != nil {
			return "", err
		}
		found := false
		for _, x := range fs {
			if strings.EqualFold(x.Name, f) || strconv.Itoa(x.ID) == f {
				u.list, u.label, found = telegram.ChatList{Folder: x.ID}, "Папка «"+x.Name+"»", true
				break
			}
		}
		if !found {
			return "", fmt.Errorf("no folder %q; folders shows the names", f)
		}
	}
	return u.reloadList(ctx)
}

// resolve finds a chat from what she wrote: the number on the list, an id, a @username or a part of a name.
func (u *UI) resolve(ctx context.Context, q string, n int) (telegram.Chat, error) {
	q = strings.TrimSpace(q)
	if q == "" && n > 0 {
		q = strconv.Itoa(n)
	}
	if q == "" {
		if u.chat.ID != 0 {
			return u.chat, nil
		}
		return telegram.Chat{}, errors.New("say which chat: a number from the list, an id, @username or a name")
	}
	if v, err := strconv.Atoi(q); err == nil && v >= 1 && v <= len(u.chats) && u.screen == "list" {
		return u.chats[v-1], nil
	}
	if id, err := strconv.ParseInt(q, 10, 64); err == nil {
		return u.TG.Chat(ctx, id)
	}
	for _, c := range u.chats {
		if strings.EqualFold(c.Title, q) {
			return c, nil
		}
	}
	cs, err := u.TG.SearchChats(ctx, q)
	if err != nil {
		return telegram.Chat{}, err
	}
	if len(cs) == 0 {
		return telegram.Chat{}, fmt.Errorf("no chat matches %q", q)
	}
	return cs[0], nil
}

func (u *UI) open(ctx context.Context, q string, n int) (string, error) {
	var c telegram.Chat
	var err error
	if u.screen == "search" && q == "" && n >= 1 && n <= len(u.found) { // a search result opens its chat at that message
		m := u.found[n-1]
		if c, err = u.TG.Chat(ctx, m.ChatID); err != nil {
			return "", err
		}
		msgs, err := u.TG.History(ctx, c.ID, m.ID, pageSize/2, pageSize/2)
		if err != nil {
			return "", err
		}
		u.chat, u.msgs, u.screen = c, msgs, "chat"
		u.emit("open", c.ID, m.ID, "открыла найденное сообщение в «"+c.Title+"»")
		return u.renderChat(ctx), nil
	}
	if c, err = u.resolve(ctx, q, n); err != nil {
		return "", err
	}
	msgs, err := u.TG.History(ctx, c.ID, 0, pageSize, 0)
	if err != nil {
		return "", err
	}
	u.chat, u.msgs, u.screen = c, msgs, "chat"
	u.emit("open", c.ID, 0, "открыла чат «"+c.Title+"»")
	return u.renderChat(ctx), nil
}

func (u *UI) scroll(ctx context.Context, dir string) (string, error) {
	if u.screen != "chat" || len(u.msgs) == 0 {
		return "", errors.New("open a chat first")
	}
	if dir == "up" {
		oldest := u.msgs[0].ID
		older, err := u.TG.History(ctx, u.chat.ID, oldest, pageSize, 0)
		if err != nil {
			return "", err
		}
		var add []telegram.Message
		for _, m := range older {
			if m.ID < oldest {
				add = append(add, m)
			}
		}
		if len(add) == 0 {
			return u.renderChat(ctx) + "\n(выше сообщений нет — это начало чата)", nil
		}
		u.msgs = add
	} else {
		newest := u.msgs[len(u.msgs)-1].ID
		newer, err := u.TG.History(ctx, u.chat.ID, newest, 0, pageSize)
		if err != nil {
			return "", err
		}
		var add []telegram.Message
		for _, m := range newer {
			if m.ID > newest {
				add = append(add, m)
			}
		}
		if len(add) == 0 {
			// already at the bottom: refresh the latest
			if latest, err := u.TG.History(ctx, u.chat.ID, 0, pageSize, 0); err == nil {
				u.msgs = latest
			}
			return u.renderChat(ctx) + "\n(ниже ничего нет — это конец чата)", nil
		}
		u.msgs = add
	}
	u.emit("scroll", u.chat.ID, 0, "листает чат «"+u.chat.Title+"» "+map[string]string{"up": "вверх", "down": "вниз"}[dir])
	return u.renderChat(ctx), nil
}

func (u *UI) find(id int64) (telegram.Message, bool) {
	for _, m := range u.msgs {
		if m.ID == id {
			return m, true
		}
	}
	if m, err := u.TG.Message(context.Background(), u.chat.ID, id); err == nil {
		return m, true
	}
	return telegram.Message{}, false
}

func (u *UI) renderChat(ctx context.Context) string { return u.renderChatFrom(ctx, 0) }

// renderChatFrom draws the open chat from the message with index start (numbers keep counting from the top of the window).
func (u *UI) renderChatFrom(ctx context.Context, start int) string {
	// refresh what the header shows (typing, online, mute...)
	if c, err := u.TG.Chat(ctx, u.chat.ID); err == nil {
		u.chat = c
	}
	var b strings.Builder
	head := "┌ ◀ " + u.chat.Title
	if t := typingText(u.chat.Typing, u.chat.TypingBy); t != "" {
		head += " · " + t
	} else if p := presenceText(u.chat, u.Loc); p != "" && u.chat.Kind == telegram.ChatPrivate {
		head += " · " + p
	}
	if u.chat.Muted {
		head += " · 🔕"
	}
	if u.chat.Unread > 0 {
		head += fmt.Sprintf(" · непрочитано %d", u.chat.Unread)
	}
	b.WriteString(head + "\n")
	if r, ok := u.TG.(telegram.Rich); ok {
		if pm, err := r.PinnedMessage(ctx, u.chat.ID); err == nil && pm.ID != 0 {
			t := pm.Text
			if t == "" {
				t = placeholder(pm)
			}
			fmt.Fprintf(&b, "│ 📌 закреплено: «%s»\n", clip(t, 80))
		}
	}
	// the three newest messages with media are looked at; the older ones stay placeholders
	describe := map[int64]bool{}
	for i, left := len(u.msgs)-1, 3; i >= 0 && left > 0; i-- {
		if u.msgs[i].Media != telegram.MediaNone && u.msgs[i].Poll == nil {
			describe[u.msgs[i].ID] = true
			left--
		}
	}
	desc := func(m telegram.Message) string {
		if u.Body == nil || !describe[m.ID] {
			return ""
		}
		return u.Body(ctx, m)
	}
	day := ""
	if start > 0 && start < len(u.msgs) {
		b.WriteString(fmt.Sprintf("│ … выше ещё %d сообщ. (номера сохранены, screen покажет всё)\n", start))
	} else {
		start = 0
	}
	for i := start; i < len(u.msgs); i++ {
		m := u.msgs[i]
		if d := dayLabel(m.Date, u.Loc); d != day {
			day = d
			b.WriteString("│ ── " + d + " ──\n")
		}
		album := 1
		if m.AlbumID != 0 {
			for i+album < len(u.msgs) && u.msgs[i+album].AlbumID == m.AlbumID {
				album++
			}
		}
		blk := MessageBlock(i+1, m, u.find, desc, u.TG.MyID(), u.Loc, album)
		if album > 1 {
			blk += fmt.Sprintf("\n      (альбом из %d)", album)
			for k := 1; k < album; k++ {
				if t := u.msgs[i+k].Text; t != "" && m.Text == "" {
					blk += "\n      " + t
				}
			}
			i += album - 1
		}
		for _, l := range strings.Split(blk, "\n") {
			b.WriteString("│ " + l + "\n")
		}
	}
	if len(u.msgs) == 0 {
		b.WriteString("│ (сообщений нет)\n")
	}
	b.WriteString("└ reply(n,text) · send(text) · react(n,emoji) · press(n,button) · view(n) · up/down · back")
	return b.String()
}

// ---- search ----

func (u *UI) search(ctx context.Context, p Params) (string, error) {
	if strings.TrimSpace(p.Text) == "" {
		return "", errors.New("what to search for? pass text")
	}
	q := telegram.SearchQuery{Text: p.Text, Limit: 20}
	scope := strings.ToLower(p.Scope)
	if u.screen == "chat" && scope != "all" {
		q.ChatID = u.chat.ID
	}
	res, err := u.TG.Search(ctx, q)
	if err != nil {
		return "", err
	}
	u.found, u.query, u.screen = res, p.Text, "search"
	u.emit("search", q.ChatID, 0, "ищет «"+p.Text+"»")
	return u.renderSearch(), nil
}

func (u *UI) renderSearch() string {
	var b strings.Builder
	fmt.Fprintf(&b, "┌ Поиск «%s» · найдено %d\n", u.query, len(u.found))
	for i, m := range u.found {
		title := ""
		if c, ok := u.chatTitle(m.ChatID); ok {
			title = c + " · "
		}
		who := m.SenderName
		if m.Outgoing {
			who = "вы"
		}
		t := m.Text
		if t == "" {
			t = placeholder(m)
		}
		fmt.Fprintf(&b, "│ %2d. %s%s %s %s: %s\n", i+1, title, dayLabel(m.Date, u.Loc), m.Date.In(u.Loc).Format("15:04"), who, clip(t, 100))
	}
	b.WriteString("└ open(n) = перейти к сообщению · back")
	return b.String()
}

func (u *UI) chatTitle(id int64) (string, bool) {
	if id == u.chat.ID && u.chat.Title != "" {
		return u.chat.Title, true
	}
	for _, c := range u.chats {
		if c.ID == id {
			return c.Title, true
		}
	}
	if c, err := u.TG.Chat(context.Background(), id); err == nil {
		return c.Title, true
	}
	return "", false
}
