package tgui

import (
	"context"
	"strconv"
	"strings"
	"testing"
	"time"

	"kuni/internal/live"
	"kuni/internal/telegram"
)

func setup(t *testing.T) (*UI, *telegram.Fake, *live.Feed) {
	t.Helper()
	f := telegram.NewFake()
	feed := &live.Feed{}
	u := New(f)
	u.Feed, u.Loc = feed, time.UTC
	return u, f, feed
}

func do(t *testing.T, u *UI, p Params) string {
	t.Helper()
	out, err := u.Do(context.Background(), p)
	if err != nil {
		t.Fatalf("%+v: %v", p, err)
	}
	return out
}

func contains(t *testing.T, s string, parts ...string) {
	t.Helper()
	for _, p := range parts {
		if !strings.Contains(s, p) {
			t.Fatalf("missing %q in:\n%s", p, s)
		}
	}
}

func TestChatListShowsTheMarksOfTheApp(t *testing.T) {
	u, f, _ := setup(t)
	f.Incoming(telegram.Chat{ID: 1, Title: "Папик", Kind: telegram.ChatPrivate, Pinned: true, Presence: "online"}, 9, "Папик", "привет")
	f.Incoming(telegram.Chat{ID: 2, Title: "Работа", Kind: telegram.ChatGroup, Muted: true, UnreadMentions: 2, Typing: "typing", TypingBy: "Алекс"}, 9, "Алекс", "сроки")
	f.Incoming(telegram.Chat{ID: 3, Title: "Новости", Kind: telegram.ChatChannel, Archived: true}, 9, "Новости", "новость")
	out := do(t, u, Params{Action: "list"})
	contains(t, out, "Все чаты", "📌👤 Папик", "в сети", "🔕👥 Работа", "@2", "✍ Алекс печатает…", "«сроки»")
	if strings.Contains(out, "Новости") {
		t.Fatalf("archived chat in the main list:\n%s", out)
	}
	if first := strings.Index(out, "Папик"); first > strings.Index(out, "Работа") {
		t.Fatalf("pinned chat is not first:\n%s", out)
	}
	arch := do(t, u, Params{Action: "list", Folder: "archive"})
	contains(t, arch, "Архив", "📢 Новости")
	f.Rich.FolderList = []telegram.Folder{{ID: 7, Name: "Работа"}}
	contains(t, do(t, u, Params{Action: "folders"}), "«Работа»", "«archive»")
	if _, err := u.Do(context.Background(), Params{Action: "list", Folder: "Нет такой"}); err == nil {
		t.Fatal("unknown folder accepted")
	}
}

func fillChat(f *telegram.Fake) telegram.Chat {
	chat := telegram.Chat{ID: 5, Title: "Алекс", Kind: telegram.ChatPrivate}
	now := time.Now()
	f.Incoming(chat, 9, "Алекс", "привет")
	f.S.Put(telegram.Message{ID: 2, ChatID: 5, SenderID: 9, SenderName: "Алекс", Date: now, Text: "глянь https://x.io", Entities: []telegram.Entity{{Type: "link", Offset: 6, Length: 12, URL: "https://x.io"}},
		Preview: &telegram.LinkPreview{URL: "https://x.io", Site: "X", Title: "Сайт", Description: "описание"}}, nil)
	f.S.Put(telegram.Message{ID: 3, ChatID: 5, SenderID: 9, SenderName: "Алекс", Date: now, ReplyTo: 1, Quote: "пр", Text: "ответ на привет",
		Buttons: [][]telegram.Button{{{Text: "Да", Kind: "callback", Data: "eWVz"}, {Text: "Сайт", Kind: "url", URL: "https://a.b"}}}, Counts: []telegram.ReactionCount{{Emoji: "👍", Count: 3, Mine: true}}}, nil)
	f.S.Put(telegram.Message{ID: 4, ChatID: 5, SenderID: 9, SenderName: "Алекс", Date: now, Service: "Алекс закрепил(а) сообщение", Text: "Алекс закрепил(а) сообщение"}, nil)
	f.S.Put(telegram.Message{ID: 5, ChatID: 5, SenderID: 9, SenderName: "Алекс", Date: now, Media: telegram.MediaPoll, Text: "Куда?", Poll: &telegram.Poll{Question: "Куда?", Options: []telegram.PollOption{{Text: "Бишкек", Votes: 2}, {Text: "Ош", Votes: 1}}}}, nil)
	f.S.Put(telegram.Message{ID: 6, ChatID: 5, SenderID: 9, SenderName: "Алекс", Date: now, Media: telegram.MediaPhoto, AlbumID: 77, Text: "подпись альбома"}, nil)
	f.S.Put(telegram.Message{ID: 7, ChatID: 5, SenderID: 9, SenderName: "Алекс", Date: now, Media: telegram.MediaPhoto, AlbumID: 77}, nil)
	f.S.Put(telegram.Message{ID: 8, ChatID: 5, SenderID: 9, SenderName: "Алекс", Date: now, Place: &telegram.Place{Lat: 42.87, Lon: 74.59, Title: "Кафе"}, Text: "📍 Кафе"}, nil)
	return chat
}

func TestOpenChatRendersEverythingTheAppShows(t *testing.T) {
	u, f, _ := setup(t)
	fillChat(f)
	do(t, u, Params{Action: "list"})
	out := do(t, u, Params{Action: "open", Chat: "1"})
	contains(t, out, "◀ Алекс", "#1 ", "глянь https://x.io ⟨https://x.io⟩", "🔗 X Сайт — описание", "↩ Алекс: «привет»", "❝ пр",
		"[1.1 Да]", "[1.2 Сайт ↗ https://a.b]", "👍3(вы)", "— Алекс закрепил(а) сообщение —",
		"📊 опрос: Куда?", "1) Бишкек — 2", "#6–#7", "(альбом из 2)", "подпись альбома", "📍", "42.87000")
}

func TestActionsOnNumbers(t *testing.T) {
	u, f, feed := setup(t)
	fillChat(f)
	f.Rich.Answer = telegram.ButtonAnswer{Text: "принято"}
	do(t, u, Params{Action: "open", Chat: "Алекс"})
	// reply to #3
	out := do(t, u, Params{Action: "reply", N: 3, Text: "ок"})
	contains(t, out, "Отправлено", "вы", "↩ Алекс: «ответ на привет»")
	sent := f.Sent[len(f.Sent)-1]
	if sent.ReplyTo != 3 || sent.Text != "ок" {
		t.Fatalf("sent: %+v", sent)
	}
	// reaction, press, vote
	do(t, u, Params{Action: "react", N: 3, Emoji: "❤"})
	if f.Reacted[3] != "❤" {
		t.Fatalf("reaction: %v", f.Reacted)
	}
	out = do(t, u, Params{Action: "press", N: 3, Button: "Да"})
	contains(t, out, "Нажата «Да»", "принято")
	if len(f.Rich.Pressed) != 1 || f.Rich.Pressed[0] != "5/3/eWVz" {
		t.Fatalf("pressed: %v", f.Rich.Pressed)
	}
	out = do(t, u, Params{Action: "press", N: 3, Button: "1.2"})
	contains(t, out, "это ссылка: https://a.b")
	if len(f.Rich.Pressed) != 1 {
		t.Fatal("a url button was pressed as a callback")
	}
	do(t, u, Params{Action: "vote", N: 5, Options: "2"})
	if _, err := u.Do(context.Background(), Params{Action: "vote", N: 5, Options: "9"}); err == nil {
		t.Fatal("option out of range accepted")
	}
	if _, err := u.Do(context.Background(), Params{Action: "vote", N: 1, Options: "1"}); err == nil {
		t.Fatal("voted in a non-poll")
	}
	// editing only her own message
	if _, err := u.Do(context.Background(), Params{Action: "edit", N: 3, Text: "x"}); err == nil {
		t.Fatal("edited somebody else's message")
	}
	u.mu.Lock()
	var mine int
	for i, m := range u.msgs {
		if m.Outgoing {
			mine = i + 1
		}
	}
	u.mu.Unlock()
	do(t, u, Params{Action: "edit", N: mine, Text: "исправлено", Markdown: true})
	contains(t, do(t, u, Params{Action: "screen"}), "исправлено", "(изм.)")
	// markdown, silent and scheduled
	do(t, u, Params{Action: "send", Text: "это *важно*", Markdown: true, Silent: true, At: "+30m"})
	if o := f.Rich.Scheduled[len(f.Rich.Scheduled)-1]; !o.Markdown || !o.Silent || o.At.IsZero() {
		t.Fatalf("options: %+v", o)
	}
	if _, err := u.Do(context.Background(), Params{Action: "send", Text: "x", At: "завтра"}); err == nil {
		t.Fatal("bad time accepted")
	}
	// forward, pin, mute, read, delete
	f.Incoming(telegram.Chat{ID: 6, Title: "Бек"}, 8, "Бек", "хай")
	do(t, u, Params{Action: "forward", N: 2, To: "Бек"})
	if len(f.Forwards) != 1 || f.Forwards[0] != [3]int64{5, 2, 6} {
		t.Fatalf("forwards: %v", f.Forwards)
	}
	do(t, u, Params{Action: "pin", N: 2})
	contains(t, do(t, u, Params{Action: "screen"}), "📌 закреплено: «глянь")
	do(t, u, Params{Action: "mute"})
	if c, _ := f.Chat(context.Background(), 5); !c.Muted {
		t.Fatal("not muted")
	}
	do(t, u, Params{Action: "dice", Emoji: "🎯"})
	do(t, u, Params{Action: "location", Lat: 42.8, Lon: 74.6})
	if len(f.Rich.Dice) != 1 || len(f.Rich.Locations) != 1 {
		t.Fatalf("dice/location: %v %v", f.Rich.Dice, f.Rich.Locations)
	}
	do(t, u, Params{Action: "delete", N: mine})
	// the panel was told
	acts := map[string]bool{}
	for _, e := range feed.Since(0) {
		if e.Kind == "ui" {
			acts[e.Act] = true
		}
	}
	for _, want := range []string{"open", "reply", "sent", "react", "press", "vote", "edit", "forward", "pin", "mute", "delete"} {
		if !acts[want] {
			t.Errorf("no ui event %q (have %v)", want, acts)
		}
	}
	// a reply event carries the message and the text she types
	for _, e := range feed.Since(0) {
		if e.Act == "reply" && (e.MsgID != 3 || e.Typing != "ок" || e.ChatID != 5) {
			t.Fatalf("reply event: %+v", e)
		}
	}
}

func TestSearchScrollAndBack(t *testing.T) {
	u, f, _ := setup(t)
	chat := telegram.Chat{ID: 5, Title: "Алекс"}
	for i := 0; i < 60; i++ {
		f.Incoming(chat, 9, "Алекс", "сообщение номер "+strconv.Itoa(i))
	}
	do(t, u, Params{Action: "open", Chat: "Алекс"})
	u.mu.Lock()
	first := u.msgs[0].ID
	u.mu.Unlock()
	out := do(t, u, Params{Action: "up"})
	u.mu.Lock()
	if u.msgs[len(u.msgs)-1].ID >= first || len(u.msgs) == 0 {
		t.Fatalf("up did not go to older messages: first was %d, now %d..%d", first, u.msgs[0].ID, u.msgs[len(u.msgs)-1].ID)
	}
	u.mu.Unlock()
	contains(t, out, "◀ Алекс")
	out = do(t, u, Params{Action: "down"})
	contains(t, out, "#")
	out = do(t, u, Params{Action: "search", Text: "номер 17"})
	contains(t, out, "Поиск «номер 17»", "Алекс · ")
	out = do(t, u, Params{Action: "open", N: 1})
	contains(t, out, "◀ Алекс")
	contains(t, do(t, u, Params{Action: "back"}), "Telegram · Все чаты")
	if _, err := u.Do(context.Background(), Params{Action: "react", N: 1, Emoji: "👍"}); err == nil {
		t.Fatal("acted on a message with no chat open")
	}
	if _, err := u.Do(context.Background(), Params{Action: "fly"}); err == nil {
		t.Fatal("unknown action accepted")
	}
}

func TestLinksAreInsertedByUTF16Offsets(t *testing.T) {
	// "😀" is two UTF-16 units: the link starts after it
	got := withLinks("😀 тут", []telegram.Entity{{Type: "link", Offset: 3, Length: 3, URL: "https://u.io"}})
	if got != "😀 тут ⟨https://u.io⟩" {
		t.Fatalf("got %q", got)
	}
	if withLinks("abc", []telegram.Entity{{Type: "link", Offset: 5, Length: 9, URL: "x"}}) != "abc" {
		t.Fatal("out of range entity changed the text")
	}
}

func TestAMessageIdWithAChatWorksWithoutOpeningIt(t *testing.T) {
	u, f, _ := setup(t)
	f.Rich.Answer = telegram.ButtonAnswer{Text: "ok"}
	chat := telegram.Chat{ID: 5, Title: "Бот"}
	f.S.Put(telegram.Message{ID: 41, ChatID: 5, SenderName: "Бот", Date: time.Now(), Text: "выбери", Buttons: [][]telegram.Button{{{Text: "Да", Kind: "callback", Data: "eWVz"}}}}, &chat)
	// the screen is on the chat list; the id comes from a normal chat view
	do(t, u, Params{Action: "press", Chat: "5", N: 41, Button: "1.1"})
	if len(f.Rich.Pressed) != 1 || f.Rich.Pressed[0] != "5/41/eWVz" {
		t.Fatalf("pressed: %v", f.Rich.Pressed)
	}
	do(t, u, Params{Action: "react", Chat: "5", N: 41, Emoji: "👍"})
	if f.Reacted[41] != "👍" {
		t.Fatalf("reaction: %v", f.Reacted)
	}
	if _, err := u.Do(context.Background(), Params{Action: "react", N: 41, Emoji: "👍"}); err == nil {
		t.Fatal("without a chat and without an open chat there is no message to react to")
	}
}
