package desktop

import (
	"context"
	"fmt"
	"image"
	"net/http"
	"net/http/httptest"
	"os/exec"
	"strings"
	"sync"
	"testing"
	"time"

	"kuni/internal/browser"
)

func need(t *testing.T) string {
	if _, err := exec.LookPath("Xvfb"); err != nil {
		t.Skip("no Xvfb")
	}
	bin := browser.Find("")
	if bin == "" {
		t.Skip("no chromium to use as the test program")
	}
	return bin
}

const appPage = `<!doctype html><title>Тестовая программа</title><style>body{margin:0;background:#fff}
#in{position:absolute;left:100px;top:200px;width:600px;height:60px;font-size:30px}
#btn{position:absolute;left:100px;top:400px;width:300px;height:80px;font-size:30px}
#tall{position:absolute;top:700px;height:3000px}</style>
<input id="in" autocomplete="off"><button id="btn" onclick="document.title='Нажата кнопка';rep('btn','1')">Кнопка</button><div id="tall">низ</div>
<script>
var N=0;function rep(k,v){fetch('/rep?k='+k+'&n='+(++N)+'&v='+encodeURIComponent(v))}
var i=document.getElementById('in');
i.addEventListener('input',()=>rep('val',i.value));
i.addEventListener('keydown',e=>{if(e.key==='Enter')rep('enter','1')});
document.addEventListener('dblclick',()=>rep('dbl','1'));
document.addEventListener('wheel',e=>rep('wheel',e.deltaY>0?'down':'up'));
document.addEventListener('contextmenu',e=>{e.preventDefault();rep('right','1')});
</script>`

type recorder struct {
	mu sync.Mutex
	m  map[string]string
	n  map[string]int
}

func (r *recorder) get(k string) string { r.mu.Lock(); defer r.mu.Unlock(); return r.m[k] }

func TestScreenEndToEnd(t *testing.T) {
	bin := need(t)
	for _, k := range []string{"GOOGLE_API_KEY", "GOOGLE_DEFAULT_CLIENT_ID", "GOOGLE_DEFAULT_CLIENT_SECRET"} {
		t.Setenv(k, "no") // no "API keys are missing" bar that would push the page down
	}
	rec := &recorder{m: map[string]string{}, n: map[string]int{}}
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/rep" {
			rec.mu.Lock()
			k := r.URL.Query().Get("k")
			var n int
			fmt.Sscan(r.URL.Query().Get("n"), &n)
			if n >= rec.n[k] { // requests may overtake each other: the newest report wins
				rec.n[k], rec.m[k] = n, r.URL.Query().Get("v")
			}
			rec.mu.Unlock()
			return
		}
		fmt.Fprint(w, appPage)
	}))
	defer srv.Close()
	wait := func(what string, cond func() bool) {
		t.Helper()
		end := time.Now().Add(8 * time.Second)
		for time.Now().Before(end) {
			if cond() {
				return
			}
			time.Sleep(100 * time.Millisecond)
		}
		t.Fatalf("timeout: %s (recorded: %v)", what, rec.m)
	}

	d := New()
	defer d.Close()
	ctx, cancel := context.WithTimeout(context.Background(), 90*time.Second)
	defer cancel()
	err := d.Do(ctx, Options{Width: 1280, Height: 800}, func(s *Screen) error {
		blank, err := s.X().Screenshot()
		if err != nil {
			return err
		}
		if s.X().Width != 1280 || s.X().Height != 800 {
			t.Fatalf("screen %dx%d", s.X().Width, s.X().Height)
		}
		sigBlank := Signature(blank)
		if err := s.Launch(fmt.Sprintf("%s --no-sandbox --test-type --disable-infobars --disable-gpu --user-data-dir=%s --window-position=0,0 --window-size=1280,800 --app=%s", bin, t.TempDir(), srv.URL)); err != nil {
			return err
		}
		var ws []Window
		wait("the window shows up", func() bool {
			ws, _ = s.X().Windows()
			return len(ws) > 0 && strings.Contains(ws[0].Title, "Тестовая программа")
		})
		shot, _ := s.X().Screenshot()
		if Signature(shot) == sigBlank {
			t.Fatal("the screen did not change after the program started")
		}
		// click into the field and type text the layout does not have (Cyrillic), capitals and symbols
		if err := s.X().Click(300, 230, 1, 1); err != nil {
			return err
		}
		const text = "Привет, Мир! abc XYZ 123 @#"
		if err := s.X().TypeText(text); err != nil {
			return err
		}
		wait("typed text arrives", func() bool { return rec.get("val") == text })
		// ctrl+a, Backspace clears it; Enter reaches the page
		if err := s.X().Press("ctrl+a"); err != nil {
			return err
		}
		if err := s.X().Press("BackSpace"); err != nil {
			return err
		}
		wait("field cleared", func() bool { return rec.get("val") == "" })
		if err := s.X().Press("Enter"); err != nil {
			return err
		}
		wait("enter", func() bool { return rec.get("enter") == "1" })
		// the button changes the window title
		if err := s.X().Click(250, 440, 1, 1); err != nil {
			return err
		}
		wait("button", func() bool {
			ws, _ = s.X().Windows()
			return len(ws) > 0 && ws[0].Title == "Нажата кнопка"
		})
		// double click, right click, wheel
		if err := s.X().Click(900, 600, 1, 2); err != nil {
			return err
		}
		wait("double click", func() bool { return rec.get("dbl") == "1" })
		if err := s.X().Click(900, 600, 3, 1); err != nil {
			return err
		}
		wait("right click", func() bool { return rec.get("right") == "1" })
		if err := s.X().Scroll(900, 600, true, 3); err != nil {
			return err
		}
		wait("wheel", func() bool { return rec.get("wheel") == "down" })
		// the grid and the encoders work on a real screenshot
		shot, _ = s.X().Screenshot()
		g := WithGrid(shot, 100)
		png, err := PNG(g)
		if err != nil || len(png) < 2000 || string(png[1:4]) != "PNG" {
			t.Fatalf("png %d %v", len(png), err)
		}
		if g.RGBAAt(100, 300) == shot.RGBAAt(100, 300) && g.RGBAAt(101, 300) == shot.RGBAAt(101, 300) && g.RGBAAt(102, 300) == shot.RGBAAt(102, 300) {
			t.Log("grid line pixel unchanged (dash gap)")
		}
		return nil
	})
	if err != nil {
		t.Fatal(err)
	}
	d.Close()
	if d.Running() {
		t.Fatal("Close must stop the screen")
	}
}

func TestKeysAndGridUnits(t *testing.T) {
	for in, want := range map[string]uint32{"Enter": 0xff0d, "ctrl": 0xffe3, "F5": 0xffc2, "a": 'a', "я": 0x01000000 | 'я', "Space": ' '} {
		if got, ok := keysymOf(in); !ok || got != want {
			t.Errorf("%q -> %#x %v, want %#x", in, got, ok, want)
		}
	}
	if _, ok := keysymOf("F13"); ok {
		t.Error("F13 is not a key we know")
	}
	if _, ok := keysymOf("blah"); ok {
		t.Error("unknown names are refused")
	}
	img := image.NewRGBA(image.Rect(0, 0, 400, 300))
	a, b := Signature(img), Signature(img)
	if a != b {
		t.Fatal("signature must be stable")
	}
	img.Pix[0] = 9
	if Signature(img) == a {
		t.Fatal("signature must notice a change")
	}
	g := WithGrid(img, 100)
	if g.Bounds() != img.Bounds() || g.Pix[(148*400+100)*4] != 255 {
		t.Fatal("grid not drawn")
	}
	if img.Pix[(148*400+100)*4+3] != 0 {
		t.Fatal("the original image must not be touched")
	}
}

func TestMissingXvfbIsExplained(t *testing.T) {
	t.Setenv("PATH", t.TempDir())
	err := New().Do(context.Background(), Options{}, func(s *Screen) error { return nil })
	if err == nil || !strings.Contains(err.Error(), "apk add xvfb") {
		t.Fatalf("%v", err)
	}
}
