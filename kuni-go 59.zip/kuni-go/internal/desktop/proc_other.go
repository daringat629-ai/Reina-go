//go:build windows

package desktop

import (
	"os"
	"os/exec"
)

func ownGroup(c *exec.Cmd) {}

func killTree(p *os.Process) {
	if p != nil {
		_ = p.Kill()
	}
}
