package desktop

import (
	"bytes"
	"image"
	"image/color"
	"image/draw"
	"image/png"
	"strconv"
)

// A 3x5 pixel font for digits: the grid labels.
var digits = [10][5]uint8{
	{7, 5, 5, 5, 7}, {2, 6, 2, 2, 7}, {7, 1, 7, 4, 7}, {7, 1, 7, 1, 7}, {5, 5, 7, 1, 1},
	{7, 4, 7, 1, 7}, {7, 4, 7, 5, 7}, {7, 1, 1, 2, 2}, {7, 5, 7, 5, 7}, {7, 5, 7, 1, 7},
}

func drawNumber(img *image.RGBA, x, y, scale int, n int) {
	bg := color.RGBA{0, 0, 0, 200}
	fg := color.RGBA{255, 255, 0, 255}
	s := strconv.Itoa(n)
	w := len(s)*4*scale + scale
	draw.Draw(img, image.Rect(x, y, x+w, y+6*scale+scale), &image.Uniform{bg}, image.Point{}, draw.Over)
	for i, ch := range s {
		g := digits[ch-'0']
		for row := 0; row < 5; row++ {
			for col := 0; col < 3; col++ {
				if g[row]&(4>>col) != 0 {
					r := image.Rect(x+scale/2+(i*4+col)*scale, y+scale/2+row*scale, x+scale/2+(i*4+col+1)*scale, y+scale/2+(row+1)*scale)
					draw.Draw(img, r, &image.Uniform{fg}, image.Point{}, draw.Src)
				}
			}
		}
	}
}

// WithGrid draws thin lines every step pixels with their coordinates, so that a vision model can name exact positions.
func WithGrid(src *image.RGBA, step int) *image.RGBA {
	img := image.NewRGBA(src.Bounds())
	copy(img.Pix, src.Pix)
	line := color.RGBA{255, 0, 80, 255}
	for xx := step; xx < img.Bounds().Dx(); xx += step {
		for y := 0; y < img.Bounds().Dy(); y++ {
			if y%4 < 2 {
				img.SetRGBA(xx, y, line)
			}
		}
	}
	for yy := step; yy < img.Bounds().Dy(); yy += step {
		for xx := 0; xx < img.Bounds().Dx(); xx++ {
			if xx%4 < 2 {
				img.SetRGBA(xx, yy, line)
			}
		}
	}
	for xx := step; xx < img.Bounds().Dx(); xx += step {
		drawNumber(img, xx+2, 2, 2, xx)
	}
	for yy := step; yy < img.Bounds().Dy(); yy += step {
		drawNumber(img, 2, yy+2, 2, yy)
	}
	return img
}

// PNG encodes the image.
func PNG(img image.Image) ([]byte, error) {
	var b bytes.Buffer
	enc := png.Encoder{CompressionLevel: png.BestSpeed}
	if err := enc.Encode(&b, img); err != nil {
		return nil, err
	}
	return b.Bytes(), nil
}

// Signature is a cheap fingerprint of a screen (every 16th pixel), equal for two unchanged screens.
func Signature(img *image.RGBA) uint64 {
	var h uint64 = 14695981039346656037
	for i := 0; i < len(img.Pix); i += 64 {
		h ^= uint64(img.Pix[i]) | uint64(img.Pix[i+1])<<8 | uint64(img.Pix[i+2])<<16
		h *= 1099511628211
	}
	return h
}
