package desktop

import (
	"encoding/binary"
	"fmt"
	"sort"
	"strings"
)

// Window is a program window on the screen.
type Window struct {
	ID                  uint32
	Title               string
	X, Y, Width, Height int
}

func (x *X) intern(name string) (uint32, error) {
	req := make([]byte, 8+(len(name)+3)&^3)
	req[0] = 16
	binary.LittleEndian.PutUint16(req[4:], uint16(len(name)))
	copy(req[8:], name)
	rep, err := x.send(req, true)
	if err != nil {
		return 0, err
	}
	return binary.LittleEndian.Uint32(rep.hdr[8:]), nil
}

func (x *X) children(w uint32) ([]uint32, error) {
	req := make([]byte, 8)
	req[0] = 15
	binary.LittleEndian.PutUint32(req[4:], w)
	rep, err := x.send(req, true)
	if err != nil {
		return nil, err
	}
	n := int(binary.LittleEndian.Uint16(rep.hdr[16:]))
	out := make([]uint32, 0, n)
	for i := 0; i < n && (i+1)*4 <= len(rep.data); i++ {
		out = append(out, binary.LittleEndian.Uint32(rep.data[i*4:]))
	}
	return out, nil
}

func (x *X) viewable(w uint32) bool {
	req := make([]byte, 8)
	req[0] = 3
	binary.LittleEndian.PutUint32(req[4:], w)
	rep, err := x.send(req, true)
	return err == nil && rep.hdr[26] == 2 // IsViewable
}

func (x *X) geometry(w uint32) (px, py, width, height int, err error) {
	req := make([]byte, 8)
	req[0] = 14
	binary.LittleEndian.PutUint32(req[4:], w)
	rep, err := x.send(req, true)
	if err != nil {
		return
	}
	return int(int16(binary.LittleEndian.Uint16(rep.hdr[12:]))), int(int16(binary.LittleEndian.Uint16(rep.hdr[14:]))),
		int(binary.LittleEndian.Uint16(rep.hdr[16:])), int(binary.LittleEndian.Uint16(rep.hdr[18:])), nil
}

func (x *X) title(w uint32, atoms []uint32) string {
	for _, a := range atoms {
		req := make([]byte, 24)
		req[0] = 20
		binary.LittleEndian.PutUint32(req[4:], w)
		binary.LittleEndian.PutUint32(req[8:], a)
		binary.LittleEndian.PutUint32(req[16:], 0)
		binary.LittleEndian.PutUint32(req[20:], 64)
		rep, err := x.send(req, true)
		if err != nil || rep.hdr[1] != 8 {
			continue
		}
		n := int(binary.LittleEndian.Uint32(rep.hdr[16:]))
		if n > 0 && n <= len(rep.data) {
			return strings.TrimSpace(string(rep.data[:n]))
		}
	}
	return ""
}

// Windows lists the visible program windows (a window manager's frames are looked through).
func (x *X) Windows() ([]Window, error) {
	netName, err := x.intern("_NET_WM_NAME")
	if err != nil {
		return nil, err
	}
	wmName, _ := x.intern("WM_NAME")
	atoms := []uint32{netName, wmName}
	top, err := x.children(x.Root)
	if err != nil {
		return nil, err
	}
	var out []Window
	for _, w := range top {
		if !x.viewable(w) {
			continue
		}
		cands := []uint32{w}
		if kids, err := x.children(w); err == nil {
			cands = append(cands, kids...)
		}
		for _, c := range cands {
			if t := x.title(c, atoms); t != "" {
				px, py, width, height, err := x.geometry(w)
				if err != nil {
					break
				}
				out = append(out, Window{ID: c, Title: t, X: px, Y: py, Width: width, Height: height})
				break
			}
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].ID < out[j].ID })
	return out, nil
}

// FormatWindows lists windows for the model.
func FormatWindows(ws []Window) string {
	if len(ws) == 0 {
		return "no windows are open"
	}
	var b strings.Builder
	for _, w := range ws {
		fmt.Fprintf(&b, "«%s» at (%d,%d) size %dx%d\n", w.Title, w.X, w.Y, w.Width, w.Height)
	}
	return b.String()
}
