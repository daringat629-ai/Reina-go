package desktop

import (
	"encoding/binary"
	"fmt"
	"strings"
	"time"
	"unicode"
)

var named = map[string]uint32{
	"enter": 0xff0d, "return": 0xff0d, "tab": 0xff09, "escape": 0xff1b, "esc": 0xff1b, "backspace": 0xff08, "delete": 0xffff, "del": 0xffff,
	"up": 0xff52, "down": 0xff54, "left": 0xff51, "right": 0xff53, "arrowup": 0xff52, "arrowdown": 0xff54, "arrowleft": 0xff51, "arrowright": 0xff53,
	"home": 0xff50, "end": 0xff57, "pageup": 0xff55, "pagedown": 0xff56, "page_up": 0xff55, "page_down": 0xff56, "insert": 0xff63,
	"space": ' ', "ctrl": 0xffe3, "control": 0xffe3, "shift": 0xffe1, "alt": 0xffe9, "super": 0xffeb, "win": 0xffeb, "meta": 0xffeb,
}

const (
	ksShift = 0xffe1
	ksCtrl  = 0xffe3
)

// keysymOf maps a key name ("Enter", "F5", "a", "я") to an X keysym.
func keysymOf(name string) (uint32, bool) {
	l := strings.ToLower(name)
	if ks, ok := named[l]; ok {
		return ks, true
	}
	if len(l) >= 2 && l[0] == 'f' {
		var n int
		if _, err := fmt.Sscanf(l[1:], "%d", &n); err == nil && n >= 1 && n <= 12 && fmt.Sprint(n) == l[1:] {
			return 0xffbe + uint32(n-1), true
		}
	}
	r := []rune(name)
	if len(r) == 1 {
		return runeKeysym(r[0]), true
	}
	return 0, false
}

func runeKeysym(r rune) uint32 {
	switch {
	case r == '\n':
		return 0xff0d
	case r == '\t':
		return 0xff09
	case r >= 0x20 && r <= 0x7e, r >= 0xa0 && r <= 0xff:
		return uint32(r)
	}
	return 0x01000000 | uint32(r)
}

// settle gives the programs time to notice a changed keyboard mapping (they re-read it when the server announces it).
const settle = 120 * time.Millisecond

// keycode finds the key for a keysym; if the layout has none, a spare key is temporarily given that keysym.
// It returns the keycode, whether Shift is needed and a function that restores the borrowed key.
func (x *X) keycode(ks uint32) (code int, shift bool, restore func(), err error) {
	if k, ok := x.keymap[ks]; ok {
		return k[0], k[1] == 1, func() {}, nil
	}
	if len(x.spareKeys) == 0 {
		return 0, false, nil, fmt.Errorf("x11: no key for symbol %#x and no spare key", ks)
	}
	spare := x.spareKeys[0]
	if err := x.mapKey(spare, ks); err != nil {
		return 0, false, nil, err
	}
	time.Sleep(settle)
	return spare, false, func() { time.Sleep(settle / 2); _ = x.mapKey(spare, 0) }, nil
}

// mapKey changes what a keycode produces (the trick xdotool uses for characters outside the layout).
func (x *X) mapKey(code int, ks uint32) error {
	req := make([]byte, 8+4*x.kpk)
	req[0], req[1] = 100, 1
	req[4], req[5] = byte(code), byte(x.kpk)
	for col := 0; col < x.kpk; col++ {
		binary.LittleEndian.PutUint32(req[8+4*col:], ks)
	}
	if _, err := x.send(req, false); err != nil {
		return err
	}
	return x.Sync()
}

func (x *X) keyEvent(code int, down bool) error {
	t := byte(3)
	if down {
		t = 2
	}
	return x.fakeInput(t, byte(code), 0, 0)
}

// TypeText types text as a person would, including characters the keyboard layout does not have (Cyrillic, emoji...):
// those are put on spare keys in batches, the programs get a moment to learn the new mapping, then the keys are typed.
func (x *X) TypeText(text string) error {
	shiftCode := x.keymap[ksShift][0]
	runes := []rune(text)
	for len(runes) > 0 {
		// take as many characters as the spare keys can hold at once
		assigned := map[uint32]int{}
		n := 0
		for n < len(runes) {
			ks := runeKeysym(runes[n])
			if _, ok := x.keymap[ks]; !ok {
				if _, done := assigned[ks]; !done {
					if len(assigned) >= len(x.spareKeys) {
						break
					}
					assigned[ks] = x.spareKeys[len(assigned)]
				}
			}
			n++
		}
		if n == 0 {
			return fmt.Errorf("x11: no spare keys for %q", string(runes[0]))
		}
		for ks, code := range assigned {
			if err := x.mapKey(code, ks); err != nil {
				return err
			}
		}
		if len(assigned) > 0 {
			time.Sleep(settle)
		}
		for _, r := range runes[:n] {
			ks := runeKeysym(r)
			code, shift := 0, false
			if k, ok := x.keymap[ks]; ok {
				code, shift = k[0], k[1] == 1
			} else {
				code = assigned[ks]
			}
			if shift && shiftCode != 0 {
				_ = x.keyEvent(shiftCode, true)
			}
			_ = x.keyEvent(code, true)
			_ = x.keyEvent(code, false)
			if shift && shiftCode != 0 {
				_ = x.keyEvent(shiftCode, false)
			}
			if err := x.Sync(); err != nil {
				return err
			}
		}
		if len(assigned) > 0 {
			time.Sleep(settle / 2) // the last keys must be read with the mapping they were typed with
			for _, code := range assigned {
				_ = x.mapKey(code, 0)
			}
		}
		runes = runes[n:]
	}
	return x.Sync()
}

// Press presses a key or a combination: "Enter", "ctrl+l", "alt+Tab", "ctrl+shift+t", "F5".
func (x *X) Press(combo string) error {
	parts := strings.Split(combo, "+")
	var codes []int
	var restores []func()
	defer func() {
		for _, r := range restores {
			r()
		}
	}()
	for i, p := range parts {
		p = strings.TrimSpace(p)
		ks, ok := keysymOf(p)
		if !ok {
			return fmt.Errorf("не знаю клавишу %q (Enter, Tab, Escape, Backspace, Delete, стрелки, Home, End, PageUp/PageDown, F1-F12, ctrl, alt, shift, super, буквы и цифры)", p)
		}
		if i == len(parts)-1 && len([]rune(p)) == 1 && unicode.IsUpper([]rune(p)[0]) && len(parts) > 1 {
			// "ctrl+L": the letter itself, ctrl does the rest
			ks = runeKeysym(unicode.ToLower([]rune(p)[0]))
		}
		code, shift, restore, err := x.keycode(ks)
		if err != nil {
			return err
		}
		restores = append(restores, restore)
		if shift {
			codes = append(codes, x.keymap[ksShift][0])
		}
		codes = append(codes, code)
	}
	for _, c := range codes {
		if err := x.keyEvent(c, true); err != nil {
			return err
		}
	}
	for i := len(codes) - 1; i >= 0; i-- {
		_ = x.keyEvent(codes[i], false)
	}
	return x.Sync()
}

// Move puts the pointer at the point.
func (x *X) Move(px, py int) error {
	if err := x.fakeInput(6, 0, px, py); err != nil {
		return err
	}
	return x.Sync()
}

// Click presses a mouse button (1 left, 2 middle, 3 right) n times at the point.
func (x *X) Click(px, py, button, n int) error {
	if err := x.Move(px, py); err != nil {
		return err
	}
	for i := 0; i < n; i++ {
		_ = x.fakeInput(4, byte(button), 0, 0)
		_ = x.fakeInput(5, byte(button), 0, 0)
		time.Sleep(40 * time.Millisecond)
	}
	return x.Sync()
}

// Drag presses the left button at the first point, moves to the second and lets go.
func (x *X) Drag(x1, y1, x2, y2 int) error {
	if err := x.Move(x1, y1); err != nil {
		return err
	}
	_ = x.fakeInput(4, 1, 0, 0)
	const steps = 8
	for i := 1; i <= steps; i++ {
		_ = x.fakeInput(6, 0, x1+(x2-x1)*i/steps, y1+(y2-y1)*i/steps)
		time.Sleep(15 * time.Millisecond)
	}
	_ = x.fakeInput(5, 1, 0, 0)
	return x.Sync()
}

// Scroll turns the wheel at the point: up or down, by clicks.
func (x *X) Scroll(px, py int, down bool, clicks int) error {
	if err := x.Move(px, py); err != nil {
		return err
	}
	b := byte(4)
	if down {
		b = 5
	}
	for i := 0; i < clicks; i++ {
		_ = x.fakeInput(4, b, 0, 0)
		_ = x.fakeInput(5, b, 0, 0)
	}
	return x.Sync()
}
