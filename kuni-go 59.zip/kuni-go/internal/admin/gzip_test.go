package admin

import (
	"compress/gzip"
	"io"
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestGzipJSONAndPlain(t *testing.T) {
	h := gzipJSON(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write([]byte(`{"a":1}`))
	})
	req := httptest.NewRequest("GET", "/", nil)
	req.Header.Set("Accept-Encoding", "gzip")
	rec := httptest.NewRecorder()
	h(rec, req)
	if rec.Header().Get("Content-Encoding") != "gzip" {
		t.Fatal("not gzipped")
	}
	zr, err := gzip.NewReader(rec.Body)
	if err != nil {
		t.Fatal(err)
	}
	b, _ := io.ReadAll(zr)
	if string(b) != `{"a":1}` {
		t.Fatalf("%s", b)
	}
	rec = httptest.NewRecorder()
	h(rec, httptest.NewRequest("GET", "/", nil))
	if rec.Header().Get("Content-Encoding") != "" || rec.Body.String() != `{"a":1}` {
		t.Fatal("plain client must get plain body")
	}
	// images pass through untouched
	img := gzipJSON(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "image/png")
		_, _ = w.Write([]byte("PNG"))
	})
	rec = httptest.NewRecorder()
	img(rec, req)
	if rec.Header().Get("Content-Encoding") != "" || rec.Body.String() != "PNG" {
		t.Fatal("media must not be compressed")
	}
}
