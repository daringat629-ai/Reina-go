package admin

import (
	"archive/zip"
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

func zipBytes(t *testing.T, files map[string][]byte) []byte {
	t.Helper()
	var b bytes.Buffer
	zw := zip.NewWriter(&b)
	for n, d := range files {
		w, _ := zw.Create(n)
		_, _ = w.Write(d)
	}
	_ = zw.Close()
	return b.Bytes()
}

func upload(p *Panel, body []byte, declared int) *httptest.ResponseRecorder {
	mux := newMux(p)
	r := httptest.NewRequest("POST", "/admin/api/update/upload", bytes.NewReader(body))
	r.ContentLength = int64(declared)
	r.RemoteAddr = "10.0.0.5:1234"
	for k, v := range auth {
		r.Header.Set(k, v)
	}
	w := httptest.NewRecorder()
	mux.ServeHTTP(w, r)
	return w
}

func TestUpdateFlowThroughThePanel(t *testing.T) {
	p, mux, _, _ := rig(t)
	bin := t.TempDir()
	_ = os.WriteFile(filepath.Join(bin, "reina-tdlib"), []byte("\x7fELFold"+strings.Repeat("o", 50)), 0o755)
	p.UpdateDir = bin
	var restarts int32
	p.Restart = func() { atomic.AddInt32(&restarts, 1) }
	_ = mux

	good := zipBytes(t, map[string][]byte{"reina-tdlib": []byte("\x7fELFnew" + strings.Repeat("n", 500))})

	// a file that stopped half way is refused, nothing is kept
	if w := upload(p, good[:len(good)/2], len(good)); w.Code != 400 || !strings.Contains(w.Body.String(), "не целиком") {
		t.Fatalf("truncated upload: %d %s", w.Code, w.Body.String())
	}
	if _, err := os.Stat(p.uploadPath()); err == nil {
		t.Fatal("a half-received file must not stay")
	}
	// a complete but broken archive is refused too
	if w := upload(p, good[:len(good)/2], len(good)/2); w.Code != 422 {
		t.Fatalf("broken archive: %d %s", w.Code, w.Body.String())
	}
	// a good one is accepted and described
	if w := upload(p, good, len(good)); w.Code != 200 {
		t.Fatalf("good upload: %d %s", w.Code, w.Body.String())
	}
	var st map[string]any
	w := do(newMux(p), "GET", "/admin/api/update", "", auth)
	_ = json.Unmarshal(w.Body.Bytes(), &st)
	if st["upload"] == nil {
		t.Fatalf("status must show the uploaded archive: %s", w.Body.String())
	}
	// install: files swapped, restart requested, nothing installed twice
	if w := do(newMux(p), "POST", "/admin/api/update/apply", "{}", auth); w.Code != 200 {
		t.Fatalf("apply: %d %s", w.Code, w.Body.String())
	}
	cur, _ := os.ReadFile(filepath.Join(bin, "reina-tdlib"))
	if !strings.HasPrefix(string(cur), "\x7fELFnew") {
		t.Fatalf("not installed: %q", cur[:8])
	}
	deadline := time.Now().Add(3 * time.Second)
	for atomic.LoadInt32(&restarts) == 0 && time.Now().Before(deadline) {
		time.Sleep(20 * time.Millisecond)
	}
	if atomic.LoadInt32(&restarts) != 1 {
		t.Fatal("the program must restart after an install")
	}
	// rollback brings the old one back and restarts again
	if w := do(newMux(p), "POST", "/admin/api/update/rollback", "{}", auth); w.Code != 200 {
		t.Fatalf("rollback: %d %s", w.Code, w.Body.String())
	}
	cur, _ = os.ReadFile(filepath.Join(bin, "reina-tdlib"))
	if !strings.HasPrefix(string(cur), "\x7fELFold") {
		t.Fatalf("not rolled back: %q", cur[:8])
	}
	if w := do(newMux(p), "POST", "/admin/api/update/rollback", "{}", auth); w.Code != 409 {
		t.Fatalf("a second rollback has nothing to restore, got %d", w.Code)
	}
}

func TestUpdateNeedsAuthAndHeader(t *testing.T) {
	p, _, _, _ := rig(t)
	if w := do(newMux(p), "POST", "/admin/api/update/apply", "{}", nil); w.Code != 401 {
		t.Fatalf("no token: %d", w.Code)
	}
	if w := do(newMux(p), "POST", "/admin/api/update/apply", "{}", map[string]string{"Authorization": "Bearer " + tok}); w.Code != 403 {
		t.Fatalf("no X-Admin header: %d", w.Code)
	}
}

func TestCleanupButton(t *testing.T) {
	p, _, _, _ := rig(t)
	if w := do(newMux(p), "POST", "/admin/api/cleanup", "{}", auth); w.Code != 400 {
		t.Fatalf("without a cleaner the button must say so: %d", w.Code)
	}
	p.Clean = func() string { return "освободила 5 МБ" }
	w := do(newMux(p), "POST", "/admin/api/cleanup", "{}", auth)
	if w.Code != 200 || !strings.Contains(w.Body.String(), "освободила 5 МБ") {
		t.Fatalf("cleanup: %d %s", w.Code, w.Body.String())
	}
}

func newMux(p *Panel) http.Handler {
	m := http.NewServeMux()
	p.Mount(m)
	return m
}

func TestCompareRunsEveryPhraseOnEveryModel(t *testing.T) {
	p, _, _, _ := rig(t)
	if w := do(newMux(p), "POST", "/admin/api/compare", `{"models":["a/b"]}`, auth); w.Code != 400 {
		t.Fatalf("without a client the tab says so: %d", w.Code)
	}
	var mu sync.Mutex
	asked := map[string]int{}
	p.Compare = func(_ context.Context, model, phrase string) (string, error) {
		mu.Lock()
		asked[model]++
		mu.Unlock()
		if model == "bad/model" {
			return "", errors.New("нет такой модели")
		}
		return model + " says: " + phrase, nil
	}
	w := do(newMux(p), "GET", "/admin/api/compare", "", auth)
	if w.Code != 200 || !strings.Contains(w.Body.String(), "ахахха") {
		t.Fatalf("get: %d %s", w.Code, w.Body.String())
	}
	w = do(newMux(p), "POST", "/admin/api/compare", `{"models":["deepseek/x"," bad/model","deepseek/x"]}`, auth)
	if w.Code != 200 {
		t.Fatalf("post: %d %s", w.Code, w.Body.String())
	}
	var out struct {
		Phrases []string
		Results []struct {
			Model   string
			Replies []struct{ Text, Error string }
		}
	}
	_ = json.Unmarshal(w.Body.Bytes(), &out)
	if len(out.Results) != 2 || len(out.Results[0].Replies) != len(out.Phrases) {
		t.Fatalf("a repeated model is asked once: %s", w.Body.String())
	}
	if !strings.Contains(out.Results[0].Replies[0].Text, "deepseek/x says") || out.Results[1].Replies[0].Error == "" {
		t.Fatalf("answers and errors must sit side by side: %+v", out.Results)
	}
	if !strings.Contains(w.Body.String(), `"verdict"`) || !strings.Contains(w.Body.String(), `"swear"`) {
		t.Fatalf("every model must come with a tone score: %s", w.Body.String())
	}
	if asked["deepseek/x"] != len(out.Phrases) {
		t.Fatalf("asked %v", asked)
	}
	for _, bad := range []string{`{"models":[]}`, `{"models":["a/b","c/d","e/f","g/h"]}`, `{"models":["x y; rm"]}`} {
		if w := do(newMux(p), "POST", "/admin/api/compare", bad, auth); w.Code != 400 {
			t.Errorf("%s must be refused, got %d", bad, w.Code)
		}
	}
}
