package admin

import (
	"bytes"
	"compress/gzip"
	"net/http"
	"strings"
	"sync"
)

// pageGz is the embedded page compressed once at first use: the panel is a big single file served on every reload.
var (
	pageGzOnce sync.Once
	pageGz     []byte
)

func gzPage() []byte {
	pageGzOnce.Do(func() {
		var b bytes.Buffer
		zw, _ := gzip.NewWriterLevel(&b, gzip.BestCompression)
		_, _ = zw.Write(page)
		_ = zw.Close()
		pageGz = b.Bytes()
	})
	return pageGz
}

func acceptsGzip(r *http.Request) bool {
	return strings.Contains(r.Header.Get("Accept-Encoding"), "gzip")
}

// gzipJSON compresses JSON/text answers of the API for clients that accept it; media and everything else pass through.
func gzipJSON(h http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if !acceptsGzip(r) || r.Header.Get("Range") != "" {
			h(w, r)
			return
		}
		gw := &gzWriter{ResponseWriter: w}
		defer gw.close()
		w.Header().Add("Vary", "Accept-Encoding")
		h(gw, r)
	}
}

type gzWriter struct {
	http.ResponseWriter
	zw      *gzip.Writer
	decided bool
	status  int
}

func (g *gzWriter) WriteHeader(code int) {
	g.status = code
	if !g.decided {
		g.decide()
	}
	g.ResponseWriter.WriteHeader(code)
}

func (g *gzWriter) decide() {
	g.decided = true
	h := g.Header()
	ct := h.Get("Content-Type")
	if (g.status == 0 || g.status == 200) && h.Get("Content-Encoding") == "" &&
		(strings.HasPrefix(ct, "application/json") || strings.HasPrefix(ct, "text/")) {
		h.Set("Content-Encoding", "gzip")
		h.Del("Content-Length")
		g.zw = gzip.NewWriter(g.ResponseWriter)
	}
}

func (g *gzWriter) Write(b []byte) (int, error) {
	if !g.decided {
		if g.Header().Get("Content-Type") == "" {
			g.Header().Set("Content-Type", http.DetectContentType(b))
		}
		g.decide()
	}
	if g.zw != nil {
		return g.zw.Write(b)
	}
	return g.ResponseWriter.Write(b)
}

func (g *gzWriter) close() {
	if g.zw != nil {
		_ = g.zw.Close()
	}
}
