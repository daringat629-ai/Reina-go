package admin

import (
	"context"
	"net/http"
	"regexp"
	"strings"
	"sync"
	"time"

	"kuni/internal/toneeval"
)

// comparePhrases are what the owner might write to her: a laugh, a greeting, an order, a jab, an open question.
var comparePhrases = []string{
	"да ахахха",
	"привет, чем занята",
	"сделай мне чай",
	"ты тупая",
	"расскажи что-нибудь про себя",
}

var modelName = regexp.MustCompile(`^[A-Za-z0-9_./:+\-@]{2,100}$`)

type compareReply struct {
	Text  string `json:"text"`
	Error string `json:"error,omitempty"`
}

type compareResult struct {
	Model   string           `json:"model"`
	Replies []compareReply   `json:"replies"`
	Score   toneeval.Summary `json:"score"`
}

// GET /admin/api/compare returns the current model and the test phrases.
// POST {models:[a,b,c]} asks each model (at most 3) the same phrases with her real prompts and shows the answers side by side.
func (p *Panel) compareAPI(w http.ResponseWriter, r *http.Request) {
	if p.Compare == nil {
		fail(w, 400, "сравнение недоступно")
		return
	}
	if r.Method != http.MethodPost {
		writeJSON(w, map[string]any{"current": p.Cfg().LLMModel, "phrases": comparePhrases})
		return
	}
	var in struct {
		Models []string `json:"models"`
	}
	if err := readBody(r, &in); err != nil {
		fail(w, 400, "bad body")
		return
	}
	var models []string
	seen := map[string]bool{}
	for _, m := range in.Models {
		m = strings.TrimSpace(m)
		if m == "" || seen[m] {
			continue
		}
		if !modelName.MatchString(m) {
			fail(w, 400, "странное имя модели: "+m)
			return
		}
		seen[m] = true
		models = append(models, m)
	}
	if len(models) == 0 || len(models) > 3 {
		fail(w, 400, "нужно от одной до трёх моделей")
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 100*time.Second)
	defer cancel()
	res := make([]compareResult, len(models))
	var wg sync.WaitGroup
	for i, m := range models {
		res[i] = compareResult{Model: m, Replies: make([]compareReply, len(comparePhrases))}
		for j, ph := range comparePhrases {
			wg.Add(1)
			go func(i, j int, m, ph string) {
				defer wg.Done()
				text, err := p.Compare(ctx, m, ph)
				if err != nil {
					res[i].Replies[j].Error = err.Error()
					return
				}
				res[i].Replies[j].Text = strings.TrimSpace(text)
			}(i, j, m, ph)
		}
	}
	wg.Wait()
	for i := range res {
		var texts []string
		for _, rp := range res[i].Replies {
			texts = append(texts, rp.Text)
		}
		res[i].Score = toneeval.Summarize(texts)
	}
	writeJSON(w, map[string]any{"phrases": comparePhrases, "results": res})
}
