package admin

import (
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"time"

	"kuni/internal/maint"
	"kuni/internal/update"
)

const maxUpload = 300 << 20

func (p *Panel) updateDir() string {
	if p.UpdateDir != "" {
		return p.UpdateDir
	}
	return update.Dir()
}

func (p *Panel) restart() {
	if p.Restart != nil {
		p.Restart()
		return
	}
	update.RequestRestart()
}

func (p *Panel) uploadPath() string { return filepath.Join(p.Cfg().DataDir, "update", "upload.zip") }

// GET /admin/api/update: what is installed now, whether a rollback is possible, what is waiting.
func (p *Panel) updateStatus(w http.ResponseWriter, r *http.Request) {
	dir := p.updateDir()
	out := map[string]any{"dir": dir, "pending": update.Pending(dir), "prev": update.Prev(dir)}
	if exe := update.Exe(); exe != "" {
		if st, err := os.Stat(exe); err == nil {
			out["exe"] = filepath.Base(exe)
			out["size"] = st.Size()
			out["built"] = st.ModTime().Format("2006-01-02 15:04")
		}
	}
	if st, err := os.Stat(p.uploadPath()); err == nil {
		if info, err := update.Inspect(p.uploadPath(), dir); err == nil {
			out["upload"] = info
			out["uploaded"] = st.ModTime().Format("15:04:05")
		}
	}
	if d, err := maint.DiskOf(dir); err == nil {
		out["free"] = d.Free
	}
	writeJSON(w, out)
}

// POST /admin/api/update/upload: the raw zip as the request body. It is saved, read end to end and described.
// A half-sent file is refused here, before anything is installed.
func (p *Panel) updateUpload(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		fail(w, 405, "POST")
		return
	}
	dir := p.updateDir()
	if r.ContentLength <= 0 || r.ContentLength > maxUpload {
		fail(w, 400, "не вижу размер файла (или он больше 300 МБ)")
		return
	}
	if d, err := maint.DiskOf(p.Cfg().DataDir); err == nil && int64(d.Free) < r.ContentLength+(30<<20) {
		fail(w, 507, "мало места на диске для загрузки: свободно "+maint.Human(d.Free))
		return
	}
	dst := p.uploadPath()
	if err := os.MkdirAll(filepath.Dir(dst), 0o755); err != nil {
		fail(w, 500, err.Error())
		return
	}
	tmp := dst + ".part"
	f, err := os.Create(tmp)
	if err != nil {
		fail(w, 500, err.Error())
		return
	}
	n, err := io.Copy(f, io.LimitReader(r.Body, maxUpload+1))
	f.Close()
	if err != nil || n != r.ContentLength {
		_ = os.Remove(tmp)
		fail(w, 400, "файл дошёл не целиком: получено "+strconv.FormatInt(n, 10)+" из "+strconv.FormatInt(r.ContentLength, 10)+" байт, попробуй ещё раз")
		return
	}
	if err := os.Rename(tmp, dst); err != nil {
		fail(w, 500, err.Error())
		return
	}
	info, err := update.Inspect(dst, dir)
	if err != nil {
		_ = os.Remove(dst)
		fail(w, 422, err.Error())
		return
	}
	writeJSON(w, map[string]any{"ok": true, "upload": info})
}

// POST /admin/api/update/apply installs the uploaded archive and restarts the program.
func (p *Panel) updateApply(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		fail(w, 405, "POST")
		return
	}
	names, err := update.Apply(p.uploadPath(), p.updateDir())
	if err != nil {
		fail(w, 422, err.Error())
		return
	}
	_ = os.Remove(p.uploadPath())
	writeJSON(w, map[string]any{"ok": true, "installed": names})
	go func() { time.Sleep(700 * time.Millisecond); p.restart() }()
}

// POST /admin/api/update/rollback brings the previous build back and restarts.
func (p *Panel) updateRollback(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		fail(w, 405, "POST")
		return
	}
	names, err := update.Rollback(p.updateDir())
	if err != nil {
		fail(w, 409, err.Error())
		return
	}
	writeJSON(w, map[string]any{"ok": true, "restored": names})
	go func() { time.Sleep(700 * time.Millisecond); p.restart() }()
}

// POST /admin/api/cleanup frees disk space (old files she sent, the tdlib cache, extra backups) and reports it.
func (p *Panel) cleanupAPI(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost || p.Clean == nil {
		fail(w, 400, "очистка недоступна")
		return
	}
	writeJSON(w, map[string]any{"ok": true, "report": p.Clean()})
}
