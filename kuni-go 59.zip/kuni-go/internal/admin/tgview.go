package admin

import (
	"bytes"
	"net/http"
	"net/url"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"kuni/internal/telegram"
)

// The Telegram view: the account's chats and messages as the panel's owner sees them in a Telegram-like window.
// Reading never marks anything read or changes anything; writing is only possible in take-over mode (tgtake.go).

type tgChat struct {
	ID       int64     `json:"id"`
	Title    string    `json:"title"`
	Kind     string    `json:"kind"`
	Unread   int       `json:"unread"`
	LastText string    `json:"last_text"`
	LastDate time.Time `json:"last_date"`
	Pinned   bool      `json:"pinned,omitempty"`
	Muted    bool      `json:"muted,omitempty"`
	Archived bool      `json:"archived,omitempty"`
	Mentions int       `json:"mentions,omitempty"`
	Typing   string    `json:"typing,omitempty"`
	TypingBy string    `json:"typing_by,omitempty"`
	Presence string    `json:"presence,omitempty"`
	LastSeen time.Time `json:"last_seen,omitempty"`
}

func toTGChat(c telegram.Chat) tgChat {
	return tgChat{ID: c.ID, Title: c.Title, Kind: string(c.Kind), Unread: c.Unread, LastText: c.LastText, LastDate: c.LastDate, Pinned: c.Pinned, Muted: c.Muted,
		Archived: c.Archived, Mentions: c.UnreadMentions, Typing: c.Typing, TypingBy: c.TypingBy, Presence: c.Presence, LastSeen: c.LastSeen}
}

type tgMsg struct {
	ID        int64     `json:"id"`
	Chat      int64     `json:"chat,omitempty"`
	ChatTitle string    `json:"chat_title,omitempty"` // search results
	Sender    string    `json:"sender"`
	SenderID  int64     `json:"sender_id"`
	Text      string    `json:"text"`
	Date      time.Time `json:"date"`
	Out       bool      `json:"out"`
	Read      bool      `json:"read,omitempty"`
	Edited    bool      `json:"edited,omitempty"`
	ReplyTo   int64     `json:"reply_to,omitempty"`
	Forward   string    `json:"forward,omitempty"`
	Media     string    `json:"media,omitempty"`
	Detail    string    `json:"detail,omitempty"`
	FileName  string    `json:"file_name,omitempty"`
	FileSize  int64     `json:"file_size,omitempty"`
	Photo     bool      `json:"photo,omitempty"` // a picture the panel can show
	File      bool      `json:"file,omitempty"`  // the media can be fetched with tg/media
	Reactions []string  `json:"reactions,omitempty"`
	Poll      *tgPoll   `json:"poll,omitempty"`

	Entities  []telegram.Entity        `json:"entities,omitempty"`
	Buttons   [][]telegram.Button      `json:"buttons,omitempty"`
	Service   string                   `json:"service,omitempty"`
	Quote     string                   `json:"quote,omitempty"`
	Album     int64                    `json:"album,omitempty"`
	Preview   *telegram.LinkPreview    `json:"preview,omitempty"`
	Place     *telegram.Place          `json:"place,omitempty"`
	Contact   string                   `json:"contact,omitempty"`
	Dice      string                   `json:"dice,omitempty"`
	Duration  int                      `json:"duration,omitempty"`
	Mime      string                   `json:"mime,omitempty"`
	Animated  bool                     `json:"animated,omitempty"`
	Title     string                   `json:"title,omitempty"`
	Views     int                      `json:"views,omitempty"`
	Forwards  int                      `json:"forwards,omitempty"`
	Replies   int                      `json:"replies,omitempty"`
	Counts    []telegram.ReactionCount `json:"counts,omitempty"`
	ViaBot    string                   `json:"via_bot,omitempty"`
	Author    string                   `json:"author,omitempty"`
	PinnedMsg int64                    `json:"pinned_msg,omitempty"`
	Thread    int64                    `json:"thread,omitempty"`
}

type tgPoll struct {
	Question  string   `json:"question"`
	Options   []string `json:"options"`
	Votes     []int    `json:"votes"`
	Chosen    []bool   `json:"chosen,omitempty"`
	Total     int      `json:"total"`
	Anonymous bool     `json:"anonymous,omitempty"`
	Multiple  bool     `json:"multiple,omitempty"`
	Closed    bool     `json:"closed,omitempty"`
}

func toTGMsg(m telegram.Message) tgMsg {
	t := tgMsg{ID: m.ID, Sender: m.SenderName, SenderID: m.SenderID, Text: m.Text, Date: m.Date, Out: m.Outgoing, Read: m.Read, Edited: m.Edited,
		ReplyTo: m.ReplyTo, Forward: m.ForwardFrom, Media: string(m.Media), Detail: m.MediaDetail, FileName: m.FileName, FileSize: m.FileSize,
		Photo: m.Media == telegram.MediaPhoto && m.FileID != "", File: m.FileID != "", Reactions: m.Reactions,
		Entities: m.Entities, Buttons: m.Buttons, Service: m.Service, Quote: m.Quote, Album: m.AlbumID, Preview: m.Preview, Place: m.Place,
		Contact: m.Contact, Dice: m.Dice, Duration: m.Duration, Mime: m.MimeType, Animated: m.Animated, Title: m.Title, Views: m.Views,
		Forwards: m.Forwards, Replies: m.Replies, Counts: m.Counts, ViaBot: m.ViaBot, Author: m.Author, PinnedMsg: m.PinnedMsg, Thread: m.ThreadID}
	if m.Poll != nil {
		pl := &tgPoll{Question: m.Poll.Question, Total: m.Poll.Total, Anonymous: m.Poll.Anonymous, Multiple: m.Poll.Multiple, Closed: m.Poll.Closed}
		for _, o := range m.Poll.Options {
			pl.Options = append(pl.Options, o.Text)
			pl.Votes = append(pl.Votes, o.Votes)
			pl.Chosen = append(pl.Chosen, o.Chosen)
		}
		t.Poll = pl
	}
	return t
}

func (p *Panel) tgOn(w http.ResponseWriter) bool {
	if p.TG == nil || !p.Cfg().PanelChats {
		fail(w, http.StatusNotFound, "the Telegram view is off (misc.panel_chats)")
		return false
	}
	return true
}

// tgChats lists the chats of the main list, the archive (folder=archive) or a folder (folder=<id>), with the folders as tabs.
func (p *Panel) tgChats(w http.ResponseWriter, r *http.Request) {
	if !p.tgOn(w) {
		return
	}
	var cs []telegram.Chat
	var err error
	rich, isRich := p.TG.(telegram.Rich)
	switch f := r.URL.Query().Get("folder"); {
	case f == "archive" && isRich:
		cs, err = rich.ChatsIn(r.Context(), telegram.ChatList{Archive: true}, 80)
	case f != "" && f != "all" && isRich:
		id, _ := strconv.Atoi(f)
		if id == 0 {
			fail(w, http.StatusBadRequest, "folder?")
			return
		}
		cs, err = rich.ChatsIn(r.Context(), telegram.ChatList{Folder: id}, 80)
	default:
		cs, err = p.TG.Chats(r.Context(), 80)
	}
	if err != nil {
		fail(w, http.StatusBadGateway, err.Error())
		return
	}
	// pinned chats first, then by the last message, as the app sorts them
	sort.SliceStable(cs, func(i, j int) bool {
		if cs[i].Pinned != cs[j].Pinned {
			return cs[i].Pinned
		}
		return cs[i].LastDate.After(cs[j].LastDate)
	})
	out := make([]tgChat, 0, len(cs))
	inArchive := r.URL.Query().Get("folder") == "archive"
	for _, c := range cs {
		if c.Archived && !inArchive && r.URL.Query().Get("folder") == "" {
			continue // the main list does not show the archive
		}
		out = append(out, toTGChat(c))
	}
	res := map[string]any{"me": p.TG.MyID(), "chats": out, "takeover": p.Cfg().PanelTakeover}
	if isRich {
		if fs, err := rich.Folders(r.Context()); err == nil {
			res["folders"] = fs
		}
	}
	writeJSON(w, res)
}

// tgHistory returns the newest n messages of a chat; before=<message id> returns the n messages older than that one.
func (p *Panel) tgHistory(w http.ResponseWriter, r *http.Request) {
	if !p.tgOn(w) {
		return
	}
	id, err := strconv.ParseInt(r.URL.Query().Get("id"), 10, 64)
	if err != nil {
		fail(w, http.StatusBadRequest, "id?")
		return
	}
	n, _ := strconv.Atoi(r.URL.Query().Get("n"))
	if n < 1 || n > 80 {
		n = 40
	}
	before, _ := strconv.ParseInt(r.URL.Query().Get("before"), 10, 64)
	around, _ := strconv.ParseInt(r.URL.Query().Get("around"), 10, 64)
	var ms []telegram.Message
	switch {
	case before != 0:
		ms, err = p.TG.History(r.Context(), id, before, n, 0)
	case around != 0:
		ms, err = p.TG.History(r.Context(), id, around, n/2, n/2)
	default:
		ms, err = p.TG.History(r.Context(), id, 0, n, 0)
	}
	if err != nil {
		fail(w, http.StatusBadGateway, err.Error())
		return
	}
	if before != 0 { // the anchor comes back too
		keep := ms[:0:0]
		for _, m := range ms {
			if m.ID < before {
				keep = append(keep, m)
			}
		}
		ms = keep
	}
	if around == 0 && len(ms) > n { // history asks for one more than n (the anchor slot)
		ms = ms[len(ms)-n:]
	}
	out := make([]tgMsg, 0, len(ms))
	for _, m := range ms {
		out = append(out, toTGMsg(m))
	}
	res := map[string]any{"messages": out, "more": before != 0 && len(out) > 0 || before == 0 && around == 0 && len(out) >= n}
	if c, err := p.TG.Chat(r.Context(), id); err == nil {
		res["chat"] = toTGChat(c)
	}
	if rich, ok := p.TG.(telegram.Rich); ok && before == 0 {
		if pm, err := rich.PinnedMessage(r.Context(), id); err == nil && pm.ID != 0 {
			res["pinned"] = toTGMsg(pm)
		}
	}
	writeJSON(w, res)
}

// tgSearch searches one chat (chat=<id>) or all of them.
func (p *Panel) tgSearch(w http.ResponseWriter, r *http.Request) {
	if !p.tgOn(w) {
		return
	}
	q := strings.TrimSpace(r.URL.Query().Get("q"))
	if q == "" {
		fail(w, http.StatusBadRequest, "q?")
		return
	}
	chat, _ := strconv.ParseInt(r.URL.Query().Get("chat"), 10, 64)
	ms, err := p.TG.Search(r.Context(), telegram.SearchQuery{Text: q, ChatID: chat, Limit: 30})
	if err != nil {
		fail(w, http.StatusBadGateway, err.Error())
		return
	}
	titles := map[int64]string{}
	out := make([]tgMsg, 0, len(ms))
	for _, m := range ms {
		t := toTGMsg(m)
		t.Chat = m.ChatID
		if _, ok := titles[m.ChatID]; !ok {
			if c, err := p.TG.Chat(r.Context(), m.ChatID); err == nil {
				titles[m.ChatID] = c.Title
			}
		}
		t.ChatTitle = titles[m.ChatID]
		out = append(out, t)
	}
	writeJSON(w, map[string]any{"messages": out})
}

const maxMedia = 25 << 20

// What the panel may serve from Telegram files. The type comes from the bytes, never from what the sender claimed:
// anything that could run in the panel's origin (html, svg, scripts) is sent as a download with a sandbox policy.
var inline = map[string]bool{"image/jpeg": true, "image/png": true, "image/gif": true, "image/webp": true,
	"video/mp4": true, "video/webm": true, "audio/ogg": true, "audio/mpeg": true, "audio/mp4": true}

func sniff(data []byte) string {
	ct := http.DetectContentType(data)
	if i := strings.Index(ct, ";"); i > 0 {
		ct = ct[:i]
	}
	if ct == "application/ogg" {
		return "audio/ogg"
	}
	if ct == "video/ogg" {
		return "audio/ogg"
	}
	// voice notes and round videos are mp4/m4a/ogg: the container is what counts
	if len(data) > 12 && string(data[4:8]) == "ftyp" {
		if m := string(data[8:12]); m == "M4A " || m == "M4B " {
			return "audio/mp4"
		}
		return "video/mp4"
	}
	return ct
}

// tgMedia serves the file of a message: pictures, stickers, videos, GIFs and voice notes inline (kind of the message decides),
// everything else only as a download (dl=1). At most 25 MB.
func (p *Panel) tgMedia(w http.ResponseWriter, r *http.Request) {
	if !p.tgOn(w) {
		return
	}
	chat, _ := strconv.ParseInt(r.URL.Query().Get("chat"), 10, 64)
	msg, _ := strconv.ParseInt(r.URL.Query().Get("msg"), 10, 64)
	dl := r.URL.Query().Get("dl") == "1"
	m, err := p.TG.Message(r.Context(), chat, msg)
	if err != nil || m.FileID == "" {
		http.NotFound(w, r)
		return
	}
	switch m.Media {
	case telegram.MediaPhoto, telegram.MediaSticker, telegram.MediaVideo, telegram.MediaVoice, telegram.MediaAudio:
	case telegram.MediaDocument:
		if !dl {
			http.NotFound(w, r)
			return
		}
	default:
		http.NotFound(w, r)
		return
	}
	if m.FileSize > maxMedia {
		http.Error(w, "file too large for the panel", http.StatusRequestEntityTooLarge)
		return
	}
	data, err := p.TG.Download(r.Context(), m.FileID)
	if err != nil || len(data) > maxMedia {
		http.NotFound(w, r)
		return
	}
	ct := sniff(data)
	h := w.Header()
	h.Set("X-Content-Type-Options", "nosniff")
	h.Set("Content-Security-Policy", "sandbox; default-src 'none'")
	h.Set("Cache-Control", "private, max-age=86400")
	if dl || !inline[ct] || (m.Media == telegram.MediaPhoto && !strings.HasPrefix(ct, "image/")) {
		if !dl {
			http.Error(w, "not a media file", http.StatusUnsupportedMediaType)
			return
		}
		name := strings.Map(func(r rune) rune {
			if r < 32 || r == '"' || r == '\\' || r == '/' || r == 127 {
				return '_'
			}
			return r
		}, m.FileName)
		if name == "" {
			name = "file"
		}
		h.Set("Content-Type", "application/octet-stream")
		h.Set("Content-Disposition", "attachment; filename*=UTF-8''"+url.PathEscape(name))
		_, _ = w.Write(data)
		return
	}
	h.Set("Content-Type", ct)
	http.ServeContent(w, r, "", time.Time{}, bytes.NewReader(data)) // Range requests: videos seek
}

var avatars = struct {
	sync.Mutex
	m map[int64]avatar
}{m: map[int64]avatar{}}

type avatar struct {
	data []byte
	at   time.Time
}

// tgAvatar serves the picture of a chat (cached for ten minutes: the list asks for all of them).
func (p *Panel) tgAvatar(w http.ResponseWriter, r *http.Request) {
	if !p.tgOn(w) {
		return
	}
	id, _ := strconv.ParseInt(r.URL.Query().Get("id"), 10, 64)
	avatars.Lock()
	a, ok := avatars.m[id]
	avatars.Unlock()
	if !ok || time.Since(a.at) > 10*time.Minute {
		data, err := p.TG.ChatPhoto(r.Context(), id)
		if err != nil {
			data = nil // no picture: remembered too, so that the list does not ask again for every refresh
		}
		a = avatar{data, time.Now()}
		avatars.Lock()
		if len(avatars.m) > 300 {
			avatars.m = map[int64]avatar{}
		}
		avatars.m[id] = a
		avatars.Unlock()
	}
	if len(a.data) == 0 {
		http.NotFound(w, r)
		return
	}
	serveImage(w, a.data, 10*time.Minute)
}

func serveImage(w http.ResponseWriter, data []byte, maxAge time.Duration) {
	ct := http.DetectContentType(data)
	switch ct {
	case "image/jpeg", "image/png", "image/gif", "image/webp":
	default:
		http.Error(w, "not an image", http.StatusUnsupportedMediaType)
		return
	}
	w.Header().Set("Content-Type", ct)
	w.Header().Set("Cache-Control", "private, max-age="+strconv.Itoa(int(maxAge.Seconds())))
	w.Header().Set("X-Content-Type-Options", "nosniff")
	_, _ = w.Write(data)
}
