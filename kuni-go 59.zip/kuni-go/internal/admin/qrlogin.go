package admin

import (
	"net/http"

	"kuni/internal/qr"
	"kuni/internal/telegram"
)

// qrLogin serves the Telegram login QR as a picture. Only the owner may see it: whoever scans this code with
// their own Telegram would sign the program in as themselves.
//
//	/admin/qr?token=<admin_token>  opens the page (and remembers the token in a cookie)
//	/admin/qr?json=1               {"waiting":bool,"done":bool}, polled by the page
//	/admin/qr?png=1                the picture
func (p *Panel) qrLogin(w http.ResponseWriter, r *http.Request) {
	if !Enabled(p.Cfg()) {
		http.NotFound(w, r)
		return
	}
	ip := clientIP(r)
	if p.blocked(ip) {
		http.Error(w, "too many attempts, try later", http.StatusTooManyRequests)
		return
	}
	if t := r.URL.Query().Get("token"); t != "" {
		if !same(t, p.Cfg().AdminToken) {
			p.fail(ip)
			http.Error(w, "wrong token", http.StatusUnauthorized)
			return
		}
		http.SetCookie(w, &http.Cookie{Name: cookieName, Value: t, Path: "/admin", HttpOnly: true, SameSite: http.SameSiteStrictMode, MaxAge: 30 * 24 * 3600})
		http.Redirect(w, r, "/admin/qr", http.StatusSeeOther)
		return
	}
	if !p.authed(r) {
		p.fail(ip)
		http.Error(w, "нужен вход: открой /admin/qr?token=<misc.admin_token>", http.StatusUnauthorized)
		return
	}
	w.Header().Set("Cache-Control", "no-store")
	link, waiting, done := telegram.LoginQR()
	switch {
	case r.URL.Query().Get("json") != "":
		writeJSON(w, map[string]any{"waiting": waiting && link != "", "done": done})
	case r.URL.Query().Get("png") != "":
		if link == "" {
			http.NotFound(w, r)
			return
		}
		c, err := qr.Encode(link, qr.M)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		w.Header().Set("Content-Type", "image/png")
		_, _ = w.Write(c.PNG(640))
	default:
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Header().Set("Content-Security-Policy", "default-src 'none'; img-src 'self'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'self'")
		_, _ = w.Write([]byte(qrPage))
	}
}

const qrPage = `<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Вход в Telegram</title>
<style>
:root{--bg:#f3f4f7;--fg:#1b1e28;--muted:#5d6475;--card:#fff;--ok:#1f7a4d;color-scheme:light}
@media (prefers-color-scheme:dark){:root{--bg:#12141a;--fg:#e7e9ef;--muted:#9aa1b3;--card:#1b1e27;--ok:#6fd3a0;color-scheme:dark}}
body{margin:0;background:var(--bg);color:var(--fg);font:16px/1.5 system-ui,sans-serif;display:flex;justify-content:center;padding:24px 16px}
main{max-width:420px;width:100%;display:flex;flex-direction:column;gap:16px;align-items:center;text-align:center}
h1{font-size:20px;margin:0}
.qr{background:#fff;padding:12px;border-radius:12px;width:100%;max-width:340px;box-sizing:border-box}
.qr img{width:100%;height:auto;display:block;image-rendering:pixelated}
ol{text-align:left;color:var(--muted);margin:0;padding-left:22px}
#st{font-weight:600}.ok{color:var(--ok)}
</style></head><body><main>
<h1>Вход Рейны в Telegram</h1>
<div class="qr" id="box" hidden><img id="img" alt="QR-код для входа в Telegram"></div>
<p id="st">Жду QR-код…</p>
<ol><li>Открой Telegram на телефоне, где вход в аккаунт Рейны</li><li>Настройки → Устройства → Подключить устройство</li><li>Наведи камеру на этот код (с другого экрана, не с того же телефона)</li></ol>
<script>
var img=document.getElementById('img'),box=document.getElementById('box'),st=document.getElementById('st'),n=0;
function tick(){fetch('/admin/qr?json=1').then(function(r){if(!r.ok)throw 0;return r.json()}).then(function(s){
 if(s.done){box.hidden=true;st.className='ok';st.textContent='✔ Вход выполнен. Эту страницу можно закрыть.';return}
 if(s.waiting){box.hidden=false;img.src='/admin/qr?png=1&n='+(n++);st.className='';st.textContent='Отсканируй код (он сам обновляется)'}
 else{box.hidden=true;st.textContent='Сейчас вход не нужен или код ещё готовится…'}
 setTimeout(tick,2500)}).catch(function(){st.textContent='Нет связи с Рейной…';setTimeout(tick,4000)})}
tick();
</script></main></body></html>`
