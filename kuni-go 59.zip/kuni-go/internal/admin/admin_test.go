package admin

import (
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"testing"
	"time"

	"kuni/internal/autonomy"
	"kuni/internal/config"
	"kuni/internal/diary"
	"kuni/internal/metrics"
	"kuni/internal/mood"
	"kuni/internal/people"
	"kuni/internal/prompts"
	"kuni/internal/usage"
	"kuni/internal/util"
)

type ctl struct {
	paused bool
	empty  bool // no open chats yet (right after a restart): the panel must still get lists, not null
}

func (c *ctl) Paused() bool     { return c.paused }
func (c *ctl) SetPaused(p bool) { c.paused = p }
func (c *ctl) SessionSummaries() []string {
	if c.empty {
		return nil
	}
	return []string{"Alex (id 1): 3 messages"}
}
func (c *ctl) QueueInfo() any {
	return map[string]any{"items": []map[string]any{{"chat_id": 5, "title": "Bob", "phase": "late"}}, "telegram": map[string]any{"flood_waits": 1, "errors": []any{}}}
}

func (c *ctl) DialogList() any {
	return []map[string]any{{"id": 5, "title": "Bob", "messages": 3}}
}
func (c *ctl) DialogMessages(id int64) (any, error) {
	if id == 9 {
		return nil, errors.New("она сейчас думает, обнови через пару секунд")
	}
	return []map[string]any{{"role": "user", "text": "hi"}, {"role": "she", "text": "➜ yo"}}, nil
}

const tok = "correct-horse-battery"

func rig(t *testing.T) (*Panel, http.Handler, *ctl, string) {
	dir := t.TempDir()
	cp := filepath.Join(dir, "config.toml")
	if _, err := config.Load(cp); err != config.ErrNeedsSetup {
		t.Fatal(err)
	}
	if err := config.SetKey(cp, "misc", "admin_token", tok); err != nil {
		t.Fatal(err)
	}
	if err := config.SetKey(cp, "misc", "data_dir", filepath.Join(dir, "data")); err != nil {
		t.Fatal(err)
	}
	// the default is relative to the working directory, i.e. this package's folder in the source tree
	if err := config.SetKey(cp, "memory", "working_memory_file", filepath.Join(dir, "data", "working_memory.md")); err != nil {
		t.Fatal(err)
	}
	h, err := config.NewHolder(cp)
	if err != nil {
		t.Fatal(err)
	}
	ps, err := prompts.NewStore(filepath.Join(dir, "prompts"), prompts.Vars{CharacterName: "R", PapikName: "P"})
	if err != nil {
		t.Fatal(err)
	}
	d, _ := diary.New(filepath.Join(dir, "diary"), nil, 0.1, 4000)
	c := &ctl{}
	p := &Panel{Cfg: h.Get, ConfigPath: cp, Prompts: ps, Diary: d, Metrics: metrics.New(), Log: util.NewLogBuf(10), Ctl: c, Started: time.Now()}
	mux := http.NewServeMux()
	p.Mount(mux)
	return p, mux, c, cp
}

func do(h http.Handler, method, path, body string, hdr map[string]string) *httptest.ResponseRecorder {
	r := httptest.NewRequest(method, path, strings.NewReader(body))
	r.RemoteAddr = "10.0.0.5:1234"
	for k, v := range hdr {
		r.Header.Set(k, v)
	}
	w := httptest.NewRecorder()
	h.ServeHTTP(w, r)
	return w
}

var auth = map[string]string{"Authorization": "Bearer " + tok, "X-Admin": "1"}

func TestDisabledWithoutToken(t *testing.T) {
	p, mux, _, cp := rig(t)
	if err := config.SetKey(cp, "misc", "admin_token", "short"); err != nil {
		t.Fatal(err)
	}
	h, _ := config.NewHolder(cp)
	p.Cfg = h.Get
	if w := do(mux, "GET", "/admin", "", nil); w.Code != 404 {
		t.Fatalf("index %d", w.Code)
	}
	if w := do(mux, "GET", "/admin/api/status", "", auth); w.Code != 404 {
		t.Fatalf("api %d", w.Code)
	}
}

func TestAuthAndCookie(t *testing.T) {
	_, mux, _, _ := rig(t)
	if w := do(mux, "GET", "/admin/api/status", "", nil); w.Code != 401 {
		t.Fatalf("want 401 got %d", w.Code)
	}
	if w := do(mux, "GET", "/admin/api/status?token="+tok, "", nil); w.Code != 401 {
		t.Fatal("token in the query string must not authorise the API")
	}
	w := do(mux, "GET", "/admin?token="+tok, "", nil)
	if w.Code != 303 || !strings.Contains(w.Header().Get("Set-Cookie"), "HttpOnly") || !strings.Contains(w.Header().Get("Set-Cookie"), "SameSite=Strict") {
		t.Fatalf("%d %v", w.Code, w.Header())
	}
	cookie := strings.Split(w.Header().Get("Set-Cookie"), ";")[0]
	if w := do(mux, "GET", "/admin/api/status", "", map[string]string{"Cookie": cookie}); w.Code != 200 {
		t.Fatalf("cookie auth %d", w.Code)
	}
	if w := do(mux, "GET", "/admin", "", nil); w.Code != 200 || !strings.Contains(w.Body.String(), "Reina") {
		t.Fatal("page not served")
	}
}

func TestCSRFHeaderRequired(t *testing.T) {
	_, mux, c, _ := rig(t)
	w := do(mux, "POST", "/admin/api/pause", `{"paused":true}`, map[string]string{"Authorization": "Bearer " + tok})
	if w.Code != 403 || c.paused {
		t.Fatalf("POST without X-Admin passed: %d", w.Code)
	}
	if w := do(mux, "POST", "/admin/api/pause", `{"paused":true}`, auth); w.Code != 200 || !c.paused {
		t.Fatalf("pause %d", w.Code)
	}
}

func TestBruteForceLockout(t *testing.T) {
	_, mux, _, _ := rig(t)
	if testing.Short() {
		t.Skip()
	}
	for i := 0; i < 8; i++ {
		do(mux, "GET", "/admin/api/status", "", map[string]string{"Authorization": "Bearer nope"})
	}
	if w := do(mux, "GET", "/admin/api/status", "", auth); w.Code != 429 {
		t.Fatalf("want 429 after 8 failures, got %d", w.Code)
	}
}

func TestConfigSecretsAreWriteOnly(t *testing.T) {
	_, mux, _, cp := rig(t)
	w := do(mux, "GET", "/admin/api/config", "", auth)
	if w.Code != 200 || strings.Contains(w.Body.String(), tok) {
		t.Fatalf("secret leaked or error: %d", w.Code)
	}
	if w := do(mux, "POST", "/admin/api/config", `{"Section":"telegram","Key":"lockdown","Value":"contacts_only"}`, auth); w.Code != 200 {
		t.Fatalf("%d %s", w.Code, w.Body)
	}
	b, _ := os.ReadFile(cp)
	if !strings.Contains(string(b), `lockdown = "contacts_only"`) {
		t.Fatal("not written")
	}
	if w := do(mux, "POST", "/admin/api/config", `{"Section":"telegram","Key":"max_tool_rounds","Value":"many"}`, auth); w.Code != 400 {
		t.Fatalf("bad value accepted: %d", w.Code)
	}
}

func TestPromptSaveAndReset(t *testing.T) {
	_, mux, _, _ := rig(t)
	if w := do(mux, "POST", "/admin/api/prompts", `{"Name":"system","Content":"hello ${PAPIK_NAME}"}`, auth); w.Code != 200 {
		t.Fatalf("%d %s", w.Code, w.Body)
	}
	w := do(mux, "GET", "/admin/api/prompts?name=system", "", auth)
	if !strings.Contains(w.Body.String(), "hello") || !strings.Contains(w.Body.String(), `"is_default":false`) {
		t.Fatal(w.Body.String())
	}
	if w := do(mux, "POST", "/admin/api/prompts", `{"Name":"system","Reset":true}`, auth); w.Code != 200 {
		t.Fatal(w.Body.String())
	}
	if w := do(mux, "GET", "/admin/api/prompts?name=system", "", auth); !strings.Contains(w.Body.String(), `"is_default":true`) {
		t.Fatal(w.Body.String())
	}
	for _, bad := range []string{`{"Name":"../../etc/passwd","Content":"x"}`, `{"Name":"nope","Content":"x"}`, `{"Name":"system","Content":"  "}`} {
		if w := do(mux, "POST", "/admin/api/prompts", bad, auth); w.Code == 200 {
			t.Fatalf("accepted %s", bad)
		}
	}
	if w := do(mux, "GET", "/admin/api/prompts?name=../../etc/passwd", "", auth); w.Code != 404 {
		t.Fatalf("traversal %d", w.Code)
	}
}

func TestMemoryDiaryShellLog(t *testing.T) {
	p, mux, _, _ := rig(t)
	if w := do(mux, "POST", "/admin/api/memory", `{"Content":"remember milk"}`, auth); w.Code != 200 {
		t.Fatal(w.Body.String())
	}
	if w := do(mux, "GET", "/admin/api/memory", "", auth); !strings.Contains(w.Body.String(), "remember milk") {
		t.Fatal(w.Body.String())
	}
	if w := do(mux, "POST", "/admin/api/diary", `{"Delete":"../x"}`, auth); w.Code != 400 {
		t.Fatalf("bad id accepted %d", w.Code)
	}
	if w := do(mux, "GET", "/admin/api/shell", "", auth); w.Code != 200 || !strings.Contains(w.Body.String(), `"lines":[]`) {
		t.Fatal(w.Body.String())
	}
	p.Log.Write([]byte("hello\nworld\n"))
	if w := do(mux, "GET", "/admin/api/log", "", auth); !strings.Contains(w.Body.String(), "world") {
		t.Fatal(w.Body.String())
	}
}

func TestStatus(t *testing.T) {
	p, mux, _, _ := rig(t)
	p.Metrics.Inc("kuni_llm_tokens_total", 120, map[string]string{"model": p.Cfg().LLMModel, "purpose": "reply", "direction": "input"})
	w := do(mux, "GET", "/admin/api/status", "", auth)
	if !strings.Contains(w.Body.String(), `"in":120`) || !strings.Contains(w.Body.String(), "Alex (id 1)") {
		t.Fatal(w.Body.String())
	}
}

func TestMoodEndpoint(t *testing.T) {
	p, mux, _, _ := rig(t)
	p.Mood = mood.New(filepath.Join(t.TempDir(), "m.json"))
	if w := do(mux, "POST", "/admin/api/mood", `{"Value":12}`, auth); w.Code != 200 || !strings.Contains(w.Body.String(), `"level":12`) {
		t.Fatalf("%d %s", w.Code, w.Body)
	}
	if w := do(mux, "POST", "/admin/api/mood", `{"Value":999}`, auth); w.Code != 400 {
		t.Fatalf("out of range accepted: %d", w.Code)
	}
	if w := do(mux, "GET", "/admin/api/status", "", auth); !strings.Contains(w.Body.String(), `"mood":{"level":12`) {
		t.Fatal(w.Body.String())
	}
}

func TestDiaryBookOrderAndFields(t *testing.T) {
	p, mux, _, _ := rig(t)
	for _, e := range []diary.Entry{
		{ID: "1760900000", Body: "second page", Meta: diary.Metadata{Confidence: 0.5}},
		{ID: "1760800000", Body: "first page <b>x</b>", Meta: diary.Metadata{Confidence: 0.9}},
		{ID: "weird", Body: "no timestamp"},
	} {
		if err := p.Diary.Save(e); err != nil {
			t.Fatal(err)
		}
	}
	w := do(mux, "GET", "/admin/api/diary?book=1", "", auth)
	if w.Code != 200 {
		t.Fatal(w.Body.String())
	}
	var got struct {
		Entries []struct {
			ID   string `json:"id"`
			Time int64  `json:"time"`
			Body string `json:"body"`
		} `json:"entries"`
	}
	if err := json.Unmarshal(w.Body.Bytes(), &got); err != nil {
		t.Fatal(err)
	}
	if len(got.Entries) != 3 {
		t.Fatalf("%+v", got)
	}
	// oldest first: numeric ids by value, then the odd one (lexical)
	if got.Entries[0].ID != "1760800000" || got.Entries[1].ID != "1760900000" || got.Entries[0].Time != 1760800000 {
		t.Fatalf("order/time: %+v", got.Entries)
	}
	if got.Entries[2].Time != 0 || got.Entries[2].Body != "no timestamp" {
		t.Fatalf("non-timestamp id: %+v", got.Entries[2])
	}
	if w := do(mux, "GET", "/admin/api/diary?book=1", "", map[string]string{}); w.Code == 200 {
		t.Fatal("book data must need auth")
	}
}

func TestAutonomyAPI(t *testing.T) {
	p, mux, _, cp := rig(t)
	dir := t.TempDir()
	p.Auto = autonomy.New(filepath.Join(dir, "a.json"), filepath.Join(dir, "a.log"))
	p.Auto.Sleep(time.Hour, "tired")
	p.Auto.Log("went to sleep until 08:00")
	w := do(mux, "GET", "/admin/api/autonomy", "", auth)
	if w.Code != 200 || !strings.Contains(w.Body.String(), `"asleep":true`) || !strings.Contains(w.Body.String(), "went to sleep") || !strings.Contains(w.Body.String(), `"enabled":false`) {
		t.Fatal(w.Body.String())
	}
	if w := do(mux, "POST", "/admin/api/autonomy", `{"wake":true}`, auth); !strings.Contains(w.Body.String(), `"asleep":false`) {
		t.Fatal(w.Body.String())
	}
	w = do(mux, "POST", "/admin/api/autonomy", `{"enabled":true}`, auth)
	if w.Code != 200 || !strings.Contains(w.Body.String(), `"enabled":true`) {
		t.Fatal(w.Body.String())
	}
	b, _ := os.ReadFile(cp)
	if !strings.Contains(string(b), "[autonomy]") || !regexp.MustCompile(`(?m)^enabled *= *true`).Match(b) {
		t.Fatalf("setting not written:\n%s", b)
	}
	if w := do(mux, "POST", "/admin/api/autonomy", `{"enabled":true}`, map[string]string{"Authorization": "Bearer " + tok}); w.Code == 200 {
		t.Fatal("POST without X-Admin must be refused")
	}
}

func TestServerAPIDiskAndBackup(t *testing.T) {
	p, mux, _, cp := rig(t)
	p.Cfg().BackupDir = filepath.Join(t.TempDir(), "bk")
	p.Cfg().BackupKeep = 2
	w := do(mux, "GET", "/admin/api/server", "", auth)
	if w.Code != 200 || !strings.Contains(w.Body.String(), `"disk"`) || !strings.Contains(w.Body.String(), `"backups":[]`) {
		t.Fatal(w.Body.String())
	}
	for i := 0; i < 3; i++ {
		w = do(mux, "POST", "/admin/api/server", `{"backup":true}`, auth)
		if w.Code != 200 || !strings.Contains(w.Body.String(), "reina-") {
			t.Fatal(w.Body.String())
		}
		time.Sleep(1100 * time.Millisecond) // file names carry seconds
	}
	es, _ := os.ReadDir(p.Cfg().BackupDir)
	if len(es) != 2 {
		t.Fatalf("keep=2, found %d", len(es))
	}
	if w := do(mux, "POST", "/admin/api/server", `{"backup":true}`, map[string]string{"Authorization": "Bearer " + tok}); w.Code == 200 {
		t.Fatal("POST without X-Admin must be refused")
	}
	_ = cp
}

func TestStatusShowsUsageAndCost(t *testing.T) {
	p, mux, _, _ := rig(t)
	p.Usage = usage.New("")
	c := p.Cfg()
	c.LLMModel, c.PriceIn, c.PriceOut, c.DailyTokenLimit = "m1", 1.0, 2.0, 5000
	p.Usage.Add("m1", 1_000_000, 500_000, 0)
	w := do(mux, "GET", "/admin/api/status", "", auth)
	body := w.Body.String()
	if !strings.Contains(body, `"usage":{`) || !strings.Contains(body, `"usd":2`) || !strings.Contains(body, `"limit":5000`) {
		t.Fatal(body)
	}
}

func TestStatusCarriesQueueInfo(t *testing.T) {
	_, h, _, _ := rig(t)
	w := do(h, "GET", "/admin/api/status", "", auth)
	var st map[string]any
	json.Unmarshal(w.Body.Bytes(), &st)
	q, _ := st["queue"].(map[string]any)
	items, _ := q["items"].([]any)
	if len(items) != 1 || items[0].(map[string]any)["title"] != "Bob" {
		t.Fatalf("queue missing in status: %s", w.Body.String())
	}
}

func TestStatusListsAreNeverNull(t *testing.T) {
	_, h, c, _ := rig(t)
	c.empty = true
	w := do(h, "GET", "/admin/api/status", "", auth)
	if !strings.Contains(w.Body.String(), `"sessions":[]`) {
		t.Fatalf("sessions must be [] not null: %s", w.Body.String())
	}
}

func TestStatusShowsRequestCountAndAveragePrompt(t *testing.T) {
	p, h, _, _ := rig(t)
	l := func(dir string) map[string]string {
		m := map[string]string{"model": p.Cfg().LLMModel, "purpose": "reply"}
		if dir != "" {
			m["direction"] = dir
		}
		return m
	}
	p.Metrics.Inc("kuni_llm_tokens_total", 3000, l("input"))
	p.Metrics.Inc("kuni_llm_calls_total", 1, l(""))
	p.Metrics.Inc("kuni_llm_calls_total", 1, l(""))
	w := do(h, "GET", "/admin/api/status", "", auth)
	var st map[string]any
	json.Unmarshal(w.Body.Bytes(), &st)
	r := st["tokens"].(map[string]any)["reply"].(map[string]any)
	if r["n"].(float64) != 2 || r["avg"].(float64) != 1500 {
		t.Fatalf("tokens row: %v", r)
	}
}

func TestStatusCarriesUsageDays(t *testing.T) {
	p, h, _, _ := rig(t)
	p.Usage = usage.New("")
	p.Usage.Add("m", 100, 10, 0)
	w := do(h, "GET", "/admin/api/status", "", auth)
	var st map[string]any
	json.Unmarshal(w.Body.Bytes(), &st)
	days, _ := st["days"].([]any)
	if len(days) != 1 || days[0].(map[string]any)["in"].(float64) != 100 {
		t.Fatalf("days missing: %s", w.Body.String())
	}
}

func TestDialogsEndpoint(t *testing.T) {
	_, h, _, _ := rig(t)
	if w := do(h, "GET", "/admin/api/dialogs", "", auth); !strings.Contains(w.Body.String(), `"title":"Bob"`) {
		t.Fatalf("list: %s", w.Body.String())
	}
	if w := do(h, "GET", "/admin/api/dialogs?id=5", "", auth); !strings.Contains(w.Body.String(), "➜ yo") {
		t.Fatalf("messages: %s", w.Body.String())
	}
	if w := do(h, "GET", "/admin/api/dialogs?id=9", "", auth); w.Code != 409 || !strings.Contains(w.Body.String(), "думает") {
		t.Fatalf("busy session: %d %s", w.Code, w.Body.String())
	}
	if w := do(h, "GET", "/admin/api/dialogs?id=x", "", auth); w.Code != 400 {
		t.Fatal("bad id")
	}
	if w := do(h, "GET", "/admin/api/dialogs", "", nil); w.Code != 401 {
		t.Fatalf("needs the token: %d", w.Code)
	}
}

func TestPeopleEndpointEditsAndDeletesCards(t *testing.T) {
	p, h, _, _ := rig(t)
	p.People = people.New(filepath.Join(t.TempDir(), "p"))
	_ = p.People.Add(7, "Joe", "likes cars", true, time.Now())
	if w := do(h, "GET", "/admin/api/people", "", auth); !strings.Contains(w.Body.String(), "likes cars") {
		t.Fatalf("%s", w.Body.String())
	}
	body := `{"id":7,"name":"Joseph","facts":[{"text":"likes boats","private":false}]}`
	w := do(h, "POST", "/admin/api/people", body, auth)
	if !strings.Contains(w.Body.String(), "likes boats") || strings.Contains(w.Body.String(), "likes cars") || p.People.Get(7).Name != "Joseph" {
		t.Fatalf("%s", w.Body.String())
	}
	if w := do(h, "POST", "/admin/api/people", `{"id":7,"facts":[]}`, auth); strings.Contains(w.Body.String(), "likes boats") || len(p.People.All()) != 0 {
		t.Fatalf("an empty card must be deleted: %s", w.Body.String())
	}
	if w := do(h, "POST", "/admin/api/people", `{"name":"x"}`, auth); w.Code != 400 {
		t.Fatal("id required")
	}
	if w := do(h, "GET", "/admin/api/people", "", auth); !strings.Contains(w.Body.String(), `"cards":[]`) {
		t.Fatalf("an empty list must be [] not null: %s", w.Body.String())
	}
}

func TestQRLoginPageNeedsTheToken(t *testing.T) {
	_, h, _, _ := rig(t)
	if w := do(h, "GET", "/admin/qr", "", nil); w.Code != 401 {
		t.Fatalf("without a token: %d", w.Code)
	}
	if w := do(h, "GET", "/admin/qr?png=1", "", nil); w.Code != 401 {
		t.Fatalf("picture without a token: %d", w.Code)
	}
	if w := do(h, "GET", "/admin/qr?json=1", "", map[string]string{"Authorization": "Bearer " + tok}); w.Code != 200 || !strings.Contains(w.Body.String(), `"waiting"`) {
		t.Fatalf("status: %d %s", w.Code, w.Body.String())
	}
	if w := do(h, "GET", "/admin/qr", "", map[string]string{"Authorization": "Bearer " + tok}); w.Code != 200 || !strings.Contains(w.Body.String(), "QR-код") {
		t.Fatalf("page: %d", w.Code)
	}
}
