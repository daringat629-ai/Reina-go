//go:build browsercheck

package admin

import (
	"net/http"
	"os"
	"testing"
	"time"
)

// go test -tags browsercheck -run TestServePanelForBrowser ./internal/admin  (serves the panel for a manual/automated look)
func TestServePanelForBrowser(t *testing.T) {
	_, mux, _, _ := rig(t)
	srv := &http.Server{Addr: "127.0.0.1:18765", Handler: mux}
	go srv.ListenAndServe()
	_ = os.WriteFile(os.Getenv("PANEL_READY"), []byte("ok"), 0o644)
	time.Sleep(90 * time.Second)
	srv.Close()
}
