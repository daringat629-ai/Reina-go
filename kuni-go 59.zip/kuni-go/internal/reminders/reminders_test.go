package reminders

import (
	"path/filepath"
	"testing"
	"time"
)

func TestParseWhen(t *testing.T) {
	loc := time.FixedZone("bsk", 6*3600)
	now := time.Date(2026, 10, 20, 10, 0, 0, 0, loc)
	cases := map[string]time.Time{
		"45m":              now.Add(45 * time.Minute),
		"2h":               now.Add(2 * time.Hour),
		"1h30m":            now.Add(90 * time.Minute),
		"+10 min":          now.Add(10 * time.Minute),
		"через 2 часа":     now.Add(2 * time.Hour),
		"1d":               now.Add(24 * time.Hour),
		"18:30":            time.Date(2026, 10, 20, 18, 30, 0, 0, loc),
		"09:00":            time.Date(2026, 10, 21, 9, 0, 0, 0, loc), // already past today: next occurrence
		"tomorrow 09:00":   time.Date(2026, 10, 21, 9, 0, 0, 0, loc),
		"завтра в 07:15":   time.Date(2026, 10, 21, 7, 15, 0, 0, loc),
		"today 23:00":      time.Date(2026, 10, 20, 23, 0, 0, 0, loc),
		"2026-10-25 12:00": time.Date(2026, 10, 25, 12, 0, 0, 0, loc),
		"2026-10-25T12:00": time.Date(2026, 10, 25, 12, 0, 0, 0, loc),
	}
	for in, want := range cases {
		got, err := ParseWhen(in, now, loc)
		if err != nil || !got.Equal(want) {
			t.Errorf("%q: got %v (%v), want %v", in, got, err, want)
		}
	}
	for _, bad := range []string{"", "soon", "25:00", "today 09:00", "2020-01-01 10:00", "0m", "999d"} {
		if _, err := ParseWhen(bad, now, loc); err == nil {
			t.Errorf("%q must fail", bad)
		}
	}
}

func TestStorePersistsDueListCancel(t *testing.T) {
	p := filepath.Join(t.TempDir(), "r.json")
	s := New(p)
	now := time.Date(2026, 10, 20, 10, 0, 0, 0, time.UTC)
	a, _ := s.Add(now.Add(time.Minute), 5, "call mom", now)
	b, _ := s.Add(now.Add(time.Hour), 5, "tea", now)
	_, _ = s.Add(now.Add(2*time.Hour), 6, "other chat", now)
	if _, err := s.Add(now, 5, " ", now); err == nil {
		t.Fatal("empty text")
	}
	s2 := New(p) // restart
	if len(s2.List(5)) != 2 || len(s2.List(0)) != 3 {
		t.Fatalf("not persisted: %+v", s2.List(0))
	}
	if s2.Cancel(a.ID, 6) {
		t.Fatal("must not cancel another chat's reminder")
	}
	if !s2.Cancel(a.ID, 5) || len(s2.List(5)) != 1 {
		t.Fatal("cancel failed")
	}
	if due := s2.Due(now.Add(30 * time.Minute)); len(due) != 0 {
		t.Fatalf("nothing due yet: %+v", due)
	}
	due := s2.Due(now.Add(90 * time.Minute))
	if len(due) != 1 || due[0].ID != b.ID {
		t.Fatalf("due: %+v", due)
	}
	if len(s2.Due(now.Add(90*time.Minute))) != 0 {
		t.Fatal("a reminder fires once")
	}
	for i := 0; i < MaxPending+5; i++ {
		_, _ = s2.Add(now.Add(time.Hour), 5, "x", now)
	}
	if len(s2.List(0)) > MaxPending {
		t.Fatal("pending reminders must be capped")
	}
}
