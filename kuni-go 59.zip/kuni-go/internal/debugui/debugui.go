// Package debugui is a small web page replacing the AUI debug window
// (KuniDebugWindow): browse diary entries, working memory, loaded prompts, and
// run an embedding query against the diary to see what would "pop up in mind".
package debugui

import (
	"fmt"
	"html"
	"net/http"
	"sort"
	"strings"

	"kuni/internal/config"
	"kuni/internal/diary"
	"kuni/internal/llm"
	"kuni/internal/memory"
)

type UI struct {
	Cfg    func() *config.Config
	Diary  *diary.Diary
	Client *llm.Client
	// Sessions, if set, returns a short description of every open session.
	Sessions func() []string
}

// Mount registers /debug and /debug/query on mux.
func (u *UI) Mount(mux *http.ServeMux) {
	mux.HandleFunc("/debug", u.index)
	mux.HandleFunc("/debug/query", u.query)
}

const page = `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Kuni debug</title><style>
body{font:15px/1.5 system-ui,sans-serif;max-width:900px;margin:0 auto;padding:16px;color:#222;background:#fff}
@media(prefers-color-scheme:dark){body{background:#16161a;color:#ddd}pre,.card{background:#202028!important}}
pre,.card{background:#f4f4f6;padding:10px;border-radius:6px;white-space:pre-wrap;word-break:break-word}
.card{margin:8px 0}.meta{color:#888;font-size:12px}input[type=text]{width:70%%;padding:6px}
</style></head><body><h1>Kuni debug</h1>%s</body></html>`

func (u *UI) index(w http.ResponseWriter, r *http.Request) {
	var b strings.Builder
	cfg := u.Cfg()
	// never print secrets
	fmt.Fprintf(&b, "<h2>Config</h2><pre>character: %s\nllm: %s (%s)\nembedding: %s\ntelegram_enabled: %v\nlockdown: %s\nproactive: %v\nsession idle: %v</pre>",
		html.EscapeString(cfg.CharacterName), html.EscapeString(cfg.LLMBaseURL), html.EscapeString(cfg.LLMModel),
		html.EscapeString(cfg.EmbeddingModel), cfg.TelegramEnabled, html.EscapeString(cfg.Lockdown), cfg.Proactive, cfg.SessionIdle)

	if u.Sessions != nil {
		b.WriteString("<h2>Open sessions</h2>")
		for _, s := range u.Sessions() {
			fmt.Fprintf(&b, "<div class=card>%s</div>", html.EscapeString(s))
		}
	}

	wm, _ := (memory.WorkingMemory{Path: cfg.WorkingMemoryFile}).Load()
	fmt.Fprintf(&b, "<h2>Working memory</h2><pre>%s</pre>", html.EscapeString(wm))

	b.WriteString(`<h2>Diary query</h2><form action="/debug/query"><input type="text" name="q" placeholder="retrieval cue"> <button>Search</button></form>`)

	entries, err := u.Diary.Load()
	if err != nil {
		fmt.Fprintf(&b, "<p>diary error: %s</p>", html.EscapeString(err.Error()))
	}
	sort.Slice(entries, func(i, j int) bool { return entries[i].ID > entries[j].ID })
	fmt.Fprintf(&b, "<h2>Diary (%d entries)</h2>", len(entries))
	for i, e := range entries {
		if i >= 100 {
			fmt.Fprintf(&b, "<p>…and %d more</p>", len(entries)-i)
			break
		}
		fmt.Fprintf(&b, "<div class=card><div class=meta>%s · confidence %.2f · embedding %d dims</div>%s</div>",
			html.EscapeString(e.ID), e.Meta.Confidence, len(e.Meta.Embedding), html.EscapeString(truncate(e.Body, 600)))
	}
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	fmt.Fprintf(w, page, b.String())
}

func (u *UI) query(w http.ResponseWriter, r *http.Request) {
	q := strings.TrimSpace(r.URL.Query().Get("q"))
	var b strings.Builder
	b.WriteString(`<p><a href="/debug">← back</a></p>`)
	fmt.Fprintf(&b, "<h2>Query: %s</h2>", html.EscapeString(q))
	if q == "" {
		b.WriteString("<p>empty query</p>")
	} else if vec, err := u.Client.Embedding(r.Context(), q); err != nil {
		fmt.Fprintf(&b, "<p>embedding error: %s</p>", html.EscapeString(err.Error()))
	} else if entries, err := u.Diary.Load(); err != nil {
		fmt.Fprintf(&b, "<p>diary error: %s</p>", html.EscapeString(err.Error()))
	} else if res, err := u.Diary.Query(r.Context(), entries, vec, u.Cfg().MaxRelatedEntries); err != nil {
		fmt.Fprintf(&b, "<p>query error: %s</p>", html.EscapeString(err.Error()))
	} else {
		for _, x := range res {
			fmt.Fprintf(&b, "<div class=card><div class=meta>%s · relatedness %.3f</div>%s</div>",
				html.EscapeString(x.Entry.ID), x.Relevance, html.EscapeString(truncate(x.Entry.Body, 800)))
		}
	}
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	fmt.Fprintf(w, page, b.String())
}

func truncate(s string, n int) string {
	r := []rune(s)
	if len(r) <= n {
		return s
	}
	return string(r[:n]) + "…"
}
