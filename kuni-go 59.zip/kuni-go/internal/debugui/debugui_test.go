package debugui

import (
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"kuni/internal/config"
	"kuni/internal/diary"
	"kuni/internal/llm"
)

func TestIndexEscapesAndHidesSecrets(t *testing.T) {
	dir := t.TempDir()
	cfg := &config.Config{CharacterName: "Kuni", LLMAPIKey: "sk-SECRET", BotToken: "123:TOKEN", WorkingMemoryFile: filepath.Join(dir, "wm.md"), LLMBaseURL: "http://x/"}
	d, _ := diary.New(filepath.Join(dir, "diary"), llm.New("", "", "", "", "", time.Second), 0, 100)
	d.Save(diary.Entry{ID: "1", Body: "<script>alert(1)</script>"})
	u := &UI{Cfg: func() *config.Config { return cfg }, Diary: d, Client: llm.New("", "", "", "", "", time.Second)}
	mux := http.NewServeMux()
	u.Mount(mux)
	rec := httptest.NewRecorder()
	mux.ServeHTTP(rec, httptest.NewRequest("GET", "/debug", nil))
	body := rec.Body.String()
	if strings.Contains(body, "<script>alert") {
		t.Fatalf("diary body not escaped: %s", body)
	}
	if strings.Contains(body, "sk-SECRET") || strings.Contains(body, "TOKEN") {
		t.Fatalf("secret leaked into debug page")
	}
	if !strings.Contains(body, "&lt;script&gt;") {
		t.Fatalf("entry missing")
	}
}
