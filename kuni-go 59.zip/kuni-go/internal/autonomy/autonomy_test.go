package autonomy

import (
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func newState(t *testing.T) (*State, *time.Time) {
	dir := t.TempDir()
	s := New(filepath.Join(dir, "a.json"), filepath.Join(dir, "a.log"))
	now := time.Date(2026, 10, 19, 12, 0, 0, 0, time.UTC)
	s.now = func() time.Time { return now }
	return s, &now
}

func TestQuietHoursWrapAndZone(t *testing.T) {
	bishkek := time.FixedZone("B", 6*3600)
	at := func(h, m int) time.Time { return time.Date(2026, 10, 19, h, m, 0, 0, bishkek) }
	cases := []struct {
		h, m int
		want bool
	}{{0, 30, false}, {1, 0, true}, {3, 0, true}, {8, 59, true}, {9, 0, false}, {23, 0, false}}
	for _, c := range cases {
		if got := InQuietHours(at(c.h, c.m), "01:00", "09:00", bishkek); got != c.want {
			t.Errorf("%02d:%02d = %v", c.h, c.m, got)
		}
	}
	if !InQuietHours(at(23, 30), "23:00", "07:00", bishkek) || !InQuietHours(at(2, 0), "23:00", "07:00", bishkek) || InQuietHours(at(12, 0), "23:00", "07:00", bishkek) {
		t.Error("window across midnight")
	}
	// the same instant, judged in another zone
	utc := time.Date(2026, 10, 19, 20, 0, 0, 0, time.UTC) // 02:00 in Bishkek
	if !InQuietHours(utc, "01:00", "09:00", bishkek) || InQuietHours(utc, "01:00", "09:00", time.UTC) {
		t.Error("zone must be applied")
	}
	if InQuietHours(at(3, 0), "", "", bishkek) || InQuietHours(at(3, 0), "bad", "09:00", bishkek) || InQuietHours(at(3, 0), "05:00", "05:00", bishkek) {
		t.Error("empty or malformed means never quiet")
	}
}

func TestDailyCapCooldownAndOwnerExemption(t *testing.T) {
	s, now := newState(t)
	lim := Limits{MaxPerDay: 2, ChatCooldown: 90 * time.Minute}
	if ok, _ := s.Allow(1, lim, false); !ok {
		t.Fatal("first message must be allowed")
	}
	s.RecordSend(1, "Ann", "hi", false)
	if ok, why := s.Allow(1, lim, false); ok || !strings.Contains(why, "minutes ago") {
		t.Fatalf("cooldown: %v %q", ok, why)
	}
	if ok, _ := s.Allow(2, lim, false); !ok {
		t.Fatal("another chat is fine")
	}
	s.RecordSend(2, "Bob", "yo", false)
	if ok, why := s.Allow(3, lim, false); ok || !strings.Contains(why, "daily limit") {
		t.Fatalf("cap: %v %q", ok, why)
	}
	if ok, _ := s.Allow(3, lim, true); !ok {
		t.Fatal("the owner is never limited")
	}
	s.RecordSend(5, "Owner", "hey", true)
	if s.SentToday() != 2 {
		t.Fatalf("exempt sends must not count: %d", s.SentToday())
	}
	*now = now.Add(24 * time.Hour) // a new day resets the counter and the cooldown has passed
	if ok, _ := s.Allow(1, lim, false); !ok || s.SentToday() != 0 {
		t.Fatal("new day")
	}
}

func TestSleepWakeAndPersistence(t *testing.T) {
	s, now := newState(t)
	until := s.Sleep(5*time.Minute, "tired") // clamped up to 20 min
	if until.Sub(*now) != 20*time.Minute {
		t.Fatalf("clamp low: %v", until.Sub(*now))
	}
	if a, _ := s.Asleep(); !a {
		t.Fatal("should be asleep")
	}
	if u := s.Sleep(99*time.Hour, ""); u.Sub(*now) != 12*time.Hour {
		t.Fatalf("clamp high: %v", u.Sub(*now))
	}
	s2 := New(s.path, s.logPath)
	s2.now = s.now
	if a, _ := s2.Asleep(); !a {
		t.Fatal("sleep must survive a restart")
	}
	s.Wake()
	if a, _ := s.Asleep(); a {
		t.Fatal("wake")
	}
	*now = now.Add(time.Hour)
	if a, _ := s2.Asleep(); a == false {
		t.Log("(s2 was loaded before wake; its own clock moved on)")
	}
}

func TestJournal(t *testing.T) {
	s, _ := newState(t)
	s.RecordSend(1, "Ann", "line one\nline two", false)
	s.Log("went to sleep until 08:00")
	got := s.Recent(5)
	if len(got) != 2 || !strings.Contains(got[0], "wrote to Ann: line one line two") || !strings.Contains(got[1], "went to sleep") {
		t.Fatalf("%q", got)
	}
	if len(s.Recent(1)) != 1 {
		t.Fatal("limit")
	}
	var nilState *State
	nilState.Log("x")
	nilState.RecordSend(1, "a", "b", false)
	if ok, _ := nilState.Allow(1, Limits{}, false); !ok {
		t.Fatal("a nil state imposes nothing")
	}
}
