package maint

import (
	"archive/tar"
	"compress/gzip"
	"io"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func write(t *testing.T, p, body string) {
	t.Helper()
	if err := os.MkdirAll(filepath.Dir(p), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(p, []byte(body), 0o644); err != nil {
		t.Fatal(err)
	}
}

func TestDiskThresholds(t *testing.T) {
	if !(Disk{Free: 1 << 30, Total: 20 << 30}).Low(10) { // 5%
		t.Fatal("5% free is low")
	}
	if (Disk{Free: 8 << 30, Total: 20 << 30}).Low(10) {
		t.Fatal("40% free is fine")
	}
	if !(Disk{Free: 100 << 20, Total: 1 << 40}).Low(1) {
		t.Fatal("under 500 MB is always low")
	}
	if (Disk{}).Low(10) {
		t.Fatal("unknown disk is not an alarm")
	}
	d, err := DiskOf(t.TempDir())
	if err != nil || d.Total == 0 {
		t.Fatalf("real statfs: %+v %v", d, err)
	}
	if Human(3<<30) != "3.0 ГБ" || Human(512<<20) != "512 МБ" {
		t.Fatal(Human(3<<30), Human(512<<20))
	}
}

func TestCleanOldKeepsFresh(t *testing.T) {
	dir := t.TempDir()
	old, fresh := filepath.Join(dir, "a", "old.md"), filepath.Join(dir, "fresh.md")
	write(t, old, "0123456789")
	write(t, fresh, "x")
	past := time.Now().Add(-40 * 24 * time.Hour)
	_ = os.Chtimes(old, past, past)
	n, b := CleanOld(dir, 30*24*time.Hour, time.Now())
	if n != 1 || b != 10 {
		t.Fatalf("%d files %d bytes", n, b)
	}
	if _, err := os.Stat(fresh); err != nil {
		t.Fatal("a fresh file must stay")
	}
	if _, err := os.Stat(old); err == nil {
		t.Fatal("old file must go")
	}
}

func TestBackupContentsPrivacyAndRotation(t *testing.T) {
	root := t.TempDir()
	write(t, filepath.Join(root, "data", "diary", "1.md"), "entry one")
	write(t, filepath.Join(root, "data", "mood.json"), `{"level":40}`)
	write(t, filepath.Join(root, "config.toml"), "api_key = \"secret\"")
	bdir := filepath.Join(root, "data", "backups")
	srcs := []string{filepath.Join(root, "data", "diary"), filepath.Join(root, "data", "mood.json"), filepath.Join(root, "config.toml"), filepath.Join(root, "missing"), filepath.Join(root, "data")}
	now := time.Date(2026, 10, 19, 3, 0, 0, 0, time.UTC)
	var last string
	for i := 0; i < 4; i++ {
		p, err := Backup(srcs, bdir, 3, now.Add(time.Duration(i)*time.Hour))
		if err != nil {
			t.Fatal(err)
		}
		_ = os.Chtimes(p, now.Add(time.Duration(i)*time.Hour), now.Add(time.Duration(i)*time.Hour))
		last = p
	}
	if got := Backups(bdir); len(got) != 3 || filepath.Join(bdir, got[0].Name) != last {
		t.Fatalf("rotation keeps the newest 3: %+v", got)
	}
	if st, _ := os.Stat(last); st.Mode().Perm() != 0o600 {
		t.Fatalf("archive holds keys, must be 0600: %v", st.Mode())
	}
	f, _ := os.Open(last)
	defer f.Close()
	gz, err := gzip.NewReader(f)
	if err != nil {
		t.Fatal(err)
	}
	tr := tar.NewReader(gz)
	names := map[string]string{}
	for {
		h, err := tr.Next()
		if err == io.EOF {
			break
		}
		if err != nil {
			t.Fatal(err)
		}
		b, _ := io.ReadAll(tr)
		names[h.Name] = string(b)
	}
	if names["diary/1.md"] != "entry one" || names["mood.json"] != `{"level":40}` || !strings.Contains(names["config.toml"], "secret") {
		t.Fatalf("contents: %v", names)
	}
	for n := range names {
		if strings.Contains(n, "backups") || strings.HasSuffix(n, ".part") {
			t.Fatalf("a backup must not contain backups: %s", n)
		}
	}
	// no half-written archive is left behind
	es, _ := os.ReadDir(bdir)
	for _, e := range es {
		if strings.HasSuffix(e.Name(), ".part") {
			t.Fatal("temp file left")
		}
	}
}

func TestParseDUPicksTheBiggestAndSkipsRoot(t *testing.T) {
	out := "100\t/mari/a\n5000\t/mari/big dir\n20\t/mari/c\n6000\t/mari\n"
	got := ParseDU(out, "/mari", 2)
	if len(got) != 2 || got[0].Path != "/mari/big dir" || got[0].Bytes != 5000<<10 || got[1].Path != "/mari/a" {
		t.Fatalf("%+v", got)
	}
}
