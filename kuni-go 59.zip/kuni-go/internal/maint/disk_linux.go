//go:build linux

package maint

import (
	"os"
	"path/filepath"
	"syscall"
)

// DiskOf returns free and total bytes of the filesystem holding path.
func DiskOf(path string) (Disk, error) {
	var st syscall.Statfs_t
	for { // a data dir that does not exist yet lives on its nearest existing parent's filesystem
		if _, err := os.Stat(path); err == nil || filepath.Dir(path) == path {
			break
		}
		path = filepath.Dir(path)
	}
	if err := syscall.Statfs(path, &st); err != nil {
		return Disk{}, err
	}
	return Disk{Free: st.Bavail * uint64(st.Bsize), Total: st.Blocks * uint64(st.Bsize)}, nil
}
