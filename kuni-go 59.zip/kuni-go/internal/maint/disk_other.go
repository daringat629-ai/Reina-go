//go:build !linux

package maint

import "errors"

// DiskOf is only implemented on Linux (where she lives).
func DiskOf(string) (Disk, error) {
	return Disk{}, errors.New("disk space is not available on this OS")
}
