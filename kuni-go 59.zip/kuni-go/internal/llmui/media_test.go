package llmui

import (
	"context"
	"fmt"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"kuni/internal/media"
	"kuni/internal/telegram"
)

type countingSTT struct{ n atomic.Int32 }

func (c *countingSTT) Transcribe(context.Context, []byte, string) (string, error) {
	c.n.Add(1)
	time.Sleep(20 * time.Millisecond)
	return "hello there", nil
}

// The history is rendered on every turn: a voice message goes to speech recognition once, not each time, and two
// sessions rendering it at once share the one transcription.
func TestVoiceTranscriptIsKept(t *testing.T) {
	e, tg := newEnv(t)
	stt := &countingSTT{}
	svc := e.Media()
	svc.STT = stt
	e.Media = func() media.Services { return svc }
	tg.Files["V"] = []byte("ogg")
	m := telegram.Message{ID: 2, SenderName: "x", Media: telegram.MediaVoice, FileID: "V", Date: time.Now()}
	var wg sync.WaitGroup
	for range 4 {
		wg.Add(1)
		go func() {
			defer wg.Done()
			if out := e.FormatMessage(context.Background(), m, time.Now()); !strings.Contains(out, "hello there") {
				t.Errorf("got %s", out)
			}
		}()
	}
	wg.Wait()
	e.FormatMessage(context.Background(), m, time.Now())
	if n := stt.n.Load(); n != 1 {
		t.Fatalf("transcribed %d times", n)
	}
}

func TestDataURLKnowsTheImageType(t *testing.T) {
	webp := append([]byte("RIFF\x00\x00\x00\x00WEBPVP8 "), make([]byte, 16)...)
	png := append([]byte("\x89PNG\r\n\x1a\n"), make([]byte, 16)...)
	for b, want := range map[string]string{string(webp): "image/webp", string(png): "image/png", "\xff\xd8\xff\xe0xxxx": "image/jpeg"} {
		if got := DataURL([]byte(b)); !strings.HasPrefix(got, "data:"+want+";base64,") {
			t.Errorf("%q: %s", want, got[:30])
		}
	}
	if isImage([]byte(`{"tgs":1}`)) || !isImage(webp) {
		t.Fatal("isImage")
	}
}

func TestFormatChatCutsByRunes(t *testing.T) {
	out := FormatChat(telegram.Chat{ID: 1, Title: "x", LastText: strings.Repeat("я", 100), LastDate: time.Now()}, time.Now())
	if !strings.Contains(out, strings.Repeat("я", 80)+"…") || strings.ContainsRune(out, '\uFFFD') {
		t.Fatalf("preview broken: %s", out)
	}
}

// Messages with media are rendered side by side and come out in their order.
func TestFormatMessagesKeepsOrder(t *testing.T) {
	e, tg := newEnv(t)
	svc := e.Media()
	svc.STT = &countingSTT{}
	e.Media = func() media.Services { return svc }
	var msgs []telegram.Message
	for i := range 6 {
		id := fmt.Sprint("F", i)
		tg.Files[id] = []byte("ogg")
		msgs = append(msgs, telegram.Message{ID: int64(i + 1), SenderName: "x", Media: telegram.MediaVoice, FileID: id, Date: time.Now()})
	}
	out := e.FormatMessages(context.Background(), msgs, time.Now())
	last := -1
	for i := range 6 {
		p := strings.Index(out, fmt.Sprintf(`message_id="%d"`, i+1))
		if p < last {
			t.Fatalf("order broken at %d:\n%s", i+1, out)
		}
		last = p
	}
}
