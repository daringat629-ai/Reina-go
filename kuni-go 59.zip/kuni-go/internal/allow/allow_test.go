package allow

import (
	"path/filepath"
	"reflect"
	"testing"
)

func TestStoreAndParse(t *testing.T) {
	p := filepath.Join(t.TempDir(), "x", "allow.json")
	s := New(p)
	s.Add(5, "Ann")
	s.Add(5, "") // again: nothing changes
	s.Add(6, "Bob")
	if !s.Has(5) || s.Has(7) || s.Has(0) || len(s.List()) != 2 {
		t.Fatal(s.List())
	}
	if s2 := New(p); !s2.Has(6) || s2.List()[0].Name != "Ann" {
		t.Fatal("not persisted")
	}
	if !s.Remove(5) || s.Remove(5) || s.Has(5) {
		t.Fatal("remove")
	}
	var n *Store
	if n.Has(1) || n.List() != nil {
		t.Fatal("nil store")
	}
	if got := ParseIDs("12, 34;@56 x -7 0 78"); !reflect.DeepEqual(got, []int64{12, 34, 56, 78}) {
		t.Fatal(got)
	}
}
