// Package allow is the white list of people (besides the owner) who may use her slash commands in Telegram.
// It lives in a small JSON file so that she can edit it on the owner's word; the owner can also list ids by hand in
// config.toml (telegram.command_users).
package allow

import (
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"kuni/internal/store"
)

// Entry is one allowed person.
type Entry struct {
	ID    int64     `json:"id"`
	Name  string    `json:"name,omitempty"`
	Added time.Time `json:"added"`
}

// Store is the list; a nil *Store allows nobody.
type Store struct {
	mu      sync.Mutex
	path    string
	Entries []Entry `json:"entries"`
	saver   store.Saver
}

// file is the on-disk shape of the list.
type file struct {
	Entries []Entry `json:"entries"`
}

// New loads the list (a missing or broken file is an empty list).
func New(path string) *Store {
	s := &Store{path: path, saver: store.Saver{What: "allow"}}
	var f file
	if store.Load("allow", path, &f) {
		s.Entries = f.Entries
	}
	return s
}

func (s *Store) save() { _ = s.saver.Save(s.path, file{Entries: s.Entries}) }

// Add puts a person on the list (again = only the name changes).
func (s *Store) Add(id int64, name string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	for i, e := range s.Entries {
		if e.ID == id {
			if name != "" {
				s.Entries[i].Name = name
				s.save()
			}
			return
		}
	}
	s.Entries = append(s.Entries, Entry{ID: id, Name: name, Added: time.Now()})
	s.save()
}

// Remove takes a person off; false = they were not on it.
func (s *Store) Remove(id int64) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	for i, e := range s.Entries {
		if e.ID == id {
			s.Entries = append(s.Entries[:i], s.Entries[i+1:]...)
			s.save()
			return true
		}
	}
	return false
}

// Has says whether the person is on the list.
func (s *Store) Has(id int64) bool {
	if s == nil || id == 0 {
		return false
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	for _, e := range s.Entries {
		if e.ID == id {
			return true
		}
	}
	return false
}

// List is everybody on the list, in the order they were added.
func (s *Store) List() []Entry {
	if s == nil {
		return nil
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	out := append([]Entry(nil), s.Entries...)
	sort.Slice(out, func(i, j int) bool { return out[i].Added.Before(out[j].Added) })
	return out
}

// ParseIDs reads "123, 456;789" (ids separated by commas, semicolons or spaces); junk is skipped.
func ParseIDs(s string) []int64 {
	var out []int64
	for _, f := range strings.FieldsFunc(s, func(r rune) bool { return r == ',' || r == ';' || r == ' ' || r == '\n' || r == '\t' }) {
		if id, err := strconv.ParseInt(strings.TrimPrefix(f, "@"), 10, 64); err == nil && id > 0 {
			out = append(out, id)
		}
	}
	return out
}
