package chart

import (
	"bytes"
	"context"
	"encoding/xml"
	"image/png"
	"io"
	"math"
	"os"
	"strings"
	"testing"
)

func wellFormed(t *testing.T, s string) {
	t.Helper()
	d := xml.NewDecoder(strings.NewReader(s))
	for {
		if _, err := d.Token(); err == io.EOF {
			return
		} else if err != nil {
			t.Fatalf("not well-formed SVG: %v", err)
		}
	}
}

func TestFromRows(t *testing.T) {
	c, err := FromRows([][]string{{"Месяц", "Еда", "Такси"}, {"Январь", "1 200,5", "300"}, {"Февраль", "900", ""}, {"Март", "15%", "abc"}}, "bar")
	if err != nil {
		t.Fatal(err)
	}
	if len(c.Labels) != 3 || c.Labels[1] != "Февраль" || len(c.Series) != 2 || c.Series[0].Name != "Еда" || c.Series[0].Values[0] != 1200.5 || c.Series[0].Values[2] != 15 {
		t.Fatalf("%+v", c)
	}
	if !math.IsNaN(c.Series[1].Values[1]) || !math.IsNaN(c.Series[1].Values[2]) {
		t.Fatal("blanks and text must be gaps")
	}
	c, _ = FromRows([][]string{{"Год", "Выручка"}, {"2023", "10"}, {"2024", "12"}}, "line")
	if c.Labels[0] != "2023" || len(c.Series) != 1 {
		t.Fatalf("years are labels: %+v", c)
	}
	c, _ = FromRows([][]string{{"3"}, {"5"}, {"4"}}, "line")
	if len(c.Series) != 1 || len(c.Series[0].Values) != 3 || c.Labels[2] != "3" {
		t.Fatalf("one column of numbers: %+v", c)
	}
	if _, err := FromRows([][]string{{"a", "b"}, {"x", "y"}}, "bar"); err == nil {
		t.Fatal("no numbers must be an error")
	}
}

func TestSVGKinds(t *testing.T) {
	base := Chart{Title: "Расходы <за> месяц", YLabel: "сом", Labels: []string{"Еда", "Такси", "Кафе", "Связь"},
		Series: []Series{{Name: "Октябрь", Values: []float64{12000, 3500, math.NaN(), 800}}, {Name: "Ноябрь", Values: []float64{11000, -200, 4000, 800}}}}
	for _, k := range Kinds {
		c := base
		c.Kind = k
		svg, err := c.SVG()
		if err != nil {
			t.Fatal(k, err)
		}
		wellFormed(t, svg)
		if !strings.Contains(svg, "Расходы &lt;за&gt; месяц") {
			t.Errorf("%s: title not escaped", k)
		}
		if k != "pie" && !strings.Contains(svg, "Ноябрь") {
			t.Errorf("%s: no legend", k)
		}
	}
	if _, err := (Chart{}).SVG(); err == nil {
		t.Fatal("an empty chart must be an error")
	}
}

func TestNumbersAndTicks(t *testing.T) {
	for v, want := range map[float64]string{1234567: "1,2 млн", 12500: "12 500", 3.14159: "3,14", 42.26: "42,3", -7: "−7", 0: "0", 1000: "1000"} {
		if got := Num(v); got != want {
			t.Errorf("Num(%v) = %q, want %q", v, got, want)
		}
	}
	ts := ticks(0, 13700, 6)
	if ts[0] != 0 || ts[len(ts)-1] < 13700 || ts[1] != 2500 {
		t.Fatalf("ticks %v", ts)
	}
}

// With a renderer at hand (Chromium here), the chart becomes a real picture.
func TestRenderPNG(t *testing.T) {
	browser := ""
	for _, p := range []string{os.Getenv("CHART_BROWSER"), "/opt/pw-browsers/chromium-1194/chrome-linux/chrome"} {
		if p != "" {
			if _, err := os.Stat(p); err == nil {
				browser = p
				break
			}
		}
	}
	c := Chart{Kind: "bar", Title: "Тест", Labels: []string{"a", "b"}, Series: []Series{{Name: "x", Values: []float64{1, 2}}}}
	svg, _ := c.SVG()
	out, err := Render(context.Background(), svg, 1000, 600, browser)
	if err == ErrNoRenderer {
		t.Skip("no renderer on this machine")
	}
	if err != nil {
		t.Fatal(err)
	}
	img, err := png.Decode(bytes.NewReader(out))
	if err != nil {
		t.Fatal(err)
	}
	if b := img.Bounds(); b.Dx() < 1000 || b.Dy() < 600 {
		t.Fatalf("picture %v", b)
	}
	if dir := os.Getenv("CHART_OUT"); dir != "" { // for a look by eye
		for _, k := range Kinds {
			c := Chart{Kind: k, Title: "Расходы за октябрь", YLabel: "сом", Labels: []string{"Еда", "Такси", "Кафе и рестораны", "Связь", "Спорт"},
				Series: []Series{{Name: "Октябрь", Values: []float64{12000, 3500, 6100, 800, 2500}}, {Name: "Ноябрь", Values: []float64{11000, 2900, 4000, 800, 3000}}}}
			if k == "pie" {
				c.Series = c.Series[:1]
			}
			svg, _ := c.SVG()
			b, err := Render(context.Background(), svg, 1000, 600, browser)
			if err != nil {
				t.Fatal(err)
			}
			os.WriteFile(dir+"/"+k+".png", b, 0o644)
		}
	}
}
