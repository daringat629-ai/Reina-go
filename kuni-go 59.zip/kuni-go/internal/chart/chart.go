// Package chart draws charts (line, area, bar, horizontal bar, pie) as SVG and turns them into PNG with whatever
// renderer the machine has: headless Chromium (the one her browser uses), rsvg-convert or ImageMagick.
package chart

import (
	"fmt"
	"html"
	"math"
	"strconv"
	"strings"
)

// Series is one line, one set of bars or the slices of a pie. A NaN value is missing (a gap in a line).
type Series struct {
	Name   string
	Values []float64
}

// Chart is what to draw.
type Chart struct {
	Kind   string // line, area, bar, hbar, pie
	Title  string
	XLabel string
	YLabel string
	Labels []string // categories / points on the x axis (slices of a pie)
	Series []Series
	Width  int // default 1000
	Height int // default 600
}

// Kinds the package draws.
var Kinds = []string{"line", "area", "bar", "hbar", "pie"}

var palette = []string{"#4C78A8", "#F58518", "#54A24B", "#E45756", "#72B7B2", "#EECA3B", "#B279A2", "#FF9DA6", "#9D755D", "#BAB0AC"}

const font = `font-family="DejaVu Sans, Noto Sans, Liberation Sans, Arial, sans-serif"`

// SVG draws the chart.
func (c Chart) SVG() (string, error) {
	if c.Width <= 0 {
		c.Width = 1000
	}
	if c.Height <= 0 {
		c.Height = 600
	}
	if len(c.Series) == 0 {
		return "", fmt.Errorf("no data to draw")
	}
	n := 0
	for _, s := range c.Series {
		n = max(n, len(s.Values))
	}
	if n == 0 {
		return "", fmt.Errorf("no values to draw")
	}
	for len(c.Labels) < n {
		c.Labels = append(c.Labels, strconv.Itoa(len(c.Labels)+1))
	}
	var b strings.Builder
	fmt.Fprintf(&b, `<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" viewBox="0 0 %d %d" %s>`, c.Width, c.Height, c.Width, c.Height, font)
	fmt.Fprintf(&b, `<rect width="100%%" height="100%%" fill="#ffffff"/>`)
	top := 30
	if c.Title != "" {
		fmt.Fprintf(&b, `<text x="%d" y="38" text-anchor="middle" font-size="24" font-weight="bold" fill="#1d1d1f">%s</text>`, c.Width/2, esc(c.Title))
		top = 64
	}
	switch strings.ToLower(c.Kind) {
	case "pie", "donut":
		c.pie(&b, top)
	case "hbar":
		c.hbar(&b, top, n)
	case "bar", "column":
		c.axes(&b, top, n, true)
	default: // line, area
		c.axes(&b, top, n, false)
	}
	b.WriteString(`</svg>`)
	return b.String(), nil
}

func esc(s string) string { return html.EscapeString(s) }

// legend draws the series names in a row under the title; it returns the height it took.
func (c Chart) legend(b *strings.Builder, y int) int {
	if len(c.Series) < 2 {
		return 0
	}
	x := 60
	for i, s := range c.Series {
		w := 34 + 9*len([]rune(s.Name))
		if x+w > c.Width-20 {
			x = 60
			y += 24
		}
		fmt.Fprintf(b, `<rect x="%d" y="%d" width="16" height="16" rx="3" fill="%s"/>`, x, y-13, color(i))
		fmt.Fprintf(b, `<text x="%d" y="%d" font-size="15" fill="#333">%s</text>`, x+22, y, esc(s.Name))
		x += w
	}
	return y + 16
}

func color(i int) string { return palette[i%len(palette)] }

// span returns the range of all values (with 0 when a bar chart, which must start at zero).
func (c Chart) span(withZero bool) (lo, hi float64) {
	lo, hi = math.Inf(1), math.Inf(-1)
	for _, s := range c.Series {
		for _, v := range s.Values {
			if !math.IsNaN(v) {
				lo, hi = math.Min(lo, v), math.Max(hi, v)
			}
		}
	}
	if math.IsInf(lo, 1) {
		return 0, 1
	}
	if withZero {
		lo, hi = math.Min(lo, 0), math.Max(hi, 0)
	}
	if lo == hi {
		lo, hi = lo-1, hi+1
	}
	return lo, hi
}

// ticks are round numbers covering [lo, hi]: 1, 2, 2.5 or 5 times a power of ten apart.
func ticks(lo, hi float64, want int) []float64 {
	raw := (hi - lo) / float64(max(want, 1))
	mag := math.Pow(10, math.Floor(math.Log10(raw)))
	step := mag
	for _, m := range []float64{1, 2, 2.5, 5, 10} {
		if m*mag >= raw {
			step = m * mag
			break
		}
	}
	start := math.Floor(lo/step) * step
	var out []float64
	for v := start; v <= hi+step*0.5 && len(out) < 50; v += step {
		out = append(out, math.Round(v/step)*step)
	}
	if len(out) > 0 && out[len(out)-1] < hi {
		out = append(out, out[len(out)-1]+step)
	}
	return out
}

// Num writes a number the Russian way: groups of thousands, a decimal comma, at most two decimals; big numbers
// short (1,2 млн).
func Num(v float64) string {
	a := math.Abs(v)
	switch {
	case a >= 1e9:
		return trimDec(v/1e9, 1) + " млрд"
	case a >= 1e6:
		return trimDec(v/1e6, 1) + " млн"
	}
	dec := 2
	if a >= 100 {
		dec = 0
	} else if a >= 10 {
		dec = 1
	}
	return trimDec(v, dec)
}

func trimDec(v float64, dec int) string {
	s := strconv.FormatFloat(v, 'f', dec, 64)
	if strings.Contains(s, ".") {
		s = strings.TrimRight(strings.TrimRight(s, "0"), ".")
	}
	neg := strings.HasPrefix(s, "-")
	s = strings.TrimPrefix(s, "-")
	whole, frac, _ := strings.Cut(s, ".")
	if len(whole) > 4 {
		var g []string
		for len(whole) > 3 {
			g = append([]string{whole[len(whole)-3:]}, g...)
			whole = whole[:len(whole)-3]
		}
		whole = strings.Join(append([]string{whole}, g...), " ")
	}
	if frac != "" {
		whole += "," + frac
	}
	if neg {
		whole = "−" + whole
	}
	return whole
}

// axes draws line, area and (vertical) bar charts.
func (c Chart) axes(b *strings.Builder, top, n int, bars bool) {
	top = max(top, c.legend(b, top)+14)
	left, right, bottom := 86, 30, 64
	if c.YLabel != "" {
		left += 26
	}
	rotate := n > 8 && longest(c.Labels) > 6 || n > 16
	if rotate {
		bottom += min(70, 7*longest(c.Labels))
	}
	if c.XLabel != "" {
		bottom += 26
	}
	w, h := c.Width-left-right, c.Height-top-bottom
	lo, hi := c.span(bars)
	ts := ticks(lo, hi, 6)
	lo, hi = math.Min(lo, ts[0]), math.Max(hi, ts[len(ts)-1])
	y := func(v float64) float64 { return float64(top) + float64(h)*(hi-v)/(hi-lo) }
	for _, t := range ts {
		fmt.Fprintf(b, `<line x1="%d" x2="%d" y1="%.1f" y2="%.1f" stroke="#e6e6e6"/>`, left, left+w, y(t), y(t))
		fmt.Fprintf(b, `<text x="%d" y="%.1f" text-anchor="end" font-size="14" fill="#555">%s</text>`, left-8, y(t)+5, Num(t))
	}
	fmt.Fprintf(b, `<line x1="%d" x2="%d" y1="%.1f" y2="%.1f" stroke="#999"/>`, left, left+w, y(math.Max(lo, math.Min(0, hi))), y(math.Max(lo, math.Min(0, hi))))
	if c.YLabel != "" {
		fmt.Fprintf(b, `<text transform="translate(26,%d) rotate(-90)" text-anchor="middle" font-size="15" fill="#444">%s</text>`, top+h/2, esc(c.YLabel))
	}
	if c.XLabel != "" {
		fmt.Fprintf(b, `<text x="%d" y="%d" text-anchor="middle" font-size="15" fill="#444">%s</text>`, left+w/2, c.Height-10, esc(c.XLabel))
	}
	slot := float64(w) / float64(n)
	x := func(i int) float64 {
		if bars {
			return float64(left) + slot*(float64(i)+0.5)
		}
		if n == 1 {
			return float64(left) + float64(w)/2
		}
		return float64(left) + float64(w)*float64(i)/float64(n-1)
	}
	every := max(1, int(math.Ceil(float64(n)*map[bool]float64{true: 14, false: 60}[rotate]/float64(w))))
	for i := 0; i < n; i += every {
		lbl := c.Labels[i]
		if r := []rune(lbl); len(r) > 18 {
			lbl = string(r[:17]) + "…"
		}
		if rotate {
			fmt.Fprintf(b, `<text transform="translate(%.1f,%d) rotate(-40)" text-anchor="end" font-size="13" fill="#555">%s</text>`, x(i)+4, top+h+18, esc(lbl))
		} else {
			fmt.Fprintf(b, `<text x="%.1f" y="%d" text-anchor="middle" font-size="14" fill="#555">%s</text>`, x(i), top+h+24, esc(lbl))
		}
	}
	single := len(c.Series) == 1
	if bars {
		ns := len(c.Series)
		bw := slot * 0.8 / float64(ns)
		labels := n*ns <= 24
		for si, s := range c.Series {
			for i, v := range s.Values {
				if math.IsNaN(v) {
					continue
				}
				bx := x(i) - slot*0.4 + bw*float64(si)
				y0, y1 := y(math.Max(v, 0)), y(math.Min(v, 0))
				fmt.Fprintf(b, `<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" rx="2" fill="%s"/>`, bx+1, y0, math.Max(bw-2, 1), math.Max(y1-y0, 0.5), color(si))
				if labels {
					ly := y0 - 6
					if v < 0 {
						ly = y1 + 16
					}
					fmt.Fprintf(b, `<text x="%.1f" y="%.1f" text-anchor="middle" font-size="13" fill="#333">%s</text>`, bx+bw/2, ly, Num(v))
				}
			}
		}
		return
	}
	area := strings.ToLower(c.Kind) == "area"
	for si, s := range c.Series {
		col := color(si)
		var seg []string
		flush := func() {
			if len(seg) == 0 {
				return
			}
			if area {
				first, last := strings.Split(seg[0], ",")[0], strings.Split(seg[len(seg)-1], ",")[0]
				base := y(math.Max(lo, math.Min(0, hi)))
				fmt.Fprintf(b, `<polygon points="%s,%.1f %s %s,%.1f" fill="%s" fill-opacity="0.22"/>`, first, base, strings.Join(seg, " "), last, base, col)
			}
			fmt.Fprintf(b, `<polyline points="%s" fill="none" stroke="%s" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"/>`, strings.Join(seg, " "), col)
			seg = nil
		}
		for i, v := range s.Values {
			if math.IsNaN(v) {
				flush()
				continue
			}
			seg = append(seg, fmt.Sprintf("%.1f,%.1f", x(i), y(v)))
		}
		flush()
		if n <= 40 {
			for i, v := range s.Values {
				if !math.IsNaN(v) {
					fmt.Fprintf(b, `<circle cx="%.1f" cy="%.1f" r="4" fill="#fff" stroke="%s" stroke-width="2.5"/>`, x(i), y(v), col)
					if single && n <= 15 {
						fmt.Fprintf(b, `<text x="%.1f" y="%.1f" text-anchor="middle" font-size="13" fill="#333">%s</text>`, x(i), y(v)-11, Num(v))
					}
				}
			}
		}
	}
}

func longest(ss []string) int {
	n := 0
	for _, s := range ss {
		n = max(n, len([]rune(s)))
	}
	return min(n, 18)
}

// hbar draws horizontal bars: good for long names of categories.
func (c Chart) hbar(b *strings.Builder, top, n int) {
	top = max(top, c.legend(b, top)+14)
	left := 30 + 8*min(longest(c.Labels), 28)
	right, bottom := 80, 40
	w, h := c.Width-left-right, c.Height-top-bottom
	lo, hi := c.span(true)
	ts := ticks(lo, hi, 5)
	lo, hi = math.Min(lo, ts[0]), math.Max(hi, ts[len(ts)-1])
	x := func(v float64) float64 { return float64(left) + float64(w)*(v-lo)/(hi-lo) }
	for _, t := range ts {
		fmt.Fprintf(b, `<line x1="%.1f" x2="%.1f" y1="%d" y2="%d" stroke="#e6e6e6"/>`, x(t), x(t), top, top+h)
		fmt.Fprintf(b, `<text x="%.1f" y="%d" text-anchor="middle" font-size="13" fill="#555">%s</text>`, x(t), top+h+20, Num(t))
	}
	slot := float64(h) / float64(n)
	ns := len(c.Series)
	bh := slot * 0.78 / float64(ns)
	for i := 0; i < n; i++ {
		lbl := c.Labels[i]
		if r := []rune(lbl); len(r) > 28 {
			lbl = string(r[:27]) + "…"
		}
		fmt.Fprintf(b, `<text x="%d" y="%.1f" text-anchor="end" font-size="14" fill="#333">%s</text>`, left-8, float64(top)+slot*(float64(i)+0.5)+5, esc(lbl))
	}
	for si, s := range c.Series {
		for i, v := range s.Values {
			if math.IsNaN(v) {
				continue
			}
			by := float64(top) + slot*float64(i) + slot*0.11 + bh*float64(si)
			x0, x1 := x(math.Min(v, 0)), x(math.Max(v, 0))
			fmt.Fprintf(b, `<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" rx="2" fill="%s"/>`, x0, by+1, math.Max(x1-x0, 0.5), math.Max(bh-2, 1), color(si))
			if n*ns <= 30 {
				fmt.Fprintf(b, `<text x="%.1f" y="%.1f" font-size="13" fill="#333">%s</text>`, x1+6, by+bh/2+5, Num(v))
			}
		}
	}
	fmt.Fprintf(b, `<line x1="%.1f" x2="%.1f" y1="%d" y2="%d" stroke="#999"/>`, x(math.Max(lo, 0)), x(math.Max(lo, 0)), top, top+h)
}

// pie draws the first series as a donut with a legend of names, values and shares.
func (c Chart) pie(b *strings.Builder, top int) {
	s := c.Series[0]
	total := 0.0
	for _, v := range s.Values {
		if v > 0 && !math.IsNaN(v) {
			total += v
		}
	}
	if total == 0 {
		fmt.Fprintf(b, `<text x="%d" y="%d" text-anchor="middle" font-size="18" fill="#555">нет положительных значений</text>`, c.Width/2, c.Height/2)
		return
	}
	r := math.Min(float64(c.Height-top-30)/2, float64(c.Width)*0.28)
	cx, cy := float64(c.Width)*0.33, float64(top)+(float64(c.Height-top-10))/2
	angle := -math.Pi / 2
	idx := 0
	lx, ly := int(float64(c.Width)*0.62), int(cy)-12*len(s.Values)+10
	ly = max(ly, top+10)
	for i, v := range s.Values {
		if v <= 0 || math.IsNaN(v) {
			continue
		}
		frac := v / total
		end := angle + 2*math.Pi*frac
		col := color(idx)
		if frac >= 0.9999 {
			fmt.Fprintf(b, `<circle cx="%.1f" cy="%.1f" r="%.1f" fill="%s"/>`, cx, cy, r, col)
		} else {
			large := 0
			if end-angle > math.Pi {
				large = 1
			}
			fmt.Fprintf(b, `<path d="M%.1f,%.1f L%.1f,%.1f A%.1f,%.1f 0 %d 1 %.1f,%.1f Z" fill="%s" stroke="#fff" stroke-width="2"/>`,
				cx, cy, cx+r*math.Cos(angle), cy+r*math.Sin(angle), r, r, large, cx+r*math.Cos(end), cy+r*math.Sin(end), col)
		}
		if frac >= 0.04 { // the share on the slice
			mid := (angle + end) / 2
			fmt.Fprintf(b, `<text x="%.1f" y="%.1f" text-anchor="middle" font-size="15" font-weight="bold" fill="#fff">%s%%</text>`,
				cx+r*0.78*math.Cos(mid), cy+r*0.78*math.Sin(mid)+5, trimDec(frac*100, map[bool]int{true: 1, false: 0}[frac < 0.1]))
		}
		if idx < 14 {
			name := c.Labels[i]
			if rn := []rune(name); len(rn) > 24 {
				name = string(rn[:23]) + "…"
			}
			fmt.Fprintf(b, `<rect x="%d" y="%d" width="16" height="16" rx="3" fill="%s"/>`, lx, ly+idx*26-13, col)
			fmt.Fprintf(b, `<text x="%d" y="%d" font-size="15" fill="#333">%s — %s (%s%%)</text>`, lx+24, ly+idx*26, esc(name), Num(v), trimDec(frac*100, 1))
		}
		idx++
		angle = end
	}
	fmt.Fprintf(b, `<circle cx="%.1f" cy="%.1f" r="%.1f" fill="#fff"/>`, cx, cy, r*0.48)
	fmt.Fprintf(b, `<text x="%.1f" y="%.1f" text-anchor="middle" font-size="20" font-weight="bold" fill="#333">%s</text>`, cx, cy+7, Num(total))
}
