// Package world is a small voxel world of her own: an endless terrain you and she can walk, build and play in.
// The server keeps the blocks and the players; the browser draws everything (see page.html).
package world

// Chunk size. A chunk is a column of 16×16 blocks, CY high.
const (
	CX       = 16
	CY       = 128
	CZ       = 16
	SeaLevel = 36
)

// Block is one kind of block. Textures are names the page knows how to paint (the page draws every texture itself, so
// there are no image files and nothing copied from anywhere).
type Block struct {
	ID      uint8   `json:"id"`
	Name    string  `json:"name"`
	Label   string  `json:"label"`
	Solid   bool    `json:"solid"`  // stops the player
	Trans   bool    `json:"trans"`  // the faces of its neighbours are still drawn
	Liquid  bool    `json:"liquid"` // swim in it
	Cross   bool    `json:"cross"`  // drawn as two crossed sheets (flowers, grass)
	Hard    float32 `json:"hard"`   // seconds to break by hand in survival
	Top     string  `json:"top"`
	Side    string  `json:"side"`
	Bottom  string  `json:"bottom"`
	Light   bool    `json:"light,omitempty"`
	Replace bool    `json:"-"` // can be built over (air, water, tall grass)
}

// IDs of the blocks the generator uses.
const (
	Air uint8 = iota
	Grass
	Dirt
	Stone
	Cobble
	Sand
	Gravel
	Log
	Leaves
	Planks
	Water
	SnowBlock
	SnowGrass
	Sandstone
	Bedrock
	Glass
	Brick
	CoalOre
	IronOre
	GoldOre
	DiamondOre
	CopperOre
	Cactus
	WoolWhite
	WoolRed
	WoolOrange
	WoolYellow
	WoolGreen
	WoolBlue
	WoolPurple
	WoolBlack
	Bookshelf
	CraftTable
	Furnace
	Lamp
	Obsidian
	Ice
	Clay
	MossyCobble
	FlowerRed
	FlowerYellow
	TallGrass
	DeadBush
	StoneBricks
	IronBlock
	GoldBlock
	DiamondBlock
	blockCount
)

func all(id uint8, name, label string, hard float32, tex ...string) Block {
	b := Block{ID: id, Name: name, Label: label, Solid: true, Hard: hard}
	switch len(tex) {
	case 1:
		b.Top, b.Side, b.Bottom = tex[0], tex[0], tex[0]
	case 2:
		b.Top, b.Side, b.Bottom = tex[0], tex[1], tex[0]
	default:
		b.Top, b.Side, b.Bottom = tex[0], tex[1], tex[2]
	}
	return b
}

func buildTable() []Block {
	t := make([]Block, blockCount)
	set := func(b Block) { t[b.ID] = b }
	set(Block{ID: Air, Name: "air", Label: "Воздух", Trans: true, Replace: true})
	set(all(Grass, "grass", "Трава", 0.6, "grass_top", "grass_side", "dirt"))
	set(all(Dirt, "dirt", "Земля", 0.5, "dirt"))
	set(all(Stone, "stone", "Камень", 1.5, "stone"))
	set(all(Cobble, "cobble", "Булыжник", 2, "cobble"))
	set(all(Sand, "sand", "Песок", 0.5, "sand"))
	set(all(Gravel, "gravel", "Гравий", 0.6, "gravel"))
	set(all(Log, "log", "Бревно", 2, "log_top", "log_side"))
	b := all(Leaves, "leaves", "Листва", 0.2, "leaves")
	b.Trans = true
	set(b)
	set(all(Planks, "planks", "Доски", 2, "planks"))
	set(Block{ID: Water, Name: "water", Label: "Вода", Trans: true, Liquid: true, Replace: true, Hard: 0, Top: "water", Side: "water", Bottom: "water"})
	set(all(SnowBlock, "snow", "Снег", 0.4, "snow"))
	set(all(SnowGrass, "snow_grass", "Снежная земля", 0.6, "snow", "snow_side", "dirt"))
	set(all(Sandstone, "sandstone", "Песчаник", 1.2, "sandstone_top", "sandstone", "sandstone_top"))
	set(all(Bedrock, "bedrock", "Коренная порода", -1, "bedrock"))
	b = all(Glass, "glass", "Стекло", 0.3, "glass")
	b.Trans = true
	set(b)
	set(all(Brick, "brick", "Кирпич", 2, "brick"))
	set(all(CoalOre, "coal_ore", "Угольная руда", 3, "coal_ore"))
	set(all(IronOre, "iron_ore", "Железная руда", 3, "iron_ore"))
	set(all(GoldOre, "gold_ore", "Золотая руда", 3, "gold_ore"))
	set(all(DiamondOre, "diamond_ore", "Алмазная руда", 3.5, "diamond_ore"))
	set(all(CopperOre, "copper_ore", "Медная руда", 3, "copper_ore"))
	set(all(Cactus, "cactus", "Кактус", 0.4, "cactus_top", "cactus_side"))
	for i, c := range []struct{ n, l string }{{"white", "Белая шерсть"}, {"red", "Красная шерсть"}, {"orange", "Оранжевая шерсть"}, {"yellow", "Жёлтая шерсть"},
		{"green", "Зелёная шерсть"}, {"blue", "Синяя шерсть"}, {"purple", "Фиолетовая шерсть"}, {"black", "Чёрная шерсть"}} {
		set(all(WoolWhite+uint8(i), "wool_"+c.n, c.l, 0.8, "wool_"+c.n))
	}
	set(all(Bookshelf, "bookshelf", "Книжная полка", 1.5, "planks", "bookshelf"))
	set(all(CraftTable, "crafting_table", "Верстак", 2.5, "craft_top", "craft_side", "planks"))
	set(all(Furnace, "furnace", "Печь", 3.5, "stone", "furnace_side"))
	b = all(Lamp, "lamp", "Лампа", 0.5, "lamp")
	b.Light = true
	set(b)
	set(all(Obsidian, "obsidian", "Обсидиан", 10, "obsidian"))
	b = all(Ice, "ice", "Лёд", 0.5, "ice")
	b.Trans = true
	set(b)
	set(all(Clay, "clay", "Глина", 0.6, "clay"))
	set(all(MossyCobble, "mossy_cobble", "Замшелый булыжник", 2, "mossy"))
	cross := func(id uint8, name, label, tex string) {
		set(Block{ID: id, Name: name, Label: label, Trans: true, Cross: true, Replace: true, Hard: 0.05, Top: tex, Side: tex, Bottom: tex})
	}
	cross(FlowerRed, "flower_red", "Красный цветок", "flower_red")
	cross(FlowerYellow, "flower_yellow", "Жёлтый цветок", "flower_yellow")
	cross(TallGrass, "tall_grass", "Высокая трава", "tall_grass")
	cross(DeadBush, "dead_bush", "Сухой куст", "dead_bush")
	set(all(StoneBricks, "stone_bricks", "Каменные кирпичи", 2, "stone_bricks"))
	set(all(IronBlock, "iron_block", "Железный блок", 5, "iron_block"))
	set(all(GoldBlock, "gold_block", "Золотой блок", 3, "gold_block"))
	set(all(DiamondBlock, "diamond_block", "Алмазный блок", 5, "diamond_block"))
	return t
}

// Blocks is the table of all block kinds, indexed by ID.
var Blocks = buildTable()

func isSolid(id uint8) bool    { return int(id) < len(Blocks) && Blocks[id].Solid }
func isLiquid(id uint8) bool   { return int(id) < len(Blocks) && Blocks[id].Liquid }
func canReplace(id uint8) bool { return int(id) < len(Blocks) && Blocks[id].Replace }
func validBlock(id uint8) bool { return int(id) < len(Blocks) && Blocks[id].Name != "" }
