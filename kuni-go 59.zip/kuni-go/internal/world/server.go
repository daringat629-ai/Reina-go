package world

import (
	"context"
	"crypto/subtle"
	_ "embed"
	"encoding/json"
	"fmt"
	"log"
	"math"
	"net/http"
	"sort"
	"strings"
	"sync"
	"time"
	"unicode"
)

//go:embed page.html
var pageHTML []byte

const (
	tickEvery  = 50 * time.Millisecond
	maxPlayers = 8
	maxView    = 8
	reach      = 9.5
)

// ChatLine is one line of the world's chat.
type ChatLine struct {
	At   time.Time
	From string
	Text string
}

// Player is somebody in the world: a person at a browser or the bot (her).
type Player struct {
	ID         int
	Name       string
	Bot        bool
	X, Y, Z    float64
	Yaw, Pitch float64

	ws      *wsConn
	out     chan outMsg
	sent    map[ckey]bool
	view    int
	cc      ckey
	hasCC   bool
	pending []ckey
	tokens  float64
	tokAt   time.Time
	closed  bool

	goal   *[3]float64
	follow string
	stuck  int
	note   string
}

type outMsg struct {
	op   byte
	data []byte
}

// Server runs the world: players, her, the chat and the websocket the page talks to.
type Server struct {
	W       *World
	Key     func() string // the password of the world; empty means nobody may enter
	BotName string
	// OnChat is told about every line a person writes (not her own), so she can answer.
	OnChat func(from, text string)

	mu      sync.Mutex
	players map[int]*Player
	nextID  int
	chat    []ChatLine
	bot     *Player
	build   *plan
	queue   []*plan
	history []*plan
	auto    bool
	ticks   int
}

// Mount registers the page (/world) and its websocket (/world/ws).
func (s *Server) Mount(mux *http.ServeMux) {
	page := func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Header().Set("Cache-Control", "no-store")
		_, _ = w.Write(pageHTML)
	}
	mux.HandleFunc("/world", page)
	mux.HandleFunc("/world/", page)
	mux.HandleFunc("/world/ws", s.handleWS)
}

// Run starts her in the world and runs it until ctx ends, then saves.
func (s *Server) Run(ctx context.Context) {
	s.mu.Lock()
	if s.players == nil {
		s.players = map[int]*Player{}
	}
	if s.BotName == "" {
		s.BotName = "Рейна"
	}
	if s.bot == nil {
		x, _, z := s.W.Spawn()
		s.nextID++
		s.bot = &Player{ID: s.nextID, Name: s.BotName, Bot: true, X: float64(x) + 2.5, Y: float64(s.W.gen.Height(x+2, z) + 1), Z: float64(z) + 0.5}
		s.players[s.bot.ID] = s.bot
	}
	s.mu.Unlock()
	tick := time.NewTicker(tickEvery)
	defer tick.Stop()
	slow := time.NewTicker(30 * time.Second)
	defer slow.Stop()
	for {
		select {
		case <-ctx.Done():
			if err := s.W.Save(); err != nil {
				log.Printf("world: save: %v", err)
			}
			return
		case <-tick.C:
			s.tick()
		case <-slow.C:
			s.housekeeping()
		}
	}
}

func (s *Server) housekeeping() {
	s.mu.Lock()
	var at [][2]int
	for _, p := range s.players {
		at = append(at, [2]int{floorDiv(int(math.Floor(p.X)), CX), floorDiv(int(math.Floor(p.Z)), CZ)})
	}
	s.mu.Unlock()
	s.W.Unload(func(cx, cz int) bool {
		for _, a := range at {
			if iabs(a[0]-cx) <= maxView+3 && iabs(a[1]-cz) <= maxView+3 {
				return true
			}
		}
		return false
	})
	if err := s.W.Save(); err != nil {
		log.Printf("world: save: %v", err)
	}
}

func cleanName(n string) string {
	var b strings.Builder
	for _, r := range strings.TrimSpace(n) {
		if unicode.IsControl(r) || r == '<' || r == '>' {
			continue
		}
		b.WriteRune(r)
		if b.Len() > 40 {
			break
		}
	}
	out := []rune(b.String())
	if len(out) > 20 {
		out = out[:20]
	}
	if len(out) == 0 {
		return "Игрок"
	}
	return string(out)
}

func (s *Server) handleWS(w http.ResponseWriter, r *http.Request) {
	want := ""
	if s.Key != nil {
		want = s.Key()
	}
	got := r.URL.Query().Get("key")
	if want == "" || subtle.ConstantTimeCompare([]byte(got), []byte(want)) != 1 {
		http.Error(w, "wrong key", http.StatusUnauthorized)
		return
	}
	s.mu.Lock()
	n := 0
	for _, p := range s.players {
		if !p.Bot {
			n++
		}
	}
	s.mu.Unlock()
	if n >= maxPlayers {
		http.Error(w, "world is full", http.StatusServiceUnavailable)
		return
	}
	ws, err := upgrade(w, r)
	if err != nil {
		return
	}
	defer ws.close()
	p := s.join(ws, cleanName(r.URL.Query().Get("name")))
	defer s.leave(p)
	for {
		op, data, err := ws.read()
		if err != nil {
			return
		}
		if op == opText {
			s.handle(p, data)
		}
	}
}

func (s *Server) join(ws *wsConn, name string) *Player {
	spx, spy, spz := s.W.Spawn()
	x, y, z := float64(spx)+0.5, float64(spy), float64(spz)+0.5
	if h, ok := s.W.Home(name); ok {
		x, y, z = h[0], h[1], h[2]
	}
	s.mu.Lock()
	if s.players == nil {
		s.players = map[int]*Player{}
	}
	for taken := true; taken; {
		taken = false
		for _, o := range s.players {
			if strings.EqualFold(o.Name, name) {
				name += "+"
				taken = true
			}
		}
	}
	s.nextID++
	p := &Player{ID: s.nextID, Name: name, X: x, Y: y, Z: z, ws: ws, out: make(chan outMsg, 512), sent: map[ckey]bool{}, view: 5, tokens: 60, tokAt: time.Now()}
	s.players[p.ID] = p
	botName := s.BotName
	s.mu.Unlock()
	go func() {
		for m := range p.out {
			if err := ws.write(m.op, m.data); err != nil {
				ws.close()
				return
			}
		}
	}()
	hello, _ := json.Marshal(map[string]any{"t": "hello", "id": p.ID, "name": p.Name, "x": x, "y": y, "z": z, "seed": s.W.Seed(),
		"time": s.W.Time(), "blocks": Blocks, "bot": botName, "maxView": maxView})
	s.sendL(p, opText, hello)
	s.say("", p.Name+" зашёл в мир")
	return p
}

func (s *Server) leave(p *Player) {
	s.mu.Lock()
	if !p.closed {
		p.closed = true
		close(p.out)
	}
	delete(s.players, p.ID)
	s.mu.Unlock()
	s.W.SetHome(p.Name, [3]float64{p.X, p.Y, p.Z})
	s.say("", p.Name+" вышел из мира")
}

// send queues a message; a client that cannot keep up is dropped.
func (s *Server) send(p *Player, op byte, data []byte) {
	if p.ws == nil || p.closed {
		return
	}
	select {
	case p.out <- outMsg{op, data}:
	default:
		p.ws.close()
	}
}

func (s *Server) sendL(p *Player, op byte, data []byte) {
	s.mu.Lock()
	s.send(p, op, data)
	s.mu.Unlock()
}

type inMsg struct {
	T     string  `json:"t"`
	X     float64 `json:"x"`
	Y     float64 `json:"y"`
	Z     float64 `json:"z"`
	Yaw   float64 `json:"a"`
	Pitch float64 `json:"b"`
	ID    int     `json:"id"`
	Text  string  `json:"text"`
	View  int     `json:"view"`
}

func finite(v float64) bool { return !math.IsNaN(v) && !math.IsInf(v, 0) && math.Abs(v) < 3e7 }

func (s *Server) handle(p *Player, raw []byte) {
	var m inMsg
	if json.Unmarshal(raw, &m) != nil {
		return
	}
	switch m.T {
	case "pos":
		if finite(m.X) && finite(m.Y) && finite(m.Z) {
			s.mu.Lock()
			p.X, p.Y, p.Z = m.X, math.Max(-20, math.Min(m.Y, CY+60)), m.Z
			if finite(m.Yaw) && finite(m.Pitch) {
				p.Yaw, p.Pitch = m.Yaw, m.Pitch
			}
			s.mu.Unlock()
		}
	case "view":
		s.mu.Lock()
		p.view = max(2, min(m.View, maxView))
		p.hasCC = false
		s.mu.Unlock()
	case "set":
		s.humanSet(p, int(math.Floor(m.X)), int(math.Floor(m.Y)), int(math.Floor(m.Z)), uint8(m.ID), m.ID >= 0 && m.ID < 256)
	case "chat":
		text := strings.TrimSpace(m.Text)
		if r := []rune(text); len(r) > 300 {
			text = string(r[:300])
		}
		if text != "" {
			s.say(p.Name, text)
			if s.OnChat != nil {
				go s.OnChat(p.Name, text)
			}
		}
	}
}

func (s *Server) humanSet(p *Player, x, y, z int, id uint8, ok bool) {
	s.mu.Lock()
	now := time.Now()
	p.tokens = math.Min(60, p.tokens+now.Sub(p.tokAt).Seconds()*40)
	p.tokAt = now
	allowed := p.tokens >= 1
	if allowed {
		p.tokens--
	}
	px, py, pz := p.X, p.Y, p.Z
	s.mu.Unlock()
	revert := func() { s.sendL(p, opText, blockMsg(x, y, z, s.W.Block(x, y, z))) }
	if !ok || !allowed || y < 1 || y >= CY || !validBlock(id) {
		revert()
		return
	}
	dx, dy, dz := float64(x)+0.5-px, float64(y)+0.5-(py+1.6), float64(z)+0.5-pz
	if dx*dx+dy*dy+dz*dz > reach*reach {
		revert()
		return
	}
	cur := s.W.Block(x, y, z)
	switch {
	case id == Air && (cur == Air || Blocks[cur].Hard < 0):
		revert()
		return
	case id != Air && !canReplace(cur):
		revert()
		return
	case id != Air && isSolid(id) && overlaps(px, py, pz, x, y, z):
		revert()
		return
	}
	s.W.SetBlock(x, y, z, id)
	s.broadcastBlock(x, y, z, id)
}

// overlaps says whether the block cell touches a player's body (0.6 wide, 1.8 high).
func overlaps(px, py, pz float64, x, y, z int) bool {
	return float64(x) < px+0.3 && float64(x+1) > px-0.3 && float64(z) < pz+0.3 && float64(z+1) > pz-0.3 && float64(y) < py+1.8 && float64(y+1) > py
}

func blockMsg(x, y, z int, id uint8) []byte {
	return []byte(fmt.Sprintf(`{"t":"b","x":%d,"y":%d,"z":%d,"id":%d}`, x, y, z, id))
}

func (s *Server) broadcastBlock(x, y, z int, id uint8) {
	msg := blockMsg(x, y, z, id)
	ck := ckey{floorDiv(x, CX), floorDiv(z, CZ)}
	s.mu.Lock()
	defer s.mu.Unlock()
	s.broadcastLocked(ck, msg)
}

// broadcastLocked is broadcastBlock for a caller that already holds s.mu.
func (s *Server) broadcastLocked(ck ckey, msg []byte) {
	for _, p := range s.players {
		if p.ws != nil && p.sent[ck] {
			s.send(p, opText, msg)
		}
	}
}

// say adds a line to the chat and tells everybody; from == "" is a notice.
func (s *Server) say(from, text string) {
	line := ChatLine{At: time.Now(), From: from, Text: text}
	msg, _ := json.Marshal(map[string]any{"t": "chat", "from": from, "text": text})
	s.mu.Lock()
	defer s.mu.Unlock()
	s.chat = append(s.chat, line)
	if len(s.chat) > 60 {
		s.chat = s.chat[len(s.chat)-60:]
	}
	for _, p := range s.players {
		s.send(p, opText, msg)
	}
}

type pstate struct {
	ID   int     `json:"i"`
	Name string  `json:"n"`
	X    float64 `json:"x"`
	Y    float64 `json:"y"`
	Z    float64 `json:"z"`
	Yaw  float64 `json:"a"`
	Pit  float64 `json:"b"`
	Bot  bool    `json:"bot,omitempty"`
}

func r2(v float64) float64 { return math.Round(v*100) / 100 }

func (s *Server) tick() {
	s.mu.Lock()
	s.ticks++
	if s.bot != nil {
		s.stepBot(s.bot, tickEvery.Seconds())
		s.stepBuild(s.bot)
	}
	type job struct {
		p  *Player
		cs []ckey
	}
	var jobs []job
	for _, p := range s.players {
		if p.ws == nil || p.closed {
			continue
		}
		cc := ckey{floorDiv(int(math.Floor(p.X)), CX), floorDiv(int(math.Floor(p.Z)), CZ)}
		if !p.hasCC || cc != p.cc {
			p.cc, p.hasCC = cc, true
			for k := range p.sent {
				if iabs(k[0]-cc[0]) > p.view+2 || iabs(k[1]-cc[1]) > p.view+2 {
					delete(p.sent, k)
				}
			}
			p.pending = p.pending[:0]
			for dx := -p.view; dx <= p.view; dx++ {
				for dz := -p.view; dz <= p.view; dz++ {
					if dx*dx+dz*dz <= p.view*p.view+p.view {
						if k := (ckey{cc[0] + dx, cc[1] + dz}); !p.sent[k] {
							p.pending = append(p.pending, k)
						}
					}
				}
			}
			sort.Slice(p.pending, func(i, j int) bool {
				a, b := p.pending[i], p.pending[j]
				return (a[0]-cc[0])*(a[0]-cc[0])+(a[1]-cc[1])*(a[1]-cc[1]) < (b[0]-cc[0])*(b[0]-cc[0])+(b[1]-cc[1])*(b[1]-cc[1])
			})
		}
		n := min(3, len(p.pending))
		if n > 0 {
			j := job{p: p, cs: append([]ckey(nil), p.pending[:n]...)}
			p.pending = p.pending[n:]
			for _, k := range j.cs {
				p.sent[k] = true
			}
			jobs = append(jobs, j)
		}
	}
	var snap []byte
	var tmsg []byte
	if s.ticks%2 == 0 {
		list := make([]pstate, 0, len(s.players))
		for _, p := range s.players {
			list = append(list, pstate{p.ID, p.Name, r2(p.X), r2(p.Y), r2(p.Z), r2(p.Yaw), r2(p.Pitch), p.Bot})
		}
		snap, _ = json.Marshal(map[string]any{"t": "p", "l": list})
	}
	if s.ticks%40 == 0 {
		tmsg, _ = json.Marshal(map[string]any{"t": "time", "v": s.W.Time()})
	}
	for _, p := range s.players {
		if snap != nil {
			s.send(p, opText, snap)
		}
		if tmsg != nil {
			s.send(p, opText, tmsg)
		}
	}
	s.mu.Unlock()
	for _, j := range jobs { // the heavy part (generating) is done without the lock
		for _, k := range j.cs {
			data := s.W.EncodeChunk(k[0], k[1])
			s.mu.Lock()
			s.send(j.p, opBinary, data)
			s.mu.Unlock()
		}
	}
}

// Players lists who is in the world (for her tools).
func (s *Server) Players() []pstate {
	s.mu.Lock()
	defer s.mu.Unlock()
	var out []pstate
	for _, p := range s.players {
		out = append(out, pstate{p.ID, p.Name, r2(p.X), r2(p.Y), r2(p.Z), r2(p.Yaw), r2(p.Pitch), p.Bot})
	}
	sort.Slice(out, func(i, j int) bool { return out[i].ID < out[j].ID })
	return out
}

// Chat returns the last n lines.
func (s *Server) Chat(n int) []ChatLine {
	s.mu.Lock()
	defer s.mu.Unlock()
	if n > len(s.chat) {
		n = len(s.chat)
	}
	return append([]ChatLine(nil), s.chat[len(s.chat)-n:]...)
}

// Humans lists the names of the people (not her) who are in the world now.
func (s *Server) Humans() []string {
	s.mu.Lock()
	defer s.mu.Unlock()
	var out []string
	for _, p := range s.players {
		if !p.Bot {
			out = append(out, p.Name)
		}
	}
	sort.Strings(out)
	return out
}
