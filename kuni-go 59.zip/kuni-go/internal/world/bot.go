package world

import (
	"fmt"
	"math"
	"sort"
	"strings"
	"time"
)

// She lives in the world as a player the server moves. These are her hands and eyes.

const (
	botSpeed  = 4.2
	botReach  = 12.0
	maxFill   = 4096
	fillRange = 32.0
)

// stepBot moves her one tick toward her goal. The caller holds s.mu.
func (s *Server) stepBot(b *Player, dt float64) {
	var gx, gz float64
	stop := 0.4
	switch {
	case b.follow != "":
		var who *Player
		for _, p := range s.players {
			if !p.Bot && strings.EqualFold(p.Name, b.follow) {
				who = p
			}
		}
		if who == nil {
			b.follow, b.note = "", "тот, за кем я шла, ушёл из мира"
		} else {
			gx, gz, stop = who.X, who.Z, 2.6
		}
	case b.goal != nil:
		gx, gz = b.goal[0], b.goal[2]
	}
	if b.follow == "" && b.goal == nil {
		s.settle(b, dt)
		return
	}
	dx, dz := gx-b.X, gz-b.Z
	dist := math.Hypot(dx, dz)
	if dist <= stop {
		if b.follow == "" {
			b.goal, b.note = nil, "дошла"
		}
		s.settle(b, dt)
		return
	}
	speed := botSpeed
	if b.follow != "" && dist > 10 {
		speed = 6
	}
	step := math.Min(speed*dt, dist-stop+0.05)
	base := math.Atan2(dz, dx)
	for _, off := range []float64{0, 0.7, -0.7, 1.4, -1.4, 2.1, -2.1} {
		a := base + off
		nx, nz := b.X+math.Cos(a)*step, b.Z+math.Sin(a)*step
		gy := float64(s.W.Ground(int(math.Floor(nx)), int(math.Floor(nz)), int(math.Floor(b.Y))+2))
		if gy-b.Y > 1.01 {
			continue
		}
		b.X, b.Z = nx, nz
		if gy < b.Y {
			b.Y = math.Max(gy, b.Y-14*dt)
		} else {
			b.Y = gy
		}
		b.Yaw = math.Atan2(-math.Cos(a), -math.Sin(a)) // the page looks down -z at yaw 0
		b.stuck = 0
		return
	}
	b.stuck++
	if b.stuck > 30 {
		b.goal, b.follow, b.stuck, b.note = nil, "", 0, "не могу пройти, упёрлась"
	}
}

// settle lets her fall to the ground when she stands in the air (a block was taken from under her).
func (s *Server) settle(b *Player, dt float64) {
	gy := float64(s.W.Ground(int(math.Floor(b.X)), int(math.Floor(b.Z)), int(math.Floor(b.Y))+2))
	if gy < b.Y {
		b.Y = math.Max(gy, b.Y-14*dt)
	} else if gy-b.Y <= 1.01 {
		b.Y = gy
	}
}

// BotGoto sends her to a place (y is ignored: she stays on the ground).
func (s *Server) BotGoto(x, z float64) string {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.bot == nil || !finite(x) || !finite(z) {
		return "не получилось"
	}
	s.bot.goal, s.bot.follow, s.bot.note, s.bot.stuck = &[3]float64{x, 0, z}, "", "", 0
	return fmt.Sprintf("иду к x=%.0f z=%.0f (до цели %.0f блоков)", x, z, math.Hypot(x-s.bot.X, z-s.bot.Z))
}

// BotFollow makes her walk after a player.
func (s *Server) BotFollow(name string) string {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.bot == nil {
		return "не получилось"
	}
	for _, p := range s.players {
		if !p.Bot && strings.EqualFold(p.Name, name) {
			s.bot.follow, s.bot.goal, s.bot.note, s.bot.stuck = p.Name, nil, "", 0
			return "иду за " + p.Name
		}
	}
	return "игрока " + name + " сейчас нет в мире"
}

// BotStop stops her.
func (s *Server) BotStop() {
	s.mu.Lock()
	if s.bot != nil {
		s.bot.goal, s.bot.follow, s.bot.note = nil, "", ""
	}
	s.mu.Unlock()
}

// BotSay writes in the world's chat as her.
func (s *Server) BotSay(text string) {
	text = strings.TrimSpace(text)
	if r := []rune(text); len(r) > 300 {
		text = string(r[:300])
	}
	if text == "" {
		return
	}
	s.mu.Lock()
	name := s.BotName
	s.mu.Unlock()
	s.say(name, text)
}

func (s *Server) botPos() (x, y, z float64) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.bot == nil {
		return 0, 0, 0
	}
	return s.bot.X, s.bot.Y, s.bot.Z
}

// BotPlace puts one block (id 0 clears it). She must be within reach.
func (s *Server) BotPlace(x, y, z int, id uint8) error {
	bx, by, bz := s.botPos()
	if d := math.Sqrt(sq(float64(x)+0.5-bx) + sq(float64(y)+0.5-(by+1.5)) + sq(float64(z)+0.5-bz)); d > botReach {
		return fmt.Errorf("слишком далеко (%.0f блоков, достаю на %.0f): подойди ближе командой goto", d, botReach)
	}
	return s.setByBot(x, y, z, id)
}

func (s *Server) setByBot(x, y, z int, id uint8) error {
	if y < 1 || y >= CY {
		return fmt.Errorf("высота y=%d вне мира (1..%d)", y, CY-1)
	}
	if !validBlock(id) {
		return fmt.Errorf("нет блока с номером %d", id)
	}
	if cur := s.W.Block(x, y, z); cur != Air && Blocks[cur].Hard < 0 {
		return fmt.Errorf("%s не сломать", Blocks[cur].Label)
	}
	s.W.SetBlock(x, y, z, id)
	s.broadcastBlock(x, y, z, id)
	return nil
}

func sq(v float64) float64 { return v * v }

// BotFill fills a box with a block (id 0 digs it out). Returns how many blocks changed.
func (s *Server) BotFill(x1, y1, z1, x2, y2, z2 int, id uint8) (int, error) {
	if x1 > x2 {
		x1, x2 = x2, x1
	}
	if y1 > y2 {
		y1, y2 = y2, y1
	}
	if z1 > z2 {
		z1, z2 = z2, z1
	}
	if n := (x2 - x1 + 1) * (y2 - y1 + 1) * (z2 - z1 + 1); n > maxFill {
		return 0, fmt.Errorf("слишком много блоков (%d, не больше %d): раздели на части", n, maxFill)
	}
	bx, _, bz := s.botPos()
	for _, c := range [][2]int{{x1, z1}, {x1, z2}, {x2, z1}, {x2, z2}} {
		if math.Hypot(float64(c[0])-bx, float64(c[1])-bz) > fillRange {
			return 0, fmt.Errorf("дальше %.0f блоков от меня: подойди ближе (goto)", fillRange)
		}
	}
	n := 0
	for y := max(1, y1); y <= min(y2, CY-1); y++ {
		for z := z1; z <= z2; z++ {
			for x := x1; x <= x2; x++ {
				if cur := s.W.Block(x, y, z); cur != id && !(cur != Air && Blocks[cur].Hard < 0) {
					if s.setByBot(x, y, z, id) == nil {
						n++
					}
				}
			}
		}
	}
	return n, nil
}

var mapChar = map[uint8]byte{
	Grass: 'g', Dirt: 'd', Stone: '#', Cobble: '#', Sand: 's', Gravel: ':', Log: 'T', Leaves: 'T', Planks: 'p', Water: '~', SnowBlock: 'n', SnowGrass: 'n',
	Sandstone: 's', Ice: '~', Clay: 'c', Cactus: 'C', Brick: 'b', Glass: 'o', Bedrock: '#', Lamp: '*', Obsidian: '#', CraftTable: 'W', Furnace: 'F', Bookshelf: 'p',
}

// BotLook describes what she sees: where she is, who is near, a small map from above, and the latest chat.
func (s *Server) BotLook() string {
	s.mu.Lock()
	if s.bot == nil {
		s.mu.Unlock()
		return "меня нет в мире"
	}
	b := *s.bot
	var near []string
	for _, p := range s.players {
		if p.ID == b.ID {
			continue
		}
		d := math.Hypot(p.X-b.X, p.Z-b.Z)
		near = append(near, fmt.Sprintf("%s (%.0f блоков, %s, x=%.0f y=%.0f z=%.0f)", p.Name, d, compass(p.X-b.X, p.Z-b.Z), p.X, p.Y, p.Z))
	}
	s.mu.Unlock()
	sort.Strings(near)
	bx, by, bz := int(math.Floor(b.X)), int(math.Floor(b.Y)), int(math.Floor(b.Z))
	var sb strings.Builder
	t := s.W.Time()
	fmt.Fprintf(&sb, "Я в точке x=%d y=%d z=%d, биом: %s, %s.\n", bx, by, bz, s.W.BiomeAt(bx, bz), dayWord(t))
	fmt.Fprintf(&sb, "Под ногами: %s; на уровне головы: %s.\n", Blocks[s.W.Block(bx, by-1, bz)].Label, Blocks[s.W.Block(bx, by+1, bz)].Label)
	switch {
	case b.follow != "":
		fmt.Fprintf(&sb, "Сейчас иду за %s.\n", b.follow)
	case b.goal != nil:
		fmt.Fprintf(&sb, "Сейчас иду к x=%.0f z=%.0f.\n", b.goal[0], b.goal[2])
	}
	if b.note != "" {
		fmt.Fprintf(&sb, "Заметка: %s.\n", b.note)
	}
	if len(near) == 0 {
		sb.WriteString("Рядом никого.\n")
	} else {
		sb.WriteString("В мире: " + strings.Join(near, "; ") + ".\n")
	}
	// map from above: north (−z) is up, east (+x) is right; @ is me, P a player
	const r = 10
	rows := make([][]byte, 2*r+1)
	counts := map[string]int{}
	for dz := -r; dz <= r; dz++ {
		row := make([]byte, 2*r+1)
		for dx := -r; dx <= r; dx++ {
			x, z := bx+dx, bz+dz
			top := s.W.Ground(x, z, CY-1) - 1
			id := s.W.Block(x, top, z)
			for top > 0 && (id == Air || Blocks[id].Cross) {
				top--
				id = s.W.Block(x, top, z)
			}
			ch, ok := mapChar[id]
			if !ok {
				ch = '?'
			}
			row[dx+r] = ch
			if dx*dx+dz*dz <= 64 {
				counts[Blocks[id].Label]++
			}
		}
		rows[dz+r] = row
	}
	rows[r][r] = '@'
	s.mu.Lock()
	for _, p := range s.players {
		if p.ID == b.ID {
			continue
		}
		if dx, dz := int(math.Floor(p.X))-bx, int(math.Floor(p.Z))-bz; iabs(dx) <= r && iabs(dz) <= r {
			rows[dz+r][dx+r] = 'P'
		}
	}
	s.mu.Unlock()
	sb.WriteString("Карта сверху 21×21 (вверх — север, −z; вправо — восток, +x): g трава, d земля, # камень, s песок, ~ вода/лёд, T дерево/листва, n снег, p доски, C кактус, : гравель, c глина, ? другое.\n")
	for _, row := range rows {
		sb.Write(row)
		sb.WriteByte('\n')
	}
	var cs []string
	for k, v := range counts {
		cs = append(cs, fmt.Sprintf("%s ×%d", k, v))
	}
	sort.Strings(cs)
	sb.WriteString("Поверхность вокруг: " + strings.Join(cs, ", ") + ".\n")
	if lines := s.Chat(8); len(lines) > 0 {
		sb.WriteString("Последний чат:\n")
		for _, l := range lines {
			who := l.From
			if who == "" {
				who = "·"
			}
			fmt.Fprintf(&sb, "  [%s] %s: %s\n", l.At.Format("15:04"), who, l.Text)
		}
	}
	return sb.String()
}

func compass(dx, dz float64) string {
	a := math.Atan2(-dz, dx) * 180 / math.Pi // 0 = east, 90 = north
	names := []string{"восток", "северо-восток", "север", "северо-запад", "запад", "юго-запад", "юг", "юго-восток"}
	return names[int(math.Round(math.Mod(a+360, 360)/45))%8]
}

func dayWord(t float64) string {
	switch {
	case t < 0.05 || t >= 0.95:
		return "рассвет"
	case t < 0.5:
		return "день"
	case t < 0.58:
		return "закат"
	}
	return "ночь"
}

// BlockByName finds a block by its name or label (case-insensitive), for her tools.
func BlockByName(name string) (uint8, bool) {
	n := strings.ToLower(strings.TrimSpace(name))
	for _, b := range Blocks {
		if b.Name != "" && (strings.ToLower(b.Name) == n || strings.ToLower(b.Label) == n) {
			return b.ID, true
		}
	}
	return 0, false
}

// BlockList is the list of block names she can use.
func BlockList() string {
	var out []string
	for _, b := range Blocks {
		if b.Name != "" && b.ID != Air {
			out = append(out, b.Name)
		}
	}
	return strings.Join(out, ", ")
}

var _ = time.Now
