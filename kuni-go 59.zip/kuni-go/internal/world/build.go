package world

import (
	"encoding/json"
	"fmt"
	"math"
	"math/rand"
	"sort"
	"strings"
)

// Blueprints: ready-made buildings written as plain code. She does not place block by block through the model:
// she says "build a house here" once and the server walks her around and lays the blocks, one by one, in view of everybody.

type op struct {
	x, y, z int
	id      uint8
}

type plan struct {
	name string
	ops  []op
	done int
	skip int
	wait int  // ticks spent out of reach
	undo []op // what was there before, for undo
}

const maxPlan = 6000

// Kinds lists the buildings she knows.
const Kinds = "house, tower, wall, pyramid, bridge, platform, lamppost, fence"

func box(ops *[]op, x1, y1, z1, x2, y2, z2 int, id uint8) {
	for y := y1; y <= y2; y++ {
		for z := z1; z <= z2; z++ {
			for x := x1; x <= x2; x++ {
				*ops = append(*ops, op{x, y, z, id})
			}
		}
	}
}

// blueprint makes the blocks of a building. (x,y,z) is the corner on the ground; size is the main dimension.
func blueprint(kind string, x, y, z, size int, m1, m2 uint8) ([]op, error) {
	var o []op
	if size <= 0 {
		size = 7
	}
	switch strings.ToLower(kind) {
	case "house":
		w := max(5, min(size, 21))
		h := 4
		box(&o, x, y-1, z, x+w-1, y-1, z+w-1, m1) // floor
		for yy := y; yy < y+h; yy++ {             // walls
			for i := 0; i < w; i++ {
				for _, c := range [][2]int{{x + i, z}, {x + i, z + w - 1}, {x, z + i}, {x + w - 1, z + i}} {
					id := m1
					if (i == 0 || i == w-1) && true {
						id = Log // corner posts
					}
					o = append(o, op{c[0], yy, c[1], id})
				}
			}
		}
		mid := x + w/2
		for yy := y; yy < y+2; yy++ { // door
			o = append(o, op{mid, yy, z, Air})
		}
		for i := 2; i < w-2; i += 2 { // windows
			o = append(o, op{x + i, y + 1, z + w - 1, Glass}, op{x, y + 1, z + i, Glass}, op{x + w - 1, y + 1, z + i, Glass})
		}
		box(&o, x-1, y+h, z-1, x+w, y+h, z+w, m2) // roof with an overhang
		o = append(o, op{x + w/2, y + h - 1, z + w/2, Lamp})
	case "tower":
		r := max(4, min(size, 9))
		hh := r*3 + 3
		for yy := y; yy < y+hh; yy++ {
			for i := 0; i < r; i++ {
				o = append(o, op{x + i, yy, z, m1}, op{x + i, yy, z + r - 1, m1}, op{x, yy, z + i, m1}, op{x + r - 1, yy, z + i, m1})
			}
		}
		for yy := y; yy < y+2; yy++ {
			o = append(o, op{x + r/2, yy, z, Air})
		}
		for i := 0; i < r; i += 2 { // battlements
			o = append(o, op{x + i, y + hh, z, m1}, op{x + i, y + hh, z + r - 1, m1}, op{x, y + hh, z + i, m1}, op{x + r - 1, y + hh, z + i, m1})
		}
		o = append(o, op{x + 1, y + hh - 1, z + 1, Lamp})
	case "wall":
		l := max(3, min(size, 60))
		for i := 0; i < l; i++ {
			box(&o, x+i, y, z, x+i, y+2, z, m1)
			if i%2 == 0 {
				o = append(o, op{x + i, y + 3, z, m1})
			}
		}
	case "pyramid":
		n := max(3, min(size, 25))
		for k := 0; n-2*k > 0; k++ {
			box(&o, x+k, y+k, z+k, x+n-1-k, y+k, z+n-1-k, m1)
		}
	case "bridge":
		l := max(4, min(size, 60))
		for i := 0; i < l; i++ {
			box(&o, x+i, y-1, z, x+i, y-1, z+2, m1)
			if i%3 == 0 {
				o = append(o, op{x + i, y, z, m2}, op{x + i, y, z + 2, m2})
			}
		}
	case "platform":
		n := max(2, min(size, 30))
		box(&o, x, y-1, z, x+n-1, y-1, z+n-1, m1)
	case "lamppost":
		box(&o, x, y, z, x, y+3, z, m1)
		o = append(o, op{x, y + 4, z, Lamp})
	case "fence":
		l := max(2, min(size, 60))
		for i := 0; i < l; i++ {
			box(&o, x+i, y, z, x+i, y+1, z, m1)
		}
	default:
		return nil, fmt.Errorf("не умею строить %q, умею: %s", kind, Kinds)
	}
	if len(o) > maxPlan {
		return nil, fmt.Errorf("слишком большая постройка (%d блоков, не больше %d)", len(o), maxPlan)
	}
	return o, nil
}

// BotBuild queues a building. y = 0 means "on the ground there". The server then builds it by itself.
func (s *Server) BotBuild(kind string, x, y, z, size int, m1, m2 uint8) (string, error) {
	if y <= 0 {
		y = s.W.Ground(x, z, CY-1)
	}
	if m1 == Air {
		m1 = Planks
	}
	if m2 == Air {
		m2 = Cobble
	}
	ops, err := blueprint(kind, x, y, z, size, m1, m2)
	if err != nil {
		return "", err
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.bot == nil {
		return "", fmt.Errorf("меня нет в мире")
	}
	return s.enqueue(&plan{name: kind, ops: ops}), nil
}

const maxQueue = 12

// enqueue adds a job; the caller holds s.mu. Jobs run one after another.
func (s *Server) enqueue(p *plan) string {
	if s.build == nil {
		s.build = p
		return fmt.Sprintf("начинаю: %s, %d блоков. Дальше сама хожу и кладу блоки; build_status покажет, как дела", p.name, len(p.ops))
	}
	if len(s.queue) >= maxQueue {
		return fmt.Sprintf("очередь полна (%d заданий), подожди", maxQueue)
	}
	s.queue = append(s.queue, p)
	return fmt.Sprintf("в очереди #%d: %s, %d блоков", len(s.queue), p.name, len(p.ops))
}

// BotCompose queues a building the model describes itself: a JSON list of parts like
// {"t":"box","x1":0,"y1":40,"z1":0,"x2":6,"y2":43,"z2":6,"b":"planks"}; t is box (solid), hollow (only the shell), sphere (x,y,z,r) or clear (digs a box out).
func (s *Server) BotCompose(name, spec string) (string, error) {
	var parts []struct {
		T                      string `json:"t"`
		X1, Y1, Z1, X2, Y2, Z2 int
		X, Y, Z, R             int
		B                      string `json:"b"`
	}
	if err := json.Unmarshal([]byte(spec), &parts); err != nil {
		return "", fmt.Errorf("plan должен быть JSON-списком частей: %v", err)
	}
	var ops []op
	for i, p := range parts {
		id := Air
		if strings.ToLower(p.T) != "clear" {
			var ok bool
			if id, ok = BlockByName(p.B); !ok {
				return "", fmt.Errorf("часть %d: нет блока %q", i+1, p.B)
			}
		}
		x1, x2, y1, y2, z1, z2 := min(p.X1, p.X2), max(p.X1, p.X2), min(p.Y1, p.Y2), max(p.Y1, p.Y2), min(p.Z1, p.Z2), max(p.Z1, p.Z2)
		switch strings.ToLower(p.T) {
		case "box", "clear":
			if (x2-x1+1)*(y2-y1+1)*(z2-z1+1) > maxPlan {
				return "", fmt.Errorf("часть %d слишком большая", i+1)
			}
			box(&ops, x1, y1, z1, x2, y2, z2, id)
		case "hollow":
			if (x2-x1+1)*(y2-y1+1)*(z2-z1+1) > 40000 {
				return "", fmt.Errorf("часть %d слишком большая", i+1)
			}
			for y := y1; y <= y2; y++ {
				for z := z1; z <= z2; z++ {
					for x := x1; x <= x2; x++ {
						if x == x1 || x == x2 || y == y1 || y == y2 || z == z1 || z == z2 {
							ops = append(ops, op{x, y, z, id})
						}
					}
				}
			}
		case "sphere":
			r := min(max(p.R, 1), 14)
			for y := -r; y <= r; y++ {
				for z := -r; z <= r; z++ {
					for x := -r; x <= r; x++ {
						if x*x+y*y+z*z <= r*r {
							ops = append(ops, op{p.X + x, p.Y + y, p.Z + z, id})
						}
					}
				}
			}
		default:
			return "", fmt.Errorf("часть %d: тип %q неизвестен (box, hollow, sphere, clear)", i+1, p.T)
		}
		if len(ops) > maxPlan {
			return "", fmt.Errorf("слишком большая постройка (больше %d блоков), раздели на несколько заданий", maxPlan)
		}
	}
	if len(ops) == 0 {
		return "", fmt.Errorf("в плане нет блоков")
	}
	sort.SliceStable(ops, func(i, j int) bool { return ops[i].y < ops[j].y }) // bottom up
	if name == "" {
		name = "свой чертёж"
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.enqueue(&plan{name: name, ops: ops}), nil
}

// BotFlatten levels a rectangle to height y (0 = the height at its middle): digs what sticks out, fills what is lower.
func (s *Server) BotFlatten(x1, z1, x2, z2, y int) (string, error) {
	x1, x2, z1, z2 = min(x1, x2), max(x1, x2), min(z1, z2), max(z1, z2)
	if (x2-x1+1)*(z2-z1+1) > 900 {
		return "", fmt.Errorf("площадка слишком большая (не больше 900 клеток, например 30×30)")
	}
	if y <= 0 {
		y = s.W.Ground(x1+(x2-x1)/2, z1+(z2-z1)/2, CY-1)
	}
	var ops []op
	for z := z1; z <= z2; z++ {
		for x := x1; x <= x2; x++ {
			g := s.W.Ground(x, z, CY-1)
			for yy := y + 8; yy >= max(g, y); yy-- {
				if yy >= y && s.W.Block(x, yy, z) != Air {
					ops = append(ops, op{x, yy, z, Air})
				}
			}
			for yy := g; yy < y; yy++ {
				ops = append(ops, op{x, yy, z, Dirt})
			}
			if g <= y {
				ops = append(ops, op{x, y - 1, z, Grass})
			}
		}
	}
	if len(ops) == 0 {
		return "уже ровно", nil
	}
	if len(ops) > maxPlan {
		return "", fmt.Errorf("слишком много работы (%d блоков), возьми площадку поменьше", len(ops))
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.enqueue(&plan{name: "выравнивание", ops: ops}), nil
}

// BotUndo reverts the last finished job (the blocks come back as they were).
func (s *Server) BotUndo() string {
	s.mu.Lock()
	defer s.mu.Unlock()
	if len(s.history) == 0 {
		return "отменять нечего"
	}
	h := s.history[len(s.history)-1]
	s.history = s.history[:len(s.history)-1]
	var ops []op
	for i := len(h.undo) - 1; i >= 0; i-- {
		ops = append(ops, h.undo[i])
	}
	return s.enqueue(&plan{name: "отмена: " + h.name, ops: ops})
}

// BotBuildStatus says how the building is going.
func (s *Server) BotBuildStatus() string {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.build == nil {
		return "сейчас ничего не строю"
	}
	return fmt.Sprintf("строю %s: %d из %d блоков; в очереди ещё %d", s.build.name, s.build.done, len(s.build.ops), len(s.queue))
}

// BotBuildCancel drops the current building.
func (s *Server) BotBuildCancel() {
	s.mu.Lock()
	s.build, s.queue = nil, nil
	s.mu.Unlock()
}

// BotAutobuild lets her build things on her own whenever she is idle (no model needed).
func (s *Server) BotAutobuild(on bool) {
	s.mu.Lock()
	s.auto = on
	s.mu.Unlock()
}

// stepBuild lays blocks of the current building; the caller holds s.mu. About 10 blocks a second, in reach only.
func (s *Server) stepBuild(b *Player) {
	if s.build == nil {
		if s.auto && b.goal == nil && b.follow == "" && s.ticks%200 == 0 && len(s.players) > 1 {
			s.autoPlan(b)
		}
		return
	}
	p := s.build
	if p.done >= len(p.ops) {
		b.note = "достроила: " + p.name
		if len(p.undo) > 0 && !strings.HasPrefix(p.name, "отмена") {
			s.history = append(s.history, p)
			if len(s.history) > 5 {
				s.history = s.history[1:]
			}
		}
		s.build = nil
		if len(s.queue) > 0 {
			s.build, s.queue = s.queue[0], s.queue[1:]
		}
		return
	}
	if s.ticks%2 != 0 || b.follow != "" {
		return
	}
	o := p.ops[p.done]
	d := math.Sqrt(sq(float64(o.x)+0.5-b.X) + sq(float64(o.y)+0.5-(b.Y+1.5)) + sq(float64(o.z)+0.5-b.Z))
	if d <= botReach-1.5 {
		p.wait = 0
	}
	if d > botReach-1.5 && p.wait < 60 { // after 3 s of failing to get close she builds from where she stands, as if with scaffolding
		p.wait++
		// walk to a spot a few blocks away from the block, on our side of it
		dx, dz := b.X-(float64(o.x)+0.5), b.Z-(float64(o.z)+0.5)
		l := math.Hypot(dx, dz)
		if l < 0.01 {
			dx, dz, l = 1, 0, 1
		}
		b.goal = &[3]float64{float64(o.x) + 0.5 + dx/l*4, 0, float64(o.z) + 0.5 + dz/l*4}
		return
	}
	if math.Abs(float64(o.x)+0.5-b.X) < 0.9 && math.Abs(float64(o.z)+0.5-b.Z) < 0.9 && float64(o.y) >= b.Y-1 && float64(o.y) <= b.Y+2 && o.id != Air {
		// we stand in that cell: do it later
		p.ops = append(p.ops, o)
		p.ops = append(p.ops[:p.done], p.ops[p.done+1:]...)
		p.skip++
		if p.skip > 200 {
			s.build = nil
		}
		return
	}
	if cur := s.W.Block(o.x, o.y, o.z); cur != o.id && !(cur != Air && Blocks[cur].Hard < 0) {
		if len(p.undo) < 20000 {
			p.undo = append(p.undo, op{o.x, o.y, o.z, cur})
		}
		s.W.SetBlock(o.x, o.y, o.z, o.id)
		s.broadcastLocked(ckey{floorDiv(o.x, CX), floorDiv(o.z, CZ)}, blockMsg(o.x, o.y, o.z, o.id))
	}
	p.done++
}

func (s *Server) autoPlan(b *Player) {
	kinds := []string{"house", "tower", "pyramid", "platform", "lamppost", "wall", "house"}
	mats := []uint8{Planks, Cobble, Brick, Sandstone, Stone}
	a := rand.Float64() * 2 * math.Pi
	r := 10 + rand.Float64()*12
	x, z := int(b.X+math.Cos(a)*r), int(b.Z+math.Sin(a)*r)
	if y := s.W.Ground(x, z, CY-1); y > SeaLevel {
		k := kinds[rand.Intn(len(kinds))]
		if ops, err := blueprint(k, x, y, z, 5+rand.Intn(5), mats[rand.Intn(len(mats))], mats[rand.Intn(len(mats))]); err == nil {
			s.build = &plan{name: k, ops: ops}
		}
	}
}
