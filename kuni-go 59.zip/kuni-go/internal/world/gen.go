package world

import "math"

// Gen builds the terrain from a seed. Everything is a pure function of the seed and the position, so a chunk that
// nobody changed never has to be saved: it is simply generated again.
type Gen struct{ seed uint64 }

func NewGen(seed int64) *Gen { return &Gen{seed: uint64(seed)} }

func mix(h uint64) uint64 {
	h ^= h >> 33
	h *= 0xff51afd7ed558ccd
	h ^= h >> 33
	h *= 0xc4ceb9fe1a85ec53
	h ^= h >> 33
	return h
}

func (g *Gen) hash(salt uint64, x, y, z int) uint64 {
	return mix(g.seed ^ salt*0x9e3779b97f4a7c15 ^ uint64(int64(x))*0x85ebca6b ^ uint64(int64(y))*0xc2b2ae35 ^ uint64(int64(z))*0x27d4eb2f165667c5)
}

func smooth(t float64) float64 { return t * t * (3 - 2*t) }

func lerp(a, b, t float64) float64 { return a + (b-a)*t }

func (g *Gen) unit(salt uint64, x, y, z int) float64 {
	return float64(g.hash(salt, x, y, z)>>11) / float64(1<<53)
}

func (g *Gen) noise2(salt uint64, x, z float64) float64 {
	x0, z0 := math.Floor(x), math.Floor(z)
	fx, fz := smooth(x-x0), smooth(z-z0)
	ix, iz := int(x0), int(z0)
	a, b := g.unit(salt, ix, 0, iz), g.unit(salt, ix+1, 0, iz)
	c, d := g.unit(salt, ix, 0, iz+1), g.unit(salt, ix+1, 0, iz+1)
	return lerp(lerp(a, b, fx), lerp(c, d, fx), fz)
}

func (g *Gen) noise3(salt uint64, x, y, z float64) float64 {
	x0, y0, z0 := math.Floor(x), math.Floor(y), math.Floor(z)
	fx, fy, fz := smooth(x-x0), smooth(y-y0), smooth(z-z0)
	ix, iy, iz := int(x0), int(y0), int(z0)
	l := func(dy int) float64 {
		a, b := g.unit(salt, ix, iy+dy, iz), g.unit(salt, ix+1, iy+dy, iz)
		c, d := g.unit(salt, ix, iy+dy, iz+1), g.unit(salt, ix+1, iy+dy, iz+1)
		return lerp(lerp(a, b, fx), lerp(c, d, fx), fz)
	}
	return lerp(l(0), l(1), fy)
}

func (g *Gen) fbm2(salt uint64, x, z float64, oct int) float64 {
	sum, amp, norm := 0.0, 1.0, 0.0
	for i := 0; i < oct; i++ {
		sum += g.noise2(salt+uint64(i)*7919, x, z) * amp
		norm += amp
		x, z, amp = x*2, z*2, amp*0.5
	}
	return sum / norm
}

// Biomes.
const (
	Plains = iota
	Forest
	Desert
	Snowy
	Mountain
	Beach
	Ocean
)

var BiomeNames = []string{"равнина", "лес", "пустыня", "снежная равнина", "горы", "пляж", "океан"}

// Height is the height of the ground at a column (the top solid block).
func (g *Gen) Height(x, z int) int {
	fx, fz := float64(x), float64(z)
	cont := g.fbm2(1, fx/190, fz/190, 3)
	hills := g.fbm2(2, fx/52, fz/52, 4)
	mount := g.fbm2(3, fx/95, fz/95, 3)
	h := 36 + (cont-0.46)*46 + (hills-0.5)*16
	if mount > 0.58 && cont > 0.45 {
		h += (mount - 0.58) * 150
	}
	return int(math.Max(5, math.Min(float64(CY-6), h)))
}

// BiomeAt picks the biome of a column given its ground height.
func (g *Gen) BiomeAt(x, z, h int) int {
	fx, fz := float64(x), float64(z)
	switch {
	case h < SeaLevel-1:
		return Ocean
	case h > SeaLevel+36:
		return Mountain
	case h <= SeaLevel+1:
		return Beach
	}
	temp := g.fbm2(4, fx/300, fz/300, 2)
	humid := g.fbm2(5, fx/260, fz/260, 2)
	switch {
	case temp > 0.56 && humid < 0.5:
		return Desert
	case temp < 0.42:
		return Snowy
	case humid > 0.5:
		return Forest
	}
	return Plains
}

// tree describes the tree (or cactus) that grows from a column, if any.
type tree struct {
	cactus bool
	trunk  int
	h      int // ground height at the root
}

func (g *Gen) treeAt(x, z int, hc map[[2]int]int) (tree, bool) {
	r := g.unit(11, x, 0, z)
	if r > 0.02 { // the cheap test first: almost every column has no tree
		return tree{}, false
	}
	key := [2]int{x, z}
	h, ok := hc[key]
	if !ok {
		h = g.Height(x, z)
		hc[key] = h
	}
	if h <= SeaLevel+1 {
		return tree{}, false
	}
	switch g.BiomeAt(x, z, h) {
	case Forest:
		if r < 0.014 {
			return tree{trunk: 4 + int(g.hash(12, x, 0, z)%3), h: h}, true
		}
	case Plains:
		if r < 0.0015 {
			return tree{trunk: 4 + int(g.hash(12, x, 0, z)%2), h: h}, true
		}
	case Snowy:
		if r < 0.003 {
			return tree{trunk: 4 + int(g.hash(12, x, 0, z)%2), h: h}, true
		}
	case Desert:
		if r < 0.004 {
			return tree{cactus: true, trunk: 1 + int(g.hash(12, x, 0, z)%3), h: h}, true
		}
	}
	return tree{}, false
}

// treeBlock is the block a tree rooted at (ox,oz) puts at (x,y,z), if any.
func (g *Gen) treeBlock(t tree, ox, oz, x, y, z int) (uint8, bool) {
	dy := y - t.h
	if t.cactus {
		if x == ox && z == oz && dy >= 1 && dy <= t.trunk {
			return Cactus, true
		}
		return 0, false
	}
	if x == ox && z == oz && dy >= 1 && dy <= t.trunk {
		return Log, true
	}
	top := t.trunk
	dx, dz := x-ox, z-oz
	adx, adz := iabs(dx), iabs(dz)
	switch {
	case dy >= top-2 && dy <= top-1 && adx <= 2 && adz <= 2:
		if adx == 2 && adz == 2 && g.hash(13, x, y, z)%2 == 0 {
			return 0, false
		}
		if dx == 0 && dz == 0 {
			return 0, false // the trunk is already there
		}
		return Leaves, true
	case dy >= top && dy <= top+1 && adx <= 1 && adz <= 1:
		if adx == 1 && adz == 1 && dy == top+1 {
			return 0, false
		}
		if dx == 0 && dz == 0 && dy == top {
			return Log, true
		}
		return Leaves, true
	}
	return 0, false
}

func iabs(a int) int {
	if a < 0 {
		return -a
	}
	return a
}

// Chunk is a column of blocks.
type Chunk struct {
	CX, CZ int
	B      [CX * CY * CZ]uint8
	Dirty  bool // changed since it was loaded or generated (has to be saved)
}

func idx(x, y, z int) int { return (y*CZ+z)*CX + x }

// Get returns a block inside the chunk (local coordinates).
func (c *Chunk) Get(x, y, z int) uint8 { return c.B[idx(x, y, z)] }

// Generate builds the chunk at (cx,cz).
func (g *Gen) Generate(cx, cz int) *Chunk {
	c := &Chunk{CX: cx, CZ: cz}
	hc := map[[2]int]int{}
	for lz := 0; lz < CZ; lz++ {
		for lx := 0; lx < CX; lx++ {
			x, z := cx*CX+lx, cz*CZ+lz
			h := g.Height(x, z)
			hc[[2]int{x, z}] = h
			biome := g.BiomeAt(x, z, h)
			g.column(c, lx, lz, x, z, h, biome)
			g.decorate(c, lx, lz, x, z, h, biome, hc)
		}
	}
	return c
}

func (g *Gen) column(c *Chunk, lx, lz, x, z, h, biome int) {
	top, fill, depth := Grass, Dirt, 3
	switch biome {
	case Desert, Beach:
		top, fill, depth = Sand, Sand, 4
	case Snowy:
		top = SnowGrass
	case Mountain:
		top, fill, depth = Stone, Stone, 3
		if h > SeaLevel+62 {
			top = SnowBlock
		}
	case Ocean:
		top, fill, depth = Sand, Sand, 3
		if g.unit(14, x, 0, z) < 0.3 {
			top, fill = Gravel, Gravel
		} else if g.unit(15, x/6, 0, z/6) < 0.12 {
			top, fill = Clay, Clay
		}
	}
	for y := 0; y <= h; y++ {
		var id uint8
		switch {
		case y == 0:
			id = Bedrock
		case y < 4 && g.unit(16, x, y, z) < 0.6:
			id = Bedrock
		case y == h:
			id = top
		case y >= h-depth:
			id = fill
		default:
			id = g.stoneOrOre(x, y, z)
			if biome == Desert && y >= h-9 {
				id = Sandstone
			}
		}
		if id != Bedrock && y >= 5 && y < h-2 && g.cave(x, y, z) {
			id = Air
		}
		c.B[idx(lx, y, lz)] = id
	}
	for y := h + 1; y <= SeaLevel; y++ {
		id := Water
		if y == SeaLevel && biome == Snowy && h < SeaLevel {
			id = Ice
		}
		c.B[idx(lx, y, lz)] = id
	}
}

func (g *Gen) cave(x, y, z int) bool {
	fx, fy, fz := float64(x), float64(y), float64(z)
	a := g.noise3(21, fx/22, fy/14, fz/22)
	b := g.noise3(22, fx/22, fy/14, fz/22)
	if math.Abs(a-0.5) < 0.045 && math.Abs(b-0.5) < 0.045 {
		return true // a tunnel is where two noise surfaces cross
	}
	return y < 30 && g.noise3(23, fx/16, fy/10, fz/16) > 0.8 // and now and then a big cave
}

func (g *Gen) stoneOrOre(x, y, z int) uint8 {
	r := int(g.hash(17, x, y, z) % 1000)
	switch {
	case y < 70 && r < 14:
		return CoalOre
	case y < 55 && r >= 14 && r < 22:
		return IronOre
	case y < 60 && r >= 22 && r < 28:
		return CopperOre
	case y < 30 && r >= 28 && r < 31:
		return GoldOre
	case y < 16 && r >= 31 && r < 33:
		return DiamondOre
	}
	if y < 20 && g.noise3(24, float64(x)/9, float64(y)/9, float64(z)/9) > 0.86 {
		return Obsidian
	}
	if y > 8 && y < 60 && g.noise3(25, float64(x)/12, float64(y)/6, float64(z)/12) > 0.85 {
		return Gravel
	}
	return Stone
}

func (g *Gen) decorate(c *Chunk, lx, lz, x, z, h, biome int, hc map[[2]int]int) {
	if h <= SeaLevel || h+1 >= CY {
		return
	}
	// plants on the ground
	above := c.B[idx(lx, h+1, lz)]
	if above == Air {
		r := g.unit(18, x, 0, z)
		switch biome {
		case Plains, Forest:
			switch {
			case r < 0.12:
				c.B[idx(lx, h+1, lz)] = TallGrass
			case r < 0.135:
				c.B[idx(lx, h+1, lz)] = FlowerRed
			case r < 0.15:
				c.B[idx(lx, h+1, lz)] = FlowerYellow
			}
		case Desert:
			if r < 0.01 {
				c.B[idx(lx, h+1, lz)] = DeadBush
			}
		}
	}
	// trees reach over the edge of a chunk: look at the roots around this column
	for oz := z - 2; oz <= z+2; oz++ {
		for ox := x - 2; ox <= x+2; ox++ {
			t, ok := g.treeAt(ox, oz, hc)
			if !ok {
				continue
			}
			for y := t.h + 1; y <= t.h+t.trunk+2 && y < CY; y++ {
				if id, ok := g.treeBlock(t, ox, oz, x, y, z); ok {
					if cur := c.B[idx(lx, y, lz)]; cur == Air || cur == TallGrass || cur == FlowerRed || cur == FlowerYellow || cur == DeadBush || (id == Log && cur == Leaves) {
						c.B[idx(lx, y, lz)] = id
					}
				}
			}
			if ox == x && oz == z && !t.cactus && lx >= 0 { // the tree stands on dirt, not on grass
				c.B[idx(lx, t.h, lz)] = Dirt
			}
		}
	}
}

// Spawn finds a dry place near the origin.
func (g *Gen) Spawn() (x, y, z int) {
	for r := 0; r < 400; r += 4 {
		for a := 0; a < 8; a++ {
			ang := float64(a) * math.Pi / 4
			px, pz := int(float64(r)*math.Cos(ang)), int(float64(r)*math.Sin(ang))
			if h := g.Height(px, pz); h > SeaLevel+1 && h < SeaLevel+20 && g.treeFree(px, pz, 5) {
				return px, h + 2, pz
			}
		}
	}
	return 0, SeaLevel + 20, 0
}

// treeFree says whether no tree grows within r blocks of a column.
func (g *Gen) treeFree(x, z, r int) bool {
	hc := map[[2]int]int{}
	for dz := -r; dz <= r; dz++ {
		for dx := -r; dx <= r; dx++ {
			if _, ok := g.treeAt(x+dx, z+dz, hc); ok {
				return false
			}
		}
	}
	return true
}
