package world

import (
	"bufio"
	"crypto/sha1"
	"encoding/base64"
	"encoding/binary"
	"errors"
	"io"
	"net"
	"net/http"
	"strings"
	"sync"
	"time"
)

// A tiny RFC 6455 server: text and binary messages, ping/pong, close. Enough for the page.

const (
	opText   = 1
	opBinary = 2
	opClose  = 8
	opPing   = 9
	opPong   = 10

	maxMessage = 64 << 10
)

type wsConn struct {
	c   net.Conn
	br  *bufio.Reader
	wmu sync.Mutex
}

func upgrade(w http.ResponseWriter, r *http.Request) (*wsConn, error) {
	if !strings.Contains(strings.ToLower(r.Header.Get("Connection")), "upgrade") || !strings.EqualFold(r.Header.Get("Upgrade"), "websocket") {
		http.Error(w, "websocket only", http.StatusBadRequest)
		return nil, errors.New("not a websocket request")
	}
	key := r.Header.Get("Sec-WebSocket-Key")
	if key == "" {
		http.Error(w, "no key", http.StatusBadRequest)
		return nil, errors.New("no key")
	}
	hj, ok := w.(http.Hijacker)
	if !ok {
		http.Error(w, "cannot hijack", http.StatusInternalServerError)
		return nil, errors.New("no hijacker")
	}
	c, rw, err := hj.Hijack()
	if err != nil {
		return nil, err
	}
	sum := sha1.Sum([]byte(key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"))
	resp := "HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: " +
		base64.StdEncoding.EncodeToString(sum[:]) + "\r\n\r\n"
	if _, err := io.WriteString(c, resp); err != nil {
		c.Close()
		return nil, err
	}
	return &wsConn{c: c, br: rw.Reader}, nil
}

// read returns the next text or binary message; control frames are answered here.
func (ws *wsConn) read() (op byte, data []byte, err error) {
	var msg []byte
	var msgOp byte
	for {
		var h [2]byte
		if _, err = io.ReadFull(ws.br, h[:]); err != nil {
			return
		}
		fin, fop := h[0]&0x80 != 0, h[0]&0x0f
		masked, n := h[1]&0x80 != 0, uint64(h[1]&0x7f)
		switch n {
		case 126:
			var b [2]byte
			if _, err = io.ReadFull(ws.br, b[:]); err != nil {
				return
			}
			n = uint64(binary.BigEndian.Uint16(b[:]))
		case 127:
			var b [8]byte
			if _, err = io.ReadFull(ws.br, b[:]); err != nil {
				return
			}
			n = binary.BigEndian.Uint64(b[:])
		}
		if n > maxMessage {
			return 0, nil, errors.New("message too big")
		}
		var mask [4]byte
		if masked {
			if _, err = io.ReadFull(ws.br, mask[:]); err != nil {
				return
			}
		}
		payload := make([]byte, n)
		if _, err = io.ReadFull(ws.br, payload); err != nil {
			return
		}
		if masked {
			for i := range payload {
				payload[i] ^= mask[i%4]
			}
		}
		switch fop {
		case opPing:
			_ = ws.write(opPong, payload)
			continue
		case opPong:
			continue
		case opClose:
			_ = ws.write(opClose, nil)
			return 0, nil, io.EOF
		case 0: // continuation
			msg = append(msg, payload...)
		default:
			msgOp, msg = fop, payload
		}
		if len(msg) > maxMessage {
			return 0, nil, errors.New("message too big")
		}
		if fin {
			return msgOp, msg, nil
		}
	}
}

func (ws *wsConn) write(op byte, data []byte) error {
	ws.wmu.Lock()
	defer ws.wmu.Unlock()
	hdr := []byte{0x80 | op}
	switch n := len(data); {
	case n < 126:
		hdr = append(hdr, byte(n))
	case n < 1<<16:
		hdr = append(hdr, 126, byte(n>>8), byte(n))
	default:
		hdr = append(hdr, 127, 0, 0, 0, 0, byte(n>>24), byte(n>>16), byte(n>>8), byte(n))
	}
	_ = ws.c.SetWriteDeadline(time.Now().Add(10 * time.Second))
	if _, err := ws.c.Write(append(hdr, data...)); err != nil {
		return err
	}
	return nil
}

func (ws *wsConn) close() { _ = ws.c.Close() }
