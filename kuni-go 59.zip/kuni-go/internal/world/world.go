package world

import (
	"bytes"
	"compress/gzip"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math/rand"
	"os"
	"path/filepath"
	"sync"
	"time"
)

type ckey [2]int

// DayLength is how long a game day lasts in real time.
const DayLength = 20 * time.Minute

// World is the blocks. It loads or generates chunks when they are asked for and saves the ones that were changed.
type World struct {
	mu     sync.RWMutex
	gen    *Gen
	dir    string
	meta   meta
	chunks map[ckey]*Chunk
	last   time.Time
}

type meta struct {
	Seed int64                 `json:"seed"`
	Time float64               `json:"time"` // fraction of a day, 0..1 (0.25 = noon)
	Home map[string][3]float64 `json:"home"` // where each player was last
}

// Open opens the world stored in dir (and creates it with a fresh seed when there is none).
func Open(dir string) (*World, error) {
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return nil, err
	}
	w := &World{dir: dir, chunks: map[ckey]*Chunk{}, last: time.Now()}
	raw, err := os.ReadFile(filepath.Join(dir, "world.json"))
	switch {
	case err == nil:
		if err := json.Unmarshal(raw, &w.meta); err != nil {
			return nil, fmt.Errorf("world.json: %w", err)
		}
	case errors.Is(err, os.ErrNotExist):
		w.meta = meta{Seed: rand.Int63(), Time: 0.12}
	default:
		return nil, err
	}
	if w.meta.Home == nil {
		w.meta.Home = map[string][3]float64{}
	}
	w.gen = NewGen(w.meta.Seed)
	return w, nil
}

func floorDiv(a, b int) int {
	q := a / b
	if (a%b != 0) && ((a < 0) != (b < 0)) {
		q--
	}
	return q
}

func floorMod(a, b int) int { return a - floorDiv(a, b)*b }

func (w *World) chunkFile(cx, cz int) string {
	return filepath.Join(w.dir, fmt.Sprintf("c.%d.%d.gz", cx, cz))
}

// load returns the chunk, reading it from disk or generating it. The caller holds the write lock.
func (w *World) loadLocked(cx, cz int) *Chunk {
	k := ckey{cx, cz}
	if c, ok := w.chunks[k]; ok {
		return c
	}
	var c *Chunk
	if f, err := os.Open(w.chunkFile(cx, cz)); err == nil {
		c = readChunk(f, cx, cz)
		f.Close()
	}
	if c == nil {
		c = w.gen.Generate(cx, cz)
	}
	w.chunks[k] = c
	return c
}

func readChunk(r io.Reader, cx, cz int) *Chunk {
	zr, err := gzip.NewReader(r)
	if err != nil {
		return nil
	}
	defer zr.Close()
	c := &Chunk{CX: cx, CZ: cz}
	if _, err := io.ReadFull(zr, c.B[:]); err != nil {
		return nil
	}
	return c
}

func (w *World) ensure(cx, cz int) {
	w.mu.RLock()
	_, ok := w.chunks[ckey{cx, cz}]
	w.mu.RUnlock()
	if !ok {
		w.mu.Lock()
		w.loadLocked(cx, cz)
		w.mu.Unlock()
	}
}

// Block returns the block at a position (air above and below the world).
func (w *World) Block(x, y, z int) uint8 {
	if y < 0 || y >= CY {
		return Air
	}
	cx, cz := floorDiv(x, CX), floorDiv(z, CZ)
	w.ensure(cx, cz)
	w.mu.RLock()
	defer w.mu.RUnlock()
	return w.chunks[ckey{cx, cz}].B[idx(floorMod(x, CX), y, floorMod(z, CZ))]
}

// SetBlock changes a block; it reports false when the position is outside the world.
func (w *World) SetBlock(x, y, z int, id uint8) bool {
	if y < 0 || y >= CY {
		return false
	}
	cx, cz := floorDiv(x, CX), floorDiv(z, CZ)
	w.mu.Lock()
	defer w.mu.Unlock()
	c := w.loadLocked(cx, cz)
	i := idx(floorMod(x, CX), y, floorMod(z, CZ))
	if c.B[i] != id {
		c.B[i] = id
		c.Dirty = true
	}
	return true
}

// EncodeChunk is the chunk as the page wants it: a marker byte, the chunk position and runs of (count, block).
func (w *World) EncodeChunk(cx, cz int) []byte {
	w.ensure(cx, cz)
	w.mu.RLock()
	defer w.mu.RUnlock()
	return encodeChunk(w.chunks[ckey{cx, cz}])
}

func encodeChunk(c *Chunk) []byte {
	out := make([]byte, 9, 9+3*512)
	out[0] = 1
	binary.LittleEndian.PutUint32(out[1:], uint32(int32(c.CX)))
	binary.LittleEndian.PutUint32(out[5:], uint32(int32(c.CZ)))
	run, cur := 0, c.B[0]
	flush := func() {
		out = append(out, byte(run), byte(run>>8), cur)
	}
	for _, b := range c.B {
		if b == cur && run < 65535 {
			run++
			continue
		}
		flush()
		cur, run = b, 1
	}
	flush()
	return out
}

// DecodeChunk is the inverse of EncodeChunk (used by tests).
func DecodeChunk(data []byte) (cx, cz int, blocks []byte, err error) {
	if len(data) < 9 || data[0] != 1 {
		return 0, 0, nil, errors.New("not a chunk")
	}
	cx, cz = int(int32(binary.LittleEndian.Uint32(data[1:]))), int(int32(binary.LittleEndian.Uint32(data[5:])))
	for p := 9; p+2 < len(data); p += 3 {
		n := int(data[p]) | int(data[p+1])<<8
		blocks = append(blocks, bytes.Repeat([]byte{data[p+2]}, n)...)
	}
	if len(blocks) != CX*CY*CZ {
		return 0, 0, nil, fmt.Errorf("chunk has %d blocks", len(blocks))
	}
	return cx, cz, blocks, nil
}

// Time advances the day and returns it (0..1).
func (w *World) Time() float64 {
	w.mu.Lock()
	defer w.mu.Unlock()
	now := time.Now()
	w.meta.Time += now.Sub(w.last).Seconds() / DayLength.Seconds()
	w.meta.Time -= float64(int(w.meta.Time))
	w.last = now
	return w.meta.Time
}

// Spawn is where new players appear.
func (w *World) Spawn() (x, y, z int) { return w.gen.Spawn() }

// Seed is the number the terrain grows from.
func (w *World) Seed() int64 { return w.meta.Seed }

// BiomeAt names the biome of a column.
func (w *World) BiomeAt(x, z int) string {
	return BiomeNames[w.gen.BiomeAt(x, z, w.gen.Height(x, z))]
}

// Ground is the y a player standing at (x,z) would stand at, looking down from fromY: the top of the first solid block.
func (w *World) Ground(x, z, fromY int) int {
	if fromY >= CY {
		fromY = CY - 1
	}
	for y := fromY; y >= 0; y-- {
		if isSolid(w.Block(x, y, z)) {
			return y + 1
		}
	}
	return 0
}

// Home and SetHome remember where a player was.
func (w *World) Home(name string) ([3]float64, bool) {
	w.mu.RLock()
	defer w.mu.RUnlock()
	p, ok := w.meta.Home[name]
	return p, ok
}

func (w *World) SetHome(name string, p [3]float64) {
	w.mu.Lock()
	w.meta.Home[name] = p
	w.mu.Unlock()
}

// Unload drops the chunks nobody is near (the changed ones are saved first).
func (w *World) Unload(keep func(cx, cz int) bool) {
	w.mu.Lock()
	defer w.mu.Unlock()
	for k, c := range w.chunks {
		if keep(k[0], k[1]) {
			continue
		}
		if c.Dirty {
			if err := w.saveChunk(c); err != nil {
				continue
			}
		}
		delete(w.chunks, k)
	}
}

func (w *World) saveChunk(c *Chunk) error {
	tmp := w.chunkFile(c.CX, c.CZ) + ".part"
	f, err := os.Create(tmp)
	if err != nil {
		return err
	}
	zw := gzip.NewWriter(f)
	_, err = zw.Write(c.B[:])
	if cerr := zw.Close(); err == nil {
		err = cerr
	}
	if cerr := f.Close(); err == nil {
		err = cerr
	}
	if err != nil {
		os.Remove(tmp)
		return err
	}
	c.Dirty = false
	return os.Rename(tmp, w.chunkFile(c.CX, c.CZ))
}

// Save writes every changed chunk and the world file.
func (w *World) Save() error {
	w.mu.Lock()
	defer w.mu.Unlock()
	var first error
	for _, c := range w.chunks {
		if c.Dirty {
			if err := w.saveChunk(c); err != nil && first == nil {
				first = err
			}
		}
	}
	raw, _ := json.Marshal(w.meta)
	tmp := filepath.Join(w.dir, "world.json.part")
	if err := os.WriteFile(tmp, raw, 0o644); err != nil {
		return err
	}
	if err := os.Rename(tmp, filepath.Join(w.dir, "world.json")); err != nil && first == nil {
		first = err
	}
	return first
}

// Loaded is the number of chunks in memory.
func (w *World) Loaded() int {
	w.mu.RLock()
	defer w.mu.RUnlock()
	return len(w.chunks)
}
