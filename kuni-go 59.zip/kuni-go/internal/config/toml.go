// Package config loads config.toml. It contains a small TOML subset parser
// (sections, string/int/float/bool scalars, comments) so the project has no
// third-party dependencies.
package config

import (
	"bufio"
	"fmt"
	"strconv"
	"strings"
)

// tomlDoc is a parsed config file: the values by "section.key" and the keys that were set more than once.
type tomlDoc struct {
	values map[string]any
	dups   []string
}

// parseTOML parses a flat-section TOML document into map["section.key"] = value.
// Values are string, int64, float64 or bool.
func parseTOML(src string) (map[string]any, error) {
	d, err := parseTOMLDoc(src)
	if err != nil {
		return nil, err
	}
	return d.values, nil
}

// parseTOMLDoc is parseTOML that also reports duplicate keys.
func parseTOMLDoc(src string) (tomlDoc, error) {
	out := map[string]any{}
	var dups []string
	section := ""
	src = strings.TrimPrefix(src, "\ufeff") // a BOM left by a Windows editor
	sc := bufio.NewScanner(strings.NewReader(src))
	line := 0
	for sc.Scan() {
		line++
		text := strings.TrimSpace(stripComment(sc.Text()))
		if text == "" {
			continue
		}
		if strings.HasPrefix(text, "[") {
			if !strings.HasSuffix(text, "]") {
				return tomlDoc{}, fmt.Errorf("line %d: bad table header %q", line, text)
			}
			section = strings.TrimSpace(text[1 : len(text)-1])
			continue
		}
		eq := strings.Index(text, "=")
		if eq < 0 {
			return tomlDoc{}, fmt.Errorf("line %d: expected key = value", line)
		}
		key := strings.Trim(strings.TrimSpace(text[:eq]), `"`)
		val, err := parseValue(strings.TrimSpace(text[eq+1:]))
		if err != nil {
			return tomlDoc{}, fmt.Errorf("line %d: %w", line, err)
		}
		full := key
		if section != "" {
			full = section + "." + key
		}
		if _, ok := out[full]; ok {
			dups = append(dups, full)
		}
		out[full] = val
	}
	return tomlDoc{values: out, dups: dups}, sc.Err()
}

// stripComment removes a trailing # comment that is not inside a string.
func stripComment(s string) string {
	inStr, quote := false, byte(0)
	for i := 0; i < len(s); i++ {
		switch s[i] {
		case '\\':
			if inStr && quote == '"' { // escapes exist only in basic strings
				i++
			}
		case '"', '\'':
			switch {
			case !inStr:
				inStr, quote = true, s[i]
			case quote == s[i]:
				inStr = false
			}
		case '#':
			if !inStr {
				return s[:i]
			}
		}
	}
	return s
}

func parseValue(v string) (any, error) {
	switch {
	case v == "true":
		return true, nil
	case v == "false":
		return false, nil
	case strings.HasPrefix(v, `"`):
		return strconv.Unquote(v)
	case strings.HasPrefix(v, "'"): // a TOML literal string: no escapes at all
		if len(v) < 2 || !strings.HasSuffix(v, "'") || strings.Contains(v[1:len(v)-1], "'") {
			return nil, fmt.Errorf("bad literal string %s", v)
		}
		return v[1 : len(v)-1], nil
	}
	if u := strings.ReplaceAll(v, "_", ""); u != v && u != "" { // TOML allows 10_000
		v = u
	}
	if i, err := strconv.ParseInt(v, 10, 64); err == nil {
		return i, nil
	}
	if f, err := strconv.ParseFloat(v, 64); err == nil {
		return f, nil
	}
	return nil, fmt.Errorf("unsupported value %q", v)
}

// formatTOML renders the default config with comments, grouped by section.
func formatTOML(sections []tomlSection) string {
	var b strings.Builder
	for i, s := range sections {
		if i > 0 {
			b.WriteString("\n")
		}
		fmt.Fprintf(&b, "[%s]\n", s.name)
		for _, kv := range s.items {
			if kv.comment != "" {
				fmt.Fprintf(&b, "# %s\n", kv.comment)
			}
			fmt.Fprintf(&b, "%s = %s\n", kv.key, formatScalar(kv.value))
		}
	}
	return b.String()
}

func formatScalar(v any) string {
	switch t := v.(type) {
	case string:
		return strconv.Quote(t)
	case float64:
		return strconv.FormatFloat(t, 'f', -1, 64)
	default:
		return fmt.Sprint(t)
	}
}

type tomlItem struct {
	key     string
	value   any
	comment string
}

type tomlSection struct {
	name  string
	items []tomlItem
}
