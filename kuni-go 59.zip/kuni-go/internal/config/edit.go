package config

import (
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"

	"kuni/internal/store"
)

// Key describes one configurable key (for the admin panel).
type Key struct {
	Section, Name, Comment string
	Kind                   string // string | bool | int | float
	Secret                 bool
}

func isSecret(key string) bool {
	return key == "api_key" || key == "bot_token" || key == "api_hash" || key == "admin_token" || key == "services" || key == "ics_urls" || key == "password" || strings.HasSuffix(key, "_password") || strings.HasSuffix(key, "_token") || strings.HasSuffix(key, "_key")
}

// Keys lists every known key in file order.
func Keys() []Key {
	var out []Key
	for _, f := range schema {
		k := "string"
		switch f.def.(type) {
		case bool:
			k = "bool"
		case int64:
			k = "int"
		case float64:
			k = "float"
		}
		out = append(out, Key{Section: f.section, Name: f.key, Comment: f.comment, Kind: k, Secret: isSecret(f.key)})
	}
	return out
}

// Value renders the current value of a key (durations in seconds, debounce in ms).
func (c *Config) Value(section, key string) string {
	if f, ok := index[section+"."+key]; ok {
		switch p := f.ptr(c).(type) {
		case *string:
			return *p
		case *bool:
			return strconv.FormatBool(*p)
		case *int64:
			return strconv.FormatInt(*p, 10)
		case *int:
			return strconv.Itoa(*p)
		case *float64:
			return strconv.FormatFloat(*p, 'f', -1, 64)
		case *time.Duration:
			if strings.HasSuffix(key, "_ms") {
				return strconv.FormatInt(p.Milliseconds(), 10)
			}
			return strconv.FormatInt(int64(*p/time.Second), 10)
		}
	}
	return ""
}

func lookup(section, key string) (field, bool) {
	if f, ok := index[section+"."+key]; ok {
		return *f, true
	}
	return field{}, false
}

// ParseFor converts user input to the type of the key.
func ParseFor(section, key, raw string) (any, error) {
	f, ok := lookup(section, key)
	if !ok {
		return nil, fmt.Errorf("unknown key %s.%s", section, key)
	}
	raw = strings.TrimSpace(raw)
	switch f.def.(type) {
	case string:
		if len(raw) >= 2 && strings.HasPrefix(raw, `"`) && strings.HasSuffix(raw, `"`) {
			return strconv.Unquote(raw)
		}
		return raw, nil
	case bool:
		switch strings.ToLower(raw) {
		case "true", "on", "yes", "1":
			return true, nil
		case "false", "off", "no", "0":
			return false, nil
		}
		return nil, fmt.Errorf("%s.%s wants true or false", section, key)
	case int64:
		n, err := strconv.ParseInt(raw, 10, 64)
		if err != nil {
			return nil, fmt.Errorf("%s.%s wants an integer", section, key)
		}
		return n, nil
	case float64:
		n, err := strconv.ParseFloat(raw, 64)
		if err != nil {
			return nil, fmt.Errorf("%s.%s wants a number", section, key)
		}
		return n, nil
	}
	return nil, fmt.Errorf("unsupported type for %s.%s", section, key)
}

// SetInText returns src with section.key set to value. An existing assignment is replaced in place,
// extra duplicates of the same key in that section are dropped (strict TOML rejects them), a missing key
// is inserted right under its section header, and a missing section is appended.
func SetInText(src, section, key string, value any) string {
	line := key + " = " + formatScalar(value)
	lines := strings.Split(strings.TrimRight(src, "\n"), "\n")
	var out []string
	inSec, secFound, done := false, false, false
	isKey := func(l string) bool {
		t := strings.TrimSpace(l)
		if !strings.HasPrefix(t, key) {
			return false
		}
		rest := strings.TrimSpace(t[len(key):])
		return strings.HasPrefix(rest, "=")
	}
	for _, l := range lines {
		t := strings.TrimSpace(l)
		if strings.HasPrefix(t, "[") && strings.HasSuffix(strings.TrimSpace(stripHashComment(t)), "]") {
			inSec = strings.TrimSpace(strings.Trim(strings.TrimSpace(stripHashComment(t)), "[]")) == section
			out = append(out, l)
			if inSec {
				secFound = true
				if !done {
					// insert now; the old assignment (if any) is removed when met below
					out = append(out, line)
					done = true
				}
			}
			continue
		}
		if inSec && isKey(l) {
			continue // replaced by the line inserted under the header
		}
		out = append(out, l)
	}
	if !secFound {
		out = append(out, "", "["+section+"]", line)
	}
	return strings.Join(out, "\n") + "\n"
}

func stripHashComment(s string) string {
	if i := strings.Index(s, "#"); i >= 0 {
		return s[:i]
	}
	return s
}

// SetKey validates and writes section.key = raw into the config file (atomically, keeping a .bak of the old file).
// The Holder's watcher picks the change up and hot-reloads it.
func SetKey(path, section, key, raw string) error {
	v, err := ParseFor(section, key, raw)
	if err != nil {
		return err
	}
	b, err := os.ReadFile(path)
	if err != nil {
		return err
	}
	next := SetInText(string(b), section, key, v)
	if _, err := parseTOML(next); err != nil {
		return fmt.Errorf("result would not be valid TOML: %w", err)
	}
	if err := store.WriteFile(path+".bak", b, store.Private); err != nil {
		return err
	}
	return store.WriteFile(path, []byte(next), store.Private)
}
