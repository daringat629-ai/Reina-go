package config

import (
	"strings"
	"testing"
	"time"
)

func hasWarning(c *Config, part string) bool {
	for _, w := range c.Warnings {
		if strings.Contains(w, part) {
			return true
		}
	}
	return false
}

func TestUnknownAndDuplicateKeysAreReportedNotFatal(t *testing.T) {
	c, err := Parse("[telegram]\ndebounce_msec = 5\ndebounce_ms = 100\ndebounce_ms = 200\n")
	if err != nil {
		t.Fatal(err)
	}
	if !hasWarning(c, "telegram.debounce_msec") {
		t.Fatalf("typo not reported: %v", c.Warnings)
	}
	if !hasWarning(c, "more than once") || c.DebounceWindow != 200*time.Millisecond {
		t.Fatalf("duplicate: %v %v", c.Warnings, c.DebounceWindow)
	}
}

func TestLiteralStringsUnderscoresAndBOM(t *testing.T) {
	src := "\ufeff[llm]\napi_key = 'sk-#not-a-comment\\x' # real comment\ndaily_token_limit = 1_000_000\n"
	c, err := Parse(src)
	if err != nil {
		t.Fatal(err)
	}
	if c.LLMAPIKey != `sk-#not-a-comment\x` {
		t.Fatalf("literal string: %q", c.LLMAPIKey)
	}
	if c.DailyTokenLimit != 1_000_000 {
		t.Fatalf("underscores: %d", c.DailyTokenLimit)
	}
}

func TestValidateClampsNonsense(t *testing.T) {
	src := `
[presence]
read_delay_min_secs = 10
read_delay_max_secs = 2
late_reply_percent = 250
[telegram]
lockdown = "Papik_Only"
mode = "bott"
typo_chance = 3.5
[report]
hour = 31
[autonomy]
timezone = "Mars/Olympus"
quiet_from = "25:99"
`
	c, err := Parse(src)
	if err != nil {
		t.Fatal(err)
	}
	if c.ReadDelayMax != 10 || c.LateReplyPercent != 100 || c.TypoChance != 1 || c.ReportHour != 9 {
		t.Fatalf("not clamped: max=%d late=%d typo=%v hour=%d", c.ReadDelayMax, c.LateReplyPercent, c.TypoChance, c.ReportHour)
	}
	if c.Lockdown != "papik_only" || c.Mode != "user" {
		t.Fatalf("enums: %q %q", c.Lockdown, c.Mode)
	}
	for _, part := range []string{"read_delay_max_secs", "late_reply_percent", "telegram.mode", "Mars/Olympus", "quiet_from", "report.hour"} {
		if !hasWarning(c, part) {
			t.Errorf("no warning about %s: %v", part, c.Warnings)
		}
	}
	if c.Location() != time.Local {
		t.Fatal("unknown zone falls back to the server's")
	}
}

func TestDefaultsProduceNoWarningsButTheOwnerHint(t *testing.T) {
	c, err := Parse("")
	if err != nil {
		t.Fatal(err)
	}
	if len(c.Warnings) != 0 { // telegram is off by default, so no owner hint either
		t.Fatalf("clean defaults warn: %v", c.Warnings)
	}
	c, _ = Parse("[general]\ntelegram_enabled = true\n")
	if !hasWarning(c, "papik_chat_id") {
		t.Fatal("missing owner id must be pointed out")
	}
}

func TestDerivedHelpers(t *testing.T) {
	c, _ := Parse("[general]\npapik_chat_id = 42\n[autonomy]\ntimezone = \"Asia/Bishkek\"\n[capabilities]\ntts_backend = \"openai\"\n")
	if !c.IsOwner(42) || c.IsOwner(0) || c.IsOwner(7) {
		t.Fatal("IsOwner")
	}
	if !c.OwnerChat(42) {
		t.Fatal("owner tools are on by default")
	}
	if c.Location().String() != "Asia/Bishkek" || !c.TTSOn() {
		t.Fatal("location / tts")
	}
	var zero Config
	if zero.IsOwner(0) || zero.TTSOn() {
		t.Fatal("a zero config has no owner and no TTS")
	}
}
