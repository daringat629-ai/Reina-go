// Package tracker keeps the owner's habits (did it today: a walk, no sugar, 8 glasses of water) and measurements
// (weight, sleep hours, steps, pressure) day by day, and works out streaks, averages and trends from them.
package tracker

import (
	"errors"
	"fmt"
	"math"
	"sort"
	"strings"
	"sync"
	"time"

	"kuni/internal/store"
)

const (
	Habit  = "habit"  // done or not each day; the values of a day add up (glasses of water), the goal is per day
	Metric = "metric" // a measurement; the last value of a day counts
)

// Point is one record.
type Point struct {
	Date  string  `json:"date"` // YYYY-MM-DD
	Value float64 `json:"value"`
	Note  string  `json:"note,omitempty"`
}

// Item is one habit or measurement.
type Item struct {
	Name    string    `json:"name"`
	Kind    string    `json:"kind"`
	Unit    string    `json:"unit,omitempty"`
	Goal    float64   `json:"goal,omitempty"` // habit: per day (default 1); metric: the value to reach
	Created time.Time `json:"created"`
	Points  []Point   `json:"points,omitempty"`
}

type file struct {
	Items []Item `json:"items"`
}

const (
	MaxItems  = 50
	MaxPoints = 5000
)

type Store struct {
	mu    sync.Mutex
	path  string
	f     file
	saver store.Saver
}

// New loads the tracker (missing = empty; a broken file is moved aside and reported).
func New(path string) *Store {
	s := &Store{path: path, saver: store.Saver{What: "tracker"}}
	store.Load("tracker", path, &s.f)
	return s
}

func key(name string) string { return strings.Join(strings.Fields(strings.ToLower(name)), " ") }

func (s *Store) findLocked(name string) *Item {
	k := key(name)
	for i := range s.f.Items {
		if key(s.f.Items[i].Name) == k {
			return &s.f.Items[i]
		}
	}
	return nil
}

// Add creates a habit or a measurement (or updates its unit and goal when it exists).
func (s *Store) Add(name, kind, unit string, goal float64, now time.Time) (Item, error) {
	name = strings.TrimSpace(name)
	if name == "" {
		return Item{}, errors.New("name it")
	}
	switch strings.ToLower(kind) {
	case "", Habit, "привычка":
		kind = Habit
	case Metric, "measure", "показатель", "замер":
		kind = Metric
	default:
		return Item{}, fmt.Errorf("kind is habit or metric, not %q", kind)
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if it := s.findLocked(name); it != nil {
		if unit != "" {
			it.Unit = unit
		}
		if goal != 0 {
			it.Goal = goal
		}
		return *it, s.saver.Save(s.path, s.f)
	}
	if len(s.f.Items) >= MaxItems {
		return Item{}, fmt.Errorf("too many trackers (%d)", MaxItems)
	}
	it := Item{Name: name, Kind: kind, Unit: strings.TrimSpace(unit), Goal: goal, Created: now}
	s.f.Items = append(s.f.Items, it)
	return it, s.saver.Save(s.path, s.f)
}

// Log records a value on a day. A habit or measurement that does not exist yet is created (a measurement when the
// value is not 1, a habit otherwise).
func (s *Store) Log(name, date string, value float64, note string, now time.Time) (Item, bool, error) {
	if _, err := time.Parse("2006-01-02", date); err != nil {
		return Item{}, false, fmt.Errorf("bad date %q", date)
	}
	if math.IsNaN(value) || math.IsInf(value, 0) {
		return Item{}, false, errors.New("the value must be a number")
	}
	s.mu.Lock()
	it := s.findLocked(name)
	s.mu.Unlock()
	created := false
	if it == nil {
		kind := Habit
		if value != 1 && value != 0 {
			kind = Metric
		}
		if _, err := s.Add(name, kind, "", 0, now); err != nil {
			return Item{}, false, err
		}
		created = true
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	it = s.findLocked(name)
	if len(it.Points) >= MaxPoints {
		it.Points = it.Points[len(it.Points)-MaxPoints+1:]
	}
	it.Points = append(it.Points, Point{Date: date, Value: value, Note: strings.TrimSpace(note)})
	sort.SliceStable(it.Points, func(i, j int) bool { return it.Points[i].Date < it.Points[j].Date })
	return *it, created, s.saver.Save(s.path, s.f)
}

// Undo removes the last record of an item.
func (s *Store) Undo(name string) (Point, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	it := s.findLocked(name)
	if it == nil {
		return Point{}, fmt.Errorf("no tracker %q", name)
	}
	if len(it.Points) == 0 {
		return Point{}, errors.New("nothing to undo")
	}
	p := it.Points[len(it.Points)-1]
	it.Points = it.Points[:len(it.Points)-1]
	return p, s.saver.Save(s.path, s.f)
}

// Delete removes an item with its history.
func (s *Store) Delete(name string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	k := key(name)
	for i, it := range s.f.Items {
		if key(it.Name) == k {
			s.f.Items = append(s.f.Items[:i], s.f.Items[i+1:]...)
			return s.saver.Save(s.path, s.f)
		}
	}
	return fmt.Errorf("no tracker %q", name)
}

// Get returns an item.
func (s *Store) Get(name string) (Item, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if it := s.findLocked(name); it != nil {
		return *it, true
	}
	return Item{}, false
}

// All returns every item.
func (s *Store) All() []Item {
	s.mu.Lock()
	defer s.mu.Unlock()
	return append([]Item(nil), s.f.Items...)
}

// Daily is the value of each day that has records: the sum for a habit, the last value for a measurement.
func (it Item) Daily() map[string]float64 {
	out := map[string]float64{}
	for _, p := range it.Points {
		if it.Kind == Habit {
			out[p.Date] += p.Value
		} else {
			out[p.Date] = p.Value
		}
	}
	return out
}

func (it Item) goal() float64 {
	if it.Kind == Habit && it.Goal <= 0 {
		return 1
	}
	return it.Goal
}

// Status is what an item looks like today.
type Status struct {
	Item       Item
	Today      float64
	DoneToday  bool
	Streak     int    // habit: days in a row up to today (or yesterday, when today is not done yet)
	Best       int    // habit: the longest streak
	Week       string // habit: the last 7 days, oldest first: ✓ done, · not
	Rate30     int    // habit: percent of the last 30 days done
	Last       float64
	LastDate   string
	Prev       float64 // metric: the value before the last
	Avg7       float64
	Avg30      float64
	Min, Max   float64
	Count      int
	TrendPer7d float64 // metric: change per week by the least squares line over the last 30 days
}

// Of works out the status of an item on the day today (YYYY-MM-DD).
func Of(it Item, today time.Time) Status {
	st := Status{Item: it}
	daily := it.Daily()
	day := func(t time.Time) string { return t.Format("2006-01-02") }
	goal := it.goal()
	done := func(t time.Time) bool {
		v, ok := daily[day(t)]
		return ok && v >= goal && v != 0
	}
	st.Today = daily[day(today)]
	st.Count = len(it.Points)
	if it.Kind == Habit {
		st.DoneToday = done(today)
		start := today
		if !st.DoneToday {
			start = today.AddDate(0, 0, -1)
		}
		for d := start; done(d); d = d.AddDate(0, 0, -1) {
			st.Streak++
		}
		var days []string
		for k := range daily {
			days = append(days, k)
		}
		sort.Strings(days)
		run := 0
		var prev time.Time
		for _, k := range days {
			t, _ := time.ParseInLocation("2006-01-02", k, today.Location())
			if !done(t) {
				run = 0
				continue
			}
			if !prev.IsZero() && t.Sub(prev) <= 25*time.Hour && run > 0 {
				run++
			} else {
				run = 1
			}
			prev = t
			st.Best = max(st.Best, run)
		}
		var w strings.Builder
		for i := 6; i >= 0; i-- {
			if done(today.AddDate(0, 0, -i)) {
				w.WriteString("✓")
			} else {
				w.WriteString("·")
			}
		}
		st.Week = w.String()
		n := 0
		for i := 0; i < 30; i++ {
			if done(today.AddDate(0, 0, -i)) {
				n++
			}
		}
		st.Rate30 = n * 100 / 30
		return st
	}
	var keys []string
	for k := range daily {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	if len(keys) == 0 {
		return st
	}
	st.LastDate = keys[len(keys)-1]
	st.Last = daily[st.LastDate]
	if len(keys) > 1 {
		st.Prev = daily[keys[len(keys)-2]]
	}
	st.Min, st.Max = math.Inf(1), math.Inf(-1)
	for _, k := range keys {
		st.Min, st.Max = math.Min(st.Min, daily[k]), math.Max(st.Max, daily[k])
	}
	avg := func(days int) float64 {
		from := day(today.AddDate(0, 0, -(days - 1)))
		s, n := 0.0, 0
		for _, k := range keys {
			if k >= from && k <= day(today) {
				s += daily[k]
				n++
			}
		}
		if n == 0 {
			return math.NaN()
		}
		return s / float64(n)
	}
	st.Avg7, st.Avg30 = avg(7), avg(30)
	// least squares over the last 30 days: the slope per day, times 7
	from := today.AddDate(0, 0, -29)
	var xs, ys []float64
	for _, k := range keys {
		t, _ := time.ParseInLocation("2006-01-02", k, today.Location())
		if !t.Before(from) && !t.After(today) {
			xs = append(xs, t.Sub(from).Hours()/24)
			ys = append(ys, daily[k])
		}
	}
	if len(xs) >= 3 {
		mx, my := mean(xs), mean(ys)
		num, den := 0.0, 0.0
		for i := range xs {
			num += (xs[i] - mx) * (ys[i] - my)
			den += (xs[i] - mx) * (xs[i] - mx)
		}
		if den > 0 {
			st.TrendPer7d = num / den * 7
		}
	}
	return st
}

func mean(v []float64) float64 {
	s := 0.0
	for _, x := range v {
		s += x
	}
	return s / float64(len(v))
}
