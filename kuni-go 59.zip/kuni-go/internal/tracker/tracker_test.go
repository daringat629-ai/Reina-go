package tracker

import (
	"math"
	"path/filepath"
	"testing"
	"time"
)

func TestHabitStreaks(t *testing.T) {
	s := New(filepath.Join(t.TempDir(), "t.json"))
	now := time.Date(2026, 10, 23, 20, 0, 0, 0, time.UTC)
	s.Add("вода", Habit, "стаканов", 8, now)
	for _, d := range []string{"2026-10-17", "2026-10-18", "2026-10-20", "2026-10-21", "2026-10-22"} {
		s.Log("вода", d, 8, "", now)
	}
	s.Log("Вода", "2026-10-23", 5, "", now) // not yet enough today
	it, _ := s.Get("ВОДА")
	st := Of(it, now)
	if st.DoneToday || st.Streak != 3 || st.Best != 3 || st.Week != "✓✓·✓✓✓·" || st.Today != 5 {
		t.Fatalf("%+v", st)
	}
	s.Log("вода", "2026-10-23", 3, "", now)
	it, _ = s.Get("вода")
	if st = Of(it, now); !st.DoneToday || st.Streak != 4 || st.Best != 4 {
		t.Fatalf("after the evening glasses: %+v", st)
	}
	if p, err := s.Undo("вода"); err != nil || p.Value != 3 {
		t.Fatal(p, err)
	}
}

func TestMetricTrend(t *testing.T) {
	s := New(filepath.Join(t.TempDir(), "t.json"))
	now := time.Date(2026, 10, 23, 9, 0, 0, 0, time.UTC)
	it, created, err := s.Log("вес", "2026-10-01", 80, "", now)
	if err != nil || !created || it.Kind != Metric {
		t.Fatalf("a value makes a measurement: %+v %v", it, err)
	}
	for i := 1; i <= 22; i++ {
		d := time.Date(2026, 10, 1+i, 0, 0, 0, 0, time.UTC).Format("2006-01-02")
		s.Log("вес", d, 80-0.1*float64(i), "", now)
	}
	it, _ = s.Get("вес")
	st := Of(it, now)
	if st.Last != 77.8 || st.LastDate != "2026-10-23" || math.Abs(st.TrendPer7d+0.7) > 1e-6 || st.Min != 77.8 || st.Max != 80 {
		t.Fatalf("%+v", st)
	}
	if math.Abs(st.Avg7-78.1) > 1e-9 {
		t.Fatalf("avg7 %v", st.Avg7)
	}
	// reload
	s2 := New(filepath.Join(filepath.Dir(s.path), "t.json"))
	if it, ok := s2.Get("вес"); !ok || len(it.Points) != 23 {
		t.Fatal("not saved")
	}
}
