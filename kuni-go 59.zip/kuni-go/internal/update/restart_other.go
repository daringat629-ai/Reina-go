//go:build windows

package update

import "errors"

// Restart is not supported on Windows.
func Restart() error {
	return errors.New("перезапуск на месте не поддерживается на этой системе")
}
