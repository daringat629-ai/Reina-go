//go:build !windows

package update

import (
	"errors"
	"os"
	"syscall"
)

// Restart replaces the running process with a fresh copy of the program file (same arguments and environment,
// so LD_LIBRARY_PATH survives). It only returns on failure.
func Restart() error {
	p := Exe()
	if p == "" {
		return errors.New("не знаю, где лежит программа")
	}
	return syscall.Exec(p, os.Args, os.Environ())
}
