package update

import (
	"archive/zip"
	"bytes"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func elf(tag string, pad int) []byte {
	return append([]byte("\x7fELF"+tag), bytes.Repeat([]byte{7}, pad)...)
}

func mkzip(t *testing.T, files map[string][]byte) string {
	t.Helper()
	p := filepath.Join(t.TempDir(), "a.zip")
	f, err := os.Create(p)
	if err != nil {
		t.Fatal(err)
	}
	zw := zip.NewWriter(f)
	for n, b := range files {
		w, _ := zw.Create(n)
		_, _ = w.Write(b)
	}
	if err := zw.Close(); err != nil {
		t.Fatal(err)
	}
	f.Close()
	return p
}

func TestInspectRejectsBrokenAndStrange(t *testing.T) {
	dir := t.TempDir()
	good := mkzip(t, map[string][]byte{"reina-tdlib": elf("a", 5000)})
	if info, err := Inspect(good, dir); err != nil || len(info.Files) != 1 || !info.Files[0].Changed {
		t.Fatalf("good archive: %+v %v", info, err)
	}
	// cut the archive in the middle, like a download that stopped
	b, _ := os.ReadFile(good)
	cut := filepath.Join(t.TempDir(), "cut.zip")
	_ = os.WriteFile(cut, b[:len(b)/2], 0o644)
	if _, err := Inspect(cut, dir); err == nil || !strings.Contains(err.Error(), "не до конца") {
		t.Fatalf("a truncated archive must be refused, got %v", err)
	}
	for name, files := range map[string]map[string][]byte{
		"extra file":  {"reina-tdlib": elf("a", 10), "evil.sh": []byte("#!/bin/sh")},
		"path":        {"../reina-tdlib": elf("a", 10)},
		"not elf":     {"reina-tdlib": []byte("hello world, not a program")},
		"no program":  {"libtdjson.so": elf("l", 10)},
		"empty entry": {"reina-tdlib": {}},
	} {
		if _, err := Inspect(mkzip(t, files), dir); err == nil {
			t.Errorf("%s: should be refused", name)
		}
	}
}

func TestApplyKeepsPrevAndRollsBackOnSecondStart(t *testing.T) {
	dir := t.TempDir()
	_ = os.WriteFile(filepath.Join(dir, "reina-tdlib"), elf("old", 100), 0o755)
	_ = os.WriteFile(filepath.Join(dir, "libtdjson.so"), elf("lib", 300), 0o755)
	z := mkzip(t, map[string][]byte{"reina-tdlib": elf("new", 200), "libtdjson.so": elf("lib", 300)})

	info, err := Inspect(z, dir)
	if err != nil {
		t.Fatal(err)
	}
	for _, f := range info.Files {
		if f.Name == "libtdjson.so" && f.Changed {
			t.Fatal("an identical library must not be rewritten (it is 50 MB on the real server)")
		}
	}
	names, err := Apply(z, dir)
	if err != nil || len(names) != 1 || names[0] != "reina-tdlib" {
		t.Fatalf("apply: %v %v", names, err)
	}
	cur, _ := os.ReadFile(filepath.Join(dir, "reina-tdlib"))
	prev, _ := os.ReadFile(filepath.Join(dir, "reina-tdlib.prev"))
	if !bytes.HasPrefix(cur, []byte("\x7fELFnew")) || !bytes.HasPrefix(prev, []byte("\x7fELFold")) {
		t.Fatalf("files not swapped: cur=%q prev=%q", cur[:8], prev[:8])
	}
	if !Pending(dir) {
		t.Fatal("the pending marker must exist after an install")
	}
	if _, err := Apply(z, dir); err == nil {
		t.Fatal("installing the same archive again must say there is nothing new")
	}

	// first start of the new build: allowed, marker stays
	if Boot(dir) {
		t.Fatal("the first start must not roll back")
	}
	// it never confirmed itself (crashed), so the second start restores the old build
	if !Boot(dir) {
		t.Fatal("the second start without confirmation must roll back")
	}
	cur, _ = os.ReadFile(filepath.Join(dir, "reina-tdlib"))
	if !bytes.HasPrefix(cur, []byte("\x7fELFold")) {
		t.Fatalf("rollback did not restore the old build: %q", cur[:8])
	}
	if Pending(dir) || len(Prev(dir)) != 0 {
		t.Fatal("marker and .prev must be gone after the rollback")
	}
}

func TestConfirmStopsRollback(t *testing.T) {
	dir := t.TempDir()
	_ = os.WriteFile(filepath.Join(dir, "reina-tdlib"), elf("old", 10), 0o755)
	_, err := Apply(mkzip(t, map[string][]byte{"reina-tdlib": elf("new", 20)}), dir)
	if err != nil {
		t.Fatal(err)
	}
	Boot(dir)
	Confirm(dir)
	if Boot(dir) {
		t.Fatal("a confirmed build must never be rolled back")
	}
	if got := Prev(dir); len(got) != 1 {
		t.Fatalf("the .prev copy must stay for a manual rollback, got %v", got)
	}
	if names, err := Rollback(dir); err != nil || len(names) != 1 {
		t.Fatalf("manual rollback: %v %v", names, err)
	}
	if _, err := Rollback(dir); err == nil {
		t.Fatal("with nothing to restore, rollback must say so")
	}
}
