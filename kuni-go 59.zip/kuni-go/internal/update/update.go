// Package update replaces the running program with a new build from a zip (reina-tdlib, optionally libtdjson.so),
// checks the archive end to end first (so a half-downloaded file can never be installed), keeps the previous files
// as *.prev and rolls back on its own when the new build does not come up.
package update

import (
	"archive/zip"
	"encoding/json"
	"errors"
	"fmt"
	"hash/crc32"
	"io"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"kuni/internal/maint"
	"kuni/internal/store"
)

const (
	pendingFile = "update.pending"
	maxEntry    = 400 << 20
	// ConfirmAfter is how long a freshly installed build must stay up before the old one is forgotten.
	ConfirmAfter = 60 * time.Second
)

// FileInfo is one file inside an archive.
type FileInfo struct {
	Name    string `json:"name"`
	Size    int64  `json:"size"`
	Changed bool   `json:"changed"` // differs from what is installed now
}

// Info is the verdict about an archive.
type Info struct {
	Files    []FileInfo `json:"files"`
	NeedFree int64      `json:"need_free"` // bytes the new files take
}

var (
	mu      sync.Mutex
	exePath string
	stop    func()
	asked   bool
)

// Init remembers where the running program lives (before it can be replaced under our feet).
func Init() {
	mu.Lock()
	defer mu.Unlock()
	p, err := os.Executable()
	if err != nil {
		return
	}
	exePath = strings.TrimSuffix(p, " (deleted)")
}

// Exe is the path of the running program ("" if unknown).
func Exe() string {
	mu.Lock()
	defer mu.Unlock()
	return exePath
}

// Dir is the directory holding the program and libtdjson.so.
func Dir() string {
	if p := Exe(); p != "" {
		return filepath.Dir(p)
	}
	return "."
}

// OnRestart registers how to stop the program gracefully; Restart then re-executes it.
func OnRestart(f func()) {
	mu.Lock()
	defer mu.Unlock()
	stop = f
}

// RequestRestart stops the program gracefully; main re-executes it once everything has finished.
func RequestRestart() {
	mu.Lock()
	f := stop
	asked = true
	mu.Unlock()
	if f != nil {
		f()
	}
}

// Requested says whether RequestRestart was called.
func Requested() bool {
	mu.Lock()
	defer mu.Unlock()
	return asked
}

// allowed names inside an archive: the program itself and the tdlib library.
func allowed(dir string) map[string]bool {
	m := map[string]bool{"reina-tdlib": true, "libtdjson.so": true}
	if p := Exe(); p != "" {
		m[filepath.Base(p)] = true
	}
	return m
}

func fileCRC(p string) (uint32, int64, error) {
	f, err := os.Open(p)
	if err != nil {
		return 0, 0, err
	}
	defer f.Close()
	h := crc32.NewIEEE()
	n, err := io.Copy(h, f)
	return h.Sum32(), n, err
}

// Inspect reads the whole archive, checking every checksum, and says what it would change in dir.
func Inspect(zipPath, dir string) (Info, error) {
	var info Info
	zr, err := zip.OpenReader(zipPath)
	if err != nil {
		return info, fmt.Errorf("архив повреждён или загружен не до конца (%v)", err)
	}
	defer zr.Close()
	ok := allowed(dir)
	seen := map[string]bool{}
	for _, f := range zr.File {
		if f.FileInfo().IsDir() {
			continue
		}
		name := f.Name
		if name != filepath.Base(name) || !ok[name] {
			return info, fmt.Errorf("в архиве лишний файл %q (ожидаю только reina-tdlib и libtdjson.so)", name)
		}
		if seen[name] {
			return info, fmt.Errorf("файл %q в архиве дважды", name)
		}
		seen[name] = true
		if f.UncompressedSize64 == 0 || f.UncompressedSize64 > maxEntry {
			return info, fmt.Errorf("файл %q странного размера", name)
		}
		rc, err := f.Open()
		if err != nil {
			return info, fmt.Errorf("%s: %v", name, err)
		}
		head := make([]byte, 4)
		if _, err := io.ReadFull(rc, head); err != nil {
			rc.Close()
			return info, fmt.Errorf("%s: пустой или повреждённый", name)
		}
		if string(head) != "\x7fELF" {
			rc.Close()
			return info, fmt.Errorf("%s не похож на Linux-программу", name)
		}
		if _, err := io.Copy(io.Discard, rc); err != nil { // verifies the CRC at the end
			rc.Close()
			return info, fmt.Errorf("%s повреждён: %v", name, err)
		}
		rc.Close()
		fi := FileInfo{Name: name, Size: int64(f.UncompressedSize64), Changed: true}
		if crc, n, err := fileCRC(filepath.Join(dir, name)); err == nil && n == fi.Size && crc == f.CRC32 {
			fi.Changed = false
		}
		if fi.Changed {
			info.NeedFree += fi.Size
		}
		info.Files = append(info.Files, fi)
	}
	if !seen[filepath.Base(Exe())] && !seen["reina-tdlib"] {
		return info, errors.New("в архиве нет программы reina-tdlib")
	}
	return info, nil
}

type pending struct {
	Files  []string  `json:"files"`
	At     time.Time `json:"at"`
	Starts int       `json:"starts"`
}

func readPending(dir string) (pending, bool) {
	var p pending
	b, err := os.ReadFile(filepath.Join(dir, pendingFile))
	if err != nil || json.Unmarshal(b, &p) != nil {
		return p, false
	}
	return p, true
}

func writePending(dir string, p pending) error {
	b, _ := json.Marshal(p)
	return store.WriteFile(filepath.Join(dir, pendingFile), b, 0o644) // a torn marker would skip the rollback
}

// Apply installs the archive: new files are written next to the old ones, verified, the old ones become *.prev and
// the new ones take their place. It returns the names it replaced. Free space is checked first.
func Apply(zipPath, dir string) ([]string, error) {
	info, err := Inspect(zipPath, dir)
	if err != nil {
		return nil, err
	}
	if d, err := maint.DiskOf(dir); err == nil && int64(d.Free) < info.NeedFree+(20<<20) {
		return nil, fmt.Errorf("мало места: нужно %s, свободно %s", maint.Human(uint64(info.NeedFree)), maint.Human(d.Free))
	}
	zr, err := zip.OpenReader(zipPath)
	if err != nil {
		return nil, err
	}
	defer zr.Close()
	changed := map[string]bool{}
	for _, f := range info.Files {
		if f.Changed {
			changed[f.Name] = true
		}
	}
	if len(changed) == 0 {
		return nil, errors.New("в архиве те же файлы, что уже установлены")
	}
	var names []string
	for _, f := range zr.File {
		if !changed[f.Name] {
			continue
		}
		tmp := filepath.Join(dir, f.Name+".new")
		if err := extract(f, tmp); err != nil {
			_ = os.Remove(tmp)
			cleanNew(dir, names)
			return nil, err
		}
		names = append(names, f.Name)
	}
	// The swap is all or nothing: when one file cannot be put in place, the ones already swapped go back (a program
	// from the new build with a library from the old one may not even start, and nothing would roll it back).
	var swapped []string
	undo := func() {
		for _, n := range swapped {
			cur, prev := filepath.Join(dir, n), filepath.Join(dir, n+".prev")
			_ = os.Remove(cur)
			_ = os.Rename(prev, cur)
		}
		cleanNew(dir, names)
	}
	for _, n := range names {
		cur, prev := filepath.Join(dir, n), filepath.Join(dir, n+".prev")
		_ = os.Remove(prev)
		if _, err := os.Stat(cur); err == nil {
			if err := os.Rename(cur, prev); err != nil {
				undo()
				return nil, err
			}
		}
		if err := os.Rename(cur+".new", cur); err != nil {
			_ = os.Rename(prev, cur)
			undo()
			return nil, err
		}
		swapped = append(swapped, n)
	}
	if err := writePending(dir, pending{Files: names, At: time.Now()}); err != nil {
		return names, err
	}
	return names, nil
}

func cleanNew(dir string, names []string) {
	for _, n := range names {
		_ = os.Remove(filepath.Join(dir, n+".new"))
	}
}

func extract(f *zip.File, dst string) error {
	rc, err := f.Open()
	if err != nil {
		return err
	}
	defer rc.Close()
	out, err := os.OpenFile(dst, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o755)
	if err != nil {
		return err
	}
	if _, err := io.Copy(out, rc); err != nil {
		out.Close()
		return fmt.Errorf("%s: %v", f.Name, err)
	}
	if err := out.Sync(); err != nil {
		out.Close()
		return err
	}
	return out.Close()
}

// Prev lists the files that have a *.prev copy (what Rollback would restore).
func Prev(dir string) []string {
	var out []string
	for n := range allowed(dir) {
		if _, err := os.Stat(filepath.Join(dir, n+".prev")); err == nil {
			out = append(out, n)
		}
	}
	return out
}

// Rollback puts every *.prev file back and forgets the pending marker. It reports what it restored.
func Rollback(dir string) ([]string, error) {
	names := Prev(dir)
	if len(names) == 0 {
		return nil, errors.New("нет прошлой версии для отката")
	}
	for _, n := range names {
		cur, prev := filepath.Join(dir, n), filepath.Join(dir, n+".prev")
		_ = os.Remove(cur)
		if err := os.Rename(prev, cur); err != nil {
			return names, err
		}
	}
	_ = os.Remove(filepath.Join(dir, pendingFile))
	return names, nil
}

// Boot runs first thing at start-up. A build that was just installed gets exactly one start: if the marker says
// it was already started once and never confirmed, the previous build is restored and true is returned (the caller
// re-executes the program).
func Boot(dir string) bool {
	p, ok := readPending(dir)
	if !ok {
		return false
	}
	if p.Starts >= 1 {
		_, err := Rollback(dir)
		return err == nil
	}
	p.Starts = 1
	_ = writePending(dir, p)
	return false
}

// Confirm says the new build works: the marker goes away (the *.prev files stay for a manual rollback).
func Confirm(dir string) {
	_ = os.Remove(filepath.Join(dir, pendingFile))
}

// Pending reports whether a new build is still awaiting confirmation.
func Pending(dir string) bool {
	_, ok := readPending(dir)
	return ok
}
