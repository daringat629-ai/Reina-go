package llm

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"sync/atomic"
	"testing"
	"time"
)

func TestHTTPErrorsAreTyped(t *testing.T) {
	for _, tc := range []struct {
		status    int
		permanent bool
	}{{401, true}, {402, true}, {404, true}, {400, true}, {429, false}, {500, false}, {503, false}, {408, false}} {
		srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			http.Error(w, "nope", tc.status)
		}))
		c := New(srv.URL+"/", "", "", "m", "", 10*time.Second)
		c.HTTP = srv.Client()
		ctx, cancel := context.WithTimeout(context.Background(), 200*time.Millisecond) // do not sit through the retries
		_, err := c.Chat(ctx, "", []Message{{Role: "user", Content: "x"}})
		cancel()
		srv.Close()
		var ae *APIError
		if tc.permanent && (!errors.As(err, &ae) || ae.Status != tc.status) {
			t.Errorf("%d: want an APIError, got %v", tc.status, err)
		}
		if Permanent(err) != tc.permanent {
			t.Errorf("%d: Permanent=%v", tc.status, Permanent(err))
		}
	}
	if Permanent(context.DeadlineExceeded) || Permanent(errors.New("connection reset")) {
		t.Fatal("network trouble is never permanent")
	}
}

func TestErrorObjectInsideA200Answer(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte(`{"error":{"message":"Insufficient credits","code":402}}`))
	}))
	defer srv.Close()
	c := New(srv.URL+"/", "", "", "m", "", 5*time.Second)
	var seen error
	c.Observer = ObserverFunc(func(_ context.Context, e Event) { seen = e.Err })
	_, err := c.Chat(context.Background(), "", nil)
	var ae *APIError
	if !errors.As(err, &ae) || ae.Status != 402 || !Permanent(err) {
		t.Fatalf("want a permanent 402, got %v", err)
	}
	if seen == nil {
		t.Fatal("the observer must see the failure (the 'model is down' alert counts on it)")
	}
}

func TestEmbeddingsAreCached(t *testing.T) {
	var n atomic.Int32
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		n.Add(1)
		w.Write([]byte(`{"data":[{"embedding":[1,2,3]}]}`))
	}))
	defer srv.Close()
	c := New(srv.URL+"/", srv.URL+"/", "", "m", "e", 5*time.Second)
	for i := 0; i < 3; i++ {
		v, err := c.Embedding(context.Background(), "same text")
		if err != nil || len(v) != 3 {
			t.Fatal(v, err)
		}
	}
	if _, err := c.Embedding(context.Background(), "other text"); err != nil {
		t.Fatal(err)
	}
	if n.Load() != 2 {
		t.Fatalf("requests=%d, want 2", n.Load())
	}
	// the cache is bounded
	for i := 0; i < embedCacheSize+10; i++ {
		c.emb.put(string(rune('a'+i%26))+time.Duration(i).String(), []float64{1})
	}
	if c.emb.order.Len() != embedCacheSize {
		t.Fatalf("cache size %d", c.emb.order.Len())
	}
}

func TestEmptyEmbeddingIsAnError(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte(`{"data":[{"embedding":[]}]}`))
	}))
	defer srv.Close()
	c := New(srv.URL+"/", srv.URL+"/", "", "m", "e", 5*time.Second)
	if _, err := c.Embedding(context.Background(), "x"); err == nil {
		t.Fatal("an empty vector must not be stored as a memory's embedding")
	}
}
