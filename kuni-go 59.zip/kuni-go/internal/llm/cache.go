package llm

import (
	"container/list"
	"sync"
)

// embedCacheSize is how many embeddings are remembered (a few MB at most).
const embedCacheSize = 256

// embedCache is a small LRU of embeddings by endpoint, model and text.
type embedCache struct {
	mu    sync.Mutex
	order *list.List // front = most recent; values are *embedEntry
	byKey map[string]*list.Element
}

type embedEntry struct {
	key string
	vec []float64
}

func (c *embedCache) get(key string) ([]float64, bool) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.byKey == nil {
		return nil, false
	}
	el, ok := c.byKey[key]
	if !ok {
		return nil, false
	}
	c.order.MoveToFront(el)
	return el.Value.(*embedEntry).vec, true
}

func (c *embedCache) put(key string, vec []float64) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.byKey == nil {
		c.byKey, c.order = map[string]*list.Element{}, list.New()
	}
	if el, ok := c.byKey[key]; ok {
		el.Value.(*embedEntry).vec = vec
		c.order.MoveToFront(el)
		return
	}
	c.byKey[key] = c.order.PushFront(&embedEntry{key: key, vec: vec})
	for c.order.Len() > embedCacheSize {
		last := c.order.Back()
		c.order.Remove(last)
		delete(c.byKey, last.Value.(*embedEntry).key)
	}
}
