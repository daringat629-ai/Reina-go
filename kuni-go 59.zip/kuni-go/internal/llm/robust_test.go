package llm

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

func TestToolArgumentsAsObjectOrString(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte(`{"choices":[{"message":{"role":"assistant","content":null,"tool_calls":[
			{"id":"a","type":"function","function":{"name":"send","arguments":{"text":"привет","n":1}}},
			{"id":"b","type":"function","function":{"name":"wait","arguments":"{\"secs\":3}"}},
			{"id":"c","type":"function","function":{"name":"skip"}}]}}]}`))
	}))
	defer srv.Close()
	c := New(srv.URL+"/", "", "", "m", "", 5*time.Second)
	m, err := c.Complete(context.Background(), Request{Messages: []Message{{Role: "user", Content: "hi"}}})
	if err != nil {
		t.Fatal(err)
	}
	if len(m.ToolCalls) != 3 || m.ToolCalls[0].Function.Arguments != `{"text":"привет","n":1}` ||
		m.ToolCalls[1].Function.Arguments != `{"secs":3}` || m.ToolCalls[2].Function.Arguments != "" {
		t.Fatalf("tool calls: %+v", m.ToolCalls)
	}
}

func TestContentAsArrayOfParts(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte(`{"choices":[{"message":{"role":"assistant","content":[{"type":"text","text":"ну "},{"type":"image_url","image_url":{}},{"type":"text","text":"привет"}]}}]}`))
	}))
	defer srv.Close()
	c := New(srv.URL+"/", "", "", "m", "", 5*time.Second)
	got, err := c.Chat(context.Background(), "", []Message{{Role: "user", Content: "hi"}})
	if err != nil || got != "ну привет" {
		t.Fatalf("%q %v", got, err)
	}
}

func TestRetryAfterIsRespectedAndCapped(t *testing.T) {
	now := time.Date(2026, 1, 1, 12, 0, 0, 0, time.UTC)
	cases := map[string]time.Duration{"": 0, "2": 2 * time.Second, "0.5": 500 * time.Millisecond, "9999": maxRetryAfter, "junk": 0,
		now.Add(4 * time.Second).Format(http.TimeFormat): 4 * time.Second, now.Add(-time.Hour).Format(http.TimeFormat): 0}
	for h, want := range cases {
		if got := retryAfter(h, now); got != want {
			t.Errorf("retryAfter(%q) = %s, want %s", h, got, want)
		}
	}
	var n int32
	var first, second time.Time
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if atomic.AddInt32(&n, 1) == 1 {
			first = time.Now()
			w.Header().Set("Retry-After", "2")
			http.Error(w, "slow down", http.StatusTooManyRequests)
			return
		}
		second = time.Now()
		w.Write([]byte(`{"choices":[{"message":{"role":"assistant","content":"ok"}}]}`))
	}))
	defer srv.Close()
	c := New(srv.URL+"/", "", "", "m", "", 10*time.Second)
	if _, err := c.Chat(context.Background(), "", []Message{{Role: "user", Content: "hi"}}); err != nil {
		t.Fatal(err)
	}
	if gap := second.Sub(first); gap < 1900*time.Millisecond {
		t.Fatalf("retried after %s, the server asked for 2s", gap)
	}
}

// The timeout can be changed while requests are running (config hot reload) without a data race,
// and a request that hangs past it fails instead of freezing her.
func TestTimeoutIsHotReloadableAndBoundsTheRequest(t *testing.T) {
	release := make(chan struct{})
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		select {
		case <-release:
		case <-r.Context().Done():
		}
	}))
	defer srv.Close()
	defer close(release)
	c := New(srv.URL+"/", "", "", "m", "", 300*time.Millisecond)
	var wg sync.WaitGroup
	wg.Add(1)
	go func() {
		defer wg.Done()
		for i := 0; i < 50; i++ {
			c.SetTimeout(time.Duration(200+i) * time.Millisecond)
		}
	}()
	start := time.Now()
	_, err := c.Chat(context.Background(), "", []Message{{Role: "user", Content: "hi"}})
	wg.Wait()
	if err == nil || !errors.Is(err, context.DeadlineExceeded) {
		t.Fatalf("want a deadline error, got %v", err)
	}
	if time.Since(start) > 3*time.Second {
		t.Fatal("the timeout did not bound the request")
	}
}
