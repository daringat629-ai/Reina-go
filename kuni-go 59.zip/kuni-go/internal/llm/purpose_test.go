package llm

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
)

func TestUsageCarriesPurpose(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		json.NewEncoder(w).Encode(map[string]any{
			"choices": []any{map[string]any{"message": map[string]any{"role": "assistant", "content": "ok"}}},
			"usage":   map[string]any{"prompt_tokens": 123, "completion_tokens": 7},
		})
	}))
	defer srv.Close()
	c := New(srv.URL+"/", srv.URL+"/", "", "m", "e", 5*time.Second)
	var got []string
	var in int
	c.Observer = ObserverFunc(func(_ context.Context, e Event) {
		if e.Usage != nil {
			got = append(got, e.Purpose)
			in += e.Usage.Prompt
		}
	})
	if _, err := c.Chat(WithPurpose(context.Background(), "ask"), "s", []Message{{Role: "user", Content: "x"}}); err != nil {
		t.Fatal(err)
	}
	if _, err := c.Chat(context.Background(), "s", []Message{{Role: "user", Content: "x"}}); err != nil {
		t.Fatal(err)
	}
	if len(got) != 2 || got[0] != "ask" || got[1] != "other" || in != 246 {
		t.Fatalf("got %v in=%d", got, in)
	}
}

func TestReasoningControl(t *testing.T) {
	var body map[string]any
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_ = json.NewDecoder(r.Body).Decode(&body)
		json.NewEncoder(w).Encode(map[string]any{"choices": []any{map[string]any{"message": map[string]any{"role": "assistant", "content": "ok"}}}})
	}))
	defer srv.Close()
	c := New(srv.URL+"/", srv.URL+"/", "", "m", "e", 5*time.Second)
	for _, tc := range []struct{ set, key, val string }{{"", "", ""}, {"off", "enabled", "false"}, {"low", "effort", "low"}} {
		s := c.settings()
		s.Reasoning = tc.set
		c.Update(s)
		if _, err := c.Chat(context.Background(), "s", []Message{{Role: "user", Content: "x"}}); err != nil {
			t.Fatal(err)
		}
		r, has := body["reasoning"].(map[string]any)
		if tc.set == "" {
			if has {
				t.Fatal("reasoning must be absent by default")
			}
			continue
		}
		if !has || (tc.key == "enabled" && r["enabled"] != false) || (tc.key == "effort" && r["effort"] != "low") {
			t.Fatalf("%s: %v", tc.set, body["reasoning"])
		}
	}
}

func TestUsageHookKnowsTheChat(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		json.NewEncoder(w).Encode(map[string]any{
			"choices": []any{map[string]any{"message": map[string]any{"role": "assistant", "content": "ok"}}},
			"usage":   map[string]any{"prompt_tokens": 50, "completion_tokens": 5},
		})
	}))
	defer srv.Close()
	c := New(srv.URL+"/", srv.URL+"/", "", "m", "e", 5*time.Second)
	type rec struct {
		chat int64
		ok   bool
		in   int
	}
	var got []rec
	c.Observer = ObserverFunc(func(ctx context.Context, e Event) {
		id, ok := ChatFrom(ctx)
		if id != e.Chat || ok != e.HasChat {
			t.Errorf("event chat %d/%v, context %d/%v", e.Chat, e.HasChat, id, ok)
		}
		got = append(got, rec{e.Chat, e.HasChat, e.Usage.Prompt})
	})
	_, _ = c.Chat(WithChat(context.Background(), 42), "s", []Message{{Role: "user", Content: "x"}})
	_, _ = c.Chat(context.Background(), "s", []Message{{Role: "user", Content: "x"}})
	if len(got) != 2 || got[0] != (rec{42, true, 50}) || got[1].ok {
		t.Fatalf("got %+v", got)
	}
}

func TestWithModelOverridesTheConfiguredOne(t *testing.T) {
	var got []string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		var req map[string]any
		_ = json.NewDecoder(r.Body).Decode(&req)
		got = append(got, req["model"].(string))
		json.NewEncoder(w).Encode(map[string]any{"choices": []any{map[string]any{"message": map[string]any{"role": "assistant", "content": "ok"}}}})
	}))
	defer srv.Close()
	c := New(srv.URL+"/", srv.URL+"/", "", "main-model", "e", 5*time.Second)
	_, _ = c.Chat(context.Background(), "s", []Message{{Role: "user", Content: "x"}})
	_, _ = c.Complete(context.Background(), Request{System: "s", Messages: []Message{{Role: "user", Content: "x"}}, Model: "other/model"})
	if len(got) != 2 || got[0] != "main-model" || got[1] != "other/model" {
		t.Fatalf("models used: %v", got)
	}
}

func TestReasoningOverrideAppliesToOneRequest(t *testing.T) {
	var bodies []map[string]any
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		var b map[string]any
		_ = json.NewDecoder(r.Body).Decode(&b)
		bodies = append(bodies, b)
		w.Write([]byte(`{"choices":[{"message":{"role":"assistant","content":"ok"}}]}`))
	}))
	defer srv.Close()
	c := New(srv.URL+"/", srv.URL+"/", "", "m", "e", 5*time.Second)
	hi := []Message{{Role: "user", Content: "hi"}}
	_, _ = c.Complete(context.Background(), Request{System: "s", Messages: hi})
	_, _ = c.Complete(context.Background(), Request{System: "s", Messages: hi, Reasoning: "off"})
	_, _ = c.Complete(context.Background(), Request{System: "s", Messages: hi})
	if _, ok := bodies[0]["reasoning"]; ok {
		t.Fatal("default request must not touch reasoning")
	}
	r, _ := bodies[1]["reasoning"].(map[string]any)
	if r["enabled"] != false {
		t.Fatalf("override not sent: %v", bodies[1]["reasoning"])
	}
	if _, ok := bodies[2]["reasoning"]; ok {
		t.Fatal("the override must not leak into the next request")
	}
}

func TestVisionModelServesImageRequestsOnly(t *testing.T) {
	s := Settings{Model: "text", LightModel: "cheap", VisionModel: "eyes"}
	for purpose, want := range map[string]string{"image": "eyes", "reply": "text", "diary": "cheap", "": "text"} {
		if got := s.modelFor(purpose); got != want {
			t.Errorf("%q -> %s, want %s", purpose, got, want)
		}
	}
	if (Settings{Model: "text"}).modelFor("image") != "text" {
		t.Fatal("without vision_model the main model looks at pictures")
	}
}
