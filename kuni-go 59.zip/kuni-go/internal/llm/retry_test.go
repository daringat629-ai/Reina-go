package llm

import (
	"context"
	"net/http"
	"net/http/httptest"
	"sync/atomic"
	"testing"
)

func TestRetryOn5xx(t *testing.T) {
	var n int32
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if atomic.AddInt32(&n, 1) < 2 {
			http.Error(w, "busy", http.StatusServiceUnavailable)
			return
		}
		w.Write([]byte(`{}`))
	}))
	defer srv.Close()
	c := &Client{HTTP: srv.Client()}
	resp, err := c.do(context.Background(), Settings{}, srv.URL, map[string]any{})
	if err != nil {
		t.Fatal(err)
	}
	resp.Body.Close()
	if n != 2 {
		t.Fatal(n)
	}
}

func TestNoRetryOn4xx(t *testing.T) {
	var n int32
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		atomic.AddInt32(&n, 1)
		http.Error(w, "bad", 400)
	}))
	defer srv.Close()
	c := &Client{HTTP: srv.Client()}
	if _, err := c.do(context.Background(), Settings{}, srv.URL, map[string]any{}); err == nil || n != 1 {
		t.Fatal(err, n)
	}
}
