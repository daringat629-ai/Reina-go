package llm

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestLightModelRouting(t *testing.T) {
	var got []string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		var b struct {
			Model string `json:"model"`
		}
		_ = json.NewDecoder(r.Body).Decode(&b)
		got = append(got, b.Model)
		_, _ = w.Write([]byte(`{"choices":[{"message":{"role":"assistant","content":"ok"}}]}`))
	}))
	defer srv.Close()
	c := New(srv.URL+"/", "", "", "main", "e", 0)
	c.Update(Settings{BaseURL: srv.URL + "/", Model: "main", LightModel: "qwen"})
	for _, p := range []string{"reply", "sleep", "ask", "diary", "compact", "image", "other"} {
		if _, err := c.Chat(WithPurpose(context.Background(), p), "s", []Message{{Role: "user", Content: "x"}}); err != nil {
			t.Fatal(err)
		}
	}
	want := []string{"main", "qwen", "qwen", "qwen", "qwen", "main", "main"}
	for i := range want {
		if got[i] != want[i] {
			t.Fatalf("purpose #%d: model %q, want %q (all: %v)", i, got[i], want[i], got)
		}
	}
	c.Update(Settings{BaseURL: srv.URL + "/", Model: "main"})
	got = nil
	_, _ = c.Chat(WithPurpose(context.Background(), "sleep"), "s", nil)
	if got[0] != "main" {
		t.Fatalf("empty light model must fall back to main, got %q", got[0])
	}
}

func TestGuardRefusesRequests(t *testing.T) {
	hit := 0
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		hit++
		_, _ = w.Write([]byte(`{"choices":[{"message":{"role":"assistant","content":"ok"}}]}`))
	}))
	defer srv.Close()
	c := New(srv.URL+"/", "", "", "m", "e", 0)
	block := false
	c.Guard = func() error {
		if block {
			return errors.New("budget")
		}
		return nil
	}
	if _, err := c.Chat(context.Background(), "s", nil); err != nil || hit != 1 {
		t.Fatalf("open guard: %v hit=%d", err, hit)
	}
	block = true
	if _, err := c.Chat(context.Background(), "s", nil); err == nil || hit != 1 {
		t.Fatalf("blocked request must not reach the server: %v hit=%d", err, hit)
	}
}
