package netguard

import (
	"net/http"
	"net/http/httptest"
	"testing"
)

func req(remote string, headers ...string) *http.Request {
	r := httptest.NewRequest(http.MethodGet, "/v1/models", nil)
	r.RemoteAddr = remote
	for i := 0; i+1 < len(headers); i += 2 {
		r.Header.Set(headers[i], headers[i+1])
	}
	return r
}

func TestLocal(t *testing.T) {
	cases := []struct {
		remote string
		scope  Scope
		hdr    []string
		want   bool
	}{
		{"127.0.0.1:5000", Loopback, nil, true},
		{"[::1]:5000", Loopback, nil, true},
		{"[::ffff:127.0.0.1]:5000", Loopback, nil, true},
		{"172.17.0.1:5000", Loopback, nil, false},
		{"172.17.0.1:5000", Private, nil, true},
		{"100.101.102.103:5000", Private, nil, true},
		{"8.8.8.8:5000", Private, nil, false},
		{"[2001:db8::1]:5000", Private, nil, false},
		{"127.0.0.1:5000", Loopback, []string{"X-Forwarded-For", "8.8.8.8"}, false}, // nginx in front: not local
		{"127.0.0.1:5000", Private, []string{"Forwarded", "for=8.8.8.8"}, false},
		{"garbage", Private, nil, false},
	}
	for _, c := range cases {
		if got := Local(req(c.remote, c.hdr...), c.scope); got != c.want {
			t.Errorf("Local(%s, %v, %v) = %v, want %v", c.remote, c.scope, c.hdr, got, c.want)
		}
	}
}

func TestPolicy(t *testing.T) {
	key := ""
	p := Policy{Keys: func() []string { return []string{key, ""} }, Scope: Loopback, KeyOnly: true}
	if !p.Allowed(req("127.0.0.1:1")) || p.Allowed(req("8.8.8.8:1")) {
		t.Fatal("no key: loopback only")
	}
	if p.Allowed(req("8.8.8.8:1", "Authorization", "Bearer ")) {
		t.Fatal("an empty key must never match the empty configured key")
	}
	key = "s3cret-key-123"
	if p.Allowed(req("127.0.0.1:1")) {
		t.Fatal("KeyOnly with a key: even loopback must authenticate")
	}
	if !p.Allowed(req("8.8.8.8:1", "Authorization", "Bearer s3cret-key-123")) || !p.Allowed(req("8.8.8.8:1", "Authorization", "bearer s3cret-key-123")) {
		t.Fatal("the key opens it from anywhere")
	}
	if p.Allowed(req("8.8.8.8:1", "Authorization", "Bearer wrong")) {
		t.Fatal("wrong key")
	}
	q := Policy{Keys: func() []string { return []string{key} }, Scope: Private}
	if !q.Allowed(req("10.1.2.3:1")) || q.Allowed(req("8.8.4.4:1")) {
		t.Fatal("not KeyOnly: private networks without a key, the internet with one")
	}
	rec := httptest.NewRecorder()
	q.Wrap(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { t.Fatal("must not run") })).ServeHTTP(rec, req("8.8.4.4:1"))
	if rec.Code != http.StatusForbidden {
		t.Fatal(rec.Code)
	}
}
