// Package netguard decides who may use the HTTP endpoints that sit next to the admin panel: the OpenAI-compatible
// proxy (it spends the owner's LLM key and can read the diary through #ask), the /debug page (open sessions, diary
// search) and /metrics (chat names in labels).
//
// Before this package all three answered anybody who could reach the port, and the port listens on every interface.
package netguard

import (
	"crypto/sha256"
	"crypto/subtle"
	"net"
	"net/http"
	"net/netip"
	"strings"
)

// Scope is how far from the machine a request may come without a key.
type Scope int

const (
	// Loopback: only this machine (127.0.0.0/8, ::1).
	Loopback Scope = iota
	// Private: this machine plus private networks (Docker bridges, a home LAN, Tailscale/CGNAT 100.64/10).
	Private
)

var privateNets = func() []netip.Prefix {
	var out []netip.Prefix
	for _, s := range []string{"10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "100.64.0.0/10", "fc00::/7", "fe80::/10", "169.254.0.0/16"} {
		out = append(out, netip.MustParsePrefix(s))
	}
	return out
}()

// forwarded reports whether the request came through a reverse proxy: then RemoteAddr is the proxy (often
// 127.0.0.1) and says nothing about the real client, so the request is never trusted as local.
func forwarded(r *http.Request) bool {
	for _, h := range []string{"X-Forwarded-For", "X-Real-Ip", "Forwarded", "Cf-Connecting-Ip", "True-Client-Ip"} {
		if r.Header.Get(h) != "" {
			return true
		}
	}
	return false
}

// Local reports whether the request comes directly (not through a reverse proxy) from within scope.
func Local(r *http.Request, scope Scope) bool {
	if forwarded(r) {
		return false
	}
	host, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		host = r.RemoteAddr
	}
	ip, err := netip.ParseAddr(host)
	if err != nil {
		return false
	}
	ip = ip.Unmap()
	if ip.IsLoopback() {
		return true
	}
	if scope == Private {
		for _, p := range privateNets {
			if p.Contains(ip) {
				return true
			}
		}
	}
	return false
}

// Bearer returns the token of an "Authorization: Bearer <token>" header ("" if absent).
func Bearer(r *http.Request) string {
	h := r.Header.Get("Authorization")
	if len(h) > 7 && strings.EqualFold(h[:7], "bearer ") {
		return strings.TrimSpace(h[7:])
	}
	return ""
}

// Same compares two secrets in constant time (hashing first hides their lengths).
func Same(a, b string) bool {
	ha, hb := sha256.Sum256([]byte(a)), sha256.Sum256([]byte(b))
	return subtle.ConstantTimeCompare(ha[:], hb[:]) == 1
}

// Policy guards one group of endpoints.
type Policy struct {
	// Keys returns the bearer tokens that open the endpoints from anywhere; empty strings are ignored.
	Keys func() []string
	// Scope is where requests are accepted without a key. KeyOnly: when a key is configured it is required even
	// from the machine itself (the proxy: a configured key means "clients authenticate").
	Scope   Scope
	KeyOnly bool
	// Hint is appended to the 403 answer: how to get access.
	Hint string
}

// Allowed reports whether r passes the policy.
func (p Policy) Allowed(r *http.Request) bool {
	var keys []string
	if p.Keys != nil {
		for _, k := range p.Keys() {
			if strings.TrimSpace(k) != "" {
				keys = append(keys, k)
			}
		}
	}
	if tok := Bearer(r); tok != "" {
		for _, k := range keys {
			if Same(tok, k) {
				return true
			}
		}
	}
	if p.KeyOnly && len(keys) > 0 {
		return false
	}
	return Local(r, p.Scope)
}

// Wrap answers 403 to requests the policy refuses.
func (p Policy) Wrap(h http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if !p.Allowed(r) {
			msg := "forbidden"
			if p.Hint != "" {
				msg += ": " + p.Hint
			}
			http.Error(w, msg, http.StatusForbidden)
			return
		}
		h.ServeHTTP(w, r)
	})
}
