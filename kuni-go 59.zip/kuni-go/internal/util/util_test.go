package util

import (
	"math"
	"testing"
	"time"
)

func TestCosineSimilarity(t *testing.T) {
	got, err := CosineSimilarity([]float64{1, 0}, []float64{1, 0})
	if err != nil || math.Abs(got-1) > 1e-9 {
		t.Fatalf("identical vectors: got %v, %v", got, err)
	}
	got, _ = CosineSimilarity([]float64{1, 0}, []float64{0, 1})
	if math.Abs(got) > 1e-9 {
		t.Fatalf("orthogonal: got %v", got)
	}
	if got, _ := CosineSimilarity([]float64{0, 0}, []float64{1, 1}); got != 0 {
		t.Fatalf("zero vector should give 0, got %v", got)
	}
	if _, err := CosineSimilarity([]float64{1}, []float64{1, 2}); err == nil {
		t.Fatal("size mismatch should error")
	}
}

func TestTimeAgo(t *testing.T) {
	now := time.Date(2026, 10, 18, 12, 0, 0, 0, time.UTC)
	cases := map[time.Duration]string{
		10 * time.Second:    "just now",
		time.Minute:         "1 minute ago",
		45 * time.Minute:    "45 minutes ago",
		90 * time.Minute:    "1 hour ago",
		5 * time.Hour:       "5 hours ago",
		25 * time.Hour:      "1 day ago",
		3 * 24 * time.Hour:  "3 days ago",
		8 * 24 * time.Hour:  "1 week ago",
		30 * 24 * time.Hour: "4 weeks ago",
	}
	for d, want := range cases {
		if got := TimeAgo(now.Add(-d), now); got != want {
			t.Errorf("TimeAgo(-%v) = %q, want %q", d, got, want)
		}
	}
}

func TestFormatPastHours(t *testing.T) {
	if got := FormatPastHours(72 * time.Hour); got != "3 days" {
		t.Errorf("got %q", got)
	}
	if got := FormatPastHours(5 * time.Hour); got != "5 hours" {
		t.Errorf("got %q", got)
	}
}
