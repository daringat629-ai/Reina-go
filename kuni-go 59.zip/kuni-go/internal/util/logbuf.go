package util

import (
	"strings"
	"sync"
)

// LogBuf is an io.Writer that keeps the last N log lines in memory (for the admin panel).
type LogBuf struct {
	mu    sync.Mutex
	lines []string
	max   int
	part  string
}

func NewLogBuf(max int) *LogBuf { return &LogBuf{max: max} }

func (b *LogBuf) Write(p []byte) (int, error) {
	b.mu.Lock()
	defer b.mu.Unlock()
	s := b.part + string(p)
	parts := strings.Split(s, "\n")
	b.part = parts[len(parts)-1]
	b.lines = append(b.lines, parts[:len(parts)-1]...)
	if over := len(b.lines) - b.max; over > 0 {
		b.lines = append([]string(nil), b.lines[over:]...)
	}
	return len(p), nil
}

// Tail returns the last n lines (oldest first).
func (b *LogBuf) Tail(n int) []string {
	b.mu.Lock()
	defer b.mu.Unlock()
	if n <= 0 || n > len(b.lines) {
		n = len(b.lines)
	}
	return append([]string(nil), b.lines[len(b.lines)-n:]...)
}
