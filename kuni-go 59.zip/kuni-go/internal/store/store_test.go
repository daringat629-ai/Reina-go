package store

import (
	"errors"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestWriteAndReadJSON(t *testing.T) {
	dir := t.TempDir()
	p := filepath.Join(dir, "sub", "state.json")
	in := map[string]int{"a": 1, "b": 2}
	if err := WriteJSON(p, in, 0); err != nil {
		t.Fatal(err)
	}
	st, err := os.Stat(p)
	if err != nil {
		t.Fatal(err)
	}
	if st.Mode().Perm() != Private {
		t.Fatalf("mode %v, want 0600", st.Mode().Perm())
	}
	var out map[string]int
	found, err := ReadJSON(p, &out)
	if err != nil || !found || out["b"] != 2 {
		t.Fatalf("read back: %v %v %v", found, err, out)
	}
	// no temporary files are left behind
	ents, _ := os.ReadDir(filepath.Dir(p))
	if len(ents) != 1 {
		t.Fatalf("leftovers: %v", ents)
	}
}

func TestReadMissingIsNotAnError(t *testing.T) {
	var v []int
	found, err := ReadJSON(filepath.Join(t.TempDir(), "nope.json"), &v)
	if found || err != nil {
		t.Fatalf("missing file: found=%v err=%v", found, err)
	}
}

func TestCorruptFileIsMovedAsideNotOverwritten(t *testing.T) {
	dir := t.TempDir()
	p := filepath.Join(dir, "reminders.json")
	if err := os.WriteFile(p, []byte(`[{"id":1,"text":"важное"`), 0o600); err != nil {
		t.Fatal(err)
	}
	var v []map[string]any
	found, err := ReadJSON(p, &v)
	if !found || !errors.Is(err, ErrCorrupt) {
		t.Fatalf("want ErrCorrupt, got found=%v err=%v", found, err)
	}
	if _, err := os.Stat(p); !os.IsNotExist(err) {
		t.Fatal("the broken file must be moved away")
	}
	ents, _ := os.ReadDir(dir)
	if len(ents) != 1 || !strings.HasPrefix(ents[0].Name(), "reminders.json.corrupt-") {
		t.Fatalf("aside copy missing: %v", ents)
	}
	b, _ := os.ReadFile(filepath.Join(dir, ents[0].Name()))
	if !strings.Contains(string(b), "важное") {
		t.Fatal("the content must survive for manual recovery")
	}
}

func TestSaverReportsErrors(t *testing.T) {
	dir := t.TempDir()
	blocker := filepath.Join(dir, "file")
	if err := os.WriteFile(blocker, nil, 0o600); err != nil {
		t.Fatal(err)
	}
	var s Saver
	s.What = "test"
	if err := s.Save(filepath.Join(blocker, "x.json"), 1); err == nil {
		t.Fatal("a save under a regular file must fail")
	}
	if err := s.Save(filepath.Join(dir, "ok.json"), 1); err != nil {
		t.Fatal(err)
	}
	if err := s.Save("", 1); err != nil {
		t.Fatal("an empty path means in-memory only")
	}
}
