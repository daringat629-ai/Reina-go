// Package store is the one way the program keeps small state on disk: JSON files written atomically.
//
// Every persistent list of hers (reminders, people, the job queue, mood, usage, the action journal...) used to carry
// its own copy of "marshal, write a .tmp, rename", with the errors thrown away. Three things went wrong with that:
// a full disk silently stopped saving while the program went on as if it had; a file that could not be parsed was
// read as "empty" and the next save overwrote it, so one broken byte lost the whole list; and the files holding
// private data (what she knows about people, the owner's jobs) were readable by every user of the machine.
//
// The helpers here fix all three in one place:
//   - Write is atomic (temporary file, fsync, rename): a crash or a full disk leaves the old file intact;
//   - Read moves a file it cannot parse aside (<name>.corrupt-<time>) and reports it, so nothing is overwritten;
//   - files are created with mode 0600 and directories with 0700 unless the caller asks otherwise.
package store

import (
	"encoding/json"
	"errors"
	"fmt"
	"io/fs"
	"log"
	"os"
	"path/filepath"
	"strconv"
	"sync"
	"time"
)

// Private is the mode of files that hold personal data or keys.
const Private fs.FileMode = 0o600

// ErrCorrupt wraps the error of a file that existed but could not be parsed; the file was moved aside.
var ErrCorrupt = errors.New("store: corrupt file")

// WriteFile writes data to path atomically: a temporary file next to it is written, synced and renamed over path,
// so readers never see a half-written file and a failure keeps the previous content. Missing parent directories
// are created with mode 0700.
func WriteFile(path string, data []byte, perm fs.FileMode) error {
	if perm == 0 {
		perm = Private
	}
	dir := filepath.Dir(path)
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return err
	}
	f, err := os.CreateTemp(dir, "."+filepath.Base(path)+".*.tmp")
	if err != nil {
		return err
	}
	tmp := f.Name()
	_, err = f.Write(data)
	if err == nil {
		err = f.Sync()
	}
	if cerr := f.Close(); err == nil {
		err = cerr
	}
	if err == nil {
		err = os.Chmod(tmp, perm)
	}
	if err == nil {
		err = os.Rename(tmp, path)
	}
	if err != nil {
		_ = os.Remove(tmp)
	}
	return err
}

// WriteJSON saves v as indented JSON with WriteFile.
func WriteJSON(path string, v any, perm fs.FileMode) error {
	b, err := json.MarshalIndent(v, "", " ")
	if err != nil {
		return err
	}
	return WriteFile(path, append(b, '\n'), perm)
}

// ReadJSON loads path into v. found is false (and err nil) when the file does not exist yet. A file that exists
// but does not parse is renamed to <path>.corrupt-<unix time> and ErrCorrupt is returned: the caller starts empty,
// and its next save cannot destroy what may still be recoverable by hand.
func ReadJSON(path string, v any) (found bool, err error) {
	b, err := os.ReadFile(path)
	if errors.Is(err, fs.ErrNotExist) {
		return false, nil
	}
	if err != nil {
		return false, err
	}
	if len(b) == 0 {
		return true, nil // an empty file is an empty state, not damage
	}
	if jerr := json.Unmarshal(b, v); jerr != nil {
		aside := path + ".corrupt-" + strconv.FormatInt(time.Now().Unix(), 10)
		if rerr := os.Rename(path, aside); rerr != nil {
			return true, fmt.Errorf("%w: %s: %v (and could not move it aside: %v)", ErrCorrupt, path, jerr, rerr)
		}
		return true, fmt.Errorf("%w: %s: %v (moved to %s)", ErrCorrupt, path, jerr, filepath.Base(aside))
	}
	return true, nil
}

// Load is ReadJSON that logs instead of returning: for stores whose constructor has no error to give back.
// It reports whether the file existed and was read.
func Load(what, path string, v any) bool {
	found, err := ReadJSON(path, v)
	if err != nil {
		log.Printf("%s: %v", what, err)
		return false
	}
	return found
}

// Saver writes a store's file and logs failures, at most once a minute per file: a full disk must be noticed, but it
// must not flood the log with one line per change.
type Saver struct {
	What string      // name for the log ("reminders", "people"...)
	Perm fs.FileMode // 0 = Private

	mu      sync.Mutex
	lastErr time.Time
	failing bool
}

// Save writes v to path (WriteJSON) and returns the error after logging it.
func (s *Saver) Save(path string, v any) error {
	if path == "" {
		return nil
	}
	err := WriteJSON(path, v, s.Perm)
	s.mu.Lock()
	defer s.mu.Unlock()
	switch {
	case err != nil && time.Since(s.lastErr) > time.Minute:
		s.lastErr, s.failing = time.Now(), true
		log.Printf("%s: could not save %s: %v", s.What, path, err)
	case err == nil && s.failing:
		s.failing = false
		log.Printf("%s: saving %s works again", s.What, path)
	}
	return err
}
