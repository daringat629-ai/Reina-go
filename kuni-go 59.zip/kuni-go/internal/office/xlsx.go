package office

import (
	"archive/zip"
	"bytes"
	"encoding/csv"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math"
	"regexp"
	"strconv"
	"strings"
	"time"
)

// CellKind is what a cell holds.
type CellKind int

const (
	Empty CellKind = iota
	Number
	Text
	Bool
	Formula
	Date     // Num is the Excel serial day number
	DateTime // Num is the serial with the time of day as the fraction
	Percent  // Num is the fraction (15% = 0.15)
)

// Cell is one cell of a sheet.
type Cell struct {
	Kind CellKind
	Num  float64
	Str  string // the text, or the formula without "="
}

// Sheet is one sheet of a workbook. With Header the first row is the column titles: bold, frozen, with a filter.
type Sheet struct {
	Name   string
	Rows   [][]Cell
	Header bool
}

var (
	reNum     = regexp.MustCompile(`^[-+]?(\d{1,3}([ \x{00a0}]\d{3})+|\d+)([.,]\d+)?$`)
	reSci     = regexp.MustCompile(`^[-+]?\d+(\.\d+)?[eE][-+]?\d+$`)
	rePercent = regexp.MustCompile(`^([-+]?\d+([.,]\d+)?)\s*%$`)
	reISODate = regexp.MustCompile(`^(\d{4})-(\d{2})-(\d{2})$`)
	reISODT   = regexp.MustCompile(`^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?$`)
	reRuDate  = regexp.MustCompile(`^(\d{2})\.(\d{2})\.(\d{4})$`)
	reRuDT    = regexp.MustCompile(`^(\d{2})\.(\d{2})\.(\d{4}) (\d{2}):(\d{2})$`)
)

// Value reads the text of a cell as what it is: a number ("1 234,5" too), a percent, a date, a formula ("=SUM(A1:A3)",
// Russian names and ";" are understood), TRUE/FALSE, or text. Codes with leading zeros, phone and card numbers stay
// text (as numbers they would lose digits).
func Value(s string) Cell {
	t := strings.TrimSpace(s)
	switch {
	case t == "":
		return Cell{}
	case len(t) > 1 && t[0] == '=':
		return Cell{Kind: Formula, Str: excelFormula(t[1:])}
	case strings.EqualFold(t, "true") || strings.EqualFold(t, "false"):
		v := 0.0
		if strings.EqualFold(t, "true") {
			v = 1
		}
		return Cell{Kind: Bool, Num: v}
	}
	if m := rePercent.FindStringSubmatch(t); m != nil {
		f, _ := strconv.ParseFloat(strings.ReplaceAll(m[1], ",", "."), 64)
		return Cell{Kind: Percent, Num: f / 100}
	}
	if d, ok := parseDate(t); ok {
		return d
	}
	digits := 0
	for _, r := range t {
		if r >= '0' && r <= '9' {
			digits++
		}
	}
	keepText := digits > 15 || (t[0] == '+' && digits >= 9) ||
		(len(t) > 1 && t[0] == '0' && t[1] >= '0' && t[1] <= '9') // 007, 0123
	if !keepText && (reNum.MatchString(t) || reSci.MatchString(t)) {
		n := strings.NewReplacer(" ", "", "\u00a0", "", ",", ".").Replace(t)
		if f, err := strconv.ParseFloat(n, 64); err == nil && !math.IsInf(f, 0) {
			return Cell{Kind: Number, Num: f}
		}
	}
	return Cell{Kind: Text, Str: s}
}

func parseDate(t string) (Cell, bool) {
	at := func(y, mo, d, h, mi, sec string) (time.Time, bool) {
		n := func(s string) int { v, _ := strconv.Atoi(s); return v }
		tm := time.Date(n(y), time.Month(n(mo)), n(d), n(h), n(mi), n(sec), 0, time.UTC)
		return tm, tm.Year() == n(y) && int(tm.Month()) == n(mo) && tm.Day() == n(d) && n(y) >= 1900
	}
	var tm time.Time
	var ok, timed bool
	if m := reISODate.FindStringSubmatch(t); m != nil {
		tm, ok = at(m[1], m[2], m[3], "0", "0", "0")
	} else if m := reISODT.FindStringSubmatch(t); m != nil {
		tm, ok = at(m[1], m[2], m[3], m[4], m[5], m[6])
		timed = true
	} else if m := reRuDate.FindStringSubmatch(t); m != nil {
		tm, ok = at(m[3], m[2], m[1], "0", "0", "0")
	} else if m := reRuDT.FindStringSubmatch(t); m != nil {
		tm, ok = at(m[3], m[2], m[1], m[4], m[5], "0")
		timed = true
	}
	if !ok {
		return Cell{}, false
	}
	serial := Serial(tm)
	if timed {
		return Cell{Kind: DateTime, Num: serial}, true
	}
	return Cell{Kind: Date, Num: serial}, true
}

// Serial is the Excel day number of a moment (days since 1899-12-30, the time of day as the fraction).
func Serial(t time.Time) float64 {
	base := time.Date(1899, 12, 30, 0, 0, 0, 0, time.UTC)
	t = time.Date(t.Year(), t.Month(), t.Day(), t.Hour(), t.Minute(), t.Second(), 0, time.UTC)
	return t.Sub(base).Hours() / 24
}

var ruFuncs = strings.NewReplacer("СУММ(", "SUM(", "СРЗНАЧ(", "AVERAGE(", "МИН(", "MIN(", "МАКС(", "MAX(", "СЧЁТ(", "COUNT(",
	"СЧЕТ(", "COUNT(", "ОКРУГЛ(", "ROUND(", "ЕСЛИ(", "IF(", "СЧЁТЗ(", "COUNTA(", "СЧЕТЗ(", "COUNTA(", "ПРОИЗВЕД(", "PRODUCT(")

// excelFormula writes a formula the way the file format wants it: English function names and "," between arguments
// (the Russian Excel shows "СУММ(A1;A2)", the file holds "SUM(A1,A2)").
func excelFormula(f string) string {
	f = ruFuncs.Replace(strings.TrimSpace(f))
	var b strings.Builder
	inStr := false
	for _, r := range f {
		switch {
		case r == '"':
			inStr = !inStr
		case r == ';' && !inStr:
			r = ','
		}
		b.WriteRune(r)
	}
	return b.String()
}

// Col is the column letter of a 0-based index (0 = A, 26 = AA).
func Col(i int) string {
	s := ""
	for i++; i > 0; i = (i - 1) / 26 {
		s = string(rune('A'+(i-1)%26)) + s
	}
	return s
}

// XLSX renders a workbook.
func XLSX(sheets []Sheet, title, author string, now time.Time) ([]byte, error) {
	if len(sheets) == 0 {
		return nil, errors.New("no sheets")
	}
	names := map[string]bool{}
	for i := range sheets {
		sheets[i].Name = sheetName(sheets[i].Name, i, names)
	}
	if now.IsZero() {
		now = time.Now()
	}
	var buf bytes.Buffer
	z := zip.NewWriter(&buf)
	var ct, rels, list, defined strings.Builder
	for i, sh := range sheets {
		fmt.Fprintf(&ct, `<Override PartName="/xl/worksheets/sheet%d.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`, i+1)
		fmt.Fprintf(&rels, `<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet%d.xml"/>`, i+1, i+1)
		fmt.Fprintf(&list, `<sheet name="%s" sheetId="%d" r:id="rId%d"/>`, escAttr(sh.Name), i+1, i+1)
		if ref := filterRef(sh); ref != "" {
			fmt.Fprintf(&defined, `<definedName name="_xlnm._FilterDatabase" localSheetId="%d" hidden="1">'%s'!%s</definedName>`, i, esc(strings.ReplaceAll(sh.Name, "'", "''")), absRef(ref))
		}
		if err := put(z, fmt.Sprintf("xl/worksheets/sheet%d.xml", i+1), []byte(sheetXML(sh, i == 0))); err != nil {
			return nil, err
		}
	}
	wb := xmlHead + `<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="` + nsR + `">` +
		`<bookViews><workbookView xWindow="0" yWindow="0" windowWidth="28800" windowHeight="15000"/></bookViews><sheets>` + list.String() + `</sheets>`
	if defined.Len() > 0 {
		wb += `<definedNames>` + defined.String() + `</definedNames>`
	}
	wb += `<calcPr calcId="191029" fullCalcOnLoad="1"/></workbook>`
	files := []struct{ name, body string }{
		{"[Content_Types].xml", xmlHead + `<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">` +
			`<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>` +
			`<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>` + ct.String() +
			`<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>` +
			`<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>` +
			`<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>`},
		{"_rels/.rels", xmlHead + `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">` +
			`<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>` +
			`<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>` +
			`<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>`},
		{"xl/workbook.xml", wb},
		{"xl/_rels/workbook.xml.rels", xmlHead + `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">` + rels.String() +
			`<Relationship Id="rIdS" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`},
		{"xl/styles.xml", xlsxStyles},
		{"docProps/core.xml", coreProps(title, author, now)},
		{"docProps/app.xml", appProps("Microsoft Excel")},
	}
	for _, f := range files {
		if err := put(z, f.name, []byte(f.body)); err != nil {
			return nil, err
		}
	}
	if err := z.Close(); err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}

// sheetName makes a name Excel accepts: at most 31 characters, none of []:*?/\, unique.
func sheetName(n string, i int, used map[string]bool) string {
	n = strings.Map(func(r rune) rune {
		if strings.ContainsRune(`[]:*?/\`, r) || r < 0x20 {
			return ' '
		}
		return r
	}, strings.TrimSpace(n))
	n = strings.Trim(n, "'")
	if n == "" {
		n = fmt.Sprintf("Лист%d", i+1)
	}
	if r := []rune(n); len(r) > 31 {
		n = string(r[:31])
	}
	base := n
	for k := 2; used[strings.ToLower(n)]; k++ {
		suffix := fmt.Sprintf(" (%d)", k)
		r := []rune(base)
		if len(r)+len([]rune(suffix)) > 31 {
			r = r[:31-len([]rune(suffix))]
		}
		n = string(r) + suffix
	}
	used[strings.ToLower(n)] = true
	return n
}

func width(sh Sheet) int {
	w := 0
	for _, r := range sh.Rows {
		w = max(w, len(r))
	}
	return w
}

func filterRef(sh Sheet) string {
	if !sh.Header || len(sh.Rows) < 2 || width(sh) == 0 {
		return ""
	}
	return fmt.Sprintf("A1:%s%d", Col(width(sh)-1), len(sh.Rows))
}

func absRef(ref string) string {
	a, b, _ := strings.Cut(ref, ":")
	abs := func(r string) string {
		i := strings.IndexAny(r, "0123456789")
		return "$" + r[:i] + "$" + r[i:]
	}
	return abs(a) + ":" + abs(b)
}

// styles of cellXfs below
const (
	stDefault = iota
	stHeader
	stDate
	stDateTime
	stPercent
	stWrap
)

func sheetXML(sh Sheet, first bool) string {
	cols := width(sh)
	ev := newEval(sh)
	var b strings.Builder
	b.WriteString(xmlHead + `<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="` + nsR + `">`)
	if cols > 0 && len(sh.Rows) > 0 {
		fmt.Fprintf(&b, `<dimension ref="A1:%s%d"/>`, Col(cols-1), len(sh.Rows))
	}
	sel := ""
	if first {
		sel = ` tabSelected="1"`
	}
	if sh.Header && len(sh.Rows) > 1 {
		fmt.Fprintf(&b, `<sheetViews><sheetView workbookViewId="0"%s><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/><selection pane="bottomLeft" activeCell="A2" sqref="A2"/></sheetView></sheetViews>`, sel)
	} else {
		fmt.Fprintf(&b, `<sheetViews><sheetView workbookViewId="0"%s/></sheetViews>`, sel)
	}
	b.WriteString(`<sheetFormatPr defaultRowHeight="15"/>`)
	if cols > 0 {
		b.WriteString("<cols>")
		for c := 0; c < cols; c++ {
			fmt.Fprintf(&b, `<col min="%d" max="%d" width="%.1f" customWidth="1"/>`, c+1, c+1, colWidth(sh, c))
		}
		b.WriteString("</cols>")
	}
	b.WriteString("<sheetData>")
	for r, row := range sh.Rows {
		fmt.Fprintf(&b, `<row r="%d">`, r+1)
		for c, cell := range row {
			ref := fmt.Sprintf("%s%d", Col(c), r+1)
			header := sh.Header && r == 0
			b.WriteString(cellXML(ref, cell, header, ev))
		}
		b.WriteString("</row>")
	}
	b.WriteString("</sheetData>")
	if ref := filterRef(sh); ref != "" {
		fmt.Fprintf(&b, `<autoFilter ref="%s"/>`, ref)
	}
	b.WriteString(`<pageMargins left="0.7" right="0.7" top="0.75" bottom="0.75" header="0.3" footer="0.3"/></worksheet>`)
	return b.String()
}

func colWidth(sh Sheet, c int) float64 {
	w := 6
	for r, row := range sh.Rows {
		if c >= len(row) {
			continue
		}
		var n int
		switch cl := row[c]; cl.Kind {
		case Text:
			n = 0
			for _, line := range strings.Split(cl.Str, "\n") {
				n = max(n, len([]rune(line)))
			}
			if sh.Header && r == 0 {
				n += 3 // the filter button
			}
		case Number:
			n = len(strconv.FormatFloat(cl.Num, 'f', -1, 64))
		case Date:
			n = 10
		case DateTime:
			n = 16
		case Formula, Percent, Bool:
			n = 8
		}
		w = max(w, n)
	}
	return math.Min(60, float64(w)+2)
}

func cellXML(ref string, c Cell, header bool, ev *eval) string {
	style := stDefault
	if header {
		style = stHeader
	}
	s := func(st int) string {
		if st == stDefault {
			return ""
		}
		return fmt.Sprintf(` s="%d"`, st)
	}
	num := func(f float64) string { return strconv.FormatFloat(f, 'g', 15, 64) }
	switch c.Kind {
	case Empty:
		if header {
			return fmt.Sprintf(`<c r="%s"%s/>`, ref, s(style))
		}
		return ""
	case Number:
		return fmt.Sprintf(`<c r="%s"%s><v>%s</v></c>`, ref, s(style), num(c.Num))
	case Bool:
		return fmt.Sprintf(`<c r="%s"%s t="b"><v>%d</v></c>`, ref, s(style), int(c.Num))
	case Date, DateTime, Percent:
		if !header {
			style = map[CellKind]int{Date: stDate, DateTime: stDateTime, Percent: stPercent}[c.Kind]
		}
		return fmt.Sprintf(`<c r="%s"%s><v>%s</v></c>`, ref, s(style), num(c.Num))
	case Formula:
		if v, ok := ev.value(ref); ok {
			return fmt.Sprintf(`<c r="%s"%s><f>%s</f><v>%s</v></c>`, ref, s(style), esc(c.Str), num(v))
		}
		return fmt.Sprintf(`<c r="%s"%s><f>%s</f></c>`, ref, s(style), esc(c.Str))
	}
	if !header && (strings.Contains(c.Str, "\n") || len([]rune(c.Str)) > 60) {
		style = stWrap
	}
	return fmt.Sprintf(`<c r="%s"%s t="inlineStr"><is><t xml:space="preserve">%s</t></is></c>`, ref, s(style), esc(c.Str))
}

var xlsxStyles = xmlHead + `<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">` +
	`<numFmts count="2"><numFmt numFmtId="164" formatCode="dd.mm.yyyy"/><numFmt numFmtId="165" formatCode="dd.mm.yyyy hh:mm"/></numFmts>` +
	`<fonts count="2"><font><sz val="11"/><color theme="1"/><name val="Calibri"/><family val="2"/><scheme val="minor"/></font>` +
	`<font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/><family val="2"/><scheme val="minor"/></font></fonts>` +
	`<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>` +
	`<fill><patternFill patternType="solid"><fgColor rgb="FF4472C4"/><bgColor indexed="64"/></patternFill></fill></fills>` +
	`<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border>` +
	`<border><left style="thin"><color rgb="FF8EA9DB"/></left><right style="thin"><color rgb="FF8EA9DB"/></right><top style="thin"><color rgb="FF8EA9DB"/></top><bottom style="thin"><color rgb="FF8EA9DB"/></bottom><diagonal/></border></borders>` +
	`<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>` +
	`<cellXfs count="6"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>` +
	`<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>` +
	`<xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>` +
	`<xf numFmtId="165" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>` +
	`<xf numFmtId="10" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>` +
	`<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf></cellXfs>` +
	`<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles><dxfs count="0"/><tableStyles count="0"/></styleSheet>`

// CSV renders rows as CSV with a UTF-8 mark at the start: without it Excel reads Cyrillic as garbage.
func CSV(rows [][]Cell) []byte {
	var b bytes.Buffer
	b.WriteString("\ufeff")
	w := csv.NewWriter(&b)
	for _, r := range rows {
		rec := make([]string, len(r))
		for i, c := range r {
			rec[i] = c.String()
		}
		_ = w.Write(rec)
	}
	w.Flush()
	return b.Bytes()
}

// String shows a cell as text (dates in the Russian way, formulas with "=").
func (c Cell) String() string {
	switch c.Kind {
	case Number:
		return strconv.FormatFloat(c.Num, 'f', -1, 64)
	case Bool:
		if c.Num != 0 {
			return "TRUE"
		}
		return "FALSE"
	case Formula:
		return "=" + c.Str
	case Percent:
		return strconv.FormatFloat(c.Num*100, 'f', -1, 64) + "%"
	case Date, DateTime:
		t := time.Date(1899, 12, 30, 0, 0, 0, 0, time.UTC).Add(time.Duration(c.Num * 24 * float64(time.Hour)))
		if c.Kind == Date {
			return t.Format("02.01.2006")
		}
		return t.Round(time.Minute).Format("02.01.2006 15:04")
	}
	return c.Str
}

// ParseTable reads the rows she passes: JSON (an array of arrays or of objects; an object of such arrays = several
// sheets), a Markdown table, or CSV/TSV with the separator guessed (tab, ";", ",", "|").
func ParseTable(data string) ([]Sheet, error) {
	data = strings.TrimPrefix(strings.TrimSpace(data), "\ufeff")
	if data == "" {
		return nil, errors.New("no data")
	}
	if data[0] == '[' || data[0] == '{' {
		v, err := decodeOrdered(json.NewDecoder(strings.NewReader(data)))
		if err == nil {
			return jsonSheets(v)
		}
		if data[0] == '{' {
			return nil, fmt.Errorf("bad JSON: %w", err)
		}
	}
	for _, b := range Parse(data) {
		if b.Kind == TableBlock {
			rows := [][]Cell{plainRow(b.Header)}
			for _, r := range b.Rows {
				rows = append(rows, plainRow(r))
			}
			return []Sheet{{Rows: rows, Header: true}}, nil
		}
	}
	r := csv.NewReader(strings.NewReader(data))
	r.Comma = guessComma(data)
	r.LazyQuotes, r.FieldsPerRecord, r.TrimLeadingSpace = true, -1, true
	var rows [][]Cell
	for {
		rec, err := r.Read()
		if err == io.EOF {
			break
		}
		if err != nil {
			return nil, fmt.Errorf("line %d: %w", len(rows)+1, err)
		}
		row := make([]Cell, len(rec))
		for i, s := range rec {
			row[i] = Value(s)
		}
		rows = append(rows, row)
	}
	return []Sheet{{Rows: rows, Header: true}}, nil
}

func plainRow(cells [][]Span) []Cell {
	row := make([]Cell, len(cells))
	for i, c := range cells {
		row[i] = Value(Plain(c))
	}
	return row
}

func guessComma(data string) rune {
	lines := strings.Split(data, "\n")
	if len(lines) > 12 {
		lines = lines[:12]
	}
	best, bestScore := ',', 0
	for _, c := range []rune{'\t', ';', ',', '|'} {
		counts := map[int]int{}
		total := 0
		for _, l := range lines {
			if strings.TrimSpace(l) == "" {
				continue
			}
			counts[strings.Count(l, string(c))]++
			total++
		}
		// the separator appears the same number of times on most lines
		for n, k := range counts {
			if n > 0 && k*2 >= total && n*k > bestScore {
				best, bestScore = c, n*k
			}
		}
	}
	return best
}

// ordered JSON: objects keep the order of their keys (map would lose it, and columns would come out shuffled).
type kv struct {
	k string
	v any
}

type object []kv

func decodeOrdered(d *json.Decoder) (any, error) {
	d.UseNumber()
	tok, err := d.Token()
	if err != nil {
		return nil, err
	}
	return value(d, tok)
}

func value(d *json.Decoder, tok json.Token) (any, error) {
	switch t := tok.(type) {
	case json.Delim:
		switch t {
		case '{':
			var o object
			for d.More() {
				kt, err := d.Token()
				if err != nil {
					return nil, err
				}
				key, _ := kt.(string)
				vt, err := d.Token()
				if err != nil {
					return nil, err
				}
				v, err := value(d, vt)
				if err != nil {
					return nil, err
				}
				o = append(o, kv{key, v})
			}
			_, err := d.Token()
			return o, err
		case '[':
			var a []any
			for d.More() {
				vt, err := d.Token()
				if err != nil {
					return nil, err
				}
				v, err := value(d, vt)
				if err != nil {
					return nil, err
				}
				a = append(a, v)
			}
			_, err := d.Token()
			return a, err
		}
	}
	return tok, nil
}

func jsonSheets(v any) ([]Sheet, error) {
	switch t := v.(type) {
	case []any:
		sh, err := jsonRows(t)
		return []Sheet{sh}, err
	case object:
		// {"rows": [...]} or {"Sheet": [...], "Other": [...]}
		var out []Sheet
		for _, e := range t {
			a, ok := e.v.([]any)
			if !ok {
				return nil, fmt.Errorf("%q: expected an array of rows", e.k)
			}
			sh, err := jsonRows(a)
			if err != nil {
				return nil, fmt.Errorf("%q: %w", e.k, err)
			}
			if e.k != "rows" && e.k != "data" {
				sh.Name = e.k
			}
			out = append(out, sh)
		}
		if len(out) == 0 {
			return nil, errors.New("no rows")
		}
		return out, nil
	}
	return nil, errors.New("expected an array of rows")
}

func jsonRows(a []any) (Sheet, error) {
	if len(a) == 0 {
		return Sheet{}, errors.New("no rows")
	}
	if _, isObj := a[0].(object); isObj { // records: the keys are the columns
		var keys []string
		index := map[string]int{}
		for _, r := range a {
			o, ok := r.(object)
			if !ok {
				return Sheet{}, errors.New("mixed rows: objects and arrays")
			}
			for _, e := range o {
				if _, ok := index[e.k]; !ok {
					index[e.k] = len(keys)
					keys = append(keys, e.k)
				}
			}
		}
		head := make([]Cell, len(keys))
		for i, k := range keys {
			head[i] = Cell{Kind: Text, Str: k}
		}
		rows := [][]Cell{head}
		for _, r := range a {
			row := make([]Cell, len(keys))
			for _, e := range r.(object) {
				row[index[e.k]] = jsonCell(e.v)
			}
			rows = append(rows, row)
		}
		return Sheet{Rows: rows, Header: true}, nil
	}
	var rows [][]Cell
	for _, r := range a {
		arr, ok := r.([]any)
		if !ok {
			arr = []any{r} // a list of values: one column
		}
		row := make([]Cell, len(arr))
		for i, v := range arr {
			row[i] = jsonCell(v)
		}
		rows = append(rows, row)
	}
	return Sheet{Rows: rows, Header: true}, nil
}

func jsonCell(v any) Cell {
	switch t := v.(type) {
	case nil:
		return Cell{}
	case json.Number:
		if f, err := t.Float64(); err == nil {
			return Cell{Kind: Number, Num: f}
		}
		return Cell{Kind: Text, Str: t.String()}
	case bool:
		if t {
			return Cell{Kind: Bool, Num: 1}
		}
		return Cell{Kind: Bool}
	case string:
		return Value(t)
	case object:
		parts := make([]string, len(t))
		for i, e := range t {
			parts[i] = fmt.Sprintf("%s: %v", e.k, e.v)
		}
		return Cell{Kind: Text, Str: strings.Join(parts, ", ")}
	}
	b, _ := json.Marshal(v)
	return Cell{Kind: Text, Str: string(b)}
}
