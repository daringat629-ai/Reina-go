package office

import (
	"archive/zip"
	"bytes"
	"fmt"
	"image"
	_ "image/gif" // image sizes
	_ "image/jpeg"
	_ "image/png"
	"os"
	"path/filepath"
	"strings"
	"time"
)

// Doc describes a Word document to make.
type Doc struct {
	Title  string // document title (shown at the top unless the text starts with a heading) and in the file's properties
	Author string
	Text   string // Markdown
	// Images resolves an image path of the text to a file; nil = the path as written (relative to the working dir).
	Images func(src string) string
	Now    time.Time // creation time in the properties (zero = now)
}

// Page geometry: A4 with 2 cm margins, in twips (1/20 pt). Drawings are measured in EMU (635 per twip).
const (
	pageW, pageH, margin = 11906, 16838, 1134
	textW                = pageW - 2*margin
	emuPerTwip           = 635
	emuPerPx             = 9525 // at 96 dpi
)

// DOCX renders the document. Images that cannot be read are replaced by their description (the document is still
// made); the second result names them.
func DOCX(d Doc) ([]byte, []string, error) {
	w := &docxWriter{doc: d}
	blocks := Parse(d.Text)
	if t := strings.TrimSpace(d.Title); t != "" && (len(blocks) == 0 || blocks[0].Kind != Heading || blocks[0].Level != 1) {
		w.para("Title", "", Inline(t))
	}
	for _, b := range blocks {
		w.block(b)
	}
	if strings.HasSuffix(w.body.String(), "</w:tbl>") || w.body.Len() == 0 {
		w.body.WriteString("<w:p/>") // a document ends with a paragraph
	}
	var buf bytes.Buffer
	z := zip.NewWriter(&buf)
	now := d.Now
	if now.IsZero() {
		now = time.Now()
	}
	title := strings.TrimSpace(d.Title)
	if title == "" {
		for _, b := range blocks {
			if b.Kind == Heading {
				title = Plain(b.Spans)
				break
			}
		}
	}
	files := []struct{ name, body string }{
		{"[Content_Types].xml", w.contentTypes()},
		{"_rels/.rels", xmlHead + `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">` +
			`<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>` +
			`<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>` +
			`<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>` +
			`</Relationships>`},
		{"docProps/core.xml", coreProps(title, d.Author, now)},
		{"docProps/app.xml", appProps("Microsoft Office Word")},
		{"word/document.xml", w.document()},
		{"word/styles.xml", docxStyles},
		{"word/numbering.xml", w.numbering()},
		{"word/settings.xml", xmlHead + `<w:settings xmlns:w="` + nsW + `"><w:defaultTabStop w:val="708"/><w:characterSpacingControl w:val="doNotCompress"/><w:compat><w:compatSetting w:name="compatibilityMode" w:uri="http://schemas.microsoft.com/office/word" w:val="15"/></w:compat></w:settings>`},
		{"word/_rels/document.xml.rels", w.rels()},
	}
	for _, f := range files {
		if err := put(z, f.name, []byte(f.body)); err != nil {
			return nil, nil, err
		}
	}
	for _, im := range w.images {
		if err := put(z, "word/media/"+im.name, im.data); err != nil {
			return nil, nil, err
		}
	}
	if err := z.Close(); err != nil {
		return nil, nil, err
	}
	return buf.Bytes(), w.missing, nil
}

const (
	xmlHead = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` + "\n"
	nsW     = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
	nsR     = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
)

type docImage struct {
	name, rid string
	data      []byte
}

type docxWriter struct {
	doc     Doc
	body    strings.Builder
	links   []string // hyperlink targets, rId = "rIdL<n>"
	images  []docImage
	missing []string
	lists   []int // start number of each ordered list (a w:num each, so the numbering restarts)
}

func put(z *zip.Writer, name string, data []byte) error {
	f, err := z.CreateHeader(&zip.FileHeader{Name: name, Method: zip.Deflate, Modified: time.Date(2026, 1, 1, 0, 0, 0, 0, time.UTC)})
	if err != nil {
		return err
	}
	_, err = f.Write(data)
	return err
}

func (w *docxWriter) block(b Block) {
	switch b.Kind {
	case Para:
		w.para("", "", b.Spans)
	case Heading:
		w.para(fmt.Sprintf("Heading%d", b.Level), "", b.Spans)
	case Quote:
		w.para("Quote", "", b.Spans)
	case CodeBlock:
		lines := strings.Split(b.Text, "\n")
		for i, l := range lines {
			extra := ""
			if i == len(lines)-1 {
				extra = `<w:spacing w:after="160"/>`
			}
			w.para("Code", extra, []Span{{Text: l, Code: true}})
		}
	case Rule:
		w.body.WriteString(`<w:p><w:pPr><w:pBdr><w:bottom w:val="single" w:sz="6" w:space="1" w:color="A6A6A6"/></w:pBdr></w:pPr></w:p>`)
	case PageBreak:
		w.body.WriteString(`<w:p><w:r><w:br w:type="page"/></w:r></w:p>`)
	case ListBlock:
		num := 1 // the bullets
		if len(b.Items) > 0 && b.Items[0].Ordered {
			w.lists = append(w.lists, b.Start)
			num = 1 + len(w.lists)
		}
		for _, it := range b.Items {
			n := num
			if !it.Ordered && num != 1 { // a bullet sub-item under a numbered list
				n = 1
			}
			w.para("ListParagraph", fmt.Sprintf(`<w:numPr><w:ilvl w:val="%d"/><w:numId w:val="%d"/></w:numPr>`, it.Level, n), it.Spans)
		}
	case TableBlock:
		w.table(b)
	case Image:
		w.image(b)
	}
}

// para writes one paragraph with a style and extra paragraph properties.
func (w *docxWriter) para(style, ppr string, spans []Span) {
	w.body.WriteString("<w:p>")
	if style != "" || ppr != "" {
		w.body.WriteString("<w:pPr>")
		if style != "" {
			w.body.WriteString(`<w:pStyle w:val="` + style + `"/>`)
		}
		w.body.WriteString(ppr)
		w.body.WriteString("</w:pPr>")
	}
	w.runs(spans)
	w.body.WriteString("</w:p>")
}

func (w *docxWriter) runs(spans []Span) {
	for _, s := range spans {
		if s.Break {
			w.body.WriteString("<w:r><w:br/></w:r>")
			continue
		}
		run := runXML(s)
		if s.Link != "" {
			w.links = append(w.links, s.Link)
			fmt.Fprintf(&w.body, `<w:hyperlink r:id="rIdL%d" w:history="1">%s</w:hyperlink>`, len(w.links), run)
			continue
		}
		w.body.WriteString(run)
	}
}

func runXML(s Span) string {
	var pr strings.Builder
	if s.Link != "" {
		pr.WriteString(`<w:rStyle w:val="Hyperlink"/>`)
	}
	if s.Code {
		pr.WriteString(`<w:rFonts w:ascii="Consolas" w:hAnsi="Consolas" w:cs="Consolas"/><w:shd w:val="clear" w:color="auto" w:fill="F2F2F2"/>`)
	}
	if s.Bold {
		pr.WriteString("<w:b/><w:bCs/>")
	}
	if s.Italic {
		pr.WriteString("<w:i/><w:iCs/>")
	}
	if s.Strike {
		pr.WriteString("<w:strike/>")
	}
	var b strings.Builder
	b.WriteString("<w:r>")
	if pr.Len() > 0 {
		b.WriteString("<w:rPr>" + pr.String() + "</w:rPr>")
	}
	// tabs inside the text become real tabs
	for i, part := range strings.Split(s.Text, "\t") {
		if i > 0 {
			b.WriteString("<w:tab/>")
		}
		if part != "" {
			b.WriteString(`<w:t xml:space="preserve">` + esc(part) + `</w:t>`)
		}
	}
	b.WriteString("</w:r>")
	return b.String()
}

func (w *docxWriter) table(b Block) {
	cols := len(b.Header)
	for _, r := range b.Rows {
		cols = max(cols, len(r))
	}
	if cols == 0 {
		return
	}
	// column widths by the length of their text, within the page
	weight := make([]int, cols)
	measure := func(row [][]Span) {
		for i, c := range row {
			weight[i] = max(weight[i], min(40, len([]rune(Plain(c))))+3)
		}
	}
	measure(b.Header)
	for _, r := range b.Rows {
		measure(r)
	}
	total := 0
	for _, x := range weight {
		total += x
	}
	widths := make([]int, cols)
	for i, x := range weight {
		widths[i] = textW * x / total
	}
	w.body.WriteString(`<w:tbl><w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:w="5000" w:type="pct"/><w:tblLook w:val="04A0" w:firstRow="1" w:lastRow="0" w:firstColumn="0" w:lastColumn="0" w:noHBand="0" w:noVBand="1"/></w:tblPr><w:tblGrid>`)
	for _, x := range widths {
		fmt.Fprintf(&w.body, `<w:gridCol w:w="%d"/>`, x)
	}
	w.body.WriteString("</w:tblGrid>")
	row := func(r [][]Span, header bool, n int) {
		w.body.WriteString("<w:tr>")
		if header {
			w.body.WriteString(`<w:trPr><w:tblHeader/></w:trPr>`)
		}
		for i := 0; i < cols; i++ {
			var c []Span
			if i < len(r) {
				c = r[i]
			}
			fill := ""
			switch {
			case header:
				fill = `<w:shd w:val="clear" w:color="auto" w:fill="DCE6F2"/>`
			case n%2 == 1:
				fill = `<w:shd w:val="clear" w:color="auto" w:fill="F7F9FC"/>`
			}
			fmt.Fprintf(&w.body, `<w:tc><w:tcPr><w:tcW w:w="%d" w:type="dxa"/>%s</w:tcPr>`, widths[i], fill)
			jc := ""
			if i < len(b.Align) {
				switch b.Align[i] {
				case 'c':
					jc = `<w:jc w:val="center"/>`
				case 'r':
					jc = `<w:jc w:val="right"/>`
				}
			}
			if header {
				for k := range c {
					c[k].Bold = true
				}
			}
			w.para("TableText", jc, c)
			w.body.WriteString("</w:tc>")
		}
		w.body.WriteString("</w:tr>")
	}
	row(b.Header, true, 0)
	for n, r := range b.Rows {
		row(r, false, n)
	}
	w.body.WriteString("</w:tbl>")
}

func (w *docxWriter) image(b Block) {
	path := b.Src
	if w.doc.Images != nil {
		path = w.doc.Images(b.Src)
	}
	data, err := os.ReadFile(path)
	var cfg image.Config
	var format string
	if err == nil {
		cfg, format, err = image.DecodeConfig(bytes.NewReader(data))
	}
	if err != nil || (format != "png" && format != "jpeg" && format != "gif") {
		w.missing = append(w.missing, b.Src)
		w.para("Caption", "", []Span{{Text: "[" + firstNonEmpty(b.Alt, b.Src) + "]", Italic: true}})
		return
	}
	ext := map[string]string{"png": "png", "jpeg": "jpeg", "gif": "gif"}[format]
	im := docImage{name: fmt.Sprintf("image%d.%s", len(w.images)+1, ext), rid: fmt.Sprintf("rIdI%d", len(w.images)+1), data: data}
	w.images = append(w.images, im)
	cx, cy := int64(cfg.Width)*emuPerPx, int64(cfg.Height)*emuPerPx
	if maxW := int64(textW) * emuPerTwip; cx > maxW { // fit the text width, keep the proportions
		cy = cy * maxW / cx
		cx = maxW
	}
	if maxH := int64(pageH-2*margin-1200) * emuPerTwip; cy > maxH {
		cx = cx * maxH / cy
		cy = maxH
	}
	id := len(w.images)
	fmt.Fprintf(&w.body, `<w:p><w:pPr><w:pStyle w:val="Picture"/></w:pPr><w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0">`+
		`<wp:extent cx="%d" cy="%d"/><wp:effectExtent l="0" t="0" r="0" b="0"/><wp:docPr id="%d" name="Picture %d" descr="%s"/>`+
		`<wp:cNvGraphicFramePr><a:graphicFrameLocks noChangeAspect="1"/></wp:cNvGraphicFramePr>`+
		`<a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic>`+
		`<pic:nvPicPr><pic:cNvPr id="%d" name="%s"/><pic:cNvPicPr/></pic:nvPicPr>`+
		`<pic:blipFill><a:blip r:embed="%s"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>`+
		`<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="%d" cy="%d"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr>`+
		`</pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>`,
		cx, cy, id, id, esc(b.Alt), id, im.name, im.rid, cx, cy)
	if strings.TrimSpace(b.Alt) != "" {
		w.para("Caption", "", []Span{{Text: b.Alt}})
	}
}

func firstNonEmpty(a ...string) string {
	for _, s := range a {
		if strings.TrimSpace(s) != "" {
			return s
		}
	}
	return ""
}

func (w *docxWriter) document() string {
	return xmlHead + `<w:document xmlns:w="` + nsW + `" xmlns:r="` + nsR + `"` +
		` xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"` +
		` xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"` +
		` xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><w:body>` + w.body.String() +
		fmt.Sprintf(`<w:sectPr><w:pgSz w:w="%d" w:h="%d"/><w:pgMar w:top="%d" w:right="%d" w:bottom="%d" w:left="%d" w:header="709" w:footer="709" w:gutter="0"/><w:pgNumType w:start="1"/><w:cols w:space="708"/></w:sectPr>`,
			pageW, pageH, margin, margin, margin, margin) +
		`</w:body></w:document>`
}

func (w *docxWriter) rels() string {
	var b strings.Builder
	b.WriteString(xmlHead + `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">`)
	b.WriteString(`<Relationship Id="rIdS" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>`)
	b.WriteString(`<Relationship Id="rIdN" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering" Target="numbering.xml"/>`)
	b.WriteString(`<Relationship Id="rIdT" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings" Target="settings.xml"/>`)
	for i, l := range w.links {
		fmt.Fprintf(&b, `<Relationship Id="rIdL%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink" Target="%s" TargetMode="External"/>`, i+1, escAttr(l))
	}
	for _, im := range w.images {
		fmt.Fprintf(&b, `<Relationship Id="%s" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/%s"/>`, im.rid, im.name)
	}
	b.WriteString(`</Relationships>`)
	return b.String()
}

func (w *docxWriter) contentTypes() string {
	return xmlHead + `<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">` +
		`<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>` +
		`<Default Extension="xml" ContentType="application/xml"/>` +
		`<Default Extension="png" ContentType="image/png"/><Default Extension="jpeg" ContentType="image/jpeg"/><Default Extension="gif" ContentType="image/gif"/>` +
		`<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>` +
		`<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>` +
		`<Override PartName="/word/numbering.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml"/>` +
		`<Override PartName="/word/settings.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml"/>` +
		`<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>` +
		`<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>` +
		`</Types>`
}

// numbering: numId 1 = bullets, numId 2.. = one per numbered list (each restarts at its own start).
func (w *docxWriter) numbering() string {
	var b strings.Builder
	b.WriteString(xmlHead + `<w:numbering xmlns:w="` + nsW + `">`)
	bullets := []string{"•", "◦", "▪"}
	b.WriteString(`<w:abstractNum w:abstractNumId="0"><w:multiLevelType w:val="hybridMultilevel"/>`)
	for l := 0; l < 9; l++ {
		fmt.Fprintf(&b, `<w:lvl w:ilvl="%d"><w:start w:val="1"/><w:numFmt w:val="bullet"/><w:lvlText w:val="%s"/><w:lvlJc w:val="left"/><w:pPr><w:ind w:left="%d" w:hanging="360"/></w:pPr><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial"/></w:rPr></w:lvl>`,
			l, bullets[l%3], 720+l*360)
	}
	b.WriteString(`</w:abstractNum>`)
	b.WriteString(`<w:abstractNum w:abstractNumId="1"><w:multiLevelType w:val="hybridMultilevel"/>`)
	formats := []string{"decimal", "lowerLetter", "lowerRoman"}
	for l := 0; l < 9; l++ {
		sep := "."
		if l%3 == 1 {
			sep = ")"
		}
		fmt.Fprintf(&b, `<w:lvl w:ilvl="%d"><w:start w:val="1"/><w:numFmt w:val="%s"/><w:lvlText w:val="%%%d%s"/><w:lvlJc w:val="left"/><w:pPr><w:ind w:left="%d" w:hanging="360"/></w:pPr></w:lvl>`,
			l, formats[l%3], l+1, sep, 720+l*360)
	}
	b.WriteString(`</w:abstractNum>`)
	b.WriteString(`<w:num w:numId="1"><w:abstractNumId w:val="0"/></w:num>`)
	for i, start := range w.lists {
		fmt.Fprintf(&b, `<w:num w:numId="%d"><w:abstractNumId w:val="1"/><w:lvlOverride w:ilvl="0"><w:startOverride w:val="%d"/></w:lvlOverride></w:num>`, i+2, max(start, 0))
	}
	b.WriteString(`</w:numbering>`)
	return b.String()
}

func coreProps(title, author string, now time.Time) string {
	if author == "" {
		author = "Kuni"
	}
	ts := now.UTC().Format("2006-01-02T15:04:05Z")
	return xmlHead + `<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">` +
		`<dc:title>` + esc(title) + `</dc:title><dc:creator>` + esc(author) + `</dc:creator><cp:lastModifiedBy>` + esc(author) + `</cp:lastModifiedBy>` +
		`<dcterms:created xsi:type="dcterms:W3CDTF">` + ts + `</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">` + ts + `</dcterms:modified></cp:coreProperties>`
}

func appProps(app string) string {
	return xmlHead + `<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>` + app + `</Application></Properties>`
}

// esc escapes text for XML and drops the characters XML 1.0 cannot hold (control characters a model may emit).
func esc(s string) string {
	var b strings.Builder
	for _, r := range s {
		switch {
		case r == '<':
			b.WriteString("&lt;")
		case r == '>':
			b.WriteString("&gt;")
		case r == '&':
			b.WriteString("&amp;")
		case r == '\t' || r == '\n' || r == '\r':
			b.WriteRune(r)
		case r < 0x20 || (r >= 0xD800 && r <= 0xDFFF) || r == 0xFFFE || r == 0xFFFF:
			// not allowed in XML
		default:
			b.WriteRune(r)
		}
	}
	return b.String()
}

func escAttr(s string) string { return strings.ReplaceAll(esc(s), `"`, "&quot;") }

// ImagesIn resolves image paths of a document against dir (relative ones) or as given (absolute ones).
func ImagesIn(dir string) func(string) string {
	return func(src string) string {
		if filepath.IsAbs(src) {
			return src
		}
		return filepath.Join(dir, src)
	}
}

var docxStyles = xmlHead + `<w:styles xmlns:w="` + nsW + `">` +
	`<w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:eastAsia="Calibri" w:cs="Calibri"/><w:sz w:val="22"/><w:szCs w:val="22"/><w:lang w:val="ru-RU" w:eastAsia="en-US" w:bidi="ar-SA"/></w:rPr></w:rPrDefault>` +
	`<w:pPrDefault><w:pPr><w:spacing w:after="120" w:line="276" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults>` +
	`<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style>` +
	`<w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:spacing w:after="240"/><w:contextualSpacing/></w:pPr><w:rPr><w:rFonts w:ascii="Calibri Light" w:hAnsi="Calibri Light"/><w:color w:val="1F3864"/><w:kern w:val="28"/><w:sz w:val="52"/><w:szCs w:val="52"/></w:rPr></w:style>` +
	heading(1, 36, "2F5496") + heading(2, 30, "2F5496") + heading(3, 26, "1F3864") + heading(4, 24, "2F5496") + heading(5, 22, "2F5496") + heading(6, 22, "1F3864") +
	`<w:style w:type="paragraph" w:styleId="Quote"><w:name w:val="Quote"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:pBdr><w:left w:val="single" w:sz="18" w:space="8" w:color="8EAADB"/></w:pBdr><w:ind w:left="567" w:right="567"/></w:pPr><w:rPr><w:i/><w:iCs/><w:color w:val="404040"/></w:rPr></w:style>` +
	`<w:style w:type="paragraph" w:styleId="Code"><w:name w:val="Code"/><w:basedOn w:val="Normal"/><w:qFormat/><w:pPr><w:shd w:val="clear" w:color="auto" w:fill="F2F2F2"/><w:spacing w:after="0" w:line="240" w:lineRule="auto"/><w:ind w:left="113" w:right="113"/></w:pPr><w:rPr><w:rFonts w:ascii="Consolas" w:hAnsi="Consolas" w:cs="Consolas"/><w:sz w:val="19"/><w:szCs w:val="19"/></w:rPr></w:style>` +
	`<w:style w:type="paragraph" w:styleId="ListParagraph"><w:name w:val="List Paragraph"/><w:basedOn w:val="Normal"/><w:qFormat/><w:pPr><w:spacing w:after="60"/><w:ind w:left="720"/><w:contextualSpacing/></w:pPr></w:style>` +
	`<w:style w:type="paragraph" w:styleId="TableText"><w:name w:val="Table Text"/><w:basedOn w:val="Normal"/><w:pPr><w:spacing w:before="40" w:after="40" w:line="240" w:lineRule="auto"/></w:pPr></w:style>` +
	`<w:style w:type="paragraph" w:styleId="Picture"><w:name w:val="Picture"/><w:basedOn w:val="Normal"/><w:pPr><w:keepNext/><w:spacing w:before="120" w:after="60"/><w:jc w:val="center"/></w:pPr></w:style>` +
	`<w:style w:type="paragraph" w:styleId="Caption"><w:name w:val="caption"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:spacing w:after="200"/><w:jc w:val="center"/></w:pPr><w:rPr><w:i/><w:iCs/><w:color w:val="595959"/><w:sz w:val="18"/><w:szCs w:val="18"/></w:rPr></w:style>` +
	`<w:style w:type="character" w:default="1" w:styleId="DefaultParagraphFont"><w:name w:val="Default Paragraph Font"/><w:uiPriority w:val="1"/><w:semiHidden/></w:style>` +
	`<w:style w:type="character" w:styleId="Hyperlink"><w:name w:val="Hyperlink"/><w:rPr><w:color w:val="0563C1"/><w:u w:val="single"/></w:rPr></w:style>` +
	`<w:style w:type="table" w:default="1" w:styleId="TableNormal"><w:name w:val="Normal Table"/><w:tblPr><w:tblInd w:w="0" w:type="dxa"/><w:tblCellMar><w:top w:w="0" w:type="dxa"/><w:left w:w="108" w:type="dxa"/><w:bottom w:w="0" w:type="dxa"/><w:right w:w="108" w:type="dxa"/></w:tblCellMar></w:tblPr></w:style>` +
	`<w:style w:type="table" w:styleId="TableGrid"><w:name w:val="Table Grid"/><w:basedOn w:val="TableNormal"/><w:pPr><w:spacing w:after="0" w:line="240" w:lineRule="auto"/></w:pPr><w:tblPr><w:tblBorders>` +
	`<w:top w:val="single" w:sz="4" w:space="0" w:color="B4C6E7"/><w:left w:val="single" w:sz="4" w:space="0" w:color="B4C6E7"/><w:bottom w:val="single" w:sz="4" w:space="0" w:color="B4C6E7"/><w:right w:val="single" w:sz="4" w:space="0" w:color="B4C6E7"/><w:insideH w:val="single" w:sz="4" w:space="0" w:color="B4C6E7"/><w:insideV w:val="single" w:sz="4" w:space="0" w:color="B4C6E7"/>` +
	`</w:tblBorders></w:tblPr></w:style>` +
	`</w:styles>`

func heading(level, size int, color string) string {
	before := 240
	if level > 2 {
		before = 160
	}
	return fmt.Sprintf(`<w:style w:type="paragraph" w:styleId="Heading%d"><w:name w:val="heading %d"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:keepNext/><w:keepLines/><w:spacing w:before="%d" w:after="80"/><w:outlineLvl w:val="%d"/></w:pPr><w:rPr><w:rFonts w:ascii="Calibri Light" w:hAnsi="Calibri Light"/><w:b/><w:bCs/><w:color w:val="%s"/><w:sz w:val="%d"/><w:szCs w:val="%d"/></w:rPr></w:style>`,
		level, level, before, level-1, color, size, size)
}
