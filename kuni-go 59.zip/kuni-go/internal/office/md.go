// Package office makes real office files with the standard library alone: a Word document (.docx) from the
// Markdown she writes, an Excel workbook (.xlsx) from rows, and an HTML page. Nothing has to be installed on the
// machine (pandoc and LibreOffice are optional extras of #convert_doc), so she can hand the owner a report, a
// letter or a table in any setup.
package office

import (
	"regexp"
	"strconv"
	"strings"
	"unicode"
	"unicode/utf8"
)

// The Markdown she writes, as blocks. It is the common subset of chat Markdown: headings, paragraphs (a single line
// break stays a line break, as in a chat), bullet / numbered / task lists with nesting, tables, code blocks,
// quotes, rules, images on a line of their own, page breaks (\newpage) and inline bold, italic, strike, code and
// links.

// Span is a piece of text with one style.
type Span struct {
	Text   string
	Bold   bool
	Italic bool
	Strike bool
	Code   bool
	Link   string // the address when the span is a link
	Break  bool   // a line break (Text is empty)
}

// BlockKind tells what a block is.
type BlockKind int

const (
	Para BlockKind = iota
	Heading
	ListBlock
	CodeBlock
	Quote
	TableBlock
	Rule
	Image
	PageBreak
)

// Item is one entry of a list. Level 0 is the outermost.
type Item struct {
	Level   int
	Ordered bool
	Spans   []Span
}

// Block is one block of a document.
type Block struct {
	Kind   BlockKind
	Level  int    // heading level 1-6
	Spans  []Span // paragraph, heading, quote
	Items  []Item // list
	Start  int    // first number of an ordered list
	Text   string // code
	Lang   string // code language
	Header [][]Span
	Rows   [][][]Span
	Align  []byte // table columns: 'l', 'c', 'r'
	Alt    string // image
	Src    string // image path
}

var (
	reHeading = regexp.MustCompile(`^(#{1,6})\s+(.*?)\s*#*\s*$`)
	reItem    = regexp.MustCompile(`^(\s*)([-*+•]|\d{1,9}[.)])\s+(.*)$`)
	reRule    = regexp.MustCompile(`^\s*(?:(?:-\s*){3,}|(?:\*\s*){3,}|(?:_\s*){3,})$`)
	reFence   = regexp.MustCompile("^\\s*(```+|~~~+)\\s*([\\w+#.-]*)\\s*$")
	reImage   = regexp.MustCompile(`^\s*!\[([^\]]*)\]\(\s*<?([^)>\s]+)>?(?:\s+"[^"]*")?\s*\)\s*$`)
	reTblSep  = regexp.MustCompile(`^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$`)
	reTask    = regexp.MustCompile(`^\[([ xXхХ])\]\s+`)
)

// Parse reads Markdown into blocks.
func Parse(src string) []Block {
	src = strings.ReplaceAll(strings.ReplaceAll(src, "\r\n", "\n"), "\r", "\n")
	lines := strings.Split(src, "\n")
	var out []Block
	var para []string
	flush := func() {
		if len(para) > 0 {
			out = append(out, Block{Kind: Para, Spans: inlineLines(para)})
			para = nil
		}
	}
	for i := 0; i < len(lines); i++ {
		l := lines[i]
		t := strings.TrimSpace(l)
		switch {
		case t == "":
			flush()
		case t == `\newpage` || t == `\pagebreak` || strings.EqualFold(t, "<!-- pagebreak -->"):
			flush()
			out = append(out, Block{Kind: PageBreak})
		case reFence.MatchString(l):
			flush()
			m := reFence.FindStringSubmatch(l)
			fence := m[1]
			var code []string
			for i++; i < len(lines); i++ {
				if strings.HasPrefix(strings.TrimSpace(lines[i]), fence[:3]) {
					break
				}
				code = append(code, strings.TrimRight(lines[i], " \t"))
			}
			out = append(out, Block{Kind: CodeBlock, Text: strings.Join(code, "\n"), Lang: m[2]})
		case reHeading.MatchString(t):
			flush()
			m := reHeading.FindStringSubmatch(t)
			out = append(out, Block{Kind: Heading, Level: len(m[1]), Spans: Inline(m[2])})
		case reRule.MatchString(l):
			flush()
			out = append(out, Block{Kind: Rule})
		case reImage.MatchString(l):
			flush()
			m := reImage.FindStringSubmatch(l)
			out = append(out, Block{Kind: Image, Alt: m[1], Src: m[2]})
		case strings.HasPrefix(t, ">"):
			flush()
			var q []string
			for ; i < len(lines) && strings.HasPrefix(strings.TrimSpace(lines[i]), ">"); i++ {
				q = append(q, strings.TrimSpace(strings.TrimPrefix(strings.TrimSpace(lines[i]), ">")))
			}
			i--
			out = append(out, Block{Kind: Quote, Spans: inlineLines(q)})
		case strings.Contains(t, "|") && i+1 < len(lines) && reTblSep.MatchString(lines[i+1]):
			flush()
			b := Block{Kind: TableBlock}
			for _, c := range cells(t) {
				b.Header = append(b.Header, Inline(c))
			}
			for _, c := range cells(lines[i+1]) {
				c = strings.TrimSpace(c)
				switch {
				case strings.HasPrefix(c, ":") && strings.HasSuffix(c, ":"):
					b.Align = append(b.Align, 'c')
				case strings.HasSuffix(c, ":"):
					b.Align = append(b.Align, 'r')
				default:
					b.Align = append(b.Align, 'l')
				}
			}
			for i += 2; i < len(lines) && strings.Contains(lines[i], "|") && strings.TrimSpace(lines[i]) != ""; i++ {
				var row [][]Span
				for _, c := range cells(lines[i]) {
					row = append(row, Inline(c))
				}
				b.Rows = append(b.Rows, row)
			}
			i--
			out = append(out, b)
		case reItem.MatchString(l) && (len(para) == 0 || startsList(l)):
			flush()
			b := Block{Kind: ListBlock, Start: 1}
			base := -1
			for ; i < len(lines); i++ {
				l := lines[i]
				m := reItem.FindStringSubmatch(l)
				if m == nil {
					// a continuation line of the last item (indented text), else the list is over
					if strings.TrimSpace(l) != "" && len(b.Items) > 0 && indent(l) > 0 {
						last := &b.Items[len(b.Items)-1]
						last.Spans = append(last.Spans, Span{Break: true})
						last.Spans = append(last.Spans, Inline(strings.TrimSpace(l))...)
						continue
					}
					break
				}
				ind := indent(m[1])
				if base < 0 {
					base = ind
				}
				lvl := max(0, (ind-base+1)/2)
				if n := len(b.Items); n > 0 && lvl > b.Items[n-1].Level+1 {
					lvl = b.Items[n-1].Level + 1
				}
				lvl = min(lvl, 8)
				ordered := m[2][0] >= '0' && m[2][0] <= '9'
				if lvl == 0 && len(b.Items) > 0 && ordered != b.Items[0].Ordered {
					break // bullets after numbers (or the other way round) start a new list
				}
				if ordered && len(b.Items) == 0 {
					b.Start, _ = strconv.Atoi(strings.TrimRight(m[2], ".)"))
				}
				text := m[3]
				if tm := reTask.FindStringSubmatch(text); tm != nil {
					box := "☐ "
					if tm[1] != " " {
						box = "☑ "
					}
					text = box + text[len(tm[0]):]
				}
				b.Items = append(b.Items, Item{Level: lvl, Ordered: ordered, Spans: Inline(text)})
			}
			i--
			out = append(out, b)
		default:
			para = append(para, strings.TrimRight(l, " \t"))
		}
	}
	flush()
	return out
}

// startsList: inside a paragraph only a real list marker (not "2020. год" in the middle of text) starts a list.
func startsList(l string) bool {
	m := reItem.FindStringSubmatch(l)
	return m != nil && m[1] == "" && (m[2] == "-" || m[2] == "*" || m[2] == "•" || m[2] == "1." || m[2] == "1)")
}

func indent(s string) int {
	n := 0
	for _, r := range s {
		switch r {
		case ' ':
			n++
		case '\t':
			n += 4
		default:
			return n
		}
	}
	return n
}

// cells splits a table line into cells (an escaped \| stays in the cell).
func cells(l string) []string {
	l = strings.TrimSpace(l)
	l = strings.TrimPrefix(l, "|")
	if strings.HasSuffix(l, "|") && !strings.HasSuffix(l, `\|`) {
		l = l[:len(l)-1]
	}
	var out []string
	var cur strings.Builder
	for i := 0; i < len(l); i++ {
		switch {
		case l[i] == '\\' && i+1 < len(l) && l[i+1] == '|':
			cur.WriteByte('|')
			i++
		case l[i] == '|':
			out = append(out, strings.TrimSpace(cur.String()))
			cur.Reset()
		default:
			cur.WriteByte(l[i])
		}
	}
	return append(out, strings.TrimSpace(cur.String()))
}

// inlineLines parses lines of one paragraph; the line breaks stay.
func inlineLines(lines []string) []Span {
	var out []Span
	for i, l := range lines {
		if i > 0 {
			out = append(out, Span{Break: true})
		}
		out = append(out, Inline(strings.TrimSpace(strings.TrimSuffix(l, `\`)))...)
	}
	return out
}

// Inline parses the inline Markdown of one line.
func Inline(s string) []Span { return merge(inline(s, Span{})) }

var reAuto = regexp.MustCompile(`^https?://[^\s<>()\[\]]+[^\s<>()\[\].,;:!?'"»)]`)

func inline(s string, st Span) []Span {
	var out []Span
	var text strings.Builder
	emit := func() {
		if text.Len() > 0 {
			sp := st
			sp.Text = text.String()
			out = append(out, sp)
			text.Reset()
		}
	}
	for i := 0; i < len(s); {
		c := s[i]
		switch {
		case c == '\\' && i+1 < len(s) && strings.IndexByte("\\`*_~[]()#+-.!|>", s[i+1]) >= 0:
			text.WriteByte(s[i+1])
			i += 2
			continue
		case c == '`':
			if j := strings.IndexByte(s[i+1:], '`'); j >= 0 {
				emit()
				sp := st
				sp.Code, sp.Text = true, s[i+1:i+1+j]
				out = append(out, sp)
				i += j + 2
				continue
			}
		case c == '!' && strings.HasPrefix(s[i:], "!["):
			if alt, _, n := link(s[i+1:]); n > 0 { // a picture inside a line: its description stands in
				text.WriteString(alt)
				i += 1 + n
				continue
			}
		case c == '[':
			if label, url, n := link(s[i:]); n > 0 {
				emit()
				sub := st
				sub.Link = url
				out = append(out, inline(label, sub)...)
				i += n
				continue
			}
		case (c == 'h' || c == 'H') && st.Link == "" && (i == 0 || !isWord(s[i-1])):
			if m := reAuto.FindString(s[i:]); m != "" {
				emit()
				sp := st
				sp.Text, sp.Link = m, m
				out = append(out, sp)
				i += len(m)
				continue
			}
		case c == '~' && strings.HasPrefix(s[i:], "~~"):
			if j := strings.Index(s[i+2:], "~~"); j > 0 {
				emit()
				sub := st
				sub.Strike = true
				out = append(out, inline(s[i+2:i+2+j], sub)...)
				i += j + 4
				continue
			}
		case c == '*' || c == '_':
			n := 1
			for i+n < len(s) && s[i+n] == c && n < 3 {
				n++
			}
			delim := strings.Repeat(string(c), n)
			if c == '_' && i > 0 && isWord(s[i-1]) { // snake_case is not emphasis
				break
			}
			if i+n < len(s) && s[i+n] == ' ' { // "* " is not an opening
				break
			}
			if c == '*' && i > 0 && i+n < len(s) && isDigit(s[i-1]) && isDigit(s[i+n]) { // 2*3*4 is arithmetic
				break
			}
			if j := closing(s[i+n:], delim, c); j > 0 {
				emit()
				sub := st
				if n >= 2 {
					sub.Bold = true
				}
				if n == 1 || n == 3 {
					sub.Italic = true
				}
				out = append(out, inline(s[i+n:i+n+j], sub)...)
				i += n + j + n
				continue
			}
		}
		_, size := utf8.DecodeRuneInString(s[i:])
		text.WriteString(s[i : i+size])
		i += size
	}
	emit()
	return out
}

// closing finds the closing delimiter of emphasis in s (index into s, or -1).
func closing(s, delim string, c byte) int {
	for from := 0; from < len(s); {
		j := strings.Index(s[from:], delim)
		if j < 0 {
			return -1
		}
		j += from
		end := j + len(delim)
		okBefore := j > 0 && s[j-1] != ' '
		okAfter := end >= len(s) || s[end] != c
		if c == '_' && end < len(s) && isWord(s[end]) {
			okAfter = false
		}
		if okBefore && okAfter && j > 0 {
			return j
		}
		from = j + 1
	}
	return -1
}

// link reads "[label](url)" at the start of s and returns its length (0 = not a link).
func link(s string) (label, url string, n int) {
	if !strings.HasPrefix(s, "[") {
		return "", "", 0
	}
	depth := 0
	for i := 0; i < len(s); i++ {
		switch s[i] {
		case '[':
			depth++
		case ']':
			depth--
			if depth == 0 {
				if i+1 >= len(s) || s[i+1] != '(' {
					return "", "", 0
				}
				end := strings.IndexByte(s[i+2:], ')')
				if end < 0 {
					return "", "", 0
				}
				u := strings.TrimSpace(s[i+2 : i+2+end])
				if sp := strings.IndexAny(u, " \t"); sp > 0 { // [x](url "title")
					u = u[:sp]
				}
				return s[1:i], strings.Trim(u, "<>"), i + 3 + end
			}
		}
	}
	return "", "", 0
}

func isDigit(b byte) bool { return b >= '0' && b <= '9' }

func isWord(b byte) bool {
	return b >= 0x80 || b == '_' || unicode.IsLetter(rune(b)) || unicode.IsDigit(rune(b))
}

// merge joins neighbour spans of the same style.
func merge(in []Span) []Span {
	var out []Span
	for _, s := range in {
		if s.Text == "" && !s.Break {
			continue
		}
		if n := len(out); n > 0 && !s.Break && !out[n-1].Break {
			p := out[n-1]
			if p.Bold == s.Bold && p.Italic == s.Italic && p.Strike == s.Strike && p.Code == s.Code && p.Link == s.Link {
				out[n-1].Text += s.Text
				continue
			}
		}
		out = append(out, s)
	}
	return out
}

// Plain is the text of spans without styles.
func Plain(sp []Span) string {
	var b strings.Builder
	for _, s := range sp {
		if s.Break {
			b.WriteByte('\n')
		}
		b.WriteString(s.Text)
	}
	return b.String()
}
