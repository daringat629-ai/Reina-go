package office

import (
	"errors"
	"math"
	"regexp"
	"strconv"
	"strings"
)

// A small formula evaluator. The file keeps a formula together with its last value; Excel and Google Sheets
// recalculate on opening anyway, but LibreOffice by default shows the stored value, and previews show nothing else.
// So the common formulas are computed here: + - * / ^ %, comparisons, cell references and ranges, SUM AVERAGE MIN
// MAX COUNT COUNTA PRODUCT ROUND ABS SQRT IF. A formula outside that (other sheets, text functions) is written without
// a value and is computed by the program that opens the file.

var errFormula = errors.New("formula not supported here")

type eval struct {
	cells map[string]Cell
	memo  map[string]float64
	busy  map[string]bool
}

func newEval(sh Sheet) *eval {
	e := &eval{cells: map[string]Cell{}, memo: map[string]float64{}, busy: map[string]bool{}}
	for r, row := range sh.Rows {
		for c, cell := range row {
			if cell.Kind != Empty {
				e.cells[Col(c)+strconv.Itoa(r+1)] = cell
			}
		}
	}
	return e
}

// value is the number of a cell (a formula is computed). ok is false for text and for formulas it cannot compute.
func (e *eval) value(ref string) (float64, bool) {
	ref = strings.ToUpper(strings.ReplaceAll(ref, "$", ""))
	if v, ok := e.memo[ref]; ok {
		return v, true
	}
	c, ok := e.cells[ref]
	if !ok {
		return 0, true // an empty cell counts as 0
	}
	switch c.Kind {
	case Number, Date, DateTime, Percent, Bool:
		return c.Num, true
	case Formula:
		if e.busy[ref] { // a circular reference
			return 0, false
		}
		e.busy[ref] = true
		defer delete(e.busy, ref)
		p := &parser{src: c.Str, e: e}
		v, err := p.expr()
		p.skip()
		if err != nil || p.pos != len(p.src) || math.IsNaN(v) || math.IsInf(v, 0) {
			return 0, false
		}
		e.memo[ref] = v
		return v, true
	}
	return 0, false
}

type parser struct {
	src string
	pos int
	e   *eval
}

func (p *parser) skip() {
	for p.pos < len(p.src) && p.src[p.pos] == ' ' {
		p.pos++
	}
}

func (p *parser) peek(s string) bool {
	p.skip()
	return strings.HasPrefix(p.src[p.pos:], s)
}

func (p *parser) eat(s string) bool {
	if p.peek(s) {
		p.pos += len(s)
		return true
	}
	return false
}

func (p *parser) expr() (float64, error) {
	a, err := p.additive()
	if err != nil {
		return 0, err
	}
	for _, op := range []string{"<=", ">=", "<>", "=", "<", ">"} {
		if p.eat(op) {
			b, err := p.additive()
			if err != nil {
				return 0, err
			}
			r := map[string]bool{"<=": a <= b, ">=": a >= b, "<>": a != b, "=": a == b, "<": a < b, ">": a > b}[op]
			if r {
				return 1, nil
			}
			return 0, nil
		}
	}
	return a, nil
}

func (p *parser) additive() (float64, error) {
	a, err := p.term()
	for err == nil {
		switch {
		case p.eat("+"):
			var b float64
			b, err = p.term()
			a += b
		case p.eat("-"):
			var b float64
			b, err = p.term()
			a -= b
		default:
			return a, nil
		}
	}
	return 0, err
}

func (p *parser) term() (float64, error) {
	a, err := p.power()
	for err == nil {
		switch {
		case p.eat("*"):
			var b float64
			b, err = p.power()
			a *= b
		case p.eat("/"):
			var b float64
			b, err = p.power()
			if b == 0 {
				return 0, errFormula // #DIV/0! is for the spreadsheet to show
			}
			a /= b
		default:
			return a, nil
		}
	}
	return 0, err
}

func (p *parser) power() (float64, error) {
	a, err := p.unary()
	for err == nil && p.eat("^") {
		var b float64
		b, err = p.unary()
		a = math.Pow(a, b)
	}
	return a, err
}

func (p *parser) unary() (float64, error) {
	if p.eat("-") {
		v, err := p.unary()
		return -v, err
	}
	if p.eat("+") {
		return p.unary()
	}
	v, err := p.primary()
	if err == nil && p.eat("%") {
		v /= 100
	}
	return v, err
}

var (
	reRef  = regexp.MustCompile(`^\$?([A-Za-z]{1,3})\$?(\d{1,7})`)
	reFn   = regexp.MustCompile(`^([A-Za-z][A-Za-z0-9.]*)\s*\(`)
	reNumF = regexp.MustCompile(`^\d+(\.\d+)?([eE][-+]?\d+)?`)
)

func (p *parser) primary() (float64, error) {
	p.skip()
	rest := p.src[p.pos:]
	switch {
	case p.eat("("):
		v, err := p.expr()
		if err != nil || !p.eat(")") {
			return 0, errFormula
		}
		return v, nil
	case reFn.MatchString(rest):
		m := reFn.FindStringSubmatch(rest)
		p.pos += len(m[0])
		return p.call(strings.ToUpper(m[1]))
	case reNumF.MatchString(rest):
		m := reNumF.FindString(rest)
		p.pos += len(m)
		return strconv.ParseFloat(m, 64)
	case reRef.MatchString(rest):
		ref := p.ref()
		if p.peek(":") { // a range outside a function
			return 0, errFormula
		}
		v, ok := p.e.value(ref)
		if !ok {
			return 0, errFormula
		}
		return v, nil
	case strings.HasPrefix(strings.ToUpper(rest), "TRUE"):
		p.pos += 4
		return 1, nil
	case strings.HasPrefix(strings.ToUpper(rest), "FALSE"):
		p.pos += 5
		return 0, nil
	}
	return 0, errFormula
}

func (p *parser) ref() string {
	m := reRef.FindStringSubmatch(p.src[p.pos:])
	p.pos += len(m[0])
	return strings.ToUpper(m[1]) + m[2]
}

// arg is one function argument: a range (its cells) or one value.
type arg struct {
	vals   []float64 // numbers of the range or the value
	filled int       // non-empty cells of a range (COUNTA)
	isRng  bool
}

func (p *parser) args() ([]arg, error) {
	var out []arg
	if p.eat(")") {
		return out, nil
	}
	for {
		p.skip()
		if m := reRef.FindString(p.src[p.pos:]); m != "" {
			save := p.pos
			from := p.ref()
			if p.eat(":") {
				if reRef.FindString(p.src[p.pos:]) == "" {
					return nil, errFormula
				}
				to := p.ref()
				a, err := p.rng(from, to)
				if err != nil {
					return nil, err
				}
				out = append(out, a)
				goto next
			}
			p.pos = save
		}
		{
			v, err := p.expr()
			if err != nil {
				return nil, err
			}
			out = append(out, arg{vals: []float64{v}, filled: 1})
		}
	next:
		if p.eat(",") {
			continue
		}
		if p.eat(")") {
			return out, nil
		}
		return nil, errFormula
	}
}

func split(ref string) (col int, row int) {
	m := reRef.FindStringSubmatch(ref)
	for _, ch := range strings.ToUpper(m[1]) {
		col = col*26 + int(ch-'A'+1)
	}
	row, _ = strconv.Atoi(m[2])
	return col - 1, row
}

func (p *parser) rng(from, to string) (arg, error) {
	c1, r1 := split(from)
	c2, r2 := split(to)
	if c1 > c2 {
		c1, c2 = c2, c1
	}
	if r1 > r2 {
		r1, r2 = r2, r1
	}
	if (c2-c1+1)*(r2-r1+1) > 200000 {
		return arg{}, errFormula
	}
	a := arg{isRng: true}
	for r := r1; r <= r2; r++ {
		for c := c1; c <= c2; c++ {
			ref := Col(c) + strconv.Itoa(r)
			cell, ok := p.e.cells[ref]
			if !ok {
				continue
			}
			a.filled++
			switch cell.Kind {
			case Number, Date, DateTime, Percent:
				a.vals = append(a.vals, cell.Num)
			case Formula:
				v, ok := p.e.value(ref)
				if !ok {
					return arg{}, errFormula
				}
				a.vals = append(a.vals, v)
			}
		}
	}
	return a, nil
}

func (p *parser) call(fn string) (float64, error) {
	args, err := p.args()
	if err != nil {
		return 0, err
	}
	var all []float64
	filled := 0
	for _, a := range args {
		all = append(all, a.vals...)
		filled += a.filled
	}
	one := func() (float64, error) {
		if len(args) != 1 || args[0].isRng {
			return 0, errFormula
		}
		return args[0].vals[0], nil
	}
	switch fn {
	case "SUM":
		s := 0.0
		for _, v := range all {
			s += v
		}
		return s, nil
	case "PRODUCT":
		s := 1.0
		for _, v := range all {
			s *= v
		}
		return s, nil
	case "AVERAGE":
		if len(all) == 0 {
			return 0, errFormula
		}
		s := 0.0
		for _, v := range all {
			s += v
		}
		return s / float64(len(all)), nil
	case "MIN", "MAX":
		if len(all) == 0 {
			return 0, nil
		}
		m := all[0]
		for _, v := range all[1:] {
			if (fn == "MIN" && v < m) || (fn == "MAX" && v > m) {
				m = v
			}
		}
		return m, nil
	case "COUNT":
		return float64(len(all)), nil
	case "COUNTA":
		return float64(filled), nil
	case "ABS":
		v, err := one()
		return math.Abs(v), err
	case "SQRT":
		v, err := one()
		if v < 0 {
			return 0, errFormula
		}
		return math.Sqrt(v), err
	case "ROUND":
		if len(args) == 0 || len(args) > 2 || args[0].isRng {
			return 0, errFormula
		}
		d := 0.0
		if len(args) == 2 {
			if args[1].isRng || len(args[1].vals) != 1 {
				return 0, errFormula
			}
			d = args[1].vals[0]
		}
		k := math.Pow(10, d)
		v := args[0].vals[0] * k
		return math.Copysign(math.Floor(math.Abs(v)+0.5), v) / k, nil // Excel rounds halves away from zero
	case "IF":
		if len(args) < 2 || len(args) > 3 || args[0].isRng || args[1].isRng {
			return 0, errFormula
		}
		if args[0].vals[0] != 0 {
			return args[1].vals[0], nil
		}
		if len(args) == 3 && !args[2].isRng {
			return args[2].vals[0], nil
		}
		return 0, nil
	}
	return 0, errFormula
}
