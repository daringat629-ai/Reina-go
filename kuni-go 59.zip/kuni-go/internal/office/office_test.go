package office

import (
	"archive/zip"
	"bytes"
	"encoding/xml"
	"image"
	"image/color"
	"image/png"
	"io"
	"math"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

const sample = `# Отчёт за октябрь

Привет! Это **жирный**, *курсив*, ~~зачёркнутый~~, ` + "`код`" + ` и [ссылка](https://example.com/a?b=1&c=2).
Вторая строка того же абзаца.

## Список дел

- купить молоко
- [x] позвонить маме
  - вложенный пункт
1. первый
2. второй

| Статья | Сумма |
|:-------|------:|
| Еда    | 1 200 |
| Такси  | 350   |

> Цитата: «всё будет хорошо»

` + "```go\nfunc main() {\n\tprintln(\"hi\")\n}\n```" + `

---

![График расходов](chart.png)

\newpage

snake_case_name stays and 2*3*4 too, http://example.org/x.
`

func unzip(t *testing.T, data []byte) map[string]string {
	t.Helper()
	z, err := zip.NewReader(bytes.NewReader(data), int64(len(data)))
	if err != nil {
		t.Fatal(err)
	}
	out := map[string]string{}
	for _, f := range z.File {
		rc, _ := f.Open()
		b, _ := io.ReadAll(rc)
		rc.Close()
		out[f.Name] = string(b)
		if strings.HasSuffix(f.Name, ".xml") || strings.HasSuffix(f.Name, ".rels") {
			d := xml.NewDecoder(bytes.NewReader(b))
			for {
				if _, err := d.Token(); err == io.EOF {
					break
				} else if err != nil {
					t.Fatalf("%s is not well-formed XML: %v", f.Name, err)
				}
			}
		}
	}
	return out
}

func TestParseMarkdown(t *testing.T) {
	bs := Parse(sample)
	kinds := []BlockKind{}
	for _, b := range bs {
		kinds = append(kinds, b.Kind)
	}
	want := []BlockKind{Heading, Para, Heading, ListBlock, ListBlock, TableBlock, Quote, CodeBlock, Rule, Image, PageBreak, Para}
	if len(kinds) != len(want) {
		t.Fatalf("blocks %v, want %v", kinds, want)
	}
	for i := range want {
		if kinds[i] != want[i] {
			t.Fatalf("block %d: %v, want %v (all %v)", i, kinds[i], want[i], kinds)
		}
	}
	p := bs[1].Spans
	var bold, italic, strike, code, link, brk bool
	for _, s := range p {
		bold = bold || (s.Bold && s.Text == "жирный")
		italic = italic || (s.Italic && s.Text == "курсив")
		strike = strike || s.Strike
		code = code || (s.Code && s.Text == "код")
		link = link || (s.Link == "https://example.com/a?b=1&c=2" && s.Text == "ссылка")
		brk = brk || s.Break
	}
	if !bold || !italic || !strike || !code || !link || !brk {
		t.Fatalf("inline styles lost: %+v", p)
	}
	l := bs[3]
	if len(l.Items) != 3 || l.Items[1].Level != 0 || l.Items[2].Level != 1 || !strings.HasPrefix(Plain(l.Items[1].Spans), "☑") {
		t.Fatalf("list: %+v", l.Items)
	}
	if !bs[4].Items[0].Ordered || bs[4].Start != 1 {
		t.Fatalf("numbered list: %+v", bs[4])
	}
	tb := bs[5]
	if len(tb.Header) != 2 || len(tb.Rows) != 2 || tb.Align[1] != 'r' || Plain(tb.Rows[0][1]) != "1 200" {
		t.Fatalf("table: %+v", tb)
	}
	if bs[7].Lang != "go" || !strings.Contains(bs[7].Text, "\tprintln") {
		t.Fatalf("code: %+v", bs[7])
	}
	last := Plain(bs[11].Spans)
	if !strings.Contains(last, "snake_case_name") || !strings.Contains(last, "2*3*4") {
		t.Fatalf("plain text was taken for emphasis: %q", last)
	}
	auto := false
	for _, s := range bs[11].Spans {
		auto = auto || s.Link == "http://example.org/x"
	}
	if !auto {
		t.Fatalf("bare address not linked (or the dot kept): %+v", bs[11].Spans)
	}
}

func testPNG(t *testing.T, dir string, w, h int) string {
	img := image.NewRGBA(image.Rect(0, 0, w, h))
	for x := 0; x < w; x++ {
		img.Set(x, h/2, color.RGBA{200, 0, 0, 255})
	}
	p := filepath.Join(dir, "chart.png")
	f, _ := os.Create(p)
	png.Encode(f, img)
	f.Close()
	return p
}

func TestDOCXIsAValidDocument(t *testing.T) {
	dir := t.TempDir()
	testPNG(t, dir, 1600, 400)
	data, missing, err := DOCX(Doc{Title: "Отчёт", Text: sample + "\n![нет](nope.png)\n", Images: ImagesIn(dir), Now: time.Date(2026, 10, 23, 0, 0, 0, 0, time.UTC)})
	if err != nil {
		t.Fatal(err)
	}
	if len(missing) != 1 || missing[0] != "nope.png" {
		t.Fatalf("missing images: %v", missing)
	}
	files := unzip(t, data)
	for _, name := range []string{"[Content_Types].xml", "_rels/.rels", "word/document.xml", "word/styles.xml", "word/numbering.xml", "word/_rels/document.xml.rels", "docProps/core.xml", "word/media/image1.png"} {
		if _, ok := files[name]; !ok {
			t.Fatalf("no %s in the package", name)
		}
	}
	doc := files["word/document.xml"]
	for _, want := range []string{`<w:pStyle w:val="Heading1"/>`, `<w:pStyle w:val="Heading2"/>`, "<w:b/>", "<w:i/>", "<w:strike/>",
		`w:val="Hyperlink"`, `<w:numId w:val="1"/>`, `<w:numId w:val="2"/>`, `<w:ilvl w:val="1"/>`, "<w:tbl>", `<w:jc w:val="right"/>`,
		`<w:pStyle w:val="Quote"/>`, `<w:pStyle w:val="Code"/>`, "<w:tab/>", `<w:br w:type="page"/>`, `r:embed="rIdI1"`, "Отчёт за октябрь", "[нет]"} {
		if !strings.Contains(doc, want) {
			t.Errorf("document.xml lacks %s", want)
		}
	}
	if strings.Contains(doc, `<w:pStyle w:val="Title"/>`) {
		t.Error("the title repeats the first heading")
	}
	// the wide picture fits the text width
	if !strings.Contains(doc, `cx="6120130"`) {
		t.Errorf("picture not scaled to the page: %s", doc[strings.Index(doc, "<wp:extent"):][:60])
	}
	rels := files["word/_rels/document.xml.rels"]
	if !strings.Contains(rels, `Target="https://example.com/a?b=1&amp;c=2" TargetMode="External"`) || !strings.Contains(rels, "media/image1.png") {
		t.Fatalf("relationships: %s", rels)
	}
	if !strings.Contains(files["docProps/core.xml"], "<dc:title>Отчёт</dc:title>") {
		t.Fatal(files["docProps/core.xml"])
	}
}

func TestDOCXDropsCharactersXMLCannotHold(t *testing.T) {
	data, _, err := DOCX(Doc{Text: "bad \x00\x07 chars & <tags>"})
	if err != nil {
		t.Fatal(err)
	}
	doc := unzip(t, data)["word/document.xml"]
	if !strings.Contains(doc, "bad  chars &amp; &lt;tags&gt;") {
		t.Fatal(doc)
	}
}

func TestValueDetection(t *testing.T) {
	cases := map[string]Cell{
		"42":               {Kind: Number, Num: 42},
		"-3,5":             {Kind: Number, Num: -3.5},
		"1 234,56":         {Kind: Number, Num: 1234.56},
		"1e3":              {Kind: Number, Num: 1000},
		"15%":              {Kind: Percent, Num: 0.15},
		"007":              {Kind: Text, Str: "007"},
		"+996555123456":    {Kind: Text, Str: "+996555123456"},
		"4111111111111111": {Kind: Text, Str: "4111111111111111"},
		"true":             {Kind: Bool, Num: 1},
		"=СУММ(A1;A2)":     {Kind: Formula, Str: "SUM(A1,A2)"},
		"привет":           {Kind: Text, Str: "привет"},
		"2026-10-23":       {Kind: Date, Num: 46318},
		"23.10.2026":       {Kind: Date, Num: 46318},
		"2026-02-30":       {Kind: Text, Str: "2026-02-30"},
	}
	for in, want := range cases {
		got := Value(in)
		if got.Kind != want.Kind || math.Abs(got.Num-want.Num) > 1e-9 || (want.Str != "" && got.Str != want.Str) {
			t.Errorf("%q: %+v, want %+v", in, got, want)
		}
	}
	if c := Value("2026-10-23 18:30"); c.Kind != DateTime || math.Abs(c.Num-(46318+18.5/24)) > 1e-9 {
		t.Errorf("datetime: %+v", c)
	}
	if got := Value("23.10.2026").String(); got != "23.10.2026" {
		t.Error(got)
	}
}

func TestFormulas(t *testing.T) {
	sh := Sheet{Rows: [][]Cell{
		{Value("10"), Value("20"), Value("=A1+B1*2")},
		{Value("5"), Value("текст"), Value("=SUM(A1:B2)")},
		{Value("=AVERAGE(A1:A2)"), Value("=ROUND(10/3, 2)"), Value("=IF(A1>B1, 1, 0)")},
		{Value("=A4*2"), Value("=A1/0"), Value("=MAX(A1:B3)-MIN(A1:A3)")},
		{Value("=COUNT(A1:B2)"), Value("=COUNTA(A1:B2)"), Value("=50%*A1")},
		{Value("=-2^2"), Value("=SUM(A1:A2;10)"), Value("=LOWER(B2)")},
	}}
	e := newEval(sh)
	want := map[string]float64{"C1": 50, "C2": 35, "A3": 7.5, "B3": 3.33, "C3": 0, "C4": 15, "A5": 3, "B5": 4, "C5": 5, "A6": 4, "B6": 25}
	for ref, w := range want {
		v, ok := e.value(ref)
		if !ok || math.Abs(v-w) > 1e-9 {
			t.Errorf("%s = %v (%v), want %v", ref, v, ok, w)
		}
	}
	for _, ref := range []string{"A4", "B4", "C6"} { // a circle, a division by zero, a function it does not know
		if _, ok := e.value(ref); ok {
			t.Errorf("%s should have no value", ref)
		}
	}
}

func TestXLSXWorkbook(t *testing.T) {
	sheets, err := ParseTable(`{"Расходы": [{"Дата": "2026-10-01", "Статья": "Еда", "Сумма": 1200.5}, {"Дата": "2026-10-02", "Статья": "Такси", "Сумма": 350}, {"Статья": "Итого", "Сумма": "=SUM(C2:C3)"}], "Заметки": [["что", "когда"], ["позвонить", "завтра"]]}`)
	if err != nil {
		t.Fatal(err)
	}
	if len(sheets) != 2 || sheets[0].Name != "Расходы" || len(sheets[0].Rows) != 4 || sheets[0].Rows[0][2].Str != "Сумма" {
		t.Fatalf("sheets: %+v", sheets)
	}
	data, err := XLSX(sheets, "Бюджет", "", time.Time{})
	if err != nil {
		t.Fatal(err)
	}
	files := unzip(t, data)
	s1 := files["xl/worksheets/sheet1.xml"]
	for _, want := range []string{`<c r="C4"><f>SUM(C2:C3)</f><v>1550.5</v></c>`, `<c r="A2" s="2"><v>46296</v></c>`, `<pane ySplit="1"`, `<autoFilter ref="A1:C4"/>`,
		`<c r="A1" s="1" t="inlineStr"><is><t xml:space="preserve">Дата</t></is></c>`, `<c r="C2"><v>1200.5</v></c>`} {
		if !strings.Contains(s1, want) {
			t.Errorf("sheet1 lacks %s\n%s", want, s1)
		}
	}
	wb := files["xl/workbook.xml"]
	if !strings.Contains(wb, `<sheet name="Заметки" sheetId="2" r:id="rId2"/>`) || !strings.Contains(wb, `'Расходы'!$A$1:$C$4`) {
		t.Fatal(wb)
	}
}

func TestParseTableFormats(t *testing.T) {
	for name, in := range map[string]string{
		"csv":      "a,b\n1,2\n3,4",
		"semi":     "a;b\n1,5;2\n3;4",
		"tsv":      "a\tb\n1\t2\n3\t4",
		"markdown": "| a | b |\n|---|---|\n| 1 | 2 |\n| 3 | 4 |",
		"json":     `[["a","b"],[1,2],[3,4]]`,
	} {
		sh, err := ParseTable(in)
		if err != nil || len(sh) != 1 || len(sh[0].Rows) != 3 || len(sh[0].Rows[1]) != 2 || sh[0].Rows[2][1].Num != 4 {
			t.Errorf("%s: %+v %v", name, sh, err)
		}
	}
	if sh, _ := ParseTable("a;b\n1,5;2"); sh[0].Rows[1][0].Num != 1.5 {
		t.Error("a decimal comma under a ; separator")
	}
	if _, err := ParseTable(`{"x": 5}`); err == nil {
		t.Error("an object without rows must be refused")
	}
}

func TestSheetNames(t *testing.T) {
	used := map[string]bool{}
	if n := sheetName("a/b:c", 0, used); n != "a b c" {
		t.Error(n)
	}
	if n := sheetName("A B C", 1, used); n != "A B C (2)" {
		t.Error(n)
	}
	if n := sheetName(strings.Repeat("я", 40), 2, used); len([]rune(n)) != 31 {
		t.Error(n)
	}
	if Col(0) != "A" || Col(25) != "Z" || Col(26) != "AA" || Col(701) != "ZZ" || Col(702) != "AAA" {
		t.Error(Col(26), Col(701), Col(702))
	}
}

func TestCSVHasTheMarkExcelNeeds(t *testing.T) {
	out := string(CSV([][]Cell{{Value("имя"), Value("15%")}, {Value("Аня"), Value("2026-10-23")}}))
	if !strings.HasPrefix(out, "\ufeff") || !strings.Contains(out, "Аня,23.10.2026") || !strings.Contains(out, "имя,15%") {
		t.Fatalf("%q", out)
	}
}

func TestHTMLPage(t *testing.T) {
	dir := t.TempDir()
	testPNG(t, dir, 10, 10)
	out := HTML(Doc{Title: "Отчёт", Text: sample + "\n[bad](javascript:alert(1))", Images: ImagesIn(dir)})
	for _, want := range []string{"<h1>Отчёт за октябрь</h1>", "<strong>жирный</strong>", "<table>", `style="text-align:right"`, "<ul><li>купить молоко", "<ul><li>вложенный пункт", "<ol>", "data:image/png;base64,", "<blockquote>", `<a href="#">bad</a>`} {
		if !strings.Contains(out, want) {
			t.Errorf("html lacks %s", want)
		}
	}
}
