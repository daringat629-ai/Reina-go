package office

import (
	"encoding/base64"
	"fmt"
	"html"
	"net/http"
	"os"
	"strings"
)

// HTML renders the document as one self-contained page (pictures are embedded), good to open in a browser or to
// print to PDF.
func HTML(d Doc) string {
	var b strings.Builder
	title := strings.TrimSpace(d.Title)
	blocks := Parse(d.Text)
	if title == "" {
		for _, bl := range blocks {
			if bl.Kind == Heading {
				title = Plain(bl.Spans)
				break
			}
		}
	}
	b.WriteString("<!doctype html>\n<html lang=\"ru\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">")
	b.WriteString("<title>" + html.EscapeString(title) + "</title><style>" + pageCSS + "</style></head><body><main>\n")
	if t := strings.TrimSpace(d.Title); t != "" && (len(blocks) == 0 || blocks[0].Kind != Heading || blocks[0].Level != 1) {
		b.WriteString("<h1 class=\"title\">" + spansHTML(Inline(t)) + "</h1>\n")
	}
	for _, bl := range blocks {
		switch bl.Kind {
		case Para:
			b.WriteString("<p>" + spansHTML(bl.Spans) + "</p>\n")
		case Heading:
			fmt.Fprintf(&b, "<h%d>%s</h%d>\n", bl.Level, spansHTML(bl.Spans), bl.Level)
		case Quote:
			b.WriteString("<blockquote>" + spansHTML(bl.Spans) + "</blockquote>\n")
		case CodeBlock:
			b.WriteString("<pre><code>" + html.EscapeString(bl.Text) + "</code></pre>\n")
		case Rule:
			b.WriteString("<hr>\n")
		case PageBreak:
			b.WriteString("<div class=\"pagebreak\"></div>\n")
		case ListBlock:
			listHTML(&b, bl)
		case TableBlock:
			b.WriteString("<table><thead><tr>")
			for i, c := range bl.Header {
				b.WriteString("<th" + align(bl.Align, i) + ">" + spansHTML(c) + "</th>")
			}
			b.WriteString("</tr></thead><tbody>\n")
			for _, r := range bl.Rows {
				b.WriteString("<tr>")
				for i := range bl.Header {
					var c []Span
					if i < len(r) {
						c = r[i]
					}
					b.WriteString("<td" + align(bl.Align, i) + ">" + spansHTML(c) + "</td>")
				}
				b.WriteString("</tr>\n")
			}
			b.WriteString("</tbody></table>\n")
		case Image:
			src := bl.Src
			if d.Images != nil {
				src = d.Images(bl.Src)
			}
			if data, err := os.ReadFile(src); err == nil {
				src = "data:" + http.DetectContentType(data) + ";base64," + base64.StdEncoding.EncodeToString(data)
			}
			b.WriteString("<figure><img src=\"" + html.EscapeString(src) + "\" alt=\"" + html.EscapeString(bl.Alt) + "\">")
			if bl.Alt != "" {
				b.WriteString("<figcaption>" + html.EscapeString(bl.Alt) + "</figcaption>")
			}
			b.WriteString("</figure>\n")
		}
	}
	b.WriteString("</main></body></html>\n")
	return b.String()
}

func align(a []byte, i int) string {
	if i < len(a) {
		switch a[i] {
		case 'c':
			return ` style="text-align:center"`
		case 'r':
			return ` style="text-align:right"`
		}
	}
	return ""
}

func listHTML(b *strings.Builder, bl Block) {
	type open struct{ tag string }
	var stack []open
	push := func(ordered bool, start int) {
		tag := "ul"
		if ordered {
			tag = "ol"
		}
		if ordered && start != 1 && len(stack) == 0 {
			fmt.Fprintf(b, "<ol start=\"%d\">", start)
		} else {
			b.WriteString("<" + tag + ">")
		}
		stack = append(stack, open{tag})
	}
	for i, it := range bl.Items {
		switch {
		case len(stack) == 0:
			push(it.Ordered, bl.Start)
		case it.Level+1 > len(stack):
			for it.Level+1 > len(stack) {
				push(it.Ordered, 1)
			}
		case it.Level+1 < len(stack):
			for it.Level+1 < len(stack) {
				b.WriteString("</li></" + stack[len(stack)-1].tag + ">")
				stack = stack[:len(stack)-1]
			}
			b.WriteString("</li>")
		default:
			if i > 0 {
				b.WriteString("</li>")
			}
		}
		b.WriteString("<li>" + spansHTML(it.Spans))
	}
	for len(stack) > 0 {
		b.WriteString("</li></" + stack[len(stack)-1].tag + ">")
		stack = stack[:len(stack)-1]
	}
	b.WriteString("\n")
}

func spansHTML(sp []Span) string {
	var b strings.Builder
	for _, s := range sp {
		if s.Break {
			b.WriteString("<br>")
			continue
		}
		t := html.EscapeString(s.Text)
		if s.Code {
			t = "<code>" + t + "</code>"
		}
		if s.Bold {
			t = "<strong>" + t + "</strong>"
		}
		if s.Italic {
			t = "<em>" + t + "</em>"
		}
		if s.Strike {
			t = "<s>" + t + "</s>"
		}
		if s.Link != "" {
			if u := strings.ToLower(strings.TrimSpace(s.Link)); strings.HasPrefix(u, "javascript:") || strings.HasPrefix(u, "data:") {
				s.Link = "#"
			}
			t = "<a href=\"" + html.EscapeString(s.Link) + "\">" + t + "</a>"
		}
		b.WriteString(t)
	}
	return b.String()
}

const pageCSS = `:root{color-scheme:light}body{margin:0;background:#fff;color:#1d1d1f;font:16px/1.6 "Segoe UI",Roboto,"Noto Sans",Arial,sans-serif}
main{max-width:800px;margin:0 auto;padding:40px 28px}h1,h2,h3,h4,h5,h6{color:#1f3864;line-height:1.25;margin:1.4em 0 .5em}
h1.title{font-size:2.2em;margin-top:0}h1{font-size:1.8em}h2{font-size:1.45em;border-bottom:1px solid #dce6f2;padding-bottom:.2em}h3{font-size:1.2em}
p{margin:.6em 0}a{color:#0563c1}code{font-family:Consolas,"DejaVu Sans Mono",monospace;background:#f2f2f2;padding:.1em .3em;border-radius:3px;font-size:.92em}
pre{background:#f2f2f2;padding:12px 14px;border-radius:6px;overflow:auto}pre code{background:none;padding:0}
blockquote{margin:1em 0;padding:.2em 1em;border-left:4px solid #8eaadb;color:#404040;font-style:italic}
table{border-collapse:collapse;width:100%;margin:1em 0}th,td{border:1px solid #b4c6e7;padding:6px 9px;vertical-align:top}
th{background:#dce6f2;text-align:left}tbody tr:nth-child(even){background:#f7f9fc}hr{border:0;border-top:1px solid #bbb;margin:1.6em 0}
figure{margin:1.2em 0;text-align:center}img{max-width:100%}figcaption{color:#595959;font-style:italic;font-size:.9em}
.pagebreak{break-after:page}@media print{main{padding:0;max-width:none}@page{size:A4;margin:2cm}}`
