package tools

import (
	"context"
	"strings"
	"testing"

	"kuni/internal/metrics"
	"kuni/internal/telegram"
)

func pollRig(t *testing.T) (Deps, *telegram.Fake, telegram.Chat) {
	d, f := peopleDeps(t, 5)
	d.Metrics = metrics.New()
	return d, f, telegram.Chat{ID: -10, Kind: telegram.ChatGroup, IsMember: true}
}

func TestCreatePollValidatesAndDefaultsToAnonymous(t *testing.T) {
	d, f, chat := pollRig(t)
	tool := createPollTool(d, chat)
	ctx := context.Background()
	out, err := tool.Run(ctx, Args{"question": "Where to eat?", "options": "Pizza | Sushi\n Burgers |"})
	if err != nil || !strings.Contains(out, "Poll posted") {
		t.Fatalf("%q %v", out, err)
	}
	p := f.Sent[0].Poll
	if p == nil || len(p.Options) != 3 || p.Options[1].Text != "Sushi" || !p.Anonymous || p.Multiple {
		t.Fatalf("poll: %+v", p)
	}
	if _, err = tool.Run(ctx, Args{"question": "q", "options": "only one"}); err == nil {
		t.Fatal("one option")
	}
	if _, err = tool.Run(ctx, Args{"question": "", "options": "a|b"}); err == nil {
		t.Fatal("empty question")
	}
	if _, err = tool.Run(ctx, Args{"question": "q", "options": "1|2|3|4|5|6|7|8|9|10|11"}); err == nil {
		t.Fatal("too many options")
	}
	if _, err = tool.Run(ctx, Args{"question": "q", "options": "a|b", "anonymous": false, "multiple_answers": true}); err != nil {
		t.Fatal(err)
	}
	if p := f.Sent[1].Poll; p.Anonymous || !p.Multiple {
		t.Fatalf("flags: %+v", p)
	}
}

func TestVotePollRules(t *testing.T) {
	d, f, chat := pollRig(t)
	ctx := context.Background()
	single, _ := f.SendPoll(ctx, chat.ID, "Q?", []string{"a", "b", "c"}, true, false, 0)
	multi, _ := f.SendPoll(ctx, chat.ID, "Q2?", []string{"a", "b", "c"}, true, true, 0)
	tool := votePollTool(d, chat)
	if out, err := tool.Run(ctx, Args{"message_id": float64(single.ID), "options": "2"}); err != nil || out != "Voted" {
		t.Fatalf("%q %v", out, err)
	}
	if m, _ := f.Message(ctx, chat.ID, single.ID); !m.Poll.Options[1].Chosen || m.Poll.Options[1].Votes != 1 || m.Poll.Total != 1 {
		t.Fatalf("vote not recorded: %+v", m.Poll)
	}
	if _, err := tool.Run(ctx, Args{"message_id": float64(single.ID), "options": "1,2"}); err == nil {
		t.Fatal("single-answer poll must refuse two options")
	}
	if _, err := tool.Run(ctx, Args{"message_id": float64(single.ID), "options": "7"}); err == nil || !strings.Contains(err.Error(), "1-3") {
		t.Fatalf("out of range: %v", err)
	}
	if _, err := tool.Run(ctx, Args{"message_id": float64(multi.ID), "options": "1, 3"}); err != nil {
		t.Fatal(err)
	}
	if out, err := tool.Run(ctx, Args{"message_id": float64(multi.ID), "options": ""}); err != nil || out != "Vote retracted" {
		t.Fatalf("%q %v", out, err)
	}
	if m, _ := f.Message(ctx, chat.ID, multi.ID); m.Poll.Total != 0 {
		t.Fatalf("retract: %+v", m.Poll)
	}
	text := f.Incoming(chat, 9, "Joe", "not a poll")
	if _, err := tool.Run(ctx, Args{"message_id": float64(text.ID), "options": "1"}); err == nil {
		t.Fatal("not a poll")
	}
	f.S.Update(chat.ID, single.ID, func(m *telegram.Message) { m.Poll.Closed = true })
	if _, err := tool.Run(ctx, Args{"message_id": float64(single.ID), "options": "1"}); err == nil || !strings.Contains(err.Error(), "closed") {
		t.Fatalf("closed: %v", err)
	}
}

func TestPinToolsOnlyWhereAllowed(t *testing.T) {
	d, f, _ := pollRig(t)
	ctx := context.Background()
	if _, err := pinTool(d, telegram.Chat{ID: -10}).Run(ctx, Args{"message_id": float64(5)}); err != nil {
		t.Fatal(err)
	}
	if got := f.Pinned[-10]; len(got) != 1 || got[0] != 5 {
		t.Fatalf("pinned %v", got)
	}
	if _, err := unpinTool(d, telegram.Chat{ID: -10}).Run(ctx, Args{"message_id": float64(5)}); err != nil || len(f.Pinned[-10]) != 0 {
		t.Fatalf("unpin: %v %v", err, f.Pinned)
	}
	has := func(c telegram.Chat, n string) bool { _, ok := ChatTools(d, c).Get(n); return ok }
	if has(telegram.Chat{ID: -10, Kind: telegram.ChatGroup, IsMember: true}, "pin_message") {
		t.Fatal("a non-admin in a group can't pin: don't offer it")
	}
	if !has(telegram.Chat{ID: -10, Kind: telegram.ChatGroup, IsMember: true, IsAdmin: true}, "pin_message") || !has(telegram.Chat{ID: 7, Kind: telegram.ChatPrivate, IsMember: true}, "pin_message") {
		t.Fatal("admins and private chats can pin")
	}
	if !has(telegram.Chat{ID: -10, Kind: telegram.ChatGroup, IsMember: true}, "create_poll") {
		t.Fatal("polls are available in groups")
	}
}
