package tools

import (
	"context"
	"crypto/rand"
	"errors"
	"fmt"
	"math/big"
	"regexp"
	"strconv"
	"strings"
	"time"

	"kuni/internal/period"
	"kuni/internal/units"
)

// util.go: exact little helpers for every chat: dates and time zones, unit conversion, fair dice and draws. A model
// guesses all of these and is wrong often enough ("what day of the week is 12 March", "100 °F in °C", "pick one of us").

// UtilTools are available in every chat she writes in.
func UtilTools(d Deps) []Tool { return []Tool{datetimeTool(d), unitsTool(), randomTool()} }

var reDur = regexp.MustCompile(`([+-]?\d+(?:[.,]\d+)?)\s*([a-zа-яё]+)`)

// addAmount adds "3 дня 4 часа", "+2w", "-90 минут", "1 месяц" to t (calendar units for years, months, weeks, days).
func addAmount(t time.Time, spec string) (time.Time, error) {
	s := strings.ToLower(strings.TrimSpace(spec))
	sign := 1
	if strings.HasPrefix(s, "-") || strings.HasPrefix(s, "минус ") {
		sign = -1
		s = strings.TrimPrefix(strings.TrimPrefix(s, "-"), "минус ")
	}
	s = strings.TrimPrefix(strings.TrimPrefix(s, "+"), "плюс ")
	ms := reDur.FindAllStringSubmatch(s, -1)
	if len(ms) == 0 {
		return t, fmt.Errorf("cannot read %q (like \"3 дня\", \"2 weeks 3 days\", \"-90 минут\")", spec)
	}
	for _, m := range ms {
		f, _ := strconv.ParseFloat(strings.Replace(m[1], ",", ".", 1), 64)
		n := int(f) * sign
		u := m[2]
		switch {
		case u == "y" || strings.HasPrefix(u, "year") || strings.HasPrefix(u, "год") || u == "лет" || u == "г":
			t = addMonths(t, 12*n)
		case u == "mo" || strings.HasPrefix(u, "month") || strings.HasPrefix(u, "мес"):
			t = addMonths(t, n)
		case u == "w" || strings.HasPrefix(u, "week") || strings.HasPrefix(u, "нед"):
			t = t.AddDate(0, 0, 7*n)
		case u == "d" || strings.HasPrefix(u, "day") || strings.HasPrefix(u, "дн") || strings.HasPrefix(u, "ден") || u == "сутки" || u == "суток":
			t = t.AddDate(0, 0, n)
		case u == "h" || strings.HasPrefix(u, "hour") || strings.HasPrefix(u, "ч"):
			t = t.Add(time.Duration(f*float64(sign)*3600) * time.Second)
		case u == "m" || strings.HasPrefix(u, "min") || strings.HasPrefix(u, "мин"):
			t = t.Add(time.Duration(f*float64(sign)*60) * time.Second)
		case u == "s" || strings.HasPrefix(u, "sec") || strings.HasPrefix(u, "сек"):
			t = t.Add(time.Duration(f*float64(sign)) * time.Second)
		default:
			return t, fmt.Errorf("unknown unit %q", u)
		}
	}
	return t, nil
}

// addMonths moves t by n months, keeping the day within the month (31 January + 1 month = 28 February, not 3 March).
func addMonths(t time.Time, n int) time.Time {
	first := time.Date(t.Year(), t.Month(), 1, t.Hour(), t.Minute(), t.Second(), t.Nanosecond(), t.Location()).AddDate(0, n, 0)
	last := first.AddDate(0, 1, -1).Day()
	return time.Date(first.Year(), first.Month(), min(t.Day(), last), t.Hour(), t.Minute(), t.Second(), t.Nanosecond(), t.Location())
}

func clockLine(t time.Time) string {
	_, off := t.Zone()
	sign := "+"
	if off < 0 {
		sign, off = "-", -off
	}
	z := fmt.Sprintf("UTC%s%d", sign, off/3600)
	if off%3600 != 0 {
		z += fmt.Sprintf(":%02d", off%3600/60)
	}
	return fmt.Sprintf("%s, %s (%s, %s)", ruDate(t), t.Format("15:04"), t.Location(), z)
}

func datetimeTool(d Deps) Tool {
	return Tool{
		Name: "datetime",
		Description: "Exact dates and time zones (never count in your head): now (tz), convert (when, tz -> to: cities), diff (when, other: days, months, " +
			"working days), add (when + amount: \"3 дня\", \"-90 минут\"), weekday, month (a calendar). when: \"2026-10-25 18:30\", \"25.10\", \"завтра 9:00\"; empty = now.",
		Props: []Prop{
			{Name: "action", Type: "string", Desc: "now, convert, diff, add, weekday, month."},
			{Name: "when", Type: "string", Nullable: true, Desc: "The date/time."},
			{Name: "tz", Type: "string", Nullable: true, Desc: "Zone of `when`: a city or IANA name (default the owner's)."},
			{Name: "to", Type: "string", Nullable: true, Desc: "convert: target zones, comma-separated."},
			{Name: "other", Type: "string", Nullable: true, Desc: "diff: the second date (default now)."},
			{Name: "amount", Type: "string", Nullable: true, Desc: "add: what to add (minus subtracts)."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			loc, err := zone(a.Str("tz"), zoneOf(d))
			if err != nil {
				return "", err
			}
			now := time.Now()
			when := func() (time.Time, bool, error) { return parseMoment(a.Str("when"), now, loc, false) }
			switch strings.ToLower(strings.TrimSpace(a.Str("action"))) {
			case "now", "":
				t := now.In(loc)
				_, week := t.ISOWeek()
				return fmt.Sprintf("Сейчас %s; неделя %d, день года %d.", clockLine(t), week, t.YearDay()), nil
			case "convert":
				t, _, err := when()
				if err != nil {
					return "", err
				}
				var b strings.Builder
				b.WriteString(clockLine(t) + "\n")
				for _, z := range strings.Split(a.Str("to"), ",") {
					if strings.TrimSpace(z) == "" {
						continue
					}
					l, err := zone(z, nil)
					if err != nil {
						return "", err
					}
					fmt.Fprintf(&b, "= %s\n", clockLine(t.In(l)))
				}
				return b.String(), nil
			case "diff":
				t1, timed1, err := when()
				if err != nil {
					return "", err
				}
				t2 := now.In(loc)
				timed2 := true
				if o := strings.TrimSpace(a.Str("other")); o != "" {
					if t2, timed2, err = parseMoment(o, now, loc, false); err != nil {
						return "", err
					}
				}
				return diffText(t1, t2, timed1 || timed2), nil
			case "add":
				t, _, err := when()
				if err != nil {
					return "", err
				}
				r, err := addAmount(t, a.Str("amount"))
				if err != nil {
					return "", err
				}
				return fmt.Sprintf("%s %s = %s", clockLine(t), a.Str("amount"), clockLine(r)), nil
			case "weekday":
				t, _, err := when()
				if err != nil {
					return "", err
				}
				left := int(time.Date(t.Year(), t.Month(), t.Day(), 0, 0, 0, 0, loc).Sub(time.Date(now.In(loc).Year(), now.In(loc).Month(), now.In(loc).Day(), 0, 0, 0, 0, loc)).Hours() / 24)
				rel := "сегодня"
				switch {
				case left > 0:
					rel = fmt.Sprintf("через %d %s", left, plural(left, "день", "дня", "дней"))
				case left < 0:
					rel = fmt.Sprintf("%d %s назад", -left, plural(-left, "день", "дня", "дней"))
				}
				return fmt.Sprintf("%s (%s)", ruDate(t), rel), nil
			case "month", "calendar":
				spec := strings.TrimSpace(a.Str("when"))
				if spec == "" {
					spec = "month"
				}
				from, to, _, err := period.Range(spec, now.In(loc))
				if err != nil {
					return "", err
				}
				return monthGrid(time.Date(from.Year(), from.Month(), 1, 0, 0, 0, 0, loc), to, now.In(loc)), nil
			}
			return "", errors.New("action is now, convert, diff, add, weekday or month")
		},
	}
}

func diffText(a, b time.Time, timed bool) string {
	if b.Before(a) {
		a, b = b, a
	}
	day := func(t time.Time) time.Time { return time.Date(t.Year(), t.Month(), t.Day(), 0, 0, 0, 0, time.UTC) }
	days := int(day(b).Sub(day(a)).Hours() / 24)
	m, dd := 0, 0
	for {
		if day(a.AddDate(0, m+1, 0)).After(day(b)) {
			dd = int(day(b).Sub(day(a.AddDate(0, m, 0))).Hours() / 24)
			break
		}
		m++
	}
	y, m := m/12, m%12
	work := 0
	for t := day(a); t.Before(day(b)); t = t.AddDate(0, 0, 1) {
		if wd := t.Weekday(); wd != time.Saturday && wd != time.Sunday {
			work++
		}
	}
	var parts []string
	if y > 0 {
		parts = append(parts, fmt.Sprintf("%d %s", y, plural(y, "год", "года", "лет")))
	}
	if m > 0 {
		parts = append(parts, fmt.Sprintf("%d мес.", m))
	}
	if dd > 0 || len(parts) == 0 {
		parts = append(parts, fmt.Sprintf("%d %s", dd, plural(dd, "день", "дня", "дней")))
	}
	out := fmt.Sprintf("От %s до %s: %d %s (%d нед. %d дн.; %s); рабочих дней (пн-пт) %d",
		ruDate(a), ruDate(b), days, plural(days, "день", "дня", "дней"), days/7, days%7, strings.Join(parts, " "), work)
	if timed {
		dur := b.Sub(a)
		out += fmt.Sprintf("; точно %d ч %d мин", int(dur.Hours()), int(dur.Minutes())%60)
	}
	return out + "."
}

func monthGrid(first, last, now time.Time) string {
	var b strings.Builder
	for m := first; !m.After(last); m = m.AddDate(0, 1, 0) {
		fmt.Fprintf(&b, "%s %d\nпн вт ср чт пт сб вс\n", strings.ToUpper(ruMonthName(m.Month())), m.Year())
		pad := (int(m.Weekday()) + 6) % 7
		b.WriteString(strings.Repeat("   ", pad))
		for d := m; d.Month() == m.Month(); d = d.AddDate(0, 0, 1) {
			mark := " "
			if d.Year() == now.Year() && d.YearDay() == now.YearDay() {
				mark = "*"
			}
			fmt.Fprintf(&b, "%2d%s", d.Day(), mark)
			if d.Weekday() == time.Sunday {
				b.WriteString("\n")
			}
		}
		b.WriteString("\n\n")
		if b.Len() > 4000 {
			break
		}
	}
	return "```\n" + strings.TrimRight(b.String(), "\n") + "\n```\n(* = сегодня)"
}

func ruMonthName(m time.Month) string {
	return [...]string{"", "январь", "февраль", "март", "апрель", "май", "июнь", "июль", "август", "сентябрь", "октябрь", "ноябрь", "декабрь"}[m]
}

func unitsTool() Tool {
	return Tool{
		Name: "units",
		Description: "Convert units exactly: length, weight, volume (incl. cups and spoons), area (сотки, гектары), speed, temperature, " +
			"data (MB, GiB, Mbit), time, energy (ккал), pressure (мм рт. ст.), power (л.с.), fuel (л/100км <-> mpg). Russian or English unit names. Money: use lookup rate.",
		Props: []Prop{
			{Name: "value", Type: "number", Desc: "The number."},
			{Name: "from", Type: "string", Desc: "Its unit (km, миль, °F, фунтов, сотки...)."},
			{Name: "to", Type: "string", Desc: "The unit wanted."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			v := a.Float("value")
			r, name, err := units.Convert(v, a.Str("from"), a.Str("to"))
			if err != nil {
				return "", err
			}
			return fmt.Sprintf("%s %s = %s %s", units.Format(v), strings.TrimSpace(a.Str("from")), units.Format(r), name), nil
		},
	}
}

// fair returns a uniformly random number in [0, n).
func fair(n int64) int64 {
	if n <= 1 {
		return 0
	}
	v, err := rand.Int(rand.Reader, big.NewInt(n))
	if err != nil {
		return time.Now().UnixNano() % n
	}
	return v.Int64()
}

var reDice = regexp.MustCompile(`^(\d{0,3})\s*[dдк]\s*(\d{1,4})\s*([+-]\s*\d{1,4})?$`)

func splitItems(s string) []string {
	sep := ","
	if strings.Contains(s, "\n") {
		sep = "\n"
	} else if strings.Contains(s, ";") {
		sep = ";"
	}
	var out []string
	for _, it := range strings.Split(s, sep) {
		if it = strings.TrimSpace(it); it != "" {
			out = append(out, it)
		}
	}
	return out
}

func randomTool() Tool {
	return Tool{
		Name: "random",
		Description: "Fair chance (a real random generator, not your guess): number (min..max), dice (\"2d6\", \"d20+3\"), coin, " +
			"pick (count of items: who goes first, a winner, what to cook), shuffle (items: an order, teams). Announce the result honestly.",
		Props: []Prop{
			{Name: "action", Type: "string", Desc: "number, dice, coin, pick or shuffle."},
			{Name: "min", Type: "integer", Nullable: true, Desc: "number: from (default 1)."},
			{Name: "max", Type: "integer", Nullable: true, Desc: "number: to (default 100)."},
			{Name: "dice", Type: "string", Nullable: true, Desc: "dice: like 2d6 (default 1d6)."},
			{Name: "items", Type: "string", Nullable: true, Desc: "pick/shuffle: the choices, comma- or line-separated."},
			{Name: "count", Type: "integer", Nullable: true, Desc: "pick: how many (default 1, all different)."},
		},
		Meta: Meta{Repeatable: true, ReadOnly: true},
		Run: func(ctx context.Context, a Args) (string, error) {
			switch strings.ToLower(strings.TrimSpace(a.Str("action"))) {
			case "number", "":
				lo, hi := int64(1), int64(100)
				if a.Has("min") {
					lo = a.Int("min")
				}
				if a.Has("max") {
					hi = a.Int("max")
				}
				if hi < lo {
					lo, hi = hi, lo
				}
				return fmt.Sprintf("Случайное число от %d до %d: %d", lo, hi, lo+fair(hi-lo+1)), nil
			case "dice":
				spec := strings.ToLower(strings.TrimSpace(a.Str("dice")))
				if spec == "" {
					spec = "1d6"
				}
				m := reDice.FindStringSubmatch(spec)
				if m == nil {
					return "", fmt.Errorf("dice like 2d6 or d20+3, not %q", spec)
				}
				n, _ := strconv.Atoi(m[1])
				if n == 0 {
					n = 1
				}
				sides, _ := strconv.ParseInt(m[2], 10, 64)
				if n > 100 || sides < 2 {
					return "", errors.New("at most 100 dice of 2+ sides")
				}
				mod := 0
				if m[3] != "" {
					mod, _ = strconv.Atoi(strings.ReplaceAll(m[3], " ", ""))
				}
				total := mod
				rolls := make([]string, n)
				for i := range rolls {
					r := 1 + fair(sides)
					total += int(r)
					rolls[i] = strconv.FormatInt(r, 10)
				}
				out := fmt.Sprintf("Бросок %s: [%s]", spec, strings.Join(rolls, ", "))
				if n > 1 || mod != 0 {
					out += fmt.Sprintf(" = %d", total)
				}
				return out, nil
			case "coin":
				if fair(2) == 0 {
					return "Монетка: орёл", nil
				}
				return "Монетка: решка", nil
			case "pick", "shuffle":
				items := splitItems(a.Str("items"))
				if len(items) == 0 {
					return "", errors.New("items are empty")
				}
				for i := len(items) - 1; i > 0; i-- { // Fisher-Yates
					j := fair(int64(i + 1))
					items[i], items[j] = items[j], items[i]
				}
				if strings.EqualFold(a.Str("action"), "shuffle") {
					return "Порядок: " + strings.Join(items, ", "), nil
				}
				k := int(a.Int("count"))
				if k <= 0 {
					k = 1
				}
				k = min(k, len(items))
				return fmt.Sprintf("Выбрано (%d из %d): %s", k, len(items), strings.Join(items[:k], ", ")), nil
			}
			return "", errors.New("action is number, dice, coin, pick or shuffle")
		},
	}
}
