package tools

import (
	"context"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"time"

	"kuni/internal/docs"
	"kuni/internal/media"
	"kuni/internal/web"
)

// webSearchTool searches the web with the configured SearXNG/Ollama search, or DuckDuckGo when none is set up.
func webSearchTool(d Deps) Tool {
	return Tool{
		Name:        "web_search",
		Description: "Search the web (owner only). Returns titles, links and snippets; open a result with read_link or the browser.",
		Props: []Prop{
			{Name: "query", Type: "string", Desc: "What to search for."},
			{Name: "count", Type: "integer", Nullable: true, Desc: "How many results (default 6, max 15)."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			q := strings.TrimSpace(a.Str("query"))
			if q == "" {
				return "", fmt.Errorf("empty query")
			}
			n := int(a.Int("count"))
			if n <= 0 || n > 15 {
				n = 6
			}
			c := d.Cfg()
			var s media.Searcher = media.DuckSearch{}
			if d.Searcher != nil {
				s = d.Searcher
			} else if c.WebSearchEnabled && c.WebSearchURL != "" {
				s = d.Media().Web
			}
			res, err := s.Search(ctx, q, n)
			if err != nil {
				return "", err
			}
			var b strings.Builder
			b.WriteString("<web_search_results>\n")
			for i, r := range res {
				fmt.Fprintf(&b, "%d. %s\n   %s\n   %s\n", i+1, r.Title, r.URL, Truncate(strings.TrimSpace(r.Content), 300))
			}
			b.WriteString("</web_search_results>")
			return b.String(), nil
		},
	}
}

// readFileTool reads a file of her machine as text: txt/md/csv/json/code, docx, xlsx, odt, pdf.
func readFileTool(d Deps) Tool {
	return Tool{
		Name:        "read_file",
		Description: "Read a file on your machine as text (owner only): documents (pdf, docx, xlsx, odt), tables, code and plain text. Relative paths are inside your workspace.",
		Props: []Prop{
			{Name: "path", Type: "string", Desc: "File path."},
			{Name: "offset", Type: "integer", Nullable: true, Desc: "Continue from this character (given in the previous answer)."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			p := strings.TrimSpace(a.Str("path"))
			if p == "" {
				return "", fmt.Errorf("empty path")
			}
			if !filepath.IsAbs(p) {
				p = filepath.Join(d.workDir(), p)
			}
			st, err := os.Stat(p)
			if err != nil {
				return "", err
			}
			if st.IsDir() {
				ents, _ := os.ReadDir(p)
				var names []string
				for _, e := range ents {
					names = append(names, e.Name())
				}
				return "directory: " + strings.Join(names, ", "), nil
			}
			if st.Size() > 50<<20 {
				return "", fmt.Errorf("file is %d MB: too big to read", st.Size()>>20)
			}
			raw, err := os.ReadFile(p)
			if err != nil {
				return "", err
			}
			text, err := docs.Extract(ctx, filepath.Base(p), raw)
			if err != nil {
				return "", err
			}
			r := []rune(text)
			off := int(a.Int("offset"))
			if off < 0 || off > len(r) {
				off = 0
			}
			end := off + 8000
			note := ""
			if end < len(r) {
				note = fmt.Sprintf("\n…(continues: read_file with offset=%d; %d characters in total)", end, len(r))
			} else {
				end = len(r)
			}
			return "<file_text>\n" + string(r[off:end]) + note + "\n</file_text>", nil
		},
	}
}

// service is one entry of integrations.services.
type service struct{ Name, Base, Header, Value string }

func parseServices(s string) map[string]service {
	out := map[string]service{}
	for _, part := range strings.FieldsFunc(s, func(r rune) bool { return r == ';' || r == '\n' }) {
		f := strings.SplitN(part, "|", 3)
		if len(f) != 3 {
			continue
		}
		h, v, ok := strings.Cut(f[2], ":")
		if !ok {
			continue
		}
		name := strings.ToLower(strings.TrimSpace(f[0]))
		out[name] = service{Name: name, Base: strings.TrimRight(strings.TrimSpace(f[1]), "/"), Header: strings.TrimSpace(h), Value: strings.TrimSpace(v)}
	}
	return out
}

// httpRequestTool calls an API. With a service name the stored key is added by the program, so the model never sees it.
func httpRequestTool(d Deps) Tool {
	return Tool{
		Name: "http_request",
		Description: "Call a web API (owner only). Either service + path for a configured service (the key is added for you; the list is in the answer when you pass an unknown name), " +
			"or a full public url without a key. GET reads, POST/PUT/PATCH/DELETE change things: use them only when the owner asked for exactly that.",
		Props: []Prop{
			{Name: "service", Type: "string", Nullable: true, Desc: "Configured service name, e.g. github."},
			{Name: "path", Type: "string", Nullable: true, Desc: "Path with query for the service, e.g. /user/repos?per_page=5. With no service: the full URL."},
			{Name: "method", Type: "string", Nullable: true, Desc: "GET (default), POST, PUT, PATCH, DELETE."},
			{Name: "body", Type: "string", Nullable: true, Desc: "Request body (JSON text) for POST/PUT/PATCH."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			method := strings.ToUpper(strings.TrimSpace(a.Str("method")))
			if method == "" {
				method = http.MethodGet
			}
			switch method {
			case "GET", "POST", "PUT", "PATCH", "DELETE":
			default:
				return "", fmt.Errorf("method %q is not allowed", method)
			}
			path := strings.TrimSpace(a.Str("path"))
			var client *http.Client
			var target string
			var hdrName, hdrVal string
			if name := strings.ToLower(strings.TrimSpace(a.Str("service"))); name != "" {
				svcs := parseServices(d.Cfg().Services)
				sv, ok := svcs[name]
				if !ok {
					var names []string
					for n := range svcs {
						names = append(names, n)
					}
					return "", fmt.Errorf("no service %q; configured: %s", name, strings.Join(names, ", "))
				}
				if !strings.HasPrefix(path, "/") {
					path = "/" + path
				}
				target = sv.Base + path
				hdrName, hdrVal = sv.Header, sv.Value
				host := mustHost(sv.Base)
				client = &http.Client{Timeout: 30 * time.Second, CheckRedirect: func(req *http.Request, via []*http.Request) error {
					if req.URL.Host != host || len(via) > 4 {
						return fmt.Errorf("redirect to another host refused (the key stays with %s)", host)
					}
					return nil
				}}
			} else {
				if path == "" {
					return "", fmt.Errorf("pass service+path or a full url in path")
				}
				if !strings.Contains(path, "://") {
					path = "https://" + path
				}
				target = path
				client = web.Fetcher{Timeout: 30 * time.Second}.Client()
				if method != "GET" {
					return "", fmt.Errorf("without a configured service only GET is allowed")
				}
			}
			var body io.Reader
			if b := a.Str("body"); b != "" {
				body = strings.NewReader(b)
			}
			req, err := http.NewRequestWithContext(ctx, method, target, body)
			if err != nil {
				return "", err
			}
			req.Header.Set("User-Agent", "reina/1.0")
			req.Header.Set("Accept", "application/json, text/plain, */*")
			if body != nil {
				req.Header.Set("Content-Type", "application/json")
			}
			if hdrName != "" {
				req.Header.Set(hdrName, hdrVal)
			}
			resp, err := client.Do(req)
			if err != nil {
				return "", fmt.Errorf("%s", strings.ReplaceAll(err.Error(), hdrVal, "***"))
			}
			defer resp.Body.Close()
			raw, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
			out := string(raw)
			if hdrVal != "" {
				out = strings.ReplaceAll(out, hdrVal, "***")
			}
			return fmt.Sprintf("HTTP %d\n<api_response>\n%s\n</api_response>", resp.StatusCode, Truncate(out, 9000)), nil
		},
	}
}

func mustHost(base string) string {
	u, err := url.Parse(base)
	if err != nil {
		return ""
	}
	return u.Host
}
