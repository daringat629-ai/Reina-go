package tools

import (
	"context"
	"fmt"

	"kuni/internal/mood"
)

// MoodTool lets the character report a mood-changing moment. It costs no extra LLM call.
func MoodTool(d Deps) Tool {
	return Tool{
		Name: "change_mood",
		Description: "Shift your mood scale when something happens: insulted, rejected or annoyed -> negative delta; praised, cared for, " +
			"flirted with, something nice -> positive. Small moments +-5..10, serious ones +-20..35.",
		Props: []Prop{
			{Name: "delta", Type: "integer", Desc: "From -35 to 35."},
			{Name: "reason", Type: "string", Desc: "Few words why."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			lvl := d.Mood.Add(int(a.Int("delta")))
			return fmt.Sprintf("Mood is now %d/100 (%s).", lvl, mood.Name(lvl)), nil
		},
	}
}
