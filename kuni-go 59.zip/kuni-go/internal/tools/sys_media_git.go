package tools

import (
	"bytes"
	"context"
	"fmt"
	"image"
	_ "image/gif"
	_ "image/jpeg"
	_ "image/png"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strings"
	"time"
)

// sys_media_git.go: eyes for image files, picture editing, git, downloading media, reading SQLite databases.

// runBin runs a program (no shell) with a timeout and returns its combined output and exit code.
func runBin(ctx context.Context, timeout time.Duration, dir string, env []string, bin string, args ...string) (string, int) {
	cctx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()
	c := exec.CommandContext(cctx, bin, args...)
	c.Dir = dir
	c.Env = append(os.Environ(), env...)
	c.WaitDelay = 2 * time.Second
	var out bytes.Buffer
	c.Stdout, c.Stderr = &out, &out
	err := c.Run()
	code := 0
	if err != nil {
		code = -1
		if ee, ok := err.(*exec.ExitError); ok {
			code = ee.ExitCode()
		}
	}
	s := out.String()
	if cctx.Err() == context.DeadlineExceeded {
		s += "\n(timed out after " + timeout.String() + ", killed)"
	}
	return s, code
}

func findBin(names ...string) (string, bool) {
	for _, n := range names {
		if p, err := exec.LookPath(n); err == nil {
			return p, true
		}
	}
	return "", false
}

// ---- looking at image files ----

func seeImageTool(d Deps) Tool {
	return Tool{
		Name:        "see_image",
		Description: "Look at a picture file on your machine (owner only): describe it, read the text on it (OCR), answer a question about it: screenshots, photos, scans, charts. png, jpg, webp, gif. For pictures people sent in Telegram you already get a description in the message; use this for files on disk.",
		Props: []Prop{
			{Name: "path", Type: "string", Desc: "Image file."},
			{Name: "question", Type: "string", Nullable: true, Desc: "What to find out. Empty = describe it and read all visible text."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			if d.UI == nil {
				return "", fmt.Errorf("no vision available")
			}
			p := d.resolvePath(a.Str("path"))
			st, err := os.Stat(p)
			if err != nil {
				return "", err
			}
			if st.IsDir() || st.Size() > 20<<20 {
				return "", fmt.Errorf("not an image file, or bigger than 20 MB")
			}
			raw, err := os.ReadFile(p)
			if err != nil {
				return "", err
			}
			if !(bytes.HasPrefix(raw, []byte("\x89PNG")) || bytes.HasPrefix(raw, []byte("\xff\xd8"))) {
				ff, ok := findBin("ffmpeg")
				if !ok {
					return "", fmt.Errorf("only png and jpg without ffmpeg installed")
				}
				tmp := filepath.Join(d.workDir(), fmt.Sprintf(".see-%d.png", time.Now().UnixNano()))
				defer os.Remove(tmp)
				if out, code := runBin(ctx, 60*time.Second, "", nil, ff, "-y", "-loglevel", "error", "-i", p, "-frames:v", "1", tmp); code != 0 {
					return "", fmt.Errorf("can't read this as a picture: %s", Truncate(out, 300))
				}
				if raw, err = os.ReadFile(tmp); err != nil {
					return "", err
				}
			}
			q := strings.TrimSpace(a.Str("question"))
			if q == "" {
				q = "Describe the picture and transcribe all text visible on it, exactly."
			}
			desc, err := d.UI.LookAtImage(ctx, raw, q)
			if err != nil {
				return "", fmt.Errorf("the vision model could not look: %w (set llm.vision_model to a model that supports images)", err)
			}
			return "<image_description>\n" + desc + "\n</image_description>", nil
		},
	}
}

// ---- picture editing ----

func imageTool(d Deps) Tool {
	return Tool{
		Name:        "image",
		Description: "Edit picture files (owner only). Actions: info (size and format), resize (width and/or height in pixels, the other keeps proportions), convert (to = target file name with the wanted extension: jpg, png, webp), compress (quality 1-100, smaller file), rotate (degrees: 90, 180, 270), crop (width, height, x, y). The result is written next to the original unless `to` is given, the original stays. Send the result with send_file.",
		Props: []Prop{
			{Name: "action", Type: "string", Desc: "info, resize, convert, compress, rotate or crop."},
			{Name: "path", Type: "string", Desc: "The picture."},
			{Name: "to", Type: "string", Nullable: true, Desc: "Output file name."},
			{Name: "width", Type: "integer", Nullable: true, Desc: "resize / crop width."},
			{Name: "height", Type: "integer", Nullable: true, Desc: "resize / crop height."},
			{Name: "x", Type: "integer", Nullable: true, Desc: "crop: left edge."},
			{Name: "y", Type: "integer", Nullable: true, Desc: "crop: top edge."},
			{Name: "quality", Type: "integer", Nullable: true, Desc: "compress: 1-100, default 70."},
			{Name: "degrees", Type: "integer", Nullable: true, Desc: "rotate: 90, 180 or 270."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			src := d.resolvePath(a.Str("path"))
			act := strings.ToLower(strings.TrimSpace(a.Str("action")))
			if act == "info" {
				f, err := os.Open(src)
				if err != nil {
					return "", err
				}
				defer f.Close()
				cfg, format, err := image.DecodeConfig(f)
				if err != nil {
					return "", fmt.Errorf("cannot read this picture directly (%v); convert it first", err)
				}
				return fmt.Sprintf("%s: %s, %dx%d, %s", src, format, cfg.Width, cfg.Height, sizeOf(src)), nil
			}
			ff, ok := findBin("ffmpeg")
			if !ok {
				return "", fmt.Errorf("ffmpeg is not installed (apk add ffmpeg)")
			}
			ext := filepath.Ext(src)
			suffix := map[string]string{"resize": "_small", "compress": "_min", "rotate": "_rot", "crop": "_crop", "convert": ""}[act]
			if _, known := map[string]bool{"resize": true, "compress": true, "rotate": true, "crop": true, "convert": true}[act]; !known {
				return "", fmt.Errorf("action must be info, resize, convert, compress, rotate or crop")
			}
			dst := strings.TrimSuffix(src, ext) + suffix + ext
			if t := strings.TrimSpace(a.Str("to")); t != "" {
				dst = d.resolvePath(t)
			}
			if act == "convert" && strings.TrimSpace(a.Str("to")) == "" {
				return "", fmt.Errorf("convert needs `to` with the new extension, like photo.webp")
			}
			if dst == src {
				return "", fmt.Errorf("the result would overwrite the original: give another `to`")
			}
			args := []string{"-y", "-loglevel", "error", "-i", src}
			switch act {
			case "resize":
				w, h := a.Int("width"), a.Int("height")
				if w <= 0 && h <= 0 {
					return "", fmt.Errorf("give width and/or height")
				}
				ws, hs := "-2", "-2"
				if w > 0 {
					ws = fmt.Sprint(w)
				}
				if h > 0 {
					hs = fmt.Sprint(h)
				}
				args = append(args, "-vf", "scale="+ws+":"+hs)
			case "rotate":
				switch a.Int("degrees") {
				case 90:
					args = append(args, "-vf", "transpose=1")
				case 180:
					args = append(args, "-vf", "transpose=1,transpose=1")
				case 270:
					args = append(args, "-vf", "transpose=2")
				default:
					return "", fmt.Errorf("degrees must be 90, 180 or 270")
				}
			case "crop":
				w, h := a.Int("width"), a.Int("height")
				if w <= 0 || h <= 0 {
					return "", fmt.Errorf("crop needs width and height")
				}
				args = append(args, "-vf", fmt.Sprintf("crop=%d:%d:%d:%d", w, h, a.Int("x"), a.Int("y")))
			case "compress":
				q := a.Int("quality")
				if q <= 0 || q > 100 {
					q = 70
				}
				// ffmpeg's jpeg scale: 2 (best) .. 31 (worst); webp takes 0..100 directly
				if strings.EqualFold(filepath.Ext(dst), ".webp") {
					args = append(args, "-quality", fmt.Sprint(q))
				} else {
					args = append(args, "-q:v", fmt.Sprint(31-int(q)*29/100))
				}
			}
			args = append(args, "-frames:v", "1", dst)
			if err := os.MkdirAll(filepath.Dir(dst), 0o755); err != nil {
				return "", err
			}
			if out, code := runBin(ctx, 120*time.Second, "", nil, ff, args...); code != 0 {
				return "", fmt.Errorf("ffmpeg failed: %s", Truncate(strings.TrimSpace(out), 400))
			}
			return fmt.Sprintf("%s -> %s (%s -> %s)", src, dst, sizeOf(src), sizeOf(dst)), nil
		},
	}
}

// ---- git ----

var reRef = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9._/@+-]{0,200}$`)

func gitTool(d Deps) Tool {
	return Tool{
		Name: "git",
		Description: "Git (owner only). Actions: clone (url, into `dir`), status, log (last 10), diff, pull, branch (list; or switch to `ref`), commit (adds everything and commits with `message`), push. `dir` is the repository (relative paths are inside your workspace). " +
			"Use it to fetch, read and save projects. Nothing here asks for passwords: private repositories need keys or tokens set up on the machine.",
		Props: []Prop{
			{Name: "action", Type: "string", Desc: "clone, status, log, diff, pull, branch, commit or push."},
			{Name: "dir", Type: "string", Nullable: true, Desc: "Repository folder (clone: where to put it)."},
			{Name: "url", Type: "string", Nullable: true, Desc: "clone: https:// or git@ address."},
			{Name: "ref", Type: "string", Nullable: true, Desc: "branch: the branch to switch to."},
			{Name: "message", Type: "string", Nullable: true, Desc: "commit: the commit message."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			git, ok := findBin("git")
			if !ok {
				return "", fmt.Errorf("git is not installed (apk add git)")
			}
			env := []string{"GIT_TERMINAL_PROMPT=0", "GIT_ASKPASS=true", "GCM_INTERACTIVE=never"}
			act := strings.ToLower(strings.TrimSpace(a.Str("action")))
			dir := d.workDir()
			if s := strings.TrimSpace(a.Str("dir")); s != "" {
				dir = d.resolvePath(s)
			}
			res := func(out string, code int) (string, error) {
				return fmt.Sprintf("exit=%d\n%s", code, Truncate(strings.TrimSpace(out), maxOut)), nil
			}
			switch act {
			case "clone":
				u := strings.TrimSpace(a.Str("url"))
				if !(strings.HasPrefix(u, "https://") || strings.HasPrefix(u, "git@") || strings.HasPrefix(u, "ssh://")) {
					return "", fmt.Errorf("url must start with https://, git@ or ssh://")
				}
				if strings.TrimSpace(a.Str("dir")) == "" {
					name := strings.TrimSuffix(filepath.Base(strings.TrimRight(u, "/")), ".git")
					dir = filepath.Join(d.workDir(), name)
				}
				d.journal("git clone "+u+" "+dir, 0)
				out, code := runBin(ctx, 300*time.Second, "", env, git, "clone", "--depth", "50", "--", u, dir)
				return res(out, code)
			case "status":
				out, code := runBin(ctx, 60*time.Second, dir, env, git, "status", "--short", "--branch")
				return res(out, code)
			case "log":
				out, code := runBin(ctx, 60*time.Second, dir, env, git, "log", "-10", "--date=short", "--pretty=format:%h %ad %an: %s")
				return res(out, code)
			case "diff":
				out, code := runBin(ctx, 60*time.Second, dir, env, git, "diff", "--stat", "--patch", "--no-color")
				return res(out, code)
			case "pull":
				out, code := runBin(ctx, 300*time.Second, dir, env, git, "pull", "--ff-only")
				return res(out, code)
			case "branch":
				if r := strings.TrimSpace(a.Str("ref")); r != "" {
					if !reRef.MatchString(r) {
						return "", fmt.Errorf("bad branch name")
					}
					out, code := runBin(ctx, 60*time.Second, dir, env, git, "switch", r)
					return res(out, code)
				}
				out, code := runBin(ctx, 60*time.Second, dir, env, git, "branch", "-vv")
				return res(out, code)
			case "commit":
				msg := strings.TrimSpace(a.Str("message"))
				if msg == "" {
					return "", fmt.Errorf("commit needs a message")
				}
				if out, code := runBin(ctx, 60*time.Second, dir, env, git, "add", "-A"); code != 0 {
					return res(out, code)
				}
				d.journal("git commit in "+dir+": "+msg, 0)
				out, code := runBin(ctx, 60*time.Second, dir, env, git, "commit", "-m", msg)
				return res(out, code)
			case "push":
				d.journal("git push in "+dir, 0)
				out, code := runBin(ctx, 300*time.Second, dir, env, git, "push")
				return res(out, code)
			}
			return "", fmt.Errorf("action must be clone, status, log, diff, pull, branch, commit or push")
		},
	}
}

// ---- downloading media ----

func mediaDownloadTool(d Deps) Tool {
	return Tool{
		Name:        "media_dl",
		Description: "Download a video or music from a link (YouTube and a thousand other sites, via yt-dlp) into your workspace (owner only). audio_only=true gives an mp3. Returns the file path: then send it with send_file. Up to 200 MB.",
		Props: []Prop{
			{Name: "url", Type: "string", Desc: "Page address."},
			{Name: "audio_only", Type: "boolean", Nullable: true, Desc: "Only the sound, as mp3."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			bin, ok := findBin("yt-dlp", "yt_dlp")
			if !ok {
				return "", fmt.Errorf("yt-dlp is not installed (apk add yt-dlp, or pip install yt-dlp)")
			}
			u := strings.TrimSpace(a.Str("url"))
			if pu, err := url.Parse(u); err != nil || (pu.Scheme != "http" && pu.Scheme != "https") || pu.Host == "" {
				return "", fmt.Errorf("give a normal http(s) link")
			}
			dir := filepath.Join(d.workDir(), "downloads")
			_ = os.MkdirAll(dir, 0o755)
			args := []string{"--no-playlist", "--no-progress", "--max-filesize", "200M", "-o", filepath.Join(dir, "%(title).80B.%(ext)s"), "--print", "after_move:filepath"}
			if a.Bool("audio_only") {
				args = append(args, "-x", "--audio-format", "mp3")
			} else {
				args = append(args, "-f", "bv*[height<=720]+ba/b[height<=720]/b", "--merge-output-format", "mp4")
			}
			args = append(args, "--", u)
			d.journal("media_dl "+u, 0)
			out, code := runBin(ctx, 600*time.Second, d.workDir(), nil, bin, args...)
			lines := strings.Split(strings.TrimSpace(out), "\n")
			if code == 0 && len(lines) > 0 {
				path := strings.TrimSpace(lines[len(lines)-1])
				if _, err := os.Stat(path); err == nil {
					return "downloaded: " + path + " (" + sizeOf(path) + ")", nil
				}
			}
			return "", fmt.Errorf("download failed (exit %d): %s", code, Truncate(strings.TrimSpace(out), 500))
		},
	}
}

// ---- SQLite ----

var reSelect = regexp.MustCompile(`(?is)^\s*(select|with|pragma|explain)\b`)

func sqliteTool(d Deps) Tool {
	return Tool{
		Name:        "sqlite",
		Description: "Read a SQLite database file (owner only), read-only: query = a SELECT / WITH / PRAGMA statement (for the list of tables: SELECT name FROM sqlite_master WHERE type='table'). Returns up to 100 rows as CSV with a header. Cannot change anything.",
		Props: []Prop{
			{Name: "path", Type: "string", Desc: "Database file."},
			{Name: "query", Type: "string", Desc: "One read-only statement."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			q := strings.TrimSpace(a.Str("query"))
			if !reSelect.MatchString(q) {
				return "", fmt.Errorf("only SELECT, WITH, PRAGMA and EXPLAIN statements")
			}
			if strings.Contains(strings.TrimSuffix(q, ";"), ";") || strings.HasPrefix(q, ".") {
				return "", fmt.Errorf("one statement at a time")
			}
			if reWrite.MatchString(q) {
				return "", fmt.Errorf("this database is read-only here")
			}
			p := d.resolvePath(a.Str("path"))
			if _, err := os.Stat(p); err != nil {
				return "", err
			}
			bin, ok := findBin("sqlite3")
			if !ok {
				return "", fmt.Errorf("sqlite3 is not installed (apk add sqlite)")
			}
			out, code := runBin(ctx, 30*time.Second, "", nil, bin, "-readonly", "-header", "-csv", p, q)
			if code != 0 {
				return "", fmt.Errorf("sqlite: %s", Truncate(strings.TrimSpace(out), 400))
			}
			lines := strings.Split(strings.TrimRight(out, "\n"), "\n")
			note := ""
			if len(lines) > 101 {
				lines, note = lines[:101], "\n…(first 100 rows; there are more)"
			}
			return Truncate(strings.Join(lines, "\n")+note, maxOut), nil
		},
	}
}

var reWrite = regexp.MustCompile(`(?i)\b(insert|update|delete|drop|alter|create|replace|attach|detach|vacuum|reindex)\b`)
