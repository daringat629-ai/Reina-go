package tools

import (
	"net"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestNotes(t *testing.T) {
	d := ownerDeps(t, 5)
	nt := notesTool(d)
	run(t, nt, Args{"action": "add", "text": "купить хлеб"})
	run(t, nt, Args{"action": "add", "text": "позвонить маме"})
	if out := run(t, nt, Args{"action": "list"}); !strings.Contains(out, "1. [ ] купить хлеб") || !strings.Contains(out, "2. [ ] позвонить") {
		t.Fatal(out)
	}
	run(t, nt, Args{"action": "done", "id": float64(1)})
	if out := run(t, nt, Args{"action": "list"}); strings.Contains(out, "хлеб") {
		t.Fatal(out)
	}
	if out := run(t, nt, Args{"action": "list", "all": true}); !strings.Contains(out, "[x] купить хлеб") {
		t.Fatal(out)
	}
	if out := run(t, nt, Args{"action": "search", "text": "МАМ"}); !strings.Contains(out, "позвонить") {
		t.Fatal(out)
	}
	run(t, nt, Args{"action": "clear_done"})
	run(t, nt, Args{"action": "delete", "id": float64(2)})
	if out := run(t, nt, Args{"action": "list", "all": true}); out != "(nothing)" {
		t.Fatal(out)
	}
	if out := run(t, nt, Args{"action": "delete", "id": float64(9)}); !strings.HasPrefix(out, "ERR") {
		t.Fatal(out)
	}
}

func TestProcRefusesInitAndSelf(t *testing.T) {
	d := ownerDeps(t, 5)
	pt := procTool(d)
	for _, pid := range []float64{0, 1, float64(os.Getpid())} {
		if out := run(t, pt, Args{"action": "kill", "pid": pid}); !strings.Contains(out, "Blocked") {
			t.Fatalf("%v: %s", pid, out)
		}
	}
	if _, err := os.Stat("/proc/self"); err == nil {
		if out := run(t, pt, Args{"action": "list"}); !strings.Contains(out, "pid") {
			t.Fatal(out)
		}
	}
}

func TestNetcheck(t *testing.T) {
	d := ownerDeps(t, 5)
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/ip" {
			w.Write([]byte("1.2.3.4\n"))
			return
		}
		w.Write([]byte("ok"))
	}))
	defer srv.Close()
	old := ipBase
	ipBase = srv.URL + "/ip"
	defer func() { ipBase = old }()
	nt := netcheckTool(d)
	if out := run(t, nt, Args{"action": "http", "url": srv.URL}); !strings.Contains(out, "HTTP 200") {
		t.Fatal(out)
	}
	if out := run(t, nt, Args{"action": "ip"}); !strings.Contains(out, "1.2.3.4") {
		t.Fatal(out)
	}
	host, port, _ := net.SplitHostPort(strings.TrimPrefix(srv.URL, "http://"))
	pn, _ := net.LookupPort("tcp", port)
	if out := run(t, nt, Args{"action": "port", "host": host, "port": float64(pn)}); !strings.Contains(out, "is open") {
		t.Fatal(out)
	}
	if out := run(t, nt, Args{"action": "port", "host": "127.0.0.1", "port": float64(1)}); !strings.Contains(out, "closed") {
		t.Fatal(out)
	}
	if out := run(t, nt, Args{"action": "dns", "host": "localhost"}); !strings.Contains(out, "127.0.0.1") && !strings.Contains(out, "::1") {
		t.Fatal(out)
	}
}

func TestArchivesRoundTripAndZipSlip(t *testing.T) {
	d := ownerDeps(t, 5)
	ft, at := filesTool(d), archiveTool(d)
	run(t, ft, Args{"action": "write", "path": "pack/a.txt", "text": "alpha"})
	run(t, ft, Args{"action": "write", "path": "pack/sub/b.txt", "text": "beta"})
	if out := run(t, at, Args{"action": "zip", "path": "pack"}); !strings.Contains(out, "2 files") {
		t.Fatal(out)
	}
	if out := run(t, at, Args{"action": "unzip", "path": "pack.zip", "to": "from_zip"}); !strings.Contains(out, "2 files") {
		t.Fatal(out)
	}
	raw, _ := os.ReadFile(filepath.Join(d.workDir(), "from_zip/pack/sub/b.txt"))
	if string(raw) != "beta" {
		t.Fatalf("%q", raw)
	}
	if out := run(t, at, Args{"action": "tar", "path": "pack"}); !strings.Contains(out, "2 files") {
		t.Fatal(out)
	}
	if out := run(t, at, Args{"action": "untar", "path": "pack.tar.gz", "to": "from_tar"}); !strings.Contains(out, "2 files") {
		t.Fatal(out)
	}
	if raw, _ := os.ReadFile(filepath.Join(d.workDir(), "from_tar/pack/a.txt")); string(raw) != "alpha" {
		t.Fatalf("%q", raw)
	}
	if inside("/a/b", "/a/b/../c") || !inside("/a/b", "/a/b/c/d") {
		t.Fatal("zip-slip guard is wrong")
	}
}

func TestRSSAndAtom(t *testing.T) {
	rss := `<?xml version="1.0"?><rss><channel><title>Блог</title><item><title>Первый</title><link>http://x/1</link><pubDate>Mon</pubDate></item><item><title>Второй</title><link>http://x/2</link></item></channel></rss>`
	atom := `<?xml version="1.0"?><feed xmlns="http://www.w3.org/2005/Atom"><title>Rel</title><entry><title>v1.0</title><link href="http://g/1"/><updated>2026-01-01</updated></entry></feed>`
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/atom" {
			w.Write([]byte(atom))
			return
		}
		w.Write([]byte(rss))
	}))
	defer srv.Close()
	d := ownerDeps(t, 5)
	rt := rssTool(d)
	if out := run(t, rt, Args{"url": srv.URL + "/rss", "count": float64(1)}); !strings.Contains(out, "Первый") || strings.Contains(out, "Второй") {
		t.Fatal(out)
	}
	if out := run(t, rt, Args{"url": srv.URL + "/atom"}); !strings.Contains(out, "v1.0 — http://g/1") {
		t.Fatal(out)
	}
	if out := run(t, rt, Args{"url": srv.URL + "/x", "count": float64(1)}); strings.HasPrefix(out, "ERR") {
		t.Fatal("rss served for any path:", out)
	}
}

func TestTextutil(t *testing.T) {
	d := ownerDeps(t, 5)
	tu := textutilTool(d)
	cases := map[string][2]string{
		"base64_encode": {"привет", "0L/RgNC40LLQtdGC"},
		"base64_decode": {"0L/RgNC40LLQtdGC", "привет"},
		"sha256":        {"abc", "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"},
		"md5":           {"abc", "900150983cd24fb0d6963f7d28e17f72"},
		"url_encode":    {"a b&c", "a+b%26c"},
		"count":         {"a b\nc", "characters 5, words 3, lines 2"},
		"time_diff":     {"2026-10-21T00:00:00+06:00 2026-10-22T12:00:00+06:00", "36h0m0s (1.5 days)"},
	}
	for op, c := range cases {
		if out := run(t, tu, Args{"op": op, "text": c[0]}); out != c[1] {
			t.Errorf("%s: got %q want %q", op, out, c[1])
		}
	}
	if out := run(t, tu, Args{"op": "uuid"}); len(out) != 36 || out[14] != '4' {
		t.Fatal(out)
	}
	if out := run(t, tu, Args{"op": "password", "text": "24"}); len(out) != 24 {
		t.Fatal(out)
	}
	if out := run(t, tu, Args{"op": "json_format", "text": `{"a":[1,2]}`}); !strings.Contains(out, "\n  \"a\"") {
		t.Fatal(out)
	}
}

func TestServiceUsesRcServiceAndProtectsSSH(t *testing.T) {
	bin := t.TempDir()
	script := "#!/bin/sh\necho \"rc-service $@\"\n"
	os.WriteFile(filepath.Join(bin, "rc-service"), []byte(script), 0o755)
	t.Setenv("PATH", bin+":"+os.Getenv("PATH"))
	d := ownerDeps(t, 5)
	st := serviceTool(d)
	if out := run(t, st, Args{"action": "restart", "name": "nginx"}); !strings.Contains(out, "rc-service nginx restart") {
		t.Fatal(out)
	}
	if out := run(t, st, Args{"action": "stop", "name": "sshd"}); !strings.Contains(out, "Blocked") {
		t.Fatal(out)
	}
	if out := run(t, st, Args{"action": "status", "name": "x; rm -rf /"}); !strings.HasPrefix(out, "ERR") {
		t.Fatal(out)
	}
}
