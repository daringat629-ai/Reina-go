package tools

import (
	"image"
	"image/color"
	"image/png"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"kuni/internal/llm"
	"kuni/internal/llmui"
	"kuni/internal/media"
)

func writePNG(t *testing.T, path string, w, h int) {
	t.Helper()
	img := image.NewRGBA(image.Rect(0, 0, w, h))
	for x := 0; x < w; x++ {
		for y := 0; y < h; y++ {
			img.Set(x, y, color.RGBA{uint8(x), uint8(y), 120, 255})
		}
	}
	f, err := os.Create(path)
	if err != nil {
		t.Fatal(err)
	}
	defer f.Close()
	if err := png.Encode(f, img); err != nil {
		t.Fatal(err)
	}
}

func needBin(t *testing.T, name string) {
	t.Helper()
	if _, err := exec.LookPath(name); err != nil {
		t.Skip(name + " is not installed here")
	}
}

func TestImageEditing(t *testing.T) {
	needBin(t, "ffmpeg")
	d := ownerDeps(t, 5)
	src := filepath.Join(d.workDir(), "pic.png")
	writePNG(t, src, 200, 100)
	it := imageTool(d)
	if out := run(t, it, Args{"action": "info", "path": "pic.png"}); !strings.Contains(out, "png, 200x100") {
		t.Fatal(out)
	}
	if out := run(t, it, Args{"action": "resize", "path": "pic.png", "width": float64(50)}); !strings.Contains(out, "pic_small.png") {
		t.Fatal(out)
	}
	if out := run(t, it, Args{"action": "info", "path": "pic_small.png"}); !strings.Contains(out, "50x2") {
		t.Fatal(out)
	}
	if out := run(t, it, Args{"action": "convert", "path": "pic.png", "to": "pic.jpg"}); strings.HasPrefix(out, "ERR") {
		t.Fatal(out)
	}
	if out := run(t, it, Args{"action": "info", "path": "pic.jpg"}); !strings.Contains(out, "jpeg, 200x100") {
		t.Fatal(out)
	}
	if out := run(t, it, Args{"action": "compress", "path": "pic.jpg", "quality": float64(20)}); strings.HasPrefix(out, "ERR") {
		t.Fatal(out)
	}
	run(t, it, Args{"action": "rotate", "path": "pic.png", "degrees": float64(90), "to": "r.png"})
	if out := run(t, it, Args{"action": "info", "path": "r.png"}); !strings.Contains(out, "100x200") {
		t.Fatal(out)
	}
	run(t, it, Args{"action": "crop", "path": "pic.png", "width": float64(40), "height": float64(30), "x": float64(10), "y": float64(5), "to": "c.png"})
	if out := run(t, it, Args{"action": "info", "path": "c.png"}); !strings.Contains(out, "40x30") {
		t.Fatal(out)
	}
	if out := run(t, it, Args{"action": "resize", "path": "pic.png", "to": "pic.png", "width": float64(10)}); !strings.HasPrefix(out, "ERR") {
		t.Fatal("overwrote the original:", out)
	}
	if out := run(t, it, Args{"action": "convert", "path": "pic.png"}); !strings.HasPrefix(out, "ERR") {
		t.Fatal(out)
	}
}

func TestSeeImageSendsThePictureAndTheQuestion(t *testing.T) {
	var body string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		raw, _ := io.ReadAll(r.Body)
		body = string(raw)
		w.Header().Set("Content-Type", "application/json")
		w.Write([]byte(`{"choices":[{"message":{"role":"assistant","content":"красный квадрат с надписью STOP"}}]}`))
	}))
	defer srv.Close()
	d := ownerDeps(t, 5)
	client := llm.New(srv.URL+"/", srv.URL+"/", "", "m", "e", 5*time.Second)
	d.UI = &llmui.Env{LLM: client, TG: d.TG, Cfg: d.Cfg, Media: func() media.Services { return media.NewDisabled() }}
	writePNG(t, filepath.Join(d.workDir(), "s.png"), 20, 20)
	out := run(t, seeImageTool(d), Args{"path": "s.png", "question": "что написано?"})
	if !strings.Contains(out, "STOP") {
		t.Fatal(out)
	}
	if !strings.Contains(body, "data:image/png;base64,") || !strings.Contains(body, "что написано?") {
		t.Fatalf("the request lacks the picture or the question: %.300s", body)
	}
	if out := run(t, seeImageTool(d), Args{"path": "missing.png"}); !strings.HasPrefix(out, "ERR") {
		t.Fatal(out)
	}
	d.UI = nil
	if out := run(t, seeImageTool(d), Args{"path": "s.png"}); !strings.Contains(out, "no vision") {
		t.Fatal(out)
	}
}

func TestGit(t *testing.T) {
	needBin(t, "git")
	t.Setenv("GIT_AUTHOR_NAME", "T")
	t.Setenv("GIT_AUTHOR_EMAIL", "t@t")
	t.Setenv("GIT_COMMITTER_NAME", "T")
	t.Setenv("GIT_COMMITTER_EMAIL", "t@t")
	d := ownerDeps(t, 5)
	repo := filepath.Join(d.workDir(), "r")
	os.MkdirAll(repo, 0o755)
	if out, code := runBin(t.Context(), 30*time.Second, repo, nil, "git", "init", "-q"); code != 0 {
		t.Fatal(out)
	}
	gt := gitTool(d)
	run(t, filesTool(d), Args{"action": "write", "path": "r/a.txt", "text": "one"})
	if out := run(t, gt, Args{"action": "status", "dir": "r"}); !strings.Contains(out, "a.txt") {
		t.Fatal(out)
	}
	if out := run(t, gt, Args{"action": "commit", "dir": "r", "message": "first"}); !strings.Contains(out, "exit=0") {
		t.Fatal(out)
	}
	if out := run(t, gt, Args{"action": "log", "dir": "r"}); !strings.Contains(out, "first") {
		t.Fatal(out)
	}
	run(t, filesTool(d), Args{"action": "write", "path": "r/a.txt", "text": "two"})
	if out := run(t, gt, Args{"action": "diff", "dir": "r"}); !strings.Contains(out, "+two") {
		t.Fatal(out)
	}
	if out := run(t, gt, Args{"action": "commit", "dir": "r"}); !strings.HasPrefix(out, "ERR") {
		t.Fatal("empty message accepted:", out)
	}
	for _, u := range []string{"--upload-pack=touch /tmp/pwned", "file:///etc", "ext::sh -c id", ""} {
		if out := run(t, gt, Args{"action": "clone", "url": u}); !strings.HasPrefix(out, "ERR") {
			t.Fatalf("clone of %q allowed: %s", u, out)
		}
	}
	if out := run(t, gt, Args{"action": "branch", "dir": "r", "ref": "--detach"}); !strings.HasPrefix(out, "ERR") {
		t.Fatal(out)
	}
}

func TestMediaDownloadWithStub(t *testing.T) {
	bin := t.TempDir()
	d := ownerDeps(t, 5)
	// the stub writes the file where -o points and prints its path like yt-dlp's --print does
	script := "#!/bin/sh\nout=''\nwhile [ $# -gt 0 ]; do if [ \"$1\" = -o ]; then out=\"$2\"; fi; shift; done\nf=$(echo \"$out\" | sed 's/%(title).80B/clip/; s/%(ext)s/mp4/')\necho data > \"$f\"\necho \"$f\"\n"
	os.WriteFile(filepath.Join(bin, "yt-dlp"), []byte(script), 0o755)
	t.Setenv("PATH", bin+":"+os.Getenv("PATH"))
	mt := mediaDownloadTool(d)
	out := run(t, mt, Args{"url": "https://example.com/v"})
	if !strings.Contains(out, "downloaded: ") || !strings.Contains(out, "clip.mp4") {
		t.Fatal(out)
	}
	for _, bad := range []string{"file:///etc/passwd", "--exec=id", "ftp://x/y", ""} {
		if out := run(t, mt, Args{"url": bad}); !strings.HasPrefix(out, "ERR") {
			t.Fatalf("%q allowed: %s", bad, out)
		}
	}
}

func TestSQLiteIsReadOnly(t *testing.T) {
	needBin(t, "sqlite3")
	d := ownerDeps(t, 5)
	db := filepath.Join(d.workDir(), "t.db")
	if out, code := runBin(t.Context(), 20*time.Second, "", nil, "sqlite3", db, "create table u(id integer, name text); insert into u values (1,'Аня'),(2,'Боб');"); code != 0 {
		t.Fatal(out)
	}
	st := sqliteTool(d)
	if out := run(t, st, Args{"path": "t.db", "query": "select * from u order by id"}); !strings.Contains(out, "id,name") || !strings.Contains(out, "2,Боб") {
		t.Fatal(out)
	}
	for _, q := range []string{"delete from u", "select 1; drop table u", "insert into u values (3,'x')", ".shell id", "with x as (select 1) delete from u"} {
		if out := run(t, st, Args{"path": "t.db", "query": q}); !strings.HasPrefix(out, "ERR") {
			t.Fatalf("%q allowed: %s", q, out)
		}
	}
	if out := run(t, st, Args{"path": "t.db", "query": "select count(*) from u"}); !strings.Contains(out, "2") {
		t.Fatal("rows lost:", out)
	}
}

func TestSQLiteGuardsNeedNoBinary(t *testing.T) {
	d := ownerDeps(t, 5)
	os.WriteFile(filepath.Join(d.workDir(), "t.db"), []byte("x"), 0o644)
	st := sqliteTool(d)
	for _, q := range []string{"delete from u", "select 1; drop table u", "insert into u values (3,'x')", ".shell id", "with x as (select 1) delete from u", "attach database 'x' as y", "pragma writable_schema=1; drop table x"} {
		out := run(t, st, Args{"path": "t.db", "query": q})
		if !strings.HasPrefix(out, "ERR") || strings.Contains(out, "not installed") {
			t.Fatalf("%q was not refused by the guard: %s", q, out)
		}
	}
}
