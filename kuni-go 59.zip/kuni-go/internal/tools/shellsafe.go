package tools

import (
	"path/filepath"
	"regexp"
	"strings"
)

// Hard floor under the shell tool: whatever the model was told or tricked into, a few commands never run.
var (
	reRecursive = regexp.MustCompile(`(?:^|\s)(?:-[a-zA-Z]*[rR][a-zA-Z]*|--recursive)(?:\s|$)`)
	reBlocked   = []struct {
		re     *regexp.Regexp
		reason string
	}{
		{regexp.MustCompile(`(?i)\b(mkfs(\.\w+)?|wipefs|fdisk|sfdisk|parted|cryptsetup)\b`), "formatting or partitioning disks"},
		{regexp.MustCompile(`(?i)\bdd\b[^;&|]*\bof=/dev/`), "writing straight onto a device"},
		{regexp.MustCompile(`(?i)>\s*/dev/(sd|nvme|vd|mmcblk|hd)\w*`), "writing straight onto a device"},
		{regexp.MustCompile(`(?i)\bshred\b[^;&|]*/dev/`), "shredding a device"},
		{regexp.MustCompile(`:\(\)\s*\{[^}]*:\s*\|\s*:`), "a fork bomb"},
		{regexp.MustCompile(`(?i)(^|[;&|]\s*|\bsudo\s+)(shutdown|reboot|poweroff|halt)\b`), "shutting the machine down"},
		{regexp.MustCompile(`(?i)(^|[;&|]\s*)init\s+[06]\b`), "shutting the machine down"},
		{regexp.MustCompile(`(?i)\bkill(all)?\b[^;&|]*\s-?(9|KILL)\s+(-1|1)\b`), "killing init"},
		{regexp.MustCompile(`(?i)\bchmod\s+-[a-z]*R[a-z]*\s+[0-7]{3,4}\s+/\s*($|[;&|])`), "chmod on the whole filesystem"},
		{regexp.MustCompile(`(?i)\bchown\s+-[a-z]*R[a-z]*\s+\S+\s+/\s*($|[;&|])`), "chown on the whole filesystem"},
		{regexp.MustCompile(`(?i)\b(curl|wget)\b[^;&]*\|\s*(sudo\s+)?(ba|z|da|k)?sh\b`), "piping a download straight into a shell"},
	}
	protectedAlways = []string{"/", "/*", "/bin", "/sbin", "/lib", "/lib64", "/usr", "/etc", "/var", "/boot", "/root", "/home", "/opt",
		"/dev", "/proc", "/sys", "~", "~/", "$HOME", "${HOME}", "/mari"}
)

// ShellDanger returns why cmd must not run ("" = fine). protect lists extra directories (her data dir, her own
// folder) that a recursive rm must never hit.
func ShellDanger(cmd string, protect ...string) string {
	for _, b := range reBlocked {
		if b.re.MatchString(cmd) {
			return b.reason
		}
	}
	// split into simple commands and look at every `rm`
	for _, part := range regexp.MustCompile(`[;&|\n]+`).Split(cmd, -1) {
		f := strings.Fields(part)
		for len(f) > 0 && (f[0] == "sudo" || f[0] == "nohup" || f[0] == "time" || f[0] == "command") {
			f = f[1:]
		}
		if len(f) == 0 || filepath.Base(f[0]) != "rm" {
			continue
		}
		args := " " + strings.Join(f[1:], " ") + " "
		if !reRecursive.MatchString(args) {
			continue
		}
		for _, a := range f[1:] {
			if strings.HasPrefix(a, "-") {
				continue
			}
			clean := a
			if len(clean) > 1 {
				clean = strings.TrimRight(clean, "/")
			}
			for _, p := range protectedAlways {
				if clean == strings.TrimRight(p, "/") || clean == p || (p == "/" && a == "/") {
					return "recursive delete of " + a
				}
			}
			for _, p := range protect {
				if p != "" && (clean == strings.TrimRight(p, "/") || a == p) {
					return "recursive delete of her own data (" + a + ")"
				}
			}
		}
	}
	return ""
}
