package tools

import (
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"testing"
	"time"

	"kuni/internal/llm"
)

func TestDelegateRunsOnTheFastModelWithHerInstructions(t *testing.T) {
	var mu sync.Mutex
	var seen map[string]any
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		raw, _ := io.ReadAll(r.Body)
		mu.Lock()
		_ = json.Unmarshal(raw, &seen)
		mu.Unlock()
		json.NewEncoder(w).Encode(map[string]any{"choices": []any{map[string]any{"message": map[string]any{"role": "assistant", "content": "  Итог: три пункта.  "}}}})
	}))
	defer srv.Close()
	c := llm.New(srv.URL+"/", srv.URL+"/", "", "main-m", "e", 5*time.Second)
	c.Update(llm.Settings{BaseURL: srv.URL + "/", EmbeddingBaseURL: srv.URL + "/", Model: "main-m", FastModel: "quick-m"})
	d := ownerDeps(t, 100)
	d.LLM = c
	tl := DelegateTool(d)
	out := run(t, tl, Args{"instructions": "сократи до трёх пунктов", "material": "длинный текст про планировщик"})
	if out != "Итог: три пункта." {
		t.Fatal(out)
	}
	mu.Lock()
	defer mu.Unlock()
	if seen["model"] != "quick-m" {
		t.Fatalf("the helper must run on the fast model: %v", seen["model"])
	}
	body, _ := json.Marshal(seen["messages"])
	if !strings.Contains(string(body), "сократи до трёх пунктов") || !strings.Contains(string(body), "material") || !strings.Contains(string(body), "длинный текст") {
		t.Fatal(string(body))
	}
	if out := run(t, tl, Args{"instructions": "  "}); !strings.HasPrefix(out, "ERR") {
		t.Fatal(out)
	}
	d.LLM = nil
	if out := run(t, DelegateTool(d), Args{"instructions": "x"}); !strings.HasPrefix(out, "ERR") {
		t.Fatal(out)
	}
}
