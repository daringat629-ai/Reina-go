package tools

import (
	"context"
	"strings"
	"testing"

	"kuni/internal/config"
	"kuni/internal/prompts"
	"kuni/internal/telegram"
)

func peopleDeps(t *testing.T, papik int64) (Deps, *telegram.Fake) {
	f := telegram.NewFake()
	f.Me = 1
	f.Roster = map[int64][]telegram.Member{
		-10: {{ID: 5, Name: "Jaabir", Role: "owner"}, {ID: 1, Name: "Reina", Role: "admin"}, {ID: 9, Name: "Joe <b>", Username: "joe", Role: "member"}},
		-20: {{ID: 9, Name: "Other", Role: "member"}},
	}
	f.Users = map[int64]telegram.User{9: {ID: 9, Name: "Joe", Username: "joe", Bio: "plays guitar"}}
	c := &config.Config{DataDir: t.TempDir(), PapikChatID: papik, OwnerTools: true}
	ps, _ := prompts.NewStore(t.TempDir(), prompts.Vars{CharacterName: "Reina"})
	return Deps{RT: NewRuntime(nil), TG: f, Cfg: func() *config.Config { return c }, Prompts: ps}, f
}

func TestChatMembersMarksYouAndOwnerAndEscapes(t *testing.T) {
	d, _ := peopleDeps(t, 5)
	out, err := chatMembersTool(d, telegram.Chat{ID: -10, Kind: telegram.ChatGroup}).Run(context.Background(), Args{})
	if err != nil {
		t.Fatal(err)
	}
	for _, want := range []string{`user_id="5"`, `is_owner="true"`, `is_you="true"`, `role="admin"`, `@joe`, "Joe &lt;b&gt;"} {
		if !strings.Contains(out, want) {
			t.Fatalf("missing %q in:\n%s", want, out)
		}
	}
}

func TestChatMembersOtherChatOnlyForOwner(t *testing.T) {
	d, _ := peopleDeps(t, 5)
	if _, err := chatMembersTool(d, telegram.Chat{ID: -10, Kind: telegram.ChatGroup}).Run(context.Background(), Args{"chat_id": float64(-20)}); err == nil {
		t.Fatal("a group chat must not look into other chats")
	}
	out, err := chatMembersTool(d, telegram.Chat{ID: 5, Kind: telegram.ChatPrivate}).Run(context.Background(), Args{"chat_id": float64(-20)})
	if err != nil || !strings.Contains(out, "Other") {
		t.Fatalf("owner should: %q %v", out, err)
	}
}

func TestUserInfo(t *testing.T) {
	d, _ := peopleDeps(t, 5)
	out, err := userInfoTool(d).Run(context.Background(), Args{"user_id": float64(9)})
	if err != nil || !strings.Contains(out, "plays guitar") || !strings.Contains(out, "@joe") {
		t.Fatalf("%q %v", out, err)
	}
	if _, err := userInfoTool(d).Run(context.Background(), Args{"user_id": float64(404)}); err == nil {
		t.Fatal("unknown user must error")
	}
}

func TestGroupToolsIncludeMembersAndUserInfo(t *testing.T) {
	d, _ := peopleDeps(t, 5)
	r := ChatTools(d, telegram.Chat{ID: -10, Kind: telegram.ChatGroup, IsMember: true})
	if !r.Has("chat_members") || !r.Has("user_info") {
		t.Fatalf("group tools: %v", r.Names())
	}
}
