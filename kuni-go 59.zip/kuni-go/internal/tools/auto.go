package tools

import (
	"context"
	"errors"
)

// GoToSleepTool lets the character decide to sleep. Only offered when autonomy is on.
func GoToSleepTool(d Deps) Tool {
	return Tool{
		Name: "go_to_sleep",
		Description: "Go to sleep for a while when you are tired, it is late, or your mood is low. While you sleep you do not start conversations " +
			"on your own and your sleep consolidates memories; messages still reach you, but you are drowsy. Say goodnight first if you want to.",
		Props: []Prop{
			{Name: "minutes", Type: "integer", Desc: "How long, 20 to 720."},
			{Name: "reason", Type: "string", Nullable: true, Desc: "Few words why (for your own journal)."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			if d.GoToSleep == nil {
				return "", errors.New("sleeping is not available")
			}
			return d.GoToSleep(int(a.Int("minutes")), a.Str("reason")), nil
		},
	}
}
