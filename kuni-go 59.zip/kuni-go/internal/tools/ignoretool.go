package tools

import (
	"context"
	"fmt"
	"slices"
	"strings"
	"time"

	"kuni/internal/allow"
)

// ignoreTool: the owner (or she, on the owner's word) puts a chat or a person on the list she does not react to.
func ignoreTool(d Deps) Tool {
	return Tool{
		Name: "ignore",
		Description: "Ignore list (owner only): a chat or a person she does not react to at all — not read, no model call, no answer. " +
			"action add (kind chat|user, id, optional hours = for how long, 0 = until removed, optional name and note = why), remove, list. " +
			"Use it when the owner says to ignore/mute/shut out a person or a group, or someone keeps spamming her. " +
			"A person is ignored in every chat, a chat as a whole. The owner can never be ignored. Look the id up with search_chats or user_info first.",
		Props: []Prop{
			{Name: "action", Type: "string", Desc: "add | remove | list."},
			{Name: "kind", Type: "string", Nullable: true, Desc: "chat or user (default: chat for a negative id, user otherwise)."},
			{Name: "id", Type: "integer", Nullable: true, Desc: "Telegram chat id or user id."},
			{Name: "hours", Type: "number", Nullable: true, Desc: "Ignore for this many hours; empty or 0 = until removed."},
			{Name: "name", Type: "string", Nullable: true, Desc: "Whom, for the list."},
			{Name: "note", Type: "string", Nullable: true, Desc: "Why."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			if d.Ignore == nil {
				return "", fmt.Errorf("the ignore list is off")
			}
			act := strings.ToLower(strings.TrimSpace(a.Str("action")))
			if act == "list" || act == "" {
				es := d.Ignore.List()
				if len(es) == 0 {
					return "Nobody is ignored.", nil
				}
				var b strings.Builder
				for _, e := range es {
					fmt.Fprintf(&b, "%s %d", e.Kind, e.ID)
					if e.Name != "" {
						fmt.Fprintf(&b, " (%s)", e.Name)
					}
					if e.Until.IsZero() {
						b.WriteString(", until removed")
					} else {
						fmt.Fprintf(&b, ", until %s", e.Until.Format("02.01 15:04"))
					}
					if e.Note != "" {
						fmt.Fprintf(&b, " — %s", e.Note)
					}
					b.WriteString("\n")
				}
				return strings.TrimSpace(b.String()), nil
			}
			id := a.Int("id")
			if id == 0 {
				return "", fmt.Errorf("id is required")
			}
			kind := strings.ToLower(strings.TrimSpace(a.Str("kind")))
			if kind == "" {
				kind = "user"
				if id < 0 {
					kind = "chat"
				}
			}
			if kind != "chat" && kind != "user" {
				return "", fmt.Errorf("kind is chat or user")
			}
			switch act {
			case "add":
				if p := d.Cfg().PapikChatID; p != 0 && id == p {
					return "", fmt.Errorf("the owner cannot be ignored")
				}
				var dur time.Duration
				if h := a.Float("hours"); h > 0 {
					dur = time.Duration(h * float64(time.Hour))
				}
				e := d.Ignore.Add(kind, id, a.Str("name"), a.Str("note"), dur)
				if e.Until.IsZero() {
					return fmt.Sprintf("Now ignoring %s %d until removed.", kind, id), nil
				}
				return fmt.Sprintf("Now ignoring %s %d until %s.", kind, id, e.Until.Format("02.01 15:04")), nil
			case "remove":
				if d.Ignore.Remove(kind, id) {
					return fmt.Sprintf("%s %d is no longer ignored.", kind, id), nil
				}
				return "", fmt.Errorf("%s %d is not on the list", kind, id)
			}
			return "", fmt.Errorf("action is add, remove or list")
		},
	}
}

// MuteTool is her own way to shut out somebody who spams or pesters her: a person (never a chat), for a limited time.
func MuteTool(d Deps) Tool {
	return Tool{
		Name: "mute_person",
		Description: "Stop reacting to a person who keeps spamming, flooding or pestering you (the same thing again and again, bot-like junk, harassment). " +
			"From then on their messages are not read and cost nothing, in every chat. Warn them once first if it is a normal person. " +
			"It lasts hours (default 24, at most 168 = a week) and is on the owner's list, so he can lift it. Never for your owner.",
		Props: []Prop{
			{Name: "user_id", Type: "integer", Desc: "The sender's Telegram user id (see sender ids in the chat / #chat_members / #user_info)."},
			{Name: "hours", Type: "number", Nullable: true, Desc: "For how long; default 24, maximum 168."},
			{Name: "reason", Type: "string", Nullable: true, Desc: "One short line why."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			if d.Ignore == nil {
				return "", fmt.Errorf("the ignore list is off")
			}
			id := a.Int("user_id")
			if id <= 0 {
				return "", fmt.Errorf("user_id is required")
			}
			if p := d.Cfg().PapikChatID; p != 0 && id == p {
				return "", fmt.Errorf("never your owner")
			}
			if d.TG != nil && id == d.TG.MyID() {
				return "", fmt.Errorf("that is you")
			}
			h := a.Float("hours")
			if h <= 0 {
				h = 24
			}
			h = min(h, 168)
			note := strings.TrimSpace(a.Str("reason"))
			if note == "" {
				note = "spam"
			}
			e := d.Ignore.Add("user", id, "", "muted by her: "+note, time.Duration(h*float64(time.Hour)))
			return fmt.Sprintf("Muted user %d until %s. Their messages will not reach you.", id, e.Until.Format("02.01 15:04")), nil
		},
	}
}

// commandUsersTool edits the white list of people who may use her slash commands.
func commandUsersTool(d Deps) Tool {
	return Tool{
		Name: "command_users",
		Description: "White list of people (besides the owner) who may use her slash commands in Telegram: /help /status /usage /pause /resume /stop, in a private chat with her. " +
			"Never /work and /backup: those stay the owner's. action add (user_id, optional name), remove (user_id), list. Ids typed by hand in config.toml (telegram.command_users) count too. " +
			"Use it when the owner says to let somebody control her or to take that away. Find the id with search_chats / user_info.",
		Props: []Prop{
			{Name: "action", Type: "string", Desc: "add | remove | list."},
			{Name: "user_id", Type: "integer", Nullable: true, Desc: "Telegram user id."},
			{Name: "name", Type: "string", Nullable: true, Desc: "Whom, for the list."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			if d.Allow == nil {
				return "", fmt.Errorf("the command white list is off")
			}
			switch strings.ToLower(strings.TrimSpace(a.Str("action"))) {
			case "list", "":
				var lines []string
				for _, e := range d.Allow.List() {
					l := fmt.Sprintf("%d", e.ID)
					if e.Name != "" {
						l += " (" + e.Name + ")"
					}
					lines = append(lines, l)
				}
				for _, id := range allow.ParseIDs(d.Cfg().CommandUsers) {
					lines = append(lines, fmt.Sprintf("%d (config.toml)", id))
				}
				if len(lines) == 0 {
					return "Only the owner may use commands.", nil
				}
				return "May use commands: " + strings.Join(lines, ", "), nil
			case "add":
				id := a.Int("user_id")
				if id <= 0 {
					return "", fmt.Errorf("user_id is required (a person, not a group)")
				}
				d.Allow.Add(id, a.Str("name"))
				return fmt.Sprintf("User %d may now use /help /status /usage /pause /resume /stop in a private chat with you.", id), nil
			case "remove":
				id := a.Int("user_id")
				if d.Allow.Remove(id) {
					return fmt.Sprintf("User %d may no longer use commands.", id), nil
				}
				if slices.Contains(allow.ParseIDs(d.Cfg().CommandUsers), id) {
					return "", fmt.Errorf("that id is written in config.toml (telegram.command_users): the owner has to remove it there")
				}
				return "", fmt.Errorf("user %d is not on the list", id)
			}
			return "", fmt.Errorf("action is add, remove or list")
		},
	}
}
