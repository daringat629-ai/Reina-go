package tools

import (
	"testing"
	"time"
)

func TestTalkLogRemembersRepliesAcrossTurnsForAWhile(t *testing.T) {
	var l talkLog
	now := time.Now()
	if l.seen(1, 7, now) {
		t.Fatal("nothing replied yet")
	}
	l.mark(1, 7, now)
	if !l.seen(1, 7, now.Add(time.Minute)) {
		t.Fatal("a reply must be remembered")
	}
	if l.seen(2, 7, now) || l.seen(1, 8, now) {
		t.Fatal("other chat or message must be free")
	}
	if l.seen(1, 7, now.Add(repliedTTL+time.Second)) {
		t.Fatal("it must be forgotten after a while")
	}
}
