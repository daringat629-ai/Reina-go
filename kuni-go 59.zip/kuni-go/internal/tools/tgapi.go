package tools

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	"kuni/internal/llmui"
	"kuni/internal/telegram"
)

// tgAPITool gives the owner's chat the whole Telegram toolbox for ANY chat in one tool, so it costs one schema in the prompt.
func tgAPITool(d Deps) Tool {
	return Tool{
		Name: "tg_api",
		Description: "Everything Telegram can do, in ANY chat (owner only, ignores lockdown). action: " +
			"history(chat, limit, message_id = read older messages before this id, repeat with the oldest id to read a whole chat) | around(chat, message_id) | " +
			"search(query, chat optional, user_id optional, limit) | chat_info(chat) | members(chat) | user(user_id) | " +
			"send(chat, text, message_id = reply to) | send_file(chat, path, text = caption) | send_photo(chat, path, text = caption) | " +
			"edit(chat, message_id, text) | delete(chat, message_id) | forward(chat, message_id, to) | react(chat, message_id, emoji) | pin / unpin(chat, message_id) | " +
			"read(chat) = mark as read | leave(chat) | ban(chat, user_id). 'chat' is an id, @username or part of the name.",
		Props: []Prop{
			{Name: "action", Type: "string", Desc: "One of the actions listed above."},
			{Name: "chat", Type: "string", Nullable: true, Desc: "Chat id, @username or part of the chat name."},
			{Name: "message_id", Type: "integer", Nullable: true, Desc: "Message id."},
			{Name: "user_id", Type: "integer", Nullable: true, Desc: "User id."},
			{Name: "text", Type: "string", Nullable: true, Desc: "Text / caption / new text."},
			{Name: "query", Type: "string", Nullable: true, Desc: "Search text."},
			{Name: "path", Type: "string", Nullable: true, Desc: "File in your workspace to send."},
			{Name: "to", Type: "string", Nullable: true, Desc: "forward: destination chat."},
			{Name: "emoji", Type: "string", Nullable: true, Desc: "react: one emoji."},
			{Name: "limit", Type: "integer", Nullable: true, Desc: "How many results (history max 100, search max 50)."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			act := strings.ToLower(strings.TrimSpace(a.Str("action")))
			ctx = telegram.NoThread(ctx)
			now := time.Now()
			needChat := func() (int64, error) {
				if strings.TrimSpace(a.Str("chat")) == "" {
					return 0, fmt.Errorf("%s needs chat", act)
				}
				return resolveChat(ctx, d, a.Str("chat"))
			}
			needMsg := func() (int64, error) {
				if a.Int("message_id") == 0 {
					return 0, fmt.Errorf("%s needs message_id", act)
				}
				return a.Int("message_id"), nil
			}
			limit := int(a.Int("limit"))
			switch act {
			case "history", "around":
				id, err := needChat()
				if err != nil {
					return "", err
				}
				n := limit
				if n <= 0 {
					n = 30
				}
				if n > 100 {
					n = 100
				}
				var msgs []telegram.Message
				switch {
				case act == "around":
					mid, err := needMsg()
					if err != nil {
						return "", err
					}
					if n > 30 {
						n = 30
					}
					msgs, err = d.TG.History(ctx, id, mid, n, n)
					if err != nil {
						return "", err
					}
				default:
					msgs, err = d.TG.History(ctx, id, a.Int("message_id"), n, 0)
					if err != nil {
						return "", err
					}
				}
				if len(msgs) == 0 {
					return "No messages", nil
				}
				out := Truncate(d.UI.FormatMessages(ctx, msgs, now), 14000)
				if act == "history" {
					out += fmt.Sprintf("\n(oldest message_id here: %d — pass it as message_id to read further back)", oldestID(msgs))
				}
				return out, nil
			case "search":
				q := telegram.SearchQuery{Text: strings.TrimSpace(a.Str("query")), SenderID: a.Int("user_id"), Limit: limit}
				if q.Text == "" {
					return "", fmt.Errorf("search needs query")
				}
				if q.Limit <= 0 || q.Limit > 50 {
					q.Limit = 20
				}
				if strings.TrimSpace(a.Str("chat")) != "" {
					id, err := needChat()
					if err != nil {
						return "", err
					}
					q.ChatID = id
				}
				msgs, err := d.TG.Search(ctx, q)
				if err != nil {
					return "", err
				}
				if len(msgs) == 0 {
					return "Nothing found", nil
				}
				return Truncate(d.UI.FormatMessages(ctx, msgs, now), 12000), nil
			case "chat_info":
				id, err := needChat()
				if err != nil {
					return "", err
				}
				c, err := d.TG.Chat(ctx, id)
				if err != nil {
					return "", err
				}
				return llmui.FormatChat(c, now), nil
			case "members":
				id, err := needChat()
				if err != nil {
					return "", err
				}
				ms, err := d.TG.Members(ctx, id, 100)
				if err != nil {
					return "", err
				}
				var b strings.Builder
				for _, m := range ms {
					b.WriteString(llmui.FormatMember(m, d.TG.MyID(), d.Cfg().PapikChatID) + "\n")
				}
				if b.Len() == 0 {
					return "No members visible", nil
				}
				return b.String(), nil
			case "user":
				if a.Int("user_id") == 0 {
					return "", fmt.Errorf("user needs user_id")
				}
				u, err := d.TG.UserInfo(ctx, a.Int("user_id"))
				if err != nil {
					return "", err
				}
				return llmui.FormatUser(u, d.TG.MyID(), d.Cfg().PapikChatID), nil
			case "send", "send_file", "send_photo":
				id, err := needChat()
				if err != nil {
					return "", err
				}
				text := strings.TrimSpace(a.Str("text"))
				if act == "send" {
					if text == "" {
						return "", fmt.Errorf("send needs text")
					}
					m, err := d.TG.SendText(ctx, id, text, a.Int("message_id"))
					if err != nil {
						return "", err
					}
					return fmt.Sprintf("sent to chat %d (message_id %d)", id, m.ID), nil
				}
				p := strings.TrimSpace(a.Str("path"))
				if p == "" {
					return "", fmt.Errorf("%s needs path", act)
				}
				if !filepath.IsAbs(p) {
					p = filepath.Join(d.workDir(), p)
				}
				data, err := os.ReadFile(p)
				if err != nil {
					return "", err
				}
				if act == "send_photo" {
					_, err = d.TG.SendPhoto(ctx, id, data, text, a.Int("message_id"))
				} else {
					_, err = d.TG.SendDocument(ctx, id, filepath.Base(p), data, text, a.Int("message_id"))
				}
				if err != nil {
					return "", err
				}
				return fmt.Sprintf("%s sent to chat %d", filepath.Base(p), id), nil
			case "edit", "delete", "forward", "react", "pin", "unpin":
				id, err := needChat()
				if err != nil {
					return "", err
				}
				mid, err := needMsg()
				if err != nil {
					return "", err
				}
				switch act {
				case "edit":
					err = d.TG.Edit(ctx, id, mid, a.Str("text"))
				case "delete":
					err = d.TG.Delete(ctx, id, mid)
				case "forward":
					var to int64
					if to, err = resolveChat(ctx, d, a.Str("to")); err == nil {
						err = d.TG.Forward(ctx, id, mid, to)
					}
				case "react":
					err = d.TG.React(ctx, id, mid, a.Str("emoji"))
				case "pin":
					err = d.TG.Pin(ctx, id, mid, true)
				case "unpin":
					err = d.TG.Unpin(ctx, id, mid)
				}
				if err != nil {
					return "", err
				}
				return act + " done", nil
			case "read":
				id, err := needChat()
				if err != nil {
					return "", err
				}
				return "marked as read", d.TG.MarkRead(ctx, id)
			case "leave":
				id, err := needChat()
				if err != nil {
					return "", err
				}
				return "left chat", d.TG.Leave(ctx, id)
			case "ban":
				id, err := needChat()
				if err != nil {
					return "", err
				}
				if a.Int("user_id") == 0 {
					return "", fmt.Errorf("ban needs user_id")
				}
				return "banned", d.TG.Ban(ctx, id, a.Int("user_id"), false)
			}
			return "", fmt.Errorf("unknown action %q", act)
		},
	}
}

func oldestID(msgs []telegram.Message) int64 {
	var min int64
	for _, m := range msgs {
		if m.ID != 0 && (min == 0 || m.ID < min) {
			min = m.ID
		}
	}
	return min
}
