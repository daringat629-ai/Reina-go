package tools

import (
	"bufio"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/url"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"time"

	"kuni/internal/config"
	"kuni/internal/maint"
	"kuni/internal/update"
)

// sys_admin.go: calculator, remote machines, transcription, document conversion, backups, her own log, her own settings,
// searching inside files.

func calcTool(d Deps) Tool {
	return Tool{
		Name:        "calc",
		Description: "Exact calculator (owner only) for anything with numbers: + - * / % ^ and brackets, 15% (percent), pi, e, sqrt abs sin cos tan ln log log2 exp floor ceil round cbrt fact min max pow. Never do long arithmetic in your head: use this. Decimal comma works (0,5); separate function arguments with ; or \", \". Example: 1250*1.12^3 - 400.",
		Props:       []Prop{{Name: "expression", Type: "string", Desc: "The expression."}},
		Run: func(ctx context.Context, a Args) (string, error) {
			e := strings.TrimSpace(a.Str("expression"))
			if e == "" {
				return "", fmt.Errorf("empty expression")
			}
			v, err := evalExpr(e)
			if err != nil {
				return "", err
			}
			return e + " = " + formatNum(v), nil
		},
	}
}

var reHost = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9_.@:-]{0,120}$`)

func sshTool(d Deps) Tool {
	return Tool{
		Name: "ssh",
		Description: "Run a command on ANOTHER machine over ssh (owner only): the host of your container, a server, a Raspberry. host is user@address or an alias from ~/.ssh/config. Works only with keys already set up (no passwords asked). " +
			"Use it when the owner wants something done outside your own box, e.g. memory limits of your container on its host.",
		Props: []Prop{
			{Name: "host", Type: "string", Desc: "user@address or a ~/.ssh/config alias."},
			{Name: "command", Type: "string", Desc: "Command line to run there."},
			{Name: "timeout_secs", Type: "integer", Nullable: true, Desc: "Default 60, max 600."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			bin, ok := findBin("ssh")
			if !ok {
				return "", fmt.Errorf("ssh is not installed (apk add openssh-client)")
			}
			host, cmd := strings.TrimSpace(a.Str("host")), strings.TrimSpace(a.Str("command"))
			if !reHost.MatchString(host) {
				return "", fmt.Errorf("bad host")
			}
			if cmd == "" {
				return "", fmt.Errorf("empty command")
			}
			if why := d.shellDanger(cmd); why != "" {
				d.journal("BLOCKED ssh ("+why+") "+host+": "+cmd, -2)
				return "Blocked: " + why + ". This never runs from here, not even on another machine.", nil
			}
			to := a.Int("timeout_secs")
			if to <= 0 {
				to = 60
			}
			if to > 600 {
				to = 600
			}
			d.journal("ssh "+host+": "+cmd, 0)
			out, code := runBin(ctx, time.Duration(to)*time.Second, "", nil, bin,
				"-o", "BatchMode=yes", "-o", "ConnectTimeout=10", "-o", "StrictHostKeyChecking=accept-new", "-o", "LogLevel=ERROR", "--", host, cmd)
			return fmt.Sprintf("exit=%d\n%s", code, Truncate(out, maxOut)), nil
		},
	}
}

var audioOK = map[string]bool{".mp3": true, ".m4a": true, ".wav": true, ".ogg": true, ".oga": true, ".opus": true, ".flac": true, ".webm": true}

func transcribeTool(d Deps) Tool {
	return Tool{
		Name:        "transcribe",
		Description: "Turn speech from an audio or video file on your machine into text (owner only): a voice recording, a lecture, a video call, a downloaded video. Long files are cut down to speech-only audio first. Needs ffmpeg for video and for files over 20 MB.",
		Props: []Prop{
			{Name: "path", Type: "string", Desc: "Audio or video file."},
			{Name: "language", Type: "string", Nullable: true, Desc: "Language hint like ru or en (empty = detect)."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			if d.Media == nil {
				return "", fmt.Errorf("speech recognition is not set up")
			}
			p := d.resolvePath(a.Str("path"))
			st, err := os.Stat(p)
			if err != nil {
				return "", err
			}
			if st.IsDir() {
				return "", fmt.Errorf("it is a folder")
			}
			ext := strings.ToLower(filepath.Ext(p))
			name := filepath.Base(p)
			var data []byte
			if audioOK[ext] && st.Size() <= 20<<20 {
				if data, err = os.ReadFile(p); err != nil {
					return "", err
				}
			} else {
				ff, ok := findBin("ffmpeg")
				if !ok {
					return "", fmt.Errorf("this file needs ffmpeg to be converted first (apk add ffmpeg)")
				}
				tmp := filepath.Join(d.workDir(), fmt.Sprintf(".stt-%d.mp3", time.Now().UnixNano()))
				defer os.Remove(tmp)
				if out, code := runBin(ctx, 10*time.Minute, "", nil, ff, "-y", "-loglevel", "error", "-i", p, "-vn", "-ac", "1", "-ar", "16000", "-b:a", "32k", tmp); code != 0 {
					return "", fmt.Errorf("ffmpeg could not read it: %s", Truncate(strings.TrimSpace(out), 300))
				}
				if data, err = os.ReadFile(tmp); err != nil {
					return "", err
				}
				if len(data) > 24<<20 {
					return "", fmt.Errorf("after conversion it is still %d MB: cut the file into pieces first (ffmpeg -t / -ss)", len(data)>>20)
				}
				name = strings.TrimSuffix(name, ext) + ".mp3"
			}
			text, err := d.Media().STT.Transcribe(ctx, data, name)
			if err != nil {
				return "", err
			}
			text = strings.TrimSpace(text)
			if text == "" {
				return "(no speech recognised)", nil
			}
			return "<transcript>\n" + Truncate(text, 14000) + "\n</transcript>", nil
		},
	}
}

func convertDocTool(d Deps) Tool {
	return Tool{
		Name: "convert_doc",
		Description: "Convert a document to another format (owner only): docx, odt, pdf, html, txt, md, xlsx, csv, pptx... Uses pandoc and/or LibreOffice when installed. Markdown or text to a PDF or Word file is the usual use: write the text with files(write), convert, then send_file. " +
			"The result lands next to the original.",
		Props: []Prop{
			{Name: "path", Type: "string", Desc: "The source file."},
			{Name: "to", Type: "string", Desc: "Target format by extension: pdf, docx, odt, html, txt, md, xlsx, csv, pptx, epub."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			src := d.resolvePath(a.Str("path"))
			if _, err := os.Stat(src); err != nil {
				return "", err
			}
			to := strings.ToLower(strings.TrimPrefix(strings.TrimSpace(a.Str("to")), "."))
			if !regexp.MustCompile(`^[a-z0-9]{2,5}$`).MatchString(to) {
				return "", fmt.Errorf("`to` is a format like pdf or docx")
			}
			from := strings.ToLower(strings.TrimPrefix(filepath.Ext(src), "."))
			if from == to {
				return "", fmt.Errorf("it is already %s", to)
			}
			dst := strings.TrimSuffix(src, filepath.Ext(src)) + "." + to
			pandoc, hasPandoc := findBin("pandoc")
			office, hasOffice := findBin("soffice", "libreoffice")
			textual := map[string]bool{"md": true, "markdown": true, "rst": true, "org": true, "tex": true, "txt": false}
			pandocTargets := map[string]bool{"docx": true, "odt": true, "html": true, "epub": true, "md": true, "txt": true, "rst": true, "pptx": true}
			run1 := func(bin string, args ...string) error {
				out, code := runBin(ctx, 5*time.Minute, filepath.Dir(src), nil, bin, args...)
				if code != 0 {
					return fmt.Errorf("%s failed: %s", filepath.Base(bin), Truncate(strings.TrimSpace(out), 400))
				}
				return nil
			}
			var err error
			switch {
			case hasPandoc && textual[from] && pandocTargets[to]:
				err = run1(pandoc, src, "-o", dst)
			case hasPandoc && hasOffice && textual[from] && to == "pdf":
				tmp := strings.TrimSuffix(src, filepath.Ext(src)) + ".tmp-conv.html"
				defer os.Remove(tmp)
				if err = run1(pandoc, src, "-s", "-o", tmp); err == nil {
					if err = run1(office, "--headless", "--convert-to", "pdf", "--outdir", filepath.Dir(src), tmp); err == nil {
						err = os.Rename(strings.TrimSuffix(tmp, ".html")+".pdf", dst)
					}
				}
			case hasOffice:
				err = run1(office, "--headless", "--convert-to", to, "--outdir", filepath.Dir(src), src)
			case hasPandoc && pandocTargets[to]:
				err = run1(pandoc, src, "-o", dst)
			default:
				return "", fmt.Errorf("no converter for %s -> %s here: install pandoc and/or libreoffice (apk add pandoc libreoffice)", from, to)
			}
			if err != nil {
				return "", err
			}
			if _, e := os.Stat(dst); e != nil {
				return "", fmt.Errorf("the converter ran but %s did not appear", filepath.Base(dst))
			}
			return fmt.Sprintf("%s (%s)", dst, sizeOf(dst)), nil
		},
	}
}

func backupTool(d Deps) Tool {
	return Tool{
		Name:        "backup",
		Description: "Backups of your memory, settings and data (owner only): now (make one on disk and keep the last few) or list (what exists and how big). Send a backup to the owner with send_file. Restoring is done by the owner by hand.",
		Props:       []Prop{{Name: "action", Type: "string", Desc: "now or list."}},
		Run: func(ctx context.Context, a Args) (string, error) {
			c := d.Cfg()
			dir := maint.BackupDirOf(c)
			switch strings.ToLower(strings.TrimSpace(a.Str("action"))) {
			case "now":
				keep := c.BackupKeep
				if keep <= 0 {
					keep = 7
				}
				p, err := maint.Backup(maint.Sources(c, d.ConfigPath), dir, keep, time.Now())
				if err != nil {
					return "", err
				}
				return fmt.Sprintf("backup created: %s (%s); it lies on the same disk, send_file can pass a copy to the owner", p, sizeOf(p)), nil
			case "list", "":
				bs := maint.Backups(dir)
				if len(bs) == 0 {
					return "no backups yet in " + dir, nil
				}
				var b strings.Builder
				for _, x := range bs {
					fmt.Fprintf(&b, "%s  %s  %s\n", filepath.Join(dir, x.Name), humanSize(x.Size), x.Time.Format("02.01 15:04"))
				}
				return b.String(), nil
			}
			return "", fmt.Errorf("action must be now or list")
		},
	}
}

func tailLogTool(d Deps) Tool {
	return Tool{
		Name:        "tail_log",
		Description: "Read the end of a log file (owner only), by default your own program log (reina.log): what you did, what failed, which errors came from Telegram or the model. Use it to find out why something broke before you guess. `pattern` keeps only matching lines (regular expression, e.g. error|fail|panic). Any other log or text file works through `path`.",
		Props: []Prop{
			{Name: "path", Type: "string", Nullable: true, Desc: "File (default: your own log)."},
			{Name: "lines", Type: "integer", Nullable: true, Desc: "How many last lines, default 60, max 400."},
			{Name: "pattern", Type: "string", Nullable: true, Desc: "Only lines matching this regular expression (case-insensitive)."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			p := strings.TrimSpace(a.Str("path"))
			if p == "" {
				dir := d.UpdateDir
				if dir == "" {
					dir = update.Dir()
				}
				p = filepath.Join(dir, "reina.log")
			} else {
				p = d.resolvePath(p)
			}
			n := int(a.Int("lines"))
			if n <= 0 {
				n = 60
			}
			if n > 400 {
				n = 400
			}
			var re *regexp.Regexp
			if pat := strings.TrimSpace(a.Str("pattern")); pat != "" {
				var err error
				if re, err = regexp.Compile("(?i)" + pat); err != nil {
					return "", fmt.Errorf("bad pattern: %v", err)
				}
			}
			f, err := os.Open(p)
			if err != nil {
				return "", err
			}
			defer f.Close()
			st, _ := f.Stat()
			const window = 1 << 20 // the last megabyte is plenty
			if st != nil && st.Size() > window {
				if _, err := f.Seek(st.Size()-window, io.SeekStart); err != nil {
					return "", err
				}
			}
			sc := bufio.NewScanner(f)
			sc.Buffer(make([]byte, 64<<10), 1<<20)
			var ring []string
			for sc.Scan() {
				line := sc.Text()
				if re != nil && !re.MatchString(line) {
					continue
				}
				if len(line) > 400 {
					line = line[:400] + "…"
				}
				ring = append(ring, line)
				if len(ring) > n {
					ring = ring[1:]
				}
			}
			if len(ring) == 0 {
				return "(no lines" + map[bool]string{true: " match", false: ""}[re != nil] + " in " + p + ")", nil
			}
			return Truncate(strings.Join(ring, "\n"), 9000), nil
		},
	}
}

// settings she must never change herself: they would lock the owner out, widen her own powers or break the connection.
var lockedSettings = map[string]bool{
	"general.papik_chat_id": true, "telegram.lockdown": true, "telegram.api_id": true, "capabilities.owner_tools": true,
	"capabilities.shell_user": true, "capabilities.shell_hard_block": true, "proxy.enabled": true, "proxy.port": true,
	"llm.base_url": true, "llm.model": true, "llm.light_base_url": true, "llm.light_model": true, "llm.fallback_model": true, "llm.fallback_base_url": true, "llm.vision_model": true, "misc.admin_token": true, "world.key": true,
}

func settingsTool(d Deps) Tool {
	return Tool{
		Name: "settings",
		Description: "Your own settings (config.toml), owner only. Actions: search (text -> matching keys with current values), get (key like llm.fast_rounds), set (key + value). Changes apply in a couple of seconds, a copy of the old file is kept. " +
			"Use it when the owner says 'отвечай быстрее / печатай дольше / включи или выключи ...'. Secrets (keys, tokens, passwords) and the settings that guard the owner's control are not readable or changeable here.",
		Props: []Prop{
			{Name: "action", Type: "string", Desc: "search, get or set."},
			{Name: "key", Type: "string", Nullable: true, Desc: "section.name, for example llm.fast_rounds."},
			{Name: "value", Type: "string", Nullable: true, Desc: "set: the new value (true/false, a number or text)."},
			{Name: "text", Type: "string", Nullable: true, Desc: "search: words to look for in names and descriptions."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			c := d.Cfg()
			keys := config.Keys()
			find := func(k string) (config.Key, error) {
				sec, name, ok := strings.Cut(strings.TrimSpace(k), ".")
				if !ok {
					return config.Key{}, fmt.Errorf("the key must look like section.name")
				}
				for _, x := range keys {
					if x.Section == sec && x.Name == name {
						return x, nil
					}
				}
				return config.Key{}, fmt.Errorf("no such setting %q: use search", k)
			}
			switch strings.ToLower(strings.TrimSpace(a.Str("action"))) {
			case "search":
				q := strings.ToLower(strings.TrimSpace(a.Str("text")))
				if q == "" {
					return "", fmt.Errorf("what to look for?")
				}
				var b strings.Builder
				n := 0
				for _, k := range keys {
					if k.Secret || lockedSettings[k.Section+"."+k.Name] {
						continue
					}
					if strings.Contains(strings.ToLower(k.Section+"."+k.Name+" "+k.Comment), q) {
						fmt.Fprintf(&b, "%s.%s = %s — %s\n", k.Section, k.Name, c.Value(k.Section, k.Name), Truncate(k.Comment, 160))
						if n++; n >= 12 {
							b.WriteString("…(more: narrow the search)\n")
							break
						}
					}
				}
				if b.Len() == 0 {
					return "nothing found", nil
				}
				return b.String(), nil
			case "get":
				k, err := find(a.Str("key"))
				if err != nil {
					return "", err
				}
				if k.Secret || lockedSettings[k.Section+"."+k.Name] {
					return "", fmt.Errorf("this one is not shown here")
				}
				return fmt.Sprintf("%s.%s = %s\n%s", k.Section, k.Name, c.Value(k.Section, k.Name), k.Comment), nil
			case "set":
				k, err := find(a.Str("key"))
				if err != nil {
					return "", err
				}
				full := k.Section + "." + k.Name
				if k.Secret || lockedSettings[full] {
					return "Blocked: " + full + " guards the owner's control or holds a secret. Only he can change it, in the panel or the file.", nil
				}
				if d.ConfigPath == "" {
					return "", fmt.Errorf("the config file is not known to me")
				}
				old := c.Value(k.Section, k.Name)
				if err := config.SetKey(d.ConfigPath, k.Section, k.Name, a.Str("value")); err != nil {
					return "", err
				}
				d.journal("settings: "+full+" "+old+" -> "+a.Str("value"), 0)
				return fmt.Sprintf("%s: %q -> %q. It applies in a couple of seconds (a copy of the old file: %s.bak).", full, old, a.Str("value"), filepath.Base(d.ConfigPath)), nil
			}
			return "", fmt.Errorf("action must be search, get or set")
		},
	}
}

var skipDirs = map[string]bool{".git": true, "node_modules": true, ".cache": true, "__pycache__": true, ".venv": true, "venv": true}

func grepTool(d Deps) Tool {
	return Tool{
		Name:        "grep",
		Description: "Search INSIDE files (owner only): the lines that match a regular expression, in a file or a whole folder, as path:line: text. For code, notes, logs, configs. `glob` limits file names (*.go, *.md). Skips binaries, files over 2 MB, .git and node_modules. To search file NAMES use files(find).",
		Props: []Prop{
			{Name: "pattern", Type: "string", Desc: "Regular expression (Go syntax)."},
			{Name: "path", Type: "string", Nullable: true, Desc: "File or folder, default your workspace."},
			{Name: "glob", Type: "string", Nullable: true, Desc: "File name pattern like *.py."},
			{Name: "ignore_case", Type: "boolean", Nullable: true, Desc: "Ignore case."},
			{Name: "max_results", Type: "integer", Nullable: true, Desc: "Default 40, max 150."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			pat := a.Str("pattern")
			if pat == "" {
				return "", fmt.Errorf("empty pattern")
			}
			if a.Bool("ignore_case") {
				pat = "(?i)" + pat
			}
			re, err := regexp.Compile(pat)
			if err != nil {
				return "", fmt.Errorf("bad pattern: %v", err)
			}
			root := d.workDir()
			if s := strings.TrimSpace(a.Str("path")); s != "" {
				root = d.resolvePath(s)
			}
			max := int(a.Int("max_results"))
			if max <= 0 {
				max = 40
			}
			if max > 150 {
				max = 150
			}
			glob := strings.TrimSpace(a.Str("glob"))
			var out []string
			files := 0
			deadline := time.Now().Add(25 * time.Second)
			scan := func(p string) {
				f, err := os.Open(p)
				if err != nil {
					return
				}
				defer f.Close()
				head := make([]byte, 512)
				n, _ := f.Read(head)
				if strings.IndexByte(string(head[:n]), 0) >= 0 {
					return // binary
				}
				_, _ = f.Seek(0, io.SeekStart)
				files++
				sc := bufio.NewScanner(f)
				sc.Buffer(make([]byte, 64<<10), 1<<20)
				for ln := 1; sc.Scan(); ln++ {
					if re.MatchString(sc.Text()) {
						t := sc.Text()
						if len(t) > 300 {
							t = t[:300] + "…"
						}
						out = append(out, fmt.Sprintf("%s:%d: %s", p, ln, strings.TrimSpace(t)))
						if len(out) >= max {
							return
						}
					}
				}
			}
			st, err := os.Stat(root)
			if err != nil {
				return "", err
			}
			if !st.IsDir() {
				scan(root)
			} else {
				_ = filepath.WalkDir(root, func(p string, e os.DirEntry, err error) error {
					if err != nil || len(out) >= max || time.Now().After(deadline) || ctx.Err() != nil {
						return filepath.SkipAll
					}
					if e.IsDir() {
						if skipDirs[e.Name()] {
							return filepath.SkipDir
						}
						return nil
					}
					if !e.Type().IsRegular() {
						return nil
					}
					if glob != "" {
						if ok, _ := filepath.Match(glob, e.Name()); !ok {
							return nil
						}
					}
					if info, err := e.Info(); err != nil || info.Size() > 2<<20 {
						return nil
					}
					scan(p)
					return nil
				})
			}
			if len(out) == 0 {
				return fmt.Sprintf("no matches (looked in %d files)", files), nil
			}
			note := ""
			if len(out) >= max {
				note = "\n…(stopped at the limit: narrow the search)"
			}
			return Truncate(strings.Join(out, "\n"), maxOut+3000) + note, nil
		},
	}
}

// ---- more lookups: encyclopedia, GitHub, who owns an address ----

var (
	wikiBase   = "https://%s.wikipedia.org"
	githubBase = "https://api.github.com"
	geoipBase  = "https://ipwho.is"
)

func lookupMore(ctx context.Context, kind, q string) (string, bool, error) {
	switch kind {
	case "wiki":
		if q == "" {
			return "", true, fmt.Errorf("what to look up?")
		}
		lang := "ru"
		if l, rest, ok := strings.Cut(q, ":"); ok && len(l) == 2 {
			lang, q = strings.ToLower(l), strings.TrimSpace(rest)
		}
		base := strings.Replace(wikiBase, "%s", lang, 1)
		txt, err := getText(ctx, base+"/w/api.php?action=query&list=search&srlimit=1&format=json&srsearch="+url.QueryEscape(q))
		if err != nil {
			return "", true, err
		}
		var sr struct {
			Query struct {
				Search []struct{ Title string } `json:"search"`
			} `json:"query"`
		}
		if json.Unmarshal([]byte(txt), &sr) != nil || len(sr.Query.Search) == 0 {
			return "nothing found on Wikipedia for " + q, true, nil
		}
		title := sr.Query.Search[0].Title
		txt, err = getText(ctx, base+"/api/rest_v1/page/summary/"+url.PathEscape(strings.ReplaceAll(title, " ", "_")))
		if err != nil {
			return "", true, err
		}
		var sm struct {
			Title, Extract string
			URLs           struct {
				Desktop struct{ Page string } `json:"desktop"`
			} `json:"content_urls"`
		}
		if json.Unmarshal([]byte(txt), &sm) != nil || sm.Extract == "" {
			return "", true, fmt.Errorf("the article %q has no summary", title)
		}
		return fmt.Sprintf("%s\n%s\n%s", sm.Title, Truncate(sm.Extract, 1800), sm.URLs.Desktop.Page), true, nil
	case "github":
		repo := strings.Trim(strings.TrimPrefix(strings.TrimPrefix(q, "https://github.com/"), "github.com/"), "/")
		if strings.Count(repo, "/") != 1 {
			return "", true, fmt.Errorf("give owner/repo")
		}
		txt, err := getText(ctx, githubBase+"/repos/"+repo)
		if err != nil {
			return "", true, err
		}
		var r struct {
			FullName    string `json:"full_name"`
			Description string
			Stars       int `json:"stargazers_count"`
			Forks       int `json:"forks_count"`
			Issues      int `json:"open_issues_count"`
			Language    string
			PushedAt    string                `json:"pushed_at"`
			License     struct{ SPDX string } `json:"license"`
		}
		if json.Unmarshal([]byte(txt), &r) != nil {
			return "", true, fmt.Errorf("unexpected answer from GitHub")
		}
		out := fmt.Sprintf("%s — %s\n★ %d, forks %d, open issues %d, language %s, last push %s", r.FullName, r.Description, r.Stars, r.Forks, r.Issues, r.Language, r.PushedAt)
		if rel, err := getText(ctx, githubBase+"/repos/"+repo+"/releases/latest"); err == nil {
			var rr struct {
				Tag         string `json:"tag_name"`
				PublishedAt string `json:"published_at"`
			}
			if json.Unmarshal([]byte(rel), &rr) == nil && rr.Tag != "" {
				out += fmt.Sprintf("\nlatest release: %s (%s)", rr.Tag, rr.PublishedAt)
			}
		}
		return out, true, nil
	case "geoip":
		if q == "" {
			return "", true, fmt.Errorf("which address?")
		}
		txt, err := getText(ctx, geoipBase+"/"+url.PathEscape(q))
		if err != nil {
			return "", true, err
		}
		var g struct {
			Success    bool
			Message    string
			IP         string
			Country    string
			City       string
			Connection struct{ ISP, Org string } `json:"connection"`
		}
		if json.Unmarshal([]byte(txt), &g) != nil {
			return "", true, fmt.Errorf("unexpected answer")
		}
		if !g.Success {
			return "", true, fmt.Errorf("%s", g.Message)
		}
		return fmt.Sprintf("%s: %s, %s; provider %s %s", g.IP, g.Country, g.City, g.Connection.ISP, g.Connection.Org), true, nil
	}
	return "", false, nil
}
