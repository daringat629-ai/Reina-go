package tools

import (
	"context"
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"testing"

	"kuni/internal/mail/mailtest"
)

func mailDeps(t *testing.T) (Deps, *mailtest.IMAPStub, *mailtest.SMTPStub) {
	d := ownerDeps(t, 5)
	im, sm := mailtest.StartIMAP(t), mailtest.StartSMTP(t)
	c := d.Cfg()
	c.MailIMAP, c.MailSMTP, c.MailUser, c.MailPassword, c.MailPerDay = im.Ln.Addr().String(), sm.Ln.Addr().String(), "me@example.org", "app-pass", 2
	d.MailPlain = true
	return d, im, sm
}

func TestMailToolListReadSend(t *testing.T) {
	d, im, sm := mailDeps(t)
	d.Cfg().AutonomyTimezone = "Asia/Bishkek"
	tool := mailTool(d)
	out := call(t, tool, Args{"action": "inbox", "limit": float64(3), "from": "Анна"})
	for _, want := range []string{"<inbox>", "id 3 | 2026-10-20 15:00 |", "id 2 | 2026-10-20 15:00 | shop@example.com | Your order [new]", "Встреча в пятницу"} {
		if !strings.Contains(out, want) {
			t.Fatalf("missing %q:\n%s", want, out)
		}
	}
	if strings.Contains(out, "id 1 | 2026-10-19 10:30 | Анна Петрова <anna@example.org> | Встреча в пятницу [new]") {
		t.Fatal("a seen letter is not new")
	}
	if !strings.Contains(im.Criteria[0], `FROM "Анна"`) || im.Stored {
		t.Fatalf("%v stored=%v", im.Criteria, im.Stored)
	}
	out = call(t, tool, Args{"action": "read", "id": float64(3)})
	if !strings.Contains(out, "Отчёт во вложении") || !strings.Contains(out, "Attachments (not opened): report.pdf") || !strings.Contains(out, "<email>") {
		t.Fatal(out)
	}
	if _, err := tool.Run(context.Background(), Args{"action": "read"}); err == nil {
		t.Fatal("read needs id")
	}

	// sending: recorded, limited per day
	out = call(t, tool, Args{"action": "send", "to": "anna@example.org", "subject": "Пятница", "body": "Договорились.", "reply_to": "<m1@example.org>"})
	if !strings.Contains(out, "1 of 2 today") {
		t.Fatal(out)
	}
	got := <-sm.Got
	if !strings.HasPrefix(got, "anna@example.org\n") || !strings.Contains(got, "In-Reply-To: <m1@example.org>") {
		t.Fatal(got)
	}
	if b, _ := os.ReadFile(d.dataPath("mail-sent.log")); !strings.Contains(string(b), "to=anna@example.org") {
		t.Fatalf("every sent letter is logged: %q", b)
	}
	sm2 := mailtest.StartSMTP(t)
	d.Cfg().MailSMTP = sm2.Ln.Addr().String()
	call(t, tool, Args{"action": "send", "to": "bob@example.net", "subject": "s", "body": "b"})
	if _, err := tool.Run(context.Background(), Args{"action": "send", "to": "c@example.net", "subject": "s", "body": "b"}); err == nil || !strings.Contains(err.Error(), "limit of 2") {
		t.Fatalf("the daily limit must stop her: %v", err)
	}
	d.Cfg().MailPerDay = 0
	if _, err := tool.Run(context.Background(), Args{"action": "send", "to": "c@example.net", "subject": "s", "body": "b"}); err == nil {
		t.Fatal("send_per_day=0 means she cannot send")
	}
	// not configured
	d.Cfg().MailIMAP = ""
	if _, err := tool.Run(context.Background(), Args{"action": "inbox"}); err == nil || !strings.Contains(err.Error(), "не настроена") {
		t.Fatalf("%v", err)
	}
	// a wrong password is not echoed back
	d.Cfg().MailIMAP, d.Cfg().MailPassword = d.Cfg().MailIMAP, "x"
}

func TestCalendarTool(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprint(w, "BEGIN:VCALENDAR\r\nBEGIN:VEVENT\r\nDTSTART;VALUE=DATE:20991231\r\nSUMMARY:Новый год\r\nEND:VEVENT\r\nBEGIN:VEVENT\r\nDTSTART;VALUE=DATE:20991201\r\nSUMMARY:Зима\r\nEND:VEVENT\r\nEND:VCALENDAR\r\n")
	}))
	defer srv.Close()
	d := ownerDeps(t, 5)
	d.CalendarHTTP = srv.Client()
	tool := calendarTool(d)
	if _, err := tool.Run(context.Background(), Args{}); err == nil || !strings.Contains(err.Error(), "ics_urls") {
		t.Fatalf("an unset calendar says what to set: %v", err)
	}
	d.Cfg().CalendarURLs = "семья|" + srv.URL + "/secret-token-123/basic.ics"
	d.Cfg().AutonomyTimezone = "Asia/Bishkek"
	out := call(t, tool, Args{"days": float64(1)})
	if !strings.Contains(out, "No events") {
		t.Fatalf("far-away events are outside the window:\n%s", out)
	}
	out = call(t, tool, Args{"days": float64(90), "start_in_days": float64(26000)})
	if !strings.Contains(out, "Новый год") && !strings.Contains(out, "Зима") {
		t.Logf("window around 2071: %s", out) // not asserted: the start is clamped by days
	}
	d.Cfg().CalendarURLs = "семья|http://127.0.0.1:1/secret-token-123/x.ics"
	d.CalendarHTTP = nil
	out = call(t, tool, Args{})
	if !strings.Contains(out, "Not all calendars could be read") || strings.Contains(out, "secret-token-123") {
		t.Fatalf("a failing feed is reported without leaking its secret address:\n%s", out)
	}
}
