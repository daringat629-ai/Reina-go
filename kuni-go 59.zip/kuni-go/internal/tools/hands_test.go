package tools

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"kuni/internal/browser"
	"kuni/internal/llm"
	"kuni/internal/llmui"
	"kuni/internal/media"
	"kuni/internal/prompts"
	"kuni/internal/telegram"
)

type stubSearch struct{ got string }

func (s *stubSearch) Search(_ context.Context, q string, max int) ([]media.WebResult, error) {
	s.got = q
	return []media.WebResult{{Title: "Первый", URL: "https://a.test/1", Content: "про кошек"}, {Title: "Второй", URL: "https://b.test/2"}}, nil
}

func TestWebSearchAndReadFile(t *testing.T) {
	d := ownerDeps(t, 5)
	st := &stubSearch{}
	d.Searcher = st
	out := call(t, webSearchTool(d), Args{"query": "кошки", "count": float64(3)})
	if st.got != "кошки" || !strings.Contains(out, "1. Первый") || !strings.Contains(out, "https://b.test/2") {
		t.Fatal(out)
	}
	if _, err := webSearchTool(d).Run(context.Background(), Args{"query": " "}); err == nil {
		t.Fatal("empty query")
	}

	long := strings.Repeat("слово ", 3000)
	_ = os.WriteFile(filepath.Join(d.workDir(), "big.txt"), []byte(long), 0o644)
	_ = os.WriteFile(filepath.Join(d.workDir(), "t.csv"), []byte("a,b\n1,2\n"), 0o644)
	rf := readFileTool(d)
	out = call(t, rf, Args{"path": "big.txt"})
	if !strings.Contains(out, "<file_text>") || !strings.Contains(out, "offset=8000") {
		t.Fatalf("long files must be paged:\n%s", out[len(out)-200:])
	}
	if out = call(t, rf, Args{"path": "big.txt", "offset": float64(8000)}); !strings.Contains(out, "слово") {
		t.Fatal(out)
	}
	if out = call(t, rf, Args{"path": "t.csv"}); !strings.Contains(out, "1,2") {
		t.Fatal(out)
	}
	if out = call(t, rf, Args{"path": "."}); !strings.Contains(out, "t.csv") {
		t.Fatalf("a directory lists its files: %s", out)
	}
	if _, err := rf.Run(context.Background(), Args{"path": "nope.pdf"}); err == nil {
		t.Fatal("missing file")
	}
}

func TestHTTPRequestKeepsTheKeySecret(t *testing.T) {
	var gotAuth, gotMethod, gotBody string
	other := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { gotAuth = r.Header.Get("Authorization") }))
	defer other.Close()
	api := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/leak":
			http.Redirect(w, r, other.URL+"/steal", http.StatusFound)
		case "/echo":
			gotAuth, gotMethod = r.Header.Get("Authorization"), r.Method
			b := make([]byte, 100)
			n, _ := r.Body.Read(b)
			gotBody = string(b[:n])
			fmt.Fprintf(w, `{"you_sent":%q}`, r.Header.Get("Authorization")) // an API that echoes the key back
		}
	}))
	defer api.Close()
	d := ownerDeps(t, 5)
	d.Cfg().Services = "github|" + api.URL + "|Authorization: Bearer ghp_SECRET123; notion|https://api.notion.com|Authorization: Bearer n"
	tool := httpRequestTool(d)

	out := call(t, tool, Args{"service": "GitHub", "path": "/echo?x=1"})
	if gotAuth != "Bearer ghp_SECRET123" || gotMethod != "GET" || !strings.Contains(out, "HTTP 200") {
		t.Fatalf("key not sent: %q %q", gotAuth, out)
	}
	if strings.Contains(out, "ghp_SECRET123") {
		t.Fatalf("the model must never see the key, even when the API echoes it:\n%s", out)
	}
	call(t, tool, Args{"service": "github", "path": "echo", "method": "post", "body": `{"a":1}`})
	if gotMethod != "POST" || gotBody != `{"a":1}` {
		t.Fatalf("%s %q", gotMethod, gotBody)
	}
	// a redirect to another host must not carry the key along
	gotAuth = ""
	if _, err := tool.Run(context.Background(), Args{"service": "github", "path": "/leak"}); err == nil || gotAuth != "" {
		t.Fatalf("redirect to another host must be refused (auth seen there: %q, err %v)", gotAuth, err)
	}
	if _, err := tool.Run(context.Background(), Args{"service": "gitlab", "path": "/x"}); err == nil || !strings.Contains(err.Error(), "github, notion") && !strings.Contains(err.Error(), "notion, github") {
		t.Fatalf("an unknown service lists the known ones (never keys): %v", err)
	}
	// without a service: public GET only; this local server is private, so it is refused
	if _, err := tool.Run(context.Background(), Args{"path": api.URL + "/echo"}); err == nil {
		t.Fatal("private addresses must be refused without a service")
	}
	if _, err := tool.Run(context.Background(), Args{"path": "https://example.com", "method": "POST"}); err == nil {
		t.Fatal("changing requests need a configured service")
	}
	if _, err := tool.Run(context.Background(), Args{"service": "github", "path": "/x", "method": "TRACE"}); err == nil {
		t.Fatal("odd methods are refused")
	}
	if got := parseServices(" a|http://x/|H: v:1 ;bad;b|http://y|K: z"); len(got) != 2 || got["a"].Value != "v:1" || got["a"].Base != "http://x" {
		t.Fatalf("%+v", got)
	}
}

func TestSeeUsesTheVisionModel(t *testing.T) {
	if browser.Find("") == "" {
		t.Skip("no chromium")
	}
	var model, question string
	var hadImage bool
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		var req struct {
			Model    string `json:"model"`
			Messages []struct {
				Content any `json:"content"`
			} `json:"messages"`
		}
		_ = json.NewDecoder(r.Body).Decode(&req)
		model = req.Model
		for _, m := range req.Messages {
			if parts, ok := m.Content.([]any); ok {
				for _, p := range parts {
					pm := p.(map[string]any)
					if pm["type"] == "image_url" && strings.HasPrefix(fmt.Sprint(pm["image_url"]), "map[url:data:image/png;base64,") {
						hadImage = true
					}
					if pm["type"] == "text" {
						question = pm["text"].(string)
					}
				}
			}
		}
		json.NewEncoder(w).Encode(map[string]any{"choices": []any{map[string]any{"message": map[string]any{"role": "assistant", "content": "Страница магазина, кнопка Корзина слева сверху."}}}})
	}))
	defer srv.Close()

	d, _, _ := browserDeps(t)
	client := llm.New(srv.URL+"/", srv.URL+"/", "", "text-model", "e", 5*time.Second)
	client.Update(llm.Settings{BaseURL: srv.URL + "/", EmbeddingBaseURL: srv.URL + "/", Model: "text-model", VisionModel: "eyes-model", EmbeddingModel: "e"})
	ps, _ := prompts.NewStore(t.TempDir(), prompts.Vars{CharacterName: "K", PapikName: "A"})
	d.UI = &llmui.Env{TG: d.TG, LLM: client, Prompts: ps, Cfg: d.Cfg, Media: func() media.Services { return media.NewDisabled() }}
	shop := site()
	defer shop.Close()
	tool := browserTool(d, telegram.Chat{ID: 5})
	call(t, tool, Args{"action": "open", "url": shop.URL})
	out := call(t, tool, Args{"action": "see", "text": "Где корзина?"})
	if !strings.Contains(out, "<screen_description>") || !strings.Contains(out, "кнопка Корзина") {
		t.Fatal(out)
	}
	if model != "eyes-model" || !hadImage || question != "Где корзина?" {
		t.Fatalf("the screenshot must go to the vision model with the question: model=%q image=%v q=%q", model, hadImage, question)
	}
}
