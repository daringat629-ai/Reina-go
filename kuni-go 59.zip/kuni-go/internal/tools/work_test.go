package tools

import (
	"context"
	"strings"
	"testing"
	"time"

	"kuni/internal/telegram"
	"kuni/internal/work"
)

func TestWorkToolAsksBeforeMoneyAndReports(t *testing.T) {
	d := ownerDeps(t, 5)
	d.Work = work.New("")
	fk := d.TG.(*telegram.Fake)
	tool := workTool(d)
	if out := call(t, tool, Args{"action": "add", "title": "Заказ на Kwork", "brief": "перевод 3000 знаков"}); !strings.Contains(out, "#1") || !strings.Contains(out, "switched off") {
		t.Fatal(out)
	}
	d.Cfg().WorkEnabled = true
	call(t, tool, Args{"action": "note", "id": 1.0, "text": "нашла заказ, жду предоплату"})
	out := call(t, tool, Args{"action": "ask", "id": 1.0, "text": "Заказчик просит предоплату 500 руб. Платить?"})
	if !strings.Contains(out, "owner was asked") {
		t.Fatal(out)
	}
	if got := fk.SentTexts(); len(got) != 1 || !strings.Contains(got[0], "ждёт тебя") || !strings.Contains(got[0], "предоплату") || fk.Sent[0].ChatID != 5 {
		t.Fatalf("the owner must be asked directly: %v", got)
	}
	if _, ok := d.Work.Take(time.Now(), 10); ok {
		t.Fatal("a parked job must not run")
	}
	call(t, tool, Args{"action": "answer", "id": 1.0, "text": "платить нельзя, откажись"})
	call(t, tool, Args{"action": "done", "id": 1.0, "text": "отказалась от заказа"})
	if got := fk.SentTexts(); len(got) != 2 || !strings.Contains(got[1], "Готово") {
		t.Fatalf("done must tell the owner: %v", got)
	}
	if out := call(t, tool, Args{"action": "show", "id": 1.0}); !strings.Contains(out, "OWNER ANSWERED") || !strings.Contains(out, "нашла заказ") {
		t.Fatal(out)
	}
	if _, err := tool.Run(context.Background(), Args{"action": "done", "id": 9.0, "text": "x"}); err == nil {
		t.Fatal("unknown job must be an error")
	}
	if out := call(t, tool, Args{"action": "list"}); !strings.Contains(out, "empty") {
		t.Fatal(out)
	}
}
