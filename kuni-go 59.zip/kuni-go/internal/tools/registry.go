// Package tools is the registry of LLM-callable tools (port of OpenAITools and src/tools/).
package tools

import (
	"context"
	"encoding/json"
	"fmt"
	"sort"
	"strconv"
	"strings"
	"sync"

	"kuni/internal/llm"
	"kuni/internal/llmui"
)

// Prop describes one tool argument. Like the C++ version (OpenAI strict mode),
// every property is "required" and optional ones are Nullable.
type Prop struct {
	Name, Type, Desc string
	Nullable         bool
}

// Args are decoded tool arguments with lenient accessors (models send "123" for 123).
type Args map[string]any

func (a Args) Has(k string) bool { v, ok := a[k]; return ok && v != nil }

func (a Args) Str(k string) string {
	switch v := a[k].(type) {
	case string:
		return v
	case nil:
		return ""
	default:
		return fmt.Sprint(v)
	}
}

func (a Args) Int(k string) int64 {
	switch v := a[k].(type) {
	case float64:
		return int64(v)
	case string:
		n, _ := strconv.ParseInt(strings.TrimSpace(v), 10, 64)
		return n
	}
	return 0
}

func (a Args) Float(k string) float64 {
	switch v := a[k].(type) {
	case float64:
		return v
	case string:
		f, _ := strconv.ParseFloat(strings.TrimSpace(v), 64)
		return f
	}
	return 0
}

func (a Args) Bool(k string) bool {
	switch v := a[k].(type) {
	case bool:
		return v
	case string:
		return v == "true"
	}
	return false
}

type Tool struct {
	Name        string
	Description string
	Props       []Prop
	Run         func(ctx context.Context, a Args) (string, error)
	Meta        // how the agent treats it; filled in from the catalog for the built-in tools
}

// Schema renders the JSON schema for the tool's parameters.
func (t Tool) Schema() map[string]any {
	props := map[string]any{}
	required := []string{}
	for _, p := range t.Props {
		var typ any = p.Type
		if p.Nullable {
			typ = []string{p.Type, "null"}
		}
		props[p.Name] = map[string]any{"type": typ, "description": p.Desc}
		required = append(required, p.Name)
	}
	return map[string]any{"type": "object", "properties": props, "required": required, "additionalProperties": false}
}

// Def is the OpenAI definition of the tool.
func (t Tool) Def() llm.ToolDef {
	return llm.ToolDef{Type: "function", Function: llm.ToolFunc{Name: t.Name, Description: t.Description, Parameters: t.Schema()}}
}

type Registry struct {
	mu    sync.RWMutex
	tools map[string]Tool
	defs  map[string]llm.ToolDef // built once per tool: the definitions go out with every request
	// lazy tool groups: rarely used tools are hidden from the model's tool list (saving prompt
	// tokens) until it unlocks the group with #more_tools (or calls one of the tools directly).
	lazy     bool
	unlocked map[string]bool
	// OnUnlock is called (outside the lock) when a group becomes visible.
	OnUnlock func(group string)
}

func NewRegistry(ts ...Tool) *Registry {
	r := &Registry{tools: map[string]Tool{}, defs: map[string]llm.ToolDef{}}
	r.Add(ts...)
	return r
}

// Add registers tools (a tool with the same name replaces the old one).
func (r *Registry) Add(ts ...Tool) {
	r.mu.Lock()
	defer r.mu.Unlock()
	for _, t := range ts {
		t = withMeta(t)
		r.tools[t.Name] = t
		r.defs[t.Name] = t.Def()
	}
}

// Remove drops tools by name.
func (r *Registry) Remove(names ...string) {
	r.mu.Lock()
	defer r.mu.Unlock()
	for _, n := range names {
		delete(r.tools, n)
		delete(r.defs, n)
	}
}

func (r *Registry) Has(name string) bool {
	r.mu.RLock()
	defer r.mu.RUnlock()
	_, ok := r.tools[name]
	return ok
}

// Get returns a tool by name.
func (r *Registry) Get(name string) (Tool, bool) {
	r.mu.RLock()
	defer r.mu.RUnlock()
	t, ok := r.tools[name]
	return t, ok
}

// All returns every tool, sorted by name.
func (r *Registry) All() []Tool {
	r.mu.RLock()
	defer r.mu.RUnlock()
	out := make([]Tool, 0, len(r.tools))
	for _, t := range r.tools {
		out = append(out, t)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Name < out[j].Name })
	return out
}

func (r *Registry) Names() []string {
	r.mu.RLock()
	defer r.mu.RUnlock()
	var out []string
	for n := range r.tools {
		out = append(out, n)
	}
	sort.Strings(out)
	return out
}

// Lazy hides the tools that belong to a group (Meta.Group) until the group is unlocked, and adds the #more_tools
// tool that unlocks one. desc describes the groups (see Groups). With no grouped tools nothing changes.
func (r *Registry) Lazy(desc map[string]string) {
	r.mu.Lock()
	r.lazy, r.unlocked = true, map[string]bool{}
	seen := map[string]bool{}
	for _, t := range r.tools {
		if t.Group != "" {
			seen[t.Group] = true
		}
	}
	r.mu.Unlock()
	var names []string
	for g := range seen {
		names = append(names, g)
	}
	if len(names) == 0 {
		return
	}
	sort.Strings(names)
	var d strings.Builder
	d.WriteString("Unlock extra tools. Groups:")
	for _, g := range names {
		d.WriteString(" " + g + " (" + desc[g] + ");")
	}
	r.Add(Tool{
		Name:        "more_tools",
		Description: d.String(),
		Props:       []Prop{{Name: "group", Type: "string", Desc: "One of: " + strings.Join(names, ", ")}},
		Meta:        Meta{Quiet: true},
		Run: func(ctx context.Context, a Args) (string, error) {
			g := strings.TrimSpace(a.Str("group"))
			ts := r.Unlock(g)
			if len(ts) == 0 {
				return "", fmt.Errorf("no such group %q; groups: %s", g, strings.Join(names, ", "))
			}
			return "Now available: " + strings.Join(ts, ", "), nil
		},
	})
}

// Unlock makes a lazy group visible and returns its tool names (nil for an unknown group).
func (r *Registry) Unlock(group string) []string {
	r.mu.Lock()
	var ts []string
	for _, t := range r.tools {
		if t.Group == group {
			ts = append(ts, t.Name)
		}
	}
	sort.Strings(ts)
	fire := len(ts) > 0 && r.lazy && !r.unlocked[group]
	if len(ts) > 0 && r.lazy {
		r.unlocked[group] = true
	}
	cb := r.OnUnlock
	r.mu.Unlock()
	if fire && cb != nil {
		cb(group)
	}
	return ts
}

func (r *Registry) hidden(t Tool) bool { return r.lazy && t.Group != "" && !r.unlocked[t.Group] }

// Defs returns OpenAI tool definitions sorted by name (stable prompts); locked lazy tools are left out.
func (r *Registry) Defs() []llm.ToolDef {
	r.mu.RLock()
	defer r.mu.RUnlock()
	out := make([]llm.ToolDef, 0, len(r.tools))
	for name, t := range r.tools {
		if r.hidden(t) {
			continue
		}
		out = append(out, r.defs[name])
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Function.Name < out[j].Function.Name })
	return out
}

// Result is the outcome of one tool call.
type Result struct {
	Text   string // what the model reads ("Error: …" when Failed)
	Failed bool   // the tool reported an error (or does not exist, or got broken arguments)
	Tool   Tool   // the tool that ran (zero when there is no such tool)
}

// Invoke runs a tool. Errors never escape: they come back as "Error: …" text so the model can react to them
// (same contract as OpenAITools::handleToolCalls), with Failed set for the program.
func (r *Registry) Invoke(ctx context.Context, name, rawArgs string) Result {
	r.mu.RLock()
	t, ok := r.tools[name]
	locked := ok && r.hidden(t)
	r.mu.RUnlock()
	if !ok {
		return Result{Text: "Error: no such tool \"" + name + "\". Available: " + strings.Join(r.Names(), ", "), Failed: true}
	}
	if locked {
		r.Unlock(t.Group) // the model remembered a tool by name: just let it work
	}
	args := Args{}
	if strings.TrimSpace(rawArgs) != "" {
		if err := json.Unmarshal([]byte(rawArgs), &args); err != nil {
			return Result{Text: "Error: arguments are not valid JSON: " + err.Error(), Failed: true, Tool: t}
		}
	}
	out, err := t.Run(ctx, args)
	if err != nil {
		return Result{Text: "Error: " + llmui.DefuseControl(err.Error()), Failed: true, Tool: t}
	}
	return Result{Text: llmui.DefuseControl(out), Tool: t} // results carry text from strangers (mail, pages, APIs): no forged instructions
}

// Call is Invoke that returns only the text.
func (r *Registry) Call(ctx context.Context, name, rawArgs string) string {
	return r.Invoke(ctx, name, rawArgs).Text
}

// HandleToolCalls executes calls and returns "tool" role messages.
func (r *Registry) HandleToolCalls(ctx context.Context, calls []llm.ToolCall) []llm.Message {
	out := make([]llm.Message, 0, len(calls))
	for _, c := range calls {
		out = append(out, llm.Message{Role: "tool", ToolCallID: c.ID, Content: r.Call(ctx, c.Function.Name, c.Function.Arguments)})
	}
	return out
}
