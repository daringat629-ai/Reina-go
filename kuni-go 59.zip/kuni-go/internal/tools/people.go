package tools

import (
	"context"
	"errors"
	"fmt"
	"strings"

	"kuni/internal/llmui"
	"kuni/internal/telegram"
)

// chatMembersTool lists who is in a group, so the model does not mix people up.
// In the owner's chat it may look into any chat by id; everywhere else only at the current one.
func chatMembersTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name:        "chat_members",
		Description: "Shows who is in this group: user_id, name, @username, role (owner/admin/member), and which one is you or your owner. Use it when you are unsure who someone is or who is an admin.",
		Props:       []Prop{{Name: "chat_id", Type: "integer", Nullable: true, Desc: "Another chat (only in the owner's chat). Null = this chat."}},
		Run: func(ctx context.Context, a Args) (string, error) {
			target := chat.ID
			if id := a.Int("chat_id"); id != 0 && id != chat.ID {
				if !IsOwnerChat(d, chat.ID) {
					return "", errors.New("you can only list members of the chat you are in")
				}
				target = id
			}
			ms, err := d.TG.Members(ctx, target, 60)
			if err != nil {
				return "", err
			}
			if len(ms) == 0 {
				return "No members visible", nil
			}
			c := d.Cfg()
			var b strings.Builder
			for _, m := range ms {
				b.WriteString(llmui.FormatMember(m, d.TG.MyID(), c.PapikChatID) + "\n")
			}
			if len(ms) >= 60 {
				b.WriteString("(list truncated: admins and the most recent participants)\n")
			}
			return b.String(), nil
		},
	}
}

// userInfoTool looks a person up by user_id (a sender_id from a message, or a member).
func userInfoTool(d Deps) Tool {
	return Tool{
		Name:        "user_info",
		Description: "Public profile of a Telegram user by user_id (sender_id of a message): name, @username, bio. Use it to understand who you are talking to. Never repeat private details of people to others.",
		Props:       []Prop{{Name: "user_id", Type: "integer", Desc: "Telegram user id."}},
		Run: func(ctx context.Context, a Args) (string, error) {
			id := a.Int("user_id")
			if id == 0 {
				return "", errors.New("user_id is required")
			}
			u, err := d.TG.UserInfo(ctx, id)
			if err != nil {
				return "", fmt.Errorf("no profile: %w", err)
			}
			return llmui.FormatUser(u, d.TG.MyID(), d.Cfg().PapikChatID), nil
		},
	}
}
