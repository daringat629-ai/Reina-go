package tools

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"kuni/internal/telegram"
)

func TestMediaKindByExtension(t *testing.T) {
	for p, want := range map[string]string{"a.MP4": telegram.KindVideo, "b.gif": telegram.KindAnimation, "c.mp3": telegram.KindAudio,
		"d.png": telegram.KindPhoto, "e.zip": telegram.KindDocument, "f": telegram.KindDocument, "g.webp": telegram.KindDocument} {
		if got := mediaKind(p, 1000); got != want {
			t.Errorf("%s: %s want %s", p, got, want)
		}
	}
	if mediaKind("huge.jpg", 20<<20) != telegram.KindDocument {
		t.Error("a 20 MB picture must go as a file")
	}
}

func TestSendFileSendsEachFileAsWhatItIs(t *testing.T) {
	d := ownerDeps(t, 5)
	fk := d.TG.(*telegram.Fake)
	os.WriteFile(filepath.Join(d.workDir(), "clip.mp4"), []byte("video"), 0o644)
	os.WriteFile(filepath.Join(d.workDir(), "data.csv"), []byte("a,b"), 0o644)
	sf := sendFileTool(d, telegram.Chat{ID: 5})
	if out := run(t, sf, Args{"path": "clip.mp4", "caption": "смотри"}); !strings.Contains(out, "as video") {
		t.Fatal(out)
	}
	if len(fk.Media.Sent) != 1 || fk.Media.Sent[0].Kind != telegram.KindVideo || fk.Media.Sent[0].Caption != "смотри" {
		t.Fatalf("%+v", fk.Media.Sent)
	}
	run(t, sf, Args{"path": "clip.mp4", "as": "file"})
	run(t, sf, Args{"path": "data.csv"})
	if len(fk.Media.Sent) != 1 {
		t.Fatalf("files must go as documents: %+v", fk.Media.Sent)
	}
	var docs int
	for _, m := range fk.Sent {
		if strings.Contains(m.Text, "[file:") {
			docs++
		}
	}
	if docs != 2 {
		t.Fatalf("documents sent: %d", docs)
	}
}

func TestParseWhen(t *testing.T) {
	loc := time.FixedZone("KG", 6*3600)
	now := time.Date(2026, 10, 21, 15, 0, 0, 0, loc)
	got, err := parseWhen("2h", "", now, loc)
	if err != nil || !got.Equal(now.Add(2*time.Hour)) {
		t.Fatal(got, err)
	}
	got, _ = parseWhen("", "10:00", now, loc) // already past today: tomorrow
	if !got.Equal(time.Date(2026, 10, 22, 10, 0, 0, 0, loc)) {
		t.Fatal(got)
	}
	got, _ = parseWhen("", "18:30", now, loc)
	if !got.Equal(time.Date(2026, 10, 21, 18, 30, 0, 0, loc)) {
		t.Fatal(got)
	}
	got, _ = parseWhen("", "2026-12-31 23:59", now, loc)
	if got.Month() != 12 || got.Day() != 31 {
		t.Fatal(got)
	}
	got, _ = parseWhen("", "05.01 09:00", now, loc) // January already passed: next year
	if got.Year() != 2027 {
		t.Fatal(got)
	}
	if _, err := parseWhen("", "когда-нибудь", now, loc); err == nil {
		t.Fatal("garbage accepted")
	}
	if _, err := parseWhen("", "", now, loc); err == nil {
		t.Fatal("nothing given")
	}
}

func TestSendLater(t *testing.T) {
	d := ownerDeps(t, 5)
	d.Cfg().AutonomyTimezone = "Asia/Bishkek"
	fk := d.TG.(*telegram.Fake)
	fk.Incoming(telegram.Chat{ID: -77, Title: "Рабочий чат", Kind: telegram.ChatGroup, IsMember: true}, 9, "Joe", "hi")
	sl := sendLaterTool(d)
	out := run(t, sl, Args{"chat": "-77", "text": "*Планёрка* в 10", "in": "3h", "markdown": true, "silent": true})
	if !strings.Contains(out, "scheduled for chat -77") {
		t.Fatal(out)
	}
	if len(fk.Rich.Scheduled) != 1 {
		t.Fatal("not scheduled")
	}
	o := fk.Rich.Scheduled[0]
	if !o.Markdown || !o.Silent || time.Until(o.At) < 2*time.Hour+50*time.Minute {
		t.Fatalf("%+v", o)
	}
	if out := run(t, sl, Args{"chat": "-77", "text": "", "in": "2h"}); !strings.HasPrefix(out, "ERR") {
		t.Fatal(out)
	}
	if out := run(t, sl, Args{"chat": "-77", "text": "x"}); !strings.HasPrefix(out, "ERR") {
		t.Fatal(out)
	}
	if out := run(t, sl, Args{"chat": "-77", "text": "x", "at": "2020-01-01 10:00"}); !strings.Contains(out, "between") {
		t.Fatal("the past was accepted:", out)
	}
}

func TestDigestSkipsOldChatsAndPutsMentionsFirst(t *testing.T) {
	d, fk := apiDeps(t)
	quiet := telegram.Chat{ID: -1, Title: "Тихий", Kind: telegram.ChatGroup, IsMember: true}
	loud := telegram.Chat{ID: -2, Title: "Громкий", Kind: telegram.ChatGroup, IsMember: true}
	fk.Incoming(quiet, 9, "Joe", "тишина")
	fk.Incoming(loud, 9, "Ann", "срочно проверь сервер")
	fk.S.UpdateChat(-2, func(c *telegram.Chat) { c.UnreadMentions = 2; c.Unread = 5 })
	old := telegram.Chat{ID: -3, Title: "Старый", Kind: telegram.ChatGroup, IsMember: true}
	fk.Incoming(old, 9, "Bob", "древность")
	fk.S.UpdateChat(-3, func(c *telegram.Chat) { c.LastDate = time.Now().Add(-48 * time.Hour) })
	out := run(t, digestTool(d), Args{"hours": float64(12)})
	if strings.Contains(out, "Старый") {
		t.Fatal("an old chat is in the digest:", out)
	}
	if i, j := strings.Index(out, "Громкий"), strings.Index(out, "Тихий"); i < 0 || j < 0 || i > j {
		t.Fatalf("mentions must come first:\n%s", out)
	}
	if !strings.Contains(out, "срочно проверь сервер") || !strings.Contains(out, "mentions of you 2") {
		t.Fatal(out)
	}
}

func TestProfileTool(t *testing.T) {
	d := ownerDeps(t, 5)
	fk := d.TG.(*telegram.Fake)
	pt := profileTool(d)
	if out := run(t, pt, Args{"action": "set_name", "first": "Рейна", "last": "Вейл"}); out != "name changed" {
		t.Fatal(out)
	}
	if out := run(t, pt, Args{"action": "set_bio", "text": "ядовитая"}); out != "bio changed" {
		t.Fatal(out)
	}
	if out := run(t, pt, Args{"action": "set_bio", "text": strings.Repeat("я", 71)}); !strings.HasPrefix(out, "ERR") {
		t.Fatal(out)
	}
	os.WriteFile(filepath.Join(d.workDir(), "me.jpg"), []byte("jpeg"), 0o644)
	if out := run(t, pt, Args{"action": "set_photo", "path": "me.jpg"}); out != "avatar changed" || fk.Media.Photo != 4 {
		t.Fatal(out, fk.Media.Photo)
	}
	if out := run(t, pt, Args{"action": "show"}); !strings.Contains(out, "Рейна Вейл") || !strings.Contains(out, "ядовитая") {
		t.Fatal(out)
	}
	if out := run(t, pt, Args{"action": "set_name", "first": " "}); !strings.HasPrefix(out, "ERR") {
		t.Fatal(out)
	}
}
