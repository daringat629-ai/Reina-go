//go:build windows

package tools

import (
	"fmt"
	"os/exec"
)

func runAs(*exec.Cmd, string, string) error {
	return fmt.Errorf("shell_user is not supported on Windows")
}
