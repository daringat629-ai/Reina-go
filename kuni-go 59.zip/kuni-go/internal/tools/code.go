package tools

import (
	"context"
	"fmt"
	"regexp"
	"strings"

	"kuni/internal/telegram"
)

// maxCodeInMessage is the longest code block sent as a monospace message; longer code goes as a file (a message
// holds 4096 characters and nobody wants to scroll through that on a phone anyway).
const maxCodeInMessage = 3000

var fenceRe = regexp.MustCompile("(?s)```([A-Za-z0-9_+#.-]{0,20})[ \\t]*\\n?(.*?)```")

type textPart struct {
	code bool
	lang string
	text string
}

// splitCode cuts a text into prose and fenced code blocks, in order. An unclosed fence stays in the prose.
func splitCode(text string) []textPart {
	var out []textPart
	last := 0
	for _, l := range fenceRe.FindAllStringSubmatchIndex(text, -1) {
		if pre := strings.TrimSpace(text[last:l[0]]); pre != "" {
			out = append(out, textPart{text: pre})
		}
		if code := strings.Trim(text[l[4]:l[5]], "\n"); strings.TrimSpace(code) != "" {
			out = append(out, textPart{code: true, lang: strings.ToLower(text[l[2]:l[3]]), text: code})
		}
		last = l[1]
	}
	if rest := strings.TrimSpace(text[last:]); rest != "" {
		out = append(out, textPart{text: rest})
	}
	return out
}

var codeExt = map[string]string{
	"python": "py", "py": "py", "javascript": "js", "js": "js", "typescript": "ts", "ts": "ts", "go": "go", "golang": "go",
	"bash": "sh", "sh": "sh", "shell": "sh", "zsh": "sh", "c": "c", "cpp": "cpp", "c++": "cpp", "csharp": "cs", "cs": "cs",
	"java": "java", "kotlin": "kt", "rust": "rs", "rs": "rs", "html": "html", "css": "css", "json": "json", "yaml": "yml",
	"yml": "yml", "toml": "toml", "sql": "sql", "asm": "asm", "nasm": "asm", "php": "php", "ruby": "rb", "lua": "lua",
	"xml": "xml", "markdown": "md", "md": "md", "dockerfile": "Dockerfile", "makefile": "Makefile",
}

// codeFileName is the name of the file a long block is sent as.
func codeFileName(lang string) string {
	ext, ok := codeExt[strings.ToLower(lang)]
	if !ok {
		ext = "txt"
	}
	switch ext {
	case "Dockerfile", "Makefile":
		return ext
	}
	return "code." + ext
}

// sendWithCode sends a text that holds code blocks: prose goes out as usual (short messages), each block as one
// monospace message with a copy button, and a block too long for a message as a file.
func sendWithCode(ctx context.Context, d Deps, chat telegram.Chat, send, raw func(context.Context, Args) (string, error), a Args, text string) (string, error) {
	parts := splitCode(text)
	if len(parts) == 0 {
		return raw(ctx, a)
	}
	var out []string
	first := true
	for _, p := range parts {
		sub := Args{}
		for k, v := range a {
			sub[k] = v
		}
		if !first {
			delete(sub, "reply_to_message_id")
		}
		first = false
		switch {
		case !p.code:
			sub["text"] = p.text
			fn := send
			if strings.Contains(p.text, "```") {
				fn = raw // an unclosed fence: sent as it is, never splitted again
			}
			r, err := fn(ctx, sub)
			if err != nil {
				return strings.Join(append(out, "error: "+err.Error()), "\n"), nil
			}
			out = append(out, r)
		case len([]rune(p.text)) <= maxCodeInMessage:
			sub["text"], sub["_norepeat"] = "```"+p.lang+"\n"+p.text+"\n```", true
			r, err := raw(ctx, sub)
			if err != nil {
				return strings.Join(append(out, "error: "+err.Error()), "\n"), nil
			}
			out = append(out, r)
		default:
			name := codeFileName(p.lang)
			if _, err := d.TG.SendDocument(ctx, chat.ID, name, []byte(p.text+"\n"), "", a.Int("reply_to_message_id")); err != nil {
				return strings.Join(append(out, "error: "+err.Error()), "\n"), nil
			}
			out = append(out, fmt.Sprintf("The code is long, so it was sent as the file %s.", name))
		}
	}
	return strings.Join(out, "\n"), nil
}
