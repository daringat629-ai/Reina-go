package tools

import (
	"fmt"
	"regexp"
	"strconv"
	"strings"
	"time"

	"kuni/internal/period"
)

// Moments and zones as people say them, shared by #calendar_invite, #datetime and the life tools.

var (
	reClock = regexp.MustCompile(`(?:^|\s)(\d{1,2})[:.](\d{2})(?::(\d{2}))?\s*(am|pm)?$`)
	reISOT  = regexp.MustCompile(`^(\d{4}-\d{1,2}-\d{1,2})[T ](\d{1,2}:\d{2}(?::\d{2})?)$`)
)

// parseMoment reads "завтра 18:30", "25.10 в 9:00", "2026-10-25T18:30", "18:30" (today; tomorrow when it has passed and
// future is set) in loc. hasTime tells whether a time of day was given.
func parseMoment(s string, now time.Time, loc *time.Location, future bool) (t time.Time, hasTime bool, err error) {
	s = strings.Join(strings.Fields(s), " ")
	now = now.In(loc)
	if s == "" || strings.EqualFold(s, "now") || strings.EqualFold(s, "сейчас") {
		return now, true, nil
	}
	if t, err := time.Parse(time.RFC3339, s); err == nil {
		return t.In(loc), true, nil
	}
	if m := reISOT.FindStringSubmatch(s); m != nil {
		s = m[1] + " " + m[2]
	}
	h, mi, sec := 0, 0, 0
	rest := s
	if m := reClock.FindStringSubmatchIndex(s); m != nil {
		h, _ = strconv.Atoi(s[m[2]:m[3]])
		mi, _ = strconv.Atoi(s[m[4]:m[5]])
		if m[6] >= 0 {
			sec, _ = strconv.Atoi(s[m[6]:m[7]])
		}
		if m[8] >= 0 {
			switch strings.ToLower(s[m[8]:m[9]]) {
			case "pm":
				if h < 12 {
					h += 12
				}
			case "am":
				if h == 12 {
					h = 0
				}
			}
		}
		if h > 23 || mi > 59 || sec > 59 {
			return time.Time{}, false, fmt.Errorf("no such time in %q", s)
		}
		hasTime = true
		rest = strings.TrimSpace(strings.TrimSuffix(strings.TrimSpace(s[:m[0]]), ","))
		for _, p := range []string{" в", " во", " at", " с"} {
			rest = strings.TrimSuffix(rest, p)
		}
		if rest == "в" || rest == "at" {
			rest = ""
		}
	}
	var day time.Time
	if rest == "" {
		day = time.Date(now.Year(), now.Month(), now.Day(), 0, 0, 0, 0, loc)
	} else {
		day, err = period.Day(rest, now, !future)
		if err != nil {
			return time.Time{}, false, err
		}
	}
	t = time.Date(day.Year(), day.Month(), day.Day(), h, mi, sec, 0, loc)
	if rest == "" && hasTime && future && t.Before(now) {
		t = t.AddDate(0, 0, 1)
	}
	return t, hasTime, nil
}

// zoneAliases are cities people name instead of time zones.
var zoneAliases = map[string]string{
	"бишкек": "Asia/Bishkek", "bishkek": "Asia/Bishkek", "ош": "Asia/Bishkek", "кыргызстан": "Asia/Bishkek", "киргизия": "Asia/Bishkek",
	"москва": "Europe/Moscow", "moscow": "Europe/Moscow", "мск": "Europe/Moscow", "msk": "Europe/Moscow", "питер": "Europe/Moscow",
	"санкт-петербург": "Europe/Moscow", "казань": "Europe/Moscow", "екатеринбург": "Asia/Yekaterinburg", "новосибирск": "Asia/Novosibirsk",
	"омск": "Asia/Omsk", "красноярск": "Asia/Krasnoyarsk", "иркутск": "Asia/Irkutsk", "владивосток": "Asia/Vladivostok", "калининград": "Europe/Kaliningrad",
	"самара": "Europe/Samara", "алматы": "Asia/Almaty", "almaty": "Asia/Almaty", "астана": "Asia/Almaty", "ташкент": "Asia/Tashkent", "tashkent": "Asia/Tashkent",
	"душанбе": "Asia/Dushanbe", "ашхабад": "Asia/Ashgabat", "баку": "Asia/Baku", "тбилиси": "Asia/Tbilisi", "ереван": "Asia/Yerevan",
	"киев": "Europe/Kyiv", "kyiv": "Europe/Kyiv", "kiev": "Europe/Kyiv", "минск": "Europe/Minsk", "кишинёв": "Europe/Chisinau", "кишинев": "Europe/Chisinau",
	"стамбул": "Europe/Istanbul", "istanbul": "Europe/Istanbul", "анталья": "Europe/Istanbul", "дубай": "Asia/Dubai", "dubai": "Asia/Dubai",
	"лондон": "Europe/London", "london": "Europe/London", "берлин": "Europe/Berlin", "berlin": "Europe/Berlin", "париж": "Europe/Paris", "paris": "Europe/Paris",
	"рим": "Europe/Rome", "мадрид": "Europe/Madrid", "варшава": "Europe/Warsaw", "прага": "Europe/Prague", "вена": "Europe/Vienna", "амстердам": "Europe/Amsterdam",
	"хельсинки": "Europe/Helsinki", "рига": "Europe/Riga", "вильнюс": "Europe/Vilnius", "таллин": "Europe/Tallinn", "афины": "Europe/Athens",
	"нью-йорк": "America/New_York", "new york": "America/New_York", "nyc": "America/New_York", "вашингтон": "America/New_York", "майами": "America/New_York",
	"чикаго": "America/Chicago", "chicago": "America/Chicago", "денвер": "America/Denver", "лос-анджелес": "America/Los_Angeles", "los angeles": "America/Los_Angeles",
	"сан-франциско": "America/Los_Angeles", "san francisco": "America/Los_Angeles", "сиэтл": "America/Los_Angeles", "торонто": "America/Toronto", "ванкувер": "America/Vancouver",
	"мехико": "America/Mexico_City", "сан-паулу": "America/Sao_Paulo", "буэнос-айрес": "America/Argentina/Buenos_Aires",
	"токио": "Asia/Tokyo", "tokyo": "Asia/Tokyo", "сеул": "Asia/Seoul", "seoul": "Asia/Seoul", "пекин": "Asia/Shanghai", "beijing": "Asia/Shanghai", "шанхай": "Asia/Shanghai",
	"гонконг": "Asia/Hong_Kong", "сингапур": "Asia/Singapore", "singapore": "Asia/Singapore", "бангкок": "Asia/Bangkok", "bangkok": "Asia/Bangkok", "пхукет": "Asia/Bangkok",
	"бали": "Asia/Makassar", "джакарта": "Asia/Jakarta", "дели": "Asia/Kolkata", "delhi": "Asia/Kolkata", "мумбаи": "Asia/Kolkata", "индия": "Asia/Kolkata",
	"тель-авив": "Asia/Jerusalem", "израиль": "Asia/Jerusalem", "каир": "Africa/Cairo", "сидней": "Australia/Sydney", "sydney": "Australia/Sydney",
	"мельбурн": "Australia/Melbourne", "окленд": "Pacific/Auckland", "utc": "UTC", "gmt": "UTC",
}

var reOffset = regexp.MustCompile(`^(?:utc|gmt)\s*([+-])\s*(\d{1,2})(?::?(\d{2}))?$`)

// zone reads a time zone: an IANA name, a city ("Бишкек", "Tokyo") or an offset ("UTC+6", "GMT-3:30").
func zone(name string, def *time.Location) (*time.Location, error) {
	n := strings.ToLower(strings.TrimSpace(name))
	if n == "" {
		return def, nil
	}
	if a, ok := zoneAliases[n]; ok {
		return time.LoadLocation(a)
	}
	if m := reOffset.FindStringSubmatch(n); m != nil {
		h, _ := strconv.Atoi(m[2])
		mins, _ := strconv.Atoi(m[3])
		off := h*3600 + mins*60
		if m[1] == "-" {
			off = -off
		}
		return time.FixedZone(strings.ToUpper(strings.ReplaceAll(name, " ", "")), off), nil
	}
	if loc, err := time.LoadLocation(strings.TrimSpace(name)); err == nil {
		return loc, nil
	}
	// "europe/moscow" with the wrong case
	parts := strings.Split(n, "/")
	for i, p := range parts {
		words := strings.Split(p, "_")
		for j, w := range words {
			if w != "" {
				words[j] = strings.ToUpper(w[:1]) + w[1:]
			}
		}
		parts[i] = strings.Join(words, "_")
	}
	if loc, err := time.LoadLocation(strings.Join(parts, "/")); err == nil {
		return loc, nil
	}
	return nil, fmt.Errorf("unknown time zone %q (use a city or an IANA name like Asia/Bishkek, or UTC+6)", name)
}

var ruWeekdays = [...]string{"воскресенье", "понедельник", "вторник", "среда", "четверг", "пятница", "суббота"}
var ruMonths = [...]string{"", "января", "февраля", "марта", "апреля", "мая", "июня", "июля", "августа", "сентября", "октября", "ноября", "декабря"}

// ruDate writes "пятница, 23 октября 2026".
func ruDate(t time.Time) string {
	return fmt.Sprintf("%s, %d %s %d", ruWeekdays[t.Weekday()], t.Day(), ruMonths[t.Month()], t.Year())
}

// plural picks the Russian form for n: one (1 день), few (2 дня), many (5 дней).
func plural(n int, one, few, many string) string {
	n = abs(n) % 100
	switch {
	case n%10 == 1 && n != 11:
		return one
	case n%10 >= 2 && n%10 <= 4 && (n < 12 || n > 14):
		return few
	}
	return many
}

// fileName makes a safe file name from a title: letters, digits, dashes; ext is added when missing.
func fileName(name, def, ext string) string {
	name = strings.TrimSpace(name)
	if name == "" {
		name = def
	}
	name = strings.TrimSuffix(name, "."+ext)
	var b strings.Builder
	for _, r := range name {
		switch {
		case r == '/' || r == '\\' || r == ':' || r == '*' || r == '?' || r == '"' || r == '<' || r == '>' || r == '|' || r < 0x20:
			b.WriteRune('_')
		default:
			b.WriteRune(r)
		}
	}
	out := strings.Trim(strings.TrimSpace(b.String()), ".")
	if r := []rune(out); len(r) > 80 {
		out = string(r[:80])
	}
	if out == "" {
		out = def
	}
	return out + "." + ext
}
