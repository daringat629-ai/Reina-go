package tools

import (
	"context"
	"path/filepath"
	"strings"
	"testing"

	"kuni/internal/mood"
)

func TestChangeMoodTool(t *testing.T) {
	d := Deps{RT: NewRuntime(nil), Mood: mood.New(filepath.Join(t.TempDir(), "m.json"))}
	d.Mood.Set(50)
	out, err := MoodTool(d).Run(context.Background(), Args{"delta": float64(-20), "reason": "insulted"})
	if err != nil || !strings.Contains(out, "30/100") {
		t.Fatal(out, err)
	}
	out, _ = MoodTool(d).Run(context.Background(), Args{"delta": float64(500)})
	if !strings.Contains(out, "65/100") {
		t.Fatalf("a single call is capped at +35: %s", out)
	}
}
