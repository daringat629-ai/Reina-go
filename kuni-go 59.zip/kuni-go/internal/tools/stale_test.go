package tools

import (
	"context"
	"strings"
	"testing"

	"kuni/internal/telegram"
)

func TestStaleReplyInGroups(t *testing.T) {
	d, f := peopleDeps(t, 5)
	ctx, g := context.Background(), telegram.Chat{ID: -10, Kind: telegram.ChatGroup}
	go func() {
		for range f.Updates() {
		}
	}()
	old := f.Incoming(g, 9, "Joe", "@ReinaVeil как группа")
	other := f.Incoming(g, 9, "Joe", "ещё")
	mine, _ := f.SendText(ctx, g.ID, "норм", old.ID)
	if err := staleReply(ctx, d, g.ID, old.ID); err == nil || !strings.Contains(err.Error(), "already answered") {
		t.Fatalf("answered twice: %v", err)
	}
	q := Message2(f, g, mine.ID)
	if err := staleReply(ctx, d, g.ID, old.ID-0); err == nil {
		t.Fatal("still stale")
	}
	if err := staleReply(ctx, d, g.ID, other.ID); err == nil || !strings.Contains(err.Error(), "replies to you") {
		t.Fatalf("must point to %d: %v", q.ID, err)
	}
	if err := staleReply(ctx, d, g.ID, q.ID); err != nil {
		t.Fatalf("the newest reply is fine: %v", err)
	}
}

// Message2 is the owner replying to her message.
func Message2(f *telegram.Fake, g telegram.Chat, to int64) telegram.Message {
	m := f.Incoming(g, 5, "Jaabir", "Хуйня ?")
	m.ReplyTo = to
	f.S.Put(m, &g)
	return m
}
