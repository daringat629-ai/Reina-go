package tools

import (
	"strings"
	"testing"
)

func TestMaybeTypo(t *testing.T) {
	always := func() float64 { return 0 }
	in := "нормальный текст сообщения"
	out := MaybeTypo(in, 1, always)
	if out == in || len([]rune(out)) != len([]rune(in)) {
		t.Fatalf("no typo or length changed: %q", out)
	}
	for _, s := range []string{"https://example.com/page", "см `код` тут", "привет @vasya ты тут", "коротко"} {
		if MaybeTypo(s, 1, always) != s {
			t.Fatalf("%q must stay untouched", s)
		}
	}
	if MaybeTypo(in, 0, always) != in {
		t.Fatal("chance 0 must never change a text")
	}
	if strings.EqualFold(out, in) {
		t.Fatalf("only case changed: %q", out)
	}
}
