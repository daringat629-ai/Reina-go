package tools

import (
	"strings"
	"unicode"
)

// SplitMessage turns text into chat-sized messages the way a person texts:
//   - every line is its own message (the model's own line breaks are respected);
//   - a line that fits max runes stays whole;
//   - a longer line is cut at sentence ends first, short sentences are packed together up to max;
//   - a sentence longer than max is cut at the best clause boundary (after a comma/dash, before "and/but/that…"),
//     the pieces are balanced so no tiny tail remains, and a chunk never ends on a dangling "и", "в", "to", "a"…;
//   - links are never cut; a single word longer than max is hard-cut as a last resort.
//
// max <= 0: lines only. Joining the result with spaces gives back the text (modulo whitespace).
func SplitMessage(text string, max int) []string {
	var out []string
	for _, line := range strings.Split(text, "\n") {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		if max <= 0 || runeLen(line) <= max {
			out = append(out, line)
			continue
		}
		out = append(out, splitLine(line, max)...)
	}
	return out
}

func runeLen(s string) int { return len([]rune(s)) }

func splitLine(line string, max int) []string {
	var out []string
	cur := ""
	flush := func() {
		if cur != "" {
			out = append(out, cur)
			cur = ""
		}
	}
	for _, sent := range sentences(line) {
		switch {
		case runeLen(sent) > max:
			flush()
			out = append(out, splitBalanced(sent, max)...)
		case cur == "":
			cur = sent
		case runeLen(cur)+1+runeLen(sent) <= max:
			cur += " " + sent
		default:
			flush()
			cur = sent
		}
	}
	flush()
	return out
}

var abbreviations = map[string]bool{
	"т.д.": true, "т.е.": true, "т.к.": true, "т.п.": true, "т.н.": true, "др.": true, "пр.": true, "г.": true, "ул.": true,
	"e.g.": true, "i.e.": true, "mr.": true, "mrs.": true, "ms.": true, "dr.": true, "vs.": true, "no.": true,
}

func hasWordRune(s string) bool {
	for _, r := range s {
		if unicode.IsLetter(r) || unicode.IsDigit(r) {
			return true
		}
	}
	return false
}

func isURL(w string) bool {
	l := strings.ToLower(w)
	return strings.Contains(l, "://") || strings.HasPrefix(l, "www.") || strings.HasPrefix(w, "@")
}

// endsSentence reports whether the word closes a sentence (. ! ? … possibly followed by ) ~ or a quote).
func endsSentence(w string) bool {
	if isURL(w) {
		return strings.HasSuffix(w, "!") || strings.HasSuffix(w, "?")
	}
	core := strings.TrimRight(w, `)~"'»”`)
	if core == "" {
		return false
	}
	r := []rune(core)
	last := r[len(r)-1]
	if !strings.ContainsRune(".!?…", last) {
		return false
	}
	if last == '.' {
		if abbreviations[strings.ToLower(core)] {
			return false
		}
		if len(r) == 2 && unicode.IsLetter(r[0]) { // an initial: "А."
			return false
		}
		if len(r) >= 2 && unicode.IsDigit(r[len(r)-2]) && !strings.ContainsAny(core, " ") && len(r) <= 3 { // "1." list marker-ish
			return false
		}
	}
	return true
}

// sentences splits a line into sentences; emoji / emoticon words stick to the sentence before them.
func sentences(line string) []string {
	words := strings.Fields(line)
	var out []string
	var cur []string
	for i, w := range words {
		cur = append(cur, w)
		if endsSentence(w) && i+1 < len(words) && hasWordRune(words[i+1]) {
			out = append(out, strings.Join(cur, " "))
			cur = nil
		}
	}
	if len(cur) > 0 {
		out = append(out, strings.Join(cur, " "))
	}
	return out
}

var danglers = map[string]bool{
	"и": true, "в": true, "на": true, "с": true, "к": true, "по": true, "из": true, "за": true, "а": true, "но": true, "да": true,
	"не": true, "у": true, "о": true, "от": true, "до": true, "я": true,
	"the": true, "a": true, "an": true, "to": true, "of": true, "in": true, "on": true, "at": true, "and": true, "or": true,
	"but": true, "if": true, "so": true, "is": true, "i": true, "my": true, "for": true, "with": true,
}

var openers = map[string]bool{
	"и": true, "но": true, "а": true, "что": true, "чтобы": true, "потому": true, "если": true, "когда": true, "как": true, "или": true,
	"and": true, "but": true, "because": true, "that": true, "so": true, "or": true, "when": true, "if": true, "which": true,
}

func bareWord(w string) string {
	return strings.ToLower(strings.TrimFunc(w, func(r rune) bool { return !unicode.IsLetter(r) && !unicode.IsDigit(r) }))
}

// splitBalanced cuts one over-long sentence into the fewest chunks of at most max runes, preferring natural
// boundaries and even sizes (a dynamic program over word positions).
func splitBalanced(s string, max int) []string {
	words := strings.Fields(s)
	n := len(words)
	lens := make([]int, n)
	for i, w := range words {
		lens[i] = runeLen(w)
	}
	const inf = 1 << 60
	best := make([]int, n+1)
	next := make([]int, n+1)
	best[n] = 0
	for i := n - 1; i >= 0; i-- {
		best[i] = inf
		width := -1
		for j := i + 1; j <= n; j++ {
			width += lens[j-1] + 1
			if width > max && j > i+1 {
				break
			}
			cost := 1000 + abs(max-width)*abs(max-width)/4
			last := words[j-1]
			if j < n {
				bw := bareWord(last)
				switch {
				case danglers[bw] || (runeLen(bw) <= 2 && hasWordRune(bw) && !strings.ContainsAny(last, ",;:.!?")):
					cost += 400
				case endsSentence(last):
					cost -= 250
				case strings.HasSuffix(last, ",") || strings.HasSuffix(last, ";") || strings.HasSuffix(last, ":") || last == "—" || last == "-" || last == "–":
					cost -= 150
				}
				if !hasWordRune(words[j]) { // never start a message with a stray emoticon
					cost += 600
				}
				if openers[bareWord(words[j])] {
					cost -= 100
				}
			} else if width < 8 && i > 0 { // a tiny orphan tail
				cost += 300
			}
			if best[j] >= inf {
				continue
			}
			if c := cost + best[j]; c < best[i] {
				best[i], next[i] = c, j
			}
		}
	}
	var out []string
	for i := 0; i < n; i = next[i] {
		chunk := strings.Join(words[i:next[i]], " ")
		if next[i] == i+1 && runeLen(chunk) > max && !isURL(chunk) {
			out = append(out, hardCut(chunk, max)...)
		} else {
			out = append(out, chunk)
		}
	}
	return out
}

func hardCut(s string, max int) []string {
	r := []rune(s)
	var out []string
	for len(r) > max {
		out = append(out, string(r[:max]))
		r = r[max:]
	}
	if len(r) > 0 {
		out = append(out, string(r))
	}
	return out
}

func abs(x int) int {
	if x < 0 {
		return -x
	}
	return x
}
