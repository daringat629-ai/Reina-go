//go:build !windows

package tools

import "syscall"

// diskFree reports the size and the free space (for a normal user) of the disk holding path.
func diskFree(path string) (total, free int64, ok bool) {
	var st syscall.Statfs_t
	if err := syscall.Statfs(path, &st); err != nil {
		return 0, 0, false
	}
	return int64(st.Blocks) * int64(st.Bsize), int64(st.Bavail) * int64(st.Bsize), true
}
