package tools

import (
	"bytes"
	"context"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"time"

	"kuni/internal/llmui"
	"kuni/internal/telegram"
	"kuni/internal/update"
)

// IsOwnerChat reports whether the chat is the owner's private chat and owner tools are enabled.
func IsOwnerChat(d Deps, chatID int64) bool {
	c := d.Cfg()
	return c.OwnerTools && c.PapikChatID != 0 && chatID == c.PapikChatID
}

// workDir is her workspace, as an absolute path: tools hand out paths in it and take them back (#send_file), and with
// a relative data_dir ("data", the default) a relative path came back doubled (data/workspace/data/workspace/...).
func (d Deps) workDir() string {
	dir := d.Cfg().ShellDir
	if dir == "" {
		dir = d.dataPath("workspace")
	}
	if abs, err := filepath.Abs(dir); err == nil {
		dir = abs
	}
	_ = os.MkdirAll(dir, 0o755)
	return dir
}

const maxOut = 6000

// Truncate keeps the head and the tail of long output.
func Truncate(s string, n int) string {
	r := []rune(s)
	if len(r) <= n {
		return s
	}
	return string(r[:n/2]) + "\n…(cut " + fmt.Sprint(len(r)-n) + " chars)…\n" + string(r[len(r)-n/2:])
}

// OwnerTools are only ever registered for the owner's private chat.
func OwnerTools(d Deps, chat telegram.Chat) []Tool {
	if !IsOwnerChat(d, chat.ID) {
		return nil
	}
	ts := []Tool{shellTool(d), downloadFileTool(d, chat), sendFileTool(d, chat), listAllChatsTool(d), readChatTool(d), ownerJoinTool(d), sendToChatTool(d), shellBgTool(d, chat), jobsTool(d), selfUpdateTool(d), tgAPITool(d), telegramUITool(d), webSearchTool(d), readFileTool(d), httpRequestTool(d), mailTool(d), calendarTool(d), filesTool(d), sysinfoTool(d), runCodeTool(d), lookupTool(d), notesTool(d), procTool(d), netcheckTool(d), archiveTool(d), rssTool(d), textutilTool(d), serviceTool(d), scheduleTool(d, chat), monitorTool(d, chat), seeImageTool(d), imageTool(d), gitTool(d), mediaDownloadTool(d), sqliteTool(d), sendLaterTool(d), digestTool(d), profileTool(d), calcTool(d), sshTool(d), transcribeTool(d), convertDocTool(d), backupTool(d), tailLogTool(d), settingsTool(d), grepTool(d), ignoreTool(d), commandUsersTool(d)}
	if d.Cfg().BrowserEnabled {
		ts = append(ts, browserTool(d, chat))
	}
	ts = append(ts, workTool(d), dockerTool(d), placesTool(d))
	ts = append(ts, MakeTools(d, chat)...)
	ts = append(ts, LifeTools(d, chat)...)
	if d.Cfg().DesktopEnabled {
		ts = append(ts, desktopTool(d, chat))
	}
	if d.RT != nil && d.RT.World != nil {
		ts = append(ts, WorldTool(d))
	}
	if chat.Kind != telegram.ChatGroup { // groups already get it from ChatTools
		ts = append(ts, chatMembersTool(d, chat))
	}
	return ts
}

func shellTool(d Deps) Tool {
	return Tool{
		Name:        "shell",
		Description: "Run a shell command on the machine you live on (owner only). Working dir is your workspace. Returns exit code and output. Use it for downloads (curl/wget), archives (unzip/tar), files, installs, anything the owner asks.",
		Props: []Prop{
			{Name: "command", Type: "string", Desc: "Command line for sh -c."},
			{Name: "timeout_secs", Type: "integer", Desc: "Optional timeout, default 60, max 600."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			cmdline := strings.TrimSpace(a.Str("command"))
			if cmdline == "" {
				return "", fmt.Errorf("empty command")
			}
			to := d.Cfg().ShellTimeout
			if to <= 0 {
				to = 60
			}
			if v := a.Int("timeout_secs"); v > 0 {
				to = v
			}
			if to > 600 {
				to = 600
			}
			if why := d.shellDanger(cmdline); why != "" {
				d.journal("BLOCKED ("+why+"): "+cmdline, -2)
				return "Blocked: " + why + ". This never runs from here, not even for the owner. If he really wants it he has to do it himself on the machine.", nil
			}
			cctx, cancel := context.WithTimeout(ctx, time.Duration(to)*time.Second)
			defer cancel()
			c, err := d.shellCmd(cctx, cmdline)
			if err != nil {
				return "", err
			}
			var out bytes.Buffer
			c.Stdout, c.Stderr = &out, &out
			err = c.Run()
			code := 0
			if err != nil {
				code = -1
				if ee, ok := err.(*exec.ExitError); ok {
					code = ee.ExitCode()
				}
			}
			d.journal(cmdline, code)
			res := fmt.Sprintf("exit=%d\n%s", code, Truncate(out.String(), maxOut))
			if cctx.Err() == context.DeadlineExceeded {
				res += "\n(timed out after " + fmt.Sprint(to) + "s, killed)"
			}
			return res, nil
		},
	}
}

func downloadFileTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name:        "download_telegram_file",
		Description: "Save the file/photo/voice/video of a message from this chat into your workspace. Returns the path.",
		Props: []Prop{
			{Name: "message_id", Type: "integer", Desc: "Message with the file."},
			{Name: "filename", Type: "string", Desc: "Optional file name to save as."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			m, err := d.TG.Message(ctx, chat.ID, a.Int("message_id"))
			if err != nil {
				return "", err
			}
			if m.FileID == "" {
				return "", fmt.Errorf("message has no downloadable file")
			}
			data, err := d.TG.Download(ctx, m.FileID)
			if err != nil {
				return "", err
			}
			name := filepath.Base(strings.TrimSpace(a.Str("filename")))
			if name == "." || name == "" || name == string(filepath.Separator) {
				name = fmt.Sprintf("tg_%d_%d", chat.ID, m.ID)
			}
			p := filepath.Join(d.workDir(), name)
			if err := os.WriteFile(p, data, 0o644); err != nil {
				return "", err
			}
			return fmt.Sprintf("saved %d bytes to %s", len(data), p), nil
		},
	}
}

func sendFileTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name:        "send_file",
		Description: "Send a file from your workspace (or any absolute path) to the owner, or to another chat with chat_id (max 50 MB). Video plays in the chat, gif loops, music gets a player, pictures show as pictures; as=file sends the original as a plain file. A folder path lists its files.",
		Props: []Prop{
			{Name: "path", Type: "string", Desc: "File path; relative paths are inside the workspace."},
			{Name: "caption", Type: "string", Nullable: true, Desc: "Optional caption."},
			{Name: "as", Type: "string", Nullable: true, Desc: "auto (default: video, gif, music and pictures are sent as what they are) or file (always as a plain file)."},
			{Name: "chat_id", Type: "integer", Nullable: true, Desc: "Another chat (id from #list_all_chats) instead of this one."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			to := chat.ID
			if id := a.Int("chat_id"); id != 0 {
				to = id
			}
			return deliverFile(ctx, d, to, a.Str("path"), a.Str("caption"), a.Str("as"), nil)
		},
	}
}

// deliverFile sends the file at path to a chat (or lists a folder). allowed, when not nil, vets the resolved path.
func deliverFile(ctx context.Context, d Deps, chatID int64, p, caption, as string, allowed func(string) error) (string, error) {
	p = strings.TrimSpace(p)
	if p == "" {
		return "", fmt.Errorf("path is required")
	}
	if !filepath.IsAbs(p) {
		p = filepath.Join(d.workDir(), p)
	}
	p = filepath.Clean(p)
	if allowed != nil {
		real, err := filepath.EvalSymlinks(p)
		if err != nil {
			return "", err
		}
		if err := allowed(real); err != nil {
			return "", err
		}
		p = real
	}
	st, err := os.Stat(p)
	if err != nil {
		return "", err
	}
	if st.IsDir() {
		ents, err := os.ReadDir(p)
		if err != nil {
			return "", err
		}
		var b strings.Builder
		if allowed != nil { // a list shown to strangers does not name credential files
			kept := ents[:0:0]
			for _, e := range ents {
				if !secretName(e.Name()) {
					kept = append(kept, e)
				}
			}
			ents = kept
		}
		for i, e := range ents {
			if i >= 60 {
				fmt.Fprintf(&b, "... and %d more\n", len(ents)-i)
				break
			}
			info, ierr := e.Info()
			switch {
			case ierr != nil:
				b.WriteString(e.Name() + "\n")
			case e.IsDir():
				b.WriteString(e.Name() + "/\n")
			default:
				fmt.Fprintf(&b, "%s (%s)\n", e.Name(), humanSize(info.Size()))
			}
		}
		if b.Len() == 0 {
			return p + " is an empty folder", nil
		}
		return p + ":\n" + strings.TrimSpace(b.String()), nil
	}
	if st.Size() > 50<<20 {
		return "", fmt.Errorf("file is %d MB, limit is 50", st.Size()>>20)
	}
	data, err := os.ReadFile(p)
	if err != nil {
		return "", err
	}
	kind := mediaKind(p, st.Size())
	if strings.EqualFold(as, "file") {
		kind = telegram.KindDocument
	}
	if ms, ok := d.TG.(telegram.MediaSender); ok && kind != telegram.KindDocument {
		if _, err := ms.SendMedia(ctx, chatID, kind, filepath.Base(p), data, caption, 0); err != nil {
			return "", err
		}
		return "sent " + filepath.Base(p) + " as " + kind, nil
	}
	if _, err := d.TG.SendDocument(ctx, chatID, filepath.Base(p), data, caption, 0); err != nil {
		return "", err
	}
	return "sent " + filepath.Base(p), nil
}

func listAllChatsTool(d Deps) Tool {
	return Tool{
		Name:        "list_all_chats",
		Description: "List ALL your Telegram chats with unread counts and last message (owner only, ignores lockdown).",
		Run: func(ctx context.Context, a Args) (string, error) {
			chats, err := d.TG.Chats(ctx, 100)
			if err != nil {
				return "", err
			}
			var b strings.Builder
			now := time.Now()
			for _, c := range chats {
				b.WriteString(llmui.FormatChat(c, now) + "\n")
			}
			if b.Len() == 0 {
				return "No chats", nil
			}
			return b.String(), nil
		},
	}
}

// resolveChat turns "123", "-100123", "@name" or part of a chat title into a chat id.
func resolveChat(ctx context.Context, d Deps, q string) (int64, error) {
	q = strings.TrimSpace(q)
	var id int64
	if _, err := fmt.Sscan(q, &id); err == nil && fmt.Sprint(id) == q {
		return id, nil
	}
	cs, err := d.TG.SearchChats(ctx, q)
	if err != nil {
		return 0, err
	}
	if len(cs) == 0 {
		return 0, fmt.Errorf("no chat matches %q", q)
	}
	return cs[0].ID, nil
}

func ownerJoinTool(d Deps) Tool {
	return Tool{
		Name:        "join_by_link",
		Description: "Join a group or channel by an invite link (t.me/+...) or @username (owner only, works from his chat). Afterwards use read_chat to look at it and send_to_chat to write there.",
		Props:       []Prop{{Name: "invite_link", Type: "string", Desc: "Invite link, @username or chat id."}},
		Run: func(ctx context.Context, a Args) (string, error) {
			link := strings.TrimSpace(a.Str("invite_link"))
			if link == "" {
				return "", fmt.Errorf("pass an invite link or @username")
			}
			if err := d.TG.Join(ctx, link); err != nil {
				return "", err
			}
			return "Joined " + link + ". Messages from it will reach you as usual; read_chat shows its history.", nil
		},
	}
}

func sendToChatTool(d Deps) Tool {
	return Tool{
		Name:        "send_to_chat",
		Description: "Write a message into ANOTHER chat, group or a person by @username (owner only, ignores lockdown). Use it when the owner asks you to write somewhere.",
		Props: []Prop{
			{Name: "chat", Type: "string", Desc: "Chat id, @username or part of the chat name."},
			{Name: "text", Type: "string", Desc: "The message text."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			text := strings.TrimSpace(a.Str("text"))
			if text == "" {
				return "", fmt.Errorf("empty text")
			}
			id, err := resolveChat(ctx, d, a.Str("chat"))
			if err != nil {
				return "", err
			}
			if _, err := d.TG.SendText(telegram.NoThread(ctx), id, text, 0); err != nil {
				return "", err
			}
			return fmt.Sprintf("sent to chat %d", id), nil
		},
	}
}

func readChatTool(d Deps) Tool {
	return Tool{
		Name:        "read_chat",
		Description: "Read recent messages of any of your chats (owner only, ignores lockdown). Does not mark as read.",
		Props: []Prop{
			{Name: "chat", Type: "string", Desc: "Chat id or part of the name."},
			{Name: "limit", Type: "integer", Desc: "How many messages, default 20, max 100."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			q := strings.TrimSpace(a.Str("chat"))
			var id int64
			if _, err := fmt.Sscan(q, &id); err != nil || fmt.Sprint(id) != q {
				cs, err := d.TG.SearchChats(ctx, q)
				if err != nil {
					return "", err
				}
				if len(cs) == 0 {
					return "", fmt.Errorf("no chat matches %q", q)
				}
				id = cs[0].ID
			}
			n := int(a.Int("limit"))
			if n <= 0 {
				n = 20
			}
			if n > 100 {
				n = 100
			}
			msgs, err := d.TG.History(ctx, id, 0, n, 0)
			if err != nil {
				return "", err
			}
			if len(msgs) == 0 {
				return "No messages", nil
			}
			return Truncate(d.UI.FormatMessages(ctx, msgs, time.Now()), 12000), nil
		},
	}
}

// journal appends a line to <data_dir>/shell.log so the owner can review what was run.
func (d Deps) journal(cmdline string, code int) {
	p := d.dataPath("shell.log")
	_ = os.MkdirAll(filepath.Dir(p), 0o755)
	f, err := os.OpenFile(p, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o600)
	if err != nil {
		return
	}
	defer f.Close()
	one := strings.ReplaceAll(strings.TrimSpace(cmdline), "\n", " ⏎ ")
	fmt.Fprintf(f, "%s exit=%d %s\n", time.Now().Format("2006-01-02 15:04:05"), code, Truncate(one, 500))
}

func absDir(p string) string {
	if p == "" {
		return ""
	}
	if a, err := filepath.Abs(p); err == nil {
		return a
	}
	return p
}

// shellCmd builds the command for sh -c (cmd /C on Windows) in her workspace, as the configured shell user.
func (d Deps) shellCmd(ctx context.Context, cmdline string) (*exec.Cmd, error) {
	var c *exec.Cmd
	if runtime.GOOS == "windows" {
		c = exec.CommandContext(ctx, "cmd", "/C", cmdline)
	} else {
		c = exec.CommandContext(ctx, "sh", "-c", cmdline)
	}
	c.Dir = d.workDir()
	if u := strings.TrimSpace(d.Cfg().ShellUser); u != "" {
		if err := runAs(c, u, c.Dir); err != nil {
			return nil, err
		}
	}
	c.WaitDelay = 2 * time.Second
	return c, nil
}

// shellDanger is the hard floor under the shell (capabilities.shell_hard_block); "" when it is off or the command is fine.
func (d Deps) shellDanger(cmdline string) string {
	if !d.Cfg().ShellHardBlock {
		return ""
	}
	return ShellDanger(cmdline, absDir(d.Cfg().DataDir), filepath.Dir(absDir(d.Cfg().DataDir)))
}

func selfUpdateTool(d Deps) Tool {
	return Tool{
		Name:        "self_update",
		Description: "Install a new build of yourself from a zip the owner sent (save it first with download_telegram_file). The archive is checked end to end; if it is cut off or wrong you get the reason and nothing changes. On success you restart in a few seconds; if the new build does not come up, the old one returns on its own.",
		Props:       []Prop{{Name: "path", Type: "string", Desc: "Path of the zip (as returned by download_telegram_file)."}},
		Run: func(ctx context.Context, a Args) (string, error) {
			p := strings.TrimSpace(a.Str("path"))
			if p == "" {
				return "", fmt.Errorf("pass the zip path")
			}
			if !filepath.IsAbs(p) {
				p = filepath.Join(d.workDir(), p)
			}
			dir := d.UpdateDir
			if dir == "" {
				dir = update.Dir()
			}
			names, err := update.Apply(p, dir)
			if err != nil {
				return "", fmt.Errorf("not installed: %v", err)
			}
			go func() {
				time.Sleep(2 * time.Second) // let the reply reach the chat first
				if d.Restart != nil {
					d.Restart()
				} else {
					update.RequestRestart()
				}
			}()
			return fmt.Sprintf("installed %s; restarting in 2 seconds, back in about 30 (the old build returns by itself if the new one fails)", strings.Join(names, ", ")), nil
		},
	}
}
