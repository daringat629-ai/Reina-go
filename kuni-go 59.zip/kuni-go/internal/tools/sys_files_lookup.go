package tools

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"io/fs"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"time"
)

// sys_files_lookup.go: the extra "hands" of the owner chat: files, the machine's health, running code, quick lookups.

func (d Deps) resolvePath(p string) string {
	p = strings.TrimSpace(p)
	if p == "~" || strings.HasPrefix(p, "~/") {
		if h, err := os.UserHomeDir(); err == nil {
			p = filepath.Join(h, strings.TrimPrefix(p, "~"))
		}
	}
	if !filepath.IsAbs(p) {
		p = filepath.Join(d.workDir(), p)
	}
	return filepath.Clean(p)
}

func humanSize(n int64) string {
	switch {
	case n >= 1<<30:
		return fmt.Sprintf("%.1f ГБ", float64(n)/(1<<30))
	case n >= 1<<20:
		return fmt.Sprintf("%.1f МБ", float64(n)/(1<<20))
	case n >= 1<<10:
		return fmt.Sprintf("%.0f КБ", float64(n)/(1<<10))
	}
	return fmt.Sprintf("%d Б", n)
}

// filesTool is the file manager: list, write, edit, move, copy, delete, find, size.
func filesTool(d Deps) Tool {
	return Tool{
		Name:        "files",
		Description: "File manager of the machine you live on (owner only). Actions: list (a directory with sizes), write (create or overwrite a file with text), append, replace (swap `find` for `text` in a file), mkdir, move (path -> to), copy (path -> to), delete (a file or a folder), find (file names matching `text` under path), size (the biggest items under path: use it before cleaning up a disk). Relative paths are inside your workspace. Reading a file is read_file.",
		Props: []Prop{
			{Name: "action", Type: "string", Desc: "list, write, append, replace, mkdir, move, copy, delete, find or size."},
			{Name: "path", Type: "string", Desc: "File or directory."},
			{Name: "to", Type: "string", Nullable: true, Desc: "move/copy: the destination."},
			{Name: "text", Type: "string", Nullable: true, Desc: "write/append: the content; replace: the new text; find: part of the file name."},
			{Name: "find", Type: "string", Nullable: true, Desc: "replace: the exact text to be replaced."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			act := strings.ToLower(strings.TrimSpace(a.Str("action")))
			p := d.resolvePath(a.Str("path"))
			switch act {
			case "list", "":
				ents, err := os.ReadDir(p)
				if err != nil {
					return "", err
				}
				var b strings.Builder
				for i, e := range ents {
					if i >= 200 {
						fmt.Fprintf(&b, "…and %d more\n", len(ents)-i)
						break
					}
					if info, err := e.Info(); err == nil {
						if e.IsDir() {
							fmt.Fprintf(&b, "%s/\n", e.Name())
						} else {
							fmt.Fprintf(&b, "%s  %s\n", e.Name(), humanSize(info.Size()))
						}
					}
				}
				if b.Len() == 0 {
					return "(empty)", nil
				}
				return Truncate(b.String(), maxOut), nil
			case "write", "append":
				if err := os.MkdirAll(filepath.Dir(p), 0o755); err != nil {
					return "", err
				}
				flag := os.O_CREATE | os.O_WRONLY | os.O_TRUNC
				if act == "append" {
					flag = os.O_CREATE | os.O_WRONLY | os.O_APPEND
				}
				f, err := os.OpenFile(p, flag, 0o644)
				if err != nil {
					return "", err
				}
				defer f.Close()
				n, err := io.WriteString(f, a.Str("text"))
				if err != nil {
					return "", err
				}
				d.journal(act+" file "+p, 0)
				return fmt.Sprintf("%s: %d bytes written", p, n), nil
			case "replace":
				find := a.Str("find")
				if find == "" {
					return "", fmt.Errorf("replace needs `find`")
				}
				raw, err := os.ReadFile(p)
				if err != nil {
					return "", err
				}
				n := strings.Count(string(raw), find)
				if n == 0 {
					return "", fmt.Errorf("text not found in %s", p)
				}
				if err := os.WriteFile(p, []byte(strings.ReplaceAll(string(raw), find, a.Str("text"))), 0o644); err != nil {
					return "", err
				}
				d.journal("replace in "+p, 0)
				return fmt.Sprintf("%s: replaced %d place(s)", p, n), nil
			case "mkdir":
				if err := os.MkdirAll(p, 0o755); err != nil {
					return "", err
				}
				return "created " + p, nil
			case "move", "copy":
				to := d.resolvePath(a.Str("to"))
				if a.Str("to") == "" {
					return "", fmt.Errorf("%s needs `to`", act)
				}
				if st, err := os.Stat(to); err == nil && st.IsDir() {
					to = filepath.Join(to, filepath.Base(p))
				}
				if err := os.MkdirAll(filepath.Dir(to), 0o755); err != nil {
					return "", err
				}
				if act == "move" {
					if err := os.Rename(p, to); err != nil {
						if err := copyTree(p, to); err != nil {
							return "", err
						}
						if why := d.deleteDanger(p); why != "" {
							return "copied to " + to + ", but the original stays: " + why, nil
						}
						_ = os.RemoveAll(p)
					}
				} else if err := copyTree(p, to); err != nil {
					return "", err
				}
				d.journal(act+" "+p+" -> "+to, 0)
				return act + ": " + p + " -> " + to, nil
			case "delete":
				if why := d.deleteDanger(p); why != "" {
					d.journal("BLOCKED delete ("+why+"): "+p, -2)
					return "Blocked: " + why + ". This never gets deleted from here.", nil
				}
				size := treeSize(p, 20*time.Second)
				if err := os.RemoveAll(p); err != nil {
					return "", err
				}
				d.journal("delete "+p, 0)
				return fmt.Sprintf("deleted %s (freed about %s)", p, humanSize(size)), nil
			case "find":
				needle := strings.ToLower(a.Str("text"))
				if needle == "" {
					return "", fmt.Errorf("find needs `text`")
				}
				var out []string
				deadline := time.Now().Add(15 * time.Second)
				_ = filepath.WalkDir(p, func(q string, e fs.DirEntry, err error) error {
					if err != nil || time.Now().After(deadline) || len(out) >= 100 {
						return fs.SkipDir
					}
					if strings.Contains(strings.ToLower(e.Name()), needle) {
						out = append(out, q)
					}
					return nil
				})
				if len(out) == 0 {
					return "nothing found", nil
				}
				return Truncate(strings.Join(out, "\n"), maxOut), nil
			case "size":
				return biggest(p, 25*time.Second), nil
			}
			return "", fmt.Errorf("unknown action %q (list, write, append, replace, mkdir, move, copy, delete, find, size)", act)
		},
	}
}

// deleteDanger applies the shell's hard floor to a deletion: system folders and her own data never go.
func (d Deps) deleteDanger(p string) string {
	if !d.Cfg().ShellHardBlock {
		return ""
	}
	return ShellDanger("rm -rf "+p, absDir(d.Cfg().DataDir), filepath.Dir(absDir(d.Cfg().DataDir)))
}

func copyTree(src, dst string) error {
	return filepath.WalkDir(src, func(p string, e fs.DirEntry, err error) error {
		if err != nil {
			return err
		}
		rel, _ := filepath.Rel(src, p)
		target := filepath.Join(dst, rel)
		if e.IsDir() {
			return os.MkdirAll(target, 0o755)
		}
		in, err := os.Open(p)
		if err != nil {
			return err
		}
		defer in.Close()
		out, err := os.OpenFile(target, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o644)
		if err != nil {
			return err
		}
		defer out.Close()
		_, err = io.Copy(out, in)
		return err
	})
}

// treeSize adds up file sizes under p (a file counts as itself), giving up after budget.
func treeSize(p string, budget time.Duration) int64 {
	var n int64
	deadline := time.Now().Add(budget)
	_ = filepath.WalkDir(p, func(q string, e fs.DirEntry, err error) error {
		if err != nil {
			return nil
		}
		if time.Now().After(deadline) {
			return fs.SkipAll
		}
		if !e.IsDir() && e.Type().IsRegular() {
			if info, err := e.Info(); err == nil {
				n += info.Size()
			}
		}
		return nil
	})
	return n
}

// biggest lists the largest direct children of p (folders by their total size).
func biggest(p string, budget time.Duration) string {
	ents, err := os.ReadDir(p)
	if err != nil {
		return "Error: " + err.Error()
	}
	type item struct {
		name string
		size int64
		dir  bool
	}
	deadline := time.Now().Add(budget)
	var items []item
	for _, e := range ents {
		left := time.Until(deadline)
		if left <= 0 {
			break
		}
		q := filepath.Join(p, e.Name())
		if e.Type()&fs.ModeSymlink != 0 {
			continue
		}
		items = append(items, item{e.Name(), treeSize(q, left), e.IsDir()})
	}
	sort.Slice(items, func(i, j int) bool { return items[i].size > items[j].size })
	var b strings.Builder
	for i, it := range items {
		if i >= 20 {
			break
		}
		suffix := ""
		if it.dir {
			suffix = "/"
		}
		fmt.Fprintf(&b, "%8s  %s%s\n", humanSize(it.size), it.name, suffix)
	}
	if b.Len() == 0 {
		return "(empty)"
	}
	if time.Now().After(deadline) {
		b.WriteString("(counted only part of it: out of time)\n")
	}
	return b.String()
}

// sysinfoTool reports the health of the machine: memory, disk, load, the greediest processes.
func sysinfoTool(d Deps) Tool {
	return Tool{
		Name:        "sysinfo",
		Description: "State of the machine you live on (owner only): memory, swap, disk, load, uptime, your own memory use. With top=true also the processes that eat the most memory. Check it before a heavy job (a browser needs ~500 MB free) and when the owner asks about memory or disk.",
		Props: []Prop{
			{Name: "top", Type: "boolean", Nullable: true, Desc: "Also list the 8 processes with the biggest memory use."},
			{Name: "path", Type: "string", Nullable: true, Desc: "Disk to measure (default /)."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			var b strings.Builder
			mem := readKV("/proc/meminfo")
			if len(mem) > 0 {
				fmt.Fprintf(&b, "Память: всего %s, доступно %s, swap занято %s из %s\n",
					humanSize(mem["MemTotal"]), humanSize(mem["MemAvailable"]),
					humanSize(mem["SwapTotal"]-mem["SwapFree"]), humanSize(mem["SwapTotal"]))
			}
			path := "/"
			if s := strings.TrimSpace(a.Str("path")); s != "" {
				path = d.resolvePath(s)
			}
			if total, free, ok := diskFree(path); ok {
				fmt.Fprintf(&b, "Диск %s: всего %s, свободно %s (занято %d%%)\n", path, humanSize(total), humanSize(free), 100-int(100*free/max64(total, 1)))
			}
			if raw, err := os.ReadFile("/proc/loadavg"); err == nil {
				f := strings.Fields(string(raw))
				if len(f) >= 3 {
					fmt.Fprintf(&b, "Нагрузка: %s %s %s, ядер %d\n", f[0], f[1], f[2], runtime.NumCPU())
				}
			}
			if raw, err := os.ReadFile("/proc/uptime"); err == nil {
				if f := strings.Fields(string(raw)); len(f) > 0 {
					if sec, err := strconv.ParseFloat(f[0], 64); err == nil {
						fmt.Fprintf(&b, "Аптайм машины: %s\n", (time.Duration(sec) * time.Second).Round(time.Minute))
					}
				}
			}
			if me := readKV("/proc/self/status"); len(me) > 0 {
				fmt.Fprintf(&b, "Я сама (процесс): память %s, swap %s\n", humanSize(me["VmRSS"]), humanSize(me["VmSwap"]))
			}
			if a.Bool("top") {
				b.WriteString("Больше всего памяти:\n")
				for _, p := range topProcs(8) {
					fmt.Fprintf(&b, "  %8s  pid %d  %s\n", humanSize(p.rss), p.pid, p.name)
				}
			}
			if b.Len() == 0 {
				return "this system does not expose /proc", nil
			}
			return b.String(), nil
		},
	}
}

func max64(a, b int64) int64 {
	if a > b {
		return a
	}
	return b
}

// readKV reads "Key:   123 kB" lines (meminfo, status) as bytes.
func readKV(path string) map[string]int64 {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil
	}
	out := map[string]int64{}
	for _, l := range strings.Split(string(raw), "\n") {
		k, v, ok := strings.Cut(l, ":")
		if !ok {
			continue
		}
		f := strings.Fields(v)
		if len(f) == 0 {
			continue
		}
		n, err := strconv.ParseInt(f[0], 10, 64)
		if err != nil {
			continue
		}
		if len(f) > 1 && strings.EqualFold(f[1], "kB") {
			n *= 1024
		}
		out[k] = n
	}
	return out
}

type procInfo struct {
	pid  int
	name string
	rss  int64
}

func topProcs(n int) []procInfo {
	ents, err := os.ReadDir("/proc")
	if err != nil {
		return nil
	}
	var ps []procInfo
	for _, e := range ents {
		pid, err := strconv.Atoi(e.Name())
		if err != nil {
			continue
		}
		raw, err := os.ReadFile(filepath.Join("/proc", e.Name(), "status"))
		if err != nil {
			continue
		}
		name := ""
		for _, l := range strings.Split(string(raw), "\n") {
			if strings.HasPrefix(l, "Name:") {
				name = strings.TrimSpace(strings.TrimPrefix(l, "Name:"))
			}
		}
		ps = append(ps, procInfo{pid, name, readKV(filepath.Join("/proc", e.Name(), "status"))["VmRSS"]})
	}
	sort.Slice(ps, func(i, j int) bool { return ps[i].rss > ps[j].rss })
	if len(ps) > n {
		ps = ps[:n]
	}
	return ps
}

// runCodeTool runs a script: write it to a file in the workspace and execute it.
func runCodeTool(d Deps) Tool {
	return Tool{
		Name:        "run_code",
		Description: "Run a program you write on the spot (owner only): python, node or sh. For calculations, parsing, converting data, anything easier in code than in your head. Prints stdout+stderr and the exit code. The script is saved in the workspace under .run/.",
		Props: []Prop{
			{Name: "language", Type: "string", Desc: "python, node or sh."},
			{Name: "code", Type: "string", Desc: "The whole program."},
			{Name: "timeout_secs", Type: "integer", Nullable: true, Desc: "Default 60, max 600."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			code := a.Str("code")
			if strings.TrimSpace(code) == "" {
				return "", fmt.Errorf("empty code")
			}
			var bin, ext string
			switch strings.ToLower(strings.TrimSpace(a.Str("language"))) {
			case "python", "py", "python3":
				bin, ext = "python3", ".py"
			case "node", "js", "javascript":
				bin, ext = "node", ".js"
			case "sh", "bash", "shell":
				bin, ext = "sh", ".sh"
			default:
				return "", fmt.Errorf("language must be python, node or sh")
			}
			if ext == ".sh" {
				if why := d.shellDanger(code); why != "" {
					return "Blocked: " + why + ".", nil
				}
			}
			dir := filepath.Join(d.workDir(), ".run")
			if err := os.MkdirAll(dir, 0o755); err != nil {
				return "", err
			}
			file := filepath.Join(dir, fmt.Sprintf("run-%d%s", time.Now().UnixNano(), ext))
			if err := os.WriteFile(file, []byte(code), 0o644); err != nil {
				return "", err
			}
			defer os.Remove(file)
			quoted := "'" + strings.ReplaceAll(file, "'", `'\''`) + "'"
			return shellTool(d).Run(ctx, Args{"command": bin + " " + quoted, "timeout_secs": a.Int("timeout_secs")})
		},
	}
}

// Quick lookups (weather, crypto, exchange rates) over free public APIs. Overridden in tests.
var (
	lookupHTTP    = &http.Client{Timeout: 12 * time.Second}
	weatherBase   = "https://wttr.in"
	cryptoBase    = "https://api.coingecko.com/api/v3/simple/price"
	currencyBase  = "https://open.er-api.com/v6/latest"
	lookupMaxBody = int64(1 << 20)
)

func getText(ctx context.Context, u string) (string, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, u, nil)
	if err != nil {
		return "", err
	}
	req.Header.Set("User-Agent", "curl/8")
	resp, err := lookupHTTP.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	raw, err := io.ReadAll(io.LimitReader(resp.Body, lookupMaxBody))
	if err != nil {
		return "", err
	}
	if resp.StatusCode != 200 {
		return "", fmt.Errorf("HTTP %d: %s", resp.StatusCode, Truncate(strings.TrimSpace(string(raw)), 200))
	}
	return string(raw), nil
}

func lookupTool(d Deps) Tool {
	return Tool{
		Name:        "lookup",
		Description: "Quick facts without a browser (owner only). kind=weather (query = a city), crypto (query = a coin like bitcoin, ethereum, toncoin; price in USD and RUB), rate (query = a currency pair like USD/KGS or EUR/RUB), time (query = a timezone like Asia/Bishkek or Europe/Moscow), wiki (query = a topic; ru: or en: prefix picks the language), github (query = owner/repo: stars, last push, latest release), geoip (query = an IP address: country, city, provider).",
		Props: []Prop{
			{Name: "kind", Type: "string", Desc: "weather, crypto, rate, time, wiki, github or geoip."},
			{Name: "query", Type: "string", Desc: "City, coin, currency pair or timezone."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			q := strings.TrimSpace(a.Str("query"))
			if out, handled, err := lookupMore(ctx, strings.ToLower(strings.TrimSpace(a.Str("kind"))), q); handled {
				return out, err
			}
			switch strings.ToLower(strings.TrimSpace(a.Str("kind"))) {
			case "weather":
				if q == "" {
					return "", fmt.Errorf("which city?")
				}
				return getText(ctx, weatherBase+"/"+url.PathEscape(q)+"?format=%25l:+%25C+%25t+(feels+%25f),+wind+%25w,+humidity+%25h&lang=ru")
			case "crypto":
				id := strings.ToLower(strings.ReplaceAll(q, " ", "-"))
				if id == "" {
					return "", fmt.Errorf("which coin?")
				}
				alias := map[string]string{"btc": "bitcoin", "биткоин": "bitcoin", "биткойн": "bitcoin", "eth": "ethereum", "эфир": "ethereum", "ton": "the-open-network", "toncoin": "the-open-network", "sol": "solana", "doge": "dogecoin", "usdt": "tether"}
				if v, ok := alias[id]; ok {
					id = v
				}
				txt, err := getText(ctx, cryptoBase+"?ids="+url.QueryEscape(id)+"&vs_currencies=usd,rub&include_24hr_change=true")
				if err != nil {
					return "", err
				}
				var m map[string]map[string]float64
				if err := json.Unmarshal([]byte(txt), &m); err != nil || len(m[id]) == 0 {
					return "", fmt.Errorf("no such coin %q", id)
				}
				c := m[id]
				return fmt.Sprintf("%s: $%.2f, %.0f ₽ (за сутки %+.1f%%)", id, c["usd"], c["rub"], c["usd_24h_change"]), nil
			case "rate":
				from, to, ok := strings.Cut(strings.ToUpper(strings.NewReplacer(" ", "", "->", "/", "-", "/").Replace(q)), "/")
				if !ok || from == "" || to == "" {
					return "", fmt.Errorf("give a pair like USD/KGS")
				}
				txt, err := getText(ctx, currencyBase+"/"+url.PathEscape(from))
				if err != nil {
					return "", err
				}
				var r struct {
					Rates map[string]float64 `json:"rates"`
				}
				if err := json.Unmarshal([]byte(txt), &r); err != nil || r.Rates[to] == 0 {
					return "", fmt.Errorf("no rate for %s/%s", from, to)
				}
				return fmt.Sprintf("1 %s = %.4f %s", from, r.Rates[to], to), nil
			case "time":
				if q == "" {
					q = "UTC"
				}
				loc, err := time.LoadLocation(q)
				if err != nil {
					return "", fmt.Errorf("unknown timezone %q (like Asia/Bishkek)", q)
				}
				return time.Now().In(loc).Format("Mon 2006-01-02 15:04 MST (-07:00)"), nil
			}
			return "", fmt.Errorf("kind must be weather, crypto, rate, time, wiki, github or geoip")
		},
	}
}
