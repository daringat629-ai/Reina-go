//go:build windows

package tools

import "fmt"

func killPID(pid int, force bool) error { return fmt.Errorf("not supported on this system") }
