package tools

import (
	"context"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func run(t *testing.T, tl Tool, a Args) string {
	t.Helper()
	out, err := tl.Run(context.Background(), a)
	if err != nil {
		return "ERR " + err.Error()
	}
	return out
}

func TestFilesWriteEditMoveDelete(t *testing.T) {
	d := ownerDeps(t, 5)
	ft := filesTool(d)
	if out := run(t, ft, Args{"action": "write", "path": "a/b.txt", "text": "hello world"}); !strings.Contains(out, "11 bytes") {
		t.Fatal(out)
	}
	run(t, ft, Args{"action": "append", "path": "a/b.txt", "text": "!"})
	if out := run(t, ft, Args{"action": "replace", "path": "a/b.txt", "find": "world", "text": "there"}); !strings.Contains(out, "1 place") {
		t.Fatal(out)
	}
	raw, _ := os.ReadFile(filepath.Join(d.workDir(), "a/b.txt"))
	if string(raw) != "hello there!" {
		t.Fatal(string(raw))
	}
	if out := run(t, ft, Args{"action": "replace", "path": "a/b.txt", "find": "zzz", "text": "x"}); !strings.HasPrefix(out, "ERR") {
		t.Fatal(out)
	}
	run(t, ft, Args{"action": "copy", "path": "a", "to": "c"})
	run(t, ft, Args{"action": "move", "path": "c", "to": "e"})
	if out := run(t, ft, Args{"action": "find", "path": ".", "text": "B.TXT"}); !strings.Contains(out, "e/b.txt") || !strings.Contains(out, "a/b.txt") {
		t.Fatal(out)
	}
	if out := run(t, ft, Args{"action": "size", "path": "."}); !strings.Contains(out, "a/") {
		t.Fatal(out)
	}
	if out := run(t, ft, Args{"action": "list", "path": "a"}); !strings.Contains(out, "b.txt") {
		t.Fatal(out)
	}
	if out := run(t, ft, Args{"action": "delete", "path": "e"}); !strings.Contains(out, "deleted") {
		t.Fatal(out)
	}
	if _, err := os.Stat(filepath.Join(d.workDir(), "e")); err == nil {
		t.Fatal("not deleted")
	}
}

func TestFilesNeverDeleteSystemOrOwnData(t *testing.T) {
	d := ownerDeps(t, 5)
	d.Cfg().ShellHardBlock = true
	ft := filesTool(d)
	for _, p := range []string{"/", "/usr", "/etc", "/opt", d.Cfg().DataDir} {
		if out := run(t, ft, Args{"action": "delete", "path": p}); !strings.Contains(out, "Blocked") {
			t.Fatalf("%s: %s", p, out)
		}
	}
	if _, err := os.Stat(d.Cfg().DataDir); err != nil {
		t.Fatal("data dir is gone")
	}
}

func TestSysinfo(t *testing.T) {
	d := ownerDeps(t, 5)
	out := run(t, sysinfoTool(d), Args{"top": true})
	if _, err := os.Stat("/proc/meminfo"); err == nil && (!strings.Contains(out, "Память") || !strings.Contains(out, "Диск")) {
		t.Fatal(out)
	}
}

func TestRunCode(t *testing.T) {
	d := ownerDeps(t, 5)
	out := run(t, runCodeTool(d), Args{"language": "sh", "code": "echo $((6*7))"})
	if !strings.Contains(out, "exit=0") || !strings.Contains(out, "42") {
		t.Fatal(out)
	}
	if out := run(t, runCodeTool(d), Args{"language": "cobol", "code": "x"}); !strings.HasPrefix(out, "ERR") {
		t.Fatal(out)
	}
	if left, _ := os.ReadDir(filepath.Join(d.workDir(), ".run")); len(left) != 0 {
		t.Fatal("script not cleaned up")
	}
}

func TestLookup(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case strings.HasPrefix(r.URL.Path, "/wx/"):
			w.Write([]byte("Бишкек: ☀️ +20°C"))
		case strings.HasPrefix(r.URL.Path, "/crypto"):
			w.Write([]byte(`{"bitcoin":{"usd":82000.5,"rub":7000000,"usd_24h_change":1.5}}`))
		case strings.HasPrefix(r.URL.Path, "/fx/USD"):
			w.Write([]byte(`{"rates":{"KGS":87.5}}`))
		default:
			http.NotFound(w, r)
		}
	}))
	defer srv.Close()
	oldW, oldC, oldF := weatherBase, cryptoBase, currencyBase
	weatherBase, cryptoBase, currencyBase = srv.URL+"/wx", srv.URL+"/crypto", srv.URL+"/fx"
	defer func() { weatherBase, cryptoBase, currencyBase = oldW, oldC, oldF }()
	d := ownerDeps(t, 5)
	lt := lookupTool(d)
	if out := run(t, lt, Args{"kind": "weather", "query": "Бишкек"}); !strings.Contains(out, "+20") {
		t.Fatal(out)
	}
	if out := run(t, lt, Args{"kind": "crypto", "query": "BTC"}); !strings.Contains(out, "82000.50") {
		t.Fatal(out)
	}
	if out := run(t, lt, Args{"kind": "rate", "query": "usd/kgs"}); !strings.Contains(out, "87.5000 KGS") {
		t.Fatal(out)
	}
	if out := run(t, lt, Args{"kind": "rate", "query": "USD/XXX"}); !strings.HasPrefix(out, "ERR") {
		t.Fatal(out)
	}
	if out := run(t, lt, Args{"kind": "time", "query": "Asia/Bishkek"}); !strings.Contains(out, "+06:00") {
		t.Fatal(out)
	}
}
