package tools

import (
	"context"
	"errors"
	"fmt"
	"strconv"
	"strings"

	"kuni/internal/telegram"
)

// splitOptions turns "Yes | No | Maybe" (or lines) into trimmed non-empty options.
func splitOptions(s string) []string {
	s = strings.ReplaceAll(s, "\n", "|")
	var out []string
	for _, o := range strings.Split(s, "|") {
		if o = strings.TrimSpace(o); o != "" {
			out = append(out, o)
		}
	}
	return out
}

func createPollTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name:        "create_poll",
		Description: "Post a poll in this chat. Good for group decisions (where to go, what to play). Do not spam polls.",
		Props: []Prop{
			{Name: "question", Type: "string", Desc: "The question (up to 250 characters)."},
			{Name: "options", Type: "string", Desc: "2 to 10 answer options separated by the | character, e.g. \"Pizza | Sushi | Burgers\"."},
			{Name: "anonymous", Type: "boolean", Nullable: true, Desc: "Hide who voted (default true)."},
			{Name: "multiple_answers", Type: "boolean", Nullable: true, Desc: "Allow choosing several options (default false)."},
			{Name: "reply_to_message_id", Type: "integer", Nullable: true, Desc: "Reply target or null."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			q := strings.TrimSpace(a.Str("question"))
			opts := splitOptions(a.Str("options"))
			if q == "" || len([]rune(q)) > 250 {
				return "", errors.New("the question must be 1-250 characters")
			}
			if len(opts) < 2 || len(opts) > 10 {
				return "", fmt.Errorf("a poll needs 2-10 options separated by |, got %d", len(opts))
			}
			for _, o := range opts {
				if len([]rune(o)) > 100 {
					return "", errors.New("an option is longer than 100 characters")
				}
			}
			anonymous := !a.Has("anonymous") || a.Bool("anonymous")
			m, err := d.TG.SendPoll(ctx, chat.ID, q, opts, anonymous, a.Bool("multiple_answers"), a.Int("reply_to_message_id"))
			if err != nil {
				return "", err
			}
			d.Metrics.Inc("kuni_telegram_polls_created_total", 1, nil)
			return fmt.Sprintf("Poll posted (message_id=%d)", m.ID), nil
		},
	}
}

func votePollTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name:        "vote_poll",
		Description: "Vote in a poll of this chat. Use the option numbers shown in <option n=...>. Voting is public to the poll's author if it is not anonymous, so vote only if you really have an opinion.",
		Props: []Prop{
			{Name: "message_id", Type: "integer", Desc: "Message with the <poll>."},
			{Name: "options", Type: "string", Desc: "Option numbers, e.g. \"2\" or \"1,3\" for multiple-answer polls. Empty string retracts your vote."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			m, err := d.TG.Message(ctx, chat.ID, a.Int("message_id"))
			if err != nil || m.Poll == nil {
				return "", errors.New("that message is not a poll")
			}
			if m.Poll.Closed {
				return "", errors.New("the poll is closed")
			}
			var idx []int
			for _, f := range strings.FieldsFunc(a.Str("options"), func(r rune) bool { return r == ',' || r == ' ' || r == ';' }) {
				n, err := strconv.Atoi(f)
				if err != nil || n < 1 || n > len(m.Poll.Options) {
					return "", fmt.Errorf("option %q does not exist: choose 1-%d", f, len(m.Poll.Options))
				}
				idx = append(idx, n-1)
			}
			if len(idx) > 1 && !m.Poll.Multiple {
				return "", errors.New("this poll allows only one answer")
			}
			if err := d.TG.VotePoll(ctx, chat.ID, m.ID, idx); err != nil {
				return "", err
			}
			if len(idx) == 0 {
				return "Vote retracted", nil
			}
			return "Voted", nil
		},
	}
}

func pinTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name:        "pin_message",
		Description: "Pin a message in this chat (important announcement, the poll everybody should see).",
		Props: []Prop{
			{Name: "message_id", Type: "integer", Desc: "Message to pin."},
			{Name: "silent", Type: "boolean", Nullable: true, Desc: "Pin without notifying everybody (default true)."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			silent := !a.Has("silent") || a.Bool("silent")
			if err := d.TG.Pin(ctx, chat.ID, a.Int("message_id"), silent); err != nil {
				return "", err
			}
			return "Pinned", nil
		},
	}
}

func unpinTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name:        "unpin_message",
		Description: "Unpin a message in this chat.",
		Props:       []Prop{{Name: "message_id", Type: "integer", Desc: "Message to unpin."}},
		Run: func(ctx context.Context, a Args) (string, error) {
			if err := d.TG.Unpin(ctx, chat.ID, a.Int("message_id")); err != nil {
				return "", err
			}
			return "Unpinned", nil
		},
	}
}
