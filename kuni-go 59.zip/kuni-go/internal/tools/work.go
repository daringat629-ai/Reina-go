package tools

import (
	"context"
	"fmt"
	"strings"
)

// workTool is her job queue: the owner hands her jobs, she works on them in the background and reports.
func workTool(d Deps) Tool {
	return Tool{
		Name: "work",
		Description: "Your queue of background jobs (owner only). The owner gives you a job; you work on it on your own in background runs (the program starts them on a schedule, within daily limits), using the browser, the desktop, the shell, mail and search. " +
			"action: add(title, brief, runs) = queue a job | list(all) | show(id) | note(id, text) = write what you did and what is next (the next run reads it, so be concrete: links, order numbers, drafts) | " +
			"done(id, text) = finished, text is the result (the owner is told) | ask(id, text) = park the job and ask the owner (he is told at once) | answer(id, text) = the owner answered your question, continue | cancel(id). " +
			"RULES for every job: you never pay, transfer money, register accounts, accept terms, publish or write in the owner's name to a stranger (a client, a site) without his explicit yes: do the preparation, then ask(id, ...) saying exactly what you want to do and why. " +
			"Never lie to clients about who you are if they ask, never promise what you cannot deliver, never do anything illegal or deceptive. Work honestly, finish small, and report the real result, including failures.",
		Props: []Prop{
			{Name: "action", Type: "string", Desc: "add, list, show, note, done, ask, answer or cancel."},
			{Name: "id", Type: "integer", Nullable: true, Desc: "Job number."},
			{Name: "title", Type: "string", Nullable: true, Desc: "add: short name of the job."},
			{Name: "brief", Type: "string", Nullable: true, Desc: "add: what exactly to do, where, limits, how the owner wants it."},
			{Name: "runs", Type: "integer", Nullable: true, Desc: "add: how many background runs it may take (default 6)."},
			{Name: "text", Type: "string", Nullable: true, Desc: "note, done, ask, answer: the text."},
			{Name: "all", Type: "boolean", Nullable: true, Desc: "list: include finished jobs."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			if d.Work == nil {
				return "", fmt.Errorf("the job queue is not available")
			}
			id := int(a.Int("id"))
			text := strings.TrimSpace(a.Str("text"))
			tell := func(msg string) {
				if d.Cfg().PapikChatID != 0 && d.TG != nil {
					_, _ = d.TG.SendText(ctx, d.Cfg().PapikChatID, msg, 0)
				}
			}
			switch strings.ToLower(strings.TrimSpace(a.Str("action"))) {
			case "add":
				t, err := d.Work.Add(a.Str("title"), a.Str("brief"), int(a.Int("runs")))
				if err != nil {
					return "", err
				}
				if !d.Cfg().WorkEnabled {
					return fmt.Sprintf("job #%d queued, but background work is switched off (work.enabled), so it will not start by itself", t.ID), nil
				}
				return fmt.Sprintf("job #%d queued; it starts in one of the next background runs", t.ID), nil
			case "list":
				ts := d.Work.List(a.Bool("all"))
				if len(ts) == 0 {
					return "the queue is empty", nil
				}
				var b strings.Builder
				for _, t := range ts {
					b.WriteString(t.Render(false) + "\n")
				}
				return b.String(), nil
			case "show":
				t, ok := d.Work.Get(id)
				if !ok {
					return "", fmt.Errorf("no job #%d", id)
				}
				return t.Render(true), nil
			case "note":
				if text == "" {
					return "", fmt.Errorf("note needs text")
				}
				if err := d.Work.Note(id, text); err != nil {
					return "", err
				}
				return "noted", nil
			case "done":
				if text == "" {
					return "", fmt.Errorf("done needs the result in text")
				}
				t, ok := d.Work.Get(id)
				if err := d.Work.Finish(id, text); err != nil {
					return "", err
				}
				title := ""
				if ok {
					title = t.Title
				}
				tell(fmt.Sprintf("Готово: задача #%d «%s».\n%s", id, title, text))
				return "job closed, the owner was told", nil
			case "ask":
				if err := d.Work.Block(id, text); err != nil {
					return "", err
				}
				t, _ := d.Work.Get(id)
				tell(fmt.Sprintf("Задача #%d «%s» ждёт тебя:\n%s\n\nОтветь мне, и я продолжу.", id, t.Title, text))
				return "job parked, the owner was asked; do not continue it until he answers", nil
			case "answer":
				if text == "" {
					return "", fmt.Errorf("answer needs the owner's words in text")
				}
				if err := d.Work.Answer(id, text); err != nil {
					return "", err
				}
				return "job back in the queue", nil
			case "cancel":
				if err := d.Work.Cancel(id); err != nil {
					return "", err
				}
				return "job cancelled", nil
			}
			return "", fmt.Errorf("unknown action; use add, list, show, note, done, ask, answer or cancel")
		},
	}
}
