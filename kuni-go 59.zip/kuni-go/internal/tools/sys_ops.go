package tools

import (
	"archive/tar"
	"archive/zip"
	"compress/gzip"
	"context"
	"crypto/md5"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"encoding/xml"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"time"

	"kuni/internal/netinfo"
	"kuni/internal/store"
)

// sys_ops.go: notes, processes, network checks, archives, feeds, text helpers, services.

// ---- notes ----

type note struct {
	ID      int       `json:"id"`
	Text    string    `json:"text"`
	Done    bool      `json:"done"`
	Created time.Time `json:"created"`
}

func loadNotes(path string) []note {
	var ns []note
	store.Load("notes", path, &ns)
	return ns
}

func saveNotes(path string, ns []note) error { return store.WriteJSON(path, ns, store.Private) }

func notesTool(d Deps) Tool {
	return Tool{
		Name:        "notes",
		Description: "The owner's notebook and to-do list that survives restarts (owner only). Actions: add (text), list (open items; all=true for done ones too), done (id), delete (id), search (text), clear_done. Use it for 'запиши', 'не забудь', shopping lists, ideas, things to do.",
		Props: []Prop{
			{Name: "action", Type: "string", Desc: "add, list, done, delete, search or clear_done."},
			{Name: "text", Type: "string", Nullable: true, Desc: "add: the note; search: what to look for."},
			{Name: "id", Type: "integer", Nullable: true, Desc: "done/delete: the number from the list."},
			{Name: "all", Type: "boolean", Nullable: true, Desc: "list: include finished ones."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			d.rt().notes.Lock()
			defer d.rt().notes.Unlock()
			path := d.dataPath("notes.json")
			ns := loadNotes(path)
			show := func(items []note) string {
				if len(items) == 0 {
					return "(nothing)"
				}
				var b strings.Builder
				for _, n := range items {
					mark := "[ ]"
					if n.Done {
						mark = "[x]"
					}
					fmt.Fprintf(&b, "%d. %s %s (%s)\n", n.ID, mark, n.Text, n.Created.Format("02.01 15:04"))
				}
				return b.String()
			}
			switch strings.ToLower(strings.TrimSpace(a.Str("action"))) {
			case "add":
				t := strings.TrimSpace(a.Str("text"))
				if t == "" {
					return "", fmt.Errorf("empty note")
				}
				id := 1
				for _, n := range ns {
					if n.ID >= id {
						id = n.ID + 1
					}
				}
				ns = append(ns, note{ID: id, Text: t, Created: time.Now()})
				if err := saveNotes(path, ns); err != nil {
					return "", err
				}
				return fmt.Sprintf("saved as #%d", id), nil
			case "list", "":
				var open []note
				for _, n := range ns {
					if a.Bool("all") || !n.Done {
						open = append(open, n)
					}
				}
				return show(open), nil
			case "search":
				q := strings.ToLower(a.Str("text"))
				var hit []note
				for _, n := range ns {
					if strings.Contains(strings.ToLower(n.Text), q) {
						hit = append(hit, n)
					}
				}
				return show(hit), nil
			case "done", "delete":
				id := int(a.Int("id"))
				found := false
				var keep []note
				for _, n := range ns {
					if n.ID == id {
						found = true
						if strings.EqualFold(a.Str("action"), "done") {
							n.Done = true
							keep = append(keep, n)
						}
						continue
					}
					keep = append(keep, n)
				}
				if !found {
					return "", fmt.Errorf("no note #%d", id)
				}
				if err := saveNotes(path, keep); err != nil {
					return "", err
				}
				return "ok", nil
			case "clear_done":
				var keep []note
				for _, n := range ns {
					if !n.Done {
						keep = append(keep, n)
					}
				}
				if err := saveNotes(path, keep); err != nil {
					return "", err
				}
				return fmt.Sprintf("removed %d finished", len(ns)-len(keep)), nil
			}
			return "", fmt.Errorf("unknown action (add, list, done, delete, search, clear_done)")
		},
	}
}

// ---- processes ----

func procTool(d Deps) Tool {
	return Tool{
		Name:        "proc",
		Description: "Processes of the machine you live on (owner only). Actions: list (the biggest memory eaters, optional text filters by name) and kill (pid; signal term by default, kill to force). Use it to free memory when the owner asks or a heavy job needs room. Never kills init or yourself.",
		Props: []Prop{
			{Name: "action", Type: "string", Desc: "list or kill."},
			{Name: "pid", Type: "integer", Nullable: true, Desc: "kill: the process id."},
			{Name: "signal", Type: "string", Nullable: true, Desc: "kill: term (default) or kill."},
			{Name: "text", Type: "string", Nullable: true, Desc: "list: only names containing this."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			switch strings.ToLower(strings.TrimSpace(a.Str("action"))) {
			case "list", "":
				var b strings.Builder
				f := strings.ToLower(a.Str("text"))
				n := 0
				for _, p := range topProcs(200) {
					if f != "" && !strings.Contains(strings.ToLower(p.name), f) {
						continue
					}
					fmt.Fprintf(&b, "%8s  pid %d  %s\n", humanSize(p.rss), p.pid, p.name)
					if n++; n >= 15 {
						break
					}
				}
				if b.Len() == 0 {
					return "no processes found (or /proc is unavailable)", nil
				}
				return b.String(), nil
			case "kill":
				pid := int(a.Int("pid"))
				if pid <= 1 || pid == os.Getpid() || pid == os.Getppid() {
					return "Blocked: that process is init, me or my parent.", nil
				}
				if err := killPID(pid, strings.EqualFold(a.Str("signal"), "kill")); err != nil {
					return "", err
				}
				d.journal(fmt.Sprintf("kill %d (%s)", pid, a.Str("signal")), 0)
				return fmt.Sprintf("signal sent to %d", pid), nil
			}
			return "", fmt.Errorf("action must be list or kill")
		},
	}
}

// ---- network ----

func netcheckTool(d Deps) Tool {
	return Tool{
		Name: "netcheck",
		Description: "Network checks from the machine you live on (owner only). Actions: dns (host -> addresses), port (host + port: is it open), http (url: status, time, final address; tells if a site is up), ip (the machine's public address), " +
			"tls (host: the site's certificate: issuer, names, until when, trusted or not), whois (host = a domain: registrar, creation and expiry dates, name servers).",
		Props: []Prop{
			{Name: "action", Type: "string", Desc: "dns, port, http, ip, tls or whois."},
			{Name: "host", Type: "string", Nullable: true, Desc: "dns/port/tls/whois: host name, domain or address."},
			{Name: "port", Type: "integer", Nullable: true, Desc: "port: the port number."},
			{Name: "url", Type: "string", Nullable: true, Desc: "http: the address."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			switch strings.ToLower(strings.TrimSpace(a.Str("action"))) {
			case "dns":
				h := strings.TrimSpace(a.Str("host"))
				if h == "" {
					return "", fmt.Errorf("which host?")
				}
				addrs, err := net.DefaultResolver.LookupHost(ctx, h)
				if err != nil {
					return "", err
				}
				return h + " -> " + strings.Join(addrs, ", "), nil
			case "port":
				h, p := strings.TrimSpace(a.Str("host")), a.Int("port")
				if h == "" || p <= 0 || p > 65535 {
					return "", fmt.Errorf("need host and port")
				}
				start := time.Now()
				c, err := (&net.Dialer{Timeout: 5 * time.Second}).DialContext(ctx, "tcp", net.JoinHostPort(h, strconv.FormatInt(p, 10)))
				if err != nil {
					return fmt.Sprintf("%s:%d is closed or unreachable (%v)", h, p, err), nil
				}
				c.Close()
				return fmt.Sprintf("%s:%d is open (%d ms)", h, p, time.Since(start).Milliseconds()), nil
			case "http":
				u := strings.TrimSpace(a.Str("url"))
				if u == "" {
					return "", fmt.Errorf("which url?")
				}
				if !strings.Contains(u, "://") {
					u = "https://" + u
				}
				req, err := http.NewRequestWithContext(ctx, http.MethodGet, u, nil)
				if err != nil {
					return "", err
				}
				req.Header.Set("User-Agent", "curl/8")
				start := time.Now()
				resp, err := lookupHTTP.Do(req)
				if err != nil {
					return fmt.Sprintf("%s is down or unreachable: %v", u, err), nil
				}
				defer resp.Body.Close()
				_, _ = io.Copy(io.Discard, io.LimitReader(resp.Body, 1<<20))
				return fmt.Sprintf("%s -> HTTP %d in %d ms (final: %s)", u, resp.StatusCode, time.Since(start).Milliseconds(), resp.Request.URL), nil
			case "ip":
				t, err := getText(ctx, ipBase)
				if err != nil {
					return "", err
				}
				return "public ip: " + strings.TrimSpace(t), nil
			case "tls", "ssl", "cert":
				host := strings.TrimSpace(a.Str("host"))
				if p := a.Int("port"); p > 0 && !strings.Contains(host, ":") {
					host = net.JoinHostPort(host, strconv.FormatInt(p, 10))
				}
				c, err := netinfo.CertOf(ctx, host, nil)
				if err != nil {
					return "", err
				}
				return c.String(), nil
			case "whois":
				return netinfo.Whois(ctx, a.Str("host"), "")
			}
			return "", fmt.Errorf("action must be dns, port, http, ip, tls or whois")
		},
	}
}

var ipBase = "https://api.ipify.org"

// ---- archives ----

func archiveTool(d Deps) Tool {
	return Tool{
		Name:        "archive",
		Description: "Pack and unpack archives (owner only). Actions: zip (path -> .zip), unzip (.zip -> folder), tar (path -> .tar.gz), untar (.tar.gz/.tgz -> folder). `to` is optional: defaults next to the source. Relative paths are inside your workspace.",
		Props: []Prop{
			{Name: "action", Type: "string", Desc: "zip, unzip, tar or untar."},
			{Name: "path", Type: "string", Desc: "What to pack or unpack."},
			{Name: "to", Type: "string", Nullable: true, Desc: "The archive to create / the folder to unpack into."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			src := d.resolvePath(a.Str("path"))
			to := strings.TrimSpace(a.Str("to"))
			switch strings.ToLower(strings.TrimSpace(a.Str("action"))) {
			case "zip":
				dst := d.resolvePath(orStr(to, src+".zip"))
				n, err := makeZip(src, dst)
				return fmt.Sprintf("%s: %d files, %s", dst, n, sizeOf(dst)), err
			case "tar":
				dst := d.resolvePath(orStr(to, src+".tar.gz"))
				n, err := makeTar(src, dst)
				return fmt.Sprintf("%s: %d files, %s", dst, n, sizeOf(dst)), err
			case "unzip":
				dst := d.resolvePath(orStr(to, strings.TrimSuffix(src, filepath.Ext(src))))
				n, err := unzipTo(src, dst)
				return fmt.Sprintf("unpacked %d files into %s", n, dst), err
			case "untar":
				dst := d.resolvePath(orStr(to, strings.TrimSuffix(strings.TrimSuffix(src, ".gz"), ".tar")))
				dst = strings.TrimSuffix(dst, ".tgz")
				n, err := untarTo(src, dst)
				return fmt.Sprintf("unpacked %d files into %s", n, dst), err
			}
			return "", fmt.Errorf("action must be zip, unzip, tar or untar")
		},
	}
}

func orStr(a, b string) string {
	if a != "" {
		return a
	}
	return b
}

func sizeOf(p string) string {
	if st, err := os.Stat(p); err == nil {
		return humanSize(st.Size())
	}
	return "?"
}

// inside reports whether target stays within dir (the zip-slip guard).
func inside(dir, target string) bool {
	rel, err := filepath.Rel(dir, target)
	return err == nil && rel != ".." && !strings.HasPrefix(rel, ".."+string(filepath.Separator))
}

func walkFiles(src string, fn func(path, rel string, info os.FileInfo) error) (int, error) {
	n := 0
	base := filepath.Dir(src)
	err := filepath.Walk(src, func(p string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		if info.IsDir() || !info.Mode().IsRegular() {
			return nil
		}
		rel, _ := filepath.Rel(base, p)
		n++
		return fn(p, filepath.ToSlash(rel), info)
	})
	return n, err
}

func makeZip(src, dst string) (int, error) {
	if err := os.MkdirAll(filepath.Dir(dst), 0o755); err != nil {
		return 0, err
	}
	out, err := os.Create(dst)
	if err != nil {
		return 0, err
	}
	defer out.Close()
	zw := zip.NewWriter(out)
	n, err := walkFiles(src, func(p, rel string, info os.FileInfo) error {
		if p == dst {
			return nil
		}
		w, err := zw.Create(rel)
		if err != nil {
			return err
		}
		f, err := os.Open(p)
		if err != nil {
			return err
		}
		defer f.Close()
		_, err = io.Copy(w, f)
		return err
	})
	if cerr := zw.Close(); err == nil {
		err = cerr
	}
	return n, err
}

func makeTar(src, dst string) (int, error) {
	if err := os.MkdirAll(filepath.Dir(dst), 0o755); err != nil {
		return 0, err
	}
	out, err := os.Create(dst)
	if err != nil {
		return 0, err
	}
	defer out.Close()
	gz := gzip.NewWriter(out)
	tw := tar.NewWriter(gz)
	n, err := walkFiles(src, func(p, rel string, info os.FileInfo) error {
		if p == dst {
			return nil
		}
		h, err := tar.FileInfoHeader(info, "")
		if err != nil {
			return err
		}
		h.Name = rel
		if err := tw.WriteHeader(h); err != nil {
			return err
		}
		f, err := os.Open(p)
		if err != nil {
			return err
		}
		defer f.Close()
		_, err = io.Copy(tw, f)
		return err
	})
	if cerr := tw.Close(); err == nil {
		err = cerr
	}
	if cerr := gz.Close(); err == nil {
		err = cerr
	}
	return n, err
}

const maxUnpack = 2 << 30 // a zip bomb must not fill the disk

func unzipTo(src, dst string) (int, error) {
	zr, err := zip.OpenReader(src)
	if err != nil {
		return 0, err
	}
	defer zr.Close()
	var total int64
	n := 0
	for _, f := range zr.File {
		target := filepath.Join(dst, f.Name)
		if !inside(dst, target) {
			return n, fmt.Errorf("unsafe path in archive: %s", f.Name)
		}
		if f.FileInfo().IsDir() {
			if err := os.MkdirAll(target, 0o755); err != nil {
				return n, err
			}
			continue
		}
		if total += int64(f.UncompressedSize64); total > maxUnpack {
			return n, fmt.Errorf("archive is bigger than 2 GB unpacked")
		}
		if err := os.MkdirAll(filepath.Dir(target), 0o755); err != nil {
			return n, err
		}
		rc, err := f.Open()
		if err != nil {
			return n, err
		}
		out, err := os.OpenFile(target, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o644)
		if err != nil {
			rc.Close()
			return n, err
		}
		_, err = io.Copy(out, io.LimitReader(rc, maxUnpack))
		rc.Close()
		out.Close()
		if err != nil {
			return n, err
		}
		n++
	}
	return n, nil
}

func untarTo(src, dst string) (int, error) {
	f, err := os.Open(src)
	if err != nil {
		return 0, err
	}
	defer f.Close()
	gz, err := gzip.NewReader(f)
	if err != nil {
		return 0, err
	}
	tr := tar.NewReader(gz)
	var total int64
	n := 0
	for {
		h, err := tr.Next()
		if err == io.EOF {
			return n, nil
		}
		if err != nil {
			return n, err
		}
		target := filepath.Join(dst, h.Name)
		if !inside(dst, target) {
			return n, fmt.Errorf("unsafe path in archive: %s", h.Name)
		}
		switch h.Typeflag {
		case tar.TypeDir:
			if err := os.MkdirAll(target, 0o755); err != nil {
				return n, err
			}
		case tar.TypeReg:
			if total += h.Size; total > maxUnpack {
				return n, fmt.Errorf("archive is bigger than 2 GB unpacked")
			}
			if err := os.MkdirAll(filepath.Dir(target), 0o755); err != nil {
				return n, err
			}
			out, err := os.OpenFile(target, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o644)
			if err != nil {
				return n, err
			}
			_, err = io.Copy(out, tr)
			out.Close()
			if err != nil {
				return n, err
			}
			n++
		}
	}
}

// ---- feeds ----

func rssTool(d Deps) Tool {
	return Tool{
		Name:        "rss",
		Description: "Read a news feed (RSS or Atom) and list its latest items with links (owner only). Good for 'что нового на ...', blogs, release feeds (GitHub: https://github.com/<owner>/<repo>/releases.atom).",
		Props: []Prop{
			{Name: "url", Type: "string", Desc: "Feed address."},
			{Name: "count", Type: "integer", Nullable: true, Desc: "How many items, default 8, max 25."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			txt, err := getText(ctx, strings.TrimSpace(a.Str("url")))
			if err != nil {
				return "", err
			}
			n := int(a.Int("count"))
			if n <= 0 {
				n = 8
			}
			if n > 25 {
				n = 25
			}
			items, title, err := parseFeed(txt)
			if err != nil {
				return "", err
			}
			if len(items) > n {
				items = items[:n]
			}
			var b strings.Builder
			fmt.Fprintf(&b, "%s\n", title)
			for i, it := range items {
				fmt.Fprintf(&b, "%d. %s — %s %s\n", i+1, it.Title, it.Link, it.Date)
			}
			return Truncate(b.String(), maxOut), nil
		},
	}
}

type feedItem struct{ Title, Link, Date string }

func parseFeed(s string) ([]feedItem, string, error) {
	var rss struct {
		Title string `xml:"channel>title"`
		Items []struct {
			Title string `xml:"title"`
			Link  string `xml:"link"`
			Date  string `xml:"pubDate"`
		} `xml:"channel>item"`
	}
	if err := xml.Unmarshal([]byte(s), &rss); err == nil && len(rss.Items) > 0 {
		var out []feedItem
		for _, i := range rss.Items {
			out = append(out, feedItem{strings.TrimSpace(i.Title), strings.TrimSpace(i.Link), i.Date})
		}
		return out, rss.Title, nil
	}
	var atom struct {
		Title   string `xml:"title"`
		Entries []struct {
			Title string `xml:"title"`
			Link  struct {
				Href string `xml:"href,attr"`
			} `xml:"link"`
			Date string `xml:"updated"`
		} `xml:"entry"`
	}
	if err := xml.Unmarshal([]byte(s), &atom); err != nil {
		return nil, "", fmt.Errorf("this is not a feed: %v", err)
	}
	if len(atom.Entries) == 0 {
		return nil, "", fmt.Errorf("the feed is empty")
	}
	var out []feedItem
	for _, e := range atom.Entries {
		out = append(out, feedItem{strings.TrimSpace(e.Title), e.Link.Href, e.Date})
	}
	return out, atom.Title, nil
}

// ---- text helpers ----

func textutilTool(d Deps) Tool {
	return Tool{
		Name:        "textutil",
		Description: "Exact little computations that models get wrong when done in the head (owner only): op = base64_encode, base64_decode, sha256, md5, uuid, json_format, url_encode, url_decode, count (characters, words, lines), password (text = length, default 16), time_diff (text = two RFC3339 dates separated by a space).",
		Props: []Prop{
			{Name: "op", Type: "string", Desc: "The operation."},
			{Name: "text", Type: "string", Nullable: true, Desc: "The input."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			t := a.Str("text")
			switch strings.ToLower(strings.TrimSpace(a.Str("op"))) {
			case "base64_encode":
				return base64.StdEncoding.EncodeToString([]byte(t)), nil
			case "base64_decode":
				raw, err := base64.StdEncoding.DecodeString(strings.TrimSpace(t))
				if err != nil {
					raw, err = base64.RawStdEncoding.DecodeString(strings.TrimSpace(t))
				}
				if err != nil {
					return "", err
				}
				return string(raw), nil
			case "sha256":
				h := sha256.Sum256([]byte(t))
				return hex.EncodeToString(h[:]), nil
			case "md5":
				h := md5.Sum([]byte(t))
				return hex.EncodeToString(h[:]), nil
			case "uuid":
				b := make([]byte, 16)
				_, _ = rand.Read(b)
				b[6] = b[6]&0x0f | 0x40
				b[8] = b[8]&0x3f | 0x80
				return fmt.Sprintf("%x-%x-%x-%x-%x", b[0:4], b[4:6], b[6:8], b[8:10], b[10:]), nil
			case "json_format":
				var v any
				if err := json.Unmarshal([]byte(t), &v); err != nil {
					return "", err
				}
				raw, _ := json.MarshalIndent(v, "", "  ")
				return Truncate(string(raw), maxOut), nil
			case "url_encode":
				return url.QueryEscape(t), nil
			case "url_decode":
				return url.QueryUnescape(t)
			case "count":
				return fmt.Sprintf("characters %d, words %d, lines %d", len([]rune(t)), len(strings.Fields(t)), strings.Count(t, "\n")+1), nil
			case "password":
				n, _ := strconv.Atoi(strings.TrimSpace(t))
				if n < 8 {
					n = 16
				}
				if n > 128 {
					n = 128
				}
				const set = "abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789!@#$%^&*-_"
				buf := make([]byte, n)
				_, _ = rand.Read(buf)
				for i := range buf {
					buf[i] = set[int(buf[i])%len(set)]
				}
				return string(buf), nil
			case "time_diff":
				f := strings.Fields(t)
				if len(f) != 2 {
					return "", fmt.Errorf("give two RFC3339 dates separated by a space")
				}
				t1, e1 := time.Parse(time.RFC3339, f[0])
				t2, e2 := time.Parse(time.RFC3339, f[1])
				if e1 != nil || e2 != nil {
					return "", fmt.Errorf("dates must look like 2026-10-21T15:00:00+06:00")
				}
				dd := t2.Sub(t1)
				return fmt.Sprintf("%s (%.1f days)", dd.Round(time.Second), dd.Hours()/24), nil
			}
			return "", fmt.Errorf("unknown op")
		},
	}
}

// ---- services ----

var reServiceName = regexp.MustCompile(`^[a-zA-Z0-9_.@-]{1,64}$`)

func serviceTool(d Deps) Tool {
	return Tool{
		Name:        "service",
		Description: "System services of the machine (owner only; OpenRC rc-service or systemd): action = status, start, stop, restart, list (running ones). Use it to look after what runs next to you.",
		Props: []Prop{
			{Name: "action", Type: "string", Desc: "status, start, stop, restart or list."},
			{Name: "name", Type: "string", Nullable: true, Desc: "Service name, like nginx or sshd (not needed for list)."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			act := strings.ToLower(strings.TrimSpace(a.Str("action")))
			name := strings.TrimSpace(a.Str("name"))
			rc, errRC := exec.LookPath("rc-service")
			sd, errSD := exec.LookPath("systemctl")
			if errRC != nil && errSD != nil {
				return "", fmt.Errorf("neither rc-service nor systemctl found")
			}
			var args []string
			bin := rc
			switch act {
			case "list":
				if errRC == nil {
					bin, args = mustLook("rc-status"), []string{"-s"}
				} else {
					bin, args = sd, []string{"list-units", "--type=service", "--state=running", "--no-pager", "--no-legend"}
				}
			case "status", "start", "stop", "restart":
				if !reServiceName.MatchString(name) {
					return "", fmt.Errorf("bad service name")
				}
				if act == "stop" && (name == "sshd" || name == "ssh" || strings.HasPrefix(name, "networking") || name == "reina") {
					return "Blocked: stopping " + name + " would cut me off from the machine.", nil
				}
				if errRC == nil {
					args = []string{name, act}
				} else {
					bin, args = sd, []string{act, name, "--no-pager"}
				}
			default:
				return "", fmt.Errorf("action must be status, start, stop, restart or list")
			}
			cctx, cancel := context.WithTimeout(ctx, 40*time.Second)
			defer cancel()
			out, err := exec.CommandContext(cctx, bin, args...).CombinedOutput()
			code := 0
			if err != nil {
				code = -1
				if ee, ok := err.(*exec.ExitError); ok {
					code = ee.ExitCode()
				}
			}
			if act != "status" && act != "list" {
				d.journal("service "+name+" "+act, code)
			}
			return fmt.Sprintf("exit=%d\n%s", code, Truncate(string(out), maxOut)), nil
		},
	}
}

func mustLook(bin string) string {
	if p, err := exec.LookPath(bin); err == nil {
		return p
	}
	return bin
}
