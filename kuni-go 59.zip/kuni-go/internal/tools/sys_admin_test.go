package tools

import (
	"context"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"kuni/internal/media"
)

func TestCalc(t *testing.T) {
	d := ownerDeps(t, 5)
	ct := calcTool(d)
	cases := map[string]string{
		"2+2*2":                   "6",
		"(2+2)*2":                 "8",
		"2^3^2":                   "512",
		"-3^2":                    "9",
		"10/4":                    "2.5",
		"1250*1.12^3 - 400":       "1356.16",
		"17 % 5":                  "2",
		"15% * 200":               "30",
		"200 * 15%":               "30",
		"sqrt(144)+abs(-3)":       "15",
		"max(3, 9, 4) - min(2;8)": "7",
		"1e3 + 2.5e-1":            "1000.25",
		"fact(5)":                 "120",
		"pi*2":                    "6.28318530718",
		"0,1+0,2":                 "0.3",
		"3×4÷2":                   "6",
		"round(2.5)":              "3",
		"2**10":                   "1024",
	}
	for in, want := range cases {
		out := run(t, ct, Args{"expression": in})
		if !strings.HasSuffix(out, "= "+want) {
			t.Errorf("%q -> %q, want %s", in, out, want)
		}
	}
	for _, bad := range []string{"", "1/0", "2+", "(1+2", "foo(1)", "1 2", "sqrt", "ln(-1)", "5 % 0", "2 ** "} {
		if out := run(t, ct, Args{"expression": bad}); !strings.HasPrefix(out, "ERR") {
			t.Errorf("%q accepted: %s", bad, out)
		}
	}
}

func TestSSHPassesOptionsAndRefusesBadHostsAndDanger(t *testing.T) {
	bin := t.TempDir()
	os.WriteFile(filepath.Join(bin, "ssh"), []byte("#!/bin/sh\necho \"ssh $@\"\n"), 0o755)
	t.Setenv("PATH", bin+":"+os.Getenv("PATH"))
	d := ownerDeps(t, 5)
	d.Cfg().ShellHardBlock = true
	st := sshTool(d)
	out := run(t, st, Args{"host": "root@10.0.0.1", "command": "free -m"})
	if !strings.Contains(out, "exit=0") || !strings.Contains(out, "BatchMode=yes") || !strings.Contains(out, "-- root@10.0.0.1 free -m") {
		t.Fatal(out)
	}
	for _, h := range []string{"-oProxyCommand=id", "", "a b", "host;id", "$(id)"} {
		if out := run(t, st, Args{"host": h, "command": "id"}); !strings.HasPrefix(out, "ERR") {
			t.Errorf("host %q accepted: %s", h, out)
		}
	}
	if out := run(t, st, Args{"host": "srv", "command": "mkfs.ext4 /dev/sda1"}); !strings.Contains(out, "Blocked") {
		t.Fatal(out)
	}
	if out := run(t, st, Args{"host": "srv", "command": " "}); !strings.HasPrefix(out, "ERR") {
		t.Fatal(out)
	}
}

type sttStub struct {
	got  []byte
	name string
}

func (s *sttStub) Transcribe(_ context.Context, audio []byte, name string) (string, error) {
	s.got, s.name = audio, name
	return "привет, это проверка", nil
}

func TestTranscribeSendsAudioAsIsAndConvertsVideo(t *testing.T) {
	d := ownerDeps(t, 5)
	stub := &sttStub{}
	d.Media = func() media.Services { s := media.NewDisabled(); s.STT = stub; return s }
	os.WriteFile(filepath.Join(d.workDir(), "v.ogg"), []byte("OggS-data"), 0o644)
	tt := transcribeTool(d)
	out := run(t, tt, Args{"path": "v.ogg"})
	if !strings.Contains(out, "привет, это проверка") || string(stub.got) != "OggS-data" || stub.name != "v.ogg" {
		t.Fatal(out, string(stub.got), stub.name)
	}
	if out := run(t, tt, Args{"path": "none.mp3"}); !strings.HasPrefix(out, "ERR") {
		t.Fatal(out)
	}
	needBin(t, "ffmpeg")
	vid := filepath.Join(d.workDir(), "clip.mkv")
	if o, code := runBin(t.Context(), 60e9, "", nil, "ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "sine=frequency=440:duration=1", "-f", "lavfi", "-i", "color=c=red:s=64x64:d=1", "-shortest", vid); code != 0 {
		t.Skip("cannot make a test video here: " + o)
	}
	out = run(t, tt, Args{"path": "clip.mkv"})
	if !strings.Contains(out, "проверка") || stub.name != "clip.mp3" || len(stub.got) == 0 {
		t.Fatal(out, stub.name, len(stub.got))
	}
	if _, err := os.Stat(filepath.Join(d.workDir(), ".stt-0.mp3")); err == nil {
		t.Fatal("temp file left")
	}
}

func TestConvertDocWithStubConverters(t *testing.T) {
	bin := t.TempDir()
	// pandoc stub: pandoc <src> [-s] -o <dst> creates dst; soffice stub: --convert-to <fmt> --outdir <dir> <src> creates <dir>/<base>.<fmt>
	os.WriteFile(filepath.Join(bin, "pandoc"), []byte("#!/bin/sh\nout=''\nwhile [ $# -gt 0 ]; do if [ \"$1\" = -o ]; then out=\"$2\"; fi; shift; done\necho pandoc > \"$out\"\n"), 0o755)
	os.WriteFile(filepath.Join(bin, "soffice"), []byte("#!/bin/sh\nfmt=''; dir=''; src=''\nwhile [ $# -gt 0 ]; do case \"$1\" in --convert-to) fmt=\"$2\"; shift;; --outdir) dir=\"$2\"; shift;; --headless) ;; *) src=\"$1\";; esac; shift; done\nb=$(basename \"$src\"); echo office > \"$dir/${b%.*}.$fmt\"\n"), 0o755)
	t.Setenv("PATH", bin+":"+os.Getenv("PATH"))
	d := ownerDeps(t, 5)
	os.WriteFile(filepath.Join(d.workDir(), "note.md"), []byte("# hi"), 0o644)
	os.WriteFile(filepath.Join(d.workDir(), "sheet.xlsx"), []byte("x"), 0o644)
	ct := convertDocTool(d)
	if out := run(t, ct, Args{"path": "note.md", "to": "docx"}); !strings.Contains(out, "note.docx") {
		t.Fatal(out)
	}
	if raw, _ := os.ReadFile(filepath.Join(d.workDir(), "note.docx")); !strings.Contains(string(raw), "pandoc") {
		t.Fatal("markdown to docx must go through pandoc")
	}
	if out := run(t, ct, Args{"path": "note.md", "to": "pdf"}); !strings.Contains(out, "note.pdf") {
		t.Fatal(out)
	}
	if raw, _ := os.ReadFile(filepath.Join(d.workDir(), "note.pdf")); !strings.Contains(string(raw), "office") {
		t.Fatal("markdown to pdf must end in LibreOffice")
	}
	if left, _ := filepath.Glob(filepath.Join(d.workDir(), "*.tmp-conv.*")); len(left) != 0 {
		t.Fatal("temp files left:", left)
	}
	if out := run(t, ct, Args{"path": "sheet.xlsx", "to": "csv"}); !strings.Contains(out, "sheet.csv") {
		t.Fatal(out)
	}
	for _, a := range []Args{{"path": "note.md", "to": "md"}, {"path": "note.md", "to": "p d f"}, {"path": "gone.md", "to": "pdf"}} {
		if out := run(t, ct, a); !strings.HasPrefix(out, "ERR") {
			t.Errorf("%v accepted: %s", a, out)
		}
	}
	t.Setenv("PATH", t.TempDir())
	if out := run(t, ct, Args{"path": "note.md", "to": "docx"}); !strings.Contains(out, "install pandoc") {
		t.Fatal(out)
	}
}

func TestBackupToolMakesAndListsBackups(t *testing.T) {
	d := ownerDeps(t, 5)
	c := d.Cfg()
	c.DiaryDir = filepath.Join(c.DataDir, "diary")
	c.WorkingMemoryFile = filepath.Join(c.DataDir, "wm.md")
	c.PromptsDir = filepath.Join(c.DataDir, "prompts")
	os.MkdirAll(c.DiaryDir, 0o755)
	os.WriteFile(filepath.Join(c.DiaryDir, "day.md"), []byte("дневник"), 0o644)
	os.WriteFile(c.WorkingMemoryFile, []byte("wm"), 0o644)
	bt := backupTool(d)
	if out := run(t, bt, Args{"action": "list"}); !strings.Contains(out, "no backups") {
		t.Fatal(out)
	}
	if out := run(t, bt, Args{"action": "now"}); !strings.Contains(out, "backup created") {
		t.Fatal(out)
	}
	if out := run(t, bt, Args{"action": "list"}); !strings.Contains(out, "reina-") {
		t.Fatal(out)
	}
	if out := run(t, bt, Args{"action": "explode"}); !strings.HasPrefix(out, "ERR") {
		t.Fatal(out)
	}
}

func TestTailLog(t *testing.T) {
	d := ownerDeps(t, 5)
	d.UpdateDir = d.workDir()
	var b strings.Builder
	for i := 0; i < 500; i++ {
		b.WriteString("2026/10/21 12:00:00 agent: all fine line " + string(rune('a'+i%26)) + "\n")
	}
	b.WriteString("2026/10/21 12:01:00 telegram: ERROR flood wait 12s\n")
	b.WriteString("2026/10/21 12:02:00 agent: one more fine line\n")
	os.WriteFile(filepath.Join(d.UpdateDir, "reina.log"), []byte(b.String()), 0o644)
	tl := tailLogTool(d)
	out := run(t, tl, Args{"lines": float64(3)})
	if n := len(strings.Split(out, "\n")); n != 3 || !strings.Contains(out, "one more fine line") {
		t.Fatalf("%d lines:\n%s", n, out)
	}
	if out := run(t, tl, Args{"pattern": "error|panic"}); !strings.Contains(out, "flood wait") || strings.Contains(out, "fine line") {
		t.Fatal(out)
	}
	if out := run(t, tl, Args{"pattern": "zzzz"}); !strings.Contains(out, "no lines match") {
		t.Fatal(out)
	}
	if out := run(t, tl, Args{"pattern": "("}); !strings.HasPrefix(out, "ERR") {
		t.Fatal(out)
	}
	if out := run(t, tl, Args{"path": "missing.log"}); !strings.HasPrefix(out, "ERR") {
		t.Fatal(out)
	}
}

func TestSettingsChangeSafeKeysAndRefuseDangerousOnes(t *testing.T) {
	d := ownerDeps(t, 5)
	d.ConfigPath = filepath.Join(t.TempDir(), "config.toml")
	os.WriteFile(d.ConfigPath, []byte("[llm]\nfast_rounds = true\n\n[general]\npapik_chat_id = 5\n"), 0o600)
	st := settingsTool(d)
	if out := run(t, st, Args{"action": "search", "text": "fast"}); !strings.Contains(out, "llm.fast_rounds") {
		t.Fatal(out)
	}
	if out := run(t, st, Args{"action": "get", "key": "llm.fast_rounds"}); !strings.Contains(out, "llm.fast_rounds =") {
		t.Fatal(out)
	}
	if out := run(t, st, Args{"action": "set", "key": "llm.fast_rounds", "value": "false"}); !strings.Contains(out, "applies in a couple of seconds") {
		t.Fatal(out)
	}
	raw, _ := os.ReadFile(d.ConfigPath)
	if !strings.Contains(string(raw), "fast_rounds = false") {
		t.Fatalf("not written:\n%s", raw)
	}
	if _, err := os.Stat(d.ConfigPath + ".bak"); err != nil {
		t.Fatal("no backup of the old file")
	}
	for _, k := range []string{"general.papik_chat_id", "capabilities.owner_tools", "capabilities.shell_hard_block", "telegram.lockdown", "misc.admin_token", "llm.api_key"} {
		out := run(t, st, Args{"action": "set", "key": k, "value": "x"})
		if !strings.Contains(out, "Blocked") && !strings.HasPrefix(out, "ERR") {
			t.Errorf("%s was changed: %s", k, out)
		}
	}
	raw2, _ := os.ReadFile(d.ConfigPath)
	if strings.Contains(string(raw2), "owner_tools") || !strings.Contains(string(raw2), "papik_chat_id = 5") {
		t.Fatalf("a locked setting changed:\n%s", raw2)
	}
	if out := run(t, st, Args{"action": "get", "key": "misc.admin_token"}); !strings.Contains(out, "not shown") {
		t.Fatal(out)
	}
	if out := run(t, st, Args{"action": "search", "text": "admin_token"}); strings.Contains(out, "admin_token =") {
		t.Fatal("a secret leaked into search:", out)
	}
	if out := run(t, st, Args{"action": "set", "key": "llm.nope", "value": "1"}); !strings.HasPrefix(out, "ERR") {
		t.Fatal(out)
	}
	if out := run(t, st, Args{"action": "set", "key": "llm.fast_rounds", "value": "maybe"}); !strings.HasPrefix(out, "ERR") {
		t.Fatal("a non-boolean accepted:", out)
	}
}

func TestGrep(t *testing.T) {
	d := ownerDeps(t, 5)
	w := d.workDir()
	os.MkdirAll(filepath.Join(w, "src", ".git"), 0o755)
	os.WriteFile(filepath.Join(w, "src", "a.go"), []byte("package a\nfunc Hello() {}\n// TODO: fix\n"), 0o644)
	os.WriteFile(filepath.Join(w, "src", "b.md"), []byte("hello world\nнашла TODO тут\n"), 0o644)
	os.WriteFile(filepath.Join(w, "src", ".git", "x"), []byte("TODO in git"), 0o644)
	os.WriteFile(filepath.Join(w, "src", "bin.dat"), []byte("TODO\x00\x01"), 0o644)
	gt := grepTool(d)
	out := run(t, gt, Args{"pattern": "TODO"})
	if !strings.Contains(out, "a.go:3:") || !strings.Contains(out, "b.md:2:") || strings.Contains(out, ".git") || strings.Contains(out, "bin.dat") {
		t.Fatal(out)
	}
	if out := run(t, gt, Args{"pattern": "hello", "ignore_case": true, "glob": "*.go"}); !strings.Contains(out, "a.go:2:") || strings.Contains(out, "b.md") {
		t.Fatal(out)
	}
	if out := run(t, gt, Args{"pattern": "TODO", "path": "src/b.md"}); !strings.Contains(out, "b.md:2:") {
		t.Fatal(out)
	}
	if out := run(t, gt, Args{"pattern": "zzz"}); !strings.Contains(out, "no matches") {
		t.Fatal(out)
	}
	if out := run(t, gt, Args{"pattern": "TODO", "max_results": float64(1)}); !strings.Contains(out, "stopped at the limit") {
		t.Fatal(out)
	}
	if out := run(t, gt, Args{"pattern": "[a-"}); !strings.HasPrefix(out, "ERR") {
		t.Fatal(out)
	}
}

func TestLookupWikiGithubGeoip(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case strings.HasPrefix(r.URL.Path, "/w/api.php"):
			if strings.Contains(r.URL.RawQuery, "nothing") {
				w.Write([]byte(`{"query":{"search":[]}}`))
				return
			}
			w.Write([]byte(`{"query":{"search":[{"title":"Бишкек"}]}}`))
		case strings.HasPrefix(r.URL.Path, "/api/rest_v1/page/summary/"):
			w.Write([]byte(`{"title":"Бишкек","extract":"Столица Киргизии.","content_urls":{"desktop":{"page":"https://ru.wikipedia.org/wiki/Бишкек"}}}`))
		case r.URL.Path == "/repos/o/r":
			w.Write([]byte(`{"full_name":"o/r","description":"тест","stargazers_count":42,"forks_count":3,"open_issues_count":1,"language":"Go","pushed_at":"2026-10-01"}`))
		case r.URL.Path == "/repos/o/r/releases/latest":
			w.Write([]byte(`{"tag_name":"v1.2.3","published_at":"2026-09-30"}`))
		case r.URL.Path == "/8.8.8.8":
			w.Write([]byte(`{"success":true,"ip":"8.8.8.8","country":"United States","city":"Mountain View","connection":{"isp":"Google","org":"Google LLC"}}`))
		case r.URL.Path == "/bad":
			w.Write([]byte(`{"success":false,"message":"Invalid IP address"}`))
		default:
			http.NotFound(w, r)
		}
	}))
	defer srv.Close()
	ow, og, oi := wikiBase, githubBase, geoipBase
	wikiBase, githubBase, geoipBase = srv.URL, srv.URL, srv.URL
	defer func() { wikiBase, githubBase, geoipBase = ow, og, oi }()
	d := ownerDeps(t, 5)
	lt := lookupTool(d)
	if out := run(t, lt, Args{"kind": "wiki", "query": "Бишкек"}); !strings.Contains(out, "Столица Киргизии") || !strings.Contains(out, "wikipedia.org/wiki") {
		t.Fatal(out)
	}
	if out := run(t, lt, Args{"kind": "wiki", "query": "en:nothing"}); !strings.Contains(out, "nothing found") {
		t.Fatal(out)
	}
	if out := run(t, lt, Args{"kind": "github", "query": "https://github.com/o/r"}); !strings.Contains(out, "★ 42") || !strings.Contains(out, "v1.2.3") {
		t.Fatal(out)
	}
	if out := run(t, lt, Args{"kind": "github", "query": "just-a-name"}); !strings.HasPrefix(out, "ERR") {
		t.Fatal(out)
	}
	if out := run(t, lt, Args{"kind": "geoip", "query": "8.8.8.8"}); !strings.Contains(out, "Mountain View") || !strings.Contains(out, "Google") {
		t.Fatal(out)
	}
	if out := run(t, lt, Args{"kind": "geoip", "query": "bad"}); !strings.Contains(out, "Invalid IP") {
		t.Fatal(out)
	}
}
