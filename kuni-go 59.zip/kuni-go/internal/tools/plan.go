package tools

import (
	"context"
	"errors"
	"fmt"
	"strings"
	"time"

	"kuni/internal/reminders"
	"kuni/internal/telegram"
)

func (d Deps) zone() *time.Location {
	if tz := d.Cfg().AutonomyTimezone; tz != "" {
		if loc, err := time.LoadLocation(tz); err == nil {
			return loc
		}
	}
	return time.Local
}

// remindTool schedules a message to herself: when the time comes she is woken in that chat and speaks.
func remindTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name:        "remind",
		Description: "Set a reminder: at the given time you will be woken up in this chat and can write to the person. Use it when someone asks you to remind them, or when you promise to get back to them later.",
		Props: []Prop{
			{Name: "when", Type: "string", Desc: "A delay (45m, 2h, 1h30m, 1d) or a local time (18:30, tomorrow 09:00, 2026-10-21 09:00)."},
			{Name: "text", Type: "string", Desc: "What to remind about, in a few words."},
			{Name: "chat_id", Type: "integer", Nullable: true, Desc: "Another chat (owner only). Null = this chat."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			target := chat.ID
			if id := a.Int("chat_id"); id != 0 && id != chat.ID {
				if !IsOwnerChat(d, chat.ID) {
					return "", errors.New("you can only set reminders for the chat you are in")
				}
				target = id
			}
			now := time.Now()
			at, err := reminders.ParseWhen(a.Str("when"), now, d.zone())
			if err != nil {
				return "", err
			}
			it, err := d.Reminders.Add(at, target, a.Str("text"), now)
			if err != nil {
				return "", err
			}
			return fmt.Sprintf("Reminder #%d set for %s.", it.ID, at.In(d.zone()).Format("Mon 2 Jan 15:04")), nil
		},
	}
}

func remindersTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name:        "reminders",
		Description: "List the pending reminders of this chat, or cancel one.",
		Props:       []Prop{{Name: "cancel_id", Type: "integer", Nullable: true, Desc: "Reminder number to cancel. Null = just list."}},
		Run: func(ctx context.Context, a Args) (string, error) {
			scope := chat.ID
			if IsOwnerChat(d, chat.ID) {
				scope = 0 // the owner sees all of them
			}
			if id := a.Int("cancel_id"); id != 0 {
				if d.Reminders.Cancel(int(id), scope) {
					return fmt.Sprintf("Reminder #%d cancelled.", id), nil
				}
				return "", fmt.Errorf("no reminder #%d here", id)
			}
			list := d.Reminders.List(scope)
			if len(list) == 0 {
				return "No pending reminders.", nil
			}
			var b strings.Builder
			for _, it := range list {
				fmt.Fprintf(&b, "#%d %s (chat %d): %s\n", it.ID, it.At.In(d.zone()).Format("Mon 2 Jan 15:04"), it.Chat, it.Text)
			}
			return b.String(), nil
		},
	}
}

// rememberPersonTool writes a durable fact on somebody's card; the card is shown whenever that person talks to her.
func rememberPersonTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name: "remember_person",
		Description: "Write a durable fact about a person on their card (job, interests, preferences, promises, how to talk to them). " +
			"Cards are shown to you whenever they write. One short fact per call; do not store passwords, secrets or trivia.",
		Props: []Prop{
			{Name: "fact", Type: "string", Desc: "The fact, in a few words."},
			{Name: "user_id", Type: "integer", Nullable: true, Desc: "The person's user id (sender_id). Null = the person you are chatting with in a private chat."},
			{Name: "name", Type: "string", Nullable: true, Desc: "Their name, if you know it."},
			{Name: "private", Type: "boolean", Nullable: true, Desc: "True = never to be used in groups. Default: true in private chats, false in groups."},
			{Name: "replaces", Type: "string", Nullable: true, Desc: "Part of an OUTDATED fact on the card that this one replaces (e.g. the old city); that fact is overwritten instead of kept next to it."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			id := a.Int("user_id")
			if id == 0 && chat.Kind == telegram.ChatPrivate {
				id = chat.ID
			}
			if id == 0 {
				return "", errors.New("user_id is required in a group (sender_id of the message)")
			}
			if id == d.TG.MyID() {
				return "", errors.New("that is you")
			}
			private := chat.Kind == telegram.ChatPrivate
			if a.Has("private") {
				private = a.Bool("private")
			}
			name := a.Str("name")
			if name == "" && chat.Kind == telegram.ChatPrivate && id == chat.ID {
				name = chat.Title
			}
			if old := strings.TrimSpace(a.Str("replaces")); old != "" {
				done, err := d.People.Supersede(id, name, old, a.Str("fact"), private, time.Now())
				if err != nil {
					return "", err
				}
				if done {
					return "Noted, the old fact is replaced.", nil
				}
				return "Noted (no fact like that to replace, so it was added).", nil
			}
			if err := d.People.Add(id, name, a.Str("fact"), private, time.Now()); err != nil {
				return "", err
			}
			return "Noted.", nil
		},
	}
}

func forgetPersonTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name:        "forget_person_fact",
		Description: "Remove facts from a person's card (those that contain the given words), e.g. when they were wrong or the person asks you to forget.",
		Props: []Prop{
			{Name: "contains", Type: "string", Desc: "Words of the fact to remove."},
			{Name: "user_id", Type: "integer", Nullable: true, Desc: "Null = the person you are chatting with in a private chat."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			id := a.Int("user_id")
			if id == 0 && chat.Kind == telegram.ChatPrivate {
				id = chat.ID
			}
			if id == 0 {
				return "", errors.New("user_id is required in a group")
			}
			n := d.People.Forget(id, a.Str("contains"))
			return fmt.Sprintf("Removed %d fact(s).", n), nil
		},
	}
}
