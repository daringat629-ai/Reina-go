package tools

import (
	"archive/zip"
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"kuni/internal/dates"
	"kuni/internal/ledger"
	"kuni/internal/telegram"
	"kuni/internal/tracker"
	"kuni/internal/web"
)

func lifeDeps(t *testing.T) (Deps, *telegram.Fake) {
	d := ownerDeps(t, 5)
	dir := d.Cfg().DataDir
	d.Ledger = ledger.New(filepath.Join(dir, "ledger.json"))
	d.Tracker = tracker.New(filepath.Join(dir, "tracker.json"))
	d.Dates = dates.New(filepath.Join(dir, "dates.json"))
	d.Cfg().AutonomyTimezone = "Asia/Bishkek"
	d.Cfg().BrowserPath = os.Getenv("KUNI_TEST_CHROME")
	t.Cleanup(d.RT.Close)
	return d, d.TG.(*telegram.Fake)
}

var owner = telegram.Chat{ID: 5, Kind: telegram.ChatPrivate}

func use(t *testing.T, tl Tool, a Args) string {
	t.Helper()
	out, err := tl.Run(context.Background(), a)
	if err != nil {
		t.Fatalf("%s %v: %v", tl.Name, a, err)
	}
	return out
}

func TestMakeDocumentAndTable(t *testing.T) {
	d, tg := lifeDeps(t)
	out := use(t, makeDocumentTool(d, owner), Args{"text": "# План\n\n- раз\n- два\n\n| a | b |\n|---|---|\n| 1 | 2 |", "title": "План на неделю"})
	if !strings.Contains(out, "documents/План на неделю.docx") || !strings.Contains(out, "Sent") {
		t.Fatal(out)
	}
	docs := tg.Docs()
	if len(docs) != 1 || docs[0].Name != "План на неделю.docx" {
		t.Fatalf("sent %+v", docs)
	}
	if _, err := zip.NewReader(bytes.NewReader(docs[0].Data), int64(len(docs[0].Data))); err != nil {
		t.Fatal("not a docx:", err)
	}
	// the same name again does not overwrite the first file
	out = use(t, makeDocumentTool(d, owner), Args{"text": "x", "title": "План на неделю", "send": false})
	if strings.Contains(out, "Sent") || !strings.Contains(out, "План на неделю-") {
		t.Fatal(out)
	}
	if out := use(t, makeDocumentTool(d, owner), Args{"text": "# H", "format": "html", "send": false}); !strings.Contains(out, ".html") {
		t.Fatal(out)
	}
	if _, err := makeDocumentTool(d, owner).Run(context.Background(), Args{"text": "x", "format": "odt"}); err == nil {
		t.Fatal("unknown format")
	}
	out = use(t, makeTableTool(d, owner), Args{"data": "Статья;Сумма\nЕда;1 200,5\nИтого;=СУММ(B2:B2)", "filename": "бюджет"})
	if !strings.Contains(out, "бюджет.xlsx: 1 sheet(s), 3 rows") {
		t.Fatal(out)
	}
	if docs := tg.Docs(); len(docs) != 2 || docs[1].Name != "бюджет.xlsx" {
		t.Fatalf("%+v", docs)
	}
	out = use(t, makeTableTool(d, owner), Args{"data": `[["a","b"],[1,2]]`, "format": "csv", "send": false})
	p := filepath.Join(d.workDir(), strings.TrimSuffix(strings.Fields(strings.TrimPrefix(out, "Made "))[0], ":"))
	if b, err := os.ReadFile(p); err != nil || !strings.HasPrefix(string(b), "\ufeffa,b") {
		t.Fatalf("%q %v", b, err)
	}
}

func TestMakePDFWhenAToolIsThere(t *testing.T) {
	d, tg := lifeDeps(t)
	out, err := makeDocumentTool(d, owner).Run(context.Background(), Args{"text": "# Привет\n\nТекст.", "format": "pdf"})
	if err != nil {
		if strings.Contains(err.Error(), "neither is installed") {
			t.Skip("no LibreOffice and no Chromium here")
		}
		t.Fatal(err)
	}
	docs := tg.Docs()
	if len(docs) != 1 || !bytes.HasPrefix(docs[0].Data, []byte("%PDF")) {
		t.Fatalf("%s %+v", out, docs)
	}
}

func TestChartQRInvite(t *testing.T) {
	d, tg := lifeDeps(t)
	out := use(t, makeChartTool(d, owner), Args{"kind": "bar", "data": "Месяц,Расходы\nЯнв,100\nФев,150", "title": "Расходы"})
	if !strings.Contains(out, "charts/Расходы.") {
		t.Fatal(out)
	}
	if _, err := makeChartTool(d, owner).Run(context.Background(), Args{"kind": "radar", "data": "a,1"}); err == nil {
		t.Fatal("unknown kind")
	}
	out = use(t, qrTool(d, owner), Args{"text": "Дом", "kind": "wifi", "password": "p;ss"})
	if !strings.Contains(out, `WIFI:T:WPA;S:Дом;P:p\;ss;;`) {
		t.Fatal(out)
	}
	if last := tg.Sent[len(tg.Sent)-1]; last.Media != telegram.MediaPhoto {
		t.Fatalf("the code goes as a picture: %+v", last)
	}
	before := len(tg.Docs())
	out = use(t, inviteTool(d, owner), Args{"title": "Стоматолог", "start": "2030-03-05 15:30", "duration_mins": 45.0, "location": "Киевская 1"})
	if !strings.Contains(out, "5 марта 2030 15:30") {
		t.Fatal(out)
	}
	docs := tg.Docs()
	if len(docs) != before+1 || docs[len(docs)-1].Name != "Стоматолог.ics" {
		t.Fatalf("%+v", docs)
	}
	ics := string(docs[len(docs)-1].Data)
	if !strings.Contains(ics, "DTSTART:20300305T093000Z") || !strings.Contains(ics, "DTEND:20300305T101500Z") {
		t.Fatalf("Bishkek time in UTC:\n%s", ics)
	}
}

func TestLedgerTool(t *testing.T) {
	d, tg := lifeDeps(t)
	tl := ledgerTool(d, owner)
	if _, err := tl.Run(context.Background(), Args{"action": "add", "amount": 500.0, "category": "такси"}); err == nil {
		t.Fatal("no currency yet")
	}
	out := use(t, tl, Args{"action": "add", "amount": "1 200 сом", "category": "Еда", "note": "продукты"})
	if !strings.Contains(out, "расход 1 200 KGS, еда") {
		t.Fatal(out)
	}
	use(t, tl, Args{"action": "add", "amount": 300.0, "category": "такси", "date": "вчера"})
	use(t, tl, Args{"action": "add", "amount": 50000.0, "category": "зарплата", "kind": "income"})
	use(t, tl, Args{"action": "budget", "category": "еда", "amount": 1300.0})
	out = use(t, tl, Args{"action": "add", "amount": 200.0, "category": "еда"})
	if !strings.Contains(out, "BUDGET EXCEEDED") {
		t.Fatal(out)
	}
	out = use(t, tl, Args{"action": "report", "period": "month"})
	if !strings.Contains(out, "потрачено 1 700") || !strings.Contains(out, "еда — 1 400") || !strings.Contains(out, "ПРЕВЫШЕН") {
		// yesterday may be last month on the first day of a month
		if time.Now().In(zoneOf(d)).Day() != 1 {
			t.Fatal(out)
		}
	}
	out = use(t, tl, Args{"action": "list", "period": "week", "text": "продукт"})
	if !strings.Contains(out, "1 записей") || !strings.Contains(out, "-1 200 KGS еда — продукты") {
		t.Fatal(out)
	}
	use(t, tl, Args{"action": "export", "period": "all"})
	if docs := tg.Docs(); len(docs) != 1 || !strings.HasSuffix(docs[0].Name, ".xlsx") {
		t.Fatalf("%+v", docs)
	}
	use(t, tl, Args{"action": "chart", "period": "all"})
	if out := use(t, tl, Args{"action": "delete", "id": 1.0}); !strings.Contains(out, "Удалено #1") {
		t.Fatal(out)
	}
}

func TestTrackerAndDatesTools(t *testing.T) {
	d, _ := lifeDeps(t)
	tr := trackerTool(d, owner)
	out := use(t, tr, Args{"action": "log", "name": "вес", "value": 78.4})
	if !strings.Contains(out, "Новый трекер «вес» (показатель)") || !strings.Contains(out, "78,4") {
		t.Fatal(out)
	}
	use(t, tr, Args{"action": "add", "name": "зарядка", "kind": "habit"})
	use(t, tr, Args{"action": "log", "name": "зарядка", "date": "вчера"})
	out = use(t, tr, Args{"action": "log", "name": "зарядка"})
	if !strings.Contains(out, "сегодня ✓; серия 2 дня") {
		t.Fatal(out)
	}
	if out := use(t, tr, Args{"action": "status"}); !strings.Contains(out, "«вес»") || !strings.Contains(out, "«зарядка»") {
		t.Fatal(out)
	}
	ds := datesTool(d, owner)
	out = use(t, ds, Args{"action": "add", "name": "ДР мамы", "date": "12.03.1965", "note": "купить цветы"})
	if !strings.Contains(out, "ДР мамы — 12 марта") || !strings.Contains(out, "купить цветы") || !strings.Contains(out, "исполнится") {
		t.Fatal(out)
	}
	out = use(t, ds, Args{"action": "add", "name": "годовщина", "date": "1 июня"})
	if strings.Contains(out, "исполнится") || strings.Contains(out, "лет") {
		t.Fatalf("no year, no age: %s", out)
	}
	if out := use(t, ds, Args{"action": "list"}); strings.Count(out, "\n") != 2 {
		t.Fatal(out)
	}
}

func TestUtilTools(t *testing.T) {
	d, _ := lifeDeps(t)
	dt := datetimeTool(d)
	if out := use(t, dt, Args{"action": "weekday", "when": "2026-03-12"}); !strings.HasPrefix(out, "четверг, 12 марта 2026") {
		t.Fatal(out)
	}
	if out := use(t, dt, Args{"action": "diff", "when": "2026-01-01", "other": "2026-03-01"}); !strings.Contains(out, ": 59 дней (8 нед. 3 дн.; 2 мес.)") || !strings.Contains(out, "рабочих дней (пн-пт) 42") {
		t.Fatal(out)
	}
	if out := use(t, dt, Args{"action": "add", "when": "2026-01-31 10:00", "amount": "1 месяц 2 дня"}); !strings.Contains(out, "= понедельник, 2 марта 2026, 10:00") {
		t.Fatal(out)
	}
	if out := use(t, dt, Args{"action": "convert", "when": "2026-06-01 12:00", "tz": "Бишкек", "to": "Москва, Tokyo, UTC-3"}); !strings.Contains(out, "09:00 (Europe/Moscow") || !strings.Contains(out, "15:00 (Asia/Tokyo") || !strings.Contains(out, "03:00 (UTC-3") {
		t.Fatal(out)
	}
	if out := use(t, dt, Args{"action": "month", "when": "2026-02"}); !strings.Contains(out, "ФЕВРАЛЬ 2026") || !strings.Contains(out, "                   1") {
		t.Fatal(out)
	}
	if out := use(t, unitsTool(), Args{"value": 100.0, "from": "°F", "to": "°C"}); out != "100 °F = 37.7778 °C" {
		t.Fatal(out)
	}
	rnd := randomTool()
	for i := 0; i < 50; i++ {
		out := use(t, rnd, Args{"action": "number", "min": 1.0, "max": 3.0})
		if !strings.HasSuffix(out, ": 1") && !strings.HasSuffix(out, ": 2") && !strings.HasSuffix(out, ": 3") {
			t.Fatal(out)
		}
	}
	if out := use(t, rnd, Args{"action": "dice", "dice": "3d6+2"}); !strings.Contains(out, "Бросок 3d6+2: [") {
		t.Fatal(out)
	}
	out := use(t, rnd, Args{"action": "pick", "items": "Аня, Боря, Вика", "count": 2.0})
	if !strings.HasPrefix(out, "Выбрано (2 из 3): ") || strings.Count(out, ",") != 1 {
		t.Fatal(out)
	}
	if !MetaOf("random").Repeatable {
		t.Fatal("random must be repeatable: the same call gives a new result")
	}
}

func TestPlacesWithFakeOSM(t *testing.T) {
	d, _ := lifeDeps(t)
	var agent string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		agent = r.UserAgent()
		switch {
		case strings.HasPrefix(r.URL.Path, "/search"):
			fmt.Fprint(w, `[{"lat":"42.8746","lon":"74.6122","display_name":"Бишкек, Киевская 1","category":"place","type":"house"}]`)
		case strings.HasPrefix(r.URL.Path, "/reverse"):
			fmt.Fprint(w, `{"display_name":"Киевская улица, 1, Бишкек"}`)
		case r.URL.Path == "/interpreter":
			r.ParseForm()
			if !strings.Contains(r.Form.Get("data"), `nwr["amenity"="pharmacy"](around:500,42.874600,74.612200)`) {
				http.Error(w, "bad query "+r.Form.Get("data"), 400)
				return
			}
			fmt.Fprint(w, `{"elements":[{"lat":42.8760,"lon":74.6122,"tags":{"name":"Неман","opening_hours":"24/7","addr:street":"Киевская","addr:housenumber":"10"}},`+
				`{"center":{"lat":42.8750,"lon":74.6122},"tags":{"name":"Аптека 1"}}]}`)
		case strings.HasPrefix(r.URL.Path, "/routed-foot/"):
			fmt.Fprint(w, `{"code":"Ok","routes":[{"distance":1530,"duration":1150}]}`)
		default:
			http.NotFound(w, r)
		}
	}))
	defer srv.Close()
	d.Places = PlacesAPI{Nominatim: srv.URL, Overpass: srv.URL + "/interpreter", Routing: srv.URL, Client: web.Fetcher{AllowPrivate: true}.Client()}
	pl := placesTool(d)
	out := use(t, pl, Args{"action": "nearby", "what": "аптеку", "near": "Киевская 1, Бишкек", "radius": 500.0})
	if !strings.Contains(out, "1. Аптека 1 — 40 м") || !strings.Contains(out, "2. Неман — 160 м, Киевская 10; часы: 24/7") || !strings.Contains(out, "maps.google.com/?q=42.875000,74.612200") {
		t.Fatal(out)
	}
	if !strings.HasPrefix(agent, "kuni-go/") {
		t.Fatalf("OpenStreetMap wants the program named: %q", agent)
	}
	out = use(t, pl, Args{"action": "route", "from": "42.87,74.60", "to": "Киевская 1", "mode": "пешком"})
	if !strings.Contains(out, "Маршрут пешком: 1,5 км, примерно 19 мин") || !strings.Contains(out, "travelmode=walking") {
		t.Fatal(out)
	}
	if out := use(t, pl, Args{"action": "address", "near": "42.8746, 74.6122"}); !strings.Contains(out, "Киевская улица, 1") {
		t.Fatal(out)
	}
}

func TestDockerToolWithAFakeBinary(t *testing.T) {
	dir := t.TempDir()
	script := "#!/bin/sh\necho \"$@\" >> " + filepath.Join(dir, "calls") + "\ncase \"$1\" in\nps) printf 'web\\tUp 2 hours\\tnginx:1\\t0.0.0.0:80->80/tcp\\n';;\nlogs) echo 'line 1'; echo 'error 2' >&2;;\nrestart) echo web;;\nstats) exit 1;;\nesac\n"
	os.WriteFile(filepath.Join(dir, "docker"), []byte(script), 0o755)
	t.Setenv("PATH", dir+string(os.PathListSeparator)+os.Getenv("PATH"))
	d, _ := lifeDeps(t)
	tl := dockerTool(d)
	if out := use(t, tl, Args{"action": "ps"}); !strings.Contains(out, "web\tUp 2 hours\tnginx:1") {
		t.Fatal(out)
	}
	if out := use(t, tl, Args{"action": "logs", "container": "web", "lines": 5.0, "since": "10m"}); !strings.Contains(out, "line 1") || !strings.Contains(out, "error 2") {
		t.Fatal(out)
	}
	if _, err := tl.Run(context.Background(), Args{"action": "logs", "container": "web; rm -rf /"}); err == nil {
		t.Fatal("a name with shell in it must be refused")
	}
	if _, err := tl.Run(context.Background(), Args{"action": "stats"}); err == nil {
		t.Fatal("a failing docker must be an error")
	}
	use(t, tl, Args{"action": "restart", "container": "web"})
	calls, _ := os.ReadFile(filepath.Join(dir, "calls"))
	if !strings.Contains(string(calls), "logs --tail 5 --timestamps --since 10m web") || !strings.Contains(string(calls), "restart web") {
		t.Fatal(string(calls))
	}
	if RiskOf("docker", `{"action":"restart","container":"web"}`, 5) == "" || RiskOf("docker", `{"action":"ps"}`, 5) != "" {
		t.Fatal("restart waits for the owner's yes, ps does not")
	}
}

func TestNewToolsAreGroupedAndShaped(t *testing.T) {
	d, _ := lifeDeps(t)
	all := append(append(OwnerTools(d, owner), ChatTools(d, owner).All()...), UtilTools(d)...)
	groups := map[string]string{"make_document": "make", "make_table": "make", "make_chart": "make", "qr_code": "make", "calendar_invite": "make",
		"ledger": "life", "tracker": "life", "dates": "life", "places": "life", "datetime": "util", "units": "util", "random": "util", "docker": "system"}
	seen := map[string]bool{}
	for _, tl := range all {
		tl = withMeta(tl)
		if g, ok := groups[tl.Name]; ok {
			seen[tl.Name] = true
			if tl.Group != g {
				t.Errorf("%s in group %q, want %q", tl.Name, tl.Group, g)
			}
		}
		// every schema is valid JSON with all properties required (strict mode)
		raw, err := json.Marshal(tl.Schema())
		if err != nil || !strings.Contains(string(raw), `"additionalProperties":false`) {
			t.Errorf("%s schema: %v", tl.Name, err)
		}
		if _, mine := groups[tl.Name]; mine && len(tl.Description) > 1000 {
			t.Errorf("%s: description of %d characters is too long for every request", tl.Name, len(tl.Description))
		}
	}
	for name := range groups {
		if !seen[name] {
			t.Errorf("%s is not registered", name)
		}
	}
	if _, ok := Groups()["life"]; !ok {
		t.Fatal("no life group for #more_tools")
	}
}

// With a relative data_dir (the default "data"), a made file is still found when it is sent.
func TestMadeFilesWithARelativeDataDir(t *testing.T) {
	d, tg := lifeDeps(t)
	t.Chdir(d.Cfg().DataDir)
	d.Cfg().DataDir = "data"
	out := use(t, makeTableTool(d, owner), Args{"data": "a,b\n1,2", "filename": "t"})
	if !strings.Contains(out, "Sent to the chat") || !strings.Contains(out, "documents/t.xlsx") {
		t.Fatal(out)
	}
	if len(tg.Docs()) != 1 {
		t.Fatal("not sent")
	}
}

func TestPlaceWordsByStem(t *testing.T) {
	for what, want := range map[string]string{"аптеку": `"amenity"="pharmacy"`, "парковку": `"amenity"="parking"`, "парк": `"leisure"="park"`,
		"банкоматы": `"amenity"="atm"`, "Глобус": `"name"~"Глобус",i`} {
		for i := 0; i < 5; i++ {
			if q := overpassQuery(what, 1, 2, 300); !strings.Contains(q, want) {
				t.Fatalf("%s: %s", what, q)
			}
		}
	}
}
