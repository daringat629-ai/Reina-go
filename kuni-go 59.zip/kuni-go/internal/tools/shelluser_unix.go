//go:build !windows

package tools

import (
	"fmt"
	"os"
	"os/exec"
	"os/user"
	"strconv"
	"syscall"
)

// runAs makes cmd run as the given unprivileged user (needs the process to be root) and returns an error when
// that is impossible, so a bad setting never silently falls back to root.
func runAs(c *exec.Cmd, name, workDir string) error {
	u, err := user.Lookup(name)
	if err != nil {
		return fmt.Errorf("shell_user %q: %w (create it: adduser -D %s)", name, err, name)
	}
	uid, _ := strconv.ParseUint(u.Uid, 10, 32)
	gid, _ := strconv.ParseUint(u.Gid, 10, 32)
	if os.Geteuid() != 0 {
		if int(uid) == os.Geteuid() {
			return nil // already that user
		}
		return fmt.Errorf("shell_user %q: only root can switch users", name)
	}
	if uid == 0 {
		return nil
	}
	_ = os.Chown(workDir, int(uid), int(gid)) // the workspace itself must be writable for her
	c.SysProcAttr = &syscall.SysProcAttr{Credential: &syscall.Credential{Uid: uint32(uid), Gid: uint32(gid)}}
	home := u.HomeDir
	if home == "" {
		home = workDir
	}
	c.Env = append(os.Environ(), "HOME="+home, "USER="+name, "LOGNAME="+name)
	return nil
}
