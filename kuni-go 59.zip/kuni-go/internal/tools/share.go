package tools

import (
	"context"
	"fmt"
	"path/filepath"
	"strings"

	"kuni/internal/telegram"
)

// shareRoots are the folders she may send files from in a chat that is not the owner's: her workspace and the
// folders the owner listed in capabilities.share_dirs.
func shareRoots(d Deps) []string {
	roots := []string{d.workDir()}
	for _, r := range strings.Split(d.Cfg().ShareDirs, ",") {
		if r = strings.TrimSpace(r); r != "" && filepath.IsAbs(r) {
			roots = append(roots, filepath.Clean(r))
		}
	}
	var out []string
	for _, r := range roots {
		if real, err := filepath.EvalSymlinks(r); err == nil {
			r = real
		}
		out = append(out, r)
	}
	return out
}

// secretName says whether a file looks like a credential; those never leave, whatever the folder.
func secretName(name string) bool {
	n := strings.ToLower(filepath.Base(name))
	switch {
	case strings.HasPrefix(n, "config.toml"), n == ".env", strings.HasPrefix(n, ".env."), n == ".netrc", n == "shadow", n == "passwd",
		strings.HasPrefix(n, "id_rsa"), strings.HasPrefix(n, "id_ed25519"), strings.HasPrefix(n, "id_ecdsa"), n == "authorized_keys",
		strings.HasSuffix(n, ".pem"), strings.HasSuffix(n, ".key"), strings.HasSuffix(n, ".session"), strings.HasSuffix(n, ".kdbx"),
		n == "carry.json", n == "sched.json", n == "ignore.json":
		return true
	}
	return false
}

// shareFileTool is her way to hand a file over in any chat: from her workspace or a folder the owner opened for it.
func shareFileTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name: "share_file",
		Description: "Send a file to this chat. You may send files from your workspace and from the folders your owner opened (a folder path lists what is in it). " +
			"Use it when somebody asks you for a file, a script or a result: do not say you cannot. Code that fits in a message goes in a ``` block instead. Max 50 MB. Never credentials.",
		Props: []Prop{
			{Name: "path", Type: "string", Desc: "File path (relative = inside your workspace), or a folder to list."},
			{Name: "caption", Type: "string", Nullable: true, Desc: "Optional caption."},
			{Name: "as", Type: "string", Nullable: true, Desc: "auto (video, gif, music, pictures as what they are) or file (a plain file)."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			roots := shareRoots(d)
			ok := func(real string) error {
				if secretName(real) {
					return fmt.Errorf("that file holds credentials and is never sent")
				}
				for _, r := range roots {
					if inside(r, real) {
						return nil
					}
				}
				return fmt.Errorf("that path is outside the folders you may share from (your owner can add folders in capabilities.share_dirs)")
			}
			return deliverFile(ctx, d, chat.ID, a.Str("path"), a.Str("caption"), a.Str("as"), ok)
		},
	}
}
