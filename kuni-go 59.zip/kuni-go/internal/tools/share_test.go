package tools

import (
	"os"
	"path/filepath"
	"strings"
	"testing"

	"kuni/internal/telegram"
)

func TestShareFileOnlyFromAllowedFolders(t *testing.T) {
	d := ownerDeps(t, 100)
	cfg := d.Cfg()
	work, pub, secret := t.TempDir(), t.TempDir(), t.TempDir()
	cfg.ShellDir = work
	os.WriteFile(filepath.Join(work, "report.txt"), []byte("report"), 0o644)
	os.WriteFile(filepath.Join(pub, "calc.asm"), []byte("mov"), 0o644)
	os.WriteFile(filepath.Join(pub, "config.toml"), []byte("token"), 0o644)
	os.WriteFile(filepath.Join(secret, "bank.txt"), []byte("secret"), 0o644)
	os.Symlink(filepath.Join(secret, "bank.txt"), filepath.Join(pub, "link.txt"))
	tg := telegram.NewFake()
	d.TG = tg
	friend := telegram.Chat{ID: 55, Title: "Friend", Kind: telegram.ChatPrivate, IsMember: true}
	tl := shareFileTool(d, friend)

	// the workspace is always open
	if out := run(t, tl, Args{"path": "report.txt"}); !strings.Contains(out, "sent report.txt") {
		t.Fatal(out)
	}
	// a folder that is not opened is closed
	if out := run(t, tl, Args{"path": filepath.Join(pub, "calc.asm")}); !strings.HasPrefix(out, "ERR") || !strings.Contains(out, "share_dirs") {
		t.Fatal(out)
	}
	cfg.ShareDirs = pub + " , relative/ignored"
	if out := run(t, tl, Args{"path": filepath.Join(pub, "calc.asm"), "as": "file"}); !strings.Contains(out, "sent calc.asm") {
		t.Fatal(out)
	}
	if out := run(t, tl, Args{"path": pub}); !strings.Contains(out, "calc.asm (3 Б)") || strings.Contains(out, "config.toml") {
		t.Fatal(out) // a folder lists its files
	}
	// credentials never leave, a symlink out of the folder is followed and refused, so is .. tricks
	for _, bad := range []string{filepath.Join(pub, "config.toml"), filepath.Join(pub, "link.txt"), filepath.Join(pub, "..", filepath.Base(secret), "bank.txt"), "/etc/passwd"} {
		if out := run(t, tl, Args{"path": bad}); !strings.HasPrefix(out, "ERR") {
			t.Fatalf("%s was sent: %s", bad, out)
		}
	}
	if n := len(tg.Docs()); n != 2 {
		t.Fatalf("%d files sent", n)
	}
	pd, _ := peopleDeps(t, 100)
	pd.Cfg().OwnerTools = true
	// the owner's chat has send_file instead, and it reaches any path and other chats
	if _, ok := ChatTools(pd, telegram.Chat{ID: 100, Kind: telegram.ChatPrivate, IsMember: true}).Get("share_file"); ok {
		t.Fatal("share_file in the owner's chat")
	}
	if _, ok := ChatTools(pd, friend).Get("share_file"); !ok {
		t.Fatal("no share_file for a friend")
	}
	ow := sendFileTool(d, telegram.Chat{ID: 100})
	if out := run(t, ow, Args{"path": filepath.Join(secret, "bank.txt"), "chat_id": float64(55)}); !strings.Contains(out, "sent bank.txt") {
		t.Fatal(out)
	}
	if docs := tg.Docs(); docs[len(docs)-1].Name != "bank.txt" {
		t.Fatal("not sent")
	}
	// the folder listing works for the owner too
	if out := run(t, ow, Args{"path": secret}); !strings.Contains(out, "bank.txt (6 Б)") {
		t.Fatal(out)
	}
}
