package tools

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"os/exec"
	"regexp"
	"strconv"
	"strings"
	"time"
)

// docker.go: the containers of the machine (Docker, or Podman when Docker is absent): what runs, how much it eats,
// its logs, and restarting what hangs. Stopping and restarting wait for the owner's yes (tools.RiskOf).

var reContainer = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$`)

func dockerBin() string {
	for _, b := range []string{"docker", "podman"} {
		if p, err := exec.LookPath(b); err == nil {
			return p
		}
	}
	return ""
}

func dockerTool(d Deps) Tool {
	return Tool{
		Name: "docker",
		Description: "Containers of the machine (Docker or Podman; owner only): ps (all = stopped too), stats (CPU and memory now), logs (container, lines, since: 10m, 1h), " +
			"inspect (state, restarts, health, ports, image), top (processes inside), images, start, stop, restart (stop and restart wait for his yes).",
		Props: []Prop{
			{Name: "action", Type: "string", Desc: "ps, stats, logs, inspect, top, images, start, stop or restart."},
			{Name: "container", Type: "string", Nullable: true, Desc: "The container name or id."},
			{Name: "all", Type: "boolean", Nullable: true, Desc: "ps: stopped containers too."},
			{Name: "lines", Type: "integer", Nullable: true, Desc: "logs: how many last lines (default 80)."},
			{Name: "since", Type: "string", Nullable: true, Desc: "logs: only newer than this (10m, 2h)."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			bin := dockerBin()
			if bin == "" {
				return "", errors.New("neither docker nor podman is installed here")
			}
			act := strings.ToLower(strings.TrimSpace(a.Str("action")))
			name := strings.TrimSpace(a.Str("container"))
			needName := map[string]bool{"logs": true, "inspect": true, "top": true, "start": true, "stop": true, "restart": true}
			if needName[act] && !reContainer.MatchString(name) {
				return "", fmt.Errorf("a container name is needed (from ps), not %q", name)
			}
			var args []string
			timeout := 30 * time.Second
			switch act {
			case "ps", "":
				args = []string{"ps", "--format", "{{.Names}}\t{{.Status}}\t{{.Image}}\t{{.Ports}}"}
				if a.Bool("all") {
					args = append(args, "--all")
				}
			case "stats":
				args = []string{"stats", "--no-stream", "--format", "{{.Name}}\tCPU {{.CPUPerc}}\tRAM {{.MemUsage}} ({{.MemPerc}})\tnet {{.NetIO}}\tdisk {{.BlockIO}}"}
				timeout = 60 * time.Second
			case "logs":
				n := a.Int("lines")
				if n <= 0 {
					n = 80
				}
				args = []string{"logs", "--tail", strconv.FormatInt(min(n, 1000), 10), "--timestamps"}
				if s := strings.TrimSpace(a.Str("since")); s != "" {
					args = append(args, "--since", s)
				}
				args = append(args, name)
			case "inspect":
				args = []string{"inspect", "--format", "name {{.Name}}\nstate {{.State.Status}} (since {{.State.StartedAt}}, exit {{.State.ExitCode}}{{if .State.Error}}, error {{.State.Error}}{{end}})\n" +
					"restarts {{.RestartCount}}, policy {{.HostConfig.RestartPolicy.Name}}\n{{if .State.Health}}health {{.State.Health.Status}}\n{{end}}" +
					"image {{.Config.Image}}\nports {{range $p, $b := .NetworkSettings.Ports}}{{$p}}{{if $b}}->{{(index $b 0).HostPort}}{{end}} {{end}}\n" +
					"mounts {{range .Mounts}}{{.Source}}:{{.Destination}} {{end}}", name}
			case "top":
				args = []string{"top", name}
			case "images":
				args = []string{"images", "--format", "{{.Repository}}:{{.Tag}}\t{{.Size}}\t{{.CreatedSince}}"}
			case "start", "stop", "restart":
				args = []string{act, name}
				timeout = 90 * time.Second
			default:
				return "", errors.New("action is ps, stats, logs, inspect, top, images, start, stop or restart")
			}
			cctx, cancel := context.WithTimeout(ctx, timeout)
			defer cancel()
			cmd := exec.CommandContext(cctx, bin, args...)
			var out bytes.Buffer
			cmd.Stdout, cmd.Stderr = &out, &out
			err := cmd.Run()
			text := strings.TrimSpace(out.String())
			if act == "start" || act == "stop" || act == "restart" {
				code := 0
				if err != nil {
					code = 1
				}
				d.journal("docker "+act+" "+name, code)
			}
			if err != nil {
				if text == "" {
					text = err.Error()
				}
				if strings.Contains(text, "permission denied") {
					text += "\n(the program's user has no access to the Docker socket: add it to the docker group)"
				}
				return "", errors.New(Truncate(text, 1500))
			}
			if text == "" {
				switch act {
				case "ps":
					text = "No containers are running."
				case "start", "stop", "restart":
					text = "Done: " + act + " " + name
				default:
					text = "(empty)"
				}
			}
			return Truncate(text, maxOut), nil
		},
	}
}
