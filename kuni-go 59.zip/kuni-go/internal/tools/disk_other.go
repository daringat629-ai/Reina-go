//go:build windows

package tools

func diskFree(path string) (total, free int64, ok bool) { return 0, 0, false }
