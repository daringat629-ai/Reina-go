package tools

import (
	"sync"
	"time"
)

// talkLog remembers, in memory and for all turns, which group messages she already replied to. The history she reads from
// Telegram can lag behind what she has just sent, and every new message in a busy group starts a new turn: without this a
// turn that begins a second after the first one answers the same message again.
type talkLog struct {
	mu      sync.Mutex
	replied map[int64]map[int64]time.Time // chat -> message id -> when she replied to it
}

const repliedTTL = 10 * time.Minute

func (t *talkLog) seen(chat, id int64, now time.Time) bool {
	t.mu.Lock()
	defer t.mu.Unlock()
	at, ok := t.replied[chat][id]
	return ok && now.Sub(at) < repliedTTL
}

func (t *talkLog) mark(chat, id int64, now time.Time) {
	t.mu.Lock()
	defer t.mu.Unlock()
	if t.replied == nil {
		t.replied = map[int64]map[int64]time.Time{}
	}
	m := t.replied[chat]
	if m == nil {
		m = map[int64]time.Time{}
		t.replied[chat] = m
	}
	for k, at := range m {
		if now.Sub(at) > repliedTTL {
			delete(m, k)
		}
	}
	m[id] = now
}
