package tools

import (
	"context"
	"errors"
	"fmt"
	"strings"
	"time"

	"kuni/internal/llmui"
	"kuni/internal/telegram"
)

// GlobalTools are available outside of a particular chat (acting proactively, chat list, search).
func GlobalTools(d Deps, proactive bool) []Tool {
	ts := []Tool{getChatsTool(d, proactive), searchChatsTool(d), searchMessagesTool(d), removeAndBanChatTool(d)}
	if d.OpenChat != nil {
		ts = append(ts, openChatTool(d))
	}
	return ts
}

func getChatsTool(d Deps, proactive bool) Tool {
	return Tool{
		Name:        "get_telegram_chats",
		Description: "Returns a list of Telegram chats. Use this to seek chat_ids, looking for existing chats and unread chats, or to start a new conversation.",
		Run: func(ctx context.Context, a Args) (string, error) {
			chats, err := d.TG.Chats(ctx, 50)
			if err != nil {
				return "", err
			}
			now := time.Now()
			var b strings.Builder
			// oldest first, newest last: LLMs tend to prioritize chats from the top of the list.
			for i := len(chats) - 1; i >= 0; i-- {
				c := chats[i]
				if !d.Accessible(c.ID) {
					continue
				}
				if proactive && c.Unread > 0 {
					continue // unread chats reach the model through notifications anyway
				}
				b.WriteString(llmui.FormatChat(c, now) + "\n")
			}
			if b.Len() == 0 {
				return "No chats", nil
			}
			return b.String(), nil
		},
	}
}

func searchChatsTool(d Deps) Tool {
	return Tool{
		Name:        "search_chats",
		Description: "Search chats and people you know by name or @username.",
		Props:       []Prop{{Name: "query", Type: "string", Desc: "Name or @username."}},
		Run: func(ctx context.Context, a Args) (string, error) {
			chats, err := d.TG.SearchChats(ctx, a.Str("query"))
			if err != nil {
				return "", err
			}
			var b strings.Builder
			for _, c := range chats {
				if d.Accessible(c.ID) {
					b.WriteString(llmui.FormatChat(c, time.Now()) + "\n")
				}
			}
			if b.Len() == 0 {
				return "Nothing found", nil
			}
			return b.String(), nil
		},
	}
}

func searchMessagesTool(d Deps) Tool {
	return Tool{
		Name:        "search_messages",
		Description: "Verbatim message search across chats (or one chat / sender / date range), like search in the official Telegram client. Does not use the diary.",
		Props: []Prop{
			{Name: "query", Type: "string", Nullable: true, Desc: "Text to find (case-insensitive substring)."},
			{Name: "chat_id", Type: "integer", Nullable: true, Desc: "Limit to this chat."},
			{Name: "sender_id", Type: "integer", Nullable: true, Desc: "Limit to this sender."},
			{Name: "days_ago", Type: "integer", Nullable: true, Desc: "Only messages from the last N days."},
			{Name: "limit", Type: "integer", Nullable: true, Desc: "Max results (default 20, max 50)."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			q := telegram.SearchQuery{Text: a.Str("query"), ChatID: a.Int("chat_id"), SenderID: a.Int("sender_id"), Limit: int(a.Int("limit"))}
			if q.Limit <= 0 {
				q.Limit = 20
			}
			if q.Limit > 50 {
				q.Limit = 50
			}
			if days := a.Int("days_ago"); days > 0 {
				q.Since = time.Now().Add(-time.Duration(days) * 24 * time.Hour)
			}
			if q.ChatID != 0 && !d.Accessible(q.ChatID) {
				return "", errors.New("that chat is not accessible (lockdown mode)")
			}
			msgs, err := d.TG.Search(ctx, q)
			if err != nil {
				return "", err
			}
			var keep []telegram.Message
			for _, m := range msgs {
				if d.Accessible(m.ChatID) {
					keep = append(keep, m)
				}
			}
			if len(keep) == 0 {
				return "Nothing found", nil
			}
			var b strings.Builder
			for _, m := range keep {
				fmt.Fprintf(&b, "<found chat_id=\"%d\">\n%s\n</found>\n", m.ChatID, d.UI.FormatMessage(ctx, m, time.Now()))
			}
			return b.String(), nil
		},
	}
}

func removeAndBanChatTool(d Deps) Tool {
	return Tool{
		Name:        "remove_and_ban_chat",
		Description: "Leave a group and never come back; for a private chat, block the user and delete the chat (use for spam or abuse).",
		Props:       []Prop{{Name: "chat_id", Type: "integer", Desc: "Chat to leave."}},
		Run: func(ctx context.Context, a Args) (string, error) {
			c, err := d.TG.Chat(ctx, a.Int("chat_id"))
			if err != nil {
				return "", err
			}
			if c.Kind == telegram.ChatPrivate {
				if b, ok := d.TG.(interface {
					Block(ctx context.Context, chatID int64) error
				}); ok {
					if err := b.Block(ctx, c.ID); err != nil {
						return "", err
					}
					return "You blocked " + c.Title + " and removed the chat", nil
				}
				return "", errors.New("bots can't block private users; just stop replying")
			}
			if err := d.TG.Leave(ctx, c.ID); err != nil {
				return "", err
			}
			return "You left " + c.Title, nil
		},
	}
}

func openChatTool(d Deps) Tool {
	return Tool{
		Name:        "open_chat",
		Description: "Open a chat to read its recent messages and talk in it. Get chat_id from #get_telegram_chats.",
		Props:       []Prop{{Name: "chat_id", Type: "integer", Desc: "Chat id."}},
		Run: func(ctx context.Context, a Args) (string, error) {
			id := a.Int("chat_id")
			if !d.Accessible(id) {
				return "", errors.New("that chat is not accessible (lockdown mode)")
			}
			return d.OpenChat(ctx, id)
		},
	}
}

// WaitTools are the explicit "do nothing" actions (#wait, #pause). They let a model that is forced to call a
// tool stay silent on purpose; the agent ends the turn when a round consists of waits only.
func WaitTools() []Tool {
	mk := func(name string) Tool {
		return Tool{
			Name:        name,
			Description: "Do nothing now and wait for the next event. Use it instead of replying when there is nothing worth saying.",
			Run:         func(context.Context, Args) (string, error) { return "Ok, waiting.", nil },
		}
	}
	skip := Tool{
		Name: "skip",
		Description: "Ignore these messages: they are not interesting or not meant for you. Nothing is sent; you simply move on. " +
			"Silence is normal, do not answer just to answer: skip small talk between other people, spam, ads, bare '+' / 'ok' / stickers not aimed at you, and arguments you have no stake in.",
		Props: []Prop{{Name: "reason", Type: "string", Nullable: true, Desc: "One short line why (for the log)."}},
		Run:   func(context.Context, Args) (string, error) { return "Skipped, moving on.", nil },
	}
	return []Tool{mk("wait"), mk("pause"), skip}
}
