package tools

import (
	"path/filepath"
	"strings"
	"testing"
	"time"

	"kuni/internal/allow"
	"kuni/internal/ignore"
)

func TestIgnoreTool(t *testing.T) {
	d := ownerDeps(t, 100)
	tl := ignoreTool(d)
	if _, err := tl.Run(t.Context(), Args{"action": "list"}); err == nil {
		t.Fatal("must say the list is off without a store")
	}
	d.Ignore = ignore.New(filepath.Join(t.TempDir(), "i.json"))
	tl = ignoreTool(d) // the tool keeps its own copy of Deps
	if out := run(t, tl, Args{"action": "list"}); !strings.Contains(out, "Nobody") {
		t.Fatal(out)
	}
	if out := run(t, tl, Args{"action": "add", "id": float64(-77), "hours": 2.0, "name": "Noise", "note": "flood"}); !strings.Contains(out, "chat -77") || !d.Ignore.Chat(-77) {
		t.Fatal(out)
	}
	if out := run(t, tl, Args{"action": "add", "id": float64(55)}); !strings.Contains(out, "user 55") || !d.Ignore.User(55) {
		t.Fatal(out)
	}
	if out := run(t, tl, Args{"action": "list"}); !strings.Contains(out, "Noise") || !strings.Contains(out, "flood") || !strings.Contains(out, "until removed") {
		t.Fatal(out)
	}
	if _, err := tl.Run(t.Context(), Args{"action": "add", "id": float64(100)}); err == nil {
		t.Fatal("the owner was ignored")
	}
	if _, err := tl.Run(t.Context(), Args{"action": "add"}); err == nil {
		t.Fatal("no id accepted")
	}
	if _, err := tl.Run(t.Context(), Args{"action": "remove", "id": float64(999)}); err == nil {
		t.Fatal("removing a stranger succeeded")
	}
	if out := run(t, tl, Args{"action": "remove", "id": float64(-77)}); !strings.Contains(out, "no longer") || d.Ignore.Chat(-77) {
		t.Fatal(out)
	}
}

func TestMutePerson(t *testing.T) {
	d := ownerDeps(t, 100)
	if _, err := MuteTool(d).Run(t.Context(), Args{"user_id": float64(5)}); err == nil {
		t.Fatal("must say the list is off without a store")
	}
	d.Ignore = ignore.New("")
	tl := MuteTool(d)
	if out := run(t, tl, Args{"user_id": float64(5), "reason": "ads"}); !strings.Contains(out, "Muted user 5") || !d.Ignore.User(5) {
		t.Fatal(out)
	}
	es := d.Ignore.List()
	if len(es) != 1 || !strings.Contains(es[0].Note, "ads") || es[0].Until.IsZero() || time.Until(es[0].Until) > 24*time.Hour+time.Minute {
		t.Fatalf("%+v", es)
	}
	run(t, tl, Args{"user_id": float64(6), "hours": 1000.0}) // capped at a week
	for _, e := range d.Ignore.List() {
		if e.ID == 6 && time.Until(e.Until) > 168*time.Hour+time.Minute {
			t.Fatal("not capped")
		}
	}
	for _, bad := range []Args{{"user_id": float64(100)}, {"user_id": float64(0)}, {}} {
		if _, err := tl.Run(t.Context(), bad); err == nil {
			t.Fatalf("accepted %v", bad)
		}
	}
	if _, err := tl.Run(t.Context(), Args{"user_id": float64(d.TG.MyID())}); err == nil {
		t.Fatal("muted herself")
	}
}

func TestCommandUsersTool(t *testing.T) {
	d := ownerDeps(t, 100)
	if _, err := commandUsersTool(d).Run(t.Context(), Args{"action": "list"}); err == nil {
		t.Fatal("must say the list is off without a store")
	}
	d.Allow = allow.New(filepath.Join(t.TempDir(), "a.json"))
	d.Cfg().CommandUsers = "42"
	tl := commandUsersTool(d)
	if out := run(t, tl, Args{"action": "list"}); !strings.Contains(out, "42 (config.toml)") {
		t.Fatal(out)
	}
	if out := run(t, tl, Args{"action": "add", "user_id": float64(7), "name": "Vasya"}); !strings.Contains(out, "User 7 may now") || !d.Allow.Has(7) {
		t.Fatal(out)
	}
	if out := run(t, tl, Args{"action": "list"}); !strings.Contains(out, "7 (Vasya)") {
		t.Fatal(out)
	}
	if out := run(t, tl, Args{"action": "remove", "user_id": float64(7)}); !strings.Contains(out, "no longer") || d.Allow.Has(7) {
		t.Fatal(out)
	}
	if out := run(t, tl, Args{"action": "remove", "user_id": float64(42)}); !strings.Contains(out, "config.toml") {
		t.Fatal(out)
	}
	if out := run(t, tl, Args{"action": "add", "user_id": float64(-5)}); !strings.HasPrefix(out, "ERR") {
		t.Fatal(out)
	}
	if out := run(t, tl, Args{"action": "remove", "user_id": float64(999)}); !strings.HasPrefix(out, "ERR") {
		t.Fatal(out)
	}
}
