package tools

import (
	"strings"
	"testing"
	"time"

	"kuni/internal/sched"
	"kuni/internal/telegram"
)

func TestParseEvery(t *testing.T) {
	for in, want := range map[string]time.Duration{"30m": 30 * time.Minute, "2h": 2 * time.Hour, "1d": 24 * time.Hour, "15 мин": 15 * time.Minute, "3 часа": 3 * time.Hour} {
		if got, err := parseEvery(in); err != nil || got != want {
			t.Errorf("%q: %v %v", in, got, err)
		}
	}
	if _, err := parseEvery("soon"); err == nil {
		t.Error("garbage accepted")
	}
}

func TestScheduleAndMonitorTools(t *testing.T) {
	d := ownerDeps(t, 5)
	d.Sched = sched.New("", time.UTC)
	chat := telegram.Chat{ID: 5}
	st := scheduleTool(d, chat)
	if out := run(t, st, Args{"action": "add", "text": "курс", "every": "2h"}); !strings.Contains(out, "каждые 2h0m0s") {
		t.Fatal(out)
	}
	if out := run(t, st, Args{"action": "add", "text": "доброе утро", "at": "09:00", "days": "пн-пт"}); !strings.Contains(out, "в 09:00 (пн,вт,ср,чт,пт)") {
		t.Fatal(out)
	}
	if out := run(t, st, Args{"action": "add", "text": "x"}); !strings.HasPrefix(out, "ERR") {
		t.Fatal(out)
	}
	if out := run(t, st, Args{"action": "list"}); !strings.Contains(out, "курс") || !strings.Contains(out, "доброе утро") {
		t.Fatal(out)
	}
	run(t, st, Args{"action": "pause", "id": float64(1)})
	if out := run(t, st, Args{"action": "list"}); !strings.Contains(out, "[на паузе]") {
		t.Fatal(out)
	}
	if out := run(t, st, Args{"action": "delete", "id": float64(1)}); out != "deleted" {
		t.Fatal(out)
	}
	mt := monitorTool(d, chat)
	if out := run(t, mt, Args{"action": "add", "kind": "disk_free_pct", "limit": float64(10)}); !strings.Contains(out, "watching") {
		t.Fatal(out)
	}
	if out := run(t, mt, Args{"action": "add", "kind": "url"}); !strings.HasPrefix(out, "ERR") {
		t.Fatal(out)
	}
	if out := run(t, mt, Args{"action": "list"}); !strings.Contains(out, "disk_free_pct") {
		t.Fatal(out)
	}
	d.Sched = nil
	if out := run(t, scheduleTool(d, chat), Args{"action": "list"}); !strings.Contains(out, "scheduler is off") {
		t.Fatal(out)
	}
}
