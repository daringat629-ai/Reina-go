package tools

import (
	"context"
	"errors"
	"fmt"
	"math"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"

	"kuni/internal/chart"
	"kuni/internal/dates"
	"kuni/internal/ledger"
	"kuni/internal/office"
	"kuni/internal/period"
	"kuni/internal/telegram"
	"kuni/internal/tracker"
)

// life.go: the owner's everyday book-keeping: money (#ledger), habits and measurements (#tracker), the dates of the
// people close to him (#dates). Kept on disk; reports, tables and charts come out of them.

// LifeTools are the owner's book-keeping tools (each only when its store is on).
func LifeTools(d Deps, chat telegram.Chat) []Tool {
	var ts []Tool
	if d.Ledger != nil {
		ts = append(ts, ledgerTool(d, chat))
	}
	if d.Tracker != nil {
		ts = append(ts, trackerTool(d, chat))
	}
	if d.Dates != nil {
		ts = append(ts, datesTool(d, chat))
	}
	return ts
}

func today(d Deps) time.Time { return time.Now().In(zoneOf(d)) }

var reAmount = regexp.MustCompile(`^\s*([-+]?\d[\d\s\x{00a0}]*(?:[.,]\d+)?)\s*(\S*)\s*$`)

// amount reads "1 200,50", "-500", "300 сом" (the currency, when written, comes back too).
func amount(a Args) (float64, string, error) {
	switch v := a["amount"].(type) {
	case float64:
		return v, "", nil
	case string:
		m := reAmount.FindStringSubmatch(v)
		if m == nil {
			return 0, "", fmt.Errorf("cannot read the amount %q", v)
		}
		f, err := strconv.ParseFloat(strings.NewReplacer(" ", "", " ", "", ",", ".").Replace(m[1]), 64)
		return f, m[2], err
	}
	return 0, "", errors.New("amount is required")
}

func ledgerTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name: "ledger",
		Description: "The owner's money book (owner only): add (\"потратил 500 на такси\": amount, category, note, date, kind=income for earnings), " +
			"report, list, edit/delete (id), budget (category, monthly amount; 0 removes; всё = the whole month), categories, currency (the default), " +
			"export (Excel), chart (a pie). Reuse existing categories; never add one expense twice.",
		Props: []Prop{
			{Name: "action", Type: "string", Desc: "add, report, list, edit, delete, budget, categories, currency, export, chart."},
			{Name: "amount", Type: "number", Nullable: true, Desc: "The sum (budget: monthly limit)."},
			{Name: "category", Type: "string", Nullable: true, Desc: "еда, такси, кафе, дом, здоровье, зарплата..."},
			{Name: "note", Type: "string", Nullable: true, Desc: "What it was."},
			{Name: "date", Type: "string", Nullable: true, Desc: "The day (default today): вчера, 21.10."},
			{Name: "currency", Type: "string", Nullable: true, Desc: "KGS, RUB, USD... (default: the book's)."},
			{Name: "kind", Type: "string", Nullable: true, Desc: "expense (default) or income."},
			{Name: "period", Type: "string", Nullable: true, Desc: "today, week, month (default), last_month, year, 30d, 2026-10, 2026-10-01..2026-10-15, all."},
			{Name: "id", Type: "integer", Nullable: true, Desc: "edit/delete: the entry number."},
			{Name: "text", Type: "string", Nullable: true, Desc: "list: words in notes."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			L := d.Ledger
			now := today(d)
			switch strings.ToLower(strings.TrimSpace(a.Str("action"))) {
			case "add":
				v, cur, err := amount(a)
				if err != nil {
					return "", err
				}
				if c := a.Str("currency"); c != "" {
					cur = c
				}
				day, err := period.Day(a.Str("date"), now, true)
				if err != nil {
					return "", err
				}
				e, warn, err := L.Add(ledger.Entry{Date: day.Format(period.Layout), Kind: a.Str("kind"), Amount: v, Currency: cur, Category: a.Str("category"), Note: a.Str("note")}, time.Now())
				if err != nil {
					return "", err
				}
				kind := "расход"
				if e.Kind == ledger.Income {
					kind = "доход"
				}
				out := fmt.Sprintf("Записано #%d: %s %s %s, %s, %s", e.ID, kind, ledger.Money(e.Amount), e.Currency, e.Category, e.Date)
				if e.Note != "" {
					out += " (" + e.Note + ")"
				}
				month := L.Summarize(e.Date[:7]+"-01", e.Date)
				out += fmt.Sprintf(". За %s потрачено %s %s.", e.Date[:7], ledger.Money(month.Spent[e.Currency]), e.Currency)
				for _, w := range warn {
					out += "\n! " + w
				}
				return out, nil
			case "report", "summary", "":
				from, to, name, err := period.Range(a.Str("period"), now)
				if err != nil {
					return "", err
				}
				return ledgerReport(L, from, to, name, now), nil
			case "list":
				from, to, name, err := period.Range(a.Str("period"), now)
				if err != nil {
					return "", err
				}
				es := L.List(ledger.Filter{From: from.Format(period.Layout), To: to.Format(period.Layout), Category: a.Str("category"), Text: a.Str("text")})
				if len(es) == 0 {
					return "Ничего за " + name + ".", nil
				}
				var b strings.Builder
				fmt.Fprintf(&b, "%d записей за %s (новые сверху):\n", len(es), name)
				for i, e := range es {
					if i == 60 {
						fmt.Fprintf(&b, "… и ещё %d\n", len(es)-i)
						break
					}
					sign := "-"
					if e.Kind == ledger.Income {
						sign = "+"
					}
					fmt.Fprintf(&b, "#%d %s %s%s %s %s", e.ID, e.Date, sign, ledger.Money(e.Amount), e.Currency, e.Category)
					if e.Note != "" {
						b.WriteString(" — " + e.Note)
					}
					b.WriteByte('\n')
				}
				return b.String(), nil
			case "edit":
				upd := ledger.Entry{Category: a.Str("category"), Note: a.Str("note"), Currency: a.Str("currency"), Kind: a.Str("kind")}
				if a.Has("amount") {
					v, _, err := amount(a)
					if err != nil {
						return "", err
					}
					upd.Amount = v
				}
				if s := a.Str("date"); s != "" {
					day, err := period.Day(s, now, true)
					if err != nil {
						return "", err
					}
					upd.Date = day.Format(period.Layout)
				}
				e, err := L.Edit(int(a.Int("id")), upd)
				if err != nil {
					return "", err
				}
				return fmt.Sprintf("Исправлено #%d: %s %s %s, %s, %s %s", e.ID, e.Kind, ledger.Money(e.Amount), e.Currency, e.Category, e.Date, e.Note), nil
			case "delete":
				e, err := L.Delete(int(a.Int("id")))
				if err != nil {
					return "", err
				}
				return fmt.Sprintf("Удалено #%d (%s %s %s, %s).", e.ID, ledger.Money(e.Amount), e.Currency, e.Category, e.Date), nil
			case "budget":
				v, cur, _ := amount(a)
				if c := a.Str("currency"); c != "" {
					cur = c
				}
				if err := L.SetBudget(a.Str("category"), v, cur); err != nil {
					return "", err
				}
				if v <= 0 {
					return "Бюджет «" + ledger.Category(a.Str("category")) + "» снят.", nil
				}
				return fmt.Sprintf("Бюджет «%s»: %s в месяц. Предупрежу на 80%% и при превышении.", ledger.Category(a.Str("category")), ledger.Money(v)), nil
			case "categories":
				out := "Расходы: " + strings.Join(L.Categories(ledger.Expense), ", ")
				if inc := L.Categories(ledger.Income); len(inc) > 0 {
					out += "\nДоходы: " + strings.Join(inc, ", ")
				}
				return out + "\nВалюта по умолчанию: " + L.DefaultCurrency(), nil
			case "currency":
				if err := L.SetDefaultCurrency(a.Str("currency")); err != nil {
					return "", err
				}
				return "Валюта по умолчанию: " + L.DefaultCurrency(), nil
			case "export":
				from, to, name, err := period.Range(a.Str("period"), now)
				if err != nil {
					return "", err
				}
				return ledgerExport(ctx, d, chat, from, to, name)
			case "chart":
				from, to, name, err := period.Range(a.Str("period"), now)
				if err != nil {
					return "", err
				}
				r := L.Summarize(from.Format(period.Layout), to.Format(period.Layout))
				cur := ledger.Currency(a.Str("currency"))
				if cur == "" {
					cur = L.DefaultCurrency()
				}
				shares := r.ByCategory[cur]
				if len(shares) == 0 {
					return fmt.Sprintf("Нет расходов в %s за %s.", cur, name), nil
				}
				c := chart.Chart{Kind: "pie", Title: fmt.Sprintf("Расходы за %s, %s", name, cur), Series: []chart.Series{{Name: cur}}}
				for i, sh := range shares {
					if i == 9 && len(shares) > 10 { // the tail in one slice
						rest := 0.0
						for _, x := range shares[i:] {
							rest += x.Amount
						}
						c.Labels = append(c.Labels, "остальное")
						c.Series[0].Values = append(c.Series[0].Values, rest)
						break
					}
					c.Labels = append(c.Labels, sh.Category)
					c.Series[0].Values = append(c.Series[0].Values, sh.Amount)
				}
				return drawAndSend(ctx, d, chat, c, "", "", true)
			}
			return "", errors.New("action is add, report, list, edit, delete, budget, categories, currency, export or chart")
		},
	}
}

func ledgerReport(L *ledger.Store, from, to time.Time, name string, now time.Time) string {
	r := L.Summarize(from.Format(period.Layout), to.Format(period.Layout))
	if r.Count == 0 {
		return "Записей за " + name + " нет."
	}
	var b strings.Builder
	fmt.Fprintf(&b, "Деньги за %s (%s — %s, %d записей):\n", name, r.From, r.To, r.Count)
	var curs []string
	for c := range r.Spent {
		curs = append(curs, c)
	}
	for c := range r.Earned {
		if _, ok := r.Spent[c]; !ok {
			curs = append(curs, c)
		}
	}
	sort.Strings(curs)
	days := r.Days
	if !to.Before(time.Date(now.Year(), now.Month(), now.Day(), 0, 0, 0, 0, now.Location())) && from.Year() > 1900 {
		days = int(now.Sub(from).Hours()/24) + 1 // a period that is still going: the average of the days so far
	}
	for _, c := range curs {
		fmt.Fprintf(&b, "\n%s: потрачено %s, получено %s, итог %s", c, ledger.Money(r.Spent[c]), ledger.Money(r.Earned[c]), ledger.Money(r.Earned[c]-r.Spent[c]))
		if days > 1 && r.Spent[c] > 0 && from.Year() > 1900 {
			fmt.Fprintf(&b, ", в среднем %s в день", ledger.Money(r.Spent[c]/float64(days)))
		}
		b.WriteByte('\n')
		for _, sh := range r.ByCategory[c] {
			fmt.Fprintf(&b, "  %s — %s (%.0f%%, %d)\n", sh.Category, ledger.Money(sh.Amount), sh.Percent, sh.Count)
		}
	}
	if bl := L.Budgets(now.Format("2006-01")); len(bl) > 0 {
		b.WriteString("\nБюджеты этого месяца:\n")
		for _, x := range bl {
			mark := ""
			switch {
			case x.Spent > x.Limit:
				mark = " — ПРЕВЫШЕН"
			case x.Spent >= 0.8*x.Limit:
				mark = " — почти всё"
			}
			fmt.Fprintf(&b, "  %s: %s из %s %s (%.0f%%)%s\n", x.Category, ledger.Money(x.Spent), ledger.Money(x.Limit), x.Currency, 100*x.Spent/x.Limit, mark)
		}
	}
	if len(r.Largest) > 0 {
		b.WriteString("\nСамые крупные траты:\n")
		for _, e := range r.Largest {
			fmt.Fprintf(&b, "  #%d %s %s %s %s %s\n", e.ID, e.Date, ledger.Money(e.Amount), e.Currency, e.Category, e.Note)
		}
	}
	return b.String()
}

func ledgerExport(ctx context.Context, d Deps, chat telegram.Chat, from, to time.Time, name string) (string, error) {
	L := d.Ledger
	es := L.List(ledger.Filter{From: from.Format(period.Layout), To: to.Format(period.Layout)})
	if len(es) == 0 {
		return "Записей за " + name + " нет.", nil
	}
	sort.SliceStable(es, func(i, j int) bool { return es[i].Date < es[j].Date })
	head := []office.Cell{{Kind: office.Text, Str: "Дата"}, {Kind: office.Text, Str: "Тип"}, {Kind: office.Text, Str: "Категория"},
		{Kind: office.Text, Str: "Сумма"}, {Kind: office.Text, Str: "Валюта"}, {Kind: office.Text, Str: "Заметка"}}
	rows := [][]office.Cell{head}
	for _, e := range es {
		kind := "расход"
		if e.Kind == ledger.Income {
			kind = "доход"
		}
		rows = append(rows, []office.Cell{office.Value(e.Date), {Kind: office.Text, Str: kind}, {Kind: office.Text, Str: e.Category},
			{Kind: office.Number, Num: e.Amount}, {Kind: office.Text, Str: e.Currency}, {Kind: office.Text, Str: e.Note}})
	}
	sheets := []office.Sheet{{Name: "Записи", Rows: rows, Header: true}}
	r := L.Summarize(from.Format(period.Layout), to.Format(period.Layout))
	cat := [][]office.Cell{{{Kind: office.Text, Str: "Категория"}, {Kind: office.Text, Str: "Валюта"}, {Kind: office.Text, Str: "Сумма"}, {Kind: office.Text, Str: "Доля"}, {Kind: office.Text, Str: "Записей"}}}
	var curs []string
	for c := range r.ByCategory {
		curs = append(curs, c)
	}
	sort.Strings(curs)
	for _, c := range curs {
		for _, sh := range r.ByCategory[c] {
			cat = append(cat, []office.Cell{{Kind: office.Text, Str: sh.Category}, {Kind: office.Text, Str: c}, {Kind: office.Number, Num: sh.Amount},
				{Kind: office.Percent, Num: sh.Percent / 100}, {Kind: office.Number, Num: float64(sh.Count)}})
		}
	}
	sheets = append(sheets, office.Sheet{Name: "По категориям", Rows: cat, Header: true})
	data, err := office.XLSX(sheets, "Деньги за "+name, d.Cfg().CharacterName, time.Now())
	if err != nil {
		return "", err
	}
	p, err := saveOut(d, "documents", fileName("деньги "+name, "деньги", "xlsx"), data)
	if err != nil {
		return "", err
	}
	if _, err := deliverFile(ctx, d, chat.ID, p, "Деньги за "+name, "file", nil); err != nil {
		return "", err
	}
	return fmt.Sprintf("Excel с %d записями за %s отправлен (%s).", len(es), name, relWork(d, p)), nil
}

func trackerTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name: "tracker",
		Description: "The owner's habits (зарядка, 8 стаканов воды) and measurements (вес, сон, шаги) by day (owner only): add, log (value: 1 = done, " +
			"or the number), status (streaks, averages, trend; no name = all), history, chart, undo (the last record), delete. " +
			"Log at once when he reports (\"сделал зарядку\", \"вешу 78.4\").",
		Props: []Prop{
			{Name: "action", Type: "string", Desc: "add, log, status, history, chart, undo, delete."},
			{Name: "name", Type: "string", Nullable: true, Desc: "\"зарядка\", \"вес\"..."},
			{Name: "value", Type: "number", Nullable: true, Desc: "log: the number (habit: 1)."},
			{Name: "date", Type: "string", Nullable: true, Desc: "log: the day (default today)."},
			{Name: "note", Type: "string", Nullable: true, Desc: "log: a remark."},
			{Name: "kind", Type: "string", Nullable: true, Desc: "add: habit or metric."},
			{Name: "unit", Type: "string", Nullable: true, Desc: "add: кг, ч, шагов..."},
			{Name: "goal", Type: "number", Nullable: true, Desc: "add: a day's amount for a habit; the target of a metric."},
			{Name: "days", Type: "integer", Nullable: true, Desc: "history/chart: days back (default 30)."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			T := d.Tracker
			now := today(d)
			name := strings.TrimSpace(a.Str("name"))
			switch strings.ToLower(strings.TrimSpace(a.Str("action"))) {
			case "add":
				it, err := T.Add(name, a.Str("kind"), a.Str("unit"), a.Float("goal"), time.Now())
				if err != nil {
					return "", err
				}
				return fmt.Sprintf("Отслеживаю «%s» (%s).", it.Name, kindRu(it.Kind)), nil
			case "log":
				day, err := period.Day(a.Str("date"), now, true)
				if err != nil {
					return "", err
				}
				v := 1.0
				if a.Has("value") {
					v = a.Float("value")
				}
				it, created, err := T.Log(name, day.Format(period.Layout), v, a.Str("note"), time.Now())
				if err != nil {
					return "", err
				}
				out := ""
				if created {
					out = fmt.Sprintf("Новый трекер «%s» (%s). ", it.Name, kindRu(it.Kind))
				}
				return out + "Записано. " + statusLine(tracker.Of(it, now)), nil
			case "status", "":
				if name != "" {
					it, ok := T.Get(name)
					if !ok {
						return "", fmt.Errorf("no tracker %q", name)
					}
					return statusLine(tracker.Of(it, now)), nil
				}
				all := T.All()
				if len(all) == 0 {
					return "Ничего не отслеживается. Начни с add.", nil
				}
				var b strings.Builder
				for _, it := range all {
					b.WriteString(statusLine(tracker.Of(it, now)) + "\n")
				}
				return b.String(), nil
			case "history":
				it, ok := T.Get(name)
				if !ok {
					return "", fmt.Errorf("no tracker %q", name)
				}
				days := int(a.Int("days"))
				if days <= 0 {
					days = 30
				}
				from := now.AddDate(0, 0, -(days - 1)).Format(period.Layout)
				var b strings.Builder
				fmt.Fprintf(&b, "%s за %d дн.:\n", it.Name, days)
				n := 0
				for _, p := range it.Points {
					if p.Date >= from {
						fmt.Fprintf(&b, "%s: %s %s %s\n", p.Date, num(p.Value), it.Unit, p.Note)
						n++
					}
				}
				if n == 0 {
					b.WriteString("записей нет\n")
				}
				return b.String(), nil
			case "chart":
				it, ok := T.Get(name)
				if !ok {
					return "", fmt.Errorf("no tracker %q", name)
				}
				days := int(a.Int("days"))
				if days <= 0 {
					days = 30
				}
				daily := it.Daily()
				c := chart.Chart{Kind: "line", Title: it.Name, YLabel: it.Unit, Series: []chart.Series{{Name: it.Name}}}
				if it.Kind == tracker.Habit {
					c.Kind = "bar"
				}
				any := false
				for i := days - 1; i >= 0; i-- {
					day := now.AddDate(0, 0, -i)
					c.Labels = append(c.Labels, day.Format("02.01"))
					v, ok := daily[day.Format(period.Layout)]
					if !ok {
						if it.Kind == tracker.Habit {
							v = 0
						} else {
							v = math.NaN()
						}
					} else {
						any = true
					}
					c.Series[0].Values = append(c.Series[0].Values, v)
				}
				if !any {
					return fmt.Sprintf("За %d дн. записей «%s» нет.", days, it.Name), nil
				}
				return drawAndSend(ctx, d, chat, c, "", "", true)
			case "undo":
				p, err := T.Undo(name)
				if err != nil {
					return "", err
				}
				return fmt.Sprintf("Убрала запись %s: %s.", p.Date, num(p.Value)), nil
			case "delete":
				if err := T.Delete(name); err != nil {
					return "", err
				}
				return "Трекер «" + name + "» удалён вместе с историей.", nil
			}
			return "", errors.New("action is add, log, status, history, chart, undo or delete")
		},
	}
}

func kindRu(k string) string {
	if k == tracker.Habit {
		return "привычка"
	}
	return "показатель"
}

func num(v float64) string { return strings.Replace(strconv.FormatFloat(v, 'f', -1, 64), ".", ",", 1) }

func statusLine(st tracker.Status) string {
	it := st.Item
	if it.Kind == tracker.Habit {
		done := "сегодня ещё нет"
		if st.DoneToday {
			done = "сегодня ✓"
		} else if st.Today > 0 {
			done = fmt.Sprintf("сегодня %s из %s", num(st.Today), num(math.Max(it.Goal, 1)))
		}
		return fmt.Sprintf("«%s»: %s; серия %d %s (лучшая %d); неделя %s; за 30 дней %d%%", it.Name, done, st.Streak,
			plural(st.Streak, "день", "дня", "дней"), st.Best, st.Week, st.Rate30)
	}
	if st.LastDate == "" {
		return fmt.Sprintf("«%s»: записей ещё нет", it.Name)
	}
	s := fmt.Sprintf("«%s»: %s %s (%s)", it.Name, num(st.Last), it.Unit, st.LastDate)
	if st.Count > 1 {
		s += fmt.Sprintf(", было %s", num(st.Prev))
	}
	if !math.IsNaN(st.Avg7) {
		s += fmt.Sprintf("; среднее за 7 дн. %s", num(math.Round(st.Avg7*100)/100))
	}
	if !math.IsNaN(st.Avg30) {
		s += fmt.Sprintf(", за 30 дн. %s", num(math.Round(st.Avg30*100)/100))
	}
	s += fmt.Sprintf("; мин %s, макс %s", num(st.Min), num(st.Max))
	if st.TrendPer7d != 0 {
		s += fmt.Sprintf("; тренд %+.2f %s в неделю", st.TrendPer7d, it.Unit)
	}
	if it.Goal != 0 {
		s += fmt.Sprintf("; цель %s (осталось %s)", num(it.Goal), num(math.Round((it.Goal-st.Last)*100)/100))
	}
	return s
}

var reYearIn = regexp.MustCompile(`(\d{4}|^\d{1,2}[./]\d{1,2}[./]\d{2}$)`)

func datesTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name: "dates",
		Description: "Birthdays and other yearly dates of the owner's people (owner only); you are reminded every year, remind_days before and on the day. " +
			"add (name \"ДР мамы\", date \"12.03.1965\" or \"12 марта\", note what to do; chat_id = the person's chat to congratulate them yourself), list, delete.",
		Props: []Prop{
			{Name: "action", Type: "string", Desc: "add, list or delete."},
			{Name: "name", Type: "string", Nullable: true, Desc: "add: \"ДР Ани\", \"годовщина свадьбы\"."},
			{Name: "date", Type: "string", Nullable: true, Desc: "add: day and month (with the year, the age is counted)."},
			{Name: "kind", Type: "string", Nullable: true, Desc: "add: birthday, anniversary, other (guessed)."},
			{Name: "remind_days", Type: "integer", Nullable: true, Desc: "add: days before (default 1; 0 = only on the day)."},
			{Name: "note", Type: "string", Nullable: true, Desc: "add: what to do."},
			{Name: "chat_id", Type: "integer", Nullable: true, Desc: "add: congratulate in this chat yourself."},
			{Name: "id", Type: "integer", Nullable: true, Desc: "delete: the number."},
			{Name: "days", Type: "integer", Nullable: true, Desc: "list: within this many days."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			D := d.Dates
			now := today(d)
			switch strings.ToLower(strings.TrimSpace(a.Str("action"))) {
			case "add":
				spec := strings.TrimSpace(a.Str("date"))
				day, err := period.Day(spec, now, true)
				if err != nil {
					return "", err
				}
				year := 0
				if reYearIn.MatchString(spec) {
					year = day.Year()
					if year > now.Year() { // "12.03.65" is 1965
						year -= 100
					}
				}
				remind := 1
				if a.Has("remind_days") {
					remind = int(a.Int("remind_days"))
				}
				target := chat.ID
				if id := a.Int("chat_id"); id != 0 {
					target = id
				}
				dt, err := D.Add(dates.Date{Name: a.Str("name"), Kind: a.Str("kind"), Month: int(day.Month()), Day: day.Day(), Year: year,
					RemindDays: remind, Chat: target, Note: a.Str("note")}, time.Now())
				if err != nil {
					return "", err
				}
				up := D.List(now, 0)
				for _, u := range up {
					if u.ID == dt.ID {
						return "Запомнила: " + upcomingLine(u), nil
					}
				}
				return fmt.Sprintf("Запомнила #%d.", dt.ID), nil
			case "list", "":
				up := D.List(now, int(a.Int("days")))
				if len(up) == 0 {
					return "Дат нет.", nil
				}
				var b strings.Builder
				for _, u := range up {
					b.WriteString(upcomingLine(u) + "\n")
				}
				return b.String(), nil
			case "delete":
				dt, err := D.Delete(int(a.Int("id")))
				if err != nil {
					return "", err
				}
				return "Удалила: " + dt.Name, nil
			}
			return "", errors.New("action is add, list or delete")
		},
	}
}

func upcomingLine(u dates.Upcoming) string {
	when := "сегодня"
	switch {
	case u.DaysLeft == 1:
		when = "завтра"
	case u.DaysLeft > 1:
		when = fmt.Sprintf("через %d %s", u.DaysLeft, plural(u.DaysLeft, "день", "дня", "дней"))
	}
	s := fmt.Sprintf("#%d %s — %d %s (%s, %s)", u.ID, u.Name, u.On.Day(), ruMonths[u.On.Month()], ruWeekdays[u.On.Weekday()], when)
	if u.Turns > 0 {
		if u.Kind == "birthday" {
			s += fmt.Sprintf(", исполнится %d %s", u.Turns, plural(u.Turns, "год", "года", "лет"))
		} else {
			s += fmt.Sprintf(", %d %s", u.Turns, plural(u.Turns, "год", "года", "лет"))
		}
	}
	if u.Note != "" {
		s += "; " + u.Note
	}
	return s
}
