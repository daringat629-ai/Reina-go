package tools

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	"kuni/internal/telegram"
)

func tailFile(path string, n int) string {
	b, err := os.ReadFile(path)
	if err != nil {
		return ""
	}
	s := strings.TrimSpace(string(b))
	if r := []rune(s); len(r) > n {
		s = "…" + string(r[len(r)-n:])
	}
	return s
}

// shellBgTool starts a long command without blocking the conversation.
func shellBgTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name: "shell_bg",
		Description: "Run a LONG shell command in the background (builds, downloads, big archives, installs; owner only). It returns at once with a job number; " +
			"when the command ends you are woken up in this chat with its exit code and the end of its output. Use #shell for quick commands.",
		Props: []Prop{
			{Name: "command", Type: "string", Desc: "Command line for sh -c."},
			{Name: "timeout_mins", Type: "integer", Nullable: true, Desc: "Kill it after this many minutes (default 30, max 240)."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			cmdline := strings.TrimSpace(a.Str("command"))
			if cmdline == "" {
				return "", fmt.Errorf("empty command")
			}
			if why := d.shellDanger(cmdline); why != "" {
				d.journal("BLOCKED ("+why+"): "+cmdline, -2)
				return "Blocked: " + why + ". This never runs from here, not even for the owner.", nil
			}
			mins := a.Int("timeout_mins")
			if mins <= 0 {
				mins = 30
			}
			if mins > 240 {
				mins = 240
			}
			jobs := &d.rt().jobs
			logDir := d.dataPath("jobs")
			jobs.Lock()
			if jobs.runningLocked() >= maxRunningJobs {
				jobs.Unlock()
				return "", fmt.Errorf("%d background jobs are already running; wait for one to finish (#jobs)", maxRunningJobs)
			}
			j := &bgJob{ID: jobs.nextIDLocked(logDir), Cmd: cmdline, Chat: chat.ID, Start: time.Now()}
			j.Log = filepath.Join(logDir, fmt.Sprintf("%d.log", j.ID))
			jobs.list = append(jobs.list, j)
			if len(jobs.list) > 30 {
				jobs.list = jobs.list[len(jobs.list)-30:]
			}
			jobs.Unlock()

			_ = os.MkdirAll(logDir, 0o755)
			f, err := os.Create(j.Log)
			if err != nil {
				return "", err
			}
			// the job lives in the runtime, not in this turn: the turn ends at once, the job when it is done (or when
			// the program stops: no orphans left behind)
			jctx, cancel := context.WithTimeout(d.rt().ctx, time.Duration(mins)*time.Minute)
			c, err := d.shellCmd(jctx, cmdline)
			if err != nil {
				cancel()
				f.Close()
				return "", err
			}
			c.Stdout, c.Stderr = f, f
			if err := c.Start(); err != nil {
				cancel()
				f.Close()
				return "", err
			}
			d.journal("BG#"+fmt.Sprint(j.ID)+" "+cmdline, 0)
			go func() {
				defer cancel()
				werr := c.Wait()
				f.Close()
				code := 0
				if werr != nil {
					code = -1
					if c.ProcessState != nil {
						code = c.ProcessState.ExitCode()
					}
				}
				jobs.Lock()
				j.Done, j.Code, j.End = true, code, time.Now()
				jobs.Unlock()
				d.journal(fmt.Sprintf("BG#%d finished", j.ID), code)
				timeout := ""
				switch {
				case jctx.Err() == context.DeadlineExceeded:
					timeout = fmt.Sprintf(" It was killed by the %d-minute timeout.", mins)
				case d.rt().ctx.Err() != nil:
					return // the program is stopping: nobody to wake
				}
				if d.Wake != nil {
					d.Wake(j.Chat, fmt.Sprintf("Your background job #%d (%s) has finished after %s with exit code %d.%s\nEnd of its output:\n%s\nTell the owner briefly how it went.",
						j.ID, Truncate(cmdline, 200), time.Since(j.Start).Round(time.Second), code, timeout, tailFile(j.Log, 1500)))
				}
			}()
			return fmt.Sprintf("Started background job #%d. You will be woken up when it ends; meanwhile tell the owner it is running.", j.ID), nil
		},
	}
}

func jobsTool(d Deps) Tool {
	return Tool{
		Name:        "jobs",
		Description: "Background jobs started with #shell_bg: state, how long, and the end of the output of one job.",
		Props:       []Prop{{Name: "id", Type: "integer", Nullable: true, Desc: "Job number to see its output. Null = list all."}},
		Run: func(ctx context.Context, a Args) (string, error) {
			jobs := &d.rt().jobs
			jobs.Lock()
			defer jobs.Unlock()
			if id := int(a.Int("id")); id != 0 {
				for _, j := range jobs.list {
					if j.ID == id {
						state := "running"
						if j.Done {
							state = fmt.Sprintf("finished, exit %d", j.Code)
						}
						return fmt.Sprintf("#%d %s (%s): %s\n%s", j.ID, state, time.Since(j.Start).Round(time.Second), j.Cmd, tailFile(j.Log, 2000)), nil
					}
				}
				return "", fmt.Errorf("no job #%d", id)
			}
			if len(jobs.list) == 0 {
				return "No background jobs.", nil
			}
			var b strings.Builder
			for _, j := range jobs.list {
				state := "running"
				if j.Done {
					state = fmt.Sprintf("exit %d", j.Code)
				}
				fmt.Fprintf(&b, "#%d [%s] %s started %s: %s\n", j.ID, state, time.Since(j.Start).Round(time.Second), j.Start.Format("15:04"), Truncate(j.Cmd, 120))
			}
			return b.String(), nil
		},
	}
}
