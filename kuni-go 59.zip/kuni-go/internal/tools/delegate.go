package tools

import (
	"context"
	"fmt"
	"strings"
	"time"

	"kuni/internal/llm"
	"kuni/internal/prompts"
	"kuni/internal/util"
)

// DelegateTool lets her hand a job to the fast model: she gives the instructions, it returns the text, she checks it.
func DelegateTool(d Deps) Tool {
	return Tool{
		Name: "delegate",
		Description: "Hand a well-defined job to your fast helper model. It is quick, does not think long, has no tools and knows nothing about your chats or yourself: " +
			"summarise or translate a long text, extract facts or a table from material, draft code or a message to a spec, reformat, list options. " +
			"YOU give the exact instructions (what, format, length) and the material; it returns text; YOU read and check the result before you use or send it. Never put secrets (keys, passwords) in.",
		Props: []Prop{
			{Name: "instructions", Type: "string", Desc: "Exactly what to do and in what format."},
			{Name: "material", Type: "string", Nullable: true, Desc: "The text or data to work on (optional)."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			if d.LLM == nil {
				return "", fmt.Errorf("no helper model")
			}
			ins := strings.TrimSpace(a.Str("instructions"))
			if ins == "" {
				return "", fmt.Errorf("instructions are required")
			}
			msg := ins
			if m := strings.TrimSpace(a.Str("material")); m != "" {
				msg += "\n\n<material>\n" + util.Trunc(m, 60000) + "\n</material>"
			}
			c, cancel := context.WithTimeout(ctx, 90*time.Second)
			defer cancel()
			reply, err := d.LLM.Complete(llm.WithPurpose(c, "delegate"), llm.Request{System: d.prompt(prompts.DelegateSystem), Messages: []llm.Message{{Role: "user", Content: msg}}, Reasoning: "off"})
			if err != nil {
				return "", fmt.Errorf("the helper failed: %w", err)
			}
			out := strings.TrimSpace(reply.Content)
			if out == "" {
				return "", fmt.Errorf("the helper returned nothing")
			}
			return util.Trunc(out, 8000), nil
		},
	}
}
