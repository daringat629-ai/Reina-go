package tools

import (
	"context"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"

	"kuni/internal/browser"
	"kuni/internal/calendar"
	"kuni/internal/chart"
	"kuni/internal/office"
	"kuni/internal/qr"
	"kuni/internal/telegram"
)

// make.go: she makes real files: a Word document or a PDF from her Markdown, an Excel table, a chart, a QR code, an
// event for a calendar. Everything is made by the program itself (LibreOffice or Chromium are only used for PDF and
// for drawing charts, when they are there).

// MakeTools are the owner's file makers.
func MakeTools(d Deps, chat telegram.Chat) []Tool {
	return []Tool{makeDocumentTool(d, chat), makeTableTool(d, chat), makeChartTool(d, chat)}
}

// sendOpt reads the "send" argument: true unless she said false.
func sendOpt(a Args) bool { return !a.Has("send") || a.Bool("send") }

// saveOut writes a made file into the workspace folder sub and returns its absolute path (data_dir may be relative,
// and a relative path would be taken as inside the workspace once more by #send_file).
func saveOut(d Deps, sub, name string, data []byte) (string, error) {
	dir, err := filepath.Abs(filepath.Join(d.workDir(), sub))
	if err != nil {
		return "", err
	}
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return "", err
	}
	p := filepath.Join(dir, name)
	if _, err := os.Stat(p); err == nil { // never overwrite an earlier file of the same name
		ext := filepath.Ext(name)
		p = filepath.Join(dir, strings.TrimSuffix(name, ext)+time.Now().Format("-150405")+ext)
	}
	return p, os.WriteFile(p, data, 0o644)
}

// relWork shows a path relative to the workspace when it is inside it.
func relWork(d Deps, p string) string {
	w, err := filepath.Abs(d.workDir())
	if err != nil {
		return p
	}
	if r, err := filepath.Rel(w, p); err == nil && !strings.HasPrefix(r, "..") {
		return r
	}
	return p
}

func makeDocumentTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name: "make_document",
		Description: "Make a document from your Markdown and send it (owner only): docx (Word, default), pdf, html or md. Markdown: headings, bold/italic, " +
			"links, nested lists, - [x] tasks, | tables |, code blocks, > quotes, \\newpage, pictures on their own line ![caption](path) (e.g. from #make_chart). " +
			"For reports, letters, CVs, instructions he keeps or prints.",
		Props: []Prop{
			{Name: "text", Type: "string", Desc: "The whole document in Markdown."},
			{Name: "title", Type: "string", Nullable: true, Desc: "Title (on top unless the text starts with #; the file name)."},
			{Name: "format", Type: "string", Nullable: true, Desc: "docx (default), pdf, html, md."},
			{Name: "filename", Type: "string", Nullable: true, Desc: "File name without the extension."},
			{Name: "send", Type: "boolean", Nullable: true, Desc: "Send to this chat (default true)."},
			{Name: "caption", Type: "string", Nullable: true, Desc: "Caption in the chat."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			text := a.Str("text")
			if strings.TrimSpace(text) == "" {
				return "", errors.New("text is empty")
			}
			title := strings.TrimSpace(a.Str("title"))
			format := strings.ToLower(strings.TrimPrefix(strings.TrimSpace(a.Str("format")), "."))
			if format == "" || format == "word" {
				format = "docx"
			}
			def := "документ-" + time.Now().In(zoneOf(d)).Format("2006-01-02")
			base := strings.TrimSpace(a.Str("filename"))
			if base == "" {
				base = title
			}
			doc := office.Doc{Title: title, Text: text, Author: d.Cfg().CharacterName, Images: office.ImagesIn(d.workDir())}
			var data []byte
			var missing []string
			var note string
			switch format {
			case "docx":
				var err error
				if data, missing, err = office.DOCX(doc); err != nil {
					return "", err
				}
			case "html", "htm":
				format = "html"
				data = []byte(office.HTML(doc))
			case "md", "markdown", "txt":
				if format != "txt" {
					format = "md"
				}
				data = []byte(text)
			case "pdf":
				var err error
				data, note, err = makePDF(ctx, d, doc)
				if err != nil {
					return "", err
				}
			default:
				return "", fmt.Errorf("format is docx, pdf, html or md, not %q", format)
			}
			p, err := saveOut(d, "documents", fileName(base, def, format), data)
			if err != nil {
				return "", err
			}
			out := fmt.Sprintf("Made %s (%s).", relWork(d, p), humanSize(int64(len(data))))
			if note != "" {
				out += " " + note
			}
			if len(missing) > 0 {
				out += " Pictures not found (left as their captions): " + strings.Join(missing, ", ") + "."
			}
			if sendOpt(a) {
				if _, err := deliverFile(ctx, d, chat.ID, p, a.Str("caption"), "file", nil); err != nil {
					return out + " Sending failed: " + err.Error(), nil
				}
				out += " Sent to the chat."
			}
			return out, nil
		},
	}
}

// makePDF prints the document to PDF with LibreOffice (from the Word file) or Chromium (from the HTML page).
func makePDF(ctx context.Context, d Deps, doc office.Doc) ([]byte, string, error) {
	dir, err := os.MkdirTemp("", "kuni-pdf-")
	if err != nil {
		return nil, "", err
	}
	defer os.RemoveAll(dir)
	ctx, cancel := context.WithTimeout(ctx, 2*time.Minute)
	defer cancel()
	var tried []string
	for _, bin := range []string{"soffice", "libreoffice"} {
		p, err := exec.LookPath(bin)
		if err != nil {
			continue
		}
		docx, _, err := office.DOCX(doc)
		if err != nil {
			return nil, "", err
		}
		in := filepath.Join(dir, "doc.docx")
		if err := os.WriteFile(in, docx, 0o600); err != nil {
			return nil, "", err
		}
		cmd := exec.CommandContext(ctx, p, "--headless", "--norestore", "-env:UserInstallation=file://"+filepath.Join(dir, "lo"), "--convert-to", "pdf", "--outdir", dir, in)
		if out, err := cmd.CombinedOutput(); err != nil {
			tried = append(tried, fmt.Sprintf("LibreOffice: %v %.200s", err, out))
			break
		}
		if b, err := os.ReadFile(filepath.Join(dir, "doc.pdf")); err == nil {
			return b, "", nil
		}
		tried = append(tried, "LibreOffice made no PDF")
		break
	}
	if bin := browser.Find(d.Cfg().BrowserPath); bin != "" {
		page := filepath.Join(dir, "doc.html")
		if err := os.WriteFile(page, []byte(office.HTML(doc)), 0o600); err != nil {
			return nil, "", err
		}
		out := filepath.Join(dir, "chrome.pdf")
		args := []string{"--headless=new", "--disable-gpu", "--no-first-run", "--user-data-dir=" + filepath.Join(dir, "profile"),
			"--no-pdf-header-footer", "--print-to-pdf=" + out, "file://" + page}
		if os.Geteuid() == 0 {
			args = append([]string{"--no-sandbox"}, args...)
		}
		if b, err := exec.CommandContext(ctx, bin, args...).CombinedOutput(); err != nil {
			tried = append(tried, fmt.Sprintf("Chromium: %v %.200s", err, b))
		} else if pdf, err := os.ReadFile(out); err == nil {
			return pdf, "(printed by the browser)", nil
		}
	}
	if len(tried) > 0 {
		return nil, "", fmt.Errorf("could not make the PDF: %s", strings.Join(tried, "; "))
	}
	return nil, "", errors.New("PDF needs LibreOffice or Chromium on the machine (neither is installed); make a docx instead, it opens everywhere")
}

func makeTableTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name: "make_table",
		Description: "Make an Excel table (xlsx, default) or CSV and send it (owner only). data: CSV lines, a Markdown table, JSON rows or objects, " +
			"or {\"Sheet\": rows, ...} for several sheets. The first row is the header. Numbers, percents, dates become real cells; formulas (=SUM(B2:B9)) work.",
		Props: []Prop{
			{Name: "data", Type: "string", Desc: "The rows."},
			{Name: "filename", Type: "string", Nullable: true, Desc: "File name without the extension."},
			{Name: "format", Type: "string", Nullable: true, Desc: "xlsx (default) or csv."},
			{Name: "header", Type: "boolean", Nullable: true, Desc: "The first row is a header (default true)."},
			{Name: "send", Type: "boolean", Nullable: true, Desc: "Send to this chat (default true)."},
			{Name: "caption", Type: "string", Nullable: true, Desc: "Caption in the chat."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			sheets, err := office.ParseTable(a.Str("data"))
			if err != nil {
				return "", err
			}
			if a.Has("header") && !a.Bool("header") {
				for i := range sheets {
					sheets[i].Header = false
				}
			}
			format := strings.ToLower(strings.TrimPrefix(strings.TrimSpace(a.Str("format")), "."))
			if format == "" || format == "excel" {
				format = "xlsx"
			}
			def := "таблица-" + time.Now().In(zoneOf(d)).Format("2006-01-02")
			var data []byte
			switch format {
			case "xlsx":
				if data, err = office.XLSX(sheets, a.Str("filename"), d.Cfg().CharacterName, time.Now()); err != nil {
					return "", err
				}
			case "csv":
				data = office.CSV(sheets[0].Rows)
			default:
				return "", fmt.Errorf("format is xlsx or csv, not %q", format)
			}
			p, err := saveOut(d, "documents", fileName(a.Str("filename"), def, format), data)
			if err != nil {
				return "", err
			}
			rows := 0
			for _, s := range sheets {
				rows += len(s.Rows)
			}
			out := fmt.Sprintf("Made %s: %d sheet(s), %d rows (%s).", relWork(d, p), len(sheets), rows, humanSize(int64(len(data))))
			if format == "csv" && len(sheets) > 1 {
				out += " CSV holds one sheet: only the first was written."
			}
			if sendOpt(a) {
				if _, err := deliverFile(ctx, d, chat.ID, p, a.Str("caption"), "file", nil); err != nil {
					return out + " Sending failed: " + err.Error(), nil
				}
				out += " Sent to the chat."
			}
			return out, nil
		},
	}
}

func makeChartTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name: "make_chart",
		Description: "Draw a chart and send it (owner only): kind line, area, bar, hbar (long names) or pie. data: rows with a header; the first column " +
			"holds the labels, the others are series of numbers. The PNG is saved too, for #make_document.",
		Props: []Prop{
			{Name: "kind", Type: "string", Desc: "line, area, bar, hbar or pie."},
			{Name: "data", Type: "string", Desc: "The rows (CSV, Markdown table or JSON)."},
			{Name: "title", Type: "string", Nullable: true, Desc: "Title."},
			{Name: "x_label", Type: "string", Nullable: true, Desc: "Horizontal axis caption."},
			{Name: "y_label", Type: "string", Nullable: true, Desc: "Vertical axis caption (units)."},
			{Name: "filename", Type: "string", Nullable: true, Desc: "File name without the extension."},
			{Name: "send", Type: "boolean", Nullable: true, Desc: "Send to this chat (default true)."},
			{Name: "caption", Type: "string", Nullable: true, Desc: "Caption in the chat."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			sheets, err := office.ParseTable(a.Str("data"))
			if err != nil {
				return "", err
			}
			var rows [][]string
			for _, r := range sheets[0].Rows {
				row := make([]string, len(r))
				for i, c := range r {
					switch c.Kind {
					case office.Number:
						row[i] = fmt.Sprint(c.Num)
					case office.Percent:
						row[i] = fmt.Sprint(c.Num * 100)
					default:
						row[i] = c.String()
					}
				}
				rows = append(rows, row)
			}
			kind := strings.ToLower(strings.TrimSpace(a.Str("kind")))
			valid := false
			for _, k := range chart.Kinds {
				valid = valid || k == kind
			}
			if !valid {
				return "", fmt.Errorf("kind is one of %s", strings.Join(chart.Kinds, ", "))
			}
			c, err := chart.FromRows(rows, kind)
			if err != nil {
				return "", err
			}
			c.Title, c.XLabel, c.YLabel = a.Str("title"), a.Str("x_label"), a.Str("y_label")
			return drawAndSend(ctx, d, chat, c, a.Str("filename"), a.Str("caption"), sendOpt(a))
		},
	}
}

// drawAndSend renders a chart, keeps it in the workspace and (when send) posts it to the chat as a picture.
func drawAndSend(ctx context.Context, d Deps, chat telegram.Chat, c chart.Chart, filename, caption string, send bool) (string, error) {
	svg, err := c.SVG()
	if err != nil {
		return "", err
	}
	def := "график-" + time.Now().In(zoneOf(d)).Format("2006-01-02-1504")
	if filename == "" {
		filename = c.Title
	}
	png, err := chart.Render(ctx, svg, 1000, 600, browser.Find(d.Cfg().BrowserPath))
	if err != nil {
		p, serr := saveOut(d, "charts", fileName(filename, def, "svg"), []byte(svg))
		if serr != nil {
			return "", err
		}
		out := fmt.Sprintf("Could not draw a picture (%v); the chart is saved as %s.", err, relWork(d, p))
		if send {
			if _, derr := deliverFile(ctx, d, chat.ID, p, caption, "file", nil); derr == nil {
				out += " Sent as an SVG file (it opens in a browser)."
			}
		}
		return out, nil
	}
	p, err := saveOut(d, "charts", fileName(filename, def, "png"), png)
	if err != nil {
		return "", err
	}
	out := fmt.Sprintf("Chart saved as %s (use ![%s](%s) in #make_document to put it into a document).", relWork(d, p), c.Title, relWork(d, p))
	if send {
		if _, err := d.TG.SendPhoto(ctx, chat.ID, png, caption, 0); err != nil {
			return out + " Sending failed: " + err.Error(), nil
		}
		out += " Sent to the chat."
	}
	return out, nil
}

// qrTool makes a QR code picture and posts it: for anybody (a link, a Wi-Fi network, a phone number, a text).
func qrTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name: "qr_code",
		Description: "Make a QR code picture and send it to this chat: kind = text (a link or any text, default), wifi (text = network name, " +
			"password, security WPA/WEP/nopass: the phone joins the network by scanning), phone, email.",
		Props: []Prop{
			{Name: "text", Type: "string", Desc: "What the code holds: the link/text, the Wi-Fi network name, the phone number or the e-mail."},
			{Name: "kind", Type: "string", Nullable: true, Desc: "text (default), wifi, phone or email."},
			{Name: "password", Type: "string", Nullable: true, Desc: "wifi: the password."},
			{Name: "security", Type: "string", Nullable: true, Desc: "wifi: WPA (default), WEP or nopass."},
			{Name: "caption", Type: "string", Nullable: true, Desc: "Caption under the picture."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			payload, err := qrPayload(a)
			if err != nil {
				return "", err
			}
			code, err := qr.Encode(payload, qr.M)
			if err != nil {
				return "", err
			}
			if _, err := d.TG.SendPhoto(ctx, chat.ID, code.PNG(800), a.Str("caption"), 0); err != nil {
				return "", err
			}
			return fmt.Sprintf("QR code sent (version %d, %d bytes of data). Scanning it gives: %s", code.Version, len(payload), Truncate(payload, 300)), nil
		},
	}
}

func qrPayload(a Args) (string, error) {
	text := strings.TrimSpace(a.Str("text"))
	if text == "" {
		return "", errors.New("text is empty")
	}
	switch strings.ToLower(strings.TrimSpace(a.Str("kind"))) {
	case "", "text", "url", "link":
		return text, nil
	case "wifi", "wi-fi":
		sec := strings.ToUpper(strings.TrimSpace(a.Str("security")))
		switch sec {
		case "", "WPA2", "WPA3", "WPA":
			sec = "WPA"
		case "WEP", "NOPASS":
		case "NONE", "OPEN":
			sec = "nopass"
		default:
			return "", fmt.Errorf("security is WPA, WEP or nopass")
		}
		if sec == "NOPASS" {
			sec = "nopass"
		}
		esc := strings.NewReplacer(`\`, `\\`, ";", `\;`, ",", `\,`, ":", `\:`, `"`, `\"`)
		p := "WIFI:T:" + sec + ";S:" + esc.Replace(text) + ";"
		if sec != "nopass" {
			p += "P:" + esc.Replace(a.Str("password")) + ";"
		}
		return p + ";", nil
	case "phone", "tel":
		return "tel:" + strings.NewReplacer(" ", "", "-", "", "(", "", ")", "").Replace(text), nil
	case "email", "mail":
		return "mailto:" + text, nil
	}
	return "", fmt.Errorf("kind is text, wifi, phone or email")
}

// inviteTool makes an .ics event: opened on the phone, it lands in the person's own calendar with its reminder.
func inviteTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name:        "calendar_invite",
		Description: "Send a calendar event (.ics) to this chat: one tap adds it to the person's calendar (Google, Apple, Outlook) with a reminder. For meetings, appointments, deadlines.",
		Props: []Prop{
			{Name: "title", Type: "string", Desc: "What the event is."},
			{Name: "start", Type: "string", Desc: "\"2026-10-25 18:30\", \"25.10 18:30\", \"завтра 9:00\"; a date alone = all day."},
			{Name: "duration_mins", Type: "integer", Nullable: true, Desc: "Length (default 60)."},
			{Name: "end", Type: "string", Nullable: true, Desc: "Or the end time."},
			{Name: "location", Type: "string", Nullable: true, Desc: "Address or a call link."},
			{Name: "description", Type: "string", Nullable: true, Desc: "Details."},
			{Name: "alarm_mins", Type: "integer", Nullable: true, Desc: "Reminder minutes before (default 30; -1 none)."},
			{Name: "repeat", Type: "string", Nullable: true, Desc: "daily, weekly, monthly, yearly."},
			{Name: "count", Type: "integer", Nullable: true, Desc: "Repetitions (default endless)."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			loc := zoneOf(d)
			now := time.Now()
			start, timed, err := parseMoment(a.Str("start"), now, loc, true)
			if err != nil {
				return "", err
			}
			in := calendar.Invite{Title: a.Str("title"), Start: start, AllDay: !timed, Location: a.Str("location"), Description: a.Str("description"),
				AlarmMins: 30, Repeat: a.Str("repeat"), Count: int(a.Int("count"))}
			if a.Has("alarm_mins") {
				in.AlarmMins = int(a.Int("alarm_mins"))
			}
			if e := strings.TrimSpace(a.Str("end")); e != "" {
				end, _, err := parseMoment(e, start, loc, true)
				if err != nil {
					return "", err
				}
				if !strings.ContainsAny(e, ".-/") && end.Before(start) { // "end 01:00" after a late start is the next day
					end = end.AddDate(0, 0, 1)
				}
				in.End = end
			} else if m := a.Int("duration_mins"); m > 0 && timed {
				in.End = start.Add(time.Duration(m) * time.Minute)
			}
			ics, err := in.ICS(now)
			if err != nil {
				return "", err
			}
			name := fileName(in.Title, "event", "ics")
			if _, err := d.TG.SendDocument(ctx, chat.ID, name, []byte(ics), "", 0); err != nil {
				return "", err
			}
			when := ruDate(start)
			if timed {
				when += start.Format(" 15:04")
			}
			return fmt.Sprintf("Event file %s sent: %s, %s (%s). Tapping it adds the event to the calendar.", name, in.Title, when, loc), nil
		},
	}
}
