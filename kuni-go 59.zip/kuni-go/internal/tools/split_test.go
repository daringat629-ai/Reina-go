package tools

import (
	"reflect"
	"strings"
	"testing"
	"unicode/utf8"
)

func rejoin(c []string) string { return strings.Join(c, " ") }

func TestSplitKeepsShortLinesWhole(t *testing.T) {
	got := SplitMessage("привет\nкак дела?\n\n  ", 60)
	if !reflect.DeepEqual(got, []string{"привет", "как дела?"}) {
		t.Fatalf("%q", got)
	}
}

func TestSplitPacksShortSentencesUpToMax(t *testing.T) {
	text := "Привет! Я тут. Как ты сегодня, расскажи мне всё что случилось за день пожалуйста?"
	got := SplitMessage(text, 40)
	for _, g := range got {
		if utf8.RuneCountInString(g) > 40 {
			t.Fatalf("too long %q", g)
		}
	}
	if got[0] != "Привет! Я тут." {
		t.Fatalf("short sentences should pack: %q", got)
	}
	if rejoin(got) != text {
		t.Fatalf("text changed: %q", got)
	}
}

func TestSplitPrefersClauseAndNeverLeavesDanglingWord(t *testing.T) {
	cases := []string{
		"я вчера весь вечер думала о том что ты сказал и в итоге решила что ты прав",
		"I was thinking about what you said yesterday and in the end I decided that you are right about it",
		"ну короче я пошла в магазин за хлебом, потом зашла к подруге, а потом вернулась домой и легла спать",
	}
	for _, text := range cases {
		got := SplitMessage(text, 40)
		if rejoin(got) != text {
			t.Fatalf("text changed: %q", got)
		}
		for i, g := range got {
			if utf8.RuneCountInString(g) > 40 {
				t.Fatalf("too long %q in %q", g, got)
			}
			if i < len(got)-1 {
				if last := bareWord(g[strings.LastIndex(g, " ")+1:]); danglers[last] {
					t.Fatalf("chunk %q ends with a dangling %q: %q", g, last, got)
				}
			}
		}
		if last := got[len(got)-1]; len(got) > 1 && utf8.RuneCountInString(last) < 8 {
			t.Fatalf("tiny orphan tail %q in %q", last, got)
		}
	}
	got := SplitMessage(cases[2], 40)
	if got[0] != "ну короче я пошла в магазин за хлебом," {
		t.Fatalf("expected a cut after the comma: %q", got)
	}
}

func TestSplitNeverCutsLinksAbbreviationsOrEmoticons(t *testing.T) {
	url := "https://example.com/some/very/long/path/that/never/ends/and/is/longer/than/sixty/characters/ok"
	got := SplitMessage("глянь вот это "+url+" там всё написано", 30)
	found := false
	for _, g := range got {
		if strings.Contains(g, url) {
			found = true
		}
	}
	if !found {
		t.Fatalf("link was cut: %q", got)
	}
	got = SplitMessage("мне нравится всё это, т.д. и т.п., и вообще давай уже встретимся завтра вечером )))", 40)
	for _, g := range got {
		if strings.HasPrefix(g, ")") {
			t.Fatalf("emoticon starts a message: %q", got)
		}
	}
	if got := SplitMessage("Пётр А. Иванов пришёл домой, и мы пошли гулять по парку вместе до вечера", 40); strings.HasSuffix(got[0], "А.") {
		t.Fatalf("initial treated as a sentence end: %q", got)
	}
}

func TestSplitEmojiAfterSentenceStaysWithIt(t *testing.T) {
	got := SplitMessage("ахаха ну ты даёшь, это было реально смешно! 😂 а теперь серьёзно, давай решим что делать дальше", 45)
	for _, g := range got {
		if strings.HasPrefix(g, "😂") {
			t.Fatalf("emoji starts a message: %q", got)
		}
	}
}
