package tools

import "testing"

func TestValidMemberTag(t *testing.T) {
	for tag, ok := range map[string]bool{"": true, "модератор": true, "1234567890123456": true, "12345678901234567": false, "топ 🔥": false, "★ star": false} {
		if err := validMemberTag(tag); (err == nil) != ok {
			t.Errorf("validMemberTag(%q) = %v, want ok=%v", tag, err, ok)
		}
	}
}
