package tools

import (
	"fmt"
	"math"
	"regexp"
	"strconv"
	"strings"
	"unicode"
)

// A small exact calculator: + - * / % ^ ( ), constants and functions. Models are bad at long arithmetic.

var reDecimalComma = regexp.MustCompile(`(\d),(\d)`)

type calcParser struct {
	s   []rune
	pos int
}

func evalExpr(expr string) (float64, error) {
	// a comma between digits is a decimal comma (0,5); arguments are separated by ";" or ", "
	expr = reDecimalComma.ReplaceAllString(expr, "$1.$2")
	expr = strings.NewReplacer("×", "*", "÷", "/", "−", "-", "**", "^").Replace(strings.ToLower(expr))
	p := &calcParser{s: []rune(expr)}
	v, err := p.sum()
	if err != nil {
		return 0, err
	}
	p.skip()
	if p.pos < len(p.s) {
		return 0, fmt.Errorf("unexpected %q at position %d", string(p.s[p.pos]), p.pos+1)
	}
	if math.IsNaN(v) || math.IsInf(v, 0) {
		return 0, fmt.Errorf("the result is not a number (division by zero or out of range)")
	}
	return v, nil
}

func (p *calcParser) skip() {
	for p.pos < len(p.s) && unicode.IsSpace(p.s[p.pos]) {
		p.pos++
	}
}

func (p *calcParser) peek() rune {
	p.skip()
	if p.pos < len(p.s) {
		return p.s[p.pos]
	}
	return 0
}

func (p *calcParser) sum() (float64, error) {
	v, err := p.product()
	if err != nil {
		return 0, err
	}
	for {
		switch p.peek() {
		case '+':
			p.pos++
			r, err := p.product()
			if err != nil {
				return 0, err
			}
			v += r
		case '-':
			p.pos++
			r, err := p.product()
			if err != nil {
				return 0, err
			}
			v -= r
		default:
			return v, nil
		}
	}
}

func (p *calcParser) product() (float64, error) {
	v, err := p.power()
	if err != nil {
		return 0, err
	}
	for {
		c := p.peek()
		if c != '*' && c != '/' && c != '%' {
			return v, nil
		}
		p.pos++
		r, err := p.power()
		if err != nil {
			return 0, err
		}
		switch c {
		case '*':
			v *= r
		case '/':
			if r == 0 {
				return 0, fmt.Errorf("division by zero")
			}
			v /= r
		case '%':
			if r == 0 {
				return 0, fmt.Errorf("division by zero")
			}
			v = math.Mod(v, r)
		}
	}
}

func (p *calcParser) power() (float64, error) {
	base, err := p.unary()
	if err != nil {
		return 0, err
	}
	if p.peek() == '^' {
		p.pos++
		exp, err := p.power() // right-associative
		if err != nil {
			return 0, err
		}
		return math.Pow(base, exp), nil
	}
	return base, nil
}

func (p *calcParser) unary() (float64, error) {
	switch p.peek() {
	case '-':
		p.pos++
		v, err := p.unary()
		return -v, err
	case '+':
		p.pos++
		return p.unary()
	}
	return p.atom()
}

var calcFuncs = map[string]func(a []float64) (float64, error){
	"sqrt": one(math.Sqrt), "abs": one(math.Abs), "sin": one(math.Sin), "cos": one(math.Cos), "tan": one(math.Tan),
	"asin": one(math.Asin), "acos": one(math.Acos), "atan": one(math.Atan), "ln": one(math.Log), "log": one(math.Log10),
	"log2": one(math.Log2), "exp": one(math.Exp), "floor": one(math.Floor), "ceil": one(math.Ceil), "round": one(math.Round),
	"cbrt": one(math.Cbrt), "fact": one(func(x float64) float64 { return math.Gamma(x + 1) }),
	"min": func(a []float64) (float64, error) {
		if len(a) == 0 {
			return 0, fmt.Errorf("min needs arguments")
		}
		m := a[0]
		for _, x := range a[1:] {
			m = math.Min(m, x)
		}
		return m, nil
	},
	"max": func(a []float64) (float64, error) {
		if len(a) == 0 {
			return 0, fmt.Errorf("max needs arguments")
		}
		m := a[0]
		for _, x := range a[1:] {
			m = math.Max(m, x)
		}
		return m, nil
	},
	"pow": func(a []float64) (float64, error) {
		if len(a) != 2 {
			return 0, fmt.Errorf("pow takes two arguments")
		}
		return math.Pow(a[0], a[1]), nil
	},
}

func one(f func(float64) float64) func([]float64) (float64, error) {
	return func(a []float64) (float64, error) {
		if len(a) != 1 {
			return 0, fmt.Errorf("the function takes one argument")
		}
		return f(a[0]), nil
	}
}

func (p *calcParser) atom() (float64, error) {
	c := p.peek()
	switch {
	case c == '(':
		p.pos++
		v, err := p.sum()
		if err != nil {
			return 0, err
		}
		if p.peek() != ')' {
			return 0, fmt.Errorf("missing )")
		}
		p.pos++
		return v, nil
	case unicode.IsDigit(c) || c == '.':
		start := p.pos
		for p.pos < len(p.s) && (unicode.IsDigit(p.s[p.pos]) || p.s[p.pos] == '.') {
			p.pos++
		}
		// scientific notation 1e6, 2.5e-3
		if p.pos < len(p.s) && p.s[p.pos] == 'e' && p.pos+1 < len(p.s) && (unicode.IsDigit(p.s[p.pos+1]) || ((p.s[p.pos+1] == '-' || p.s[p.pos+1] == '+') && p.pos+2 < len(p.s) && unicode.IsDigit(p.s[p.pos+2]))) {
			p.pos += 2
			for p.pos < len(p.s) && unicode.IsDigit(p.s[p.pos]) {
				p.pos++
			}
		}
		v, err := strconv.ParseFloat(string(p.s[start:p.pos]), 64)
		if err != nil {
			return 0, fmt.Errorf("bad number %q", string(p.s[start:p.pos]))
		}
		if p.peek() == '%' && !p.startsOperand(p.pos+1) { // 15% = 0.15 when nothing follows to take the remainder of
			p.pos++
			return v / 100, nil
		}
		return v, nil
	case unicode.IsLetter(c):
		start := p.pos
		for p.pos < len(p.s) && (unicode.IsLetter(p.s[p.pos]) || unicode.IsDigit(p.s[p.pos])) {
			p.pos++
		}
		name := string(p.s[start:p.pos])
		switch name {
		case "pi":
			return math.Pi, nil
		case "e":
			return math.E, nil
		}
		f, ok := calcFuncs[name]
		if !ok {
			return 0, fmt.Errorf("unknown name %q", name)
		}
		if p.peek() != '(' {
			return 0, fmt.Errorf("%s needs (…)", name)
		}
		p.pos++
		var args []float64
		if p.peek() == ')' {
			p.pos++
		} else {
			for {
				v, err := p.sum()
				if err != nil {
					return 0, err
				}
				args = append(args, v)
				if p.peek() == ',' || p.peek() == ';' {
					p.pos++
					continue
				}
				if p.peek() != ')' {
					return 0, fmt.Errorf("missing ) after %s", name)
				}
				p.pos++
				break
			}
		}
		return f(args)
	case c == 0:
		return 0, fmt.Errorf("the expression ends too early")
	}
	return 0, fmt.Errorf("unexpected %q at position %d", string(c), p.pos+1)
}

// startsOperand reports whether an operand (a number, name or bracket) begins at i: then "%" is a modulo, not a percent.
func (p *calcParser) startsOperand(i int) bool {
	for i < len(p.s) && unicode.IsSpace(p.s[i]) {
		i++
	}
	if i >= len(p.s) {
		return false
	}
	c := p.s[i]
	return unicode.IsDigit(c) || c == '.' || c == '(' || unicode.IsLetter(c)
}

// formatNum prints a result without float noise: whole numbers plainly, others with up to 12 significant digits.
func formatNum(v float64) string {
	if v == math.Trunc(v) && math.Abs(v) < 1e15 {
		return strconv.FormatInt(int64(v), 10)
	}
	return strconv.FormatFloat(v, 'g', 12, 64)
}
