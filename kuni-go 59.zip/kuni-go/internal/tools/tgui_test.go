package tools

import (
	"context"
	"strings"
	"testing"

	"kuni/internal/telegram"
)

func TestTelegramUIToolWorksOnTheScreen(t *testing.T) {
	d := ownerDeps(t, 5)
	f := d.TG.(*telegram.Fake)
	f.Incoming(telegram.Chat{ID: 9, Title: "Алина", Kind: telegram.ChatPrivate, Pinned: true}, 9, "Алина", "привет, ты где")
	tool := telegramUITool(d)
	run := func(a Args) string {
		t.Helper()
		out, err := tool.Run(context.Background(), a)
		if err != nil {
			t.Fatalf("%v: %v", a, err)
		}
		return out
	}
	if out := run(Args{"action": "list"}); !strings.Contains(out, "📌👤 Алина") {
		t.Fatalf("list: %s", out)
	}
	if out := run(Args{"action": "open", "chat": "1"}); !strings.Contains(out, "привет, ты где") {
		t.Fatalf("open: %s", out)
	}
	if out := run(Args{"action": "reply", "n": float64(1), "text": "тут"}); !strings.Contains(out, "↩ Алина") {
		t.Fatalf("reply: %s", out)
	}
	if got := f.Sent[len(f.Sent)-1]; got.ChatID != 9 || got.ReplyTo == 0 || got.Text != "тут" {
		t.Fatalf("sent: %+v", got)
	}
	run(Args{"action": "location", "lat": 42.8, "lon": 74.6})
	if len(f.Rich.Locations) != 1 || f.Rich.Locations[0][0] != 42.8 {
		t.Fatalf("location: %v", f.Rich.Locations)
	}
	if _, err := tool.Run(context.Background(), Args{"action": "dance"}); err == nil {
		t.Fatal("unknown action accepted")
	}
	// the screen keeps its place between calls
	if out := run(Args{"action": "screen"}); !strings.Contains(out, "◀ Алина") {
		t.Fatalf("screen: %s", out)
	}
}
