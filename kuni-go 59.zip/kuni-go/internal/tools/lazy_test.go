package tools

import (
	"context"
	"strings"
	"testing"
)

func names(r *Registry) string {
	var out []string
	for _, d := range r.Defs() {
		out = append(out, d.Function.Name)
	}
	return strings.Join(out, ",")
}

func mk(name string) Tool {
	return Tool{Name: name, Run: func(context.Context, Args) (string, error) { return name + " ran", nil }}
}

func in(group string, t Tool) Tool { t.Group = group; return t }

func TestLazyGroups(t *testing.T) {
	r := NewRegistry(mk("send"), in("media", mk("photo")), in("media", mk("sticker")), in("admin", mk("ban")))
	var fired []string
	r.OnUnlock = func(g string) { fired = append(fired, g) }
	r.Lazy(map[string]string{"media": "photos", "admin": "moderation", "empty": "nothing"})
	if got := names(r); got != "more_tools,send" {
		t.Fatalf("locked defs: %s", got)
	}
	var moreDesc string
	for _, d := range r.Defs() {
		if d.Function.Name == "more_tools" {
			moreDesc = d.Function.Description
		}
	}
	if !strings.Contains(moreDesc, "media (photos)") || strings.Contains(moreDesc, "empty") {
		t.Fatalf("description: %q", moreDesc)
	}
	if out := r.Call(context.Background(), "more_tools", `{"group":"media"}`); !strings.Contains(out, "photo, sticker") {
		t.Fatal(out)
	}
	if got := names(r); got != "more_tools,photo,send,sticker" {
		t.Fatalf("after unlock: %s", got)
	}
	if out := r.Call(context.Background(), "more_tools", `{"group":"bogus"}`); !strings.HasPrefix(out, "Error:") {
		t.Fatal(out)
	}
	// calling a hidden tool by name works and unlocks its group
	if out := r.Call(context.Background(), "ban", `{}`); out != "ban ran" {
		t.Fatal(out)
	}
	if got := names(r); !strings.Contains(got, "ban") {
		t.Fatalf("ban not unlocked: %s", got)
	}
	if len(fired) != 2 {
		t.Fatalf("OnUnlock fired %v", fired)
	}
	// nothing to hide -> no more_tools, no change
	r2 := NewRegistry(mk("a"))
	r2.Lazy(map[string]string{"g": "zzz"})
	if names(r2) != "a" {
		t.Fatal(names(r2))
	}
}

func TestCatalogMetadataIsApplied(t *testing.T) {
	r := NewRegistry(mk("web_search"), mk("send_telegram_message"), mk("wait"), mk("browser"), mk("shell"),
		Tool{Name: "custom", Meta: Meta{ReadOnly: true}})
	get := func(n string) Tool { x, _ := r.Get(n); return x }
	if ws := get("web_search"); !ws.ReadOnly || ws.Group != "system" || ws.Quiet {
		t.Fatalf("web_search: %+v", ws.Meta)
	}
	if s := get("send_telegram_message"); !s.Sends || !s.Repeatable || s.ReadOnly {
		t.Fatalf("send: %+v", s.Meta)
	}
	if w := get("wait"); !w.Idle || !w.Quiet {
		t.Fatalf("wait: %+v", w.Meta)
	}
	if b := get("browser"); !b.Repeatable || b.Group != "browser" {
		t.Fatalf("browser: %+v", b.Meta)
	}
	if sh := get("shell"); sh.ReadOnly || sh.Quiet || sh.Idle {
		t.Fatalf("shell: %+v", sh.Meta)
	}
	if c := get("custom"); !c.ReadOnly {
		t.Fatal("a tool's own metadata stays")
	}
	res := r.Invoke(context.Background(), "nope", "")
	if !res.Failed || !strings.HasPrefix(res.Text, "Error") {
		t.Fatalf("unknown tool: %+v", res)
	}
	if res := r.Invoke(context.Background(), "shell", "{broken"); !res.Failed || res.Tool.Name != "shell" {
		t.Fatalf("broken args: %+v", res)
	}
	if res := r.Invoke(context.Background(), "shell", "{}"); res.Failed || res.Text != "shell ran" {
		t.Fatalf("ok call: %+v", res)
	}
}
