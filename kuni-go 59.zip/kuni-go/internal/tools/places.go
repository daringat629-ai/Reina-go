package tools

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math"
	"net/http"
	"net/url"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"

	"kuni/internal/web"
)

// places.go: the map. Addresses and places come from OpenStreetMap (Nominatim to find, Overpass for "what is near",
// OSRM for routes): free, no key, the whole world. Their rules ask for at most one request a second and an honest
// name of the program, both kept here.

// PlacesAPI points #places at other servers (tests); empty fields = the public OpenStreetMap services.
type PlacesAPI struct {
	Nominatim string // https://nominatim.openstreetmap.org
	Overpass  string // https://overpass-api.de/api/interpreter
	Routing   string // https://routing.openstreetmap.de (routed-car, routed-foot, routed-bike)
	Client    *http.Client
}

func (p PlacesAPI) withDefaults() PlacesAPI {
	if p.Nominatim == "" {
		p.Nominatim = "https://nominatim.openstreetmap.org"
	}
	if p.Overpass == "" {
		p.Overpass = "https://overpass-api.de/api/interpreter"
	}
	if p.Routing == "" {
		p.Routing = "https://routing.openstreetmap.de"
	}
	if p.Client == nil {
		p.Client = web.Fetcher{Timeout: 30 * time.Second}.Client()
	}
	return p
}

const osmAgent = "kuni-go/1.0 (personal assistant; https://github.com/Alex2772/kuni)"

// osmGet fetches JSON from an OpenStreetMap service, one request a second at most.
func (d Deps) osmGet(ctx context.Context, api PlacesAPI, u string, body url.Values, out any) error {
	rt := d.rt()
	rt.osmMu.Lock()
	if wait := time.Until(rt.osmLast.Add(1100 * time.Millisecond)); wait > 0 {
		select {
		case <-time.After(wait):
		case <-ctx.Done():
			rt.osmMu.Unlock()
			return ctx.Err()
		}
	}
	rt.osmLast = time.Now()
	rt.osmMu.Unlock()
	var req *http.Request
	var err error
	if body != nil {
		req, err = http.NewRequestWithContext(ctx, http.MethodPost, u, strings.NewReader(body.Encode()))
		if req != nil {
			req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
		}
	} else {
		req, err = http.NewRequestWithContext(ctx, http.MethodGet, u, nil)
	}
	if err != nil {
		return err
	}
	req.Header.Set("User-Agent", osmAgent)
	req.Header.Set("Accept-Language", "ru,en")
	resp, err := api.Client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	raw, err := io.ReadAll(io.LimitReader(resp.Body, 8<<20))
	if err != nil {
		return err
	}
	if resp.StatusCode != 200 {
		return fmt.Errorf("map service: HTTP %d %.200s", resp.StatusCode, raw)
	}
	return json.Unmarshal(raw, out)
}

type geoHit struct {
	Lat, Lon float64
	Name     string
	Kind     string
}

var reLatLon = regexp.MustCompile(`^\s*(-?\d{1,2}(?:\.\d+)?)\s*[,; ]\s*(-?\d{1,3}(?:\.\d+)?)\s*$`)

// geocode finds places by text (or reads "lat,lon").
func (d Deps) geocode(ctx context.Context, api PlacesAPI, q string, limit int) ([]geoHit, error) {
	if m := reLatLon.FindStringSubmatch(q); m != nil {
		lat, _ := strconv.ParseFloat(m[1], 64)
		lon, _ := strconv.ParseFloat(m[2], 64)
		if math.Abs(lat) <= 90 && math.Abs(lon) <= 180 {
			return []geoHit{{Lat: lat, Lon: lon, Name: q}}, nil
		}
	}
	var res []struct {
		Lat, Lon    string
		DisplayName string `json:"display_name"`
		Type        string `json:"type"`
		Category    string `json:"category"`
	}
	u := api.Nominatim + "/search?format=jsonv2&limit=" + strconv.Itoa(limit) + "&q=" + url.QueryEscape(q)
	if err := d.osmGet(ctx, api, u, nil, &res); err != nil {
		return nil, err
	}
	var out []geoHit
	for _, r := range res {
		lat, _ := strconv.ParseFloat(r.Lat, 64)
		lon, _ := strconv.ParseFloat(r.Lon, 64)
		out = append(out, geoHit{Lat: lat, Lon: lon, Name: r.DisplayName, Kind: strings.Trim(r.Category+"/"+r.Type, "/")})
	}
	if len(out) == 0 {
		return nil, fmt.Errorf("nothing found for %q on the map", q)
	}
	return out, nil
}

// distance between two points in metres (haversine).
func distance(lat1, lon1, lat2, lon2 float64) float64 {
	const r = 6371000
	rad := math.Pi / 180
	dlat, dlon := (lat2-lat1)*rad, (lon2-lon1)*rad
	h := math.Sin(dlat/2)*math.Sin(dlat/2) + math.Cos(lat1*rad)*math.Cos(lat2*rad)*math.Sin(dlon/2)*math.Sin(dlon/2)
	return 2 * r * math.Asin(math.Sqrt(h))
}

func mapLinks(lat, lon float64) string {
	return fmt.Sprintf("https://maps.google.com/?q=%.6f,%.6f | https://www.openstreetmap.org/?mlat=%.6f&mlon=%.6f#map=18/%.6f/%.6f", lat, lon, lat, lon, lat, lon)
}

// osmTags maps what people look for to OpenStreetMap tags.
var osmTags = map[string][]string{
	"аптека": {"amenity=pharmacy"}, "pharmacy": {"amenity=pharmacy"},
	"кафе": {"amenity=cafe"}, "кофейня": {"amenity=cafe"}, "кофе": {"amenity=cafe"}, "cafe": {"amenity=cafe"}, "coffee": {"amenity=cafe"},
	"ресторан": {"amenity=restaurant"}, "restaurant": {"amenity=restaurant"}, "поесть": {"amenity=restaurant", "amenity=cafe", "amenity=fast_food"},
	"фастфуд": {"amenity=fast_food"}, "fast food": {"amenity=fast_food"}, "бар": {"amenity=bar", "amenity=pub"}, "bar": {"amenity=bar", "amenity=pub"},
	"банкомат": {"amenity=atm"}, "atm": {"amenity=atm"}, "банк": {"amenity=bank"}, "bank": {"amenity=bank"}, "обменник": {"amenity=bureau_de_change"},
	"заправка": {"amenity=fuel"}, "азс": {"amenity=fuel"}, "fuel": {"amenity=fuel"}, "зарядка": {"amenity=charging_station"},
	"больница": {"amenity=hospital"}, "hospital": {"amenity=hospital"}, "клиника": {"amenity=clinic", "amenity=doctors"}, "поликлиника": {"amenity=clinic"},
	"стоматология": {"amenity=dentist"}, "стоматолог": {"amenity=dentist"}, "dentist": {"amenity=dentist"}, "ветеринар": {"amenity=veterinary"}, "ветклиника": {"amenity=veterinary"},
	"супермаркет": {"shop=supermarket"}, "продукты": {"shop=supermarket", "shop=convenience"}, "магазин": {"shop=supermarket", "shop=convenience"}, "supermarket": {"shop=supermarket"},
	"пекарня": {"shop=bakery"}, "рынок": {"amenity=marketplace"}, "торговый центр": {"shop=mall"}, "тц": {"shop=mall"}, "mall": {"shop=mall"},
	"парк": {"leisure=park"}, "park": {"leisure=park"}, "отель": {"tourism=hotel"}, "гостиница": {"tourism=hotel"}, "hotel": {"tourism=hotel"}, "хостел": {"tourism=hostel"},
	"туалет": {"amenity=toilets"}, "парковка": {"amenity=parking"}, "parking": {"amenity=parking"}, "кино": {"amenity=cinema"}, "кинотеатр": {"amenity=cinema"},
	"спортзал": {"leisure=fitness_centre"}, "фитнес": {"leisure=fitness_centre"}, "gym": {"leisure=fitness_centre"}, "бассейн": {"leisure=swimming_pool"},
	"школа": {"amenity=school"}, "детский сад": {"amenity=kindergarten"}, "почта": {"amenity=post_office"}, "полиция": {"amenity=police"},
	"автомойка": {"amenity=car_wash"}, "шиномонтаж": {"shop=tyres"}, "автосервис": {"shop=car_repair"}, "остановка": {"highway=bus_stop", "public_transport=platform"},
	"метро": {"station=subway", "railway=subway_entrance"}, "вокзал": {"railway=station", "amenity=bus_station"}, "музей": {"tourism=museum"}, "театр": {"amenity=theatre"},
	"библиотека": {"amenity=library"}, "салон красоты": {"shop=beauty"}, "парикмахерская": {"shop=hairdresser"}, "барбершоп": {"shop=hairdresser"},
	"цветы": {"shop=florist"}, "цветочный": {"shop=florist"}, "одежда": {"shop=clothes"}, "электроника": {"shop=electronics"}, "мечеть": {"amenity=place_of_worship"},
	"церковь": {"amenity=place_of_worship"}, "смотровая": {"tourism=viewpoint"}, "достопримечательности": {"tourism=attraction"},
}

// osmKeys are the words of osmTags, the longest first.
var osmKeys = func() []string {
	ks := make([]string, 0, len(osmTags))
	for k := range osmTags {
		ks = append(ks, k)
	}
	sort.Slice(ks, func(i, j int) bool {
		if a, b := len([]rune(ks[i])), len([]rune(ks[j])); a != b {
			return a > b
		}
		return ks[i] < ks[j]
	})
	return ks
}()

func overpassQuery(what string, lat, lon float64, radius int) string {
	key := strings.ToLower(strings.TrimSpace(what))
	tags, ok := osmTags[key]
	if !ok { // "аптеку", "аптеки": by the stem, the longest word first ("парковку" is a parking, not a park)
		for _, k := range osmKeys {
			if len([]rune(k)) >= 4 && strings.HasPrefix(key, string([]rune(k)[:len([]rune(k))-1])) {
				tags, ok = osmTags[k], true
				break
			}
		}
	}
	var b strings.Builder
	b.WriteString("[out:json][timeout:20];(")
	if ok {
		for _, t := range tags {
			k, v, _ := strings.Cut(t, "=")
			fmt.Fprintf(&b, `nwr["%s"="%s"](around:%d,%.6f,%.6f);`, k, v, radius, lat, lon)
		}
	} else { // by name
		re := regexp.QuoteMeta(strings.TrimSpace(what))
		re = strings.NewReplacer(`"`, `\"`, `\`, `\\`).Replace(re)
		fmt.Fprintf(&b, `nwr["name"~"%s",i](around:%d,%.6f,%.6f);`, re, radius, lat, lon)
	}
	b.WriteString(");out center tags 40;")
	return b.String()
}

func placesTool(d Deps) Tool {
	return Tool{
		Name: "places",
		Description: "The map (OpenStreetMap; owner only): search (query), nearby (what: аптека, кафе, банкомат, заправка... or a name; near: address, " +
			"city or \"lat,lon\" of a location message), route (from, to, mode car|foot|bike: distance, time), address (near = \"lat,lon\"). With map links.",
		Props: []Prop{
			{Name: "action", Type: "string", Desc: "search, nearby, route or address."},
			{Name: "query", Type: "string", Nullable: true, Desc: "search: with the city (\"Киевская 1, Бишкек\")."},
			{Name: "what", Type: "string", Nullable: true, Desc: "nearby: the kind of place or a name."},
			{Name: "near", Type: "string", Nullable: true, Desc: "nearby/address: where."},
			{Name: "radius", Type: "integer", Nullable: true, Desc: "nearby: metres (default 1000, max 5000)."},
			{Name: "from", Type: "string", Nullable: true, Desc: "route: the start."},
			{Name: "to", Type: "string", Nullable: true, Desc: "route: the destination."},
			{Name: "mode", Type: "string", Nullable: true, Desc: "route: car (default), foot, bike."},
		},
		Meta: Meta{ReadOnly: true},
		Run: func(ctx context.Context, a Args) (string, error) {
			api := d.Places.withDefaults()
			switch strings.ToLower(strings.TrimSpace(a.Str("action"))) {
			case "search", "":
				q := strings.TrimSpace(a.Str("query"))
				if q == "" {
					return "", errors.New("query is empty")
				}
				hits, err := d.geocode(ctx, api, q, 5)
				if err != nil {
					return "", err
				}
				var b strings.Builder
				for i, h := range hits {
					fmt.Fprintf(&b, "%d. %s [%s] (%.6f, %.6f)\n   %s\n", i+1, h.Name, h.Kind, h.Lat, h.Lon, mapLinks(h.Lat, h.Lon))
				}
				return b.String(), nil
			case "address", "reverse", "where":
				m := reLatLon.FindStringSubmatch(a.Str("near"))
				if m == nil {
					return "", errors.New("near must be \"lat,lon\"")
				}
				var res struct {
					DisplayName string `json:"display_name"`
					Error       string `json:"error"`
				}
				u := fmt.Sprintf("%s/reverse?format=jsonv2&lat=%s&lon=%s&zoom=18", api.Nominatim, m[1], m[2])
				if err := d.osmGet(ctx, api, u, nil, &res); err != nil {
					return "", err
				}
				if res.DisplayName == "" {
					return "", fmt.Errorf("no address there: %s", res.Error)
				}
				lat, _ := strconv.ParseFloat(m[1], 64)
				lon, _ := strconv.ParseFloat(m[2], 64)
				return res.DisplayName + "\n" + mapLinks(lat, lon), nil
			case "nearby":
				what := strings.TrimSpace(a.Str("what"))
				if what == "" {
					return "", errors.New("what to look for?")
				}
				near := strings.TrimSpace(a.Str("near"))
				if near == "" {
					return "", errors.New("near: an address, a city or \"lat,lon\" (ask where he is or for his location)")
				}
				hits, err := d.geocode(ctx, api, near, 1)
				if err != nil {
					return "", err
				}
				c := hits[0]
				radius := int(a.Int("radius"))
				if radius <= 0 {
					radius = 1000
				}
				radius = min(radius, 5000)
				var res struct {
					Elements []struct {
						Lat, Lon float64
						Center   *struct{ Lat, Lon float64 }
						Tags     map[string]string
					}
				}
				if err := d.osmGet(ctx, api, api.Overpass, url.Values{"data": {overpassQuery(what, c.Lat, c.Lon, radius)}}, &res); err != nil {
					return "", err
				}
				type place struct {
					name, line string
					dist       float64
				}
				var ps []place
				for _, e := range res.Elements {
					lat, lon := e.Lat, e.Lon
					if e.Center != nil {
						lat, lon = e.Center.Lat, e.Center.Lon
					}
					t := e.Tags
					name := firstOf(t["name:ru"], t["name"], t["brand"], t["operator"])
					if name == "" {
						name = "(без названия)"
					}
					dist := distance(c.Lat, c.Lon, lat, lon)
					line := fmt.Sprintf("%s — %s", name, metres(dist))
					if addr := strings.TrimSpace(t["addr:street"] + " " + t["addr:housenumber"]); addr != "" {
						line += ", " + addr
					}
					if h := t["opening_hours"]; h != "" {
						line += "; часы: " + h
					}
					if p := firstOf(t["phone"], t["contact:phone"]); p != "" {
						line += "; тел. " + p
					}
					if w := firstOf(t["website"], t["contact:website"], t["contact:instagram"]); w != "" {
						line += "; " + w
					}
					line += "\n   " + mapLinks(lat, lon)
					ps = append(ps, place{name, line, dist})
				}
				if len(ps) == 0 {
					return fmt.Sprintf("Рядом с %s (%d м) ничего «%s» не нашлось на карте. Попробуй радиус больше или другое слово.", c.Name, radius, what), nil
				}
				sort.Slice(ps, func(i, j int) bool { return ps[i].dist < ps[j].dist })
				var b strings.Builder
				fmt.Fprintf(&b, "«%s» в %d м от %s — %d найдено, ближайшие:\n", what, radius, short(c.Name, 80), len(ps))
				for i, p := range ps {
					if i == 10 {
						break
					}
					fmt.Fprintf(&b, "%d. %s\n", i+1, p.line)
				}
				return b.String(), nil
			case "route", "directions":
				from, err := d.geocode(ctx, api, a.Str("from"), 1)
				if err != nil {
					return "", fmt.Errorf("from: %w", err)
				}
				to, err := d.geocode(ctx, api, a.Str("to"), 1)
				if err != nil {
					return "", fmt.Errorf("to: %w", err)
				}
				profile, travel, name := "car", "driving", "на машине"
				switch strings.ToLower(strings.TrimSpace(a.Str("mode"))) {
				case "foot", "walk", "walking", "пешком":
					profile, travel, name = "foot", "walking", "пешком"
				case "bike", "bicycle", "cycling", "велосипед":
					profile, travel, name = "bike", "bicycling", "на велосипеде"
				}
				var res struct {
					Code   string
					Routes []struct{ Distance, Duration float64 }
				}
				u := fmt.Sprintf("%s/routed-%s/route/v1/driving/%.6f,%.6f;%.6f,%.6f?overview=false", api.Routing, profile, from[0].Lon, from[0].Lat, to[0].Lon, to[0].Lat)
				if err := d.osmGet(ctx, api, u, nil, &res); err != nil {
					return "", err
				}
				if res.Code != "Ok" || len(res.Routes) == 0 {
					return "", fmt.Errorf("no route found (%s)", res.Code)
				}
				r := res.Routes[0]
				return fmt.Sprintf("Маршрут %s: %s, примерно %s.\nОткуда: %s\nКуда: %s\nhttps://www.google.com/maps/dir/?api=1&origin=%.6f,%.6f&destination=%.6f,%.6f&travelmode=%s",
					name, metres(r.Distance), minutes(r.Duration), short(from[0].Name, 100), short(to[0].Name, 100),
					from[0].Lat, from[0].Lon, to[0].Lat, to[0].Lon, travel), nil
			}
			return "", errors.New("action is search, nearby, route or address")
		},
	}
}

func firstOf(ss ...string) string {
	for _, s := range ss {
		if strings.TrimSpace(s) != "" {
			return strings.TrimSpace(s)
		}
	}
	return ""
}

func metres(m float64) string {
	if m < 1000 {
		return fmt.Sprintf("%.0f м", math.Round(m/10)*10)
	}
	return strings.Replace(fmt.Sprintf("%.1f км", m/1000), ".", ",", 1)
}

func minutes(sec float64) string {
	m := int(math.Round(sec / 60))
	if m < 60 {
		return fmt.Sprintf("%d мин", max(m, 1))
	}
	return fmt.Sprintf("%d ч %d мин", m/60, m%60)
}

func short(s string, n int) string {
	if r := []rune(s); len(r) > n {
		return string(r[:n]) + "…"
	}
	return s
}
