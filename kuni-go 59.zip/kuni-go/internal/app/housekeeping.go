package app

import (
	"context"
	"errors"
	"fmt"
	"log"
	"strings"
	"time"

	"kuni/internal/alerts"
	"kuni/internal/config"
	"kuni/internal/diary"
	"kuni/internal/maint"
	"kuni/internal/telegram"
	"kuni/internal/usage"
)

// The housekeeping of the program: her sleep (memory consolidation), the disk and the backups, the daily report and
// the watch over Telegram. Each is one loop run by the Supervisor.

// sleepLoop runs one consolidation cycle a minute after start and then every 6 hours. Between the cycles it gives
// diary entries without an embedding (new consolidated pages, entries made before the embedding model changed) their
// vectors, a few at a time, so recalling a memory never has to wait for that during a conversation.
func sleepLoop(ctx context.Context, d *diary.Diary, cfg func() *config.Config) {
	timer := time.NewTimer(time.Minute)
	defer timer.Stop()
	index := time.NewTicker(5 * time.Minute)
	defer index.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-index.C:
			if n, err := d.Reindex(ctx, 20); err != nil && !errors.Is(err, context.Canceled) {
				log.Printf("diary: reindex: %v", err)
			} else if n > 0 {
				log.Printf("diary: %d entries got their embedding", n)
			}
		case <-timer.C:
			if err := d.Consolidate(ctx, cfg().SleepMaxTime); err != nil && !errors.Is(err, context.Canceled) {
				log.Printf("kuni: sleep consolidation: %v", err)
			}
			timer.Reset(6 * time.Hour)
		}
	}
}

// maintLoop watches the disk (clears the caches when it runs low, warns the owner once a day) and makes a daily
// backup. It starts quietly: the first look is a minute after start.
func maintLoop(ctx context.Context, cfg func() *config.Config, cfgPath string, notify func(string), clean func(context.Context, bool) string) {
	var warnedDay string
	var lastClean, lastForced time.Time
	timer := time.NewTimer(time.Minute)
	defer timer.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-timer.C:
		}
		timer.Reset(10 * time.Minute)
		c := cfg()
		if !c.MaintEnabled {
			continue
		}
		if time.Since(lastClean) > 24*time.Hour { // a quiet daily tidy-up so the disk never fills up unnoticed
			lastClean = time.Now()
			log.Printf("kuni: daily cleanup: %s", clean(ctx, false))
		}
		if d, err := maint.DiskOf(c.DataDir); err == nil && d.Low(c.DiskWarnPercent) {
			cleaned := ""
			if time.Since(lastForced) > time.Hour { // a thorough pass at most once an hour
				lastForced = time.Now()
				if rep := clean(ctx, true); !strings.HasPrefix(rep, "Чистить нечего") {
					cleaned = " " + rep
					d, _ = maint.DiskOf(c.DataDir)
				}
			}
			if day := time.Now().Format("2006-01-02"); warnedDay != day && d.Low(c.DiskWarnPercent) {
				warnedDay = day
				log.Printf("kuni: disk is low: %s free of %s", maint.Human(d.Free), maint.Human(d.Total))
				hogs := ""
				if top := biggestOnDisk(ctx); top != "" {
					hogs = " Больше всего места жрут: " + top + "."
				}
				notify(fmt.Sprintf("Папик, на диске почти нет места: свободно %s из %s (%.0f%%).%s%s Надо удалить ненужное, например старые архивы.", maint.Human(d.Free), maint.Human(d.Total), d.Percent(), cleaned, hogs))
			}
		}
		if c.BackupEnabled {
			dir := maint.BackupDirOf(c)
			if list := maint.Backups(dir); len(list) == 0 || time.Since(list[0].Time) > 24*time.Hour {
				if p, err := maint.Backup(maint.Sources(c, cfgPath), dir, c.BackupKeep, time.Now()); err != nil {
					log.Printf("kuni: backup: %v", err)
				} else {
					log.Printf("kuni: backup written: %s", p)
				}
			}
		}
	}
}

// biggestOnDisk names the biggest top-level directories of the root filesystem (empty if du is unavailable).
func biggestOnDisk(ctx context.Context) string {
	c, cancel := context.WithTimeout(ctx, 90*time.Second)
	defer cancel()
	top, err := maint.Biggest(c, "/", 5)
	if err != nil || len(top) == 0 {
		return ""
	}
	var parts []string
	for _, d := range top {
		parts = append(parts, fmt.Sprintf("%s (%s)", d.Path, maint.Human(d.Bytes)))
	}
	return strings.Join(parts, ", ")
}

// reportText is the daily message to the owner about yesterday.
func reportText(y usage.Day, week []usage.Day, free *maint.Disk) string {
	var b strings.Builder
	fmt.Fprintf(&b, "Папик, отчёт за %s: %s токенов на входе, %s на выходе, %d запросов", y.Day, kilo(y.In), kilo(y.Out), y.Calls)
	if y.HasPrice {
		fmt.Fprintf(&b, ", примерно $%.2f", y.USD)
	}
	b.WriteString(".")
	var max usage.Day
	for _, d := range week {
		if d.In+d.Out > max.In+max.Out {
			max = d
		}
	}
	if len(week) > 2 && max.Day != "" && max.Day != y.Day {
		fmt.Fprintf(&b, " Самый жирный день недели: %s (%s токенов).", max.Day, kilo(max.In+max.Out))
	}
	if free != nil {
		fmt.Fprintf(&b, " Диск: свободно %s из %s.", maint.Human(free.Free), maint.Human(free.Total))
	}
	return b.String()
}

func kilo(n int64) string {
	switch {
	case n >= 1_000_000:
		return fmt.Sprintf("%.1fM", float64(n)/1e6)
	case n >= 1000:
		return fmt.Sprintf("%dk", n/1000)
	}
	return fmt.Sprint(n)
}

// reportLoop sends the daily report once the configured hour has come (and never twice a day, even across restarts).
func reportLoop(ctx context.Context, cfg func() *config.Config, tr *usage.Tracker, notify func(string)) {
	t := time.NewTicker(5 * time.Minute)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
		}
		c := cfg()
		if !c.ReportEnabled {
			continue
		}
		if time.Now().In(c.Location()).Hour() < c.ReportHour {
			continue
		}
		price := PriceOf(c)
		y, ok := tr.DueReport(price)
		if !ok {
			continue
		}
		var disk *maint.Disk
		if d, err := maint.DiskOf(c.DataDir); err == nil {
			disk = &d
		}
		week := tr.Days(8, price)
		notify(reportText(y, week[:max(len(week)-1, 0)], disk))
	}
}

// PriceOf maps a model name to its configured prices (zero when unknown).
func PriceOf(c *config.Config) func(string) usage.Prices {
	return func(m string) usage.Prices {
		switch {
		case m == c.LLMModel:
			return usage.Prices{In: c.PriceIn, Out: c.PriceOut}
		case c.LightModel != "" && m == c.LightModel:
			return usage.Prices{In: c.LightPriceIn, Out: c.LightPriceOut}
		case c.FastModel != "" && m == c.FastModel:
			return usage.Prices{In: c.FastPriceIn, Out: c.FastPriceOut}
		}
		return usage.Prices{}
	}
}

// watchLoop checks Telegram once a minute and tells the owner about trouble (each kind at most every 2 hours).
func watchLoop(ctx context.Context, cfg func() *config.Config, tg telegram.Client, notify func(string)) {
	hs, ok := tg.(telegram.HealthSource)
	if !ok {
		return
	}
	var gate alerts.Gate
	t := time.NewTicker(time.Minute)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
		}
		if !cfg().AlertsEnabled {
			continue
		}
		now := time.Now()
		if msg := tgTrouble(hs.Health(), now); msg != "" && gate.Allow("tg", 2*time.Hour, now) {
			notify("Папик, проблема: " + msg + ".")
		}
	}
}
