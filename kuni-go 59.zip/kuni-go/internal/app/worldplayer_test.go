package app

import (
	"path/filepath"
	"strings"
	"testing"
)

func TestWorldNotesSurviveAndAreCapped(t *testing.T) {
	w := &worldPlayer{path: filepath.Join(t.TempDir(), "notes.txt")}
	for i := 0; i < 60; i++ {
		w.addNote("дом номер " + string(rune('A'+i%26)))
	}
	w.finish("Готово. ЗАПОМНИТЬ: башня у озера")
	n := w.notes()
	if got := len(strings.Split(n, "\n")); got != 40 {
		t.Fatalf("notes lines = %d, want 40", got)
	}
	if !strings.Contains(n, "башня у озера") {
		t.Fatalf("last note missing: %q", n)
	}
}
