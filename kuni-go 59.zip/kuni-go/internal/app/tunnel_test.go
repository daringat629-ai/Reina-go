package app

import (
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestTunnelRequestsSeeOnlyTheWorld(t *testing.T) {
	h := worldOnlyFromTunnel(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(200) }))
	get := func(path, hdr string) int {
		r := httptest.NewRequest("GET", path, nil)
		if hdr != "" {
			r.Header.Set(hdr, "1.2.3.4")
		}
		w := httptest.NewRecorder()
		h.ServeHTTP(w, r)
		return w.Code
	}
	for _, p := range []string{"/admin", "/admin/api/status", "/debug", "/metrics", "/v1/chat/completions"} {
		if get(p, "Cf-Connecting-Ip") != 404 {
			t.Fatalf("%s must be closed through the tunnel", p)
		}
	}
	for _, p := range []string{"/world", "/world/ws"} {
		if get(p, "Cf-Connecting-Ip") != 200 {
			t.Fatalf("%s must open through the tunnel", p)
		}
	}
	if get("/admin", "") != 200 {
		t.Fatal("the home network must still reach the panel")
	}
}
