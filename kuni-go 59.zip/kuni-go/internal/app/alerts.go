package app

import (
	"fmt"
	"time"

	"kuni/internal/telegram"
)

// tgTrouble says what is wrong with Telegram right now ("" if nothing): a burst of failed requests or a flood wait.
func tgTrouble(h telegram.Health, now time.Time) string {
	n := 0
	var last telegram.ErrorRecord
	for _, e := range h.Errors {
		if now.Sub(e.At) <= 10*time.Minute {
			n++
			last = e
		}
	}
	msg := ""
	if n >= 5 {
		msg = fmt.Sprintf("в Telegram за 10 минут %d ошибок, последняя: %s — %s", n, last.Method, last.Message)
	}
	if h.FloodUntil.After(now.Add(5 * time.Minute)) {
		if msg != "" {
			msg += "; "
		}
		msg += fmt.Sprintf("Telegram притормозил меня (flood wait) до %s", h.FloodUntil.Format("15:04"))
	}
	return msg
}
