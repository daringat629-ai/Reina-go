package app

import (
	"strings"
	"testing"

	"kuni/internal/maint"
	"kuni/internal/usage"
)

func TestReportTextHasTheNumbers(t *testing.T) {
	y := usage.Day{Day: "2026-10-19", In: 1_250_000, Out: 31_000, Calls: 85, USD: 0.34, HasPrice: true}
	week := []usage.Day{{Day: "2026-10-15", In: 4_000_000, Out: 1}, {Day: "2026-10-18", In: 10}, y}
	got := reportText(y, week, &maint.Disk{Free: 528 << 20, Total: 25 << 30})
	for _, want := range []string{"2026-10-19", "1.2M", "31k", "85 запросов", "$0.34", "Самый жирный день недели: 2026-10-15", "528 МБ"} {
		if !strings.Contains(got, want) {
			t.Fatalf("report lacks %q: %s", want, got)
		}
	}
	if strings.Contains(reportText(y, nil, nil), "Диск") {
		t.Fatal("no disk info without disk data")
	}
}
