// Package memory implements the working memory file (data/working_memory.md),
// the "middle layer" between the context window and the diary.
package memory

import (
	"errors"
	"io/fs"
	"os"

	"kuni/internal/store"
)

type WorkingMemory struct {
	Path string
}

// Load returns the current contents, or "" if the file does not exist yet.
func (w WorkingMemory) Load() (string, error) {
	b, err := os.ReadFile(w.Path)
	if errors.Is(err, fs.ErrNotExist) {
		return "", nil
	}
	return string(b), err
}

// Save overwrites the working memory atomically.
func (w WorkingMemory) Save(content string) error {
	return store.WriteFile(w.Path, []byte(content), store.Private)
}
