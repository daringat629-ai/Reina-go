package people

import (
	"strings"
	"testing"
	"time"
)

func TestCardsStoreDedupeCapAndPrivacy(t *testing.T) {
	s := New(t.TempDir())
	now := time.Now()
	if err := s.Add(7, "Joe", "works as a welder", true, now); err != nil {
		t.Fatal(err)
	}
	_ = s.Add(7, "Joe", "  Works as a   WELDER ", false, now) // same fact, learned publicly: stays one line, now public
	_ = s.Add(7, "Joe", "loves old cars", true, now)
	c := s.Get(7)
	if len(c.Facts) != 2 || c.Name != "Joe" || c.Facts[0].Private {
		t.Fatalf("%+v", c)
	}
	pub := c.Render(false)
	if !strings.Contains(pub, "welder") || strings.Contains(pub, "old cars") || !strings.Contains(pub, `user_id="7"`) {
		t.Fatalf("private facts leaked into a group view: %s", pub)
	}
	if !strings.Contains(c.Render(true), "old cars") {
		t.Fatal("private chat sees everything")
	}
	for i := 0; i < 30; i++ {
		_ = s.Add(7, "", strings.Repeat("x", i+1), false, now)
	}
	if n := len(s.Get(7).Facts); n != MaxFacts {
		t.Fatalf("not capped: %d", n)
	}
	_ = s.Add(8, "Ann", strings.Repeat("я", 500), false, now)
	if r := []rune(s.Get(8).Facts[0].Text); len(r) > MaxFactLen+1 {
		t.Fatalf("long fact not cut: %d", len(r))
	}
	if n := s.Forget(8, "ЯЯЯ"); n != 1 || len(s.Get(8).Facts) != 0 {
		t.Fatalf("forget: %d", n)
	}
	if all := s.All(); len(all) != 1 || all[0].ID != 7 {
		t.Fatalf("all: %+v", all)
	}
	if err := s.Add(0, "", "x", false, now); err == nil {
		t.Fatal("needs an id")
	}
	if err := s.Replace(7, "Joseph", []Fact{{Text: "new fact"}}); err != nil || s.Get(7).Name != "Joseph" || len(s.Get(7).Facts) != 1 {
		t.Fatal("replace")
	}
	_ = s.Replace(7, "", nil)
	if len(s.All()) != 0 {
		t.Fatal("empty card must be deleted")
	}
}

func TestSupersedeReplacesInsteadOfPiling(t *testing.T) {
	s := New(t.TempDir())
	now := time.Now()
	_ = s.Add(5, "Bob", "живёт в Бишкеке", true, now)
	_ = s.Add(5, "", "работает водителем", true, now)
	ok, err := s.Supersede(5, "Bob", "бишкек", "переехал в Алматы", true, now)
	if err != nil || !ok {
		t.Fatalf("%v %v", ok, err)
	}
	c := s.Get(5)
	if len(c.Facts) != 2 || c.Facts[0].Text != "переехал в Алматы" || c.Facts[1].Text != "работает водителем" {
		t.Fatalf("the old fact must be replaced in place: %+v", c.Facts)
	}
	// no match: it is simply added
	if ok, _ := s.Supersede(5, "", "кошка", "завёл кошку", true, now); ok || len(s.Get(5).Facts) != 3 {
		t.Fatalf("no match means add: %+v", s.Get(5).Facts)
	}
	// the correction was already known: the old fact goes, no duplicate stays
	_ = s.Add(5, "", "бросил курить", true, now)
	_ = s.Add(5, "", "курит", true, now)
	if ok, _ := s.Supersede(5, "", "курит", "бросил курить", true, now); !ok {
		t.Fatal("must replace")
	}
	n := 0
	for _, f := range s.Get(5).Facts {
		if f.Text == "бросил курить" {
			n++
		}
		if f.Text == "курит" {
			t.Fatal("the outdated fact must be gone")
		}
	}
	if n != 1 {
		t.Fatalf("the correction must appear once, not %d times", n)
	}
	// a too short pattern would match anything: it only adds
	before := len(s.Get(5).Facts)
	if ok, _ := s.Supersede(5, "", "а", "новый факт", true, now); ok || len(s.Get(5).Facts) != before+1 {
		t.Fatal("a too short pattern must not replace anything")
	}
	if _, err := s.Supersede(0, "", "x", "y", true, now); err == nil {
		t.Fatal("no user id, no card")
	}
}

func TestAboutAndProfileLiveOnTheCard(t *testing.T) {
	s := New(t.TempDir())
	now := time.Now()
	// a description alone makes a card; the profile needs a card
	if err := s.SetProfile(7, "@vasya", "bio"); err != nil || len(s.All()) != 0 {
		t.Fatal("a profile alone must not create a card")
	}
	if err := s.SetAbout(7, "Вася", "  Нормальный парень, любит ассемблер.  ", now); err != nil {
		t.Fatal(err)
	}
	all := s.All()
	if len(all) != 1 || all[0].About != "Нормальный парень, любит ассемблер." || all[0].Name != "Вася" || all[0].AboutAt.IsZero() {
		t.Fatalf("%+v", all)
	}
	s.SetProfile(7, "@vasya", "пишу на asm")
	s.Add(7, "", "любит ассемблер", true, now)
	c := s.Get(7)
	if c.Username != "vasya" || c.Bio != "пишу на asm" || len(c.Facts) != 1 {
		t.Fatalf("%+v", c)
	}
	// editing the facts keeps the profile and the description
	if err := s.Replace(7, "Вася", []Fact{{Text: "новый факт", Private: true}}); err != nil {
		t.Fatal(err)
	}
	if c = s.Get(7); c.About == "" || c.Username != "vasya" || len(c.Facts) != 1 || c.Facts[0].Text != "новый факт" {
		t.Fatalf("%+v", c)
	}
	// the description goes to the model only in private; a card with a description but no facts stays
	if r := c.Render(true); !strings.Contains(r, "your own take: Нормальный парень") {
		t.Fatal(r)
	}
	if r := c.Render(false); strings.Contains(r, "own take") || r != "" {
		t.Fatalf("the description leaked to a group: %q", r)
	}
	s.Replace(7, "Вася", nil)
	if len(s.All()) != 1 {
		t.Fatal("deleting the facts must not delete her description")
	}
	// clearing the description with no facts removes the card
	s.SetAbout(7, "", "", now)
	if len(s.All()) != 0 {
		t.Fatal("an empty card must go")
	}
	// a long description is cut
	s.SetAbout(8, "Ann", strings.Repeat("я", MaxAbout+50), now)
	if got := []rune(s.Get(8).About); len(got) != MaxAbout+1 {
		t.Fatal(len(got))
	}
	if err := s.SetAbout(0, "", "x", now); err == nil {
		t.Fatal("id 0 accepted")
	}
}
