package proxy

import (
	"crypto/sha256"
	"encoding/hex"
	"strings"
	"sync"
)

// Injector remembers "hidden" messages — the tool calls and results the proxy
// executed itself — and re-inserts them into later requests. The client only ever
// saw the final assistant text, so on the next request that text is the key:
// hidden messages are put right before the assistant message that followed them.
// (Port of proxy_server/message_injector + json_fingerprint, simplified.)
type Injector struct {
	mu     sync.Mutex
	hidden map[string][]map[string]any
	order  []string // FIFO for eviction
}

const maxHidden = 512

func NewInjector() *Injector { return &Injector{hidden: map[string][]map[string]any{}} }

func fingerprint(content string) string {
	h := sha256.Sum256([]byte(strings.TrimSpace(content)))
	return hex.EncodeToString(h[:8])
}

// Remember stores hidden messages that preceded the final assistant text.
func (in *Injector) Remember(finalAssistantText string, hidden []map[string]any) {
	if len(hidden) == 0 || strings.TrimSpace(finalAssistantText) == "" {
		return
	}
	k := fingerprint(finalAssistantText)
	in.mu.Lock()
	defer in.mu.Unlock()
	if _, ok := in.hidden[k]; !ok {
		in.order = append(in.order, k)
		if len(in.order) > maxHidden {
			delete(in.hidden, in.order[0])
			in.order = in.order[1:]
		}
	}
	in.hidden[k] = hidden
}

// Merge returns messages with hidden messages re-inserted.
func (in *Injector) Merge(msgs []any) []any {
	in.mu.Lock()
	defer in.mu.Unlock()
	out := make([]any, 0, len(msgs))
	for _, m := range msgs {
		if mm, ok := m.(map[string]any); ok && mm["role"] == "assistant" {
			if text, ok := mm["content"].(string); ok {
				for _, h := range in.hidden[fingerprint(text)] {
					out = append(out, h)
				}
			}
		}
		out = append(out, m)
	}
	return out
}
