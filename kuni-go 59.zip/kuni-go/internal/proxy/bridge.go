package proxy

import (
	"context"
	"fmt"
	"log"
	"strings"
	"sync"
	"time"

	"kuni/internal/llm"
	"kuni/internal/memory"
)

// Bridge collects proxied conversations and, when they go idle, saves them to the
// diary and working memory — so an external client (e.g. an IDE assistant) talking
// through the proxy also leaves memories. Port of proxy_server/context_bridge.
type Bridge struct {
	Dumper  *memory.Dumper
	System  func() string
	Timeout func() time.Duration

	mu       sync.Mutex
	sessions map[string]*bridgeSession
}

type bridgeSession struct {
	key     string
	msgs    []llm.Message
	updated time.Time
}

func NewBridge(d *memory.Dumper, system func() string, timeout func() time.Duration) *Bridge {
	return &Bridge{Dumper: d, System: system, Timeout: timeout, sessions: map[string]*bridgeSession{}}
}

// Collect records the latest request of a conversation. A request extends an
// existing session if it starts with the same first user message.
func (b *Bridge) Collect(msgs []any) {
	var conv []llm.Message
	key := ""
	for _, m := range msgs {
		mm, ok := m.(map[string]any)
		if !ok {
			continue
		}
		role, _ := mm["role"].(string)
		text := contentText(mm["content"])
		if role == "system" {
			continue
		}
		if key == "" && role == "user" {
			key = fingerprint(text)
		}
		if role == "tool" {
			role = "user"
			text = "[tool result] " + text
		}
		if strings.TrimSpace(text) != "" {
			conv = append(conv, llm.Message{Role: role, Content: text})
		}
	}
	if key == "" || len(conv) == 0 {
		return
	}
	b.mu.Lock()
	defer b.mu.Unlock()
	b.sessions[key] = &bridgeSession{key: key, msgs: conv, updated: time.Now()}
}

func contentText(c any) string {
	switch v := c.(type) {
	case string:
		return v
	case []any:
		var parts []string
		for _, p := range v {
			if pm, ok := p.(map[string]any); ok {
				if t, ok := pm["text"].(string); ok {
					parts = append(parts, t)
				}
			}
		}
		return strings.Join(parts, "\n")
	}
	return ""
}

// Flush dumps sessions not updated since cutoff. Pass time.Now() to flush everything.
func (b *Bridge) Flush(ctx context.Context, cutoff time.Time) (int, error) {
	b.mu.Lock()
	var due []*bridgeSession
	for k, s := range b.sessions {
		if !s.updated.After(cutoff) {
			due = append(due, s)
			delete(b.sessions, k)
		}
	}
	b.mu.Unlock()
	n := 0
	for _, s := range due {
		if err := b.Dumper.DumpSession(ctx, b.System(), s.msgs); err != nil {
			// put it back so the next tick retries
			b.mu.Lock()
			b.sessions[s.key] = s
			b.mu.Unlock()
			return n, fmt.Errorf("bridge dump: %w", err)
		}
		n++
	}
	return n, nil
}

// Run flushes idle sessions every minute until ctx ends, then flushes the rest.
func (b *Bridge) Run(ctx context.Context) {
	t := time.NewTicker(time.Minute)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			fctx, cancel := context.WithTimeout(context.Background(), 2*time.Minute)
			if _, err := b.Flush(fctx, time.Now()); err != nil {
				log.Printf("proxy: final bridge flush: %v", err)
			}
			cancel()
			return
		case <-t.C:
			if _, err := b.Flush(ctx, time.Now().Add(-b.Timeout())); err != nil {
				log.Printf("proxy: %v", err)
			}
		}
	}
}
