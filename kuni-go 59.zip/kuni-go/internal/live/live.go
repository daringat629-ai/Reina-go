// Package live is the feed of what she is doing right now: tool calls, results and thoughts, for the panel's "Эфир" tab.
// It lives in memory (a ring), so it costs nothing and vanishes on restart.
package live

import (
	"strings"
	"sync"
	"time"
)

// Event is one line of the feed.
type Event struct {
	ID   int64     `json:"id"`
	At   time.Time `json:"at"`
	Kind string    `json:"kind"` // tool, result, thought, chat
	Chat string    `json:"chat,omitempty"`
	Text string    `json:"text"`
	// ChatID is the Telegram chat the event is about (0 = none); Typing is the text she is writing there. The Telegram view of
	// the panel follows her with them.
	ChatID int64  `json:"chat_id,omitempty"`
	Typing string `json:"typing,omitempty"`
	// MsgID is the message her cursor is on (a reply, a reaction, a pressed button...); Act names what she does with it.
	MsgID int64  `json:"msg_id,omitempty"`
	Act   string `json:"act,omitempty"`
}

const keep = 400

// Feed is a ring of events, safe for concurrent use.
type Feed struct {
	mu   sync.Mutex
	next int64
	buf  []Event
}

// Add appends an event. Text is cut to one short paragraph.
func (f *Feed) Add(kind, chat, text string) { f.AddEvent(Event{Kind: kind, Chat: chat, Text: text}) }

// AddEvent appends a full event (ID and time are set here).
func (f *Feed) AddEvent(e Event) {
	if f == nil {
		return
	}
	e.Text = strings.TrimSpace(e.Text)
	if r := []rune(e.Text); len(r) > 400 {
		e.Text = string(r[:400]) + "…"
	}
	if r := []rune(e.Typing); len(r) > 2000 {
		e.Typing = string(r[:2000])
	}
	f.mu.Lock()
	defer f.mu.Unlock()
	f.next++
	e.ID, e.At = f.next, time.Now()
	f.buf = append(f.buf, e)
	if len(f.buf) > keep {
		f.buf = append([]Event(nil), f.buf[len(f.buf)-keep:]...)
	}
}

// Since returns the events newer than id (all kept ones for 0), oldest first.
func (f *Feed) Since(id int64) []Event {
	if f == nil {
		return nil
	}
	f.mu.Lock()
	defer f.mu.Unlock()
	i := len(f.buf)
	for i > 0 && f.buf[i-1].ID > id {
		i--
	}
	return append([]Event(nil), f.buf[i:]...)
}

// Last is the id of the newest event (0 when empty).
func (f *Feed) Last() int64 {
	if f == nil {
		return 0
	}
	f.mu.Lock()
	defer f.mu.Unlock()
	return f.next
}
