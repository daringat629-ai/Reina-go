package live

import (
	"strings"
	"testing"
)

func TestFeedRingAndSince(t *testing.T) {
	f := &Feed{}
	f.Add("tool", "Alex", "  browser {\"action\":\"open\"}  ")
	f.Add("result", "Alex", strings.Repeat("я", 1000))
	got := f.Since(0)
	if len(got) != 2 || got[0].Text != `browser {"action":"open"}` || got[0].ID != 1 {
		t.Fatalf("%+v", got)
	}
	if n := len([]rune(got[1].Text)); n != 401 {
		t.Fatalf("long text must be cut, got %d runes", n)
	}
	if got := f.Since(1); len(got) != 1 || got[0].Kind != "result" {
		t.Fatalf("since: %+v", got)
	}
	if len(f.Since(2)) != 0 || f.Last() != 2 {
		t.Fatal("nothing newer than the last")
	}
	for i := 0; i < 1000; i++ {
		f.Add("tool", "", "x")
	}
	if all := f.Since(0); len(all) != keep || all[len(all)-1].ID != 1002 {
		t.Fatalf("ring: %d", len(f.Since(0)))
	}
	var nilFeed *Feed
	nilFeed.Add("tool", "", "x") // a missing feed must not crash
	if nilFeed.Since(0) != nil {
		t.Fatal()
	}
}
