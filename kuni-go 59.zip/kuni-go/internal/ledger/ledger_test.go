package ledger

import (
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestBookAndBudgets(t *testing.T) {
	dir := t.TempDir()
	s := New(filepath.Join(dir, "ledger.json"))
	now := time.Date(2026, 10, 23, 12, 0, 0, 0, time.UTC)
	if _, _, err := s.Add(Entry{Date: "2026-10-01", Amount: 100, Category: "еда"}, now); err == nil || !strings.Contains(err.Error(), "currency") {
		t.Fatalf("the first entry needs a currency: %v", err)
	}
	e, _, err := s.Add(Entry{Date: "2026-10-01", Amount: 1200, Currency: "сом", Category: " Еда ", Note: "продукты"}, now)
	if err != nil || e.Currency != "KGS" || e.Category != "еда" || e.Kind != Expense || e.ID != 1 {
		t.Fatalf("%+v %v", e, err)
	}
	if s.DefaultCurrency() != "KGS" {
		t.Fatal("the first currency becomes the default")
	}
	if err := s.SetBudget("еда", 2000, ""); err != nil {
		t.Fatal(err)
	}
	_, warn, _ := s.Add(Entry{Date: "2026-10-05", Amount: 500, Category: "еда"}, now)
	if len(warn) != 1 || !strings.Contains(warn[0], "almost") {
		t.Fatalf("80%% warning: %v", warn)
	}
	_, warn, _ = s.Add(Entry{Date: "2026-10-06", Amount: -400, Category: "еда"}, now)
	if len(warn) != 1 || !strings.Contains(warn[0], "EXCEEDED") {
		t.Fatalf("over budget: %v", warn)
	}
	_, warn, _ = s.Add(Entry{Date: "2026-10-07", Amount: 300, Category: "такси"}, now)
	if len(warn) != 1 || !strings.Contains(warn[0], "new category") {
		t.Fatalf("new category hint: %v", warn)
	}
	s.Add(Entry{Date: "2026-10-10", Amount: 50000, Kind: "доход", Category: "зарплата"}, now)
	s.Add(Entry{Date: "2026-10-11", Amount: 20, Currency: "usd", Category: "подписки"}, now)
	s.Add(Entry{Date: "2026-09-30", Amount: 999, Category: "еда"}, now)

	r := s.Summarize("2026-10-01", "2026-10-31")
	if r.Spent["KGS"] != 2400 || r.Earned["KGS"] != 50000 || r.Spent["USD"] != 20 || r.Days != 31 {
		t.Fatalf("report %+v", r)
	}
	if c := r.ByCategory["KGS"]; c[0].Category != "еда" || c[0].Amount != 2100 || c[0].Count != 3 || c[1].Category != "такси" {
		t.Fatalf("categories %+v", c)
	}
	if bl := s.Budgets("2026-10"); len(bl) != 1 || bl[0].Spent != 2100 {
		t.Fatalf("budget lines %+v", bl)
	}
	if l := s.List(Filter{Text: "продукт"}); len(l) != 1 || l[0].ID != 1 {
		t.Fatalf("search %+v", l)
	}
	if _, err := s.Edit(1, Entry{Amount: 1300, Category: "Продукты"}); err != nil {
		t.Fatal(err)
	}
	if _, err := s.Delete(2); err != nil {
		t.Fatal(err)
	}
	// it all survives a restart
	s2 := New(filepath.Join(dir, "ledger.json"))
	if l := s2.List(Filter{}); len(l) != 6 || s2.DefaultCurrency() != "KGS" {
		t.Fatalf("after reload: %d entries", len(l))
	}
	if e, _, _ := s2.Add(Entry{Date: "2026-10-12", Amount: 1, Category: "x"}, now); e.ID != 8 {
		t.Fatalf("ids continue: %d", e.ID)
	}
}

func TestMoneyAndCurrency(t *testing.T) {
	for v, want := range map[float64]string{12500: "12 500", 3.5: "3,5", 0.1: "0,1", 1234567.891: "1 234 567,89", -50: "-50"} {
		if got := Money(v); got != want {
			t.Errorf("Money(%v) = %q, want %q", v, got, want)
		}
	}
	for in, want := range map[string]string{"сом": "KGS", "₽": "RUB", "$": "USD", "евро": "EUR", "btc": "BTC", "kgs": "KGS"} {
		if got := Currency(in); got != want {
			t.Errorf("Currency(%q) = %q", in, got)
		}
	}
}
