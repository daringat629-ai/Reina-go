package telegram

import (
	"regexp"
	"strconv"
	"strings"
	"unicode/utf16"
)

var mentionRe = regexp.MustCompile(`\[([^\]\n]{1,64})\]\(tg://user\?id=(\d{1,15})\)`)

// codeRe finds a fenced block (```lang\n...```) or an inline `code` span; the block comes first so that
// backticks inside it are not taken for spans.
var codeRe = regexp.MustCompile("(?s)```([A-Za-z0-9_+#.-]{0,20})[ \\t]*\\n?(.*?)```|`([^`\\n]{1,300})`")

func u16len(s string) int {
	n := 0
	for _, r := range s {
		n += utf16.RuneLen(r)
	}
	return n
}

// withMentions turns the few markup forms she is allowed to use into a formattedText and leaves everything else as plain
// text (no markdown surprises): "[Joe](tg://user?id=9)" becomes the visible text "Joe" plus a text-mention entity,
// ```lang ... ``` becomes a monospace block with a copy button, `x` becomes inline monospace.
func withMentions(text string) obj {
	if !strings.Contains(text, "`") && !mentionRe.MatchString(text) {
		return formatted(text)
	}
	var b strings.Builder
	var ents []any
	units := 0
	prose := func(seg string) {
		last := 0
		for _, l := range mentionRe.FindAllStringSubmatchIndex(seg, -1) {
			before := seg[last:l[0]]
			b.WriteString(before)
			units += u16len(before)
			label := seg[l[2]:l[3]]
			uid, _ := strconv.ParseInt(seg[l[4]:l[5]], 10, 64)
			ents = append(ents, obj{"@type": "textEntity", "offset": units, "length": u16len(label),
				"type": obj{"@type": "textEntityTypeMentionName", "user_id": uid}})
			b.WriteString(label)
			units += u16len(label)
			last = l[1]
		}
		rest := seg[last:]
		b.WriteString(rest)
		units += u16len(rest)
	}
	last := 0
	for _, l := range codeRe.FindAllStringSubmatchIndex(text, -1) {
		prose(text[last:l[0]])
		last = l[1]
		if l[6] >= 0 { // inline `code`
			code := text[l[6]:l[7]]
			ents = append(ents, obj{"@type": "textEntity", "offset": units, "length": u16len(code), "type": obj{"@type": "textEntityTypeCode"}})
			b.WriteString(code)
			units += u16len(code)
			continue
		}
		lang, code := text[l[2]:l[3]], strings.Trim(text[l[4]:l[5]], "\n")
		if code == "" {
			continue
		}
		// a block starts on its own line
		if b.Len() > 0 && !strings.HasSuffix(b.String(), "\n") {
			b.WriteString("\n")
			units++
		}
		typ := obj{"@type": "textEntityTypePre"}
		if lang != "" {
			typ = obj{"@type": "textEntityTypePreCode", "language": lang}
		}
		ents = append(ents, obj{"@type": "textEntity", "offset": units, "length": u16len(code), "type": typ})
		b.WriteString(code)
		units += u16len(code)
	}
	prose(text[last:])
	out := b.String()
	if len(ents) == 0 {
		return formatted(out)
	}
	return obj{"@type": "formattedText", "text": strings.TrimLeft(out, "\n"), "entities": fixOffsets(out, ents)}
}

// fixOffsets shifts the entities when TrimLeft removed leading newlines (a block at the very start of the message).
func fixOffsets(out string, ents []any) []any {
	trimmed := len(out) - len(strings.TrimLeft(out, "\n"))
	if trimmed == 0 {
		return ents
	}
	for _, e := range ents {
		m := e.(obj)
		m["offset"] = m["offset"].(int) - trimmed
	}
	return ents
}
