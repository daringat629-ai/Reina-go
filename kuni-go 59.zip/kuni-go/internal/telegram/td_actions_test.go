package telegram

import (
	"strings"
	"testing"
	"time"
)

func TestSendWithMarkdownSilentAndScheduled(t *testing.T) {
	f := newFakeTD(func(req obj) obj {
		switch str(req, "@type") {
		case "parseTextEntities":
			if strings.Contains(str(req, "text"), "BAD") {
				return obj{"@type": "error", "code": 400, "message": "can't parse"}
			}
			return obj{"@type": "formattedText", "text": "жир", "entities": []any{obj{"@type": "textEntity", "offset": 0, "length": 3, "type": obj{"@type": "textEntityTypeBold"}}}}
		case "sendMessage":
			return obj{"@type": "message", "id": 5, "chat_id": req["chat_id"], "date": 1, "content": obj{"@type": "messageText", "text": obj{"text": "x"}}}
		}
		return nil
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	at := time.Unix(1900000000, 0)
	if _, err := c.SendWith(ctx, 5, "*жир*", SendOptions{Markdown: true, Silent: true, At: at, ReplyTo: 3}); err != nil {
		t.Fatal(err)
	}
	r := f.requests("sendMessage")[0]
	txt := sub(sub(r, "input_message_content"), "text")
	opts := sub(r, "options")
	if len(arr(txt, "entities")) != 1 || str(txt, "text") != "жир" || opts["disable_notification"] != true ||
		num(sub(opts, "scheduling_state")["send_date"]) != 1900000000 || num(sub(r, "reply_to")["message_id"]) != 3 {
		t.Fatalf("request: %v", r)
	}
	pt := f.requests("parseTextEntities")[0]
	if str(sub(pt, "parse_mode"), "@type") != "textParseModeMarkdown" {
		t.Fatalf("parse mode: %v", pt)
	}
	// the parser refuses: the text goes out as written
	if _, err := c.SendWith(ctx, 5, "BAD *", SendOptions{Markdown: true}); err != nil {
		t.Fatal(err)
	}
	r = f.requests("sendMessage")[1]
	if str(sub(sub(r, "input_message_content"), "text"), "text") != "BAD *" || r["options"] != nil {
		t.Fatalf("fallback: %v", r)
	}
}

func TestPressButtonMuteDiceLocationPinnedAndFolderLists(t *testing.T) {
	f := newFakeTD(func(req obj) obj {
		switch str(req, "@type") {
		case "getCallbackQueryAnswer":
			return obj{"@type": "callbackQueryAnswer", "text": "Готово", "show_alert": true, "url": ""}
		case "getChatPinnedMessage":
			if num(req["chat_id"]) == 6 {
				return obj{"@type": "error", "code": 404, "message": "Not Found"}
			}
			return obj{"@type": "message", "id": 8, "chat_id": 5, "date": 1, "content": obj{"@type": "messageText", "text": obj{"text": "закреп"}}}
		case "getChats":
			return obj{"@type": "chats", "chat_ids": []any{5}}
		case "getChat":
			return obj{"@type": "chat", "id": 5, "title": "A", "type": obj{"@type": "chatTypeBasicGroup", "basic_group_id": 1}}
		case "sendMessage":
			return obj{"@type": "message", "id": 5, "chat_id": 5, "date": 1, "content": obj{"@type": "messageDice", "emoji": "🎯", "value": 3}}
		}
		return nil
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	a, err := c.PressButton(ctx, 5, 9, "eWVz")
	if err != nil || a.Text != "Готово" || !a.Alert {
		t.Fatalf("answer: %+v %v", a, err)
	}
	q := f.requests("getCallbackQueryAnswer")[0]
	if str(sub(q, "payload"), "data") != "eWVz" || str(sub(q, "payload"), "@type") != "callbackQueryPayloadData" {
		t.Fatalf("press request: %v", q)
	}
	if err := c.SetMuted(ctx, 5, true); err != nil {
		t.Fatal(err)
	}
	ns := sub(f.requests("setChatNotificationSettings")[0], "notification_settings")
	if num(ns["mute_for"]) < 365*24*3600 || ns["use_default_mute_for"] != false || ns["use_default_sound"] != true {
		t.Fatalf("mute: %v", ns)
	}
	if m, err := c.PinnedMessage(ctx, 5); err != nil || m.Text != "закреп" {
		t.Fatalf("pinned: %+v %v", m, err)
	}
	if _, err := c.PinnedMessage(ctx, 6); err != ErrNotFound {
		t.Fatalf("no pinned: %v", err)
	}
	if n := len(c.Health().Errors); n != 0 {
		t.Fatalf("a 404 (no pinned message) must not count as a Telegram fault: %d errors", n)
	}
	if m, err := c.SendDice(ctx, 5, "🎯", 0); err != nil || m.Dice != "🎯 3" {
		t.Fatalf("dice: %+v %v", m, err)
	}
	if str(sub(f.requests("sendMessage")[0], "input_message_content"), "emoji") != "🎯" {
		t.Fatal("dice emoji not sent")
	}
	if _, err := c.SendLocation(ctx, 5, 91, 0, 0); err == nil {
		t.Fatal("bad latitude accepted")
	}
	if _, err := c.SendLocation(ctx, 5, 42.8, 74.6, 0); err != nil {
		t.Fatal(err)
	}
	loc := sub(sub(f.requests("sendMessage")[1], "input_message_content"), "location")
	if fnum(loc["latitude"]) != 42.8 {
		t.Fatalf("location: %v", loc)
	}
	if chats, err := c.ChatsIn(ctx, ChatList{Folder: 3}, 10); err != nil || len(chats) != 1 {
		t.Fatalf("folder list: %v %v", chats, err)
	}
	gc := f.requests("getChats")[0]
	if str(sub(gc, "chat_list"), "@type") != "chatListFolder" || num(sub(gc, "chat_list")["chat_folder_id"]) != 3 {
		t.Fatalf("folder request: %v", gc)
	}
	if _, err := c.ChatsIn(ctx, ChatList{Archive: true}, 10); err != nil {
		t.Fatal(err)
	}
	if str(sub(f.requests("getChats")[1], "chat_list"), "@type") != "chatListArchive" || len(f.requests("loadChats")) != 2 {
		t.Fatal("archive request")
	}
}

func TestFakeRichFiltersAndRecords(t *testing.T) {
	f := NewFake()
	f.Incoming(Chat{ID: 1, Title: "A", Folders: []int{2}}, 5, "x", "hi")
	f.Incoming(Chat{ID: 2, Title: "B", Archived: true}, 5, "x", "hi")
	f.Incoming(Chat{ID: 3, Title: "C"}, 5, "x", "hi")
	ctx := t.Context()
	if l, _ := f.ChatsIn(ctx, ChatList{Archive: true}, 0); len(l) != 1 || l[0].ID != 2 {
		t.Fatalf("archive: %+v", l)
	}
	if l, _ := f.ChatsIn(ctx, ChatList{Folder: 2}, 0); len(l) != 1 || l[0].ID != 1 {
		t.Fatalf("folder: %+v", l)
	}
	if l, _ := f.ChatsIn(ctx, ChatList{}, 0); len(l) != 2 {
		t.Fatalf("main: %+v", l)
	}
	_ = f.SetMuted(ctx, 3, true)
	if c, _ := f.Chat(ctx, 3); !c.Muted {
		t.Fatal("mute not stored")
	}
	m, _ := f.SendWith(ctx, 3, "a *b* c", SendOptions{Markdown: true})
	if m.Text != "a b c" || len(m.Entities) != 1 || m.Entities[0].Offset != 2 {
		t.Fatalf("markdown: %+v", m)
	}
	if _, err := f.PinnedMessage(ctx, 3); err != ErrNotFound {
		t.Fatalf("pinned: %v", err)
	}
	_ = f.Pin(ctx, 3, m.ID, false)
	if p, err := f.PinnedMessage(ctx, 3); err != nil || p.ID != m.ID {
		t.Fatalf("pinned: %+v %v", p, err)
	}
}

func TestLoginCodeIsHidden(t *testing.T) {
	if got := redactLoginCode(777000, "Код для входа в Telegram: 13583. Не давайте код никому"); strings.Contains(got, "13583") {
		t.Fatalf("code leaked: %s", got)
	}
	if got := redactLoginCode(5, "мой код 13583"); !strings.Contains(got, "13583") {
		t.Fatal("other chats must stay untouched")
	}
}
