package telegram

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

// Transport moves raw tdlib JSON requests/updates. The real one is a thin cgo
// wrapper over libtdjson (build tag "tdlib", see td_cgo.go); tests use a fake.
type Transport interface {
	// Send submits one request (a JSON object). Safe for concurrent use.
	Send(req []byte)
	// Receive waits up to timeout for the next response/update; nil on timeout.
	// It is called from a single goroutine.
	Receive(timeout time.Duration) []byte
}

// TDConfig configures the user-account client.
type TDConfig struct {
	APIID   int64
	APIHash string
	Phone   string // optional; asked on stdin when empty
	// QR logs in by a QR code (shown by the panel at /admin/qr) instead of a code sent to the phone.
	QR bool
	// Password is the cloud password (two-step verification); asked on stdin when empty and needed.
	Password   string
	DBDir      string // tdlib database directory (login is kept here)
	AppVersion string
	// Prompt asks the operator for "phone number", "verification code" or "cloud password".
	// Default: print to stdout and read a line from stdin.
	Prompt func(what string) string
	// MaxQPS throttles requests: Telegram bans accounts of aggressive 3rd party clients. Default 20.
	MaxQPS int
}

type obj = map[string]any

// TDClient implements Client for a *user account* through tdlib's JSON interface,
// exactly what the C++ project does (TelegramClientImpl + td_api).
type TDClient struct {
	tr  Transport
	cfg TDConfig

	seq     atomic.Int64
	mu      sync.Mutex
	pending map[string]chan obj
	updates chan Message
	events  chan Event
	ev      eventState
	hl      healthState
	sleepFn func(ctx context.Context, d time.Duration) error // tests
	threads sync.Map                                         // "chat:msg" -> topic id of messages seen in forum topics
	ready   chan struct{}
	readyOK sync.Once
	closed  chan struct{}
	myID    atomic.Int64
	closeAt atomic.Int64 // unix nanos: when the shutdown stops waiting for tdlib
	ver     atomic.Int64 // tdlib version (see td_version.go), 0 until reported
	dropped atomic.Int64 // incoming messages that found the updates channel full

	cmu      sync.Mutex
	users    map[int64]string
	chats    map[int64]*tdChat
	actions  map[int64]action // chat -> what someone is doing there (typing...), for the chat list
	statuses map[int64]userSt // user -> online status
	folders  []Folder

	tmu      sync.Mutex
	callTime []time.Time

	contactsMu sync.Mutex
	contacts   map[int64]bool
	contactsAt time.Time

	sends   sendWaits   // pending sends waiting for their outcome (td_sent.go)
	inq     chan obj    // incoming messages, parsed and delivered in order by one worker
	inOnce  sync.Once   // starts that worker
	members memberCache // her own status in groups (Chat), refreshed now and then
}

type tdChat struct {
	ID           int64
	Title        string
	Kind         ChatKind
	Unread       int
	LastReadIn   int64
	LastMsgID    int64
	LastText     string
	LastDate     time.Time
	PhotoFileID  int64
	InChatList   bool
	superOrBasic bool
	groupID      int64 // supergroup_id or basic_group_id
	basic        bool
	// the live state of the chat list
	Pinned, Muted, Archived bool
	Folders                 []int
	Mentions                int
	UserID                  int64 // private chats
}

func NewTD(tr Transport, cfg TDConfig) *TDClient {
	if cfg.MaxQPS <= 0 {
		cfg.MaxQPS = 20
	}
	if cfg.DBDir == "" {
		cfg.DBDir = "tdlib"
	}
	if cfg.Prompt == nil {
		cfg.Prompt = stdinPrompt
	}
	return &TDClient{tr: tr, cfg: cfg, pending: map[string]chan obj{}, updates: make(chan Message, 256), events: make(chan Event, 128),
		inq: make(chan obj, 1024), ready: make(chan struct{}), closed: make(chan struct{}), users: map[int64]string{}, chats: map[int64]*tdChat{}}
}

func stdinPrompt(what string) string {
	fmt.Printf("[Authentication] required. Please supply %s: ", what)
	var s string
	fmt.Scanln(&s)
	return strings.TrimSpace(s)
}

func (c *TDClient) Updates() <-chan Message { return c.updates }
func (c *TDClient) MyID() int64             { return c.myID.Load() }

// ---- JSON helpers ----

func decode(raw []byte) (obj, error) {
	var m obj
	d := json.NewDecoder(bytes.NewReader(raw))
	d.UseNumber() // ids exceed 2^53 in the wild; keep them exact
	if err := d.Decode(&m); err != nil {
		return nil, err
	}
	return m, nil
}

func str(m obj, k string) string { s, _ := m[k].(string); return s }
func sub(m obj, k string) obj    { s, _ := m[k].(map[string]any); return s }
func arr(m obj, k string) []any  { s, _ := m[k].([]any); return s }
func typ(m obj) string           { return str(m, "@type") }

func num(v any) int64 {
	switch t := v.(type) {
	case json.Number:
		if n, err := t.Int64(); err == nil {
			return n
		}
		f, _ := t.Float64()
		return int64(f)
	case string: // tdlib's JSON interface encodes int64 fields (e.g. my_id) as strings
		n, _ := strconv.ParseInt(t, 10, 64)
		return n
	case float64:
		return int64(t)
	case int64:
		return t
	case int:
		return int64(t)
	}
	return 0
}

func toObj(v any) obj { m, _ := v.(map[string]any); return m }

// ---- request plumbing ----

func (c *TDClient) throttle(ctx context.Context) error {
	for {
		c.tmu.Lock()
		now := time.Now()
		cut := now.Add(-time.Second)
		i := 0
		for i < len(c.callTime) && c.callTime[i].Before(cut) {
			i++
		}
		c.callTime = c.callTime[i:]
		if len(c.callTime) < c.cfg.MaxQPS {
			c.callTime = append(c.callTime, now)
			c.tmu.Unlock()
			return nil
		}
		wait := c.callTime[0].Add(time.Second).Sub(now)
		c.tmu.Unlock()
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-time.After(wait):
		}
	}
}

// call sends a request and waits for its response; tdlib "error" objects become Go errors.
// A flood-wait (429 "retry after N") is waited out and the request repeated: Telegram rejected it, nothing was done.
func (c *TDClient) call(ctx context.Context, req obj) (obj, error) {
	for attempt := 0; ; attempt++ {
		if err := c.waitFlood(ctx); err != nil {
			return nil, err
		}
		resp, err := c.call1(ctx, req)
		if err == nil {
			return resp, nil
		}
		var te *tdError
		if !errors.As(err, &te) {
			return nil, err
		}
		if te.Code != 404 { // "not found" is an ordinary answer (no pinned message, everything loaded), not a fault
			c.hl.record(str(req, "@type"), num(req["chat_id"]), te.Error())
		}
		if te.Code != 429 || attempt >= 2 {
			return nil, err
		}
		wait := floodDelay(te.Message)
		c.hl.flood(wait)
		fmt.Fprintf(os.Stderr, "telegram: flood wait %s on %s\n", wait, str(req, "@type"))
	}
}

// tdError is a tdlib "error" object.
type tdError struct {
	Code    int
	Message string
}

func (e *tdError) Error() string { return fmt.Sprintf("telegram %d: %s", e.Code, e.Message) }

var retryAfterRe = regexp.MustCompile(`(?i)retry after (\d+)`)

// floodDelay reads "Too Many Requests: retry after 12" (capped: a long ban must not freeze her for hours).
func floodDelay(msg string) time.Duration {
	n := 5
	if m := retryAfterRe.FindStringSubmatch(msg); m != nil {
		n, _ = strconv.Atoi(m[1])
	}
	d := time.Duration(n+1) * time.Second
	if d > 90*time.Second {
		d = 90 * time.Second
	}
	return d
}

// waitFlood holds every request back while a flood wait is running.
func (c *TDClient) waitFlood(ctx context.Context) error {
	d := time.Until(c.hl.until())
	if d <= 0 {
		return nil
	}
	return c.sleep(ctx, d)
}

func (c *TDClient) sleep(ctx context.Context, d time.Duration) error {
	if c.sleepFn != nil {
		return c.sleepFn(ctx, d)
	}
	select {
	case <-time.After(d):
		return nil
	case <-ctx.Done():
		return ctx.Err()
	}
}

func (c *TDClient) call1(ctx context.Context, req obj) (obj, error) {
	if err := c.throttle(ctx); err != nil {
		return nil, err
	}
	id := strconv.FormatInt(c.seq.Add(1), 10)
	req["@extra"] = id
	raw, err := json.Marshal(req)
	if err != nil {
		return nil, err
	}
	ch := make(chan obj, 1)
	c.mu.Lock()
	c.pending[id] = ch
	c.mu.Unlock()
	defer func() { c.mu.Lock(); delete(c.pending, id); c.mu.Unlock() }()
	c.tr.Send(raw)
	select {
	case <-ctx.Done():
		return nil, ctx.Err()
	case <-c.closed:
		return nil, errors.New("tdlib closed")
	case resp := <-ch:
		if typ(resp) == "error" {
			return nil, &tdError{Code: int(num(resp["code"])), Message: str(resp, "message")}
		}
		return resp, nil
	}
}

func (c *TDClient) waitReady(ctx context.Context) error {
	select {
	case <-c.ready:
		return nil
	case <-ctx.Done():
		return ctx.Err()
	}
}

// api waits for login and then calls.
func (c *TDClient) api(ctx context.Context, req obj) (obj, error) {
	if err := c.waitReady(ctx); err != nil {
		return nil, err
	}
	return c.call(ctx, req)
}

// Run drives tdlib (authorization, updates) until ctx ends.
func (c *TDClient) Run(ctx context.Context) error {
	c.tr.Send([]byte(`{"@type":"getOption","name":"version"}`)) // starts the client
	done := make(chan struct{})
	stopping := make(chan struct{})
	go func() {
		defer close(done)
		for {
			select {
			case <-c.closed:
				return // tdlib has flushed its database and will send nothing more
			case <-stopping:
				// after close was sent: keep reading so authorizationStateClosed is seen, but give up eventually
			default:
			}
			raw := c.tr.Receive(time.Second)
			if raw == nil {
				select {
				case <-stopping:
					if time.Now().After(c.closeDeadline()) {
						return
					}
				default:
				}
				continue
			}
			m, err := decode(raw)
			if err != nil {
				continue
			}
			c.dispatch(ctx, m)
		}
	}()
	<-ctx.Done()
	// graceful close so tdlib flushes its database: the receive loop runs until tdlib says it is closed.
	c.setCloseDeadline(time.Now().Add(10 * time.Second))
	close(stopping)
	c.tr.Send([]byte(`{"@type":"close"}`))
	select {
	case <-done:
	case <-time.After(12 * time.Second):
	}
	return nil
}

func (c *TDClient) setCloseDeadline(t time.Time) { c.closeAt.Store(t.UnixNano()) }
func (c *TDClient) closeDeadline() time.Time     { return time.Unix(0, c.closeAt.Load()) }

func (c *TDClient) dispatch(ctx context.Context, m obj) {
	if extra := str(m, "@extra"); extra != "" {
		c.mu.Lock()
		ch := c.pending[extra]
		c.mu.Unlock()
		if ch != nil {
			ch <- m
		}
		return
	}
	switch typ(m) {
	case "updateAuthorizationState":
		c.onAuthState(ctx, sub(m, "authorization_state"))
	case "updateOption":
		switch str(m, "name") {
		case "my_id":
			c.myID.Store(num(sub(m, "value")["value"]))
		case "version":
			if v := parseTDVersion(str(sub(m, "value"), "value")); v != 0 {
				if c.ver.Swap(v) != v {
					fmt.Fprintf(os.Stderr, "telegram: tdlib %s\n", str(sub(m, "value"), "value"))
					if v < tdv(1, 8, 61) {
						fmt.Fprintf(os.Stderr, "telegram: tdlib older than 1.8.61 is not supported (setChatMemberTag and the newer message shapes are missing); rebuild it from a fresh master\n")
					}
				}
			}
		}
	case "updateUser":
		u := sub(m, "user")
		c.cmu.Lock()
		c.users[num(u["id"])] = userDisplay(u)
		if st := sub(u, "status"); st != nil {
			if c.statuses == nil {
				c.statuses = map[int64]userSt{}
			}
			c.statuses[num(u["id"])] = statusOf(st)
		}
		c.cmu.Unlock()
	case "updateNewChat":
		c.storeChat(sub(m, "chat"))
	case "updateChatNotificationSettings", "updateChatUnreadMentionCount", "updateChatPosition", "updateChatAddedToList", "updateChatRemovedFromList",
		"updateChatAction", "updateUserStatus", "updateChatFolders":
		c.chatFlagsUpdate(m)
	case "updateChatLastMessage":
		c.cmu.Lock()
		if ch := c.chats[num(m["chat_id"])]; ch != nil {
			if lm := sub(m, "last_message"); lm != nil {
				ch.LastMsgID, ch.LastDate, ch.LastText = num(lm["id"]), time.Unix(num(lm["date"]), 0), contentPreview(sub(lm, "content"))
			}
		}
		c.cmu.Unlock()
	case "updateChatReadInbox":
		c.cmu.Lock()
		if ch := c.chats[num(m["chat_id"])]; ch != nil {
			ch.LastReadIn, ch.Unread = num(m["last_read_inbox_message_id"]), int(num(m["unread_count"]))
		}
		c.cmu.Unlock()
	case "updateChatTitle":
		c.cmu.Lock()
		if ch := c.chats[num(m["chat_id"])]; ch != nil {
			ch.Title = str(m, "title")
		}
		c.cmu.Unlock()
	case "updateMessageContent":
		go c.onContent(ctx, m)
	case "updateMessageInteractionInfo":
		go c.onInteraction(ctx, m)
	case "updateNewMessage":
		msg := sub(m, "message")
		if msg == nil || msg["is_outgoing"] == true {
			return
		}
		// One worker parses and delivers the messages in the order they came: a goroutine per message (as before)
		// let a quick message overtake a slow one, so a reply could reach her before the question. The receive loop
		// never blocks here: when even the queue is full, the message is counted as dropped.
		c.inOnce.Do(func() { go c.incoming(ctx) })
		select {
		case c.inq <- msg:
		default:
			c.dropped.Add(1)
			fmt.Fprintf(os.Stderr, "telegram: dropped an incoming message in chat %d: the agent is not keeping up\n", num(msg["chat_id"]))
		}
	case "updateMessageSendSucceeded", "updateMessageSendFailed":
		c.onSendResult(m)
	case "updateChatMember":
		if u := sub(sub(m, "new_chat_member"), "member_id"); num(u["user_id"]) == c.MyID() {
			c.members.forget(num(m["chat_id"]))
		}
	case "updateSupergroup", "updateBasicGroup": // they carry her own status in the group
		if g := sub(m, "supergroup"); g != nil {
			c.members.forget(-1000000000000 - num(g["id"]))
		} else if g := sub(m, "basic_group"); g != nil {
			c.members.forget(-num(g["id"]))
		}
	}
}

// incoming delivers new messages one by one, in order. When the agent is behind, it waits (the queue keeps the rest).
func (c *TDClient) incoming(ctx context.Context) {
	for {
		select {
		case <-ctx.Done():
			return
		case msg := <-c.inq:
			out := c.parseMessage(ctx, msg)
			c.remember(out)
			select {
			case c.updates <- out:
			case <-ctx.Done():
				return
			}
		}
	}
}

func (c *TDClient) onAuthState(ctx context.Context, st obj) {
	go func() {
		var err error
		switch typ(st) {
		case "authorizationStateWaitTdlibParameters":
			_, err = c.call(ctx, obj{"@type": "setTdlibParameters", "database_directory": c.cfg.DBDir, "use_message_database": true,
				"use_secret_chats": true, "api_id": c.cfg.APIID, "api_hash": c.cfg.APIHash, "system_language_code": "en",
				"device_model": "Desktop", "application_version": c.cfg.AppVersion})
		case "authorizationStateWaitPhoneNumber":
			if c.cfg.QR {
				_, err = c.call(ctx, obj{"@type": "requestQrCodeAuthentication", "other_user_ids": []int64{}})
				break
			}
			phone := c.cfg.Phone
			if phone == "" {
				phone = c.cfg.Prompt("phone number")
			}
			_, err = c.call(ctx, obj{"@type": "setAuthenticationPhoneNumber", "phone_number": phone})
		case "authorizationStateWaitOtherDeviceConfirmation":
			link := str(st, "link")
			setLoginQR(link)
			fmt.Fprintln(os.Stderr, "telegram: вход по QR-коду: открой в браузере http://АДРЕС-ЭТОГО-КОМПЬЮТЕРА:ПОРТ/admin/qr и отсканируй код в Telegram (Настройки → Устройства → Подключить устройство)")
		case "authorizationStateWaitCode":
			_, err = c.call(ctx, obj{"@type": "checkAuthenticationCode", "code": c.cfg.Prompt("verification code")})
		case "authorizationStateWaitPassword":
			pw := c.cfg.Password
			if pw == "" {
				pw = c.cfg.Prompt("cloud password")
			}
			_, err = c.call(ctx, obj{"@type": "checkAuthenticationPassword", "password": pw})
		case "authorizationStateReady":
			setLoginDone()
			c.readyOK.Do(func() { close(c.ready) })
		case "authorizationStateClosed":
			select {
			case <-c.closed:
			default:
				close(c.closed)
			}
		}
		if err != nil && ctx.Err() == nil {
			fmt.Fprintf(os.Stderr, "telegram auth (%s): %v\n", typ(st), err)
		}
	}()
}

// ---- caches / conversion ----

// ---- Client: reading ----

func (c *TDClient) Chats(ctx context.Context, limit int) ([]Chat, error) {
	if limit <= 0 {
		limit = 50
	}
	r, err := c.api(ctx, obj{"@type": "getChats", "chat_list": obj{"@type": "chatListMain"}, "limit": limit})
	if err != nil {
		return nil, err
	}
	var out []Chat
	for _, idv := range arr(r, "chat_ids") {
		t, err := c.chatInfo(ctx, num(idv))
		if err != nil {
			continue
		}
		out = append(out, c.toChat(t))
	}
	return out, nil
}

func (c *TDClient) Chat(ctx context.Context, id int64) (Chat, error) {
	t, err := c.chatInfo(ctx, id)
	if err != nil {
		return Chat{}, err
	}
	ch := c.toChat(t)
	if t.superOrBasic {
		// membership / admin status, like the C++ getChatMember(myId) check. Every turn asks for the chat, and for a
		// supergroup that is a request to the server: the answer is kept for a while (and dropped when it changes).
		st, ok := c.members.get(id)
		if !ok {
			r, err := c.call(ctx, obj{"@type": "getChatMember", "chat_id": id, "member_id": obj{"@type": "messageSenderUser", "user_id": c.MyID()}})
			if err == nil {
				st = typ(sub(r, "status"))
			}
			c.members.put(id, st) // "" (the list is hidden) is kept too: asking again gives the same
		}
		switch st {
		case "":
			ch.IsMember = t.InChatList // large channels hide the member list
		case "chatMemberStatusLeft", "chatMemberStatusBanned":
			ch.IsMember = false
		case "chatMemberStatusCreator", "chatMemberStatusAdministrator":
			ch.IsAdmin = true
		}
	}
	return ch, nil
}

// memberCache keeps her own member status per group for memberTTL.
type memberCache struct {
	mu sync.Mutex
	m  map[int64]memberStatus
}

type memberStatus struct {
	status string
	at     time.Time
}

const memberTTL = 3 * time.Minute

func (mc *memberCache) get(chat int64) (string, bool) {
	mc.mu.Lock()
	defer mc.mu.Unlock()
	e, ok := mc.m[chat]
	if !ok || time.Since(e.at) > memberTTL {
		return "", false
	}
	return e.status, true
}

func (mc *memberCache) put(chat int64, status string) {
	mc.mu.Lock()
	defer mc.mu.Unlock()
	if mc.m == nil || len(mc.m) > 2000 {
		mc.m = map[int64]memberStatus{}
	}
	mc.m[chat] = memberStatus{status, time.Now()}
}

func (mc *memberCache) forget(chat int64) {
	mc.mu.Lock()
	defer mc.mu.Unlock()
	delete(mc.m, chat)
}

func (c *TDClient) SearchChats(ctx context.Context, q string) ([]Chat, error) {
	var ids []int64
	if strings.HasPrefix(q, "@") {
		r, err := c.api(ctx, obj{"@type": "searchPublicChat", "username": strings.TrimPrefix(q, "@")})
		if err == nil {
			ids = append(ids, num(r["id"]))
			c.storeChat(r)
		}
	}
	r, err := c.api(ctx, obj{"@type": "searchChats", "query": strings.TrimPrefix(q, "@"), "limit": 20})
	if err != nil {
		return nil, err
	}
	for _, v := range arr(r, "chat_ids") {
		ids = append(ids, num(v))
	}
	var out []Chat
	seen := map[int64]bool{}
	for _, id := range ids {
		if seen[id] {
			continue
		}
		seen[id] = true
		if t, err := c.chatInfo(ctx, id); err == nil {
			out = append(out, c.toChat(t))
		}
	}
	return out, nil
}

// historyPages bounds the requests of one history read.
const historyPages = 8

// history reads up to limit messages of a chat, oldest first. tdlib answers getChatHistory with what it has at hand
// — often a single message when the chat was not opened lately — so the read goes on, from the oldest message got,
// until it has enough or the chat has no more. (One request used to be all: she often saw one message of a dialog.)
func (c *TDClient) history(ctx context.Context, chatID, from int64, offset, limit int) ([]Message, error) {
	var raw []any
	seen := map[int64]bool{}
	for page := 0; len(raw) < limit && page < historyPages; page++ {
		r, err := c.api(ctx, obj{"@type": "getChatHistory", "chat_id": chatID, "from_message_id": from, "offset": offset, "limit": limit - len(raw)})
		if err != nil {
			if len(raw) > 0 {
				break // what was read is still worth having
			}
			return nil, err
		}
		added := 0
		for _, v := range arr(r, "messages") {
			m := toObj(v)
			if m == nil || seen[num(m["id"])] {
				continue
			}
			seen[num(m["id"])] = true
			raw = append(raw, v)
			added++
		}
		if added == 0 {
			break
		}
		from, offset = num(toObj(raw[len(raw)-1])["id"]), 0 // newest first: the last one is the oldest
	}
	return c.parseList(ctx, raw, true), nil
}

func (c *TDClient) Unread(ctx context.Context, chatID int64) ([]Message, error) {
	t, err := c.chatInfo(ctx, chatID)
	if err != nil {
		return nil, err
	}
	if t.Unread <= 0 {
		return nil, nil
	}
	n := t.Unread
	if n > 100 {
		n = 100
	}
	msgs, err := c.history(ctx, chatID, 0, 0, n)
	if err != nil {
		return nil, err
	}
	var out []Message
	for _, m := range msgs {
		if !m.Outgoing && m.ID > t.LastReadIn {
			out = append(out, m)
		}
	}
	return out, nil
}

func (c *TDClient) History(ctx context.Context, chatID, aroundID int64, before, after int) ([]Message, error) {
	if aroundID == 0 {
		return c.history(ctx, chatID, 0, 0, before+1)
	}
	// a negative offset returns `after` newer messages, the anchor, and older ones.
	return c.history(ctx, chatID, aroundID, -after, before+after+1)
}

func (c *TDClient) Message(ctx context.Context, chatID, msgID int64) (Message, error) {
	r, err := c.api(ctx, obj{"@type": "getMessage", "chat_id": chatID, "message_id": msgID})
	if err != nil {
		return Message{}, err
	}
	return c.parseMessage(ctx, r), nil
}

func (c *TDClient) Search(ctx context.Context, q SearchQuery) ([]Message, error) {
	limit := q.Limit
	if limit <= 0 {
		limit = 20
	}
	var req obj
	if q.ChatID != 0 {
		req = obj{"@type": "searchChatMessages", "chat_id": q.ChatID, "query": q.Text, "from_message_id": 0, "offset": 0, "limit": limit}
		if q.SenderID != 0 {
			req["sender_id"] = obj{"@type": "messageSenderUser", "user_id": q.SenderID}
		}
	} else {
		req = obj{"@type": "searchMessages", "chat_list": obj{"@type": "chatListMain"}, "query": q.Text, "offset": "", "limit": limit}
		if !q.Since.IsZero() {
			req["min_date"] = q.Since.Unix()
		}
	}
	r, err := c.api(ctx, req)
	if err != nil {
		return nil, err
	}
	msgs := c.parseList(ctx, arr(r, "messages"), false)
	var out []Message
	for _, m := range msgs {
		if q.SenderID != 0 && m.SenderID != q.SenderID {
			continue
		}
		if !q.Since.IsZero() && m.Date.Before(q.Since) {
			continue
		}
		out = append(out, m)
	}
	return out, nil
}

// MarkRead opens the chat and views its latest message with force_read, like a human opening it.
func (c *TDClient) MarkRead(ctx context.Context, chatID int64) error {
	t, err := c.chatInfo(ctx, chatID)
	if err != nil {
		return err
	}
	if t.LastMsgID == 0 {
		return nil
	}
	if _, err := c.call(ctx, obj{"@type": "viewMessages", "chat_id": chatID, "message_ids": []int64{t.LastMsgID}, "force_read": true}); err != nil {
		return err
	}
	c.cmu.Lock()
	t.Unread, t.LastReadIn = 0, t.LastMsgID
	c.cmu.Unlock()
	return nil
}

// SetOnline toggles the account's online status (the C++ bot only appears online while active).
func (c *TDClient) SetOnline(ctx context.Context, online bool) {
	_, _ = c.api(ctx, obj{"@type": "setOption", "name": "online", "value": obj{"@type": "optionValueBoolean", "value": online}})
}

// Contacts returns the user's contact ids (cached 5 minutes); used by lockdown=contacts_only.
func (c *TDClient) Contacts(ctx context.Context) map[int64]bool {
	c.contactsMu.Lock()
	defer c.contactsMu.Unlock()
	if c.contacts != nil && time.Since(c.contactsAt) < 5*time.Minute {
		return c.contacts
	}
	r, err := c.api(ctx, obj{"@type": "getContacts"})
	if err != nil {
		return c.contacts
	}
	m := map[int64]bool{}
	for _, v := range arr(r, "user_ids") {
		m[num(v)] = true
	}
	c.contacts, c.contactsAt = m, time.Now()
	return m
}

// ---- Client: acting ----

var _ Client = (*TDClient)(nil)
