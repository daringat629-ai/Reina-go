package telegram

import (
	"context"
	"errors"
	"fmt"
	"os"
	"sort"
	"strconv"
	"strings"
)

func (c *TDClient) Join(ctx context.Context, link string) error {
	link = strings.TrimSpace(link)
	switch {
	case strings.HasPrefix(link, "@"):
		r, err := c.api(ctx, obj{"@type": "searchPublicChat", "username": strings.TrimPrefix(link, "@")})
		if err != nil {
			return err
		}
		_, err = c.call(ctx, obj{"@type": "joinChat", "chat_id": num(r["id"])})
		return err
	case strings.Contains(link, "t.me/") || strings.HasPrefix(link, "http"):
		_, err := c.api(ctx, obj{"@type": "joinChatByInviteLink", "invite_link": link})
		return err
	}
	id, err := strconv.ParseInt(link, 10, 64)
	if err != nil {
		return fmt.Errorf("don't know how to join %q: pass an invite link, @username or chat id", link)
	}
	_, err = c.api(ctx, obj{"@type": "joinChat", "chat_id": id})
	return err
}

func (c *TDClient) Leave(ctx context.Context, chatID int64) error {
	_, err := c.api(ctx, obj{"@type": "leaveChat", "chat_id": chatID})
	return err
}

func (c *TDClient) Ban(ctx context.Context, chatID, userID int64, removeAll bool) error {
	_, err := c.api(ctx, obj{"@type": "banChatMember", "chat_id": chatID,
		"member_id": obj{"@type": "messageSenderUser", "user_id": userID}, "banned_until_date": 0, "revoke_messages": removeAll})
	return err
}

func (c *TDClient) SetMemberTag(ctx context.Context, chatID, userID int64, tag string) error {
	_, err := c.api(ctx, obj{"@type": "setChatMemberTag", "chat_id": chatID, "user_id": userID, "tag": tag})
	return err
}

func memberRole(status obj) string {
	switch typ(status) {
	case "chatMemberStatusCreator":
		return "owner"
	case "chatMemberStatusAdministrator":
		return "admin"
	}
	return "member"
}

func userUsername(u obj) string {
	if un := sub(u, "usernames"); un != nil {
		if a := arr(un, "active_usernames"); len(a) > 0 {
			s, _ := a[0].(string)
			return s
		}
	}
	return str(u, "username")
}

func (c *TDClient) toMember(ctx context.Context, m obj) (Member, bool) {
	sender := sub(m, "member_id")
	if typ(sender) != "messageSenderUser" {
		return Member{}, false
	}
	id := num(sender["user_id"])
	mem := Member{ID: id, Role: memberRole(sub(m, "status"))}
	if u, err := c.call(ctx, obj{"@type": "getUser", "user_id": id}); err == nil {
		mem.Name, mem.Username = userDisplay(u), userUsername(u)
		mem.IsBot = typ(sub(u, "type")) == "userTypeBot"
	} else {
		mem.Name = c.userName(ctx, id)
	}
	return mem, true
}

func (c *TDClient) Members(ctx context.Context, chatID int64, limit int) ([]Member, error) {
	if limit <= 0 || limit > 200 {
		limit = 50
	}
	t, err := c.chatInfo(ctx, chatID)
	if err != nil {
		return nil, err
	}
	var raw []obj
	switch {
	case t.Kind == ChatPrivate:
		u, err := c.call(ctx, obj{"@type": "getUser", "user_id": chatID})
		if err != nil {
			return nil, err
		}
		return []Member{{ID: chatID, Name: userDisplay(u), Username: userUsername(u), Role: "member", IsBot: typ(sub(u, "type")) == "userTypeBot"}}, nil
	case t.basic:
		r, err := c.api(ctx, obj{"@type": "getBasicGroupFullInfo", "basic_group_id": t.groupID})
		if err != nil {
			return nil, err
		}
		for _, v := range arr(r, "members") {
			if m, ok := v.(map[string]any); ok {
				raw = append(raw, m)
			}
		}
	case t.superOrBasic && t.Kind == ChatGroup:
		// administrators first, then the most recent participants
		for _, f := range []string{"supergroupMembersFilterAdministrators", "supergroupMembersFilterRecent"} {
			r, err := c.api(ctx, obj{"@type": "getSupergroupMembers", "supergroup_id": t.groupID, "filter": obj{"@type": f}, "offset": 0, "limit": limit})
			if err != nil {
				if f == "supergroupMembersFilterAdministrators" {
					continue
				}
				return nil, err
			}
			for _, v := range arr(r, "members") {
				if m, ok := v.(map[string]any); ok {
					raw = append(raw, m)
				}
			}
		}
	default:
		return nil, errors.New("members of channels are not visible")
	}
	var out []Member
	seen := map[int64]bool{}
	for _, m := range raw {
		mem, ok := c.toMember(ctx, m)
		if !ok || seen[mem.ID] {
			continue
		}
		seen[mem.ID] = true
		out = append(out, mem)
	}
	sort.SliceStable(out, func(i, j int) bool { return roleRank(out[i].Role) < roleRank(out[j].Role) })
	if len(out) > limit {
		out = out[:limit]
	}
	return out, nil
}

func roleRank(r string) int {
	switch r {
	case "owner":
		return 0
	case "admin":
		return 1
	}
	return 2
}

func (c *TDClient) UserInfo(ctx context.Context, userID int64) (User, error) {
	u, err := c.call(ctx, obj{"@type": "getUser", "user_id": userID})
	if err != nil {
		return User{}, err
	}
	out := User{ID: userID, Name: userDisplay(u), Username: userUsername(u), IsBot: typ(sub(u, "type")) == "userTypeBot", IsContact: u["is_contact"] == true}
	if f, err := c.call(ctx, obj{"@type": "getUserFullInfo", "user_id": userID}); err == nil {
		out.Bio = str(sub(f, "bio"), "text")
		if out.Bio == "" {
			out.Bio = str(f, "bio")
		}
	}
	return out, nil
}

// Block removes the private chat's history and blocks the user (remove_and_ban_chat for private chats).
func (c *TDClient) Block(ctx context.Context, chatID int64) error {
	if _, err := c.api(ctx, obj{"@type": "setMessageSenderBlockList", "sender_id": obj{"@type": "messageSenderUser", "user_id": chatID},
		"block_list": obj{"@type": "blockListMain"}}); err != nil {
		return err
	}
	_, err := c.call(ctx, obj{"@type": "deleteChatHistory", "chat_id": chatID, "remove_from_chat_list": true, "revoke": true})
	return err
}

func (c *TDClient) Download(ctx context.Context, fileID string) ([]byte, error) {
	id, err := strconv.ParseInt(fileID, 10, 64)
	if err != nil {
		return nil, fmt.Errorf("bad file id %q", fileID)
	}
	r, err := c.api(ctx, obj{"@type": "downloadFile", "file_id": id, "priority": 1, "offset": 0, "limit": 0, "synchronous": true})
	if err != nil {
		return nil, err
	}
	path := str(sub(r, "local"), "path")
	if path == "" {
		return nil, errors.New("tdlib returned no local path")
	}
	return os.ReadFile(path)
}

func (c *TDClient) ChatPhoto(ctx context.Context, chatID int64) ([]byte, error) {
	t, err := c.chatInfo(ctx, chatID)
	if err != nil {
		return nil, err
	}
	if t.PhotoFileID == 0 {
		return nil, errors.New("chat has no photo")
	}
	return c.Download(ctx, strconv.FormatInt(t.PhotoFileID, 10))
}
