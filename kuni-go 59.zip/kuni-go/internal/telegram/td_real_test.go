//go:build tdlib && cgo && tdreal

package telegram

// An integration test against a real libtdjson, without a Telegram account:
//
//	CGO_LDFLAGS=-L<dir> LD_LIBRARY_PATH=<dir> go test -tags 'tdlib tdreal' -run TestRealTDLib ./internal/telegram
//
// tdlib parses a JSON request into its td_api object before it looks at the authorization state, so every request
// the client builds can be sent before logging in: a request with a wrong field type or a missing wrapper fails
// with a parse error, a well-formed one with "Unauthorized" / "parameters are needed". The requests are the ones
// TestRequestsMatchEveryTDLibSchema produces against the fake.

import (
	"context"
	"encoding/json"
	"strconv"
	"strings"
	"testing"
	"time"
)

func TestRealTDLib(t *testing.T) {
	tr, err := NewTDJSONTransport()
	if err != nil {
		t.Fatal(err)
	}
	// 1. the version option the client relies on to pick request shapes
	tr.Send([]byte(`{"@type":"getOption","name":"version","@extra":"v"}`))
	version := ""
	deadline := time.Now().Add(10 * time.Second)
	for version == "" && time.Now().Before(deadline) {
		raw := tr.Receive(200 * time.Millisecond)
		if raw == nil {
			continue
		}
		m, _ := decode(raw)
		switch {
		case typ(m) == "updateOption" && str(m, "name") == "version":
			version = str(sub(m, "value"), "value")
		case str(m, "@extra") == "v" && typ(m) == "optionValueString":
			version = str(m, "value")
		}
	}
	if parseTDVersion(version) < tdv(1, 8, 61) {
		t.Fatalf("real tdlib reported version %q", version)
	}
	t.Logf("libtdjson %s", version)

	// 2. every request the client builds, against the version the real library reports
	f := newFakeTD(nil)
	f.version = version
	c, ctx := loggedIn(t, f, TDConfig{})
	for _, kind := range []string{KindPhoto, KindDocument, KindVideo, KindAnimation, KindAudio} {
		_, _ = c.SendMedia(ctx, 5, kind, "f.bin", []byte("x"), "cap", 3)
	}
	_, _ = c.SendPhoto(ctx, 5, []byte("x"), "c", 0)
	_, _ = c.SendVoice(ctx, 5, []byte("x"), 0)
	_, _ = c.SendSticker(ctx, 5, "77", 0)
	_, _ = c.SendPoll(ctx, 5, "q?", []string{"a", "b"}, false, true, 0)
	_, _ = c.SendLocation(ctx, 5, 42.87, 74.59, 0)
	_, _ = c.SendText(WithThread(ctx, 9), 5, "hi [Joe](tg://user?id=9)", 2)
	_, _ = c.SendDice(ctx, 5, "🎲", 0)
	_ = c.React(ctx, 5, 7, "👍")
	_ = c.Edit(ctx, 5, 7, "x")
	_ = c.Pin(ctx, 5, 7, true)
	_ = c.VotePoll(ctx, 5, 7, []int{0})
	_ = c.Ban(ctx, -100, 5, true)
	_ = c.SetMemberTag(ctx, -100, 5, "tag")
	_ = c.SetProfilePhoto(ctx, []byte("x"))
	_ = c.Typing(ctx, 5)

	f.mu.Lock()
	reqs := append([]obj(nil), f.reqs...)
	f.mu.Unlock()
	skip := map[string]bool{"getOption": true, "setTdlibParameters": true, "setAuthenticationPhoneNumber": true,
		"checkAuthenticationCode": true, "checkAuthenticationPassword": true, "close": true}
	sent := map[string]string{}
	for i, r := range reqs {
		if skip[typ(r)] {
			continue
		}
		extra := "r" + strconv.Itoa(i)
		r["@extra"] = extra
		b, _ := json.Marshal(r)
		sent[extra] = string(b)
		tr.Send(b)
	}
	if len(sent) < 15 {
		t.Fatalf("only %d requests captured", len(sent))
	}
	deadline = time.Now().Add(20 * time.Second)
	for len(sent) > 0 && time.Now().Before(deadline) {
		raw := tr.Receive(200 * time.Millisecond)
		if raw == nil {
			continue
		}
		m, _ := decode(raw)
		req, ok := sent[str(m, "@extra")]
		if !ok {
			continue
		}
		delete(sent, str(m, "@extra"))
		msg := strings.ToLower(str(m, "message"))
		if typ(m) == "error" && (strings.Contains(msg, "parse") || strings.Contains(msg, "unknown class") || strings.Contains(msg, "expected")) {
			t.Errorf("tdlib %s cannot parse a request the client builds:\n  %s\n  -> %s", version, req, raw)
		}
	}
	if len(sent) > 0 {
		t.Errorf("%d requests got no answer", len(sent))
	}
}

// The real login sequence up to the phone prompt (no network needed): setTdlibParameters is accepted by this tdlib,
// the version is picked up from updateOption, and the shutdown waits for tdlib to close its database.
func TestRealTDLibLoginReachesPhone(t *testing.T) {
	tr, _ := NewTDJSONTransport()
	asked := make(chan string, 4)
	c := NewTD(tr, TDConfig{APIID: 1, APIHash: "0123456789abcdef0123456789abcdef", DBDir: t.TempDir(),
		AppVersion: "kuni-go-test", Prompt: func(what string) string { asked <- what; select {} }})
	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan struct{})
	go func() { c.Run(ctx); close(done) }()
	select {
	case what := <-asked:
		t.Logf("tdlib %s asked for %q", c.TDLibVersion(), what)
	case <-time.After(30 * time.Second):
		t.Fatal("never asked for the phone: setTdlibParameters rejected?")
	}
	cancel()
	start := time.Now()
	<-done
	// graceful close: the receive loop waits for authorizationStateClosed instead of a fixed timeout
	if took := time.Since(start); took > 8*time.Second {
		t.Fatalf("shutdown took %s: tdlib never confirmed it closed", took)
	} else {
		t.Logf("shutdown took %s", took.Round(time.Millisecond))
	}
}
