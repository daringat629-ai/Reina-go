package telegram

import (
	"context"
	"errors"
	"fmt"
	"strings"
)

// The fake's version of Rich: it records what was asked so tests can check it.

// FakeRich holds what the fake knows about the app beyond chatting.
type FakeRich struct {
	FolderList []Folder
	Answer     ButtonAnswer
	PressErr   error
	Pressed    []string // "chat/msg/data"
	Scheduled  []SendOptions
	Locations  [][2]float64
	Dice       []string
}

func (s *Store) UpdateChat(id int64, f func(*Chat)) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	c := s.chats[id]
	if c == nil {
		return false
	}
	f(c)
	return true
}

func (f *Fake) Folders(context.Context) ([]Folder, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	return append([]Folder(nil), f.Rich.FolderList...), nil
}

func (f *Fake) ChatsIn(ctx context.Context, l ChatList, limit int) ([]Chat, error) {
	all, _ := f.Chats(ctx, 0)
	var out []Chat
	for _, c := range all {
		in := false
		switch {
		case l.Archive:
			in = c.Archived
		case l.Folder != 0:
			for _, id := range c.Folders {
				in = in || id == l.Folder
			}
		default:
			in = !c.Archived
		}
		if in {
			out = append(out, c)
		}
	}
	if limit > 0 && len(out) > limit {
		out = out[:limit]
	}
	return out, nil
}

func (f *Fake) PressButton(_ context.Context, chatID, msgID int64, data string) (ButtonAnswer, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.Rich.Pressed = append(f.Rich.Pressed, fmt.Sprintf("%d/%d/%s", chatID, msgID, data))
	return f.Rich.Answer, f.Rich.PressErr
}

func (f *Fake) SetMuted(_ context.Context, chatID int64, muted bool) error {
	if !f.S.UpdateChat(chatID, func(c *Chat) { c.Muted = muted }) {
		return ErrNotFound
	}
	return nil
}

func (f *Fake) PinnedMessage(_ context.Context, chatID int64) (Message, error) {
	f.mu.Lock()
	ids := f.Pinned[chatID]
	f.mu.Unlock()
	if len(ids) == 0 {
		return Message{}, ErrNotFound
	}
	return f.Message(context.Background(), chatID, ids[len(ids)-1])
}

func (f *Fake) SendWith(ctx context.Context, chatID int64, text string, o SendOptions) (Message, error) {
	f.mu.Lock()
	f.Rich.Scheduled = append(f.Rich.Scheduled, o)
	f.mu.Unlock()
	m := Message{Text: text, ReplyTo: o.ReplyTo}
	if o.Markdown { // the fake understands *bold* well enough for tests
		m.Entities = fakeMarkdown(&m.Text)
	}
	return f.send(chatID, m), nil
}

// fakeMarkdown strips *x* and gives it a bold entity (UTF-16 offsets are not needed for ASCII tests).
func fakeMarkdown(text *string) []Entity {
	var ents []Entity
	var b strings.Builder
	parts := strings.Split(*text, "*")
	if len(parts)%2 == 0 {
		return nil
	}
	off := 0
	for i, p := range parts {
		if i%2 == 1 {
			ents = append(ents, Entity{Type: "bold", Offset: off, Length: len([]rune(p))})
		}
		b.WriteString(p)
		off += len([]rune(p))
	}
	*text = b.String()
	return ents
}

func (f *Fake) EditFormatted(ctx context.Context, chatID, msgID int64, text string, markdown bool) error {
	var ents []Entity
	if markdown {
		ents = fakeMarkdown(&text)
	}
	if !f.S.Update(chatID, msgID, func(m *Message) { m.Text, m.Edited, m.Entities = text, true, ents }) {
		return ErrNotFound
	}
	return nil
}

func (f *Fake) SendDice(_ context.Context, chatID int64, emoji string, replyTo int64) (Message, error) {
	if emoji == "" {
		emoji = "🎲"
	}
	f.mu.Lock()
	f.Rich.Dice = append(f.Rich.Dice, emoji)
	f.mu.Unlock()
	return f.send(chatID, Message{Dice: emoji + " 4", Text: emoji + " 4", ReplyTo: replyTo}), nil
}

func (f *Fake) SendLocation(_ context.Context, chatID int64, lat, lon float64, replyTo int64) (Message, error) {
	if lat < -90 || lat > 90 || lon < -180 || lon > 180 {
		return Message{}, errors.New("coordinates out of range")
	}
	f.mu.Lock()
	f.Rich.Locations = append(f.Rich.Locations, [2]float64{lat, lon})
	f.mu.Unlock()
	return f.send(chatID, Message{Place: &Place{Lat: lat, Lon: lon}, Text: "📍 геопозиция", ReplyTo: replyTo}), nil
}

var _ Rich = (*Fake)(nil)
var _ Rich = (*TDClient)(nil)
