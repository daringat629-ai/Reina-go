package telegram

import (
	"testing"
	"time"
)

func richClient(t *testing.T, chats ...obj) (*TDClient, *fakeTD, func()) {
	t.Helper()
	f := newFakeTD(func(req obj) obj {
		switch str(req, "@type") {
		case "getUser":
			return obj{"@type": "user", "id": req["user_id"], "first_name": "Alex"}
		case "getChat":
			for _, c := range chats {
				if num(c["id"]) == num(req["chat_id"]) {
					return c
				}
			}
		}
		return nil
	})
	c, _ := loggedIn(t, f, TDConfig{})
	return c, f, func() {}
}

func TestMessageKeepsFormattingButtonsQuotesPreviewsAndCounters(t *testing.T) {
	c, _, _ := richClient(t)
	m := obj{"@type": "message", "id": 9, "chat_id": 5, "date": 1700000000, "is_outgoing": false, "media_album_id": "777", "via_bot_user_id": 12, "author_signature": "Редакция",
		"sender_id": obj{"@type": "messageSenderUser", "user_id": 12},
		"reply_to":  obj{"@type": "messageReplyToMessage", "message_id": 4, "quote": obj{"text": "кусок"}},
		"content": obj{"@type": "messageText", "text": obj{"text": "жир и ссылка", "entities": []any{
			obj{"offset": 0, "length": 3, "type": obj{"@type": "textEntityTypeBold"}},
			obj{"offset": 6, "length": 6, "type": obj{"@type": "textEntityTypeTextUrl", "url": "https://x.io"}},
			obj{"offset": 0, "length": 1, "type": obj{"@type": "textEntityTypeUnknownFuture"}},
		}}, "link_preview": obj{"url": "https://x.io", "site_name": "X", "title": "Заголовок", "description": obj{"text": "описание"}}},
		"reply_markup": obj{"@type": "replyMarkupInlineKeyboard", "rows": []any{
			[]any{obj{"text": "Да", "type": obj{"@type": "inlineKeyboardButtonTypeCallback", "data": "eWVz"}}, obj{"text": "Сайт", "type": obj{"@type": "inlineKeyboardButtonTypeUrl", "url": "https://a.b"}}},
		}},
		"interaction_info": obj{"view_count": 100, "forward_count": 3, "reply_info": obj{"reply_count": 7},
			"reactions": obj{"reactions": []any{obj{"type": obj{"@type": "reactionTypeEmoji", "emoji": "👍"}, "total_count": 5, "is_chosen": true}}}},
	}
	out := c.parseMessage(t.Context(), m)
	if len(out.Entities) != 2 || out.Entities[0].Type != "bold" || out.Entities[1].URL != "https://x.io" || out.Entities[1].Offset != 6 {
		t.Fatalf("entities: %+v", out.Entities)
	}
	if len(out.Buttons) != 1 || len(out.Buttons[0]) != 2 || out.Buttons[0][0].Kind != "callback" || out.Buttons[0][0].Data != "eWVz" || out.Buttons[0][1].URL != "https://a.b" {
		t.Fatalf("buttons: %+v", out.Buttons)
	}
	if out.Quote != "кусок" || out.ReplyTo != 4 || out.AlbumID != 777 || out.ViaBot != "Alex" || out.Author != "Редакция" {
		t.Fatalf("meta: %+v", out)
	}
	if out.Preview == nil || out.Preview.Title != "Заголовок" || out.Preview.Description != "описание" {
		t.Fatalf("preview: %+v", out.Preview)
	}
	if out.Views != 100 || out.Forwards != 3 || out.Replies != 7 || len(out.Counts) != 1 || out.Counts[0].Count != 5 || !out.Counts[0].Mine {
		t.Fatalf("counters: %+v", out)
	}
}

func TestServiceMessagesGetRussianText(t *testing.T) {
	c, _, _ := richClient(t)
	base := func(content obj) Message {
		return c.parseMessage(t.Context(), obj{"@type": "message", "id": 1, "chat_id": 5, "date": 1, "sender_id": obj{"@type": "messageSenderUser", "user_id": 12}, "content": content})
	}
	if m := base(obj{"@type": "messagePinMessage", "message_id": 77}); m.Service != "Alex закрепил(а) сообщение" || m.PinnedMsg != 77 || m.Text != m.Service {
		t.Fatalf("pin: %+v", m)
	}
	if m := base(obj{"@type": "messageChatAddMembers", "member_user_ids": []any{12}}); m.Service != "Alex вступил(а) в чат" {
		t.Fatalf("join: %q", m.Service)
	}
	if m := base(obj{"@type": "messageChatChangeTitle", "title": "Новое"}); m.Service != "Название изменено: «Новое»" {
		t.Fatalf("title: %q", m.Service)
	}
	if m := base(obj{"@type": "messageCall", "duration": 75, "discard_reason": obj{"@type": "callDiscardReasonHungUp"}}); m.Service != "Звонок · 1:15" {
		t.Fatalf("call: %q", m.Service)
	}
	if m := base(obj{"@type": "messageCall", "discard_reason": obj{"@type": "callDiscardReasonMissed"}, "is_video": true}); m.Service != "Пропущенный видеозвонок" {
		t.Fatalf("missed: %q", m.Service)
	}
	if m := base(obj{"@type": "messageText", "text": obj{"text": "обычное"}}); m.Service != "" {
		t.Fatalf("plain text became service: %+v", m)
	}
}

func TestPlacesContactsDiceAudioAndStickers(t *testing.T) {
	c, _, _ := richClient(t)
	base := func(content obj) Message {
		return c.parseMessage(t.Context(), obj{"@type": "message", "id": 1, "chat_id": 5, "date": 1, "sender_id": obj{"@type": "messageSenderUser", "user_id": 12}, "content": content})
	}
	if m := base(obj{"@type": "messageLocation", "location": obj{"latitude": 42.87, "longitude": 74.59}}); m.Place == nil || m.Place.Lat != 42.87 || m.Place.Lon != 74.59 {
		t.Fatalf("location: %+v", m.Place)
	}
	if m := base(obj{"@type": "messageVenue", "venue": obj{"title": "Кафе", "address": "ул. 1", "location": obj{"latitude": 1.5, "longitude": 2.5}}}); m.Place == nil || m.Place.Title != "Кафе" {
		t.Fatalf("venue: %+v", m.Place)
	}
	if m := base(obj{"@type": "messageContact", "contact": obj{"first_name": "Бек", "phone_number": "+996"}}); m.Contact != "Бек +996" {
		t.Fatalf("contact: %q", m.Contact)
	}
	if m := base(obj{"@type": "messageDice", "emoji": "🎲", "value": 6}); m.Dice != "🎲 6" {
		t.Fatalf("dice: %q", m.Dice)
	}
	m := base(obj{"@type": "messageAudio", "audio": obj{"duration": 200, "mime_type": "audio/mpeg", "performer": "Группа", "title": "Песня", "audio": obj{"id": 31, "size": 1000}}})
	if m.Media != MediaAudio || m.Duration != 200 || m.Title != "Группа - Песня" || m.FileID != "31" {
		t.Fatalf("audio: %+v", m)
	}
	if m := base(obj{"@type": "messageSticker", "sticker": obj{"emoji": "😀", "format": obj{"@type": "stickerFormatTgs"}, "sticker": obj{"id": 5, "size": 10}}}); !m.Animated || m.MimeType != "application/x-tgsticker" {
		t.Fatalf("tgs: %+v", m)
	}
	if m := base(obj{"@type": "messageSticker", "sticker": obj{"emoji": "😀", "format": obj{"@type": "stickerFormatWebm"}, "sticker": obj{"id": 5, "size": 10}}}); m.Animated || m.MimeType != "video/webm" {
		t.Fatalf("webm: %+v", m)
	}
	if m := base(obj{"@type": "messageSticker", "sticker": obj{"emoji": "😀", "format": obj{"@type": "stickerFormatWebp"}, "sticker": obj{"id": 5, "size": 10}}}); m.MimeType != "image/webp" {
		t.Fatalf("webp: %+v", m)
	}
	if m := base(obj{"@type": "messageVoiceNote", "voice_note": obj{"duration": 9, "mime_type": "audio/ogg", "voice": obj{"id": 2}}}); m.Duration != 9 || m.Media != MediaVoice {
		t.Fatalf("voice: %+v", m)
	}
}

func TestChatListShowsPinsMuteFoldersMentionsTypingAndPresence(t *testing.T) {
	chat := obj{"@type": "chat", "id": 5, "title": "Алекс", "type": obj{"@type": "chatTypePrivate", "user_id": 12}, "unread_count": 2, "unread_mention_count": 1,
		"chat_lists":            []any{obj{"@type": "chatListMain"}, obj{"@type": "chatListFolder", "chat_folder_id": 3}},
		"positions":             []any{obj{"list": obj{"@type": "chatListMain"}, "is_pinned": true}},
		"notification_settings": obj{"mute_for": 3600, "use_default_mute_for": false}}
	c, f, _ := richClient(t, chat)
	c.userName(t.Context(), 12)
	f.Push(obj{"@type": "updateNewChat", "chat": chat})
	f.Push(obj{"@type": "updateChatFolders", "chat_folders": []any{obj{"id": 3, "name": obj{"text": obj{"text": "Работа"}}}, obj{"id": 4, "name": "Семья"}}})
	f.Push(obj{"@type": "updateUserStatus", "user_id": 12, "status": obj{"@type": "userStatusOnline"}})
	f.Push(obj{"@type": "updateChatAction", "chat_id": 5, "sender_id": obj{"@type": "messageSenderUser", "user_id": 12}, "action": obj{"@type": "chatActionTyping"}})
	deadline := time.Now().Add(2 * time.Second)
	var ch Chat
	for time.Now().Before(deadline) {
		ch, _ = c.Chat(t.Context(), 5)
		if ch.Typing != "" && ch.Presence != "" {
			break
		}
		time.Sleep(20 * time.Millisecond)
	}
	if !ch.Pinned || !ch.Muted || ch.UnreadMentions != 1 || len(ch.Folders) != 1 || ch.Folders[0] != 3 || ch.Typing != "typing" || ch.TypingBy != "Alex" || ch.Presence != "online" {
		t.Fatalf("chat: %+v", ch)
	}
	fs, _ := c.Folders(t.Context())
	if len(fs) != 2 || fs[0].Name != "Работа" || fs[1].Name != "Семья" {
		t.Fatalf("folders: %+v", fs)
	}
	// updates after the first look
	f.Push(obj{"@type": "updateChatNotificationSettings", "chat_id": 5, "notification_settings": obj{"mute_for": 0}})
	f.Push(obj{"@type": "updateChatPosition", "chat_id": 5, "position": obj{"list": obj{"@type": "chatListMain"}, "is_pinned": false}})
	f.Push(obj{"@type": "updateChatRemovedFromList", "chat_id": 5, "chat_list": obj{"@type": "chatListFolder", "chat_folder_id": 3}})
	f.Push(obj{"@type": "updateChatAddedToList", "chat_id": 5, "chat_list": obj{"@type": "chatListArchive"}})
	f.Push(obj{"@type": "updateChatAction", "chat_id": 5, "sender_id": obj{"@type": "messageSenderUser", "user_id": 12}, "action": obj{"@type": "chatActionCancel"}})
	deadline = time.Now().Add(2 * time.Second)
	for time.Now().Before(deadline) {
		ch, _ = c.Chat(t.Context(), 5)
		if ch.Archived {
			break
		}
		time.Sleep(20 * time.Millisecond)
	}
	time.Sleep(50 * time.Millisecond)
	ch, _ = c.Chat(t.Context(), 5)
	if ch.Pinned || ch.Muted || len(ch.Folders) != 0 || !ch.Archived || ch.Typing != "" {
		t.Fatalf("after updates: %+v", ch)
	}
}

// Numbers arrive from the real JSON decoder as json.Number; helpers fed with Go numbers in tests would hide a mismatch.
func TestLocationSurvivesTheJSONPath(t *testing.T) {
	c, f, _ := richClient(t)
	f.Push(obj{"@type": "updateNewMessage", "message": obj{"@type": "message", "id": 3, "chat_id": 5, "date": 1, "sender_id": obj{"@type": "messageSenderUser", "user_id": 12},
		"content": obj{"@type": "messageLocation", "location": obj{"latitude": 42.8746, "longitude": 74.5698}}}})
	select {
	case m := <-c.Updates():
		if m.Place == nil || m.Place.Lat != 42.8746 || m.Place.Lon != 74.5698 {
			t.Fatalf("place: %+v", m.Place)
		}
	case <-time.After(3 * time.Second):
		t.Fatal("no update")
	}
}
