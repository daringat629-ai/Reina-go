//go:build tdlib && cgo

package telegram

/*
#cgo LDFLAGS: -ltdjson
#include <stdlib.h>

// tdlib JSON interface (td/telegram/td_json_client.h)
int td_create_client_id(void);
void td_send(int client_id, const char *request);
const char *td_receive(double timeout);
const char *td_execute(const char *request);
*/
import "C"

import (
	"time"
	"unsafe"
)

type jsonTransport struct{ id C.int }

// NewTDJSONTransport creates a libtdjson client. Build with `-tags tdlib` and libtdjson installed.
func NewTDJSONTransport() (Transport, error) {
	q := C.CString(`{"@type":"setLogVerbosityLevel","new_verbosity_level":1}`)
	C.td_execute(q)
	C.free(unsafe.Pointer(q))
	return &jsonTransport{id: C.td_create_client_id()}, nil
}

func (t *jsonTransport) Send(req []byte) {
	s := C.CString(string(req))
	defer C.free(unsafe.Pointer(s))
	C.td_send(t.id, s)
}

// Receive returns the next event of this client. td_receive is process-wide: it hands out the events of every
// client created in the process (each tagged "@client_id"), so events of another client are skipped here.
func (t *jsonTransport) Receive(timeout time.Duration) []byte {
	deadline := time.Now().Add(timeout)
	for {
		left := time.Until(deadline)
		if left < 0 {
			left = 0
		}
		p := C.td_receive(C.double(left.Seconds()))
		if p == nil {
			return nil
		}
		b := []byte(C.GoString(p)) // copy: tdlib reuses the buffer on the next call
		if id, ok := clientIDOf(b); !ok || id == int64(t.id) {
			return b
		}
		if time.Now().After(deadline) {
			return nil
		}
	}
}
