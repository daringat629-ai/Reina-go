package telegram

import (
	"context"
	"strconv"
	"sync"
)

// eventState remembers what incoming messages said (to show "was -> now" on edits) and which reactions a
// message already had (to report only the new ones). Both are bounded.
type eventState struct {
	mu     sync.Mutex
	texts  map[string]seenText
	reacts map[string]map[string]int
}

type seenText struct {
	text   string
	sender int64
	name   string
}

const eventCacheMax = 2000

func evKey(chat, msg int64) string {
	return strconv.FormatInt(chat, 10) + ":" + strconv.FormatInt(msg, 10)
}

// Events delivers edits of other people's messages and new reactions on her own messages.
func (c *TDClient) Events() <-chan Event { return c.events }

func (c *TDClient) emit(e Event) {
	select {
	case c.events <- e:
	default: // nobody is listening fast enough: events are hints, dropping is fine
	}
}

// remember keeps the text of an incoming message so a later edit can be shown as a change.
func (c *TDClient) remember(m Message) {
	if m.Outgoing || m.Text == "" {
		return
	}
	c.ev.mu.Lock()
	defer c.ev.mu.Unlock()
	if c.ev.texts == nil || len(c.ev.texts) >= eventCacheMax {
		c.ev.texts = map[string]seenText{}
	}
	c.ev.texts[evKey(m.ChatID, m.ID)] = seenText{m.Text, m.SenderID, m.SenderName}
}

func contentText(content obj) string {
	if typ(content) == "messageText" {
		return str(sub(content, "text"), "text")
	}
	return str(sub(content, "caption"), "text")
}

func (c *TDClient) onContent(ctx context.Context, m obj) {
	chat, id := num(m["chat_id"]), num(m["message_id"])
	now := contentText(sub(m, "new_content"))
	key := evKey(chat, id)
	c.ev.mu.Lock()
	old, ok := c.ev.texts[key]
	if ok && old.text != now {
		c.ev.texts[key] = seenText{now, old.sender, old.name}
	}
	c.ev.mu.Unlock()
	if !ok || old.text == now {
		return // unknown (her own or never seen) or not a text change (e.g. a live-updating poll)
	}
	c.emit(Event{Kind: EventEdit, ChatID: chat, MsgID: id, ActorID: old.sender, Actor: old.name, Old: old.text, New: now})
}

func reactionEmoji(t obj) string {
	if typ(t) == "reactionTypeEmoji" {
		return str(t, "emoji")
	}
	return "⭐" // custom emoji and paid stars have no plain emoji form
}

func (c *TDClient) onInteraction(ctx context.Context, m obj) {
	chat, id := num(m["chat_id"]), num(m["message_id"])
	now := map[string]int{}
	var recent []obj
	for _, r := range arr(sub(sub(m, "interaction_info"), "reactions"), "reactions") {
		ro := toObj(r)
		now[reactionEmoji(sub(ro, "type"))] += int(num(ro["total_count"]))
		for _, s := range arr(ro, "recent_sender_ids") {
			recent = append(recent, toObj(s))
		}
	}
	key := evKey(chat, id)
	c.ev.mu.Lock()
	if c.ev.reacts == nil || len(c.ev.reacts) >= eventCacheMax {
		c.ev.reacts = map[string]map[string]int{}
	}
	before := c.ev.reacts[key]
	c.ev.reacts[key] = now
	c.ev.mu.Unlock()
	var added []string
	for e, n := range now {
		if n > before[e] {
			added = append(added, e)
		}
	}
	if len(added) == 0 {
		return
	}
	msg, err := c.api(ctx, obj{"@type": "getMessage", "chat_id": chat, "message_id": id})
	if err != nil || msg["is_outgoing"] != true {
		return // only reactions to her own messages matter
	}
	var actorID int64
	var actor string
	for _, s := range recent {
		if typ(s) == "messageSenderUser" {
			if uid := num(s["user_id"]); uid != c.MyID() {
				actorID, actor = uid, c.userName(ctx, uid)
				break
			}
		}
	}
	for _, e := range added {
		c.emit(Event{Kind: EventReaction, ChatID: chat, MsgID: id, ActorID: actorID, Actor: actor, Emoji: e})
	}
}

var _ EventSource = (*TDClient)(nil)
