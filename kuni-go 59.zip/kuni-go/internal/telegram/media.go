package telegram

import "context"

// MediaKinds are the ways a file can be sent so that Telegram shows it as what it is.
const (
	KindVideo     = "video"     // plays in the chat
	KindAnimation = "animation" // a looping gif without sound
	KindAudio     = "audio"     // music with a player
	KindPhoto     = "photo"
	KindDocument  = "document"
)

// MediaSender is what only the user-account client can do: send a file as a video, gif or track, not as a plain file.
// Callers type-assert for it and fall back to SendDocument.
type MediaSender interface {
	SendMedia(ctx context.Context, chatID int64, kind, name string, data []byte, caption string, replyTo int64) (Message, error)
}

// Profile is the account's own card.
type Profile struct {
	FirstName, LastName, Username, Bio string
}

// ProfileEditor changes who she is in Telegram: name, bio, avatar. User-account client only.
type ProfileEditor interface {
	MyProfile(ctx context.Context) (Profile, error)
	SetName(ctx context.Context, first, last string) error
	SetBio(ctx context.Context, bio string) error
	SetProfilePhoto(ctx context.Context, data []byte) error
}
