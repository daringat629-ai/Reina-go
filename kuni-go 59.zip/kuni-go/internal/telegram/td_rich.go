package telegram

import (
	"context"
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
	"time"
)

// What the Telegram app shows beyond a plain text: formatting, buttons, service lines, link cards, places...
// All of it is read defensively: tdlib renames fields between versions, and a missing one must never break a message.

var entityTypes = map[string]string{
	"textEntityTypeBold": "bold", "textEntityTypeItalic": "italic", "textEntityTypeUnderline": "underline",
	"textEntityTypeStrikethrough": "strike", "textEntityTypeCode": "code", "textEntityTypePre": "pre", "textEntityTypePreCode": "pre",
	"textEntityTypeSpoiler": "spoiler", "textEntityTypeBlockQuote": "quote", "textEntityTypeExpandableBlockQuote": "quote",
	"textEntityTypeTextUrl": "link", "textEntityTypeUrl": "url", "textEntityTypeMention": "mention", "textEntityTypeMentionName": "mentionname",
	"textEntityTypeHashtag": "hashtag", "textEntityTypeCashtag": "cashtag", "textEntityTypeBotCommand": "command",
	"textEntityTypeEmailAddress": "email", "textEntityTypePhoneNumber": "phone", "textEntityTypeCustomEmoji": "emoji",
}

// parseEntities converts the entities of a tdlib formattedText.
func parseEntities(ft obj) []Entity {
	var out []Entity
	for _, v := range arr(ft, "entities") {
		e := toObj(v)
		t := sub(e, "type")
		kind, ok := entityTypes[typ(t)]
		if !ok {
			continue
		}
		en := Entity{Type: kind, Offset: int(num(e["offset"])), Length: int(num(e["length"]))}
		switch kind {
		case "link":
			en.URL = str(t, "url")
		case "mentionname":
			en.UserID = num(t["user_id"])
		}
		if en.Length > 0 {
			out = append(out, en)
		}
	}
	return out
}

// parseMarkup reads an inline keyboard.
func parseMarkup(rm obj) [][]Button {
	if typ(rm) != "replyMarkupInlineKeyboard" {
		return nil
	}
	var rows [][]Button
	for _, r := range arr(rm, "rows") {
		var row []Button
		for _, b := range arr(map[string]any{"x": r}, "x") {
			bo := toObj(b)
			bt := sub(bo, "type")
			btn := Button{Text: str(bo, "text"), Kind: "other"}
			switch typ(bt) {
			case "inlineKeyboardButtonTypeCallback":
				btn.Kind, btn.Data = "callback", str(bt, "data")
			case "inlineKeyboardButtonTypeUrl", "inlineKeyboardButtonTypeLoginUrl":
				btn.Kind, btn.URL = "url", str(bt, "url")
			case "inlineKeyboardButtonTypeWebApp":
				btn.Kind, btn.URL = "webapp", str(bt, "url")
			case "inlineKeyboardButtonTypeCopyText":
				btn.Kind, btn.URL = "copy", str(bt, "text")
			}
			row = append(row, btn)
		}
		if len(row) > 0 {
			rows = append(rows, row)
		}
	}
	return rows
}

// linkPreview reads the card of a link (tdlib calls it link_preview in new versions and web_page in old ones).
func linkPreview(content obj) *LinkPreview {
	lp := sub(content, "link_preview")
	if lp == nil {
		lp = sub(content, "web_page")
	}
	if lp == nil {
		return nil
	}
	p := &LinkPreview{URL: str(lp, "url"), Site: str(lp, "site_name"), Title: str(lp, "title"), Description: ftext(lp["description"])}
	if p.Title == "" && p.Description == "" && p.Site == "" {
		return nil
	}
	return p
}

func dur(sec int64) string {
	if sec < 0 {
		sec = 0
	}
	if sec >= 3600 {
		return fmt.Sprintf("%d:%02d:%02d", sec/3600, sec/60%60, sec%60)
	}
	return fmt.Sprintf("%d:%02d", sec/60, sec%60)
}

// serviceText describes a service message the way the app shows it; ok is false for ordinary content.
func (c *TDClient) serviceText(ctx context.Context, content obj, who string) (text string, pinned int64, ok bool) {
	if who == "" {
		who = "Кто-то"
	}
	names := func(ids []any) string {
		var n []string
		for _, id := range ids {
			n = append(n, c.userName(ctx, num(id)))
		}
		return strings.Join(n, ", ")
	}
	switch t := typ(content); t {
	case "messageChatAddMembers":
		ids := arr(content, "member_user_ids")
		if len(ids) == 1 && c.userName(ctx, num(ids[0])) == who {
			return who + " вступил(а) в чат", 0, true
		}
		return who + " добавил(а): " + names(ids), 0, true
	case "messageChatJoinByLink", "messageChatJoinByRequest":
		return who + " вступил(а) по ссылке", 0, true
	case "messageChatDeleteMember":
		n := c.userName(ctx, num(content["user_id"]))
		if n == who {
			return who + " покинул(а) чат", 0, true
		}
		return who + " удалил(а): " + n, 0, true
	case "messageChatChangeTitle":
		return "Название изменено: «" + str(content, "title") + "»", 0, true
	case "messageChatChangePhoto":
		return who + " сменил(а) фото чата", 0, true
	case "messageChatDeletePhoto":
		return who + " удалил(а) фото чата", 0, true
	case "messagePinMessage":
		return who + " закрепил(а) сообщение", num(content["message_id"]), true
	case "messageBasicGroupChatCreate", "messageSupergroupChatCreate":
		return "Создан чат «" + str(content, "title") + "»", 0, true
	case "messageScreenshotTaken":
		return who + " сделал(а) скриншот", 0, true
	case "messageContactRegistered":
		return who + " теперь в Telegram", 0, true
	case "messageCall":
		kind := "Звонок"
		if content["is_video"] == true {
			kind = "Видеозвонок"
		}
		switch typ(sub(content, "discard_reason")) {
		case "callDiscardReasonMissed":
			kind = "Пропущенный " + strings.ToLower(kind)
		case "callDiscardReasonDeclined":
			kind = "Отклонённый " + strings.ToLower(kind)
		default:
			if d := num(content["duration"]); d > 0 {
				kind += " · " + dur(d)
			}
		}
		return kind, 0, true
	case "messageVideoChatStarted", "messageGroupCall":
		return "Начат видеочат", 0, true
	case "messageVideoChatEnded":
		return "Видеочат завершён · " + dur(num(content["duration"])), 0, true
	case "messageVideoChatScheduled":
		return "Запланирован видеочат", 0, true
	case "messageForumTopicCreated":
		return "Создана тема «" + str(content, "name") + "»", 0, true
	case "messageForumTopicEdited":
		return "Тема изменена", 0, true
	case "messageCustomServiceAction":
		return str(content, "text"), 0, true
	case "messageExpiredPhoto":
		return "Фото удалено (самоуничтожение)", 0, true
	case "messageExpiredVideo", "messageExpiredVideoNote", "messageExpiredVoiceNote":
		return "Медиа удалено (самоуничтожение)", 0, true
	case "messageUnsupported":
		return "Сообщение не поддерживается этой версией клиента", 0, true
	default:
		if strings.HasPrefix(t, "messageGift") || strings.HasPrefix(t, "messageUpgradedGift") || strings.HasPrefix(t, "messageRefundedUpgradedGift") {
			return "🎁 подарок", 0, true
		}
	}
	return "", 0, false
}

// enrich fills what the app shows of a message beyond the text: formatting, buttons, quotes, link cards, places, counters...
func (c *TDClient) enrich(ctx context.Context, m, content obj, out *Message) {
	ft := sub(content, "text")
	if ft == nil {
		ft = sub(content, "caption")
	}
	out.Entities = parseEntities(ft)
	out.Buttons = parseMarkup(sub(m, "reply_markup"))
	if rt := sub(m, "reply_to"); typ(rt) == "messageReplyToMessage" {
		out.Quote = ftext(sub(rt, "quote")["text"])
	}
	out.AlbumID = num(m["media_album_id"])
	if id := num(m["via_bot_user_id"]); id != 0 {
		out.ViaBot = c.userName(ctx, id)
	}
	out.Author = str(m, "author_signature")
	if ii := sub(m, "interaction_info"); ii != nil {
		out.Views, out.Forwards = int(num(ii["view_count"])), int(num(ii["forward_count"]))
		out.Replies = int(num(sub(ii, "reply_info")["reply_count"]))
		for _, r := range arr(sub(ii, "reactions"), "reactions") {
			ro := toObj(r)
			if t := sub(ro, "type"); typ(t) == "reactionTypeEmoji" {
				out.Counts = append(out.Counts, ReactionCount{Emoji: str(t, "emoji"), Count: int(num(ro["total_count"])), Mine: ro["is_chosen"] == true})
			} else if t != nil {
				out.Counts = append(out.Counts, ReactionCount{Emoji: "⭐", Count: int(num(ro["total_count"])), Mine: ro["is_chosen"] == true})
			}
		}
	}

	if text, pinned, ok := c.serviceText(ctx, content, out.SenderName); ok {
		out.Service, out.Text, out.PinnedMsg = text, text, pinned
		return
	}
	switch typ(content) {
	case "messageText":
		out.Preview = linkPreview(content)
	case "messageLocation":
		l := sub(content, "location")
		out.Place = &Place{Lat: fnum(l["latitude"]), Lon: fnum(l["longitude"]), Live: num(content["live_period"]) > 0}
		out.Text = "📍 геопозиция"
	case "messageVenue":
		v := sub(content, "venue")
		l := sub(v, "location")
		out.Place = &Place{Lat: fnum(l["latitude"]), Lon: fnum(l["longitude"]), Title: str(v, "title"), Address: str(v, "address")}
		out.Text = "📍 " + str(v, "title")
	case "messageContact":
		ct := sub(content, "contact")
		out.Contact = strings.TrimSpace(str(ct, "first_name")+" "+str(ct, "last_name")) + " " + str(ct, "phone_number")
		out.Text = "👤 контакт: " + out.Contact
	case "messageDice":
		out.Dice = str(content, "emoji") + " " + strconv.FormatInt(num(content["value"]), 10)
		out.Text = out.Dice
	case "messageAudio":
		a := sub(content, "audio")
		out.Media, out.Text = MediaAudio, str(sub(content, "caption"), "text")
		out.FileID, out.FileSize = fileRef(sub(a, "audio"))
		out.Duration, out.MimeType = int(num(a["duration"])), str(a, "mime_type")
		out.Title = strings.Trim(str(a, "performer")+" - "+str(a, "title"), " -")
		out.FileName = str(a, "file_name")
	case "messageVoiceNote":
		v := sub(content, "voice_note")
		out.Duration, out.MimeType = int(num(v["duration"])), str(v, "mime_type")
	case "messageVideo":
		v := sub(content, "video")
		out.Duration, out.MimeType, out.FileName = int(num(v["duration"])), str(v, "mime_type"), str(v, "file_name")
	case "messageVideoNote":
		out.Duration = int(num(sub(content, "video_note")["duration"]))
		out.MimeType = "video/mp4"
	case "messageAnimation":
		a := sub(content, "animation")
		out.Duration, out.MimeType = int(num(a["duration"])), str(a, "mime_type")
	case "messageDocument":
		out.MimeType = str(sub(content, "document"), "mime_type")
	case "messageSticker":
		st := sub(content, "sticker")
		switch typ(sub(st, "format")) {
		case "stickerFormatTgs":
			out.Animated, out.MimeType = true, "application/x-tgsticker"
		case "stickerFormatWebm":
			out.MimeType = "video/webm"
		default:
			out.MimeType = "image/webp"
			if st["is_animated"] == true {
				out.Animated, out.MimeType = true, "application/x-tgsticker"
			}
		}
	case "messageChecklist":
		list := sub(content, "list")
		var b strings.Builder
		b.WriteString("☑ " + ftext(list["title"]))
		for _, t := range arr(list, "tasks") {
			to := toObj(t)
			mark := "☐ "
			if num(to["completion_date"]) > 0 || to["is_completed"] == true {
				mark = "☑ "
			}
			b.WriteString("\n" + mark + ftext(to["text"]))
		}
		out.Text = b.String()
	}
}

func fnum(v any) float64 {
	switch t := v.(type) {
	case json.Number: // the decoder keeps numbers exact, so coordinates arrive as json.Number
		f, _ := t.Float64()
		return f
	case int:
		return float64(t)
	case int64:
		return float64(t)
	case float64:
		return t
	case string:
		f, _ := strconv.ParseFloat(t, 64)
		return f
	}
	return 0
}

// ---- the chat list: pins, mute, folders, typing, presence ----

type userSt struct {
	Kind string
	At   time.Time // last seen
}

func statusOf(s obj) userSt {
	switch typ(s) {
	case "userStatusOnline":
		return userSt{Kind: "online"}
	case "userStatusOffline":
		return userSt{Kind: "offline", At: time.Unix(num(s["was_online"]), 0)}
	case "userStatusRecently":
		return userSt{Kind: "recently"}
	case "userStatusLastWeek":
		return userSt{Kind: "week"}
	case "userStatusLastMonth":
		return userSt{Kind: "month"}
	case "userStatusEmpty":
		return userSt{Kind: "hidden"}
	}
	return userSt{}
}

type action struct {
	Kind  string
	By    int64
	Until time.Time
}

func actionKind(a obj) string {
	switch typ(a) {
	case "chatActionTyping":
		return "typing"
	case "chatActionRecordingVoiceNote", "chatActionRecordingVideoNote":
		return "voice"
	case "chatActionUploadingPhoto":
		return "photo"
	case "chatActionUploadingVideo", "chatActionUploadingVideoNote", "chatActionRecordingVideo":
		return "video"
	case "chatActionUploadingDocument", "chatActionUploadingVoiceNote":
		return "file"
	case "chatActionChoosingSticker":
		return "sticker"
	}
	return ""
}

// applyFlags reads pin, mute, folders and mentions from a tdlib chat object.
func applyFlags(t *tdChat, ch obj) {
	t.Folders, t.Archived = nil, false
	for _, l := range arr(ch, "chat_lists") {
		lo := toObj(l)
		switch typ(lo) {
		case "chatListArchive":
			t.Archived = true
		case "chatListFolder":
			t.Folders = append(t.Folders, int(num(lo["chat_folder_id"])))
		}
	}
	t.Pinned = false
	for _, p := range arr(ch, "positions") {
		po := toObj(p)
		if typ(sub(po, "list")) == "chatListMain" && po["is_pinned"] == true {
			t.Pinned = true
		}
	}
	if ns := sub(ch, "notification_settings"); ns != nil {
		t.Muted = num(ns["mute_for"]) > 0 && ns["use_default_mute_for"] != true
	}
	t.Mentions = int(num(ch["unread_mention_count"]))
	if ty := sub(ch, "type"); typ(ty) == "chatTypePrivate" || typ(ty) == "chatTypeSecret" {
		t.UserID = num(ty["user_id"])
	}
}

// chatFlagsUpdate handles the small updates of the chat list.
func (c *TDClient) chatFlagsUpdate(m obj) {
	id := num(m["chat_id"])
	c.cmu.Lock()
	defer c.cmu.Unlock()
	t := c.chats[id]
	switch typ(m) {
	case "updateChatNotificationSettings":
		if t != nil {
			ns := sub(m, "notification_settings")
			t.Muted = num(ns["mute_for"]) > 0 && ns["use_default_mute_for"] != true
		}
	case "updateChatUnreadMentionCount":
		if t != nil {
			t.Mentions = int(num(m["unread_mention_count"]))
		}
	case "updateChatPosition":
		if t != nil {
			po := sub(m, "position")
			if typ(sub(po, "list")) == "chatListMain" {
				t.Pinned = po["is_pinned"] == true
			}
		}
	case "updateChatAddedToList", "updateChatRemovedFromList":
		if t != nil {
			l := sub(m, "chat_list")
			add := typ(m) == "updateChatAddedToList"
			switch typ(l) {
			case "chatListArchive":
				t.Archived = add
			case "chatListFolder":
				fid := int(num(l["chat_folder_id"]))
				var keep []int
				for _, f := range t.Folders {
					if f != fid {
						keep = append(keep, f)
					}
				}
				if add {
					keep = append(keep, fid)
				}
				t.Folders = keep
			}
		}
	case "updateChatAction":
		if c.actions == nil {
			c.actions = map[int64]action{}
		}
		kind := actionKind(sub(m, "action"))
		if kind == "" {
			delete(c.actions, id)
			return
		}
		var by int64
		if s := sub(m, "sender_id"); typ(s) == "messageSenderUser" {
			by = num(s["user_id"])
		}
		c.actions[id] = action{Kind: kind, By: by, Until: time.Now().Add(7 * time.Second)}
	case "updateUserStatus":
		if c.statuses == nil {
			c.statuses = map[int64]userSt{}
		}
		c.statuses[num(m["user_id"])] = statusOf(sub(m, "status"))
	case "updateChatFolders":
		var fs []Folder
		for _, f := range arr(m, "chat_folders") {
			fo := toObj(f)
			name := ftext(fo["name"])
			if name == "" {
				name = ftext(sub(fo, "name")["text"])
			}
			fs = append(fs, Folder{ID: int(num(fo["id"])), Name: name})
		}
		c.folders = fs
	}
}

// decorate adds the live state of the chat list to a chat.
func (c *TDClient) decorate(ch *Chat, t *tdChat) {
	ch.Pinned, ch.Muted, ch.Archived, ch.UnreadMentions = t.Pinned, t.Muted, t.Archived, t.Mentions
	ch.Folders = append([]int(nil), t.Folders...)
	if a, ok := c.actions[t.ID]; ok && time.Now().Before(a.Until) {
		ch.Typing, ch.TypingBy = a.Kind, c.users[a.By]
	}
	if t.Kind == ChatPrivate && t.UserID != 0 {
		if st, ok := c.statuses[t.UserID]; ok {
			ch.Presence, ch.LastSeen = st.Kind, st.At
		}
	}
}

// Folders lists the chat folders of the account (the tabs of the chat list).
func (c *TDClient) Folders(ctx context.Context) ([]Folder, error) {
	c.cmu.Lock()
	defer c.cmu.Unlock()
	return append([]Folder(nil), c.folders...), nil
}
