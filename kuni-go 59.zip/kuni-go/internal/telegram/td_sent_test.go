package telegram

import (
	"context"
	"strings"
	"testing"
	"time"
)

func pendingMsg(id, chat int64, text string) obj {
	m := textMsg(id, chat, 4242, text)
	m["is_outgoing"] = true
	m["sending_state"] = obj{"@type": "messageSendingStatePending"}
	return m
}

// A send returns the message as the server accepted it (its permanent id), whether the outcome comes before or
// after the answer to sendMessage.
func TestSendWaitsForTheRealMessage(t *testing.T) {
	var f *fakeTD
	n := int64(0)
	f = newFakeTD(func(req obj) obj {
		if str(req, "@type") != "sendMessage" {
			return nil
		}
		n++
		temp, real := int64(1000+n), int64(5000+n)
		ok := obj{"@type": "updateMessageSendSucceeded", "old_message_id": temp, "message": textMsg(real, num(req["chat_id"]), 4242, "hi")}
		if n == 1 {
			f.Push(ok) // the outcome comes first: kept until the sender asks
		} else {
			go func() { time.Sleep(50 * time.Millisecond); f.Push(ok) }()
		}
		return pendingMsg(temp, num(req["chat_id"]), "hi")
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	for i, want := range []int64{5001, 5002} {
		m, err := c.SendText(ctx, 5, "hi", 0)
		if err != nil || m.ID != want {
			t.Fatalf("send %d: id=%d err=%v, want %d", i, m.ID, err, want)
		}
	}
}

// A message the server refuses is an error, not a message that seems sent.
func TestSendFailureSurfaces(t *testing.T) {
	var f *fakeTD
	f = newFakeTD(func(req obj) obj {
		switch str(req, "@type") {
		case "sendMessage":
			go func() {
				time.Sleep(20 * time.Millisecond)
				f.Push(obj{"@type": "updateMessageSendFailed", "old_message_id": 77, "message": textMsg(77, 5, 4242, "x"),
					"error": obj{"@type": "error", "code": 403, "message": "CHAT_SEND_PLAIN_FORBIDDEN"}})
			}()
			return pendingMsg(77, 5, "x")
		case "forwardMessages":
			return obj{"@type": "messages", "messages": []any{nil}}
		}
		return nil
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	if _, err := c.SendText(ctx, 5, "x", 0); err == nil || !strings.Contains(err.Error(), "CHAT_SEND_PLAIN_FORBIDDEN") {
		t.Fatalf("want the refusal, got %v", err)
	}
	if h := c.Health(); len(h.Errors) == 0 {
		t.Fatal("the refusal must show on the panel")
	}
	if err := c.Forward(ctx, 6, 1, 5); err == nil {
		t.Fatal("a message tdlib could not forward must be an error")
	}
}

// When the outcome is late (a big upload), the send does not hang: it gives the temporary message.
func TestSendTimesOutGracefully(t *testing.T) {
	f := newFakeTD(func(req obj) obj {
		if str(req, "@type") == "sendMessage" {
			return pendingMsg(88, 5, "slow")
		}
		return nil
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	sctx, cancel := context.WithTimeout(ctx, 100*time.Millisecond)
	defer cancel()
	m, err := c.SendText(sctx, 5, "slow", 0)
	if err != nil || m.ID != 88 {
		t.Fatalf("id=%d err=%v", m.ID, err)
	}
}

// tdlib gives history in small pieces; the client reads on until it has what was asked.
func TestHistoryReadsOnUntilEnough(t *testing.T) {
	f := newFakeTD(func(req obj) obj {
		switch str(req, "@type") {
		case "getChatHistory":
			from := num(req["from_message_id"])
			if from == 0 {
				from = 60
			}
			if from <= 10 {
				return obj{"@type": "messages", "messages": []any{}}
			}
			return obj{"@type": "messages", "messages": []any{textMsg(from-10, 5, 1, "m")}} // one at a time, older
		case "getUser":
			return obj{"@type": "user", "id": 1, "first_name": "U"}
		}
		return nil
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	msgs, err := c.History(ctx, 5, 0, 3, 0)
	if err != nil || len(msgs) != 4 || msgs[0].ID != 20 || msgs[3].ID != 50 {
		t.Fatalf("history: %+v err=%v", msgs, err)
	}
	msgs, _ = c.History(ctx, 5, 0, 20, 0)
	if len(msgs) != 5 {
		t.Fatalf("the read must stop at the start of the chat: %d", len(msgs))
	}
}

// Incoming messages reach the agent in the order they came, even when a name has to be looked up for the first.
func TestIncomingKeepsOrder(t *testing.T) {
	f := newFakeTD(func(req obj) obj {
		if str(req, "@type") == "getUser" {
			if num(req["user_id"]) == 1 {
				time.Sleep(80 * time.Millisecond) // the first sender's name is slow to resolve
			}
			return obj{"@type": "user", "id": req["user_id"], "first_name": "U"}
		}
		return nil
	})
	c, _ := loggedIn(t, f, TDConfig{})
	f.Push(obj{"@type": "updateNewMessage", "message": textMsg(1, 5, 1, "first")})
	f.Push(obj{"@type": "updateNewMessage", "message": textMsg(2, 5, 2, "second")})
	for _, want := range []string{"first", "second"} {
		select {
		case m := <-c.Updates():
			if m.Text != want {
				t.Fatalf("got %q, want %q", m.Text, want)
			}
		case <-time.After(3 * time.Second):
			t.Fatal("no message")
		}
	}
}

// Her status in a group is asked once and kept, until tdlib says it changed.
func TestChatMembershipIsCached(t *testing.T) {
	status := "chatMemberStatusMember"
	f := newFakeTD(func(req obj) obj {
		switch str(req, "@type") {
		case "getChat":
			return obj{"@type": "chat", "id": -100, "title": "G", "type": obj{"@type": "chatTypeSupergroup", "supergroup_id": 1}}
		case "getChatMember":
			return obj{"@type": "chatMember", "status": obj{"@type": status}}
		}
		return nil
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	for range 3 {
		if ch, err := c.Chat(ctx, -100); err != nil || ch.IsAdmin {
			t.Fatalf("%+v %v", ch, err)
		}
	}
	if n := len(f.requests("getChatMember")); n != 1 {
		t.Fatalf("getChatMember asked %d times", n)
	}
	status = "chatMemberStatusAdministrator"
	f.Push(obj{"@type": "updateChatMember", "chat_id": -100, "new_chat_member": obj{"member_id": obj{"@type": "messageSenderUser", "user_id": c.MyID()}}})
	deadline := time.Now().Add(2 * time.Second)
	for {
		if ch, _ := c.Chat(ctx, -100); ch.IsAdmin {
			break
		}
		if time.Now().After(deadline) {
			t.Fatal("the change of status was not noticed")
		}
		time.Sleep(10 * time.Millisecond)
	}
}

func TestTopicIDsFitTDLib(t *testing.T) {
	for in, want := range map[int64][2]int64{23958913024: {23958913024, 22849}, 22849: {23958913024, 22849}, 1 << 20: {1 << 20, 1}} {
		th, tp := topicIDs(in)
		if th != want[0] || tp != want[1] {
			t.Errorf("%d: %d %d, want %v", in, th, tp, want)
		}
	}
}
