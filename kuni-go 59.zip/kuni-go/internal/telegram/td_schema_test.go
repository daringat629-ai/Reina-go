package telegram

import (
	"bufio"
	"compress/gzip"
	"encoding/json"
	"fmt"
	"os"
	"regexp"
	"sort"
	"strings"
	"sync"
	"testing"
)

// The real tdlib API schemas (td/generate/scheme/td_api.tl) of the oldest supported version and of the newest one
// this build was checked against. Every request the client sends in the tests is validated against the schema of
// the version the fake reports, so a field that tdlib renamed or a wrapper it introduced fails a test here instead
// of failing silently on a live account. To check a newer tdlib, drop its td_api.tl.gz into testdata and add the
// version to schemaVersions.
var schemaVersions = []string{"1.8.61", "1.8.69"}

const newestTD = "1.8.69"

type tlDef struct {
	fields map[string]string
	result string
	fn     bool
}

type tlSchema map[string]*tlDef

var (
	schemaMu    sync.Mutex
	schemaCache = map[string]tlSchema{}
	tlLine      = regexp.MustCompile(`^([a-zA-Z0-9_]+)((?:\s+[a-zA-Z0-9_]+:\S+)*)\s*=\s*([A-Za-z0-9_<>.]+);`)
)

func loadSchema(t testing.TB, version string) tlSchema {
	t.Helper()
	schemaMu.Lock()
	defer schemaMu.Unlock()
	if s, ok := schemaCache[version]; ok {
		return s
	}
	f, err := os.Open("testdata/td_api_" + version + ".tl.gz")
	if err != nil {
		t.Fatalf("schema %s: %v", version, err)
	}
	defer f.Close()
	zr, err := gzip.NewReader(f)
	if err != nil {
		t.Fatalf("schema %s: %v", version, err)
	}
	s := tlSchema{}
	fn := false
	sc := bufio.NewScanner(zr)
	sc.Buffer(make([]byte, 1<<20), 1<<20)
	for sc.Scan() {
		l := strings.TrimSpace(sc.Text())
		if l == "---functions---" {
			fn = true
			continue
		}
		m := tlLine.FindStringSubmatch(l)
		if m == nil || strings.HasPrefix(l, "//") {
			continue
		}
		d := &tlDef{fields: map[string]string{}, result: m[3], fn: fn}
		for _, p := range strings.Fields(m[2]) {
			kv := strings.SplitN(p, ":", 2)
			d.fields[kv[0]] = kv[1]
		}
		s[m[1]] = d
	}
	schemaCache[version] = s
	return s
}

// validate checks a request (or a nested object) against the schema; want is "" for a top-level function,
// a class name ("InputFile") or a bare constructor name ("formattedText").
func (s tlSchema) validate(v any, want, path string) []string {
	m, ok := v.(map[string]any)
	if !ok {
		return []string{fmt.Sprintf("%s: want an object of %s, got %T", path, want, v)}
	}
	t, _ := m["@type"].(string)
	d := s[t]
	if d == nil {
		return []string{fmt.Sprintf("%s: unknown @type %q", path, t)}
	}
	switch {
	case want == "" && !d.fn:
		return []string{fmt.Sprintf("%s: %q is not a function", path, t)}
	case want != "" && want != t && want != d.result:
		return []string{fmt.Sprintf("%s: %q (%s) where %s is expected", path, t, d.result, want)}
	}
	var errs []string
	keys := make([]string, 0, len(m))
	for k := range m {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	for _, k := range keys {
		if k == "@type" || k == "@extra" {
			continue
		}
		ft, ok := d.fields[k]
		if !ok {
			// tdlib ignores unknown fields, so a key kept for another tdlib version is harmless only when it is
			// documented as such; everything else is a typo or a renamed field
			if t == "sendMessage" && k == "message_thread_id" {
				continue
			}
			errs = append(errs, fmt.Sprintf("%s: %s has no field %q", path, t, k))
			continue
		}
		errs = append(errs, s.value(m[k], ft, path+"."+k)...)
	}
	return errs
}

func (s tlSchema) value(v any, ft, path string) []string {
	if v == nil {
		return nil // null = the default value
	}
	if strings.HasPrefix(ft, "vector<") {
		arr, ok := v.([]any)
		if !ok {
			return []string{fmt.Sprintf("%s: want %s, got %T", path, ft, v)}
		}
		inner := strings.TrimSuffix(strings.TrimPrefix(ft, "vector<"), ">")
		var errs []string
		for i, e := range arr {
			errs = append(errs, s.value(e, inner, fmt.Sprintf("%s[%d]", path, i))...)
		}
		return errs
	}
	bad := func() []string { return []string{fmt.Sprintf("%s: want %s, got %T (%v)", path, ft, v, v)} }
	switch ft {
	case "string", "bytes":
		if _, ok := v.(string); !ok {
			return bad()
		}
	case "Bool":
		if _, ok := v.(bool); !ok {
			return bad()
		}
	case "int32", "int53", "double":
		if _, ok := v.(json.Number); !ok {
			return bad()
		}
	case "int64": // tdlib accepts a number or a string
		switch v.(type) {
		case json.Number, string:
		default:
			return bad()
		}
	default:
		return s.validate(v, ft, path)
	}
	return nil
}

// checkSchema validates one raw request; used by fakeTD.Send.
func checkSchema(t testing.TB, version string, req obj) []string {
	if version == "" {
		version = newestTD
	}
	return loadSchema(t, version).validate(req, "", str(req, "@type"))
}

func TestSchemaValidatorCatchesMistakes(t *testing.T) {
	s := loadSchema(t, newestTD)
	good := obj{"@type": "sendMessage", "chat_id": json.Number("5"), "input_message_content": obj{"@type": "inputMessageText",
		"text": obj{"@type": "formattedText", "text": "hi", "entities": []any{}}}}
	if errs := s.validate(roundTrip(good), "", "sendMessage"); len(errs) != 0 {
		t.Fatalf("valid request rejected: %v", errs)
	}
	bad := obj{"@type": "sendMessage", "chat_id": 5, "input_message_content": obj{"@type": "inputMessagePhoto",
		"photo": obj{"@type": "inputFileLocal", "path": "/x"}}, "reply_too": 1}
	errs := s.validate(roundTrip(bad), "", "sendMessage")
	joined := strings.Join(errs, "\n")
	if !strings.Contains(joined, `no field "reply_too"`) || !strings.Contains(joined, `"inputFileLocal" (InputFile) where inputPhoto is expected`) {
		t.Fatalf("mistakes not reported: %v", errs)
	}
}

func roundTrip(m obj) obj {
	b, _ := json.Marshal(m)
	out, _ := decode(b)
	return out
}

// Every shape the client builds is valid for every supported tdlib version.
func TestRequestsMatchEveryTDLibSchema(t *testing.T) {
	for _, v := range schemaVersions {
		t.Run(v, func(t *testing.T) {
			f := newFakeTD(nil)
			f.version = v
			c, ctx := loggedIn(t, f, TDConfig{})
			if got := c.TDLibVersion(); got != v {
				t.Fatalf("version = %q, want %q", got, v)
			}
			for _, kind := range []string{KindPhoto, KindDocument, KindVideo, KindAnimation, KindAudio} {
				if _, err := c.SendMedia(ctx, 5, kind, "f.bin", []byte("x"), "cap @nick", 3); err != nil {
					t.Fatal(err)
				}
			}
			if _, err := c.SendPhoto(ctx, 5, []byte("x"), "c", 0); err != nil {
				t.Fatal(err)
			}
			if _, err := c.SendDocument(ctx, 5, "a.txt", []byte("x"), "c", 0); err != nil {
				t.Fatal(err)
			}
			if _, err := c.SendVoice(ctx, 5, []byte("x"), 0); err != nil {
				t.Fatal(err)
			}
			if _, err := c.SendSticker(ctx, 5, "77", 0); err != nil {
				t.Fatal(err)
			}
			if _, err := c.SendPoll(ctx, 5, "q?", []string{"a", "b"}, false, true, 0); err != nil {
				t.Fatal(err)
			}
			if _, err := c.SendLocation(ctx, 5, 42.87, 74.59, 0); err != nil {
				t.Fatal(err)
			}
			if _, err := c.SendText(ctx, 5, "hi **there**", 2); err != nil {
				t.Fatal(err)
			}
			_ = c.SetProfilePhoto(ctx, []byte("x"))
			// the cleanup registered by loggedIn fails the test if any request above broke the schema
		})
	}
}

func TestClientIDOf(t *testing.T) {
	if id, ok := clientIDOf([]byte(`{"@type":"ok","@extra":"1","@client_id":12}`)); !ok || id != 12 {
		t.Fatal(id, ok)
	}
	if _, ok := clientIDOf([]byte(`{"@type":"ok"}`)); ok {
		t.Fatal("no client id")
	}
	// a message text that contains the key must not confuse it: tdlib puts the real one last
	if id, _ := clientIDOf([]byte(`{"text":"\"@client_id\":99","@client_id":3}`)); id != 3 {
		t.Fatal(id)
	}
}
