package telegram

import "context"

// StorageOptimizer is implemented by clients that keep a media cache on disk (tdlib): it deletes cached files
// not used for ttlDays days and reports how many bytes it freed.
type StorageOptimizer interface {
	OptimizeStorage(ctx context.Context, ttlDays int) (int64, error)
}

// OptimizeStorage asks tdlib to delete downloaded media it has not needed for ttlDays days (chats keep their
// messages; a file is simply fetched again if somebody opens it).
func (c *TDClient) OptimizeStorage(ctx context.Context, ttlDays int) (int64, error) {
	if ttlDays < 1 {
		ttlDays = 1
	}
	r, err := c.api(ctx, obj{"@type": "optimizeStorage", "size": -1, "ttl": ttlDays * 86400, "count": -1, "immunity_delay": 600,
		"file_types": []any{}, "chat_ids": []any{}, "exclude_chat_ids": []any{}, "return_deleted_file_statistics": true, "chat_limit": 0})
	if err != nil {
		return 0, err
	}
	return num(r["size"]), nil
}

var _ StorageOptimizer = (*TDClient)(nil)
