package telegram

import (
	"context"
	"errors"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"
	"time"
)

// A flood wait is sat out and the call repeated; the error of a transport failure never shows the token.
func TestBotFloodWaitAndTokenScrub(t *testing.T) {
	var n atomic.Int32
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		io.ReadAll(r.Body)
		if n.Add(1) == 1 {
			w.WriteHeader(429)
			io.WriteString(w, `{"ok":false,"error_code":429,"description":"Too Many Requests: retry after 1","parameters":{"retry_after":1}}`)
			return
		}
		io.WriteString(w, `{"ok":true,"result":{"message_id":5,"date":1,"chat":{"id":42,"type":"private"},"text":"hi"}}`)
	}))
	defer srv.Close()
	b := NewBot("123:SECRET", srv.URL)
	start := time.Now()
	m, err := b.SendText(context.Background(), 42, "hi", 0)
	if err != nil || m.ID != 5 || n.Load() != 2 || time.Since(start) < time.Second {
		t.Fatalf("m=%+v err=%v calls=%d", m, err, n.Load())
	}

	dead := NewBot("123:SECRET", "http://127.0.0.1:1")
	_, err = dead.SendText(context.Background(), 42, "hi", 0)
	if err == nil || strings.Contains(err.Error(), "SECRET") || !strings.Contains(err.Error(), "<token>") {
		t.Fatalf("token in error: %v", err)
	}
}

// A token the API rejects (401, or 404 for a malformed one) stops the client instead of retrying forever.
func TestBotRejectedTokenIsFinal(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(404)
		io.WriteString(w, `{"ok":false,"error_code":404,"description":"Not Found"}`)
	}))
	defer srv.Close()
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	err := NewBot("bad", srv.URL).Run(ctx)
	var ae *BotAPIError
	if err == nil || !errors.As(err, &ae) || ae.Code != 404 {
		t.Fatalf("want a final error, got %v", err)
	}
}
