package telegram

import (
	"context"
	"errors"
	"sync"
	"time"
)

// Fake is an in-memory Client for tests and for running the agent without Telegram.
type Fake struct {
	Core
	Rich     FakeRich
	Media    FakeMedia
	Me       int64
	mu       sync.Mutex
	updates  chan Message
	Sent     []Message
	docs     []Doc
	Joined   []string
	Reacted  map[int64]string
	Banned   []int64
	Files    map[string][]byte
	Left     []int64
	Typings  int
	Forwards [][3]int64
	Roster   map[int64][]Member // chat id -> members
	Users    map[int64]User
	events   chan Event
	Pinned   map[int64][]int64                       // chat -> pinned message ids
	OnSend   func(ctx context.Context, chatID int64) // test hook: sees the context of every text send
}

func NewFake() *Fake {
	return &Fake{Core: Core{S: NewStore()}, Me: 1, updates: make(chan Message, 64), events: make(chan Event, 16), Reacted: map[int64]string{}, Files: map[string][]byte{}}
}

func (f *Fake) Run(ctx context.Context) error { <-ctx.Done(); return nil }
func (f *Fake) Updates() <-chan Message       { return f.updates }

// Events and Emit let tests simulate reactions and edits.
func (f *Fake) Events() <-chan Event { return f.events }
func (f *Fake) Emit(e Event)         { f.events <- e }
func (f *Fake) MyID() int64          { return f.Me }

// Incoming simulates a user message arriving in a chat.
func (f *Fake) Incoming(chat Chat, senderID int64, sender, text string) Message {
	m := Message{ID: f.S.NextID(chat.ID), ChatID: chat.ID, SenderID: senderID, SenderName: sender, Date: time.Now(), Text: text}
	f.S.Put(m, &chat)
	f.updates <- m
	return m
}

// IncomingIn is Incoming for a message in a forum topic.
func (f *Fake) IncomingIn(chat Chat, senderID int64, sender, text string, thread int64) Message {
	m := Message{ID: f.S.NextID(chat.ID), ChatID: chat.ID, SenderID: senderID, SenderName: sender, Date: time.Now(), Text: text, ThreadID: thread}
	f.S.Put(m, &chat)
	f.updates <- m
	return m
}

func (f *Fake) send(chatID int64, m Message) Message {
	m.ID, m.ChatID, m.SenderID, m.SenderName, m.Date, m.Outgoing, m.Read = f.S.NextID(chatID), chatID, f.Me, "me", time.Now(), true, true
	f.S.Put(m, nil)
	f.mu.Lock()
	f.Sent = append(f.Sent, m)
	f.mu.Unlock()
	return m
}

func (f *Fake) SendText(ctx context.Context, chatID int64, text string, replyTo int64) (Message, error) {
	if f.OnSend != nil {
		f.OnSend(ctx, chatID)
	}
	return f.send(chatID, Message{Text: text, ReplyTo: replyTo}), nil
}
func (f *Fake) SendPhoto(_ context.Context, chatID int64, data []byte, caption string, replyTo int64) (Message, error) {
	return f.send(chatID, Message{Text: caption, ReplyTo: replyTo, Media: MediaPhoto}), nil
}

// Doc is a file the fake was asked to send.
type Doc struct {
	Name string
	Data []byte
}

// Docs returns the files sent so far.
func (f *Fake) Docs() []Doc {
	f.mu.Lock()
	defer f.mu.Unlock()
	return append([]Doc(nil), f.docs...)
}

func (f *Fake) SendDocument(_ context.Context, chatID int64, name string, data []byte, caption string, replyTo int64) (Message, error) {
	f.mu.Lock()
	f.docs = append(f.docs, Doc{name, data})
	f.mu.Unlock()
	return f.send(chatID, Message{Text: caption + "[file:" + name + "]", ReplyTo: replyTo}), nil
}
func (f *Fake) SendVoice(_ context.Context, chatID int64, data []byte, replyTo int64) (Message, error) {
	return f.send(chatID, Message{ReplyTo: replyTo, Media: MediaVoice}), nil
}
func (f *Fake) SendSticker(_ context.Context, chatID int64, fileID string, replyTo int64) (Message, error) {
	return f.send(chatID, Message{ReplyTo: replyTo, Media: MediaSticker, FileID: fileID}), nil
}
func (f *Fake) Edit(_ context.Context, chatID, msgID int64, text string) error {
	if !f.S.Update(chatID, msgID, func(m *Message) { m.Text, m.Edited = text, true }) {
		return ErrNotFound
	}
	return nil
}
func (f *Fake) Delete(_ context.Context, chatID, msgID int64) error {
	f.S.Remove(chatID, msgID)
	return nil
}
func (f *Fake) Forward(_ context.Context, from, msgID, to int64) error {
	f.mu.Lock()
	f.Forwards = append(f.Forwards, [3]int64{from, msgID, to})
	f.mu.Unlock()
	return nil
}
func (f *Fake) React(_ context.Context, chatID, msgID int64, emoji string) error {
	f.mu.Lock()
	f.Reacted[msgID] = emoji
	f.mu.Unlock()
	return nil
}
func (f *Fake) Typing(context.Context, int64) error {
	f.mu.Lock()
	f.Typings++
	f.mu.Unlock()
	return nil
}
func (f *Fake) SendPoll(_ context.Context, chatID int64, question string, options []string, anonymous, multiple bool, replyTo int64) (Message, error) {
	if len(options) < 2 || len(options) > 10 {
		return Message{}, errors.New("a poll needs 2-10 options")
	}
	p := &Poll{Question: question, Anonymous: anonymous, Multiple: multiple}
	for _, o := range options {
		p.Options = append(p.Options, PollOption{Text: o})
	}
	return f.send(chatID, Message{Text: question, ReplyTo: replyTo, Media: MediaPoll, Poll: p}), nil
}
func (f *Fake) VotePoll(_ context.Context, chatID, msgID int64, options []int) error {
	if !f.S.Update(chatID, msgID, func(m *Message) {
		if m.Poll == nil {
			return
		}
		cp := *m.Poll
		cp.Options = append([]PollOption(nil), m.Poll.Options...)
		for i := range cp.Options {
			if cp.Options[i].Chosen {
				cp.Options[i].Chosen, cp.Options[i].Votes, cp.Total = false, cp.Options[i].Votes-1, cp.Total-1
			}
		}
		for _, o := range options {
			if o >= 0 && o < len(cp.Options) {
				cp.Options[o].Chosen, cp.Options[o].Votes, cp.Total = true, cp.Options[o].Votes+1, cp.Total+1
			}
		}
		m.Poll = &cp
	}) {
		return ErrNotFound
	}
	return nil
}
func (f *Fake) Pin(_ context.Context, chatID, msgID int64, silent bool) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.Pinned == nil {
		f.Pinned = map[int64][]int64{}
	}
	f.Pinned[chatID] = append(f.Pinned[chatID], msgID)
	return nil
}
func (f *Fake) Unpin(_ context.Context, chatID, msgID int64) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	var keep []int64
	for _, id := range f.Pinned[chatID] {
		if id != msgID {
			keep = append(keep, id)
		}
	}
	f.Pinned[chatID] = keep
	return nil
}
func (f *Fake) Join(_ context.Context, link string) error {
	f.mu.Lock()
	f.Joined = append(f.Joined, link)
	f.mu.Unlock()
	return nil
}
func (f *Fake) Leave(_ context.Context, chatID int64) error {
	f.mu.Lock()
	f.Left = append(f.Left, chatID)
	f.mu.Unlock()
	return nil
}
func (f *Fake) Ban(_ context.Context, chatID, userID int64, removeAll bool) error {
	f.mu.Lock()
	f.Banned = append(f.Banned, userID)
	f.mu.Unlock()
	return nil
}
func (f *Fake) SetMemberTag(context.Context, int64, int64, string) error { return nil }
func (f *Fake) Members(_ context.Context, chatID int64, limit int) ([]Member, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	m, ok := f.Roster[chatID]
	if !ok {
		return nil, errors.New("members not available")
	}
	if limit > 0 && len(m) > limit {
		m = m[:limit]
	}
	return append([]Member(nil), m...), nil
}
func (f *Fake) UserInfo(_ context.Context, id int64) (User, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	if u, ok := f.Users[id]; ok {
		return u, nil
	}
	return User{}, ErrNotFound
}
func (f *Fake) Download(_ context.Context, fileID string) ([]byte, error) {
	if b, ok := f.Files[fileID]; ok {
		return b, nil
	}
	return nil, errors.New("no such file")
}
func (f *Fake) ChatPhoto(context.Context, int64) ([]byte, error) { return nil, ErrNotFound }

// SentTexts returns the text of all messages sent so far.
func (f *Fake) SentTexts() []string {
	f.mu.Lock()
	defer f.mu.Unlock()
	var out []string
	for _, m := range f.Sent {
		out = append(out, m.Text)
	}
	return out
}

var _ Client = (*Fake)(nil)
