//go:build !(tdlib && cgo)

package telegram

import "errors"

// NewTDJSONTransport is unavailable without the "tdlib" build tag.
func NewTDJSONTransport() (Transport, error) {
	return nil, errors.New("user-account mode needs tdlib: install libtdjson and rebuild with `go build -tags tdlib` (see README)")
}
