//go:build tdlib && cgo

package telegram

import (
	"strings"
	"testing"
	"time"
)

// Runs against whatever libtdjson is linked; with a real tdlib the first reply is not "echo",
// so the test only asserts the transport round-trips bytes when the library is a stub.
func TestCgoTransportRoundTrip(t *testing.T) {
	tr, err := NewTDJSONTransport()
	if err != nil {
		t.Fatal(err)
	}
	tr.Send([]byte(`{"@type":"getOption","name":"version"}`))
	deadline := time.Now().Add(3 * time.Second)
	for time.Now().Before(deadline) {
		if raw := tr.Receive(100 * time.Millisecond); raw != nil {
			if strings.Contains(string(raw), `"echo"`) && !strings.Contains(string(raw), `getOption`) {
				t.Fatalf("payload lost: %s", raw)
			}
			return
		}
	}
	t.Fatal("no response from libtdjson")
}
