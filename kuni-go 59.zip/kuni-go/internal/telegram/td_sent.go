package telegram

import (
	"context"
	"sync"
	"time"
)

// tdlib answers sendMessage at once with a temporary message: a local id and sending_state "pending". The real
// message (with the id every later action must use) comes afterwards in updateMessageSendSucceeded, and a refusal of
// the server (no right to write, slow mode, a file too big...) only in updateMessageSendFailed.
//
// The client used to return the temporary message and never look at those updates: she was given an id that
// editing, deleting, pinning or answering failed with, and a message the server refused counted as sent. Now a send
// waits for the outcome (briefly) and returns the real message or the server's error.

// sendWaitText and sendWaitFile bound the wait: a text goes out in a moment, a file has to be uploaded first.
const (
	sendWaitText = 20 * time.Second
	sendWaitFile = 3 * time.Minute
)

type sendOutcome struct {
	msg obj   // the message as sent (permanent id)
	err error // the server refused it
	at  time.Time
}

// sendWaits pairs pending sends with their outcome. An outcome that arrives before anybody waits for it (the
// receive loop is quicker than the goroutine that sent) is kept for a while.
type sendWaits struct {
	mu    sync.Mutex
	wait  map[string]chan sendOutcome
	early map[string]sendOutcome
}

// deliver hands the outcome of the send key (chat:temporary id) to its waiter, or keeps it for one.
func (w *sendWaits) deliver(key string, o sendOutcome) {
	w.mu.Lock()
	defer w.mu.Unlock()
	if ch, ok := w.wait[key]; ok {
		delete(w.wait, key)
		ch <- o
		return
	}
	if w.early == nil {
		w.early = map[string]sendOutcome{}
	}
	o.at = time.Now()
	w.early[key] = o
	if len(w.early) > 256 { // nobody waits for these (the sender gave up): forget the old ones
		for k, v := range w.early {
			if time.Since(v.at) > 10*time.Minute {
				delete(w.early, k)
			}
		}
	}
}

// await waits for the outcome of the send key. ok is false when it did not come in time.
func (w *sendWaits) await(ctx context.Context, key string, d time.Duration) (o sendOutcome, ok bool) {
	w.mu.Lock()
	if e, found := w.early[key]; found {
		delete(w.early, key)
		w.mu.Unlock()
		return e, true
	}
	if w.wait == nil {
		w.wait = map[string]chan sendOutcome{}
	}
	ch := make(chan sendOutcome, 1)
	w.wait[key] = ch
	w.mu.Unlock()
	t := time.NewTimer(d)
	defer t.Stop()
	select {
	case o = <-ch:
		return o, true
	case <-t.C:
	case <-ctx.Done():
	}
	w.mu.Lock()
	delete(w.wait, key)
	w.mu.Unlock()
	select { // it may have come just now
	case o = <-ch:
		return o, true
	default:
	}
	return sendOutcome{}, false
}

// onSendResult reads updateMessageSendSucceeded / updateMessageSendFailed.
func (c *TDClient) onSendResult(m obj) {
	msg := sub(m, "message")
	key := evKey(num(msg["chat_id"]), num(m["old_message_id"]))
	if typ(m) == "updateMessageSendSucceeded" {
		c.sends.deliver(key, sendOutcome{msg: msg})
		return
	}
	e := &tdError{Code: int(num(m["error_code"])), Message: str(m, "error_message")} // tdlib up to 1.8.4x
	if er := sub(m, "error"); er != nil {
		e = &tdError{Code: int(num(er["code"])), Message: str(er, "message")}
	}
	c.hl.record("sendMessage", num(msg["chat_id"]), e.Error())
	c.sends.deliver(key, sendOutcome{err: e})
}

// settle turns the answer of a send into the message as it really went out: it waits up to d for the outcome of a
// pending send. When the outcome does not come in time (a big upload), the temporary message is returned.
func (c *TDClient) settle(ctx context.Context, r obj, d time.Duration) (obj, error) {
	if typ(sub(r, "sending_state")) != "messageSendingStatePending" || sub(r, "scheduling_state") != nil {
		return r, nil
	}
	o, ok := c.sends.await(ctx, evKey(num(r["chat_id"]), num(r["id"])), d)
	switch {
	case !ok:
		return r, nil
	case o.err != nil:
		return nil, o.err
	}
	return o.msg, nil
}

// sendWait is how long a send of content may take.
func sendWait(content obj) time.Duration {
	switch typ(content) {
	case "inputMessageText", "inputMessageDice", "inputMessageLocation", "inputMessageVenue", "inputMessageContact",
		"inputMessagePoll", "inputMessageSticker", "inputMessageForwarded":
		return sendWaitText
	}
	return sendWaitFile
}
