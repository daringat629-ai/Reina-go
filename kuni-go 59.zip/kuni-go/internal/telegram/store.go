package telegram

import (
	"context"
	"encoding/json"
	"errors"
	"os"
	"sort"
	"strings"
	"sync"
	"time"

	"kuni/internal/store"
)

// ErrNotFound is returned for unknown chats/messages.
var ErrNotFound = errors.New("telegram: not found")

// Store keeps chats and messages seen so far. The Bot API cannot fetch history,
// so the store is the source for History/Search/Unread, and is persisted to disk.
type Store struct {
	mu       sync.RWMutex
	chats    map[int64]*Chat
	messages map[int64][]Message // by chat, ascending by ID
	nextID   map[int64]int64     // for fakes
}

func NewStore() *Store {
	return &Store{chats: map[int64]*Chat{}, messages: map[int64][]Message{}, nextID: map[int64]int64{}}
}

// Put inserts or replaces a message and updates the chat summary.
func (s *Store) Put(m Message, chat *Chat) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if chat != nil {
		c := *chat
		if old, ok := s.chats[c.ID]; ok {
			c.Unread, c.IsMember, c.IsAdmin = old.Unread, old.IsMember || c.IsMember, old.IsAdmin || c.IsAdmin
		} else {
			c.IsMember = true
		}
		s.chats[c.ID] = &c
	}
	c := s.chats[m.ChatID]
	if c == nil {
		c = &Chat{ID: m.ChatID, Title: "chat " + itoa(m.ChatID), Kind: ChatPrivate, IsMember: true}
		s.chats[m.ChatID] = c
	}
	list := s.messages[m.ChatID]
	replaced := false
	for i := range list {
		if list[i].ID == m.ID {
			list[i] = m
			replaced = true
			break
		}
	}
	if !replaced {
		list = append(list, m)
		sort.SliceStable(list, func(i, j int) bool { return list[i].ID < list[j].ID })
		if !m.Outgoing {
			c.Unread++
		}
	}
	s.messages[m.ChatID] = list
	c.LastText, c.LastDate = m.Text, m.Date
}

func (s *Store) SetChatFlags(id int64, member, admin bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if c := s.chats[id]; c != nil {
		c.IsMember, c.IsAdmin = member, admin
	}
}

func (s *Store) Remove(chatID, msgID int64) {
	s.mu.Lock()
	defer s.mu.Unlock()
	list := s.messages[chatID]
	for i := range list {
		if list[i].ID == msgID {
			s.messages[chatID] = append(list[:i:i], list[i+1:]...)
			return
		}
	}
}

func (s *Store) Update(chatID, msgID int64, f func(*Message)) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	list := s.messages[chatID]
	for i := range list {
		if list[i].ID == msgID {
			f(&list[i])
			return true
		}
	}
	return false
}

func (s *Store) NextID(chatID int64) int64 {
	s.mu.Lock()
	defer s.mu.Unlock()
	max := s.nextID[chatID]
	for _, m := range s.messages[chatID] {
		if m.ID > max {
			max = m.ID
		}
	}
	s.nextID[chatID] = max + 1
	return max + 1
}

func (s *Store) ChatByID(id int64) (Chat, bool) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	c, ok := s.chats[id]
	if !ok {
		return Chat{}, false
	}
	return *c, true
}

// Core implements the read-only parts of Client on top of a Store.
type Core struct {
	S *Store
}

func (c Core) Chats(_ context.Context, limit int) ([]Chat, error) {
	c.S.mu.RLock()
	defer c.S.mu.RUnlock()
	out := make([]Chat, 0, len(c.S.chats))
	for _, ch := range c.S.chats {
		out = append(out, *ch)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].LastDate.After(out[j].LastDate) })
	if limit > 0 && len(out) > limit {
		out = out[:limit]
	}
	return out, nil
}

func (c Core) Chat(_ context.Context, id int64) (Chat, error) {
	ch, ok := c.S.ChatByID(id)
	if !ok {
		return Chat{}, ErrNotFound
	}
	return ch, nil
}

func (c Core) SearchChats(ctx context.Context, q string) ([]Chat, error) {
	all, _ := c.Chats(ctx, 0)
	q = strings.TrimPrefix(strings.ToLower(q), "@")
	var out []Chat
	for _, ch := range all {
		if strings.Contains(strings.ToLower(ch.Title), q) {
			out = append(out, ch)
		}
	}
	return out, nil
}

func (c Core) Unread(_ context.Context, chatID int64) ([]Message, error) {
	c.S.mu.RLock()
	defer c.S.mu.RUnlock()
	var out []Message
	for _, m := range c.S.messages[chatID] {
		if !m.Outgoing && !m.Read {
			out = append(out, m)
		}
	}
	return out, nil
}

func (c Core) History(_ context.Context, chatID, aroundID int64, before, after int) ([]Message, error) {
	c.S.mu.RLock()
	defer c.S.mu.RUnlock()
	list := c.S.messages[chatID]
	if len(list) == 0 {
		return nil, nil
	}
	idx := len(list) - 1
	if aroundID > 0 {
		idx = -1
		for i := range list {
			if list[i].ID >= aroundID {
				idx = i
				break
			}
		}
		if idx < 0 {
			idx = len(list) - 1
		}
	}
	lo, hi := idx-before, idx+after+1
	if lo < 0 {
		lo = 0
	}
	if hi > len(list) {
		hi = len(list)
	}
	return append([]Message(nil), list[lo:hi]...), nil
}

func (c Core) Message(_ context.Context, chatID, msgID int64) (Message, error) {
	c.S.mu.RLock()
	defer c.S.mu.RUnlock()
	for _, m := range c.S.messages[chatID] {
		if m.ID == msgID {
			return m, nil
		}
	}
	return Message{}, ErrNotFound
}

func (c Core) Search(_ context.Context, q SearchQuery) ([]Message, error) {
	c.S.mu.RLock()
	defer c.S.mu.RUnlock()
	limit := q.Limit
	if limit <= 0 {
		limit = 20
	}
	needle := strings.ToLower(q.Text)
	var out []Message
	for chatID, list := range c.S.messages {
		if q.ChatID != 0 && chatID != q.ChatID {
			continue
		}
		for _, m := range list {
			if q.SenderID != 0 && m.SenderID != q.SenderID {
				continue
			}
			if !q.Since.IsZero() && m.Date.Before(q.Since) {
				continue
			}
			if needle != "" && !strings.Contains(strings.ToLower(m.Text), needle) {
				continue
			}
			out = append(out, m)
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Date.After(out[j].Date) })
	if len(out) > limit {
		out = out[:limit]
	}
	return out, nil
}

func (c Core) MarkRead(_ context.Context, chatID int64) error {
	c.S.mu.Lock()
	defer c.S.mu.Unlock()
	list := c.S.messages[chatID]
	for i := range list {
		list[i].Read = true
	}
	if ch := c.S.chats[chatID]; ch != nil {
		ch.Unread = 0
	}
	return nil
}

// persisted is the on-disk form of a Store.
type persisted struct {
	Chats    []Chat              `json:"chats"`
	Messages map[int64][]Message `json:"messages"`
}

// Save writes the store to path atomically.
func (s *Store) Save(path string) error {
	s.mu.RLock()
	p := persisted{Messages: s.messages}
	for _, c := range s.chats {
		p.Chats = append(p.Chats, *c)
	}
	raw, err := json.Marshal(p)
	s.mu.RUnlock()
	if err != nil {
		return err
	}
	return store.WriteFile(path, raw, store.Private) // other people's messages: private
}

// Load reads a store saved by Save; a missing file is not an error.
func (s *Store) Load(path string) error {
	raw, err := os.ReadFile(path)
	if os.IsNotExist(err) {
		return nil
	}
	if err != nil {
		return err
	}
	var p persisted
	if err := json.Unmarshal(raw, &p); err != nil {
		return err
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	for i := range p.Chats {
		c := p.Chats[i]
		s.chats[c.ID] = &c
	}
	if p.Messages != nil {
		s.messages = p.Messages
	}
	return nil
}

func itoa(n int64) string {
	b, _ := json.Marshal(n)
	return string(b)
}

var _ = time.Now
