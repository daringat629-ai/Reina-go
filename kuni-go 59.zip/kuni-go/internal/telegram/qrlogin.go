package telegram

import "sync"

// The login-by-QR state: tdlib hands out a tg://login?token=... link that the owner confirms from a phone that is
// already signed in (Settings > Devices > Link Desktop Device). The panel draws it as a picture (/admin/qr).
var qrLogin struct {
	mu      sync.Mutex
	link    string
	waiting bool
	done    bool
}

func setLoginQR(link string) {
	qrLogin.mu.Lock()
	qrLogin.link, qrLogin.waiting, qrLogin.done = link, true, false
	qrLogin.mu.Unlock()
}

func setLoginDone() {
	qrLogin.mu.Lock()
	wasWaiting := qrLogin.waiting
	qrLogin.link, qrLogin.waiting, qrLogin.done = "", false, wasWaiting
	qrLogin.mu.Unlock()
}

// LoginQR reports the current login link ("" when none), whether the program waits for a scan, and whether a scan
// just finished the login.
func LoginQR() (link string, waiting, done bool) {
	qrLogin.mu.Lock()
	defer qrLogin.mu.Unlock()
	return qrLogin.link, qrLogin.waiting, qrLogin.done
}
