package telegram

import (
	"context"
	"time"
)

// ChatList names a list of chats: the main one, the archive or a folder.
type ChatList struct {
	Archive bool
	Folder  int // folder id, 0 = none
}

// SendOptions are the extras of a send that the app offers beyond the text.
type SendOptions struct {
	ReplyTo  int64
	Silent   bool      // no notification
	Markdown bool      // the text uses *bold* _italic_ `code` [text](url)
	At       time.Time // schedule for later (zero = now)
}

// ButtonAnswer is what a bot says back when an inline button is pressed.
type ButtonAnswer struct {
	Text  string `json:"text,omitempty"`
	Alert bool   `json:"alert,omitempty"`
	URL   string `json:"url,omitempty"`
}

// Rich is what only the user-account client can do: the parts of the app beyond plain chatting.
// Callers type-assert for it; the Bot API client does not implement it.
type Rich interface {
	Folders(ctx context.Context) ([]Folder, error)
	ChatsIn(ctx context.Context, l ChatList, limit int) ([]Chat, error)
	// PressButton presses a callback button of a bot message (data as in Button.Data).
	PressButton(ctx context.Context, chatID, msgID int64, data string) (ButtonAnswer, error)
	SetMuted(ctx context.Context, chatID int64, muted bool) error
	PinnedMessage(ctx context.Context, chatID int64) (Message, error)
	SendWith(ctx context.Context, chatID int64, text string, o SendOptions) (Message, error)
	EditFormatted(ctx context.Context, chatID, msgID int64, text string, markdown bool) error
	SendDice(ctx context.Context, chatID int64, emoji string, replyTo int64) (Message, error)
	SendLocation(ctx context.Context, chatID int64, lat, lon float64, replyTo int64) (Message, error)
}
