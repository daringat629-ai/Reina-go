package media

import (
	"bytes"
	"context"
	_ "embed"
	"encoding/base64"
	"fmt"
	"image"
	"image/color"
	_ "image/jpeg"
	"image/png"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

// Her reference picture: every photo is made FROM it (img2img), so the face, the hair and the style stay the same
// instead of being re-invented from words each time.

//go:embed reference.jpg
var defaultReference []byte

// The size of the pictures Stable Diffusion makes here (portrait 2:3).
const (
	genWidth  = 512
	genHeight = 768
)

// SeedReference writes the built-in reference to path when no file is there yet; an existing file is never touched.
func SeedReference(path string) error {
	if path == "" {
		return nil
	}
	if _, err := os.Stat(path); err == nil {
		return nil
	}
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return err
	}
	return os.WriteFile(path, defaultReference, 0o644)
}

type refEntry struct {
	mod time.Time
	b64 string
}

var (
	refMu    sync.Mutex
	refCache = map[string]refEntry{}
)

// LoadReference returns the reference at path ready for img2img: cropped to 2:3 and scaled to the generation size,
// as a base64 PNG. The result is cached until the file changes.
func LoadReference(path string) (string, error) {
	st, err := os.Stat(path)
	if err != nil {
		return "", err
	}
	refMu.Lock()
	defer refMu.Unlock()
	if e, ok := refCache[path]; ok && e.mod.Equal(st.ModTime()) {
		return e.b64, nil
	}
	raw, err := os.ReadFile(path)
	if err != nil {
		return "", err
	}
	b, err := prepareReference(raw)
	if err != nil {
		return "", fmt.Errorf("reference %s: %w", path, err)
	}
	enc := base64.StdEncoding.EncodeToString(b)
	refCache[path] = refEntry{st.ModTime(), enc}
	return enc, nil
}

// prepareReference crops the picture to the 2:3 frame (keeping the upper part where the face is) and scales it.
func prepareReference(raw []byte) ([]byte, error) {
	img, _, err := image.Decode(bytes.NewReader(raw))
	if err != nil {
		return nil, err
	}
	b := img.Bounds()
	w, h := b.Dx(), b.Dy()
	if w < 64 || h < 64 {
		return nil, fmt.Errorf("the picture is too small (%dx%d)", w, h)
	}
	// the largest 2:3 window inside the picture
	cw, ch := w, w*genHeight/genWidth
	if ch > h {
		ch, cw = h, h*genWidth/genHeight
	}
	x0 := b.Min.X + (w-cw)/2
	y0 := b.Min.Y + (h-ch)/4 // a taller picture loses more at the bottom than at the top
	out := image.NewRGBA(image.Rect(0, 0, genWidth, genHeight))
	// bilinear scaling
	for y := 0; y < genHeight; y++ {
		fy := (float64(y)+0.5)*float64(ch)/genHeight - 0.5
		y1 := int(fy)
		if fy < 0 {
			y1, fy = 0, 0
		}
		dy := fy - float64(y1)
		y2 := y1 + 1
		if y2 >= ch {
			y2 = ch - 1
		}
		for x := 0; x < genWidth; x++ {
			fx := (float64(x)+0.5)*float64(cw)/genWidth - 0.5
			x1 := int(fx)
			if fx < 0 {
				x1, fx = 0, 0
			}
			dx := fx - float64(x1)
			x2 := x1 + 1
			if x2 >= cw {
				x2 = cw - 1
			}
			var c [3]float64
			for i, p := range [4]struct {
				x, y int
				w    float64
			}{{x1, y1, (1 - dx) * (1 - dy)}, {x2, y1, dx * (1 - dy)}, {x1, y2, (1 - dx) * dy}, {x2, y2, dx * dy}} {
				_ = i
				r, g, bl, _ := img.At(x0+p.x, y0+p.y).RGBA()
				c[0] += float64(r>>8) * p.w
				c[1] += float64(g>>8) * p.w
				c[2] += float64(bl>>8) * p.w
			}
			out.Set(x, y, color.RGBA{uint8(c[0] + 0.5), uint8(c[1] + 0.5), uint8(c[2] + 0.5), 255})
		}
	}
	var buf bytes.Buffer
	if err := png.Encode(&buf, out); err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}

// generateFromReference asks Stable Diffusion for an img2img: the prompt describes the new scene, the reference keeps
// the look. strength is how far the result may move away from the reference (0.3 = nearly the same picture,
// 0.8 = only the colours and the mood stay).
func (s StableDiffusion) generateFromReference(ctx context.Context, prompt, negative string) ([]byte, error) {
	strength := s.Strength
	if strength <= 0 || strength >= 1 {
		strength = 0.6
	}
	var out struct {
		Images []string `json:"images"`
	}
	_, err := doJSON(ctx, http.MethodPost, strings.TrimRight(s.BaseURL, "/")+"/sdapi/v1/img2img", nil, map[string]any{
		"init_images": []string{s.Reference}, "denoising_strength": strength, "resize_mode": 0,
		"prompt": prompt, "negative_prompt": negative, "steps": 25, "width": genWidth, "height": genHeight, "cfg_scale": 7,
	}, &out)
	if err != nil {
		return nil, err
	}
	if len(out.Images) == 0 {
		return nil, fmt.Errorf("stable diffusion returned no images")
	}
	return base64.StdEncoding.DecodeString(out.Images[0])
}

func logRefFallback(err error) {
	log.Printf("media: img2img from the reference failed (%v), making the picture from the text alone", err)
}
