package media

import (
	"log"
	"path/filepath"
	"strings"

	"kuni/internal/config"
)

// ReferencePath is where her reference picture lies ("" = the feature is off). A relative path is inside data_dir.
func ReferencePath(c *config.Config) string {
	p := strings.TrimSpace(c.SDReference)
	if p == "" || strings.EqualFold(p, "off") {
		return ""
	}
	if !filepath.IsAbs(p) {
		p = filepath.Join(c.DataDir, p)
	}
	return p
}

// FromConfig builds the services enabled in config.toml; the rest stay Disabled.
func FromConfig(c *config.Config) Services {
	s := NewDisabled()
	if c.SDEnabled {
		sd := StableDiffusion{BaseURL: c.SDURL, Strength: c.SDReferenceStrength}
		if p := ReferencePath(c); p != "" {
			if ref, err := LoadReference(p); err == nil {
				sd.Reference = ref
			} else {
				log.Printf("media: no reference picture (%v): photos come from the text alone", err)
			}
		}
		s.Images = sd
	}
	if c.STTEnabled {
		s.STT = Whisper{BaseURL: c.STTURL, Model: c.STTModel}
	}
	switch c.TTSBackend {
	case "openai":
		s.TTS = OpenAITTS{BaseURL: c.TTSURL, Key: c.TTSKey, Model: c.TTSModel, Voice: c.TTSVoice}
	case "elevenlabs":
		s.TTS = ElevenLabs{Key: c.TTSKey, VoiceID: c.TTSVoice, Model: c.TTSModel}
	}
	if c.WebSearchEnabled {
		s.Web = WebSearch{URL: c.WebSearchURL, Key: c.WebSearchKey}
	}
	s.Video = FFmpeg{Path: c.FFmpegPath}
	return s
}
