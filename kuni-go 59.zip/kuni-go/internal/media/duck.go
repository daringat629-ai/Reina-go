package media

import (
	"context"
	"fmt"
	"html"
	"io"
	"net/http"
	"net/url"
	"regexp"
	"strings"
	"time"
)

// DuckSearch searches the web without any key through the HTML page of DuckDuckGo (a fallback when no SearXNG is set up).
type DuckSearch struct{ URL string }

var (
	duckLink    = regexp.MustCompile(`(?s)<a[^>]+class="[^"]*result__a[^"]*"[^>]+href="([^"]+)"[^>]*>(.*?)</a>`)
	duckSnippet = regexp.MustCompile(`(?s)<a[^>]+class="[^"]*result__snippet[^"]*"[^>]*>(.*?)</a>`)
	htmlTag     = regexp.MustCompile(`(?s)<[^>]*>`)
)

func (d DuckSearch) Search(ctx context.Context, query string, max int) ([]WebResult, error) {
	base := d.URL
	if base == "" {
		base = "https://html.duckduckgo.com/html/"
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, base+"?q="+url.QueryEscape(query), nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("User-Agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36")
	req.Header.Set("Accept-Language", "ru,en;q=0.8")
	c := &http.Client{Timeout: 20 * time.Second}
	resp, err := c.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(io.LimitReader(resp.Body, 2<<20))
	if resp.StatusCode/100 != 2 {
		return nil, fmt.Errorf("search answered HTTP %d (it may want a captcha: try the browser or set up SearXNG)", resp.StatusCode)
	}
	out := ParseDuck(string(body), max)
	if len(out) == 0 {
		return nil, fmt.Errorf("nothing found, or the search page asked for a captcha")
	}
	return out, nil
}

// ParseDuck extracts results from the HTML of DuckDuckGo.
func ParseDuck(page string, max int) []WebResult {
	links := duckLink.FindAllStringSubmatch(page, -1)
	snips := duckSnippet.FindAllStringSubmatch(page, -1)
	var out []WebResult
	for i, m := range links {
		href := html.UnescapeString(m[1])
		if u, err := url.Parse(href); err == nil {
			if t := u.Query().Get("uddg"); t != "" { // //duckduckgo.com/l/?uddg=<real address>
				href = t
			}
		}
		if strings.HasPrefix(href, "//") {
			href = "https:" + href
		}
		if !strings.HasPrefix(href, "http") || strings.Contains(href, "duckduckgo.com/y.js") { // ads
			continue
		}
		r := WebResult{Title: clean(m[2]), URL: href}
		if i < len(snips) {
			r.Content = clean(snips[i][1])
		}
		out = append(out, r)
		if max > 0 && len(out) >= max {
			break
		}
	}
	return out
}

func clean(s string) string {
	return strings.Join(strings.Fields(html.UnescapeString(htmlTag.ReplaceAllString(s, ""))), " ")
}
