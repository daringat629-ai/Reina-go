package media

import (
	"context"
	"encoding/base64"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestWhisperUploadsMultipart(t *testing.T) {
	var ctype, model string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		ctype = r.Header.Get("Content-Type")
		r.ParseMultipartForm(1 << 20)
		model = r.FormValue("model")
		if f, _, err := r.FormFile("file"); err != nil || f == nil {
			t.Errorf("no file part: %v", err)
		}
		io.WriteString(w, `{"text":" hello there "}`)
	}))
	defer srv.Close()
	got, err := Whisper{BaseURL: srv.URL + "/v1/", Model: "whisper-1"}.Transcribe(context.Background(), []byte("OggS"), "voice.ogg")
	if err != nil || got != "hello there" {
		t.Fatalf("got %q err=%v", got, err)
	}
	if !strings.HasPrefix(ctype, "multipart/form-data") || model != "whisper-1" {
		t.Fatalf("ctype=%q model=%q", ctype, model)
	}
}

func TestTTSBackends(t *testing.T) {
	var paths []string
	var keys []string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		paths = append(paths, r.URL.Path)
		keys = append(keys, r.Header.Get("xi-api-key")+"|"+r.Header.Get("Authorization"))
		io.WriteString(w, "AUDIO")
	}))
	defer srv.Close()
	a, ext, err := OpenAITTS{BaseURL: srv.URL + "/v1", Key: "k", Model: "tts-1", Voice: "alloy"}.Speak(context.Background(), "hi")
	if err != nil || string(a) != "AUDIO" || ext != "ogg" {
		t.Fatalf("openai tts: %q %q %v", a, ext, err)
	}
	a, ext, err = ElevenLabs{BaseURL: srv.URL + "/v1", Key: "xi", VoiceID: "V1"}.Speak(context.Background(), "hi")
	if err != nil || string(a) != "AUDIO" || ext != "mp3" {
		t.Fatalf("elevenlabs: %q %q %v", a, ext, err)
	}
	if paths[0] != "/v1/audio/speech" || paths[1] != "/v1/text-to-speech/V1" || !strings.HasPrefix(keys[1], "xi|") {
		t.Fatalf("paths=%v keys=%v", paths, keys)
	}
}

func TestStableDiffusionDecodesBase64(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		var req map[string]any
		json.NewDecoder(r.Body).Decode(&req)
		if req["prompt"] != "cat" || req["negative_prompt"] != "dog" {
			t.Errorf("bad request %v", req)
		}
		json.NewEncoder(w).Encode(map[string]any{"images": []string{base64.StdEncoding.EncodeToString([]byte("PNGDATA"))}})
	}))
	defer srv.Close()
	img, err := StableDiffusion{BaseURL: srv.URL}.Generate(context.Background(), "cat", "dog")
	if err != nil || string(img) != "PNGDATA" {
		t.Fatalf("got %q err=%v", img, err)
	}
}

func TestWebSearchBothFlavours(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodGet {
			if r.URL.Query().Get("q") != "weather moscow" || r.URL.Query().Get("format") != "json" {
				t.Errorf("bad searx query %v", r.URL.RawQuery)
			}
		}
		io.WriteString(w, `{"results":[{"title":"A","url":"http://a","content":"x"},{"title":"B","url":"http://b","content":"y"}]}`)
	}))
	defer srv.Close()
	res, err := WebSearch{URL: srv.URL + "/search"}.Search(context.Background(), "weather moscow", 1)
	if err != nil || len(res) != 1 || res[0].Title != "A" {
		t.Fatalf("searx: %+v %v", res, err)
	}
}

func TestDisabledServices(t *testing.T) {
	s := NewDisabled()
	if _, err := s.STT.Transcribe(context.Background(), nil, "x"); err != ErrDisabled {
		t.Fatalf("got %v", err)
	}
	if _, _, err := s.TTS.Speak(context.Background(), "x"); err != ErrDisabled {
		t.Fatalf("got %v", err)
	}
}
