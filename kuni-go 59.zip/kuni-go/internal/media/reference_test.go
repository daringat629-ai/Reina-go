package media

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"image"
	"image/color"
	"image/png"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"kuni/internal/config"
)

func TestBuiltInReferenceIsAValidPicture(t *testing.T) {
	b, err := prepareReference(defaultReference)
	if err != nil {
		t.Fatal(err)
	}
	img, err := png.Decode(bytes.NewReader(b))
	if err != nil || img.Bounds().Dx() != genWidth || img.Bounds().Dy() != genHeight {
		t.Fatalf("%v %v", img.Bounds(), err)
	}
}

func TestPrepareCropsToThePortraitFrameWithoutStretching(t *testing.T) {
	// a wide picture: left half red, right half blue. A 2:3 crop of the middle keeps both halves at the same width.
	src := image.NewRGBA(image.Rect(0, 0, 1200, 1000))
	for x := 0; x < 1200; x++ {
		for y := 0; y < 1000; y++ {
			if x < 600 {
				src.Set(x, y, color.RGBA{255, 0, 0, 255})
			} else {
				src.Set(x, y, color.RGBA{0, 0, 255, 255})
			}
		}
	}
	var in bytes.Buffer
	png.Encode(&in, src)
	out, err := prepareReference(in.Bytes())
	if err != nil {
		t.Fatal(err)
	}
	img, _ := png.Decode(bytes.NewReader(out))
	r1, _, b1, _ := img.At(10, 400).RGBA()
	r2, _, b2, _ := img.At(genWidth-10, 400).RGBA()
	if r1>>8 < 200 || b1>>8 > 50 || b2>>8 < 200 || r2>>8 > 50 {
		t.Fatalf("the halves are not where they should be: left %d/%d right %d/%d", r1>>8, b1>>8, r2>>8, b2>>8)
	}
	if _, err := prepareReference([]byte("not a picture")); err == nil {
		t.Fatal("garbage accepted")
	}
	tiny := image.NewRGBA(image.Rect(0, 0, 10, 10))
	var tb bytes.Buffer
	png.Encode(&tb, tiny)
	if _, err := prepareReference(tb.Bytes()); err == nil {
		t.Fatal("a tiny picture accepted")
	}
}

func TestSeedNeverOverwritesTheOwnersFile(t *testing.T) {
	dir := t.TempDir()
	p := filepath.Join(dir, "sub", "reference.jpg")
	if err := SeedReference(p); err != nil {
		t.Fatal(err)
	}
	if st, err := os.Stat(p); err != nil || st.Size() != int64(len(defaultReference)) {
		t.Fatal("not seeded", err)
	}
	os.WriteFile(p, []byte("mine"), 0o644)
	if err := SeedReference(p); err != nil {
		t.Fatal(err)
	}
	if raw, _ := os.ReadFile(p); string(raw) != "mine" {
		t.Fatal("the owner's file was overwritten")
	}
	if err := SeedReference(""); err != nil {
		t.Fatal(err)
	}
}

func TestLoadReferenceIsCachedUntilTheFileChanges(t *testing.T) {
	p := filepath.Join(t.TempDir(), "r.jpg")
	os.WriteFile(p, defaultReference, 0o644)
	a, err := LoadReference(p)
	if err != nil {
		t.Fatal(err)
	}
	b, _ := LoadReference(p)
	if a != b {
		t.Fatal("same file, different result")
	}
	// a new picture with a new modification time
	img := image.NewRGBA(image.Rect(0, 0, 200, 300))
	var buf bytes.Buffer
	png.Encode(&buf, img)
	os.WriteFile(p, buf.Bytes(), 0o644)
	future := time.Now().Add(time.Hour)
	os.Chtimes(p, future, future)
	c, err := LoadReference(p)
	if err != nil || c == a {
		t.Fatal("the change was not noticed", err)
	}
	if _, err := LoadReference(filepath.Join(t.TempDir(), "missing.jpg")); err == nil {
		t.Fatal("missing file accepted")
	}
}

func TestGenerateUsesImg2ImgWithTheReferenceAndFallsBackToTxt2Img(t *testing.T) {
	var paths []string
	var last map[string]any
	failImg2img := false
	png1 := base64.StdEncoding.EncodeToString([]byte("PNGDATA"))
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		raw, _ := io.ReadAll(r.Body)
		paths = append(paths, r.URL.Path)
		last = nil
		_ = json.Unmarshal(raw, &last)
		if r.URL.Path == "/sdapi/v1/img2img" && failImg2img {
			http.Error(w, "no", 500)
			return
		}
		w.Write([]byte(`{"images":["` + png1 + `"]}`))
	}))
	defer srv.Close()
	ref, _ := LoadReference(writeRef(t))
	sd := StableDiffusion{BaseURL: srv.URL, Reference: ref, Strength: 0.5}
	img, err := sd.Generate(t.Context(), "selfie", "ugly")
	if err != nil || string(img) != "PNGDATA" {
		t.Fatal(string(img), err)
	}
	if paths[0] != "/sdapi/v1/img2img" || last["denoising_strength"] != 0.5 || last["prompt"] != "selfie" ||
		len(last["init_images"].([]any)) != 1 || last["width"] != float64(512) || last["height"] != float64(768) {
		t.Fatalf("%v %v", paths, last)
	}
	// img2img fails: a photo from the text still arrives
	failImg2img = true
	paths = nil
	if img, err = sd.Generate(t.Context(), "selfie", ""); err != nil || string(img) != "PNGDATA" {
		t.Fatal(err)
	}
	if len(paths) != 2 || paths[1] != "/sdapi/v1/txt2img" {
		t.Fatalf("no fallback: %v", paths)
	}
	// without a reference: text only, no img2img at all
	paths = nil
	if _, err := (StableDiffusion{BaseURL: srv.URL}).Generate(t.Context(), "x", ""); err != nil || len(paths) != 1 || paths[0] != "/sdapi/v1/txt2img" {
		t.Fatalf("%v %v", paths, err)
	}
	// a silly strength falls back to the default
	failImg2img = false
	(StableDiffusion{BaseURL: srv.URL, Reference: ref, Strength: 5}).Generate(t.Context(), "x", "")
	if last["denoising_strength"] != 0.6 {
		t.Fatal(last["denoising_strength"])
	}
}

func writeRef(t *testing.T) string {
	p := filepath.Join(t.TempDir(), "r.jpg")
	os.WriteFile(p, defaultReference, 0o644)
	return p
}

func TestFromConfigWiresTheReference(t *testing.T) {
	dir := t.TempDir()
	c := &config.Config{SDEnabled: true, SDURL: "http://x", DataDir: dir, SDReference: "reference.jpg", SDReferenceStrength: 0.7}
	if got := ReferencePath(c); got != filepath.Join(dir, "reference.jpg") {
		t.Fatal(got)
	}
	if sd := FromConfig(c).Images.(StableDiffusion); sd.Reference != "" {
		t.Fatal("no file yet, there must be no reference")
	}
	SeedReference(ReferencePath(c))
	sd := FromConfig(c).Images.(StableDiffusion)
	if sd.Reference == "" || sd.Strength != 0.7 {
		t.Fatalf("%+v", sd.Strength)
	}
	c.SDReference = "off"
	if ReferencePath(c) != "" || FromConfig(c).Images.(StableDiffusion).Reference != "" {
		t.Fatal("off must switch it off")
	}
	c.SDReference = "/abs/path.jpg"
	if !strings.HasPrefix(ReferencePath(c), "/abs/") {
		t.Fatal(ReferencePath(c))
	}
}
