package media

import (
	"context"
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

const duckPage = `<div class="result"><h2 class="result__title"><a rel="nofollow" class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fexample.org%2Fcats%3Fa%3D1&amp;rut=abc">Всё про <b>кошек</b></a></h2>
<a class="result__snippet" href="//duckduckgo.com/l/?uddg=x">Кошки &amp; коты: <b>описание</b></a></div>
<div class="result"><a class="result__a" href="https://duckduckgo.com/y.js?ad_provider=bing">Реклама</a></div>
<div class="result"><a class="result__a" href="https://direct.test/page">Прямая ссылка</a><a class="result__snippet" href="x">второй текст</a></div>`

func TestParseDuckAndSearch(t *testing.T) {
	rs := ParseDuck(duckPage, 10)
	if len(rs) != 2 {
		t.Fatalf("ads must be skipped: %+v", rs)
	}
	if rs[0].URL != "https://example.org/cats?a=1" || rs[0].Title != "Всё про кошек" || rs[0].Content != "Кошки & коты: описание" {
		t.Fatalf("%+v", rs[0])
	}
	if rs[1].URL != "https://direct.test/page" {
		t.Fatalf("%+v", rs[1])
	}
	var q string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		q = r.URL.Query().Get("q")
		if q == "captcha" {
			fmt.Fprint(w, "<html>please solve</html>")
			return
		}
		_, _ = w.Write([]byte(duckPage))
	}))
	defer srv.Close()
	out, err := DuckSearch{URL: srv.URL}.Search(context.Background(), "коты и кошки", 1)
	if err != nil || len(out) != 1 || q != "коты и кошки" {
		t.Fatalf("%v %v %q", out, err, q)
	}
	if _, err := (DuckSearch{URL: srv.URL}).Search(context.Background(), "captcha", 3); err == nil || !strings.Contains(err.Error(), "captcha") {
		t.Fatalf("an empty page must say so: %v", err)
	}
}
