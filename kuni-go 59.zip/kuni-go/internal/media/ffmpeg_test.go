package media

import (
	"context"
	"os"
	"os/exec"
	"path/filepath"
	"testing"
)

// TestFFmpegFramesAndAudio runs against a real ffmpeg when it is installed.
func TestFFmpegFramesAndAudio(t *testing.T) {
	if _, err := exec.LookPath("ffmpeg"); err != nil {
		t.Skip("ffmpeg not installed")
	}
	dir := t.TempDir()
	path := filepath.Join(dir, "t.mp4")
	if out, err := exec.Command("ffmpeg", "-loglevel", "error", "-f", "lavfi", "-i", "testsrc=duration=6:size=320x240:rate=10",
		"-f", "lavfi", "-i", "sine=frequency=440:duration=6", "-shortest", "-pix_fmt", "yuv420p", path).CombinedOutput(); err != nil {
		t.Fatalf("can't make test video: %v %s", err, out)
	}
	video, _ := os.ReadFile(path)
	f := FFmpeg{}
	frames, err := f.Frames(context.Background(), video, 3)
	if err != nil || len(frames) != 3 {
		t.Fatalf("frames: %d err=%v", len(frames), err)
	}
	if len(frames[0]) < 4 || frames[0][0] != 0xFF || frames[0][1] != 0xD8 {
		t.Fatalf("frame is not a JPEG")
	}
	wav, err := f.Audio(context.Background(), video)
	if err != nil || len(wav) < 1000 || string(wav[:4]) != "RIFF" {
		t.Fatalf("audio: %d bytes err=%v", len(wav), err)
	}
}
