//go:build windows

package sched

func DiskFree(path string) (total, free int64, ok bool) { return 0, 0, false }
