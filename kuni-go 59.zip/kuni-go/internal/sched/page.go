package sched

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"strings"
	"time"

	"kuni/internal/netinfo"
	"kuni/internal/web"
)

// Page and certificate monitors: "tell me when the price changes", "when it is back in stock", "before the
// certificate of my site expires".

// pageArg splits "url | phrase".
func pageArg(arg string) (url, phrase string) {
	u, p, ok := strings.Cut(arg, "|")
	if !ok {
		return strings.TrimSpace(arg), ""
	}
	return strings.TrimSpace(u), strings.TrimSpace(p)
}

func fetchPage(ctx context.Context, u string) (string, error) {
	ctx, cancel := context.WithTimeout(ctx, 40*time.Second)
	defer cancel()
	p, err := web.Fetcher{Timeout: 30 * time.Second}.Fetch(ctx, u)
	if err != nil {
		return "", err
	}
	return p.Title + "\n" + p.Text, nil
}

// lines is the page text as non-empty lines with single spaces.
func lines(text string) []string {
	var out []string
	for _, l := range strings.Split(text, "\n") {
		if l = strings.Join(strings.Fields(l), " "); l != "" {
			out = append(out, l)
		}
	}
	return out
}

const pageKeep = 20000 // characters of the page kept to tell what changed

func pageCheck(ctx context.Context, m Monitor, fetch func(context.Context, string) (string, error)) Result {
	u, phrase := pageArg(m.Arg)
	if !strings.Contains(u, "://") {
		u = "https://" + u
	}
	text, err := fetch(ctx, u)
	if err != nil {
		return Result{Bad: true, Detail: u + " не открывается: " + err.Error()}
	}
	switch m.Kind {
	case "page_contains", "page_lacks":
		has := strings.Contains(strings.ToLower(strings.Join(lines(text), " ")), strings.ToLower(strings.Join(strings.Fields(phrase), " ")))
		if m.Kind == "page_contains" {
			if has {
				return Result{Bad: true, Detail: fmt.Sprintf("на %s появилось «%s»", u, phrase)}
			}
			return Result{Detail: fmt.Sprintf("на %s больше нет «%s»", u, phrase)}
		}
		if !has {
			return Result{Bad: true, Detail: fmt.Sprintf("на %s пропало «%s»", u, phrase)}
		}
		return Result{Detail: fmt.Sprintf("на %s снова есть «%s»", u, phrase)}
	}
	ls := lines(text)
	body := strings.Join(ls, "\n")
	if len(body) > pageKeep {
		body = body[:pageKeep]
	}
	sum := sha256.Sum256([]byte(strings.Join(ls, "\n")))
	state := hex.EncodeToString(sum[:8]) + "\n" + body
	oldHash, oldBody, _ := strings.Cut(m.State, "\n")
	if m.State == "" || oldHash == hex.EncodeToString(sum[:8]) {
		return Result{State: state} // the first look, or nothing new
	}
	before := map[string]bool{}
	for _, l := range strings.Split(oldBody, "\n") {
		before[l] = true
	}
	now := map[string]bool{}
	var added, removed []string
	for _, l := range ls {
		now[l] = true
		if !before[l] && len(added) < 6 {
			added = append(added, clip(l, 160))
		}
	}
	for _, l := range strings.Split(oldBody, "\n") {
		if l != "" && !now[l] && len(removed) < 3 {
			removed = append(removed, clip(l, 120))
		}
	}
	detail := "страница " + u + " изменилась"
	if len(added) > 0 {
		detail += "; новое: «" + strings.Join(added, "» «") + "»"
	}
	if len(removed) > 0 {
		detail += "; пропало: «" + strings.Join(removed, "» «") + "»"
	}
	return Result{Event: true, Detail: detail, State: state}
}

func clip(s string, n int) string {
	if r := []rune(s); len(r) > n {
		return string(r[:n]) + "…"
	}
	return s
}

func certCheck(ctx context.Context, m Monitor, now time.Time) Result {
	ctx, cancel := context.WithTimeout(ctx, 30*time.Second)
	defer cancel()
	c, err := netinfo.CertOf(ctx, m.Arg, nil)
	if err != nil {
		return Result{Bad: true, Detail: "не проверить сертификат " + m.Arg + ": " + err.Error()}
	}
	left := c.DaysLeft(now)
	switch {
	case c.VerifyErr != "":
		return Result{Bad: true, Detail: fmt.Sprintf("сертификат %s не доверенный: %s", c.Host, c.VerifyErr)}
	case float64(left) < m.Limit:
		return Result{Bad: true, Detail: fmt.Sprintf("сертификат %s истекает через %d дн. (%s), предел %g", c.Host, left, c.NotAfter.Format("2006-01-02"), m.Limit)}
	}
	return Result{Detail: fmt.Sprintf("сертификат %s в порядке: ещё %d дн.", c.Host, left)}
}
