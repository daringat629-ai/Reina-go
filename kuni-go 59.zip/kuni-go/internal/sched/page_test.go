package sched

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestPageMonitors(t *testing.T) {
	ctx := context.Background()
	page := "Товар\nЦена: 1200 сом\nНет в наличии"
	fetch := func(context.Context, string) (string, error) { return page, nil }
	m := Monitor{Kind: "page_change", Arg: "shop.example/item"}
	r := pageCheck(ctx, m, fetch)
	if r.Event || r.Bad || r.State == "" {
		t.Fatalf("the first look only remembers: %+v", r)
	}
	m.State = r.State
	if r := pageCheck(ctx, m, fetch); r.Event {
		t.Fatal("nothing changed")
	}
	page = "Товар\nЦена: 990 сом\nВ наличии"
	r = pageCheck(ctx, m, fetch)
	if !r.Event || !strings.Contains(r.Detail, "990") || !strings.Contains(r.Detail, "Нет в наличии") {
		t.Fatalf("change: %+v", r)
	}
	lacks := Monitor{Kind: "page_lacks", Arg: "shop.example/item | нет в наличии"}
	if r := pageCheck(ctx, lacks, fetch); !r.Bad {
		t.Fatalf("the phrase is gone: %+v", r)
	}
	contains := Monitor{Kind: "page_contains", Arg: "shop.example/item | в наличии"}
	if r := pageCheck(ctx, contains, fetch); !r.Bad {
		t.Fatalf("the phrase appeared: %+v", r)
	}
	broken := func(context.Context, string) (string, error) { return "", errors.New("timeout") }
	if r := pageCheck(ctx, m, broken); !r.Bad || r.Event {
		t.Fatalf("a page that does not open: %+v", r)
	}
}

// A page change is told each time, and never leaves the monitor "down".
func TestPageChangeAlerts(t *testing.T) {
	s := New(filepath.Join(t.TempDir(), "s.json"), time.UTC)
	now := time.Now()
	m, err := s.AddMonitor(Monitor{Chat: 1, Kind: "page_change", Arg: "example.org"}, now)
	if err != nil || m.EveryMin != 30 {
		t.Fatal(m, err)
	}
	n := 0
	check := func(context.Context, Monitor) Result {
		n++
		if n == 1 {
			return Result{State: "a"}
		}
		return Result{Event: true, Detail: "changed", State: "b"}
	}
	if al := s.CheckDue(context.Background(), now, check); len(al) != 0 {
		t.Fatal(al)
	}
	al := s.CheckDue(context.Background(), now.Add(31*time.Minute), check)
	if len(al) != 1 || !al[0].Changed || al[0].Monitor.Down || s.Monitors()[0].State != "b" {
		t.Fatalf("%+v %+v", al, s.Monitors())
	}
	if _, err := s.AddMonitor(Monitor{Kind: "page_contains", Arg: "example.org"}, now); err == nil {
		t.Fatal("page_contains needs a phrase")
	}
}

func TestCertMonitor(t *testing.T) {
	srv := httptest.NewTLSServer(http.HandlerFunc(func(http.ResponseWriter, *http.Request) {}))
	defer srv.Close()
	host := strings.TrimPrefix(srv.URL, "https://")
	m := Monitor{Kind: "cert_expiry", Arg: host, Limit: 14}
	r := certCheck(context.Background(), m, time.Now())
	if !r.Bad || !strings.Contains(r.Detail, "не доверенный") {
		t.Fatalf("the test server's certificate is not trusted: %+v", r)
	}
}
