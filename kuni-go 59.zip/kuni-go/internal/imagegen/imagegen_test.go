package imagegen

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"testing"
	"time"

	"kuni/internal/llm"
	"kuni/internal/media"
	"kuni/internal/prompts"
)

type fakeSD struct {
	mu   sync.Mutex
	negs []string
}

func (f *fakeSD) Generate(_ context.Context, p, n string) ([]byte, error) {
	f.mu.Lock()
	f.negs = append(f.negs, n)
	f.mu.Unlock()
	return []byte("IMG"), nil
}

func gen(t *testing.T, criticVerdicts []bool) (*Generator, *fakeSD, *int) {
	calls := 0
	verdict := 0
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		var req struct {
			Messages []llm.Message `json:"messages"`
		}
		json.NewDecoder(r.Body).Decode(&req)
		system := req.Messages[0].Content
		var content string
		if strings.Contains(system, "quality gate") {
			ok := criticVerdicts[min(verdict, len(criticVerdicts)-1)]
			verdict++
			b, _ := json.Marshal(map[string]any{"satisfied": ok, "feedback": "hands look wrong"})
			content = "```json\n" + string(b) + "\n```"
		} else {
			calls++
			content = `{"positivePrompt":"1girl, (smile:1.2)","negativePrompt":"bad hands"}`
		}
		json.NewEncoder(w).Encode(map[string]any{"choices": []any{map[string]any{"message": map[string]any{"role": "assistant", "content": content}}}})
	}))
	t.Cleanup(srv.Close)
	ps, err := prompts.NewStore(t.TempDir(), prompts.Vars{CharacterName: "Kuni"})
	if err != nil {
		t.Fatal(err)
	}
	sd := &fakeSD{}
	svc := media.NewDisabled()
	svc.Images = sd
	return &Generator{LLM: llm.New(srv.URL+"/", srv.URL+"/", "", "m", "e", 5*time.Second), Prompts: ps,
		Media: func() media.Services { return svc }, CharacterName: func() string { return "Kuni" }, Trials: 4}, sd, &calls
}

func TestRetriesUntilCriticIsSatisfied(t *testing.T) {
	g, sd, engineered := gen(t, []bool{false, false, true})
	img, err := g.Generate(context.Background(), "selfie in a park")
	if err != nil || string(img) != "IMG" {
		t.Fatalf("got %q err=%v", img, err)
	}
	if *engineered != 3 || len(sd.negs) != 3 {
		t.Fatalf("expected 3 engineering rounds and 3 SD calls, got %d / %d", *engineered, len(sd.negs))
	}
	for _, n := range sd.negs {
		if !strings.Contains(n, "child") {
			t.Fatalf("negative prompt must always forbid children: %q", n)
		}
	}
}

func TestGivesUpWithFirstFeedback(t *testing.T) {
	g, _, _ := gen(t, []bool{false})
	_, err := g.Generate(context.Background(), "x")
	if err == nil || !strings.Contains(err.Error(), "hands look wrong") {
		t.Fatalf("got %v", err)
	}
}

func TestDisabledSDReturnsClearError(t *testing.T) {
	g, _, _ := gen(t, []bool{true})
	g.Media = func() media.Services { return media.NewDisabled() }
	if _, err := g.Generate(context.Background(), "x"); err != media.ErrDisabled {
		t.Fatalf("got %v", err)
	}
}

func TestSanitizeStripsBannedWords(t *testing.T) {
	if got := sanitize("a girl, nsfw, in a park"); strings.Contains(got, "nsfw") {
		t.Fatalf("got %q", got)
	}
}

func TestParseJSONFromFencedAnswer(t *testing.T) {
	var v struct{ A int }
	if err := ParseJSON("sure!\n```json\n{\"A\": 5}\n```", &v); err != nil || v.A != 5 {
		t.Fatalf("%+v %v", v, err)
	}
	if err := ParseJSON("no json", &v); err == nil {
		t.Fatal("want error")
	}
}
