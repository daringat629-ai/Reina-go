// Package imagegen is the photo pipeline from ImageGenerator.cpp:
// LLM "prompt engineer" -> Stable Diffusion -> LLM vision critic, retried until
// the critic is satisfied or the trial budget is exhausted.
package imagegen

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"strings"

	"kuni/internal/llm"
	"kuni/internal/llmui"
	"kuni/internal/media"
	"kuni/internal/prompts"
)

// BannedWords are stripped from user-supplied descriptions before they reach the prompt engineer.
var BannedWords = []string{"explicit nudity", "explicit nude", "explicit erotic", "nsfw", "genital"}

// Generator holds the dependencies of the pipeline.
type Generator struct {
	LLM           *llm.Client
	Prompts       *prompts.Store
	Media         func() media.Services
	CharacterName func() string
	Trials        int // 0 = default (6)
}

type pair struct{ Positive, Negative string }

// ParseJSON extracts the first JSON object from an LLM answer (handles ``` fences).
func ParseJSON(s string, out any) error {
	start, end := strings.Index(s, "{"), strings.LastIndex(s, "}")
	if start < 0 || end < start {
		return errors.New("no JSON object in answer")
	}
	return json.Unmarshal([]byte(s[start:end+1]), out)
}

func sanitize(desc string) string {
	for _, w := range BannedWords {
		desc = strings.ReplaceAll(strings.ReplaceAll(desc, w, ""), strings.ToUpper(w), "")
	}
	return strings.TrimSpace(desc)
}

func (g *Generator) engineer(ctx context.Context, desc string, prev pair, feedback string) (pair, error) {
	system := prompts.Format(g.Prompts.Get(prompts.ImageEngineerSystem), map[string]string{
		"CHARACTER_NAME":              g.CharacterName(),
		"CHARACTER_APPEARANCE_PROMPT": g.Prompts.Get(prompts.CharacterAppearance),
		"SANITIZED_PHOTO_DESCRIPTION": sanitize(desc),
	})
	var msg strings.Builder
	msg.WriteString("# Previous prompt iteration \nPositive prompt: " + prev.Positive + "\n\nNegative prompt: " + prev.Negative + "\n\n")
	if feedback != "" {
		msg.WriteString("# Feedback to previous prompt iteration\n" + feedback + "\n")
	}
	msg.WriteString("\n" + g.Prompts.Get(prompts.ImageEngineerInstructions) + "\nGenerate SD prompt:")
	history := []llm.Message{{Role: "user", Content: msg.String()}}

	for attempt := 0; attempt < 3; attempt++ {
		answer, err := g.LLM.Chat(llm.WithPurpose(ctx, "image"), system, history)
		if err != nil {
			return pair{}, err
		}
		var j struct {
			Positive string `json:"positivePrompt"`
			Negative string `json:"negativePrompt"`
		}
		if err := ParseJSON(answer, &j); err != nil {
			continue
		}
		// long prompts distort the character's base design: ask for a shorter one.
		if strings.Count(j.Positive, " ") > 60 || strings.Count(j.Negative, " ") > 60 {
			history = append(history, llm.Message{Role: "assistant", Content: answer},
				llm.Message{Role: "user", Content: "Adjusted prompt is too long. Shorten it to 50 words or less; restructure or adjust word (weights:1.5) instead"})
			continue
		}
		// the character must never be rendered as a child.
		j.Negative += " child"
		return pair{j.Positive, j.Negative}, nil
	}
	return pair{}, errors.New("prompt engineer did not return a usable prompt")
}

type assessment struct {
	Satisfied bool   `json:"satisfied"`
	Feedback  string `json:"feedback"`
}

func (g *Generator) assess(ctx context.Context, img []byte, desc string) (assessment, error) {
	system := g.Prompts.Get(prompts.ImageAssessSystem) + desc + "\nThe character(s) must not appear as child"
	msg := llm.Message{Role: "user", Parts: []llm.Part{
		{Type: "text", Text: "Assess this image:"},
		{Type: "image_url", ImageURL: llmui.DataURL(img)},
	}}
	answer, err := g.LLM.Chat(llm.WithPurpose(ctx, "image"), system, []llm.Message{msg})
	if err != nil {
		return assessment{}, err
	}
	var a assessment
	if err := ParseJSON(answer, &a); err != nil {
		return assessment{Satisfied: false}, nil // unparsable critic answer = not satisfied
	}
	return a, nil
}

// Generate produces an image for description; it returns the critic's first complaint on failure.
func (g *Generator) Generate(ctx context.Context, description string) ([]byte, error) {
	svc := g.Media()
	trials := g.Trials
	if trials <= 0 {
		trials = 6
	}
	full := "<character name=\"" + g.CharacterName() + "\" canonical_description>\n" + g.Prompts.Get(prompts.CharacterAppearance) +
		"\n</character canonical_description>\n<user_description overrides_canonical=\"true\">\n" + description + "\n</user_description overrides_canonical=\"true\">"
	var prompt pair
	var feedback, firstFeedback string
	for i := 0; i < trials && ctx.Err() == nil; i++ {
		var err error
		prompt, err = g.engineer(ctx, description, prompt, feedback)
		if err != nil {
			log.Printf("imagegen: engineer: %v", err)
			continue
		}
		img, err := svc.Images.Generate(ctx, prompt.Positive, prompt.Negative)
		if err != nil {
			if errors.Is(err, media.ErrDisabled) {
				return nil, err
			}
			log.Printf("imagegen: sd: %v", err)
			continue
		}
		a, err := g.assess(ctx, img, full)
		if err != nil {
			log.Printf("imagegen: assess: %v", err)
			continue
		}
		if a.Satisfied {
			return img, nil
		}
		if firstFeedback == "" {
			firstFeedback = a.Feedback
		}
		feedback = a.Feedback
	}
	return nil, fmt.Errorf("can't find image: feedback: %q; make photo_desc shorter", firstFeedback)
}
