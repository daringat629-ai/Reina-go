package period

import (
	"testing"
	"time"
)

func TestDay(t *testing.T) {
	loc, _ := time.LoadLocation("Asia/Bishkek")
	now := time.Date(2026, 10, 23, 15, 0, 0, 0, loc) // a Friday
	cases := []struct {
		in   string
		past bool
		want string
	}{
		{"", true, "2026-10-23"}, {"вчера", true, "2026-10-22"}, {"позавчера", true, "2026-10-21"}, {"завтра", false, "2026-10-24"},
		{"2026-01-05", true, "2026-01-05"}, {"05.01.2026", true, "2026-01-05"}, {"5.1.26", true, "2026-01-05"},
		{"12.12", true, "2025-12-12"}, {"12.12", false, "2026-12-12"}, {"12 марта", false, "2027-03-12"}, {"12 марта 1990", true, "1990-03-12"},
		{"в понедельник", true, "2026-10-19"}, {"понедельник", false, "2026-10-26"}, {"пятница", true, "2026-10-23"},
		{"3 дня назад", true, "2026-10-20"},
	}
	for _, c := range cases {
		got, err := Day(c.in, now, c.past)
		if err != nil || got.Format(Layout) != c.want {
			t.Errorf("Day(%q, past=%v) = %v %v, want %s", c.in, c.past, got.Format(Layout), err, c.want)
		}
	}
	for _, bad := range []string{"31.02.2026", "когда-нибудь", "2026-13-01"} {
		if _, err := Day(bad, now, true); err == nil {
			t.Errorf("%q must be an error", bad)
		}
	}
}

func TestRange(t *testing.T) {
	now := time.Date(2026, 10, 23, 15, 0, 0, 0, time.UTC)
	cases := map[string][2]string{
		"today": {"2026-10-23", "2026-10-23"}, "неделя": {"2026-10-17", "2026-10-23"}, "эта неделя": {"2026-10-19", "2026-10-23"},
		"прошлая неделя": {"2026-10-12", "2026-10-18"}, "месяц": {"2026-10-01", "2026-10-23"}, "прошлый месяц": {"2026-09-01", "2026-09-30"},
		"year": {"2026-01-01", "2026-10-23"}, "30d": {"2026-09-24", "2026-10-23"}, "2026-02": {"2026-02-01", "2026-02-28"},
		"02.2024": {"2024-02-01", "2024-02-29"}, "2025": {"2025-01-01", "2025-12-31"}, "ноябрь": {"2025-11-01", "2025-11-30"},
		"2026-10-01..2026-10-15": {"2026-10-01", "2026-10-15"}, "с 01.10 по 05.10": {"2026-10-01", "2026-10-05"}, "вчера": {"2026-10-22", "2026-10-22"},
	}
	for in, want := range cases {
		a, b, _, err := Range(in, now)
		if err != nil || a.Format(Layout) != want[0] || b.Format(Layout) != want[1] {
			t.Errorf("Range(%q) = %s..%s %v, want %v", in, a.Format(Layout), b.Format(Layout), err, want)
		}
	}
	if _, _, _, err := Range("когда-то", now); err == nil {
		t.Error("nonsense must be an error")
	}
}
