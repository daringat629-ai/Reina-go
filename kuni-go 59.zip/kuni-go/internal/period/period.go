// Package period reads the dates and periods people say ("вчера", "12.03", "прошлый месяц", "2026-10-01..2026-10-15")
// into calendar days of the owner's zone. Tools that keep a diary of money, habits or dates share it, so "за неделю"
// means the same everywhere.
package period

import (
	"fmt"
	"regexp"
	"strconv"
	"strings"
	"time"
)

// Layout is the form of a day.
const Layout = "2006-01-02"

func midnight(t time.Time) time.Time {
	return time.Date(t.Year(), t.Month(), t.Day(), 0, 0, 0, 0, t.Location())
}

var (
	reISO    = regexp.MustCompile(`^(\d{4})-(\d{1,2})-(\d{1,2})$`)
	reRu     = regexp.MustCompile(`^(\d{1,2})[./](\d{1,2})(?:[./](\d{2,4}))?$`)
	reAgo    = regexp.MustCompile(`^(\d{1,4})\s*(d|д|day|days|день|дня|дней)\s*(ago|назад)$`)
	reLastN  = regexp.MustCompile(`^(?:last\s*|последние\s*)?(\d{1,4})\s*(d|д|days|дней|дня|день)$`)
	reYear   = regexp.MustCompile(`^(\d{4})$`)
	reMonth  = regexp.MustCompile(`^(\d{4})-(\d{1,2})$`)
	reMonthR = regexp.MustCompile(`^(\d{1,2})[./](\d{4})$`)
)

var weekdays = map[string]time.Weekday{
	"monday": time.Monday, "понедельник": time.Monday, "пн": time.Monday,
	"tuesday": time.Tuesday, "вторник": time.Tuesday, "вт": time.Tuesday,
	"wednesday": time.Wednesday, "среда": time.Wednesday, "среду": time.Wednesday, "ср": time.Wednesday,
	"thursday": time.Thursday, "четверг": time.Thursday, "чт": time.Thursday,
	"friday": time.Friday, "пятница": time.Friday, "пятницу": time.Friday, "пт": time.Friday,
	"saturday": time.Saturday, "суббота": time.Saturday, "субботу": time.Saturday, "сб": time.Saturday,
	"sunday": time.Sunday, "воскресенье": time.Sunday, "вс": time.Sunday,
}

var monthNames = map[string]time.Month{
	"январь": 1, "января": 1, "january": 1, "jan": 1, "янв": 1,
	"февраль": 2, "февраля": 2, "february": 2, "feb": 2, "фев": 2,
	"март": 3, "марта": 3, "march": 3, "mar": 3, "мар": 3,
	"апрель": 4, "апреля": 4, "april": 4, "apr": 4, "апр": 4,
	"май": 5, "мая": 5, "may": 5,
	"июнь": 6, "июня": 6, "june": 6, "jun": 6, "июн": 6,
	"июль": 7, "июля": 7, "july": 7, "jul": 7, "июл": 7,
	"август": 8, "августа": 8, "august": 8, "aug": 8, "авг": 8,
	"сентябрь": 9, "сентября": 9, "september": 9, "sep": 9, "сен": 9,
	"октябрь": 10, "октября": 10, "october": 10, "oct": 10, "окт": 10,
	"ноябрь": 11, "ноября": 11, "november": 11, "nov": 11, "ноя": 11,
	"декабрь": 12, "декабря": 12, "december": 12, "dec": 12, "дек": 12,
}

// Month reads a month name in Russian or English ("марта", "Oct"); 0 when it is not one.
func Month(s string) time.Month { return monthNames[strings.ToLower(strings.TrimSpace(s))] }

func clean(s string) string {
	return strings.Join(strings.Fields(strings.ToLower(strings.TrimSpace(s))), " ")
}

// Day reads one day relative to now (in now's zone). A date without a year, or a weekday, is taken in the past when
// past is true ("в пятницу потратил") and in the future otherwise ("в пятницу встреча").
func Day(spec string, now time.Time, past bool) (time.Time, error) {
	s := clean(spec)
	today := midnight(now)
	s = strings.TrimPrefix(strings.TrimPrefix(s, "в "), "во ")
	switch s {
	case "", "today", "сегодня", "now", "сейчас":
		return today, nil
	case "yesterday", "вчера":
		return today.AddDate(0, 0, -1), nil
	case "позавчера", "day before yesterday":
		return today.AddDate(0, 0, -2), nil
	case "tomorrow", "завтра":
		return today.AddDate(0, 0, 1), nil
	case "послезавтра", "day after tomorrow":
		return today.AddDate(0, 0, 2), nil
	}
	if m := reAgo.FindStringSubmatch(s); m != nil {
		n, _ := strconv.Atoi(m[1])
		return today.AddDate(0, 0, -n), nil
	}
	if wd, ok := weekdays[s]; ok {
		d := today
		for i := 0; i < 7; i++ {
			if past {
				d = today.AddDate(0, 0, -i)
			} else {
				d = today.AddDate(0, 0, i)
			}
			if d.Weekday() == wd {
				break
			}
		}
		return d, nil
	}
	mk := func(y, mo, d int) (time.Time, error) {
		t := time.Date(y, time.Month(mo), d, 0, 0, 0, 0, now.Location())
		if t.Year() != y || int(t.Month()) != mo || t.Day() != d {
			return time.Time{}, fmt.Errorf("no such date: %q", spec)
		}
		return t, nil
	}
	if m := reISO.FindStringSubmatch(s); m != nil {
		y, _ := strconv.Atoi(m[1])
		mo, _ := strconv.Atoi(m[2])
		d, _ := strconv.Atoi(m[3])
		return mk(y, mo, d)
	}
	day, mon, year := 0, 0, 0
	if m := reRu.FindStringSubmatch(s); m != nil {
		day, _ = strconv.Atoi(m[1])
		mon, _ = strconv.Atoi(m[2])
		if m[3] != "" {
			year, _ = strconv.Atoi(m[3])
			if year < 100 {
				year += 2000
			}
		}
	} else if f := strings.Fields(s); len(f) >= 2 && Month(f[1]) != 0 { // "12 марта", "12 марта 1990"
		day, _ = strconv.Atoi(f[0])
		mon = int(Month(f[1]))
		if len(f) >= 3 {
			year, _ = strconv.Atoi(strings.TrimSuffix(strings.TrimSuffix(f[2], "г."), "г"))
		}
	}
	if day > 0 && mon > 0 {
		if year > 0 {
			return mk(year, mon, day)
		}
		t, err := mk(today.Year(), mon, day)
		if err != nil {
			return t, err
		}
		if past && t.After(today) {
			return mk(today.Year()-1, mon, day)
		}
		if !past && t.Before(today) {
			return mk(today.Year()+1, mon, day)
		}
		return t, nil
	}
	return time.Time{}, fmt.Errorf("cannot read the date %q (use YYYY-MM-DD, DD.MM.YYYY, DD.MM, вчера, сегодня...)", spec)
}

// Range reads a period into its first and last day (inclusive) and a name for it.
func Range(spec string, now time.Time) (from, to time.Time, name string, err error) {
	s := clean(spec)
	today := midnight(now)
	monthStart := time.Date(today.Year(), today.Month(), 1, 0, 0, 0, 0, today.Location())
	weekStart := today.AddDate(0, 0, -((int(today.Weekday()) + 6) % 7)) // Monday
	switch s {
	case "today", "сегодня", "day", "день":
		return today, today, "сегодня", nil
	case "yesterday", "вчера":
		y := today.AddDate(0, 0, -1)
		return y, y, "вчера", nil
	case "week", "неделя", "неделю", "за неделю", "7d":
		return today.AddDate(0, 0, -6), today, "последние 7 дней", nil
	case "this_week", "this week", "эта неделя", "эту неделю", "на этой неделе":
		return weekStart, today, "эта неделя", nil
	case "last_week", "last week", "прошлая неделя", "прошлую неделю", "на прошлой неделе":
		return weekStart.AddDate(0, 0, -7), weekStart.AddDate(0, 0, -1), "прошлая неделя", nil
	case "", "month", "месяц", "этот месяц", "за месяц", "this_month", "this month", "в этом месяце":
		return monthStart, today, monthStart.Format("2006-01"), nil
	case "last_month", "last month", "прошлый месяц", "за прошлый месяц", "в прошлом месяце":
		ls := monthStart.AddDate(0, -1, 0)
		return ls, monthStart.AddDate(0, 0, -1), ls.Format("2006-01"), nil
	case "year", "год", "этот год", "за год", "this_year", "this year", "в этом году":
		ys := time.Date(today.Year(), 1, 1, 0, 0, 0, 0, today.Location())
		return ys, today, strconv.Itoa(today.Year()), nil
	case "last_year", "last year", "прошлый год", "в прошлом году":
		ys := time.Date(today.Year()-1, 1, 1, 0, 0, 0, 0, today.Location())
		return ys, ys.AddDate(1, 0, -1), strconv.Itoa(today.Year() - 1), nil
	case "all", "всё", "все", "за всё время", "all time":
		return time.Date(1900, 1, 1, 0, 0, 0, 0, today.Location()), today, "всё время", nil
	}
	if m := reLastN.FindStringSubmatch(s); m != nil {
		n, _ := strconv.Atoi(m[1])
		n = max(n, 1)
		return today.AddDate(0, 0, -(n - 1)), today, fmt.Sprintf("последние %d дн.", n), nil
	}
	if m := reYear.FindStringSubmatch(s); m != nil {
		y, _ := strconv.Atoi(m[1])
		ys := time.Date(y, 1, 1, 0, 0, 0, 0, today.Location())
		return ys, ys.AddDate(1, 0, -1), m[1], nil
	}
	ym := func(y, mo int) (time.Time, time.Time, string, error) {
		if mo < 1 || mo > 12 {
			return time.Time{}, time.Time{}, "", fmt.Errorf("no month %d", mo)
		}
		ms := time.Date(y, time.Month(mo), 1, 0, 0, 0, 0, today.Location())
		return ms, ms.AddDate(0, 1, -1), ms.Format("2006-01"), nil
	}
	if m := reMonth.FindStringSubmatch(s); m != nil {
		y, _ := strconv.Atoi(m[1])
		mo, _ := strconv.Atoi(m[2])
		return ym(y, mo)
	}
	if m := reMonthR.FindStringSubmatch(s); m != nil {
		mo, _ := strconv.Atoi(m[1])
		y, _ := strconv.Atoi(m[2])
		return ym(y, mo)
	}
	if mo := Month(strings.TrimPrefix(strings.TrimPrefix(s, "в "), "за ")); mo != 0 { // "октябрь": the last one
		y := today.Year()
		if mo > today.Month() {
			y--
		}
		return ym(y, int(mo))
	}
	for _, sep := range []string{"..", " - ", " — ", " to ", " по "} {
		if a, b, ok := strings.Cut(s, sep); ok {
			a = strings.TrimPrefix(strings.TrimPrefix(a, "с "), "from ")
			fa, err := Day(a, now, true)
			if err != nil {
				return time.Time{}, time.Time{}, "", err
			}
			fb, err := Day(b, now, true)
			if err != nil {
				return time.Time{}, time.Time{}, "", err
			}
			if fb.Before(fa) {
				fa, fb = fb, fa
			}
			return fa, fb, fa.Format(Layout) + " — " + fb.Format(Layout), nil
		}
	}
	if d, err := Day(s, now, true); err == nil {
		return d, d, d.Format(Layout), nil
	}
	return time.Time{}, time.Time{}, "", fmt.Errorf("cannot read the period %q (today, week, month, last_month, year, 30d, 2026-10, 2026-10-01..2026-10-15, all)", spec)
}
