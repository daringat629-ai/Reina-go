// Package alerts holds the small pieces behind "tell the owner when something is wrong": a throttle so that one
// problem is reported once, and a failure streak that trips after N failures in a row and notices the recovery.
package alerts

import (
	"sync"
	"time"
)

// Gate lets a message with the same key through at most once per interval.
type Gate struct {
	mu   sync.Mutex
	last map[string]time.Time
}

// Allow reports whether key may be sent at now, and remembers that it was.
func (g *Gate) Allow(key string, every time.Duration, now time.Time) bool {
	g.mu.Lock()
	defer g.mu.Unlock()
	if g.last == nil {
		g.last = map[string]time.Time{}
	}
	if t, ok := g.last[key]; ok && now.Sub(t) < every {
		return false
	}
	g.last[key] = now
	return true
}

// Streak counts failures in a row.
type Streak struct {
	Threshold int
	mu        sync.Mutex
	n         int
	tripped   bool
}

// Fail records a failure and returns true exactly once per streak, when it reaches the threshold.
func (s *Streak) Fail() bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.n++
	if s.n >= s.Threshold && !s.tripped {
		s.tripped = true
		return true
	}
	return false
}

// OK records a success and returns true when it ends a streak that had been reported.
func (s *Streak) OK() bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	was := s.tripped
	s.n, s.tripped = 0, false
	return was
}

// Count is the current number of failures in a row.
func (s *Streak) Count() int {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.n
}
