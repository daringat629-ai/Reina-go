package qr

import (
	"bytes"
	"image/png"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
)

// Capacities from the standard's table (data bytes of the code).
func TestCapacities(t *testing.T) {
	want := map[[2]int]int{
		{1, int(L)}: 19, {1, int(M)}: 16, {1, int(Q)}: 13, {1, int(H)}: 9,
		{7, int(M)}: 124, {10, int(Q)}: 154, {20, int(H)}: 385,
		{40, int(L)}: 2956, {40, int(M)}: 2334, {40, int(Q)}: 1666, {40, int(H)}: 1276,
	}
	for k, w := range want {
		if got := DataCodewords(k[0], Level(k[1])); got != w {
			t.Errorf("version %d level %d: %d data bytes, want %d", k[0], k[1], got, w)
		}
	}
}

// The worked example of the standard's tutorial: "HELLO WORLD" at 1-Q.
func TestReedSolomon(t *testing.T) {
	data := []byte{32, 91, 11, 120, 209, 114, 220, 77, 67, 64, 236, 17, 236}
	want := []byte{168, 72, 22, 82, 217, 54, 156, 0, 46, 15, 180, 122, 16}
	if got := rsRemainder(data, rsDivisor(13)); !bytes.Equal(got, want) {
		t.Fatalf("ecc %v, want %v", got, want)
	}
	c, err := Encode("HELLO WORLD", Q)
	if err != nil || c.Version != 1 || c.Level != Q || c.Size != 21 {
		t.Fatalf("%+v %v", c, err)
	}
}

func TestVersionsAndModes(t *testing.T) {
	cases := []struct {
		text string
		l    Level
		ver  int
	}{
		{"01234567", M, 1},                       // numeric
		{"HTTPS://EXAMPLE.COM", M, 1},            // alphanumeric: 19 chars
		{"https://example.com", M, 2},            // bytes
		{strings.Repeat("я", 300), L, 0},         // 600 bytes: some large version
		{"WIFI:T:WPA;S:Дом;P:пароль123;;", H, 0}, // UTF-8
		{strings.Repeat("0", 7089), L, 40},       // the largest numeric code
	}
	for _, cs := range cases {
		c, err := Encode(cs.text, cs.l)
		if err != nil {
			t.Fatalf("%.20q: %v", cs.text, err)
		}
		if cs.ver != 0 && c.Version != cs.ver {
			t.Errorf("%.20q: version %d, want %d", cs.text, c.Version, cs.ver)
		}
		if c.Size != c.Version*4+17 || len(c.Modules) != c.Size {
			t.Errorf("size %d for version %d", c.Size, c.Version)
		}
	}
	if _, err := Encode(strings.Repeat("я", 2000), L); err != ErrTooLong {
		t.Fatalf("want ErrTooLong, got %v", err)
	}
}

func TestPNG(t *testing.T) {
	c, _ := Encode("https://example.com", M)
	img, err := png.Decode(bytes.NewReader(c.PNG(600)))
	if err != nil {
		t.Fatal(err)
	}
	if w := img.Bounds().Dx(); w < 500 || w > 600 {
		t.Fatalf("width %d", w)
	}
	// the top-left module of the finder is dark, the quiet zone light
	if r, _, _, _ := img.At(4*21+2, 4*21+2).RGBA(); r != 0 {
		t.Error("finder corner should be dark")
	}
	if r, _, _, _ := img.At(2, 2).RGBA(); r == 0 {
		t.Error("quiet zone should be light")
	}
}

// When OpenCV is at hand (python3 with cv2), real decoding proves the codes readable. (Its detector is unreliable on
// big codes, even its own: TestSameDataAsOpenCV covers those.)
func TestDecodesWithOpenCV(t *testing.T) {
	if exec.Command("python3", "-c", "import cv2").Run() != nil {
		t.Skip("python3 with cv2 is not installed")
	}
	dir := t.TempDir()
	texts := []string{"HELLO WORLD", "https://t.me/kuni_bot?start=привет", "WIFI:T:WPA;S:MyHome;P:secret pass;;", "79991234567",
		strings.Repeat("Длинный текст. ", 8), strings.Repeat("A1B2C3 ", 25)}
	var files []string
	var want []string
	for i, txt := range texts {
		for _, l := range []Level{L, M, Q, H} {
			c, err := Encode(txt, l)
			if err != nil {
				t.Fatal(err)
			}
			p := filepath.Join(dir, strings.Repeat("x", i+1)+string("LMQH"[l])+".png")
			os.WriteFile(p, c.PNG(8*(c.Size+8)), 0o644)
			files = append(files, p)
			want = append(want, txt)
		}
	}
	script := `
import cv2, sys
d = cv2.QRCodeDetector()
for p in sys.argv[1:]:
    img = cv2.imread(p)
    val, pts, _ = d.detectAndDecode(img)
    sys.stdout.write(val.replace("\n", "\\n") + "\n")
`
	out, err := exec.Command("python3", append([]string{"-c", script}, files...)...).Output()
	if err != nil {
		t.Fatal(err)
	}
	got := strings.Split(strings.TrimSuffix(string(out), "\n"), "\n")
	for i := range files {
		if i >= len(got) || got[i] != want[i] {
			g := ""
			if i < len(got) {
				g = got[i]
			}
			t.Errorf("%s: decoded %.40q, want %.40q", filepath.Base(files[i]), g, want[i])
		}
	}
}
