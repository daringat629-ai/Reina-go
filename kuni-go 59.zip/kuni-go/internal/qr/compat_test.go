package qr

import (
	"encoding/json"
	"os/exec"
	"testing"
)

// OpenCV has an encoder of its own: the same text at the same version and level must give the same data modules
// (masks may be chosen differently, so each code is unmasked first). OpenCV's encoder is wrong at version 21 (its
// own decoder cannot read those), so that version is left out.
func TestSameDataAsOpenCV(t *testing.T) {
	if exec.Command("python3", "-c", "import cv2").Run() != nil {
		t.Skip("python3 with cv2 is not installed")
	}
	script := `
import cv2, json, random, sys
lv = {'L': cv2.QRCodeEncoder_CORRECT_LEVEL_L, 'M': cv2.QRCodeEncoder_CORRECT_LEVEL_M, 'Q': cv2.QRCodeEncoder_CORRECT_LEVEL_Q, 'H': cv2.QRCodeEncoder_CORRECT_LEVEL_H}
out = []
random.seed(1)
for v in [1, 2, 3, 5, 6, 7, 8, 10, 14, 16, 25, 27, 32, 33, 40]:
    for l in 'LMQH':
        n = 5 + v * 12
        while n > 0:
            txt = ''.join(random.choice('abcdefghijklmnopqrstuvwxyz0123456789 ') for _ in range(n))
            p = cv2.QRCodeEncoder_Params(); p.version = v; p.correction_level = lv[l]; p.mode = cv2.QRCodeEncoder_MODE_BYTE
            try:
                img = cv2.QRCodeEncoder.create(p).encode(txt)
                break
            except cv2.error:
                n = n * 3 // 4
        size = v * 4 + 17
        b = (img.shape[0] - size) // 2
        rows = [''.join('1' if img[y][x] == 0 else '0' for x in range(b, b + size)) for y in range(b, b + size)]
        out.append({'v': v, 'l': l, 'text': txt, 'rows': rows})
json.dump(out, sys.stdout)
`
	raw, err := exec.Command("python3", "-c", script).Output()
	if err != nil {
		t.Skip("OpenCV encoder unavailable: ", err)
	}
	var cases []struct {
		V    int
		L    string
		Text string
		Rows []string
	}
	if err := json.Unmarshal(raw, &cases); err != nil {
		t.Fatal(err)
	}
	for _, cs := range cases {
		l := ParseLevel(cs.L)
		mine := build(cs.Text, modeByte, dataBits(cs.Text, modeByte), cs.V, l)
		n := cs.V*4 + 17
		theirs := make([][]bool, n)
		for y, r := range cs.Rows {
			theirs[y] = make([]bool, n)
			for x, ch := range r {
				theirs[y][x] = ch == '1'
			}
		}
		theirMask := -1 // read from their format bits
		for m := 0; m < 8; m++ {
			ok := true
			probe := &Code{Version: cs.V, Level: l, Size: n}
			probe.format(func(x, y int, d bool) {
				if theirs[y][x] != d {
					ok = false
				}
			}, m)
			if ok {
				theirMask = m
			}
		}
		if theirMask < 0 {
			t.Errorf("v%d %s: format bits do not match", cs.V, cs.L)
			continue
		}
		fn := functionMap(cs.V)
		diff := 0
		for y := 0; y < n; y++ {
			for x := 0; x < n; x++ {
				if fn[y][x] {
					if !formatArea(x, y, n) && mine.Modules[y][x] != theirs[y][x] {
						diff++
					}
					continue
				}
				if (mine.Modules[y][x] != maskBit(mine.Mask, x, y)) != (theirs[y][x] != maskBit(theirMask, x, y)) {
					diff++
				}
			}
		}
		if diff > 1 { // the remainder bits after the last codeword may be left unmasked by OpenCV
			t.Errorf("v%d %s: %d modules differ", cs.V, cs.L, diff)
		}
	}
}

func formatArea(x, y, n int) bool {
	return (y == 8 && (x <= 8 || x >= n-8)) || (x == 8 && (y <= 8 || y >= n-8))
}

func maskBit(m, x, y int) bool {
	switch m {
	case 0:
		return (x+y)%2 == 0
	case 1:
		return y%2 == 0
	case 2:
		return x%3 == 0
	case 3:
		return (x+y)%3 == 0
	case 4:
		return (x/3+y/2)%2 == 0
	case 5:
		return x*y%2+x*y%3 == 0
	case 6:
		return (x*y%2+x*y%3)%2 == 0
	}
	return ((x+y)%2+x*y%3)%2 == 0
}

func functionMap(ver int) [][]bool {
	n := ver*4 + 17
	fn := make([][]bool, n)
	for i := range fn {
		fn[i] = make([]bool, n)
	}
	for i := 0; i < n; i++ {
		fn[i][6], fn[6][i] = true, true
	}
	mark := func(cx, cy, r int) {
		for dy := -r; dy <= r; dy++ {
			for dx := -r; dx <= r; dx++ {
				x, y := cx+dx, cy+dy
				if x >= 0 && x < n && y >= 0 && y < n {
					fn[y][x] = true
				}
			}
		}
	}
	mark(3, 3, 4)
	mark(n-4, 3, 4)
	mark(3, n-4, 4)
	pos := alignment(ver)
	for i, y := range pos {
		for j, x := range pos {
			if (i == 0 && j == 0) || (i == 0 && j == len(pos)-1) || (i == len(pos)-1 && j == 0) {
				continue
			}
			mark(x, y, 2)
		}
	}
	for i := 0; i <= 8; i++ {
		fn[8][i], fn[i][8] = true, true
	}
	for i := 0; i < 8; i++ {
		fn[8][n-1-i], fn[n-1-i][8] = true, true
	}
	if ver >= 7 {
		for i := 0; i < 18; i++ {
			a, b := n-11+i%3, i/3
			fn[b][a], fn[a][b] = true, true
		}
	}
	return fn
}
