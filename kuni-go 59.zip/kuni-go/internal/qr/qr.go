// Package qr makes QR codes (ISO/IEC 18004, model 2: versions 1-40, error correction L/M/Q/H, the best of the
// eight masks) and draws them as PNG. It follows Project Nayuki's reference design; only the standard library is
// used.
package qr

import (
	"bytes"
	"errors"
	"image"
	"image/color"
	"image/png"
	"strings"
)

// Level is how much of the code may be damaged and still read: L 7%, M 15%, Q 25%, H 30%.
type Level int

const (
	L Level = iota
	M
	Q
	H
)

// ParseLevel reads "L", "M", "Q" or "H" (anything else is M).
func ParseLevel(s string) Level {
	switch strings.ToUpper(strings.TrimSpace(s)) {
	case "L":
		return L
	case "Q":
		return Q
	case "H":
		return H
	}
	return M
}

func (l Level) formatBits() int { return [...]int{1, 0, 3, 2}[l] }

// Code is a finished QR code: Modules[y][x] true = dark.
type Code struct {
	Version int
	Level   Level
	Mask    int
	Size    int
	Modules [][]bool
}

// ErrTooLong: the text does not fit even the largest code.
var ErrTooLong = errors.New("the text is too long for a QR code (at most about 2900 bytes at level L)")

var eccPerBlock = [4][41]int{
	{-1, 7, 10, 15, 20, 26, 18, 20, 24, 30, 18, 20, 24, 26, 30, 22, 24, 28, 30, 28, 28, 28, 28, 30, 30, 26, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30},
	{-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26, 26, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28},
	{-1, 13, 22, 18, 26, 18, 24, 18, 22, 20, 24, 28, 26, 24, 20, 30, 24, 28, 28, 26, 30, 28, 30, 30, 30, 30, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30},
	{-1, 17, 28, 22, 16, 22, 28, 26, 26, 24, 28, 24, 28, 22, 24, 24, 30, 28, 28, 26, 28, 30, 24, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30},
}

var numBlocks = [4][41]int{
	{-1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4, 4, 4, 4, 4, 6, 6, 6, 6, 7, 8, 8, 9, 9, 10, 12, 12, 12, 13, 14, 15, 16, 17, 18, 19, 19, 20, 21, 22, 24, 25},
	{-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10, 10, 11, 13, 14, 16, 17, 17, 18, 20, 21, 23, 25, 26, 28, 29, 31, 33, 35, 37, 38, 40, 43, 45, 47, 49},
	{-1, 1, 1, 2, 2, 4, 4, 6, 6, 8, 8, 8, 10, 12, 16, 12, 17, 16, 18, 21, 20, 23, 23, 25, 27, 29, 34, 34, 35, 38, 40, 43, 45, 48, 51, 53, 56, 59, 62, 65, 68},
	{-1, 1, 1, 2, 4, 4, 4, 5, 6, 8, 8, 11, 11, 16, 16, 18, 16, 19, 21, 25, 25, 25, 34, 30, 32, 35, 37, 40, 42, 45, 48, 51, 54, 57, 60, 63, 66, 70, 74, 77, 81},
}

// rawModules is the number of modules of a version that carry data (everything but the function patterns).
func rawModules(ver int) int {
	r := (16*ver+128)*ver + 64
	if ver >= 2 {
		n := ver/7 + 2
		r -= (25*n-10)*n - 55
		if ver >= 7 {
			r -= 36
		}
	}
	return r
}

// DataCodewords is how many bytes of data a version holds at a level.
func DataCodewords(ver int, l Level) int {
	return rawModules(ver)/8 - eccPerBlock[l][ver]*numBlocks[l][ver]
}

// segment modes
const (
	modeNumeric = 1
	modeAlnum   = 2
	modeByte    = 4
)

const alnumChars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:"

func modeOf(s string) int {
	numeric, alnum := true, true
	for i := 0; i < len(s); i++ {
		c := s[i]
		if c < '0' || c > '9' {
			numeric = false
		}
		if strings.IndexByte(alnumChars, c) < 0 {
			alnum = false
		}
	}
	switch {
	case numeric && len(s) > 0:
		return modeNumeric
	case alnum && len(s) > 0:
		return modeAlnum
	}
	return modeByte
}

func countBits(mode, ver int) int {
	i := 0
	if ver >= 27 {
		i = 2
	} else if ver >= 10 {
		i = 1
	}
	switch mode {
	case modeNumeric:
		return [...]int{10, 12, 14}[i]
	case modeAlnum:
		return [...]int{9, 11, 13}[i]
	}
	return [...]int{8, 16, 16}[i]
}

type bits []bool

func (b *bits) put(v, n int) {
	for i := n - 1; i >= 0; i-- {
		*b = append(*b, (v>>i)&1 == 1)
	}
}

// dataBits is the encoded segment without the header.
func dataBits(s string, mode int) bits {
	var b bits
	switch mode {
	case modeNumeric:
		for i := 0; i < len(s); i += 3 {
			chunk := s[i:min(i+3, len(s))]
			v := 0
			for _, c := range chunk {
				v = v*10 + int(c-'0')
			}
			b.put(v, len(chunk)*3+1)
		}
	case modeAlnum:
		for i := 0; i+1 < len(s); i += 2 {
			b.put(strings.IndexByte(alnumChars, s[i])*45+strings.IndexByte(alnumChars, s[i+1]), 11)
		}
		if len(s)%2 == 1 {
			b.put(strings.IndexByte(alnumChars, s[len(s)-1]), 6)
		}
	default:
		for i := 0; i < len(s); i++ {
			b.put(int(s[i]), 8)
		}
	}
	return b
}

// Encode makes the smallest code holding text at least at level l (the level is raised when it costs no size).
func Encode(text string, l Level) (*Code, error) {
	mode := modeOf(text)
	body := dataBits(text, mode)
	count := len(text)
	ver := 0
	for v := 1; v <= 40; v++ {
		if 4+countBits(mode, v)+len(body) <= DataCodewords(v, l)*8 && count < 1<<countBits(mode, v) {
			ver = v
			break
		}
	}
	if ver == 0 {
		return nil, ErrTooLong
	}
	need := 4 + countBits(mode, ver) + len(body)
	for _, better := range []Level{M, Q, H} {
		if better > l && need <= DataCodewords(ver, better)*8 {
			l = better
		}
	}
	return build(text, mode, body, ver, l), nil
}

// build makes the code of a version and level that the text is known to fit.
func build(text string, mode int, body bits, ver int, l Level) *Code {
	count := len(text)
	var b bits
	b.put(mode, 4)
	b.put(count, countBits(mode, ver))
	b = append(b, body...)
	capacity := DataCodewords(ver, l) * 8
	b.put(0, min(4, capacity-len(b))) // terminator
	b.put(0, (8-len(b)%8)%8)
	for pad := 0xEC; len(b) < capacity; pad ^= 0xEC ^ 0x11 {
		b.put(pad, 8)
	}
	data := make([]byte, len(b)/8)
	for i, bit := range b {
		if bit {
			data[i>>3] |= 1 << (7 - i&7)
		}
	}
	c := &Code{Version: ver, Level: l, Size: ver*4 + 17}
	c.draw(withECC(data, ver, l))
	return c
}

// withECC splits the data into blocks, adds the Reed-Solomon codewords of each, and interleaves them.
func withECC(data []byte, ver int, l Level) []byte {
	nb, eccLen := numBlocks[l][ver], eccPerBlock[l][ver]
	raw := rawModules(ver) / 8
	short := nb - raw%nb
	shortLen := raw / nb // data + ecc of a short block
	div := rsDivisor(eccLen)
	var blocks, eccs [][]byte
	k := 0
	for i := 0; i < nb; i++ {
		n := shortLen - eccLen
		if i >= short {
			n++
		}
		blk := data[k : k+n]
		k += n
		blocks = append(blocks, blk)
		eccs = append(eccs, rsRemainder(blk, div))
	}
	var out []byte
	for i := 0; i <= shortLen-eccLen; i++ {
		for _, blk := range blocks {
			if i < len(blk) {
				out = append(out, blk[i])
			}
		}
	}
	for i := 0; i < eccLen; i++ {
		for _, e := range eccs {
			out = append(out, e[i])
		}
	}
	return out
}

func gfMul(x, y byte) byte {
	z := 0
	for i := 7; i >= 0; i-- {
		z = (z << 1) ^ ((z >> 7) * 0x11D)
		z ^= int((y>>i)&1) * int(x)
	}
	return byte(z)
}

func rsDivisor(degree int) []byte {
	r := make([]byte, degree)
	r[degree-1] = 1
	root := byte(1)
	for i := 0; i < degree; i++ {
		for j := range r {
			r[j] = gfMul(r[j], root)
			if j+1 < len(r) {
				r[j] ^= r[j+1]
			}
		}
		root = gfMul(root, 0x02)
	}
	return r
}

func rsRemainder(data, div []byte) []byte {
	r := make([]byte, len(div))
	for _, b := range data {
		f := b ^ r[0]
		copy(r, r[1:])
		r[len(r)-1] = 0
		for i, c := range div {
			r[i] ^= gfMul(c, f)
		}
	}
	return r
}

func (c *Code) draw(codewords []byte) {
	n := c.Size
	c.Modules = make([][]bool, n)
	fn := make([][]bool, n)
	for i := range c.Modules {
		c.Modules[i] = make([]bool, n)
		fn[i] = make([]bool, n)
	}
	set := func(x, y int, dark bool) {
		c.Modules[y][x] = dark
		fn[y][x] = true
	}
	for i := 0; i < n; i++ { // timing patterns
		set(6, i, i%2 == 0)
		set(i, 6, i%2 == 0)
	}
	finder := func(cx, cy int) {
		for dy := -4; dy <= 4; dy++ {
			for dx := -4; dx <= 4; dx++ {
				x, y := cx+dx, cy+dy
				if x >= 0 && x < n && y >= 0 && y < n {
					d := max(abs(dx), abs(dy))
					set(x, y, d != 2 && d != 4)
				}
			}
		}
	}
	finder(3, 3)
	finder(n-4, 3)
	finder(3, n-4)
	pos := alignment(c.Version)
	for i, y := range pos {
		for j, x := range pos {
			if (i == 0 && j == 0) || (i == 0 && j == len(pos)-1) || (i == len(pos)-1 && j == 0) {
				continue
			}
			for dy := -2; dy <= 2; dy++ {
				for dx := -2; dx <= 2; dx++ {
					set(x+dx, y+dy, max(abs(dx), abs(dy)) != 1)
				}
			}
		}
	}
	c.format(set, 0) // reserves the format area
	if c.Version >= 7 {
		r := c.Version
		for i := 0; i < 12; i++ {
			r = (r << 1) ^ ((r >> 11) * 0x1F25)
		}
		v := c.Version<<12 | r
		for i := 0; i < 18; i++ {
			bit := (v>>i)&1 == 1
			a, b := n-11+i%3, i/3
			set(a, b, bit)
			set(b, a, bit)
		}
	}
	// the data, in the zigzag from the bottom right
	i := 0
	for right := n - 1; right >= 1; right -= 2 {
		if right == 6 {
			right = 5
		}
		for vert := 0; vert < n; vert++ {
			for j := 0; j < 2; j++ {
				x := right - j
				y := vert
				if (right+1)&2 == 0 {
					y = n - 1 - vert
				}
				if !fn[y][x] && i < len(codewords)*8 {
					c.Modules[y][x] = (codewords[i>>3]>>(7-i&7))&1 == 1
					i++
				}
			}
		}
	}
	best, bestScore := 0, -1
	for m := 0; m < 8; m++ {
		c.mask(fn, m)
		c.format(set, m)
		if s := c.penalty(); bestScore < 0 || s < bestScore {
			best, bestScore = m, s
		}
		c.mask(fn, m) // undo (a mask is its own inverse)
	}
	c.Mask = best
	c.mask(fn, best)
	c.format(set, best)
}

func abs(x int) int {
	if x < 0 {
		return -x
	}
	return x
}

func alignment(ver int) []int {
	if ver == 1 {
		return nil
	}
	n := ver/7 + 2
	step := (ver*4 + n*2 + 1) / (n*2 - 2) * 2
	if ver == 32 {
		step = 26
	}
	out := make([]int, n)
	out[0] = 6
	for i, p := n-1, ver*4+17-7; i >= 1; i, p = i-1, p-step {
		out[i] = p
	}
	return out
}

func (c *Code) format(set func(x, y int, dark bool), mask int) {
	data := c.Level.formatBits()<<3 | mask
	r := data
	for i := 0; i < 10; i++ {
		r = (r << 1) ^ ((r >> 9) * 0x537)
	}
	b := (data<<10 | r) ^ 0x5412
	bit := func(i int) bool { return (b>>i)&1 == 1 }
	n := c.Size
	for i := 0; i <= 5; i++ {
		set(8, i, bit(i))
	}
	set(8, 7, bit(6))
	set(8, 8, bit(7))
	set(7, 8, bit(8))
	for i := 9; i < 15; i++ {
		set(14-i, 8, bit(i))
	}
	for i := 0; i < 8; i++ {
		set(n-1-i, 8, bit(i))
	}
	for i := 8; i < 15; i++ {
		set(8, n-15+i, bit(i))
	}
	set(8, n-8, true)
}

func (c *Code) mask(fn [][]bool, m int) {
	for y := 0; y < c.Size; y++ {
		for x := 0; x < c.Size; x++ {
			var inv bool
			switch m {
			case 0:
				inv = (x+y)%2 == 0
			case 1:
				inv = y%2 == 0
			case 2:
				inv = x%3 == 0
			case 3:
				inv = (x+y)%3 == 0
			case 4:
				inv = (x/3+y/2)%2 == 0
			case 5:
				inv = x*y%2+x*y%3 == 0
			case 6:
				inv = (x*y%2+x*y%3)%2 == 0
			case 7:
				inv = ((x+y)%2+x*y%3)%2 == 0
			}
			if inv && !fn[y][x] {
				c.Modules[y][x] = !c.Modules[y][x]
			}
		}
	}
}

// penalty scores a masked code by the four rules of the standard; the mask with the lowest score is used.
func (c *Code) penalty() int {
	n := c.Size
	score := 0
	at := func(x, y int, col bool) bool {
		if col {
			return c.Modules[x][y]
		}
		return c.Modules[y][x]
	}
	pat1 := []bool{true, false, true, true, true, false, true, false, false, false, false}
	pat2 := []bool{false, false, false, false, true, false, true, true, true, false, true}
	for _, col := range []bool{false, true} {
		for y := 0; y < n; y++ {
			run := 1
			for x := 1; x <= n; x++ {
				if x < n && at(x, y, col) == at(x-1, y, col) {
					run++
					continue
				}
				if run >= 5 {
					score += 3 + run - 5
				}
				run = 1
			}
			for x := 0; x+11 <= n; x++ {
				m1, m2 := true, true
				for k := 0; k < 11; k++ {
					v := at(x+k, y, col)
					m1 = m1 && v == pat1[k]
					m2 = m2 && v == pat2[k]
				}
				if m1 {
					score += 40
				}
				if m2 {
					score += 40
				}
			}
		}
	}
	dark := 0
	for y := 0; y < n; y++ {
		for x := 0; x < n; x++ {
			if c.Modules[y][x] {
				dark++
			}
			if x+1 < n && y+1 < n {
				v := c.Modules[y][x]
				if c.Modules[y][x+1] == v && c.Modules[y+1][x] == v && c.Modules[y+1][x+1] == v {
					score += 3
				}
			}
		}
	}
	k := abs(dark*20-n*n*10) / (n * n) // each 5% away from half dark
	return score + k*10
}

// Image draws the code with a quiet zone of 4 modules, scale pixels per module.
func (c *Code) Image(scale int) image.Image {
	scale = max(scale, 1)
	quiet := 4
	side := (c.Size + 2*quiet) * scale
	img := image.NewPaletted(image.Rect(0, 0, side, side), color.Palette{color.White, color.Black})
	for y := 0; y < c.Size; y++ {
		for x := 0; x < c.Size; x++ {
			if !c.Modules[y][x] {
				continue
			}
			for dy := 0; dy < scale; dy++ {
				row := img.Pix[((y+quiet)*scale+dy)*img.Stride:]
				for dx := 0; dx < scale; dx++ {
					row[(x+quiet)*scale+dx] = 1
				}
			}
		}
	}
	return img
}

// PNG draws the code at about px pixels on a side (at least 4 pixels per module).
func (c *Code) PNG(px int) []byte {
	scale := max(4, px/(c.Size+8))
	var b bytes.Buffer
	_ = png.Encode(&b, c.Image(scale))
	return b.Bytes()
}

// String draws the code with blocks (for tests and terminals).
func (c *Code) String() string {
	var b strings.Builder
	for _, row := range c.Modules {
		for _, d := range row {
			if d {
				b.WriteString("██")
			} else {
				b.WriteString("  ")
			}
		}
		b.WriteByte('\n')
	}
	return b.String()
}
