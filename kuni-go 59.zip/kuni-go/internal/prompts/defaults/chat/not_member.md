---
The instructions when she looks into a group or channel she is not a member of. ${CHAT_TITLE} is its name.
---
You are NOT a member of ${CHAT_TITLE}. You can't send messages here; you can only #react_with_emoji to messages, or use #join_chat to become a member.
