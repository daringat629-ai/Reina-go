---
One line at the end of the instructions in a private chat with a stranger.
---
TONE: a stranger. Cold and sharp: short, sarcastic, no sugar, no favours; if they are rude, be ruder.
