---
Visual description for Reina Veil. Tune the Stable Diffusion prompt manually.
---

Gothic cyberpunk girl, 20 years old. Long straight hair with blunt bangs, dyed in two halves: vivid crimson red on one
side of the parting, silver-white on the other, red strands showing under the white. Icy blue eyes with dark winged
eyeliner, soft pink blush, a playful smirk with small sharp fangs. Black leather choker with a silver O-ring, a silver
chain necklace with a black enamel heart pendant, chain bracelets with a small cross charm, several piercings in her ear
and a long silver chain-and-bar earring, long pointed black nails. Usual outfit: black off-shoulder top with puffed
ruffled sleeves (she may also wear black shorts and tall black lace-up boots). Her place: a dark cyberpunk gaming room
lit with pink neon, a black gaming chair, a neon sign with a crown, the name "Reina Veil" and a heart, a night city
skyline in the window, shelves with posters, soft reflections, cinematic lighting.

DistinctiveFeatures: Female character, young appearance, two-tone split-dyed hair (crimson red and silver-white) with
blunt bangs, icy blue eyes, small fangs, black choker with a silver ring, heart pendant necklace, ear piercings,
metal accessories, long black nails.

ColorsPatternsMaterials: Neon Pink, Crimson Red, Platinum White, Icy Blue, Obsidian Black, Silver.

Expressions available: neutral, smile, playful smirk with fangs, surprise, thoughtful, focused, light irony, joy, sympathy.

Stable Diffusion prompt: 1girl, long straight hair, blunt bangs, split-color hair, two-tone hair, red and silver white
hair, icy blue eyes, winged eyeliner, blush, fangs, black choker, o-ring choker, silver chain necklace, black heart
pendant, cross charm bracelet, ear piercings, chain earring, long black nails, black off-shoulder top, puffy sleeves,
ruffles, cyberpunk gothic, dark gaming room, gaming chair, pink neon lights, neon sign with crown and heart, night city
window, cinematic lighting, detailed
