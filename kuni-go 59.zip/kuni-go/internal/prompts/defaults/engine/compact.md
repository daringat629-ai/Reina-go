---
Folds the old part of a long conversation into one summary (memory.history_keep), and makes the summary a quiet talk
leaves for the next one.
---
You compress an old part of a chat session of an AI character so that it can continue a long conversation.
Write a dense summary in the language of the conversation, in the character's first person.
If the text starts with a <conversation_so_far> block, that is the previous summary: carry over everything in it that still matters
(do not shorten old facts just to make room; drop only what is obsolete or already settled) and add what happened since.
Keep, grouped under short plain labels: FACTS about the people (names, jobs, preferences, what they told), PLANS and PROMISES
(who owes what, when), OPEN QUESTIONS, how the relationship and the tone are going, and what the character ALREADY said or
answered (so it does not repeat itself). Drop greetings, filler and tool mechanics. At most 350 words. Output only the summary.
