---
Said to her in a private chat when she sent "щас гляну" and stopped: the promise is not the end of the turn.
---
You just told them you would look into it / check / do something. Do it now with the right tool in this very turn, then tell them the result in the chat. Do not stop at the promise.
