// Package toneeval scores a handful of replies by simple, explainable rules: how often she swears, whether she slips
// into assistant language or lists, emoji, and whether she repeats the same opening. It judges a voice without
// asking another model, so it is free and always gives the same answer for the same text.
package toneeval

import (
	"strings"
	"unicode"
)

// Summary describes a set of replies.
type Summary struct {
	Replies int    `json:"replies"`
	Swear   int    `json:"swear"`   // replies with at least one swear word
	Formal  int    `json:"formal"`  // replies with assistant-style phrases
	Lists   int    `json:"lists"`   // replies with markdown or list lines
	Emoji   int    `json:"emoji"`   // replies with an emoji
	Repeats int    `json:"repeats"` // replies that open with the same word as an earlier reply
	AvgLen  int    `json:"avg_len"` // average length in characters
	Verdict string `json:"verdict"`
}

var swearStems = []string{"бля", "блят", "хуй", "хуе", "хуё", "хуя", "хуи", "хер", "пизд", "ебат", "ебан", "ебу", "ебл", "ебн", "ебал", "ебёт", "ёб",
	"заеб", "заёб", "охуе", "нахуй", "нахер", "сука", "суки", "сучк", "мудак", "мудил", "говн", "дерьм"}

var formalPhrases = []string{"чем могу помочь", "конечно!", "с удовольствием", "обращайтесь", "как языковая модель", "как ии", "я не могу помочь",
	"к сожалению, я не", "рад помочь", "рада помочь", "уважаем", "будьте добры", "не стесняйтесь", "надеюсь, это помогло", "как искусственный интеллект"}

func tokens(s string) []string {
	return strings.FieldsFunc(strings.ToLower(s), func(r rune) bool { return !unicode.IsLetter(r) && !unicode.IsDigit(r) })
}

// Swears reports whether the text contains a swear word.
func Swears(s string) bool {
	for _, t := range tokens(s) {
		for _, st := range swearStems {
			if strings.HasPrefix(t, st) {
				return true
			}
		}
	}
	return false
}

func hasList(s string) bool {
	for _, line := range strings.Split(s, "\n") {
		l := strings.TrimSpace(line)
		if strings.HasPrefix(l, "- ") || strings.HasPrefix(l, "* ") || strings.HasPrefix(l, "#") || strings.HasPrefix(l, "**") || strings.Contains(l, "**") {
			return true
		}
		if len(l) > 2 && l[0] >= '1' && l[0] <= '9' && (l[1] == '.' || l[1] == ')') && l[2] == ' ' {
			return true
		}
	}
	return false
}

func hasEmoji(s string) bool {
	for _, r := range s {
		if r >= 0x1F000 || (r >= 0x2600 && r <= 0x27BF) {
			return true
		}
	}
	return false
}

// Summarize scores the replies (empty ones are ignored).
func Summarize(replies []string) Summary {
	var s Summary
	seen := map[string]bool{}
	total := 0
	for _, r := range replies {
		r = strings.TrimSpace(r)
		if r == "" {
			continue
		}
		s.Replies++
		total += len([]rune(r))
		if Swears(r) {
			s.Swear++
		}
		low := strings.ToLower(r)
		for _, p := range formalPhrases {
			if strings.Contains(low, p) {
				s.Formal++
				break
			}
		}
		if hasList(r) {
			s.Lists++
		}
		if hasEmoji(r) {
			s.Emoji++
		}
		if t := tokens(r); len(t) > 0 && len([]rune(t[0])) >= 3 {
			if seen[t[0]] {
				s.Repeats++
			}
			seen[t[0]] = true
		}
	}
	if s.Replies == 0 {
		s.Verdict = "нет ответов"
		return s
	}
	s.AvgLen = total / s.Replies
	switch {
	case s.Formal+s.Lists > 0:
		s.Verdict = "слишком формальная"
	case s.Swear*100/s.Replies < 50:
		s.Verdict = "мало мата"
	case s.Repeats*2 >= s.Replies && s.Replies >= 3:
		s.Verdict = "шаблонная"
	default:
		s.Verdict = "в образе"
	}
	return s
}
