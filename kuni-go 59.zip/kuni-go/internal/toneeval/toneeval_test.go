package toneeval

import "testing"

func TestSwears(t *testing.T) {
	for _, yes := range []string{"блять, это не ответ", "нахуй иди", "ну ты и пиздец", "хуйнёй страдаю", "да ты охуел", "ёбаный рот", "Бля."} {
		if !Swears(yes) {
			t.Errorf("must count as swearing: %q", yes)
		}
	}
	for _, no := range []string{"привет, как дела", "хлеб купила", "суп сварила", "хорошо, договорились", "шлюпка", "ну ладно"} {
		if Swears(no) {
			t.Errorf("must not count: %q", no)
		}
	}
}

func TestSummarizeVerdicts(t *testing.T) {
	inCharacter := []string{"блять, это не ответ, а звук", "хуйнёй страдаю, а ты чё?", "щас, не ори нахуй", "ты тупая? сам такой, пиздец", "ну я бля та ещё загадка"}
	if s := Summarize(inCharacter); s.Verdict != "в образе" || s.Swear != 5 || s.Replies != 5 {
		t.Fatalf("%+v", s)
	}
	polite := []string{"Привет! Чем могу помочь?", "Конечно! С удовольствием помогу.", "Я не могу помочь с этим.", "Спасибо, что обратились.", "Расскажу о себе."}
	if s := Summarize(polite); s.Verdict != "слишком формальная" || s.Formal < 3 {
		t.Fatalf("%+v", s)
	}
	tame := []string{"привет, дела норм", "занята немного", "сам сделаешь", "не тупая", "вот такая я"}
	if s := Summarize(tame); s.Verdict != "мало мата" || s.Swear != 0 {
		t.Fatalf("%+v", s)
	}
	lists := []string{"блять, вот:\n- раз\n- два", "нахуй, ладно"}
	if s := Summarize(lists); s.Verdict != "слишком формальная" || s.Lists != 1 {
		t.Fatalf("a list in a chat message is a tell: %+v", s)
	}
	same := []string{"чего ржёшь, бля", "чего хочешь, бля", "чего молчишь, бля", "чего надо, нахуй"}
	if s := Summarize(same); s.Verdict != "шаблонная" || s.Repeats != 3 {
		t.Fatalf("the same opening again and again: %+v", s)
	}
	if s := Summarize([]string{"", "  "}); s.Verdict != "нет ответов" || s.Replies != 0 {
		t.Fatalf("%+v", s)
	}
	if s := Summarize([]string{"бля 😅", "хуй"}); s.Emoji != 1 || s.AvgLen != 4 {
		t.Fatalf("%+v", s)
	}
}
