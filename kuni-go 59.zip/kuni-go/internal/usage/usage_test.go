package usage

import (
	"path/filepath"
	"testing"
	"time"
)

func TestTallyCostPersistenceAndDayRoll(t *testing.T) {
	path := filepath.Join(t.TempDir(), "u.json")
	u := New(path)
	now := time.Date(2026, 10, 19, 12, 0, 0, 0, time.UTC)
	u.now = func() time.Time { return now }
	u.Add("deepseek", 1_000_000, 100_000, 0)
	u.Add("qwen", 500_000, 0, 0)
	in, out := u.Today()
	if in != 1_500_000 || out != 100_000 {
		t.Fatalf("%d %d", in, out)
	}
	price := func(m string) Prices {
		if m == "deepseek" {
			return Prices{In: 0.02, Out: 0.64}
		}
		return Prices{}
	}
	usd, ok := u.Cost(price)
	if !ok || usd < 0.0839 || usd > 0.0841 { // 0.02 + 0.064; the unpriced model adds nothing
		t.Fatalf("cost %v %v", usd, ok)
	}
	if _, ok := u.Cost(func(string) Prices { return Prices{} }); ok {
		t.Fatal("no prices -> no cost shown")
	}
	u2 := New(path)
	u2.now = u.now
	if in2, _ := u2.Today(); in2 != 1_500_000 {
		t.Fatalf("not persisted: %d", in2)
	}
	now = now.Add(24 * time.Hour)
	if in3, out3 := u.Today(); in3 != 0 || out3 != 0 {
		t.Fatal("a new day starts from zero")
	}
}

func TestSoftWarnsOnceAndHardGuards(t *testing.T) {
	u := New("")
	if u.Add("m", 400, 0, 1000) || u.Over(1000) {
		t.Fatal("below the limit")
	}
	if !u.Add("m", 700, 0, 1000) {
		t.Fatal("crossing the soft limit must be reported")
	}
	if u.Add("m", 10, 0, 1000) {
		t.Fatal("only once per day")
	}
	if !u.Over(1000) || u.Guard(1000) != nil {
		t.Fatal("over soft but not hard")
	}
	u.Add("m", 2000, 0, 1000)
	if u.Guard(1000) != ErrHardLimit {
		t.Fatal("3x limit must hard-stop")
	}
	if u.Guard(0) != nil {
		t.Fatal("no limit configured, no guard")
	}
	var nilT *Tracker
	nilT.Add("m", 1, 1, 1)
	if nilT.Guard(1) != nil || nilT.Over(1) {
		t.Fatal("nil tracker never blocks")
	}
}

func TestHistoryKeepsFinishedDaysAndReportsOncePerDay(t *testing.T) {
	path := filepath.Join(t.TempDir(), "u.json")
	u := New(path)
	now := time.Date(2026, 10, 19, 12, 0, 0, 0, time.UTC)
	u.now = func() time.Time { return now }
	price := func(string) Prices { return Prices{In: 1, Out: 2} }
	u.Add("m", 1_000_000, 500_000, 0)
	u.Add("m", 1_000_000, 0, 0)
	if _, ok := u.DueReport(price); ok {
		t.Fatal("no finished day yet")
	}
	now = now.Add(24 * time.Hour)
	d, ok := u.DueReport(price)
	if !ok || d.Day != "2026-10-19" || d.In != 2_000_000 || d.Out != 500_000 || d.Calls != 2 || !d.HasPrice || d.USD < 2.99 || d.USD > 3.01 {
		t.Fatalf("report: %+v %v", d, ok)
	}
	if _, ok := u.DueReport(price); ok {
		t.Fatal("the report goes out once per day")
	}
	u2 := New(path) // survives a restart without being sent again
	u2.now = u.now
	if _, ok := u2.DueReport(price); ok {
		t.Fatal("restart must not repeat the report")
	}
	days := u2.Days(14, price)
	if len(days) != 2 || days[0].Day != "2026-10-19" || days[1].Day != "2026-10-20" {
		t.Fatalf("days: %+v", days)
	}
	for i := 0; i < 40; i++ {
		now = now.Add(24 * time.Hour)
		u2.Add("m", 1, 1, 0)
	}
	if n := len(u2.Days(0, nil)); n > keepDays+1 {
		t.Fatalf("history not capped: %d", n)
	}
}

func TestDaysFollowTheConfiguredZone(t *testing.T) {
	u := New("")
	u.SetZone(time.FixedZone("x", 6*3600))
	u.now = func() time.Time { return time.Date(2026, 10, 19, 20, 0, 0, 0, time.UTC) } // already the 20th in +06:00
	u.Add("m", 1, 1, 0)
	if d := u.Days(1, nil); d[0].Day != "2026-10-20" {
		t.Fatalf("day %s", d[0].Day)
	}
}

func TestPerChatSpendAndDayRoll(t *testing.T) {
	u := New(filepath.Join(t.TempDir(), "u.json"))
	now := time.Date(2026, 10, 19, 12, 0, 0, 0, time.UTC)
	u.now = func() time.Time { return now }
	u.AddChat(5, "m", 1_000_000, 100_000)
	u.AddChat(5, "m", 1_000_000, 0)
	u.AddChat(0, "m", 10, 1) // her own thoughts are a chat too
	price := func(m string) Prices { return Prices{In: 1, Out: 10} }
	c := u.Chat(5, price)
	if c.In != 2_000_000 || c.Out != 100_000 || !c.HasPrice || c.USD < 2.99 || c.USD > 3.01 {
		t.Fatalf("chat 5: %+v", c)
	}
	if o := u.Chat(7, price); o.In != 0 || o.HasPrice {
		t.Fatalf("an unknown chat spent nothing: %+v", o)
	}
	if free := u.Chat(5, func(string) Prices { return Prices{} }); free.HasPrice {
		t.Fatal("without prices there is no cost")
	}
	now = now.Add(24 * time.Hour)
	if n := u.Chat(5, price); n.In != 0 {
		t.Fatal("a new day starts from zero")
	}
	// survives a restart
	u.AddChat(5, "m", 5, 5)
	u2 := New(u.path)
	u2.now = u.now
	if got := u2.Chat(5, price); got.In != 5 {
		t.Fatalf("not persisted: %+v", got)
	}
}

func TestNearLimitOncePerDay(t *testing.T) {
	tr := New(t.TempDir() + "/u.json")
	tr.Add("m", 700, 0, 1000)
	if tr.NearLimit(1000) {
		t.Fatal("70% is not near")
	}
	tr.Add("m", 100, 0, 1000)
	if !tr.NearLimit(1000) {
		t.Fatal("80% must warn")
	}
	if tr.NearLimit(1000) {
		t.Fatal("only once")
	}
	if tr.NearLimit(0) {
		t.Fatal("no limit, no warning")
	}
}
