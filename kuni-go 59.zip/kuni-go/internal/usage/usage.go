// Package usage keeps a per-day, restart-proof tally of LLM tokens and what they cost, and enforces the optional
// daily token limit: past the soft limit the character stops acting on her own, past the hard limit (3x) every
// request is refused, which stops a runaway loop from burning money.
package usage

import (
	"errors"
	"strconv"
	"sync"
	"time"

	"kuni/internal/store"
)

// HardFactor is how many times the soft limit the hard stop sits at.
const HardFactor = 3

type counts struct {
	In  int64 `json:"in"`
	Out int64 `json:"out"`
}

type data struct {
	Day      string                       `json:"day"`
	Models   map[string]counts            `json:"models"`
	Calls    int64                        `json:"calls"`
	Chats    map[string]map[string]counts `json:"chats,omitempty"`    // today's tokens per chat and model
	Warned   bool                         `json:"warned"`             // the soft-limit warning went out today
	Near     bool                         `json:"near,omitempty"`     // the "80% spent" warning went out today
	Reported string                       `json:"reported,omitempty"` // the day whose report was already sent
	History  []DayStat                    `json:"history,omitempty"`  // finished days, oldest first (at most keepDays)
}

// DayStat is one finished day.
type DayStat struct {
	Day    string            `json:"day"`
	Models map[string]counts `json:"models"`
	Calls  int64             `json:"calls"`
}

const keepDays = 30

// Prices are dollars per million tokens.
type Prices struct{ In, Out float64 }

// Tracker is safe for concurrent use. A nil *Tracker counts nothing and never blocks.
type Tracker struct {
	mu    sync.Mutex
	path  string
	d     data
	now   func() time.Time
	loc   *time.Location // days change at midnight of this zone (default: the server's)
	saver store.Saver
}

// SetZone makes the usage days follow the given zone (so "today" matches the owner's clock).
func (t *Tracker) SetZone(loc *time.Location) {
	if t == nil || loc == nil {
		return
	}
	t.mu.Lock()
	t.loc = loc
	t.mu.Unlock()
}

func (t *Tracker) dayNow() string {
	n := t.now()
	if t.loc != nil {
		n = n.In(t.loc)
	}
	return n.Format("2006-01-02")
}

func New(path string) *Tracker {
	t := &Tracker{path: path, now: time.Now, saver: store.Saver{What: "usage"}}
	store.Load("usage", path, &t.d)
	return t
}

func (t *Tracker) roll() {
	if day := t.dayNow(); t.d.Day != day {
		old := t.d
		t.d = data{Day: day, Models: map[string]counts{}, Reported: old.Reported, History: old.History}
		if old.Day != "" && (len(old.Models) > 0 || old.Calls > 0) {
			t.d.History = append(t.d.History, DayStat{Day: old.Day, Models: old.Models, Calls: old.Calls})
		}
		if n := len(t.d.History); n > keepDays {
			t.d.History = t.d.History[n-keepDays:]
		}
	}
	if t.d.Models == nil {
		t.d.Models = map[string]counts{}
	}
}

func (t *Tracker) save() { _ = t.saver.Save(t.path, t.d) }

// Add counts one request. It reports true exactly once per day: when the soft limit is crossed for the first time.
func (t *Tracker) Add(model string, in, out int, softLimit int64) (crossed bool) {
	if t == nil {
		return false
	}
	t.mu.Lock()
	defer t.mu.Unlock()
	t.roll()
	c := t.d.Models[model]
	c.In += int64(in)
	c.Out += int64(out)
	t.d.Models[model] = c
	t.d.Calls++
	if softLimit > 0 && !t.d.Warned && t.totalLocked() >= softLimit {
		t.d.Warned, crossed = true, true
	}
	t.save()
	return crossed
}

// NearLimit reports true exactly once per day: when 80% of the soft limit is spent.
func (t *Tracker) NearLimit(limit int64) bool {
	if t == nil || limit <= 0 {
		return false
	}
	t.mu.Lock()
	defer t.mu.Unlock()
	t.roll()
	if t.d.Near || t.totalLocked()*100 < limit*80 {
		return false
	}
	t.d.Near = true
	t.save()
	return true
}

func (t *Tracker) totalLocked() int64 {
	var n int64
	for _, c := range t.d.Models {
		n += c.In + c.Out
	}
	return n
}

// AddChat attributes one request to a chat (the same request is also counted by Add).
func (t *Tracker) AddChat(chat int64, model string, in, out int) {
	if t == nil {
		return
	}
	t.mu.Lock()
	defer t.mu.Unlock()
	t.roll()
	if t.d.Chats == nil {
		t.d.Chats = map[string]map[string]counts{}
	}
	k := strconv.FormatInt(chat, 10)
	if t.d.Chats[k] == nil {
		t.d.Chats[k] = map[string]counts{}
	}
	c := t.d.Chats[k][model]
	c.In += int64(in)
	c.Out += int64(out)
	t.d.Chats[k][model] = c
	t.save()
}

// ChatUse is what one chat spent today.
type ChatUse struct {
	In, Out  int64
	USD      float64
	HasPrice bool
}

// Chat returns today's spend of one chat; USD is only meaningful when HasPrice.
func (t *Tracker) Chat(chat int64, price func(model string) Prices) ChatUse {
	var u ChatUse
	if t == nil {
		return u
	}
	t.mu.Lock()
	defer t.mu.Unlock()
	t.roll()
	for m, c := range t.d.Chats[strconv.FormatInt(chat, 10)] {
		u.In += c.In
		u.Out += c.Out
		if p := price(m); p.In != 0 || p.Out != 0 {
			u.HasPrice = true
			u.USD += float64(c.In)/1e6*p.In + float64(c.Out)/1e6*p.Out
		}
	}
	return u
}

// Today returns the tokens used today.
func (t *Tracker) Today() (in, out int64) {
	if t == nil {
		return 0, 0
	}
	t.mu.Lock()
	defer t.mu.Unlock()
	t.roll()
	for _, c := range t.d.Models {
		in += c.In
		out += c.Out
	}
	return in, out
}

// Cost is today's spend in dollars given per-model prices; ok is false when no used model has a price.
func (t *Tracker) Cost(price func(model string) Prices) (usd float64, ok bool) {
	if t == nil {
		return 0, false
	}
	t.mu.Lock()
	defer t.mu.Unlock()
	t.roll()
	for m, c := range t.d.Models {
		p := price(m)
		if p.In == 0 && p.Out == 0 {
			continue
		}
		ok = true
		usd += float64(c.In)/1e6*p.In + float64(c.Out)/1e6*p.Out
	}
	return usd, ok
}

// Over reports whether today's tokens reached limit (0 = no limit).
func (t *Tracker) Over(limit int64) bool {
	if t == nil || limit <= 0 {
		return false
	}
	in, out := t.Today()
	return in+out >= limit
}

// ErrHardLimit is returned by Guard once the hard limit is hit.
var ErrHardLimit = errors.New("daily token limit exceeded: the character is paused until tomorrow (llm.daily_token_limit)")

// Guard returns ErrHardLimit when today's tokens reached HardFactor x limit.
func (t *Tracker) Guard(limit int64) error {
	if t.Over(limit*HardFactor) && limit > 0 {
		return ErrHardLimit
	}
	return nil
}

// Day is one row of the usage history.
type Day struct {
	Day      string  `json:"day"`
	In       int64   `json:"in"`
	Out      int64   `json:"out"`
	Calls    int64   `json:"calls"`
	USD      float64 `json:"usd"`
	HasPrice bool    `json:"has_price"`
}

func sumDay(day string, models map[string]counts, calls int64, price func(string) Prices) Day {
	d := Day{Day: day, Calls: calls}
	for m, c := range models {
		d.In += c.In
		d.Out += c.Out
		if price != nil {
			if p := price(m); p.In != 0 || p.Out != 0 {
				d.HasPrice = true
				d.USD += float64(c.In)/1e6*p.In + float64(c.Out)/1e6*p.Out
			}
		}
	}
	return d
}

// Days returns up to n most recent days, oldest first, today last.
func (t *Tracker) Days(n int, price func(model string) Prices) []Day {
	if t == nil {
		return nil
	}
	t.mu.Lock()
	defer t.mu.Unlock()
	t.roll()
	var out []Day
	for _, h := range t.d.History {
		out = append(out, sumDay(h.Day, h.Models, h.Calls, price))
	}
	out = append(out, sumDay(t.d.Day, t.d.Models, t.d.Calls, price))
	if n > 0 && len(out) > n {
		out = out[len(out)-n:]
	}
	return out
}

// DueReport returns yesterday's totals the first time it is called on a new day (so a report goes out once).
// ok is false when the report for today was already taken or there is no finished day yet.
func (t *Tracker) DueReport(price func(model string) Prices) (Day, bool) {
	if t == nil {
		return Day{}, false
	}
	t.mu.Lock()
	defer t.mu.Unlock()
	t.roll()
	if t.d.Reported == t.d.Day || len(t.d.History) == 0 {
		return Day{}, false
	}
	h := t.d.History[len(t.d.History)-1]
	t.d.Reported = t.d.Day
	t.save()
	return sumDay(h.Day, h.Models, h.Calls, price), true
}

// SetNow replaces the clock (tests and screenshots).
func (t *Tracker) SetNow(f func() time.Time) { t.mu.Lock(); t.now = f; t.mu.Unlock() }
