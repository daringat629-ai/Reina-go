// Package mailtest has stand-in IMAP and SMTP servers for tests of the mail code.
package mailtest

import (
	"bufio"
	"encoding/base64"
	"fmt"
	"net"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"testing"
)

func B64(s string) string { return base64.StdEncoding.EncodeToString([]byte(s)) }

func CP1251(s string) string {
	var out []byte
	for _, r := range s {
		switch {
		case r < 0x80:
			out = append(out, byte(r))
		case r >= 0x410 && r <= 0x44F:
			out = append(out, byte(r-0x410+0xC0))
		case r == 'ё':
			out = append(out, 0xB8)
		}
	}
	return string(out)
}

var Mails = map[int]string{
	1: "From: =?utf-8?B?" + B64("Анна Петрова") + "?= <anna@example.org>\r\nTo: me@example.org\r\nSubject: =?utf-8?B?" + B64("Встреча в пятницу") + "?=\r\nDate: Mon, 19 Oct 2026 10:30:00 +0600\r\nMessage-ID: <m1@example.org>\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" + B64("Привет! Давай в пятницу в 15:00.\nАнна") + "\r\n",
	2: "From: shop@example.com\r\nSubject: Your order\r\nDate: Tue, 20 Oct 2026 09:00:00 +0000\r\nMIME-Version: 1.0\r\nContent-Type: multipart/alternative; boundary=\"b1\"\r\n\r\n--b1\r\nContent-Type: text/html; charset=utf-8\r\n\r\n<html><body><p>HTML only <b>version</b></p></body></html>\r\n--b1\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Transfer-Encoding: quoted-printable\r\n\r\nPlain =D0=BF=D1=80=D0=B8=D0=B2=D0=B5=D1=82 version=\r\n continues\r\n--b1--\r\n",
	3: "From: boss@example.net\r\nSubject: Report\r\nDate: Tue, 20 Oct 2026 12:00:00 +0300\r\nMIME-Version: 1.0\r\nContent-Type: multipart/mixed; boundary=\"b2\"\r\n\r\n--b2\r\nContent-Type: text/plain; charset=windows-1251\r\nContent-Transfer-Encoding: 8bit\r\n\r\n" + CP1251("Отчёт во вложении") + "\r\n--b2\r\nContent-Type: application/pdf; name=\"report.pdf\"\r\nContent-Disposition: attachment; filename=\"report.pdf\"\r\nContent-Transfer-Encoding: base64\r\n\r\nJVBERi0xLjQ=\r\n--b2--\r\n",
}

type IMAPStub struct {
	Ln       net.Listener
	mu       sync.Mutex
	Criteria []string
	Examined []string
	Stored   bool
}

func StartIMAP(t *testing.T) *IMAPStub {
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	s := &IMAPStub{Ln: ln}
	t.Cleanup(func() { ln.Close() })
	go func() {
		for {
			c, err := ln.Accept()
			if err != nil {
				return
			}
			go s.serve(c)
		}
	}()
	return s
}

var fetchHdr = regexp.MustCompile(`^(\w+) UID FETCH ([\d,]+) \(UID FLAGS BODY\.PEEK\[HEADER\.FIELDS`)
var fetchBody = regexp.MustCompile(`^(\w+) UID FETCH (\d+) \(BODY\.PEEK\[\]<0\.(\d+)>\)`)

func (s *IMAPStub) serve(c net.Conn) {
	defer c.Close()
	r := bufio.NewReader(c)
	fmt.Fprint(c, "* OK stub ready\r\n")
	for {
		line, err := r.ReadString('\n')
		if err != nil {
			return
		}
		line = strings.TrimRight(line, "\r\n")
		f := strings.SplitN(line, " ", 3)
		tag := f[0]
		switch {
		case strings.Contains(line, " LOGIN "):
			if strings.Contains(line, `"me@example.org" "app-pass"`) {
				fmt.Fprintf(c, "%s OK logged in\r\n", tag)
			} else {
				fmt.Fprintf(c, "%s NO [AUTHENTICATIONFAILED] bad\r\n", tag)
			}
		case strings.Contains(line, " EXAMINE "):
			s.mu.Lock()
			s.Examined = append(s.Examined, line)
			s.mu.Unlock()
			fmt.Fprintf(c, "* 3 EXISTS\r\n%s OK [READ-ONLY] done\r\n", tag)
		case strings.Contains(line, " UID SEARCH "):
			s.mu.Lock()
			s.Criteria = append(s.Criteria, line)
			s.mu.Unlock()
			fmt.Fprintf(c, "* SEARCH 1 2 3\r\n%s OK done\r\n", tag)
		case fetchHdr.MatchString(line):
			m := fetchHdr.FindStringSubmatch(line)
			for _, u := range strings.Split(m[2], ",") {
				n, _ := strconv.Atoi(u)
				raw := Mails[n]
				hdr := raw[:strings.Index(raw, "\r\n\r\n")+4]
				flags := `\Seen`
				if n == 2 {
					flags = ""
				}
				fmt.Fprintf(c, "* %d FETCH (UID %d FLAGS (%s) BODY[HEADER.FIELDS (FROM SUBJECT DATE)] {%d}\r\n%s)\r\n", n, n, flags, len(hdr), hdr)
			}
			fmt.Fprintf(c, "%s OK done\r\n", tag)
		case fetchBody.MatchString(line):
			m := fetchBody.FindStringSubmatch(line)
			n, _ := strconv.Atoi(m[2])
			raw, ok := Mails[n]
			if !ok {
				fmt.Fprintf(c, "%s OK done\r\n", tag)
				continue
			}
			fmt.Fprintf(c, "* %d FETCH (UID %d BODY[]<0> {%d}\r\n%s)\r\n%s OK done\r\n", n, n, len(raw), raw, tag)
		case strings.Contains(line, " STORE "):
			s.Stored = true
			fmt.Fprintf(c, "%s OK\r\n", tag)
		case strings.Contains(line, " LOGOUT"):
			fmt.Fprintf(c, "* BYE\r\n%s OK bye\r\n", tag)
			return
		default:
			fmt.Fprintf(c, "%s BAD unknown\r\n", tag)
		}
	}
}

type SMTPStub struct {
	Ln   net.Listener
	Got  chan string
	Auth chan string
}

func StartSMTP(t *testing.T) *SMTPStub {
	ln, _ := net.Listen("tcp", "127.0.0.1:0")
	s := &SMTPStub{Ln: ln, Got: make(chan string, 4), Auth: make(chan string, 4)}
	t.Cleanup(func() { ln.Close() })
	go func() {
		c, err := ln.Accept()
		if err != nil {
			return
		}
		defer c.Close()
		r := bufio.NewReader(c)
		fmt.Fprint(c, "220 stub\r\n")
		var data strings.Builder
		in := false
		var rcpts []string
		for {
			line, err := r.ReadString('\n')
			if err != nil {
				return
			}
			line = strings.TrimRight(line, "\r\n")
			if in {
				if line == "." {
					in = false
					s.Got <- strings.Join(rcpts, ",") + "\n" + data.String()
					fmt.Fprint(c, "250 queued\r\n")
					continue
				}
				data.WriteString(line + "\r\n")
				continue
			}
			switch {
			case strings.HasPrefix(line, "EHLO"):
				fmt.Fprint(c, "250-stub\r\n250 AUTH PLAIN\r\n")
			case strings.HasPrefix(line, "AUTH PLAIN"):
				s.Auth <- line
				fmt.Fprint(c, "235 ok\r\n")
			case strings.HasPrefix(line, "MAIL FROM"):
				fmt.Fprint(c, "250 ok\r\n")
			case strings.HasPrefix(line, "RCPT TO"):
				rcpts = append(rcpts, strings.Trim(line[len("RCPT TO:"):], "<> "))
				fmt.Fprint(c, "250 ok\r\n")
			case line == "DATA":
				in = true
				fmt.Fprint(c, "354 go\r\n")
			case line == "QUIT":
				fmt.Fprint(c, "221 bye\r\n")
				return
			default:
				fmt.Fprint(c, "250 ok\r\n")
			}
		}
	}()
	return s
}
