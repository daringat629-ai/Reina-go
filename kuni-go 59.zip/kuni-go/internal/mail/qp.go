package mail

import (
	"io"
	"mime/quotedprintable"
)

func quotedPrintable(r io.Reader) io.Reader { return quotedprintable.NewReader(r) }
