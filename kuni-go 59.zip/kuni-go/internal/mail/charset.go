package mail

import (
	"fmt"
	"io"
	"strings"
	"unicode/utf8"
)

// A small set of charsets that real mail still uses; no outside packages.

var cp1251High = [64]rune{
	0x0402, 0x0403, 0x201A, 0x0453, 0x201E, 0x2026, 0x2020, 0x2021, 0x20AC, 0x2030, 0x0409, 0x2039, 0x040A, 0x040C, 0x040B, 0x040F,
	0x0452, 0x2018, 0x2019, 0x201C, 0x201D, 0x2022, 0x2013, 0x2014, 0xFFFD, 0x2122, 0x0459, 0x203A, 0x045A, 0x045C, 0x045B, 0x045F,
	0x00A0, 0x040E, 0x045E, 0x0408, 0x00A4, 0x0490, 0x00A6, 0x00A7, 0x0401, 0x00A9, 0x0404, 0x00AB, 0x00AC, 0x00AD, 0x00AE, 0x0407,
	0x00B0, 0x00B1, 0x0406, 0x0456, 0x0491, 0x00B5, 0x00B6, 0x00B7, 0x0451, 0x2116, 0x0454, 0x00BB, 0x0458, 0x0405, 0x0455, 0x0457,
}

const koi8Low = "юабцдефгхийклмнопярстужвьызшэщчъ"

func decode1251(b []byte) string {
	var sb strings.Builder
	for _, c := range b {
		switch {
		case c < 0x80:
			sb.WriteByte(c)
		case c < 0xC0:
			sb.WriteRune(cp1251High[c-0x80])
		default:
			sb.WriteRune(rune(0x0410) + rune(c-0xC0))
		}
	}
	return sb.String()
}

func decodeKOI8R(b []byte) string {
	low := []rune(koi8Low)
	var sb strings.Builder
	for _, c := range b {
		switch {
		case c < 0x80:
			sb.WriteByte(c)
		case c == 0xA3:
			sb.WriteRune('ё')
		case c == 0xB3:
			sb.WriteRune('Ё')
		case c >= 0xC0 && c < 0xE0:
			sb.WriteRune(low[c-0xC0])
		case c >= 0xE0:
			sb.WriteRune([]rune(strings.ToUpper(koi8Low))[c-0xE0])
		default:
			sb.WriteRune('?')
		}
	}
	return sb.String()
}

func decodeLatin1(b []byte) string {
	r := make([]rune, len(b))
	for i, c := range b {
		r[i] = rune(c)
	}
	return string(r)
}

// ToUTF8 converts text in the named charset to UTF-8 (unknown charsets pass through as they are).
func ToUTF8(charset string, b []byte) string {
	switch strings.ToLower(strings.TrimSpace(charset)) {
	case "windows-1251", "cp1251", "win-1251":
		return decode1251(b)
	case "koi8-r", "koi8r":
		return decodeKOI8R(b)
	case "iso-8859-1", "latin1", "windows-1252", "iso-8859-15":
		return decodeLatin1(b)
	}
	if !utf8.Valid(b) {
		return strings.ToValidUTF8(string(b), "?")
	}
	return string(b)
}

// charsetReader is for mime.WordDecoder.
func charsetReader(charset string, in io.Reader) (io.Reader, error) {
	b, err := io.ReadAll(io.LimitReader(in, 1<<20))
	if err != nil {
		return nil, err
	}
	switch strings.ToLower(charset) {
	case "utf-8", "us-ascii", "windows-1251", "cp1251", "koi8-r", "iso-8859-1", "latin1", "windows-1252", "iso-8859-15":
		return strings.NewReader(ToUTF8(charset, b)), nil
	}
	return nil, fmt.Errorf("unsupported charset %q", charset)
}
