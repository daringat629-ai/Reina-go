package mail

import (
	"context"
	"strings"
	"testing"
	"time"

	"kuni/internal/mail/mailtest"
)

func TestIMAPListReadAndLogin(t *testing.T) {
	s := mailtest.StartIMAP(t)
	acc := Account{IMAPHost: s.Ln.Addr().String(), User: "me@example.org", Password: "app-pass", Plain: true}
	ctx := context.Background()
	if _, err := DialIMAP(ctx, Account{IMAPHost: acc.IMAPHost, User: "me@example.org", Password: "wrong", Plain: true}); err == nil || !strings.Contains(err.Error(), "пароль приложения") {
		t.Fatalf("a wrong password must say what to do: %v", err)
	}
	if _, err := DialIMAP(ctx, Account{}); err == nil {
		t.Fatal("unconfigured")
	}
	m, err := DialIMAP(ctx, acc)
	if err != nil {
		t.Fatal(err)
	}
	defer m.Close()
	if err := m.Select(""); err != nil {
		t.Fatal(err)
	}
	uids, err := m.Search(Query{Unseen: true, From: "Анна", Since: time.Date(2026, 10, 1, 0, 0, 0, 0, time.UTC)}, 2)
	if err != nil || len(uids) != 2 || uids[0] != 3 || uids[1] != 2 {
		t.Fatalf("newest first and limited: %v %v", uids, err)
	}
	crit := s.Criteria[0]
	for _, want := range []string{"UID SEARCH CHARSET UTF-8", "UNSEEN", `FROM "Анна"`, "SINCE 1-Oct-2026"} {
		if !strings.Contains(crit, want) {
			t.Errorf("criteria %q lacks %q", crit, want)
		}
	}
	if !strings.Contains(s.Examined[0], "EXAMINE") || s.Stored {
		t.Fatal("folders are opened read-only and nothing is marked")
	}
	hs, err := m.Headers([]int{1, 2, 3})
	if err != nil || len(hs) != 3 {
		t.Fatalf("%v %v", hs, err)
	}
	if hs[0].From != "Анна Петрова <anna@example.org>" || hs[0].Subject != "Встреча в пятницу" || !hs[0].Seen || hs[1].Seen || hs[0].Date != "2026-10-19 10:30" {
		t.Fatalf("%+v", hs[0])
	}

	msg, err := m.Fetch(1, 100000)
	if err != nil || !strings.Contains(msg.Text, "Давай в пятницу в 15:00.") {
		t.Fatalf("%v %+v", err, msg)
	}
	msg, _ = m.Fetch(2, 100000)
	if !strings.Contains(msg.Text, "Plain привет version continues") || msg.HasHTMLOnly {
		t.Fatalf("plain part is preferred and quoted-printable decoded: %+v", msg)
	}
	msg, _ = m.Fetch(3, 100000)
	if !strings.Contains(msg.Text, "Отчёт во вложении") || len(msg.Attachments) != 1 || msg.Attachments[0] != "report.pdf" {
		t.Fatalf("windows-1251 body and the attachment name: %+v", msg)
	}
	if _, err := m.Fetch(99, 1000); err == nil {
		t.Fatal("missing message")
	}
}

func TestHTMLOnlyMessageAndKOI8(t *testing.T) {
	raw := "From: a@b.c\r\nSubject: =?koi8-r?B?" + mailtest.B64("\xf0\xd2\xc9\xd7\xc5\xd4") + "?=\r\nContent-Type: text/html; charset=utf-8\r\n\r\n<p>Только <b>HTML</b></p>"
	m, err := ParseMessage([]byte(raw))
	if err != nil || !m.HasHTMLOnly || !strings.Contains(m.Text, "Только HTML") {
		t.Fatalf("%v %+v", err, m)
	}
	if m.Subject != "Привет" {
		t.Fatalf("koi8-r subject: %q", m.Subject)
	}
	if got := ToUTF8("windows-1251", []byte{0xA8, 0xB8, 0xC0, 0xFF, 0x97}); got != "ЁёАя—" {
		t.Fatalf("%q", got)
	}
}

func TestSendBuildsASafeMessage(t *testing.T) {
	s := mailtest.StartSMTP(t)
	err := Send(Account{SMTPHost: s.Ln.Addr().String(), User: "me@example.org", Password: "app-pass", From: "Reina <me@example.org>", Plain: true},
		Outgoing{To: []string{"Анна <anna@example.org>", "bob@example.net"}, Subject: "Пятница в 15:00", Body: "Договорились!\nДо встречи.", InReplyTo: "<m1@example.org>"})
	if err != nil {
		t.Fatal(err)
	}
	got := <-s.Got
	rcpt, raw, _ := strings.Cut(got, "\n")
	if rcpt != "anna@example.org,bob@example.net" {
		t.Fatalf("recipients: %s", rcpt)
	}
	for _, want := range []string{"From: \"Reina\" <me@example.org>", "Subject: =?utf-8?q?", "In-Reply-To: <m1@example.org>", "Content-Transfer-Encoding: base64", "MIME-Version: 1.0"} {
		if !strings.Contains(raw, want) {
			t.Errorf("missing %q in\n%s", want, raw)
		}
	}
	parsed, err := ParseMessage([]byte(raw))
	if err != nil || parsed.Subject != "Пятница в 15:00" || !strings.Contains(parsed.Text, "Договорились!\nДо встречи.") {
		t.Fatalf("round trip: %v %+v", err, parsed)
	}
	if a := <-s.Auth; !strings.HasPrefix(a, "AUTH PLAIN") {
		t.Fatal(a)
	}
}

func TestBuildRefusesInjectionAndBadAddresses(t *testing.T) {
	now := time.Now()
	for name, o := range map[string]Outgoing{
		"newline in subject": {To: []string{"a@b.c"}, Subject: "hi\r\nBcc: evil@x.y", Body: "x"},
		"bad rcpt":           {To: []string{"not an address"}, Subject: "s", Body: "x"},
		"no rcpt":            {Subject: "s", Body: "x"},
		"too many":           {To: []string{"a@b.c", "b@b.c", "c@b.c", "d@b.c", "e@b.c", "f@b.c"}, Subject: "s", Body: "x"},
		"newline in reply":   {To: []string{"a@b.c"}, Subject: "s", Body: "x", InReplyTo: "<a>\r\nBcc: z@z.z"},
	} {
		if _, _, err := Build("me@example.org", o, now); err == nil {
			t.Errorf("%s must be refused", name)
		}
	}
	if _, _, err := Build("nonsense", Outgoing{To: []string{"a@b.c"}}, now); err == nil {
		t.Error("bad sender")
	}
	if err := Send(Account{User: "x@y.z"}, Outgoing{To: []string{"a@b.c"}}); err == nil {
		t.Error("smtp not configured")
	}
}

func TestOnlyALocalRelayMayGoUnencrypted(t *testing.T) {
	for host, want := range map[string]bool{"localhost": true, "127.0.0.1": true, "::1": true, "smtp.example.org": false, "10.0.0.5": false} {
		if isLoopbackHost(host) != want {
			t.Errorf("%s: want %v", host, want)
		}
	}
}
