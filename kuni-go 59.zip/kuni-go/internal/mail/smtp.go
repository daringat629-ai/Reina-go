package mail

import (
	"crypto/rand"
	"crypto/tls"
	"encoding/base64"
	"errors"
	"fmt"
	"mime"
	"net"
	stdmail "net/mail"
	"net/smtp"
	"strings"
	"time"
)

// Outgoing is a message to send.
type Outgoing struct {
	To        []string
	Subject   string
	Body      string
	InReplyTo string
}

// Build renders the message: UTF-8 text, base64 body, encoded subject. Headers cannot be injected.
func Build(from string, o Outgoing, now time.Time) ([]byte, []string, error) {
	fa, err := stdmail.ParseAddress(from)
	if err != nil {
		return nil, nil, fmt.Errorf("плохой адрес отправителя %q", from)
	}
	if len(o.To) == 0 || len(o.To) > 5 {
		return nil, nil, errors.New("нужен от 1 до 5 получателей")
	}
	var rcpt, shown []string
	for _, t := range o.To {
		a, err := stdmail.ParseAddress(strings.TrimSpace(t))
		if err != nil {
			return nil, nil, fmt.Errorf("плохой адрес получателя %q", t)
		}
		rcpt = append(rcpt, a.Address)
		shown = append(shown, a.String())
	}
	if strings.ContainsAny(o.Subject, "\r\n") || strings.ContainsAny(o.InReplyTo, "\r\n") {
		return nil, nil, errors.New("перевод строки в теме или в ответе")
	}
	id := make([]byte, 8)
	_, _ = rand.Read(id)
	domain := fa.Address[strings.LastIndex(fa.Address, "@")+1:]
	var b strings.Builder
	h := func(k, v string) { b.WriteString(k + ": " + v + "\r\n") }
	h("From", fa.String())
	h("To", strings.Join(shown, ", "))
	h("Subject", mime.QEncoding.Encode("utf-8", o.Subject))
	h("Date", now.Format(time.RFC1123Z))
	h("Message-ID", fmt.Sprintf("<%x@%s>", id, domain))
	if o.InReplyTo != "" {
		h("In-Reply-To", o.InReplyTo)
		h("References", o.InReplyTo)
	}
	h("MIME-Version", "1.0")
	h("Content-Type", `text/plain; charset="utf-8"`)
	h("Content-Transfer-Encoding", "base64")
	b.WriteString("\r\n")
	enc := base64.StdEncoding.EncodeToString([]byte(o.Body))
	for len(enc) > 76 {
		b.WriteString(enc[:76] + "\r\n")
		enc = enc[76:]
	}
	b.WriteString(enc + "\r\n")
	return []byte(b.String()), rcpt, nil
}

// Send delivers the message through the account's SMTP server (587 STARTTLS or 465 TLS).
func Send(a Account, o Outgoing) error {
	from := a.From
	if from == "" {
		from = a.User
	}
	raw, rcpt, err := Build(from, o, time.Now())
	if err != nil {
		return err
	}
	fa, _ := stdmail.ParseAddress(from)
	host := a.SMTPHost
	if host == "" {
		return errors.New("почта не настроена: заполни mail.smtp_host")
	}
	if !strings.Contains(host, ":") {
		host += ":587"
	}
	name := strings.Split(host, ":")[0]
	d := net.Dialer{Timeout: 20 * time.Second}
	var conn net.Conn
	if strings.HasSuffix(host, ":465") {
		conn, err = tls.DialWithDialer(&d, "tcp", host, &tls.Config{ServerName: name})
	} else {
		conn, err = d.Dial("tcp", host)
	}
	if err != nil {
		return fmt.Errorf("smtp: %w", err)
	}
	_ = conn.SetDeadline(time.Now().Add(60 * time.Second))
	c, err := smtp.NewClient(conn, name)
	if err != nil {
		conn.Close()
		return err
	}
	defer c.Close()
	if !a.Plain && !strings.HasSuffix(host, ":465") {
		// without encryption the letter (and the password) would cross the network readable: a server that does not
		// offer it is refused, except a relay on this very machine (nothing leaves it unencrypted)
		if ok, _ := c.Extension("STARTTLS"); ok {
			if err := c.StartTLS(&tls.Config{ServerName: name}); err != nil {
				return err
			}
		} else if !isLoopbackHost(name) {
			return errors.New("smtp: сервер не предлагает шифрование (STARTTLS) — письмо ушло бы открытым текстом; укажи порт 465 или сервер с STARTTLS")
		}
	}
	if a.Password != "" {
		if err := c.Auth(smtp.PlainAuth("", a.User, a.Password, name)); err != nil {
			return fmt.Errorf("smtp: вход не удался: %w", err)
		}
	}
	if err := c.Mail(fa.Address); err != nil {
		return err
	}
	for _, r := range rcpt {
		if err := c.Rcpt(r); err != nil {
			return fmt.Errorf("получатель %s не принят: %w", r, err)
		}
	}
	w, err := c.Data()
	if err != nil {
		return err
	}
	if _, err := w.Write(raw); err != nil {
		return err
	}
	if err := w.Close(); err != nil {
		return err
	}
	return c.Quit()
}

// isLoopbackHost reports whether host names this machine.
func isLoopbackHost(host string) bool {
	if host == "localhost" {
		return true
	}
	ip := net.ParseIP(host)
	return ip != nil && ip.IsLoopback()
}
