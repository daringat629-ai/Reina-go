package browser

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"sync"
	"time"
)

// cdp is one Chrome DevTools protocol connection (to a page).
type cdp struct {
	ws      *wsConn
	mu      sync.Mutex
	next    int64
	pending map[int64]chan cdpReply
	onEvent func(method string, params json.RawMessage)
	done    chan struct{}
	err     error
}

type cdpReply struct {
	Result json.RawMessage
	Err    error
}

func newCDP(ws *wsConn, onEvent func(string, json.RawMessage)) *cdp {
	c := &cdp{ws: ws, pending: map[int64]chan cdpReply{}, onEvent: onEvent, done: make(chan struct{})}
	go c.loop()
	return c
}

func (c *cdp) loop() {
	defer close(c.done)
	for {
		raw, err := c.ws.read()
		if err != nil {
			c.mu.Lock()
			c.err = err
			for id, ch := range c.pending {
				ch <- cdpReply{Err: fmt.Errorf("browser connection lost: %w", err)}
				delete(c.pending, id)
			}
			c.mu.Unlock()
			return
		}
		var m struct {
			ID     int64           `json:"id"`
			Method string          `json:"method"`
			Params json.RawMessage `json:"params"`
			Result json.RawMessage `json:"result"`
			Error  *struct {
				Code    int    `json:"code"`
				Message string `json:"message"`
			} `json:"error"`
		}
		if json.Unmarshal(raw, &m) != nil {
			continue
		}
		if m.ID == 0 {
			if m.Method != "" && c.onEvent != nil {
				c.onEvent(m.Method, m.Params)
			}
			continue
		}
		c.mu.Lock()
		ch := c.pending[m.ID]
		delete(c.pending, m.ID)
		c.mu.Unlock()
		if ch == nil {
			continue
		}
		if m.Error != nil {
			ch <- cdpReply{Err: fmt.Errorf("browser: %s", m.Error.Message)}
		} else {
			ch <- cdpReply{Result: m.Result}
		}
	}
}

// call sends one command and decodes the result into out (may be nil).
func (c *cdp) call(ctx context.Context, method string, params any, out any) error {
	ch := make(chan cdpReply, 1)
	c.mu.Lock()
	if c.err != nil {
		err := c.err
		c.mu.Unlock()
		return fmt.Errorf("browser connection lost: %w", err)
	}
	c.next++
	id := c.next
	c.pending[id] = ch
	c.mu.Unlock()
	if params == nil {
		params = map[string]any{}
	}
	b, _ := json.Marshal(map[string]any{"id": id, "method": method, "params": params})
	if err := c.ws.write(0x1, b); err != nil {
		return err
	}
	select {
	case r := <-ch:
		if r.Err != nil {
			return r.Err
		}
		if out != nil && len(r.Result) > 0 {
			return json.Unmarshal(r.Result, out)
		}
		return nil
	case <-ctx.Done():
		c.mu.Lock()
		delete(c.pending, id)
		c.mu.Unlock()
		return ctx.Err()
	case <-time.After(60 * time.Second):
		c.mu.Lock()
		delete(c.pending, id)
		c.mu.Unlock()
		return errors.New("browser did not answer in 60 s")
	}
}

func (c *cdp) close() { c.ws.close() }
