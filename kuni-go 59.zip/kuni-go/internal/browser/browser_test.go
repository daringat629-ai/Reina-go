package browser

import (
	"bufio"
	"context"
	"fmt"
	"net"
	"net/http"
	"net/http/httptest"
	"os/exec"
	"strings"
	"testing"
	"time"
)

const pageHTML = `<!doctype html><html><head><title>Тест</title></head><body>
<h1>Привет, мир</h1>
<a href="/two">Вторая страница</a>
<a href="/blank" target="_blank">Новая вкладка</a>
<input id="q" placeholder="Поиск" value="">
<select id="s"><option value="a">Яблоко</option><option value="b">Груша</option></select>
<button onclick="document.getElementById('out').textContent='нажато '+(++window.n)">Кнопка</button>
<button onclick="alert('внимание')">Алерт</button>
<div id="out">пусто</div>
<form action="/search"><input name="term" placeholder="Форма"></form>
<div style="height:3000px">длинный блок</div><p>конец страницы</p>
<script>window.n=0</script></body></html>`

func server() *httptest.Server {
	mux := http.NewServeMux()
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) { fmt.Fprint(w, pageHTML) })
	mux.HandleFunc("/two", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprint(w, `<title>Две</title><h1>Вторая</h1><a href="/">назад домой</a>`)
	})
	mux.HandleFunc("/blank", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprint(w, `<title>Blank</title><h1>Открылось</h1>`)
	})
	mux.HandleFunc("/search", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprintf(w, `<title>Поиск</title><h1>Искали: %s</h1>`, r.URL.Query().Get("term"))
	})
	return httptest.NewServer(mux)
}

func find(sn Snapshot, label string) int {
	for _, e := range sn.Els {
		if strings.Contains(e.Label, label) {
			return e.ID
		}
	}
	return 0
}

func TestRealBrowserEndToEnd(t *testing.T) {
	if Find("") == "" {
		t.Skip("no chromium on this machine")
	}
	srv := server()
	defer srv.Close()
	b := New()
	defer b.Close()
	opt := Options{ProfileDir: t.TempDir(), NoSandbox: true, Idle: time.Minute}
	ctx, cancel := context.WithTimeout(context.Background(), 90*time.Second)
	defer cancel()

	err := b.Do(ctx, opt, func(s *Session) error {
		if err := s.Open(ctx, srv.URL); err != nil {
			return err
		}
		sn, err := s.Look(ctx, 500)
		if err != nil {
			return err
		}
		if sn.Title != "Тест" || !strings.Contains(sn.Text, "Привет, мир") {
			t.Fatalf("page not read: %+v", sn)
		}
		for _, l := range []string{"Вторая страница", "Кнопка", "Поиск"} {
			if find(sn, l) == 0 {
				t.Fatalf("element %q not listed:\n%s", l, sn)
			}
		}
		// click a button twice: the page counts
		btn := find(sn, "Кнопка")
		if err := s.Click(ctx, btn); err != nil {
			return err
		}
		sn, _ = s.Look(ctx, 500)
		if !strings.Contains(sn.Text, "нажато 1") {
			t.Fatalf("click did not reach the page:\n%s", sn)
		}
		// typing and a select
		if err := s.Type(ctx, find(sn, "Поиск"), "кошки", true, false); err != nil {
			return err
		}
		if err := s.Type(ctx, find(sn, "Яблоко"), "груша", false, false); err != nil {
			return err
		}
		sn, _ = s.Look(ctx, 500)
		if !strings.Contains(sn.String(), "= «кошки»") {
			t.Fatalf("text was not typed:\n%s", sn)
		}
		// a javascript alert must not freeze the browser
		if err := s.Click(ctx, find(sn, "Алерт")); err != nil {
			return err
		}
		sn, err = s.Look(ctx, 500)
		if err != nil || !strings.Contains(strings.Join(sn.Notes, ";"), "внимание") {
			t.Fatalf("alert not handled: %v %v", sn.Notes, err)
		}
		// form submit with Enter navigates
		if err := s.Type(ctx, find(sn, "Форма"), "собаки", true, true); err != nil {
			return err
		}
		sn, _ = s.Look(ctx, 500)
		if !strings.Contains(sn.Text, "Искали: собаки") {
			t.Fatalf("enter did not submit:\n%s", sn)
		}
		if err := s.Back(ctx); err != nil {
			return err
		}
		// link navigation and the popup link (target=_blank) both end up in the working tab
		sn, _ = s.Look(ctx, 500)
		if err := s.Click(ctx, find(sn, "Вторая страница")); err != nil {
			return err
		}
		if sn, _ = s.Look(ctx, 500); sn.Title != "Две" {
			t.Fatalf("link not followed: %q", sn.Title)
		}
		if err := s.Back(ctx); err != nil {
			return err
		}
		sn, _ = s.Look(ctx, 500)
		if err := s.Click(ctx, find(sn, "Новая вкладка")); err != nil {
			return err
		}
		if sn, _ = s.Look(ctx, 500); sn.Title != "Blank" {
			t.Fatalf("target=_blank link not followed: %q", sn.Title)
		}
		if err := s.Open(ctx, srv.URL); err != nil {
			return err
		}
		// scrolling and the long text
		if err := s.Scroll(ctx, "bottom"); err != nil {
			return err
		}
		sn, _ = s.Look(ctx, 100)
		if !strings.Contains(sn.String(), "(конец)") || sn.ScrollY < 100 {
			t.Fatalf("scroll did not move: %+v", sn)
		}
		txt, total, err := s.Text(ctx, 0, 30)
		if err != nil || total < 40 || txt == "" {
			t.Fatalf("text: %q %d %v", txt, total, err)
		}
		// screenshots: viewport PNG and a full-page JPEG
		png, ext, err := s.Shot(ctx, false)
		if err != nil || ext != "png" || len(png) < 1000 || string(png[1:4]) != "PNG" {
			t.Fatalf("screenshot: %d bytes %s %v", len(png), ext, err)
		}
		jpg, ext, err := s.Shot(ctx, true)
		if err != nil || ext != "jpg" || len(jpg) < 1000 || jpg[0] != 0xFF {
			t.Fatalf("full screenshot: %d bytes %s %v", len(jpg), ext, err)
		}
		// forbidden schemes
		for _, u := range []string{"file:///etc/passwd", "javascript:alert(1)", "chrome://settings", "data:text/html,x"} {
			if s.Open(ctx, u) == nil {
				t.Errorf("%s must be refused", u)
			}
		}
		// a wrong address is an error, not a hang
		if err := s.Open(ctx, "http://no-such-host.invalid/"); err == nil {
			t.Error("a dead address must fail")
		}
		return nil
	})
	if err != nil {
		t.Fatal(err)
	}
	if !b.Running() {
		t.Fatal("browser should still be running between calls")
	}
	b.Close()
	if b.Running() {
		t.Fatal("Close must stop the process")
	}
	// it comes back by itself, with the same profile
	if err := b.Do(ctx, opt, func(s *Session) error { return s.Open(ctx, srv.URL) }); err != nil {
		t.Fatalf("restart after close: %v", err)
	}
}

func TestIdleClosesTheBrowser(t *testing.T) {
	if Find("") == "" {
		t.Skip("no chromium on this machine")
	}
	b := New()
	defer b.Close()
	opt := Options{ProfileDir: t.TempDir(), NoSandbox: true, Idle: 800 * time.Millisecond}
	if err := b.Do(context.Background(), opt, func(s *Session) error { return nil }); err != nil {
		t.Fatal(err)
	}
	time.Sleep(2 * time.Second)
	if b.Running() {
		t.Fatal("an idle browser must close itself (memory)")
	}
}

func TestMissingBrowserSaysHowToInstall(t *testing.T) {
	b := New()
	err := b.Do(context.Background(), Options{Path: "definitely-not-a-browser", ProfileDir: t.TempDir()}, func(s *Session) error { return nil })
	if err == nil || !strings.Contains(err.Error(), "apk add chromium") {
		t.Fatalf("unhelpful error: %v", err)
	}
}

func TestAllowedURL(t *testing.T) {
	for in, ok := range map[string]bool{"example.com": true, "https://a.b/c?d=1": true, "http://localhost:8080": true, "ftp://x.y": false, "file:///etc/passwd": false, "": false} {
		if _, err := allowedURL(in); (err == nil) != ok {
			t.Errorf("%q: ok=%v err=%v", in, ok, err)
		}
	}
}

func TestWebsocketFramesRoundTrip(t *testing.T) {
	a, b := net.Pipe()
	defer a.Close()
	defer b.Close()
	client, server := &wsConn{c: a, br: bufio.NewReader(a)}, &wsConn{c: b, br: bufio.NewReader(b)}
	for _, n := range []int{5, 200, 70000} { // 7-bit, 16-bit and 64-bit length forms
		msg := []byte(strings.Repeat("я", n/2+1))
		go func() { _ = client.write(0x1, msg) }()
		got, err := server.read()
		if err != nil || string(got) != string(msg) {
			t.Fatalf("n=%d: %v (len %d)", n, err, len(got))
		}
	}
}

func TestGraphicalModeOnVirtualScreen(t *testing.T) {
	if Find("") == "" {
		t.Skip("no chromium on this machine")
	}
	if _, err := exec.LookPath("Xvfb"); err != nil {
		t.Skip("no Xvfb")
	}
	srv := server()
	defer srv.Close()
	b := New()
	defer b.Close()
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()
	err := b.Do(ctx, Options{ProfileDir: t.TempDir(), NoSandbox: true, Xvfb: true}, func(s *Session) error {
		if err := s.Open(ctx, srv.URL); err != nil {
			return err
		}
		sn, err := s.Look(ctx, 200)
		if err != nil || sn.Title != "Тест" {
			t.Fatalf("%+v %v", sn, err)
		}
		png, _, err := s.Shot(ctx, false)
		if err != nil || len(png) < 1000 {
			t.Fatalf("shot %d %v", len(png), err)
		}
		return nil
	})
	if err != nil {
		t.Fatal(err)
	}
	pid := b.xvfb.Process.Pid
	b.Close()
	time.Sleep(500 * time.Millisecond)
	if syscallProbe(pid) == nil {
		t.Fatal("Xvfb must stop with the browser")
	}
}
