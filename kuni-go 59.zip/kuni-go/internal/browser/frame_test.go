package browser

import (
	"bytes"
	"context"
	"image/jpeg"
	"testing"
	"time"
)

func TestLiveFrameShowsThePageWhileAnActionRuns(t *testing.T) {
	if Find("") == "" {
		t.Skip("no chromium on this machine")
	}
	srv := server()
	defer srv.Close()
	b := New()
	defer b.Close()
	if _, ok, _ := b.Frame(context.Background()); ok || b.Live() {
		t.Fatal("a stopped browser has no picture")
	}
	opt := Options{ProfileDir: t.TempDir(), NoSandbox: true, Idle: time.Minute, Width: 900, Height: 600}
	ctx, cancel := context.WithTimeout(context.Background(), 90*time.Second)
	defer cancel()
	err := b.Do(ctx, opt, func(s *Session) error {
		if err := s.Open(ctx, srv.URL); err != nil {
			return err
		}
		// the Do call (and its lock) is still running: the live view must not need it
		data, ok, err := b.Frame(ctx)
		if err != nil || !ok {
			t.Fatalf("frame: %v %v", ok, err)
		}
		img, err := jpeg.Decode(bytes.NewReader(data))
		if err != nil || img.Bounds().Dx() < 300 {
			t.Fatalf("not a picture: %v", err)
		}
		again, ok, _ := b.Frame(ctx) // cached for a moment
		if !ok || !bytes.Equal(again, data) {
			t.Fatal("a second frame right away must come from the cache")
		}
		return nil
	})
	if err != nil {
		t.Fatal(err)
	}
	if !b.Live() {
		t.Fatal("Live must be true while the browser runs")
	}
	b.Close()
	if _, ok, _ := b.Frame(ctx); ok || b.Live() {
		t.Fatal("after Close there is no picture")
	}
}
