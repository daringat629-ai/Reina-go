//go:build !windows

package browser

import (
	"os"
	"os/exec"
	"syscall"
)

func ownGroup(c *exec.Cmd) { c.SysProcAttr = &syscall.SysProcAttr{Setpgid: true} }

// killTree stops the process and everything it started (Chromium has many helpers).
func killTree(p *os.Process) {
	if p == nil {
		return
	}
	_ = syscall.Kill(-p.Pid, syscall.SIGKILL)
	_ = p.Kill()
}

func isRoot() bool { return os.Geteuid() == 0 }
