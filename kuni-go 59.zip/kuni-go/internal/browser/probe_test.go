//go:build !windows

package browser

import "syscall"

// syscallProbe returns nil while the process exists.
func syscallProbe(pid int) error { return syscall.Kill(pid, 0) }
