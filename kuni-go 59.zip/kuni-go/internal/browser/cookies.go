package browser

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"strconv"
	"strings"
)

// Cookie is one cookie as the DevTools protocol wants it.
type Cookie struct {
	Name     string  `json:"name"`
	Value    string  `json:"value"`
	Domain   string  `json:"domain,omitempty"`
	Path     string  `json:"path,omitempty"`
	URL      string  `json:"url,omitempty"`
	Secure   bool    `json:"secure,omitempty"`
	HTTPOnly bool    `json:"httpOnly,omitempty"`
	SameSite string  `json:"sameSite,omitempty"`
	Expires  float64 `json:"expires,omitempty"`
}

// ParseCookies reads a cookie export: the JSON of Cookie-Editor / EditThisCookie / Playwright, or a Netscape cookies.txt.
func ParseCookies(data []byte) ([]Cookie, error) {
	data = bytes.TrimSpace(data)
	if len(data) == 0 {
		return nil, errors.New("файл пустой")
	}
	var cs []Cookie
	var err error
	switch data[0] {
	case '[', '{':
		cs, err = parseJSONCookies(data)
	default:
		cs, err = parseNetscape(string(data))
	}
	if err != nil {
		return nil, err
	}
	var out []Cookie
	for _, c := range cs {
		if c.Name == "" || (c.Domain == "" && c.URL == "") {
			continue
		}
		if c.Path == "" {
			c.Path = "/"
		}
		if strings.HasPrefix(c.Name, "__Host-") { // these must be set for a host, without a Domain attribute
			c.URL, c.Domain = "https://"+strings.TrimPrefix(c.Domain, ".")+"/", ""
			c.Path, c.Secure = "/", true
		}
		if strings.HasPrefix(c.Name, "__Secure-") {
			c.Secure = true
		}
		out = append(out, c)
	}
	if len(out) == 0 {
		return nil, errors.New("в файле не нашла ни одной cookie (нужен экспорт из Cookie-Editor в JSON или cookies.txt)")
	}
	return out, nil
}

func parseJSONCookies(data []byte) ([]Cookie, error) {
	var raw []map[string]any
	if data[0] == '{' { // {"cookies":[...]} as Playwright's storage state
		var wrap struct {
			Cookies []map[string]any `json:"cookies"`
		}
		if err := json.Unmarshal(data, &wrap); err != nil {
			return nil, fmt.Errorf("не JSON: %w", err)
		}
		raw = wrap.Cookies
	} else if err := json.Unmarshal(data, &raw); err != nil {
		return nil, fmt.Errorf("не JSON: %w", err)
	}
	str := func(m map[string]any, k string) string { s, _ := m[k].(string); return s }
	flag := func(m map[string]any, k string) bool { b, _ := m[k].(bool); return b }
	var out []Cookie
	for _, m := range raw {
		c := Cookie{Name: str(m, "name"), Value: str(m, "value"), Domain: str(m, "domain"), Path: str(m, "path"), Secure: flag(m, "secure"), HTTPOnly: flag(m, "httpOnly")}
		for _, k := range []string{"expirationDate", "expires"} {
			if f, ok := m[k].(float64); ok && f > 0 {
				c.Expires = f
			}
		}
		if flag(m, "session") {
			c.Expires = 0
		}
		switch strings.ToLower(str(m, "sameSite")) {
		case "no_restriction", "none":
			c.SameSite = "None"
		case "lax":
			c.SameSite = "Lax"
		case "strict":
			c.SameSite = "Strict"
		}
		out = append(out, c)
	}
	return out, nil
}

func parseNetscape(text string) ([]Cookie, error) {
	var out []Cookie
	for _, line := range strings.Split(text, "\n") {
		line = strings.TrimRight(line, "\r")
		httpOnly := false
		if strings.HasPrefix(line, "#HttpOnly_") {
			line, httpOnly = strings.TrimPrefix(line, "#HttpOnly_"), true
		}
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		f := strings.Split(line, "\t")
		if len(f) < 7 {
			continue
		}
		c := Cookie{Domain: f[0], Path: f[2], Secure: strings.EqualFold(f[3], "TRUE"), Name: f[5], Value: f[6], HTTPOnly: httpOnly}
		if n, err := strconv.ParseFloat(f[4], 64); err == nil && n > 0 {
			c.Expires = n
		}
		out = append(out, c)
	}
	if len(out) == 0 {
		return nil, errors.New("не похоже на cookies.txt")
	}
	return out, nil
}

// SetCookies puts the cookies into the browser profile. It returns how many were accepted per domain.
func (s *Session) SetCookies(ctx context.Context, cs []Cookie) (map[string]int, error) {
	per := map[string]int{}
	for _, c := range cs {
		if c.Expires > 0 && c.Expires < float64(nowUnix()) {
			continue // already expired
		}
		var r struct {
			Success bool `json:"success"`
		}
		if err := s.b.page.call(ctx, "Network.setCookie", c, &r); err != nil || !r.Success {
			continue
		}
		d := strings.TrimPrefix(c.Domain, ".")
		if d == "" {
			d = strings.TrimSuffix(strings.TrimPrefix(c.URL, "https://"), "/")
		}
		per[d]++
	}
	if len(per) == 0 {
		return nil, errors.New("браузер не принял ни одной cookie (все просрочены или неверный формат)")
	}
	return per, nil
}

func nowUnix() int64 { return timeNow().Unix() }
