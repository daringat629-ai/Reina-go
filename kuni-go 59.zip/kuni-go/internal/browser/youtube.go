package browser

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"strconv"
	"strings"
)

// Video is a card from a list of videos (home page, search, recommendations, a playlist).
type Video struct {
	ID       string `json:"id"`
	Title    string `json:"title"`
	Channel  string `json:"channel"`
	Meta     string `json:"meta"`
	Duration string `json:"dur"`
	URL      string `json:"url"`
}

const videosJS = `(()=>{
 const out=[],seen={};
 const norm=h=>{try{const u=new URL(h,location.href);
  if(u.pathname==='/watch'&&u.searchParams.get('v'))return {id:u.searchParams.get('v'),url:'https://www.youtube.com/watch?v='+u.searchParams.get('v')};
  const m=u.pathname.match(/^\/shorts\/([\w-]+)/);if(m)return {id:m[1],url:'https://www.youtube.com/shorts/'+m[1]};}catch(_){}return null};
 const txt=(e,sel)=>{const x=e&&e.querySelector(sel);return x?(x.innerText||x.textContent||'').replace(/\s+/g,' ').trim():''};
 const cards=document.querySelectorAll('ytd-rich-item-renderer,ytd-video-renderer,ytd-compact-video-renderer,ytd-grid-video-renderer,ytd-playlist-video-renderer,ytd-playlist-panel-video-renderer,yt-lockup-view-model,ytm-shorts-lockup-view-model,ytd-reel-item-renderer');
 const add=(a,card)=>{const n=norm(a.href);if(!n||seen[n.id])return;
  let title=(a.getAttribute('title')||a.getAttribute('aria-label')||a.innerText||'').replace(/\s+/g,' ').trim();
  if(!title&&card)title=txt(card,'#video-title,h3,.yt-lockup-metadata-view-model-wiz__title');
  if(!title||title.length<2)return;seen[n.id]=1;
  out.push({id:n.id,url:n.url,title:title.slice(0,140),channel:txt(card,'ytd-channel-name,#channel-name,.yt-content-metadata-view-model-wiz__metadata-text'),
   meta:txt(card,'#metadata-line,.yt-content-metadata-view-model-wiz__metadata-row'),dur:txt(card,'ytd-thumbnail-overlay-time-status-renderer,.badge-shape-wiz__text')})};
 for(const c of cards){const a=c.querySelector('a#video-title,a#video-title-link,a.yt-lockup-metadata-view-model-wiz__title,a[href*="/watch?v="],a[href*="/shorts/"]');if(a)add(a,c);if(out.length>=30)break}
 if(out.length<30){for(const a of document.querySelectorAll('a[href*="/watch?v="],a[href*="/shorts/"]')){add(a,a.closest('ytd-rich-item-renderer,ytd-video-renderer,ytd-compact-video-renderer,div'));if(out.length>=30)break}}
 return JSON.stringify(out)})()`

// Videos lists the video cards loaded on the page (scroll to load more).
func (s *Session) Videos(ctx context.Context) ([]Video, error) {
	var raw string
	if err := s.eval(ctx, videosJS, &raw); err != nil {
		return nil, err
	}
	var vs []Video
	if err := json.Unmarshal([]byte(raw), &vs); err != nil {
		return nil, err
	}
	return vs, nil
}

// FormatVideos renders the list for the model: number, title, channel, length, views/age, link.
func FormatVideos(vs []Video) string {
	if len(vs) == 0 {
		return "На странице не видно ни одного видео (прокрути вниз или открой другую страницу)."
	}
	var b strings.Builder
	for i, v := range vs {
		fmt.Fprintf(&b, "%d. %s", i+1, v.Title)
		if v.Channel != "" {
			b.WriteString(" — " + v.Channel)
		}
		if v.Duration != "" {
			b.WriteString(" · " + v.Duration)
		}
		if v.Meta != "" {
			b.WriteString(" · " + v.Meta)
		}
		b.WriteString("\n   " + v.URL + "\n")
	}
	return b.String()
}

// Transcript is what a video says (its subtitles) plus the basic facts about it.
type Transcript struct {
	Title   string `json:"title"`
	Channel string `json:"channel"`
	Seconds string `json:"len"`
	Views   string `json:"views"`
	Desc    string `json:"desc"`
	Lang    string `json:"lang"`
	Auto    bool   `json:"auto"`
	Err     string `json:"err"`
	Lines   []struct {
		T int    `json:"t"`
		S string `json:"s"`
	} `json:"lines"`
}

const transcriptJS = `(async()=>{
 const want=%s;
 const q=new URLSearchParams(location.search).get('v');
 let pr=window.ytInitialPlayerResponse;
 if(!pr||!pr.videoDetails||(q&&pr.videoDetails.videoId!==q)){
  const html=await (await fetch(location.href,{credentials:'include'})).text();
  const m=html.match(/ytInitialPlayerResponse\s*=\s*(\{.+?\});\s*(?:var |<\/script>)/s);
  if(!m)return JSON.stringify({err:'это не страница видео (или YouTube изменил разметку)'});
  pr=JSON.parse(m[1]);
 }
 const vd=pr.videoDetails||{};
 const res={title:vd.title||'',channel:vd.author||'',len:vd.lengthSeconds||'',views:vd.viewCount||'',desc:(vd.shortDescription||'').slice(0,700),lines:[]};
 const tr=(pr.captions&&pr.captions.playerCaptionsTracklistRenderer&&pr.captions.playerCaptionsTracklistRenderer.captionTracks)||[];
 if(!tr.length){res.err='у этого видео нет субтитров, по нему могу сказать только название, описание и комментарии';return JSON.stringify(res)}
 const pick=l=>tr.find(t=>t.languageCode===l&&t.kind!=='asr')||tr.find(t=>t.languageCode===l)||tr.find(t=>t.languageCode.startsWith(l));
 const t=(want&&pick(want))||pick('ru')||pick('en')||tr.find(t=>t.kind!=='asr')||tr[0];
 const u=new URL(t.baseUrl,location.href);u.searchParams.set('fmt','json3');
 const j=await (await fetch(u,{credentials:'include'})).json();
 res.lang=t.languageCode;res.auto=t.kind==='asr';
 for(const e of (j.events||[])){if(!e.segs)continue;const s=e.segs.map(x=>x.utf8).join('').replace(/\s+/g,' ').trim();if(s)res.lines.push({t:Math.floor((e.tStartMs||0)/1000),s:s})}
 return JSON.stringify(res)})()`

// Transcript reads the subtitles of the video on the current page (lang: preferred language code, may be empty).
func (s *Session) Transcript(ctx context.Context, lang string) (Transcript, error) {
	var raw string
	if err := s.eval(ctx, fmt.Sprintf(transcriptJS, jsStr(strings.ToLower(strings.TrimSpace(lang)))), &raw); err != nil {
		return Transcript{}, err
	}
	var t Transcript
	if err := json.Unmarshal([]byte(raw), &t); err != nil {
		return Transcript{}, err
	}
	if t.Err != "" && t.Title == "" {
		return t, errors.New(t.Err)
	}
	return t, nil
}

// String renders the transcript: facts first, then the speech in blocks of about 30 seconds with timestamps.
func (t Transcript) String() string {
	var b strings.Builder
	fmt.Fprintf(&b, "«%s» — %s", t.Title, t.Channel)
	if n, err := strconv.Atoi(t.Seconds); err == nil && n > 0 {
		fmt.Fprintf(&b, " · %d:%02d", n/60, n%60)
	}
	if t.Views != "" {
		b.WriteString(" · просмотров: " + t.Views)
	}
	b.WriteString("\n")
	if t.Desc != "" {
		b.WriteString("Описание: " + strings.ReplaceAll(t.Desc, "\n", " ") + "\n")
	}
	if len(t.Lines) == 0 {
		b.WriteString("! " + t.Err + "\n")
		return b.String()
	}
	kind := "субтитры"
	if t.Auto {
		kind = "автосубтитры (могут быть неточными)"
	}
	fmt.Fprintf(&b, "Речь из видео, %s [%s]:\n", kind, t.Lang)
	block, start := "", -100
	flush := func() {
		if block != "" {
			fmt.Fprintf(&b, "[%d:%02d] %s\n", start/60, start%60, strings.TrimSpace(block))
		}
	}
	for _, l := range t.Lines {
		if l.T-start >= 30 {
			flush()
			block, start = "", l.T
		}
		block += " " + l.S
	}
	flush()
	return b.String()
}
