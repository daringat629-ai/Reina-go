//go:build windows

package browser

import "errors"

// syscallProbe: Windows has no signal 0; the only test that needs it runs under Xvfb and is skipped here.
func syscallProbe(pid int) error { return errors.New("no process probe on windows") }
