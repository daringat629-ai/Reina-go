package browser

import (
	"context"
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"
)

// a page that imitates the parts of YouTube we read: video cards and the player response with subtitles
func youtubeLike() *httptest.Server {
	mux := http.NewServeMux()
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprint(w, `<title>Главная</title><body>
<ytd-rich-item-renderer><a id="video-title-link" title="Как работает мозг" href="/watch?v=abc123">Как работает мозг</a>
 <ytd-channel-name>Наука</ytd-channel-name><div id="metadata-line">1,2 млн просмотров · 3 дня назад</div><ytd-thumbnail-overlay-time-status-renderer>12:34</ytd-thumbnail-overlay-time-status-renderer></ytd-rich-item-renderer>
<ytd-rich-item-renderer><a id="video-title-link" title="Рецепт борща" href="/watch?v=def456&amp;t=5s">Рецепт борща</a><ytd-channel-name>Кухня</ytd-channel-name></ytd-rich-item-renderer>
<ytd-rich-item-renderer><a id="video-title-link" title="Рецепт борща" href="/watch?v=def456">Рецепт борща</a></ytd-rich-item-renderer>
<ytd-reel-item-renderer><a href="/shorts/sh0rt1" title="Смешной кот">Смешной кот</a></ytd-reel-item-renderer>
<a href="/watch?v=ghi789">Старая вёрстка без карточек</a></body>`)
	})
	mux.HandleFunc("/watch", func(w http.ResponseWriter, r *http.Request) {
		v := r.URL.Query().Get("v")
		fmt.Fprintf(w, `<title>Видео</title><script>window.ytInitialPlayerResponse={"videoDetails":{"videoId":%q,"title":"Как работает мозг","author":"Наука","lengthSeconds":"754","viewCount":"1200000","shortDescription":"Про нейроны и сон"},
"captions":{"playerCaptionsTracklistRenderer":{"captionTracks":[{"baseUrl":"/cap?v=%s&lang=en","languageCode":"en"},{"baseUrl":"/cap?v=%s&lang=ru","languageCode":"ru","kind":"asr"}]}}};</script><h1>Видео</h1>`, v, v, v)
	})
	mux.HandleFunc("/cap", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Query().Get("fmt") != "json3" {
			http.Error(w, "need json3", 400)
			return
		}
		if r.URL.Query().Get("lang") == "ru" {
			fmt.Fprint(w, `{"events":[{"tStartMs":0,"segs":[{"utf8":"Мозг состоит "},{"utf8":"из нейронов"}]},{"tStartMs":12000,"segs":[{"utf8":"они общаются\nимпульсами"}]},{"tStartMs":45000,"segs":[{"utf8":"во сне мозг убирает мусор"}]},{"tStartMs":50000}]}`)
			return
		}
		fmt.Fprint(w, `{"events":[{"tStartMs":0,"segs":[{"utf8":"The brain is made of neurons"}]}]}`)
	})
	return httptest.NewServer(mux)
}

func TestVideosListAndTranscript(t *testing.T) {
	if Find("") == "" {
		t.Skip("no chromium")
	}
	srv := youtubeLike()
	defer srv.Close()
	b := New()
	defer b.Close()
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()
	err := b.Do(ctx, Options{ProfileDir: t.TempDir(), NoSandbox: true}, func(s *Session) error {
		if err := s.Open(ctx, srv.URL); err != nil {
			return err
		}
		vs, err := s.Videos(ctx)
		if err != nil {
			return err
		}
		out := FormatVideos(vs)
		for _, want := range []string{"Как работает мозг — Наука · 12:34", "1,2 млн просмотров", "https://www.youtube.com/watch?v=abc123", "https://www.youtube.com/shorts/sh0rt1", "Старая вёрстка без карточек"} {
			if !strings.Contains(out, want) {
				t.Fatalf("missing %q in:\n%s", want, out)
			}
		}
		if strings.Count(out, "def456") != 1 {
			t.Fatalf("the same video must be listed once, with a clean link:\n%s", out)
		}
		if strings.Contains(out, "t=5s") {
			t.Fatal("links must be normalised")
		}
		// the video page: Russian asked, Russian (auto) served
		if err := s.Open(ctx, srv.URL+"/watch?v=abc123"); err != nil {
			return err
		}
		tr, err := s.Transcript(ctx, "ru")
		if err != nil {
			return err
		}
		txt := tr.String()
		for _, want := range []string{"«Как работает мозг» — Наука · 12:34", "просмотров: 1200000", "Про нейроны и сон", "автосубтитры", "[0:00] Мозг состоит из нейронов они общаются импульсами", "[0:45] во сне мозг убирает мусор"} {
			if !strings.Contains(txt, want) {
				t.Fatalf("missing %q in:\n%s", want, txt)
			}
		}
		tr, _ = s.Transcript(ctx, "en")
		if !strings.Contains(tr.String(), "The brain is made of neurons") || strings.Contains(tr.String(), "автосубтитры") {
			t.Fatalf("English track not chosen:\n%s", tr.String())
		}
		// not a video page
		if err := s.Open(ctx, srv.URL); err != nil {
			return err
		}
		if _, err := s.Transcript(ctx, ""); err == nil {
			t.Fatal("a list page has no transcript")
		}
		return nil
	})
	if err != nil {
		t.Fatal(err)
	}
}

func TestParseCookiesFormats(t *testing.T) {
	cookieEditor := `[{"domain":".youtube.com","expirationDate":4102444800,"hostOnly":false,"httpOnly":true,"name":"SID","path":"/","sameSite":"no_restriction","secure":true,"session":false,"value":"abc"},
 {"domain":"www.youtube.com","name":"__Host-3PLSID","path":"/","secure":true,"session":true,"value":"zzz","sameSite":"unspecified"},
 {"domain":".google.com","name":"__Secure-1PSID","value":"qqq","expirationDate":4102444800}]`
	cs, err := ParseCookies([]byte(cookieEditor))
	if err != nil || len(cs) != 3 {
		t.Fatalf("%v %+v", err, cs)
	}
	if cs[0].SameSite != "None" || !cs[0].HTTPOnly || cs[0].Expires != 4102444800 {
		t.Fatalf("%+v", cs[0])
	}
	if cs[1].Domain != "" || cs[1].URL != "https://www.youtube.com/" || cs[1].Expires != 0 {
		t.Fatalf("__Host- cookie must be set for the host without a Domain: %+v", cs[1])
	}
	if !cs[2].Secure {
		t.Fatal("__Secure- cookies are secure")
	}
	netscape := "# Netscape HTTP Cookie File\n.youtube.com\tTRUE\t/\tTRUE\t4102444800\tSAPISID\tkkk\n#HttpOnly_.youtube.com\tTRUE\t/\tTRUE\t0\tHSID\thhh\n"
	cs, err = ParseCookies([]byte(netscape))
	if err != nil || len(cs) != 2 || !cs[1].HTTPOnly || cs[0].Value != "kkk" || cs[1].Expires != 0 {
		t.Fatalf("%v %+v", err, cs)
	}
	pw := `{"cookies":[{"name":"a","value":"b","domain":"x.com","path":"/","expires":4102444800}],"origins":[]}`
	if cs, err = ParseCookies([]byte(pw)); err != nil || len(cs) != 1 {
		t.Fatalf("playwright state: %v %+v", err, cs)
	}
	for _, bad := range []string{"", "hello", "[]", `{"x":1}`, "[1,2"} {
		if _, err := ParseCookies([]byte(bad)); err == nil {
			t.Errorf("%q must be rejected", bad)
		}
	}
}

func TestCookiesReachThePageAndSurviveARestart(t *testing.T) {
	if Find("") == "" {
		t.Skip("no chromium")
	}
	var seen []string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		c, err := r.Cookie("SID")
		if err == nil {
			seen = append(seen, c.Value)
		}
		fmt.Fprint(w, "<title>x</title>ok")
	}))
	defer srv.Close()
	b := New()
	defer b.Close()
	opt := Options{ProfileDir: t.TempDir(), NoSandbox: true}
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()
	exp := float64(time.Now().Add(24 * time.Hour).Unix())
	err := b.Do(ctx, opt, func(s *Session) error {
		per, err := s.SetCookies(ctx, []Cookie{
			{Name: "SID", Value: "secret1", Domain: "127.0.0.1", Path: "/", Expires: exp},
			{Name: "old", Value: "x", Domain: "127.0.0.1", Path: "/", Expires: 5}, // long expired
		})
		if err != nil || per["127.0.0.1"] != 1 {
			t.Fatalf("%v %v", per, err)
		}
		return s.Open(ctx, srv.URL)
	})
	if err != nil || len(seen) == 0 || seen[len(seen)-1] != "secret1" {
		t.Fatalf("the site did not get the cookie: %v %v", seen, err)
	}
}

func TestPasswordFieldsAreRefusedUnlessAllowed(t *testing.T) {
	if Find("") == "" {
		t.Skip("no chromium")
	}
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprint(w, `<title>Вход</title><input placeholder="Логин"><input type="password" placeholder="Пароль">`)
	}))
	defer srv.Close()
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()
	for _, allow := range []bool{false, true} {
		b := New()
		err := b.Do(ctx, Options{ProfileDir: t.TempDir(), NoSandbox: true, AllowPasswords: allow}, func(s *Session) error {
			if err := s.Open(ctx, srv.URL); err != nil {
				return err
			}
			sn, _ := s.Look(ctx, 100)
			if err := s.Type(ctx, find(sn, "Логин"), "user", true, false); err != nil {
				t.Fatalf("a normal field must work: %v", err)
			}
			err := s.Type(ctx, find(sn, "Пароль"), "hunter2", true, false)
			if allow == (err != nil) {
				t.Fatalf("allow=%v but err=%v", allow, err)
			}
			if err != nil && !strings.Contains(err.Error(), "cookies") {
				t.Fatalf("the refusal must point to cookies: %v", err)
			}
			return nil
		})
		b.Close()
		if err != nil {
			t.Fatal(err)
		}
	}
}
