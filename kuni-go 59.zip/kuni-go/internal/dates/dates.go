// Package dates keeps the days that come back every year (birthdays, anniversaries, holidays of the family) and says
// when to remind about them: some days before and on the day itself. Reminders one-off and recurring tasks exist
// elsewhere; a birthday is neither ("every 365 days" drifts with leap years, a reminder fires once).
package dates

import (
	"errors"
	"fmt"
	"sort"
	"strings"
	"sync"
	"time"

	"kuni/internal/store"
)

// Date is one yearly day.
type Date struct {
	ID         int       `json:"id"`
	Name       string    `json:"name"` // "ДР мамы", "годовщина свадьбы"
	Kind       string    `json:"kind"` // birthday, anniversary, other
	Month      int       `json:"month"`
	Day        int       `json:"day"`
	Year       int       `json:"year,omitempty"`        // when it began (birth year...), 0 = unknown
	RemindDays int       `json:"remind_days,omitempty"` // a reminder that many days before (0 = only on the day)
	Chat       int64     `json:"chat"`                  // where she is woken up for it
	Note       string    `json:"note,omitempty"`        // what to do ("поздравить сама", "купить цветы")
	Created    time.Time `json:"created"`
	Fired      []string  `json:"fired,omitempty"` // reminders already given: "2026:-3", "2026:0"
}

type file struct {
	Dates []Date `json:"dates"`
	Next  int    `json:"next"`
}

const MaxDates = 300

type Store struct {
	mu    sync.Mutex
	path  string
	f     file
	saver store.Saver
}

// New loads the dates (missing = empty; a broken file is moved aside and reported).
func New(path string) *Store {
	s := &Store{path: path, saver: store.Saver{What: "dates"}}
	store.Load("dates", path, &s.f)
	if s.f.Next <= 0 {
		s.f.Next = 1
		for _, d := range s.f.Dates {
			s.f.Next = max(s.f.Next, d.ID+1)
		}
	}
	return s
}

// Add keeps a new date.
func (s *Store) Add(d Date, now time.Time) (Date, error) {
	d.Name = strings.TrimSpace(d.Name)
	if d.Name == "" {
		return Date{}, errors.New("what is the date? (name)")
	}
	if d.Month < 1 || d.Month > 12 || d.Day < 1 || d.Day > 31 || time.Date(2024, time.Month(d.Month), d.Day, 0, 0, 0, 0, time.UTC).Day() != d.Day {
		return Date{}, fmt.Errorf("no such day %02d.%02d", d.Day, d.Month)
	}
	if d.Year != 0 && (d.Year < 1900 || d.Year > now.Year()+50) {
		return Date{}, fmt.Errorf("odd year %d", d.Year)
	}
	k, name := strings.ToLower(strings.TrimSpace(d.Kind)), strings.ToLower(d.Name)
	switch {
	case k == "birthday" || k == "др" || k == "день рождения" || k == "" && (strings.Contains(name, "др") || strings.Contains(name, "рожд") || strings.Contains(name, "birthday")):
		d.Kind = "birthday"
	case k == "anniversary" || k == "годовщина" || k == "" && (strings.Contains(name, "годовщин") || strings.Contains(name, "anniversary")):
		d.Kind = "anniversary"
	default:
		d.Kind = "other"
	}
	d.RemindDays = min(max(d.RemindDays, 0), 60)
	s.mu.Lock()
	defer s.mu.Unlock()
	if len(s.f.Dates) >= MaxDates {
		return Date{}, fmt.Errorf("too many dates (%d)", MaxDates)
	}
	d.ID, d.Created, d.Fired = s.f.Next, now, nil
	s.f.Next++
	s.f.Dates = append(s.f.Dates, d)
	return d, s.saver.Save(s.path, s.f)
}

// Delete removes a date.
func (s *Store) Delete(id int) (Date, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	for i, d := range s.f.Dates {
		if d.ID == id {
			s.f.Dates = append(s.f.Dates[:i], s.f.Dates[i+1:]...)
			return d, s.saver.Save(s.path, s.f)
		}
	}
	return Date{}, fmt.Errorf("no date #%d", id)
}

func day(t time.Time) time.Time {
	return time.Date(t.Year(), t.Month(), t.Day(), 0, 0, 0, 0, t.Location())
}

// on is the day of the date in a year (29 February falls on the 28th in other years).
func on(d Date, year int, loc *time.Location) time.Time {
	t := time.Date(year, time.Month(d.Month), d.Day, 0, 0, 0, 0, loc)
	if t.Month() != time.Month(d.Month) {
		t = time.Date(year, time.Month(d.Month), 28, 0, 0, 0, 0, loc)
	}
	return t
}

// Next is the nearest day of the date from today on (today included).
func Next(d Date, now time.Time) time.Time {
	today := day(now)
	t := on(d, today.Year(), now.Location())
	if t.Before(today) {
		t = on(d, today.Year()+1, now.Location())
	}
	return t
}

// Upcoming is a date with its next day.
type Upcoming struct {
	Date
	On       time.Time
	DaysLeft int
	Turns    int // years it will be (0 = unknown)
}

// List returns the dates by how soon they come (only those within days, when days > 0).
func (s *Store) List(now time.Time, days int) []Upcoming {
	s.mu.Lock()
	defer s.mu.Unlock()
	var out []Upcoming
	for _, d := range s.f.Dates {
		u := upcoming(d, now)
		if days > 0 && u.DaysLeft > days {
			continue
		}
		out = append(out, u)
	}
	sort.Slice(out, func(i, j int) bool {
		if out[i].DaysLeft != out[j].DaysLeft {
			return out[i].DaysLeft < out[j].DaysLeft
		}
		return out[i].ID < out[j].ID
	})
	return out
}

func upcoming(d Date, now time.Time) Upcoming {
	n := Next(d, now)
	u := Upcoming{Date: d, On: n, DaysLeft: int(n.Sub(day(now)).Hours()/24 + 0.5)}
	if d.Year > 0 {
		u.Turns = n.Year() - d.Year
	}
	return u
}

// Due is a reminder whose time has come.
type Due struct {
	Upcoming
	Before bool // the reminder days before (false = the day itself)
}

// Due returns the reminders to give now and marks them given: on the day itself and RemindDays before, each from
// hour o'clock (local) on. A day the program was off is not caught up later: a birthday reminder a week late helps
// nobody.
func (s *Store) Due(now time.Time, hour int) []Due {
	if now.Hour() < hour {
		return nil
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	today := day(now)
	var out []Due
	changed := false
	for i := range s.f.Dates {
		d := &s.f.Dates[i]
		u := upcoming(*d, now)
		check := func(daysBefore int, before bool) {
			if u.On.AddDate(0, 0, -daysBefore) != today {
				return
			}
			k := fmt.Sprintf("%d:%d", u.On.Year(), daysBefore)
			for _, f := range d.Fired {
				if f == k {
					return
				}
			}
			d.Fired = append(d.Fired, k)
			if len(d.Fired) > 8 {
				d.Fired = d.Fired[len(d.Fired)-8:]
			}
			changed = true
			out = append(out, Due{Upcoming: upcoming(*d, now), Before: before})
		}
		if d.RemindDays > 0 {
			check(d.RemindDays, true)
		}
		check(0, false)
	}
	if changed {
		_ = s.saver.Save(s.path, s.f)
	}
	return out
}
