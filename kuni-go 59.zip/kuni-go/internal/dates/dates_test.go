package dates

import (
	"path/filepath"
	"testing"
	"time"
)

func TestDatesAndReminders(t *testing.T) {
	loc, _ := time.LoadLocation("Asia/Bishkek")
	s := New(filepath.Join(t.TempDir(), "d.json"))
	now := time.Date(2026, 3, 9, 8, 0, 0, 0, loc)
	mom, err := s.Add(Date{Name: "ДР мамы", Month: 3, Day: 12, Year: 1965, RemindDays: 3, Chat: 100}, now)
	if err != nil || mom.Kind != "birthday" {
		t.Fatal(mom, err)
	}
	if _, err := s.Add(Date{Name: "x", Month: 2, Day: 30}, now); err == nil {
		t.Fatal("30 February")
	}
	leap, _ := s.Add(Date{Name: "годовщина", Month: 2, Day: 29, Year: 2020}, now)
	if leap.Kind != "anniversary" {
		t.Fatal(leap.Kind)
	}
	up := s.List(now, 0)
	if up[0].Name != "ДР мамы" || up[0].DaysLeft != 3 || up[0].Turns != 61 {
		t.Fatalf("%+v", up[0])
	}
	if up[1].On.Format("2006-01-02") != "2027-02-28" || up[1].Turns != 7 {
		t.Fatalf("29 February in a common year: %+v", up[1])
	}
	if d := s.Due(now, 10); len(d) != 0 {
		t.Fatal("before ten nothing fires")
	}
	at10 := now.Add(2 * time.Hour)
	d := s.Due(at10, 10)
	if len(d) != 1 || !d[0].Before || d[0].DaysLeft != 3 {
		t.Fatalf("three days before: %+v", d)
	}
	if len(s.Due(at10.Add(time.Hour), 10)) != 0 {
		t.Fatal("given once")
	}
	if len(s.Due(at10.AddDate(0, 0, 1), 10)) != 0 {
		t.Fatal("nothing the day after")
	}
	d = s.Due(at10.AddDate(0, 0, 3), 10)
	if len(d) != 1 || d[0].Before || d[0].DaysLeft != 0 || d[0].Turns != 61 {
		t.Fatalf("on the day: %+v", d)
	}
	// next year it fires again; the marks survive a reload
	s2 := New(s.path)
	if len(s2.Due(at10.AddDate(0, 0, 3), 10)) != 0 {
		t.Fatal("given marks lost on reload")
	}
	if d := s2.Due(time.Date(2027, 3, 12, 11, 0, 0, 0, loc), 10); len(d) != 1 || d[0].Turns != 62 {
		t.Fatalf("next year: %+v", d)
	}
}
