// Command world runs the block world on its own, without Reina's Telegram brain: an endless sandbox in the browser.
// She is in it as a builder that raises houses, towers and pyramids by herself (no model, no cost).
package main

import (
	"context"
	"flag"
	"fmt"
	"log"
	"net"
	"net/http"
	"os"
	"os/signal"
	"path/filepath"
	"syscall"

	"kuni/internal/mir"
)

func main() {
	port := flag.Int("port", 8080, "port to listen on")
	key := flag.String("key", "", "password to enter (empty = no password, for your own network only)")
	dir := flag.String("data", "world-data", "folder where the world is saved")
	name := flag.String("name", "Рейна", "name of the builder")
	build := flag.Bool("autobuild", true, "the builder raises houses and towers by herself while someone is in the world")
	flag.Parse()

	s, err := mir.Open(*dir, *name, func() string { return *key })
	if err != nil {
		log.Fatalf("world: %v", err)
	}
	s.NoPassword = *key == ""
	s.BotAutobuild(*build)
	mux := http.NewServeMux()
	s.Mount(mux)
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	go s.Run(ctx)
	abs, _ := filepath.Abs(*dir)
	fmt.Printf("Мир запущен. Данные: %s\n", abs)
	for _, ip := range localIPs() {
		fmt.Printf("  открой в браузере: http://%s:%d/world\n", ip, *port)
	}
	if *key == "" {
		fmt.Println("  пароль не задан: любой в этой сети может зайти (задай -key пароль)")
	} else {
		fmt.Println("  пароль мира:", *key)
	}
	fmt.Println("Остановить: Ctrl+C")
	hs := &http.Server{Addr: fmt.Sprintf(":%d", *port), Handler: mux}
	go func() { <-ctx.Done(); _ = hs.Close() }()
	if err := hs.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		log.Fatal(err)
	}
}

func localIPs() []string {
	out := []string{"localhost"}
	addrs, _ := net.InterfaceAddrs()
	for _, a := range addrs {
		if n, ok := a.(*net.IPNet); ok && !n.IP.IsLoopback() && n.IP.To4() != nil {
			out = append(out, n.IP.String())
		}
	}
	return out
}
