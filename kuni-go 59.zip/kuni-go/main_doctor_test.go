package main

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"testing"

	"kuni/internal/config"
)

func TestDoctor(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Authorization") != "Bearer good" {
			w.WriteHeader(http.StatusUnauthorized)
			w.Write([]byte(`{"error":{"message":"invalid key"}}`))
			return
		}
		if strings.HasSuffix(r.URL.Path, "/embeddings") {
			json.NewEncoder(w).Encode(map[string]any{"data": []any{map[string]any{"embedding": []float64{0.1, 0.2, 0.3}}}})
			return
		}
		w.Write([]byte(`{"choices":[{"message":{"role":"assistant","content":"pong"}}]}`))
	}))
	defer srv.Close()
	path := filepath.Join(t.TempDir(), "config.toml")
	var out strings.Builder
	if err := runDoctor(path, &out); err == nil || !strings.Contains(out.String(), "создан") {
		t.Fatalf("a missing config must be reported: %v\n%s", err, out.String())
	}
	set := func(sec, key, val string) {
		if err := config.SetKey(path, sec, key, val); err != nil {
			t.Fatal(err)
		}
	}
	set("llm", "base_url", srv.URL+"/v1/")
	set("llm", "model", "m")
	set("llm", "api_key", "good")
	set("llm", "embedding_model", "e")
	set("misc", "data_dir", filepath.Join(t.TempDir(), "data"))
	out.Reset()
	if err := runDoctor(path, &out); err != nil {
		t.Fatalf("a working setup failed: %v\n%s", err, out.String())
	}
	for _, want := range []string{"✔ LLM m — отвечает", "✔ эмбеддинги e — вектор из 3 чисел", "Telegram — выключен"} {
		if !strings.Contains(out.String(), want) {
			t.Errorf("missing %q in:\n%s", want, out.String())
		}
	}
	set("llm", "api_key", "bad")
	out.Reset()
	if err := runDoctor(path, &out); err == nil || !strings.Contains(out.String(), "ключ не подходит") {
		t.Fatalf("a bad key must fail with a clear reason:\n%s", out.String())
	}
}
