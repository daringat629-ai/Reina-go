package main

import (
	"strings"
	"testing"
)

func TestInitScriptIsEmbeddedAndPointsAtTheRealDirectory(t *testing.T) {
	s := renderInit("/srv/reina")
	if !strings.Contains(s, ": ${REINA_DIR:=/srv/reina}") || strings.Contains(s, ":=/opt/reina}") {
		t.Fatalf("the directory must be filled in:\n%s", s)
	}
	for _, want := range []string{"#!/sbin/openrc-run", "supervise-daemon", "reina-tdlib", "LD_LIBRARY_PATH", "respawn_max=0"} {
		if !strings.Contains(s, want) {
			t.Errorf("init script lacks %q", want)
		}
	}
}
