package main

import (
	_ "embed"
	"fmt"
	"os"
	"os/exec"
	"strings"
)

//go:embed deploy/reina.initd
var initScript string

// renderInit is the OpenRC script with the program directory filled in.
func renderInit(dir string) string {
	return strings.Replace(initScript, ": ${REINA_DIR:=/opt/reina}", ": ${REINA_DIR:="+dir+"}", 1)
}

// installService: `reina-tdlib install-service` writes /etc/init.d/reina and enables it at boot (Alpine/OpenRC).
// It does not stop the running copy: the owner switches over with one command, printed at the end.
func installService(dir string) error {
	if _, err := exec.LookPath("rc-update"); err != nil {
		return fmt.Errorf("это не Alpine/OpenRC (нет rc-update), запускай вручную")
	}
	if err := os.WriteFile("/etc/init.d/reina", []byte(renderInit(dir)), 0o755); err != nil {
		return fmt.Errorf("не смог записать /etc/init.d/reina (нужен root): %v", err)
	}
	if out, err := exec.Command("rc-update", "add", "reina", "default").CombinedOutput(); err != nil {
		return fmt.Errorf("rc-update: %v: %s", err, strings.TrimSpace(string(out)))
	}
	fmt.Println("Служба установлена и включена в автозапуск.")
	fmt.Println("Переключись на неё одной командой:")
	fmt.Println("  kill $(pgrep -x reina-tdlib); sleep 3; rc-service reina start; sleep 3; rc-service reina status")
	fmt.Println("Дальше: rc-service reina restart | stop | status. Лог: " + dir + "/reina.log")
	return nil
}
