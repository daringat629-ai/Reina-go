package telegram

import (
	"context"
	"errors"
	"sync"
	"time"
)

// Fake is an in-memory Client for tests and for running the agent without Telegram.
type Fake struct {
	Core
	Me       int64
	mu       sync.Mutex
	updates  chan Message
	Sent     []Message
	Reacted  map[int64]string
	Banned   []int64
	Files    map[string][]byte
	Left     []int64
	Typings  int
	Forwards [][3]int64
}

func NewFake() *Fake {
	return &Fake{Core: Core{S: NewStore()}, Me: 1, updates: make(chan Message, 64), Reacted: map[int64]string{}, Files: map[string][]byte{}}
}

func (f *Fake) Run(ctx context.Context) error { <-ctx.Done(); return nil }
func (f *Fake) Updates() <-chan Message       { return f.updates }
func (f *Fake) MyID() int64                   { return f.Me }

// Incoming simulates a user message arriving in a chat.
func (f *Fake) Incoming(chat Chat, senderID int64, sender, text string) Message {
	m := Message{ID: f.S.NextID(chat.ID), ChatID: chat.ID, SenderID: senderID, SenderName: sender, Date: time.Now(), Text: text}
	f.S.Put(m, &chat)
	f.updates <- m
	return m
}

func (f *Fake) send(chatID int64, m Message) Message {
	m.ID, m.ChatID, m.SenderID, m.SenderName, m.Date, m.Outgoing, m.Read = f.S.NextID(chatID), chatID, f.Me, "me", time.Now(), true, true
	f.S.Put(m, nil)
	f.mu.Lock()
	f.Sent = append(f.Sent, m)
	f.mu.Unlock()
	return m
}

func (f *Fake) SendText(_ context.Context, chatID int64, text string, replyTo int64) (Message, error) {
	return f.send(chatID, Message{Text: text, ReplyTo: replyTo}), nil
}
func (f *Fake) SendPhoto(_ context.Context, chatID int64, data []byte, caption string, replyTo int64) (Message, error) {
	return f.send(chatID, Message{Text: caption, ReplyTo: replyTo, Media: MediaPhoto}), nil
}
func (f *Fake) SendDocument(_ context.Context, chatID int64, name string, data []byte, caption string, replyTo int64) (Message, error) {
	return f.send(chatID, Message{Text: caption + "[file:" + name + "]", ReplyTo: replyTo}), nil
}
func (f *Fake) SendVoice(_ context.Context, chatID int64, data []byte, replyTo int64) (Message, error) {
	return f.send(chatID, Message{ReplyTo: replyTo, Media: MediaVoice}), nil
}
func (f *Fake) SendSticker(_ context.Context, chatID int64, fileID string, replyTo int64) (Message, error) {
	return f.send(chatID, Message{ReplyTo: replyTo, Media: MediaSticker, FileID: fileID}), nil
}
func (f *Fake) Edit(_ context.Context, chatID, msgID int64, text string) error {
	if !f.S.Update(chatID, msgID, func(m *Message) { m.Text, m.Edited = text, true }) {
		return ErrNotFound
	}
	return nil
}
func (f *Fake) Delete(_ context.Context, chatID, msgID int64) error {
	f.S.Remove(chatID, msgID)
	return nil
}
func (f *Fake) Forward(_ context.Context, from, msgID, to int64) error {
	f.mu.Lock()
	f.Forwards = append(f.Forwards, [3]int64{from, msgID, to})
	f.mu.Unlock()
	return nil
}
func (f *Fake) React(_ context.Context, chatID, msgID int64, emoji string) error {
	f.mu.Lock()
	f.Reacted[msgID] = emoji
	f.mu.Unlock()
	return nil
}
func (f *Fake) Typing(context.Context, int64) error {
	f.mu.Lock()
	f.Typings++
	f.mu.Unlock()
	return nil
}
func (f *Fake) Join(context.Context, string) error { return nil }
func (f *Fake) Leave(_ context.Context, chatID int64) error {
	f.mu.Lock()
	f.Left = append(f.Left, chatID)
	f.mu.Unlock()
	return nil
}
func (f *Fake) Ban(_ context.Context, chatID, userID int64, removeAll bool) error {
	f.mu.Lock()
	f.Banned = append(f.Banned, userID)
	f.mu.Unlock()
	return nil
}
func (f *Fake) SetMemberTag(context.Context, int64, int64, string) error { return nil }
func (f *Fake) Download(_ context.Context, fileID string) ([]byte, error) {
	if b, ok := f.Files[fileID]; ok {
		return b, nil
	}
	return nil, errors.New("no such file")
}
func (f *Fake) ChatPhoto(context.Context, int64) ([]byte, error) { return nil, ErrNotFound }

// SentTexts returns the text of all messages sent so far.
func (f *Fake) SentTexts() []string {
	f.mu.Lock()
	defer f.mu.Unlock()
	var out []string
	for _, m := range f.Sent {
		out = append(out, m.Text)
	}
	return out
}

var _ Client = (*Fake)(nil)
