package telegram

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"mime/multipart"
	"net/http"
	"net/url"
	"path/filepath"
	"strconv"
	"strings"
	"time"
)

// BotClient implements Client over the Telegram Bot API (long polling).
// Limitations vs. the tdlib user-account client in the C++ project:
//   - a bot only sees messages sent to it (history is whatever it has seen; kept in Store);
//   - bots cannot join chats by link nor search public chats;
//   - read marks and "online" status are not controllable.
type BotClient struct {
	Core
	Token   string
	APIBase string // e.g. https://api.telegram.org
	HTTP    *http.Client
	// StatePath, if set, is where the message store is persisted.
	StatePath string

	updates chan Message
	meID    int64
}

func NewBot(token, apiBase string) *BotClient {
	if apiBase == "" {
		apiBase = "https://api.telegram.org"
	}
	return &BotClient{
		Core: Core{S: NewStore()}, Token: token, APIBase: strings.TrimRight(apiBase, "/"),
		HTTP: &http.Client{Timeout: 75 * time.Second}, updates: make(chan Message, 256),
	}
}

func (b *BotClient) Updates() <-chan Message { return b.updates }
func (b *BotClient) MyID() int64             { return b.meID }

type apiResp struct {
	OK          bool            `json:"ok"`
	Result      json.RawMessage `json:"result"`
	Description string          `json:"description"`
}

func (b *BotClient) call(ctx context.Context, method string, params any, out any) error {
	var body io.Reader
	ctype := "application/json"
	switch p := params.(type) {
	case nil:
	case *multipartBody:
		body, ctype = p.buf, p.ctype
	default:
		raw, err := json.Marshal(p)
		if err != nil {
			return err
		}
		body = bytes.NewReader(raw)
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, fmt.Sprintf("%s/bot%s/%s", b.APIBase, b.Token, method), body)
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", ctype)
	resp, err := b.HTTP.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	raw, err := io.ReadAll(resp.Body)
	if err != nil {
		return err
	}
	var r apiResp
	if err := json.Unmarshal(raw, &r); err != nil {
		return fmt.Errorf("telegram %s: HTTP %d: %.200s", method, resp.StatusCode, raw)
	}
	if !r.OK {
		return fmt.Errorf("telegram %s: %s", method, r.Description)
	}
	if out != nil {
		return json.Unmarshal(r.Result, out)
	}
	return nil
}

type multipartBody struct {
	buf   *bytes.Buffer
	ctype string
}

func multipartFile(fields map[string]string, fileField, filename string, data []byte) (*multipartBody, error) {
	buf := &bytes.Buffer{}
	w := multipart.NewWriter(buf)
	for k, v := range fields {
		if v != "" {
			if err := w.WriteField(k, v); err != nil {
				return nil, err
			}
		}
	}
	fw, err := w.CreateFormFile(fileField, filename)
	if err != nil {
		return nil, err
	}
	if _, err := fw.Write(data); err != nil {
		return nil, err
	}
	if err := w.Close(); err != nil {
		return nil, err
	}
	return &multipartBody{buf, w.FormDataContentType()}, nil
}

// --- Bot API wire types ---

type apiUser struct {
	ID        int64  `json:"id"`
	FirstName string `json:"first_name"`
	LastName  string `json:"last_name"`
	Username  string `json:"username"`
}

type apiChat struct {
	ID        int64  `json:"id"`
	Type      string `json:"type"`
	Title     string `json:"title"`
	FirstName string `json:"first_name"`
	Username  string `json:"username"`
}

type apiMessage struct {
	MessageID int64    `json:"message_id"`
	Date      int64    `json:"date"`
	Chat      apiChat  `json:"chat"`
	From      *apiUser `json:"from"`
	Text      string   `json:"text"`
	Caption   string   `json:"caption"`
	ReplyTo   *struct {
		MessageID int64 `json:"message_id"`
	} `json:"reply_to_message"`
	ForwardOrigin *struct {
		SenderUserName string   `json:"sender_user_name"`
		Chat           *apiChat `json:"chat"`
		SenderUser     *apiUser `json:"sender_user"`
	} `json:"forward_origin"`
	Photo []struct {
		FileID string `json:"file_id"`
	} `json:"photo"`
	Voice *struct {
		FileID string `json:"file_id"`
	} `json:"voice"`
	Video *struct {
		FileID string `json:"file_id"`
	} `json:"video"`
	VideoNote *struct {
		FileID string `json:"file_id"`
	} `json:"video_note"`
	Sticker *struct {
		FileID string `json:"file_id"`
		Emoji  string `json:"emoji"`
	} `json:"sticker"`
}

type apiUpdate struct {
	UpdateID      int64       `json:"update_id"`
	Message       *apiMessage `json:"message"`
	EditedMessage *apiMessage `json:"edited_message"`
	ChannelPost   *apiMessage `json:"channel_post"`
}

func (c apiChat) toChat() Chat {
	ch := Chat{ID: c.ID, Title: c.Title, IsMember: true}
	switch c.Type {
	case "private":
		ch.Kind = ChatPrivate
		ch.Title = c.FirstName
		if ch.Title == "" {
			ch.Title = c.Username
		}
	case "channel":
		ch.Kind = ChatChannel
	default:
		ch.Kind = ChatGroup
	}
	return ch
}

func (m apiMessage) toMessage(myID int64) Message {
	out := Message{ID: m.MessageID, ChatID: m.Chat.ID, Date: time.Unix(m.Date, 0), Text: m.Text}
	if out.Text == "" {
		out.Text = m.Caption
	}
	if m.From != nil {
		out.SenderID = m.From.ID
		out.SenderName = strings.TrimSpace(m.From.FirstName + " " + m.From.LastName)
		if out.SenderName == "" {
			out.SenderName = m.From.Username
		}
		out.Outgoing = myID != 0 && m.From.ID == myID
	} else {
		out.SenderName = m.Chat.Title // channel post
	}
	if m.ReplyTo != nil {
		out.ReplyTo = m.ReplyTo.MessageID
	}
	if f := m.ForwardOrigin; f != nil {
		switch {
		case f.SenderUser != nil:
			out.ForwardFrom = f.SenderUser.FirstName
		case f.Chat != nil:
			out.ForwardFrom = f.Chat.Title
		default:
			out.ForwardFrom = f.SenderUserName
		}
	}
	switch {
	case len(m.Photo) > 0:
		out.Media, out.FileID = MediaPhoto, m.Photo[len(m.Photo)-1].FileID
	case m.Voice != nil:
		out.Media, out.FileID = MediaVoice, m.Voice.FileID
	case m.Video != nil:
		out.Media, out.FileID = MediaVideo, m.Video.FileID
	case m.VideoNote != nil:
		out.Media, out.FileID = MediaVideo, m.VideoNote.FileID
	case m.Sticker != nil:
		out.Media, out.FileID = MediaSticker, m.Sticker.FileID
		if out.Text == "" {
			out.Text = m.Sticker.Emoji
		}
	}
	return out
}

// Run long-polls getUpdates until ctx is done and periodically persists the store.
func (b *BotClient) Run(ctx context.Context) error {
	var me apiUser
	if err := b.call(ctx, "getMe", nil, &me); err != nil {
		return fmt.Errorf("getMe: %w", err)
	}
	b.meID = me.ID
	log.Printf("telegram: logged in as @%s (%d)", me.Username, me.ID)
	if b.StatePath != "" {
		if err := b.S.Load(b.StatePath); err != nil {
			log.Printf("telegram: can't load state: %v", err)
		}
		go b.persistLoop(ctx)
		defer b.S.Save(b.StatePath)
	}

	offset := int64(0)
	for ctx.Err() == nil {
		var ups []apiUpdate
		err := b.call(ctx, "getUpdates", map[string]any{"offset": offset, "timeout": 30,
			"allowed_updates": []string{"message", "edited_message", "channel_post"}}, &ups)
		if err != nil {
			if ctx.Err() != nil {
				return nil
			}
			log.Printf("telegram: getUpdates: %v", err)
			select {
			case <-ctx.Done():
				return nil
			case <-time.After(3 * time.Second):
			}
			continue
		}
		for _, u := range ups {
			offset = u.UpdateID + 1
			am := u.Message
			if am == nil {
				am = u.ChannelPost
			}
			if am == nil {
				if u.EditedMessage != nil {
					m := u.EditedMessage.toMessage(b.meID)
					m.Edited = true
					chat := u.EditedMessage.Chat.toChat()
					b.S.Put(m, &chat)
				}
				continue
			}
			chat := am.Chat.toChat()
			m := am.toMessage(b.meID)
			b.S.Put(m, &chat)
			if !m.Outgoing {
				select {
				case b.updates <- m:
				default:
					log.Printf("telegram: update queue full, dropping message %d", m.ID)
				}
			}
		}
	}
	return nil
}

func (b *BotClient) persistLoop(ctx context.Context) {
	t := time.NewTicker(time.Minute)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
			if err := b.S.Save(b.StatePath); err != nil {
				log.Printf("telegram: save state: %v", err)
			}
		}
	}
}

// Chat refreshes membership/admin flags from the server.
func (b *BotClient) Chat(ctx context.Context, id int64) (Chat, error) {
	ch, err := b.Core.Chat(ctx, id)
	if err != nil {
		return ch, err
	}
	if ch.Kind != ChatPrivate && b.meID != 0 {
		var cm struct {
			Status string `json:"status"`
		}
		if err := b.call(ctx, "getChatMember", map[string]any{"chat_id": id, "user_id": b.meID}, &cm); err == nil {
			member := cm.Status != "left" && cm.Status != "kicked"
			admin := cm.Status == "administrator" || cm.Status == "creator"
			b.S.SetChatFlags(id, member, admin)
			ch.IsMember, ch.IsAdmin = member, admin
		}
	}
	return ch, nil
}

func (b *BotClient) record(m apiMessage) Message {
	msg := m.toMessage(b.meID)
	msg.Outgoing, msg.Read = true, true
	chat := m.Chat.toChat()
	b.S.Put(msg, &chat)
	return msg
}

func replyParams(replyTo int64) map[string]any {
	if replyTo == 0 {
		return nil
	}
	return map[string]any{"message_id": replyTo, "allow_sending_without_reply": true}
}

func (b *BotClient) SendText(ctx context.Context, chatID int64, text string, replyTo int64) (Message, error) {
	var m apiMessage
	p := map[string]any{"chat_id": chatID, "text": text}
	if rp := replyParams(replyTo); rp != nil {
		p["reply_parameters"] = rp
	}
	if err := b.call(ctx, "sendMessage", p, &m); err != nil {
		return Message{}, err
	}
	return b.record(m), nil
}

func (b *BotClient) sendFile(ctx context.Context, method, field, name string, chatID int64, data []byte, caption string, replyTo int64) (Message, error) {
	fields := map[string]string{"chat_id": strconv.FormatInt(chatID, 10), "caption": caption}
	if replyTo != 0 {
		fields["reply_parameters"] = fmt.Sprintf(`{"message_id":%d,"allow_sending_without_reply":true}`, replyTo)
	}
	body, err := multipartFile(fields, field, name, data)
	if err != nil {
		return Message{}, err
	}
	var m apiMessage
	if err := b.call(ctx, method, body, &m); err != nil {
		return Message{}, err
	}
	return b.record(m), nil
}

func (b *BotClient) SendPhoto(ctx context.Context, chatID int64, data []byte, caption string, replyTo int64) (Message, error) {
	return b.sendFile(ctx, "sendPhoto", "photo", "photo.jpg", chatID, data, caption, replyTo)
}

func (b *BotClient) SendDocument(ctx context.Context, chatID int64, name string, data []byte, caption string, replyTo int64) (Message, error) {
	return b.sendFile(ctx, "sendDocument", "document", filepath.Base(name), chatID, data, caption, replyTo)
}

func (b *BotClient) SendVoice(ctx context.Context, chatID int64, data []byte, replyTo int64) (Message, error) {
	return b.sendFile(ctx, "sendVoice", "voice", "voice.ogg", chatID, data, "", replyTo)
}

func (b *BotClient) SendSticker(ctx context.Context, chatID int64, fileID string, replyTo int64) (Message, error) {
	var m apiMessage
	p := map[string]any{"chat_id": chatID, "sticker": fileID}
	if rp := replyParams(replyTo); rp != nil {
		p["reply_parameters"] = rp
	}
	if err := b.call(ctx, "sendSticker", p, &m); err != nil {
		return Message{}, err
	}
	return b.record(m), nil
}

func (b *BotClient) Edit(ctx context.Context, chatID, msgID int64, text string) error {
	// Media captions and plain text use different methods; try text first, then caption.
	err := b.call(ctx, "editMessageText", map[string]any{"chat_id": chatID, "message_id": msgID, "text": text}, nil)
	if err != nil && strings.Contains(err.Error(), "no text in the message") {
		err = b.call(ctx, "editMessageCaption", map[string]any{"chat_id": chatID, "message_id": msgID, "caption": text}, nil)
	}
	if err == nil {
		b.S.Update(chatID, msgID, func(m *Message) { m.Text, m.Edited = text, true })
	}
	return err
}

func (b *BotClient) Delete(ctx context.Context, chatID, msgID int64) error {
	err := b.call(ctx, "deleteMessage", map[string]any{"chat_id": chatID, "message_id": msgID}, nil)
	if err == nil {
		b.S.Remove(chatID, msgID)
	}
	return err
}

func (b *BotClient) Forward(ctx context.Context, from, msgID, to int64) error {
	var m apiMessage
	if err := b.call(ctx, "forwardMessage", map[string]any{"chat_id": to, "from_chat_id": from, "message_id": msgID}, &m); err != nil {
		return err
	}
	b.record(m)
	return nil
}

// React sets a reaction. The U+FE0F variation selector is stripped, otherwise
// Telegram rejects some emojis (see the C++ fix "emoji reactions rejected on U+FE0F").
func (b *BotClient) React(ctx context.Context, chatID, msgID int64, emoji string) error {
	emoji = strings.ReplaceAll(emoji, "️", "")
	err := b.call(ctx, "setMessageReaction", map[string]any{"chat_id": chatID, "message_id": msgID,
		"reaction": []map[string]string{{"type": "emoji", "emoji": emoji}}}, nil)
	if err == nil {
		b.S.Update(chatID, msgID, func(m *Message) { m.Reactions = append(m.Reactions, emoji) })
	}
	return err
}

func (b *BotClient) Typing(ctx context.Context, chatID int64) error {
	return b.call(ctx, "sendChatAction", map[string]any{"chat_id": chatID, "action": "typing"}, nil)
}

func (b *BotClient) Join(context.Context, string) error {
	return errors.New("bots can't join chats by link; ask a human to add the bot to the chat")
}

func (b *BotClient) Leave(ctx context.Context, chatID int64) error {
	return b.call(ctx, "leaveChat", map[string]any{"chat_id": chatID}, nil)
}

func (b *BotClient) Ban(ctx context.Context, chatID, userID int64, removeAll bool) error {
	return b.call(ctx, "banChatMember", map[string]any{"chat_id": chatID, "user_id": userID, "revoke_messages": removeAll}, nil)
}

func (b *BotClient) SetMemberTag(ctx context.Context, chatID, userID int64, tag string) error {
	return b.call(ctx, "setChatMemberTag", map[string]any{"chat_id": chatID, "user_id": userID, "tag": tag}, nil)
}

func (b *BotClient) Download(ctx context.Context, fileID string) ([]byte, error) {
	var f struct {
		FilePath string `json:"file_path"`
	}
	if err := b.call(ctx, "getFile", map[string]any{"file_id": fileID}, &f); err != nil {
		return nil, err
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, fmt.Sprintf("%s/file/bot%s/%s", b.APIBase, b.Token, url.PathEscape(f.FilePath)), nil)
	if err != nil {
		return nil, err
	}
	// PathEscape would encode '/', restore it.
	req.URL.Path = fmt.Sprintf("/file/bot%s/%s", b.Token, f.FilePath)
	req.URL.RawPath = ""
	resp, err := b.HTTP.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode/100 != 2 {
		return nil, fmt.Errorf("telegram download: HTTP %d", resp.StatusCode)
	}
	return io.ReadAll(io.LimitReader(resp.Body, 50<<20))
}

func (b *BotClient) ChatPhoto(ctx context.Context, chatID int64) ([]byte, error) {
	var c struct {
		Photo *struct {
			BigFileID string `json:"big_file_id"`
		} `json:"photo"`
	}
	if err := b.call(ctx, "getChat", map[string]any{"chat_id": chatID}, &c); err != nil {
		return nil, err
	}
	if c.Photo == nil {
		return nil, errors.New("chat has no photo")
	}
	return b.Download(ctx, c.Photo.BigFileID)
}

var _ Client = (*BotClient)(nil)
