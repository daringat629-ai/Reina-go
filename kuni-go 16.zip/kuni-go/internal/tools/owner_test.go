package tools

import (
	"context"
	"strings"
	"testing"

	"kuni/internal/config"
	"kuni/internal/telegram"
)

func ownerDeps(t *testing.T, papik int64) Deps {
	c := &config.Config{DataDir: t.TempDir(), PapikChatID: papik, OwnerTools: true, ShellTimeout: 60}
	return Deps{TG: telegram.NewFake(), Cfg: func() *config.Config { return c }}
}

func TestOwnerToolsOnlyForOwner(t *testing.T) {
	d := ownerDeps(t, 5)
	if len(OwnerTools(d, telegram.Chat{ID: 6})) != 0 {
		t.Fatal("tools leaked to a stranger")
	}
	if len(OwnerTools(d, telegram.Chat{ID: 5})) != 5 {
		t.Fatal("owner should get 5 tools")
	}
}

func TestShell(t *testing.T) {
	d := ownerDeps(t, 5)
	out, _ := shellTool(d).Run(context.Background(), Args{"command": "echo hi; exit 3"})
	if !strings.Contains(out, "exit=3") || !strings.Contains(out, "hi") {
		t.Fatal(out)
	}
	out, _ = shellTool(d).Run(context.Background(), Args{"command": "sleep 5", "timeout_secs": float64(1)})
	if !strings.Contains(out, "timed out") {
		t.Fatal(out)
	}
	if got := Truncate(strings.Repeat("a", 20000), 6000); len(got) > 6100 {
		t.Fatal(len(got))
	}
}

func TestSendFile(t *testing.T) {
	d := ownerDeps(t, 5)
	_, _ = shellTool(d).Run(context.Background(), Args{"command": "echo x > a.txt"})
	if _, err := sendFileTool(d, telegram.Chat{ID: 5}).Run(context.Background(), Args{"path": "a.txt"}); err != nil {
		t.Fatal(err)
	}
}
