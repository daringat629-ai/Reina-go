package admin

import (
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"kuni/internal/config"
	"kuni/internal/diary"
	"kuni/internal/metrics"
	"kuni/internal/mood"
	"kuni/internal/prompts"
	"kuni/internal/util"
)

type ctl struct{ paused bool }

func (c *ctl) Paused() bool               { return c.paused }
func (c *ctl) SetPaused(p bool)           { c.paused = p }
func (c *ctl) SessionSummaries() []string { return []string{"Alex (id 1): 3 messages"} }

const tok = "correct-horse-battery"

func rig(t *testing.T) (*Panel, http.Handler, *ctl, string) {
	dir := t.TempDir()
	cp := filepath.Join(dir, "config.toml")
	if _, err := config.Load(cp); err != config.ErrNeedsSetup {
		t.Fatal(err)
	}
	if err := config.SetKey(cp, "misc", "admin_token", tok); err != nil {
		t.Fatal(err)
	}
	if err := config.SetKey(cp, "misc", "data_dir", filepath.Join(dir, "data")); err != nil {
		t.Fatal(err)
	}
	h, err := config.NewHolder(cp)
	if err != nil {
		t.Fatal(err)
	}
	ps, err := prompts.NewStore(filepath.Join(dir, "prompts"), prompts.Vars{CharacterName: "R", PapikName: "P"})
	if err != nil {
		t.Fatal(err)
	}
	d, _ := diary.New(filepath.Join(dir, "diary"), nil, 0.1, 4000)
	c := &ctl{}
	p := &Panel{Cfg: h.Get, ConfigPath: cp, Prompts: ps, Diary: d, Metrics: metrics.New(), Log: util.NewLogBuf(10), Ctl: c, Started: time.Now()}
	mux := http.NewServeMux()
	p.Mount(mux)
	return p, mux, c, cp
}

func do(h http.Handler, method, path, body string, hdr map[string]string) *httptest.ResponseRecorder {
	r := httptest.NewRequest(method, path, strings.NewReader(body))
	r.RemoteAddr = "10.0.0.5:1234"
	for k, v := range hdr {
		r.Header.Set(k, v)
	}
	w := httptest.NewRecorder()
	h.ServeHTTP(w, r)
	return w
}

var auth = map[string]string{"Authorization": "Bearer " + tok, "X-Admin": "1"}

func TestDisabledWithoutToken(t *testing.T) {
	p, mux, _, cp := rig(t)
	if err := config.SetKey(cp, "misc", "admin_token", "short"); err != nil {
		t.Fatal(err)
	}
	h, _ := config.NewHolder(cp)
	p.Cfg = h.Get
	if w := do(mux, "GET", "/admin", "", nil); w.Code != 404 {
		t.Fatalf("index %d", w.Code)
	}
	if w := do(mux, "GET", "/admin/api/status", "", auth); w.Code != 404 {
		t.Fatalf("api %d", w.Code)
	}
}

func TestAuthAndCookie(t *testing.T) {
	_, mux, _, _ := rig(t)
	if w := do(mux, "GET", "/admin/api/status", "", nil); w.Code != 401 {
		t.Fatalf("want 401 got %d", w.Code)
	}
	if w := do(mux, "GET", "/admin/api/status?token="+tok, "", nil); w.Code != 401 {
		t.Fatal("token in the query string must not authorise the API")
	}
	w := do(mux, "GET", "/admin?token="+tok, "", nil)
	if w.Code != 303 || !strings.Contains(w.Header().Get("Set-Cookie"), "HttpOnly") || !strings.Contains(w.Header().Get("Set-Cookie"), "SameSite=Strict") {
		t.Fatalf("%d %v", w.Code, w.Header())
	}
	cookie := strings.Split(w.Header().Get("Set-Cookie"), ";")[0]
	if w := do(mux, "GET", "/admin/api/status", "", map[string]string{"Cookie": cookie}); w.Code != 200 {
		t.Fatalf("cookie auth %d", w.Code)
	}
	if w := do(mux, "GET", "/admin", "", nil); w.Code != 200 || !strings.Contains(w.Body.String(), "Reina") {
		t.Fatal("page not served")
	}
}

func TestCSRFHeaderRequired(t *testing.T) {
	_, mux, c, _ := rig(t)
	w := do(mux, "POST", "/admin/api/pause", `{"paused":true}`, map[string]string{"Authorization": "Bearer " + tok})
	if w.Code != 403 || c.paused {
		t.Fatalf("POST without X-Admin passed: %d", w.Code)
	}
	if w := do(mux, "POST", "/admin/api/pause", `{"paused":true}`, auth); w.Code != 200 || !c.paused {
		t.Fatalf("pause %d", w.Code)
	}
}

func TestBruteForceLockout(t *testing.T) {
	_, mux, _, _ := rig(t)
	if testing.Short() {
		t.Skip()
	}
	for i := 0; i < 8; i++ {
		do(mux, "GET", "/admin/api/status", "", map[string]string{"Authorization": "Bearer nope"})
	}
	if w := do(mux, "GET", "/admin/api/status", "", auth); w.Code != 429 {
		t.Fatalf("want 429 after 8 failures, got %d", w.Code)
	}
}

func TestConfigSecretsAreWriteOnly(t *testing.T) {
	_, mux, _, cp := rig(t)
	w := do(mux, "GET", "/admin/api/config", "", auth)
	if w.Code != 200 || strings.Contains(w.Body.String(), tok) {
		t.Fatalf("secret leaked or error: %d", w.Code)
	}
	if w := do(mux, "POST", "/admin/api/config", `{"Section":"telegram","Key":"lockdown","Value":"contacts_only"}`, auth); w.Code != 200 {
		t.Fatalf("%d %s", w.Code, w.Body)
	}
	b, _ := os.ReadFile(cp)
	if !strings.Contains(string(b), `lockdown = "contacts_only"`) {
		t.Fatal("not written")
	}
	if w := do(mux, "POST", "/admin/api/config", `{"Section":"telegram","Key":"max_tool_rounds","Value":"many"}`, auth); w.Code != 400 {
		t.Fatalf("bad value accepted: %d", w.Code)
	}
}

func TestPromptSaveAndReset(t *testing.T) {
	_, mux, _, _ := rig(t)
	if w := do(mux, "POST", "/admin/api/prompts", `{"Name":"system","Content":"hello ${PAPIK_NAME}"}`, auth); w.Code != 200 {
		t.Fatalf("%d %s", w.Code, w.Body)
	}
	w := do(mux, "GET", "/admin/api/prompts?name=system", "", auth)
	if !strings.Contains(w.Body.String(), "hello") || !strings.Contains(w.Body.String(), `"is_default":false`) {
		t.Fatal(w.Body.String())
	}
	if w := do(mux, "POST", "/admin/api/prompts", `{"Name":"system","Reset":true}`, auth); w.Code != 200 {
		t.Fatal(w.Body.String())
	}
	if w := do(mux, "GET", "/admin/api/prompts?name=system", "", auth); !strings.Contains(w.Body.String(), `"is_default":true`) {
		t.Fatal(w.Body.String())
	}
	for _, bad := range []string{`{"Name":"../../etc/passwd","Content":"x"}`, `{"Name":"nope","Content":"x"}`, `{"Name":"system","Content":"  "}`} {
		if w := do(mux, "POST", "/admin/api/prompts", bad, auth); w.Code == 200 {
			t.Fatalf("accepted %s", bad)
		}
	}
	if w := do(mux, "GET", "/admin/api/prompts?name=../../etc/passwd", "", auth); w.Code != 404 {
		t.Fatalf("traversal %d", w.Code)
	}
}

func TestMemoryDiaryShellLog(t *testing.T) {
	p, mux, _, _ := rig(t)
	if w := do(mux, "POST", "/admin/api/memory", `{"Content":"remember milk"}`, auth); w.Code != 200 {
		t.Fatal(w.Body.String())
	}
	if w := do(mux, "GET", "/admin/api/memory", "", auth); !strings.Contains(w.Body.String(), "remember milk") {
		t.Fatal(w.Body.String())
	}
	if w := do(mux, "POST", "/admin/api/diary", `{"Delete":"../x"}`, auth); w.Code != 400 {
		t.Fatalf("bad id accepted %d", w.Code)
	}
	if w := do(mux, "GET", "/admin/api/shell", "", auth); w.Code != 200 || !strings.Contains(w.Body.String(), `"lines":[]`) {
		t.Fatal(w.Body.String())
	}
	p.Log.Write([]byte("hello\nworld\n"))
	if w := do(mux, "GET", "/admin/api/log", "", auth); !strings.Contains(w.Body.String(), "world") {
		t.Fatal(w.Body.String())
	}
}

func TestStatus(t *testing.T) {
	p, mux, _, _ := rig(t)
	p.Metrics.Inc("kuni_llm_tokens_total", 120, map[string]string{"model": p.Cfg().LLMModel, "purpose": "reply", "direction": "input"})
	w := do(mux, "GET", "/admin/api/status", "", auth)
	if !strings.Contains(w.Body.String(), `"reply":{"in":120`) || !strings.Contains(w.Body.String(), "Alex (id 1)") {
		t.Fatal(w.Body.String())
	}
}

func TestMoodEndpoint(t *testing.T) {
	p, mux, _, _ := rig(t)
	p.Mood = mood.New(filepath.Join(t.TempDir(), "m.json"))
	if w := do(mux, "POST", "/admin/api/mood", `{"Value":12}`, auth); w.Code != 200 || !strings.Contains(w.Body.String(), `"level":12`) {
		t.Fatalf("%d %s", w.Code, w.Body)
	}
	if w := do(mux, "POST", "/admin/api/mood", `{"Value":999}`, auth); w.Code != 400 {
		t.Fatalf("out of range accepted: %d", w.Code)
	}
	if w := do(mux, "GET", "/admin/api/status", "", auth); !strings.Contains(w.Body.String(), `"mood":{"level":12`) {
		t.Fatal(w.Body.String())
	}
}
