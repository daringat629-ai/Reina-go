package app

import (
	"fmt"

	"kuni/internal/billing"
	"kuni/internal/config"
)

// ownerSettings are the settings the owner may change from the admin Mini App: prices and limits, nothing that holds a key.
var ownerSettings = []billing.Setting{
	{Section: "billing", Key: "free_per_day", Label: "Бесплатных разговоров в день", Hint: "Каждому, каждый день", Kind: "int"},
	{Section: "billing", Key: "free_tokens_per_day", Label: "Потолок бесплатных токенов в день", Hint: "0 = без потолка. Защищает от очень длинных бесплатных чатов", Kind: "int"},
	{Section: "billing", Key: "packs", Label: "Пакеты (токенов, через запятую)", Hint: "Например 500000,2000000,6000000", Kind: "text"},
	{Section: "billing", Key: "margin", Label: "Наценка", Hint: "Во сколько раз пакет дороже, чем стоят его токены. Меньше 2 — риск уйти в минус", Kind: "float"},
	{Section: "billing", Key: "star_usd", Label: "Сколько тебе приносит одна звезда, $", Hint: "Около 0.013", Kind: "float"},
	{Section: "billing", Key: "ref_tokens", Label: "Бонус за приглашение, токенов", Hint: "Обоим, при первом пополнении друга. 0 = выключено", Kind: "int"},
	{Section: "billing", Key: "qr", Label: "Оплата картой по QR", Hint: "Нужен сохранённый QR", Kind: "bool"},
	{Section: "llm", Key: "price_in_per_m", Label: "Цена модели: 1 млн входных токенов, $", Hint: "Как в кабинете провайдера. От неё считаются пакеты", Kind: "float"},
	{Section: "llm", Key: "price_out_per_m", Label: "Цена модели: 1 млн выходных токенов, $", Hint: "Как в кабинете провайдера", Kind: "float"},
}

// settingsFor fills the owner's settings with their current values.
func settingsFor(c *config.Config) []billing.Setting {
	out := make([]billing.Setting, len(ownerSettings))
	for i, s := range ownerSettings {
		s.Value = c.Value(s.Section, s.Key)
		out[i] = s
	}
	return out
}

// setOwnerSetting writes one of the owner's settings (and only those) into config.toml.
func setOwnerSetting(path, section, key, value string) error {
	for _, s := range ownerSettings {
		if s.Section == section && s.Key == key {
			return config.SetKey(path, section, key, value)
		}
	}
	return fmt.Errorf("эту настройку отсюда менять нельзя")
}
