package billing

import (
	"net"
	"net/http"
	"strings"
	"sync"
	"time"
)

// guard counts events per key inside a sliding window, in memory only (a restart forgives everybody, which is fine).
type guard struct {
	mu   sync.Mutex
	hits map[string][]time.Time
}

func (g *guard) prune(key string, now time.Time, per time.Duration) []time.Time {
	if g.hits == nil {
		g.hits = map[string][]time.Time{}
	}
	var keep []time.Time
	for _, t := range g.hits[key] {
		if now.Sub(t) < per {
			keep = append(keep, t)
		}
	}
	if len(keep) == 0 {
		delete(g.hits, key)
		return nil
	}
	g.hits[key] = keep
	return keep
}

// over says whether key already has n or more events in the last per.
func (g *guard) over(key string, now time.Time, n int, per time.Duration) bool {
	g.mu.Lock()
	defer g.mu.Unlock()
	return len(g.prune(key, now, per)) >= n
}

// add records one event for key.
func (g *guard) add(key string, now time.Time, per time.Duration) {
	g.mu.Lock()
	defer g.mu.Unlock()
	g.prune(key, now, per)
	g.hits[key] = append(g.hits[key], now)
	if len(g.hits) > 20000 { // a flood of keys must not eat the memory
		g.hits = map[string][]time.Time{key: g.hits[key]}
	}
}

// take records an event and reports whether key is still within n per window.
func (g *guard) take(key string, now time.Time, n int, per time.Duration) bool {
	if g.over(key, now, n, per) {
		return false
	}
	g.add(key, now, per)
	return true
}

const (
	codeFailLimit  = 6 // wrong promo/gift codes per person
	codeFailWindow = 15 * time.Minute
)

// errTooManyCodes stops guessing of promo and gift codes.
const errTooManyCodes = "слишком много неверных кодов, попробуй через 15 минут"

// clientIP is the caller's address: behind a tunnel the real one comes in a header, otherwise it is the connection's.
func clientIP(r *http.Request) string {
	if v := strings.TrimSpace(r.Header.Get("Cf-Connecting-Ip")); v != "" {
		return v
	}
	if v := strings.TrimSpace(strings.Split(r.Header.Get("X-Forwarded-For"), ",")[0]); v != "" {
		return v
	}
	h, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		return r.RemoteAddr
	}
	return h
}

// apiGuard limits the Mini App's public API: bad signatures per address and requests per person.
var apiGuard guard
