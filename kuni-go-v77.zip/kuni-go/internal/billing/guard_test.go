package billing

import (
	"net/http/httptest"
	"path/filepath"
	"testing"
	"time"
)

func TestGuardWindow(t *testing.T) {
	var g guard
	now := time.Now()
	for i := 0; i < 3; i++ {
		if !g.take("k", now, 3, time.Minute) {
			t.Fatalf("take %d refused", i)
		}
	}
	if g.take("k", now, 3, time.Minute) {
		t.Fatal("fourth take must be refused")
	}
	if !g.take("k", now.Add(2*time.Minute), 3, time.Minute) {
		t.Fatal("the window must slide")
	}
	if !g.take("other", now, 3, time.Minute) {
		t.Fatal("keys are independent")
	}
}

func TestCodeGuessingIsStopped(t *testing.T) {
	s := Open(filepath.Join(t.TempDir(), "b.json"))
	now := time.Now()
	for i := 0; i < codeFailLimit; i++ {
		if _, _, err := s.Redeem("NOPE", 7, now); err == nil || err.Error() == errTooManyCodes {
			t.Fatalf("guess %d: %v", i, err)
		}
	}
	if _, _, err := s.Redeem("NOPE", 7, now); err == nil || err.Error() != errTooManyCodes {
		t.Fatalf("after %d wrong codes the person must be stopped, got %v", codeFailLimit, err)
	}
	if _, err := s.ClaimGift("XXXXXXXX", 7, now); err == nil || err.Error() != errTooManyCodes {
		t.Fatalf("gift guessing shares the limit, got %v", err)
	}
	if _, _, err := s.Redeem("NOPE", 8, now); err == nil || err.Error() == errTooManyCodes {
		t.Fatal("somebody else is not blocked")
	}
	if _, _, err := s.Redeem("NOPE", 7, now.Add(codeFailWindow+time.Second)); err == nil || err.Error() == errTooManyCodes {
		t.Fatal("the block must end")
	}
}

func TestClientIP(t *testing.T) {
	r := httptest.NewRequest("POST", "/app/api/me", nil)
	r.RemoteAddr = "10.0.0.5:4444"
	if clientIP(r) != "10.0.0.5" {
		t.Fatal(clientIP(r))
	}
	r.Header.Set("Cf-Connecting-Ip", "203.0.113.9")
	if clientIP(r) != "203.0.113.9" {
		t.Fatal(clientIP(r))
	}
}
