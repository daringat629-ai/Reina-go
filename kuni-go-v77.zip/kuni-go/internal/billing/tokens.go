package billing

import (
	"crypto/rand"
	"errors"
	"fmt"
	"strings"
	"time"
)

// Pack is a number of tokens on sale, priced in Stars and (optionally) in the main currency for a bank QR.
type Pack struct {
	Tokens int64
	Stars  int
	Price  int // by bank QR, in the main currency (0 = not by QR)
}

// PackPrice is what a pack must cost so that serving it never loses money: the tokens at the main model's input price (output
// tokens are already counted at their own price when they are taken from the balance), times margin, turned into Stars (what one
// Star brings the owner, in USD) and into the main currency (usdPerUnit = how many USD one unit is worth; 0 = no QR price).
func PackPrice(tokens int64, priceInPerM, margin, starUSD, usdPerUnit float64) (stars, price int) {
	if tokens <= 0 || priceInPerM <= 0 || margin <= 0 {
		return 0, 0
	}
	usd := float64(tokens) / 1e6 * priceInPerM * margin
	if starUSD > 0 {
		stars = int(usd/starUSD + .999)
		stars = max(stars, 1)
	}
	if usdPerUnit > 0 {
		price = int(usd/usdPerUnit + .999)
		price = max(price, 1)
	}
	return
}

// Credits is what one model request costs in tokens of the main model: input and output each at their own price, so a request to a
// dearer or a cheaper model takes as much as it really costs.
func Credits(in, out int, priceIn, priceOut, mainIn float64) int64 {
	if mainIn <= 0 {
		return int64(in + out)
	}
	if priceIn <= 0 && priceOut <= 0 { // an unknown price: count it like the main model's input, output at 3.5x
		priceIn, priceOut = mainIn, mainIn*3.5
	}
	return int64((float64(in)*priceIn + float64(out)*priceOut) / mainIn)
}

// AddTokens puts tokens on a person's balance and records it. The same charge id is never counted twice. kind: pack, qr, bonus, gift_in.
func (s *Store) AddTokens(id, tokens int64, stars, som int, charge, kind string, now time.Time) (User, error) {
	if tokens <= 0 {
		return User{}, errors.New("billing: tokens must be positive")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if charge != "" {
		for _, p := range s.d.Payments {
			if p.Charge == charge {
				return *s.user(id), nil
			}
		}
	}
	u := s.user(id)
	u.Tokens += tokens
	if kind == "pack" || kind == "qr" {
		u.Paid++
	}
	s.d.Payments = append(s.d.Payments, Payment{At: now, UserID: id, Stars: stars, Som: som, Charge: charge, Tokens: tokens, Kind: kind})
	s.save()
	return *u, nil
}

// Spend takes what one model request in a person's chat cost. Only a conversation paid from the balance takes it from the balance;
// every conversation adds to the numbers behind the "≈ N messages" estimate. Unknown chats (groups, the owner) are ignored.
func (s *Store) Spend(id, credits int64, now time.Time) {
	if credits <= 0 {
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	u := s.d.Users[id]
	if u == nil {
		return
	}
	if u.Day == now.Format("2006-01-02") {
		u.DayTokens += credits
	}
	u.AllTokens += credits
	s.d.ConvSum += credits
	if u.Charging {
		u.Tokens -= credits
		u.Spent += credits
	}
	s.save()
}

// PerConv is how many tokens one conversation costs on average; until there are enough conversations to tell, it is def.
func (s *Store) PerConv(def int64) int64 {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.d.ConvN >= 30 && s.d.ConvSum > 0 {
		return max(s.d.ConvSum/s.d.ConvN, 1)
	}
	return max(def, 1)
}

// Gift is a pack someone bought for somebody else: a code the friend opens in the bot.
type Gift struct {
	Code    string    `json:"code"`
	From    int64     `json:"from"`
	Tokens  int64     `json:"tokens"`
	Stars   int       `json:"stars"`
	At      time.Time `json:"at"`
	To      int64     `json:"to,omitempty"`
	Claimed time.Time `json:"claimed,omitempty"`
	Charge  string    `json:"charge,omitempty"`
}

func giftCode() string {
	const abc = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
	b := make([]byte, 8)
	_, _ = rand.Read(b)
	for i := range b {
		b[i] = abc[int(b[i])%len(abc)]
	}
	return string(b)
}

// NewGift records a gift paid with charge (the same charge again returns the same gift).
func (s *Store) NewGift(from, tokens int64, stars int, charge string, now time.Time) Gift {
	s.mu.Lock()
	defer s.mu.Unlock()
	for _, g := range s.d.Gifts {
		if charge != "" && g.Charge == charge {
			return g
		}
	}
	g := Gift{Code: giftCode(), From: from, Tokens: tokens, Stars: stars, At: now, Charge: charge}
	s.d.Gifts = append(s.d.Gifts, g)
	u := s.user(from)
	u.Paid++
	s.d.Payments = append(s.d.Payments, Payment{At: now, UserID: from, Stars: stars, Charge: charge, Tokens: tokens, Kind: "gift"})
	s.save()
	return g
}

// ClaimGift moves a gift's tokens to the person who opened its code.
func (s *Store) ClaimGift(code string, to int64, now time.Time) (Gift, error) {
	code = strings.ToUpper(strings.TrimSpace(code))
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.codeFails.over(fmt.Sprint(to), now, codeFailLimit, codeFailWindow) {
		return Gift{}, errors.New(errTooManyCodes)
	}
	for i := range s.d.Gifts {
		g := &s.d.Gifts[i]
		if g.Code != code {
			continue
		}
		switch {
		case g.To != 0:
			return *g, errors.New("этот подарок уже открыли")
		case g.From == to:
			return *g, errors.New("свой подарок открыть нельзя: отправь ссылку другу")
		}
		g.To, g.Claimed = to, now
		u := s.user(to)
		u.Tokens += g.Tokens
		s.d.Payments = append(s.d.Payments, Payment{At: now, UserID: to, Tokens: g.Tokens, Charge: "gift:" + g.Code, Kind: "gift_in"})
		s.save()
		return *g, nil
	}
	s.codeFails.add(fmt.Sprint(to), now, codeFailWindow)
	return Gift{}, fmt.Errorf("подарок %s не найден", code)
}

// SetWatch turns on or off the message about her coming online.
func (s *Store) SetWatch(id int64, on bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.user(id).Watch = on
	s.save()
}

// TakeWatchers returns everyone waiting for her and forgets them (they are told once).
func (s *Store) TakeWatchers() []int64 {
	s.mu.Lock()
	defer s.mu.Unlock()
	var out []int64
	for id, u := range s.d.Users {
		if u.Watch {
			u.Watch = false
			out = append(out, id)
		}
	}
	if len(out) > 0 {
		s.save()
	}
	return out
}

// History is a person's payments, gifts and bonuses, newest first (at most n).
func (s *Store) History(id int64, n int) []Payment {
	s.mu.Lock()
	defer s.mu.Unlock()
	var out []Payment
	for i := len(s.d.Payments) - 1; i >= 0 && len(out) < n; i-- {
		if p := s.d.Payments[i]; p.UserID == id {
			out = append(out, p)
		}
	}
	return out
}

// GiftsFrom lists the gifts a person bought, newest first.
func (s *Store) GiftsFrom(id int64) []Gift {
	s.mu.Lock()
	defer s.mu.Unlock()
	var out []Gift
	for i := len(s.d.Gifts) - 1; i >= 0; i-- {
		if s.d.Gifts[i].From == id {
			out = append(out, s.d.Gifts[i])
		}
	}
	return out
}

// Own marks that she is writing to a person on her own (a reminder, a follow-up): what that costs is never taken from their
// balance. The next conversation they start is counted by Take as usual.
func (s *Store) Own(id int64) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if u := s.d.Users[id]; u != nil && u.Charging {
		u.Charging = false
		s.save()
	}
}
