package billing

import (
	"context"
	"encoding/json"
	"fmt"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestPromoCodesGiveTokensOncePerPersonAndShowWhoPaid(t *testing.T) {
	srv, calls := fakeAPI(t)
	st := Open(filepath.Join(t.TempDir(), "b.json"))
	b := newBot(srv, st)
	ctx := context.Background()
	if _, err := st.NewPromo("ре", 1, 0, 0, "", t0); err == nil {
		t.Fatal("bad code refused")
	}
	if _, err := st.NewPromo("reina100", 100000, 2, 7, "TikTok", t0); err != nil {
		t.Fatal(err)
	}
	if _, err := st.NewPromo("REINA100", 1, 0, 0, "", t0); err == nil {
		t.Fatal("no duplicate codes")
	}
	b.handle(ctx, msg(t, `{"update_id":1,"message":{"from":{"id":7},"chat":{"id":7},"text":"/start p_REINA100"}}`))
	if st.Get(7, t0).Tokens != 100000 || st.Get(7, t0).Promo != "REINA100" {
		t.Fatalf("by link: %+v", st.Get(7, t0))
	}
	b.handle(ctx, msg(t, `{"update_id":2,"message":{"from":{"id":7},"chat":{"id":7},"text":"reina100"}}`))
	if st.Get(7, t0).Tokens != 100000 || !strings.Contains(fmt.Sprint(calls("sendMessage")), "уже вводил") {
		t.Fatal("once per person")
	}
	b.handle(ctx, msg(t, `{"update_id":3,"message":{"from":{"id":8},"chat":{"id":8},"text":"REINA100"}}`))
	b.Now = func() time.Time { return t0.Add(time.Minute) }
	b.handle(ctx, msg(t, `{"update_id":4,"message":{"from":{"id":9},"chat":{"id":9},"text":"/promo REINA100"}}`))
	if st.Get(8, t0).Tokens != 100000 || st.Get(9, t0).Tokens != 0 {
		t.Fatal("two people only")
	}
	b.handle(ctx, msg(t, `{"update_id":5,"message":{"from":{"id":9},"chat":{"id":9},"text":"HELLO"}}`))
	if strings.Contains(fmt.Sprint(calls("sendMessage")), "промокода HELLO нет") {
		t.Fatal("ordinary text is not taken for a code")
	}
	_, _ = st.AddTokens(8, 500000, 20, 0, "c", "pack", t0)
	ps := st.PromoStats(t0)
	if len(ps) != 1 || ps[0].Used != 2 || ps[0].Paid != 1 || ps[0].Left != 0 || ps[0].Active {
		t.Fatalf("stats: %+v", ps)
	}
	if s := st.Stats(t0, time.UTC); s.TokensSold != 500000 {
		t.Fatalf("promo tokens are not sales: %+v", s)
	}
	if _, _, err := st.Redeem("REINA100", 10, t0.Add(8*24*time.Hour)); err == nil {
		t.Fatal("expired")
	}
	_, _ = st.NewPromo("FREE", 50000, 0, 0, "", t0)
	_ = st.SetPromoOff("free", true)
	if _, _, err := st.Redeem("FREE", 11, t0); err == nil {
		t.Fatal("switched off")
	}
}

func TestOwnersProfitPricesAndPromosInTheApp(t *testing.T) {
	srv, _ := fakeAPI(t)
	dir := t.TempDir()
	st := Open(filepath.Join(dir, "b.json"))
	pay := newBot(srv, st)
	var saved string
	adm := &Admin{Token: "A", BaseURL: srv.URL, Store: st, Pay: pay, QRPath: filepath.Join(dir, "qr.png"), Owner: func() int64 { return 1 }, Now: func() time.Time { return t0 }, Loc: time.UTC,
		Costs: func(n int) map[string]float64 { return map[string]float64{"2026-10-30": 0.40, "2026-10-29": 1.10} },
		Money: func() (float64, float64) { return 0.013, 0.0125 },
		Settings: func() []Setting {
			return []Setting{{Section: "billing", Key: "margin", Label: "Наценка", Value: "2.5", Kind: "float"}}
		},
		Set: func(sec, key, val string) error { saved = sec + "." + key + "=" + val; return nil }}
	_, _ = st.AddTokens(7, 2000000, 100, 0, "s", "pack", t0)
	_, _ = st.AddTokens(8, 500000, 0, 80, "q", "qr", t0)
	h := adm.WebApp()
	boss := signInit("A", `{"id":1}`, t0)
	w := postJSON(h, "/app/admin/api/profit", `{"days":3}`, boss)
	var pf map[string]any
	_ = json.Unmarshal(w.Body.Bytes(), &pf)
	// today: 100 stars * 0.013 = 1.30 + 80 rub * 0.0125 = 1.00 -> 2.30 in, 0.40 cost; yesterday 1.10 cost
	if pf["in"].(float64) != 2.3 || pf["cost"].(float64) != 1.5 || pf["profit"].(float64) != 0.8 || len(pf["days"].([]any)) != 3 {
		t.Fatalf("profit: %s", w.Body.String())
	}
	if w := postJSON(h, "/app/admin/api/set", `{"section":"billing","key":"margin","value":3}`, boss); w.Code != 200 || saved != "billing.margin=3" {
		t.Fatalf("set: %s %q", w.Body.String(), saved)
	}
	if w := postJSON(h, "/app/admin/api/settings", `{}`, boss); !strings.Contains(w.Body.String(), `"stars":20`) || !strings.Contains(w.Body.String(), "Наценка") {
		t.Fatalf("settings with the packs' prices: %s", w.Body.String())
	}
	if w := postJSON(h, "/app/admin/api/promo/new", `{"code":"tiktok","tokens":100000,"max":50,"note":"ролик 1"}`, boss); !strings.Contains(w.Body.String(), `"code":"TIKTOK"`) || !strings.Contains(w.Body.String(), "start=p_TIKTOK") {
		t.Fatalf("promo: %s", w.Body.String())
	}
	if w := postJSON(h, "/app/admin/api/promo/off", `{"code":"TIKTOK","off":true}`, boss); !strings.Contains(w.Body.String(), `"off":true`) {
		t.Fatalf("off: %s", w.Body.String())
	}
}
