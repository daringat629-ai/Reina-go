package billing

import (
	"errors"
	"fmt"
	"regexp"
	"sort"
	"strings"
	"time"
)

// Promo is a code the owner hands out (in a video, to a blogger): whoever enters it gets tokens, once per person.
type Promo struct {
	Code    string    `json:"code"`
	Tokens  int64     `json:"tokens"`
	Max     int       `json:"max,omitempty"` // how many people may use it (0 = no limit)
	Note    string    `json:"note,omitempty"`
	Created time.Time `json:"created"`
	Expires time.Time `json:"expires,omitempty"`
	Off     bool      `json:"off,omitempty"`
	UsedBy  []int64   `json:"used_by,omitempty"`
}

var promoRe = regexp.MustCompile(`^[A-Z0-9_-]{3,24}$`)

// NormPromo is a code as it is stored: capitals, no spaces.
func NormPromo(s string) string { return strings.ToUpper(strings.TrimSpace(s)) }

// IsPromoLike says whether a message looks like a promo code someone typed.
func IsPromoLike(s string) bool { return promoRe.MatchString(NormPromo(s)) }

// NewPromo creates a code (days = how long it works, 0 = no end).
func (s *Store) NewPromo(code string, tokens int64, limit, days int, note string, now time.Time) (Promo, error) {
	code = NormPromo(code)
	if !promoRe.MatchString(code) {
		return Promo{}, errors.New("код: 3-24 латинских буквы, цифры, _ или -")
	}
	if tokens <= 0 || tokens > 1_000_000_000 {
		return Promo{}, errors.New("сколько токенов даёт код?")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	for _, p := range s.d.Promos {
		if p.Code == code {
			return Promo{}, fmt.Errorf("код %s уже есть", code)
		}
	}
	p := Promo{Code: code, Tokens: tokens, Max: max(limit, 0), Note: strings.TrimSpace(note), Created: now}
	if days > 0 {
		p.Expires = now.AddDate(0, 0, days)
	}
	s.d.Promos = append(s.d.Promos, p)
	s.save()
	return p, nil
}

// SetPromoOff turns a code off (or back on).
func (s *Store) SetPromoOff(code string, off bool) error {
	code = NormPromo(code)
	s.mu.Lock()
	defer s.mu.Unlock()
	for i := range s.d.Promos {
		if s.d.Promos[i].Code == code {
			s.d.Promos[i].Off = off
			s.save()
			return nil
		}
	}
	return fmt.Errorf("кода %s нет", code)
}

// Redeem gives a person the tokens of a code, once per person.
func (s *Store) Redeem(code string, id int64, now time.Time) (Promo, User, error) {
	code = NormPromo(code)
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.codeFails.over(fmt.Sprint(id), now, codeFailLimit, codeFailWindow) {
		return Promo{}, User{}, errors.New(errTooManyCodes)
	}
	for i := range s.d.Promos {
		p := &s.d.Promos[i]
		if p.Code != code {
			continue
		}
		switch {
		case p.Off:
			return *p, User{}, errors.New("этот промокод больше не действует")
		case !p.Expires.IsZero() && now.After(p.Expires):
			return *p, User{}, errors.New("срок промокода закончился")
		case p.Max > 0 && len(p.UsedBy) >= p.Max:
			return *p, User{}, errors.New("промокод уже разобрали")
		}
		for _, u := range p.UsedBy {
			if u == id {
				return *p, User{}, errors.New("ты уже вводил(а) этот промокод")
			}
		}
		p.UsedBy = append(p.UsedBy, id)
		u := s.user(id)
		u.Tokens += p.Tokens
		if u.Promo == "" {
			u.Promo = p.Code
		}
		s.d.Payments = append(s.d.Payments, Payment{At: now, UserID: id, Tokens: p.Tokens, Charge: "promo:" + p.Code + ":" + fmt.Sprint(id), Kind: "promo"})
		s.save()
		return *p, *u, nil
	}
	s.codeFails.add(fmt.Sprint(id), now, codeFailWindow)
	return Promo{}, User{}, fmt.Errorf("промокода %s нет", code)
}

// PromoStat is a code with how it worked: how many used it and how many of them later paid.
type PromoStat struct {
	Promo
	Used, Paid int
	Left       int // -1 = no limit
	Active     bool
}

// PromoStats lists the codes, newest first.
func (s *Store) PromoStats(now time.Time) []PromoStat {
	s.mu.Lock()
	defer s.mu.Unlock()
	var out []PromoStat
	for _, p := range s.d.Promos {
		st := PromoStat{Promo: p, Used: len(p.UsedBy), Left: -1}
		if p.Max > 0 {
			st.Left = max(p.Max-st.Used, 0)
		}
		for _, id := range p.UsedBy {
			if u := s.d.Users[id]; u != nil && u.Paid > 0 {
				st.Paid++
			}
		}
		st.Active = !p.Off && (p.Expires.IsZero() || now.Before(p.Expires)) && st.Left != 0
		out = append(out, st)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Created.After(out[j].Created) })
	return out
}

// DayMoney is what came in on one day.
type DayMoney struct {
	Stars, Som int
}

// Revenue is the money of the last n days (by the given clock), keyed "2006-01-02". Gifts received, bonuses and promo
// codes are not money and are left out.
func (s *Store) Revenue(now time.Time, loc *time.Location, n int) map[string]DayMoney {
	from := now.In(loc).AddDate(0, 0, -n).Format("2006-01-02")
	s.mu.Lock()
	defer s.mu.Unlock()
	out := map[string]DayMoney{}
	for _, p := range s.d.Payments {
		if p.Kind == "gift_in" || p.Kind == "bonus" || p.Kind == "promo" {
			continue
		}
		d := p.At.In(loc).Format("2006-01-02")
		if d <= from {
			continue
		}
		m := out[d]
		m.Stars += p.Stars
		m.Som += p.Som
		out[d] = m
	}
	return out
}

// HasPromo says whether such a code exists (so ordinary text is not answered with "no such code").
func (s *Store) HasPromo(code string) bool {
	code = NormPromo(code)
	s.mu.Lock()
	defer s.mu.Unlock()
	for _, p := range s.d.Promos {
		if p.Code == code {
			return true
		}
	}
	return false
}
