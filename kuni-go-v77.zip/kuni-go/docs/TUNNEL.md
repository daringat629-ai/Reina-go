# Постоянный адрес для мини-приложения

Мини-приложению нужен публичный https-адрес, который смотрит на порт `proxy.port` (10434). Рейна отдаёт по нему только `/app/` и `/world`, остальное закрыто.

## Вариант 1. Свой домен и именованный туннель Cloudflare (надёжнее всего)

Адрес не меняется никогда. Нужен домен (от ~100 ₽ в год) на DNS Cloudflare.

```
cloudflared tunnel login
cloudflared tunnel create reina
cloudflared tunnel route dns reina app.твой-домен.ru
```

`~/.cloudflared/config.yml`:

```
tunnel: reina
credentials-file: /home/USER/.cloudflared/<ID>.json
ingress:
  - hostname: app.твой-домен.ru
    service: http://localhost:10434
  - service: http_status:404
```

Запуск как службы: `sudo cloudflared service install`. В `config.toml`: `webapp_url = "https://app.твой-домен.ru/app/"`.

## Вариант 2. Бесплатный быстрый туннель с автообновлением адреса

Быстрый туннель Cloudflare временный и сам умирает. Скрипт `deploy/reina-tunnel.sh` держит его живым, перезапускает, если он перестал отвечать, и пишет новый адрес в `config.toml`. Рейна перечитывает конфиг сама, а кнопка «Открыть» в ботах переезжает на новый адрес в течение минуты, перезапуск не нужен.

Установка (один раз, на сервере):

```
sudo install -m 755 deploy/reina-tunnel.sh /usr/local/bin/reina-tunnel.sh
sudo install -m 644 deploy/reina-tunnel.service /etc/systemd/system/reina-tunnel.service
sudo systemctl daemon-reload && sudo systemctl enable --now reina-tunnel
```

Нужен `cloudflared` в `/usr/local/bin/cloudflared` (или переменная `CLOUDFLARED=путь` в службе). Если конфиг лежит не в `/opt/reina/config.toml`, задай `REINA_CONF`.

Пока адрес меняется, мини-приложение у людей может пропасть на пару минут: для платежей надёжнее вариант 1. Кнопки оплаты в самом боте работают без туннеля.
