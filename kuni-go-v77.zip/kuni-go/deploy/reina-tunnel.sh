#!/bin/bash
# Keeps a free Cloudflare quick tunnel to Reina alive and writes its current address into config.toml as billing.webapp_url.
# Reina reloads the config by herself and moves the Mini App button to the new address within a minute.
# Quick tunnels are temporary: this script restarts the tunnel when it dies or stops answering.
CONF="${REINA_CONF:-/opt/reina/config.toml}"
BIN="${CLOUDFLARED:-/usr/local/bin/cloudflared}"
PORT="${REINA_PORT:-10434}"
LOG="${TUNNEL_LOG:-/var/log/reina-tunnel.log}"

while true; do
  : > "$LOG"
  "$BIN" tunnel --no-autoupdate --url "http://localhost:$PORT" > "$LOG" 2>&1 &
  PID=$!
  U=""
  for _ in $(seq 1 40); do
    U=$(grep -o 'https://[a-z0-9-]*\.trycloudflare\.com' "$LOG" | head -1)
    [ -n "$U" ] && break
    sleep 1
  done
  if [ -n "$U" ]; then
    sed -i "s|^webapp_url = .*|webapp_url = \"$U/app/\"|" "$CONF"
    echo "$(date -u +%FT%TZ) tunnel $U" >> "$LOG"
  fi
  bad=0
  while kill -0 "$PID" 2>/dev/null; do
    sleep 30
    if grep -q "Tunnel not found" "$LOG"; then break; fi
    code=$(curl -s -o /dev/null -m 10 -w '%{http_code}' "$U/app/")
    if [ "$code" = 200 ]; then bad=0; else bad=$((bad+1)); fi
    [ "$bad" -ge 3 ] && break
  done
  kill "$PID" 2>/dev/null; wait "$PID" 2>/dev/null
  sleep 5
done
