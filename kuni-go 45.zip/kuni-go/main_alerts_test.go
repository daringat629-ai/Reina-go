package main

import (
	"strings"
	"testing"
	"time"

	"kuni/internal/telegram"
)

func TestTgTrouble(t *testing.T) {
	now := time.Now()
	var errs []telegram.ErrorRecord
	for i := 0; i < 4; i++ {
		errs = append(errs, telegram.ErrorRecord{At: now.Add(-time.Minute), Method: "sendMessage", Message: "boom"})
	}
	if got := tgTrouble(telegram.Health{Errors: errs}, now); got != "" {
		t.Fatalf("4 errors is not an outage: %q", got)
	}
	errs = append(errs, telegram.ErrorRecord{At: now.Add(-time.Minute), Method: "sendMessage", Message: "telegram 400: InputFile is not specified"})
	got := tgTrouble(telegram.Health{Errors: errs}, now)
	if !strings.Contains(got, "5 ошибок") || !strings.Contains(got, "InputFile") {
		t.Fatalf("a burst must be reported with the last error: %q", got)
	}
	old := []telegram.ErrorRecord{}
	for i := 0; i < 9; i++ {
		old = append(old, telegram.ErrorRecord{At: now.Add(-time.Hour), Method: "x", Message: "old"})
	}
	if got := tgTrouble(telegram.Health{Errors: old}, now); got != "" {
		t.Fatalf("errors from an hour ago are history: %q", got)
	}
	if got := tgTrouble(telegram.Health{FloodUntil: now.Add(20 * time.Minute)}, now); !strings.Contains(got, "flood wait") {
		t.Fatalf("a long flood wait must be reported: %q", got)
	}
	if got := tgTrouble(telegram.Health{FloodUntil: now.Add(30 * time.Second)}, now); got != "" {
		t.Fatalf("a short flood wait is normal: %q", got)
	}
}
