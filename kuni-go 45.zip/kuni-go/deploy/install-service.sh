#!/bin/sh
# Installs the OpenRC service so Reina starts at boot and comes back if she crashes.
# Run as root. Usage: sh deploy/install-service.sh [/opt/reina]
set -e
DIR="${1:-/opt/reina}"
SRC="$(dirname "$0")/reina.initd"
[ "$(id -u)" = 0 ] || { echo "нужен root"; exit 1; }
command -v rc-service >/dev/null || { echo "это не OpenRC (Alpine). Запускай вручную: LD_LIBRARY_PATH=$DIR nohup $DIR/reina-tdlib > $DIR/reina.log 2>&1 &"; exit 1; }
[ -x "$DIR/reina-tdlib" ] || { echo "не вижу $DIR/reina-tdlib"; exit 1; }
sed "s#: \${REINA_DIR:=/opt/reina}#: \${REINA_DIR:=$DIR}#" "$SRC" > /etc/init.d/reina
chmod +x /etc/init.d/reina
rc-update add reina default
# stop the hand-started copy (if any) and let the service take over
pid=$(pgrep -x reina-tdlib || true)
[ -n "$pid" ] && kill $pid && sleep 3
rc-service reina start
sleep 3
rc-service reina status
tail -n 3 "$DIR/reina.log"
echo "Готово. Управление: rc-service reina start|stop|restart|status"
