// Package people keeps a short card per person she talks to: durable facts, preferences, promises. Cards are
// cheap to show (a few lines, only for the people in the current conversation) and she writes them herself.
// Facts learned in a private chat are marked private and never shown in groups.
package people

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

const (
	MaxFacts   = 14  // oldest facts are dropped beyond this
	MaxFactLen = 220 // characters
)

// Fact is one remembered line.
type Fact struct {
	Text    string    `json:"text"`
	Private bool      `json:"private,omitempty"`
	At      time.Time `json:"at"`
}

// Card is everything she knows about one person.
type Card struct {
	ID    int64  `json:"id"`
	Name  string `json:"name"`
	Facts []Fact `json:"facts"`
	// Username and Bio come from the Telegram profile; About is what SHE thinks of the person, in her own words.
	Username string    `json:"username,omitempty"`
	Bio      string    `json:"bio,omitempty"`
	About    string    `json:"about,omitempty"`
	AboutAt  time.Time `json:"about_at,omitempty"`
}

// MaxAbout is the longest description kept, in characters.
const MaxAbout = 600

type Store struct {
	mu  sync.Mutex
	dir string
}

func New(dir string) *Store { return &Store{dir: dir} }

func (s *Store) path(id int64) string { return filepath.Join(s.dir, strconv.FormatInt(id, 10)+".json") }

func (s *Store) load(id int64) Card {
	c := Card{ID: id}
	if b, err := os.ReadFile(s.path(id)); err == nil {
		_ = json.Unmarshal(b, &c)
		c.ID = id
	}
	return c
}

func (s *Store) save(c Card) error {
	if len(c.Facts) == 0 && strings.TrimSpace(c.About) == "" {
		err := os.Remove(s.path(c.ID))
		if os.IsNotExist(err) {
			return nil
		}
		return err
	}
	if err := os.MkdirAll(s.dir, 0o755); err != nil {
		return err
	}
	b, _ := json.MarshalIndent(c, "", " ")
	tmp := s.path(c.ID) + ".tmp"
	if err := os.WriteFile(tmp, b, 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, s.path(c.ID))
}

// Get returns the card (empty when nobody wrote one yet).
func (s *Store) Get(id int64) Card {
	if s == nil {
		return Card{ID: id}
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.load(id)
}

func norm(s string) string { return strings.ToLower(strings.Join(strings.Fields(s), " ")) }

// Add remembers a fact; a fact that is already known is not repeated.
func (s *Store) Add(id int64, name, fact string, private bool, now time.Time) error {
	fact = strings.TrimSpace(strings.ReplaceAll(fact, "\n", " "))
	if id == 0 || fact == "" {
		return fmt.Errorf("need a user id and a fact")
	}
	if r := []rune(fact); len(r) > MaxFactLen {
		fact = string(r[:MaxFactLen]) + "…"
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	c := s.load(id)
	if name = strings.TrimSpace(name); name != "" {
		c.Name = name
	}
	for i, f := range c.Facts {
		if norm(f.Text) == norm(fact) {
			c.Facts[i].Private = f.Private && private // known in public: stays public
			return s.save(c)
		}
	}
	c.Facts = append(c.Facts, Fact{Text: fact, Private: private, At: now})
	if n := len(c.Facts); n > MaxFacts {
		c.Facts = c.Facts[n-MaxFacts:]
	}
	return s.save(c)
}

// Supersede replaces the known fact that contains oldPart (case-insensitive) with newFact, so an outdated fact does not
// stay next to its correction. Without a match (or with a too short oldPart) the new fact is simply added.
// It reports whether something was replaced.
func (s *Store) Supersede(id int64, name, oldPart, newFact string, private bool, now time.Time) (bool, error) {
	newFact = strings.TrimSpace(strings.ReplaceAll(newFact, "\n", " "))
	oldNorm := norm(oldPart)
	if id == 0 || newFact == "" {
		return false, fmt.Errorf("need a user id and a fact")
	}
	if r := []rune(newFact); len(r) > MaxFactLen {
		newFact = string(r[:MaxFactLen]) + "…"
	}
	if len([]rune(oldNorm)) < 3 {
		return false, s.Add(id, name, newFact, private, now)
	}
	if done, err := s.replace(id, name, oldNorm, newFact, private, now); done || err != nil {
		return done, err
	}
	return false, s.Add(id, name, newFact, private, now)
}

func (s *Store) replace(id int64, name, oldNorm, newFact string, private bool, now time.Time) (bool, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	c := s.load(id)
	at := -1
	// the best match wins: the whole fact, then the pattern as whole words, then anywhere inside a fact
	for _, match := range []func(string) bool{
		func(t string) bool { return t == oldNorm },
		func(t string) bool { return strings.Contains(" "+t+" ", " "+oldNorm+" ") },
		func(t string) bool { return strings.Contains(t, oldNorm) },
	} {
		for i, f := range c.Facts {
			if match(norm(f.Text)) {
				at = i
				break
			}
		}
		if at >= 0 {
			break
		}
	}
	if at < 0 {
		return false, nil
	}
	if n := strings.TrimSpace(name); n != "" {
		c.Name = n
	}
	var kept []Fact
	for i, f := range c.Facts {
		if i != at && norm(f.Text) == norm(newFact) {
			continue // the correction was already known: only the old one goes
		}
		if i == at {
			f = Fact{Text: newFact, Private: private, At: now}
		}
		kept = append(kept, f)
	}
	c.Facts = kept
	return true, s.save(c)
}

// Forget removes the facts containing the text (case-insensitive) and returns how many it removed.
func (s *Store) Forget(id int64, contains string) int {
	contains = norm(contains)
	if contains == "" {
		return 0
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	c := s.load(id)
	var keep []Fact
	for _, f := range c.Facts {
		if !strings.Contains(norm(f.Text), contains) {
			keep = append(keep, f)
		}
	}
	n := len(c.Facts) - len(keep)
	if n > 0 {
		c.Facts = keep
		_ = s.save(c)
	}
	return n
}

// Replace overwrites a card (the panel editor). Empty facts delete the card.
func (s *Store) Replace(id int64, name string, facts []Fact) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	var clean []Fact
	for _, f := range facts {
		f.Text = strings.TrimSpace(f.Text)
		if f.Text == "" {
			continue
		}
		if r := []rune(f.Text); len(r) > MaxFactLen {
			f.Text = string(r[:MaxFactLen]) + "…"
		}
		clean = append(clean, f)
	}
	if len(clean) > MaxFacts {
		clean = clean[len(clean)-MaxFacts:]
	}
	c := s.load(id) // the profile and her description stay
	c.Name, c.Facts = strings.TrimSpace(name), clean
	return s.save(c)
}

// All lists every card, by name.
func (s *Store) All() []Card {
	if s == nil {
		return nil
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	ents, _ := os.ReadDir(s.dir)
	var out []Card
	for _, e := range ents {
		id, err := strconv.ParseInt(strings.TrimSuffix(e.Name(), ".json"), 10, 64)
		if err != nil || !strings.HasSuffix(e.Name(), ".json") {
			continue
		}
		if c := s.load(id); len(c.Facts) > 0 || c.About != "" {
			out = append(out, c)
		}
	}
	sort.Slice(out, func(i, j int) bool { return strings.ToLower(out[i].Name) < strings.ToLower(out[j].Name) })
	return out
}

// Render is the card as shown to the model. Private facts are left out unless includePrivate.
func (c Card) Render(includePrivate bool) string {
	var lines []string
	for _, f := range c.Facts {
		if f.Private && !includePrivate {
			continue
		}
		lines = append(lines, "- "+f.Text)
	}
	if includePrivate && strings.TrimSpace(c.About) != "" {
		lines = append([]string{"(your own take: " + strings.Join(strings.Fields(c.About), " ") + ")"}, lines...)
	}
	if len(lines) == 0 {
		return ""
	}
	name := strings.ReplaceAll(c.Name, `"`, "'")
	return fmt.Sprintf("<person_card user_id=\"%d\" name=\"%s\">\n%s\n</person_card>\n", c.ID, name, strings.Join(lines, "\n"))
}

// SetAbout stores her description of the person (an empty text removes it).
func (s *Store) SetAbout(id int64, name, about string, now time.Time) error {
	if id == 0 {
		return fmt.Errorf("need a user id")
	}
	about = strings.TrimSpace(about)
	if r := []rune(about); len(r) > MaxAbout {
		about = string(r[:MaxAbout]) + "…"
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	c := s.load(id)
	if name = strings.TrimSpace(name); name != "" {
		c.Name = name
	}
	c.About = about
	c.AboutAt = now
	if about == "" {
		c.AboutAt = time.Time{}
	}
	return s.save(c)
}

// SetProfile files the Telegram profile on an existing card (no card, nothing to do).
func (s *Store) SetProfile(id int64, username, bio string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	c := s.load(id)
	if len(c.Facts) == 0 && c.About == "" {
		return nil
	}
	username, bio = strings.TrimPrefix(strings.TrimSpace(username), "@"), strings.TrimSpace(bio)
	if r := []rune(bio); len(r) > 300 {
		bio = string(r[:300]) + "…"
	}
	if c.Username == username && c.Bio == bio {
		return nil
	}
	c.Username, c.Bio = username, bio
	return s.save(c)
}
