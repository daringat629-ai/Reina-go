package desktop

import (
	"bytes"
	"context"
	"image/jpeg"
	"testing"
	"time"
)

func TestLiveFrameWorksWhileAnActionHoldsTheDesktop(t *testing.T) {
	need(t)
	d := New()
	defer d.Close()
	if _, ok, _ := d.Frame(); ok || d.Live() {
		t.Fatal("a stopped desktop has no picture")
	}
	inAction, release := make(chan struct{}), make(chan struct{})
	done := make(chan error, 1)
	go func() {
		done <- d.Do(context.Background(), Options{Width: 800, Height: 600}, func(s *Screen) error {
			if err := s.X().Move(321, 123); err != nil {
				return err
			}
			close(inAction)
			<-release // a long action: the desktop lock is held
			return nil
		})
	}()
	<-inAction
	got := make(chan []byte, 1)
	go func() {
		b, ok, err := d.Frame()
		if !ok || err != nil {
			t.Error("frame:", ok, err)
		}
		got <- b
	}()
	select {
	case b := <-got:
		img, err := jpeg.Decode(bytes.NewReader(b))
		if err != nil || img.Bounds().Dx() != 800 || img.Bounds().Dy() != 600 {
			t.Fatalf("not a screen-sized jpeg: %v", err)
		}
	case <-time.After(5 * time.Second):
		t.Fatal("the live view waited for the action")
	}
	if x, y, ok := Pointer(); !ok || x != 321 || y != 123 {
		t.Fatalf("pointer: %d,%d,%v", x, y, ok)
	}
	if !d.Live() {
		t.Fatal("Live must be true while running")
	}
	close(release)
	if err := <-done; err != nil {
		t.Fatal(err)
	}
	d.Close()
	if _, ok, _ := d.Frame(); ok || d.Live() {
		t.Fatal("after Close there is no picture")
	}
}
