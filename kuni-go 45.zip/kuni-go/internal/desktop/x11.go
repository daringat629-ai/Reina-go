// Package desktop gives her a screen of her own: an Xvfb virtual display where she can start any graphical program, look at the
// screen, move the mouse, click, type and press keys. It speaks the X11 protocol itself (screenshots with GetImage, input with
// the XTEST extension), so nothing but Xvfb and the programs she runs has to be installed.
package desktop

import (
	"bufio"
	"encoding/binary"
	"errors"
	"fmt"
	"image"
	"io"
	"net"
	"os"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

type xreply struct {
	hdr  [32]byte
	data []byte
	err  byte // X error code, 0 = ok
}

// X is one connection to an X server.
type X struct {
	c       net.Conn
	r       *bufio.Reader
	wmu     sync.Mutex
	mu      sync.Mutex
	seq     uint16
	waiting map[uint16]chan xreply
	dead    error

	Root          uint32
	Width, Height int
	rootDepth     byte
	bpp           int
	minKey        int
	maxKey        int
	xtest         byte              // major opcode of XTEST
	keymap        map[uint32][2]int // keysym -> keycode, column (0 plain, 1 shifted)
	kpk           int
	spareKeys     []int
}

// Dial connects to the display (":3" or a socket path of the form "unix:/tmp/.X11-unix/X3").
func Dial(display string) (*X, error) {
	path := display
	if strings.HasPrefix(display, ":") {
		n := strings.TrimPrefix(display, ":")
		if i := strings.Index(n, "."); i >= 0 {
			n = n[:i]
		}
		path = "/tmp/.X11-unix/X" + n
	}
	c, err := net.DialTimeout("unix", path, 5*time.Second)
	if err != nil {
		return nil, fmt.Errorf("x11: %w", err)
	}
	x := &X{c: c, r: bufio.NewReaderSize(c, 1<<20), waiting: map[uint16]chan xreply{}}
	if err := x.handshake(); err != nil {
		c.Close()
		return nil, err
	}
	go x.loop()
	if err := x.initInput(); err != nil {
		c.Close()
		return nil, err
	}
	return x, nil
}

func (x *X) Close() { x.c.Close() }

func (x *X) handshake() error {
	req := make([]byte, 12)
	req[0] = 'l'
	binary.LittleEndian.PutUint16(req[2:], 11)
	if _, err := x.c.Write(req); err != nil {
		return err
	}
	var h [8]byte
	if _, err := io.ReadFull(x.r, h[:]); err != nil {
		return err
	}
	body := make([]byte, int(binary.LittleEndian.Uint16(h[6:]))*4)
	if _, err := io.ReadFull(x.r, body); err != nil {
		return err
	}
	if h[0] != 1 {
		return fmt.Errorf("x11: the display refused the connection: %s", strings.TrimSpace(string(body[:min(len(body), int(h[1]))])))
	}
	le := binary.LittleEndian
	vendorLen := int(le.Uint16(body[16:]))
	nScreens, nFormats := int(body[20]), int(body[21])
	x.minKey, x.maxKey = int(body[26]), int(body[27])
	if body[22] != 0 {
		return errors.New("x11: a big-endian display is not supported")
	}
	off := 32 + (vendorLen+3)&^3
	formats := map[byte]int{}
	for i := 0; i < nFormats; i++ {
		formats[body[off]] = int(body[off+1])
		off += 8
	}
	if nScreens < 1 {
		return errors.New("x11: no screens")
	}
	x.Root = le.Uint32(body[off:])
	x.Width, x.Height = int(le.Uint16(body[off+20:])), int(le.Uint16(body[off+22:]))
	x.rootDepth = body[off+38]
	x.bpp = formats[x.rootDepth]
	if x.bpp != 32 && x.bpp != 24 {
		return fmt.Errorf("x11: the screen has %d bits per pixel, I support 24 and 32", x.bpp)
	}
	return nil
}

func (x *X) loop() {
	for {
		var h [32]byte
		if _, err := io.ReadFull(x.r, h[:]); err != nil {
			x.fail(err)
			return
		}
		switch h[0] {
		case 0, 1:
			rep := xreply{hdr: h}
			if h[0] == 0 {
				rep.err = h[1]
			} else if n := int(binary.LittleEndian.Uint32(h[4:])) * 4; n > 0 {
				if n > 256<<20 {
					x.fail(errors.New("x11: absurd reply size"))
					return
				}
				rep.data = make([]byte, n)
				if _, err := io.ReadFull(x.r, rep.data); err != nil {
					x.fail(err)
					return
				}
			}
			seq := binary.LittleEndian.Uint16(h[2:])
			x.mu.Lock()
			ch := x.waiting[seq]
			delete(x.waiting, seq)
			x.mu.Unlock()
			if ch != nil {
				ch <- rep
			}
		default: // events (key mapping changes...) are not needed
		}
	}
}

func (x *X) fail(err error) {
	x.mu.Lock()
	x.dead = err
	for s, ch := range x.waiting {
		close(ch)
		delete(x.waiting, s)
	}
	x.mu.Unlock()
}

// send writes a request; if reply is true it waits for the answer.
func (x *X) send(req []byte, reply bool) (xreply, error) {
	if len(req)%4 != 0 {
		return xreply{}, errors.New("x11: request not aligned")
	}
	binary.LittleEndian.PutUint16(req[2:], uint16(len(req)/4))
	x.wmu.Lock()
	x.mu.Lock()
	if x.dead != nil {
		err := x.dead
		x.mu.Unlock()
		x.wmu.Unlock()
		return xreply{}, fmt.Errorf("x11: connection lost: %w", err)
	}
	x.seq++
	seq := x.seq
	var ch chan xreply
	if reply {
		ch = make(chan xreply, 1)
		x.waiting[seq] = ch
	}
	x.mu.Unlock()
	_ = x.c.SetWriteDeadline(time.Now().Add(20 * time.Second))
	_, err := x.c.Write(req)
	x.wmu.Unlock()
	if err != nil {
		return xreply{}, err
	}
	if !reply {
		return xreply{}, nil
	}
	select {
	case rep, ok := <-ch:
		if !ok {
			return xreply{}, errors.New("x11: connection lost")
		}
		if rep.err != 0 {
			return rep, fmt.Errorf("x11: the server answered with error %d", rep.err)
		}
		return rep, nil
	case <-time.After(20 * time.Second):
		return xreply{}, errors.New("x11: the display did not answer in 20 s")
	}
}

func (x *X) initInput() error {
	name := "XTEST"
	req := make([]byte, 8+(len(name)+3)&^3)
	req[0] = 98
	binary.LittleEndian.PutUint16(req[4:], uint16(len(name)))
	copy(req[8:], name)
	rep, err := x.send(req, true)
	if err != nil {
		return err
	}
	if rep.hdr[8] == 0 {
		return errors.New("x11: this display has no XTEST extension, input is impossible")
	}
	x.xtest = rep.hdr[9]
	// keyboard mapping
	n := x.maxKey - x.minKey + 1
	km := make([]byte, 8)
	km[0] = 101
	km[4], km[5] = byte(x.minKey), byte(n)
	rep, err = x.send(km, true)
	if err != nil {
		return err
	}
	x.kpk = int(rep.hdr[1])
	if x.kpk < 2 {
		return errors.New("x11: unexpected keyboard mapping")
	}
	x.keymap = map[uint32][2]int{}
	x.spareKeys = nil
	for i := 0; i < n; i++ {
		empty := true
		for col := 0; col < x.kpk; col++ {
			ks := binary.LittleEndian.Uint32(rep.data[(i*x.kpk+col)*4:])
			if ks != 0 {
				empty = false
			}
			if col < 2 && ks != 0 {
				if _, ok := x.keymap[ks]; !ok || col == 0 {
					x.keymap[ks] = [2]int{x.minKey + i, col}
				}
			}
		}
		if empty {
			x.spareKeys = append(x.spareKeys, x.minKey+i) // keys nobody uses: borrowed for characters the layout lacks
		}
	}
	return nil
}

// fakeInput injects one event: type 2/3 key press/release, 4/5 button press/release, 6 motion (absolute).
func (x *X) fakeInput(typ byte, detail byte, px, py int) error {
	if typ == 6 { // motion: remember where the pointer is, for the live view
		pointer.Store(uint64(uint32(int32(px)))<<32 | uint64(uint32(int32(py))))
	}
	req := make([]byte, 36)
	req[0], req[1] = x.xtest, 2
	req[4], req[5] = typ, detail
	binary.LittleEndian.PutUint32(req[12:], x.Root)
	binary.LittleEndian.PutUint16(req[24:], uint16(int16(px)))
	binary.LittleEndian.PutUint16(req[26:], uint16(int16(py)))
	_, err := x.send(req, false)
	return err
}

// Sync waits until the server has processed everything sent so far.
func (x *X) Sync() error {
	req := make([]byte, 4)
	req[0] = 43 // GetInputFocus: has a reply and no side effects
	_, err := x.send(req, true)
	return err
}

// Screenshot returns the whole screen.
func (x *X) Screenshot() (*image.RGBA, error) {
	req := make([]byte, 20)
	req[0], req[1] = 73, 2
	binary.LittleEndian.PutUint32(req[4:], x.Root)
	binary.LittleEndian.PutUint16(req[12:], uint16(x.Width))
	binary.LittleEndian.PutUint16(req[14:], uint16(x.Height))
	binary.LittleEndian.PutUint32(req[16:], 0xffffffff)
	rep, err := x.send(req, true)
	if err != nil {
		return nil, err
	}
	stride := x.bpp / 8
	if len(rep.data) < x.Width*x.Height*stride {
		return nil, fmt.Errorf("x11: the screenshot is %d bytes, expected %d", len(rep.data), x.Width*x.Height*stride)
	}
	img := image.NewRGBA(image.Rect(0, 0, x.Width, x.Height))
	for i := 0; i < x.Width*x.Height; i++ {
		b, g, r := rep.data[i*stride], rep.data[i*stride+1], rep.data[i*stride+2]
		img.Pix[i*4], img.Pix[i*4+1], img.Pix[i*4+2], img.Pix[i*4+3] = r, g, b, 255
	}
	return img, nil
}

// WaitForSocket waits for the display's socket to appear (used right after Xvfb starts).
func WaitForSocket(display string, d time.Duration) error {
	path := "/tmp/.X11-unix/X" + strings.TrimPrefix(display, ":")
	end := time.Now().Add(d)
	for time.Now().Before(end) {
		if _, err := os.Stat(path); err == nil {
			return nil
		}
		time.Sleep(50 * time.Millisecond)
	}
	return errors.New("the display did not come up")
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}

// pointer is where the last mouse move went (x<<32|y); the screenshot does not draw the cursor, the live view does.
var pointer atomic.Uint64

// Pointer returns the last pointer position and whether it was ever set.
func Pointer() (x, y int, ok bool) {
	v := pointer.Load()
	return int(int32(uint32(v >> 32))), int(int32(uint32(v))), v != 0
}
