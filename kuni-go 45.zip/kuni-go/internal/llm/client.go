// Package llm is an OpenAI-compatible HTTP client: chat with tool calling and
// vision parts, SSE streaming and embeddings. Port of OpenAIChatImpl.
package llm

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"strings"
	"sync"
	"time"
)

// Part is one piece of multimodal content ("text" or "image_url").
type Part struct {
	Type     string // "text" | "image_url"
	Text     string
	ImageURL string // data: URL or http(s) URL
}

type FunctionCall struct {
	Name      string `json:"name"`
	Arguments string `json:"arguments"`
}

type ToolCall struct {
	ID       string       `json:"id"`
	Type     string       `json:"type"`
	Function FunctionCall `json:"function"`
}

type Message struct {
	Role       string     `json:"role"`
	Content    string     `json:"content"`
	Parts      []Part     `json:"-"` // if set, sent instead of Content
	ToolCalls  []ToolCall `json:"tool_calls,omitempty"`
	ToolCallID string     `json:"tool_call_id,omitempty"`
}

// MarshalJSON emits multimodal content arrays when Parts is set.
func (m Message) MarshalJSON() ([]byte, error) {
	out := map[string]any{"role": m.Role}
	if len(m.Parts) > 0 {
		var arr []map[string]any
		for _, p := range m.Parts {
			if p.Type == "image_url" {
				arr = append(arr, map[string]any{"type": "image_url", "image_url": map[string]string{"url": p.ImageURL}})
			} else {
				arr = append(arr, map[string]any{"type": "text", "text": p.Text})
			}
		}
		out["content"] = arr
	} else {
		out["content"] = m.Content
	}
	if len(m.ToolCalls) > 0 {
		out["tool_calls"] = m.ToolCalls
	}
	if m.ToolCallID != "" {
		out["tool_call_id"] = m.ToolCallID
	}
	return json.Marshal(out)
}

// ToolDef is an OpenAI function tool definition.
type ToolDef struct {
	Type     string   `json:"type"`
	Function ToolFunc `json:"function"`
}

type ToolFunc struct {
	Name        string         `json:"name"`
	Description string         `json:"description"`
	Parameters  map[string]any `json:"parameters"`
}

// Settings are the hot-reloadable connection parameters.
type Settings struct {
	BaseURL          string
	EmbeddingBaseURL string
	APIKey           string
	Model            string
	// LightModel, if set, serves background purposes (see lightPurposes) instead of Model.
	LightModel string
	// FastModel, if set, runs delegated jobs (purpose "delegate"); the agent also picks it per request for fast rounds.
	FastModel string
	// VisionModel, if set, serves requests that look at pictures (purpose "image": photos, stickers, screenshots).
	VisionModel    string
	EmbeddingModel string
	Temperature    *float64
	// Reasoning is OpenRouter-style reasoning control: "" = server default, "off" disables reasoning,
	// "low"/"medium"/"high" set the effort. Reasoning models are 3-10x slower with it on.
	Reasoning string
	// CachePrompt marks the system prompt as cacheable (Anthropic-style cache_control) for models that need it;
	// DeepSeek, OpenAI and others cache a stable prompt prefix on their own.
	CachePrompt bool
}

type Client struct {
	noOff sync.Map // models whose endpoint rejects reasoning:off
	mu    sync.RWMutex
	s     Settings
	HTTP  *http.Client
	// Observe, if set, is called after every request (metrics hook).
	Observe func(kind string, d time.Duration, err error)
	// OnUsage, if set, receives token usage reported by the server (metrics hook).
	OnUsage func(model, purpose string, promptTokens, completionTokens int)
	// OnCached, if set, receives how many prompt tokens the provider served from its cache.
	OnCached func(model, purpose string, cachedTokens int)
	// OnUsageCtx is OnUsage with the request context (it carries the chat, see WithChat).
	OnUsageCtx func(ctx context.Context, model, purpose string, promptTokens, completionTokens int)
	// Guard, if set, is asked before every chat request; a non-nil error refuses it (daily token budget).
	Guard func() error
}

func New(baseURL, embeddingBaseURL, apiKey, model, embeddingModel string, timeout time.Duration) *Client {
	return &Client{
		s:    Settings{BaseURL: baseURL, EmbeddingBaseURL: embeddingBaseURL, APIKey: apiKey, Model: model, EmbeddingModel: embeddingModel},
		HTTP: &http.Client{Timeout: timeout},
	}
}

// Update swaps settings atomically (config hot reload).
func (c *Client) Update(s Settings) {
	c.mu.Lock()
	c.s = s
	c.mu.Unlock()
}

func (c *Client) settings() Settings {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return c.s
}

// lightPurposes are the background tasks that can run on the cheaper LightModel.
// "reply" (what the character says) always uses Model; "image" (needs vision) uses VisionModel when it is set.
var lightPurposes = map[string]bool{"ask": true, "sleep": true, "diary": true, "compact": true, "people": true}

// modelFor picks the model for a request by its purpose.
func (s Settings) modelFor(purpose string) string {
	if s.VisionModel != "" && purpose == "image" {
		return s.VisionModel
	}
	if s.FastModel != "" && purpose == "delegate" {
		return s.FastModel
	}
	if s.LightModel != "" && lightPurposes[purpose] {
		return s.LightModel
	}
	return s.Model
}

// needsCacheControl: Anthropic models only cache what is explicitly marked.
func needsCacheControl(model string) bool {
	m := strings.ToLower(model)
	return strings.Contains(m, "claude") || strings.HasPrefix(m, "anthropic/")
}

// Model returns the configured chat model.
func (c *Client) Model() string { return c.settings().Model }

type chatResponse struct {
	Choices []struct {
		Message Message `json:"message"`
	} `json:"choices"`
	Usage *struct {
		PromptTokens        int `json:"prompt_tokens"`
		CompletionTokens    int `json:"completion_tokens"`
		PromptTokensDetails *struct {
			CachedTokens int `json:"cached_tokens"`
		} `json:"prompt_tokens_details,omitempty"`
	} `json:"usage,omitempty"`
	Error json.RawMessage `json:"error,omitempty"`
}

// Complete is the full-featured chat call: system prompt, history and optional tools.
func (c *Client) Complete(ctx context.Context, system string, msgs []Message, tools []ToolDef) (Message, error) {
	s := c.settings()
	if c.Guard != nil {
		if err := c.Guard(); err != nil {
			return Message{}, err
		}
	}
	model := s.modelFor(PurposeFrom(ctx))
	if m, ok := ctx.Value(modelKey{}).(string); ok && m != "" {
		model = m
	}
	var all any = msgs
	switch {
	case system != "" && s.CachePrompt && needsCacheControl(model):
		sys := map[string]any{"role": "system", "content": []map[string]any{{"type": "text", "text": system, "cache_control": map[string]string{"type": "ephemeral"}}}}
		list := make([]any, 0, len(msgs)+1)
		list = append(list, sys)
		for _, m := range msgs {
			list = append(list, m)
		}
		all = list
	case system != "":
		all = append([]Message{{Role: "system", Content: system}}, msgs...)
	}
	body := map[string]any{"model": model, "messages": all, "stream": false}
	if len(tools) > 0 {
		body["tools"] = tools
		if tc, ok := ctx.Value(toolChoiceKey{}).(string); ok && tc != "" {
			body["tool_choice"] = tc
		}
	}
	if s.Temperature != nil {
		body["temperature"] = *s.Temperature
	}
	reasoning := s.Reasoning
	if v, ok := ctx.Value(reasoningKey{}).(string); ok && v != "" {
		reasoning = v // this request only (fast rounds)
	}
	if c.noOffHas(model) && (reasoning == "off" || reasoning == "none" || reasoning == "false") {
		// this model's endpoint refuses to switch reasoning off. A per-round request (fast rounds) thinks as little as
		// allowed; the global llm.reasoning = "off" falls back to the model's own default instead of crippling every answer
		if _, perRequest := ctx.Value(reasoningKey{}).(string); perRequest {
			reasoning = "low"
		} else {
			reasoning = ""
		}
	}
	switch reasoning {
	case "":
	case "off", "none", "false":
		body["reasoning"] = map[string]any{"enabled": false, "exclude": true}
	default:
		body["reasoning"] = map[string]any{"effort": reasoning, "exclude": true}
	}
	var out chatResponse
	start := time.Now()
	err := c.postJSON(ctx, s, s.BaseURL+"chat/completions", body, &out)
	if err != nil && body["reasoning"] != nil && strings.Contains(err.Error(), "easoning is mandatory") {
		// the endpoint cannot run without reasoning: remember it and retry with the lowest effort
		c.noOff.Store(model, true)
		if _, perRequest := ctx.Value(reasoningKey{}).(string); perRequest {
			body["reasoning"] = map[string]any{"effort": "low", "exclude": true}
		} else {
			delete(body, "reasoning")
		}
		out = chatResponse{}
		err = c.postJSON(ctx, s, s.BaseURL+"chat/completions", body, &out)
	}
	c.observe("chat", start, err)
	if err != nil {
		return Message{}, err
	}
	if len(out.Error) > 0 && string(out.Error) != "null" {
		return Message{}, fmt.Errorf("llm: upstream error: %s", out.Error)
	}
	if out.Usage != nil && c.OnUsage != nil {
		c.OnUsage(model, PurposeFrom(ctx), out.Usage.PromptTokens, out.Usage.CompletionTokens)
	}
	if out.Usage != nil && c.OnUsageCtx != nil {
		c.OnUsageCtx(ctx, model, PurposeFrom(ctx), out.Usage.PromptTokens, out.Usage.CompletionTokens)
	}
	if out.Usage != nil && c.OnCached != nil && out.Usage.PromptTokensDetails != nil && out.Usage.PromptTokensDetails.CachedTokens > 0 {
		c.OnCached(model, PurposeFrom(ctx), out.Usage.PromptTokensDetails.CachedTokens)
	}
	if len(out.Choices) == 0 {
		return Message{}, fmt.Errorf("llm: no choices")
	}
	return out.Choices[0].Message, nil
}

// Chat is Complete without tools, returning only the text.
func (c *Client) Chat(ctx context.Context, systemPrompt string, msgs []Message) (string, error) {
	m, err := c.Complete(ctx, systemPrompt, msgs, nil)
	return m.Content, err
}

// ChatStream forwards SSE deltas of a streamed completion to onDelta.
func (c *Client) ChatStream(ctx context.Context, systemPrompt string, msgs []Message, onDelta func(string)) error {
	if c.Guard != nil {
		if err := c.Guard(); err != nil {
			return err
		}
	}
	s := c.settings()
	body := map[string]any{
		"model":    s.Model,
		"messages": append([]Message{{Role: "system", Content: systemPrompt}}, msgs...),
		"stream":   true,
	}
	resp, err := c.do(ctx, s, s.BaseURL+"chat/completions", body)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	sc := bufio.NewScanner(resp.Body)
	sc.Buffer(make([]byte, 1<<20), 1<<24)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if !strings.HasPrefix(line, "data:") {
			continue
		}
		payload := strings.TrimSpace(strings.TrimPrefix(line, "data:"))
		if payload == "[DONE]" {
			break
		}
		var chunk struct {
			Choices []struct {
				Delta struct {
					Content string `json:"content"`
				} `json:"delta"`
			} `json:"choices"`
		}
		if err := json.Unmarshal([]byte(payload), &chunk); err != nil {
			return fmt.Errorf("llm: bad stream chunk: %w", err)
		}
		for _, ch := range chunk.Choices {
			if ch.Delta.Content != "" {
				onDelta(ch.Delta.Content)
			}
		}
	}
	return sc.Err()
}

type embeddingResponse struct {
	Data []struct {
		Embedding []float64 `json:"embedding"`
	} `json:"data"`
}

// Embedding returns the embedding vector of text.
func (c *Client) Embedding(ctx context.Context, text string) ([]float64, error) {
	s := c.settings()
	body := map[string]any{"model": s.EmbeddingModel, "input": text}
	var out embeddingResponse
	start := time.Now()
	err := c.postJSON(ctx, s, s.EmbeddingBaseURL+"embeddings", body, &out)
	c.observe("embedding", start, err)
	if err != nil {
		return nil, err
	}
	if len(out.Data) == 0 {
		return nil, fmt.Errorf("llm: no embedding returned")
	}
	return out.Data[0].Embedding, nil
}

func (c *Client) observe(kind string, start time.Time, err error) {
	if c.Observe != nil {
		c.Observe(kind, time.Since(start), err)
	}
}

func (c *Client) postJSON(ctx context.Context, s Settings, url string, body any, out any) error {
	resp, err := c.do(ctx, s, url, body)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	raw, err := io.ReadAll(resp.Body)
	if err != nil {
		return err
	}
	if err := json.Unmarshal(raw, out); err != nil {
		return fmt.Errorf("llm: decode response: %w (body: %.200s)", err, raw)
	}
	return nil
}

func (c *Client) do(ctx context.Context, s Settings, url string, body any) (*http.Response, error) {
	buf, err := json.Marshal(body)
	if err != nil {
		return nil, err
	}
	var lastErr error
	for attempt := 0; attempt < 3; attempt++ {
		if attempt > 0 { // transient failure: back off 1s, 3s
			select {
			case <-time.After(time.Duration(attempt*2-1) * time.Second):
			case <-ctx.Done():
				return nil, ctx.Err()
			}
		}
		req, err := http.NewRequestWithContext(ctx, http.MethodPost, url, bytes.NewReader(buf))
		if err != nil {
			return nil, err
		}
		req.Header.Set("Content-Type", "application/json")
		if s.APIKey != "" {
			req.Header.Set("Authorization", "Bearer "+s.APIKey)
		}
		resp, err := c.HTTP.Do(req)
		if err != nil {
			if ctx.Err() != nil {
				return nil, err
			}
			var ne net.Error
			if errors.As(err, &ne) && ne.Timeout() {
				return nil, err // a hung request is not retried: three full timeouts in a row freeze her for minutes
			}
			lastErr = err
			continue
		}
		if resp.StatusCode/100 != 2 {
			b, _ := io.ReadAll(io.LimitReader(resp.Body, 4096))
			resp.Body.Close()
			lastErr = fmt.Errorf("llm: HTTP %d: %s", resp.StatusCode, b)
			if resp.StatusCode == 429 || resp.StatusCode >= 500 {
				continue
			}
			return nil, lastErr
		}
		return resp, nil
	}
	return nil, lastErr
}

type purposeKey struct{}

// WithPurpose labels LLM requests made with the returned context (reply, ask, diary, sleep, compact, ...),
// so token usage can be split by what it was spent on.
func WithPurpose(ctx context.Context, p string) context.Context {
	return context.WithValue(ctx, purposeKey{}, p)
}

// PurposeFrom returns the label set by WithPurpose ("other" by default).
func PurposeFrom(ctx context.Context) string {
	if p, ok := ctx.Value(purposeKey{}).(string); ok && p != "" {
		return p
	}
	return "other"
}

type modelKey struct{}

// WithModel makes the requests made with the returned context use this model instead of the configured one
// (the panel's model comparison).
func WithModel(ctx context.Context, model string) context.Context {
	return context.WithValue(ctx, modelKey{}, model)
}

type chatKey struct{}

// WithChat marks the requests made with the returned context as spent on a chat (0 = her own thoughts).
func WithChat(ctx context.Context, id int64) context.Context {
	return context.WithValue(ctx, chatKey{}, id)
}

// ChatFrom returns the chat set by WithChat.
func ChatFrom(ctx context.Context) (int64, bool) {
	id, ok := ctx.Value(chatKey{}).(int64)
	return id, ok
}

type toolChoiceKey struct{}

// WithToolChoice sets the OpenAI "tool_choice" ("required" forces the model to call a tool) for requests made with the context.
func WithToolChoice(ctx context.Context, choice string) context.Context {
	return context.WithValue(ctx, toolChoiceKey{}, choice)
}

type reasoningKey struct{}

// WithReasoning overrides llm.reasoning for the requests made with ctx ("off", "low"...).
func WithReasoning(ctx context.Context, mode string) context.Context {
	return context.WithValue(ctx, reasoningKey{}, mode)
}

func (c *Client) noOffHas(model string) bool { _, ok := c.noOff.Load(model); return ok }
