package sched

import (
	"context"
	"net"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"testing"
	"time"
)

var bishkek = time.FixedZone("KG", 6*3600)

func at(s string) time.Time {
	t, err := time.ParseInLocation("2006-01-02 15:04", s, bishkek)
	if err != nil {
		panic(err)
	}
	return t
}

func TestNextDailyRespectsZoneAndWeekdays(t *testing.T) {
	// Wed 2026-10-21 10:00 Bishkek: 09:00 already passed -> tomorrow
	n, err := NextDaily(at("2026-10-21 10:00"), "09:00", nil, bishkek)
	if err != nil || !n.Equal(at("2026-10-22 09:00")) {
		t.Fatal(n, err)
	}
	n, _ = NextDaily(at("2026-10-21 08:00"), "9:00", nil, bishkek)
	if !n.Equal(at("2026-10-21 09:00")) {
		t.Fatal(n)
	}
	days, err := ParseDays("пн-пт")
	if err != nil || len(days) != 5 {
		t.Fatal(days, err)
	}
	// Friday evening, weekdays only -> Monday
	n, _ = NextDaily(at("2026-10-23 20:00"), "09:00", days, bishkek)
	if n.Weekday() != time.Monday || !n.Equal(at("2026-10-26 09:00")) {
		t.Fatal(n, n.Weekday())
	}
	if _, err := NextDaily(time.Now(), "25:00", nil, bishkek); err == nil {
		t.Fatal("bad time accepted")
	}
	if _, err := ParseDays("xyz"); err == nil {
		t.Fatal("bad days accepted")
	}
	if d, _ := ParseDays("sat,sun"); len(d) != 2 || d[0] != 0 || d[1] != 6 {
		t.Fatal(d)
	}
}

func TestTasksFireOnceAndSurviveRestart(t *testing.T) {
	p := filepath.Join(t.TempDir(), "s.json")
	s := New(p, bishkek)
	now := at("2026-10-21 10:00")
	if _, err := s.AddEvery(5, "проверь курс", 30*time.Second, now); err == nil {
		t.Fatal("30s interval accepted")
	}
	a, err := s.AddEvery(5, "проверь курс", time.Hour, now)
	if err != nil {
		t.Fatal(err)
	}
	b, _ := s.AddDaily(5, "доброе утро", "09:00", nil, now)
	if len(s.DueTasks(now.Add(59*time.Minute))) != 0 {
		t.Fatal("fired early")
	}
	// the program was off for three days: each task runs once, not once per missed turn
	due := s.DueTasks(now.Add(72 * time.Hour))
	if len(due) != 2 {
		t.Fatal(due)
	}
	if len(s.DueTasks(now.Add(72*time.Hour+time.Minute))) != 0 {
		t.Fatal("fired twice")
	}
	s2 := New(p, bishkek)
	if len(s2.Tasks()) != 2 {
		t.Fatal("not persisted")
	}
	c, _ := s2.AddEvery(5, "ещё", time.Hour, now)
	if c.ID <= b.ID || b.ID <= a.ID {
		t.Fatal("ids reused", a.ID, b.ID, c.ID)
	}
	s2.SetPaused(a.ID, true, now)
	for _, d := range s2.DueTasks(now.Add(200 * time.Hour)) {
		if d.ID == a.ID {
			t.Fatal("paused task fired")
		}
	}
	if !s2.DeleteTask(a.ID) || s2.DeleteTask(a.ID) {
		t.Fatal("delete")
	}
}

func TestMonitorAlertsOnceThenRecovers(t *testing.T) {
	s := New("", bishkek)
	now := at("2026-10-21 10:00")
	m, err := s.AddMonitor(Monitor{Chat: 5, Kind: "disk_free_pct", Limit: 10, EveryMin: 1, CooldownMin: 30}, now)
	if err != nil {
		t.Fatal(err)
	}
	bad := true
	check := func(ctx context.Context, m Monitor) (bool, string) { return bad, "detail" }
	ctx := context.Background()
	if al := s.CheckDue(ctx, now, check); len(al) != 1 || al[0].Recovered {
		t.Fatal(al)
	}
	if al := s.CheckDue(ctx, now.Add(time.Minute), check); len(al) != 0 {
		t.Fatal("repeated inside cooldown", al)
	}
	if al := s.CheckDue(ctx, now.Add(31*time.Minute), check); len(al) != 1 {
		t.Fatal("no reminder after cooldown", al)
	}
	bad = false
	al := s.CheckDue(ctx, now.Add(33*time.Minute), check)
	if len(al) != 1 || !al[0].Recovered || al[0].Monitor.ID != m.ID {
		t.Fatal(al)
	}
	if al := s.CheckDue(ctx, now.Add(40*time.Minute), check); len(al) != 0 {
		t.Fatal("recovery repeated", al)
	}
	// not due yet: the checker must not even be called
	called := false
	s.CheckDue(ctx, now.Add(40*time.Minute+10*time.Second), func(context.Context, Monitor) (bool, string) { called = true; return false, "" })
	if called {
		t.Fatal("checked too often")
	}
}

func TestMonitorValidation(t *testing.T) {
	s := New("", bishkek)
	for _, m := range []Monitor{{Kind: "nope"}, {Kind: "url"}, {Kind: "disk_free_pct", Limit: 150}, {Kind: "mem_avail_mb"}} {
		if _, err := s.AddMonitor(m, time.Now()); err == nil {
			t.Fatalf("accepted %+v", m)
		}
	}
	got, err := s.AddMonitor(Monitor{Kind: "disk_free_pct", Limit: 5}, time.Now())
	if err != nil || got.Arg != "/" || got.EveryMin != 5 || got.CooldownMin != 60 {
		t.Fatal(got, err)
	}
}

func TestDefaultChecks(t *testing.T) {
	ctx := context.Background()
	up := true
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if !up {
			http.Error(w, "boom", 503)
		}
	}))
	defer srv.Close()
	if bad, _ := DefaultCheck(ctx, Monitor{Kind: "url", Arg: srv.URL}); bad {
		t.Fatal("healthy site reported bad")
	}
	up = false
	if bad, _ := DefaultCheck(ctx, Monitor{Kind: "url", Arg: srv.URL}); !bad {
		t.Fatal("503 not noticed")
	}
	ln, _ := net.Listen("tcp", "127.0.0.1:0")
	if bad, _ := DefaultCheck(ctx, Monitor{Kind: "port", Arg: ln.Addr().String()}); bad {
		t.Fatal("open port reported bad")
	}
	addr := ln.Addr().String()
	ln.Close()
	if bad, _ := DefaultCheck(ctx, Monitor{Kind: "port", Arg: addr}); !bad {
		t.Fatal("closed port not noticed")
	}
	if bad, d := DefaultCheck(ctx, Monitor{Kind: "disk_free_pct", Arg: "/", Limit: 99.99}); total0(d) == false && bad == false {
		t.Log("disk check:", d)
	}
	if bad, _ := DefaultCheck(ctx, Monitor{Kind: "process", Arg: "zzz-no-such-process-zzz"}); !bad {
		if _, err := net.LookupHost("localhost"); err == nil {
			t.Log("process check is unavailable here")
		}
	}
}

func total0(d string) bool { return d == "диск не измерить" }
