// Package sched keeps her recurring tasks ("every morning send the weather") and monitors ("tell me when the disk is
// almost full or the site is down") in one small JSON file, so they survive restarts.
package sched

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

// Task is something she does again and again.
type Task struct {
	ID      int           `json:"id"`
	Chat    int64         `json:"chat"`
	Text    string        `json:"text"`
	Every   time.Duration `json:"every,omitempty"` // interval; 0 = daily at At
	At      string        `json:"at,omitempty"`    // "HH:MM" in the store's zone
	Days    []int         `json:"days,omitempty"`  // weekdays 0=Sunday..6; empty = every day
	Next    time.Time     `json:"next"`
	Last    time.Time     `json:"last,omitempty"`
	Runs    int           `json:"runs"`
	Paused  bool          `json:"paused,omitempty"`
	Created time.Time     `json:"created"`
}

// Monitor watches one thing and speaks up when it goes bad (and again when it recovers).
type Monitor struct {
	ID          int       `json:"id"`
	Chat        int64     `json:"chat"`
	Kind        string    `json:"kind"` // disk_free_pct, mem_avail_mb, load, url, port, process
	Arg         string    `json:"arg,omitempty"`
	Limit       float64   `json:"limit,omitempty"`
	EveryMin    int       `json:"every_min"`
	CooldownMin int       `json:"cooldown_min"`
	Down        bool      `json:"down,omitempty"`
	LastAlert   time.Time `json:"last_alert,omitempty"`
	LastCheck   time.Time `json:"last_check,omitempty"`
	Created     time.Time `json:"created"`
}

// Limits keep a mistaken request from flooding the machine.
const (
	MaxTasks     = 30
	MaxMonitors  = 20
	MinEvery     = time.Minute
	minMonitorEv = 1
)

type file struct {
	Tasks    []Task    `json:"tasks"`
	Monitors []Monitor `json:"monitors"`
	Next     int       `json:"next"`
}

type Store struct {
	mu   sync.Mutex
	path string
	loc  *time.Location
	f    file
}

// New loads path (missing or broken = empty). loc is the zone of "daily at HH:MM" (nil = local).
func New(path string, loc *time.Location) *Store {
	if loc == nil {
		loc = time.Local
	}
	s := &Store{path: path, loc: loc}
	if raw, err := os.ReadFile(path); err == nil {
		_ = json.Unmarshal(raw, &s.f)
	}
	if s.f.Next < 1 {
		s.f.Next = 1
	}
	for _, t := range s.f.Tasks {
		if t.ID >= s.f.Next {
			s.f.Next = t.ID + 1
		}
	}
	for _, m := range s.f.Monitors {
		if m.ID >= s.f.Next {
			s.f.Next = m.ID + 1
		}
	}
	return s
}

func (s *Store) save() {
	if s.path == "" {
		return
	}
	_ = os.MkdirAll(filepath.Dir(s.path), 0o755)
	raw, _ := json.MarshalIndent(s.f, "", " ")
	tmp := s.path + ".tmp"
	if os.WriteFile(tmp, raw, 0o644) == nil {
		_ = os.Rename(tmp, s.path)
	}
}

var reHM = regexp.MustCompile(`^([01]?\d|2[0-3]):([0-5]\d)$`)

var dayNames = map[string]int{"sun": 0, "mon": 1, "tue": 2, "wed": 3, "thu": 4, "fri": 5, "sat": 6,
	"вс": 0, "пн": 1, "вт": 2, "ср": 3, "чт": 4, "пт": 5, "сб": 6}

// ParseDays turns "mon,wed,fri", "пн-пт", "1-5" or "" into weekday numbers.
func ParseDays(s string) ([]int, error) {
	s = strings.ToLower(strings.TrimSpace(s))
	if s == "" || s == "daily" || s == "every" || s == "ежедневно" {
		return nil, nil
	}
	if s == "weekdays" || s == "будни" {
		return []int{1, 2, 3, 4, 5}, nil
	}
	if s == "weekends" || s == "выходные" {
		return []int{0, 6}, nil
	}
	num := func(x string) (int, bool) {
		x = strings.TrimSpace(x)
		if v, ok := dayNames[x]; ok {
			return v, true
		}
		if n, err := strconv.Atoi(x); err == nil && n >= 0 && n <= 7 {
			return n % 7, true
		}
		return 0, false
	}
	seen := map[int]bool{}
	for _, part := range strings.Split(s, ",") {
		if a, b, ok := strings.Cut(part, "-"); ok {
			x, ok1 := num(a)
			y, ok2 := num(b)
			if !ok1 || !ok2 {
				return nil, fmt.Errorf("bad days %q", s)
			}
			for d := x; ; d = (d + 1) % 7 {
				seen[d] = true
				if d == y {
					break
				}
			}
			continue
		}
		v, ok := num(part)
		if !ok {
			return nil, fmt.Errorf("bad days %q", s)
		}
		seen[v] = true
	}
	var out []int
	for d := range seen {
		out = append(out, d)
	}
	sort.Ints(out)
	return out, nil
}

// NextDaily is the first moment after now that is HH:MM on an allowed weekday.
func NextDaily(now time.Time, hm string, days []int, loc *time.Location) (time.Time, error) {
	m := reHM.FindStringSubmatch(strings.TrimSpace(hm))
	if m == nil {
		return time.Time{}, fmt.Errorf("time must look like 09:00")
	}
	h, _ := strconv.Atoi(m[1])
	mi, _ := strconv.Atoi(m[2])
	n := now.In(loc)
	for i := 0; i < 9; i++ {
		c := time.Date(n.Year(), n.Month(), n.Day()+i, h, mi, 0, 0, loc)
		if !c.After(now) {
			continue
		}
		if len(days) > 0 {
			ok := false
			for _, d := range days {
				if int(c.Weekday()) == d {
					ok = true
				}
			}
			if !ok {
				continue
			}
		}
		return c, nil
	}
	return time.Time{}, fmt.Errorf("no such day")
}

// AddEvery adds a task that repeats at an interval (the first run is one interval from now).
func (s *Store) AddEvery(chat int64, text string, every time.Duration, now time.Time) (Task, error) {
	if every < MinEvery {
		return Task{}, fmt.Errorf("the interval must be at least a minute")
	}
	return s.add(Task{Chat: chat, Text: text, Every: every, Next: now.Add(every)}, now)
}

// AddDaily adds a task for HH:MM (on the given weekdays, empty = every day).
func (s *Store) AddDaily(chat int64, text, hm string, days []int, now time.Time) (Task, error) {
	next, err := NextDaily(now, hm, days, s.loc)
	if err != nil {
		return Task{}, err
	}
	return s.add(Task{Chat: chat, Text: text, At: hm, Days: days, Next: next}, now)
}

func (s *Store) add(t Task, now time.Time) (Task, error) {
	t.Text = strings.TrimSpace(t.Text)
	if t.Text == "" {
		return Task{}, fmt.Errorf("empty task")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if len(s.f.Tasks) >= MaxTasks {
		return Task{}, fmt.Errorf("too many tasks (%d): delete some first", MaxTasks)
	}
	t.ID, t.Created = s.f.Next, now
	s.f.Next++
	s.f.Tasks = append(s.f.Tasks, t)
	s.save()
	return t, nil
}

func (s *Store) Tasks() []Task {
	s.mu.Lock()
	defer s.mu.Unlock()
	return append([]Task(nil), s.f.Tasks...)
}

func (s *Store) DeleteTask(id int) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	for i, t := range s.f.Tasks {
		if t.ID == id {
			s.f.Tasks = append(s.f.Tasks[:i], s.f.Tasks[i+1:]...)
			s.save()
			return true
		}
	}
	return false
}

// SetPaused pauses or resumes a task; resuming starts the count from now.
func (s *Store) SetPaused(id int, paused bool, now time.Time) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	for i := range s.f.Tasks {
		t := &s.f.Tasks[i]
		if t.ID != id {
			continue
		}
		t.Paused = paused
		if !paused {
			if t.Every > 0 {
				t.Next = now.Add(t.Every)
			} else if n, err := NextDaily(now, t.At, t.Days, s.loc); err == nil {
				t.Next = n
			}
		}
		s.save()
		return true
	}
	return false
}

// DueTasks returns the tasks whose time has come and moves each to its next time. A task that was missed while the
// program was off runs once, not once per missed turn.
func (s *Store) DueTasks(now time.Time) []Task {
	s.mu.Lock()
	defer s.mu.Unlock()
	var out []Task
	for i := range s.f.Tasks {
		t := &s.f.Tasks[i]
		if t.Paused || t.Next.After(now) {
			continue
		}
		out = append(out, *t)
		t.Last, t.Runs = now, t.Runs+1
		if t.Every > 0 {
			t.Next = now.Add(t.Every)
		} else if n, err := NextDaily(now, t.At, t.Days, s.loc); err == nil {
			t.Next = n
		} else {
			t.Paused = true
		}
	}
	if len(out) > 0 {
		s.save()
	}
	return out
}

// Describe is a human line about a task.
func (t Task) Describe(loc *time.Location) string {
	when := ""
	if t.Every > 0 {
		when = "каждые " + t.Every.String()
	} else {
		when = "в " + t.At
		if len(t.Days) > 0 {
			var ds []string
			names := []string{"вс", "пн", "вт", "ср", "чт", "пт", "сб"}
			for _, d := range t.Days {
				ds = append(ds, names[d])
			}
			when += " (" + strings.Join(ds, ",") + ")"
		}
	}
	state := ""
	if t.Paused {
		state = " [на паузе]"
	}
	return fmt.Sprintf("#%d %s: %s%s; дальше %s, было раз: %d", t.ID, when, t.Text, state, t.Next.In(loc).Format("02.01 15:04"), t.Runs)
}

// Loc is the zone of the store.
func (s *Store) Loc() *time.Location { return s.loc }

// ---- monitors ----

var validKinds = map[string]string{
	"disk_free_pct": "alert when free space on the disk at arg (default /) falls below limit percent",
	"mem_avail_mb":  "alert when available memory falls below limit MB",
	"load":          "alert when the 1-minute load average rises above limit",
	"url":           "alert when arg (a web address) does not answer or answers 5xx",
	"port":          "alert when arg (host:port) does not accept connections",
	"process":       "alert when no process with a name containing arg runs",
}

// Kinds lists the monitor kinds with a one-line meaning.
func Kinds() map[string]string { return validKinds }

func (s *Store) AddMonitor(m Monitor, now time.Time) (Monitor, error) {
	m.Kind = strings.ToLower(strings.TrimSpace(m.Kind))
	if _, ok := validKinds[m.Kind]; !ok {
		return Monitor{}, fmt.Errorf("unknown kind %q", m.Kind)
	}
	m.Arg = strings.TrimSpace(m.Arg)
	switch m.Kind {
	case "url", "port", "process":
		if m.Arg == "" {
			return Monitor{}, fmt.Errorf("%s needs arg", m.Kind)
		}
	case "disk_free_pct":
		if m.Arg == "" {
			m.Arg = "/"
		}
		if m.Limit <= 0 || m.Limit >= 100 {
			return Monitor{}, fmt.Errorf("limit is a percent between 0 and 100")
		}
	case "mem_avail_mb", "load":
		if m.Limit <= 0 {
			return Monitor{}, fmt.Errorf("limit must be positive")
		}
	}
	if m.EveryMin < minMonitorEv {
		m.EveryMin = 5
	}
	if m.CooldownMin <= 0 {
		m.CooldownMin = 60
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if len(s.f.Monitors) >= MaxMonitors {
		return Monitor{}, fmt.Errorf("too many monitors (%d)", MaxMonitors)
	}
	m.ID, m.Created = s.f.Next, now
	s.f.Next++
	s.f.Monitors = append(s.f.Monitors, m)
	s.save()
	return m, nil
}

func (s *Store) Monitors() []Monitor {
	s.mu.Lock()
	defer s.mu.Unlock()
	return append([]Monitor(nil), s.f.Monitors...)
}

func (s *Store) DeleteMonitor(id int) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	for i, m := range s.f.Monitors {
		if m.ID == id {
			s.f.Monitors = append(s.f.Monitors[:i], s.f.Monitors[i+1:]...)
			s.save()
			return true
		}
	}
	return false
}

func (m Monitor) Describe() string {
	state := "в норме"
	if m.Down {
		state = "ПЛОХО"
	}
	return fmt.Sprintf("#%d %s %s предел %g, проверка раз в %d мин: %s", m.ID, m.Kind, m.Arg, m.Limit, m.EveryMin, state)
}

// Checker answers whether a monitored thing is bad right now, with a detail for the message.
type Checker func(ctx context.Context, m Monitor) (bad bool, detail string)

// Alert is what the loop must tell the owner.
type Alert struct {
	Monitor   Monitor
	Detail    string
	Recovered bool
}

// CheckDue runs the monitors whose turn has come and reports state changes (and reminders every cooldown while bad).
func (s *Store) CheckDue(ctx context.Context, now time.Time, check Checker) []Alert {
	s.mu.Lock()
	ms := append([]Monitor(nil), s.f.Monitors...)
	s.mu.Unlock()
	var due []Monitor
	for _, m := range ms {
		if m.LastCheck.IsZero() || now.Sub(m.LastCheck) >= time.Duration(m.EveryMin)*time.Minute {
			due = append(due, m)
		}
	}
	var alerts []Alert
	for _, m := range due {
		bad, detail := check(ctx, m)
		s.mu.Lock()
		for i := range s.f.Monitors {
			cur := &s.f.Monitors[i]
			if cur.ID != m.ID {
				continue
			}
			cur.LastCheck = now
			switch {
			case bad && (!cur.Down || now.Sub(cur.LastAlert) >= time.Duration(cur.CooldownMin)*time.Minute):
				cur.Down, cur.LastAlert = true, now
				alerts = append(alerts, Alert{Monitor: *cur, Detail: detail})
			case !bad && cur.Down:
				cur.Down = false
				alerts = append(alerts, Alert{Monitor: *cur, Detail: detail, Recovered: true})
			}
		}
		s.save()
		s.mu.Unlock()
	}
	return alerts
}

// DefaultCheck looks at the real machine.
func DefaultCheck(ctx context.Context, m Monitor) (bool, string) {
	switch m.Kind {
	case "disk_free_pct":
		total, free, ok := DiskFree(m.Arg)
		if !ok || total == 0 {
			return false, "диск не измерить"
		}
		pct := 100 * float64(free) / float64(total)
		return pct < m.Limit, fmt.Sprintf("на %s свободно %.1f%% (%d МБ), предел %g%%", m.Arg, pct, free>>20, m.Limit)
	case "mem_avail_mb":
		raw, err := os.ReadFile("/proc/meminfo")
		if err != nil {
			return false, "память не измерить"
		}
		for _, l := range strings.Split(string(raw), "\n") {
			if strings.HasPrefix(l, "MemAvailable:") {
				if f := strings.Fields(l); len(f) >= 2 {
					kb, _ := strconv.ParseFloat(f[1], 64)
					return kb/1024 < m.Limit, fmt.Sprintf("доступно памяти %.0f МБ, предел %g МБ", kb/1024, m.Limit)
				}
			}
		}
		return false, "память не измерить"
	case "load":
		raw, err := os.ReadFile("/proc/loadavg")
		if err != nil {
			return false, "нагрузку не измерить"
		}
		f := strings.Fields(string(raw))
		if len(f) == 0 {
			return false, "нагрузку не измерить"
		}
		v, _ := strconv.ParseFloat(f[0], 64)
		return v > m.Limit, fmt.Sprintf("нагрузка %.2f, предел %g", v, m.Limit)
	case "url":
		u := m.Arg
		if !strings.Contains(u, "://") {
			u = "https://" + u
		}
		req, err := http.NewRequestWithContext(ctx, http.MethodGet, u, nil)
		if err != nil {
			return true, err.Error()
		}
		c := &http.Client{Timeout: 15 * time.Second}
		resp, err := c.Do(req)
		if err != nil {
			return true, u + " не отвечает: " + err.Error()
		}
		defer resp.Body.Close()
		_, _ = io.Copy(io.Discard, io.LimitReader(resp.Body, 1<<16))
		return resp.StatusCode >= 500, fmt.Sprintf("%s ответил %d", u, resp.StatusCode)
	case "port":
		c, err := (&net.Dialer{Timeout: 5 * time.Second}).DialContext(ctx, "tcp", m.Arg)
		if err != nil {
			return true, m.Arg + " закрыт: " + err.Error()
		}
		c.Close()
		return false, m.Arg + " открыт"
	case "process":
		ents, err := os.ReadDir("/proc")
		if err != nil {
			return false, "процессы не посмотреть"
		}
		want := strings.ToLower(m.Arg)
		for _, e := range ents {
			if _, err := strconv.Atoi(e.Name()); err != nil {
				continue
			}
			raw, err := os.ReadFile(filepath.Join("/proc", e.Name(), "comm"))
			if err == nil && strings.Contains(strings.ToLower(string(raw)), want) {
				return false, "процесс " + m.Arg + " работает"
			}
		}
		return true, "процесс " + m.Arg + " не найден"
	}
	return false, "неизвестный вид"
}
