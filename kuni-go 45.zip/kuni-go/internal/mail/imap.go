package mail

import (
	"bufio"
	"context"
	"crypto/tls"
	"errors"
	"fmt"
	"io"
	"net"
	"regexp"
	"strconv"
	"strings"
	"time"
)

// IMAP is a small read-only IMAP4rev1 client: log in, open a folder without changing anything, search, read.
type IMAP struct {
	c   net.Conn
	r   *bufio.Reader
	tag int
}

// Account is where the mailbox lives.
type Account struct {
	IMAPHost string // host:993 (TLS)
	SMTPHost string // host:587 (STARTTLS) or host:465 (TLS)
	User     string
	Password string
	From     string // address in From (default User)
	Plain    bool   // no TLS: tests only
}

// DialIMAP connects and logs in.
func DialIMAP(ctx context.Context, a Account) (*IMAP, error) {
	if a.IMAPHost == "" || a.User == "" {
		return nil, errors.New("почта не настроена: заполни mail.imap_host, mail.user и mail.password")
	}
	host := a.IMAPHost
	if !strings.Contains(host, ":") {
		host += ":993"
	}
	d := net.Dialer{Timeout: 15 * time.Second}
	var c net.Conn
	var err error
	if a.Plain {
		c, err = d.DialContext(ctx, "tcp", host)
	} else {
		var t *tls.Conn
		t, err = tls.DialWithDialer(&d, "tcp", host, &tls.Config{ServerName: strings.Split(host, ":")[0]})
		c = t
	}
	if err != nil {
		return nil, fmt.Errorf("imap: %w", err)
	}
	_ = c.SetDeadline(time.Now().Add(60 * time.Second))
	m := &IMAP{c: c, r: bufio.NewReaderSize(c, 64<<10)}
	if _, err := m.r.ReadString('\n'); err != nil { // greeting
		c.Close()
		return nil, err
	}
	if _, err := m.do("LOGIN " + quote(a.User) + " " + quote(a.Password)); err != nil {
		c.Close()
		return nil, fmt.Errorf("imap: вход не удался (%w). Для Gmail нужен пароль приложения, не обычный пароль", err)
	}
	return m, nil
}

func (m *IMAP) Close() {
	_, _ = m.do("LOGOUT")
	m.c.Close()
}

func quote(s string) string {
	return `"` + strings.NewReplacer(`\`, `\\`, `"`, `\"`, "\r", "", "\n", "").Replace(s) + `"`
}

// response is one untagged answer: its text with literals cut out, and the literals.
type response struct {
	Line string
	Lits [][]byte
}

var litRe = regexp.MustCompile(`\{(\d+)\}$`)

const maxLiteral = 4 << 20

// do sends a command and returns the untagged answers; an error unless the tagged answer is OK.
func (m *IMAP) do(cmd string) ([]response, error) {
	m.tag++
	tag := fmt.Sprintf("A%03d", m.tag)
	if _, err := io.WriteString(m.c, tag+" "+cmd+"\r\n"); err != nil {
		return nil, err
	}
	var out []response
	for {
		line, err := m.r.ReadString('\n')
		if err != nil {
			return out, err
		}
		line = strings.TrimRight(line, "\r\n")
		if strings.HasPrefix(line, tag+" ") {
			status := strings.TrimPrefix(line, tag+" ")
			if strings.HasPrefix(status, "OK") {
				return out, nil
			}
			return out, errors.New(status)
		}
		resp := response{}
		for {
			lm := litRe.FindStringSubmatch(line)
			if lm == nil {
				resp.Line += line
				break
			}
			n, _ := strconv.Atoi(lm[1])
			resp.Line += strings.TrimSuffix(line, lm[0]) + "{}"
			if n > maxLiteral {
				if _, err := io.CopyN(io.Discard, m.r, int64(n)); err != nil {
					return out, err
				}
				resp.Lits = append(resp.Lits, nil)
			} else {
				buf := make([]byte, n)
				if _, err := io.ReadFull(m.r, buf); err != nil {
					return out, err
				}
				resp.Lits = append(resp.Lits, buf)
			}
			if line, err = m.r.ReadString('\n'); err != nil {
				return out, err
			}
			line = strings.TrimRight(line, "\r\n")
		}
		out = append(out, resp)
	}
}

// Select opens a folder read-only (EXAMINE): nothing is marked as read.
func (m *IMAP) Select(folder string) error {
	if folder == "" {
		folder = "INBOX"
	}
	_, err := m.do("EXAMINE " + quote(folder))
	return err
}

// Query narrows a search.
type Query struct {
	Unseen  bool
	From    string
	Subject string
	Text    string
	Since   time.Time
}

func (q Query) criteria() string {
	var parts []string
	if q.Unseen {
		parts = append(parts, "UNSEEN")
	}
	if q.From != "" {
		parts = append(parts, "FROM "+quote(q.From))
	}
	if q.Subject != "" {
		parts = append(parts, "SUBJECT "+quote(q.Subject))
	}
	if q.Text != "" {
		parts = append(parts, "TEXT "+quote(q.Text))
	}
	if !q.Since.IsZero() {
		parts = append(parts, "SINCE "+q.Since.Format("2-Jan-2006"))
	}
	if len(parts) == 0 {
		return "ALL"
	}
	return strings.Join(parts, " ")
}

// Search returns UIDs, newest first, at most limit.
func (m *IMAP) Search(q Query, limit int) ([]int, error) {
	rs, err := m.do("UID SEARCH CHARSET UTF-8 " + q.criteria())
	if err != nil {
		return nil, err
	}
	var uids []int
	for _, r := range rs {
		if strings.HasPrefix(r.Line, "* SEARCH") {
			for _, f := range strings.Fields(strings.TrimPrefix(r.Line, "* SEARCH")) {
				if n, err := strconv.Atoi(f); err == nil {
					uids = append(uids, n)
				}
			}
		}
	}
	for i, j := 0, len(uids)-1; i < j; i, j = i+1, j-1 {
		uids[i], uids[j] = uids[j], uids[i]
	}
	if limit > 0 && len(uids) > limit {
		uids = uids[:limit]
	}
	return uids, nil
}

// Header is the short line of the list.
type Header struct {
	UID                 int
	From, Subject, Date string
	When                time.Time
	Seen                bool
}

var uidRe = regexp.MustCompile(`UID (\d+)`)

// Headers fetches From, Subject and Date for the UIDs.
func (m *IMAP) Headers(uids []int) ([]Header, error) {
	if len(uids) == 0 {
		return nil, nil
	}
	var set []string
	for _, u := range uids {
		set = append(set, strconv.Itoa(u))
	}
	rs, err := m.do("UID FETCH " + strings.Join(set, ",") + " (UID FLAGS BODY.PEEK[HEADER.FIELDS (FROM SUBJECT DATE)])")
	if err != nil {
		return nil, err
	}
	byUID := map[int]Header{}
	for _, r := range rs {
		if !strings.Contains(r.Line, "FETCH") || len(r.Lits) == 0 {
			continue
		}
		um := uidRe.FindStringSubmatch(r.Line)
		if um == nil {
			continue
		}
		uid, _ := strconv.Atoi(um[1])
		msg, err := ParseMessage(append(r.Lits[0], '\r', '\n'))
		if err != nil {
			continue
		}
		byUID[uid] = Header{UID: uid, From: msg.From, Subject: msg.Subject, Date: msg.Date, When: msg.When, Seen: strings.Contains(r.Line, `\Seen`)}
	}
	var out []Header
	for _, u := range uids { // keep the order asked for
		if h, ok := byUID[u]; ok {
			out = append(out, h)
		}
	}
	return out, nil
}

// Fetch downloads one message (at most maxBytes of it) and parses it.
func (m *IMAP) Fetch(uid, maxBytes int) (Message, error) {
	rs, err := m.do(fmt.Sprintf("UID FETCH %d (BODY.PEEK[]<0.%d>)", uid, maxBytes))
	if err != nil {
		return Message{}, err
	}
	for _, r := range rs {
		if strings.Contains(r.Line, "FETCH") && len(r.Lits) > 0 && r.Lits[0] != nil {
			return ParseMessage(r.Lits[0])
		}
	}
	return Message{}, errors.New("письмо не найдено (или слишком большое)")
}
