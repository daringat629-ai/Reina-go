package tools

import (
	"context"
	"strings"
	"sync"
	"time"

	"kuni/internal/live"
	"kuni/internal/telegram"
	"kuni/internal/tgui"
)

var (
	tguiMu  sync.Mutex
	tguiMap = map[telegram.Client]*tgui.UI{}
)

// tgUI is the one Telegram screen of the program: she keeps her place (open chat, scroll position) between turns.
func (d Deps) tgUI() *tgui.UI {
	tguiMu.Lock()
	defer tguiMu.Unlock()
	u := tguiMap[d.TG]
	if u == nil {
		u = tgui.New(d.TG)
		tguiMap[d.TG] = u
	}
	u.Feed = live.Default
	if d.UI != nil {
		u.Body = d.UI.Body
	}
	u.Loc = time.Local
	if tz := d.Cfg().AutonomyTimezone; tz != "" {
		if l, err := time.LoadLocation(tz); err == nil {
			u.Loc = l
		}
	}
	return u
}

// telegramUITool is the Telegram app as she sees it, the one the owner watches in the panel.
func telegramUITool(d Deps) Tool {
	return Tool{
		Name: "telegram_ui",
		Description: "The Telegram app on your phone, as a screen of text (owner only). Every action returns the screen; chats, messages and buttons are numbered, and you act on the numbers. " +
			"The owner watches the same screen live in the panel, so use this when you want to do things like a person would: look at your chats, open one, scroll, react, answer a specific message, press a bot's button. " +
			"Actions: screen | folders | list(folder = all / archive / a folder name) | open(chat = number from the list, id, @username or name; or n = a search result) | back | up / down = scroll older / newer | " +
			"search(text, scope = all to search every chat; inside an open chat it searches that chat) | " +
			"send(text, chat optional = another chat) | reply(n, text) | edit(n, text) | delete(n) | react(n, emoji) | press(n, button = \"row.col\", its text or number) | " +
			"forward(n, to) | pin(n) / unpin(n) | vote(n, options = \"1,3\") | view(n) = look closely at a photo, voice, video, file | read = mark read | mute / unmute | dice(emoji) | location(lat, lon). " +
			"send / reply / edit also take markdown (true = *bold* _italic_ `code` [text](url)), silent (no notification) and at (schedule: '+30m', '2026-10-21 09:00'). " +
			"Marks: 📌 pinned, 🔕 muted, ●N unread, @N mentions, ✍ someone is typing, ✓✓ read. Plain Telegram actions without a screen are still in tg_api.",
		Props: []Prop{
			{Name: "action", Type: "string", Desc: "One of the actions above."},
			{Name: "chat", Type: "string", Nullable: true, Desc: "open/send/read/mute: number from the list, id, @username or part of the name."},
			{Name: "n", Type: "integer", Nullable: true, Desc: "Number of a message on the screen (#n); in search results, of a result."},
			{Name: "text", Type: "string", Nullable: true, Desc: "Message text / search text."},
			{Name: "folder", Type: "string", Nullable: true, Desc: "list: all, archive or the name of a folder."},
			{Name: "emoji", Type: "string", Nullable: true, Desc: "react / dice: one emoji."},
			{Name: "button", Type: "string", Nullable: true, Desc: "press: \"row.col\" as printed (1.2), a number in order, or the button's text."},
			{Name: "to", Type: "string", Nullable: true, Desc: "forward: destination chat."},
			{Name: "options", Type: "string", Nullable: true, Desc: "vote: option numbers, e.g. \"1,3\"."},
			{Name: "markdown", Type: "boolean", Nullable: true, Desc: "send/edit: the text uses markdown."},
			{Name: "silent", Type: "boolean", Nullable: true, Desc: "send/pin: no notification."},
			{Name: "at", Type: "string", Nullable: true, Desc: "send: schedule for later."},
			{Name: "scope", Type: "string", Nullable: true, Desc: "search: all."},
			{Name: "lat", Type: "number", Nullable: true, Desc: "location: latitude."},
			{Name: "lon", Type: "number", Nullable: true, Desc: "location: longitude."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			p := tgui.Params{
				Action: a.Str("action"), Chat: a.Str("chat"), N: int(a.Int("n")), Text: a.Str("text"), Folder: a.Str("folder"),
				Emoji: a.Str("emoji"), Button: a.Str("button"), To: a.Str("to"), Options: a.Str("options"),
				Markdown: a.Bool("markdown"), Silent: a.Bool("silent"), At: a.Str("at"), Scope: a.Str("scope"),
				Lat: a.Float("lat"), Lon: a.Float("lon"),
			}
			out, err := d.tgUI().Do(ctx, p)
			if err != nil {
				return "", err
			}
			return Truncate(strings.TrimSpace(out), 9000), nil
		},
	}
}
