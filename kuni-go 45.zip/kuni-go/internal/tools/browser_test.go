package tools

import (
	"context"
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"kuni/internal/browser"
	"kuni/internal/config"
	"kuni/internal/llmui"
	"kuni/internal/media"
	"kuni/internal/telegram"
)

func browserDeps(t *testing.T) (Deps, *telegram.Fake, *config.Config) {
	d := ownerDeps(t, 5)
	c := d.Cfg()
	c.BrowserEnabled, c.BrowserNoSandbox, c.BrowserSteps, c.BrowserIdleSecs = true, true, 6, 120
	d.Browser = browser.New()
	t.Cleanup(d.Browser.Close)
	return d, d.TG.(*telegram.Fake), c
}

func site() *httptest.Server {
	mux := http.NewServeMux()
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprint(w, `<title>Главная</title><h1>Магазин</h1><a href="/cart">Корзина</a><button>Ничего не делает</button><input placeholder="Найти">`)
	})
	mux.HandleFunc("/cart", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprint(w, `<title>Корзина</title><h1>Корзина пуста</h1>`)
	})
	return httptest.NewServer(mux)
}

func call(t *testing.T, tool Tool, args Args) string {
	t.Helper()
	out, err := tool.Run(context.Background(), args)
	if err != nil {
		t.Fatalf("%v: %v", args, err)
	}
	return out
}

func TestBrowserToolWorksAndSendsScreenshots(t *testing.T) {
	if browser.Find("") == "" {
		t.Skip("no chromium")
	}
	d, fk, _ := browserDeps(t)
	s := site()
	defer s.Close()
	tool := browserTool(d, telegram.Chat{ID: 5})

	out := call(t, tool, Args{"action": "open", "url": s.URL})
	if !strings.Contains(out, "шаг 1/6") || !strings.Contains(out, "Магазин") || !strings.Contains(out, "Корзина") {
		t.Fatal(out)
	}
	// the number in the list is what she clicks
	var n string
	for _, l := range strings.Split(out, "\n") {
		if strings.Contains(l, "«Корзина»") {
			n = strings.Fields(l)[0]
		}
	}
	out = call(t, tool, Args{"action": "click", "target": n})
	if !strings.Contains(out, "Корзина пуста") {
		t.Fatal(out)
	}
	out = call(t, tool, Args{"action": "text"})
	if !strings.Contains(out, "<web_page_text>") || !strings.Contains(out, "Корзина пуста") {
		t.Fatal(out)
	}
	out = call(t, tool, Args{"action": "send", "caption": "вот"})
	if !strings.Contains(out, "screenshot sent") {
		t.Fatal(out)
	}
	if len(fk.Sent) != 1 || fk.Sent[0].Media != telegram.MediaPhoto || fk.Sent[0].Text != "вот" || fk.Sent[0].ChatID != 5 {
		t.Fatalf("screenshot not delivered: %+v", fk.Sent)
	}
	if out := call(t, tool, Args{"action": "close"}); !strings.Contains(out, "closed") || d.Browser.Running() {
		t.Fatal("close must stop the browser")
	}
	if _, err := tool.Run(context.Background(), Args{"action": "dance"}); err == nil {
		t.Fatal("unknown action must be an error")
	}
}

func TestBrowserToolStopsALoopAndTheStepLimit(t *testing.T) {
	if browser.Find("") == "" {
		t.Skip("no chromium")
	}
	d, _, _ := browserDeps(t)
	s := site()
	defer s.Close()
	tool := browserTool(d, telegram.Chat{ID: 5})
	out := call(t, tool, Args{"action": "open", "url": s.URL})
	var idle string
	for _, l := range strings.Split(out, "\n") {
		if strings.Contains(l, "«Ничего не делает»") {
			idle = strings.Fields(l)[0]
		}
	}
	// clicking a dead button over and over: two warnings, then a hard stop
	for i := 1; i <= 2; i++ {
		if out = call(t, tool, Args{"action": "click", "target": idle}); !strings.Contains(out, "Страница не изменилась") {
			t.Fatalf("useless click %d must warn:\n%s", i, out)
		}
	}
	out = call(t, tool, Args{"action": "click", "target": idle})
	if !strings.Contains(out, "по кругу") {
		t.Fatalf("a loop must end the browsing:\n%s", out)
	}
	if out = call(t, tool, Args{"action": "look"}); !strings.Contains(out, "going in circles") {
		t.Fatalf("after the stop the tool must refuse:\n%s", out)
	}
	// a fresh message of the owner builds a fresh tool: new steps, new guard
	tool = browserTool(d, telegram.Chat{ID: 5})
	if out = call(t, tool, Args{"action": "look"}); !strings.Contains(out, "Магазин") {
		t.Fatal(out)
	}
}

func TestBrowserStepLimit(t *testing.T) {
	if browser.Find("") == "" {
		t.Skip("no chromium")
	}
	d, _, c := browserDeps(t)
	c.BrowserSteps = 3
	s := site()
	defer s.Close()
	tool := browserTool(d, telegram.Chat{ID: 5})
	call(t, tool, Args{"action": "open", "url": s.URL})
	call(t, tool, Args{"action": "scroll", "direction": "down"})
	call(t, tool, Args{"action": "look"})
	if out := call(t, tool, Args{"action": "look"}); !strings.Contains(out, "Step limit reached (3") {
		t.Fatalf("no step limit:\n%s", out)
	}
}

func TestLoopGuardOscillation(t *testing.T) {
	g := &loopGuard{}
	var stopped bool
	for i := 0; i < 12 && !stopped; i++ {
		fp := []string{"A", "B"}[i%2] // back and forth between two pages
		_, stopped = g.check(fp)
	}
	if !stopped {
		t.Fatal("going A,B,A,B,... must be stopped")
	}
	g = &loopGuard{}
	for i := 0; i < 10; i++ {
		if _, stop := g.check(fmt.Sprint("page", i)); stop {
			t.Fatal("moving through different pages is not a loop")
		}
	}
}

func TestBrowserOnlyForOwnerAndSwitchable(t *testing.T) {
	d, _, c := browserDeps(t)
	names := func(chat int64) (out []string) {
		for _, t := range OwnerTools(d, telegram.Chat{ID: chat}) {
			out = append(out, t.Name)
		}
		return
	}
	if !strings.Contains(strings.Join(names(5), ","), "browser") || strings.Contains(strings.Join(names(6), ","), "browser") {
		t.Fatal("the browser belongs to the owner's chat only")
	}
	c.BrowserEnabled = false
	if strings.Contains(strings.Join(names(5), ","), "browser") {
		t.Fatal("browser.enabled=false must remove the tool")
	}
	if !strings.Contains(strings.Join(names(5), ","), "tg_api") {
		t.Fatal("tg_api is part of the owner tools")
	}
}

func apiDeps(t *testing.T) (Deps, *telegram.Fake) {
	d := ownerDeps(t, 5)
	fk := d.TG.(*telegram.Fake)
	d.UI = &llmui.Env{TG: fk, Cfg: d.Cfg, Media: func() media.Services { return media.NewDisabled() }}
	return d, fk
}

func TestTgAPIReadsAWholeChatInPagesAndActsAnywhere(t *testing.T) {
	d, fk := apiDeps(t)
	group := telegram.Chat{ID: -77, Title: "Рабочий чат", Kind: telegram.ChatGroup, IsMember: true}
	for i := 0; i < 25; i++ {
		fk.Incoming(group, 9, "Joe", fmt.Sprintf("сообщение номер %d", i))
	}
	fk.Roster = map[int64][]telegram.Member{-77: {{ID: 9, Name: "Joe", Role: "admin"}}}
	fk.Users = map[int64]telegram.User{9: {ID: 9, Name: "Joe", Bio: "любит сыр"}}
	tool := tgAPITool(d)

	// read all 25 messages in pages of 10 by walking back with the oldest id
	seen := map[string]bool{}
	var before int64
	for page := 0; page < 6; page++ {
		args := Args{"action": "history", "chat": "-77", "limit": float64(10)}
		if before != 0 {
			args["message_id"] = float64(before)
		}
		out := call(t, tool, args)
		for i := 0; i < 25; i++ {
			if strings.Contains(out, fmt.Sprintf("сообщение номер %d<", i)) || strings.Contains(out, fmt.Sprintf("сообщение номер %d\n", i)) {
				seen[fmt.Sprint(i)] = true
			}
		}
		var next int64
		if _, err := fmt.Sscanf(out[strings.LastIndex(out, "oldest message_id here: ")+len("oldest message_id here: "):], "%d", &next); err != nil || next == before {
			break
		}
		before = next
	}
	if len(seen) < 25 {
		t.Fatalf("paging did not reach the beginning, saw %d of 25", len(seen))
	}
	if out := call(t, tool, Args{"action": "search", "query": "номер 17", "chat": "-77"}); !strings.Contains(out, "номер 17") {
		t.Fatal(out)
	}
	if out := call(t, tool, Args{"action": "members", "chat": "-77"}); !strings.Contains(out, "Joe") {
		t.Fatal(out)
	}
	if out := call(t, tool, Args{"action": "user", "user_id": float64(9)}); !strings.Contains(out, "сыр") {
		t.Fatal(out)
	}
	call(t, tool, Args{"action": "send", "chat": "-77", "text": "привет из лички"})
	call(t, tool, Args{"action": "pin", "chat": "-77", "message_id": float64(3)})
	call(t, tool, Args{"action": "forward", "chat": "-77", "message_id": float64(3), "to": "5"})
	call(t, tool, Args{"action": "react", "chat": "-77", "message_id": float64(3), "emoji": "👍"})
	call(t, tool, Args{"action": "ban", "chat": "-77", "user_id": float64(9)})
	call(t, tool, Args{"action": "leave", "chat": "-77"})
	if len(fk.Sent) != 1 || len(fk.Pinned[-77]) != 1 || len(fk.Forwards) != 1 || len(fk.Banned) != 1 || len(fk.Left) != 1 || fk.Reacted[3] == "" {
		t.Fatalf("actions did not reach Telegram: sent=%d pinned=%v fwd=%v banned=%v left=%v", len(fk.Sent), fk.Pinned, fk.Forwards, fk.Banned, fk.Left)
	}
	// files from her workspace
	_, _ = shellTool(d).Run(context.Background(), Args{"command": "echo data > r.txt"})
	call(t, tool, Args{"action": "send_file", "chat": "-77", "path": "r.txt", "text": "держи"})
	if last := fk.Sent[len(fk.Sent)-1]; !strings.Contains(last.Text, "r.txt") {
		t.Fatalf("file not sent: %+v", last)
	}
	for _, bad := range []Args{{"action": "send", "chat": "-77"}, {"action": "edit", "chat": "-77"}, {"action": "nope"}, {"action": "history"}, {"action": "send_file", "chat": "-77", "path": "../../etc/hostname-none"}} {
		if _, err := tool.Run(context.Background(), bad); err == nil {
			t.Errorf("%v must fail", bad)
		}
	}
	_ = time.Second
}

func TestBrowserToolYouTubeFlowAndAccountGuard(t *testing.T) {
	if browser.Find("") == "" {
		t.Skip("no chromium")
	}
	d, _, c := browserDeps(t)
	c.BrowserBlockHosts, c.BrowserSteps = "accounts.google.com,myaccount.google.com", 30
	mux := http.NewServeMux()
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprint(w, `<title>Главная</title><ytd-rich-item-renderer><a id="video-title-link" title="Лекция про сон" href="/watch?v=zzz111">Лекция про сон</a><ytd-channel-name>Наука</ytd-channel-name></ytd-rich-item-renderer>
<a href="/go-settings">Настройки аккаунта</a>`)
	})
	mux.HandleFunc("/watch", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprint(w, `<title>В</title><script>window.ytInitialPlayerResponse={"videoDetails":{"videoId":"zzz111","title":"Лекция про сон","author":"Наука","lengthSeconds":"600","viewCount":"5"},
"captions":{"playerCaptionsTracklistRenderer":{"captionTracks":[{"baseUrl":"/cap","languageCode":"ru"}]}}}</script>`)
	})
	mux.HandleFunc("/cap", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprint(w, `{"events":[{"tStartMs":0,"segs":[{"utf8":"Сон нужен чтобы память закреплялась"}]}]}`)
	})
	mux.HandleFunc("/echo", func(w http.ResponseWriter, r *http.Request) {
		ck, _ := r.Cookie("SID")
		if ck != nil {
			fmt.Fprint(w, "<title>x</title>вход как "+ck.Value)
		} else {
			fmt.Fprint(w, "<title>x</title>гость")
		}
	})
	s := httptest.NewServer(mux)
	defer s.Close()
	tool := browserTool(d, telegram.Chat{ID: 5})

	call(t, tool, Args{"action": "open", "url": s.URL})
	out := call(t, tool, Args{"action": "videos"})
	if !strings.Contains(out, "Лекция про сон — Наука") || !strings.Contains(out, "watch?v=zzz111") {
		t.Fatal(out)
	}
	call(t, tool, Args{"action": "open", "url": s.URL + "/watch?v=zzz111"})
	out = call(t, tool, Args{"action": "transcript", "text": "ru"})
	if !strings.Contains(out, "<video>") || !strings.Contains(out, "Сон нужен чтобы память закреплялась") {
		t.Fatal(out)
	}

	// cookies from a file he sent: imported, the file is gone, the site sees them
	_, _ = shellTool(d).Run(context.Background(), Args{"command": `printf '[{"domain":"127.0.0.1","name":"SID","value":"jaabir","path":"/","expirationDate":4102444800}]' > c.json`})
	out = call(t, tool, Args{"action": "cookies", "path": "c.json"})
	if !strings.Contains(out, "imported (127.0.0.1: 1)") || !strings.Contains(out, "deleted") {
		t.Fatal(out)
	}
	if _, err := os.Stat(filepath.Join(d.workDir(), "c.json")); err == nil {
		t.Fatal("the cookie file is a key to the account: it must be deleted")
	}
	if out = call(t, tool, Args{"action": "open", "url": s.URL + "/echo"}); !strings.Contains(out, "вход как jaabir") {
		t.Fatalf("cookie not used:\n%s", out)
	}
	if _, err := tool.Run(context.Background(), Args{"action": "cookies", "path": "nope.json"}); err == nil {
		t.Fatal("a missing file is an error")
	}

	// account pages are off limits, both by address and by following a link there
	for _, u := range []string{"https://accounts.google.com/signin", "myaccount.google.com", "https://sub.myaccount.google.com/x"} {
		if _, err := tool.Run(context.Background(), Args{"action": "open", "url": u}); err == nil || !strings.Contains(err.Error(), "block list") {
			t.Errorf("%s must be refused: %v", u, err)
		}
	}
	if blockedHost("accounts.google.com", "https://www.youtube.com/") != "" || blockedHost("", "https://accounts.google.com") != "" {
		t.Fatal("ordinary sites and an empty list must pass")
	}
}
