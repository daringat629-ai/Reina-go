package tools

import (
	"context"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"

	"kuni/internal/browser"
	"kuni/internal/desktop"
	"kuni/internal/telegram"
)

func TestDesktopToolDrivesAProgram(t *testing.T) {
	if _, err := exec.LookPath("Xvfb"); err != nil {
		t.Skip("no Xvfb")
	}
	bin := browser.Find("")
	if bin == "" {
		t.Skip("no chromium")
	}
	d := ownerDeps(t, 5)
	c := d.Cfg()
	c.DesktopEnabled, c.DesktopSteps, c.DesktopWidth, c.DesktopHeight, c.DesktopIdleSecs = true, 12, 1000, 700, 120
	d.Desktop = desktop.New()
	t.Cleanup(d.Desktop.Close)
	fk := d.TG.(*telegram.Fake)

	dir := t.TempDir()
	page := filepath.Join(dir, "p.html")
	os.WriteFile(page, []byte(`<!doctype html><title>Старт</title><body style="margin:0"><button style="position:absolute;left:100px;top:100px;width:300px;height:100px;font-size:30px" onclick="document.title='Нажата';document.body.style.background='red'">Кнопка</button>`), 0o644)
	tool := desktopTool(d, telegram.Chat{ID: 5})
	if n := len(OwnerTools(d, telegram.Chat{ID: 5})); n != 51 {
		t.Fatalf("enabled desktop must add a tool, got %d", n)
	}

	line := fmt.Sprintf("%s --no-sandbox --test-type --disable-infobars --disable-gpu --user-data-dir=%s --window-position=0,0 --window-size=1000,700 --app=file://%s", bin, filepath.Join(dir, "prof"), page)
	out := call(t, tool, Args{"action": "launch", "command": line})
	if !strings.Contains(out, "шаг 1/12") || !strings.Contains(out, "Старт") {
		t.Fatal(out)
	}
	out = call(t, tool, Args{"action": "click", "x": 200.0, "y": 150.0})
	if !strings.Contains(out, "Нажата") || !strings.Contains(out, "Экран изменился") {
		t.Fatal(out)
	}
	if _, err := tool.Run(context.Background(), Args{"action": "click", "x": 5000.0, "y": 1.0}); err == nil {
		t.Fatal("a click outside the screen must be refused")
	}
	if out := call(t, tool, Args{"action": "look"}); !strings.Contains(out, "Нажата") {
		t.Fatal(out)
	}
	out = call(t, tool, Args{"action": "send", "caption": "экран"})
	if !strings.Contains(out, "screenshot sent") || len(fk.Sent) != 1 || fk.Sent[0].Media != telegram.MediaPhoto {
		t.Fatalf("%s %+v", out, fk.Sent)
	}
	// nothing changes: first she is warned, then stopped
	var last string
	for i := 0; i < 4; i++ {
		last = call(t, tool, Args{"action": "move", "x": 800.0, "y": 600.0})
	}
	if !strings.Contains(last, "по кругу") {
		t.Fatal(last)
	}
	if out := call(t, tool, Args{"action": "key", "key": "F5"}); !strings.Contains(out, "circles") {
		t.Fatal(out)
	}
	if out := call(t, tool, Args{"action": "close"}); !strings.Contains(out, "closed") {
		t.Fatal(out)
	}
}

func TestDesktopToolOffByDefault(t *testing.T) {
	d := ownerDeps(t, 5)
	if _, err := desktopTool(d, telegram.Chat{ID: 5}).Run(context.Background(), Args{"action": "look"}); err == nil {
		t.Fatal("must refuse when switched off")
	}
}
