package tools

import (
	"context"
	"fmt"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"

	"kuni/internal/sched"
	"kuni/internal/telegram"
)

var reEvery = regexp.MustCompile(`^(\d+)\s*(m|min|мин|h|ч|d|д)\p{L}*$`)

// parseEvery reads "30m", "2h", "1d", "15 мин".
func parseEvery(s string) (time.Duration, error) {
	m := reEvery.FindStringSubmatch(strings.ToLower(strings.TrimSpace(s)))
	if m == nil {
		return 0, fmt.Errorf("every must look like 30m, 2h or 1d")
	}
	n, _ := strconv.Atoi(m[1])
	switch m[2] {
	case "m", "min", "мин":
		return time.Duration(n) * time.Minute, nil
	case "h", "ч":
		return time.Duration(n) * time.Hour, nil
	}
	return time.Duration(n) * 24 * time.Hour, nil
}

func scheduleTool(d Deps, chat telegram.Chat) Tool {
	return Tool{
		Name: "schedule",
		Description: "Recurring tasks that you will do on your own later and report to the owner (owner only). Actions: add (text = what to do when the time comes, written for yourself, e.g. 'узнай курс биткоина и напиши папику'; plus every = 30m / 2h / 1d, or at = HH:MM with optional days = пн-пт, sat,sun, weekdays), list, delete (id), pause (id), resume (id). " +
			"Use it for 'каждое утро...', 'раз в час проверяй...', 'по будням в 9...'. For one-off 'напомни через...' use remind.",
		Props: []Prop{
			{Name: "action", Type: "string", Desc: "add, list, delete, pause or resume."},
			{Name: "text", Type: "string", Nullable: true, Desc: "add: what to do each time."},
			{Name: "every", Type: "string", Nullable: true, Desc: "add: interval like 30m, 2h, 1d."},
			{Name: "at", Type: "string", Nullable: true, Desc: "add: time of day HH:MM (owner's zone)."},
			{Name: "days", Type: "string", Nullable: true, Desc: "add with at: weekdays like пн-пт or mon,wed. Empty = every day."},
			{Name: "id", Type: "integer", Nullable: true, Desc: "delete/pause/resume: the task number."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			if d.Sched == nil {
				return "", fmt.Errorf("the scheduler is off")
			}
			now := time.Now()
			switch strings.ToLower(strings.TrimSpace(a.Str("action"))) {
			case "add":
				var t sched.Task
				var err error
				switch {
				case strings.TrimSpace(a.Str("every")) != "":
					var dur time.Duration
					if dur, err = parseEvery(a.Str("every")); err == nil {
						t, err = d.Sched.AddEvery(chat.ID, a.Str("text"), dur, now)
					}
				case strings.TrimSpace(a.Str("at")) != "":
					var days []int
					if days, err = sched.ParseDays(a.Str("days")); err == nil {
						t, err = d.Sched.AddDaily(chat.ID, a.Str("text"), a.Str("at"), days, now)
					}
				default:
					err = fmt.Errorf("give either every (30m, 2h, 1d) or at (HH:MM)")
				}
				if err != nil {
					return "", err
				}
				return "added: " + t.Describe(d.Sched.Loc()), nil
			case "list", "":
				ts := d.Sched.Tasks()
				if len(ts) == 0 {
					return "no recurring tasks", nil
				}
				sort.Slice(ts, func(i, j int) bool { return ts[i].ID < ts[j].ID })
				var b strings.Builder
				for _, t := range ts {
					b.WriteString(t.Describe(d.Sched.Loc()) + "\n")
				}
				return b.String(), nil
			case "delete":
				if !d.Sched.DeleteTask(int(a.Int("id"))) {
					return "", fmt.Errorf("no task #%d", a.Int("id"))
				}
				return "deleted", nil
			case "pause", "resume":
				if !d.Sched.SetPaused(int(a.Int("id")), strings.EqualFold(a.Str("action"), "pause"), now) {
					return "", fmt.Errorf("no task #%d", a.Int("id"))
				}
				return "ok", nil
			}
			return "", fmt.Errorf("action must be add, list, delete, pause or resume")
		},
	}
}

func monitorTool(d Deps, chat telegram.Chat) Tool {
	var kinds []string
	for k, v := range sched.Kinds() {
		kinds = append(kinds, k+" ("+v+")")
	}
	sort.Strings(kinds)
	return Tool{
		Name: "monitor",
		Description: "Watches something in the background and writes to the owner by itself when it goes bad, and again when it recovers (owner only). Actions: add, list, delete (id). Kinds: " + strings.Join(kinds, "; ") +
			". Use it for 'скажи, если диск кончится', 'следи за сайтом', 'дай знать, если бот упадёт'.",
		Props: []Prop{
			{Name: "action", Type: "string", Desc: "add, list or delete."},
			{Name: "kind", Type: "string", Nullable: true, Desc: "add: disk_free_pct, mem_avail_mb, load, url, port or process."},
			{Name: "arg", Type: "string", Nullable: true, Desc: "add: path / address / host:port / process name."},
			{Name: "limit", Type: "number", Nullable: true, Desc: "add: the threshold (percent, MB or load)."},
			{Name: "every_min", Type: "integer", Nullable: true, Desc: "add: check every N minutes (default 5)."},
			{Name: "cooldown_min", Type: "integer", Nullable: true, Desc: "add: repeat the warning at most every N minutes while it stays bad (default 60)."},
			{Name: "id", Type: "integer", Nullable: true, Desc: "delete: the monitor number."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			if d.Sched == nil {
				return "", fmt.Errorf("the scheduler is off")
			}
			switch strings.ToLower(strings.TrimSpace(a.Str("action"))) {
			case "add":
				m, err := d.Sched.AddMonitor(sched.Monitor{Chat: chat.ID, Kind: a.Str("kind"), Arg: a.Str("arg"), Limit: a.Float("limit"),
					EveryMin: int(a.Int("every_min")), CooldownMin: int(a.Int("cooldown_min"))}, time.Now())
				if err != nil {
					return "", err
				}
				return "watching: " + m.Describe(), nil
			case "list", "":
				ms := d.Sched.Monitors()
				if len(ms) == 0 {
					return "no monitors", nil
				}
				var b strings.Builder
				for _, m := range ms {
					b.WriteString(m.Describe() + "\n")
				}
				return b.String(), nil
			case "delete":
				if !d.Sched.DeleteMonitor(int(a.Int("id"))) {
					return "", fmt.Errorf("no monitor #%d", a.Int("id"))
				}
				return "deleted", nil
			}
			return "", fmt.Errorf("action must be add, list or delete")
		},
	}
}
