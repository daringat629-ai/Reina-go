package admin

import (
	"context"
	"encoding/json"
	"errors"
	"strings"
	"testing"

	"kuni/internal/live"
)

func TestLiveViewIsGuardedAndServesFramesAndFeed(t *testing.T) {
	p, mux, c, _ := rig(t)
	// without a login nothing is served
	if w := do(mux, "GET", "/admin/api/live/frame?src=desktop", "", nil); w.Code != 401 {
		t.Fatalf("frame without auth: %d", w.Code)
	}
	if w := do(mux, "GET", "/admin/api/live/events", "", nil); w.Code != 401 {
		t.Fatalf("events without auth: %d", w.Code)
	}
	// the view is off until the program wires it
	if w := do(mux, "GET", "/admin/api/live/frame?src=desktop", "", auth); w.Code != 404 {
		t.Fatalf("no source: %d", w.Code)
	}
	running := true
	p.Frame = func(_ context.Context, src string) ([]byte, string, bool, error) {
		switch {
		case src == "browser":
			return nil, "", false, errors.New("boom")
		case !running:
			return nil, "", false, nil
		}
		return []byte{0xff, 0xd8, 0xff, 0xd9}, "321,123", true, nil
	}
	p.Screens = func() (bool, bool) { return false, running }
	p.Feed = &live.Feed{}
	p.Feed.Add("tool", "Alex", "browser open")
	p.Feed.Add("result", "Alex", "ok")
	c.paused = true

	w := do(mux, "GET", "/admin/api/live/frame?src=desktop", "", auth)
	if w.Code != 200 || w.Header().Get("Content-Type") != "image/jpeg" || w.Header().Get("X-Pointer") != "321,123" || !strings.Contains(w.Header().Get("Cache-Control"), "no-store") || w.Body.Len() != 4 {
		t.Fatalf("frame: %d %v", w.Code, w.Header())
	}
	running = false
	if w := do(mux, "GET", "/admin/api/live/frame?src=desktop", "", auth); w.Code != 204 {
		t.Fatalf("a stopped screen must be 204, got %d", w.Code)
	}
	if w := do(mux, "GET", "/admin/api/live/frame?src=browser", "", auth); w.Code != 502 {
		t.Fatalf("error: %d", w.Code)
	}
	if w := do(mux, "GET", "/admin/api/live/frame?src=../etc/passwd", "", auth); w.Code != 400 {
		t.Fatalf("bad src: %d", w.Code)
	}

	var j struct {
		Events  []live.Event `json:"events"`
		Last    int64        `json:"last"`
		Desktop bool         `json:"desktop"`
		Browser bool         `json:"browser"`
		Paused  bool         `json:"paused"`
	}
	w = do(mux, "GET", "/admin/api/live/events?since=0", "", auth)
	if err := json.Unmarshal(w.Body.Bytes(), &j); err != nil || len(j.Events) != 2 || j.Last != 2 || j.Desktop || !j.Paused {
		t.Fatalf("events: %s", w.Body.String())
	}
	w = do(mux, "GET", "/admin/api/live/events?since=1", "", auth)
	j.Events = nil
	json.Unmarshal(w.Body.Bytes(), &j)
	if len(j.Events) != 1 || j.Events[0].Kind != "result" {
		t.Fatalf("since: %s", w.Body.String())
	}
	// the tab is part of the page
	if w := do(mux, "GET", "/admin", "", map[string]string{"Authorization": "Bearer " + tok}); !strings.Contains(w.Body.String(), `["live","Эфир"]`) {
		t.Fatal("the Эфир tab is missing from the page")
	}
}
