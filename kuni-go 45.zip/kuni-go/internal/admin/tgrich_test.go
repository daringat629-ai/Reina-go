package admin

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"kuni/internal/config"
	"kuni/internal/live"
	"kuni/internal/telegram"
)

func richRig(t *testing.T) (*Panel, http.Handler, *telegram.Fake, string) {
	t.Helper()
	p, mux, _, cp := rig(t)
	fk := telegram.NewFake()
	p.TG = fk
	return p, mux, fk, cp
}

func get(mux http.Handler, path string) *httptest.ResponseRecorder {
	return do(mux, "GET", "/admin/api/"+path, "", auth)
}

func TestChatListShowsPinsFoldersArchiveAndLiveMarks(t *testing.T) {
	_, mux, fk, _ := richRig(t)
	now := time.Now()
	fk.S.Put(telegram.Message{ID: 1, ChatID: 1, Date: now.Add(-time.Hour), Text: "старое"}, &telegram.Chat{ID: 1, Title: "Закреп", Pinned: true, Folders: []int{3}})
	fk.S.Put(telegram.Message{ID: 1, ChatID: 2, Date: now, Text: "новое"}, &telegram.Chat{ID: 2, Title: "Свежий", Muted: true, Typing: "typing", TypingBy: "Бек", UnreadMentions: 2, Presence: "online"})
	fk.S.Put(telegram.Message{ID: 1, ChatID: 3, Date: now, Text: "в архиве"}, &telegram.Chat{ID: 3, Title: "Архивный", Archived: true})
	fk.Rich.FolderList = []telegram.Folder{{ID: 3, Name: "Работа"}}
	var res struct {
		Chats    []tgChat          `json:"chats"`
		Folders  []telegram.Folder `json:"folders"`
		Takeover bool              `json:"takeover"`
	}
	w := get(mux, "tg/chats")
	if err := json.Unmarshal(w.Body.Bytes(), &res); err != nil || len(res.Chats) != 2 {
		t.Fatalf("main list: %d %s", w.Code, w.Body.String())
	}
	if res.Chats[0].Title != "Закреп" || !res.Chats[0].Pinned || res.Chats[1].Title != "Свежий" {
		t.Fatalf("pinned chat must be first: %+v", res.Chats)
	}
	c := res.Chats[1]
	if !c.Muted || c.Typing != "typing" || c.TypingBy != "Бек" || c.Mentions != 2 || c.Presence != "online" {
		t.Fatalf("marks: %+v", c)
	}
	if len(res.Folders) != 1 || res.Folders[0].Name != "Работа" || res.Takeover {
		t.Fatalf("folders: %+v takeover=%v", res.Folders, res.Takeover)
	}
	json.Unmarshal(get(mux, "tg/chats?folder=archive").Body.Bytes(), &res)
	if len(res.Chats) != 1 || res.Chats[0].Title != "Архивный" {
		t.Fatalf("archive: %+v", res.Chats)
	}
	json.Unmarshal(get(mux, "tg/chats?folder=3").Body.Bytes(), &res)
	if len(res.Chats) != 1 || res.Chats[0].Title != "Закреп" {
		t.Fatalf("folder: %+v", res.Chats)
	}
	if w := get(mux, "tg/chats?folder=zzz"); w.Code != 400 {
		t.Fatalf("bad folder: %d", w.Code)
	}
}

func TestHistoryCarriesTheRichMessageAndPagesBackwards(t *testing.T) {
	_, mux, fk, _ := richRig(t)
	chat := telegram.Chat{ID: 7, Title: "Алина", Kind: telegram.ChatPrivate}
	now := time.Now()
	for i := int64(1); i <= 30; i++ {
		fk.S.Put(telegram.Message{ID: i, ChatID: 7, SenderID: 7, SenderName: "Алина", Date: now, Text: "m" + itoa(i)}, &chat)
	}
	fk.S.Put(telegram.Message{ID: 31, ChatID: 7, SenderID: 7, SenderName: "Алина", Date: now, Text: "с кнопками", Quote: "цитата",
		Entities: []telegram.Entity{{Type: "bold", Offset: 0, Length: 1}}, Buttons: [][]telegram.Button{{{Text: "Да", Kind: "callback", Data: "eWVz"}}},
		Preview: &telegram.LinkPreview{URL: "https://x.io", Title: "T"}, Place: &telegram.Place{Lat: 1, Lon: 2}, Counts: []telegram.ReactionCount{{Emoji: "👍", Count: 2}},
		Poll: &telegram.Poll{Question: "q", Multiple: true, Options: []telegram.PollOption{{Text: "a", Votes: 1, Chosen: true}, {Text: "b"}}}, Media: telegram.MediaPoll}, &chat)
	fk.S.Put(telegram.Message{ID: 32, ChatID: 7, Date: now, Service: "Алина закрепила сообщение", Text: "Алина закрепила сообщение", PinnedMsg: 5}, &chat)
	_ = fk.Pin(nil, 7, 5, false)
	var res struct {
		Messages []tgMsg `json:"messages"`
		More     bool    `json:"more"`
		Pinned   *tgMsg  `json:"pinned"`
		Chat     tgChat  `json:"chat"`
	}
	w := get(mux, "tg/history?id=7&n=10")
	if err := json.Unmarshal(w.Body.Bytes(), &res); err != nil || len(res.Messages) != 10 || !res.More {
		t.Fatalf("latest: %d %s", w.Code, w.Body.String())
	}
	rich := res.Messages[8]
	if rich.ID != 31 || rich.Quote != "цитата" || len(rich.Entities) != 1 || rich.Buttons[0][0].Data != "eWVz" || rich.Preview.Title != "T" || rich.Place == nil ||
		rich.Counts[0].Count != 2 || rich.Poll == nil || !rich.Poll.Multiple || !rich.Poll.Chosen[0] {
		t.Fatalf("rich message: %+v", rich)
	}
	if res.Messages[9].Service != "Алина закрепила сообщение" || res.Messages[9].PinnedMsg != 5 {
		t.Fatalf("service: %+v", res.Messages[9])
	}
	if res.Pinned == nil || res.Pinned.ID != 5 || res.Chat.Title != "Алина" {
		t.Fatalf("pinned bar / chat: %+v %+v", res.Pinned, res.Chat)
	}
	oldest := res.Messages[0].ID
	var older, mid struct {
		Messages []tgMsg `json:"messages"`
		Pinned   *tgMsg  `json:"pinned"`
	}
	json.Unmarshal(get(mux, "tg/history?id=7&n=10&before="+itoa(oldest)).Body.Bytes(), &older)
	if len(older.Messages) != 10 || older.Messages[len(older.Messages)-1].ID != oldest-1 || older.Pinned != nil {
		t.Fatalf("older page: %d messages, pinned=%v", len(older.Messages), older.Pinned)
	}
	json.Unmarshal(get(mux, "tg/history?id=7&n=10&around=15").Body.Bytes(), &mid)
	found := false
	for _, m := range mid.Messages {
		found = found || m.ID == 15
	}
	if !found {
		t.Fatalf("around 15: %+v", mid.Messages)
	}
}

func TestSearchFindsMessagesWithTheirChat(t *testing.T) {
	_, mux, fk, _ := richRig(t)
	now := time.Now()
	fk.S.Put(telegram.Message{ID: 1, ChatID: 1, Date: now, Text: "купить молоко"}, &telegram.Chat{ID: 1, Title: "Дом"})
	fk.S.Put(telegram.Message{ID: 1, ChatID: 2, Date: now, Text: "молоко кончилось"}, &telegram.Chat{ID: 2, Title: "Магазин"})
	var res struct {
		Messages []tgMsg `json:"messages"`
	}
	json.Unmarshal(get(mux, "tg/search?q=молоко").Body.Bytes(), &res)
	if len(res.Messages) != 2 || res.Messages[0].ChatTitle == "" || res.Messages[0].Chat == 0 {
		t.Fatalf("all chats: %+v", res.Messages)
	}
	json.Unmarshal(get(mux, "tg/search?q=молоко&chat=2").Body.Bytes(), &res)
	if len(res.Messages) != 1 || res.Messages[0].ChatTitle != "Магазин" {
		t.Fatalf("one chat: %+v", res.Messages)
	}
	if w := get(mux, "tg/search"); w.Code != 400 {
		t.Fatalf("empty query: %d", w.Code)
	}
}

func TestMediaIsServedByItsBytesAndDangerousFilesOnlyAsDownloads(t *testing.T) {
	_, mux, fk, _ := richRig(t)
	chat := telegram.Chat{ID: 7, Title: "A"}
	mp4 := append([]byte{0, 0, 0, 0x18}, []byte("ftypmp42\x00\x00\x00\x00mp42isom")...)
	mp4 = append(mp4, make([]byte, 64)...)
	ogg := append([]byte("OggS\x00\x02"), make([]byte, 64)...)
	webp := append([]byte("RIFF\x24\x00\x00\x00WEBPVP8 "), make([]byte, 40)...)
	m4a := append([]byte{0, 0, 0, 0x18}, []byte("ftypM4A \x00\x00\x00\x00M4A mp42")...)
	m4a = append(m4a, make([]byte, 64)...)
	fk.Files = map[string][]byte{"m4a": m4a, "mp4": mp4, "ogg": ogg, "webp": webp, "html": []byte("<html><script>alert(1)</script></html>"), "svg": []byte(`<svg xmlns="http://www.w3.org/2000/svg" onload="alert(1)"/>`)}
	put := func(id int64, m telegram.Message) {
		m.ID, m.ChatID, m.Date = id, 7, time.Now()
		fk.S.Put(m, &chat)
	}
	put(1, telegram.Message{Media: telegram.MediaVideo, FileID: "mp4", MediaDetail: "gif"})
	put(2, telegram.Message{Media: telegram.MediaVoice, FileID: "ogg"})
	put(3, telegram.Message{Media: telegram.MediaSticker, FileID: "webp"})
	put(4, telegram.Message{Media: telegram.MediaDocument, FileID: "html", FileName: "a\"b/../c.html"})
	put(5, telegram.Message{Media: telegram.MediaVideo, FileID: "html"})
	put(6, telegram.Message{Media: telegram.MediaSticker, FileID: "svg"})
	put(7, telegram.Message{Media: telegram.MediaDocument, FileID: "mp4", FileSize: 100 << 20, FileName: "big.mp4"})
	put(8, telegram.Message{Media: telegram.MediaAudio, FileID: "m4a"})
	for id, want := range map[string]string{"1": "video/mp4", "2": "audio/ogg", "3": "image/webp", "8": "audio/mp4"} {
		w := get(mux, "tg/media?chat=7&msg="+id)
		if w.Code != 200 || w.Header().Get("Content-Type") != want || w.Header().Get("X-Content-Type-Options") != "nosniff" || !strings.Contains(w.Header().Get("Content-Security-Policy"), "sandbox") {
			t.Fatalf("msg %s: %d %v", id, w.Code, w.Header())
		}
	}
	// videos seek: Range requests are answered with 206
	rr := httptest.NewRequest("GET", "/admin/api/tg/media?chat=7&msg=1", nil)
	rr.Header.Set("Authorization", "Bearer "+tok)
	rr.Header.Set("Range", "bytes=0-9")
	rw := httptest.NewRecorder()
	mux.ServeHTTP(rw, rr)
	if rw.Code != 206 || rw.Body.Len() != 10 {
		t.Fatalf("range: %d len=%d", rw.Code, rw.Body.Len())
	}
	// a document is never shown inline; as a download it is an attachment of unknown type with a safe name
	if w := get(mux, "tg/media?chat=7&msg=4"); w.Code != 404 {
		t.Fatalf("document inline: %d", w.Code)
	}
	w := get(mux, "tg/media?chat=7&msg=4&dl=1")
	cd := w.Header().Get("Content-Disposition")
	if w.Code != 200 || w.Header().Get("Content-Type") != "application/octet-stream" || !strings.HasPrefix(cd, "attachment;") || strings.ContainsAny(strings.TrimPrefix(cd, "attachment; filename*=UTF-8''"), `"/\`) {
		t.Fatalf("download: %d %v", w.Code, w.Header())
	}
	// html or svg pretending to be a video or sticker is refused
	for _, id := range []string{"5", "6"} {
		if w := get(mux, "tg/media?chat=7&msg="+id); w.Code != 415 {
			t.Fatalf("msg %s pretending: %d %v", id, w.Code, w.Header())
		}
	}
	if w := get(mux, "tg/media?chat=7&msg=7&dl=1"); w.Code != 413 {
		t.Fatalf("too large: %d", w.Code)
	}
}

type noter struct {
	ctl
	chat int64
	text string
}

func (n *noter) NoteOwnerAction(chat int64, text string) { n.chat, n.text = chat, text }

func post(mux http.Handler, path, body string) *httptest.ResponseRecorder {
	return do(mux, "POST", "/admin/api/"+path, body, auth)
}

func TestTakeoverIsOffByDefaultNeedsConfirmAndTellsHer(t *testing.T) {
	p, mux, fk, cp := richRig(t)
	n := &noter{}
	p.Ctl = n
	feed := &live.Feed{}
	p.Feed = feed
	chat := telegram.Chat{ID: 7, Title: "Алина", Kind: telegram.ChatPrivate}
	fk.S.Put(telegram.Message{ID: 1, ChatID: 7, SenderID: 7, Date: time.Now(), Text: "привет",
		Buttons: [][]telegram.Button{{{Text: "Да", Kind: "callback", Data: "eWVz"}}}}, &chat)
	fk.Rich.Answer = telegram.ButtonAnswer{Text: "принято", Alert: true}

	if w := do(mux, "POST", "/admin/api/tg/send", `{"chat":7,"text":"x","confirm":true}`, nil); w.Code != 401 {
		t.Fatalf("without login: %d", w.Code)
	}
	if w := do(mux, "POST", "/admin/api/tg/send", `{"chat":7,"text":"x","confirm":true}`, map[string]string{"Authorization": "Bearer " + tok}); w.Code != 403 {
		t.Fatalf("without X-Admin: %d", w.Code)
	}
	for _, path := range []string{"tg/send", "tg/react", "tg/press", "tg/edit", "tg/delete", "tg/pin", "tg/vote", "tg/read", "tg/mute"} {
		if w := post(mux, path, `{"chat":7,"msg":1,"text":"x","emoji":"👍","confirm":true}`); w.Code != 403 || !strings.Contains(w.Body.String(), "panel_takeover") {
			t.Fatalf("%s must be off by default: %d %s", path, w.Code, w.Body.String())
		}
	}
	if len(fk.Sent) != 0 {
		t.Fatal("something was sent while take-over was off")
	}
	if err := config.SetKey(cp, "misc", "panel_takeover", "true"); err != nil {
		t.Fatal(err)
	}
	h, _ := config.NewHolder(cp)
	p.Cfg = h.Get
	if w := post(mux, "tg/send", `{"chat":7,"text":"привет"}`); w.Code != 400 || len(fk.Sent) != 0 {
		t.Fatalf("no confirmation: %d", w.Code)
	}
	if w := do(mux, "GET", "/admin/api/tg/send", "", auth); w.Code != 405 {
		t.Fatalf("GET: %d", w.Code)
	}
	if w := post(mux, "tg/send", `{"chat":7,"text":"  ","confirm":true}`); w.Code != 502 {
		t.Fatalf("empty text: %d", w.Code)
	}
	w := post(mux, "tg/send", `{"chat":7,"text":"*привет*","markdown":true,"silent":true,"reply_to":1,"confirm":true}`)
	if w.Code != 200 || len(fk.Sent) != 1 || fk.Sent[0].ReplyTo != 1 || len(fk.Rich.Scheduled) != 1 || !fk.Rich.Scheduled[0].Silent {
		t.Fatalf("send: %d %s sent=%+v", w.Code, w.Body.String(), fk.Sent)
	}
	if n.chat != 7 || !strings.Contains(n.text, "написал от её имени") {
		t.Fatalf("she was not told: %+v", n)
	}
	found := false
	for _, e := range feed.Since(0) {
		found = found || (e.Kind == "owner" && e.ChatID == 7 && e.Act == "send" && strings.Contains(e.Text, "папик из панели"))
	}
	if !found {
		t.Fatalf("no feed event: %+v", feed.Since(0))
	}
	w = post(mux, "tg/press", `{"chat":7,"msg":1,"data":"eWVz","confirm":true}`)
	var ans map[string]any
	json.Unmarshal(w.Body.Bytes(), &ans)
	if w.Code != 200 || ans["answer"] != "принято" || ans["alert"] != true || len(fk.Rich.Pressed) != 1 {
		t.Fatalf("press: %d %s", w.Code, w.Body.String())
	}
	if w := post(mux, "tg/react", `{"chat":7,"msg":1,"emoji":"🔥","confirm":true}`); w.Code != 200 || fk.Reacted[1] != "🔥" {
		t.Fatalf("react: %d", w.Code)
	}
	if w := post(mux, "tg/pin", `{"chat":7,"msg":1,"pin":true,"confirm":true}`); w.Code != 200 || len(fk.Pinned[7]) != 1 {
		t.Fatalf("pin: %d", w.Code)
	}
	if w := post(mux, "tg/mute", `{"chat":7,"muted":true,"confirm":true}`); w.Code != 200 {
		t.Fatalf("mute: %d", w.Code)
	}
	if c, _ := fk.Chat(nil, 7); !c.Muted {
		t.Fatal("not muted")
	}
	if w := post(mux, "tg/delete", `{"chat":7,"msg":1,"confirm":true}`); w.Code != 200 {
		t.Fatalf("delete: %d", w.Code)
	}
	if w := post(mux, "tg/send", `{"text":"x","confirm":true}`); w.Code != 400 {
		t.Fatalf("no chat: %d", w.Code)
	}
	// the rate is limited
	takeLimit.Lock()
	takeLimit.at = nil
	for i := 0; i < 40; i++ {
		takeLimit.at = append(takeLimit.at, time.Now())
	}
	takeLimit.Unlock()
	if w := post(mux, "tg/send", `{"chat":7,"text":"ещё","confirm":true}`); w.Code != 429 {
		t.Fatalf("rate limit: %d", w.Code)
	}
	takeLimit.Lock()
	takeLimit.at = nil
	takeLimit.Unlock()
}
