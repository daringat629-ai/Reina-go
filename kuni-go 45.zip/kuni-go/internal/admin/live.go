package admin

import (
	"net/http"
	"strconv"
)

// liveFrame serves the current picture of her browser or desktop (JPEG, never cached); 204 when that screen is not running.
func (p *Panel) liveFrame(w http.ResponseWriter, r *http.Request) {
	if p.Frame == nil {
		http.Error(w, "live view is off", http.StatusNotFound)
		return
	}
	src := r.URL.Query().Get("src")
	if src != "desktop" && src != "browser" {
		http.Error(w, "src must be desktop or browser", http.StatusBadRequest)
		return
	}
	data, meta, ok, err := p.Frame(r.Context(), src)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadGateway)
		return
	}
	if !ok {
		w.WriteHeader(http.StatusNoContent)
		return
	}
	w.Header().Set("Content-Type", "image/jpeg")
	w.Header().Set("Cache-Control", "no-store")
	if meta != "" {
		w.Header().Set("X-Pointer", meta)
	}
	_, _ = w.Write(data)
}

// liveEvents returns the feed since an id and which screens are up.
func (p *Panel) liveEvents(w http.ResponseWriter, r *http.Request) {
	since, _ := strconv.ParseInt(r.URL.Query().Get("since"), 10, 64)
	out := map[string]any{"events": []any{}, "last": int64(0), "browser": false, "desktop": false, "paused": false}
	if p.Feed != nil {
		if evs := p.Feed.Since(since); len(evs) > 0 {
			out["events"] = evs
		}
		out["last"] = p.Feed.Last()
	}
	if p.Screens != nil {
		out["browser"], out["desktop"] = p.Screens()
	}
	if p.Ctl != nil {
		out["paused"] = p.Ctl.Paused()
	}
	writeJSON(w, out)
}
