package telegram

import (
	"context"
	"errors"
	"strings"
)

// markdownText turns a markdown text into a formattedText with tdlib's own parser. If the parser refuses
// (an unbalanced asterisk), the text is sent as it is: a message with stray symbols beats no message.
func (c *TDClient) markdownText(ctx context.Context, text string) obj {
	r, err := c.api(ctx, obj{"@type": "parseTextEntities", "text": text, "parse_mode": obj{"@type": "textParseModeMarkdown", "version": 1}})
	if err != nil || typ(r) != "formattedText" {
		return withMentions(text)
	}
	return r
}

func (c *TDClient) SendWith(ctx context.Context, chatID int64, text string, o SendOptions) (Message, error) {
	var ft obj
	if o.Markdown {
		ft = c.markdownText(ctx, text)
	} else {
		ft = withMentions(text)
	}
	var opts obj
	if o.Silent || !o.At.IsZero() {
		opts = obj{"@type": "messageSendOptions", "disable_notification": o.Silent}
		if !o.At.IsZero() {
			opts["scheduling_state"] = obj{"@type": "messageSchedulingStateSendAtDate", "send_date": o.At.Unix()}
		}
	}
	return c.sendWith(ctx, chatID, o.ReplyTo, obj{"@type": "inputMessageText", "text": ft}, opts)
}

func (c *TDClient) EditFormatted(ctx context.Context, chatID, msgID int64, text string, markdown bool) error {
	ft := formatted(text)
	if markdown {
		ft = c.markdownText(ctx, text)
	}
	m, err := c.api(ctx, obj{"@type": "getMessage", "chat_id": chatID, "message_id": msgID})
	if err != nil {
		return err
	}
	if typ(sub(m, "content")) == "messageText" {
		_, err = c.call(ctx, obj{"@type": "editMessageText", "chat_id": chatID, "message_id": msgID,
			"input_message_content": obj{"@type": "inputMessageText", "text": ft}})
	} else {
		_, err = c.call(ctx, obj{"@type": "editMessageCaption", "chat_id": chatID, "message_id": msgID, "caption": ft})
	}
	return err
}

func (c *TDClient) SendDice(ctx context.Context, chatID int64, emoji string, reply int64) (Message, error) {
	if emoji == "" {
		emoji = "🎲"
	}
	return c.send(ctx, chatID, reply, obj{"@type": "inputMessageDice", "emoji": emoji, "clear_draft": false})
}

func (c *TDClient) SendLocation(ctx context.Context, chatID int64, lat, lon float64, reply int64) (Message, error) {
	if lat < -90 || lat > 90 || lon < -180 || lon > 180 {
		return Message{}, errors.New("coordinates out of range")
	}
	return c.send(ctx, chatID, reply, obj{"@type": "inputMessageLocation", "live_period": 0,
		"location": obj{"@type": "location", "latitude": lat, "longitude": lon}})
}

func (c *TDClient) PressButton(ctx context.Context, chatID, msgID int64, data string) (ButtonAnswer, error) {
	r, err := c.api(ctx, obj{"@type": "getCallbackQueryAnswer", "chat_id": chatID, "message_id": msgID,
		"payload": obj{"@type": "callbackQueryPayloadData", "data": data}})
	if err != nil {
		return ButtonAnswer{}, err
	}
	return ButtonAnswer{Text: str(r, "text"), Alert: r["show_alert"] == true, URL: str(r, "url")}, nil
}

func (c *TDClient) SetMuted(ctx context.Context, chatID int64, muted bool) error {
	mute := 0
	if muted {
		mute = 366 * 24 * 3600 // "forever" in the app is a bit over a year
	}
	_, err := c.api(ctx, obj{"@type": "setChatNotificationSettings", "chat_id": chatID, "notification_settings": obj{
		"@type": "chatNotificationSettings", "use_default_mute_for": false, "mute_for": mute,
		"use_default_sound": true, "use_default_show_preview": true, "use_default_mute_stories": true, "use_default_story_sound": true,
		"use_default_show_story_poster": true, "use_default_disable_pinned_message_notifications": true, "use_default_disable_mention_notifications": true}})
	if err != nil {
		return err
	}
	c.cmu.Lock()
	if t := c.chats[chatID]; t != nil {
		t.Muted = muted
	}
	c.cmu.Unlock()
	return nil
}

func (c *TDClient) PinnedMessage(ctx context.Context, chatID int64) (Message, error) {
	r, err := c.api(ctx, obj{"@type": "getChatPinnedMessage", "chat_id": chatID})
	if err != nil {
		if strings.Contains(err.Error(), "404") {
			return Message{}, ErrNotFound
		}
		return Message{}, err
	}
	return c.parseMessage(ctx, r), nil
}

// ChatsIn lists the chats of the archive or of a folder; the main list is Chats.
func (c *TDClient) ChatsIn(ctx context.Context, l ChatList, limit int) ([]Chat, error) {
	if !l.Archive && l.Folder == 0 {
		return c.Chats(ctx, limit)
	}
	if limit <= 0 {
		limit = 50
	}
	list := obj{"@type": "chatListArchive"}
	if !l.Archive {
		list = obj{"@type": "chatListFolder", "chat_folder_id": l.Folder}
	}
	_, _ = c.api(ctx, obj{"@type": "loadChats", "chat_list": list, "limit": limit}) // a 404 means everything is loaded already
	r, err := c.api(ctx, obj{"@type": "getChats", "chat_list": list, "limit": limit})
	if err != nil {
		return nil, err
	}
	var out []Chat
	for _, idv := range arr(r, "chat_ids") {
		t, err := c.chatInfo(ctx, num(idv))
		if err != nil {
			continue
		}
		out = append(out, c.toChat(t))
	}
	return out, nil
}
