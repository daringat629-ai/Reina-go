package telegram

import "testing"

func TestSendMediaUsesTheRightContentType(t *testing.T) {
	f := newFakeTD(func(req obj) obj {
		if str(req, "@type") == "sendMessage" {
			return obj{"@type": "message", "id": 5, "chat_id": req["chat_id"], "date": 1, "content": obj{"@type": "messageText", "text": obj{"text": "x"}}}
		}
		return nil
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	cases := map[string]string{KindVideo: "inputMessageVideo", KindAnimation: "inputMessageAnimation", KindAudio: "inputMessageAudio", KindPhoto: "inputMessagePhoto", KindDocument: "inputMessageDocument"}
	i := 0
	for kind, want := range cases {
		if _, err := c.SendMedia(ctx, 5, kind, "clip.bin", []byte("data"), "подпись", 3); err != nil {
			t.Fatal(kind, err)
		}
		r := f.requests("sendMessage")[i]
		i++
		content := sub(r, "input_message_content")
		if str(content, "@type") != want || str(sub(content, "caption"), "text") != "подпись" || num(sub(r, "reply_to")["message_id"]) != 3 {
			t.Fatalf("%s: %v", kind, r)
		}
	}
	v := sub(f.requests("sendMessage")[0], "input_message_content")
	if str(v, "@type") == "inputMessageVideo" && v["supports_streaming"] != true {
		t.Fatal("video must stream")
	}
	if _, err := c.SendMedia(ctx, 5, "hologram", "x", []byte("d"), "", 0); err == nil {
		t.Fatal("unknown kind accepted")
	}
	if _, err := c.SendMedia(ctx, 5, KindVideo, "x.mp4", nil, "", 0); err == nil {
		t.Fatal("empty file accepted")
	}
}

func TestProfileReadAndChange(t *testing.T) {
	f := newFakeTD(func(req obj) obj {
		switch str(req, "@type") {
		case "getMe":
			return obj{"@type": "user", "id": 4242, "first_name": "Reina", "last_name": "Veil", "usernames": obj{"active_usernames": []any{"reina_v"}}}
		case "getUserFullInfo":
			return obj{"@type": "userFullInfo", "bio": obj{"@type": "formattedText", "text": "ядовитая"}}
		case "setName", "setBio", "setProfilePhoto":
			return obj{"@type": "ok"}
		}
		return nil
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	p, err := c.MyProfile(ctx)
	if err != nil || p.FirstName != "Reina" || p.LastName != "Veil" || p.Username != "reina_v" || p.Bio != "ядовитая" {
		t.Fatalf("%+v %v", p, err)
	}
	if err := c.SetName(ctx, "", "x"); err == nil {
		t.Fatal("empty first name accepted")
	}
	if err := c.SetName(ctx, "Рейна", ""); err != nil {
		t.Fatal(err)
	}
	if err := c.SetBio(ctx, "новое био"); err != nil {
		t.Fatal(err)
	}
	if err := c.SetProfilePhoto(ctx, []byte("jpegdata")); err != nil {
		t.Fatal(err)
	}
	if r := f.requests("setName")[0]; str(r, "first_name") != "Рейна" {
		t.Fatal(r)
	}
	if r := f.requests("setBio")[0]; str(r, "bio") != "новое био" {
		t.Fatal(r)
	}
	r := f.requests("setProfilePhoto")[0]
	ph := sub(r, "photo")
	if str(ph, "@type") != "inputChatPhotoStatic" || str(sub(ph, "photo"), "@type") != "inputFileLocal" {
		t.Fatal(r)
	}
}
