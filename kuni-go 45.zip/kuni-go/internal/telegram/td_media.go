package telegram

import (
	"context"
	"fmt"
	"path/filepath"
	"strings"
)

func (c *TDClient) SendMedia(ctx context.Context, chatID int64, kind, name string, data []byte, caption string, reply int64) (Message, error) {
	p, err := c.outboxFile(filepath.Base(name), data)
	if err != nil {
		return Message{}, err
	}
	file := obj{"@type": "inputFileLocal", "path": p}
	cap := withMentions(caption)
	switch kind {
	case KindVideo:
		return c.send(ctx, chatID, reply, obj{"@type": "inputMessageVideo", "video": file, "supports_streaming": true, "caption": cap})
	case KindAnimation:
		return c.send(ctx, chatID, reply, obj{"@type": "inputMessageAnimation", "animation": file, "caption": cap})
	case KindAudio:
		title := strings.TrimSuffix(filepath.Base(name), filepath.Ext(name))
		return c.send(ctx, chatID, reply, obj{"@type": "inputMessageAudio", "audio": file, "title": title, "caption": cap})
	case KindPhoto:
		return c.send(ctx, chatID, reply, obj{"@type": "inputMessagePhoto", "photo": file, "caption": cap})
	case KindDocument, "":
		return c.send(ctx, chatID, reply, obj{"@type": "inputMessageDocument", "document": file, "caption": cap})
	}
	return Message{}, fmt.Errorf("unknown media kind %q", kind)
}

func (c *TDClient) MyProfile(ctx context.Context) (Profile, error) {
	me, err := c.api(ctx, obj{"@type": "getMe"})
	if err != nil {
		return Profile{}, err
	}
	p := Profile{FirstName: str(me, "first_name"), LastName: str(me, "last_name"), Username: str(me, "username")}
	if names := arr(sub(me, "usernames"), "active_usernames"); len(names) > 0 {
		p.Username, _ = names[0].(string)
	}
	if full, err := c.api(ctx, obj{"@type": "getUserFullInfo", "user_id": c.MyID()}); err == nil {
		if b := sub(full, "bio"); b != nil { // newer tdlib: formattedText; older: a plain string
			p.Bio = str(b, "text")
		}
		if p.Bio == "" {
			p.Bio = str(full, "bio")
		}
	}
	return p, nil
}

func (c *TDClient) SetName(ctx context.Context, first, last string) error {
	if strings.TrimSpace(first) == "" {
		return fmt.Errorf("the first name cannot be empty")
	}
	_, err := c.call(ctx, obj{"@type": "setName", "first_name": first, "last_name": last})
	return err
}

func (c *TDClient) SetBio(ctx context.Context, bio string) error {
	_, err := c.call(ctx, obj{"@type": "setBio", "bio": bio})
	return err
}

func (c *TDClient) SetProfilePhoto(ctx context.Context, data []byte) error {
	p, err := c.outboxFile("avatar.jpg", data)
	if err != nil {
		return err
	}
	_, err = c.call(ctx, obj{"@type": "setProfilePhoto", "photo": obj{"@type": "inputChatPhotoStatic", "photo": obj{"@type": "inputFileLocal", "path": p}}, "is_public": false})
	return err
}
