package alerts

import (
	"testing"
	"time"
)

func TestGateReportsOnceAndAgain(t *testing.T) {
	var g Gate
	t0 := time.Now()
	if !g.Allow("disk", time.Hour, t0) {
		t.Fatal("first message must pass")
	}
	if g.Allow("disk", time.Hour, t0.Add(10*time.Minute)) {
		t.Fatal("the same problem within the hour must stay quiet")
	}
	if !g.Allow("other", time.Hour, t0.Add(10*time.Minute)) {
		t.Fatal("a different problem is independent")
	}
	if !g.Allow("disk", time.Hour, t0.Add(61*time.Minute)) {
		t.Fatal("after the interval it may be repeated")
	}
}

func TestStreakTripsOnceAndNoticesRecovery(t *testing.T) {
	s := &Streak{Threshold: 3}
	if s.OK() {
		t.Fatal("recovery without an alert is not news")
	}
	trips := 0
	for i := 0; i < 7; i++ {
		if s.Fail() {
			trips++
		}
	}
	if trips != 1 || s.Count() != 7 {
		t.Fatalf("trips=%d count=%d", trips, s.Count())
	}
	if !s.OK() {
		t.Fatal("the first success after an alert must say recovered")
	}
	if s.OK() {
		t.Fatal("and only once")
	}
	s.Fail()
	s.Fail()
	s.OK() // a success resets the streak
	if s.Fail() || s.Fail() {
		t.Fatal("two failures after a reset are below the threshold")
	}
}
