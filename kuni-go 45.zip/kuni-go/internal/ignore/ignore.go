// Package ignore is her "do not react to this one" list: whole chats and single people (by Telegram id), forever or for a while.
// An ignored chat or person never wakes the model: no reading, no tokens, no answer.
package ignore

import (
	"encoding/json"
	"os"
	"path/filepath"
	"sort"
	"sync"
	"time"
)

// Entry is one ignored chat or person.
type Entry struct {
	Kind  string    `json:"kind"` // chat | user
	ID    int64     `json:"id"`
	Name  string    `json:"name,omitempty"`
	Note  string    `json:"note,omitempty"`  // why
	Until time.Time `json:"until,omitempty"` // zero = until removed
	Added time.Time `json:"added"`
}

// Store keeps the list in a JSON file; a nil *Store ignores nobody.
type Store struct {
	mu      sync.Mutex
	path    string
	Entries []Entry `json:"entries"`
}

// New loads the list (a missing or broken file is an empty list).
func New(path string) *Store {
	s := &Store{path: path}
	if raw, err := os.ReadFile(path); err == nil {
		_ = json.Unmarshal(raw, s)
	}
	return s
}

func (s *Store) save() {
	if s.path == "" {
		return
	}
	raw, _ := json.MarshalIndent(s, "", " ")
	_ = os.MkdirAll(filepath.Dir(s.path), 0o755)
	tmp := s.path + ".tmp"
	if os.WriteFile(tmp, raw, 0o644) == nil {
		_ = os.Rename(tmp, s.path)
	}
}

// prune drops expired entries; the caller holds the lock.
func (s *Store) prune(now time.Time) {
	kept := s.Entries[:0]
	for _, e := range s.Entries {
		if e.Until.IsZero() || now.Before(e.Until) {
			kept = append(kept, e)
		}
	}
	if len(kept) != len(s.Entries) {
		s.Entries = kept
		s.save()
	}
}

// Add ignores a chat or a person; d <= 0 means until removed. Ignoring the same one again only changes the term.
func (s *Store) Add(kind string, id int64, name, note string, d time.Duration) Entry {
	s.mu.Lock()
	defer s.mu.Unlock()
	now := time.Now()
	s.prune(now)
	e := Entry{Kind: kind, ID: id, Name: name, Note: note, Added: now}
	if d > 0 {
		e.Until = now.Add(d)
	}
	for i, old := range s.Entries {
		if old.Kind == kind && old.ID == id {
			if e.Name == "" {
				e.Name = old.Name
			}
			s.Entries[i] = e
			s.save()
			return e
		}
	}
	s.Entries = append(s.Entries, e)
	s.save()
	return e
}

// Remove stops ignoring; false = it was not on the list.
func (s *Store) Remove(kind string, id int64) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	for i, e := range s.Entries {
		if e.Kind == kind && e.ID == id {
			s.Entries = append(s.Entries[:i], s.Entries[i+1:]...)
			s.save()
			return true
		}
	}
	return false
}

// List is the current entries, soonest-added first.
func (s *Store) List() []Entry {
	if s == nil {
		return nil
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	s.prune(time.Now())
	out := append([]Entry(nil), s.Entries...)
	sort.Slice(out, func(i, j int) bool { return out[i].Added.Before(out[j].Added) })
	return out
}

// Chat says whether the whole chat is ignored.
func (s *Store) Chat(chatID int64) bool { return s.has("chat", chatID) }

// User says whether one person is ignored (in any chat).
func (s *Store) User(userID int64) bool { return userID != 0 && s.has("user", userID) }

func (s *Store) has(kind string, id int64) bool {
	if s == nil {
		return false
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	now := time.Now()
	for _, e := range s.Entries {
		if e.Kind == kind && e.ID == id && (e.Until.IsZero() || now.Before(e.Until)) {
			return true
		}
	}
	return false
}
