package agent

import (
	"context"
	"fmt"
	"log"
	"strings"
	"time"
	"unicode/utf8"

	"kuni/internal/llm"
	"kuni/internal/reminders"
	"kuni/internal/telegram"
)

const learnSystem = "You keep a short file about one person you chat with. You only write facts that will still matter weeks from now."

const learnAsk = `Above is your conversation with this person. Answer in lines of three kinds, and nothing else:
"- fact": a NEW lasting fact about them (job, interests, plans, how they like to be talked to, important people in their life). At most 120 characters, in the language they speak.
"~ part of the old fact => corrected fact": when something they said replaces a known fact (they moved, changed jobs, quit something).
"@ when | what": something YOU promised to do or say later and have not done yet. when is like 30m, 3h, tomorrow 10:00 (24-hour clock). Only concrete promises.
Skip small talk, passing moods and anything already known. At most 3 fact lines (new or corrected) and 2 promise lines. If there is nothing, answer exactly: NONE.

Now: %s
Known facts:
`

// learned is what the model took from a finished conversation.
type learned struct {
	Facts    []string
	Changes  []change
	Promises []promise
}

type change struct{ Old, New string }
type promise struct{ When, What string }

// parseLearned reads the three kinds of lines (see learnAsk). NONE and noise give nothing.
func parseLearned(s string) learned {
	var out learned
	for _, line := range strings.Split(s, "\n") {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		first, size := utf8.DecodeRuneInString(line)
		switch first {
		case '-', '•':
			if f := strings.TrimSpace(strings.TrimLeft(line, "-•* ")); len([]rune(f)) >= 4 && len(out.Facts)+len(out.Changes) < 3 {
				out.Facts = append(out.Facts, f)
			}
		case '~':
			parts := strings.SplitN(strings.TrimSpace(line[size:]), "=>", 2)
			if len(parts) == 2 && len(out.Facts)+len(out.Changes) < 3 {
				o, n := strings.TrimSpace(parts[0]), strings.TrimSpace(parts[1])
				if len([]rune(o)) >= 3 && len([]rune(n)) >= 4 {
					out.Changes = append(out.Changes, change{o, n})
				}
			}
		case '@':
			parts := strings.SplitN(strings.TrimSpace(line[size:]), "|", 2)
			if len(parts) == 2 && len(out.Promises) < 2 {
				w, t := strings.TrimSpace(parts[0]), strings.TrimSpace(parts[1])
				if w != "" && len([]rune(t)) >= 4 {
					out.Promises = append(out.Promises, promise{w, t})
				}
			}
		}
	}
	return out
}

// learnPerson runs once when a private conversation is closed: one short light-model request that files lasting facts on
// the person's card (private, because they were told in private), corrects facts that went out of date and turns her own
// promises into reminders. Anything that is switched off or has no store is simply skipped.
func (a *Agent) learnPerson(ctx context.Context, s *session, msgs []llm.Message) {
	cfg := a.Cfg.Get()
	cards := cfg.AutoPersonCards && a.Deps.People != nil
	promises := cfg.AutoPromises && a.Deps.Reminders != nil
	if !(cards || promises) || s.id == 0 || s.chat.Kind != telegram.ChatPrivate {
		return
	}
	users := 0
	for _, m := range msgs {
		if m.Role == "user" {
			users++
		}
	}
	if users < 2 {
		return
	}
	known := "(none yet)"
	if a.Deps.People != nil {
		if k := a.Deps.People.Get(s.id).Render(true); k != "" {
			known = k
		}
	}
	loc := a.location()
	now := time.Now()
	view := fitBudget(slimHistory(trim(msgs, 80), 200), 8000)
	ask := append(append([]llm.Message(nil), view...), llm.Message{Role: "user", Content: fmt.Sprintf(learnAsk, now.In(loc).Format("Mon 2006-01-02 15:04")) + known})
	c, cancel := context.WithTimeout(context.WithoutCancel(ctx), 60*time.Second)
	defer cancel()
	out, err := a.LLM.Chat(llm.WithChat(llm.WithPurpose(c, "people"), s.id), learnSystem, ask)
	if err != nil {
		log.Printf("agent: learning from chat %d: %v", s.id, err)
		return
	}
	l := parseLearned(out)
	nf := 0
	if cards {
		for _, f := range l.Facts {
			if a.Deps.People.Add(s.id, s.chat.Title, f, true, now) == nil {
				nf++
			}
		}
		for _, ch := range l.Changes {
			if _, err := a.Deps.People.Supersede(s.id, s.chat.Title, ch.Old, ch.New, true, now); err == nil {
				nf++
			}
		}
	}
	if nf > 0 {
		a.maybeDescribe(s.id)
	}
	np := 0
	if promises {
		for _, p := range l.Promises {
			at, err := reminders.ParseWhen(p.When, now, loc)
			if err != nil || at.Before(now.Add(time.Minute)) || at.After(now.Add(30*24*time.Hour)) {
				continue
			}
			if dup(a.Deps.Reminders.List(s.id), p.What) {
				continue
			}
			if _, err := a.Deps.Reminders.Add(at, s.id, "You promised: "+p.What, now); err == nil {
				np++
			}
		}
	}
	if nf+np > 0 {
		log.Printf("agent: from the talk with %s: %d fact(s), %d promise(s)", s.chat.Title, nf, np)
	}
}

// dup says whether a pending reminder of the chat already holds this promise.
func dup(items []reminders.Item, what string) bool {
	w := strings.ToLower(strings.TrimSpace(what))
	for _, it := range items {
		if strings.Contains(strings.ToLower(it.Text), w) {
			return true
		}
	}
	return false
}
