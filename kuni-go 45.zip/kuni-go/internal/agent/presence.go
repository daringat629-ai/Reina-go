package agent

import (
	"context"
	"log"
	"math/rand"
	"time"

	"kuni/internal/telegram"
	"kuni/internal/tools"
)

// presenceIn is everything that decides how quickly she notices a message.
type presenceIn struct {
	Owner      bool          // the owner's private chat: always quick, never postponed
	Group      bool          // groups are noticed more slowly
	Asleep     bool          // she went to sleep (go_to_sleep)
	Night      bool          // quiet hours
	SinceLast  time.Duration // time since the last turn in this chat; a live conversation needs no warm-up
	ReadMin    time.Duration
	ReadMax    time.Duration
	LateChance float64 // 0..1, applied at night
	LateMin    time.Duration
	LateMax    time.Duration
	SlowChance float64 // 0..1: she was busy and notices this one much later
}

type presencePlan struct {
	Late time.Duration // >0: do not look at the chat for this long (messages stay unread)
	Read time.Duration // pause before opening the chat
}

// planPresence is pure (rnd injected) so it can be tested.
func planPresence(in presenceIn, rnd func() float64) presencePlan {
	span := func(lo, hi time.Duration) time.Duration {
		if hi <= lo {
			return lo
		}
		return lo + time.Duration(rnd()*float64(hi-lo))
	}
	if in.Owner {
		p := presencePlan{Read: span(0, 1500*time.Millisecond)}
		if in.SlowChance > 0 && rnd() < in.SlowChance && in.SinceLast > 90*time.Second {
			p.Read = span(15*time.Second, 55*time.Second) // busy for a moment; never minutes for him
		}
		return p
	}
	var p presencePlan
	if in.Asleep || (in.Night && rnd() < in.LateChance) {
		p.Late = span(in.LateMin, in.LateMax)
	} else if in.SlowChance > 0 && in.SinceLast > 90*time.Second && rnd() < in.SlowChance {
		p.Late = span(2*time.Minute, 12*time.Minute) // a busy moment in the middle of the day
	}
	read := span(in.ReadMin, in.ReadMax)
	if in.Group {
		read += span(in.ReadMin, in.ReadMax) // groups: notice later
	}
	if in.SinceLast > 0 && in.SinceLast < 90*time.Second {
		read /= 4 // already talking
	}
	p.Read = read
	return p
}

func (a *Agent) presenceFor(chat telegram.Chat, s *session, now time.Time) presencePlan {
	cfg := a.Cfg.Get()
	if !cfg.PresenceEnabled {
		return presencePlan{}
	}
	in := presenceIn{
		Owner:      tools.IsOwnerChat(a.Deps, chat.ID) || (cfg.PapikChatID != 0 && chat.ID == cfg.PapikChatID),
		Group:      chat.Kind != telegram.ChatPrivate,
		Night:      a.isNight(now),
		ReadMin:    time.Duration(cfg.ReadDelayMin) * time.Second,
		ReadMax:    time.Duration(cfg.ReadDelayMax) * time.Second,
		LateChance: float64(cfg.LateReplyPercent) / 100,
		LateMin:    time.Duration(cfg.LateReplyMinMins) * time.Minute,
		LateMax:    time.Duration(cfg.LateReplyMaxMins) * time.Minute,
		SlowChance: float64(cfg.SlowPercent) / 100,
	}
	if a.Auto != nil && cfg.AutonomyEnabled {
		in.Asleep, _ = a.Auto.Asleep()
	}
	if !s.last.IsZero() {
		in.SinceLast = now.Sub(s.last)
	}
	return planPresence(in, rand.Float64)
}

// postponed reports whether a late reply is pending for the chat; its timer (re)starts HandleChat.
func (a *Agent) postponedUntil(chatID int64) (time.Time, bool) {
	a.mu.Lock()
	defer a.mu.Unlock()
	t, ok := a.later[chatID]
	return t, ok
}

// postpone holds the chat back for d and handles it afterwards (the deferral is then used up).
func (a *Agent) postpone(ctx context.Context, chatID int64, d time.Duration) {
	a.mu.Lock()
	until := time.Now().Add(d)
	a.later[chatID] = until
	a.setPhaseLocked(chatID, "late", until)
	if t, ok := a.timers[chatID]; ok {
		t.Stop()
	}
	a.timers[chatID] = time.AfterFunc(d, func() {
		if ctx.Err() != nil {
			return
		}
		a.mu.Lock()
		delete(a.later, chatID)
		a.used[chatID] = true // do not postpone the same messages twice
		a.mu.Unlock()
		a.setPhase(chatID, "waiting", time.Time{})
		defer a.endPhase(chatID)
		defer func() {
			if r := recover(); r != nil {
				log.Printf("agent: chat %d: PANIC recovered: %v", chatID, r)
			}
		}()
		if err := a.HandleChat(ctx, chatID); err != nil {
			log.Printf("agent: chat %d: %v", chatID, err)
		}
	})
	a.mu.Unlock()
	a.Metrics.Inc("kuni_presence_late_replies_total", 1, nil)
	log.Printf("agent: chat %d: will look at it in %s (late reply)", chatID, d.Round(time.Second))
}

// takeUsed reports (and clears) that the chat was already postponed once for the current messages.
func (a *Agent) takeUsed(chatID int64) bool {
	a.mu.Lock()
	defer a.mu.Unlock()
	u := a.used[chatID]
	delete(a.used, chatID)
	return u
}

// readPause waits before the chat is opened. false = interrupted.
func (a *Agent) readPause(ctx context.Context, d time.Duration) bool {
	if d <= 0 {
		return true
	}
	select {
	case <-time.After(d):
		return true
	case <-ctx.Done():
		return false
	}
}

func (a *Agent) beginNoticing(chatID int64) bool {
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.noticing[chatID] {
		return false
	}
	a.noticing[chatID] = true
	return true
}

func (a *Agent) endNoticing(chatID int64) {
	a.mu.Lock()
	delete(a.noticing, chatID)
	a.mu.Unlock()
}

// offlineAfter is how long the account stays "online" after the last turn.
func (a *Agent) offlineAfter() time.Duration {
	if s := a.Cfg.Get().OfflineAfterSecs; s > 0 {
		return time.Duration(s) * time.Second
	}
	return 20 * time.Second
}
