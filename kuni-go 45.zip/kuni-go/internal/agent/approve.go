package agent

import (
	"context"
	"fmt"
	"log"
	"sort"
	"strconv"
	"strings"
	"time"

	"kuni/internal/tools"
)

// Risky actions wait for the owner: she asks, he answers /yes N or /no N, and only then the action runs. The pending
// requests live in memory (a restart forgets them, which is the safe way to forget).

const approvalTTL = 30 * time.Minute

type pending struct {
	id   int
	tool string
	args string
	why  string
	chat int64
	at   time.Time
	run  func(ctx context.Context) string
}

// riskOf: the call needs the owner's yes (and the switch is on).
func (a *Agent) riskOf(name, args string) string {
	cfg := a.Cfg.Get()
	if !cfg.ConfirmRisky || cfg.PapikChatID == 0 {
		return ""
	}
	return tools.RiskOf(name, args, cfg.PapikChatID)
}

// requestApproval parks the call, tells the owner, and returns what the model sees instead of a result.
func (a *Agent) requestApproval(ctx context.Context, s *session, name, args, why string, run func(context.Context) string) string {
	cfg := a.Cfg.Get()
	a.mu.Lock()
	if a.appr == nil {
		a.appr = map[int]*pending{}
	}
	a.apprNext++
	p := &pending{id: a.apprNext, tool: name, args: args, why: why, chat: s.id, at: time.Now(), run: run}
	if s.id == 0 {
		p.chat = cfg.PapikChatID
	}
	a.appr[p.id] = p
	a.mu.Unlock()
	msg := fmt.Sprintf("⚠️ Нужно твоё да: %s.\n#%d %s %s\n/yes %d выполнить, /no %d отменить (%d мин)", why, p.id, name, oneLine(args, 140), p.id, p.id, int(approvalTTL.Minutes()))
	if _, err := a.TG.SendText(ctx, cfg.PapikChatID, msg, 0); err != nil {
		log.Printf("agent: approval #%d: %v", p.id, err)
	}
	return fmt.Sprintf("NOT executed yet: this is %s, so the owner has to confirm it (request #%d was sent to him in the chat). Do not call it again. Tell him in one short line what you want to do and why, then wait: when he says yes the program runs it by itself and you will be told the result; if he says no, drop it.", why, p.id)
}

// approve answers /yes and /no: id empty = the only pending request.
func (a *Agent) approve(ctx context.Context, arg string, yes bool) string {
	a.mu.Lock()
	for id, p := range a.appr {
		if time.Since(p.at) > approvalTTL {
			delete(a.appr, id)
		}
	}
	var p *pending
	arg = strings.TrimPrefix(strings.TrimSpace(arg), "#")
	switch {
	case arg == "" && len(a.appr) == 1:
		for _, only := range a.appr {
			p = only
		}
	case arg == "" && len(a.appr) > 1:
		a.mu.Unlock()
		return "Ждёт несколько запросов: " + a.pendingList() + "\nУкажи номер: /yes N или /no N."
	case arg != "":
		if id, err := strconv.Atoi(arg); err == nil {
			p = a.appr[id]
		}
	}
	if p == nil {
		a.mu.Unlock()
		return "Такого запроса нет (мог истечь за " + strconv.Itoa(int(approvalTTL.Minutes())) + " мин или бот перезапускался)."
	}
	delete(a.appr, p.id)
	a.mu.Unlock()
	cfg := a.Cfg.Get()
	chat := p.chat
	if chat == 0 {
		chat = cfg.PapikChatID
	}
	if !yes {
		go a.wakeAbout(chat, fmt.Sprintf("<approval>The owner DECLINED request #%d (%s %s). Do not do it and do not ask again; acknowledge in a few words.</approval>", p.id, p.tool, oneLine(p.args, 100)))
		return fmt.Sprintf("Отменено #%d.", p.id)
	}
	out := p.run(ctx)
	go a.wakeAbout(chat, fmt.Sprintf("<approval>The owner CONFIRMED request #%d (%s) and it was executed. Result:\n%s\nTell him how it went.</approval>", p.id, p.tool, oneLine(out, 1500)))
	return fmt.Sprintf("✅ #%d выполнено.", p.id)
}

func (a *Agent) wakeAbout(chat int64, text string) {
	if err := a.Wake(a.wakeCtx(), chat, text); err != nil {
		log.Printf("agent: wake after approval: %v", err)
	}
}

// pendingList describes the waiting requests (the lock is NOT held by the caller of pendingText).
func (a *Agent) pendingList() string {
	var ids []int
	for id := range a.appr {
		ids = append(ids, id)
	}
	sort.Ints(ids)
	var parts []string
	for _, id := range ids {
		p := a.appr[id]
		parts = append(parts, fmt.Sprintf("#%d %s (%s)", p.id, p.tool, p.why))
	}
	return strings.Join(parts, "; ")
}

func (a *Agent) pendingText() string {
	a.mu.Lock()
	defer a.mu.Unlock()
	for id, p := range a.appr {
		if time.Since(p.at) > approvalTTL {
			delete(a.appr, id)
		}
	}
	if len(a.appr) == 0 {
		return "Ничего не ждёт твоего ответа."
	}
	return "Ждут ответа: " + a.pendingList() + "\n/yes N или /no N."
}
