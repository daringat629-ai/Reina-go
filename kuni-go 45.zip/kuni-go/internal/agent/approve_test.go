package agent

import (
	"context"
	"strings"
	"testing"
	"time"
)

func TestApprovalYesRunsNoDrops(t *testing.T) {
	f := newFakeLLM(t, sendCall)
	r := newRig(t, f)
	cfg := r.ag.Cfg.Get()
	cfg.PapikChatID = 100
	cfg.ConfirmRisky = true
	ctx := context.Background()

	if r.ag.riskOf("shell", `{"command":"ls"}`) != "" {
		t.Fatal("ls is routine")
	}
	if r.ag.riskOf("shell", `{"command":"rm -rf x"}`) == "" {
		t.Fatal("rm -rf must be risky")
	}
	cfg.ConfirmRisky = false
	if r.ag.riskOf("shell", `{"command":"rm -rf x"}`) != "" {
		t.Fatal("switch off")
	}
	cfg.ConfirmRisky = true

	s := &session{id: 100}
	ran := 0
	msg := r.ag.requestApproval(ctx, s, "shell", `{"command":"rm -rf x"}`, "deleting", func(context.Context) string { ran++; return "done" })
	if !strings.Contains(msg, "NOT executed") || ran != 0 {
		t.Fatalf("must wait: %q ran=%d", msg, ran)
	}
	if !strings.Contains(r.ag.pendingText(), "#1") {
		t.Fatal("pending list")
	}
	if got := r.ag.approve(ctx, "", true); !strings.Contains(got, "выполнено") || ran != 1 {
		t.Fatalf("yes: %q ran=%d", got, ran)
	}
	if got := r.ag.approve(ctx, "1", true); !strings.Contains(got, "нет") || ran != 1 {
		t.Fatalf("second yes must not rerun: %q", got)
	}
	r.ag.requestApproval(ctx, s, "shell", `{"command":"kill 1"}`, "killing", func(context.Context) string { ran++; return "" })
	if got := r.ag.approve(ctx, "2", false); !strings.Contains(got, "Отменено") || ran != 1 {
		t.Fatalf("no: %q ran=%d", got, ran)
	}
	r.ag.requestApproval(ctx, s, "shell", `{}`, "a", func(context.Context) string { ran++; return "" })
	r.ag.appr[3].at = time.Now().Add(-time.Hour)
	if got := r.ag.approve(ctx, "3", true); !strings.Contains(got, "нет") || ran != 1 {
		t.Fatalf("expired: %q", got)
	}
}
