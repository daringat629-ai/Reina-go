package agent

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"testing"

	"kuni/internal/browser"
	"kuni/internal/llm"
	"kuni/internal/telegram"
)

// A browsing job takes many rounds: max_tool_rounds (6 here) must not cut it, the rounds after a browser step
// run without reasoning, and the first round (a fresh message) keeps the normal one.
func TestBrowsingTurnGetsExtraRoundsAndFastReasoning(t *testing.T) {
	if browser.Find("") == "" {
		t.Skip("no chromium")
	}
	var mu sync.Mutex
	var reasoning []any
	rounds := 0
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if strings.HasSuffix(r.URL.Path, "/embeddings") {
			json.NewEncoder(w).Encode(map[string]any{"data": []any{map[string]any{"embedding": []float64{1, 0.5}}}})
			return
		}
		var req map[string]any
		_ = json.NewDecoder(r.Body).Decode(&req)
		mu.Lock()
		rounds++
		n := rounds
		reasoning = append(reasoning, req["reasoning"])
		mu.Unlock()
		call := func(name, args string) map[string]any {
			return map[string]any{"role": "assistant", "content": "next", "tool_calls": []any{map[string]any{"id": "c" + string(rune('a'+n)), "type": "function", "function": map[string]any{"name": name, "arguments": args}}}}
		}
		msg := call("browser", `{"action":"scroll","direction":"down"}`)
		if n >= 10 {
			msg = call("send_telegram_message", `{"text":"готово","photo_filename":null,"audio_filename":null,"reply_to_message_id":null}`)
		}
		json.NewEncoder(w).Encode(map[string]any{"choices": []any{map[string]any{"message": msg}}, "usage": map[string]any{"prompt_tokens": 10, "completion_tokens": 1}})
	}))
	defer srv.Close()

	f := &fakeLLM{srv: srv}
	r := newRig(t, f)
	cfg := r.ag.Cfg.Get()
	cfg.OwnerTools, cfg.BrowserEnabled, cfg.BrowserFast, cfg.BrowserNoSandbox = true, true, true, true
	cfg.BrowserSteps, cfg.BrowserIdleSecs, cfg.MaxToolRounds, cfg.StopAfterSend = 20, 60, 6, true
	cfg.ForceTools = true
	b := browser.New()
	defer b.Close()
	r.ag.Deps.Browser = b

	chat := telegram.Chat{ID: cfg.PapikChatID, Title: "Jaabir", Kind: telegram.ChatPrivate, IsMember: true}
	m := r.tg.Incoming(chat, cfg.PapikChatID, "Jaabir", "зайди в браузер и пролистай")
	s := r.ag.getSession(chat.ID)
	view, err := r.ag.renderChat(context.Background(), s, chat, []telegram.Message{m})
	if err != nil {
		t.Fatal(err)
	}
	s.msgs = append(s.msgs, llm.Message{Role: "user", Content: view})
	if err := r.ag.runTurn(context.Background(), s); err != nil {
		t.Fatal(err)
	}
	mu.Lock()
	defer mu.Unlock()
	if rounds != 10 {
		t.Fatalf("expected 9 browser rounds and the final answer, the model was asked %d times", rounds)
	}
	if reasoning[0] != nil {
		t.Fatalf("the first round keeps the normal reasoning: %v", reasoning[0])
	}
	for i, v := range reasoning[1:] {
		if m, _ := v.(map[string]any); m == nil || m["enabled"] != false {
			t.Fatalf("round %d after a browser step must run without reasoning, got %v", i+1, v)
		}
	}
	if len(r.tg.SentTexts()) != 1 {
		t.Fatalf("the report did not reach the owner: %v", r.tg.SentTexts())
	}
}
