package agent

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	"kuni/internal/tools"
	"kuni/internal/util"
)

// The action journal: what she DID (ran, wrote, sent elsewhere, scheduled, changed), kept on disk. A session's
// history is cut, summarised and thrown away; this list is what keeps her from saying "I never did that" or doing
// the same job twice. It is shown to her when a session starts and now and then in a long one, and #my_actions
// searches it.

const (
	maxActions      = 300
	actionsShown    = 12 // from this chat
	actionsShownOth = 8  // from the other chats and her own business
	actionsRefresh  = 30 * time.Minute
	actionsWindow   = 48 * time.Hour
)

type action struct {
	At    time.Time `json:"at"`
	Chat  int64     `json:"chat"`
	Title string    `json:"title,omitempty"`
	Tool  string    `json:"tool"`
	What  string    `json:"what"`
	Out   string    `json:"out,omitempty"`
	OK    bool      `json:"ok"`
}

// quietTools never go into the journal: they only look, think or wait.
var quietTools = map[string]bool{
	"wait": true, "pause": true, "skip": true, "change_mood": true, "ask": true, "open_chat": true, "my_actions": true,
	"go_to_sleep": true, "react_with_emoji": true, "typing": true, "get_telegram_chats": true,
}

func (a *Agent) actionsPath() string { return filepath.Join(a.Cfg.Get().DataDir, "actions.json") }

func (a *Agent) loadActions() {
	if a.Cfg.Get().DataDir == "" {
		return
	}
	if b, err := os.ReadFile(a.actionsPath()); err == nil {
		_ = json.Unmarshal(b, &a.acts)
	}
}

// saveActionsLocked writes the journal (a.mu held).
func (a *Agent) saveActionsLocked() {
	if a.Cfg.Get().DataDir == "" {
		return
	}
	b, err := json.Marshal(a.acts)
	if err != nil {
		return
	}
	_ = os.MkdirAll(filepath.Dir(a.actionsPath()), 0o755)
	tmp := a.actionsPath() + ".tmp"
	if os.WriteFile(tmp, b, 0o600) == nil {
		_ = os.Rename(tmp, a.actionsPath())
	}
}

// oneLine squeezes whitespace and cuts to n runes.
func oneLine(s string, n int) string { return util.Trunc(strings.Join(strings.Fields(s), " "), n) }

// noteAction puts one finished tool call into the journal.
func (a *Agent) noteAction(s *session, name, args, out string) {
	if quietTools[name] || parallelSafe[name] {
		return
	}
	title := ""
	if s != nil {
		title = s.chat.Title
	}
	var id int64
	if s != nil {
		id = s.id
	}
	what := oneLine(args, 160)
	if name == "send_telegram_message" {
		var v struct {
			Text string `json:"text"`
		}
		if json.Unmarshal([]byte(args), &v) == nil && v.Text != "" {
			what = oneLine(v.Text, 140)
		}
	}
	ok := !strings.HasPrefix(out, "Error")
	e := action{At: time.Now(), Chat: id, Title: title, Tool: name, What: what, Out: oneLine(out, 100), OK: ok}
	a.mu.Lock()
	defer a.mu.Unlock()
	a.acts = append(a.acts, e)
	if len(a.acts) > maxActions {
		a.acts = a.acts[len(a.acts)-maxActions:]
	}
	a.saveActionsLocked()
}

func formatAction(e action, now time.Time) string {
	var b strings.Builder
	fmt.Fprintf(&b, "- %s", util.TimeAgo(e.At, now))
	if e.Title != "" {
		fmt.Fprintf(&b, " in %q", e.Title)
	}
	fmt.Fprintf(&b, ": #%s %s", e.Tool, e.What)
	if !e.OK {
		b.WriteString(" -> FAILED")
	}
	if e.Out != "" {
		b.WriteString(" -> " + e.Out)
	}
	return b.String()
}

// actionsBlock is what she is reminded of when a chat is opened: her recent deeds here (not the messages she sent in
// this very chat, those are in the chat history) and elsewhere. Empty when there is nothing, or when it was shown
// recently in this session.
func (a *Agent) actionsBlock(s *session, force bool) string {
	now := time.Now()
	if !force && !s.actionsAt.IsZero() && now.Sub(s.actionsAt) < actionsRefresh {
		return ""
	}
	a.mu.Lock()
	var here, other []action
	for i := len(a.acts) - 1; i >= 0; i-- {
		e := a.acts[i]
		if now.Sub(e.At) > actionsWindow {
			break
		}
		if e.Chat == s.id {
			if e.Tool == "send_telegram_message" && e.OK {
				continue
			}
			if len(here) < actionsShown {
				here = append(here, e)
			}
		} else if len(other) < actionsShownOth {
			other = append(other, e)
		}
	}
	a.mu.Unlock()
	if len(here)+len(other) == 0 {
		return ""
	}
	s.actionsAt = now
	var b strings.Builder
	b.WriteString("<your_recent_actions>\nThings YOU did (newest first). They happened: do not deny them, do not redo them without a reason; #my_actions searches older ones.\n")
	for _, e := range here {
		b.WriteString(formatAction(e, now) + "\n")
	}
	if len(other) > 0 {
		b.WriteString("Elsewhere:\n")
		for _, e := range other {
			b.WriteString(formatAction(e, now) + "\n")
		}
	}
	b.WriteString("</your_recent_actions>\n")
	return b.String()
}

// searchActions lists journal entries matching every word of the query (any when empty), newest first.
func (a *Agent) searchActions(query string, limit int) string {
	if limit <= 0 || limit > 50 {
		limit = 15
	}
	words := strings.Fields(strings.ToLower(query))
	now := time.Now()
	a.mu.Lock()
	defer a.mu.Unlock()
	var out []string
	for i := len(a.acts) - 1; i >= 0 && len(out) < limit; i-- {
		e := a.acts[i]
		hay := strings.ToLower(e.Tool + " " + e.What + " " + e.Out + " " + e.Title)
		match := true
		for _, w := range words {
			if !strings.Contains(hay, w) {
				match = false
				break
			}
		}
		if match {
			out = append(out, formatAction(e, now))
		}
	}
	if len(out) == 0 {
		return "Nothing in your action journal matches."
	}
	return strings.Join(out, "\n")
}

// myActionsTool lets her look up what she did: by words (a tool name, a file, a chat, a command) or just the latest.
func (a *Agent) myActionsTool() tools.Tool {
	return tools.Tool{
		Name:        "my_actions",
		Description: "Your own action journal: what you actually DID (commands run, files written, messages sent to other chats, tasks scheduled, settings changed), newest first. Look here before you say you did not do something, or before you do a job again.",
		Props: []tools.Prop{
			{Name: "query", Type: "string", Nullable: true, Desc: "Words that must all appear (a tool name, a file name, a chat, a word from the command). Empty = the latest."},
			{Name: "limit", Type: "integer", Nullable: true, Desc: "How many entries (default 15, at most 50)."},
		},
		Run: func(ctx context.Context, args tools.Args) (string, error) {
			return a.searchActions(args.Str("query"), int(args.Int("limit"))), nil
		},
	}
}

// Actions is the journal for the panel: entries matching every word of query, newest first.
func (a *Agent) Actions(query string, limit int) any {
	if limit <= 0 || limit > 300 {
		limit = 60
	}
	words := strings.Fields(strings.ToLower(query))
	a.mu.Lock()
	defer a.mu.Unlock()
	out := []action{}
	for i := len(a.acts) - 1; i >= 0 && len(out) < limit; i-- {
		e := a.acts[i]
		hay := strings.ToLower(e.Tool + " " + e.What + " " + e.Out + " " + e.Title)
		match := true
		for _, w := range words {
			if !strings.Contains(hay, w) {
				match = false
				break
			}
		}
		if match {
			out = append(out, e)
		}
	}
	return out
}
