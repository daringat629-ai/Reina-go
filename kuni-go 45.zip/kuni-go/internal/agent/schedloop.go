package agent

import (
	"context"
	"fmt"
	"log"
	"time"

	"kuni/internal/sched"
)

// schedLoop runs her recurring tasks and the monitors. While she is paused nothing fires (tasks move on, alerts wait).
func (a *Agent) schedLoop(ctx context.Context) {
	if a.Deps.Sched == nil {
		return
	}
	t := time.NewTicker(30 * time.Second)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
		}
		if a.paused.Load() {
			continue
		}
		a.runSched(ctx, time.Now())
	}
}

func (a *Agent) runSched(ctx context.Context, now time.Time) {
	st := a.Deps.Sched
	for _, tk := range st.DueTasks(now) {
		tk := tk
		go func() {
			text := fmt.Sprintf("A task you were given to do regularly is due (#%d, run %d): %q. Do it now with your tools, then tell the person the result in your own words and usual tone. Keep it short; if there is nothing worth saying this time, stay silent.", tk.ID, tk.Runs+1, tk.Text)
			if err := a.Wake(ctx, tk.Chat, text); err != nil {
				log.Printf("agent: scheduled task #%d: %v", tk.ID, err)
			}
		}()
	}
	for _, al := range st.CheckDue(ctx, now, sched.DefaultCheck) {
		al := al
		go func() {
			var text string
			if al.Recovered {
				text = fmt.Sprintf("A monitor you set up reports that things are fine again (%s: %s). Tell the person briefly, in your tone.", al.Monitor.Kind, al.Detail)
			} else {
				text = fmt.Sprintf("ALERT from your monitor #%d (%s %s): %s. Tell the person right now what is wrong, in your tone, and say what you can do about it; if you can fix it yourself with your tools, offer to.", al.Monitor.ID, al.Monitor.Kind, al.Monitor.Arg, al.Detail)
			}
			if err := a.Wake(ctx, al.Monitor.Chat, text); err != nil {
				log.Printf("agent: monitor #%d: wake failed (%v), sending plain text", al.Monitor.ID, err)
				plain := "⚠️ " + al.Detail
				if al.Recovered {
					plain = "✅ " + al.Detail
				}
				if _, err := a.TG.SendText(ctx, al.Monitor.Chat, plain, 0); err != nil {
					log.Printf("agent: monitor #%d: %v", al.Monitor.ID, err)
				}
			}
		}()
	}
}
