package agent

import (
	"fmt"
	"math/rand"
	"sort"
	"time"

	"kuni/internal/config"
	"kuni/internal/telegram"
)

// QueueItem is a chat she has not answered yet and why: the panel shows these.
type QueueItem struct {
	ChatID int64     `json:"chat_id"`
	Title  string    `json:"title"`
	Phase  string    `json:"phase"` // waiting | noticing | late | thinking
	Since  time.Time `json:"since"`
	Until  time.Time `json:"until,omitempty"` // late: when she will look
}

type phaseInfo struct {
	phase string
	since time.Time
	until time.Time
}

func (a *Agent) setPhase(chatID int64, phase string, until time.Time) {
	a.mu.Lock()
	defer a.mu.Unlock()
	a.setPhaseLocked(chatID, phase, until)
}

// setPhaseLocked is setPhase for callers that hold a.mu.
func (a *Agent) setPhaseLocked(chatID int64, phase string, until time.Time) {
	if a.phases == nil {
		a.phases = map[int64]phaseInfo{}
	}
	old, ok := a.phases[chatID]
	since := time.Now()
	if ok && old.phase == phase {
		since = old.since
	}
	a.phases[chatID] = phaseInfo{phase, since, until}
}

// endPhase forgets the chat unless it is postponed (a late reply keeps its entry until it fires).
func (a *Agent) endPhase(chatID int64) {
	a.mu.Lock()
	defer a.mu.Unlock()
	if p, ok := a.phases[chatID]; ok && p.phase == "late" && time.Now().Before(p.until) {
		return
	}
	delete(a.phases, chatID)
}

// Queue lists the chats being waited for, oldest first.
func (a *Agent) Queue() []QueueItem {
	a.mu.Lock()
	defer a.mu.Unlock()
	var out []QueueItem
	for id, p := range a.phases {
		title := fmt.Sprintf("chat %d", id)
		if s := a.sessions[id]; s != nil && s.chat.Title != "" {
			title = s.chat.Title
		}
		out = append(out, QueueItem{ChatID: id, Title: title, Phase: p.phase, Since: p.since, Until: p.until})
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Since.Before(out[j].Since) })
	return out
}

// QueueInfo is the panel's view: her queue plus the state of the Telegram connection.
func (a *Agent) QueueInfo() any {
	info := struct {
		Items    []QueueItem     `json:"items"`
		Telegram telegram.Health `json:"telegram"`
	}{Items: a.Queue()}
	if info.Items == nil {
		info.Items = []QueueItem{}
	}
	if h, ok := a.TG.(telegram.HealthSource); ok {
		info.Telegram = h.Health()
	}
	if info.Telegram.Errors == nil {
		info.Telegram.Errors = []telegram.ErrorRecord{}
	}
	return info
}

// modalityHint nudges her to answer the way she was addressed: voice for voice, a sticker or a reaction for a sticker.
func modalityHint(cfg *config.Config, unread []telegram.Message) string {
	var last *telegram.Message
	for i := len(unread) - 1; i >= 0; i-- {
		if !unread[i].Outgoing {
			last = &unread[i]
			break
		}
	}
	if last == nil {
		return ""
	}
	tts := cfg.TTSBackend != "" && cfg.TTSBackend != "none"
	switch {
	case !cfg.MirrorModality && !(tts && cfg.VoicePercent > 0):
		return ""
	case cfg.MirrorModality && last.Media == telegram.MediaVoice && tts:
		return "<hint>They sent a voice message. If your answer is short, a voice message back is natural: #record_audio, then #send_telegram_message with audio_filename. Long or technical answers stay text.</hint>\n"
	case cfg.MirrorModality && last.Media == telegram.MediaSticker && cfg.UseStickers:
		return "<hint>They sent a sticker. Answer in kind: a sticker (#sticker_send) or an emoji reaction (#react_with_emoji), or at most a few words. A long text would be out of tune.</hint>\n"
	case last.Media == telegram.MediaNone && tts && cfg.VoicePercent > 0 && rand.Intn(100) < cfg.VoicePercent:
		return "<hint>If your answer is short and personal, you may say it as a voice message instead of text: #record_audio, then #send_telegram_message with audio_filename. Long or technical answers stay text.</hint>\n"
	}
	return ""
}
