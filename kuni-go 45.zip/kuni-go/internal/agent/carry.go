package agent

import (
	"context"
	"encoding/json"
	"log"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"kuni/internal/llm"
)

// The carried summary of a quiet talk is kept on disk: a restart must not make her forget what was said an hour ago.

type carryFile map[string]struct {
	Text string    `json:"text"`
	At   time.Time `json:"at"`
}

func (a *Agent) carryPath() string {
	return filepath.Join(a.Cfg.Get().DataDir, "carry.json")
}

// saveCarryLocked writes the carried summaries to disk (a.mu held).
func (a *Agent) saveCarryLocked() {
	if a.Cfg.Get().DataDir == "" {
		return
	}
	f := carryFile{}
	for id, c := range a.carry {
		if time.Since(c.at) < carryTTL {
			f[carryKey(id)] = struct {
				Text string    `json:"text"`
				At   time.Time `json:"at"`
			}{c.head.Content, c.at}
		}
	}
	b, err := json.Marshal(f)
	if err != nil {
		return
	}
	_ = os.MkdirAll(filepath.Dir(a.carryPath()), 0o755)
	tmp := a.carryPath() + ".tmp"
	if os.WriteFile(tmp, b, 0o600) == nil {
		_ = os.Rename(tmp, a.carryPath())
	}
}

func (a *Agent) loadCarry() {
	if a.Cfg.Get().DataDir == "" {
		return
	}
	b, err := os.ReadFile(a.carryPath())
	if err != nil {
		return
	}
	var f carryFile
	if json.Unmarshal(b, &f) != nil {
		return
	}
	for k, v := range f {
		id, ok := carryID(k)
		if !ok || time.Since(v.At) >= carryTTL || v.Text == "" {
			continue
		}
		a.carry[id] = carried{head: llm.Message{Role: "user", Content: v.Text}, at: v.At}
	}
	log.Printf("agent: restored the summaries of %d quiet talks", len(a.carry))
}

// carryOf is the summary a dumped session leaves for the next one: the old summary plus what happened since,
// compressed into one block. It returns false when there is nothing worth carrying.
func (a *Agent) carryOf(ctx context.Context, s *session) (llm.Message, bool) {
	if len(s.msgs) == 0 {
		return llm.Message{}, false
	}
	if len(s.msgs) == 1 && isSummary(s.msgs[0]) {
		return s.msgs[0], true
	}
	cfg := a.Cfg.Get()
	// bound to ctx (shutdown has a deadline) and to 40 s: one try with the light model, no fallbacks
	cc, cancel := context.WithTimeout(ctx, 40*time.Second)
	defer cancel()
	sum, err := a.LLM.Chat(llm.WithPurpose(cc, "compact"), compactSystem, flatten(slimHistory(s.msgs, cfg.ToolResultChars)))
	if sum = strings.TrimSpace(sum); err == nil && sum != "" {
		return llm.Message{Role: "user", Content: summaryOpen + "\n" + sum + "\n" + summaryClose}, true
	}
	if err != nil {
		log.Printf("agent: chat %d: carried summary: %v", s.id, err)
	}
	if isSummary(s.msgs[0]) {
		return s.msgs[0], true // the new part could not be summarised: at least keep the old summary
	}
	return llm.Message{}, false
}

func carryKey(id int64) string { return strconv.FormatInt(id, 10) }

func carryID(s string) (int64, bool) {
	n, err := strconv.ParseInt(s, 10, 64)
	return n, err == nil
}
