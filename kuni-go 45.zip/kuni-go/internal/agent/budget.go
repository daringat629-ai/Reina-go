package agent

import (
	"context"
	"log"
	"math/rand"
	"regexp"
	"strings"
	"time"

	"kuni/internal/llm"
	"kuni/internal/telegram"
	"kuni/internal/util"
)

// Every user view carries blocks that only matter in the turn they were written for (instructions, mood,
// recalled memories, the member roster...). Left in the history they are paid for again on every request.
var staleBlocks = func() []*regexp.Regexp {
	var out []*regexp.Regexp
	for _, tag := range []string{"memories_that_popped_up_in_mind", "earlier_messages", "instructions", "chat_info",
		"while_you_were_away", "things_to_remember", "state", "mood", "person_card", "event", "hint", "style_check", "life"} {
		out = append(out, regexp.MustCompile(`(?s)\s*<`+tag+`[ >].*?</`+tag+`>[ \t]*\n?`))
	}
	return out
}()

// slimUser removes the stale blocks from one user view.
func slimUser(s string) string {
	for _, re := range staleBlocks {
		s = re.ReplaceAllString(s, "\n")
	}
	return strings.TrimSpace(s)
}

// slimHistory returns msgs ready to be sent: everything before the latest user view loses its stale blocks,
// and old tool results / thoughts are cut. The stored session is not modified.
func slimHistory(msgs []llm.Message, toolChars int) []llm.Message {
	last := -1
	for i := len(msgs) - 1; i >= 0; i-- {
		if msgs[i].Role == "user" {
			last = i
			break
		}
	}
	if last <= 0 {
		return msgs
	}
	if toolChars <= 0 {
		toolChars = 300
	}
	out := make([]llm.Message, len(msgs))
	copy(out, msgs)
	for i := 0; i < last; i++ {
		switch out[i].Role {
		case "user":
			if !strings.HasPrefix(out[i].Content, "<conversation_so_far>") {
				out[i].Content = slimUser(out[i].Content)
			}
		case "tool":
			out[i].Content = util.Trunc(out[i].Content, toolChars)
		case "assistant":
			out[i].Content = util.Trunc(out[i].Content, 300)
		}
	}
	return out
}

func msgSize(m llm.Message) int {
	n := len(m.Content)
	for _, c := range m.ToolCalls {
		n += len(c.Function.Name) + len(c.Function.Arguments) + 20
	}
	return n
}

// fitBudget drops the oldest messages (in whole user-turns) until the history is at most chars characters.
// The latest user turn is always kept, whatever its size.
func fitBudget(msgs []llm.Message, chars int) []llm.Message {
	if chars <= 0 {
		return msgs
	}
	if len(msgs) > 1 && isSummary(msgs[0]) {
		// the rolling summary stays whatever happens; the rest has what is left of the budget (at least half)
		left := chars - msgSize(msgs[0])
		if left < chars/2 {
			left = chars / 2
		}
		return append([]llm.Message{msgs[0]}, fitBudget(msgs[1:], left)...)
	}
	total := 0
	for _, m := range msgs {
		total += msgSize(m)
	}
	start := 0
	for total > chars {
		next := start + 1
		for next < len(msgs) && msgs[next].Role != "user" {
			next++
		}
		if next >= len(msgs) {
			break // only the latest turn is left
		}
		for i := start; i < next; i++ {
			total -= msgSize(msgs[i])
		}
		start = next
	}
	return msgs[start:]
}

// outgoing is what is actually sent to the model for this session.
func (a *Agent) outgoing(s *session) []llm.Message {
	cfg := a.Cfg.Get()
	return fitBudget(slimBrowser(slimHistory(trim(s.msgs, 80), cfg.ToolResultChars)), cfg.ContextChars)
}

// worthWaking decides, for a group, whether the unread messages deserve a (paid) model call at all.
func (a *Agent) worthWaking(ctx context.Context, chat telegram.Chat, unread []telegram.Message) bool {
	cfg := a.Cfg.Get()
	if chat.Kind == telegram.ChatPrivate || cfg.GroupReplyMode == "all" {
		return true
	}
	for _, m := range unread {
		if m.Outgoing {
			continue
		}
		if cfg.PapikChatID != 0 && m.SenderID == cfg.PapikChatID {
			return true
		}
		if a.UI.AddressedToMe(ctx, m) {
			return true
		}
	}
	if cfg.GroupInterestPercent > 0 && interesting(unread, cfg.GroupInterestWords) && rand.Intn(100) < cfg.GroupInterestPercent {
		return true // a topic she cares about: she joins in more often than at random
	}
	if cfg.GroupChime > 0 && rand.Intn(100) < cfg.GroupChime {
		return true
	}
	return false
}

// interesting says whether somebody else's message in unread mentions one of her topics (comma-separated, any case).
func interesting(unread []telegram.Message, words string) bool {
	var ws []string
	for _, w := range strings.Split(strings.ToLower(words), ",") {
		if w = strings.TrimSpace(w); w != "" {
			ws = append(ws, w)
		}
	}
	for _, m := range unread {
		if m.Outgoing {
			continue
		}
		t := strings.ToLower(m.Text)
		for _, w := range ws {
			if strings.Contains(t, w) {
				return true
			}
		}
	}
	return false
}

// compactNow summarises the old part of the session. It must not die together with the turn that triggered it
// (a new message cancels that turn), so it runs on a detached context; the light model is tried first, the main
// one second, and if both fail the old part is simply dropped so the history cannot grow without bound.
func (a *Agent) compactSummary(ctx context.Context, old []llm.Message) string {
	c, cancel := context.WithTimeout(context.WithoutCancel(ctx), 90*time.Second)
	defer cancel()
	sum, err := a.LLM.Chat(llm.WithPurpose(c, "compact"), compactSystem, old)
	if err == nil && strings.TrimSpace(sum) != "" {
		return strings.TrimSpace(sum)
	}
	log.Printf("agent: compact (light): %v; trying the main model", err)
	sum, err = a.LLM.Chat(llm.WithPurpose(c, "compact_main"), compactSystem, old)
	if err == nil && strings.TrimSpace(sum) != "" {
		return strings.TrimSpace(sum)
	}
	log.Printf("agent: compact (main): %v", err)
	return ""
}

const (
	summaryOpen  = "<conversation_so_far>"
	summaryClose = "</conversation_so_far>"
	// carryTTL is how long a summary of a quiet talk waits for the person to come back.
	carryTTL = 24 * time.Hour
)

// carried is the rolling summary of a session that was dumped to the diary; the next session of the chat starts with it.
type carried struct {
	head llm.Message
	at   time.Time
}

func isSummary(m llm.Message) bool {
	return m.Role == "user" && strings.HasPrefix(m.Content, summaryOpen)
}

// live says whether the session already holds real messages (not only a carried summary).
func live(s *session) bool {
	n := len(s.msgs)
	return n > 1 || (n == 1 && !isSummary(s.msgs[0]))
}

// slimBrowser keeps only the newest browser page in full: a page is 1-2 KB, and twenty of them in one task would
// drown the request. Older results shrink to their first lines (step, address, title).
func slimBrowser(msgs []llm.Message) []llm.Message {
	names := map[string]string{}
	for _, m := range msgs {
		for _, c := range m.ToolCalls {
			names[c.ID] = c.Function.Name
		}
	}
	last := -1
	for i := len(msgs) - 1; i >= 0; i-- {
		if msgs[i].Role == "tool" && names[msgs[i].ToolCallID] == "browser" {
			last = i
			break
		}
	}
	if last <= 0 {
		return msgs
	}
	var out []llm.Message
	for i, m := range msgs {
		if i < last && m.Role == "tool" && names[m.ToolCallID] == "browser" && len(m.Content) > 220 {
			if out == nil {
				out = append([]llm.Message(nil), msgs...)
			}
			head := m.Content
			for n, cut := 0, 0; cut < len(head); cut++ {
				if head[cut] == '\n' {
					if n++; n == 4 {
						head = head[:cut]
						break
					}
				}
			}
			out[i].Content = util.Trunc(head, 240) + "\n(older page, cut)"
		}
	}
	if out == nil {
		return msgs
	}
	return out
}
