package agent

import (
	"context"
	"fmt"
	"log"
	"strings"
	"time"
)

// workSessionID is the session key of background jobs: their own history, apart from every chat.
const workSessionID int64 = -777

// workLoop gives her jobs from the owner's queue, one run at a time, inside the limits of the settings.
func (a *Agent) workLoop(ctx context.Context) {
	for {
		mins := a.Cfg.Get().WorkEveryMins
		if mins < 2 {
			mins = 2
		}
		select {
		case <-ctx.Done():
			return
		case <-time.After(time.Duration(mins) * time.Minute):
		}
		if err := a.workOnce(ctx); err != nil {
			log.Printf("agent: work run: %v", err)
		}
	}
}

// workOnce starts one background run when it is allowed: work switched on, not paused, token limit not hit,
// the previous run finished, and a job is waiting.
func (a *Agent) workOnce(ctx context.Context) error {
	cfg := a.Cfg.Get()
	if !cfg.WorkEnabled || a.paused.Load() || a.Deps.Work == nil || cfg.PapikChatID == 0 {
		return nil
	}
	if a.Usage != nil && a.Usage.Over(cfg.DailyTokenLimit) {
		return nil
	}
	s := a.getSession(workSessionID)
	if !s.mu.TryLock() { // the previous run is still going
		return nil
	}
	s.mu.Unlock()
	t, ok := a.Deps.Work.Take(time.Now(), cfg.WorkMaxRuns)
	if !ok {
		return nil
	}
	var b strings.Builder
	fmt.Fprintf(&b, "BACKGROUND WORK RUN. Nobody is talking to you now: do not chat, do not greet. You work on a job from your queue (#work); the owner reads only what you send through #work done / #work ask.\n\n")
	fmt.Fprintf(&b, "<job>\n%s\n</job>\n\n", t.Render(true))
	b.WriteString("Do one real, concrete chunk of work now with your tools (browser, desktop, web_search, read_file, shell, http_request, mail). Be quick, one action per round, never repeat what changed nothing.\n" +
		"When the chunk is over: write #work note with exactly what you did and what is next (links, numbers, drafts: the next run starts from your notes, not from memory).\n" +
		"If the job is finished: #work done with the result. If you need his decision, any payment, any account registration, acceptance of terms, or a message in his name to a stranger: do the preparation and #work ask with exactly what you want to do and why, then stop. If you are stuck, #work ask too.\n" +
		"Never pay, never register, never accept a contract, never impersonate or deceive. Do not write to the owner in the chat in any other way.")
	log.Printf("agent: background run of job #%d (%s), run %d/%d", t.ID, t.Title, t.Runs, t.MaxRuns)
	return a.wake(ctx, workSessionID, cfg.PapikChatID, b.String(), []string{"browser", "desktop"})
}
