package prompts

import (
	"crypto/sha256"
	"encoding/hex"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestAll13PromptsLoadedWithVariables(t *testing.T) {
	dir := t.TempDir()
	s, err := NewStore(dir, Vars{CharacterName: "Mika", CharacterNickname: "@mika", PapikName: "Bob"})
	if err != nil {
		t.Fatal(err)
	}
	for _, name := range []string{System, CharacterBase, CharacterAppearance, PhotoToText, StickerToText, AntiRepeat, DiarySave,
		SleepConsolidator, RecordAudioSpeech, MessagesEpilogue, ImageEngineerSystem, ImageEngineerInstructions, ImageAssessSystem} {
		if strings.TrimSpace(s.Get(name)) == "" {
			t.Errorf("prompt %q is empty", name)
		}
		if _, err := os.Stat(filepath.Join(dir, name+".md")); err != nil {
			t.Errorf("default file for %q not written", name)
		}
		if strings.Contains(s.Get(name), "${") {
			t.Errorf("prompt %q has unexpanded variables", name)
		}
		if strings.HasPrefix(strings.TrimSpace(s.Get(name)), "---") {
			t.Errorf("prompt %q still has front matter", name)
		}
	}
	if !strings.Contains(s.Get(CharacterBase), "Mika") {
		t.Errorf("CHARACTER_NAME not substituted into character_base")
	}
}

func TestUserEditsSurviveAndReload(t *testing.T) {
	dir := t.TempDir()
	s, _ := NewStore(dir, Vars{CharacterName: "Kuni"})
	custom := "---\nmy note\n---\nHello ${CHARACTER_NAME}, be nice."
	if err := os.WriteFile(filepath.Join(dir, AntiRepeat+".md"), []byte(custom), 0o644); err != nil {
		t.Fatal(err)
	}
	if err := s.Reload(); err != nil {
		t.Fatal(err)
	}
	if got := strings.TrimSpace(s.Get(AntiRepeat)); got != "Hello Kuni, be nice." {
		t.Fatalf("got %q", got)
	}
	// a fresh store must not overwrite the user's file with the default
	s2, _ := NewStore(dir, Vars{CharacterName: "Kuni"})
	if !strings.Contains(s2.Get(AntiRepeat), "be nice") {
		t.Fatal("user edit was overwritten")
	}
}

func TestFormat(t *testing.T) {
	got := Format("a {X} b {Y}", map[string]string{"X": "1", "Y": "2"})
	if got != "a 1 b 2" {
		t.Fatalf("got %q", got)
	}
}

func TestUntouchedOldDefaultIsUpgradedButOwnerEditsAreNot(t *testing.T) {
	old := "---\nx\n---\nстарый текст внешности"
	sum := sha256.Sum256([]byte(old))
	saved := outdated["character_appearance.md"]
	outdated["character_appearance.md"] = append(append([]string{}, saved...), hex.EncodeToString(sum[:]))
	defer func() { outdated["character_appearance.md"] = saved }()

	dir := t.TempDir()
	path := filepath.Join(dir, "character_appearance.md")
	if err := os.WriteFile(path, []byte(old), 0o644); err != nil {
		t.Fatal(err)
	}
	s, err := NewStore(dir, Vars{CharacterName: "Reina"})
	if err != nil {
		t.Fatal(err)
	}
	got := s.Get(CharacterAppearance)
	if strings.Contains(got, "старый текст") || !strings.Contains(got, "split-dyed") {
		t.Fatalf("the untouched old default was not upgraded:\n%s", got)
	}
	if kept, _ := os.ReadFile(path + ".old"); string(kept) != old {
		t.Fatal("the old text must be kept as .old")
	}

	// the owner edited it (even slightly): hands off
	mine := old + " и моя правка"
	if err := os.WriteFile(path, []byte(mine), 0o644); err != nil {
		t.Fatal(err)
	}
	if err := s.Reload(); err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(s.Get(CharacterAppearance), "моя правка") {
		t.Fatal("an edited prompt was overwritten")
	}
}
