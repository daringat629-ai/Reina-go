// Package prompts loads the 13 original Kuni prompts (extracted verbatim from
// src/prompts.cpp into defaults/*.md). Like the C++ version, defaults are written
// to <dir>/<name>.md on first run and the files are then the source of truth:
// the YAML-ish front matter is stripped and ${CHARACTER_NAME} etc. are expanded.
package prompts

import (
	"crypto/sha256"
	"embed"
	"encoding/hex"
	"os"
	"path/filepath"
	"strings"
	"sync"
)

//go:embed defaults/*.md
var defaults embed.FS

// Names of all prompts.
const (
	System                    = "system"
	CharacterBase             = "character_base"
	CharacterAppearance       = "character_appearance"
	PhotoToText               = "photo_to_text"
	StickerToText             = "sticker_to_text"
	AntiRepeat                = "anti_repeat"
	DiarySave                 = "diary_save"
	SleepConsolidator         = "sleep_consolidator"
	RecordAudioSpeech         = "record_audio_speech"
	MessagesEpilogue          = "messages_epilogue"
	ImageEngineerSystem       = "image_engineer_system"
	ImageEngineerInstructions = "image_engineer_instructions"
	ImageAssessSystem         = "image_assess_system"
)

// Vars are the ${VARIABLES} substituted into prompts.
type Vars struct {
	CharacterName     string
	CharacterNickname string
	PapikName         string
}

// outdated lists, per file, the SHA-256 of default texts that shipped before. A prompt file on disk that is byte for
// byte one of them was never edited by the owner, so it is replaced by the current default (the old one is kept as
// <name>.md.old). A file the owner changed even by one character is never touched.
var outdated = map[string][]string{
	"character_appearance.md": {"6e726bb0354932b85f608f920acf6cbd747b25880210cc77c1d716c175e13727",
		"21b2f6eaa77aa9dece03180eda2ffa76623522b1c4e34cd41839b1ba4d4f6bea"},
}

func isOutdatedDefault(file string, raw []byte) bool {
	sum := sha256.Sum256(raw)
	h := hex.EncodeToString(sum[:])
	for _, o := range outdated[file] {
		if o == h {
			return true
		}
	}
	return false
}

// Store keeps loaded prompts; Reload re-reads files (hot reload).
type Store struct {
	Dir  string
	mu   sync.RWMutex
	vars Vars
	data map[string]string
}

func NewStore(dir string, vars Vars) (*Store, error) {
	s := &Store{Dir: dir, vars: vars}
	return s, s.Reload()
}

// SetVars changes variables and re-expands prompts.
func (s *Store) SetVars(v Vars) error {
	s.mu.Lock()
	s.vars = v
	s.mu.Unlock()
	return s.Reload()
}

// Reload reads every prompt file, creating missing ones from the embedded defaults.
func (s *Store) Reload() error {
	if err := os.MkdirAll(s.Dir, 0o755); err != nil {
		return err
	}
	entries, err := defaults.ReadDir("defaults")
	if err != nil {
		return err
	}
	s.mu.RLock()
	vars := s.vars
	s.mu.RUnlock()
	out := make(map[string]string, len(entries))
	for _, e := range entries {
		file := e.Name()
		name := strings.TrimSuffix(file, ".md")
		path := filepath.Join(s.Dir, file)
		raw, err := os.ReadFile(path)
		if os.IsNotExist(err) {
			def, _ := defaults.ReadFile("defaults/" + file)
			if err := os.WriteFile(path, def, 0o644); err != nil {
				return err
			}
			raw = def
		} else if err != nil {
			return err
		} else if isOutdatedDefault(file, raw) {
			def, _ := defaults.ReadFile("defaults/" + file)
			_ = os.WriteFile(path+".old", raw, 0o644)
			if err := os.WriteFile(path, def, 0o644); err != nil {
				return err
			}
			raw = def
		}
		out[name] = expand(StripFrontMatter(string(raw)), vars)
	}
	s.mu.Lock()
	s.data = out
	s.mu.Unlock()
	return nil
}

// Get returns a loaded prompt ("" if unknown).
func (s *Store) Get(name string) string {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.data[name]
}

// Files lists prompt files for the file watcher.
func (s *Store) Files() []string {
	entries, _ := defaults.ReadDir("defaults")
	var out []string
	for _, e := range entries {
		out = append(out, filepath.Join(s.Dir, e.Name()))
	}
	return out
}

// StripFrontMatter removes a leading "---\n...\n---" block (same rule as Prompts::load).
func StripFrontMatter(s string) string {
	i := strings.Index(s, "---")
	if i < 0 {
		return s
	}
	j := strings.Index(s[i+4:], "\n---")
	if j < 0 {
		return s
	}
	return s[i+4+j+4:]
}

func expand(s string, v Vars) string {
	return strings.NewReplacer(
		"${CHARACTER_NAME}", v.CharacterName,
		"${CHARACTER_NICKNAME}", v.CharacterNickname,
		"${PAPIK_NAME}", v.PapikName,
	).Replace(s)
}

// Format fills {KEY} placeholders (used by image_engineer_system).
func Format(s string, kv map[string]string) string {
	pairs := make([]string, 0, len(kv)*2)
	for k, v := range kv {
		pairs = append(pairs, "{"+k+"}", v)
	}
	return strings.NewReplacer(pairs...).Replace(s)
}

// Names lists the prompt names (sorted by file name).
func (s *Store) Names() []string {
	entries, _ := defaults.ReadDir("defaults")
	var out []string
	for _, e := range entries {
		out = append(out, strings.TrimSuffix(e.Name(), ".md"))
	}
	return out
}

func (s *Store) known(name string) bool {
	for _, n := range s.Names() {
		if n == name {
			return true
		}
	}
	return false
}

// Raw returns the prompt file as stored (with front matter and ${VARS}).
func (s *Store) Raw(name string) (string, error) {
	if !s.known(name) {
		return "", os.ErrNotExist
	}
	b, err := os.ReadFile(filepath.Join(s.Dir, name+".md"))
	return string(b), err
}

// Default returns the built-in text of a prompt.
func (s *Store) Default(name string) (string, error) {
	if !s.known(name) {
		return "", os.ErrNotExist
	}
	b, err := defaults.ReadFile("defaults/" + name + ".md")
	return string(b), err
}

// Write replaces a prompt file (atomically, keeping a .bak) and reloads.
func (s *Store) Write(name, content string) error {
	if !s.known(name) {
		return os.ErrNotExist
	}
	path := filepath.Join(s.Dir, name+".md")
	if old, err := os.ReadFile(path); err == nil {
		_ = os.WriteFile(path+".bak", old, 0o644)
	}
	tmp := path + ".tmp"
	if err := os.WriteFile(tmp, []byte(content), 0o644); err != nil {
		return err
	}
	if err := os.Rename(tmp, path); err != nil {
		return err
	}
	return s.Reload()
}
