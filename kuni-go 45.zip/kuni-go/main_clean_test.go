package main

import (
	"context"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"kuni/internal/config"
	"kuni/internal/telegram"
)

type optTG struct {
	*telegram.Fake
	ttl int
}

func (o *optTG) OptimizeStorage(_ context.Context, ttl int) (int64, error) {
	o.ttl = ttl
	return 7 << 20, nil
}

func put(t *testing.T, p string, size int, age time.Duration) {
	t.Helper()
	_ = os.MkdirAll(filepath.Dir(p), 0o755)
	if err := os.WriteFile(p, make([]byte, size), 0o644); err != nil {
		t.Fatal(err)
	}
	old := time.Now().Add(-age)
	_ = os.Chtimes(p, old, old)
}

func TestCleanerFreesOnlyWhatIsOld(t *testing.T) {
	dir := t.TempDir()
	td := filepath.Join(dir, "tdlib")
	c := &config.Config{DataDir: filepath.Join(dir, "data"), TDLibDir: td, CacheDays: 30, TelegramEnabled: true}
	put(t, filepath.Join(td, "outbox", "old.jpg"), 3<<20, 3*time.Hour)
	put(t, filepath.Join(td, "outbox", "fresh.jpg"), 1<<20, time.Minute) // still being sent
	put(t, filepath.Join(c.DataDir, "cache", "images", "x.md"), 1<<20, 40*24*time.Hour)
	put(t, filepath.Join(c.DataDir, "cache", "images", "y.md"), 1<<20, 2*24*time.Hour)
	put(t, filepath.Join(c.DataDir, "diary", "page.md"), 1<<20, 400*24*time.Hour) // never touched
	put(t, filepath.Join(c.DataDir, "update", "upload.zip"), 2<<20, 2*24*time.Hour)

	tg := &optTG{Fake: telegram.NewFake()}
	rep := cleaner{cfg: func() *config.Config { return c }, tg: tg}.Run(context.Background(), false)

	exists := func(p string) bool { _, err := os.Stat(p); return err == nil }
	if exists(filepath.Join(td, "outbox", "old.jpg")) || !exists(filepath.Join(td, "outbox", "fresh.jpg")) {
		t.Fatal("outbox: old files go, a file sent a minute ago stays")
	}
	if exists(filepath.Join(c.DataDir, "cache", "images", "x.md")) || !exists(filepath.Join(c.DataDir, "cache", "images", "y.md")) {
		t.Fatal("cache: only files older than cache_days go")
	}
	if !exists(filepath.Join(c.DataDir, "diary", "page.md")) {
		t.Fatal("the diary must never be cleaned")
	}
	if exists(filepath.Join(c.DataDir, "update", "upload.zip")) {
		t.Fatal("a stale update upload must go")
	}
	if tg.ttl != 7 {
		t.Fatalf("tdlib cache: normal pass keeps a week, got %d", tg.ttl)
	}
	if !strings.Contains(rep, "Освободила около") || !strings.Contains(rep, "кэш Telegram: 7 МБ") {
		t.Fatalf("report: %s", rep)
	}

	// a forced pass is stricter: a day for the cache and for tdlib
	rep = cleaner{cfg: func() *config.Config { return c }, tg: tg}.Run(context.Background(), true)
	if tg.ttl != 1 || exists(filepath.Join(c.DataDir, "cache", "images", "y.md")) {
		t.Fatalf("forced pass must use a one-day age (ttl=%d): %s", tg.ttl, rep)
	}
}

func TestCleanerEmptiesAHugeLog(t *testing.T) {
	dir := t.TempDir()
	logf := filepath.Join(dir, "reina.log")
	put(t, logf, 31<<20, 0)
	c := &config.Config{DataDir: dir, TDLibDir: filepath.Join(dir, "tdlib")}
	rep := cleaner{cfg: func() *config.Config { return c }, tg: telegram.NewFake(), LogFile: logf}.Run(context.Background(), false)
	if st, _ := os.Stat(logf); st.Size() != 0 || !strings.Contains(rep, "лог: 31 МБ") {
		t.Fatalf("a log over 30 MB must be emptied: size=%d, %s", st.Size(), rep)
	}
	put(t, logf, 1<<20, 0)
	cleaner{cfg: func() *config.Config { return c }, tg: telegram.NewFake(), LogFile: logf}.Run(context.Background(), false)
	if st, _ := os.Stat(logf); st.Size() != 1<<20 {
		t.Fatal("a small log must stay")
	}
}

func TestCleanerWithNothingToDo(t *testing.T) {
	dir := t.TempDir()
	c := &config.Config{DataDir: dir, TDLibDir: filepath.Join(dir, "tdlib")}
	rep := cleaner{cfg: func() *config.Config { return c }, tg: telegram.NewFake()}.Run(context.Background(), false)
	if !strings.HasPrefix(rep, "Чистить нечего") {
		t.Fatal(rep)
	}
}
