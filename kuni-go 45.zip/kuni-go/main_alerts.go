package main

import (
	"context"
	"fmt"
	"time"

	"kuni/internal/alerts"
	"kuni/internal/config"
	"kuni/internal/telegram"
)

// tgTrouble says what is wrong with Telegram right now ("" if nothing): a burst of failed requests or a flood wait.
func tgTrouble(h telegram.Health, now time.Time) string {
	n := 0
	var last telegram.ErrorRecord
	for _, e := range h.Errors {
		if now.Sub(e.At) <= 10*time.Minute {
			n++
			last = e
		}
	}
	msg := ""
	if n >= 5 {
		msg = fmt.Sprintf("в Telegram за 10 минут %d ошибок, последняя: %s — %s", n, last.Method, last.Message)
	}
	if h.FloodUntil.After(now.Add(5 * time.Minute)) {
		if msg != "" {
			msg += "; "
		}
		msg += fmt.Sprintf("Telegram притормозил меня (flood wait) до %s", h.FloodUntil.Format("15:04"))
	}
	return msg
}

// watchLoop checks Telegram once a minute and tells the owner about trouble (each kind at most every 2 hours).
func watchLoop(ctx context.Context, cfg func() *config.Config, tg telegram.Client, notify func(string)) {
	hs, ok := tg.(telegram.HealthSource)
	if !ok {
		return
	}
	var gate alerts.Gate
	t := time.NewTicker(time.Minute)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
		}
		if !cfg().AlertsEnabled {
			continue
		}
		now := time.Now()
		if msg := tgTrouble(hs.Health(), now); msg != "" && gate.Allow("tg", 2*time.Hour, now) {
			notify("Папик, проблема: " + msg + ".")
		}
	}
}
