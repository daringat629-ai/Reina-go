// Package billing is the plans people other than the owner are on: Start (free), Plus and Max. Each plan has a daily number of
// conversations (one conversation = one time she answers a batch of new messages in a chat). A payment, taken by a small separate bot
// in Telegram Stars, moves a person to Plus or Max for a number of days. The owner is never limited and never billed.
package billing

import (
	"errors"
	"fmt"
	"sort"
	"sync"
	"time"

	"kuni/internal/store"
)

// Plans.
const (
	Free = "start"
	Plus = "plus"
	Max  = "max"
)

// Limits are the daily conversation limits per plan (0 = no cap).
type Limits struct{ Free, Plus, Max int }

func (l Limits) of(plan string) int {
	switch plan {
	case Plus:
		return l.Plus
	case Max:
		return l.Max
	}
	return l.Free
}

// User is one person's account.
type User struct {
	ID    int64     `json:"id"`
	Plan  string    `json:"plan"`
	Until time.Time `json:"until,omitempty"`
	Day   string    `json:"day"`
	Used  int       `json:"used"`
	Told  string    `json:"told,omitempty"` // the day she last said that the limit is over (said once a day)
}

// Payment is one successful payment, kept so that the same charge is never counted twice.
type Payment struct {
	At     time.Time `json:"at"`
	UserID int64     `json:"user_id"`
	Plan   string    `json:"plan"`
	Stars  int       `json:"stars"`
	Charge string    `json:"charge"`
	Days   int       `json:"days"`
}

type data struct {
	Users    map[int64]*User `json:"users"`
	Payments []Payment       `json:"payments"`
}

// Store keeps accounts in one JSON file. Safe for concurrent use.
type Store struct {
	mu    sync.Mutex
	path  string
	saver store.Saver
	d     data
}

// Open loads the accounts (or starts empty).
func Open(path string) *Store {
	s := &Store{path: path, saver: store.Saver{What: "billing"}}
	store.Load("billing", path, &s.d)
	if s.d.Users == nil {
		s.d.Users = map[int64]*User{}
	}
	return s
}

func (s *Store) save() { _ = s.saver.Save(s.path, s.d) }

func (s *Store) user(id int64) *User {
	u := s.d.Users[id]
	if u == nil {
		u = &User{ID: id, Plan: Free}
		s.d.Users[id] = u
	}
	return u
}

// planAt is the plan in force at now (a paid plan that ran out falls back to Start).
func planAt(u *User, now time.Time) string {
	if u.Plan != Free && now.Before(u.Until) {
		return u.Plan
	}
	return Free
}

// Decision is the answer to "may she answer this person now".
type Decision struct {
	OK       bool
	Plan     string
	Left     int  // conversations left today after this one (-1 = no cap)
	TellOnce bool // the limit is over and she has not said so today yet
}

// Take counts one conversation for the person and says whether it is allowed.
func (s *Store) Take(id int64, now time.Time, l Limits) Decision {
	s.mu.Lock()
	defer s.mu.Unlock()
	u := s.user(id)
	day := now.Format("2006-01-02")
	if u.Day != day {
		u.Day, u.Used = day, 0
	}
	plan := planAt(u, now)
	limit := l.of(plan)
	if limit > 0 && u.Used >= limit {
		d := Decision{Plan: plan, TellOnce: u.Told != day}
		u.Told = day
		s.save()
		return d
	}
	u.Used++
	s.save()
	left := -1
	if limit > 0 {
		left = limit - u.Used
	}
	return Decision{OK: true, Plan: plan, Left: left}
}

// Activate records a payment and moves the person to the plan for days more (added to what is left of the same plan).
func (s *Store) Activate(id int64, plan string, days, stars int, charge string, now time.Time) (User, error) {
	if plan != Plus && plan != Max {
		return User{}, fmt.Errorf("billing: unknown plan %q", plan)
	}
	if days <= 0 {
		return User{}, errors.New("billing: days must be positive")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	for _, p := range s.d.Payments {
		if charge != "" && p.Charge == charge {
			return *s.user(id), nil // the same payment again: already counted
		}
	}
	u := s.user(id)
	start := now
	if planAt(u, now) == plan && u.Until.After(now) {
		start = u.Until
	}
	u.Plan, u.Until = plan, start.Add(time.Duration(days)*24*time.Hour)
	s.d.Payments = append(s.d.Payments, Payment{At: now, UserID: id, Plan: plan, Stars: stars, Charge: charge, Days: days})
	s.save()
	return *u, nil
}

// Get returns a person's account as of now.
func (s *Store) Get(id int64, now time.Time) User {
	s.mu.Lock()
	defer s.mu.Unlock()
	u := *s.user(id)
	u.Plan = planAt(&u, now)
	return u
}

// All lists every account (paid first) and every payment, for the panel.
func (s *Store) All(now time.Time) ([]User, []Payment) {
	s.mu.Lock()
	defer s.mu.Unlock()
	var us []User
	for _, u := range s.d.Users {
		x := *u
		x.Plan = planAt(&x, now)
		us = append(us, x)
	}
	sort.Slice(us, func(i, j int) bool {
		if (us[i].Plan == Free) != (us[j].Plan == Free) {
			return us[j].Plan == Free
		}
		return us[i].ID < us[j].ID
	})
	return us, append([]Payment(nil), s.d.Payments...)
}
