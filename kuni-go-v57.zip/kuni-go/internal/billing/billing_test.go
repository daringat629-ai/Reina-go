package billing

import (
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"
)

var t0 = time.Date(2026, 10, 30, 12, 0, 0, 0, time.UTC)
var lim = Limits{Free: 2, Plus: 5, Max: 0}

func TestFreeLimitResetsDailyAndIsToldOnce(t *testing.T) {
	s := Open(filepath.Join(t.TempDir(), "b.json"))
	for i := 0; i < 2; i++ {
		if d := s.Take(7, t0, lim); !d.OK || d.Plan != Free {
			t.Fatalf("conversation %d must be allowed: %+v", i, d)
		}
	}
	d := s.Take(7, t0, lim)
	if d.OK || !d.TellOnce {
		t.Fatalf("over the limit, told once: %+v", d)
	}
	if d := s.Take(7, t0.Add(time.Minute), lim); d.OK || d.TellOnce {
		t.Fatalf("not told twice in a day: %+v", d)
	}
	if d := s.Take(7, t0.Add(24*time.Hour), lim); !d.OK || d.Left != 1 {
		t.Fatalf("a new day resets the count: %+v", d)
	}
}

func TestActivateExtendsAndIgnoresTheSameChargeTwice(t *testing.T) {
	path := filepath.Join(t.TempDir(), "b.json")
	s := Open(path)
	if _, err := s.Activate(7, "gold", 30, 1, "x", t0); err == nil {
		t.Fatal("unknown plan")
	}
	u, err := s.Activate(7, Plus, 30, 250, "c1", t0)
	if err != nil || u.Plan != Plus || !u.Until.Equal(t0.Add(30*24*time.Hour)) {
		t.Fatalf("%+v %v", u, err)
	}
	if u, _ := s.Activate(7, Plus, 30, 250, "c1", t0); !u.Until.Equal(t0.Add(30 * 24 * time.Hour)) {
		t.Fatal("the same charge must not be counted twice")
	}
	if u, _ := s.Activate(7, Plus, 30, 250, "c2", t0.Add(24*time.Hour)); !u.Until.Equal(t0.Add(60 * 24 * time.Hour)) {
		t.Fatalf("a second payment adds to what is left: %v", u.Until)
	}
	for i := 0; i < 5; i++ {
		s.Take(7, t0, lim)
	}
	if d := s.Take(7, t0, lim); d.OK {
		t.Fatal("Plus has its own limit")
	}
	if g := Open(path).Get(7, t0.Add(61*24*time.Hour)); g.Plan != Free {
		t.Fatalf("an expired plan falls back to Start (and survives a restart): %+v", g)
	}
	if _, pays := Open(path).All(t0); len(pays) != 2 {
		t.Fatalf("payments are kept: %d", len(pays))
	}
}

func TestMaxHasNoCap(t *testing.T) {
	s := Open(filepath.Join(t.TempDir(), "b.json"))
	_, _ = s.Activate(9, Max, 30, 600, "m", t0)
	for i := 0; i < 100; i++ {
		if d := s.Take(9, t0, lim); !d.OK || d.Left != -1 {
			t.Fatalf("Max without a cap: %+v", d)
		}
	}
}

func TestBotChecksPriceAndAppliesPayment(t *testing.T) {
	var mu sync.Mutex
	calls := map[string][]map[string]any{}
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		raw, _ := io.ReadAll(r.Body)
		var in map[string]any
		_ = json.Unmarshal(raw, &in)
		m := r.URL.Path[strings.LastIndex(r.URL.Path, "/")+1:]
		mu.Lock()
		calls[m] = append(calls[m], in)
		mu.Unlock()
		w.Write([]byte(`{"ok":true,"result":true}`))
	}))
	defer srv.Close()
	st := Open(filepath.Join(t.TempDir(), "b.json"))
	var paid int64
	b := &Bot{Token: "T", BaseURL: srv.URL, Store: st, Now: func() time.Time { return t0 },
		Prices: func() (int, int, int) { return 250, 600, 30 }, Limits: func() Limits { return lim },
		OnPaid: func(id int64, plan string, until time.Time) { paid = id }}
	ctx := context.Background()
	var u update
	_ = json.Unmarshal([]byte(`{"update_id":1,"message":{"from":{"id":7},"chat":{"id":7},"text":"/start"}}`), &u)
	b.handle(ctx, u)
	if len(calls["sendInvoice"]) != 2 || calls["sendInvoice"][0]["currency"] != "XTR" || calls["sendInvoice"][0]["provider_token"] != "" {
		t.Fatalf("two Stars invoices: %+v", calls["sendInvoice"])
	}
	_ = json.Unmarshal([]byte(`{"update_id":2,"pre_checkout_query":{"id":"q1","currency":"XTR","total_amount":1,"invoice_payload":"plus"}}`), &u)
	b.handle(ctx, u)
	if calls["answerPreCheckoutQuery"][0]["ok"] != false {
		t.Fatal("a wrong price must be refused before money moves")
	}
	u = update{}
	_ = json.Unmarshal([]byte(`{"update_id":3,"pre_checkout_query":{"id":"q2","currency":"XTR","total_amount":600,"invoice_payload":"max"}}`), &u)
	b.handle(ctx, u)
	if calls["answerPreCheckoutQuery"][1]["ok"] != true {
		t.Fatal("the right price is accepted")
	}
	u = update{}
	_ = json.Unmarshal([]byte(`{"update_id":4,"message":{"from":{"id":7},"chat":{"id":7},"successful_payment":{"currency":"XTR","total_amount":600,"invoice_payload":"max","telegram_payment_charge_id":"ch1"}}}`), &u)
	b.handle(ctx, u)
	if g := st.Get(7, t0); g.Plan != Max || paid != 7 {
		t.Fatalf("the payment moves the person to Max and tells the owner: %+v %d", g, paid)
	}
}
