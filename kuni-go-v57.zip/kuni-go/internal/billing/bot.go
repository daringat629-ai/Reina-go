package billing

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"net/http"
	"strings"
	"time"
)

// Bot is the small payment bot: it shows a person their plan and sends invoices in Telegram Stars (currency XTR). Her own Telegram
// account is a user account and cannot send invoices, so payment lives in a separate bot from @BotFather.
type Bot struct {
	Token   string
	BaseURL string // https://api.telegram.org by default (tests point it elsewhere)
	Store   *Store
	Prices  func() (plus, max, days int)
	Limits  func() Limits
	HTTP    *http.Client
	Now     func() time.Time
	OnPaid  func(userID int64, plan string, until time.Time) // e.g. tell the owner
	offset  int64
}

func (b *Bot) now() time.Time {
	if b.Now != nil {
		return b.Now()
	}
	return time.Now()
}

func (b *Bot) call(ctx context.Context, method string, in, out any) error {
	base := b.BaseURL
	if base == "" {
		base = "https://api.telegram.org"
	}
	body, _ := json.Marshal(in)
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, base+"/bot"+b.Token+"/"+method, bytes.NewReader(body))
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/json")
	hc := b.HTTP
	if hc == nil {
		hc = &http.Client{Timeout: 70 * time.Second}
	}
	resp, err := hc.Do(req)
	if err != nil {
		return fmt.Errorf("billing bot: %s: %w", method, errors.Unwrap(err)) // never put the token (it is in the URL) into a log line
	}
	defer resp.Body.Close()
	var r struct {
		OK          bool            `json:"ok"`
		Result      json.RawMessage `json:"result"`
		Description string          `json:"description"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&r); err != nil {
		return fmt.Errorf("billing bot: %s: bad answer", method)
	}
	if !r.OK {
		return fmt.Errorf("billing bot: %s: %s", method, r.Description)
	}
	if out != nil {
		return json.Unmarshal(r.Result, out)
	}
	return nil
}

type update struct {
	UpdateID int64 `json:"update_id"`
	Message  *struct {
		From struct {
			ID int64 `json:"id"`
		} `json:"from"`
		Chat struct {
			ID int64 `json:"id"`
		} `json:"chat"`
		Text              string `json:"text"`
		SuccessfulPayment *struct {
			Currency    string `json:"currency"`
			TotalAmount int    `json:"total_amount"`
			Payload     string `json:"invoice_payload"`
			ChargeID    string `json:"telegram_payment_charge_id"`
		} `json:"successful_payment"`
	} `json:"message"`
	PreCheckout *struct {
		ID       string `json:"id"`
		Currency string `json:"currency"`
		Total    int    `json:"total_amount"`
		Payload  string `json:"invoice_payload"`
	} `json:"pre_checkout_query"`
}

// Run polls the Bot API until ctx ends.
func (b *Bot) Run(ctx context.Context) {
	for ctx.Err() == nil {
		var ups []update
		err := b.call(ctx, "getUpdates", map[string]any{"offset": b.offset, "timeout": 50, "allowed_updates": []string{"message", "pre_checkout_query"}}, &ups)
		if err != nil {
			if ctx.Err() == nil {
				log.Printf("%v", err)
				select {
				case <-ctx.Done():
				case <-time.After(10 * time.Second):
				}
			}
			continue
		}
		for _, u := range ups {
			b.offset = u.UpdateID + 1
			b.handle(ctx, u)
		}
	}
}

func (b *Bot) price(plan string) int {
	plus, max, _ := b.Prices()
	if plan == Max {
		return max
	}
	return plus
}

func (b *Bot) handle(ctx context.Context, u update) {
	switch {
	case u.PreCheckout != nil:
		q := u.PreCheckout
		ok := q.Currency == "XTR" && (q.Payload == Plus || q.Payload == Max) && q.Total == b.price(q.Payload)
		in := map[string]any{"pre_checkout_query_id": q.ID, "ok": ok}
		if !ok {
			in["error_message"] = "Цена изменилась. Откройте /plans ещё раз."
		}
		if err := b.call(ctx, "answerPreCheckoutQuery", in, nil); err != nil {
			log.Printf("%v", err)
		}
	case u.Message != nil && u.Message.SuccessfulPayment != nil:
		m, p := u.Message, u.Message.SuccessfulPayment
		if p.Currency != "XTR" || (p.Payload != Plus && p.Payload != Max) {
			log.Printf("billing bot: an unexpected payment (%s %d %q) from %d, not applied", p.Currency, p.TotalAmount, p.Payload, m.From.ID)
			return
		}
		_, _, days := b.Prices()
		acc, err := b.Store.Activate(m.From.ID, p.Payload, days, p.TotalAmount, p.ChargeID, b.now())
		if err != nil {
			log.Printf("%v", err)
			return
		}
		b.send(ctx, m.Chat.ID, fmt.Sprintf("Спасибо! Тариф %s действует до %s. Можно возвращаться к Рейне.", title(acc.Plan), acc.Until.Format("02.01.2006")))
		if b.OnPaid != nil {
			b.OnPaid(m.From.ID, acc.Plan, acc.Until)
		}
	case u.Message != nil:
		m := u.Message
		cmd := strings.Fields(strings.ToLower(m.Text) + " ")
		switch {
		case len(cmd) > 0 && (cmd[0] == "/start" || cmd[0] == "/plans"):
			b.send(ctx, m.Chat.ID, b.status(m.From.ID))
			for _, plan := range []string{Plus, Max} {
				b.invoice(ctx, m.Chat.ID, plan)
			}
		case len(cmd) > 0 && cmd[0] == "/status":
			b.send(ctx, m.Chat.ID, b.status(m.From.ID))
		default:
			b.send(ctx, m.Chat.ID, "Здесь можно оплатить тариф для разговоров с Рейной. /plans — тарифы, /status — ваш тариф.")
		}
	}
}

func title(plan string) string {
	switch plan {
	case Plus:
		return "Plus"
	case Max:
		return "Max"
	}
	return "Старт"
}

func (b *Bot) status(id int64) string {
	u := b.Store.Get(id, b.now())
	l := b.Limits()
	per := func(n int) string {
		if n <= 0 {
			return "без лимита"
		}
		return fmt.Sprintf("%d разговоров в день", n)
	}
	s := fmt.Sprintf("Ваш тариф: %s (%s).", title(u.Plan), per(l.of(u.Plan)))
	if u.Plan != Free {
		s += " Действует до " + u.Until.Format("02.01.2006") + "."
	}
	_, _, days := b.Prices()
	return s + fmt.Sprintf("\n\nPlus: %s. Max: %s. Оплата в Telegram Stars, на %d дней, без автопродления.", per(l.Plus), per(l.Max), days)
}

func (b *Bot) invoice(ctx context.Context, chat int64, plan string) {
	_, _, days := b.Prices()
	l := b.Limits()
	desc := fmt.Sprintf("%d дней разговоров с Рейной: %d в день.", days, l.of(plan))
	if l.of(plan) <= 0 {
		desc = fmt.Sprintf("%d дней разговоров с Рейной без дневного лимита.", days)
	}
	err := b.call(ctx, "sendInvoice", map[string]any{"chat_id": chat, "title": "Рейна · " + title(plan), "description": desc, "payload": plan,
		"provider_token": "", "currency": "XTR", "prices": []map[string]any{{"label": title(plan), "amount": b.price(plan)}}}, nil)
	if err != nil {
		log.Printf("%v", err)
	}
}

func (b *Bot) send(ctx context.Context, chat int64, text string) {
	if err := b.call(ctx, "sendMessage", map[string]any{"chat_id": chat, "text": text}, nil); err != nil {
		log.Printf("%v", err)
	}
}
