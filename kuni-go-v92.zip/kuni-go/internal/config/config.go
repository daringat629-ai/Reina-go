package config

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"
	"sort"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"kuni/internal/store"
	"kuni/internal/util"
)

// FileName is the runtime configuration file in the working directory.
const FileName = "config.toml"

// Config mirrors the sections of the C++ config.toml.
type Config struct {
	// [general]
	CharacterName   string
	CharacterNick   string
	PapikName       string
	PapikChatID     int64
	TelegramEnabled bool

	// [telegram]
	Mode           string // user | bot
	Phone          string
	TelegramQR     bool
	TelegramPass   string
	TDLibDir       string
	BotToken       string
	TelegramAPI    string
	TelegramAPIID  int64
	TelegramHash   string
	Lockdown       string // none | contacts_only | papik_only
	CanJoinChats   bool
	CanLeaveChats  bool
	SessionIdle    time.Duration
	Proactive      time.Duration // 0 = disabled
	MaxToolRounds  int
	DebounceWindow time.Duration
	DebounceMax    time.Duration // private chats: read at the latest this long after the first new message (0 = no limit)

	// [llm]
	LLMBaseURL                                     string
	LLMAPIKey                                      string
	LightBaseURL                                   string
	FallbackModel, FallbackBaseURL, FallbackAPIKey string
	LightAPIKey                                    string
	EmbeddingAPIKey                                string
	LLMModel                                       string
	LightModel                                     string
	VisionModel                                    string
	PriceIn                                        float64 // $ per 1M tokens, 0 = unknown
	PriceOut                                       float64
	LightPriceIn                                   float64
	LightPriceOut                                  float64
	FastModel                                      string
	CodeModel, CodeBaseURL, CodeAPIKey             string
	WorkModel, WorkBaseURL, WorkAPIKey             string
	WorkReasoning                                  string
	DeepModel, DeepBaseURL, DeepAPIKey             string
	FastPriceIn                                    float64
	FastPriceOut                                   float64
	FastGroups                                     bool
	DailyTokenLimit                                int64
	EmbeddingBaseURL                               string
	EmbeddingModel                                 string
	RequestTimeout                                 time.Duration
	Temperature                                    float64 // < 0 = unset
	Reasoning                                      string
	FastRounds                                     bool
	FastShortChars                                 int
	CachePrompt                                    bool

	// [proxy]
	ProxyEnabled bool
	ProxyPort    int
	ProxyAPIKey  string

	// [memory]
	DiaryDir          string
	WorkingMemoryFile string
	DiaryTokenTrigger int
	SleepMaxTime      time.Duration
	ConfidenceFactor  float64
	MaxRelatedEntries int

	// [maintenance]
	MaintEnabled    bool
	AlertsEnabled   bool
	ReportEnabled   bool
	ReportHour      int
	DiskWarnPercent int
	CacheDays       int
	BackupEnabled   bool
	BackupKeep      int
	BackupDir       string

	// [autonomy]
	AutonomyEnabled      bool
	AutonomyInner        bool
	AutonomyMinMins      int
	AutonomyMaxMins      int
	AutonomyQuietFrom    string
	AutonomyQuietTo      string
	AutonomyTimezone     string
	AutonomyMaxPerDay    int
	AutonomyChatCooldown int // minutes

	// [presence]
	PresenceEnabled  bool
	ReadDelayMin     int // seconds before she notices a message in a private chat
	ReadDelayMax     int
	LateReplyPercent int // chance (night or asleep) that she answers much later
	LateReplyMinMins int
	LateReplyMaxMins int
	OfflineAfterSecs int
	TypingPerCharMs  int
	TypoChance       float64
	CycleOn          bool    // a monthly cycle with real symptoms colours her days
	CycleMode        string  // auto | random | period | follicular | ovulation | luteal | pms
	CycleLen         int64   // days in the cycle
	CycleStart       string  // first day of a period, YYYY-MM-DD (any past one; the cycle repeats from it)
	DayLife          bool    // her own small day (busy hours, a small thing that happened) is put in front of chats
	TypoFixChance    float64 // after a typo: the chance that she sends a quick "*word" with the right spelling
	MirrorModality   bool

	// [capabilities]
	WebSearchEnabled     bool
	WebSearchURL         string // SearXNG-compatible JSON endpoint, or https://ollama.com/api/web_search
	WebSearchKey         string
	SDEnabled            bool
	SDURL                string
	SDReference          string
	SDReferenceStrength  float64
	STTEnabled           bool
	STTURL               string
	STTModel             string
	STTKey               string // key for stt_url (Groq, OpenAI...)
	TTSBackend           string // none | openai | elevenlabs
	TTSURL               string
	TTSKey               string
	TTSModel             string
	TTSVoice             string
	FFmpegPath           string
	ReadLinks            bool
	LinkMaxChars         int
	DocMaxMB             int
	DocMaxChars          int
	MediaMaxMB           int
	UseStickers          bool
	LazyTools            bool
	OwnerTools           bool
	SelfRepair           bool
	PhoneADB             string
	MachineFeeling       bool
	OwnerRhythm          bool
	OwnerAllTools        bool
	ConfirmRisky         bool
	ShareDirs            string
	ParallelTools        bool
	BrowserEnabled       bool
	BrowserPath          string
	BrowserXvfb          bool
	BrowserNoSandbox     bool
	BrowserWidth         int
	BrowserHeight        int
	BrowserSteps         int
	BrowserIdleSecs      int
	BrowserFast          bool
	BrowserBlockHosts    string
	Services             string
	MailIMAP             string
	MailSMTP             string
	MailUser             string
	MailPassword         string
	MailFrom             string
	MailPerDay           int
	CalendarURLs         string
	DesktopSession       string
	DesktopDisplay       string
	WorldStayHome        bool
	LearnEnabled         bool
	RoomLifeEnabled      bool
	CortexEnabled        bool
	MindEnabled          bool
	MindAnswerAlone      bool
	MindWithOwner        bool
	MindMinTrials        int
	MindHitRate          float64
	MindMinSim           float64
	MindCompose          bool
	MindReservoir        bool
	CortexNeurons        int
	LearnEvery           time.Duration
	DesktopEnabled       bool
	WorldEnabled         bool
	WorldKey             string
	WorldModel           string
	WorldThinkSecs       int
	WorldAutobuild       bool
	DesktopWidth         int
	DesktopHeight        int
	DesktopSteps         int
	DesktopIdleSecs      int
	WorkEnabled          bool
	BillingEnabled       bool   // plans and daily limits for people other than the owner
	BillingBotToken      string // token of the small payment bot (Telegram Stars)
	BillingBotName       string // its @username, shown to people who ran out of messages
	BillingFreePerDay    int64
	BillingPlusPerDay    int64
	BillingMaxPerDay     int64
	BillingPlusStars     int64
	BillingMaxStars      int64
	BillingPeriodDays    int64
	BillingPlusDayStars  int64
	BillingPlusWeekStars int64
	BillingMaxDayStars   int64
	BillingMaxWeekStars  int64
	BillingRefDays       int64
	BillingSupport       string
	BillingIcons         string // custom emoji ids for the four menu buttons: plans,profile,friends,help
	BillingAdminToken    string // the owner's own admin bot
	BillingQR            bool   // pay by bank QR (manual check by the owner)
	BillingCurrency      string // the currency prices are set and paid in (RUB, USD, KGS...)
	BillingRates         string // how much one unit of billing.currency is in other currencies, for showing prices
	BillingPlusDayPrice  int64
	BillingPlusWeekPrice int64
	BillingPlusPrice     int64
	BillingMaxDayPrice   int64
	BillingMaxWeekPrice  int64
	BillingMaxPrice      int64
	BillingPacks         string  // token packs on sale, comma separated
	BillingMargin        float64 // a pack costs this many times what its tokens cost at the main model's price
	BillingStarUSD       float64 // what one Telegram Star brings the owner, in USD
	BillingEstTokens     int64   // tokens one conversation is assumed to cost until there is enough history
	BillingFreeTokens    int64   // free conversations also stop after this many tokens a day (0 = no token cap)
	BillingRefTokens     int64   // invite bonus in tokens, for both sides
	BillingHer           string  // her @username for the "write to her" button in the pay bot
	BillingWebApp        string  // public https address of the Mini App (<tunnel>/app/); empty = no app
	UpdateRepo           string  // GitHub owner/name whose releases carry new builds
	UpdateAuto           bool    // install a new release by itself
	UpdateCheckHours     int64   // how often to look for a new release
	WorkEveryMins        int
	WorkMaxRuns          int
	BackupSend           bool
	BrowserPasswords     bool
	MoodEnabled          bool
	StopAfterSend        bool
	TypingThinking       bool
	ShellDir             string
	ShellUser            string
	ShellHardBlock       bool
	ShellTimeout         int64
	ForceTools           bool
	RefusalGuard         bool
	MaxMessageChars      int  // a message longer than this is split into several (0 = no limit)
	SmartSplit           bool // a message with several sentences is cut where a person would start a new bubble
	PackChars            int  // short lines of one answer are glued into one message up to this many characters (0 = every line is its own message)
	MaxBubbles           int  // most messages in one answer (0 = no limit); the rest is glued to the last ones
	TypingMinMs          int
	TypingMaxMs          int
	HistoryKeep          int
	ContextChars         int
	AutoPersonCards      bool
	AutoPersonAbout      bool
	AutoPromises         bool
	TicGuard             bool
	IgnorePercent        int
	BriefPercent         int
	LifeEnabled          bool
	SlowPercent          int
	GroupInterestWords   string
	GroupInterestPercent int
	VoicePercent         int
	ToolResultChars      int
	GroupReplyMode       string // addressed | all
	GroupChime           int
	GroupDebounce        time.Duration
	CommandUsers         string
	GroupMaxWait         time.Duration
	GroupCooldown        time.Duration

	// [misc]
	MetricsEnabled bool
	DebugUI        bool
	AdminToken     string
	PanelChats     bool
	PanelTakeover  bool
	DeskOverview   bool
	DataDir        string
	DebugPrompt    bool
	PromptsDir     string

	// Warnings are the problems Load found and fixed or ignored (unknown keys, values out of range...). Not a setting.
	Warnings []string

	loc *time.Location // AutonomyTimezone resolved once by Load (nil: resolved on demand)
}

type field struct {
	section, key, comment string
	def                   any
	ptr                   func(c *Config) any
}

// full is "section.key".
func (f field) full() string { return f.section + "." + f.key }

// unit is the time unit of a duration key, taken from its name: *_ms are milliseconds, everything else seconds.
func (f field) unit() time.Duration {
	if strings.HasSuffix(f.key, "_ms") {
		return time.Millisecond
	}
	return time.Second
}

// schema is the table of every key, built once; index finds a key by "section.key".
var (
	schema = fields()
	index  = func() map[string]*field {
		m := make(map[string]*field, len(schema))
		for i := range schema {
			m[schema[i].full()] = &schema[i]
		}
		return m
	}()
)

func fields() []field {
	f := func(s, k, comment string, def any, ptr func(c *Config) any) field {
		return field{s, k, comment, def, ptr}
	}
	return []field{
		f("general", "character_name", "the name the character uses for herself", "Reina Veil", func(c *Config) any { return &c.CharacterName }),
		f("general", "character_nickname", "", "@kunii_chan", func(c *Config) any { return &c.CharacterNick }),
		f("general", "papik_name", "the instance owner's nickname", "Alex2772", func(c *Config) any { return &c.PapikName }),
		f("general", "papik_chat_id", "the instance owner's Telegram user ID", int64(0), func(c *Config) any { return &c.PapikChatID }),
		f("general", "telegram_enabled", "set to false to run as a standalone proxy without Telegram", false, func(c *Config) any { return &c.TelegramEnabled }),

		f("telegram", "mode", "user = log in as a regular account via tdlib (like the C++ version; build with -tags tdlib); bot = Bot API", "user", func(c *Config) any { return &c.Mode }),
		f("telegram", "qr_login", "user mode: sign in by a QR code shown as a picture at http://<this computer>:<proxy.port>/admin/qr (needs misc.admin_token); scan it in Telegram > Settings > Devices > Link Desktop Device. false = the code is typed in the console", true, func(c *Config) any { return &c.TelegramQR }),
		f("telegram", "cloud_password", "user mode: the two-step verification password, if the account has one (asked in the console when empty)", "", func(c *Config) any { return &c.TelegramPass }),
		f("telegram", "phone_number", "user mode: phone to log in with (asked on stdin if empty)", "", func(c *Config) any { return &c.Phone }),
		f("telegram", "tdlib_dir", "user mode: tdlib database directory (keeps the login)", "tdlib", func(c *Config) any { return &c.TDLibDir }),
		f("telegram", "bot_token", "bot mode: token from @BotFather", "", func(c *Config) any { return &c.BotToken }),
		f("telegram", "api_base", "Bot API base URL", "https://api.telegram.org", func(c *Config) any { return &c.TelegramAPI }),
		f("telegram", "api_id", "user mode: get from https://my.telegram.org", int64(0), func(c *Config) any { return &c.TelegramAPIID }),
		f("telegram", "api_hash", "user mode: get from https://my.telegram.org", "", func(c *Config) any { return &c.TelegramHash }),
		f("telegram", "lockdown", "none = everyone | contacts_only = groups, the owner and contacts | papik_only = only the owner chat", "none", func(c *Config) any { return &c.Lockdown }),
		f("telegram", "can_join_chats", "", true, func(c *Config) any { return &c.CanJoinChats }),
		f("telegram", "can_leave_chats", "", true, func(c *Config) any { return &c.CanLeaveChats }),
		f("telegram", "session_idle_secs", "dump the conversation to the diary after this much silence", int64(900), func(c *Config) any { return &c.SessionIdle }),
		f("telegram", "proactive_interval_secs", "0 disables acting proactively", int64(1800), func(c *Config) any { return &c.Proactive }),
		f("telegram", "max_tool_rounds", "max LLM<->tool round-trips per turn", int64(12), func(c *Config) any { return &c.MaxToolRounds }),
		f("telegram", "debounce_ms", "private chats: wait until the person has been quiet this long, then read everything they wrote and answer once (every new message restarts the wait)", int64(6000), func(c *Config) any { return &c.DebounceWindow }),
		f("telegram", "debounce_max_secs", "private chats: however long they keep writing, read at the latest this long after the first new message (0 = no limit)", int64(40), func(c *Config) any { return &c.DebounceMax }),

		f("llm", "base_url", "OpenAI-compatible endpoint: Inception https://api.inceptionlabs.ai/v1/ (key from platform.inceptionlabs.ai), or local Ollama http://localhost:11434/v1/", "https://api.inceptionlabs.ai/v1/", func(c *Config) any { return &c.LLMBaseURL }),
		f("llm", "api_key", "bearer key, empty if not needed", "", func(c *Config) any { return &c.LLMAPIKey }),
		f("llm", "model", "chat model name, e.g. mercury-3 (Inception; text only: photos need vision_model)", "mercury-3", func(c *Config) any { return &c.LLMModel }),
		f("llm", "light_model", "cheap/fast model for background thinking (ask, sleep, diary, compact); empty = use model. Same endpoint and key as model", "", func(c *Config) any { return &c.LightModel }),
		f("llm", "fallback_model", "spare model: when the main one fails (endpoint down, no money, rate limit) the same request goes once to this model so she keeps answering. Must support tool calls. Empty = off", "", func(c *Config) any { return &c.FallbackModel }),
		f("llm", "fallback_base_url", "endpoint of fallback_model (e.g. https://openrouter.ai/api/v1/); empty = base_url", "", func(c *Config) any { return &c.FallbackBaseURL }),
		f("llm", "fallback_api_key", "key for fallback_base_url; empty = api_key", "", func(c *Config) any { return &c.FallbackAPIKey }),
		f("llm", "light_base_url", "own endpoint for light_model (diary, sleep, memory, people cards), e.g. https://openrouter.ai/api/v1/; empty = base_url", "", func(c *Config) any { return &c.LightBaseURL }),
		f("llm", "light_api_key", "key for light_base_url; empty = api_key", "", func(c *Config) any { return &c.LightAPIKey }),
		f("llm", "vision_model", "model that looks at pictures (photos in chats, stickers, browser and desktop screenshots); empty = model. Must support images (Inception Mercury models are text only): it goes to light_base_url / light_api_key when they are set, e.g. OpenRouter with google/gemini-2.5-flash", "", func(c *Config) any { return &c.VisionModel }),
		f("llm", "price_in_per_m", "price of 1M input tokens of `model` in USD (only to show the cost on the panel; 0 = unknown). mercury-3: 0.10 at launch, 0.20 regular", 0.10, func(c *Config) any { return &c.PriceIn }),
		f("llm", "price_out_per_m", "price of 1M output tokens of `model` in USD. mercury-3: 0.35 at launch, 0.70 regular", 0.35, func(c *Config) any { return &c.PriceOut }),
		f("llm", "light_price_in_per_m", "same for light_model", 0.0, func(c *Config) any { return &c.LightPriceIn }),
		f("llm", "light_price_out_per_m", "same for light_model", 0.0, func(c *Config) any { return &c.LightPriceOut }),
		f("llm", "fast_model", "a quick model WITHOUT mandatory thinking (e.g. mercury-2.5 or mercury-3 on Inception): it answers the fast rounds (short private messages, rounds after a tool result, browser steps, group banter) instead of the main model, so she does not think for ages. The main model still handles everything hard, and she can hand it jobs with #delegate. Empty = the main model does all. Same endpoint and key", "", func(c *Config) any { return &c.FastModel }),
		f("llm", "code_model", "the model that writes code for her #vibe_code tool (quick vibe coding: whole files in seconds), e.g. mercury-2.5 on Inception; empty = fast_model, then model", "", func(c *Config) any { return &c.CodeModel }),
		f("llm", "code_base_url", "own endpoint for code_model, e.g. https://openrouter.ai/api/v1/ (mercury-2.5 is cheaper there); empty = base_url", "", func(c *Config) any { return &c.CodeBaseURL }),
		f("llm", "code_api_key", "key for code_base_url; empty = api_key", "", func(c *Config) any { return &c.CodeAPIKey }),
		f("llm", "work_model", "the model for JOBS, not for chat: the rounds that follow web search, reading pages, the browser, the desktop, the shell, files and code. It sees the tool results and plans the next step, quick and cheap, e.g. mercury-2.5. Anything she says to people is still written by `model`, so her voice stays one. Empty = off", "", func(c *Config) any { return &c.WorkModel }),
		f("llm", "work_base_url", "own endpoint for work_model; empty = base_url", "", func(c *Config) any { return &c.WorkBaseURL }),
		f("llm", "work_api_key", "key for work_base_url; empty = api_key", "", func(c *Config) any { return &c.WorkAPIKey }),
		f("llm", "work_reasoning", "reasoning of work_model: off, low, medium or high (empty = low)", "", func(c *Config) any { return &c.WorkReasoning }),
		f("llm", "deep_model", "a strong model for the rare heavy thinking: sleep (memory consolidation), self-reflection. A few requests a day, so it can be an expensive one. Empty = light_model / fast_model as before", "", func(c *Config) any { return &c.DeepModel }),
		f("llm", "deep_base_url", "own endpoint for deep_model, e.g. https://openrouter.ai/api/v1/; empty = base_url", "", func(c *Config) any { return &c.DeepBaseURL }),
		f("llm", "deep_api_key", "key for deep_base_url; empty = api_key", "", func(c *Config) any { return &c.DeepAPIKey }),
		f("llm", "fast_price_in_per_m", "same for fast_model", 0.0, func(c *Config) any { return &c.FastPriceIn }),
		f("llm", "fast_price_out_per_m", "same for fast_model", 0.0, func(c *Config) any { return &c.FastPriceOut }),
		f("llm", "fast_groups", "with fast_model set, the first round of a reply in a group chat is also answered by the fast model (off by default: a non-thinking model reads a busy group worse and talks nonsense)", false, func(c *Config) any { return &c.FastGroups }),
		f("llm", "fast_rounds", "think only where it matters: rounds that follow a tool result (and a short private message) are answered with reasoning switched off, several times faster. Turn off if she gets sloppy at multi-step work", false, func(c *Config) any { return &c.FastRounds }),
		f("llm", "fast_short_chars", "a private message up to this many characters (no files, no media) is also answered without reasoning on its first round. 0 = the first round always thinks", int64(0), func(c *Config) any { return &c.FastShortChars }),
		f("llm", "daily_token_limit", "soft daily limit (input+output tokens): past it she stops acting on her own and you get a warning; at 3x every LLM request is refused until tomorrow. 0 = no limit", int64(0), func(c *Config) any { return &c.DailyTokenLimit }),
		f("llm", "embedding_base_url", "endpoint for /embeddings (empty = base_url; with Inception, which has no embeddings, empty = local Ollama http://localhost:11434/v1/)", "", func(c *Config) any { return &c.EmbeddingBaseURL }),
		f("llm", "embedding_api_key", "key for embedding_base_url (e.g. your OpenRouter key); empty = api_key", "", func(c *Config) any { return &c.EmbeddingAPIKey }),
		f("llm", "embedding_model", "embedding model name", "nomic-embed-text", func(c *Config) any { return &c.EmbeddingModel }),
		f("llm", "request_timeout_secs", "", int64(300), func(c *Config) any { return &c.RequestTimeout }),
		f("llm", "cache_prompt", "mark the system prompt cacheable for Claude models (cuts the cost of each request); other models cache a stable prefix by themselves", true, func(c *Config) any { return &c.CachePrompt }),
		f("llm", "reasoning", "reasoning control: empty = model default (mercury-3: low), off = fastest (Inception: instant), low|medium|high", "high", func(c *Config) any { return &c.Reasoning }),
		f("llm", "temperature", "negative = server default", -1.0, func(c *Config) any { return &c.Temperature }),

		f("maintenance", "enabled", "watch free disk space (warns you in Telegram, clears the image cache) and keep backups", true, func(c *Config) any { return &c.MaintEnabled }),
		f("alerts", "enabled", "she tells you in Telegram when something breaks: the model stops answering (key, balance), Telegram throws errors or slows her down", true, func(c *Config) any { return &c.AlertsEnabled }),
		f("report", "enabled", "once a day she sends you a short report of yesterday's tokens, requests, cost and free disk", true, func(c *Config) any { return &c.ReportEnabled }),
		f("report", "hour", "local hour (0-23, autonomy.timezone) when the daily report is sent", int64(9), func(c *Config) any { return &c.ReportHour }),
		f("maintenance", "disk_warn_percent", "warn when less than this percent of the disk is free (or under 500 MB)", int64(10), func(c *Config) any { return &c.DiskWarnPercent }),
		f("maintenance", "cache_days", "when the disk is low, delete cached image descriptions older than this many days", int64(30), func(c *Config) any { return &c.CacheDays }),
		f("maintenance", "backup_enabled", "daily backup of the diary, memory, prompts, mood and config (config contains your keys: the archive is private, mode 0600)", true, func(c *Config) any { return &c.BackupEnabled }),
		f("maintenance", "backup_keep", "how many daily backups to keep", int64(7), func(c *Config) any { return &c.BackupKeep }),
		f("maintenance", "backup_send", "once a day send a copy of her memory (diary, people, reminders, job queue, mood) to your private chat: the only copy that survives a dead container. The sent copy never contains config.toml (keys and passwords)", true, func(c *Config) any { return &c.BackupSend }),
		f("maintenance", "backup_dir", "where backups go (empty = <data_dir>/backups)", "", func(c *Config) any { return &c.BackupDir }),

		f("autonomy", "enabled", "she acts on her own: writes first to people, speaks her mind, goes to sleep. Respects lockdown, quiet hours and the limits below", true, func(c *Config) any { return &c.AutonomyEnabled }),
		f("autonomy", "inner_monologue", "when awake she thinks to herself every hour or so (a few sentences, kept in inner_monologue.md); the latest thoughts colour what she says next. Costs a few small requests a day", true, func(c *Config) any { return &c.AutonomyInner }),
		f("autonomy", "min_interval_mins", "shortest pause between her own initiatives", int64(30), func(c *Config) any { return &c.AutonomyMinMins }),
		f("autonomy", "max_interval_mins", "longest pause between her own initiatives (the pause is random between min and max)", int64(120), func(c *Config) any { return &c.AutonomyMaxMins }),
		f("autonomy", "quiet_from", "night starts (HH:MM): no initiatives, she is sleepy. Empty = no night", "01:00", func(c *Config) any { return &c.AutonomyQuietFrom }),
		f("autonomy", "quiet_to", "night ends (HH:MM)", "09:00", func(c *Config) any { return &c.AutonomyQuietTo }),
		f("autonomy", "timezone", "IANA zone for quiet hours, e.g. Asia/Bishkek. Empty = the server's zone (often UTC)", "Asia/Bishkek", func(c *Config) any { return &c.AutonomyTimezone }),
		f("autonomy", "max_messages_per_day", "most messages she may start on her own per day (your own chat is not limited)", int64(20), func(c *Config) any { return &c.AutonomyMaxPerDay }),
		f("autonomy", "chat_cooldown_mins", "minimum gap between her initiative messages to the same chat", int64(90), func(c *Config) any { return &c.AutonomyChatCooldown }),

		f("proxy", "enabled", "run the OpenAI-compatible proxy", true, func(c *Config) any { return &c.ProxyEnabled }),
		f("proxy", "port", "port of the OpenAI-compatible proxy (the admin panel, /metrics and /debug share it)", int64(10434), func(c *Config) any { return &c.ProxyPort }),
		f("proxy", "api_key", "key clients must send (Authorization: Bearer <key>) to use the proxy. Empty = the proxy answers only this machine (127.0.0.1): it spends your LLM key and can read her diary, so never leave it open to the internet", "", func(c *Config) any { return &c.ProxyAPIKey }),

		f("memory", "diary_dir", "where diary entries (*.md) are stored", "data/diary", func(c *Config) any { return &c.DiaryDir }),
		f("memory", "working_memory_file", "", "data/working_memory.md", func(c *Config) any { return &c.WorkingMemoryFile }),
		f("memory", "diary_token_count_trigger", "stop merging related entries after this many characters", int64(4000), func(c *Config) any { return &c.DiaryTokenTrigger }),
		f("memory", "sleep_max_time_secs", "how long one sleep consolidation may run", int64(600), func(c *Config) any { return &c.SleepMaxTime }),
		f("memory", "confidence_factor", "weight of an entry's stored confidence in RAG ranking", 0.1, func(c *Config) any { return &c.ConfidenceFactor }),
		f("memory", "max_related_entries", "how many diary entries are injected into a prompt", int64(8), func(c *Config) any { return &c.MaxRelatedEntries }),

		f("presence", "enabled", "living presence: she does not answer instantly (reads after a pause), types as long as the text takes, and sometimes answers late at night", true, func(c *Config) any { return &c.PresenceEnabled }),
		f("presence", "read_delay_min_secs", "shortest pause before she reads a new message in a private chat (groups wait longer, your own chat much less)", int64(2), func(c *Config) any { return &c.ReadDelayMin }),
		f("presence", "read_delay_max_secs", "longest pause before she reads a new message", int64(10), func(c *Config) any { return &c.ReadDelayMax }),
		f("presence", "late_reply_percent", "at night (autonomy quiet hours) this % of messages from others is answered much later; while she is asleep always. Your own chat is never delayed", int64(35), func(c *Config) any { return &c.LateReplyPercent }),
		f("presence", "late_reply_min_mins", "a late answer comes after at least this many minutes", int64(5), func(c *Config) any { return &c.LateReplyMinMins }),
		f("presence", "late_reply_max_mins", "...and at most this many", int64(40), func(c *Config) any { return &c.LateReplyMaxMins }),
		f("presence", "slow_percent", "chance in percent that a normal message is noticed much later (she was busy): minutes in other chats, up to a minute in yours", int64(6), func(c *Config) any { return &c.SlowPercent }),
		f("realism", "tic_guard", "she watches her own last messages and is told to stop repeating habits (the same opening word, 'папик' in every line, a question at the end of everything, emoji in a row)", true, func(c *Config) any { return &c.TicGuard }),
		f("realism", "ignore_percent", "chance in percent that a bare laugh or 'ok' gets only a reaction or silence instead of an answer", int64(25), func(c *Config) any { return &c.IgnorePercent }),
		f("realism", "brief_percent", "chance in percent that a short message gets a one-to-three-word answer", int64(15), func(c *Config) any { return &c.BriefPercent }),
		f("realism", "life", "she knows roughly what she is doing at this hour (breakfast, coding, a series), the same all day, so she never contradicts herself", true, func(c *Config) any { return &c.LifeEnabled }),
		f("presence", "offline_after_secs", "how long after the last turn the account still shows online", int64(20), func(c *Config) any { return &c.OfflineAfterSecs }),

		f("capabilities", "web_search_enabled", "", false, func(c *Config) any { return &c.WebSearchEnabled }),
		f("capabilities", "web_search_url", "SearXNG (…/search) or https://ollama.com/api/web_search", "http://localhost:8888/search", func(c *Config) any { return &c.WebSearchURL }),
		f("capabilities", "web_search_key", "bearer key (ollama web search)", "", func(c *Config) any { return &c.WebSearchKey }),
		f("capabilities", "stable_diffusion_enabled", "photos via Stable Diffusion WebUI (--api)", false, func(c *Config) any { return &c.SDEnabled }),
		f("capabilities", "stable_diffusion_url", "", "http://localhost:7860", func(c *Config) any { return &c.SDURL }),
		f("capabilities", "stable_diffusion_reference", "her reference picture: every photo is made from it (img2img) so she always looks the same. A file name inside data_dir or a full path; the built-in one is written there on first start. 'off' = from the text alone", "reference.jpg", func(c *Config) any { return &c.SDReference }),
		f("capabilities", "stable_diffusion_reference_strength", "how far a photo may move away from the reference: 0.3 = almost the same picture, 0.6 = same face and style but new pose and scene, 0.8 = only colours and mood stay", 0.6, func(c *Config) any { return &c.SDReferenceStrength }),
		f("capabilities", "stt_enabled", "voice/video transcription (Whisper, OpenAI-compatible)", false, func(c *Config) any { return &c.STTEnabled }),
		f("capabilities", "stt_url", "OpenAI-compatible Whisper endpoint: your own server, or e.g. https://api.groq.com/openai/v1/ (model whisper-large-v3-turbo) or https://api.openai.com/v1/ (whisper-1)", "http://localhost:9000/v1/", func(c *Config) any { return &c.STTURL }),
		f("capabilities", "stt_model", "", "whisper-1", func(c *Config) any { return &c.STTModel }),
		f("capabilities", "stt_key", "API key for stt_url (empty = no key, for your own server)", "", func(c *Config) any { return &c.STTKey }),
		f("capabilities", "tts_backend", "none | openai | elevenlabs", "none", func(c *Config) any { return &c.TTSBackend }),
		f("capabilities", "tts_url", "OpenAI-compatible base (e.g. OmniVoice http://localhost:8880/v1/) or ElevenLabs base", "http://localhost:8880/v1/", func(c *Config) any { return &c.TTSURL }),
		f("capabilities", "tts_key", "", "", func(c *Config) any { return &c.TTSKey }),
		f("capabilities", "tts_model", "", "tts-1", func(c *Config) any { return &c.TTSModel }),
		f("capabilities", "tts_voice", "voice name / ElevenLabs voice id", "alloy", func(c *Config) any { return &c.TTSVoice }),
		f("capabilities", "read_links", "she can open links people send (public web pages only; never your server, LAN or Tailscale)", true, func(c *Config) any { return &c.ReadLinks }),
		f("capabilities", "link_max_chars", "most characters of a web page that she reads at once (she can read on)", int64(5000), func(c *Config) any { return &c.LinkMaxChars }),
		f("capabilities", "document_max_mb", "documents (txt, md, csv, docx, xlsx, pdf...) from anyone up to this size can be read", int64(10), func(c *Config) any { return &c.DocMaxMB }),
		f("capabilities", "document_max_chars", "most characters of a document that she reads at once (she can read on)", int64(6000), func(c *Config) any { return &c.DocMaxChars }),
		f("capabilities", "media_max_mb", "videos, round videos and gifs larger than this are not watched", int64(25), func(c *Config) any { return &c.MediaMaxMB }),
		f("capabilities", "ffmpeg_path", "needed for video transcription", "ffmpeg", func(c *Config) any { return &c.FFmpegPath }),
		f("telegram", "max_message_chars", "one Telegram message is at most this many characters; longer text is sent as several messages (no limit on their number). 0 = no limit", int64(220), func(c *Config) any { return &c.MaxMessageChars }),
		f("telegram", "smart_split", "smart splitting like a person: a short reaction first and alone, a closing question as its own message, sometimes a long message cut in the middle at a sentence end", true, func(c *Config) any { return &c.SmartSplit }),
		f("telegram", "pack_chars", "short lines of one answer are glued into a single message up to this many characters, like a person writing a few sentences at once. 0 = every line is its own message (how people really text)", int64(0), func(c *Config) any { return &c.PackChars }),
		f("telegram", "max_bubbles", "most messages in one answer; if the model wrote more, the shortest neighbours are glued together. 0 = no limit", int64(6), func(c *Config) any { return &c.MaxBubbles }),
		f("telegram", "typing_min_ms", "how long the 'typing...' status shows before each message (min)", int64(3000), func(c *Config) any { return &c.TypingMinMs }),
		f("telegram", "mirror_modality", "answer the way she was addressed: a voice message for a voice message (when TTS is on), a sticker or reaction for a sticker", true, func(c *Config) any { return &c.MirrorModality }),
		f("telegram", "cycle", "a monthly cycle (period, ovulation, PMS) with believable symptoms and mood swings; she feels them in her own way and does not know why", true, func(c *Config) any { return &c.CycleOn }),
		f("telegram", "cycle_mode", "auto = by the calendar from cycle_start; random = a new random phase every day; or force one now: period, follicular, ovulation, luteal, pms", "auto", func(c *Config) any { return &c.CycleMode }),
		f("telegram", "cycle_length", "days in her cycle (21-40)", int64(28), func(c *Config) any { return &c.CycleLen }),
		f("telegram", "cycle_start", "the first day of one of her periods, YYYY-MM-DD; the cycle repeats from it (empty = a fixed date)", "", func(c *Config) any { return &c.CycleStart }),
		f("telegram", "day_life", "give her a small life of her own each day: a busy stretch when she answers briefly or later, and one small thing that happened to her, so she is not always free and perfect", true, func(c *Config) any { return &c.DayLife }),
		f("telegram", "typo_fix_chance", "after a typo, the chance that she sends a quick \"*word\" with the correct spelling a moment later (like a person); 0 = never", 0.5, func(c *Config) any { return &c.TypoFixChance }),
		f("telegram", "typo_chance", "chance of a human typo (two letters swapped / a neighbouring key) in a message, for each kind; 0 = never. Links, code, mentions and short texts are never touched", 0.02, func(c *Config) any { return &c.TypoChance }),
		f("telegram", "typing_per_char_ms", "typing time per character (a longer message types longer, between ~1 s and typing_max_ms). 0 = always random between typing_min_ms and typing_max_ms", int64(55), func(c *Config) any { return &c.TypingPerCharMs }),
		f("telegram", "typing_max_ms", "how long the 'typing...' status shows before each message (max)", int64(4000), func(c *Config) any { return &c.TypingMaxMs }),
		f("telegram", "force_tool_call", "require the model to call a tool (reply, react or #wait) on the first round of every turn; fixes models that answer in plain text instead of calling #send_telegram_message", true, func(c *Config) any { return &c.ForceTools }),
		f("telegram", "refusal_guard", "in a private chat, an answer like \"I can't\" / \"I tried, it does not work\" given without a single tool call is held back once: she is told to try with her tools and the next rounds run on the main model. Fixes weak or hurried models that give up on tasks the tools can do (e.g. sending /start to a bot)", true, func(c *Config) any { return &c.RefusalGuard }),
		f("capabilities", "mood_enabled", "mood scale 0-100: low = quiet and grumpy (never rude), middle = friendly, high = flirty; shifts by events and drifts back to normal", true, func(c *Config) any { return &c.MoodEnabled }),
		f("capabilities", "share_dirs", "folders she may send files from in ANY chat (#share_file), besides her own workspace; comma-separated, e.g. /mnt,/home/reina/public. Empty = workspace only. In the owner's chat she may send any file", "", func(c *Config) any { return &c.ShareDirs }),
		f("capabilities", "confirm_risky", "risky actions (rm -r, kill, reboot, uninstall, git push, stopping services, sending e-mail or a file to someone else, self-update) wait for your /yes in Telegram before they run; /no cancels. Catastrophic commands are always refused", true, func(c *Config) any { return &c.ConfirmRisky }),
		f("capabilities", "owner_all_tools", "in the owner's chat every tool group (browser, desktop, media, polls...) is open from the first round, not unlocked by trigger words; costs some prompt tokens, but she never says she has no hands", true, func(c *Config) any { return &c.OwnerAllTools }),
		f("llm", "parallel_tools", "run independent read-only tool calls of one round (searches, page reads, lookups) at the same time", true, func(c *Config) any { return &c.ParallelTools }),
		f("capabilities", "machine_feeling", "she describes herself as a computational process, not as a body: the prompt gets ten numbers (load, free capacity, prediction error, goal conflict...) instead of the biological texts of the body, feelings and senses, and the program itself shortens her answers, limits tool rounds and gives her the right to go quiet by those numbers. The body, feelings and the brain keep running as sources. Off = the old behaviour", false, func(c *Config) any { return &c.MachineFeeling }),
		f("capabilities", "owner_rhythm", "she notices how you write to her (speed, length, capitals, the hour) and may gently guess how you are, saying that it is only a guess. Only your own messages to her, only numbers (no words are kept), and only in your chat. Off = off", true, func(c *Config) any { return &c.OwnerRhythm }),
		f("capabilities", "phone_adb", "her own phone with her own SIM number, over ADB (for example 192.168.1.50:5555 after `adb tcpip 5555` over USB once; or a USB serial). Full access for her: she sees its screen and camera, taps, types, reads her notification bar, installs apps, makes and answers calls (up to 5 calls a day). She has it in your chat and in her own free time, not in chats with other people. Empty = off. Needs the adb program on this machine (android-tools in apps.txt)", "", func(c *Config) any { return &c.PhoneADB }),
		f("capabilities", "self_repair", "give her, in her own free time (never in chats with other people), her own server tools: shell, files, logs, backup. She fixes small bugs herself; every call is seen in the live feed. Use shell_hard_block and a throw-away machine. Off by default", true, func(c *Config) any { return &c.SelfRepair }),
		f("capabilities", "owner_tools", "give the owner (papik_chat_id) shell, file and read-any-chat tools in his private chat", true, func(c *Config) any { return &c.OwnerTools }),
		f("browser", "enabled", "give the owner a real browser (Chromium) she can drive: open pages, click, type, scroll, send screenshots", true, func(c *Config) any { return &c.BrowserEnabled }),
		f("browser", "path", "browser program (empty = look for chromium / google-chrome in PATH). Alpine: apk add chromium font-noto", "", func(c *Config) any { return &c.BrowserPath }),
		f("browser", "xvfb", "run a full graphical browser on a virtual screen (needs Xvfb: apk add xvfb) instead of headless", false, func(c *Config) any { return &c.BrowserXvfb }),
		f("browser", "no_sandbox", "start Chromium with --no-sandbox (required when the program runs as root, as in containers)", true, func(c *Config) any { return &c.BrowserNoSandbox }),
		f("browser", "width", "viewport width in pixels", int64(1280), func(c *Config) any { return &c.BrowserWidth }),
		f("browser", "height", "viewport height in pixels", int64(800), func(c *Config) any { return &c.BrowserHeight }),
		f("browser", "max_steps", "most browser actions per message of the owner; protects against loops (he can say 'continue' for more)", int64(20), func(c *Config) any { return &c.BrowserSteps }),
		f("browser", "idle_secs", "close the browser after this much inactivity (frees memory; the profile with logins stays)", int64(300), func(c *Config) any { return &c.BrowserIdleSecs }),
		f("browser", "fast", "switch model reasoning off for the rounds that follow a browser step (much faster, fewer loops)", false, func(c *Config) any { return &c.BrowserFast }),
		f("browser", "block_hosts", "sites the browser never opens or stays on (comma-separated): account settings, passwords and payments of a logged-in Google account", "accounts.google.com,myaccount.google.com,payments.google.com,pay.google.com,wallet.google.com,passwords.google.com", func(c *Config) any { return &c.BrowserBlockHosts }),
		f("browser", "allow_passwords", "let her type into password fields. Off by default: she logs in with imported cookies (action=cookies), so no password ever goes through the chat or the model", true, func(c *Config) any { return &c.BrowserPasswords }),
		f("integrations", "services", "services she may call with #http_request, her keys are never shown to the model. Format: name|base url|Header: value, several separated by ;  e.g. github|https://api.github.com|Authorization: Bearer ghp_xxx", "", func(c *Config) any { return &c.Services }),
		f("mail", "imap_host", "IMAP server with the port, e.g. imap.gmail.com:993. Mail is read-only: she never marks, moves or deletes", "", func(c *Config) any { return &c.MailIMAP }),
		f("mail", "smtp_host", "SMTP server with the port, e.g. smtp.gmail.com:587 (STARTTLS) or :465 (TLS)", "", func(c *Config) any { return &c.MailSMTP }),
		f("mail", "user", "mailbox login (usually the address)", "", func(c *Config) any { return &c.MailUser }),
		f("mail", "password", "password of the mailbox. Gmail and most providers need an app password, not the main one", "", func(c *Config) any { return &c.MailPassword }),
		f("mail", "from", "address (or 'Name <address>') in From; empty = the login", "", func(c *Config) any { return &c.MailFrom }),
		f("mail", "send_per_day", "most e-mails she may send per day (0 = she cannot send)", int64(10), func(c *Config) any { return &c.MailPerDay }),
		f("calendar", "ics_urls", "calendars to read: the secret iCal address (Google Calendar: Settings > calendar > Secret address in iCal format). Format name|address, several separated by ;", "", func(c *Config) any { return &c.CalendarURLs }),
		f("world", "enabled", "the 3D block world at /world (same port as the admin panel): an endless sandbox where she lives as a player and you can join from a browser", true, func(c *Config) any { return &c.WorldEnabled }),
		f("world", "key", "password to enter the world (empty = misc.admin_token)", "", func(c *Config) any { return &c.WorldKey }),
		f("world", "model", "the model that plays for her inside the world (needs tool calls: mercury-3, mercury-2.5...). Same endpoint and key as llm.model. Empty = the world chat goes to her normal owner chat instead", "", func(c *Config) any { return &c.WorldModel }),
		f("world", "think_secs", "while someone is in the world she looks around and decides what to do every N seconds (0 = only answers when spoken to)", int64(45), func(c *Config) any { return &c.WorldThinkSecs }),
		f("world", "autobuild", "while someone is in the world she builds houses, towers and pyramids around by herself with ready-made plans, with no model and no cost", true, func(c *Config) any { return &c.WorldAutobuild }),
		f("desktop", "enabled", "give the owner a virtual desktop (Xvfb) where she can start programs, look at the screen, move the mouse, click and type. Needs Xvfb (Alpine: apk add xvfb)", true, func(c *Config) any { return &c.DesktopEnabled }),
		f("desktop", "session", "what starts on the screen first: empty = openbox window manager with a tint2 taskbar when installed (apk add openbox tint2), off = a bare screen, or your own shell line", "", func(c *Config) any { return &c.DesktopSession }),
		f("world", "stay_home", "she does not leave her flat: no walks in the city, she lives and studies in her room", true, func(c *Config) any { return &c.WorldStayHome }),
		f("room", "enabled", "she lives in her room by her own will: walks, sits and lies down on her own initiative, learns movements by trying (and sometimes falls)", true, func(c *Config) any { return &c.RoomLifeEnabled }),
		f("cortex", "enabled", "her brain as ~35 human brain regions (stem, thalamus, limbic system, basal ganglia, cerebellum, cortex) made of millions of rate neurons with machine logic in each region, wired to her body, senses, feelings and will", true, func(c *Config) any { return &c.CortexEnabled }),
		f("cortex", "neurons", "total neurons of the region brain. Measured on 2 cores: 4 million = about 36 MB and ~0.6 s per step (the step runs every 3 s), 1 million = ~0.09 s; the time grows with the number of neurons, memory ~9 bytes per neuron. On a weak machine lower it (e.g. 800000)", int64(4000000), func(c *Config) any { return &c.CortexNeurons }),
		f("mind", "enabled", "her own mind learns from every answer of the model (the teacher): memory of talks, habits, her own voice; it also dreams, grading itself without the API. Nothing is sent anywhere", true, func(c *Config) any { return &c.MindEnabled }),
		f("mind", "answer_alone", "a habit that has proved itself (hits the teacher's answer often enough) may answer by itself with no API call, when the region brain is calm and the answer is short; 15% of such answers are still checked against the teacher. Off = she only learns and the panel shows how ready she is", false, func(c *Config) any { return &c.MindAnswerAlone }),
		f("mind", "with_owner", "her own mind may also answer the owner alone (when answer_alone is on)", true, func(c *Config) any { return &c.MindWithOwner }),
		f("mind", "min_trials", "how many exams a habit must pass before it may answer alone", int64(12), func(c *Config) any { return &c.MindMinTrials }),
		f("mind", "min_sim", "confidence router: minimal likeness of the situation to a habit to answer alone (0.6..0.95)", 0.75, func(c *Config) any { return &c.MindMinSim }),
		f("mind", "hit_rate", "share of exams a habit must pass (0.5..0.95)", 0.8, func(c *Config) any { return &c.MindHitRate }),
		f("mind", "compose", "her voice may write new short answers (a remix of the answers she knows, in her own trigram voice) instead of only repeating remembered ones; every remix is graded by the same exams", true, func(c *Config) any { return &c.MindCompose }),
		f("mind", "reservoir", "experiment: a fixed random recurrent net of 2048 neurons is driven by the words of talks and only its readout learns, by the local error rule on the next word, in her sleep (~16 MB). Its replies are offered as candidates and must pass the same exams", true, func(c *Config) any { return &c.MindReservoir }),
		f("learn", "enabled", "she studies in her room: reads Wikipedia about her body, senses and the world and keeps what she learned", true, func(c *Config) any { return &c.LearnEnabled }),
		f("learn", "every_secs", "how often she sits down to study a new topic", int64(1200), func(c *Config) any { return &c.LearnEvery }),
		f("desktop", "display", "use a real X screen (e.g. :0, the laptop's own monitor) instead of a private virtual one: you sit at it like at an ordinary PC and watch her work; needs deploy/screen.sh on the host and /tmp/.X11-unix mounted into the container. Empty = virtual Xvfb", "", func(c *Config) any { return &c.DesktopDisplay }),
		f("desktop", "width", "screen width in pixels", int64(1280), func(c *Config) any { return &c.DesktopWidth }),
		f("desktop", "height", "screen height in pixels", int64(800), func(c *Config) any { return &c.DesktopHeight }),
		f("desktop", "max_steps", "most desktop actions per message of the owner (loop protection)", int64(25), func(c *Config) any { return &c.DesktopSteps }),
		f("desktop", "idle_secs", "close the desktop and its programs after this much inactivity", int64(600), func(c *Config) any { return &c.DesktopIdleSecs }),
		f("billing", "enabled", "limits for people other than the owner: free_per_day conversations a day, beyond that conversations are paid from a token balance topped up in the pay bot. Off = everyone talks without limits, as before. The owner is never limited", true, func(c *Config) any { return &c.BillingEnabled }),
		f("billing", "bot_token", "token of a separate small bot from @BotFather that takes payment in Telegram Stars (her own account cannot send invoices). Empty = limits work, but nobody can pay", "", func(c *Config) any { return &c.BillingBotToken }),
		f("billing", "bot_name", "the payment bot's @username without @, shown when someone runs out of messages", "", func(c *Config) any { return &c.BillingBotName }),
		f("billing", "free_per_day", "free conversations per day (one conversation = one time she answers a batch of new messages); beyond them a person spends tokens from their balance", int64(30), func(c *Config) any { return &c.BillingFreePerDay }),
		f("billing", "plus_per_day", "conversations per day on the old Plus plan (no longer sold; only for people who still have it)", int64(300), func(c *Config) any { return &c.BillingPlusPerDay }),
		f("billing", "max_per_day", "conversations per day on the old Max plan (no longer sold; 0 = no cap)", int64(2000), func(c *Config) any { return &c.BillingMaxPerDay }),
		f("billing", "plus_stars", "price of Plus for one period, in Telegram Stars", int64(250), func(c *Config) any { return &c.BillingPlusStars }),
		f("billing", "max_stars", "price of Max for one period, in Telegram Stars", int64(600), func(c *Config) any { return &c.BillingMaxStars }),
		f("billing", "plus_day_stars", "Plus for 1 day, in Stars (a cheap first step; 0 = not offered)", int64(15), func(c *Config) any { return &c.BillingPlusDayStars }),
		f("billing", "plus_week_stars", "Plus for 7 days, in Stars (0 = not offered)", int64(80), func(c *Config) any { return &c.BillingPlusWeekStars }),
		f("billing", "max_day_stars", "Max for 1 day, in Stars (0 = not offered)", int64(35), func(c *Config) any { return &c.BillingMaxDayStars }),
		f("billing", "max_week_stars", "Max for 7 days, in Stars (0 = not offered)", int64(190), func(c *Config) any { return &c.BillingMaxWeekStars }),
		f("billing", "ref_days", "invite bonus: when an invited friend pays for the first time, the friend gets this many extra days and the one who invited gets this many days of Plus (0 = no invite program)", int64(3), func(c *Config) any { return &c.BillingRefDays }),
		f("billing", "icons", "custom emoji icons for the bot's menu buttons: six ids separated by commas, in the order Пополнить, Профиль, Рейна, Подарить, Друзьям, Помощь (an empty place = an ordinary emoji). Telegram shows them only if the bot's owner has Telegram Premium or the bot has a username bought on Fragment. The profile and status pictures have their own drawn icons and need nothing", "", func(c *Config) any { return &c.BillingIcons }),
		f("billing", "admin_bot_token", "token of YOUR admin bot (a third bot from @BotFather): statistics, people, QR payment requests with ✅/❌, your QR picture. It answers only the owner (papik_chat_id). Empty = off", "", func(c *Config) any { return &c.BillingAdminToken }),
		f("billing", "qr", "let people pay by bank QR straight to your card: they get your QR picture (send it to the admin bot), transfer the sum with a code in the comment and send a screenshot of the receipt; you confirm with ✅ in the admin bot and the plan turns on. Needs admin_bot_token", true, func(c *Config) any { return &c.BillingQR }),
		f("billing", "currency", "the main currency of QR prices: RUB, USD, KZT, KGS... (the QR must take this currency)", "RUB", func(c *Config) any { return &c.BillingCurrency }),
		f("billing", "rates", "prices are also shown in other currencies: how much ONE unit of billing.currency is worth, CODE=rate separated by commas. Fixed numbers you set yourself, not live rates. Empty = main currency only", "USD=0.01262", func(c *Config) any { return &c.BillingRates }),
		f("billing", "plus_day_price", "Plus for 1 day by QR, in billing.currency (0 = not offered)", int64(29), func(c *Config) any { return &c.BillingPlusDayPrice }),
		f("billing", "plus_week_price", "Plus for 7 days by QR, in billing.currency", int64(129), func(c *Config) any { return &c.BillingPlusWeekPrice }),
		f("billing", "plus_price", "Plus for period_days by QR, in billing.currency", int64(399), func(c *Config) any { return &c.BillingPlusPrice }),
		f("billing", "max_day_price", "Max for 1 day by QR, in billing.currency", int64(69), func(c *Config) any { return &c.BillingMaxDayPrice }),
		f("billing", "max_week_price", "Max for 7 days by QR, in billing.currency", int64(299), func(c *Config) any { return &c.BillingMaxWeekPrice }),
		f("billing", "max_price", "Max for period_days by QR, in billing.currency", int64(899), func(c *Config) any { return &c.BillingMaxPrice }),
		f("billing", "packs", "token packs on sale in the pay bot, in tokens of the main model, separated by commas. Prices are worked out by themselves from llm.price_in_per_m, billing.margin and billing.star_usd (and billing.rates USD=... for the QR price), so a pack always costs more than serving it", "500000,2000000,6000000", func(c *Config) any { return &c.BillingPacks }),
		f("billing", "margin", "how many times a pack costs more than its tokens cost you at llm.price_in_per_m. It has to pay for the free conversations, Telegram's cut and the server too: below 2 you may lose money", 2.5, func(c *Config) any { return &c.BillingMargin }),
		f("billing", "star_usd", "what ONE Telegram Star brings you in USD when you withdraw it (about 0.013)", 0.013, func(c *Config) any { return &c.BillingStarUSD }),
		f("billing", "est_tokens_per_message", "how many tokens one conversation is assumed to cost for the «≈ N разговоров» estimates, until 30 real conversations are counted (then the real average is used)", int64(40000), func(c *Config) any { return &c.BillingEstTokens }),
		f("billing", "free_tokens_per_day", "a second cap on the free conversations: they also stop once a person's conversations cost this many tokens in a day (0 = only free_per_day counts). Protects you from very long free chats", int64(0), func(c *Config) any { return &c.BillingFreeTokens }),
		f("billing", "ref_tokens", "invite bonus: when an invited friend tops up for the first time, both get this many tokens (0 = no invite program)", int64(300000), func(c *Config) any { return &c.BillingRefTokens }),
		f("update", "github_repo", "GitHub repository (owner/name) whose Releases carry new builds (the workflow publishes them). Empty = no checks", "", func(c *Config) any { return &c.UpdateRepo }),
		f("update", "auto", "install a new release by itself and restart (the old build comes back on its own if the new one does not start). Off = only tell the owner, who installs with /update in the admin bot", true, func(c *Config) any { return &c.UpdateAuto }),
		f("update", "check_hours", "how often to look for a new release, in hours", int64(6), func(c *Config) any { return &c.UpdateCheckHours }),
		f("billing", "webapp_url", "public https address of the pay bot's Mini App: your tunnel or domain + /app/ (e.g. https://reina.example.com/app/). The app is served by this program on proxy.port; Telegram opens it from the bot's menu button. Empty = no app, only buttons", "", func(c *Config) any { return &c.BillingWebApp }),
		f("billing", "her_username", "her Telegram @username without @, for the «Написать Рейне» button and the online message in the pay bot (empty = no button)", "", func(c *Config) any { return &c.BillingHer }),
		f("billing", "support", "where people can ask about payments (a @username or an e-mail), shown under «Поддержка»", "", func(c *Config) any { return &c.BillingSupport }),
		f("billing", "period_days", "how many days one payment gives", int64(30), func(c *Config) any { return &c.BillingPeriodDays }),
		f("work", "enabled", "background work: she takes jobs from her queue (#work, the owner adds them in chat) on her own, with the browser and the desktop, and reports. Every run costs tokens: set llm.daily_token_limit too", true, func(c *Config) any { return &c.WorkEnabled }),
		f("work", "every_mins", "how often she looks at the queue (minutes, at least 2)", int64(10), func(c *Config) any { return &c.WorkEveryMins }),
		f("work", "max_runs_per_day", "most background runs per day over all jobs (a hard limit of the program)", int64(12), func(c *Config) any { return &c.WorkMaxRuns }),
		f("capabilities", "shell_dir", "working directory for shell commands (empty = <data_dir>/workspace)", "", func(c *Config) any { return &c.ShellDir }),
		f("capabilities", "shell_user", "run shell commands as this unprivileged system user instead of root (create it: adduser -D reina). Empty = same user as the program", "", func(c *Config) any { return &c.ShellUser }),
		f("capabilities", "shell_hard_block", "refuse catastrophic shell commands (rm -rf /, formatting disks, reboot, curl|sh, deleting her own data) even for the owner. Off by default", true, func(c *Config) any { return &c.ShellHardBlock }),
		f("capabilities", "shell_timeout_secs", "default shell command timeout (max 600)", int64(60), func(c *Config) any { return &c.ShellTimeout }),
		f("telegram", "stop_after_send", "end the turn right after a round that only sent messages/reactions (saves one slow LLM call per reply)", true, func(c *Config) any { return &c.StopAfterSend }),
		f("telegram", "typing_while_thinking", "show 'typing' in private chats while the model thinks", true, func(c *Config) any { return &c.TypingThinking }),
		f("misc", "lazy_tools", "hide rarely used tools behind #more_tools (saves ~1.5-2k prompt tokens per request)", true, func(c *Config) any { return &c.LazyTools }),
		f("memory", "auto_person_about", "once a card has 3+ facts she writes (and from time to time rewrites) a short description of the person in her own words; it is shown on the card in the panel", true, func(c *Config) any { return &c.AutoPersonAbout }),
		f("memory", "auto_person_cards", "when a private conversation ends she files 1-3 lasting facts about the person on their card (one short extra request)", true, func(c *Config) any { return &c.AutoPersonCards }),
		f("memory", "auto_promises", "when a private conversation ends she turns her own concrete promises ('напишу завтра в 10') into reminders that wake her at the time", true, func(c *Config) any { return &c.AutoPromises }),
		f("memory", "context_chars", "most characters of the session history sent with one request; older messages are dropped (cost control; ~4 chars per token)", int64(32000), func(c *Config) any { return &c.ContextChars }),
		f("memory", "old_tool_result_chars", "tool results older than the current turn are cut to this many characters", int64(300), func(c *Config) any { return &c.ToolResultChars }),
		f("telegram", "group_reply_mode", "addressed = in groups she wakes the model only when someone talks to her (reply, her name/@nick, the owner); all = every message", "addressed", func(c *Config) any { return &c.GroupReplyMode }),
		f("telegram", "group_interest_words", "topics she likes, comma-separated: in a group (reply mode addressed) a message with one of them wakes her more often", "нейросет,искусственный интеллект,код,программир,linux,линукс,музык,философи", func(c *Config) any { return &c.GroupInterestWords }),
		f("telegram", "group_interest_percent", "chance in percent that such a message wakes her (0 = off)", int64(50), func(c *Config) any { return &c.GroupInterestPercent }),
		f("telegram", "voice_percent", "when TTS is on: chance in percent that a short answer to a text message is nudged to be a voice message (0 = off)", int64(0), func(c *Config) any { return &c.VoicePercent }),
		f("telegram", "group_chime_percent", "in 'addressed' mode: chance (%) that she still looks at a group message not meant for her", int64(15), func(c *Config) any { return &c.GroupChime }),
		f("telegram", "command_users", "white list: Telegram user ids (besides the owner) who may use her slash commands /help /status /usage /pause /resume /stop in a private chat with her; comma-separated. She can also edit the list on the owner's word (data/allow.json)", "", func(c *Config) any { return &c.CommandUsers }),
		f("telegram", "group_debounce_secs", "groups: wait until the chat has been quiet this long before reading (fewer, bigger turns)", int64(8), func(c *Config) any { return &c.GroupDebounce }),
		f("telegram", "group_max_wait_secs", "groups: however busy the chat is, read it at the latest this long after the first new message (0 = no limit)", int64(30), func(c *Config) any { return &c.GroupMaxWait }),
		f("telegram", "group_cooldown_secs", "groups: after an answer, do not look at the same group again for this long; what arrives meanwhile is read as one batch (0 = off)", int64(12), func(c *Config) any { return &c.GroupCooldown }),
		f("memory", "history_keep", "keep this many recent session messages verbatim; older ones are summarised once there are twice as many (0 = never summarise)", int64(30), func(c *Config) any { return &c.HistoryKeep }),
		f("capabilities", "use_stickers", "", true, func(c *Config) any { return &c.UseStickers }),

		f("misc", "metrics_enabled", "Prometheus endpoint at /metrics", true, func(c *Config) any { return &c.MetricsEnabled }),
		f("misc", "panel_chats", "the panel shows her Telegram chats and messages in a Telegram-like window. Turn off if other people's private messages must never appear in the panel", true, func(c *Config) any { return &c.PanelChats }),
		f("misc", "desk_overview", "in the owner's chat (and in her own wake-ups there) she gets a short overview of her whole Telegram: chats with unread messages, mentions, who is typing, folders. Costs a few hundred tokens now and then; off = she looks herself with telegram_ui", true, func(c *Config) any { return &c.DeskOverview }),
		f("misc", "panel_takeover", "take-over mode of the Telegram window: the owner can write, react, press bot buttons, delete and pin from the panel AS HER account (each action asks for confirmation). Off by default: the window is read-only", true, func(c *Config) any { return &c.PanelTakeover }),
		f("misc", "admin_token", "password for the web admin panel at /admin (12+ chars; empty = panel disabled)", "", func(c *Config) any { return &c.AdminToken }),
		f("misc", "debug_ui", "web debug page at /debug (same port as proxy)", true, func(c *Config) any { return &c.DebugUI }),
		f("misc", "debug_prompt", "write what the model saw on its last call (system prompt tail, history, the new chat view, tool names) to <data_dir>/last_prompt.txt. For finding out why she answers off-topic; contains chat texts, turn it off afterwards", true, func(c *Config) any { return &c.DebugPrompt }),
		f("misc", "data_dir", "photos, voice, stickers, telegram state", "data", func(c *Config) any { return &c.DataDir }),
		f("misc", "prompts_dir", "prompt files; edited files are hot-reloaded", "prompts", func(c *Config) any { return &c.PromptsDir }),
	}
}

// ErrNeedsSetup is returned on the first run, after a default config.toml was written.
var ErrNeedsSetup = errors.New("config.toml was created; fill it in and start again")

// Load reads config.toml. If it does not exist, a default one is written and
// ErrNeedsSetup is returned, matching the behaviour of the C++ version.
// A value of the wrong type is an error; unknown keys and values out of range are fixed or ignored and listed in
// Config.Warnings, so a typo never stops her but is never silent either.
func Load(path string) (*Config, error) {
	raw, err := os.ReadFile(path)
	if errors.Is(err, os.ErrNotExist) {
		if werr := store.WriteFile(path, []byte(defaultFileContents()), store.Private); werr != nil { // it will hold the keys
			return nil, werr
		}
		return nil, ErrNeedsSetup
	}
	if err != nil {
		return nil, err
	}
	return Parse(string(raw))
}

// Parse builds a Config from the text of config.toml (missing keys take their defaults).
func Parse(src string) (*Config, error) {
	doc, err := parseTOMLDoc(src)
	if err != nil {
		return nil, err
	}
	c := &Config{}
	for i := range schema {
		f := &schema[i]
		v, ok := doc.values[f.full()]
		if !ok {
			v = f.def
		}
		if err := assign(f, f.ptr(c), v); err != nil {
			return nil, fmt.Errorf("%s: %w", f.full(), err)
		}
	}
	var unknown []string
	for k := range doc.values {
		if _, ok := index[k]; !ok {
			unknown = append(unknown, k)
		}
	}
	sort.Strings(unknown)
	for _, k := range unknown {
		c.Warnings = append(c.Warnings, fmt.Sprintf("unknown setting %s (a typo? it is ignored)", k))
	}
	for _, k := range doc.dups {
		c.Warnings = append(c.Warnings, fmt.Sprintf("%s is set more than once; the last value wins", k))
	}
	c.LLMBaseURL = withSlash(c.LLMBaseURL)
	if c.FallbackBaseURL != "" {
		c.FallbackBaseURL = withSlash(c.FallbackBaseURL)
	}
	if c.LightBaseURL != "" {
		c.LightBaseURL = withSlash(c.LightBaseURL)
	}
	if c.WorkBaseURL != "" {
		c.WorkBaseURL = withSlash(c.WorkBaseURL)
	}
	if c.DeepBaseURL != "" {
		c.DeepBaseURL = withSlash(c.DeepBaseURL)
	}
	if c.CodeBaseURL != "" {
		c.CodeBaseURL = withSlash(c.CodeBaseURL)
	}
	if c.EmbeddingBaseURL == "" && strings.Contains(strings.ToLower(c.LLMBaseURL), "inceptionlabs.ai") {
		c.EmbeddingBaseURL = "http://localhost:11434/v1/" // Inception has no /embeddings
	} else if c.EmbeddingBaseURL == "" {
		c.EmbeddingBaseURL = c.LLMBaseURL
	} else {
		c.EmbeddingBaseURL = withSlash(c.EmbeddingBaseURL)
	}
	c.Warnings = append(c.Warnings, c.validate()...)
	return c, nil
}

func withSlash(u string) string {
	if u != "" && !strings.HasSuffix(u, "/") {
		return u + "/"
	}
	return u
}

func assign(f *field, dst any, v any) error {
	switch p := dst.(type) {
	case *string:
		s, ok := v.(string)
		if !ok {
			return fmt.Errorf("want string, got %T", v)
		}
		*p = s
	case *bool:
		b, ok := v.(bool)
		if !ok {
			return fmt.Errorf("want bool, got %T", v)
		}
		*p = b
	case *int64:
		n, err := toInt(v)
		if err != nil {
			return err
		}
		*p = n
	case *int:
		n, err := toInt(v)
		if err != nil {
			return err
		}
		*p = int(n)
	case *float64:
		switch t := v.(type) {
		case float64:
			*p = t
		case int64:
			*p = float64(t)
		default:
			return fmt.Errorf("want number, got %T", v)
		}
	case *time.Duration:
		// keys are named *_secs or *_ms; the unit comes from the name
		n, err := toInt(v)
		if err != nil {
			return err
		}
		*p = time.Duration(n) * f.unit()
	default:
		return fmt.Errorf("unsupported field type %T", dst)
	}
	return nil
}

func toInt(v any) (int64, error) {
	switch t := v.(type) {
	case int64:
		return t, nil
	case float64:
		return int64(t), nil // 800.0 is read as 800, as it always was
	}
	return 0, fmt.Errorf("want integer, got %T", v)
}

func defaultFileContents() string {
	var sections []tomlSection
	seen := map[string]int{}
	for _, f := range schema {
		idx, ok := seen[f.section]
		if !ok {
			idx = len(sections)
			seen[f.section] = idx
			sections = append(sections, tomlSection{name: f.section})
		}
		sections[idx].items = append(sections[idx].items, tomlItem{key: f.key, value: f.def, comment: f.comment})
	}
	return formatTOML(sections)
}

// Holder gives lock-free access to the current config and notifies on reload.
type Holder struct {
	p         atomic.Pointer[Config]
	path      string
	mu        sync.Mutex
	listeners []func(*Config)
}

// NewHolder loads the config once.
func NewHolder(path string) (*Holder, error) {
	c, err := Load(path)
	if err != nil {
		return nil, err
	}
	h := &Holder{path: path}
	h.p.Store(c)
	return h, nil
}

// NewStaticHolder wraps an already-built config (tests).
func NewStaticHolder(c *Config) *Holder {
	h := &Holder{}
	h.p.Store(c)
	return h
}

// Get returns the current config. Treat it as read-only: a reload replaces it as a whole.
func (h *Holder) Get() *Config { return h.p.Load() }

// Path is the file the config was loaded from ("" for a static holder).
func (h *Holder) Path() string { return h.path }

// OnChange registers a listener called (on the watcher goroutine) after a successful reload.
func (h *Holder) OnChange(f func(*Config)) {
	h.mu.Lock()
	h.listeners = append(h.listeners, f)
	h.mu.Unlock()
}

// Reload reads the file again now; a broken file keeps the old config and returns the error.
func (h *Holder) Reload() error {
	c, err := Load(h.path)
	if err != nil {
		return err
	}
	h.p.Store(c)
	for _, w := range c.Warnings {
		log.Printf("config: %s", w)
	}
	h.mu.Lock()
	ls := append([]func(*Config){}, h.listeners...)
	h.mu.Unlock()
	for _, l := range ls {
		l(c)
	}
	return nil
}

// Watch hot-reloads the config file until ctx is done. A broken file keeps the old config.
func (h *Holder) Watch(ctx context.Context) {
	util.Watch(ctx, 2*time.Second, func() []string { return []string{h.path} }, func(string) {
		if err := h.Reload(); err != nil {
			log.Printf("config: reload failed, keeping old config: %v", err)
			return
		}
		log.Printf("config: reloaded")
	})
}
