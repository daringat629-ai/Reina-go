package maint

import (
	"strings"
	"testing"

	"orvi/internal/config"
)

func TestBackupHoldsTheMoney(t *testing.T) {
	c := &config.Config{DataDir: "/d"}
	got := strings.Join(Sources(c, "/c.toml"), "\n")
	for _, want := range []string{"/d/billing.json", "/d/pay_qr.png", "/d/receipts"} {
		if !strings.Contains(got, want) {
			t.Errorf("the backup must contain %s", want)
		}
	}
}
