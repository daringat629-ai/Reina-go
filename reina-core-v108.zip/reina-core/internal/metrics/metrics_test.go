package metrics

import (
	"net/http/httptest"
	"strings"
	"testing"
)

func TestExposition(t *testing.T) {
	r := New()
	r.Help("reina_llm_requests_total", "LLM requests")
	r.Inc("reina_llm_requests_total", 1, map[string]string{"kind": "chat"})
	r.Inc("reina_llm_requests_total", 2, map[string]string{"kind": "chat"})
	r.Set("reina_sessions_active", 3, nil)
	r.Observe("reina_llm_seconds", 1.5, nil)
	rec := httptest.NewRecorder()
	r.Handler().ServeHTTP(rec, httptest.NewRequest("GET", "/metrics", nil))
	body := rec.Body.String()
	for _, want := range []string{`reina_llm_requests_total{kind="chat"} 3`, "reina_sessions_active 3", "reina_llm_seconds_sum 1.5", "reina_llm_seconds_count 1", "# HELP reina_llm_requests_total"} {
		if !strings.Contains(body, want) {
			t.Errorf("missing %q in:\n%s", want, body)
		}
	}
}

func TestHistogramHasBucketsForQuantiles(t *testing.T) {
	r := New()
	r.Buckets = []float64{0.5, 1, 5}
	l := map[string]string{"tool": "shell", "chat": `Al"ex`}
	for _, v := range []float64{0.2, 0.7, 0.9, 3, 100} {
		r.Observe("tool_call_response_time_seconds", v, l)
	}
	rec := httptest.NewRecorder()
	r.Handler().ServeHTTP(rec, httptest.NewRequest("GET", "/metrics", nil))
	body := rec.Body.String()
	for _, want := range []string{
		"# TYPE tool_call_response_time_seconds histogram",
		`tool_call_response_time_seconds_bucket{chat="Al\"ex",tool="shell",le="0.5"} 1`,
		`tool_call_response_time_seconds_bucket{chat="Al\"ex",tool="shell",le="1"} 3`,
		`tool_call_response_time_seconds_bucket{chat="Al\"ex",tool="shell",le="5"} 4`,
		`tool_call_response_time_seconds_bucket{chat="Al\"ex",tool="shell",le="+Inf"} 5`,
		`tool_call_response_time_seconds_count{chat="Al\"ex",tool="shell"} 5`,
		`tool_call_response_time_seconds_sum{chat="Al\"ex",tool="shell"} 104.8`,
	} {
		if !strings.Contains(body, want) {
			t.Errorf("missing %q in:\n%s", want, body)
		}
	}
	if r.Count("tool_call_response_time_seconds", l) != 5 {
		t.Fatal("count")
	}
}
