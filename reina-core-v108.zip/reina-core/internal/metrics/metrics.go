// Package metrics is a tiny Prometheus text-format exporter: counters, gauges and histograms (with buckets, so
// histogram_quantile works), enough for the bundled Grafana dashboards.
package metrics

import (
	"fmt"
	"math"
	"net/http"
	"sort"
	"strconv"
	"strings"
	"sync"
)

// DefaultBuckets suit durations in seconds: a tool call, an LLM request.
var DefaultBuckets = []float64{0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10, 20, 30, 60, 120, 300}

type histogram struct {
	name   string
	labels map[string]string
	counts []uint64 // per bucket of the registry's buckets (cumulative on output)
	sum    float64
	count  uint64
}

type Registry struct {
	mu       sync.Mutex
	counters map[string]float64
	gauges   map[string]float64
	hists    map[string]*histogram
	help     map[string]string
	types    map[string]string // metric name -> counter | gauge | histogram
	// Buckets are the upper bounds used by Observe (DefaultBuckets when nil).
	Buckets []float64
}

func New() *Registry {
	return &Registry{counters: map[string]float64{}, gauges: map[string]float64{}, hists: map[string]*histogram{},
		help: map[string]string{}, types: map[string]string{}}
}

// key renders name{k="v",...} with labels sorted.
func key(name string, labels map[string]string) string {
	if len(labels) == 0 {
		return name
	}
	ks := make([]string, 0, len(labels))
	for k := range labels {
		ks = append(ks, k)
	}
	sort.Strings(ks)
	parts := make([]string, len(ks))
	for i, k := range ks {
		parts[i] = k + "=" + quote(labels[k])
	}
	return name + "{" + strings.Join(parts, ",") + "}"
}

// quote escapes a label value the way the exposition format wants (backslash, quote, newline).
func quote(v string) string {
	return `"` + strings.NewReplacer(`\`, `\\`, `"`, `\"`, "\n", `\n`).Replace(v) + `"`
}

func (r *Registry) Help(name, text string) {
	if r == nil {
		return
	}
	r.mu.Lock()
	r.help[name] = text
	r.mu.Unlock()
}

// Inc adds v to a counter.
func (r *Registry) Inc(name string, v float64, labels map[string]string) {
	if r == nil {
		return
	}
	r.mu.Lock()
	r.counters[key(name, labels)] += v
	if r.types[name] == "" {
		r.types[name] = "counter"
	}
	r.mu.Unlock()
}

// Set sets a gauge.
func (r *Registry) Set(name string, v float64, labels map[string]string) {
	if r == nil {
		return
	}
	r.mu.Lock()
	r.gauges[key(name, labels)] = v
	if r.types[name] == "" {
		r.types[name] = "gauge"
	}
	r.mu.Unlock()
}

func (r *Registry) buckets() []float64 {
	if len(r.Buckets) > 0 {
		return r.Buckets
	}
	return DefaultBuckets
}

// Observe records a value (a duration in seconds, usually) into the histogram <name>: <name>_bucket{le=...},
// <name>_sum and <name>_count, as Prometheus histograms are exposed.
func (r *Registry) Observe(name string, v float64, labels map[string]string) {
	if r == nil || math.IsNaN(v) {
		return
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	k := key(name, labels)
	h := r.hists[k]
	bs := r.buckets()
	if h == nil {
		cp := make(map[string]string, len(labels))
		for lk, lv := range labels {
			cp[lk] = lv
		}
		h = &histogram{name: name, labels: cp, counts: make([]uint64, len(bs))}
		r.hists[k] = h
		r.types[name] = "histogram"
	}
	for i, b := range bs {
		if v <= b {
			h.counts[i]++
			break
		}
	}
	h.sum += v
	h.count++
}

// Get returns a counter value (tests and the panel).
func (r *Registry) Get(name string, labels map[string]string) float64 {
	r.mu.Lock()
	defer r.mu.Unlock()
	return r.counters[key(name, labels)]
}

// Count returns how many values a histogram has seen (tests).
func (r *Registry) Count(name string, labels map[string]string) uint64 {
	r.mu.Lock()
	defer r.mu.Unlock()
	if h := r.hists[key(name, labels)]; h != nil {
		return h.count
	}
	return 0
}

func fmtFloat(v float64) string {
	switch {
	case math.IsInf(v, 1):
		return "+Inf"
	case math.IsInf(v, -1):
		return "-Inf"
	}
	return strconv.FormatFloat(v, 'g', -1, 64)
}

// Handler serves the Prometheus text exposition format.
func (r *Registry) Handler() http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		r.mu.Lock()
		byName := map[string][]string{} // metric family -> sample lines
		add := func(family, line string) { byName[family] = append(byName[family], line) }
		family := func(k string) string {
			if i := strings.IndexByte(k, '{'); i >= 0 {
				return k[:i]
			}
			return k
		}
		for k, v := range r.counters {
			add(family(k), k+" "+fmtFloat(v))
		}
		for k, v := range r.gauges {
			add(family(k), k+" "+fmtFloat(v))
		}
		bs := r.buckets()
		hkeys := make([]string, 0, len(r.hists))
		for k := range r.hists {
			hkeys = append(hkeys, k)
		}
		sort.Strings(hkeys)
		for _, hk := range hkeys {
			h := r.hists[hk]
			var cum uint64
			for i, b := range bs {
				cum += h.counts[i]
				add(h.name, bucketKey(h.name, h.labels, fmtFloat(b))+" "+strconv.FormatUint(cum, 10))
			}
			add(h.name, bucketKey(h.name, h.labels, "+Inf")+" "+strconv.FormatUint(h.count, 10))
			add(h.name, key(h.name+"_sum", h.labels)+" "+fmtFloat(h.sum))
			add(h.name, key(h.name+"_count", h.labels)+" "+strconv.FormatUint(h.count, 10))
		}
		helps := make(map[string]string, len(r.help))
		for k, v := range r.help {
			helps[k] = v
		}
		types := make(map[string]string, len(r.types))
		for k, v := range r.types {
			types[k] = v
		}
		r.mu.Unlock()

		names := make([]string, 0, len(byName))
		for n := range byName {
			names = append(names, n)
		}
		sort.Strings(names)
		w.Header().Set("Content-Type", "text/plain; version=0.0.4")
		for _, n := range names {
			if h, ok := helps[n]; ok {
				fmt.Fprintf(w, "# HELP %s %s\n", n, h)
			}
			if t := types[n]; t != "" {
				fmt.Fprintf(w, "# TYPE %s %s\n", n, t)
			}
			lines := byName[n]
			if types[n] != "histogram" { // histogram lines keep their bucket order
				sort.Strings(lines)
			}
			for _, l := range lines {
				fmt.Fprintln(w, l)
			}
		}
	})
}

// bucketKey is name_bucket{labels...,le="x"} with le last, as Prometheus clients print it.
func bucketKey(name string, labels map[string]string, le string) string {
	k := key(name+"_bucket", labels)
	if strings.HasSuffix(k, "}") {
		return k[:len(k)-1] + `,le="` + le + `"}`
	}
	return k + `{le="` + le + `"}`
}
