package util

import (
	"context"
	"os"
	"time"
)

// Watch polls the given files' modification times and calls onChange when any changes.
// It is a portable poller that works on every platform.
func Watch(ctx context.Context, interval time.Duration, files func() []string, onChange func(path string)) {
	last := map[string]time.Time{}
	scan := func(fire bool) {
		for _, f := range files() {
			st, err := os.Stat(f)
			if err != nil {
				continue
			}
			prev, seen := last[f]
			last[f] = st.ModTime()
			if fire && seen && !st.ModTime().Equal(prev) {
				onChange(f)
			}
		}
	}
	scan(false)
	t := time.NewTicker(interval)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
			scan(true)
		}
	}
}
