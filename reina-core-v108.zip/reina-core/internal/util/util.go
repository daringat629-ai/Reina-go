// Package util holds small helpers.
package util

import (
	"errors"
	"fmt"
	"math"
	"time"
)

// CosineSimilarity returns cos(a, b). Zero vectors yield 0.
func CosineSimilarity(a, b []float64) (float64, error) {
	if len(a) != len(b) {
		return 0, fmt.Errorf("size mismatch: %d and %d", len(a), len(b))
	}
	var dot, na, nb float64
	for i := range a {
		dot += a[i] * b[i]
		na += a[i] * a[i]
		nb += b[i] * b[i]
	}
	if na == 0 || nb == 0 {
		return 0, nil
	}
	return dot / (math.Sqrt(na) * math.Sqrt(nb)), nil
}

// TimeAgo formats t relative to now.
func TimeAgo(t, now time.Time) string {
	diff := now.Sub(t)
	minutes := int64(diff / time.Minute)
	hours := int64(diff / time.Hour)
	days := hours / 24
	weeks := days / 7
	switch {
	case minutes < 1:
		return "just now"
	case minutes == 1:
		return "1 minute ago"
	case minutes < 60:
		return fmt.Sprintf("%d minutes ago", minutes)
	case hours == 1:
		return "1 hour ago"
	case hours < 24:
		return fmt.Sprintf("%d hours ago", hours)
	case days == 1:
		return "1 day ago"
	case days < 7:
		return fmt.Sprintf("%d days ago", days)
	case weeks == 1:
		return "1 week ago"
	default:
		return fmt.Sprintf("%d weeks ago", weeks)
	}
}

// FormatPastHours renders a duration as e.g. "3 days" / "5 hours".
func FormatPastHours(d time.Duration) string {
	h := int64(d / time.Hour)
	if h%24 == 0 && h >= 24 {
		n := h / 24
		if n == 1 {
			return "1 day"
		}
		return fmt.Sprintf("%d days", n)
	}
	if h == 1 {
		return "1 hour"
	}
	return fmt.Sprintf("%d hours", h)
}

// ErrNoContent is returned when an LLM answer is empty.
var ErrNoContent = errors.New("empty content")

// Trunc shortens s to at most n runes (adds "…" when cut).
func Trunc(s string, n int) string {
	r := []rune(s)
	if len(r) <= n {
		return s
	}
	return string(r[:n]) + "…"
}
