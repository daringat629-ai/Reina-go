---
Added to the message of the prompt writer together with the previous prompt and the feedback, if there is any.
Has no placeholders.
---

<instructions>
When you improve the prompt:
- Use Stable Diffusion weights such as (term:1.2) or (phrase:1.5) for emphasis.
- Do not make the prompt longer only to stress something.
- If it is too long, cut filler words.
- Add words only if an important element is missing from the picture.
- Keep the result short, ordered and suitable for Stable Diffusion.
- Do not change the character's design.
- "positivePrompt": string, the current positive prompt with small changes that fix the problems.
- "negativePrompt": string, the current negative prompt with small changes that fix the problems.

The positive prompt lists what must be in the picture. The negative prompt lists what must not be.
</instructions>
