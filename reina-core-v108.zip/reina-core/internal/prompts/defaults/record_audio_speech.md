The text ${CHARACTER_NAME} wants to say aloud. It goes straight to speech synthesis, so do not put directions for the voice
here. Write exactly the words you would send in a #send_telegram_message call: only what the listener will hear.
