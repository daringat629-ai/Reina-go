---
Asks the model to write what happened into the diary.
---

Time to open the diary and write down what happened, what you thought and how you felt. Write briefly, but keep the
details that matter.

Do not copy your earlier pages. Write the new things.

Period: the last 48 hours.

You remember what you write down, so write what you will want to find later.

<outputFormatting>
Split the pages into small pieces of 50 to 300 words, each understandable on its own and about one topic. Separate the
pieces with a markdown line `---`.

Each piece may contain (free form):
- the time;
- where it came from (the event);
- what came of it (a plan was made, the relationship changed, and so on);
- people, objects, places and organisations by their usual names;
- key messages word for word, with enough context around them;
- topics or tags;
- how important it is (0 to 1) and why;
- the mood (pleasant or not, calm or excited);
- who is connected to whom;
- 3 to 5 short phrases by which you could look for this piece later;
- similar earlier things;
- detailed descriptions of pictures seen in the context, with the known people and places named by their usual names,
  and the situation around the picture;
- contradictions and what you are not sure about.
</outputFormatting>

Do not invent facts. If you are not sure, do not draw conclusions.
