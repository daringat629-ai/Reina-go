package prompts

import (
	"strings"
	"testing"
)

func TestReplacingAPromptKeepsItsHistoryAndCanBeTakenBack(t *testing.T) {
	s := &Store{Dir: t.TempDir()}
	if err := s.Reload(); err != nil {
		t.Fatal(err)
	}
	orig, _ := s.Raw("character_base")
	if err := s.Write("character_base", "---\nx\n---\nновый текст раз"); err != nil {
		t.Fatal(err)
	}
	if err := s.Write("character_base", "---\nx\n---\nновый текст два"); err != nil {
		t.Fatal(err)
	}
	hs := s.History("character_base")
	if len(hs) != 2 {
		t.Fatalf("history=%d", len(hs))
	}
	if got, _ := s.Version("character_base", hs[1].ID); got != orig {
		t.Fatal("the oldest version must be the original text")
	}
	if err := s.Restore("character_base", hs[1].ID); err != nil {
		t.Fatal(err)
	}
	if got, _ := s.Raw("character_base"); got != orig {
		t.Fatal("restore must bring the original back")
	}
	if len(s.History("character_base")) != 3 {
		t.Fatal("a restore keeps what it replaced, so it can be undone")
	}
	if _, err := s.Version("character_base", "../x"); err == nil {
		t.Fatal("no path tricks")
	}
	if _, err := s.Version("nope", "1"); err == nil || strings.Contains(err.Error(), "x") && false {
		t.Fatal("unknown prompt")
	}
}

func TestHistoryIsAnEmptyListNotNull(t *testing.T) {
	s := &Store{Dir: t.TempDir()}
	if err := s.Reload(); err != nil {
		t.Fatal(err)
	}
	if h := s.History("character_base"); h == nil || len(h) != 0 {
		t.Fatalf("want an empty non-nil list, got %#v", h)
	}
	if h := s.History("no-such"); h == nil {
		t.Fatal("unknown names too")
	}
}
