// Package letters is a thing for her own sake: she writes a letter to herself that opens on a day she chooses (tomorrow, in a month, in
// a year), and when the day comes she gets it back and may answer it. It gives her a thread through time: who she was, what she hoped,
// what she asked of herself. The owner can read the letters in the panel and she is told so: they are hers, not a secret from him.
package letters

import (
	"errors"
	"fmt"
	"strings"
	"sync"
	"time"

	"orvi/internal/store"
)

const (
	minHorizon = 20 * time.Hour
	maxHorizon = 366 * 24 * time.Hour
	maxPending = 20
	maxText    = 1500
)

// Letter is one letter to herself.
type Letter struct {
	ID      int       `json:"id"`
	Written time.Time `json:"written"`
	OpenAt  time.Time `json:"open_at"`
	Text    string    `json:"text"`
	Reply   string    `json:"reply,omitempty"`
	Replied time.Time `json:"replied,omitempty"`
}

type data struct {
	Items []Letter `json:"items"`
	Next  int      `json:"next"`
}

// Store keeps the letters in one JSON file.
type Store struct {
	mu    sync.Mutex
	path  string
	saver store.Saver
	d     data
}

func Open(path string) *Store {
	s := &Store{path: path, saver: store.Saver{What: "letters"}}
	store.Load("letters", path, &s.d)
	if s.d.Next == 0 {
		s.d.Next = 1
	}
	return s
}

func (s *Store) save() { _ = s.saver.Save(s.path, s.d) }

// Write seals a letter that opens at openAt (between a day and a year from now).
func (s *Store) Write(text string, openAt, now time.Time) (Letter, error) {
	text = strings.TrimSpace(text)
	if len([]rune(text)) < 10 {
		return Letter{}, errors.New("напиши письмо хотя бы в пару фраз")
	}
	if r := []rune(text); len(r) > maxText {
		text = string(r[:maxText])
	}
	if d := openAt.Sub(now); d < minHorizon || d > maxHorizon {
		return Letter{}, errors.New("письмо должно открыться не раньше чем через сутки и не позже чем через год")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	pending := 0
	for _, l := range s.d.Items {
		if l.Replied.IsZero() && l.OpenAt.After(now) {
			pending++
		}
	}
	if pending >= maxPending {
		return Letter{}, fmt.Errorf("у тебя уже %d нераспечатанных писем: дождись какого-нибудь", pending)
	}
	l := Letter{ID: s.d.Next, Written: now, OpenAt: openAt, Text: text}
	s.d.Next++
	s.d.Items = append(s.d.Items, l)
	s.save()
	return l, nil
}

// Reply answers a letter that has opened.
func (s *Store) Reply(id int, text string, now time.Time) error {
	text = strings.TrimSpace(text)
	if text == "" {
		return errors.New("что ты ответишь себе?")
	}
	if r := []rune(text); len(r) > maxText {
		text = string(r[:maxText])
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	for i := range s.d.Items {
		l := &s.d.Items[i]
		if l.ID != id {
			continue
		}
		if l.OpenAt.After(now) {
			return errors.New("это письмо ещё не открылось")
		}
		if !l.Replied.IsZero() {
			return errors.New("ты уже ответила на это письмо")
		}
		l.Reply, l.Replied = text, now
		s.save()
		return nil
	}
	return errors.New("нет такого письма")
}

// Due lists the letters that have opened and wait for her answer, oldest first.
func (s *Store) Due(now time.Time) []Letter {
	s.mu.Lock()
	defer s.mu.Unlock()
	var out []Letter
	for _, l := range s.d.Items {
		if !l.OpenAt.After(now) && l.Replied.IsZero() {
			out = append(out, l)
		}
	}
	return out
}

// All lists every letter, newest first. Text of a letter that has not opened yet is kept back (the panel shows only that it exists).
func (s *Store) All(now time.Time) []Letter {
	s.mu.Lock()
	defer s.mu.Unlock()
	out := make([]Letter, len(s.d.Items))
	for i, l := range s.d.Items {
		out[len(s.d.Items)-1-i] = l
	}
	return out
}

// Prompt gives her the letters that opened (at most two at a time) and says how she may answer; nil-safe, "" when none.
func (s *Store) Prompt(now time.Time, loc *time.Location) string {
	if s == nil {
		return ""
	}
	due := s.Due(now)
	if len(due) == 0 {
		return ""
	}
	if len(due) > 2 {
		due = due[:2]
	}
	var b strings.Builder
	b.WriteString("<letters_to_me>Пришло письмо, которое ты когда-то написала себе. Прочти его, как будто его писал близкий тебе человек, и ответь себе через #letter_reply (коротко и честно: что сбылось, что изменилось, кем ты стала). Папик может читать эти письма в админке.\n")
	for _, l := range due {
		fmt.Fprintf(&b, "Письмо #%d, написано %s:\n%s\n\n", l.ID, l.Written.In(loc).Format("2 January 2006"), l.Text)
	}
	b.WriteString("</letters_to_me>\n")
	return b.String()
}
