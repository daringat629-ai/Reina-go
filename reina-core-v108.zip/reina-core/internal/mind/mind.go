// Package mind is the way out of the API: the model (the teacher) answers, and every answer becomes a lesson for her own
// small mind (the student). Nothing here is a language model. It is made of what brains are made of:
//
//   - episodic memory (the hippocampus): what was said to her and what she answered, as sparse feature vectors;
//   - habits (the basal ganglia): clusters of similar situations, each with its own measured competence;
//   - her own voice (a word trigram model of her replies): it picks among the remembered answers and measures how
//     predictable she has become to herself;
//   - dreams (sleep consolidation): while she sleeps she examines herself on her own memories (leave-one-out) and grades
//     the habits without spending a single API call;
//   - an unannounced examiner: a graduated habit is still checked against the teacher from time to time; a habit that
//     starts to fail loses its right to answer alone.
//
// A habit answers alone only when it has proved itself, the situation is calm (no threat or inner conflict in the region
// brain) and the answer is short. Everything else goes to the teacher, who in turn teaches again.
package mind

import (
	"crypto/cipher"
	"math"
	"math/rand"
	"sort"
	"strings"
	"sync"
	"time"
	"unicode"

	"orvi/internal/store"
)

const (
	hitSim    = .5  // two answers this alike count as the same answer
	joinSim   = .55 // situations this alike belong to one habit
	minSim    = .5  // the nearest memory must be this close to answer at all
	maxEp     = 3000
	maxAnswer = 140 // she answers alone only with short replies
)

// Situation is what she is answering.
type Situation struct {
	Text  string // what was said to her
	Owner bool   // the owner is talking
}

// Gate is what the region brain says about whether it is calm enough to answer alone.
type Gate struct{ Threat, Conflict float64 }

type episode struct {
	In     string `json:"in"`
	Out    string `json:"out"`
	Tool   bool   `json:"tool,omitempty"` // the teacher needed tools here: this is not a chat answer
	Cl     int    `json:"cl"`
	Served int    `json:"served,omitempty"`
	id     int
	vec    map[uint32]float32
}

type cluster struct {
	N    int     `json:"n"`
	Hit  float64 `json:"hit"` // how often her own answer matched the teacher's (moving average)
	Grad bool    `json:"grad"`
}

// Config is what the owner sets.
type Config struct {
	AnswerAlone bool
	WithOwner   bool
	MinTrials   int
	HitRate     float64
	MinSim      float64 // how close the situation must be to the habit before she answers alone (default .6, router raises it)
	Compose     bool    // her voice may write new answers from remembered ones
	Reservoir   bool    // the experimental reservoir net learns in her sleep and offers its own candidate answers
}

// Mind is her own mind. Safe for concurrent use.
type Mind struct {
	mu      sync.Mutex
	gcmOnce sync.Once // the corpus cipher is built once, not on every line
	gcm     cipher.AEAD
	path    string
	saver   store.Saver
	rng     *rand.Rand
	eps     []*episode
	cl      map[int]*cluster
	next    int
	tri     map[string]map[string]uint32
	bi      map[string]map[string]uint32 // the same with one word of context: lets remixes cross between answers
	uni     map[string]uint32
	uniN    uint32
	st      counters
	perp    float64
	hasPerp bool
	res     *reservoir
	resAt   time.Time
	useRes  bool
	banned  []string // answers the owner called bad: never said alone again
	compose bool     // her voice may remix answers (set from the config at every call)
	recent  []string // what she answered alone lately: she does not repeat herself
}

type counters struct {
	Teacher  int     `json:"teacher"` // chat answers the teacher gave
	Shadow   int     `json:"shadow"`  // of those, how many she could have predicted
	ShadowOK float64 `json:"shadow_ok"`
	Saved    int     `json:"saved"`    // answers she gave alone
	Composed int     `json:"composed"` // of those, new ones written in her own voice
	Dreams   int     `json:"dreams"`
	DreamOK  float64 `json:"dream_ok"`
}

type saved struct {
	Eps  []*episode       `json:"eps"`
	Cl   map[int]*cluster `json:"cl"`
	Next int              `json:"next"`
	Ban  []string         `json:"ban,omitempty"`
	St   counters         `json:"st"`
}

// New opens her mind ("" path = nothing is saved).
func New(path string, seed int64) *Mind {
	m := &Mind{path: path, saver: store.Saver{What: "mind"}, rng: rand.New(rand.NewSource(seed)), cl: map[int]*cluster{}, tri: map[string]map[string]uint32{}, bi: map[string]map[string]uint32{}, uni: map[string]uint32{}}
	if path != "" {
		var s saved
		if store.Load("mind", path, &s) {
			m.eps, m.next, m.st, m.banned = s.Eps, s.Next, s.St, s.Ban
			if s.Cl != nil {
				m.cl = s.Cl
			}
			for i, e := range m.eps {
				e.id = i
				e.vec = vec(e.In)
				if !e.Tool {
					m.train(e.Out)
				}
			}
		}
	}
	return m
}

// reservoirFor returns the reservoir when it is switched on (created or loaded on first use).
func (m *Mind) reservoirFor(cfg Config) *reservoir {
	m.useRes = cfg.Reservoir
	if !cfg.Reservoir {
		return nil
	}
	if m.res == nil {
		m.res = newReservoir(7)
		if m.path != "" {
			m.res.load(m.path + ".res.gz")
		}
		m.resAt = time.Now()
	}
	return m.res
}

// Close saves everything, the reservoir too.
func (m *Mind) Close() {
	m.Save()
	m.mu.Lock()
	if m.res != nil && m.res.dirty && m.path != "" {
		_ = m.res.save(m.path + ".res.gz")
	}
	m.mu.Unlock()
}

// Save writes the memory (the reservoir at most every 20 minutes: it is big).
func (m *Mind) saveRes() {
	if m.res != nil && m.res.dirty && m.path != "" && time.Since(m.resAt) > 20*time.Minute {
		m.resAt = time.Now()
		_ = m.res.save(m.path + ".res.gz")
	}
}

// Save writes the memory.
func (m *Mind) Save() {
	if m.path == "" {
		return
	}
	m.mu.Lock()
	s := saved{Eps: m.eps, Cl: m.cl, Next: m.next, St: m.st, Ban: m.banned}
	err := m.saver.Save(m.path, &s)
	m.saveRes()
	m.mu.Unlock()
	_ = err
}

func fnv(s string) uint32 {
	h := uint32(2166136261)
	for i := 0; i < len(s); i++ {
		h = (h ^ uint32(s[i])) * 16777619
	}
	return h
}

func words(s string) []string {
	return strings.FieldsFunc(strings.ToLower(s), func(r rune) bool { return !unicode.IsLetter(r) && !unicode.IsDigit(r) })
}

// vec is the sparse picture of a text: its words and the letter triples inside them (so that "приветик" is near "привет").
func vec(s string) map[uint32]float32 {
	v := map[uint32]float32{}
	for _, w := range words(s) {
		v[fnv("w"+w)%4096] += 1
		r := []rune("_" + w + "_")
		for i := 0; i+3 <= len(r); i++ {
			v[fnv("t"+string(r[i:i+3]))%4096+4096] += .5
		}
	}
	var n float64
	for _, x := range v {
		n += float64(x * x)
	}
	if n == 0 {
		return v
	}
	n = math.Sqrt(n)
	for k := range v {
		v[k] = float32(float64(v[k]) / n)
	}
	return v
}

func cos(a, b map[uint32]float32) float64 {
	if len(a) > len(b) {
		a, b = b, a
	}
	var s float64
	for k, x := range a {
		s += float64(x * b[k])
	}
	return s
}

// ---- her voice ----

// toks are the units of her voice: words with their punctuation and tildes, so that "привет~" stays "привет~".
func toks(s string) []string { return strings.Fields(strings.ToLower(s)) }

func (m *Mind) train(text string) {
	w := append(toks(text), "</s>")
	prev1, prev2 := "<s>", "<s>"
	for _, x := range w {
		k := prev2 + " " + prev1
		if m.tri[k] == nil {
			if len(m.tri) > 150000 {
				break
			}
			m.tri[k] = map[string]uint32{}
		}
		m.tri[k][x]++
		if m.bi[prev1] == nil {
			m.bi[prev1] = map[string]uint32{}
		}
		m.bi[prev1][x]++
		m.uni[x]++
		m.uniN++
		prev2, prev1 = prev1, x
	}
}

// logp is the mean log-probability per word of a text under her own voice (backing off to single words).
func (m *Mind) logp(text string) float64 {
	w := append(toks(text), "</s>")
	if len(w) == 0 || m.uniN == 0 {
		return -10
	}
	prev1, prev2 := "<s>", "<s>"
	var s float64
	for _, x := range w {
		p := (float64(m.uni[x]) + .1) / (float64(m.uniN) + 1000)
		if c := m.tri[prev2+" "+prev1]; c != nil {
			var tot float64
			for _, n := range c {
				tot += float64(n)
			}
			p = .7*(float64(c[x])/tot) + .3*p
		}
		s += math.Log(p)
		prev2, prev1 = prev1, x
	}
	return s / float64(len(w))
}

// ---- prediction ----

type guess struct {
	text string
	cl   int
	sim  float64
	ep   *episode
	gen  bool // composed by her voice from the neighbours' words, not a remembered answer
}

// predict is her own answer to a situation from memory, without the episode skip (and its twins with the same words).
func (m *Mind) predict(text string, skip *episode, avoid []string) (guess, bool) {
	v := vec(text)
	type nb struct {
		e *episode
		s float64
	}
	var top []nb
	for _, e := range m.eps {
		if e == skip || (skip != nil && e.In == skip.In) {
			continue
		}
		s := cos(v, e.vec)
		if s < minSim {
			continue
		}
		top = append(top, nb{e, s})
	}
	if len(top) == 0 {
		return guess{}, false
	}
	sort.Slice(top, func(i, j int) bool { return top[i].s > top[j].s })
	if top[0].e.Tool { // when the closest memory needed tools, so does this
		return guess{}, false
	}
	if len(top) > 6 {
		top = top[:6]
	}
	best, bs := guess{}, -1e9
	for _, x := range top {
		if x.e.Tool || tooLike(x.e.Out, avoid) {
			continue
		}
		sc := x.s + .15*math.Exp(m.logp(x.e.Out)/2)
		if sc > bs {
			bs, best = sc, guess{x.e.Out, x.e.Cl, x.s, x.e, false}
		}
	}
	if m.compose && bs > -1e9 && len(top) > 1 {
		var outs []string
		var ws []float64
		for _, x := range top {
			if !x.e.Tool {
				outs = append(outs, x.e.Out)
				ws = append(ws, x.s)
			}
		}
		cands := m.composeAnswers(outs, ws, 8)
		if m.useRes && m.res != nil && m.res.acc >= .25 {
			cands = append(cands, m.res.generate(text, m.rng, 2)...)
		}
		for _, c := range cands {
			if tooLike(c, avoid) {
				continue
			}
			var sim float64
			for i, o := range outs {
				sim = math.Max(sim, cos(vec(c), vec(o))*(.8+.2*ws[i]))
			}
			if sim < .6 { // a remix must still be recognisably one of the answers she knows
				continue
			}
			if sc := top[0].s + .15*math.Exp(m.logp(c)/2) + .05*sim; sc > bs+.04 {
				bs, best = sc, guess{c, best.cl, top[0].s, best.ep, true}
			}
		}
	}
	return best, bs > -1e9
}

// composeAnswers writes n new answers in her own voice: it walks her trigram model, leaning toward the words of the remembered
// answers of similar situations (a pointer-style copy bias), and stops where answers of hers usually stop.
func (m *Mind) composeAnswers(outs []string, ws []float64, n int) []string {
	bias := map[string]float64{}
	for i, o := range outs {
		for _, t := range toks(o) {
			bias[t] += ws[i]
		}
	}
	var res []string
	seen := map[string]bool{}
	for k := 0; k < n; k++ {
		p1, p2 := "<s>", "<s>"
		var out []string
		for len(out) < 24 {
			c := map[string]float64{}
			for t, n := range m.tri[p2+" "+p1] {
				c[t] += float64(n)
			}
			for t, n := range m.bi[p1] {
				c[t] += .25 * float64(n)
			}
			if len(c) == 0 {
				break
			}
			keys := make([]string, 0, len(c))
			for t := range c {
				keys = append(keys, t)
			}
			sort.Strings(keys) // the same dice give the same word
			var tot float64
			w := make([]float64, len(keys))
			for i, t := range keys {
				x := c[t] * (1 + 6*bias[t])
				if t == "</s>" && len(out) < 1 {
					x = 0
				}
				w[i] = x
				tot += x
			}
			if tot == 0 {
				break
			}
			r := m.rng.Float64() * tot
			pick := keys[len(keys)-1]
			for i, t := range keys {
				if r -= w[i]; r <= 0 {
					pick = t
					break
				}
			}
			if pick == "</s>" {
				break
			}
			out = append(out, pick)
			p2, p1 = p1, pick
		}
		if len(out) >= 1 {
			t := strings.Join(out, " ")
			if !seen[t] {
				seen[t] = true
				res = append(res, t)
			}
		}
	}
	return res
}

func (c *cluster) update(hit bool, alpha float64) {
	h := 0.0
	if hit {
		h = 1
	}
	if c.N == 0 {
		c.Hit = h
	} else {
		c.Hit += alpha * (h - c.Hit)
	}
	c.N++
}

func (m *Mind) regrade(cfg Config) {
	if cfg.MinTrials <= 0 {
		cfg.MinTrials = 12
	}
	if cfg.HitRate <= 0 {
		cfg.HitRate = .8
	}
	for _, c := range m.cl {
		switch {
		case !c.Grad && c.N >= cfg.MinTrials && c.Hit >= cfg.HitRate:
			c.Grad = true
		case c.Grad && c.Hit < cfg.HitRate-.2:
			c.Grad = false
		}
	}
}

// Observe is a lesson: the teacher answered the situation with out (tool = it needed tools instead of just chatting). Before
// she learns it she tries to predict it: that is the exam that decides which habits may answer alone.
func (m *Mind) Observe(sit Situation, out string, tool bool, cfg Config) {
	text := strings.TrimSpace(sit.Text)
	if text == "" {
		return
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	m.compose = cfg.Compose
	m.reservoirFor(cfg)
	cl := -1
	if !tool {
		m.st.Teacher++
		if g, ok := m.predict(text, nil, nil); ok {
			hit := cos(vec(g.text), vec(out)) >= hitSim
			if c := m.cl[g.cl]; c != nil {
				c.update(hit, .1)
			}
			m.st.Shadow++
			h := 0.0
			if hit {
				h = 1
			}
			m.st.ShadowOK += .05 * (h - m.st.ShadowOK)
			if m.st.Shadow == 1 {
				m.st.ShadowOK = h
			}
			cl = g.cl
			if !m.hasPerp {
				m.perp, m.hasPerp = m.logp(out), true
			} else {
				m.perp += .05 * (m.logp(out) - m.perp)
			}
		}
	}
	v := vec(text)
	if cl < 0 {
		best := 0.0
		for _, e := range m.eps {
			if s := cos(v, e.vec); s > best && s >= joinSim {
				best, cl = s, e.Cl
			}
		}
	}
	if cl < 0 {
		cl = m.next
		m.next++
		m.cl[cl] = &cluster{}
	}
	if m.cl[cl] == nil {
		m.cl[cl] = &cluster{}
	}
	m.eps = append(m.eps, &episode{In: text, Out: out, Tool: tool, Cl: cl, vec: v, id: len(m.eps)})
	if !tool {
		m.appendCorpus(text, out, sit.Owner)
	}
	if !tool {
		m.train(out)
	}
	if len(m.eps) > maxEp { // forget the oldest memory that never served and is not the last of a graduated habit
		for i, e := range m.eps {
			if e.Served == 0 {
				m.eps = append(m.eps[:i], m.eps[i+1:]...)
				break
			}
		}
	}
	m.regrade(cfg)
}

// Try answers alone when a graduated habit fits, the region brain is calm and the answer is short.
func (m *Mind) Try(sit Situation, g Gate, cfg Config) (string, bool) {
	if !cfg.AnswerAlone || (sit.Owner && !cfg.WithOwner) || g.Threat > .35 || g.Conflict > .6 {
		return "", false
	}
	text := strings.TrimSpace(sit.Text)
	if text == "" {
		return "", false
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	m.compose = cfg.Compose
	m.reservoirFor(cfg)
	p, ok := m.predict(text, nil, append(append([]string(nil), m.recent...), m.banned...))
	if !ok || len([]rune(p.text)) > maxAnswer {
		return "", false
	}
	c := m.cl[p.cl]
	if c == nil || !c.Grad || p.sim < max(.6, cfg.MinSim) {
		return "", false
	}
	if m.rng.Float64() < .15 { // the unannounced examiner: the teacher answers, and her habit is graded against it
		return "", false
	}
	p.ep.Served++
	if p.gen {
		m.st.Composed++
	}
	m.recent = append(m.recent, p.text)
	if len(m.recent) > 6 {
		m.recent = m.recent[1:]
	}
	m.st.Saved++
	return p.text, true
}

// Dream is the examination in sleep: she answers her own memories from the others and grades the habits. No API is used.
func (m *Mind) Dream(n int, cfg Config) {
	m.mu.Lock()
	defer m.mu.Unlock()
	if len(m.eps) < 8 {
		return
	}
	m.compose = cfg.Compose
	if r := m.reservoirFor(cfg); r != nil { // sleep trains the reservoir on the talks she has had
		for k := 0; k < 1+n/10; k++ {
			if e := m.eps[m.rng.Intn(len(m.eps))]; !e.Tool {
				r.train(e.In, e.Out)
			}
		}
	}
	for i := 0; i < n; i++ {
		e := m.eps[m.rng.Intn(len(m.eps))]
		if e.Tool {
			continue
		}
		g, ok := m.predict(e.In, e, nil)
		if !ok {
			continue
		}
		hit := cos(vec(g.text), vec(e.Out)) >= hitSim
		if c := m.cl[g.cl]; c != nil {
			c.update(hit, .05)
		}
		h := 0.0
		if hit {
			h = 1
		}
		m.st.Dreams++
		m.st.DreamOK += .02 * (h - m.st.DreamOK)
	}
	m.regrade(cfg)
}

// Sample is one habit shown in the panel.
type Sample struct {
	In, Out string
	N       int
	Hit     float64
	Grad    bool
}

// Stats is the state of her mind for the panel.
type Stats struct {
	Episodes, Habits, Graduated   int
	Teacher, Shadow, Saved, Dream int
	Composed                      int
	ResAcc, ResLoss               float64
	ResWords, ResSteps            int
	ShadowHit, DreamHit           float64
	Coverage                      float64 // how many teacher answers she could have predicted
	Independence                  float64 // answers she gave alone out of all answers
	VoiceFit                      float64 // how well she predicts her own words, 0..1
	Top                           []Sample
}

// Stats reports the state.
func (m *Mind) Stats() Stats {
	m.mu.Lock()
	defer m.mu.Unlock()
	s := Stats{Episodes: len(m.eps), Teacher: m.st.Teacher, Shadow: m.st.Shadow, Saved: m.st.Saved, Composed: m.st.Composed, Dream: m.st.Dreams, ShadowHit: m.st.ShadowOK, DreamHit: m.st.DreamOK}
	for _, c := range m.cl {
		if c.N > 0 {
			s.Habits++
		}
		if c.Grad {
			s.Graduated++
		}
	}
	if m.st.Teacher > 0 {
		s.Coverage = float64(m.st.Shadow) / float64(m.st.Teacher)
	}
	if t := m.st.Teacher + m.st.Saved; t > 0 {
		s.Independence = float64(m.st.Saved) / float64(t)
	}
	if m.res != nil {
		s.ResAcc, s.ResLoss, s.ResWords, s.ResSteps = m.res.acc, m.res.loss, len(m.res.words), m.res.steps
	}
	if m.hasPerp {
		s.VoiceFit = math.Exp(m.perp)
	}
	seen := map[int]bool{}
	for i := len(m.eps) - 1; i >= 0 && len(s.Top) < 6; i-- {
		e := m.eps[i]
		c := m.cl[e.Cl]
		if e.Tool || c == nil || c.N == 0 || seen[e.Cl] {
			continue
		}
		seen[e.Cl] = true
		s.Top = append(s.Top, Sample{e.In, e.Out, c.N, c.Hit, c.Grad})
	}
	return s
}

// Prompt is one line for her: how far she is from needing the teacher.
func (m *Mind) Prompt() string {
	s := m.Stats()
	if s.Episodes < 5 {
		return ""
	}
	return "<independence>Ты учишься отвечать сама: помнишь " + itoa(s.Episodes) + " разговоров, привычных ответов " + itoa(s.Graduated) + ", сама ответила " + itoa(s.Saved) + " раз (" + itoa(int(s.Independence*100)) + "%). Это твоя собственная память, а не подсказка.</independence>\n"
}

func itoa(n int) string {
	if n == 0 {
		return "0"
	}
	neg := n < 0
	if neg {
		n = -n
	}
	var b []byte
	for n > 0 {
		b = append([]byte{byte('0' + n%10)}, b...)
		n /= 10
	}
	if neg {
		b = append([]byte{'-'}, b...)
	}
	return string(b)
}

// tooLike: the text is (almost) one of those she has just said.
func tooLike(text string, recent []string) bool {
	v := vec(text)
	for _, r := range recent {
		if r == text || cos(v, vec(r)) >= .9 {
			return true
		}
	}
	return false
}
