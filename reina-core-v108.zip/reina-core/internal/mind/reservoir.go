package mind

import (
	"compress/gzip"
	"encoding/gob"
	"math"
	"math/rand"
	"os"
	"path/filepath"
	"sort"
	"strings"
)

// The reservoir is the experiment: language without a transformer and without backpropagation. A sparse recurrent net of leaky
// neurons (fixed, random, hashed wiring: like cortex tissue before it has learned anything) is driven by the words of a talk;
// its state is a memory of everything said so far. Only a readout learns, by the local, dopamine-like error rule
// (weights += lr * (what came - what was expected) * activity): the prediction error of the next word. It trains in her sleep,
// on the talks the teacher gave her. Then, given a situation, the state after "what was said to me" is read out word by word
// into a reply. It is small and weak; its replies are only candidates, and pass the same exams as every other answer.

const (
	resN      = 2048 // reservoir neurons
	resV      = 2000 // words it can speak
	resIn     = 24   // neurons that every word pokes
	resK      = 8    // recurrent inputs per neuron
	resLeak   = .55
	resLR     = .06
	resMaxGen = 24
)

type reservoir struct {
	voc   map[string]int
	words []string
	w     []float32 // resV x (resN+1)
	salt  uint64
	acc   float64 // top-1 accuracy of the next word, moving average
	loss  float64
	steps int
	dirty bool
}

func newReservoir(seed int64) *reservoir {
	r := &reservoir{voc: map[string]int{}, w: make([]float32, resV*(resN+1)), salt: uint64(seed)*0x9e3779b97f4a7c15 + 1}
	r.id("<sep>")
	r.id("</s>")
	return r
}

func (r *reservoir) id(w string) int {
	if i, ok := r.voc[w]; ok {
		return i
	}
	if len(r.words) >= resV {
		return -1
	}
	r.voc[w] = len(r.words)
	r.words = append(r.words, w)
	return len(r.words) - 1
}

func hash64(a uint64) uint64 {
	a += 0x9e3779b97f4a7c15
	a = (a ^ (a >> 30)) * 0xbf58476d1ce4e5b9
	a = (a ^ (a >> 27)) * 0x94d049bb133111eb
	return a ^ (a >> 31)
}

// step drives the reservoir with one word (id) and returns the new state.
func (r *reservoir) step(s, tmp []float32, id int) {
	for i := 0; i < resN; i++ {
		var acc float32
		h := hash64(r.salt ^ uint64(i)*0x1f1f1f)
		for k := 0; k < resK; k++ {
			h2 := hash64(h ^ uint64(k+1)*0x51ed27)
			j := int(h2 % resN)
			if h2&(1<<40) != 0 {
				acc += s[j]
			} else {
				acc -= s[j]
			}
		}
		tmp[i] = acc * (1.15 / resK * 2)
	}
	for k := 0; k < resIn; k++ { // the word pokes its own neurons
		h := hash64(r.salt ^ uint64(id+7)*0xabcdef ^ uint64(k)*0x77)
		v := float32(1)
		if h&(1<<33) != 0 {
			v = -1
		}
		tmp[int(h%resN)] += v
	}
	for i := range s {
		s[i] = (1-resLeak)*s[i] + resLeak*float32(math.Tanh(float64(tmp[i])))
	}
}

// predict is the softmax over the words from the state.
func (r *reservoir) predict(s []float32, p []float32) {
	nw := len(r.words)
	var max float32 = -1e30
	for v := 0; v < nw; v++ {
		row := r.w[v*(resN+1) : (v+1)*(resN+1)]
		z := row[resN]
		for i, x := range s {
			z += row[i] * x
		}
		p[v] = z
		if z > max {
			max = z
		}
	}
	var sum float32
	for v := 0; v < nw; v++ {
		p[v] = float32(math.Exp(float64(p[v] - max)))
		sum += p[v]
	}
	for v := 0; v < nw; v++ {
		p[v] /= sum
	}
}

// train lets the reservoir hear one talk (what was said, then her answer) and learns to expect the answer's words.
func (r *reservoir) train(in, out string) {
	s := make([]float32, resN)
	tmp := make([]float32, resN)
	feed := func(w string) int {
		id := r.id(w)
		if id < 0 {
			id = 1
		}
		r.step(s, tmp, id)
		return id
	}
	for _, w := range toks(in) {
		feed(w)
	}
	feed("<sep>")
	p := make([]float32, resV)
	seq := append(toks(out), "</s>")
	for _, w := range seq {
		target := r.id(w)
		if target < 0 {
			target = 1
		}
		r.predict(s, p)
		best := 0
		for v := 1; v < len(r.words); v++ {
			if p[v] > p[best] {
				best = v
			}
		}
		hit := 0.0
		if best == target {
			hit = 1
		}
		r.acc += .02 * (hit - r.acc)
		r.loss += .02 * (-math.Log(float64(p[target])+1e-9) - r.loss)
		r.steps++
		for v := 0; v < len(r.words); v++ { // the local error rule: only the readout changes
			e := -p[v]
			if v == target {
				e += 1
			}
			if e > -1e-3 && e < 1e-3 {
				continue
			}
			g := resLR * e
			row := r.w[v*(resN+1) : (v+1)*(resN+1)]
			for i, x := range s {
				row[i] += g * x
			}
			row[resN] += g
		}
		feed(w)
	}
	r.dirty = true
}

// generate reads a reply out of the state after the situation: sampled among the likeliest words, until "</s>".
func (r *reservoir) generate(in string, rng *rand.Rand, n int) []string {
	if r.steps < 200 {
		return nil // it has heard too little to say anything
	}
	var res []string
	seen := map[string]bool{}
	for k := 0; k < n; k++ {
		s := make([]float32, resN)
		tmp := make([]float32, resN)
		for _, w := range toks(in) {
			id, ok := r.voc[w]
			if !ok {
				id = 1
			}
			r.step(s, tmp, id)
		}
		r.step(s, tmp, 0)
		p := make([]float32, resV)
		var out []string
		for len(out) < resMaxGen {
			r.predict(s, p)
			type cand struct {
				v int
				p float32
			}
			cs := make([]cand, 0, len(r.words))
			for v := 2; v < len(r.words); v++ {
				cs = append(cs, cand{v, p[v]})
			}
			endP := p[1]
			sort.Slice(cs, func(i, j int) bool { return cs[i].p > cs[j].p })
			if len(cs) > 4 {
				cs = cs[:4]
			}
			if len(cs) == 0 {
				break
			}
			var tot float32
			for _, c := range cs {
				tot += c.p
			}
			if endP > cs[0].p && len(out) > 0 {
				break
			}
			x := float32(rng.Float64()) * tot
			pick := cs[0].v
			for _, c := range cs {
				if x -= c.p; x <= 0 {
					pick = c.v
					break
				}
			}
			out = append(out, r.words[pick])
			r.step(s, tmp, pick)
		}
		if len(out) > 0 {
			t := strings.Join(out, " ")
			if !seen[t] {
				seen[t] = true
				res = append(res, t)
			}
		}
	}
	return res
}

type resFile struct {
	Words []string
	W     []float32
	Acc   float64
	Loss  float64
	Steps int
}

func (r *reservoir) save(path string) error {
	f, err := os.CreateTemp(filepath.Dir(path), ".res-*.tmp")
	if err != nil {
		return err
	}
	tmp := f.Name()
	zw := gzip.NewWriter(f)
	err = gob.NewEncoder(zw).Encode(resFile{r.words, r.w, r.acc, r.loss, r.steps})
	if cerr := zw.Close(); err == nil {
		err = cerr
	}
	if err == nil {
		err = f.Sync() // data must be on disk before the rename makes it the only copy
	}
	if cerr := f.Close(); err == nil {
		err = cerr
	}
	if err == nil {
		err = os.Chmod(tmp, 0o600)
	}
	if err == nil {
		err = os.Rename(tmp, path)
	}
	if err != nil {
		_ = os.Remove(tmp)
		return err
	}
	r.dirty = false
	return nil
}

func (r *reservoir) load(path string) {
	f, err := os.Open(path)
	if err != nil {
		return
	}
	defer f.Close()
	zr, err := gzip.NewReader(f)
	if err != nil {
		return
	}
	var rf resFile
	if gob.NewDecoder(zr).Decode(&rf) != nil || len(rf.W) != len(r.w) {
		return
	}
	r.words, r.w, r.acc, r.loss, r.steps = rf.Words, rf.W, rf.Acc, rf.Loss, rf.Steps
	r.voc = map[string]int{}
	for i, w := range r.words {
		r.voc[w] = i
	}
}
