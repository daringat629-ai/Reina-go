package mind

import (
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
)

// Concurrent saves must not clash on a shared temp name, leave no temp files, and the result must load back.
func TestReservoirSaveAtomicConcurrent(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "x.res.gz")
	r := newReservoir(1)
	var wg sync.WaitGroup
	for i := 0; i < 4; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			c := newReservoir(1)
			if err := c.save(path); err != nil {
				t.Error(err)
			}
		}()
	}
	wg.Wait()
	ents, _ := os.ReadDir(dir)
	for _, e := range ents {
		if strings.HasSuffix(e.Name(), ".tmp") {
			t.Fatalf("temp file left: %s", e.Name())
		}
	}
	r.load(path)
	if st, err := os.Stat(path); err != nil || st.Mode().Perm() != 0o600 {
		t.Fatalf("stat %v %v", st, err)
	}
}
