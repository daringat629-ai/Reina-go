// Package ledger is the owner's money book: what he spent and earned, by category and currency, with monthly
// budgets that warn when they run out. Kept in one JSON file; amounts in different currencies are never added up
// together (there is no honest exchange rate for the past).
package ledger

import (
	"errors"
	"fmt"
	"math"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"orvi/internal/store"
)

const (
	Expense = "expense"
	Income  = "income"
)

// Entry is one line of the book.
type Entry struct {
	ID       int       `json:"id"`
	Date     string    `json:"date"` // YYYY-MM-DD in the owner's zone
	Kind     string    `json:"kind"` // expense or income
	Amount   float64   `json:"amount"`
	Currency string    `json:"currency"`
	Category string    `json:"category"`
	Note     string    `json:"note,omitempty"`
	Created  time.Time `json:"created"`
}

// Budget is a monthly limit of spending in a category.
type Budget struct {
	Category string  `json:"category"`
	Limit    float64 `json:"limit"`
	Currency string  `json:"currency"`
}

type file struct {
	Entries  []Entry  `json:"entries"`
	Budgets  []Budget `json:"budgets,omitempty"`
	Currency string   `json:"currency,omitempty"` // the default currency
	Next     int      `json:"next"`
}

// MaxEntries keeps the file small enough to read at once (years of daily spending).
const MaxEntries = 50000

type Store struct {
	mu    sync.Mutex
	path  string
	f     file
	saver store.Saver
}

// New loads the book (missing = empty; a broken file is moved aside and reported).
func New(path string) *Store {
	s := &Store{path: path, saver: store.Saver{What: "ledger"}}
	store.Load("ledger", path, &s.f)
	if s.f.Next <= 0 {
		s.f.Next = 1
		for _, e := range s.f.Entries {
			s.f.Next = max(s.f.Next, e.ID+1)
		}
	}
	return s
}

func (s *Store) save() error { return s.saver.Save(s.path, s.f) }

var currencies = map[string]string{
	"сом": "KGS", "сомов": "KGS", "сома": "KGS", "с": "KGS", "kgs": "KGS", "som": "KGS",
	"руб": "RUB", "рубль": "RUB", "рублей": "RUB", "рубля": "RUB", "р": "RUB", "₽": "RUB", "rub": "RUB",
	"$": "USD", "usd": "USD", "доллар": "USD", "долларов": "USD", "доллара": "USD", "бакс": "USD", "баксов": "USD",
	"€": "EUR", "eur": "EUR", "евро": "EUR",
	"тенге": "KZT", "₸": "KZT", "kzt": "KZT", "грн": "UAH", "гривен": "UAH", "₴": "UAH", "uah": "UAH",
	"сум": "UZS", "uzs": "UZS", "лари": "GEL", "gel": "GEL", "драм": "AMD", "amd": "AMD", "лир": "TRY", "лира": "TRY", "try": "TRY",
	"юань": "CNY", "юаней": "CNY", "cny": "CNY", "£": "GBP", "фунт": "GBP", "gbp": "GBP", "usdt": "USDT",
}

var reCode = regexp.MustCompile(`^[A-Za-z]{3,4}$`)

// Currency normalizes a currency name ("сом", "₽", "usd") to its code; "" stays "".
func Currency(s string) string {
	s = strings.ToLower(strings.TrimSpace(strings.TrimSuffix(strings.TrimSpace(s), ".")))
	if s == "" {
		return ""
	}
	if c, ok := currencies[s]; ok {
		return c
	}
	if reCode.MatchString(s) {
		return strings.ToUpper(s)
	}
	return strings.ToUpper(s)
}

// Category normalizes a category name (lower case, single spaces).
func Category(s string) string {
	return strings.Join(strings.Fields(strings.ToLower(s)), " ")
}

// DefaultCurrency is the currency used when none is given ("" until the first entry with one).
func (s *Store) DefaultCurrency() string {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.f.Currency
}

// SetDefaultCurrency changes the currency used when none is given.
func (s *Store) SetDefaultCurrency(c string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.f.Currency = Currency(c)
	return s.save()
}

// Add writes an entry and returns it with warnings (a budget passed or nearly used up, a new category).
func (s *Store) Add(e Entry, now time.Time) (Entry, []string, error) {
	if e.Amount == 0 || math.IsNaN(e.Amount) || math.IsInf(e.Amount, 0) {
		return Entry{}, nil, errors.New("the amount must be a number other than 0")
	}
	if e.Amount < 0 { // "-500" means spent
		e.Amount = -e.Amount
		if e.Kind == "" {
			e.Kind = Expense
		}
	}
	switch strings.ToLower(e.Kind) {
	case "", Expense, "расход", "spend", "spent":
		e.Kind = Expense
	case Income, "доход", "earn", "earned":
		e.Kind = Income
	default:
		return Entry{}, nil, fmt.Errorf("kind is expense or income, not %q", e.Kind)
	}
	e.Category = Category(e.Category)
	if e.Category == "" {
		e.Category = "разное"
	}
	if _, err := time.Parse("2006-01-02", e.Date); err != nil {
		return Entry{}, nil, fmt.Errorf("bad date %q", e.Date)
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if len(s.f.Entries) >= MaxEntries {
		return Entry{}, nil, fmt.Errorf("the book is full (%d entries)", MaxEntries)
	}
	e.Currency = Currency(e.Currency)
	if e.Currency == "" {
		e.Currency = s.f.Currency
	}
	if e.Currency == "" {
		return Entry{}, nil, errors.New("which currency? say it once (e.g. KGS, RUB, USD): it becomes the default")
	}
	if s.f.Currency == "" {
		s.f.Currency = e.Currency
	}
	var warn []string
	if e.Kind == Expense && !s.knownLocked(e.Category) {
		if cats := s.categoriesLocked(Expense); len(cats) > 0 {
			warn = append(warn, fmt.Sprintf("new category %q (existing: %s): if it is one of those, fix it with action=edit", e.Category, strings.Join(cats, ", ")))
		}
	}
	e.ID, e.Created = s.f.Next, now
	e.Note = strings.TrimSpace(e.Note)
	s.f.Next++
	s.f.Entries = append(s.f.Entries, e)
	if err := s.save(); err != nil {
		s.f.Entries = s.f.Entries[:len(s.f.Entries)-1]
		return Entry{}, nil, err
	}
	if e.Kind == Expense {
		if b, ok := s.budgetLocked(e.Category, e.Currency); ok {
			spent := s.sumLocked(e.Category, e.Currency, e.Date[:7])
			switch {
			case spent > b.Limit:
				warn = append(warn, fmt.Sprintf("BUDGET EXCEEDED: %s %s of %s %s this month", Money(spent), e.Currency, Money(b.Limit), b.Currency))
			case spent >= 0.8*b.Limit:
				warn = append(warn, fmt.Sprintf("budget almost used: %s of %s %s this month", Money(spent), Money(b.Limit), b.Currency))
			}
		}
	}
	return e, warn, nil
}

func (s *Store) knownLocked(cat string) bool {
	for _, e := range s.f.Entries {
		if e.Category == cat {
			return true
		}
	}
	return false
}

func (s *Store) categoriesLocked(kind string) []string {
	seen := map[string]int{}
	for _, e := range s.f.Entries {
		if kind == "" || e.Kind == kind {
			seen[e.Category]++
		}
	}
	out := make([]string, 0, len(seen))
	for c := range seen {
		out = append(out, c)
	}
	sort.Slice(out, func(i, j int) bool {
		return seen[out[i]] > seen[out[j]] || seen[out[i]] == seen[out[j]] && out[i] < out[j]
	})
	if len(out) > 25 {
		out = out[:25]
	}
	return out
}

// Categories lists the categories in use, the most used first.
func (s *Store) Categories(kind string) []string {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.categoriesLocked(kind)
}

func (s *Store) budgetLocked(cat, cur string) (Budget, bool) {
	for _, b := range s.f.Budgets {
		if b.Category == cat && b.Currency == cur {
			return b, true
		}
	}
	return Budget{}, false
}

// sumLocked is what was spent in a category (all categories when cat is "") and currency in a month (YYYY-MM).
func (s *Store) sumLocked(cat, cur, month string) float64 {
	t := 0.0
	for _, e := range s.f.Entries {
		if e.Kind == Expense && (cat == "" || e.Category == cat) && e.Currency == cur && strings.HasPrefix(e.Date, month) {
			t += e.Amount
		}
	}
	return t
}

// Edit changes an entry: fields left empty (amount 0) stay.
func (s *Store) Edit(id int, upd Entry) (Entry, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	for i := range s.f.Entries {
		e := &s.f.Entries[i]
		if e.ID != id {
			continue
		}
		old := *e
		if upd.Amount != 0 {
			e.Amount = math.Abs(upd.Amount)
		}
		if upd.Category != "" {
			e.Category = Category(upd.Category)
		}
		if upd.Currency != "" {
			e.Currency = Currency(upd.Currency)
		}
		if upd.Note != "" {
			e.Note = strings.TrimSpace(upd.Note)
		}
		if upd.Date != "" {
			if _, err := time.Parse("2006-01-02", upd.Date); err != nil {
				return Entry{}, fmt.Errorf("bad date %q", upd.Date)
			}
			e.Date = upd.Date
		}
		switch strings.ToLower(upd.Kind) {
		case Expense, Income:
			e.Kind = strings.ToLower(upd.Kind)
		}
		if err := s.save(); err != nil {
			*e = old
			return Entry{}, err
		}
		return *e, nil
	}
	return Entry{}, fmt.Errorf("no entry #%d", id)
}

// Delete removes an entry.
func (s *Store) Delete(id int) (Entry, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	for i, e := range s.f.Entries {
		if e.ID == id {
			s.f.Entries = append(s.f.Entries[:i], s.f.Entries[i+1:]...)
			if err := s.save(); err != nil {
				return Entry{}, err
			}
			return e, nil
		}
	}
	return Entry{}, fmt.Errorf("no entry #%d", id)
}

// Filter selects entries.
type Filter struct {
	From, To string // dates, inclusive ("" = open)
	Kind     string
	Category string
	Text     string // in the note or the category
}

// List returns the matching entries, newest first.
func (s *Store) List(f Filter) []Entry {
	s.mu.Lock()
	defer s.mu.Unlock()
	cat, text := Category(f.Category), strings.ToLower(strings.TrimSpace(f.Text))
	var out []Entry
	for _, e := range s.f.Entries {
		if (f.From != "" && e.Date < f.From) || (f.To != "" && e.Date > f.To) || (f.Kind != "" && e.Kind != f.Kind) ||
			(cat != "" && e.Category != cat) ||
			(text != "" && !strings.Contains(strings.ToLower(e.Note+" "+e.Category), text)) {
			continue
		}
		out = append(out, e)
	}
	sort.SliceStable(out, func(i, j int) bool {
		if out[i].Date != out[j].Date {
			return out[i].Date > out[j].Date
		}
		return out[i].ID > out[j].ID
	})
	return out
}

// SetBudget sets (limit > 0) or removes (limit = 0) the monthly budget of a category.
func (s *Store) SetBudget(cat string, limit float64, cur string) error {
	cat = Category(cat)
	if cat == "" {
		return errors.New("which category?")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	cur = Currency(cur)
	if cur == "" {
		cur = s.f.Currency
	}
	if cur == "" {
		return errors.New("which currency?")
	}
	kept := s.f.Budgets[:0]
	for _, b := range s.f.Budgets {
		if b.Category != cat || b.Currency != cur {
			kept = append(kept, b)
		}
	}
	s.f.Budgets = kept
	if limit > 0 {
		s.f.Budgets = append(s.f.Budgets, Budget{Category: cat, Limit: limit, Currency: cur})
	}
	return s.save()
}

// BudgetLine is the state of one budget in a month.
type BudgetLine struct {
	Budget
	Spent float64
}

// Budgets returns every budget with what was spent in the month (YYYY-MM). The category "всё" (or "all") limits
// the whole month's spending.
func (s *Store) Budgets(month string) []BudgetLine {
	s.mu.Lock()
	defer s.mu.Unlock()
	var out []BudgetLine
	for _, b := range s.f.Budgets {
		cat := b.Category
		if cat == "всё" || cat == "все" || cat == "all" {
			cat = ""
		}
		out = append(out, BudgetLine{Budget: b, Spent: s.sumLocked(cat, b.Currency, month)})
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Category < out[j].Category })
	return out
}

// --- reports ---

// Report is a summary of a period.
type Report struct {
	From, To string
	Days     int
	// per currency
	Spent, Earned map[string]float64
	// per currency, categories by spending (largest first)
	ByCategory map[string][]Share
	Largest    []Entry
	Count      int
}

// Share is one category's part of the spending.
type Share struct {
	Category string
	Amount   float64
	Percent  float64
	Count    int
}

// Summarize makes the report of [from, to].
func (s *Store) Summarize(from, to string) Report {
	r := Report{From: from, To: to, Spent: map[string]float64{}, Earned: map[string]float64{}, ByCategory: map[string][]Share{}}
	if a, err := time.Parse("2006-01-02", from); err == nil {
		if b, err := time.Parse("2006-01-02", to); err == nil {
			r.Days = int(b.Sub(a).Hours()/24) + 1
		}
	}
	entries := s.List(Filter{From: from, To: to})
	cats := map[string]map[string]*Share{}
	for _, e := range entries {
		r.Count++
		if e.Kind == Income {
			r.Earned[e.Currency] += e.Amount
			continue
		}
		r.Spent[e.Currency] += e.Amount
		if cats[e.Currency] == nil {
			cats[e.Currency] = map[string]*Share{}
		}
		sh := cats[e.Currency][e.Category]
		if sh == nil {
			sh = &Share{Category: e.Category}
			cats[e.Currency][e.Category] = sh
		}
		sh.Amount += e.Amount
		sh.Count++
		r.Largest = append(r.Largest, e)
	}
	for cur, m := range cats {
		var list []Share
		for _, sh := range m {
			sh.Percent = 100 * sh.Amount / r.Spent[cur]
			list = append(list, *sh)
		}
		sort.Slice(list, func(i, j int) bool { return list[i].Amount > list[j].Amount })
		r.ByCategory[cur] = list
	}
	sort.SliceStable(r.Largest, func(i, j int) bool { return r.Largest[i].Amount > r.Largest[j].Amount })
	if len(r.Largest) > 5 {
		r.Largest = r.Largest[:5]
	}
	return r
}

// Money writes an amount the Russian way: 12 500, 3,5.
func Money(v float64) string {
	s := strconv.FormatFloat(math.Round(v*100)/100, 'f', 2, 64)
	s = strings.TrimSuffix(strings.TrimSuffix(s, "00"), ".")
	whole, frac, _ := strings.Cut(s, ".")
	neg := strings.HasPrefix(whole, "-")
	whole = strings.TrimPrefix(whole, "-")
	var g []string
	for len(whole) > 3 {
		g = append([]string{whole[len(whole)-3:]}, g...)
		whole = whole[:len(whole)-3]
	}
	out := strings.Join(append([]string{whole}, g...), " ")
	if frac != "" {
		out += "," + strings.TrimRight(frac, "0")
	}
	if neg {
		out = "-" + out
	}
	return out
}
