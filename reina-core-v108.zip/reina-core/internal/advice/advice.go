// Package advice is how the people she talks to shape her: when something in her own life puzzles her (a feeling, a
// relationship, a choice), she opens a question, asks different people what they think, keeps their answers, and once
// she has heard enough she decides what she thinks now. Her conclusions stay with her and colour who she becomes, so her
// character grows out of the people around her instead of being written in advance.
//
// It never carries private details from one person to another: a question is written in general words, and the
// answers are only ever shown back to her as advice, never to other people.
package advice

import (
	"errors"
	"fmt"
	"strings"
	"sync"
	"time"

	"orvi/internal/store"
)

// Answer is what one person told her.
type Answer struct {
	UserID int64     `json:"user_id"`
	Name   string    `json:"name"`
	Text   string    `json:"text"`
	At     time.Time `json:"at"`
}

// Question is one thing she is curious about.
type Question struct {
	ID         int                 `json:"id"`
	Text       string              `json:"text"`
	Opened     time.Time           `json:"opened"`
	Asked      map[int64]time.Time `json:"asked,omitempty"` // whom she has asked, when
	Answers    []Answer            `json:"answers,omitempty"`
	Conclusion string              `json:"conclusion,omitempty"`
	Closed     time.Time           `json:"closed,omitempty"`
}

type data struct {
	Questions []Question `json:"questions"`
	Next      int        `json:"next"`
	LastAsk   time.Time  `json:"last_ask"` // the last time a chat was offered a question (a global pace)
}

// Box keeps her questions in one JSON file. Safe for concurrent use.
type Box struct {
	mu    sync.Mutex
	path  string
	d     data
	saver store.Saver
}

// Rules of pace: how often she brings a question up and how many voices she wants before deciding.
const (
	MaxOpen     = 2                // open questions at once
	Enough      = 3                // answers after which she is nudged to decide
	PaceBetween = 40 * time.Minute // between offering a question in any two chats
	PerPerson   = 3 * 24 * time.Hour
)

// Open loads the box (or starts empty).
func Open(path string) *Box {
	b := &Box{path: path, saver: store.Saver{What: "advice"}}
	store.Load("advice", path, &b.d)
	return b
}

func (b *Box) save() { _ = b.saver.Save(b.path, b.d) }

// Ask opens a new question in her words.
func (b *Box) Ask(text string, now time.Time) (Question, error) {
	text = strings.TrimSpace(text)
	if len([]rune(text)) < 8 {
		return Question{}, errors.New("write the question in a full sentence")
	}
	b.mu.Lock()
	defer b.mu.Unlock()
	open := 0
	for _, q := range b.d.Questions {
		if q.Closed.IsZero() {
			open++
			if strings.EqualFold(q.Text, text) {
				return q, nil
			}
		}
	}
	if open >= MaxOpen {
		return Question{}, fmt.Errorf("you already have %d open questions: listen to people and decide on one first", open)
	}
	b.d.Next++
	q := Question{ID: b.d.Next, Text: text, Opened: now}
	b.d.Questions = append(b.d.Questions, q)
	b.save()
	return q, nil
}

// Note keeps what a person answered to a question.
func (b *Box) Note(id int, user int64, name, text string, now time.Time) (Question, error) {
	text = strings.TrimSpace(text)
	if text == "" {
		return Question{}, errors.New("what did they say?")
	}
	b.mu.Lock()
	defer b.mu.Unlock()
	q := b.find(id)
	if q == nil || !q.Closed.IsZero() {
		return Question{}, fmt.Errorf("no open question %d", id)
	}
	for i, a := range q.Answers {
		if a.UserID == user && user != 0 { // the same person again: the newer answer replaces the older one
			q.Answers[i] = Answer{UserID: user, Name: name, Text: text, At: now}
			b.save()
			return *q, nil
		}
	}
	q.Answers = append(q.Answers, Answer{UserID: user, Name: name, Text: text, At: now})
	b.save()
	return *q, nil
}

// Decide closes a question with what she now thinks.
func (b *Box) Decide(id int, conclusion string, now time.Time) (Question, error) {
	conclusion = strings.TrimSpace(conclusion)
	if conclusion == "" {
		return Question{}, errors.New("write what you think now")
	}
	b.mu.Lock()
	defer b.mu.Unlock()
	q := b.find(id)
	if q == nil || !q.Closed.IsZero() {
		return Question{}, fmt.Errorf("no open question %d", id)
	}
	q.Conclusion, q.Closed = conclusion, now
	b.save()
	return *q, nil
}

func (b *Box) find(id int) *Question {
	for i := range b.d.Questions {
		if b.d.Questions[i].ID == id {
			return &b.d.Questions[i]
		}
	}
	return nil
}

// Offer picks an open question to bring up with this person, if the pace allows: not too often across chats, not the
// same question to the same person twice, and never the same person more than once in PerPerson. It marks it offered.
func (b *Box) Offer(user int64, now time.Time) (Question, bool) {
	b.mu.Lock()
	defer b.mu.Unlock()
	if now.Sub(b.d.LastAsk) < PaceBetween {
		return Question{}, false
	}
	for _, q := range b.d.Questions {
		if at, ok := q.Asked[user]; ok && now.Sub(at) < PerPerson {
			return Question{}, false
		}
	}
	for i := range b.d.Questions {
		q := &b.d.Questions[i]
		if !q.Closed.IsZero() || len(q.Answers) >= Enough+2 {
			continue
		}
		if _, asked := q.Asked[user]; asked {
			continue
		}
		if q.Asked == nil {
			q.Asked = map[int64]time.Time{}
		}
		q.Asked[user] = now
		b.d.LastAsk = now
		b.save()
		return *q, true
	}
	return Question{}, false
}

// Pending is the question asked in this chat that is still waiting for this person's answer (the most recent one).
func (b *Box) Pending(user int64, now time.Time) (Question, bool) {
	b.mu.Lock()
	defer b.mu.Unlock()
	for i := len(b.d.Questions) - 1; i >= 0; i-- {
		q := b.d.Questions[i]
		at, asked := q.Asked[user]
		if !asked || !q.Closed.IsZero() || now.Sub(at) > 24*time.Hour {
			continue
		}
		answered := false
		for _, a := range q.Answers {
			answered = answered || a.UserID == user
		}
		if !answered {
			return q, true
		}
	}
	return Question{}, false
}

// Ready lists open questions with enough answers to decide.
func (b *Box) Ready() []Question {
	b.mu.Lock()
	defer b.mu.Unlock()
	var out []Question
	for _, q := range b.d.Questions {
		if q.Closed.IsZero() && len(q.Answers) >= Enough {
			out = append(out, q)
		}
	}
	return out
}

// OpenCount is how many questions are open, and when the last one was opened.
func (b *Box) OpenCount() (n int, last time.Time) {
	b.mu.Lock()
	defer b.mu.Unlock()
	for _, q := range b.d.Questions {
		if q.Closed.IsZero() {
			n++
		}
		if q.Opened.After(last) {
			last = q.Opened
		}
	}
	return
}

// Lessons are her latest conclusions, newest first (at most n).
func (b *Box) Lessons(n int) []Question {
	b.mu.Lock()
	defer b.mu.Unlock()
	var out []Question
	for i := len(b.d.Questions) - 1; i >= 0 && len(out) < n; i-- {
		if q := b.d.Questions[i]; !q.Closed.IsZero() {
			out = append(out, q)
		}
	}
	return out
}

// All is every question, for the owner's panel.
func (b *Box) All() []Question {
	b.mu.Lock()
	defer b.mu.Unlock()
	return append([]Question(nil), b.d.Questions...)
}

// clip shortens a text to n runes for a prompt.
func clip(s string, n int) string {
	r := []rune(strings.Join(strings.Fields(s), " "))
	if len(r) <= n {
		return string(r)
	}
	return string(r[:n]) + "…"
}

// LessonsPrompt is the <what_people_taught_me> block: what she decided after listening to people. It is part of who she is.
func (b *Box) LessonsPrompt() string {
	ls := b.Lessons(5)
	if len(ls) == 0 {
		return ""
	}
	var s strings.Builder
	s.WriteString("<what_people_taught_me>\nТо, что ты решила сама, выслушав разных людей. Это часть тебя сейчас:\n")
	for _, q := range ls {
		fmt.Fprintf(&s, "- «%s» → %s (%d мнений)\n", clip(q.Text, 120), clip(q.Conclusion, 220), len(q.Answers))
	}
	s.WriteString("</what_people_taught_me>\n")
	return s.String()
}

// ReadyPrompt is the block for her own time: questions she has heard enough about, with what people said.
func (b *Box) ReadyPrompt() string {
	qs := b.Ready()
	if len(qs) == 0 {
		return ""
	}
	q := qs[0]
	var s strings.Builder
	fmt.Fprintf(&s, "<advice_ready id=\"%d\">\nТы спрашивала у людей: «%s». Вот что тебе ответили:\n", q.ID, clip(q.Text, 200))
	for _, a := range q.Answers {
		fmt.Fprintf(&s, "- %s: %s\n", clip(a.Name, 30), clip(a.Text, 240))
	}
	s.WriteString("Подумай, с чем ты согласна, а с чем нет, и реши, что ты думаешь теперь. Запиши это своими словами: #advice decide. Можно не соглашаться ни с кем.\n</advice_ready>\n")
	return s.String()
}
