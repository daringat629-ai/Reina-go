package admin

import (
	"context"
	"encoding/json"
	"errors"
	"strings"
	"testing"
	"time"

	"orvi/internal/people"
	"orvi/internal/telegram"
)

type descCtl struct {
	ctl
	store *people.Store
}

func (d *descCtl) DescribePerson(_ context.Context, id int64) (people.Card, error) {
	if id == 13 {
		return people.Card{}, errors.New("она пока ничего не знает об этом человеке")
	}
	err := d.store.SetAbout(id, "", "Свой парень, любит ассемблер.", time.Now())
	return d.store.Get(id), err
}

func TestPeopleCardsGetProfilesAndHerDescription(t *testing.T) {
	p, mux, _, _ := rig(t)
	p.People = people.New(t.TempDir())
	fk := telegram.NewFake()
	fk.Users = map[int64]telegram.User{7: {ID: 7, Name: "Вася", Username: "vasya", Bio: "пишу на asm"}}
	p.TG = fk
	p.Ctl = &descCtl{store: p.People}
	p.People.Add(7, "Вася", "любит ассемблер", true, time.Now())

	read := func(body string) map[string]any {
		method := "GET"
		if body != "" {
			method = "POST"
		}
		w := do(mux, method, "/admin/api/people", body, auth)
		if w.Code != 200 {
			t.Fatalf("%d %s", w.Code, w.Body)
		}
		var o map[string]any
		json.Unmarshal(w.Body.Bytes(), &o)
		return o
	}
	o := read("")
	card := o["cards"].([]any)[0].(map[string]any)
	if card["username"] != "vasya" || card["bio"] != "пишу на asm" || o["can_describe"] != true {
		t.Fatalf("the Telegram profile is missing: %v", o)
	}
	if p.People.Get(7).Username != "vasya" {
		t.Fatal("the profile was not filed on the card")
	}
	// "make her describe" works for a person with a card and for a new id
	o = read(`{"id":7,"describe":true}`)
	if c := o["cards"].([]any)[0].(map[string]any); !strings.Contains(c["about"].(string), "Свой парень") {
		t.Fatalf("%v", c)
	}
	if w := do(mux, "POST", "/admin/api/people", `{"id":13,"describe":true}`, auth); w.Code != 400 || !strings.Contains(w.Body.String(), "ничего не знает") {
		t.Fatalf("%d %s", w.Code, w.Body)
	}
	// the owner can correct the description by hand, and saving facts does not wipe it
	o = read(`{"id":7,"name":"Вася","about":"Правка руками"}`)
	if c := o["cards"].([]any)[0].(map[string]any); c["about"] != "Правка руками" || len(c["facts"].([]any)) != 1 {
		t.Fatalf("%v", c)
	}
	o = read(`{"id":7,"name":"Вася","facts":[{"text":"новый факт","private":true}]}`)
	if c := o["cards"].([]any)[0].(map[string]any); c["about"] != "Правка руками" || c["username"] != "vasya" {
		t.Fatalf("%v", c)
	}
	// deleting the card = no facts and an empty description
	o = read(`{"id":7,"name":"Вася","facts":[],"about":""}`)
	if len(o["cards"].([]any)) != 0 {
		t.Fatalf("%v", o)
	}
}

func TestPeopleTabWithoutTelegramStillWorks(t *testing.T) {
	p, mux, _, _ := rig(t)
	p.People = people.New(t.TempDir())
	p.People.Add(7, "Вася", "факт", false, time.Now())
	w := do(mux, "GET", "/admin/api/people", "", auth)
	if w.Code != 200 || !strings.Contains(w.Body.String(), `"can_describe":false`) {
		t.Fatalf("%d %s", w.Code, w.Body)
	}
	if w := do(mux, "POST", "/admin/api/people", `{"id":7,"describe":true}`, auth); w.Code != 400 {
		t.Fatalf("%d", w.Code)
	}
}

func TestPeoplePageShowsAvatarsAndAbout(t *testing.T) {
	for _, want := range []string{"/admin/api/tg/avatar?id=", "Что она думает о человеке", "Пусть опишет", "c.username"} {
		if !strings.Contains(string(page), want) {
			t.Fatalf("the page lacks %q", want)
		}
	}
}
