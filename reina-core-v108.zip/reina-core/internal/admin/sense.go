package admin

import (
	"net/http"
	"time"

	"orvi/internal/sense"
)

// senseAPI: her sensorium: every sensor with place, value, expectation, surprise, and who won attention.
func (p *Panel) senseAPI(w http.ResponseWriter, r *http.Request) {
	if p.Sense == nil || p.Body == nil {
		fail(w, http.StatusNotFound, "сенсориум выключен")
		return
	}
	p.Sense.Update(time.Now(), p.Body.Snapshot())
	s := p.Sense.Snapshot()
	var att []string
	for _, v := range s.Attended() {
		att = append(att, v.ID)
	}
	af := sense.Affect{Control: .6}
	if p.Feel != nil {
		f := p.Feel.Snapshot()
		af = sense.Affect{Valence: f.Valence, Arousal: f.Arousal, Control: f.Control}
	}
	type em struct {
		Name  string  `json:"name"`
		Level float64 `json:"level"`
		Why   string  `json:"why"`
	}
	var ems []em
	for _, e := range s.Emotions(af) {
		ems = append(ems, em{e.Name, e.Level, e.Why})
	}
	var lessons []any
	if p.Learn != nil {
		for _, l := range p.Learn.Lessons() {
			lessons = append(lessons, l)
		}
	}
	var motor any
	if p.Life != nil {
		motor = p.Life.View(-1)
	}
	writeJSON(w, map[string]any{"motor": motor, "lessons": lessons, "home": p.Cfg().WorldStayHome, "emotions": ems, "sensors": s.Sensors, "attended": att, "surprise": s.Surprise(), "report": s.Report("")})
}
