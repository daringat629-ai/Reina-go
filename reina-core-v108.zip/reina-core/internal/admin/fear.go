package admin

import (
	"net/http"

	"orvi/internal/fear"
)

// fearAPI shows her fears for the "Сны" tab. Nothing is hidden: she knows the owner can read them.
func (p *Panel) fearAPI(w http.ResponseWriter, r *http.Request) {
	if p.Fear == nil {
		fail(w, http.StatusNotFound, "страх выключен")
		return
	}
	s := p.Fear.Snapshot()
	writeJSON(w, map[string]any{"level": s.Level, "of": s.Of, "word": fear.Word(s.Level), "items": s.Items})
}
