package admin

import (
	"encoding/json"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"orvi/internal/allow"
	"orvi/internal/config"
	"orvi/internal/ignore"
	"orvi/internal/sched"
)

type actCtl struct{ ctl }

func (actCtl) Actions(q string, n int) any {
	return []map[string]any{{"tool": "shell", "what": "ls " + q, "ok": true, "limit": n}}
}

func TestControlTabEditsIgnoreAllowAndSchedules(t *testing.T) {
	p, mux, _, cp := rig(t)
	dir := t.TempDir()
	p.Ignore = ignore.New(filepath.Join(dir, "i.json"))
	p.Allow = allow.New(filepath.Join(dir, "a.json"))
	p.Sched = sched.New(filepath.Join(dir, "s.json"), time.UTC)
	if _, err := p.Sched.AddEvery(100, "ping", time.Hour, time.Now()); err != nil {
		t.Fatal(err)
	}
	if _, err := p.Sched.AddMonitor(sched.Monitor{Chat: 100, Kind: "disk_free_pct", Limit: 10, EveryMin: 5, CooldownMin: 30}, time.Now()); err != nil {
		t.Fatal(err)
	}
	config.SetKey(cp, "capabilities", "share_dirs", "/mnt")
	config.SetKey(cp, "telegram", "command_users", "42, 43")
	config.SetKey(cp, "general", "papik_chat_id", "100")
	h, _ := config.NewHolder(cp)
	p.Cfg = h.Get

	get := func() map[string]any {
		w := do(mux, "GET", "/admin/api/control", "", auth)
		if w.Code != 200 {
			t.Fatalf("%d %s", w.Code, w.Body)
		}
		var out map[string]any
		json.Unmarshal(w.Body.Bytes(), &out)
		return out
	}
	post := func(body string) (int, string) {
		w := do(mux, "POST", "/admin/api/control", body, auth)
		return w.Code, w.Body.String()
	}
	o := get()
	if len(o["tasks"].([]any)) != 1 || len(o["monitors"].([]any)) != 1 || o["share_dirs"] != "/mnt" || len(o["config_allow"].([]any)) != 2 || len(o["ignore"].([]any)) != 0 {
		t.Fatalf("%v", o)
	}

	// ignore: add (a chat by a negative id, for 2 hours), the owner is refused, remove
	if c, b := post(`{"op":"ignore_add","id":-77,"name":"Noise","hours":2,"note":"flood"}`); c != 200 {
		t.Fatal(c, b)
	}
	if !p.Ignore.Chat(-77) {
		t.Fatal("chat not ignored")
	}
	es := p.Ignore.List()
	if len(es) != 1 || es[0].Kind != "chat" || time.Until(es[0].Until) < time.Hour {
		t.Fatalf("%+v", es)
	}
	if c, b := post(`{"op":"ignore_add","id":100}`); c != 400 || !strings.Contains(b, "игнорировать нельзя") {
		t.Fatal(c, b)
	}
	if c, _ := post(`{"op":"ignore_remove","kind":"chat","id":-77}`); c != 200 || p.Ignore.Chat(-77) {
		t.Fatal("not removed")
	}
	if c, _ := post(`{"op":"ignore_remove","kind":"chat","id":-77}`); c != 400 {
		t.Fatal("removing twice must fail")
	}

	// white list: add, remove, a config.toml id has to be removed by hand
	if c, b := post(`{"op":"allow_add","id":7,"name":"Vasya"}`); c != 200 || !p.Allow.Has(7) {
		t.Fatal(c, b)
	}
	if c, _ := post(`{"op":"allow_add","id":-7}`); c != 400 {
		t.Fatal("a negative id accepted")
	}
	if c, b := post(`{"op":"allow_remove","id":42}`); c != 400 || !strings.Contains(b, "config.toml") {
		t.Fatal(c, b)
	}
	if c, _ := post(`{"op":"allow_remove","id":7}`); c != 200 || p.Allow.Has(7) {
		t.Fatal("not removed")
	}

	// tasks and monitors
	id := int(get()["tasks"].([]any)[0].(map[string]any)["id"].(float64))
	if c, _ := post(`{"op":"task_pause","id":` + itoa(int64(id)) + `,"paused":true}`); c != 200 || !p.Sched.Tasks()[0].Paused {
		t.Fatal("not paused")
	}
	if c, _ := post(`{"op":"task_delete","id":` + itoa(int64(id)) + `}`); c != 200 || len(p.Sched.Tasks()) != 0 {
		t.Fatal("not deleted")
	}
	mid := int(get()["monitors"].([]any)[0].(map[string]any)["id"].(float64))
	if c, _ := post(`{"op":"monitor_delete","id":` + itoa(int64(mid)) + `}`); c != 200 || len(p.Sched.Monitors()) != 0 {
		t.Fatal("monitor not deleted")
	}
	if c, _ := post(`{"op":"nonsense"}`); c != 400 {
		t.Fatal("unknown op accepted")
	}
	// the write needs the header
	if w := do(mux, "POST", "/admin/api/control", `{"op":"allow_add","id":9}`, map[string]string{"Authorization": "Bearer " + tok}); w.Code != 403 {
		t.Fatalf("%d", w.Code)
	}
}

func TestControlTabWorksWithNothingConnected(t *testing.T) {
	_, mux, _, _ := rig(t)
	w := do(mux, "GET", "/admin/api/control", "", auth)
	if w.Code != 200 || !strings.Contains(w.Body.String(), `"ignore":[]`) || !strings.Contains(w.Body.String(), `"tasks":[]`) {
		t.Fatalf("%d %s", w.Code, w.Body)
	}
	if c := do(mux, "POST", "/admin/api/control", `{"op":"ignore_add","id":5}`, auth).Code; c != 400 {
		t.Fatalf("%d", c)
	}
	if w := do(mux, "GET", "/admin/api/actions", "", auth); w.Code != 200 || !strings.Contains(w.Body.String(), `"actions":[]`) {
		t.Fatalf("%d %s", w.Code, w.Body)
	}
}

func TestActionsEndpointSearches(t *testing.T) {
	p, mux, _, _ := rig(t)
	p.Ctl = &actCtl{}
	w := do(mux, "GET", "/admin/api/actions?q=%20mnt%20&limit=5", "", auth)
	if w.Code != 200 || !strings.Contains(w.Body.String(), `"what":"ls mnt"`) || !strings.Contains(w.Body.String(), `"limit":5`) {
		t.Fatalf("%d %s", w.Code, w.Body)
	}
}

func TestPanelPageHasTheControlTab(t *testing.T) {
	if !strings.Contains(string(page), `["control","Контроль"]`) || !strings.Contains(string(page), "async control(m)") {
		t.Fatal("the tab is missing from the page")
	}
}
