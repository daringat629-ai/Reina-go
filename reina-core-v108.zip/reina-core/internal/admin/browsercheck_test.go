//go:build browsercheck

package admin

import (
	"net/http"
	"orvi/internal/cortex"
	"os"
	"testing"
	"time"
)

// go test -tags browsercheck -run TestServePanelForBrowser ./internal/admin  (serves the panel for a manual/automated look)
func TestServePanelForBrowser(t *testing.T) {
	p, mux, _, _ := rig(t)
	p.Cortex = cortex.New("", 50000, 3)
	p.Cortex.Step(cortex.Inputs{Hour: 12, Channels: map[string]float64{"threat": .5}})
	p.Machine = func() (any, bool) {
		return map[string]any{"load": .4, "free_capacity": .6, "prediction_error": .3, "goal_conflict": .2, "memory_pressure": .5, "coherence": .8, "update_urge": .3, "withdrawal": .2, "threat": .1, "reward": .7}, true
	}
	srv := &http.Server{Addr: "127.0.0.1:18765", Handler: mux}
	go srv.ListenAndServe()
	_ = os.WriteFile(os.Getenv("PANEL_READY"), []byte("ok"), 0o644)
	time.Sleep(90 * time.Second)
	srv.Close()
}
