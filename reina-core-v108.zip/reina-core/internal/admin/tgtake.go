package admin

import (
	"encoding/json"
	"errors"
	"net/http"
	"strconv"
	"strings"
	"sync"
	"time"

	"orvi/internal/live"
	"orvi/internal/telegram"
)

// Take-over mode: the owner uses her account from the panel's Telegram window. Everything here acts AS HER, so it is off unless
// misc.panel_takeover is true, every call must say "confirm": true (the window asks first) and the rate is limited.
// She is told in her next turn what he did, so she does not think she wrote it herself.

// OwnerNoter is implemented by a Controller that can tell her about the owner's actions in her chats.
type OwnerNoter interface {
	NoteOwnerAction(chatID int64, text string)
}

var takeLimit = struct {
	sync.Mutex
	at []time.Time
}{}

func takeAllowed() bool {
	takeLimit.Lock()
	defer takeLimit.Unlock()
	now := time.Now()
	keep := takeLimit.at[:0]
	for _, t := range takeLimit.at {
		if now.Sub(t) < time.Minute {
			keep = append(keep, t)
		}
	}
	takeLimit.at = keep
	if len(keep) >= 40 {
		return false
	}
	takeLimit.at = append(takeLimit.at, now)
	return true
}

type takeReq struct {
	Chat     int64  `json:"chat"`
	Msg      int64  `json:"msg"`
	Text     string `json:"text"`
	ReplyTo  int64  `json:"reply_to"`
	Emoji    string `json:"emoji"`
	Data     string `json:"data"`
	Options  []int  `json:"options"`
	Markdown bool   `json:"markdown"`
	Silent   bool   `json:"silent"`
	At       string `json:"at"`
	Muted    bool   `json:"muted"`
	Pin      bool   `json:"pin"`
	Confirm  bool   `json:"confirm"`
}

// takeover wraps a take-over action: method, switches, confirmation, rate.
func (p *Panel) takeover(act string, h func(_ http.ResponseWriter, r *http.Request, q takeReq, res map[string]any) (string, error)) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			fail(w, http.StatusMethodNotAllowed, "POST only")
			return
		}
		if !p.tgOn(w) {
			return
		}
		if !p.Cfg().PanelTakeover {
			fail(w, http.StatusForbidden, "take-over mode is off (misc.panel_takeover)")
			return
		}
		var q takeReq
		if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 1<<20)).Decode(&q); err != nil {
			fail(w, http.StatusBadRequest, "bad json")
			return
		}
		if !q.Confirm {
			fail(w, http.StatusBadRequest, "this acts as her account: confirm must be true")
			return
		}
		if q.Chat == 0 {
			fail(w, http.StatusBadRequest, "chat?")
			return
		}
		if !takeAllowed() {
			fail(w, http.StatusTooManyRequests, "too many actions per minute")
			return
		}
		res := map[string]any{"ok": true}
		note, err := h(w, r, q, res)
		if err != nil {
			fail(w, http.StatusBadGateway, err.Error())
			return
		}
		if note != "" {
			if p.Feed != nil {
				title := ""
				if c, err := p.TG.Chat(r.Context(), q.Chat); err == nil {
					title = c.Title
				}
				p.Feed.AddEvent(live.Event{Kind: "owner", Chat: title, ChatID: q.Chat, MsgID: q.Msg, Act: act, Text: "папик из панели: " + note})
			}
			if n, ok := p.Ctl.(OwnerNoter); ok {
				n.NoteOwnerAction(q.Chat, note)
			}
		}
		writeJSON(w, res)
	}
}

func short(s string) string {
	s = strings.Join(strings.Fields(s), " ")
	if r := []rune(s); len(r) > 160 {
		return string(r[:160]) + "…"
	}
	return s
}

func (p *Panel) mountTakeover(api func(string, http.HandlerFunc)) {
	api("tg/send", p.takeover("send", func(_ http.ResponseWriter, r *http.Request, q takeReq, res map[string]any) (string, error) {
		if strings.TrimSpace(q.Text) == "" {
			return "", errors.New("empty text")
		}
		ctx := telegram.NoThread(r.Context())
		if rich, ok := p.TG.(telegram.Rich); ok {
			var at time.Time
			if q.At != "" {
				t, err := time.Parse(time.RFC3339, q.At)
				if err != nil {
					return "", errors.New("at: RFC3339")
				}
				at = t
			}
			if _, err := rich.SendWith(ctx, q.Chat, q.Text, telegram.SendOptions{ReplyTo: q.ReplyTo, Silent: q.Silent, Markdown: q.Markdown, At: at}); err != nil {
				return "", err
			}
		} else if _, err := p.TG.SendText(ctx, q.Chat, q.Text, q.ReplyTo); err != nil {
			return "", err
		}
		return "написал от её имени: «" + short(q.Text) + "»", nil
	}))
	api("tg/edit", p.takeover("edit", func(_ http.ResponseWriter, r *http.Request, q takeReq, res map[string]any) (string, error) {
		if strings.TrimSpace(q.Text) == "" || q.Msg == 0 {
			return "", errors.New("msg and text?")
		}
		var err error
		if rich, ok := p.TG.(telegram.Rich); ok {
			err = rich.EditFormatted(r.Context(), q.Chat, q.Msg, q.Text, q.Markdown)
		} else {
			err = p.TG.Edit(r.Context(), q.Chat, q.Msg, q.Text)
		}
		return "исправил её сообщение #" + itoa(q.Msg) + ": «" + short(q.Text) + "»", err
	}))
	api("tg/delete", p.takeover("delete", func(_ http.ResponseWriter, r *http.Request, q takeReq, res map[string]any) (string, error) {
		if q.Msg == 0 {
			return "", errors.New("msg?")
		}
		return "удалил сообщение #" + itoa(q.Msg), p.TG.Delete(r.Context(), q.Chat, q.Msg)
	}))
	api("tg/react", p.takeover("react", func(_ http.ResponseWriter, r *http.Request, q takeReq, res map[string]any) (string, error) {
		if q.Msg == 0 || strings.TrimSpace(q.Emoji) == "" {
			return "", errors.New("msg and emoji?")
		}
		return "поставил " + q.Emoji + " на сообщение #" + itoa(q.Msg), p.TG.React(r.Context(), q.Chat, q.Msg, q.Emoji)
	}))
	api("tg/press", p.takeover("press", func(_ http.ResponseWriter, r *http.Request, q takeReq, res map[string]any) (string, error) {
		rich, ok := p.TG.(telegram.Rich)
		if !ok || q.Msg == 0 {
			return "", errors.New("buttons need the user account and msg")
		}
		ans, err := rich.PressButton(r.Context(), q.Chat, q.Msg, q.Data)
		if err != nil {
			return "", err
		}
		res["answer"], res["alert"], res["url"] = ans.Text, ans.Alert, ans.URL
		return "нажал кнопку под сообщением #" + itoa(q.Msg), nil
	}))
	api("tg/pin", p.takeover("pin", func(_ http.ResponseWriter, r *http.Request, q takeReq, res map[string]any) (string, error) {
		if q.Msg == 0 {
			return "", errors.New("msg?")
		}
		if q.Pin {
			return "закрепил сообщение #" + itoa(q.Msg), p.TG.Pin(r.Context(), q.Chat, q.Msg, q.Silent)
		}
		return "открепил сообщение #" + itoa(q.Msg), p.TG.Unpin(r.Context(), q.Chat, q.Msg)
	}))
	api("tg/vote", p.takeover("vote", func(_ http.ResponseWriter, r *http.Request, q takeReq, res map[string]any) (string, error) {
		if q.Msg == 0 {
			return "", errors.New("msg?")
		}
		return "проголосовал в опросе #" + itoa(q.Msg), p.TG.VotePoll(r.Context(), q.Chat, q.Msg, q.Options)
	}))
	api("tg/read", p.takeover("read", func(_ http.ResponseWriter, r *http.Request, q takeReq, res map[string]any) (string, error) {
		return "", p.TG.MarkRead(r.Context(), q.Chat)
	}))
	api("tg/mute", p.takeover("mute", func(_ http.ResponseWriter, r *http.Request, q takeReq, res map[string]any) (string, error) {
		rich, ok := p.TG.(telegram.Rich)
		if !ok {
			return "", errors.New("needs the user account")
		}
		what := "включил звук в чате"
		if q.Muted {
			what = "выключил звук в чате"
		}
		return what, rich.SetMuted(r.Context(), q.Chat, q.Muted)
	}))
}

func itoa(n int64) string { return strconv.FormatInt(n, 10) }
