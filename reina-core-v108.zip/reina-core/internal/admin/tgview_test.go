package admin

import (
	"bytes"
	"context"
	"encoding/json"
	"image"
	"image/png"
	"strings"
	"testing"
	"time"

	"orvi/internal/config"
	"orvi/internal/telegram"
)

func TestTelegramViewIsReadOnlyGuardedAndShowsEverything(t *testing.T) {
	p, mux, _, cp := rig(t)
	for _, path := range []string{"tg/chats", "tg/history?id=1", "tg/media?chat=1&msg=1", "tg/avatar?id=1"} {
		if w := do(mux, "GET", "/admin/api/"+path, "", nil); w.Code != 401 {
			t.Fatalf("%s without login: %d", path, w.Code)
		}
		if w := do(mux, "GET", "/admin/api/"+path, "", auth); w.Code != 404 {
			t.Fatalf("%s without a Telegram client must be 404, got %d", path, w.Code)
		}
	}
	fk := telegram.NewFake()
	var pb bytes.Buffer
	png.Encode(&pb, image.NewRGBA(image.Rect(0, 0, 4, 4)))
	fk.Files = map[string][]byte{"ph": pb.Bytes(), "doc": []byte("<script>alert(1)</script>")}
	chat := telegram.Chat{ID: 7, Title: "Алина", Kind: telegram.ChatPrivate, IsMember: true, Unread: 2}
	now := time.Now()
	fk.S.Put(telegram.Message{ID: 1, ChatID: 7, SenderID: 7, SenderName: "Алина", Date: now, Text: "привет"}, &chat)
	fk.S.Put(telegram.Message{ID: 2, ChatID: 7, SenderName: "Рейна", Date: now, Outgoing: true, Text: "ну", Reactions: []string{"🔥"}, ReplyTo: 1, Media: telegram.MediaPhoto, FileID: "ph", Edited: true}, &chat)
	fk.S.Put(telegram.Message{ID: 3, ChatID: 7, SenderName: "Рейна", Date: now, Outgoing: true, Media: telegram.MediaDocument, FileID: "doc", FileName: "a.html", FileSize: 25}, &chat)
	p.TG = fk
	before, _ := fk.Unread(context.Background(), 7)

	var cs struct {
		Chats []tgChat `json:"chats"`
	}
	w := do(mux, "GET", "/admin/api/tg/chats", "", auth)
	if err := json.Unmarshal(w.Body.Bytes(), &cs); err != nil || len(cs.Chats) != 1 || cs.Chats[0].Title != "Алина" || cs.Chats[0].Unread == 0 {
		t.Fatalf("chats: %d %s", w.Code, w.Body.String())
	}
	var hs struct {
		Messages []tgMsg `json:"messages"`
	}
	w = do(mux, "GET", "/admin/api/tg/history?id=7&n=20", "", auth)
	if err := json.Unmarshal(w.Body.Bytes(), &hs); err != nil || len(hs.Messages) != 3 {
		t.Fatalf("history: %d %s", w.Code, w.Body.String())
	}
	m2 := hs.Messages[1]
	if !m2.Out || !m2.Photo || m2.ReplyTo != 1 || !m2.Edited || len(m2.Reactions) != 1 || hs.Messages[2].FileName != "a.html" || hs.Messages[2].Photo {
		t.Fatalf("message not shown completely: %+v", hs.Messages)
	}
	if w := do(mux, "GET", "/admin/api/tg/history?id=x", "", auth); w.Code != 400 {
		t.Fatalf("bad id: %d", w.Code)
	}
	// reading never marks anything read
	if u, _ := fk.Unread(context.Background(), 7); len(u) != len(before) || len(before) == 0 {
		t.Fatalf("the view must not mark messages read: %d -> %d unread", len(before), len(u))
	}
	// a photo is served as an image; anything else is refused, even when someone sends html as a "photo"
	if w := do(mux, "GET", "/admin/api/tg/media?chat=7&msg=2", "", auth); w.Code != 200 || w.Header().Get("Content-Type") != "image/png" || w.Header().Get("X-Content-Type-Options") != "nosniff" {
		t.Fatalf("photo: %d %v", w.Code, w.Header())
	}
	if w := do(mux, "GET", "/admin/api/tg/media?chat=7&msg=3", "", auth); w.Code != 404 {
		t.Fatalf("a document is not served as media: %d", w.Code)
	}
	fk.S.Put(telegram.Message{ID: 4, ChatID: 7, Date: now, Media: telegram.MediaPhoto, FileID: "doc"}, &chat)
	if w := do(mux, "GET", "/admin/api/tg/media?chat=7&msg=4", "", auth); w.Code != http415() {
		t.Fatalf("html pretending to be a photo must be refused: %d", w.Code)
	}
	if w := do(mux, "GET", "/admin/api/tg/avatar?id=7", "", auth); w.Code != 404 {
		t.Fatalf("no avatar: %d", w.Code)
	}
	// the owner can switch the view off: other people's private messages stay out of the panel
	if err := config.SetKey(cp, "misc", "panel_chats", "false"); err != nil {
		t.Fatal(err)
	}
	h, _ := config.NewHolder(cp)
	p.Cfg = h.Get
	if w := do(mux, "GET", "/admin/api/tg/chats", "", auth); w.Code != 404 || !strings.Contains(w.Body.String(), "panel_chats") {
		t.Fatalf("switched off: %d %s", w.Code, w.Body.String())
	}
}

func http415() int { return 415 }
