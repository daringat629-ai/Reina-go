package admin

import (
	"net/http"
	"slices"
	"strconv"
	"strings"
	"time"

	"orvi/internal/allow"
	"orvi/internal/ignore"
	"orvi/internal/sched"
)

// ActionSource is implemented by a Controller that keeps her action journal.
type ActionSource interface {
	Actions(query string, limit int) any
}

// controlAPI is the "Контроль" tab: whom she ignores, who may use her commands, her schedules and monitors.
// GET returns everything; POST {op: ...} changes one thing and returns the same overview.
func (p *Panel) controlAPI(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		var in struct {
			Op     string  `json:"op"`
			Kind   string  `json:"kind"`
			ID     int64   `json:"id"`
			Hours  float64 `json:"hours"`
			Name   string  `json:"name"`
			Note   string  `json:"note"`
			Paused bool    `json:"paused"`
		}
		if err := readBody(r, &in); err != nil {
			fail(w, 400, "не разобрал запрос")
			return
		}
		if msg := p.controlOp(in.Op, in.Kind, in.ID, in.Hours, in.Name, in.Note, in.Paused); msg != "" {
			fail(w, 400, msg)
			return
		}
	}
	c := p.Cfg()
	out := map[string]any{
		"ignore":       []ignore.Entry{},
		"allow":        []allow.Entry{},
		"config_allow": []int64{},
		"tasks":        []sched.Task{},
		"monitors":     []sched.Monitor{},
		"share_dirs":   c.ShareDirs,
		"owner":        c.PapikChatID,
		"have":         map[string]bool{"ignore": p.Ignore != nil, "allow": p.Allow != nil, "sched": p.Sched != nil},
	}
	if p.Ignore != nil {
		if es := p.Ignore.List(); es != nil {
			out["ignore"] = es
		}
	}
	if p.Allow != nil {
		if es := p.Allow.List(); es != nil {
			out["allow"] = es
		}
	}
	if ids := allow.ParseIDs(c.CommandUsers); ids != nil {
		out["config_allow"] = ids
	}
	if p.Sched != nil {
		if ts := p.Sched.Tasks(); ts != nil {
			out["tasks"] = ts
		}
		if ms := p.Sched.Monitors(); ms != nil {
			out["monitors"] = ms
		}
		out["zone"] = p.Sched.Loc().String()
	}
	writeJSON(w, out)
}

// controlOp applies one change; a non-empty result is the error to show.
func (p *Panel) controlOp(op, kind string, id int64, hours float64, name, note string, paused bool) string {
	switch op {
	case "ignore_add":
		if p.Ignore == nil {
			return "список игнора выключен"
		}
		if kind != "chat" && kind != "user" {
			kind = "user"
			if id < 0 {
				kind = "chat"
			}
		}
		if id == 0 {
			return "нужен id"
		}
		if o := p.Cfg().PapikChatID; o != 0 && id == o {
			return "тебя игнорировать нельзя"
		}
		var d time.Duration
		if hours > 0 {
			d = time.Duration(hours * float64(time.Hour))
		}
		p.Ignore.Add(kind, id, name, note, d)
	case "ignore_remove":
		if p.Ignore == nil || !p.Ignore.Remove(kind, id) {
			return "этого нет в списке"
		}
	case "allow_add":
		if p.Allow == nil {
			return "белый список выключен"
		}
		if id <= 0 {
			return "нужен id человека (положительный)"
		}
		p.Allow.Add(id, name)
	case "allow_remove":
		if p.Allow == nil || !p.Allow.Remove(id) {
			if slices.Contains(allow.ParseIDs(p.Cfg().CommandUsers), id) {
				return "этот id записан в config.toml (telegram.command_users), убери его там"
			}
			return "этого нет в списке"
		}
	case "task_pause":
		if p.Sched == nil || !p.Sched.SetPaused(int(id), paused, time.Now()) {
			return "задачи нет"
		}
	case "task_delete":
		if p.Sched == nil || !p.Sched.DeleteTask(int(id)) {
			return "задачи нет"
		}
	case "monitor_delete":
		if p.Sched == nil || !p.Sched.DeleteMonitor(int(id)) {
			return "монитора нет"
		}
	default:
		return "неизвестное действие"
	}
	return ""
}

// actionsAPI searches her action journal: ?q=words&limit=N.
func (p *Panel) actionsAPI(w http.ResponseWriter, r *http.Request) {
	src, ok := p.Ctl.(ActionSource)
	if !ok {
		writeJSON(w, map[string]any{"actions": []any{}})
		return
	}
	limit, _ := strconv.Atoi(r.URL.Query().Get("limit"))
	writeJSON(w, map[string]any{"actions": src.Actions(strings.TrimSpace(r.URL.Query().Get("q")), limit)})
}
