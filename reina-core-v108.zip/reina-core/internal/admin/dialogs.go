package admin

import (
	"context"
	"net/http"
	"strconv"
	"strings"
	"time"

	"orvi/internal/people"
)

// DialogSource is implemented by a Controller that can show her open conversations.
type DialogSource interface {
	DialogList() any
	DialogMessages(id int64) (any, error)
}

// GET /admin/api/dialogs lists her open sessions; ?id=N returns what is in one of them.
func (p *Panel) dialogsAPI(w http.ResponseWriter, r *http.Request) {
	src, ok := p.Ctl.(DialogSource)
	if !ok {
		fail(w, 400, "диалоги недоступны (Telegram выключен)")
		return
	}
	if q := r.URL.Query().Get("id"); q != "" {
		id, err := strconv.ParseInt(q, 10, 64)
		if err != nil {
			fail(w, 400, "bad id")
			return
		}
		msgs, err := src.DialogMessages(id)
		if err != nil {
			fail(w, 409, err.Error())
			return
		}
		writeJSON(w, map[string]any{"messages": msgs})
		return
	}
	writeJSON(w, map[string]any{"dialogs": src.DialogList()})
}

// /admin/api/people: GET lists the cards; POST {id, name, facts:[{text, private}]} replaces one (no facts = delete).
// PersonDescriber is implemented by a Controller that can make her write a description of a person.
type PersonDescriber interface {
	DescribePerson(ctx context.Context, id int64) (people.Card, error)
}

func (p *Panel) peopleAPI(w http.ResponseWriter, r *http.Request) {
	if p.People == nil {
		fail(w, 400, "карточки людей недоступны")
		return
	}
	if r.Method == http.MethodPost {
		var in struct {
			ID       int64         `json:"id"`
			Name     string        `json:"name"`
			Facts    []people.Fact `json:"facts"`
			About    *string       `json:"about"`
			Describe bool          `json:"describe"`
		}
		if err := readBody(r, &in); err != nil || in.ID == 0 {
			fail(w, 400, "нужен id человека")
			return
		}
		switch {
		case in.Describe:
			d, ok := p.Ctl.(PersonDescriber)
			if !ok {
				fail(w, 400, "описывать некому: Telegram выключен")
				return
			}
			if _, err := d.DescribePerson(r.Context(), in.ID); err != nil {
				fail(w, 400, err.Error())
				return
			}
		default:
			if in.Facts != nil {
				if err := p.People.Replace(in.ID, in.Name, in.Facts); err != nil {
					fail(w, 500, err.Error())
					return
				}
			}
			if in.About != nil {
				if err := p.People.SetAbout(in.ID, in.Name, *in.About, time.Now()); err != nil {
					fail(w, 500, err.Error())
					return
				}
			}
		}
	}
	cards := p.People.All()
	if cards == nil {
		cards = []people.Card{}
	}
	p.fillProfiles(r.Context(), cards)
	_, canDescribe := p.Ctl.(PersonDescriber)
	writeJSON(w, map[string]any{"cards": cards, "can_describe": canDescribe && p.TG != nil})
}

// fillProfiles asks Telegram for the @username and bio of cards that have none yet (a few per request, short wait) and
// files them on the cards, so the panel shows a real profile.
func (p *Panel) fillProfiles(ctx context.Context, cards []people.Card) {
	if p.TG == nil {
		return
	}
	ctx, cancel := context.WithTimeout(ctx, 4*time.Second)
	defer cancel()
	asked := 0
	for i := range cards {
		c := &cards[i]
		if c.Username != "" || c.Bio != "" || asked >= 8 || ctx.Err() != nil {
			continue
		}
		asked++
		if u, err := p.TG.UserInfo(ctx, c.ID); err == nil && (u.Username != "" || u.Bio != "") {
			c.Username, c.Bio = strings.TrimPrefix(u.Username, "@"), u.Bio
			_ = p.People.SetProfile(c.ID, u.Username, u.Bio)
		}
	}
}
