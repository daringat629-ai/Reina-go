// Package admin is the password-protected web panel at /admin: status, live log, pause/resume,
// settings, prompts, memory and the log of shell commands. It is a single embedded page plus a small JSON API.
package admin

import (
	"context"
	"crypto/sha256"
	"crypto/subtle"
	"embed"
	"encoding/json"
	"net"
	"net/http"
	"orvi/internal/billing"
	"orvi/internal/fear"
	"orvi/internal/keepsakes"
	"orvi/internal/letters"
	"os"
	"path/filepath"
	"slices"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"orvi/internal/allow"
	"orvi/internal/autonomy"
	"orvi/internal/body"
	"orvi/internal/brain"
	"orvi/internal/config"
	"orvi/internal/cortex"
	"orvi/internal/diary"
	"orvi/internal/feel"
	"orvi/internal/ideas"
	"orvi/internal/ignore"
	"orvi/internal/learn"
	"orvi/internal/life"
	"orvi/internal/live"
	"orvi/internal/maint"
	"orvi/internal/memory"
	"orvi/internal/metrics"
	"orvi/internal/mind"
	"orvi/internal/mood"
	"orvi/internal/people"
	"orvi/internal/physics"
	"orvi/internal/prompts"
	"orvi/internal/sched"
	"orvi/internal/sense"
	"orvi/internal/telegram"
	"orvi/internal/usage"
	"orvi/internal/util"
)

//go:embed icons/*.png
var iconFS embed.FS

//go:embed page.html
var page []byte

// ControlReq is one action of the owner on her desktop: op is move, click, drag, scroll, type or key.
type ControlReq struct {
	Op     string `json:"op"`
	X      int    `json:"x"`
	Y      int    `json:"y"`
	X2     int    `json:"x2"`
	Y2     int    `json:"y2"`
	Button int    `json:"button"`
	N      int    `json:"n"`
	Down   bool   `json:"down"`
	Text   string `json:"text"`
	Key    string `json:"key"`
}

// Controller is what the panel needs from the agent.
type Controller interface {
	Paused() bool
	SetPaused(bool)
	SessionSummaries() []string
}

// QueueSource is implemented by a Controller that can describe her queue and the Telegram connection.
type QueueSource interface{ QueueInfo() any }

type Panel struct {
	Cfg        func() *config.Config
	ConfigPath string
	Prompts    *prompts.Store
	Diary      *diary.Diary
	Metrics    *metrics.Registry
	Log        *util.LogBuf
	Mood       *mood.Mood         // nil when the scale is not available
	Brain      *brain.Brain       // nil = no 3D brain view
	Auto       *autonomy.State    // nil when autonomy is not available
	Usage      *usage.Tracker     // nil when not tracked
	People     *people.Store      // nil when person cards are off
	Ignore     *ignore.Store      // nil = the ignore list is off
	Body       *body.Body         // her body (nil = off)
	Feel       *feel.Feel         // her feelings (nil = off)
	Sense      *sense.Sense       // her sensorium (nil = off)
	Learn      *learn.Store       // what she has studied (nil = off)
	Life       *life.Life         // her room, movements and will (nil = off)
	Cortex     *cortex.Cortex     // her region brain (nil = off)
	Machine    func() (any, bool) // the machine state the agent computed last (nil = no machine mode)
	Mind       *mind.Mind         // her own mind (nil = off)
	Presence   *physics.Presence  // where she is: her room or the city (reported by her world page)
	Ideas      *ideas.Store       // her box of wild ideas (nil = off)
	Letters    *letters.Store     // her letters to herself (nil = off)
	Keepsakes  *keepsakes.Store   // her keepsake box (nil = off)
	Fear       *fear.Fear         // her fears (nil = off)
	Billing    *billing.Store     // plans and payments of other people (nil = off)
	Allow      *allow.Store       // nil = the command white list is off
	Sched      *sched.Store       // nil = no schedules and monitors
	Ctl        Controller         // nil when Telegram is off
	Started    time.Time
	UpdateDir  string                                                                                                     // where the program lives (empty = next to the running binary); tests set a temp dir
	Restart    func()                                                                                                     // restarts the program after an update (nil = update.RequestRestart)
	Compare    func(ctx context.Context, model, phrase string) (string, error)                                            // nil = the Models tab is off
	Talk       func(ctx context.Context, audio []byte, mime string) (TalkResult, error)                                   // one turn of the live voice call (nil = the call button is hidden)
	Clean      func() string                                                                                              // frees disk space and says what it freed (nil = the button is hidden)
	Stream     func(ctx context.Context, src string, prev uint64) (data []byte, hash uint64, changed, ok bool, err error) // the same for a continuous stream (unchanged pictures come back without data)
	Pointer    func(src string) string                                                                                    // "x,y" of the desktop pointer
	Frame      func(ctx context.Context, src string) (data []byte, meta string, ok bool, err error)                       // live picture of "desktop" or "browser" (nil = no live view)
	Control    func(src string, c ControlReq) error                                                                       // the owner's mouse and keyboard on her desktop (nil = control is off)
	Screens    func() (browser, desktop bool)                                                                             // which screens are up
	TG         telegram.Client                                                                                            // the account, for the read-only Telegram view (nil = off)
	Feed       *live.Feed                                                                                                 // what she is doing now (nil = no feed)

	mu    sync.Mutex
	fails map[string][]time.Time
}

const cookieName = "reina_admin"

// panelCSP: the page is one file with inline script and style; everything it loads comes from the panel itself.
const panelCSP = "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; " +
	"media-src 'self' blob:; connect-src 'self'; frame-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'; object-src 'none'"

// MinTokenLen is the shortest accepted admin_token.
const MinTokenLen = 12

// Enabled reports whether the configured token is long enough to switch the panel on.
func Enabled(c *config.Config) bool { return len(c.AdminToken) >= MinTokenLen }

// Mount registers /admin and /admin/api/*.
func (p *Panel) Mount(mux *http.ServeMux) {
	p.fails = map[string][]time.Time{}
	mux.HandleFunc("/admin", p.index)
	mux.HandleFunc("/admin/qr", p.qrLogin)
	mux.HandleFunc("/admin/desk", p.desk)
	mux.HandleFunc("/admin/brain/", p.brainView)
	mux.HandleFunc("/admin/city/", p.cityView)
	mux.HandleFunc("/admin/body3d/", p.bodyView)
	mux.HandleFunc("/admin/manifest.webmanifest", p.manifest)
	mux.HandleFunc("/admin/icon-192.png", p.icon("icons/icon-192.png"))
	mux.HandleFunc("/admin/icon-512.png", p.icon("icons/icon-512.png"))
	mux.HandleFunc("/admin/apple-touch-icon.png", p.icon("icons/icon-180.png"))
	mux.HandleFunc("/admin/", p.index)
	api := func(path string, h http.HandlerFunc) { mux.HandleFunc("/admin/api/"+path, p.guard(gzipJSON(h))) }
	api("status", p.status)
	api("mood", p.moodAPI)
	api("autonomy", p.autonomyAPI)
	api("server", p.serverAPI)
	api("pause", p.pause)
	api("log", p.logTail)
	api("config", p.configAPI)
	api("prompts", p.promptsAPI)
	api("memory", p.memoryAPI)
	api("diary", p.diaryAPI)
	api("shell", p.shellLog)
	api("dialogs", p.dialogsAPI)
	api("people", p.peopleAPI)
	api("control", p.controlAPI)
	api("actions", p.actionsAPI)
	api("update", p.updateStatus)
	api("update/upload", p.updateUpload)
	api("update/apply", p.updateApply)
	api("update/rollback", p.updateRollback)
	api("cleanup", p.cleanupAPI)
	api("compare", p.compareAPI)
	api("live/frame", p.liveFrame)
	api("live/events", p.liveEvents)
	api("live/pointer", p.livePointer)
	api("live/control", p.liveControl)
	api("live/talk", p.liveTalk)
	api("ideas", p.ideasAPI)
	api("body", p.bodyAPI)
	api("mind", p.mindAPI)
	api("sense", p.senseAPI)
	api("net", p.netAPI)
	api("dreams", p.dreamsAPI)
	api("letters", p.lettersAPI)
	api("keepsakes", p.keepsakesAPI)
	api("fear", p.fearAPI)
	api("billing", p.billingAPI)
	mux.HandleFunc("/admin/api/live/stream", p.guard(p.liveStream)) // not gzipped: it never ends
	api("tg/chats", p.tgChats)
	api("tg/history", p.tgHistory)
	api("tg/media", p.tgMedia)
	api("tg/search", p.tgSearch)
	p.mountTakeover(api)
	api("tg/avatar", p.tgAvatar)
}

// --- auth ---------------------------------------------------------------

func clientIP(r *http.Request) string {
	h, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		return r.RemoteAddr
	}
	return h
}

func (p *Panel) blocked(ip string) bool {
	p.mu.Lock()
	defer p.mu.Unlock()
	cut := time.Now().Add(-10 * time.Minute)
	kept := p.fails[ip][:0]
	for _, t := range p.fails[ip] {
		if t.After(cut) {
			kept = append(kept, t)
		}
	}
	if len(kept) == 0 {
		delete(p.fails, ip) // every request passes here: do not keep an entry per visitor
		return false
	}
	p.fails[ip] = kept
	return len(kept) >= 8
}

func (p *Panel) fail(ip string) {
	p.mu.Lock()
	p.fails[ip] = append(p.fails[ip], time.Now())
	if len(p.fails) > 4096 { // many addresses (IPv6 makes them free): forget the ones with no recent failure
		cut := time.Now().Add(-10 * time.Minute)
		for k, ts := range p.fails {
			if len(ts) == 0 || ts[len(ts)-1].Before(cut) {
				delete(p.fails, k)
			}
		}
	}
	p.mu.Unlock()
	time.Sleep(400 * time.Millisecond) // slow brute force down
}

func same(a, b string) bool {
	ha, hb := sha256.Sum256([]byte(a)), sha256.Sum256([]byte(b))
	return subtle.ConstantTimeCompare(ha[:], hb[:]) == 1
}

// authed checks the bearer header or the cookie (never a query string, except on the index page).
func (p *Panel) authed(r *http.Request) bool {
	tok := p.Cfg().AdminToken
	if len(tok) < MinTokenLen {
		return false
	}
	if h := r.Header.Get("Authorization"); strings.HasPrefix(h, "Bearer ") && same(strings.TrimPrefix(h, "Bearer "), tok) {
		return true
	}
	if c, err := r.Cookie(cookieName); err == nil && same(c.Value, tok) {
		return true
	}
	return false
}

func (p *Panel) guard(h http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if !Enabled(p.Cfg()) {
			http.NotFound(w, r)
			return
		}
		ip := clientIP(r)
		if p.blocked(ip) {
			http.Error(w, "too many attempts, try later", http.StatusTooManyRequests)
			return
		}
		if !p.authed(r) {
			p.fail(ip)
			http.Error(w, "unauthorized", http.StatusUnauthorized)
			return
		}
		if r.Method != http.MethodGet && r.Header.Get("X-Admin") != "1" {
			http.Error(w, "missing X-Admin header", http.StatusForbidden)
			return
		}
		h(w, r)
	}
}

func (p *Panel) index(w http.ResponseWriter, r *http.Request) {
	if (r.URL.Path != "/admin" && r.URL.Path != "/admin/") || !Enabled(p.Cfg()) {
		http.NotFound(w, r)
		return
	}
	ip := clientIP(r)
	if t := r.URL.Query().Get("token"); t != "" {
		if p.blocked(ip) {
			http.Error(w, "too many attempts, try later", http.StatusTooManyRequests)
			return
		}
		if len(p.Cfg().AdminToken) >= MinTokenLen && same(t, p.Cfg().AdminToken) {
			http.SetCookie(w, &http.Cookie{Name: cookieName, Value: t, Path: "/admin", HttpOnly: true, SameSite: http.SameSiteStrictMode, MaxAge: 30 * 24 * 3600})
			http.Redirect(w, r, "/admin", http.StatusSeeOther)
			return
		}
		p.fail(ip)
	}
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("X-Frame-Options", "DENY")
	w.Header().Set("Referrer-Policy", "no-referrer")
	w.Header().Set("X-Content-Type-Options", "nosniff")
	// the page shows other people's messages: even if some text slipped past the DOM-only rendering, it could not
	// load a script from elsewhere, send data out or frame the panel
	w.Header().Set("Content-Security-Policy", panelCSP)
	if acceptsGzip(r) {
		w.Header().Set("Content-Encoding", "gzip")
		w.Header().Add("Vary", "Accept-Encoding")
		_, _ = w.Write(gzPage())
		return
	}
	_, _ = w.Write(page)
}

// --- helpers ------------------------------------------------------------

func writeJSON(w http.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	_ = json.NewEncoder(w).Encode(v)
}

func fail(w http.ResponseWriter, code int, msg string) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(map[string]string{"error": msg})
}

func readBody(r *http.Request, v any) error {
	r.Body = http.MaxBytesReader(nil, r.Body, 1<<20)
	return json.NewDecoder(r.Body).Decode(v)
}

// --- endpoints ----------------------------------------------------------

func (p *Panel) status(w http.ResponseWriter, r *http.Request) {
	c := p.Cfg()
	tokens := map[string]map[string]float64{}
	if p.Metrics != nil {
		for _, purpose := range []string{"reply", "ask", "compact", "diary", "sleep", "image", "delegate", "code", "other"} {
			var in, out, n, cached float64
			models := []string{c.LLMModel}
			if c.LightModel != "" && c.LightModel != c.LLMModel {
				models = append(models, c.LightModel)
			}
			if c.FastModel != "" && c.FastModel != c.LLMModel && c.FastModel != c.LightModel {
				models = append(models, c.FastModel)
			}
			if c.CodeModel != "" && c.CodeModel != c.LLMModel && c.CodeModel != c.LightModel && c.CodeModel != c.FastModel {
				models = append(models, c.CodeModel)
			}
			for _, extra := range []string{c.WorkModel, c.DeepModel} {
				if extra != "" && !slices.Contains(models, extra) {
					models = append(models, extra)
				}
			}
			for _, m := range models {
				in += p.Metrics.Get("reina_llm_tokens_total", map[string]string{"model": m, "purpose": purpose, "direction": "input"})
				out += p.Metrics.Get("reina_llm_tokens_total", map[string]string{"model": m, "purpose": purpose, "direction": "output"})
				n += p.Metrics.Get("reina_llm_calls_total", map[string]string{"model": m, "purpose": purpose})
				cached += p.Metrics.Get("reina_llm_cached_tokens_total", map[string]string{"model": m, "purpose": purpose})
			}
			if in > 0 || out > 0 {
				tokens[purpose] = map[string]float64{"in": in, "out": out, "n": n, "avg": avg(in, n), "cached": cached}
			}
		}
	}
	st := map[string]any{
		"character": c.CharacterName, "model": c.LLMModel, "light_model": c.LightModel, "fast_model": c.FastModel, "base_url": c.LLMBaseURL, "lockdown": c.Lockdown,
		"mode": c.Mode, "telegram": c.TelegramEnabled, "owner_tools": c.OwnerTools && c.PapikChatID != 0,
		"uptime_secs": int(time.Since(p.Started).Seconds()), "tokens": tokens, "paused": false, "sessions": []string{},
	}
	if p.Usage != nil {
		in, out := p.Usage.Today()
		u := map[string]any{"in": in, "out": out, "limit": c.DailyTokenLimit}
		if usd, ok := p.Usage.Cost(func(m string) usage.Prices {
			switch m {
			case c.LLMModel:
				return usage.Prices{In: c.PriceIn, Out: c.PriceOut}
			case c.LightModel:
				return usage.Prices{In: c.LightPriceIn, Out: c.LightPriceOut}
			case c.FastModel:
				return usage.Prices{In: c.FastPriceIn, Out: c.FastPriceOut}
			}
			return usage.Prices{}
		}); ok {
			u["usd"] = usd
		}
		st["usage"] = u
		st["days"] = p.Usage.Days(14, func(m string) usage.Prices {
			switch m {
			case c.LLMModel:
				return usage.Prices{In: c.PriceIn, Out: c.PriceOut}
			case c.LightModel:
				return usage.Prices{In: c.LightPriceIn, Out: c.LightPriceOut}
			case c.FastModel:
				return usage.Prices{In: c.FastPriceIn, Out: c.FastPriceOut}
			}
			return usage.Prices{}
		})
	}
	if p.Mood != nil && c.MoodEnabled {
		lvl := p.Mood.Level()
		st["mood"] = map[string]any{"level": lvl, "name": mood.Name(lvl)}
	}
	if p.Ctl != nil {
		st["paused"] = p.Ctl.Paused()
		s := p.Ctl.SessionSummaries()
		if s == nil {
			s = []string{} // JSON null would break the panel right after a restart, when no chat is open yet
		}
		sort.Strings(s)
		st["sessions"] = s
		if q, ok := p.Ctl.(QueueSource); ok {
			st["queue"] = q.QueueInfo()
		}
	}
	writeJSON(w, st)
}

func (p *Panel) pause(w http.ResponseWriter, r *http.Request) {
	if p.Ctl == nil {
		fail(w, 400, "Telegram выключен, паузить нечего")
		return
	}
	var in struct {
		Paused bool `json:"paused"`
	}
	if err := readBody(r, &in); err != nil {
		fail(w, 400, "bad json")
		return
	}
	p.Ctl.SetPaused(in.Paused)
	writeJSON(w, map[string]bool{"paused": p.Ctl.Paused()})
}

func (p *Panel) logTail(w http.ResponseWriter, r *http.Request) {
	lines := []string{}
	if p.Log != nil {
		lines = p.Log.Tail(300)
	}
	writeJSON(w, map[string]any{"lines": lines})
}

type keyView struct {
	Section string `json:"section"`
	Name    string `json:"name"`
	Comment string `json:"comment"`
	Kind    string `json:"kind"`
	Secret  bool   `json:"secret"`
	Value   string `json:"value"`
	Set     bool   `json:"set"`
}

func (p *Panel) configAPI(w http.ResponseWriter, r *http.Request) {
	switch r.Method {
	case http.MethodGet:
		c := p.Cfg()
		var out []keyView
		for _, k := range config.Keys() {
			v := c.Value(k.Section, k.Name)
			kv := keyView{Section: k.Section, Name: k.Name, Comment: k.Comment, Kind: k.Kind, Secret: k.Secret, Value: v}
			if k.Secret {
				kv.Set, kv.Value = v != "", "" // secrets are write-only
			}
			out = append(out, kv)
		}
		writeJSON(w, out)
	case http.MethodPost:
		var in struct{ Section, Key, Value string }
		if err := readBody(r, &in); err != nil {
			fail(w, 400, "bad json")
			return
		}
		if err := config.SetKey(p.ConfigPath, in.Section, in.Key, in.Value); err != nil {
			fail(w, 400, err.Error())
			return
		}
		writeJSON(w, map[string]string{"ok": "сохранено, применится за пару секунд"})
	default:
		fail(w, 405, "method not allowed")
	}
}

func (p *Panel) promptsAPI(w http.ResponseWriter, r *http.Request) {
	name := r.URL.Query().Get("name")
	switch r.Method {
	case http.MethodGet:
		if name == "" {
			writeJSON(w, p.Prompts.Names())
			return
		}
		if r.URL.Query().Get("history") != "" {
			writeJSON(w, p.Prompts.History(name))
			return
		}
		if id := r.URL.Query().Get("version"); id != "" {
			t, err := p.Prompts.Version(name, id)
			if err != nil {
				fail(w, 404, "no such version")
				return
			}
			writeJSON(w, map[string]string{"name": name, "content": t})
			return
		}
		raw, err := p.Prompts.Raw(name)
		if err != nil {
			fail(w, 404, "no such prompt")
			return
		}
		def, _ := p.Prompts.Default(name)
		writeJSON(w, map[string]any{"name": name, "content": raw, "is_default": raw == def})
	case http.MethodPost:
		var in struct {
			Name, Content string
			Reset         bool
			Restore       string
		}
		if err := readBody(r, &in); err != nil {
			fail(w, 400, "bad json")
			return
		}
		if in.Restore != "" {
			if err := p.Prompts.Restore(in.Name, in.Restore); err != nil {
				fail(w, 400, err.Error())
				return
			}
			writeJSON(w, map[string]string{"ok": "версия возвращена (то, что было перед этим, тоже сохранено в истории)"})
			return
		}
		content := in.Content
		if in.Reset {
			def, err := p.Prompts.Default(in.Name)
			if err != nil {
				fail(w, 404, "no such prompt")
				return
			}
			content = def
		}
		if strings.TrimSpace(content) == "" {
			fail(w, 400, "empty prompt")
			return
		}
		if err := p.Prompts.Write(in.Name, content); err != nil {
			fail(w, 400, err.Error())
			return
		}
		writeJSON(w, map[string]string{"ok": "сохранено. Прежний текст в истории: его можно вернуть"})
	default:
		fail(w, 405, "method not allowed")
	}
}

func (p *Panel) memoryAPI(w http.ResponseWriter, r *http.Request) {
	wm := memory.WorkingMemory{Path: p.Cfg().WorkingMemoryFile}
	switch r.Method {
	case http.MethodGet:
		s, _ := wm.Load()
		writeJSON(w, map[string]string{"content": s})
	case http.MethodPost:
		var in struct{ Content string }
		if err := readBody(r, &in); err != nil {
			fail(w, 400, "bad json")
			return
		}
		if err := wm.Save(in.Content); err != nil {
			fail(w, 500, err.Error())
			return
		}
		writeJSON(w, map[string]string{"ok": "сохранено"})
	default:
		fail(w, 405, "method not allowed")
	}
}

func (p *Panel) diaryAPI(w http.ResponseWriter, r *http.Request) {
	switch r.Method {
	case http.MethodGet:
		es, err := p.Diary.Load()
		if err != nil {
			fail(w, 500, err.Error())
			return
		}
		if r.URL.Query().Get("book") != "" {
			p.diaryBook(w, es)
			return
		}
		sort.Slice(es, func(i, j int) bool { return es[i].ID > es[j].ID })
		type row struct {
			ID   string  `json:"id"`
			Body string  `json:"body"`
			Conf float64 `json:"confidence"`
		}
		out := []row{}
		for i, e := range es {
			if i >= 60 {
				break
			}
			out = append(out, row{e.ID, e.Body, e.Meta.Confidence})
		}
		writeJSON(w, map[string]any{"total": len(es), "entries": out})
	case http.MethodPost:
		var in struct{ Delete string }
		if err := readBody(r, &in); err != nil || in.Delete == "" {
			fail(w, 400, "bad json")
			return
		}
		if strings.ContainsAny(in.Delete, `/\.`) {
			fail(w, 400, "bad id")
			return
		}
		if err := p.Diary.Remove(in.Delete); err != nil {
			fail(w, 400, err.Error())
			return
		}
		writeJSON(w, map[string]string{"ok": "удалено"})
	default:
		fail(w, 405, "method not allowed")
	}
}

func (p *Panel) shellLog(w http.ResponseWriter, r *http.Request) {
	b, _ := os.ReadFile(filepath.Join(p.Cfg().DataDir, "shell.log"))
	lines := strings.Split(strings.TrimRight(string(b), "\n"), "\n")
	if len(lines) == 1 && lines[0] == "" {
		lines = []string{}
	}
	if len(lines) > 100 {
		lines = lines[len(lines)-100:]
	}
	writeJSON(w, map[string]any{"lines": lines})
}

func (p *Panel) moodAPI(w http.ResponseWriter, r *http.Request) {
	if p.Mood == nil {
		fail(w, 400, "шкала настроения недоступна")
		return
	}
	var in struct{ Value int }
	if err := readBody(r, &in); err != nil || in.Value < 0 || in.Value > 100 {
		fail(w, 400, "нужно число от 0 до 100")
		return
	}
	lvl := p.Mood.Set(in.Value)
	writeJSON(w, map[string]any{"level": lvl, "name": mood.Name(lvl)})
}

// diaryBook serves the whole diary oldest-first for the book view (the page paginates it itself).
func (p *Panel) diaryBook(w http.ResponseWriter, es []diary.Entry) {
	sort.SliceStable(es, func(i, j int) bool {
		a, aerr := strconv.ParseInt(es[i].ID, 10, 64)
		b, berr := strconv.ParseInt(es[j].ID, 10, 64)
		if aerr == nil && berr == nil {
			return a < b
		}
		return es[i].ID < es[j].ID
	})
	const most = 1500 // keep the response small; the newest entries win
	if len(es) > most {
		es = es[len(es)-most:]
	}
	type page struct {
		ID   string  `json:"id"`
		Time int64   `json:"time,omitempty"` // unix seconds when the id is a timestamp
		Body string  `json:"body"`
		Conf float64 `json:"confidence"`
	}
	out := make([]page, 0, len(es))
	for _, e := range es {
		pg := page{ID: e.ID, Body: e.Body, Conf: e.Meta.Confidence}
		if t, err := strconv.ParseInt(e.ID, 10, 64); err == nil && t > 1_000_000_000 && t < 10_000_000_000 {
			pg.Time = t
		}
		out = append(out, pg)
	}
	writeJSON(w, map[string]any{"name": p.Cfg().CharacterName, "entries": out})
}

func (p *Panel) autonomyAPI(w http.ResponseWriter, r *http.Request) {
	c := p.Cfg()
	enabled := c.AutonomyEnabled
	if r.Method == http.MethodPost {
		var in struct {
			Enabled *bool `json:"enabled"`
			Wake    bool  `json:"wake"`
		}
		if err := readBody(r, &in); err != nil {
			fail(w, 400, "bad json")
			return
		}
		if in.Wake {
			p.Auto.Wake()
		}
		if in.Enabled != nil {
			if err := config.SetKey(p.ConfigPath, "autonomy", "enabled", strconv.FormatBool(*in.Enabled)); err != nil {
				fail(w, 400, err.Error())
				return
			}
			enabled = *in.Enabled // the watcher reloads the file a moment later; show the new value at once
		}
	} else if r.Method != http.MethodGet {
		fail(w, 405, "method not allowed")
		return
	}
	snap := p.Auto.Snapshot()
	journal := p.Auto.Recent(40)
	if journal == nil {
		journal = []string{}
	}
	writeJSON(w, map[string]any{
		"available": p.Auto != nil, "enabled": enabled,
		"asleep": snap.Asleep, "sleep_until": snap.SleepUntil, "sleep_note": snap.SleepNote,
		"sent_today": snap.SentToday, "max_per_day": c.AutonomyMaxPerDay, "last_run": snap.LastRun, "last_action": snap.LastAction,
		"quiet_from": c.AutonomyQuietFrom, "quiet_to": c.AutonomyQuietTo, "timezone": c.AutonomyTimezone,
		"min_mins": c.AutonomyMinMins, "max_mins": c.AutonomyMaxMins, "journal": journal,
	})
}

// serverAPI: free disk space and backups; POST {"backup":true} makes one right now.
func (p *Panel) serverAPI(w http.ResponseWriter, r *http.Request) {
	c := p.Cfg()
	dir := maint.BackupDirOf(c)
	var made string
	switch r.Method {
	case http.MethodPost:
		var in struct {
			Backup bool `json:"backup"`
		}
		if err := readBody(r, &in); err != nil || !in.Backup {
			fail(w, 400, "bad json")
			return
		}
		path, err := maint.Backup(maint.Sources(c, p.ConfigPath), dir, c.BackupKeep, time.Now())
		if err != nil {
			fail(w, 500, err.Error())
			return
		}
		made = filepath.Base(path)
	case http.MethodGet:
	default:
		fail(w, 405, "method not allowed")
		return
	}
	out := map[string]any{"backup_dir": dir, "maintenance": c.MaintEnabled, "made": made}
	if d, err := maint.DiskOf(c.DataDir); err == nil {
		out["disk"] = map[string]any{"free": d.Free, "total": d.Total, "percent": d.Percent(), "low": d.Low(c.DiskWarnPercent),
			"free_h": maint.Human(d.Free), "total_h": maint.Human(d.Total)}
	}
	list := maint.Backups(dir)
	if len(list) > 5 {
		list = list[:5]
	}
	if list == nil {
		list = []maint.BackupInfo{}
	}
	out["backups"] = list
	writeJSON(w, out)
}

// avg is the mean prompt size per request.
func avg(in, n float64) float64 {
	if n <= 0 {
		return 0
	}
	return in / n
}

// manifest and the icons make the panel installable on a phone ("Add to Home Screen": its own window, its own icon).
// They hold nothing private, so they need no login.
func (p *Panel) manifest(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/manifest+json")
	w.Header().Set("Cache-Control", "public, max-age=3600")
	_, _ = w.Write([]byte(`{"name":"Reina","short_name":"Reina","start_url":"/admin","scope":"/admin","display":"standalone","orientation":"portrait","background_color":"#0f0e15","theme_color":"#0f0e15","icons":[{"src":"/admin/icon-192.png","sizes":"192x192","type":"image/png"},{"src":"/admin/icon-512.png","sizes":"512x512","type":"image/png","purpose":"any"}]}`))
}

func (p *Panel) icon(name string) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		b, err := iconFS.ReadFile(name)
		if err != nil {
			http.NotFound(w, r)
			return
		}
		w.Header().Set("Content-Type", "image/png")
		w.Header().Set("Cache-Control", "public, max-age=86400")
		_, _ = w.Write(b)
	}
}
