package config

import (
	"fmt"
	"strings"
	"time"
)

// validate fixes values that would make the program misbehave (a percentage of 250, a maximum below its minimum,
// an unknown mode...) and says what it changed. It never refuses a config: she keeps running with the nearest
// sensible value, and the warning is printed at start, on every reload and by `reina doctor`.
func (c *Config) validate() []string {
	var w []string
	warn := func(format string, a ...any) { w = append(w, fmt.Sprintf(format, a...)) }

	oneOf := func(key string, v *string, def string, allowed ...string) {
		t := strings.ToLower(strings.TrimSpace(*v))
		for _, a := range allowed {
			if t == a {
				*v = t
				return
			}
		}
		warn("%s = %q is not one of %s; using %q", key, *v, strings.Join(allowed, ", "), def)
		*v = def
	}
	oneOf("telegram.mode", &c.Mode, "user", "user", "bot")
	oneOf("telegram.lockdown", &c.Lockdown, "none", "none", "contacts_only", "papik_only")
	oneOf("telegram.group_reply_mode", &c.GroupReplyMode, "addressed", "addressed", "all")
	oneOf("capabilities.tts_backend", &c.TTSBackend, "none", "none", "", "openai", "elevenlabs")
	if c.TTSBackend == "" {
		c.TTSBackend = "none"
	}
	oneOf("llm.reasoning", &c.Reasoning, "", "", "off", "none", "false", "low", "medium", "high")

	pct := func(key string, v *int) {
		switch {
		case *v < 0:
			warn("%s = %d is below 0; using 0", key, *v)
			*v = 0
		case *v > 100:
			warn("%s = %d is above 100; using 100", key, *v)
			*v = 100
		}
	}
	pct("presence.late_reply_percent", &c.LateReplyPercent)
	pct("presence.seen_later_percent", &c.SeenLaterPercent)
	pct("presence.slow_percent", &c.SlowPercent)
	pct("realism.ignore_percent", &c.IgnorePercent)
	pct("realism.brief_percent", &c.BriefPercent)
	pct("telegram.group_interest_percent", &c.GroupInterestPercent)
	pct("telegram.voice_percent", &c.VoicePercent)
	pct("telegram.group_chime_percent", &c.GroupChime)
	pct("maintenance.disk_warn_percent", &c.DiskWarnPercent)

	unit := func(key string, v *float64) {
		if *v < 0 || *v > 1 {
			nv := min(max(*v, 0), 1)
			warn("%s = %v must be between 0 and 1; using %v", key, *v, nv)
			*v = nv
		}
	}
	span := func(key string, v *float64, lo, hi float64) {
		if *v < lo || *v > hi {
			nv := min(max(*v, lo), hi)
			warn("%s = %v must be between %v and %v; using %v", key, *v, lo, hi, nv)
			*v = nv
		}
	}
	span("mind.min_sim", &c.MindMinSim, 0.6, 0.95)
	span("mind.hit_rate", &c.MindHitRate, 0.5, 0.95)
	unit("telegram.typo_chance", &c.TypoChance)
	unit("telegram.typing_jitter", &c.TypingJitter)
	if c.TypingSpeedCPS < 0 || (c.TypingSpeedCPS > 0 && c.TypingSpeedCPS < 1) || c.TypingSpeedCPS > 40 {
		nv := min(max(c.TypingSpeedCPS, 1), 40)
		if c.TypingSpeedCPS < 0 {
			nv = 0
		}
		warn("telegram.typing_speed_cps = %v must be 0 (old model) or between 1 and 40; using %v", c.TypingSpeedCPS, nv)
		c.TypingSpeedCPS = nv
	}
	unit("capabilities.stable_diffusion_reference_strength", &c.SDReferenceStrength)

	nonNeg := func(key string, v *int) {
		if *v < 0 {
			warn("%s = %d is negative; using 0", key, *v)
			*v = 0
		}
	}
	for _, p := range []struct {
		key string
		v   *int
	}{
		{"presence.read_delay_min_secs", &c.ReadDelayMin}, {"presence.read_delay_max_secs", &c.ReadDelayMax},
		{"presence.late_reply_min_mins", &c.LateReplyMinMins}, {"presence.late_reply_max_mins", &c.LateReplyMaxMins},
		{"presence.offline_after_secs", &c.OfflineAfterSecs}, {"telegram.typing_min_ms", &c.TypingMinMs},
		{"telegram.typing_max_ms", &c.TypingMaxMs}, {"telegram.typing_per_char_ms", &c.TypingPerCharMs},
		{"telegram.max_message_chars", &c.MaxMessageChars}, {"memory.history_keep", &c.HistoryKeep},
		{"memory.context_chars", &c.ContextChars}, {"memory.old_tool_result_chars", &c.ToolResultChars},
		{"autonomy.max_messages_per_day", &c.AutonomyMaxPerDay}, {"autonomy.chat_cooldown_mins", &c.AutonomyChatCooldown},
		{"maintenance.backup_keep", &c.BackupKeep}, {"maintenance.cache_days", &c.CacheDays},
		{"telegram.typing_cap_secs", &c.TypingCapSecs}, {"telegram.bubble_gap_max_ms", &c.BubbleGapMaxMs},
		{"telegram.thinking_typing_delay_ms", &c.ThinkTypingDelayMs}, {"telegram.thinking_typing_max_secs", &c.ThinkTypingMaxSecs},
		{"presence.sleep_jitter_mins", &c.SleepJitterMins}, {"presence.weekend_shift_mins", &c.WeekendShiftMins},
		{"presence.morning_lag_min_mins", &c.MorningLagMinMins}, {"presence.morning_lag_max_mins", &c.MorningLagMaxMins},
		{"presence.owner_read_max_secs", &c.OwnerReadMaxSecs}, {"presence.owner_night_max_secs", &c.OwnerNightMaxSecs},
		{"presence.seen_later_min_mins", &c.SeenLaterMinMins}, {"presence.seen_later_max_mins", &c.SeenLaterMaxMins},
		{"mail.send_per_day", &c.MailPerDay}, {"work.max_runs_per_day", &c.WorkMaxRuns},
	} {
		nonNeg(p.key, p.v)
	}

	order := func(lo, hi string, a, b *int) {
		if *b < *a {
			warn("%s (%d) is below %s (%d); using %d for both", hi, *b, lo, *a, *a)
			*b = *a
		}
	}
	order("presence.read_delay_min_secs", "presence.read_delay_max_secs", &c.ReadDelayMin, &c.ReadDelayMax)
	order("presence.late_reply_min_mins", "presence.late_reply_max_mins", &c.LateReplyMinMins, &c.LateReplyMaxMins)
	order("telegram.typing_min_ms", "telegram.typing_max_ms", &c.TypingMinMs, &c.TypingMaxMs)
	order("presence.morning_lag_min_mins", "presence.morning_lag_max_mins", &c.MorningLagMinMins, &c.MorningLagMaxMins)
	order("presence.seen_later_min_mins", "presence.seen_later_max_mins", &c.SeenLaterMinMins, &c.SeenLaterMaxMins)
	order("autonomy.min_interval_mins", "autonomy.max_interval_mins", &c.AutonomyMinMins, &c.AutonomyMaxMins)
	order("autonomy.inner_min_mins", "autonomy.inner_max_mins", &c.InnerMinMins, &c.InnerMaxMins)
	if c.InnerMinMins < 1 {
		warn("autonomy.inner_min_mins = %d; using 1", c.InnerMinMins)
		c.InnerMinMins = 1
		if c.InnerMaxMins < 1 {
			c.InnerMaxMins = 1
		}
	}
	if c.InnerPerDay < 0 {
		c.InnerPerDay = 0
	}
	if c.AutonomyMinMins < 1 {
		warn("autonomy.min_interval_mins = %d; using 1", c.AutonomyMinMins)
		c.AutonomyMinMins = 1
		if c.AutonomyMaxMins < 1 {
			c.AutonomyMaxMins = 1
		}
	}

	if c.ReportHour < 0 || c.ReportHour > 23 {
		warn("report.hour = %d is not an hour of the day; using 9", c.ReportHour)
		c.ReportHour = 9
	}
	if c.ProxyPort <= 0 || c.ProxyPort > 65535 {
		warn("proxy.port = %d is not a port; using 10434", c.ProxyPort)
		c.ProxyPort = 10434
	}
	if c.MaxToolRounds < 1 {
		warn("telegram.max_tool_rounds = %d; using 1", c.MaxToolRounds)
		c.MaxToolRounds = 1
	}
	if c.WorkEveryMins < 2 {
		c.WorkEveryMins = 2 // documented minimum, enforced silently as before
	}
	for _, q := range []struct {
		key string
		v   *string
		def string
	}{{"presence.bedtime", &c.Bedtime, "01:30"}, {"presence.wake", &c.WakeAt, "10:00"}} {
		if !validHM(*q.v) {
			warn("%s = %q is not HH:MM; using %s", q.key, *q.v, q.def)
			*q.v = q.def
		}
	}
	for _, q := range []struct{ key, v string }{{"autonomy.quiet_from", c.AutonomyQuietFrom}, {"autonomy.quiet_to", c.AutonomyQuietTo}} {
		if q.v != "" && !validHM(q.v) {
			warn("%s = %q is not HH:MM; there will be no quiet hours", q.key, q.v)
		}
	}
	if c.AutonomyTimezone != "" {
		if loc, err := time.LoadLocation(c.AutonomyTimezone); err != nil {
			warn("autonomy.timezone = %q is unknown (%v); using the server's zone", c.AutonomyTimezone, err)
		} else {
			c.loc = loc
		}
	}
	if c.AdminToken != "" && len(c.AdminToken) < 12 {
		warn("misc.admin_token is shorter than 12 characters: the panel stays off")
	}
	if c.TelegramEnabled && c.PapikChatID == 0 {
		warn("general.papik_chat_id is 0: owner-only features (commands, owner tools, alerts and reports) are off")
	}
	if c.ShutdownTimeout < 5*time.Second || c.ShutdownTimeout > 600*time.Second {
		nv := min(max(c.ShutdownTimeout, 5*time.Second), 600*time.Second)
		warn("misc.shutdown_timeout_secs = %d must be between 5 and 600; using %d", int64(c.ShutdownTimeout/time.Second), int64(nv/time.Second))
		c.ShutdownTimeout = nv
	}
	if strings.TrimSpace(c.DataDir) == "" {
		warn("misc.data_dir is empty; using \"data\"")
		c.DataDir = "data"
	}
	if c.TTSOn() && strings.TrimSpace(c.TTSURL) == "" {
		warn("capabilities.tts_backend = %q, but capabilities.tts_url is empty: voice replies will fail", c.TTSBackend)
	}
	// a URL without http:// or https:// is the commonest typo (localhost:8081/v1 or a pasted host name)
	for _, f := range schema {
		if _, isStr := f.def.(string); !isStr || !(strings.HasSuffix(f.key, "_url") || f.key == "api_base") {
			continue
		}
		p, ok := f.ptr(c).(*string)
		if !ok {
			continue
		}
		if v := strings.TrimSpace(*p); v != "" && !strings.HasPrefix(v, "http://") && !strings.HasPrefix(v, "https://") && !strings.HasPrefix(v, "ws://") && !strings.HasPrefix(v, "wss://") {
			warn("%s = %q does not start with http:// or https://; requests to it will fail", f.full(), v)
		}
	}
	if c.ProxyEnabled && c.ProxyAPIKey != "" && len(c.ProxyAPIKey) < 8 {
		warn("proxy.api_key is shorter than 8 characters: anyone who reaches the port can guess it")
	}
	return w
}

func validHM(s string) bool {
	var h, m int
	_, err := fmt.Sscanf(strings.TrimSpace(s), "%d:%d", &h, &m)
	return err == nil && h >= 0 && h <= 23 && m >= 0 && m <= 59
}

// Location is the owner's time zone (autonomy.timezone), or the server's when it is empty or unknown.
func (c *Config) Location() *time.Location {
	if c.loc != nil {
		return c.loc
	}
	if c.AutonomyTimezone != "" {
		if l, err := time.LoadLocation(c.AutonomyTimezone); err == nil {
			return l
		}
	}
	return time.Local
}

// IsOwner reports whether id is the owner (his user id, which is also his private chat id).
func (c *Config) IsOwner(id int64) bool { return c.PapikChatID != 0 && id == c.PapikChatID }

// OwnerChat reports whether chatID is the owner's private chat AND owner tools are on: the only place where she has
// a shell, the browser, his mail and the rest of the owner's powers.
func (c *Config) OwnerChat(chatID int64) bool { return c.OwnerTools && c.IsOwner(chatID) }

// TTSOn reports whether a text-to-speech backend is configured.
func (c *Config) TTSOn() bool { return c.TTSBackend != "" && c.TTSBackend != "none" }
