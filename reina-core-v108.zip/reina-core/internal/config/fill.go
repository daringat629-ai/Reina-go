package config

import (
	"errors"
	"fmt"
	"os"
	"regexp"
	"strings"

	"orvi/internal/store"
)

var (
	secRe = regexp.MustCompile(`^\s*\[([^\]]+)\]\s*(#.*)?$`)
	keyRe = regexp.MustCompile(`^\s*([A-Za-z0-9_]+)\s*=`)
)

// FillMissing writes every setting that config.toml lacks into the file, with its default and comment, so nothing
// stays hidden behind an unwritten default. Existing lines are never touched; the old file is kept as <path>.bak
// (once per run that changes something). It returns the "section.key" names it added.
func FillMissing(path string) ([]string, error) {
	raw, err := os.ReadFile(path)
	if errors.Is(err, os.ErrNotExist) {
		return nil, nil // the first run: Load writes the whole default file
	}
	if err != nil {
		return nil, err
	}
	lines := strings.Split(strings.TrimRight(strings.TrimPrefix(string(raw), "\ufeff"), "\n"), "\n") // a BOM from a Windows editor hid the first [section]
	have := map[string]bool{}
	secs := map[string]bool{}
	cur := ""
	for _, l := range lines {
		if m := secRe.FindStringSubmatch(l); m != nil {
			cur = strings.TrimSpace(m[1])
			secs[cur] = true
		} else if m := keyRe.FindStringSubmatch(l); m != nil && cur != "" {
			have[cur+"."+m[1]] = true
		}
	}
	missing := map[string][]field{}
	var order []string
	var added []string
	for _, f := range schema {
		if have[f.section+"."+f.key] {
			continue
		}
		if _, ok := missing[f.section]; !ok {
			order = append(order, f.section)
		}
		missing[f.section] = append(missing[f.section], f)
		added = append(added, f.section+"."+f.key)
	}
	if len(added) == 0 {
		return nil, nil
	}
	render := func(fs []field) []string {
		var out []string
		for _, f := range fs {
			if f.comment != "" {
				out = append(out, "# "+f.comment)
			}
			out = append(out, fmt.Sprintf("%s = %s", f.key, formatScalar(f.def)))
		}
		return out
	}
	// insert at the end of each existing section (before its trailing blank lines)
	var out []string
	cur = ""
	flush := func() {
		if fs, ok := missing[cur]; ok && secs[cur] {
			n := len(out)
			for n > 0 && strings.TrimSpace(out[n-1]) == "" {
				n--
			}
			tail := append([]string{}, out[n:]...)
			out = append(append(out[:n], render(fs)...), tail...)
			delete(missing, cur)
		}
	}
	for _, l := range lines {
		if m := secRe.FindStringSubmatch(l); m != nil {
			flush()
			cur = strings.TrimSpace(m[1])
		}
		out = append(out, l)
	}
	flush()
	for _, s := range order { // sections the file does not have at all
		if fs, ok := missing[s]; ok {
			out = append(out, "", "["+s+"]")
			out = append(out, render(fs)...)
		}
	}
	if err := store.WriteFile(path+".bak", raw, store.Private); err != nil {
		return nil, err
	}
	if err := store.WriteFile(path, []byte(strings.Join(out, "\n")+"\n"), store.Private); err != nil {
		return nil, err
	}
	return added, nil
}
