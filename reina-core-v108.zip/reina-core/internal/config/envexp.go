package config

import (
	"fmt"
	"os"
	"regexp"
	"sort"
	"strings"
)

// envRef matches ${NAME} and ${NAME:-default} inside a string value of config.toml.
var envRef = regexp.MustCompile(`\$\{([A-Za-z_][A-Za-z0-9_]*)(?::-([^}]*))?\}`)

// expandEnvText replaces ${NAME} with the environment variable NAME (${NAME:-x} falls back to x when it is unset or
// empty). "$${" stays a literal "${". It returns the text and the names of variables that were needed but empty.
// The expansion happens only while the file is read: SetKey and FillMissing work on the text of the file, so a
// secret taken from the environment is never written back expanded.
func expandEnvText(s string, lookup func(string) (string, bool)) (string, []string) {
	if !strings.Contains(s, "${") {
		return s, nil
	}
	const esc = "\x00esc\x00"
	s = strings.ReplaceAll(s, "$${", esc)
	var missing []string
	s = envRef.ReplaceAllStringFunc(s, func(m string) string {
		sub := envRef.FindStringSubmatch(m)
		if v, ok := lookup(sub[1]); ok && v != "" {
			return v
		}
		if strings.Contains(m, ":-") {
			return sub[2]
		}
		missing = append(missing, sub[1])
		return ""
	})
	return strings.ReplaceAll(s, esc, "${"), missing
}

// expandDocEnv expands every string value of the parsed file and returns warnings for the unset variables.
func expandDocEnv(values map[string]any, lookup func(string) (string, bool)) []string {
	keys := make([]string, 0, len(values))
	for k := range values {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	var w []string
	for _, k := range keys {
		s, ok := values[k].(string)
		if !ok {
			continue
		}
		out, missing := expandEnvText(s, lookup)
		for _, name := range missing {
			w = append(w, fmt.Sprintf("%s uses ${%s}, but the environment variable %s is not set or empty; the value stays empty", k, name, name))
		}
		values[k] = out
	}
	return w
}

func osLookup(name string) (string, bool) { return os.LookupEnv(name) }

// suggestKey finds the known key of the same section (or, failing that, any section) that looks most like a mistyped
// one, for the "did you mean" hint. It returns "" when nothing is close.
func suggestKey(full string) string {
	best, bestD := "", 4
	sec, name, _ := strings.Cut(full, ".")
	for _, f := range schema {
		d := editDistance(name, f.key)
		if f.section != sec {
			d += 2
		}
		if d < bestD {
			best, bestD = f.full(), d
		}
	}
	return best
}

func editDistance(a, b string) int {
	ra, rb := []rune(a), []rune(b)
	prev := make([]int, len(rb)+1)
	for j := range prev {
		prev[j] = j
	}
	for i := 1; i <= len(ra); i++ {
		cur := make([]int, len(rb)+1)
		cur[0] = i
		for j := 1; j <= len(rb); j++ {
			c := 1
			if ra[i-1] == rb[j-1] {
				c = 0
			}
			cur[j] = min(prev[j]+1, cur[j-1]+1, prev[j-1]+c)
		}
		prev = cur
	}
	return prev[len(rb)]
}
