package config

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestFillMissingKeepsUserLinesAndAddsTheRest(t *testing.T) {
	p := filepath.Join(t.TempDir(), "config.toml")
	mine := "[llm]\nmodel = \"my/model\"\n\n[telegram]\nlockdown = \"papik_only\"\n"
	if err := os.WriteFile(p, []byte(mine), 0o600); err != nil {
		t.Fatal(err)
	}
	added, err := FillMissing(p)
	if err != nil || len(added) < 10 {
		t.Fatalf("added=%d err=%v", len(added), err)
	}
	b, _ := os.ReadFile(p)
	s := string(b)
	for _, want := range []string{`model = "my/model"`, `lockdown = "papik_only"`, "panel_takeover = true", "desk_overview = true", "[misc]"} {
		if !strings.Contains(s, want) {
			t.Fatalf("lacks %q:\n%s", want, s)
		}
	}
	if strings.Count(s, "lockdown =") != 1 || strings.Count(s, "[llm]") != 1 {
		t.Fatalf("duplicates:\n%s", s)
	}
	if bk, _ := os.ReadFile(p + ".bak"); string(bk) != mine {
		t.Fatal("backup differs from the original")
	}
	// the result still loads, with the user's values intact
	c, err := Load(p)
	if err != nil || c.LLMModel != "my/model" || c.Lockdown != "papik_only" {
		t.Fatalf("load: %v %+v", err, c)
	}
	// second run is a no-op
	again, err := FillMissing(p)
	if err != nil || len(again) != 0 {
		t.Fatalf("second run added %v (%v)", again, err)
	}
}

func TestFillMissingNeverOverwritesOddButValidFiles(t *testing.T) {
	p := filepath.Join(t.TempDir(), "config.toml")
	// a commented section header, a value that differs from the default, a secret from the environment, an unknown key
	mine := "\ufeff[llm] # my model\napi_key = \"${REINA_FILL_KEY}\"\nrequest_timeout_secs = 17\nmystery = 1\n\n[misc]\nmetrics_enabled = false\nshutdown_timeout_secs = 45\n"
	if err := os.WriteFile(p, []byte(mine), 0o600); err != nil {
		t.Fatal(err)
	}
	if _, err := FillMissing(p); err != nil {
		t.Fatal(err)
	}
	b, _ := os.ReadFile(p)
	s := string(b)
	for _, want := range []string{"request_timeout_secs = 17", "metrics_enabled = false", "shutdown_timeout_secs = 45", "mystery = 1", "${REINA_FILL_KEY}"} {
		if !strings.Contains(s, want) {
			t.Fatalf("lost %q:\n%s", want, s)
		}
	}
	s = strings.TrimPrefix(s, "\ufeff")
	if strings.Count(s, "request_timeout_secs") != 1 || strings.Count(s, "[llm]") != 1 {
		t.Fatalf("duplicated:\n%s", s)
	}
	if st, _ := os.Stat(p); st.Mode().Perm() != 0o600 {
		t.Fatalf("mode %v", st.Mode())
	}
}
