package config

import (
	"errors"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestFirstRunWritesDefaults(t *testing.T) {
	p := filepath.Join(t.TempDir(), "config.toml")
	if _, err := Load(p); !errors.Is(err, ErrNeedsSetup) {
		t.Fatalf("want ErrNeedsSetup, got %v", err)
	}
	c, err := Load(p)
	if err != nil {
		t.Fatalf("reload defaults: %v", err)
	}
	if c.LLMBaseURL != "https://api.inceptionlabs.ai/v1/" || c.LLMModel != "mercury-3" || c.ProxyPort != 10434 {
		t.Fatalf("unexpected defaults: %+v", c)
	}
	if c.DebounceWindow != 6000*time.Millisecond || c.SessionIdle != 900*time.Second {
		t.Fatalf("durations: %v %v", c.DebounceWindow, c.SessionIdle)
	}
}

func TestParseOverridesAndComments(t *testing.T) {
	src := `
# top comment
[general]
character_name = "Mika" # inline comment
papik_chat_id = 625207005

[llm]
base_url = "http://example.com/v1"
request_timeout_secs = 12
temperature = 0.7
[proxy]
port = 9999
`
	p := filepath.Join(t.TempDir(), "config.toml")
	if err := os.WriteFile(p, []byte(src), 0o644); err != nil {
		t.Fatal(err)
	}
	c, err := Load(p)
	if err != nil {
		t.Fatal(err)
	}
	if c.CharacterName != "Mika" || c.LLMBaseURL != "http://example.com/v1/" || c.ProxyPort != 9999 || c.Temperature != 0.7 {
		t.Fatalf("got %+v", c)
	}
	if c.EmbeddingBaseURL != c.LLMBaseURL {
		t.Fatalf("embedding base should default to llm base")
	}
}

func TestBadTypeIsAnError(t *testing.T) {
	p := filepath.Join(t.TempDir(), "config.toml")
	os.WriteFile(p, []byte("[proxy]\nport = \"x\"\n"), 0o644)
	if _, err := Load(p); err == nil {
		t.Fatal("expected type error")
	}
}

func TestEnvExpansionInText(t *testing.T) {
	t.Setenv("REINA_T_KEY", "sk-secret")
	t.Setenv("REINA_T_EMPTY", "")
	c, err := Parse("[llm]\napi_key = \"${REINA_T_KEY}\"\nbase_url = \"https://${REINA_T_HOST:-api.example.com}/v1\"\nembedding_api_key = \"${REINA_T_NOPE}\"\nmodel = \"a$${b}\"\n")
	if err != nil {
		t.Fatal(err)
	}
	if c.LLMAPIKey != "sk-secret" {
		t.Fatalf("key = %q", c.LLMAPIKey)
	}
	if c.LLMBaseURL != "https://api.example.com/v1/" {
		t.Fatalf("url = %q", c.LLMBaseURL)
	}
	if c.LLMModel != "a${b}" {
		t.Fatalf("escape = %q", c.LLMModel)
	}
	found := false
	for _, w := range c.Warnings {
		if strings.Contains(w, "REINA_T_NOPE") {
			found = true
		}
	}
	if !found {
		t.Fatalf("no warning for the unset variable: %v", c.Warnings)
	}
}

func TestEnvNotWrittenBack(t *testing.T) {
	t.Setenv("REINA_T_KEY", "sk-secret")
	path := filepath.Join(t.TempDir(), "config.toml")
	if err := os.WriteFile(path, []byte("[llm]\napi_key = \"${REINA_T_KEY}\"\n"), 0o600); err != nil {
		t.Fatal(err)
	}
	if _, err := FillMissing(path); err != nil {
		t.Fatal(err)
	}
	if err := SetKey(path, "llm", "model", "m1"); err != nil {
		t.Fatal(err)
	}
	b, _ := os.ReadFile(path)
	if !strings.Contains(string(b), "${REINA_T_KEY}") || strings.Contains(string(b), "sk-secret") {
		t.Fatalf("the secret was written back:\n%s", b)
	}
}

func TestUnknownKeyHint(t *testing.T) {
	c, err := Parse("[llm]\nreasonin = \"low\"\n")
	if err != nil {
		t.Fatal(err)
	}
	ok := false
	for _, w := range c.Warnings {
		if strings.Contains(w, "did you mean llm.reasoning") {
			ok = true
		}
	}
	if !ok {
		t.Fatalf("warnings: %v", c.Warnings)
	}
}

func TestExampleConfigsParseWithoutWarnings(t *testing.T) {
	t.Setenv("INCEPTION_API_KEY", "k1")
	t.Setenv("OPENROUTER_API_KEY", "k2")
	b, err := os.ReadFile("../../examples/config-inception-openrouter.toml")
	if err != nil {
		t.Skip(err)
	}
	c, err := Parse(string(b))
	if err != nil {
		t.Fatal(err)
	}
	for _, w := range c.Warnings {
		if strings.Contains(w, "unknown") || strings.Contains(w, "environment") {
			t.Errorf("example config: %s", w)
		}
	}
	if c.LLMAPIKey != "k1" || c.LightAPIKey != "k2" {
		t.Fatalf("env not expanded: %q %q", c.LLMAPIKey, c.LightAPIKey)
	}
}
