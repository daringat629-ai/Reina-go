// Package web opens links people send her. Anything a stranger can paste into a chat is hostile, so the
// fetcher only talks to public internet addresses: loopback, private ranges, link-local, the cloud metadata
// address and Tailscale/CGNAT (100.64.0.0/10, where the admin panel lives) are refused at connect time,
// which also covers redirects and DNS tricks.
package web

import (
	"context"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/netip"
	"net/url"
	"strings"
	"syscall"
	"time"

	"orvi/internal/docs"
)

var blockedPrefixes = func() []netip.Prefix {
	var out []netip.Prefix
	for _, s := range []string{
		"0.0.0.0/8", "10.0.0.0/8", "100.64.0.0/10", "127.0.0.0/8", "169.254.0.0/16", "172.16.0.0/12", "192.0.0.0/24",
		"192.0.2.0/24", "192.168.0.0/16", "198.18.0.0/15", "198.51.100.0/24", "203.0.113.0/24", "224.0.0.0/4", "240.0.0.0/4",
		"::/128", "::1/128", "64:ff9b::/96", "100::/64", "2001:db8::/32", "fc00::/7", "fe80::/10", "ff00::/8",
	} {
		out = append(out, netip.MustParsePrefix(s))
	}
	return out
}()

// BlockedIP reports whether an address must never be fetched.
func BlockedIP(ip netip.Addr) bool {
	ip = ip.Unmap()
	if !ip.IsValid() || !ip.IsGlobalUnicast() || ip.IsPrivate() || ip.IsLoopback() {
		return true
	}
	for _, p := range blockedPrefixes {
		if p.Contains(ip) {
			return true
		}
	}
	return false
}

// Page is what a link looked like.
type Page struct {
	URL         string // after redirects
	Title       string
	Description string
	Text        string
	ContentType string
}

// Fetcher downloads and cleans web pages.
type Fetcher struct {
	AllowPrivate bool          // tests only
	MaxBytes     int64         // body limit (default 2 MB)
	Timeout      time.Duration // default 20 s
}

var ErrBlocked = errors.New("that address is not on the public internet; I don't open it")

func (f Fetcher) client() *http.Client {
	dialer := &net.Dialer{Timeout: 10 * time.Second}
	if !f.AllowPrivate {
		dialer.Control = func(network, address string, _ syscall.RawConn) error {
			host, _, err := net.SplitHostPort(address)
			if err != nil {
				return err
			}
			ip, err := netip.ParseAddr(host)
			if err != nil || BlockedIP(ip) {
				return ErrBlocked
			}
			return nil
		}
	}
	to := f.Timeout
	if to <= 0 {
		to = 20 * time.Second
	}
	return &http.Client{
		Timeout:   to,
		Transport: &http.Transport{Proxy: nil, DialContext: dialer.DialContext, TLSHandshakeTimeout: 10 * time.Second, DisableKeepAlives: true, MaxResponseHeaderBytes: 64 << 10},
		CheckRedirect: func(req *http.Request, via []*http.Request) error {
			if len(via) >= 5 {
				return errors.New("too many redirects")
			}
			return checkURL(req.URL)
		},
	}
}

// Client is the SSRF-safe HTTP client (public addresses only, redirects checked) for callers that need more than GET.
func (f Fetcher) Client() *http.Client { return f.client() }

func checkURL(u *url.URL) error {
	if u.Scheme != "http" && u.Scheme != "https" {
		return fmt.Errorf("only http and https links can be opened (got %q)", u.Scheme)
	}
	if u.Host == "" || u.User != nil {
		return errors.New("bad link")
	}
	return nil
}

// Fetch opens a link. Text pages are cleaned; PDFs go through docs.Extract.
func (f Fetcher) Fetch(ctx context.Context, raw string) (Page, error) {
	raw = strings.TrimSpace(raw)
	if !strings.Contains(raw, "://") {
		raw = "https://" + raw
	}
	u, err := url.Parse(raw)
	if err != nil {
		return Page{}, errors.New("bad link")
	}
	if err := checkURL(u); err != nil {
		return Page{}, err
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, u.String(), nil)
	if err != nil {
		return Page{}, err
	}
	req.Header.Set("User-Agent", "Mozilla/5.0 (compatible; link-preview)")
	req.Header.Set("Accept", "text/html,text/plain,application/json,application/pdf;q=0.8,*/*;q=0.1")
	req.Header.Set("Accept-Language", "ru,en;q=0.8")
	resp, err := f.client().Do(req)
	if err != nil {
		if errors.Is(err, ErrBlocked) || strings.Contains(err.Error(), ErrBlocked.Error()) {
			return Page{}, ErrBlocked
		}
		return Page{}, fmt.Errorf("can't open the link: %w", unwrap(err))
	}
	defer resp.Body.Close()
	if resp.StatusCode/100 != 2 {
		return Page{}, fmt.Errorf("the site answered HTTP %d", resp.StatusCode)
	}
	limit := f.MaxBytes
	if limit <= 0 {
		limit = 2 << 20
	}
	body, err := io.ReadAll(io.LimitReader(resp.Body, limit))
	if err != nil {
		return Page{}, fmt.Errorf("can't read the page: %w", unwrap(err))
	}
	ct := strings.ToLower(strings.TrimSpace(strings.SplitN(resp.Header.Get("Content-Type"), ";", 2)[0]))
	pg := Page{URL: resp.Request.URL.String(), ContentType: ct}
	switch {
	case ct == "application/pdf":
		pg.Text, err = docs.Extract(ctx, "page.pdf", body)
		if err != nil {
			return Page{}, err
		}
	case ct == "" || strings.HasPrefix(ct, "text/") || strings.Contains(ct, "json") || strings.Contains(ct, "xml") || strings.Contains(ct, "javascript"):
		s, err := docs.DecodeText(body)
		if err != nil {
			return Page{}, err
		}
		if strings.Contains(ct, "html") || (ct == "" && strings.Contains(strings.ToLower(s[:min(len(s), 512)]), "<html")) {
			pg.Title, pg.Description = docs.HTMLTitle(s)
			pg.Text = docs.HTMLToText(s)
		} else {
			pg.Text = strings.TrimSpace(s)
		}
	default:
		return Page{}, fmt.Errorf("that link is a %s file, not a web page (I can read pages, text and PDF)", ct)
	}
	if strings.TrimSpace(pg.Text) == "" && pg.Description == "" {
		return Page{}, errors.New("the page has no readable text (it may need JavaScript or a login)")
	}
	return pg, nil
}

// unwrap drops the noisy *url.Error wrapper so the model sees "connection refused", not the whole URL again.
func unwrap(err error) error {
	var ue *url.Error
	if errors.As(err, &ue) {
		return ue.Err
	}
	return err
}
