package mail

import (
	"bytes"
	"encoding/base64"
	"io"
	"mime"
	"mime/multipart"
	stdmail "net/mail"
	"strings"
	"time"

	"orvi/internal/docs"
)

// Message is a parsed e-mail.
type Message struct {
	From, To, Subject, Date string
	MessageID               string
	When                    time.Time
	Text                    string
	Attachments             []string
	HasHTMLOnly             bool
}

var wordDecoder = &mime.WordDecoder{CharsetReader: charsetReader}

// DecodeHeader decodes RFC 2047 words ("=?utf-8?B?...?=").
func DecodeHeader(s string) string {
	if d, err := wordDecoder.DecodeHeader(s); err == nil {
		return strings.Join(strings.Fields(d), " ")
	}
	return strings.Join(strings.Fields(s), " ")
}

// ParseMessage reads a raw RFC 822 message (headers + body) into text: the plain part, or the HTML part as text.
func ParseMessage(raw []byte) (Message, error) {
	m, err := stdmail.ReadMessage(bytes.NewReader(raw))
	if err != nil {
		return Message{}, err
	}
	out := Message{
		From: DecodeHeader(m.Header.Get("From")), To: DecodeHeader(m.Header.Get("To")), Subject: DecodeHeader(m.Header.Get("Subject")),
		Date: m.Header.Get("Date"), MessageID: strings.TrimSpace(m.Header.Get("Message-Id")),
	}
	if t, err := m.Header.Date(); err == nil {
		out.Date, out.When = t.Format("2006-01-02 15:04"), t
	}
	var plain, htmlText []string
	walk(textproto(m.Header), m.Body, &plain, &htmlText, &out.Attachments, 0)
	switch {
	case len(plain) > 0:
		out.Text = strings.TrimSpace(strings.Join(plain, "\n"))
	case len(htmlText) > 0:
		out.Text, out.HasHTMLOnly = strings.TrimSpace(strings.Join(htmlText, "\n")), true
	}
	return out, nil
}

type headerGetter interface{ Get(string) string }

func textproto(h stdmail.Header) headerGetter { return h }

func walk(h headerGetter, body io.Reader, plain, htmlText, atts *[]string, depth int) {
	if depth > 6 {
		return
	}
	ct, params, err := mime.ParseMediaType(h.Get("Content-Type"))
	if err != nil || ct == "" {
		ct, params = "text/plain", map[string]string{}
	}
	disp, dparams, _ := mime.ParseMediaType(h.Get("Content-Disposition"))
	if name := firstNonEmpty(dparams["filename"], params["name"]); name != "" && (disp == "attachment" || !strings.HasPrefix(ct, "text/") && !strings.HasPrefix(ct, "multipart/")) {
		*atts = append(*atts, DecodeHeader(name))
		return
	}
	if strings.HasPrefix(ct, "multipart/") {
		mr := multipart.NewReader(body, params["boundary"])
		for {
			p, err := mr.NextPart()
			if err != nil {
				return
			}
			walk(p.Header, p, plain, htmlText, atts, depth+1)
		}
	}
	if !strings.HasPrefix(ct, "text/") {
		return
	}
	raw, _ := io.ReadAll(io.LimitReader(decodeBody(h.Get("Content-Transfer-Encoding"), body), 2<<20))
	text := ToUTF8(params["charset"], raw)
	if ct == "text/html" {
		*htmlText = append(*htmlText, docs.HTMLToText(text))
	} else if ct == "text/plain" {
		*plain = append(*plain, text)
	}
}

func firstNonEmpty(a ...string) string {
	for _, s := range a {
		if s != "" {
			return s
		}
	}
	return ""
}

func decodeBody(enc string, r io.Reader) io.Reader {
	switch strings.ToLower(strings.TrimSpace(enc)) {
	case "base64":
		return base64.NewDecoder(base64.StdEncoding, &stripNL{r})
	case "quoted-printable":
		return quotedPrintable(r)
	}
	return r
}

// stripNL drops CR/LF so base64 with line breaks decodes.
type stripNL struct{ r io.Reader }

func (s *stripNL) Read(p []byte) (int, error) {
	n, err := s.r.Read(p)
	j := 0
	for i := 0; i < n; i++ {
		if p[i] != '\r' && p[i] != '\n' {
			p[j] = p[i]
			j++
		}
	}
	return j, err
}
