package update

import (
	"context"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestLatestReleaseAndDownload(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/repos/o/r/releases/latest":
			w.Write([]byte(`{"tag_name":"build-12","name":"v72","published_at":"2026-11-01T10:00:00Z","assets":[{"name":"notes.txt","browser_download_url":"x"},{"name":"reina-alpine-tdlib.zip","browser_download_url":"` + "http://" + r.Host + `/dl"}]}`))
		case "/dl":
			w.Write([]byte("ZIPDATA"))
		default:
			http.NotFound(w, r)
		}
	}))
	defer srv.Close()
	ctx := context.Background()
	r, err := Latest(ctx, srv.Client(), srv.URL, "o/r")
	if err != nil || r.Tag != "build-12" || r.URL != srv.URL+"/dl" {
		t.Fatalf("%+v %v", r, err)
	}
	if _, err := Latest(ctx, srv.Client(), srv.URL, "nope"); err == nil {
		t.Fatal("repo must be owner/name")
	}
	dir := t.TempDir()
	dst := filepath.Join(dir, "a.zip")
	if err := Download(ctx, srv.Client(), r.URL, dst, 3); err == nil {
		t.Fatal("too big")
	}
	if _, err := os.Stat(dst); err == nil {
		t.Fatal("no half file left")
	}
	if err := Download(ctx, srv.Client(), r.URL, dst, 1<<20); err != nil {
		t.Fatal(err)
	}
	exe := filepath.Join(dir, "reina")
	_ = os.WriteFile(exe, nil, 0o755)
	old := time.Date(2026, 10, 1, 0, 0, 0, 0, time.UTC)
	_ = os.Chtimes(exe, old, old)
	if !IsNew(r, dir, exe) {
		t.Fatal("published after the program file: new")
	}
	_ = MarkInstalled(dir, "build-12")
	if IsNew(r, dir, exe) {
		t.Fatal("the same tag again: not new")
	}
	r.Tag = "build-13"
	if !IsNew(r, dir, exe) {
		t.Fatal("another tag: new")
	}
}

func TestRepoAndLinkValidation(t *testing.T) {
	for _, bad := range []string{"a/b?x=1", "a/..", "a b/c", "a/b#"} {
		if _, err := Latest(context.Background(), http.DefaultClient, "http://127.0.0.1:1", bad); err == nil || !strings.Contains(err.Error(), "github_repo") {
			t.Fatalf("%q must be refused: %v", bad, err)
		}
	}
	if err := Download(context.Background(), http.DefaultClient, "http://evil.example/x.zip", filepath.Join(t.TempDir(), "x"), 10); err == nil {
		t.Fatal("plain http to a remote host must be refused")
	}
}
