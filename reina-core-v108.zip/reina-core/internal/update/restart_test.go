//go:build !windows

package update

import "testing"

func TestLoaderRestart(t *testing.T) {
	for p, want := range map[string]bool{
		"/work/alp/root/lib/ld-musl-x86_64.so.1": true,
		"/lib64/ld-linux-x86-64.so.2":            true,
		"/opt/reina/reina-tdlib":                 false,
	} {
		if isLoader(p) != want {
			t.Errorf("isLoader(%q) = %v, want %v", p, !want, want)
		}
	}
	got := splitCmdline([]byte("/ld/ld-musl\x00--library-path\x00/x:/y\x00./reina-tdlib\x00"))
	if len(got) != 4 || got[3] != "./reina-tdlib" {
		t.Errorf("splitCmdline = %q", got)
	}
}
