//go:build !windows

package update

import (
	"errors"
	"os"
	"path/filepath"
	"strings"
	"syscall"
)

// Restart replaces the running process with a fresh copy of the program file (same arguments and environment,
// so LD_LIBRARY_PATH survives). It only returns on failure.
//
// When the program was started through the dynamic loader (ld-musl-x86_64.so.1 --library-path ... ./reina-tdlib, as on
// Alpine-in-a-container nodes) the "executable" is the loader itself and os.Args has lost its own arguments, so a plain
// exec printed the loader's usage and the process died. In that case the original command line is replayed.
func Restart() error {
	p := Exe()
	if p == "" {
		return errors.New("не знаю, где лежит программа")
	}
	args := os.Args
	if isLoader(p) {
		if raw, err := os.ReadFile("/proc/self/cmdline"); err == nil {
			if full := splitCmdline(raw); len(full) >= 2 {
				args = full
			}
		}
	}
	return syscall.Exec(p, args, os.Environ())
}

func isLoader(path string) bool {
	b := filepath.Base(path)
	return strings.HasPrefix(b, "ld-musl") || strings.HasPrefix(b, "ld-linux")
}

func splitCmdline(raw []byte) []string {
	s := strings.TrimRight(string(raw), "\x00")
	if s == "" {
		return nil
	}
	return strings.Split(s, "\x00")
}
