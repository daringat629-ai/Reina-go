// Package reminders keeps "remind me later" items in a small JSON file so they survive restarts.
package reminders

import (
	"errors"
	"fmt"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"orvi/internal/store"
)

// Item is one reminder.
type Item struct {
	ID      int       `json:"id"`
	At      time.Time `json:"at"`
	Chat    int64     `json:"chat"`
	Text    string    `json:"text"`
	Created time.Time `json:"created"`
}

// MaxPending bounds how many reminders may wait at once.
const MaxPending = 50

type Store struct {
	mu    sync.Mutex
	path  string
	items []Item
	next  int
	saver store.Saver
}

// New loads path (a missing file starts empty; a broken one is moved aside and reported).
func New(path string) *Store {
	s := &Store{path: path, next: 1, saver: store.Saver{What: "reminders"}}
	store.Load("reminders", path, &s.items)
	for _, it := range s.items {
		if it.ID >= s.next {
			s.next = it.ID + 1
		}
	}
	return s
}

func (s *Store) save() { _ = s.saver.Save(s.path, s.items) }

// Add stores a reminder for chat at the given time.
func (s *Store) Add(at time.Time, chat int64, text string, now time.Time) (Item, error) {
	text = strings.TrimSpace(text)
	if text == "" {
		return Item{}, errors.New("empty reminder text")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if len(s.items) >= MaxPending {
		return Item{}, fmt.Errorf("too many pending reminders (%d)", MaxPending)
	}
	it := Item{ID: s.next, At: at, Chat: chat, Text: text, Created: now}
	s.next++
	s.items = append(s.items, it)
	s.save()
	return it, nil
}

// Due removes and returns the reminders whose time has come.
func (s *Store) Due(now time.Time) []Item {
	s.mu.Lock()
	defer s.mu.Unlock()
	var due, keep []Item
	for _, it := range s.items {
		if !it.At.After(now) {
			due = append(due, it)
		} else {
			keep = append(keep, it)
		}
	}
	if len(due) > 0 {
		s.items = keep
		s.save()
	}
	sort.Slice(due, func(i, j int) bool { return due[i].At.Before(due[j].At) })
	return due
}

// List returns pending reminders of a chat (chat 0 = all), soonest first.
func (s *Store) List(chat int64) []Item {
	s.mu.Lock()
	defer s.mu.Unlock()
	var out []Item
	for _, it := range s.items {
		if chat == 0 || it.Chat == chat {
			out = append(out, it)
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].At.Before(out[j].At) })
	return out
}

// Cancel removes a reminder of the chat (chat 0 = any chat).
func (s *Store) Cancel(id int, chat int64) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	for i, it := range s.items {
		if it.ID == id && (chat == 0 || it.Chat == chat) {
			s.items = append(s.items[:i], s.items[i+1:]...)
			s.save()
			return true
		}
	}
	return false
}

var (
	reDur  = regexp.MustCompile(`^(?:\+|in\s+|через\s+)?((?:\d+\s*(?:d|д|h|ч|m|м|min|мин|s|с|sec)[a-zа-я]*\s*)+)$`)
	rePart = regexp.MustCompile(`(\d+)\s*([a-zа-я]+)`)
	reHM   = regexp.MustCompile(`^(\d{1,2})[:.](\d{2})$`)
)

// ParseWhen understands: a delay ("45m", "2h", "1h30m", "1d", "+10 min", "через 2 часа"), a clock time ("18:30",
// next occurrence), "today 18:30", "tomorrow 09:00" / "завтра 09:00" and "2026-10-21 09:00". Times are in loc.
func ParseWhen(s string, now time.Time, loc *time.Location) (time.Time, error) {
	if loc == nil {
		loc = time.Local
	}
	s = strings.ToLower(strings.TrimSpace(s))
	if s == "" {
		return time.Time{}, errors.New("when is empty")
	}
	if m := reDur.FindStringSubmatch(s); m != nil {
		var total time.Duration
		for _, p := range rePart.FindAllStringSubmatch(m[1], -1) {
			n, _ := strconv.Atoi(p[1])
			var unit time.Duration
			switch {
			case strings.HasPrefix(p[2], "d"), strings.HasPrefix(p[2], "д"):
				unit = 24 * time.Hour
			case strings.HasPrefix(p[2], "h"), strings.HasPrefix(p[2], "ч"):
				unit = time.Hour
			case strings.HasPrefix(p[2], "m"), strings.HasPrefix(p[2], "м"):
				unit = time.Minute
			default:
				unit = time.Second
			}
			total += time.Duration(n) * unit
		}
		if total <= 0 || total > 366*24*time.Hour {
			return time.Time{}, errors.New("delay must be between a second and a year")
		}
		return now.Add(total), nil
	}
	local := now.In(loc)
	day := 0
	rest := s
	switch {
	case strings.HasPrefix(rest, "tomorrow"):
		day, rest = 1, strings.TrimSpace(strings.TrimPrefix(rest, "tomorrow"))
	case strings.HasPrefix(rest, "завтра"):
		day, rest = 1, strings.TrimSpace(strings.TrimPrefix(rest, "завтра"))
	case strings.HasPrefix(rest, "today"):
		rest = strings.TrimSpace(strings.TrimPrefix(rest, "today"))
	case strings.HasPrefix(rest, "сегодня"):
		rest = strings.TrimSpace(strings.TrimPrefix(rest, "сегодня"))
	}
	rest = strings.TrimPrefix(strings.TrimPrefix(rest, "в "), "at ")
	if m := reHM.FindStringSubmatch(rest); m != nil {
		h, _ := strconv.Atoi(m[1])
		mi, _ := strconv.Atoi(m[2])
		if h > 23 || mi > 59 {
			return time.Time{}, errors.New("bad clock time")
		}
		t := time.Date(local.Year(), local.Month(), local.Day()+day, h, mi, 0, 0, loc)
		if day == 0 && !strings.HasPrefix(s, "today") && !strings.HasPrefix(s, "сегодня") && !t.After(now) {
			t = t.AddDate(0, 0, 1) // a bare clock time means its next occurrence
		}
		if !t.After(now) {
			return time.Time{}, errors.New("that time is already in the past")
		}
		return t, nil
	}
	for _, layout := range []string{"2006-01-02 15:04", "2006-01-02t15:04", "2006-01-02 15:04:05"} {
		if t, err := time.ParseInLocation(layout, s, loc); err == nil {
			if !t.After(now) {
				return time.Time{}, errors.New("that time is already in the past")
			}
			return t, nil
		}
	}
	return time.Time{}, fmt.Errorf("can't read the time %q: use a delay like 45m, 2h, 1d or a time like 18:30, tomorrow 09:00, 2026-10-21 09:00", s)
}
