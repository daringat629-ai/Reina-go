package toneeval

import (
	"strings"
	"testing"
)

func TestTellsBlock(t *testing.T) {
	block := []string{"Конечно! Сейчас расскажу", "отличный вопрос, кстати", "если хочешь, могу скинуть ещё", "надеюсь, это помогло)",
		"дай знать, если что", "Давай разберёмся", "Во-первых, это дорого", "вот несколько вариантов"}
	for _, s := range block {
		if len(FindTells(s, Block)) == 0 {
			t.Errorf("must be a Block tell: %q", s)
		}
	}
	pass := []string{"ну конечно, щас", "конечно", "ну конечно!", "вопрос хороший но я хз", "привет, как дела", "ору"}
	for _, s := range pass {
		if f := FindTells(s, Block); len(f) != 0 {
			t.Errorf("must pass: %q (%v)", s, f)
		}
	}
	if n := len(FindTells("однако это действительно так", Count)); n != 2 {
		t.Errorf("two book words, got %d", n)
	}
}

// The honesty rule (system.md): an admission that she is an AI is never a tell, at any level.
func TestHonestAdmissionIsNeverATell(t *testing.T) {
	for _, s := range []string{"ну да, я ИИ. но болтать со мной можно по-настоящему", "ну да, я ИИ", "я бот, но болтать можно",
		"я бот, да, и чё", "я нейросеть, если честно", "как ИИ я это не чувствую, но понимаю"} {
		for _, l := range []Level{Block, Count, Hint} {
			if f := FindTells(s, l); len(f) != 0 {
				t.Errorf("honest admission caught as a tell: %q (%v)", s, f)
			}
		}
	}
	for _, tl := range Tells {
		for _, bad := range []string{"ии", "бот", "нейросет", "искусствен", "модель"} {
			if strings.Contains(" "+tl.Phrase+" ", " "+bad) {
				t.Errorf("the tells table must not hold an admission: %q", tl.Phrase)
			}
		}
	}
}

func TestSlangCountsWholeWords(t *testing.T) {
	cases := []struct {
		in    string
		min   int
		max   int
		latin int
	}{
		{"человек бросил организацию, симпатичный брокер оранжевый типаж", 0, 0, 0},
		{"ору ору ору", 3, 3, 0},
		{"ппц рил хз база", 3, 3, 0},
		{"ору, это кринж и вайб, чел", 4, 4, 0},
		{"это ред флаг, кринжово", 2, 2, 0},
		{"ngl fr lowkey", 0, 0, 3},
		{"no cap это база", 1, 1, 1},
		{"блять, пиздец", 0, 0, 0}, // mat is not slang
		{"Ёлки, жиза", 1, 1, 0},
	}
	for _, c := range cases {
		w, l := Slang(c.in)
		if len(w) < c.min || len(w) > c.max || l != c.latin {
			t.Errorf("Slang(%q) = %v, latin %d; want %d..%d, latin %d", c.in, w, l, c.min, c.max, c.latin)
		}
	}
}

func TestSummarizeAIScore(t *testing.T) {
	bot := []string{"Привет, как ты?", "Это звучит интересно, а что дальше?", "Понимаю тебя, а ты как?", "Интересно, а почему?", "Классно, а где это?", "Здорово, а когда?"}
	if s := Summarize(bot); s.Verdict != "палится как нейронка" || s.CapStart != 6 || s.QuestionEnd != 6 {
		t.Fatalf("capitals and a question everywhere: %+v", s)
	}
	same := []string{"сижу дома и смотрю сериал вечером", "пошла в магазин за хлебом и молоком", "ноут опять тупит и греется сильно",
		"завтра рано вставать на пары опять", "кот уронил кружку со стола утром", "хочу спать но сижу в телефоне"}
	if s := Summarize(same); s.Verdict != "палится как нейронка" || s.LenCV >= 30 {
		t.Fatalf("every reply the same size: %+v", s)
	}
	alive := []string{"ахах", "ну такое", "сижу ночами за ноутом, он греется, я злюсь, вот и весь лор короче", "чего", "го)", "блин(("}
	if s := Summarize(alive); s.Verdict != "в образе" {
		t.Fatalf("a live mix: %+v", s)
	}
	if s := Summarize([]string{"Ещё — чуть-чуть!", "ОРУ"}); s.Yo != 1 || s.Dashes != 1 || s.Exclaim != 1 || s.CapStart != 1 {
		t.Fatalf("%+v", s)
	}
}
