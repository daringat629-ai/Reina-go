// Package toneeval scores a handful of replies by simple, explainable rules: how often she swears, whether she slips
// into assistant language or lists, emoji, and whether she repeats the same opening. It judges a voice without
// asking another model, so it is free and always gives the same answer for the same text.
package toneeval

import (
	"math"
	"strings"
	"unicode"
)

// Summary describes a set of replies.
type Summary struct {
	Replies int `json:"replies"`
	Swear   int `json:"swear"`   // replies with at least one swear word
	Formal  int `json:"formal"`  // replies with assistant-style phrases
	Lists   int `json:"lists"`   // replies with markdown or list lines
	Emoji   int `json:"emoji"`   // replies with an emoji
	Repeats int `json:"repeats"` // replies that open with the same word as an earlier reply
	AvgLen  int `json:"avg_len"` // average length in characters

	// what a picky reader notices first (see the tells table in tells.go)
	BookWords   int `json:"book_words"`   // replies with a book word («однако», «действительно»...)
	CapStart    int `json:"cap_start"`    // replies that begin with a capital letter (a capitals burst is not counted)
	QuestionEnd int `json:"question_end"` // replies that end with a question
	Exclaim     int `json:"exclaim"`      // replies that end with a single «!»
	Yo          int `json:"yo"`           // replies written with «ё» (people on a phone mostly type «е»)
	Dashes      int `json:"dashes"`       // replies with a long dash
	Slang       int `json:"slang"`        // trendy slang words in all replies
	SlangKinds  int `json:"slang_kinds"`  // how many different ones
	LenCV       int `json:"len_cv"`       // spread of the lengths in percent of the average (low = every reply the same size)

	Verdict string `json:"verdict"`
}

var swearStems = []string{"бля", "блят", "хуй", "хуе", "хуё", "хуя", "хуи", "хер", "пизд", "ебат", "ебан", "ебу", "ебл", "ебн", "ебал", "ебёт", "ёб",
	"заеб", "заёб", "охуе", "нахуй", "нахер", "сука", "суки", "сучк", "мудак", "мудил", "говн", "дерьм"}

// offlineFormal are extra assistant phrases counted only in this offline score. Some of them («как ии») are what an
// honest admission can sound like, so this list must never be used to stop a message (the guard uses Tells).
var offlineFormal = []string{"чем могу помочь", "конечно!", "с удовольствием", "обращайтесь", "как языковая модель", "как ии", "я не могу помочь",
	"к сожалению, я не", "рад помочь", "рада помочь", "уважаем", "будьте добры", "не стесняйтесь", "надеюсь, это помогло", "как искусственный интеллект"}

func tokens(s string) []string {
	return strings.FieldsFunc(strings.ToLower(s), func(r rune) bool { return !unicode.IsLetter(r) && !unicode.IsDigit(r) })
}

// Swears reports whether the text contains a swear word.
func Swears(s string) bool {
	for _, t := range tokens(s) {
		for _, st := range swearStems {
			if strings.HasPrefix(t, st) {
				return true
			}
		}
	}
	return false
}

func hasList(s string) bool {
	for _, line := range strings.Split(s, "\n") {
		l := strings.TrimSpace(line)
		if strings.HasPrefix(l, "- ") || strings.HasPrefix(l, "* ") || strings.HasPrefix(l, "#") || strings.HasPrefix(l, "**") || strings.Contains(l, "**") {
			return true
		}
		if len(l) > 2 && l[0] >= '1' && l[0] <= '9' && (l[1] == '.' || l[1] == ')') && l[2] == ' ' {
			return true
		}
	}
	return false
}

func hasEmoji(s string) bool {
	for _, r := range s {
		if r >= 0x1F000 || (r >= 0x2600 && r <= 0x27BF) {
			return true
		}
	}
	return false
}

// Summarize scores the replies (empty ones are ignored).
func Summarize(replies []string) Summary {
	var s Summary
	seen, kinds := map[string]bool{}, map[string]bool{}
	total := 0
	var lens []float64
	for _, r := range replies {
		r = strings.TrimSpace(r)
		if r == "" {
			continue
		}
		s.Replies++
		total += len([]rune(r))
		if Swears(r) {
			s.Swear++
		}
		low := strings.ToLower(r)
		formal := len(FindTells(r, Block)) > 0
		for _, p := range offlineFormal {
			if strings.Contains(low, p) {
				formal = true
				break
			}
		}
		if formal {
			s.Formal++
		}
		if len(FindTells(r, Count)) > 0 {
			s.BookWords++
		}
		if capStart(r) {
			s.CapStart++
		}
		end := strings.TrimRightFunc(r, func(c rune) bool { return unicode.IsSpace(c) || c == ')' || c == '(' })
		if strings.HasSuffix(end, "?") {
			s.QuestionEnd++
		}
		if strings.HasSuffix(end, "!") && !strings.HasSuffix(end, "!!") && !strings.HasSuffix(end, "?!") {
			s.Exclaim++
		}
		if strings.ContainsAny(r, "ёЁ") {
			s.Yo++
		}
		if strings.ContainsAny(r, "—–") {
			s.Dashes++
		}
		ws, _ := Slang(r)
		s.Slang += len(ws)
		for _, w := range ws {
			kinds[w] = true
		}
		lens = append(lens, float64(len([]rune(r))))
		if hasList(r) {
			s.Lists++
		}
		if hasEmoji(r) {
			s.Emoji++
		}
		if t := tokens(r); len(t) > 0 && len([]rune(t[0])) >= 3 {
			if seen[t[0]] {
				s.Repeats++
			}
			seen[t[0]] = true
		}
	}
	if s.Replies == 0 {
		s.Verdict = "нет ответов"
		return s
	}
	s.AvgLen = total / s.Replies
	s.SlangKinds = len(kinds)
	s.LenCV = lenCV(lens)
	switch {
	case s.Formal+s.Lists > 0:
		s.Verdict = "слишком формальная"
	case s.Replies >= 6 && (pct(s.CapStart, s.Replies) > 60 || pct(s.QuestionEnd, s.Replies) > 50 || pct(s.BookWords, s.Replies) >= 30 || s.LenCV < 30):
		s.Verdict = "палится как нейронка"
	case s.Repeats*2 >= s.Replies && s.Replies >= 3:
		s.Verdict = "шаблонная"
	case pct(s.Swear, s.Replies) > 40:
		s.Verdict = "переигрывает" // mat in almost every reply reads like a checklist (unless she is really angry: judge by hand)
	default:
		s.Verdict = "в образе"
	}
	return s
}

func pct(n, of int) int { return n * 100 / of }

// capStart: the reply begins with a capital letter, and it is not a capitals burst or an abbreviation («ОРУ», «ИИ»).
func capStart(s string) bool {
	w := strings.FieldsFunc(s, func(r rune) bool { return !unicode.IsLetter(r) })
	if len(w) == 0 {
		return false
	}
	r := []rune(w[0])
	if !unicode.IsUpper(r[0]) {
		return false
	}
	return len(r) == 1 || strings.ToUpper(w[0]) != w[0]
}

// lenCV is the standard deviation of the lengths in percent of their mean (0 for fewer than two).
func lenCV(l []float64) int {
	if len(l) < 2 {
		return 0
	}
	var sum float64
	for _, x := range l {
		sum += x
	}
	mean := sum / float64(len(l))
	if mean == 0 {
		return 0
	}
	var v float64
	for _, x := range l {
		v += (x - mean) * (x - mean)
	}
	return int(math.Sqrt(v/float64(len(l))) / mean * 100)
}
