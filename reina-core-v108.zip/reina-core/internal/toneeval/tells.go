package toneeval

import (
	"strings"
	"unicode"
)

// The one list of phrases that give an AI away in a Russian chat. The voice guard (internal/agent/guard.go) and the
// offline score below read the same table, so what is measured is what is stopped.
//
// NEVER put an honest admission here («я ИИ», «я бот», «я нейросеть», «как ИИ»): when someone sincerely asks, she
// admits she is an AI (system.md), and no filter may stand in the way of that. A test holds this.

// Level says what is done with a tell.
type Level int

const (
	Block Level = iota // a canonical assistant phrase: the guard sends the message back once
	Count              // a book word: one is human, two or more in a message are sent back once
	Hint               // a shape (a neat conclusion...): only measured, never blocked
)

// Tell is one phrase. Phrase is in normalized form (lower case, е for ё, words split by single spaces).
type Tell struct {
	Phrase string
	Level  Level
	Start  bool // counts only at the very start of the message
	Bang   bool // counts only when an exclamation mark follows it («конечно!»)
}

var Tells = []Tell{
	{Phrase: "конечно", Level: Block, Start: true, Bang: true},
	{Phrase: "отличный вопрос", Level: Block},
	{Phrase: "хороший вопрос", Level: Block},
	{Phrase: "интересный вопрос", Level: Block},
	{Phrase: "если хочешь могу", Level: Block},
	{Phrase: "если хочешь я могу", Level: Block},
	{Phrase: "надеюсь это помогло", Level: Block},
	{Phrase: "надеюсь помогла", Level: Block},
	{Phrase: "надеюсь помог", Level: Block},
	{Phrase: "чем могу помочь", Level: Block},
	{Phrase: "чем еще могу помочь", Level: Block},
	{Phrase: "рада помочь", Level: Block},
	{Phrase: "рад помочь", Level: Block},
	{Phrase: "с удовольствием помогу", Level: Block},
	{Phrase: "обращайся", Level: Block},
	{Phrase: "обращайтесь", Level: Block},
	{Phrase: "не стесняйся", Level: Block},
	{Phrase: "дай знать", Level: Block},
	{Phrase: "давай разберемся", Level: Block},
	{Phrase: "давай разберем", Level: Block},
	{Phrase: "вот несколько", Level: Block},
	{Phrase: "существует несколько", Level: Block},
	{Phrase: "во первых", Level: Block},
	{Phrase: "важно отметить", Level: Block},
	{Phrase: "стоит отметить", Level: Block},
	{Phrase: "я здесь чтобы", Level: Block},
	{Phrase: "понимаю твои чувства", Level: Block},
	{Phrase: "это совершенно нормально", Level: Block},

	{Phrase: "действительно", Level: Count},
	{Phrase: "безусловно", Level: Count},
	{Phrase: "вполне", Level: Count},
	{Phrase: "весьма", Level: Count},
	{Phrase: "зачастую", Level: Count},
	{Phrase: "в целом", Level: Count},
	{Phrase: "отчасти", Level: Count},
	{Phrase: "однако", Level: Count},
	{Phrase: "впрочем", Level: Count},
	{Phrase: "тем не менее", Level: Count},
	{Phrase: "звучит интересно", Level: Count},
	{Phrase: "звучит круто", Level: Count},
	{Phrase: "понимаю тебя", Level: Count},
	{Phrase: "это нормально", Level: Count},
	{Phrase: "это важно", Level: Count},
	{Phrase: "если что я рядом", Level: Count},

	{Phrase: "так что да", Level: Hint},
	{Phrase: "и знаешь что", Level: Hint},
}

// Normalize is the form tells and slang are matched in: lower case, е for ё, only letters and digits, single spaces.
func Normalize(s string) string {
	s = strings.ReplaceAll(strings.ToLower(s), "ё", "е")
	return strings.Join(strings.FieldsFunc(s, func(r rune) bool { return !unicode.IsLetter(r) && !unicode.IsDigit(r) }), " ")
}

// FindTells returns the tells of the given level found in s (each phrase once).
func FindTells(s string, level Level) []string {
	norm := " " + Normalize(s) + " "
	raw := strings.ReplaceAll(strings.ToLower(strings.TrimSpace(s)), "ё", "е")
	var out []string
	for _, t := range Tells {
		if t.Level != level {
			continue
		}
		switch {
		case t.Start:
			if !strings.HasPrefix(norm, " "+t.Phrase+" ") {
				continue
			}
			if t.Bang && !strings.HasPrefix(strings.TrimLeftFunc(strings.TrimPrefix(raw, t.Phrase), unicode.IsSpace), "!") {
				continue
			}
		case !strings.Contains(norm, " "+t.Phrase+" "):
			continue
		}
		out = append(out, t.Phrase)
	}
	return out
}

// --- slang ---

// slangSet are the trendy words that sound forced when piled up. Plain talk (лан, норм, ок, щас, че, типа, короч)
// is speech, not slang, and is not counted; neither is mat.
var slangSet = map[string]bool{
	"жиза": true, "имба": true, "изи": true, "краш": true, "симп": true, "рил": true, "тейк": true, "лор": true,
	"делулу": true, "скуф": true, "пикми": true, "нпс": true, "бро": true, "чел": true, "ору": true, "ор": true,
	"пц": true, "ппц": true, "жесть": true, "капец": true, "база": true, "гринфлаг": true, "редфлаг": true,
}

// slangStems are counted with any ending (кринж, кринжово, кринжанула...).
var slangStems = []string{"кринж", "вайб", "рофл", "токсик", "тильт", "хайп", "душнил", "задушнил", "чилл", "зашквар",
	"мидов", "байти", "забайти", "агри", "ливну", "базов"}

var latinSet = map[string]bool{
	"fr": true, "ngl": true, "lowkey": true, "highkey": true, "idk": true, "ig": true, "rn": true, "iykyk": true,
	"bruh": true, "bet": true, "mid": true, "based": true, "valid": true, "cooked": true, "aura": true, "npc": true,
	"delulu": true, "yapping": true, "glazing": true, "slay": true, "ick": true,
}

var latinPairs = []string{"no cap", "its giving", "it s giving", "touch grass", "skill issue", "say less", "him cook",
	"canon event", "lock in", "main character", "villain era"}

func isSlang(w string) bool {
	if slangSet[w] {
		return true
	}
	for _, st := range slangStems {
		if strings.HasPrefix(w, st) {
			return true
		}
	}
	return false
}

// Slang returns the trendy Russian slang words of s (every occurrence, in order) and how many English slang words
// it holds. Words are compared whole, so «человек», «брокер» or «организация» are never slang.
func Slang(s string) (words []string, latin int) {
	tok := strings.Fields(Normalize(s))
	for i, w := range tok {
		if w == "ред" && i+1 < len(tok) && tok[i+1] == "флаг" {
			words = append(words, "ред флаг")
			continue
		}
		if isSlang(w) {
			words = append(words, w)
		}
		if latinSet[w] {
			latin++
		}
	}
	norm := " " + strings.Join(tok, " ") + " "
	for _, p := range latinPairs {
		latin += strings.Count(norm, " "+p+" ")
	}
	return words, latin
}
