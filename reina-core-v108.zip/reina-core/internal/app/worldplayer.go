package app

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"orvi/internal/config"
	"orvi/internal/llm"
	"orvi/internal/mir"
	"orvi/internal/prompts"
	"orvi/internal/tools"
)

// worldPlayer is the model that plays for her inside the world: its own short history, its own model
// (world.model), the world tool and a notebook that survives restarts, so she remembers what she built and promised.
type worldPlayer struct {
	srv    *mir.Server
	client *llm.Client
	ps     *prompts.Store
	cfg    func() *config.Config
	tool   tools.Tool
	path   string // notes file

	mu   sync.Mutex
	hist []llm.Message
	wake chan string
}

func newWorldPlayer(srv *mir.Server, c *llm.Client, ps *prompts.Store, cfg func() *config.Config, d tools.Deps, dir string) *worldPlayer {
	reg := tools.NewRegistry(tools.WorldTool(d))
	t, _ := reg.Get("world")
	return &worldPlayer{srv: srv, client: c, ps: ps, cfg: cfg, tool: t, path: filepath.Join(dir, "notes.txt"), wake: make(chan string, 16)}
}

// Hear queues something that happened in the world chat.
func (w *worldPlayer) Hear(from, text string) {
	select {
	case w.wake <- fmt.Sprintf("%s пишет в чате мира: «%s»", from, text):
	default:
	}
}

func (w *worldPlayer) notes() string {
	b, _ := os.ReadFile(w.path)
	lines := strings.Split(strings.TrimSpace(string(b)), "\n")
	if len(lines) > 40 {
		lines = lines[len(lines)-40:]
	}
	return strings.Join(lines, "\n")
}

func (w *worldPlayer) addNote(s string) {
	f, err := os.OpenFile(w.path, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o600)
	if err != nil {
		return
	}
	defer f.Close()
	fmt.Fprintf(f, "%s %s\n", time.Now().Format("02.01 15:04"), strings.ReplaceAll(strings.TrimSpace(s), "\n", " "))
}

func (w *worldPlayer) Run(ctx context.Context) {
	idle := time.NewTimer(time.Hour)
	reset := func() {
		n := w.cfg().WorldThinkSecs
		if n <= 0 {
			n = 3600
		}
		idle.Reset(time.Duration(n) * time.Second)
	}
	reset()
	for {
		var event string
		select {
		case <-ctx.Done():
			return
		case event = <-w.wake:
		case <-idle.C:
			if len(w.srv.Humans()) > 0 && w.cfg().WorldThinkSecs > 0 {
				event = "Прошло немного времени. Осмотрись и сама реши, что делать: помочь игроку, строить, исследовать или просто поболтать."
			}
		}
		reset()
		if event != "" {
			func() {
				cctx, cancel := context.WithTimeout(ctx, 2*time.Minute)
				defer cancel()
				if err := w.turn(cctx, event); err != nil {
					log.Printf("world player: %v", err)
				}
			}()
		}
	}
}

// model is world.model; the word "light" means the cheap background model (llm.light_model, on its own endpoint).
func (w *worldPlayer) model() string {
	c := w.cfg()
	if strings.EqualFold(c.WorldModel, "light") && c.LightModel != "" {
		return c.LightModel
	}
	return c.WorldModel
}

func (w *worldPlayer) system() string {
	var b strings.Builder
	b.WriteString(w.ps.Get(prompts.CharacterBase))
	b.WriteString("\n\nСейчас ты в 3D-мире из блоков (как Minecraft) и играешь там как обычный игрок. Управляй собой инструментом world: ")
	b.WriteString("look (смотри вокруг), goto, follow, say (говорить в чате мира), build (построить целое здание одним вызовом: дом, башня, стена, пирамида, мост, площадка, фонарь, забор; она сама пойдёт и выложит блоки), compose (свой чертёж списком коробок), flatten (выровнять площадку), undo (отменить последнее), build_status, place, fill, blocks. Ты командуешь, а стройку исполняет сервер: задания встают в очередь и выполняются сами, поэтому давай сразу несколько заданий подряд и не жди каждого. Говори коротко и по-живому, как в игре, не пиши длинных текстов. ")
	b.WriteString("Строй по-настоящему: сначала look, чтобы выбрать ровное место, потом build; мелочи доделывай fill/place. Если важно запомнить (что построила, что обещала, где дом, кто что просил), напиши это в текстовом ответе после слов ЗАПОМНИТЬ: одной строкой.")
	if n := w.notes(); n != "" {
		b.WriteString("\n\nТвои заметки об этом мире:\n" + n)
	}
	if h := w.srv.Humans(); len(h) > 0 {
		b.WriteString("\n\nСейчас в мире: " + strings.Join(h, ", "))
	}
	return b.String()
}

func (w *worldPlayer) turn(ctx context.Context, event string) error {
	w.mu.Lock()
	defer w.mu.Unlock()
	w.hist = append(w.hist, llm.Message{Role: "user", Content: event})
	if len(w.hist) > 24 {
		w.hist = w.hist[len(w.hist)-24:]
		for len(w.hist) > 0 && w.hist[0].Role != "user" { // never start in the middle of a tool exchange
			w.hist = w.hist[1:]
		}
	}
	for step := 0; step < 8; step++ {
		m, err := w.client.Complete(llm.WithPurpose(ctx, "world"), llm.Request{System: w.system(), Messages: w.hist, Tools: []llm.ToolDef{w.tool.Def()}, Model: w.model()})
		if err != nil {
			return err
		}
		w.hist = append(w.hist, m)
		if len(m.ToolCalls) == 0 {
			w.finish(m.Content)
			return nil
		}
		for _, tc := range m.ToolCalls {
			var a tools.Args
			_ = json.Unmarshal([]byte(tc.Function.Arguments), &a)
			out, err := w.tool.Run(ctx, a)
			if err != nil {
				out = "ошибка: " + err.Error()
			}
			w.hist = append(w.hist, llm.Message{Role: "tool", ToolCallID: tc.ID, Content: out})
		}
	}
	return nil
}

// finish handles her closing text: a line after ЗАПОМНИТЬ goes to the notebook.
func (w *worldPlayer) finish(text string) {
	if i := strings.Index(text, "ЗАПОМНИТЬ"); i >= 0 {
		w.addNote(strings.TrimLeft(text[i+len("ЗАПОМНИТЬ"):], ": "))
	}
}
