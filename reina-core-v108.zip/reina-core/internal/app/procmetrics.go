package app

import (
	"context"
	"runtime"
	"time"

	"orvi/internal/config"
	"orvi/internal/maint"
	"orvi/internal/metrics"
	"orvi/internal/run"
)

// processMetrics refreshes the metrics about the program itself: how long it has been up, memory, goroutines, the
// loops that are running, the free space under data/ and how many warnings the config has. They answer "is she
// healthy" without opening the panel (alert on reina_data_disk_free_bytes or reina_config_warnings > 0).
func processMetrics(reg *metrics.Registry, sup *run.Supervisor, cfg *config.Config, started time.Time) {
	var m runtime.MemStats
	runtime.ReadMemStats(&m)
	reg.Set("reina_process_start_time_seconds", float64(started.Unix()), nil)
	reg.Set("reina_uptime_seconds", time.Since(started).Seconds(), nil)
	reg.Set("reina_goroutines", float64(runtime.NumGoroutine()), nil)
	reg.Set("reina_heap_bytes", float64(m.HeapAlloc), nil)
	reg.Set("reina_loops_running", float64(len(sup.Running())), nil)
	reg.Set("reina_config_warnings", float64(len(cfg.Warnings)), nil)
	if disk, err := maint.DiskOf(cfg.DataDir); err == nil {
		reg.Set("reina_data_disk_free_bytes", float64(disk.Free), nil)
		reg.Set("reina_data_disk_total_bytes", float64(disk.Total), nil)
	}
}

func processMetricsLoop(ctx context.Context, reg *metrics.Registry, sup *run.Supervisor, cfg func() *config.Config, started time.Time) {
	if started.IsZero() {
		started = time.Now()
	}
	for {
		processMetrics(reg, sup, cfg(), started)
		select {
		case <-ctx.Done():
			return
		case <-time.After(30 * time.Second):
		}
	}
}

func init() {
	helpTexts["reina_process_start_time_seconds"] = "Unix time when the program started"
	helpTexts["reina_uptime_seconds"] = "Seconds since the program started"
	helpTexts["reina_goroutines"] = "Goroutines in the process"
	helpTexts["reina_heap_bytes"] = "Heap in use, bytes"
	helpTexts["reina_loops_running"] = "Supervised background loops that are running"
	helpTexts["reina_config_warnings"] = "Warnings about config.toml (typos, values out of range); 0 is clean"
	helpTexts["reina_data_disk_free_bytes"] = "Free space on the disk that holds data/"
	helpTexts["reina_data_disk_total_bytes"] = "Size of the disk that holds data/"
}
