package app

import (
	"context"
	"errors"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"

	"orvi/internal/config"
	"orvi/internal/llm"
	"orvi/internal/metrics"
	"orvi/internal/usage"
)

type notes struct {
	mu   sync.Mutex
	msgs []string
}

func (n *notes) send(s string) { n.mu.Lock(); n.msgs = append(n.msgs, s); n.mu.Unlock() }
func (n *notes) all() []string {
	n.mu.Lock()
	defer n.mu.Unlock()
	return append([]string(nil), n.msgs...)
}

func TestLLMWatchAccountsAndAlerts(t *testing.T) {
	cfg := &config.Config{AlertsEnabled: true, DailyTokenLimit: 1000}
	reg := metrics.New()
	tr := usage.New(filepath.Join(t.TempDir(), "usage.json"))
	var n notes
	w := newLLMWatch(func() *config.Config { return cfg }, reg, tr, n.send)
	ctx := context.Background()

	w.ObserveLLM(ctx, llm.Event{Kind: "chat", Model: "m", Purpose: "reply", Chat: 5, HasChat: true,
		Usage: &llm.Usage{Model: "m", Purpose: "reply", Prompt: 700, Completion: 50, CachedPromptTokens: 600}})
	if in, out := tr.Today(); in != 700 || out != 50 {
		t.Fatalf("tally %d/%d", in, out)
	}
	if got := reg.Get("reina_llm_tokens_total", map[string]string{"model": "m", "purpose": "reply", "direction": "input"}); got != 700 {
		t.Fatalf("token metric %v", got)
	}
	if got := reg.Get("llm_usage_input_cache_hit", map[string]string{"model": "m", "chat": "5"}); got != 600 {
		t.Fatalf("cache metric %v", got)
	}
	if msgs := n.all(); len(msgs) != 0 {
		t.Fatalf("no warning yet: %v", msgs)
	}
	w.ObserveLLM(ctx, llm.Event{Kind: "chat", Model: "m", Purpose: "reply", Usage: &llm.Usage{Model: "m", Purpose: "reply", Prompt: 100, Completion: 10}})
	if msgs := n.all(); len(msgs) != 1 || !strings.Contains(msgs[0], "80%") {
		t.Fatalf("near-limit warning: %v", msgs)
	}
	w.ObserveLLM(ctx, llm.Event{Kind: "chat", Model: "m", Purpose: "reply", Usage: &llm.Usage{Model: "m", Purpose: "reply", Prompt: 300, Completion: 10}})
	if msgs := n.all(); len(msgs) != 2 || !strings.Contains(msgs[1], "дневной лимит") {
		t.Fatalf("limit warning: %v", msgs)
	}

	// four failures in a row: one alert; a success after it: one "fixed"
	for i := 0; i < 6; i++ {
		w.ObserveLLM(ctx, llm.Event{Kind: "chat", Err: errors.New("HTTP 502")})
	}
	w.ObserveLLM(ctx, llm.Event{Kind: "chat", Err: context.Canceled}) // her own cancellation is not the model's fault
	w.ObserveLLM(ctx, llm.Event{Kind: "chat"})
	msgs := n.all()
	if len(msgs) != 4 || !strings.Contains(msgs[2], "не отвечает") || !strings.Contains(msgs[3], "починилось") {
		t.Fatalf("alerts: %v", msgs)
	}
	if reg.Get("reina_llm_requests_total", map[string]string{"kind": "chat", "outcome": "error"}) != 7 {
		t.Fatal("request metric")
	}
}

func TestOwnerLineWithoutTelegramOnlyLogs(t *testing.T) {
	var o ownerLine
	o.Send("hello") // must not panic or block
	o.Wait(10 * time.Millisecond)
}
