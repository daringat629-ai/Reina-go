package app

import (
	"context"
	"errors"
	"strings"
	"sync"

	"orvi/internal/admin"
	"orvi/internal/llm"
)

// liveCall is the owner's voice call from the panel: speech in, one short spoken answer out. It keeps its own short memory of the call
// (not a Telegram chat) and uses no tools, so an answer comes back in a couple of seconds instead of waiting for the agent's queue.
type liveCall struct {
	mu     sync.Mutex
	hist   []llm.Message
	stt    func(ctx context.Context, audio []byte, filename string) (string, error)
	say    func(ctx context.Context, system string, msgs []llm.Message) (string, error)
	speak  func(ctx context.Context, text string) ([]byte, string, error) // nil = no voice
	system func() string
	hear   func(heard string) // told what was said (the brain's perception), may be nil
}

const callKeep = 16 // messages of the call she remembers

func callFilename(mime string) string {
	switch {
	case strings.Contains(mime, "ogg"):
		return "call.ogg"
	case strings.Contains(mime, "mp4"), strings.Contains(mime, "m4a"), strings.Contains(mime, "aac"):
		return "call.m4a"
	case strings.Contains(mime, "wav"):
		return "call.wav"
	}
	return "call.webm"
}

// Turn handles one recorded phrase.
func (c *liveCall) Turn(ctx context.Context, audio []byte, mime string) (admin.TalkResult, error) {
	heard, err := c.stt(ctx, audio, callFilename(mime))
	if err != nil {
		return admin.TalkResult{}, errors.New("не расслышала: " + err.Error())
	}
	heard = strings.TrimSpace(heard)
	if len([]rune(heard)) < 2 {
		return admin.TalkResult{Silent: true}, nil
	}
	if c.hear != nil {
		c.hear(heard)
	}
	c.mu.Lock()
	defer c.mu.Unlock() // one turn at a time: a second phrase waits for the first answer, so the history stays in order
	msgs := append(append([]llm.Message(nil), c.hist...), llm.Message{Role: "user", Content: heard})
	reply, err := c.say(ctx, c.system(), msgs)
	if err != nil {
		return admin.TalkResult{Heard: heard}, err
	}
	reply = strings.TrimSpace(reply)
	if r := []rune(reply); len(r) > 500 {
		reply = string(r[:500])
	}
	if reply == "" {
		return admin.TalkResult{Heard: heard, Silent: true}, nil
	}
	c.hist = append(msgs, llm.Message{Role: "assistant", Content: reply})
	if len(c.hist) > callKeep {
		c.hist = c.hist[len(c.hist)-callKeep:]
	}
	out := admin.TalkResult{Heard: heard, Reply: reply}
	if c.speak != nil {
		if b, m, err := c.speak(ctx, reply); err == nil && len(b) > 0 {
			out.Audio, out.Mime = admin.EncodeAudio(b), m
		}
	}
	return out, nil
}
