package app

import (
	"context"
	"errors"
	"fmt"
	"log"
	"strconv"
	"sync"
	"sync/atomic"
	"time"

	"orvi/internal/alerts"
	"orvi/internal/billing"
	"orvi/internal/config"
	"orvi/internal/llm"
	"orvi/internal/metrics"
	"orvi/internal/usage"
)

// llmWatch turns what the LLM client reports into metrics, the token tally (with its daily limit) and messages to
// the owner when the model stops answering or the budget runs out. It used to be six separate hooks on the client
// wired up with closures in main; now it is one observer with one place for each rule.
type llmWatch struct {
	cfg    func() *config.Config
	reg    *metrics.Registry
	usage  *usage.Tracker
	notify func(string) // a message to the owner (may be a no-op)

	bill atomic.Pointer[billing.Store] // where the cost of people's conversations is taken from (nil until the stores open)

	mu    sync.Mutex
	fails map[string]*alerts.Streak // one streak per model and kind, so a failing side model cannot mask or fake the main one
	gate  alerts.Gate
}

func (w *llmWatch) streak(e llm.Event) *alerts.Streak {
	w.mu.Lock()
	defer w.mu.Unlock()
	key := e.Kind + "/" + e.Model
	st := w.fails[key]
	if st == nil {
		st = &alerts.Streak{Threshold: 4}
		w.fails[key] = st
	}
	return st
}

func newLLMWatch(cfg func() *config.Config, reg *metrics.Registry, tr *usage.Tracker, notify func(string)) *llmWatch {
	return &llmWatch{cfg: cfg, reg: reg, usage: tr, notify: notify, fails: map[string]*alerts.Streak{}}
}

func (w *llmWatch) ObserveLLM(ctx context.Context, e llm.Event) {
	w.health(e)
	outcome := "ok"
	if e.Err != nil {
		outcome = "error"
	}
	w.reg.Inc("reina_llm_requests_total", 1, map[string]string{"kind": e.Kind, "outcome": outcome})
	w.reg.Observe("reina_llm_request_seconds", e.Duration.Seconds(), map[string]string{"kind": e.Kind})
	if e.Usage != nil {
		w.account(e)
	}
}

// health tells the owner once when the model keeps failing, and once when it works again.
func (w *llmWatch) health(e llm.Event) {
	st := w.streak(e)
	switch {
	case e.Err == nil:
		if st.OK() {
			w.notify(fmt.Sprintf("Папик, модель %s снова отвечает, всё починилось.", e.Model))
		}
	case errors.Is(e.Err, context.Canceled) || errors.Is(e.Err, usage.ErrHardLimit):
		// she stopped the request herself, or the budget refused it: the model is not at fault
	case w.cfg().AlertsEnabled:
		if st.Fail() && w.gate.Allow("llm/"+e.Kind+"/"+e.Model, time.Hour, time.Now()) {
			w.notify(fmt.Sprintf("Папик, модель %s не отвечает: %d ошибок подряд, последняя: %v. Проверь ключ и баланс у её провайдера.", e.Model, st.Count(), e.Err))
		}
	}
}

// account adds one request's tokens to the tally, the metrics and the owner's budget warnings.
func (w *llmWatch) account(e llm.Event) {
	u := *e.Usage
	limit := w.cfg().DailyTokenLimit
	crossed := w.usage.Add(u.Model, u.Prompt, u.Completion, limit)
	if !crossed && w.usage.NearLimit(limit) {
		w.notify(fmt.Sprintf("Папик, токены сегодня на исходе: потрачено 80%% лимита (%d). Дальше я буду экономнее; если надо больше, подними llm.daily_token_limit.", limit))
	}
	if crossed {
		w.notify(fmt.Sprintf("Папик, я потратила дневной лимит токенов (%d). Сама ничего начинать не буду до завтра, а на сообщения пока отвечаю. Если расход дойдёт до x%d, остановлюсь совсем.", limit, usage.HardFactor))
	}
	if e.HasChat {
		w.usage.AddChat(e.Chat, u.Model, u.Prompt, u.Completion)
		w.charge(e.Chat, u.Model, u.Prompt, u.Completion)
	}
	log.Printf("llm: %s request: prompt=%d completion=%d tokens", u.Purpose, u.Prompt, u.Completion)

	pl := map[string]string{"model": u.Model, "purpose": u.Purpose}
	w.reg.Inc("reina_llm_calls_total", 1, pl)
	w.reg.Inc("reina_llm_tokens_total", float64(u.Prompt), map[string]string{"model": u.Model, "purpose": u.Purpose, "direction": "input"})
	w.reg.Inc("reina_llm_tokens_total", float64(u.Completion), map[string]string{"model": u.Model, "purpose": u.Purpose, "direction": "output"})
	w.reg.Set("reina_llm_last_prompt_tokens", float64(u.Prompt), pl)

	// the names used by the bundled Grafana dashboard
	l := map[string]string{"model": u.Model}
	w.reg.Inc("llm_usage_input", float64(u.Prompt), l)
	w.reg.Inc("llm_usage_output", float64(u.Completion), l)
	w.reg.Set("llm_usage_input_gauge", float64(u.Prompt), l)
	w.reg.Set("llm_usage_output_gauge", float64(u.Completion), l)

	hit, miss := u.CachedPromptTokens, max(u.Prompt-u.CachedPromptTokens, 0)
	cl := map[string]string{"model": u.Model}
	if e.HasChat {
		cl["chat"] = strconv.FormatInt(e.Chat, 10)
	}
	w.reg.Inc("llm_usage_input_cache_hit", float64(hit), cl)
	w.reg.Inc("llm_usage_input_cache_miss", float64(miss), cl)
	w.reg.Set("llm_usage_input_cache_hit_gauge", float64(hit), l)
	w.reg.Set("llm_usage_input_cache_miss_gauge", float64(miss), l)
	if hit > 0 {
		w.reg.Inc("reina_llm_cached_tokens_total", float64(hit), pl)
		log.Printf("llm: %s request: %d prompt tokens came from the provider cache", u.Purpose, hit)
	}
}

// charge takes what a request in a person's chat cost from their balance (in tokens of the main model, each side at its price).
// The owner and groups are never charged; the billing store ignores chats it does not know.
func (w *llmWatch) charge(chat int64, model string, in, out int) {
	st := w.bill.Load()
	c := w.cfg()
	if st == nil || !c.BillingEnabled || chat <= 0 || c.IsOwner(chat) {
		return
	}
	p := PriceOf(c)(model)
	st.Spend(chat, billing.Credits(in, out, p.In, p.Out, c.PriceIn), time.Now())
}

// helpTexts are the descriptions of the metrics on /metrics.
var helpTexts = map[string]string{
	"reina_llm_requests_total":        "LLM requests by kind and outcome",
	"reina_tool_calls_total":          "Tool calls executed",
	"reina_llm_tokens_total":          "LLM tokens by model, purpose (reply/ask/diary/sleep/compact/image) and direction",
	"reina_llm_last_prompt_tokens":    "Prompt size of the last LLM request by purpose",
	"reina_sessions_active":           "Open conversation sessions",
	"reina_llm_request_seconds":       "LLM request duration by kind",
	"tool_call_response_time_seconds": "Tool call duration by tool and chat",
	"reina_turn_retries_total":        "Turns repeated after the model failed",
	"reina_app_restarts_total":        "Background loops restarted after a crash",
}
