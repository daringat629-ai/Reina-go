package app

import (
	"context"
	"path/filepath"
	"testing"
	"time"

	"orvi/internal/billing"
	"orvi/internal/config"
	"orvi/internal/llm"
	"orvi/internal/metrics"
	"orvi/internal/usage"
)

func TestPacksArePricedFromTheModelCost(t *testing.T) {
	c := &config.Config{PriceIn: 0.20, BillingMargin: 2.5, BillingStarUSD: 0.013, BillingRates: "USD=0.01262", BillingCurrency: "RUB", BillingPacks: "500000, 2000000,bad,0"}
	ps := PacksOf(c)
	if len(ps) != 2 || ps[0].Tokens != 500000 || ps[0].Stars != 20 || ps[0].Price != 20 || ps[1].Stars != 77 {
		t.Fatalf("%+v", ps)
	}
	c.PriceIn = 0
	if ps := PacksOf(c); ps[0].Stars != 0 {
		t.Fatal("no model price: nothing is sold rather than sold at a loss")
	}
}

func TestPeoplesRequestsAreChargedButNotTheOwnersOrGroups(t *testing.T) {
	c := &config.Config{PapikChatID: 1, BillingEnabled: true, LLMModel: "m", PriceIn: 0.20, PriceOut: 0.70}
	dir := t.TempDir()
	st := billing.Open(filepath.Join(dir, "b.json"))
	w := newLLMWatch(func() *config.Config { return c }, metrics.New(), usage.New(filepath.Join(dir, "u.json")), func(string) {})
	w.bill.Store(st)
	now := time.Now()
	st.Take(7, now, billing.Limits{Free: 0}) // no cap: free
	_, _ = st.AddTokens(7, 100000, 1, 0, "c", "pack", now)
	st.Take(8, now, billing.Limits{Free: 1})
	st.Take(8, now.Add(time.Minute), billing.Limits{Free: 1})
	_, _ = st.AddTokens(8, 100000, 1, 0, "d", "pack", now)
	st.Take(8, now.Add(2*time.Minute), billing.Limits{Free: 1}) // beyond the free one: from the balance
	for _, chat := range []int64{1, -100, 7, 8} {
		w.ObserveLLM(context.Background(), llm.Event{HasChat: true, Chat: chat, Usage: &llm.Usage{Model: "m", Prompt: 10000, Completion: 1000}})
	}
	if u := st.Get(7, now); u.Tokens != 100000 || u.AllTokens != 13500 {
		t.Fatalf("a free conversation is counted, not charged: %+v", u)
	}
	if u := st.Get(8, now); u.Tokens != 100000-13500 {
		t.Fatalf("a paid conversation takes the real cost: %+v", u)
	}
	c.BillingEnabled = false
	w.ObserveLLM(context.Background(), llm.Event{HasChat: true, Chat: 8, Usage: &llm.Usage{Model: "m", Prompt: 10000}})
	if u := st.Get(8, now); u.Tokens != 100000-13500 {
		t.Fatal("billing off: nothing is taken")
	}
}
