package app

import (
	"path/filepath"
	"strings"
	"testing"

	"orvi/internal/prompts"
)

// The voice test and the live call both start from ownerPersona: it must carry her character and looks, and her tone with him.
func TestOwnerPersonaCarriesCharacterAndTone(t *testing.T) {
	ps, err := prompts.NewStore(filepath.Join(t.TempDir(), "prompts"), prompts.Vars{CharacterName: "Рейна", PapikName: "Папик"})
	if err != nil {
		t.Fatal(err)
	}
	got := (&boot{ps: ps}).ownerPersona()
	for _, want := range []string{ps.Get(prompts.System), ps.Get(prompts.CharacterBase), "<your_appearance>", "</your_appearance>", ps.Text(prompts.ToneOwner, nil)} {
		if !strings.Contains(got, want) {
			t.Fatalf("persona is missing %.40q", want)
		}
	}
	if !strings.HasSuffix(got, "\n") {
		t.Fatalf("the caller appends its own instruction, so the persona must end with a newline")
	}
}
