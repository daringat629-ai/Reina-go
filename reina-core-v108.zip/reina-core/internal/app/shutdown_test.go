package app

import (
	"context"
	"sync/atomic"
	"testing"
	"time"

	"orvi/internal/run"
)

func TestShutdownDoesNotHangOnAStuckLoop(t *testing.T) {
	sup := &run.Supervisor{}
	release := make(chan struct{})
	defer close(release)
	started := make(chan struct{})
	sup.Go(context.Background(), "stuck", func(context.Context) { close(started); <-release })
	<-started
	done := make(chan struct{})
	go func() {
		_ = shutdown(sup, &ownerLine{}, 100*time.Millisecond, func(int) { t.Error("watchdog must not fire yet") })
		close(done)
	}()
	select {
	case <-done:
	case <-time.After(5 * time.Second):
		t.Fatal("shutdown hung on a loop that ignores its context")
	}
}

func TestShutdownWaitsForPoliteLoops(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	sup := &run.Supervisor{}
	var finished atomic.Bool
	sup.Go(ctx, "polite", func(ctx context.Context) { <-ctx.Done(); time.Sleep(50 * time.Millisecond); finished.Store(true) })
	time.Sleep(10 * time.Millisecond)
	cancel()
	_ = shutdown(sup, &ownerLine{}, 5*time.Second, func(int) {})
	if !finished.Load() {
		t.Fatal("shutdown returned before the loop finished its work")
	}
}

func TestWatchdogFiresAndCanBeDisarmed(t *testing.T) {
	var fired atomic.Int32
	armWatchdog(20*time.Millisecond, func(c int) { fired.Add(int32(c)) })
	time.Sleep(100 * time.Millisecond)
	if fired.Load() != 1 {
		t.Fatalf("fired = %d", fired.Load())
	}
	armWatchdog(20*time.Millisecond, func(int) { fired.Add(10) })()
	time.Sleep(60 * time.Millisecond)
	if fired.Load() != 1 {
		t.Fatalf("disarmed watchdog fired: %d", fired.Load())
	}
}
