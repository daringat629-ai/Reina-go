package app

import (
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"orvi/internal/config"
	"orvi/internal/metrics"
	"orvi/internal/run"
)

func TestProcessMetricsAreExposed(t *testing.T) {
	reg := metrics.New()
	cfg, _ := config.Parse("[misc]\nbogus = 1\n")
	cfg.DataDir = t.TempDir()
	processMetrics(reg, &run.Supervisor{}, cfg, time.Now().Add(-time.Minute))
	rec := httptest.NewRecorder()
	reg.Handler().ServeHTTP(rec, httptest.NewRequest("GET", "/metrics", nil))
	for _, want := range []string{"reina_data_disk_free_bytes", "reina_goroutines", "reina_loops_running 0", "reina_config_warnings 1"} {
		if !strings.Contains(rec.Body.String(), want) {
			t.Fatalf("%q not exposed:\n%s", want, rec.Body.String())
		}
	}
}
