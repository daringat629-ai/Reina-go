package app

import "orvi/internal/advice"

// adviceForOwner is her questions to people as the owner's app shows them: newest first, with what people said.
func adviceForOwner(box *advice.Box) any {
	all := box.All()
	out := make([]map[string]any, 0, len(all))
	for i := len(all) - 1; i >= 0; i-- {
		q := all[i]
		var said []string
		for _, a := range q.Answers {
			said = append(said, a.Name+": "+a.Text)
		}
		out = append(out, map[string]any{"text": q.Text, "conclusion": q.Conclusion, "answers": len(q.Answers), "said": said})
	}
	return out
}
