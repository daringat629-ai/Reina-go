package app

import (
	"os"
	"path/filepath"
	"testing"

	"orvi/internal/config"
)

func TestOwnerMayChangeOnlyPricesAndLimits(t *testing.T) {
	p := filepath.Join(t.TempDir(), "config.toml")
	_ = os.WriteFile(p, []byte("[billing]\nmargin = 2.5\n"), 0o600)
	if err := setOwnerSetting(p, "billing", "margin", "3"); err != nil {
		t.Fatal(err)
	}
	if err := setOwnerSetting(p, "llm", "api_key", "x"); err == nil {
		t.Fatal("keys are never changed from the app")
	}
	if err := setOwnerSetting(p, "billing", "margin", "abc"); err == nil {
		t.Fatal("a bad number is refused")
	}
	b, _ := os.ReadFile(p)
	c, err := config.Load(p)
	if err != nil || c.BillingMargin != 3 {
		t.Fatalf("%s %v %v", b, err, c.BillingMargin)
	}
	if s := settingsFor(c); len(s) != len(ownerSettings) || s[3].Value != "3" {
		t.Fatalf("%+v", s)
	}
}
