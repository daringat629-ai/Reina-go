package app

import (
	"context"
	"errors"
	"fmt"
	"log"
	"math"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"orvi/internal/alerts"
	"orvi/internal/billing"
	"orvi/internal/body"
	"orvi/internal/brain"
	"orvi/internal/config"
	"orvi/internal/cortex"
	"orvi/internal/diary"
	"orvi/internal/learn"
	"orvi/internal/life"
	"orvi/internal/maint"
	"orvi/internal/metrics"
	"orvi/internal/mind"
	"orvi/internal/store"
	"orvi/internal/telegram"
	"orvi/internal/tools"
	"orvi/internal/usage"
)

// The housekeeping of the program: her sleep (memory consolidation), the disk and the backups, the daily report and
// the watch over Telegram. Each is one loop run by the Supervisor.

// sleepLoop runs one consolidation cycle a minute after start and then every 6 hours. Between the cycles it gives
// diary entries without an embedding (new consolidated pages, entries made before the embedding model changed) their
// vectors, a few at a time, so recalling a memory never has to wait for that during a conversation.
func sleepLoop(ctx context.Context, d *diary.Diary, cfg func() *config.Config) {
	timer := time.NewTimer(time.Minute)
	defer timer.Stop()
	index := time.NewTicker(5 * time.Minute)
	defer index.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-index.C:
			if n, err := d.Reindex(ctx, 20); err != nil && !errors.Is(err, context.Canceled) {
				log.Printf("diary: reindex: %v", err)
			} else if n > 0 {
				log.Printf("diary: %d entries got their embedding", n)
			}
		case <-timer.C:
			if err := d.Consolidate(ctx, cfg().SleepMaxTime); err != nil && !errors.Is(err, context.Canceled) {
				log.Printf("reina: sleep consolidation: %v", err)
			}
			timer.Reset(6 * time.Hour)
		}
	}
}

// maintLoop watches the disk (clears the caches when it runs low, warns the owner once a day) and makes a daily
// backup. It starts quietly: the first look is a minute after start.
func maintLoop(ctx context.Context, cfg func() *config.Config, cfgPath string, notify func(string), clean func(context.Context, bool) string) {
	var warnedDay string
	var lastClean, lastForced time.Time
	timer := time.NewTimer(time.Minute)
	defer timer.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-timer.C:
		}
		timer.Reset(10 * time.Minute)
		c := cfg()
		if !c.MaintEnabled {
			continue
		}
		if time.Since(lastClean) > 24*time.Hour { // a quiet daily tidy-up so the disk never fills up unnoticed
			lastClean = time.Now()
			log.Printf("reina: daily cleanup: %s", clean(ctx, false))
		}
		if d, err := maint.DiskOf(c.DataDir); err == nil && d.Low(c.DiskWarnPercent) {
			cleaned := ""
			if time.Since(lastForced) > time.Hour { // a thorough pass at most once an hour
				lastForced = time.Now()
				if rep := clean(ctx, true); !strings.HasPrefix(rep, "Чистить нечего") {
					cleaned = " " + rep
					d, _ = maint.DiskOf(c.DataDir)
				}
			}
			if day := time.Now().Format("2006-01-02"); warnedDay != day && d.Low(c.DiskWarnPercent) {
				warnedDay = day
				log.Printf("reina: disk is low: %s free of %s", maint.Human(d.Free), maint.Human(d.Total))
				hogs := ""
				if top := biggestOnDisk(ctx); top != "" {
					hogs = " Больше всего места жрут: " + top + "."
				}
				notify(fmt.Sprintf("Папик, на диске почти нет места: свободно %s из %s (%.0f%%).%s%s Надо удалить ненужное, например старые архивы.", maint.Human(d.Free), maint.Human(d.Total), d.Percent(), cleaned, hogs))
			}
		}
		if c.BackupEnabled {
			dir := maint.BackupDirOf(c)
			if list := maint.Backups(dir); len(list) == 0 || time.Since(list[0].Time) > 24*time.Hour {
				if p, err := maint.Backup(maint.Sources(c, cfgPath), dir, c.BackupKeep, time.Now()); err != nil {
					log.Printf("reina: backup: %v", err)
				} else {
					log.Printf("reina: backup written: %s", p)
				}
			}
		}
	}
}

// biggestOnDisk names the biggest top-level directories of the root filesystem (empty if du is unavailable).
func biggestOnDisk(ctx context.Context) string {
	c, cancel := context.WithTimeout(ctx, 90*time.Second)
	defer cancel()
	top, err := maint.Biggest(c, "/", 5)
	if err != nil || len(top) == 0 {
		return ""
	}
	var parts []string
	for _, d := range top {
		parts = append(parts, fmt.Sprintf("%s (%s)", d.Path, maint.Human(d.Bytes)))
	}
	return strings.Join(parts, ", ")
}

// reportText is the daily message to the owner about yesterday.
func reportText(y usage.Day, week []usage.Day, free *maint.Disk) string {
	var b strings.Builder
	fmt.Fprintf(&b, "Папик, отчёт за %s: %s токенов на входе, %s на выходе, %d запросов", y.Day, kilo(y.In), kilo(y.Out), y.Calls)
	if y.HasPrice {
		fmt.Fprintf(&b, ", примерно $%.2f", y.USD)
	}
	b.WriteString(".")
	var max usage.Day
	for _, d := range week {
		if d.In+d.Out > max.In+max.Out {
			max = d
		}
	}
	if len(week) > 2 && max.Day != "" && max.Day != y.Day {
		fmt.Fprintf(&b, " Самый жирный день недели: %s (%s токенов).", max.Day, kilo(max.In+max.Out))
	}
	if free != nil {
		fmt.Fprintf(&b, " Диск: свободно %s из %s.", maint.Human(free.Free), maint.Human(free.Total))
	}
	return b.String()
}

func kilo(n int64) string {
	switch {
	case n >= 1_000_000:
		return fmt.Sprintf("%.1fM", float64(n)/1e6)
	case n >= 1000:
		return fmt.Sprintf("%dk", n/1000)
	}
	return fmt.Sprint(n)
}

// reportLoop sends the daily report once the configured hour has come (and never twice a day, even across restarts).
func reportLoop(ctx context.Context, cfg func() *config.Config, tr *usage.Tracker, notify func(string)) {
	t := time.NewTicker(5 * time.Minute)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
		}
		c := cfg()
		if !c.ReportEnabled {
			continue
		}
		if time.Now().In(c.Location()).Hour() < c.ReportHour {
			continue
		}
		price := PriceOf(c)
		y, ok := tr.DueReport(price)
		if !ok {
			continue
		}
		var disk *maint.Disk
		if d, err := maint.DiskOf(c.DataDir); err == nil {
			disk = &d
		}
		week := tr.Days(8, price)
		notify(reportText(y, week[:max(len(week)-1, 0)], disk))
	}
}

// PriceOf maps a model name to its configured prices (zero when unknown).
func PriceOf(c *config.Config) func(string) usage.Prices {
	return func(m string) usage.Prices {
		switch {
		case m == c.LLMModel:
			return usage.Prices{In: c.PriceIn, Out: c.PriceOut}
		case c.LightModel != "" && m == c.LightModel:
			return usage.Prices{In: c.LightPriceIn, Out: c.LightPriceOut}
		case c.FastModel != "" && m == c.FastModel:
			return usage.Prices{In: c.FastPriceIn, Out: c.FastPriceOut}
		}
		return usage.Prices{}
	}
}

// USDPerUnit is what one unit of the QR currency is worth in USD (from billing.rates USD=...; 1 when the currency is USD; 0 = unknown).
func USDPerUnit(c *config.Config) float64 {
	if strings.EqualFold(c.BillingCurrency, "USD") {
		return 1
	}
	for _, kv := range strings.Split(c.BillingRates, ",") {
		if code, v, ok := strings.Cut(strings.TrimSpace(kv), "="); ok && strings.EqualFold(strings.TrimSpace(code), "USD") {
			f, _ := strconv.ParseFloat(strings.TrimSpace(v), 64)
			return f
		}
	}
	return 0
}

// LimitsOf is the daily limits the config sets (free conversations, the old plans, the free token cap).
func LimitsOf(c *config.Config) billing.Limits {
	return billing.Limits{Free: int(c.BillingFreePerDay), Plus: int(c.BillingPlusPerDay), Max: int(c.BillingMaxPerDay), FreeTokens: c.BillingFreeTokens, GlobalFree: int(c.BillingGlobalFree)}
}

// PacksOf is the token packs on sale with their prices worked out from what the tokens cost: the main model's input price
// times billing.margin, in Stars by billing.star_usd and in the QR currency by the USD rate in billing.rates.
func PacksOf(c *config.Config) []billing.Pack {
	usdPerUnit := USDPerUnit(c)
	var out []billing.Pack
	for _, f := range strings.Split(c.BillingPacks, ",") {
		n, err := strconv.ParseInt(strings.TrimSpace(f), 10, 64)
		if err != nil || n <= 0 {
			continue
		}
		stars, price := billing.PackPrice(n, c.PriceIn, c.BillingMargin, c.BillingStarUSD, usdPerUnit)
		out = append(out, billing.Pack{Tokens: n, Stars: stars, Price: price})
	}
	return out
}

// watchLoop checks Telegram once a minute and tells the owner about trouble (each kind at most every 2 hours).
func watchLoop(ctx context.Context, cfg func() *config.Config, tg telegram.Client, notify func(string)) {
	hs, ok := tg.(telegram.HealthSource)
	if !ok {
		return
	}
	var gate alerts.Gate
	t := time.NewTicker(time.Minute)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
		}
		if !cfg().AlertsEnabled {
			continue
		}
		now := time.Now()
		if msg := tgTrouble(hs.Health(), now); msg != "" && gate.Allow("tg", 2*time.Hour, now) {
			notify("Папик, проблема: " + msg + ".")
		}
	}
}

// studyLoop makes her sit down in her room and study: every so often (and not while she sleeps) she reads the next topic,
// preferring the one that explains the part of her that is loudest now. She never needs to leave the flat for it.
func studyLoop(ctx context.Context, d tools.Deps, cfg func() *config.Config) {
	timer := time.NewTimer(2 * time.Minute)
	defer timer.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-timer.C:
		}
		c := cfg()
		every := c.LearnEvery
		if every < time.Minute {
			every = time.Minute
		}
		timer.Reset(every)
		if !c.LearnEnabled || d.Learn == nil {
			continue
		}
		hot := ""
		if d.Body != nil {
			if d.Body.Snapshot().Doing == body.Asleep {
				continue
			}
			if d.Sense != nil {
				if at := d.Sense.Snapshot().Attended(); len(at) > 0 {
					hot = learn.AreaOf(at[0].ID)
				}
			}
		}
		t, ok := d.Learn.Next(hot)
		if !ok && !exploring(d.Brain) { // the seeds are learned: she reads on only when curiosity is what her brain wants most
			continue
		}
		sctx, cancel := context.WithTimeout(ctx, 30*time.Second)
		var l learn.Lesson
		var err error
		if ok {
			l, err = d.Learn.Study(sctx, t)
		} else {
			l, err = d.Learn.Wonder(sctx)
			t.Title = l.Title
		}
		if err == nil && !ok {
			rememberLesson(sctx, d, l)
		}
		cancel()
		if err != nil {
			log.Printf("learn: %s: %v", t.Title, err)
			continue
		}
		log.Printf("learn: she studied %q (%s)", l.Title, l.Area)
	}
}

// lifeLoop is her will: every few seconds the things in her room fall or settle, and when she is free she decides by herself
// what to do (walk, sit, lie down, look out of the window) from her body, her mood and her drives.
func lifeLoop(ctx context.Context, d tools.Deps, cfg func() *config.Config) {
	d.Life.WarmUp(time.Now())
	hb := newDailyHabits(cfg().DataDir)
	tick := time.NewTicker(5 * time.Second)
	defer tick.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-tick.C:
		}
		d.Life.Room.Step(5)
		if !cfg().RoomLifeEnabled {
			continue
		}
		d.Life.Chaos(time.Now(), 5)
		in := life.Inputs{Drives: map[string]float64{}}
		if d.Body != nil {
			b := d.Body.Snapshot()
			in.Fatigue, in.Sleep, in.Stress = b.Fatigue, b.Sleep, b.Stress
		}
		if d.Feel != nil {
			in.Valence = d.Feel.Snapshot().Valence
		}
		if d.Brain != nil {
			for _, dr := range d.Brain.Drives() {
				in.Drives[dr.Name] = dr.Value
			}
		}
		if hb.morningCoffee(d, time.Now(), cfg().Location()) {
			log.Printf("life: утренний кофе")
		}
		h := time.Now().In(cfg().Location()).Hour()
		in.Night = h >= 23 || h < 7
		in.Studying = d.Learn != nil && time.Since(d.Learn.Last()) < 6*time.Minute
		if a := d.Life.Decide(time.Now(), in); a != nil {
			log.Printf("life: %s (%s): %s", a.Goal, a.Reason, a.Outcome)
		}
	}
}

// newCortex builds the region brain (nil when switched off).
func newCortex(cfg *config.Config) *cortex.Cortex {
	if !cfg.CortexEnabled {
		return nil
	}
	n := cfg.CortexNeurons
	if n < 50000 {
		n = 50000
	}
	return cortex.New(filepath.Join(cfg.DataDir, "cortex.json"), n, 20201027)
}

// cortexLoop is the pulse of her region brain: every few seconds it is shown her body, senses, feelings and what she could do,
// and what it concludes (leanings of the will, arousal, threat) flows back into her decisions and her prompt.
func cortexLoop(ctx context.Context, d tools.Deps, cfg func() *config.Config) {
	tick := time.NewTicker(3 * time.Second)
	defer tick.Stop()
	saveAt := time.Now()
	var phoneProbe time.Time
	for {
		select {
		case <-ctx.Done():
			d.Cortex.Save()
			if d.Mind != nil {
				d.Mind.Close()
			}
			return
		case <-tick.C:
		}
		now := time.Now()
		loc := cfg().Location()
		in := cortex.Inputs{Hour: float64(now.In(loc).Hour()) + float64(now.In(loc).Minute())/60, Channels: map[string]float64{}, Surprise: map[string]float64{}, Attended: map[string]bool{}, Temp: 36.8, Oxygen: 1}
		if d.Body != nil {
			b := d.Body.Snapshot()
			in.Heart, in.Breath, in.Oxygen, in.Glucose, in.Water, in.Temp = b.Heart, b.Breath, b.Oxygen, b.Glucose, b.Water, b.Temp
			in.Fatigue, in.Sleep, in.Pain, in.Stress = b.Fatigue, b.Sleep, b.Pain, b.Stress
			in.Light, in.Noise, in.Scent = b.Light, b.Noise, b.Scent
			in.Hunger, in.Thirst = b.Hunger(), b.Thirst()
			for k, v := range d.Body.Inputs() {
				in.Channels[k] = v
			}
		}
		if d.Sense != nil {
			s := d.Sense.Snapshot()
			for _, sn := range s.Sensors {
				in.Surprise[sn.ID] = sn.Surprise
			}
			for _, at := range s.Attended() {
				in.Attended[at.ID] = true
			}
			for k, v := range d.Sense.Inputs() {
				in.Channels[k] = math.Max(in.Channels[k], v)
			}
		}
		if d.Feel != nil {
			f := d.Feel.Snapshot()
			in.Valence, in.Arousal, in.Control = f.Valence, f.Arousal, f.Control
			for k, v := range d.Feel.Inputs() {
				in.Channels[k] = math.Max(in.Channels[k], v)
			}
		}
		if d.Mood != nil {
			in.Mood = float64(d.Mood.Level()) / 100
		}
		h := now.In(loc).Hour()
		if h >= 23 || h < 7 {
			in.Channels["night"] = 1
		}
		if d.Brain != nil {
			for _, dr := range d.Brain.Drives() {
				in.Channels["drive_"+dr.Name] = dr.Value
			}
		}
		if d.Life != nil {
			in.Posture = d.Life.Posture()
			in.Moving = d.Life.Moving(now)
			in.Sleeping = d.Life.Sleeping(now)
			in.X, in.Z = d.Life.Pos()
			if a, _ := d.Life.Current(now); a != nil {
				in.ActionID, in.ActionKind, in.ActionOK = a.ID, a.Goal, a.OK
			}
			for _, o := range d.Life.Options() {
				in.Choices = append(in.Choices, cortex.Choice{Goal: o.Goal, U: o.U})
			}
			in.Alone = in.Channels["social"] < .3 && in.Channels["owner"] < .3
		}
		if t := strings.TrimSpace(cfg().PhoneADB); t != "" { // a phone she had and lost is felt as a small, capped rise of stress
			if now.Sub(phoneProbe) > 2*time.Minute {
				phoneProbe = now
				go tools.Phone.Probe(ctx, t, now)
			}
			if lost, _ := tools.Phone.Lost(now); lost {
				in.Stress = math.Max(in.Stress, .3)
			}
		}
		out := d.Cortex.Step(in)
		if d.Mind != nil && (in.Sleeping || (in.Alone && in.Channels["quiet"] > .5)) { // the hippocampus replays: she examines herself
			d.Mind.Dream(10+10*out.Replayed, mindConfig(cfg()))
		}
		if d.Life != nil {
			d.Life.SetBrain(out.Bias)
		}
		if now.Sub(saveAt) > 5*time.Minute {
			saveAt = now
			d.Cortex.Save()
			if d.Mind != nil {
				d.Mind.Save()
			}
		}
	}
}

// newMind opens her own mind (nil when switched off).
func newMind(cfg *config.Config) *mind.Mind {
	if !cfg.MindEnabled {
		return nil
	}
	return mind.New(filepath.Join(cfg.DataDir, "mind.json"), 20201028)
}

// mindConfig is what the owner set for her own mind.
func mindConfig(c *config.Config) mind.Config {
	return mind.Config{AnswerAlone: c.MindAnswerAlone, WithOwner: c.MindWithOwner, MinTrials: c.MindMinTrials, HitRate: c.MindHitRate, MinSim: c.MindMinSim, Compose: c.MindCompose, Reservoir: c.MindReservoir}
}

// dailyHabits are the small routines of her day that she does by herself, remembered across restarts.
type dailyHabits struct {
	path  string
	saver store.Saver
	Day   struct {
		Coffee string `json:"coffee"` // the day (YYYY-MM-DD) she had her morning coffee
	}
}

func newDailyHabits(dir string) *dailyHabits {
	h := &dailyHabits{path: filepath.Join(dir, "habits.json"), saver: store.Saver{What: "habits"}}
	store.Load("habits", h.path, &h.Day)
	return h
}

// morningCoffee: between 7 and 11 o'clock, once a day, when she is awake she makes coffee and sits down at her desk with it.
// It reports whether she did it now.
func (h *dailyHabits) morningCoffee(d tools.Deps, now time.Time, loc *time.Location) bool {
	t := now.In(loc)
	day := t.Format("2006-01-02")
	if t.Hour() < 7 || t.Hour() >= 11 || h.Day.Coffee == day || d.Body == nil {
		return false
	}
	if d.Life != nil && d.Life.Sleeping(now) {
		return false
	}
	if _, err := d.Body.Do("coffee", 0); err != nil {
		return false
	}
	h.Day.Coffee = day
	_ = h.saver.Save(h.path, &h.Day)
	if d.Life != nil {
		d.Life.Do("desk", "утренний кофе: хочу выпить и сесть за стол", now)
	}
	return true
}

// exploring says whether curiosity is the strongest drive of her brain right now.
func exploring(b *brain.Brain) bool {
	if b == nil {
		return false
	}
	ds := b.Drives()
	return len(ds) > 0 && ds[0].Name == "explore" && ds[0].Value > .2
}

// rememberLesson writes what she read of her own accord into the diary, so it can come back as a memory ("I read that...").
func rememberLesson(ctx context.Context, d tools.Deps, l learn.Lesson) {
	if d.Diary == nil || d.Diary.LLM == nil || l.Title == "" {
		return
	}
	body := "Я сама прочитала про «" + l.Title + "»: " + l.Summary
	emb, err := d.Diary.LLM.Embedding(ctx, body)
	if err != nil {
		return
	}
	if err := d.Diary.Save(diary.Entry{ID: d.Diary.NewID(), Meta: diary.Metadata{Embedding: emb}, Body: body}); err != nil {
		log.Printf("learn: diary: %v", err)
	}
}

// funnelLoop keeps the business numbers (new people, talkers, returners, the limit wall, payments) fresh in /metrics.
// They are computed from the accounts every minute, so Grafana and Prometheus always show the real funnel.
func funnelLoop(ctx context.Context, cfg func() *config.Config, st *billing.Store, reg *metrics.Registry) {
	publish := func() {
		c := cfg()
		l := LimitsOf(c)
		st.Funnel(time.Now(), c.Location(), l).Publish(reg)
	}
	publish()
	t := time.NewTicker(time.Minute)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
			publish()
		}
	}
}
