package app

import (
	"context"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"strings"
	"time"

	"orvi/internal/config"
	"orvi/internal/maint"
	"orvi/internal/telegram"
)

// cleaner frees disk space without touching anything that makes her "her" (diary, memory, prompts, config).
type cleaner struct {
	cfg     func() *config.Config
	tg      telegram.Client
	LogFile string // the text log (reina.log): emptied when it grows past 30 MB
}

// Run deletes: files she sent more than an hour ago (tdlib/outbox keeps a copy of every one), old update uploads,
// cached image/document descriptions, and media that tdlib cached and nobody opened for a while. force cleans
// everything older than a day instead of the configured ages. It returns a one-paragraph report in Russian.
func (c cleaner) Run(ctx context.Context, force bool) string {
	cf := c.cfg()
	now := time.Now()
	before, _ := maint.DiskOf(cf.DataDir)
	var parts []string
	var total int64
	add := func(what string, files int, bytes int64) {
		if bytes > 0 || files > 0 {
			parts = append(parts, fmt.Sprintf("%s: %s", what, mb(bytes)))
			total += bytes
		}
	}

	if st, err := os.Stat(c.LogFile); c.LogFile != "" && err == nil && st.Size() > maxLog {
		if os.Truncate(c.LogFile, 0) == nil {
			add("лог", 1, st.Size())
		}
	}
	n, b := maint.CleanOld(filepath.Join(cf.TDLibDir, "outbox"), time.Hour, now)
	add("отправленные файлы", n, b)
	n, b = maint.CleanOld(filepath.Join(cf.DataDir, "update"), 24*time.Hour, now)
	add("загрузки обновлений", n, b)

	prof := filepath.Join(cf.DataDir, "browser-profile")
	var bn int
	var bb int64
	for _, sub := range []string{"Default/Cache", "Default/Code Cache", "Default/GPUCache", "Default/Service Worker/CacheStorage", "ShaderCache", "GrShaderCache"} {
		n, b := maint.CleanOld(filepath.Join(prof, sub), 24*time.Hour, now)
		bn, bb = bn+n, bb+b
	}
	n, b = maint.CleanOld(filepath.Join(cf.DataDir, "workspace", "browser"), 24*time.Hour, now) // her screenshots
	add("кэш браузера и скриншоты", bn+n, bb+b)

	age := time.Duration(cf.CacheDays) * 24 * time.Hour
	if force && (age <= 0 || age > 24*time.Hour) {
		age = 24 * time.Hour
	}
	if age > 0 {
		n, b = maint.CleanOld(filepath.Join(cf.DataDir, "cache"), age, now)
		add("кэш описаний", n, b)
	}
	if so, ok := c.tg.(telegram.StorageOptimizer); ok && cf.TelegramEnabled {
		ttl := 7
		if force {
			ttl = 1
		}
		tctx, cancel := context.WithTimeout(ctx, 2*time.Minute)
		freed, err := so.OptimizeStorage(tctx, ttl)
		cancel()
		if err != nil {
			log.Printf("reina: tdlib storage cleanup: %v", err)
		} else {
			add("кэш Telegram", 0, freed)
		}
	}

	after, _ := maint.DiskOf(cf.DataDir)
	if len(parts) == 0 {
		return fmt.Sprintf("Чистить нечего. Свободно %s из %s.", maint.Human(after.Free), maint.Human(after.Total))
	}
	_ = before
	return fmt.Sprintf("Освободила около %s (%s). Свободно теперь %s из %s.", mb(total), strings.Join(parts, ", "), maint.Human(after.Free), maint.Human(after.Total))
}

const maxLog = 30 << 20

func mb(n int64) string {
	if n >= 1<<30 {
		return fmt.Sprintf("%.1f ГБ", float64(n)/(1<<30))
	}
	return fmt.Sprintf("%d МБ", n>>20)
}
