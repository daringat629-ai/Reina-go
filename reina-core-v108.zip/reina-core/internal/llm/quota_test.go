package llm

import (
	"context"
	"testing"
)

func TestQuotaSpentIsNotRetried(t *testing.T) {
	if !quotaSpent(429, "68400", "") || !quotaSpent(429, "", `{"error":{"status":"RESOURCE_EXHAUSTED","message":"quota"}}`) {
		t.Fatal("a spent quota must be recognised")
	}
	if quotaSpent(429, "2", "slow down") || quotaSpent(500, "99999", "") {
		t.Fatal("a short rate limit is still retried")
	}
	if (&APIError{Status: 429, Exhausted: true}).Temporary() {
		t.Fatal("exhausted must be permanent")
	}
}

func TestDeadEmbeddingServerIsSkippedAfterTwoFailures(t *testing.T) {
	c := New("http://127.0.0.1:1/", "http://127.0.0.1:1/", "", "m", "e", 0)
	for i := 0; i < embedFailLimit; i++ {
		if _, err := c.Embedding(context.Background(), "x"); err == nil {
			t.Fatal("a dead server must fail")
		}
	}
	if _, err := c.Embedding(context.Background(), "y"); err != errEmbeddingPaused {
		t.Fatalf("after %d failures the server must be skipped, got %v", embedFailLimit, err)
	}
}
