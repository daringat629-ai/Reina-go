// Package promises is what the owner promised her and when he last wrote: she keeps the book, names the dates, notices when
// a promise is overdue and when he has been silent for long ("не пропадай и выполняй обещанное"). One JSON file.
package promises

import (
	"errors"
	"fmt"
	"sort"
	"strings"
	"sync"
	"time"

	"orvi/internal/store"
)

// Item is one promise.
type Item struct {
	ID     int       `json:"id"`
	Text   string    `json:"text"`
	Made   time.Time `json:"made"`
	Due    time.Time `json:"due,omitempty"` // zero = no date was named
	Closed time.Time `json:"closed,omitempty"`
	To     string    `json:"to,omitempty"` // her own promises: to whom
}

type data struct {
	Items    []Item    `json:"items"`
	Next     int       `json:"next"`
	LastSeen time.Time `json:"last_seen,omitempty"` // when the owner last wrote to her
	Mine     []Item    `json:"mine,omitempty"`      // what SHE promised to people
}

// Store is the book.
type Store struct {
	mu    sync.Mutex
	path  string
	d     data
	saver store.Saver
}

// New loads the book from path (missing = empty).
func New(path string) *Store {
	s := &Store{path: path, saver: store.Saver{What: "promises"}}
	store.Load("promises", path, &s.d)
	if s.d.Next == 0 {
		s.d.Next = 1
	}
	return s
}

func (s *Store) save() { _ = s.saver.Save(s.path, s.d) }

// Add writes a promise down. due may be zero.
func (s *Store) Add(text string, due, now time.Time) (Item, error) {
	text = strings.TrimSpace(text)
	if text == "" {
		return Item{}, errors.New("what was promised?")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	it := Item{ID: s.d.Next, Text: text, Made: now, Due: due}
	s.d.Next++
	s.d.Items = append(s.d.Items, it)
	s.save()
	return it, nil
}

// Done closes a promise as kept.
func (s *Store) Done(id int, now time.Time) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	for i := range s.d.Items {
		if s.d.Items[i].ID == id && s.d.Items[i].Closed.IsZero() {
			s.d.Items[i].Closed = now
			s.save()
			return true
		}
	}
	return false
}

// Open lists the promises not kept yet, the ones with the nearest date first.
func (s *Store) Open() []Item {
	s.mu.Lock()
	defer s.mu.Unlock()
	var out []Item
	for _, it := range s.d.Items {
		if it.Closed.IsZero() {
			out = append(out, it)
		}
	}
	sort.SliceStable(out, func(i, j int) bool {
		a, b := out[i].Due, out[j].Due
		if a.IsZero() != b.IsZero() {
			return !a.IsZero()
		}
		return a.Before(b)
	})
	return out
}

// Stats counts kept promises, open ones and those past their date.
func (s *Store) Stats(now time.Time) (kept, open, overdue int) {
	s.mu.Lock()
	defer s.mu.Unlock()
	for _, it := range s.d.Items {
		switch {
		case !it.Closed.IsZero():
			kept++
		case !it.Due.IsZero() && it.Due.Before(now):
			open++
			overdue++
		default:
			open++
		}
	}
	return
}

// Seen records that the owner has just written to her.
func (s *Store) Seen(now time.Time) {
	s.mu.Lock()
	defer s.mu.Unlock()
	// the file is touched at most every few minutes: this is called for every message
	if now.Sub(s.d.LastSeen) < 5*time.Minute {
		return
	}
	s.d.LastSeen = now
	s.save()
}

// Silence is how long it has been since he wrote (0 when she has never seen him).
func (s *Store) Silence(now time.Time) time.Duration {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.d.LastSeen.IsZero() {
		return 0
	}
	return now.Sub(s.d.LastSeen)
}

func ago(d time.Duration) string {
	switch {
	case d < 36*time.Hour:
		return fmt.Sprintf("%d ч", int(d.Hours()))
	default:
		return fmt.Sprintf("%d дн", int(d.Hours()/24))
	}
}

// Prompt is the block for a conversation with the owner: what he promised and has not done, with the dates.
// owner = his own chat (promises are not for strangers' eyes).
func (s *Store) Prompt(now time.Time, loc *time.Location, owner bool) string {
	if s == nil || !owner {
		return ""
	}
	open := s.Open()
	if len(open) == 0 {
		return ""
	}
	if loc == nil {
		loc = time.Local
	}
	var b strings.Builder
	b.WriteString("<promises>Что папик тебе обещал и ещё не сделал (твой список; закрывай #promise_done, когда выполнено):\n")
	for i, it := range open {
		if i >= 6 {
			fmt.Fprintf(&b, "...и ещё %d\n", len(open)-i)
			break
		}
		switch {
		case it.Due.IsZero():
			fmt.Fprintf(&b, "#%d %s (срок не назван, обещано %s назад)\n", it.ID, it.Text, ago(now.Sub(it.Made)))
		case it.Due.Before(now):
			fmt.Fprintf(&b, "#%d %s (СРОК ПРОШЁЛ: %s)\n", it.ID, it.Text, it.Due.In(loc).Format("2 Jan 15:04"))
		default:
			fmt.Fprintf(&b, "#%d %s (срок %s)\n", it.ID, it.Text, it.Due.In(loc).Format("2 Jan 15:04"))
		}
	}
	b.WriteString("Напоминай по делу и без занудства: один раз, своими словами. На «скоро» отвечай просьбой назвать срок и записывай его через #promise_add.</promises>\n")
	return b.String()
}

// Absence is the block for her free time when he has been silent for long. It says nothing for a short silence.
func (s *Store) Absence(now time.Time) string {
	if s == nil {
		return ""
	}
	d := s.Silence(now)
	if d < 8*time.Hour {
		return ""
	}
	return fmt.Sprintf("<papik_silent>Папик не писал тебе уже %s. Ты волнуешься за него, хоть и не показываешь. Можно один раз написать коротко и по-человечески (как он, всё ли в порядке), можно промолчать: не дави и не упрекай.</papik_silent>\n", ago(d))
}
