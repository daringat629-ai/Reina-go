package agent

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"orvi/internal/config"
	"orvi/internal/llm"
	"orvi/internal/prompts"
	"orvi/internal/selfmodel"
	"orvi/internal/tools"
	"orvi/internal/usage"
)

func TestSplitReflection(t *testing.T) {
	th, l := splitReflection("Странно, что меня так качнуло. Не знаю почему.\nВывод: я не всегда знаю, что со мной будет.")
	if !strings.HasPrefix(th, "Странно") || l != "я не всегда знаю, что со мной будет." {
		t.Fatalf("%q | %q", th, l)
	}
	if th, l := splitReflection("Просто мысль."); th != "Просто мысль." || l != "" {
		t.Fatal("no finding is fine")
	}
}

func TestReflectOnSelfThinksAndLearnsOnceInAWhile(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		json.NewEncoder(w).Encode(map[string]any{"choices": []any{map[string]any{"message": map[string]any{"role": "assistant",
			"content": "Меня качнуло, а я ждала спокойствия. Причины не знаю.\nВывод: я хуже, чем думала, предсказываю свою тревогу."}}}, "usage": map[string]any{"prompt_tokens": 10, "completion_tokens": 10}})
	}))
	defer srv.Close()
	dir := t.TempDir()
	cfg := &config.Config{CharacterName: "Рейна", PapikName: "Папик", DataDir: dir, AutonomyInner: true, LLMBaseURL: srv.URL + "/", LLMModel: "m"}
	ps, err := prompts.NewStore(filepath.Join(dir, "prompts"), prompts.Vars{CharacterName: "Рейна", PapikName: "Папик"})
	if err != nil {
		t.Fatal(err)
	}
	a := &Agent{Cfg: config.NewStaticHolder(cfg), LLM: llm.New(cfg.LLMBaseURL, "", "", "m", "", 5*time.Second), Prompts: ps,
		Usage: usage.New(filepath.Join(dir, "usage.json")), Deps: tools.Deps{Self: selfmodel.New(filepath.Join(dir, "self.json"))}}
	at := time.Now()
	if err := a.reflectOnSelf(context.Background(), "тревога скакнула", at); err != nil {
		t.Fatal(err)
	}
	if got := a.thoughtStore().Last(1); len(got) != 1 || !strings.Contains(got[0].Text, "качнуло") || strings.Contains(got[0].Text, "Вывод") {
		t.Fatalf("her thought is kept without the finding line: %+v", got)
	}
	if r, _ := a.Deps.Self.Latest(); len(r.Learned) != 1 || !strings.Contains(r.Learned[0], "предсказываю") {
		t.Fatalf("what she found out reaches her self-model: %+v", r)
	}
	if a.reflect.handledAt().Before(at) {
		t.Fatal("this surprise is marked as handled")
	}
	// another surprise right away: she does not reflect again, it would turn into a ritual
	if err := a.reflectOnSelf(context.Background(), "ещё одно", at.Add(time.Minute)); err != nil {
		t.Fatal(err)
	}
	if n := len(a.thoughtStore().Last(10)); n != 1 {
		t.Fatalf("one reflection per %v, got %d thoughts", reflectGap, n)
	}
}

func TestReflectOnShiftComparesWithTheOlderSelfAtNight(t *testing.T) {
	var asked string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		var req struct {
			Messages []struct{ Content string } `json:"messages"`
		}
		_ = json.NewDecoder(r.Body).Decode(&req)
		asked = req.Messages[len(req.Messages)-1].Content
		json.NewEncoder(w).Encode(map[string]any{"choices": []any{map[string]any{"message": map[string]any{"role": "assistant",
			"content": "Я стала спокойнее, а страх остаться без него остался прежним."}}}, "usage": map[string]any{"prompt_tokens": 10, "completion_tokens": 10}})
	}))
	defer srv.Close()
	dir := t.TempDir()
	cfg := &config.Config{CharacterName: "Рейна", PapikName: "Папик", DataDir: dir, AutonomyInner: true, AutonomyEnabled: true,
		AutonomyQuietFrom: "00:00", AutonomyQuietTo: "23:59", LLMBaseURL: srv.URL + "/", LLMModel: "m"}
	ps, _ := prompts.NewStore(filepath.Join(dir, "prompts"), prompts.Vars{CharacterName: "Рейна", PapikName: "Папик"})
	selfPath := filepath.Join(dir, "self.json")
	// an old self written eight days ago, then a newer one
	old := selfmodel.New(selfPath)
	_ = old.Reflect("Рейна", "персонаж", "только начала", "понять себя", nil)
	raw, _ := os.ReadFile(selfPath)
	raw = []byte(strings.Replace(string(raw), time.Now().Format("2006-01-02"), time.Now().AddDate(0, 0, -8).Format("2006-01-02"), -1))
	_ = os.WriteFile(selfPath, raw, 0o600)
	self := selfmodel.New(selfPath)
	_ = self.Reflect("", "", "освоилась", "", nil)
	a := &Agent{Cfg: config.NewStaticHolder(cfg), LLM: llm.New(cfg.LLMBaseURL, "", "", "m", "", 5*time.Second), Prompts: ps,
		Usage: usage.New(filepath.Join(dir, "usage.json")), Deps: tools.Deps{Self: self}}
	if err := a.reflectOnShift(context.Background()); err != nil {
		t.Fatal(err)
	}
	sh, ok := self.LastShift()
	if !ok || !strings.Contains(sh.Text, "спокойнее") {
		t.Fatalf("the account is kept: %+v", sh)
	}
	if !strings.Contains(asked, "только начала") || !strings.Contains(asked, "освоилась") {
		t.Fatalf("she must see both selves: %s", asked)
	}
	before := len(self.Shifts())
	_ = a.reflectOnShift(context.Background())
	if len(self.Shifts()) != before {
		t.Fatal("once a week, not every hour")
	}
}
