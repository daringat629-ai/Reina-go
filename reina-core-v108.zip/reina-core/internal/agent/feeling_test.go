package agent

import "testing"

func TestSplitFeelingTakesTheClosingLine(t *testing.T) {
	text, f := splitFeeling("Думала про море.\nХотелось тишины.\n**Чувствовала:** тихую грусть.")
	if text != "Думала про море. Хотелось тишины." || f != "тихую грусть" {
		t.Fatalf("%q | %q", text, f)
	}
	if text, f := splitFeeling("Просто текст"); text != "Просто текст" || f != "" {
		t.Fatalf("no line, no feeling: %q %q", text, f)
	}
}
