package agent

import (
	"context"
	"fmt"
	"hash/fnv"
	"math/rand"
	"time"

	"orvi/internal/telegram"
)

// Living presence: she does not answer the instant a message lands. She notices it after a pause, a group later than
// a private chat, a live conversation at once; at night (or asleep) and in a busy moment she may come back to it
// only minutes later. The owner's chat is never postponed.

// presenceIn is everything that decides how quickly she notices a message.
type presenceIn struct {
	Owner      bool          // the owner's private chat: always quick, never postponed
	Group      bool          // groups are noticed more slowly
	Asleep     bool          // she went to sleep (go_to_sleep)
	Night      bool          // quiet hours
	SinceLast  time.Duration // time since the last turn in this chat; a live conversation needs no warm-up
	ReadMin    time.Duration
	ReadMax    time.Duration
	LateChance float64 // 0..1, applied at night
	LateMin    time.Duration
	LateMax    time.Duration
	SlowChance float64 // 0..1: she was busy and notices this one much later

	Urgent        bool          // the person is not okay: no artificial delay at all
	SleepLeft     time.Duration // >0: she sleeps by her schedule and wakes up in this long
	MorningMin    time.Duration // after waking up she answers the night's messages after a while
	MorningMax    time.Duration
	OwnerReadMax  time.Duration // the owner's chat in the daytime (0 = the old 1.5 s)
	OwnerNightMax time.Duration // the owner's chat while she sleeps: slower and sleepy, never later than this (0 = no night delay)
	SeenChance    float64       // 0..1: she reads it now and answers only later
	SeenMin       time.Duration
	SeenMax       time.Duration
	Busy          bool // today's busy stretch (herday): she notices things later
}

type presencePlan struct {
	Late time.Duration // >0: do not look at the chat for this long (messages stay unread)
	Read time.Duration // pause before opening the chat
	Seen time.Duration // >0: open and read the chat, but answer only after this long ("left on read" for a while)
}

// planPresence is pure (rnd injected) so it can be tested.
func planPresence(in presenceIn, rnd func() float64) presencePlan {
	span := func(lo, hi time.Duration) time.Duration {
		if hi <= lo {
			return lo
		}
		return lo + time.Duration(rnd()*float64(hi-lo))
	}
	live := in.SinceLast > 0 && in.SinceLast < 90*time.Second
	if in.Urgent {
		return presencePlan{Read: span(0, 1500*time.Millisecond)} // someone is not okay: she is there at once
	}
	if in.Owner {
		if in.OwnerNightMax > 0 && (in.Asleep || in.SleepLeft > 0) && !live {
			// he woke her up: she always answers him, sleepily and a bit later, never minutes and minutes
			return presencePlan{Read: span(min(30*time.Second, in.OwnerNightMax), in.OwnerNightMax)}
		}
		hi := 1500 * time.Millisecond
		lo := time.Duration(0)
		if in.OwnerReadMax > 0 && !live {
			hi, lo = in.OwnerReadMax, min(time.Second, in.OwnerReadMax)
		}
		p := presencePlan{Read: span(lo, hi)}
		if in.SlowChance > 0 && rnd() < in.SlowChance && in.SinceLast > 90*time.Second {
			p.Read = span(15*time.Second, 55*time.Second) // busy for a moment; never minutes for him
		}
		return p
	}
	slow := in.SlowChance
	if in.Busy {
		slow = min(1, slow*4)
	}
	var p presencePlan
	switch {
	case in.SleepLeft > 0:
		p.Late = in.SleepLeft + span(in.MorningMin, in.MorningMax) // asleep: she sees it in the morning
	case in.Asleep || (in.Night && rnd() < in.LateChance):
		p.Late = span(in.LateMin, in.LateMax)
	case slow > 0 && in.SinceLast > 90*time.Second && rnd() < slow:
		p.Late = span(2*time.Minute, 12*time.Minute) // a busy moment in the middle of the day
	}
	read := span(in.ReadMin, in.ReadMax)
	if in.Group {
		read += span(in.ReadMin, in.ReadMax) // groups: notice later
	}
	if live {
		read /= 4 // already talking
	} else if in.Busy {
		read *= 2
	}
	p.Read = read
	if p.Late == 0 && !in.Group && !live && in.SeenChance > 0 && rnd() < in.SeenChance {
		p.Seen = span(in.SeenMin, in.SeenMax)
	}
	return p
}

func (a *Agent) presenceFor(chat telegram.Chat, s *session, now time.Time, unread []telegram.Message) presencePlan {
	cfg := a.cfg()
	if !cfg.PresenceEnabled {
		return presencePlan{}
	}
	sec := func(n int) time.Duration { return time.Duration(n) * time.Second }
	in := presenceIn{
		Owner:      cfg.IsOwner(chat.ID),
		Group:      chat.Kind != telegram.ChatPrivate,
		Night:      a.isNight(now),
		ReadMin:    time.Duration(cfg.ReadDelayMin) * time.Second,
		ReadMax:    time.Duration(cfg.ReadDelayMax) * time.Second,
		LateChance: float64(cfg.LateReplyPercent) / 100,
		LateMin:    time.Duration(cfg.LateReplyMinMins) * time.Minute,
		LateMax:    time.Duration(cfg.LateReplyMaxMins) * time.Minute,
		SlowChance: float64(cfg.SlowPercent) / 100,

		Urgent:        anyUrgent(unread),
		MorningMin:    time.Duration(cfg.MorningLagMinMins) * time.Minute,
		MorningMax:    time.Duration(cfg.MorningLagMaxMins) * time.Minute,
		OwnerReadMax:  sec(cfg.OwnerReadMaxSecs),
		OwnerNightMax: sec(cfg.OwnerNightMaxSecs),
		SeenChance:    float64(cfg.SeenLaterPercent) / 100,
		SeenMin:       time.Duration(cfg.SeenLaterMinMins) * time.Minute,
		SeenMax:       time.Duration(cfg.SeenLaterMaxMins) * time.Minute,
	}
	if cfg.DayLife {
		in.Busy = planOfDay(now.In(cfg.Location())).busy(now.In(cfg.Location()).Hour())
	}
	if asleep, wake := a.scheduledSleep(now); asleep {
		in.SleepLeft = wake.Sub(now)
	}
	if a.Auto != nil && cfg.AutonomyEnabled {
		in.Asleep, _ = a.Auto.Asleep()
	}
	if last := s.lastTime(); !last.IsZero() {
		in.SinceLast = now.Sub(last)
	}
	return planPresence(in, rand.Float64)
}

// sleepWindow is the night that holds `now` by her schedule: bedtime and wake from the config, moved by up to
// jitter minutes by the date (the same all night, different every night) and later on Friday and Saturday nights.
// A bedtime before noon belongs to the night after the evening before ("01:30" = the night from Monday to Tuesday).
func sleepWindow(now time.Time, bed, wake string, jitter, weekend int) (asleep bool, until time.Time) {
	bm, ok1 := hhmm(bed)
	wm, ok2 := hhmm(wake)
	if !ok1 || !ok2 {
		return false, time.Time{}
	}
	if bm < 12*60 {
		bm += 24 * 60
	}
	shift := func(day time.Time, salt string) int {
		if jitter <= 0 {
			return 0
		}
		h := fnv.New32a()
		fmt.Fprintf(h, "%s/%s", day.Format("2006-01-02"), salt)
		return int(h.Sum32()%uint32(2*jitter+1)) - jitter
	}
	for _, back := range []int{0, -1} { // the night that began this evening, or the one that began yesterday
		eve := time.Date(now.Year(), now.Month(), now.Day()+back, 0, 0, 0, 0, now.Location())
		late := 0
		if wd := eve.Weekday(); wd == time.Friday || wd == time.Saturday {
			late = weekend
		}
		from := eve.Add(time.Duration(bm+shift(eve, "bed")+late) * time.Minute)
		to := eve.AddDate(0, 0, 1).Add(time.Duration(wm+shift(eve, "wake")+late) * time.Minute)
		if !now.Before(from) && now.Before(to) {
			return true, to
		}
	}
	return false, time.Time{}
}

func hhmm(s string) (int, bool) {
	var h, m int
	if n, err := fmt.Sscanf(s, "%d:%d", &h, &m); err != nil || n != 2 || h < 0 || h > 23 || m < 0 || m > 59 {
		return 0, false
	}
	return h*60 + m, true
}

// scheduledSleep says whether she sleeps now by her schedule (presence.sleep_schedule) and when she wakes.
func (a *Agent) scheduledSleep(now time.Time) (bool, time.Time) {
	cfg := a.cfg()
	if !cfg.SleepSchedule || !cfg.PresenceEnabled {
		return false, time.Time{}
	}
	return sleepWindow(now.In(cfg.Location()), cfg.Bedtime, cfg.WakeAt, cfg.SleepJitterMins, cfg.WeekendShiftMins)
}

// readPause waits before the chat is opened. false = interrupted.
func (a *Agent) readPause(ctx context.Context, d time.Duration) bool {
	if d <= 0 {
		return true
	}
	t := time.NewTimer(d)
	defer t.Stop()
	select {
	case <-t.C:
		return true
	case <-ctx.Done():
		return false
	}
}

// offlineAfter is how long the account stays "online" after the last turn.
func (a *Agent) offlineAfter() time.Duration {
	if s := a.cfg().OfflineAfterSecs; s > 0 {
		return time.Duration(s) * time.Second
	}
	return 20 * time.Second
}

// lastIncomingLen is how much they wrote in the messages she answers now (in runes, all of a burst together): a short
// message gets a short answer. 0 = only media, nothing to measure.
func lastIncomingLen(unread []telegram.Message) int {
	n := 0
	for _, m := range unread {
		if !m.Outgoing {
			n += len([]rune(m.Text))
		}
	}
	return n
}
