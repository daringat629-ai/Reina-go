package agent

import (
	"fmt"
	"time"

	"orvi/internal/telegram"
)

// adviceBlock is what she carries into a chat from her questions to people: what she decided after listening to others
// (always, it is part of her), and in a private chat with someone other than the owner, a question she may bring up or
// is waiting an answer to.
func (a *Agent) adviceBlock(chat telegram.Chat, now time.Time) string {
	box := a.Deps.Advice
	if box == nil {
		return ""
	}
	out := box.LessonsPrompt()
	if chat.Kind != telegram.ChatPrivate || chat.ID <= 0 || a.cfg().IsOwner(chat.ID) {
		return out
	}
	if q, ok := box.Pending(chat.ID, now); ok {
		return out + fmt.Sprintf("<curiosity id=\"%d\" state=\"asked\">Ты спросила у этого человека его мнение: «%s». Если он ответил, сохрани суть ответа: #advice note (id %d). Если не ответил, не дави и не переспрашивай.</curiosity>\n", q.ID, q.Text, q.ID)
	}
	if q, ok := box.Offer(chat.ID, now); ok {
		return out + fmt.Sprintf("<curiosity id=\"%d\">Тебе правда интересно, что думают об этом разные люди: «%s». Если разговор спокойный и человеку не нужна помощь прямо сейчас, можешь спросить его мнение, своими словами и к месту, как спрашивают у друга. Не называй имён и не выдавай ничего личного о других людях. Ответ сохрани: #advice note (id %d). Если момент неподходящий, просто не спрашивай.</curiosity>\n", q.ID, q.Text, q.ID)
	}
	return out
}

// adviceOwnBlock is for her own time: decide on questions she has heard enough about, or, now and then, notice whether
// something in her life is worth asking people about.
func (a *Agent) adviceOwnBlock(now time.Time) string {
	box := a.Deps.Advice
	if box == nil {
		return ""
	}
	if r := box.ReadyPrompt(); r != "" {
		return r
	}
	n, last := box.OpenCount()
	if n > 0 || now.Sub(last) < 48*time.Hour {
		return ""
	}
	day := now.In(a.cfg().Location()).Format("2006-01-02")
	a.questionMu.Lock()
	defer a.questionMu.Unlock()
	if a.adviceSeedDay == day {
		return ""
	}
	a.adviceSeedDay = day
	return "<curiosity_seed>Есть ли сейчас в твоей жизни что-то, о чём тебе интересно узнать мнение разных людей: чувство, отношения, выбор, что-то непонятное о себе? Если да, открой вопрос: #advice ask. Пиши общими словами, без имён и личных подробностей. Если ничего такого нет, ничего не делай.</curiosity_seed>\n"
}
