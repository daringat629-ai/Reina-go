package agent

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"testing"

	"orvi/internal/llm"
	"orvi/internal/telegram"
)

// scriptLLM answers the chat rounds (requests with tools) from a list, in order; the rest gets a plain text.
type scriptLLM struct {
	srv   *httptest.Server
	mu    sync.Mutex
	steps []llm.ToolCall // one tool call per round; a zero Name means "no tool call, just words"
	round int
	reqs  []string // the messages of every chat round, as JSON
}

func newScript(t *testing.T, steps ...llm.ToolCall) *scriptLLM {
	f := &scriptLLM{steps: steps}
	f.srv = httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		var req map[string]any
		_ = json.NewDecoder(r.Body).Decode(&req)
		if strings.HasSuffix(r.URL.Path, "/embeddings") {
			json.NewEncoder(w).Encode(map[string]any{"data": []any{map[string]any{"embedding": []float64{1, 0.5}}}})
			return
		}
		msg := map[string]any{"role": "assistant", "content": "A long enough diary page about talking to Alex today.\n---\nSecond page: he asked how I am doing and I said hi."}
		if _, hasTools := req["tools"]; hasTools {
			f.mu.Lock()
			raw, _ := json.Marshal(req["messages"])
			f.reqs = append(f.reqs, string(raw))
			var call llm.ToolCall
			if f.round < len(f.steps) {
				call = f.steps[f.round]
			}
			f.round++
			f.mu.Unlock()
			msg = map[string]any{"role": "assistant", "content": "thinking"}
			if call.Function.Name != "" {
				msg["tool_calls"] = []any{call}
			}
		}
		json.NewEncoder(w).Encode(map[string]any{"choices": []any{map[string]any{"message": msg}}, "usage": map[string]any{"prompt_tokens": 100, "completion_tokens": 10}})
	}))
	t.Cleanup(f.srv.Close)
	return f
}

func (f *scriptLLM) rounds() int { f.mu.Lock(); defer f.mu.Unlock(); return f.round }

func say(text string) llm.ToolCall {
	b, _ := json.Marshal(map[string]any{"text": text})
	return llm.ToolCall{ID: "s" + text[:3], Type: "function", Function: llm.FunctionCall{Name: "send_telegram_message", Arguments: string(b)}}
}

func doWork() llm.ToolCall {
	return llm.ToolCall{ID: "w1", Type: "function", Function: llm.FunctionCall{Name: "user_info", Arguments: `{"user_id":5}`}}
}

func reportRig(t *testing.T, f *scriptLLM) (*rig, func()) {
	r := newRig(t, &fakeLLM{srv: f.srv})
	r.ag.Cfg.Get().StopAfterSend = true // the production default: a round that only sent ends the turn
	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan struct{})
	go func() { r.ag.Run(ctx); close(done) }()
	return r, func() { cancel(); <-done }
}

var alex = telegram.Chat{ID: 100, Title: "Alex", Kind: telegram.ChatPrivate, IsMember: true}

func TestAPromiseToLookIsNotTheEndOfTheTurn(t *testing.T) {
	f := newScript(t, say("щас гляну, секунду"), doWork(), say("глянула: годная вещь, но слишком длинная"))
	r, stop := reportRig(t, f)
	defer stop()
	r.tg.Incoming(alex, 100, "Alex", "посмотри че там по памяти")
	waitFor(t, "the report after the promise", func() bool { return len(r.tg.SentTexts()) == 2 })
	if got := r.tg.SentTexts(); !strings.Contains(got[1], "годная вещь") {
		t.Fatal(got)
	}
	f.mu.Lock()
	second := f.reqs[1]
	f.mu.Unlock()
	if !strings.Contains(second, "Do it now with the right tool") {
		t.Fatal("she was not told to keep her promise")
	}
}

func TestSheMustTellWhatSheFoundAfterWorkingInSilence(t *testing.T) {
	f := newScript(t, doWork(), llm.ToolCall{} /* words only, no tool */, say("нашла: это манга без картинок, читай справа налево"))
	r, stop := reportRig(t, f)
	defer stop()
	r.tg.Incoming(alex, 100, "Alex", "глянь и скажи как тебе")
	waitFor(t, "the report", func() bool { return len(r.tg.SentTexts()) == 1 })
	f.mu.Lock()
	third := f.reqs[2]
	f.mu.Unlock()
	if !strings.Contains(third, "have not told them anything yet") {
		t.Fatal("no nudge to report")
	}
}

func TestNoNudgeWhenSheAlreadyAnswered(t *testing.T) {
	f := newScript(t, doWork(), say("вот что вышло: всё нормально"))
	r, stop := reportRig(t, f)
	defer stop()
	r.tg.Incoming(alex, 100, "Alex", "как дела у человека 5")
	waitFor(t, "the answer", func() bool { return len(r.tg.SentTexts()) == 1 })
	// the turn ends after the report: no third round
	waitFor(t, "two rounds", func() bool { return f.rounds() >= 2 })
	if n := f.rounds(); n != 2 {
		t.Fatalf("%d rounds, want 2", n)
	}
}

func TestOrdinaryWordsAreNotPromises(t *testing.T) {
	yes := []string{"щас гляну", "щас, секунду", "секунду...", "проверю и скажу", "сейчас погоди", "let me check", "one sec", "поищу в сети", "Подожди~"}
	no := []string{"сейчас холодно", "ахах, ну ты даёшь", "я уже посмотрела это вчера", "секунду назад всё работало", "нашла, держи ссылку"}
	for _, s := range yes {
		if !promisesWork([]llm.ToolCall{say(s)}) {
			t.Errorf("%q must count as a promise", s)
		}
	}
	for _, s := range no {
		if promisesWork([]llm.ToolCall{say(s)}) {
			t.Errorf("%q is no promise", s)
		}
	}
}

func TestNoNudgesInGroups(t *testing.T) {
	f := newScript(t, say("щас гляну, секунду"))
	r, stop := reportRig(t, f)
	defer stop()
	r.tg.Incoming(telegram.Chat{ID: -900, Title: "Club", Kind: telegram.ChatGroup, IsMember: true}, 301, "Ann", "Reina посмотри")
	waitFor(t, "her message", func() bool { return len(r.tg.SentTexts()) == 1 })
	waitFor(t, "a round", func() bool { return f.rounds() >= 1 })
	if f.rounds() != 1 {
		t.Fatalf("%d rounds in a group", f.rounds())
	}
}

func TestFollowThroughRuleIsInTheInstructions(t *testing.T) {
	r := newRig(t, newFakeLLM(t, sendCall))
	in := r.ag.chatInstructions(alex)
	if !strings.Contains(in, "FOLLOW THROUGH") || !strings.Contains(in, "как тебе") {
		t.Fatal(in)
	}
}
