package agent

import (
	"context"
	"strings"
	"testing"
	"time"

	"orvi/internal/cortex"
	"orvi/internal/mind"
	"orvi/internal/telegram"
)

func TestBrainCommandShowsRegionsAndHerOwnMind(t *testing.T) {
	r := newRig(t, newFakeLLM(t, sendCall))
	r.ag.Cfg.Get().PapikChatID = 100
	c := cortex.New("", 50000, 2)
	c.Step(cortex.Inputs{Hour: 12, Channels: map[string]float64{}})
	r.ag.Deps.Cortex = c
	r.ag.Deps.Mind = mind.New("", 1)
	chat := telegram.Chat{ID: 100, Title: "Alex", Kind: telegram.ChatPrivate, IsMember: true}
	for _, name := range []string{"/мозг", "/brain"} {
		n := len(r.tg.SentTexts())
		m := telegram.Message{ID: int64(10 + n), ChatID: 100, SenderID: 100, SenderName: "Alex", Date: time.Now(), Text: name}
		r.tg.S.Put(m, &chat)
		if !r.ag.command(context.Background(), m) {
			t.Fatal(name, "is not a command")
		}
		waitFor(t, "a reply", func() bool { return len(r.tg.SentTexts()) > n })
		got := r.tg.SentTexts()[n]
		if !strings.Contains(got, "нейронов") || !strings.Contains(got, "Собственный разум") || !strings.Contains(got, "mind.answer_alone") {
			t.Fatalf("%s: %q", name, got)
		}
	}
}
