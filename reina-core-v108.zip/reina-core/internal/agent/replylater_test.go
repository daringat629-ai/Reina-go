package agent

import (
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestReplyLaterComesBackWhenDueAndSurvivesRestart(t *testing.T) {
	p := filepath.Join(t.TempDir(), "r.json")
	r := newReplyLater(p)
	now := time.Now()
	if err := r.add(7, "Вика", "ответить про кино", 30*time.Minute, now); err != nil {
		t.Fatal(err)
	}
	if len(r.due(now.Add(10*time.Minute))) != 0 {
		t.Fatal("not due yet")
	}
	r2 := newReplyLater(p) // restart
	d := r2.due(now.Add(31 * time.Minute))
	if len(d) != 1 || !strings.Contains(d[0].Note, "кино") {
		t.Fatalf("due=%+v", d)
	}
	r2.add(7, "Вика", "новое", time.Hour, now) // one note per chat
	if len(r2.items) != 1 {
		t.Fatalf("items=%d", len(r2.items))
	}
	r2.done(7)
	if len(r2.items) != 0 {
		t.Fatal("done must clear it")
	}
}

func TestOwedWakesOnTheMinuteAndKeepsThePromiseUnlimited(t *testing.T) {
	r := newReplyLater("")
	now := time.Now()
	r.add(5, "Рома", "ответить", time.Minute, now)
	if len(r.wake(now.Add(30*time.Second))) != 0 {
		t.Fatal("too early")
	}
	if len(r.wake(now.Add(61*time.Second))) != 1 {
		t.Fatal("must wake at the minute")
	}
	if len(r.wake(now.Add(2*time.Minute))) != 0 {
		t.Fatal("must not wake again within ten minutes")
	}
	if len(r.wake(now.Add(12*time.Minute))) != 1 {
		t.Fatal("must retry after ten minutes if still not answered")
	}
	if !r.keeps(5, now) || r.keeps(6, now) {
		t.Fatal("limits are lifted only for the chat she owes")
	}
	r.done(5)
	if !r.keeps(5, now) {
		t.Fatal("grace after going back")
	}
}
