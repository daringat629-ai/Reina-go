package agent

import (
	"path/filepath"
	"strings"
	"testing"
	"time"

	"orvi/internal/config"
	"orvi/internal/keepsakes"
	"orvi/internal/telegram"
	"orvi/internal/tools"
)

func TestKeepsakeBlockOnlyForHerAndHim(t *testing.T) {
	st := keepsakes.Open(filepath.Join(t.TempDir(), "k.json"))
	if _, err := st.Keep("Дождь пахнет пылью и железом.", "мне нравится, как это звучит", time.Now().Add(-10*24*time.Hour)); err != nil {
		t.Fatal(err)
	}
	c := &config.Config{PapikChatID: 77, OwnerTools: true}
	a := &Agent{Cfg: config.NewStaticHolder(c), Deps: tools.Deps{Keepsakes: st}}
	if a.keepsakeBlock(telegram.Chat{ID: 5}) != "" {
		t.Fatal("never in a stranger's chat")
	}
	if g := a.keepsakeBlock(telegram.Chat{ID: 77}); !strings.Contains(g, "keepsake") {
		t.Fatal("his chat must bring it back:", g)
	}
}
