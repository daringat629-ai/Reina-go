package agent

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"orvi/internal/llm"
	"orvi/internal/people"
	"orvi/internal/reminders"
	"orvi/internal/telegram"
)

func TestParseLearned(t *testing.T) {
	l := parseLearned("Вот:\n- работает водителем\n• любит кофе\n- a\n~ бишкек => переехал в Алматы\n- четвёртый лишний факт\n@ 3h | написать ему про диск\n@ tomorrow 10:00 | скинуть файл\n@ завтра | третье лишнее обещание\n@ | пустое время")
	if len(l.Facts) != 2 || l.Facts[0] != "работает водителем" || l.Facts[1] != "любит кофе" {
		t.Fatalf("facts: %q", l.Facts)
	}
	if len(l.Changes) != 1 || l.Changes[0].Old != "бишкек" || l.Changes[0].New != "переехал в Алматы" {
		t.Fatalf("changes: %+v", l.Changes)
	}
	if len(l.Promises) != 2 || l.Promises[0].When != "3h" || l.Promises[1].What != "скинуть файл" {
		t.Fatalf("promises (at most two): %+v", l.Promises)
	}
	n := parseLearned("- один\n- два факта\n- три факта\n~ четыре => четвёртый факт")
	if len(n.Facts)+len(n.Changes) != 3 {
		t.Fatalf("at most three fact lines, new or corrected: %+v", n)
	}
	if e := parseLearned("NONE"); len(e.Facts)+len(e.Changes)+len(e.Promises) != 0 {
		t.Fatal("NONE gives nothing")
	}
}

func TestClosingAPrivateChatFilesFactsOnTheCard(t *testing.T) {
	var calls int32
	var lastPrompt string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		var req struct {
			Messages []llm.Message `json:"messages"`
		}
		_ = json.NewDecoder(r.Body).Decode(&req)
		atomic.AddInt32(&calls, 1)
		lastPrompt = req.Messages[len(req.Messages)-1].Content
		json.NewEncoder(w).Encode(map[string]any{"choices": []any{map[string]any{"message": map[string]any{"role": "assistant", "content": "- работает водителем в такси\n~ голосовые => не любит голосовые\n@ 2h | напомнить ему про встречу\n@ вчера | в прошлом\n@ 1h | напомнить ему про встречу"}}}})
	}))
	defer srv.Close()

	r := newRig(t, newFakeLLM(t, sendCall))
	r.ag.LLM = llm.New(srv.URL+"/", srv.URL+"/", "", "m", "e", 5*time.Second)
	r.ag.Deps.People = people.New(filepath.Join(r.dir, "people"))
	r.ag.Deps.Reminders = reminders.New(filepath.Join(r.dir, "rem.json"))
	_ = r.ag.Deps.People.Add(7, "Bob", "любит голосовые сообщения", true, time.Now())
	r.ag.Cfg.Get().AutoPersonCards, r.ag.Cfg.Get().AutoPromises = true, true

	s := &session{id: 7, chat: telegram.Chat{ID: 7, Title: "Bob", Kind: telegram.ChatPrivate}}
	msgs := []llm.Message{{Role: "user", Content: "привет, я таксист"}, {Role: "assistant", Content: "ну и что"}, {Role: "user", Content: "ненавижу голосовые"}}

	r.ag.learnPerson(context.Background(), s, msgs)
	c := r.ag.Deps.People.Get(7)
	if len(c.Facts) != 2 || c.Facts[0].Text != "не любит голосовые" || c.Facts[1].Text != "работает водителем в такси" || !c.Facts[0].Private {
		t.Fatalf("the outdated fact must be replaced, the new one added: %+v", c)
	}
	if !strings.Contains(lastPrompt, "любит голосовые сообщения") || !strings.Contains(lastPrompt, "Now:") {
		t.Fatalf("the model must see what is already known and the time: %q", lastPrompt)
	}
	pend := r.ag.Deps.Reminders.List(7)
	if len(pend) != 1 || !strings.Contains(pend[0].Text, "напомнить ему про встречу") || !pend[0].At.After(time.Now().Add(90*time.Minute)) {
		t.Fatalf("one promise becomes one reminder (the past one and the duplicate do not): %+v", pend)
	}
	// the same answer again adds nothing new (facts and promises are de-duplicated)
	r.ag.learnPerson(context.Background(), s, msgs)
	if len(r.ag.Deps.People.Get(7).Facts) != 2 || len(r.ag.Deps.Reminders.List(7)) != 1 {
		t.Fatalf("known facts and promises must not be repeated: %+v %+v", r.ag.Deps.People.Get(7).Facts, r.ag.Deps.Reminders.List(7))
	}
	// never in groups, never for her own thoughts, never for a one-line chat, never when switched off
	before := atomic.LoadInt32(&calls)
	r.ag.learnPerson(context.Background(), &session{id: 8, chat: telegram.Chat{ID: 8, Kind: telegram.ChatGroup}}, msgs)
	r.ag.learnPerson(context.Background(), &session{id: 0, chat: telegram.Chat{Kind: telegram.ChatPrivate}}, msgs)
	r.ag.learnPerson(context.Background(), s, msgs[:1])
	r.ag.Cfg.Get().AutoPersonCards, r.ag.Cfg.Get().AutoPromises = false, false
	r.ag.learnPerson(context.Background(), s, msgs)
	if atomic.LoadInt32(&calls) != before {
		t.Fatal("these cases must not cost a request")
	}
}
