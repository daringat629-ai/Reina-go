package agent

import (
	"context"
	"strings"
	"testing"

	"orvi/internal/telegram"
)

// The owner's powers (shell, mail, browser...) are described only in his chat: a stranger's request neither pays
// for those tokens nor learns what to ask her for.
func TestOwnerPowersOnlyInTheOwnersChat(t *testing.T) {
	f := newFakeLLM(t, sendCall)
	r := newRig(t, f)
	r.ag.Cfg.Get().OwnerTools = true
	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan struct{})
	go func() { r.ag.Run(ctx); close(done) }()
	defer func() { cancel(); <-done }()

	system := func(chatID int64) string {
		f.mu.Lock()
		defer f.mu.Unlock()
		for i := len(f.calls) - 1; i >= 0; i-- {
			msgs, _ := f.calls[i]["messages"].([]any)
			if len(msgs) < 2 {
				continue
			}
			sys, _ := msgs[0].(map[string]any)["content"].(string)
			if _, tools := f.calls[i]["tools"]; !tools {
				continue
			}
			for _, m := range msgs[1:] {
				if c, _ := m.(map[string]any)["content"].(string); strings.Contains(c, map[int64]string{100: "hello boss", 555: "who are you"}[chatID]) {
					return sys
				}
			}
		}
		return ""
	}
	r.tg.Incoming(telegram.Chat{ID: 555, Title: "Stranger", Kind: telegram.ChatPrivate, IsMember: true}, 555, "Stranger", "who are you")
	waitFor(t, "an answer to the stranger", func() bool { return len(r.tg.SentTexts()) >= 1 })
	r.tg.Incoming(telegram.Chat{ID: 100, Title: "Alex", Kind: telegram.ChatPrivate, IsMember: true}, 100, "Alex", "hello boss")
	waitFor(t, "an answer to the owner", func() bool { return len(r.tg.SentTexts()) >= 2 })

	stranger, owner := system(555), system(100)
	if stranger == "" || owner == "" {
		t.Fatal("system prompts not captured")
	}
	if strings.Contains(stranger, "OWNER POWERS") || strings.Contains(stranger, "download_telegram_file") {
		t.Fatal("a stranger's request carries the owner's powers")
	}
	if !strings.Contains(owner, "OWNER POWERS") {
		t.Fatal("the owner's chat lost the description of her powers")
	}
	if !strings.Contains(stranger, "never claim to be human") {
		t.Fatal("the honesty rule is missing")
	}
}
