package agent

import (
	"testing"
	"time"
)

func TestPlanOfDayIsStableAndVaries(t *testing.T) {
	d := time.Date(2026, 11, 2, 12, 0, 0, 0, time.UTC)
	if planOfDay(d) != planOfDay(d.Add(3*time.Hour)) {
		t.Fatal("the plan must not change within a day")
	}
	seen := map[string]bool{}
	for i := 0; i < 30; i++ {
		p := planOfDay(d.AddDate(0, 0, i))
		seen[p.thing] = true
		if p.busyTo > p.busyFrom && (p.busyFrom < 11 || p.busyTo > 19) {
			t.Fatalf("busy stretch out of daytime: %+v", p)
		}
	}
	if len(seen) < 4 {
		t.Fatalf("days look the same: %d things in 30 days", len(seen))
	}
}
