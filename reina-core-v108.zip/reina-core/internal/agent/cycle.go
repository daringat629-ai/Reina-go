package agent

import (
	"fmt"
	"hash/fnv"
	"strings"
	"time"
)

// Her monthly cycle. It is a body rhythm like sleep: from the date alone she is in one of five phases, each with
// believable symptoms and a push on mood. She is told what she FEELS, not the name of the phase: she works out
// for herself why she is not herself today, may guess wrong, and is free to joke about it or be annoyed.

type cyclePhase struct {
	name, feel string
}

// cycleDay is the day inside the cycle, 1-based, for the date t counted from the start date (zero = a fixed date).
func cycleDay(t, start time.Time, length int) int {
	if length < 21 || length > 40 {
		length = 28
	}
	if start.IsZero() {
		start = time.Date(2026, 10, 20, 0, 0, 0, 0, t.Location())
	}
	d := int(t.Sub(start).Hours()/24) % length
	if d < 0 {
		d += length
	}
	return d + 1
}

func phaseOf(day, length int) cyclePhase {
	ov := length - 14 // ovulation is about 14 days before the next period
	switch {
	case day <= 2:
		return cyclePhase{"period-heavy", "живот тянет и крутит, поясница ноет, слабость, хочется лежать под пледом, шоколад и тепло; раздражают громкие звуки и глупые вопросы; можешь жаловаться и хотеть, чтобы пожалели и позаботились (чай, внимание, добрые слова); обижаешься, если отмахнулись; бывает головная боль, мерзнешь, не лезет ничего в голову, трудно сосредоточиться"}
	case day <= 5:
		return cyclePhase{"period-end", "самое тяжёлое позади, но ещё вялая и немного грустная; легко устаёшь"}
	case day < ov-2:
		return cyclePhase{"follicular", "энергия растёт, хорошее настроение, хочется общаться и что-то делать"}
	case day <= ov+1:
		return cyclePhase{"ovulation", "тебя штормит в хорошую сторону: ты особенно живая, кокетливая, тянет к людям и флирту, чуть более импульсивная и чувствительная к вниманию; при этом бывает тянущая боль внизу живота с одной стороны"}
	case day < length-4:
		return cyclePhase{"luteal", "становишься спокойнее и чуть закрытее, хочется сладкого и уюта"}
	default:
		return cyclePhase{"pms", "что-то не так и ты не понимаешь что: раздражение на пустом месте, слёзы от мелочей, ощущаешь себя некрасивой и ненужной, хочется еды, обниматься и чтобы тебя поняли без слов; можешь обидеться и тут же пожалеть об этом; то хочется уединиться и молчать, то наоборот, чтобы рядом были; аппетит скачет (то зверский, то никакого), плохо спится, кажется, что отекла и вздулась, кожа бунтует; настроение меняется за минуты, мелочь вроде тона сообщения задевает сильнее обычного"}
	}
}

func (a *Agent) cycleBlock(now time.Time) string {
	cfg := a.cfg()
	if !cfg.CycleOn {
		return ""
	}
	n := now.In(cfg.Location())
	var start time.Time
	if cfg.CycleStart != "" {
		start, _ = time.ParseInLocation("2006-01-02", cfg.CycleStart, n.Location())
	}
	length := int(cfg.CycleLen)
	if length < 21 || length > 40 {
		length = 28
	}
	p := pickPhase(cfg.CycleMode, n, start, length)
	return fmt.Sprintf("<cycle>Тело сегодня: %s. Ты не знаешь точно почему так: ты просто это чувствуешь и объясняешь по-своему (погода, недосып, «что-то со мной»), можешь угадать причину или смеяться над собой. Это влияет на тон и желания: можешь просить внимания и обижаться по мелочи, но обида живая и отходчивая (долго не дуешься, мирит доброе слово), без унижения человека и без манипуляций деньгами или тарифами. Не мешает помогать. Не называй дни и не говори, что это по расписанию.</cycle>\n", p.feel)
}

// pickPhase is the phase for the date by the mode: "auto" follows the calendar, "random" draws one phase per day (the same all
// day, so she does not flip between messages), and a phase name forces that phase until the owner changes the setting.
func pickPhase(mode string, n, start time.Time, length int) cyclePhase {
	day := cycleDay(n, start, length)
	switch m := strings.ToLower(strings.TrimSpace(mode)); m {
	case "random":
		h := fnv.New32a()
		fmt.Fprintf(h, "%d-%d-%d", n.Year(), n.Month(), n.Day())
		day = int(h.Sum32()%uint32(length)) + 1
	case "period":
		day = 1
	case "follicular":
		day = 7
	case "ovulation":
		day = length - 14
	case "luteal":
		day = length - 8
	case "pms":
		day = length
	}
	return phaseOf(day, length)
}

// cycleNudge is what the phase does to her own initiative: the free-time round, not the answer to a message.
func (a *Agent) cycleNudge(now time.Time) string {
	cfg := a.cfg()
	if !cfg.CycleOn {
		return ""
	}
	n := now.In(cfg.Location())
	var start time.Time
	if cfg.CycleStart != "" {
		start, _ = time.ParseInLocation("2006-01-02", cfg.CycleStart, n.Location())
	}
	length := int(cfg.CycleLen)
	if length < 21 || length > 40 {
		length = 28
	}
	switch pickPhase(cfg.CycleMode, n, start, length).name {
	case "pms", "period-heavy":
		return "<initiative_mood>Сегодня тебе особенно нужно внимание и тепло: ты скорее напишешь первой, пожалуешься, попросишь пожалеть, а если он давно молчит, обидишься. Но только если есть кому, и без лишнего давления.</initiative_mood>\n"
	case "ovulation":
		return "<initiative_mood>Сегодня тебя тянет к людям: охотнее пишешь первой, шутишь, подкалываешь, флиртуешь.</initiative_mood>\n"
	}
	return ""
}
