package agent

import (
	"context"
	"fmt"
	"log"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"orvi/internal/tools"
)

// Risky actions wait for the owner: she asks, he answers /yes N or /no N, and only then the action runs. The pending
// requests live in memory (a restart forgets them, which is the safe way to forget).

const approvalTTL = 30 * time.Minute

type pending struct {
	id   int
	tool string
	args string
	why  string
	chat int64
	at   time.Time
	run  func(ctx context.Context) string
}

// approvals are the requests waiting for the owner's answer.
type approvals struct {
	mu   sync.Mutex
	byID map[int]*pending
	next int
}

// add parks a call and returns its request.
func (ap *approvals) add(p *pending) *pending {
	ap.mu.Lock()
	defer ap.mu.Unlock()
	if ap.byID == nil {
		ap.byID = map[int]*pending{}
	}
	ap.next++
	p.id = ap.next
	ap.byID[p.id] = p
	return p
}

// take removes and returns the request the answer is about: by number, or the only one when there is no number.
// A list of the waiting requests comes back instead when the choice is ambiguous.
func (ap *approvals) take(arg string) (p *pending, ambiguous string) {
	ap.mu.Lock()
	defer ap.mu.Unlock()
	ap.expireLocked()
	arg = strings.TrimPrefix(strings.TrimSpace(arg), "#")
	switch {
	case arg == "" && len(ap.byID) == 1:
		for _, only := range ap.byID {
			p = only
		}
	case arg == "" && len(ap.byID) > 1:
		return nil, ap.listLocked()
	case arg != "":
		if id, err := strconv.Atoi(arg); err == nil {
			p = ap.byID[id]
		}
	}
	if p != nil {
		delete(ap.byID, p.id)
	}
	return p, ""
}

func (ap *approvals) expireLocked() {
	for id, p := range ap.byID {
		if time.Since(p.at) > approvalTTL {
			delete(ap.byID, id)
		}
	}
}

// listLocked describes the waiting requests (ap.mu held).
func (ap *approvals) listLocked() string {
	ids := make([]int, 0, len(ap.byID))
	for id := range ap.byID {
		ids = append(ids, id)
	}
	sort.Ints(ids)
	parts := make([]string, 0, len(ids))
	for _, id := range ids {
		p := ap.byID[id]
		parts = append(parts, fmt.Sprintf("#%d %s (%s)", p.id, p.tool, p.why))
	}
	return strings.Join(parts, "; ")
}

// pendingText is what /pending answers.
func (ap *approvals) pendingText() string {
	ap.mu.Lock()
	defer ap.mu.Unlock()
	ap.expireLocked()
	if len(ap.byID) == 0 {
		return "Ничего не ждёт твоего ответа."
	}
	return "Ждут ответа: " + ap.listLocked() + "\n/yes N или /no N."
}

// riskOf: the call needs the owner's yes (and the switch is on).
func (a *Agent) riskOf(name, args string) string {
	cfg := a.cfg()
	if !cfg.ConfirmRisky || cfg.PapikChatID == 0 {
		return ""
	}
	return tools.RiskOf(name, args, cfg.PapikChatID)
}

// requestApproval parks the call, tells the owner, and returns what the model sees instead of a result.
func (a *Agent) requestApproval(ctx context.Context, s *session, name, args, why string, run func(context.Context) string) string {
	cfg := a.cfg()
	chat := s.id
	if chat == 0 {
		chat = cfg.PapikChatID
	}
	p := a.approvals.add(&pending{tool: name, args: args, why: why, chat: chat, at: time.Now(), run: run})
	msg := fmt.Sprintf("⚠️ Нужно твоё да: %s.\n#%d %s %s\n/yes %d выполнить, /no %d отменить (%d мин)", why, p.id, name, oneLine(args, 140), p.id, p.id, int(approvalTTL.Minutes()))
	if _, err := a.TG.SendText(ctx, cfg.PapikChatID, msg, 0); err != nil {
		log.Printf("agent: approval #%d: %v", p.id, err)
	}
	return fmt.Sprintf("NOT executed yet: this is %s, so the owner has to confirm it (request #%d was sent to him in the chat). Do not call it again. Tell him in one short line what you want to do and why, then wait: when he says yes the program runs it by itself and you will be told the result; if he says no, drop it.", why, p.id)
}

// approve answers /yes and /no: id empty = the only pending request.
func (a *Agent) approve(ctx context.Context, arg string, yes bool) string {
	p, list := a.approvals.take(arg)
	if list != "" {
		return "Ждёт несколько запросов: " + list + "\nУкажи номер: /yes N или /no N."
	}
	if p == nil {
		return "Такого запроса нет (мог истечь за " + strconv.Itoa(int(approvalTTL.Minutes())) + " мин или бот перезапускался)."
	}
	chat := p.chat
	if chat == 0 {
		chat = a.cfg().PapikChatID
	}
	if !yes {
		a.wakeLater(chat, fmt.Sprintf("<approval>The owner DECLINED request #%d (%s %s). Do not do it and do not ask again; acknowledge in a few words.</approval>", p.id, p.tool, oneLine(p.args, 100)))
		return fmt.Sprintf("Отменено #%d.", p.id)
	}
	out := p.run(ctx)
	a.wakeLater(chat, fmt.Sprintf("<approval>The owner CONFIRMED request #%d (%s) and it was executed. Result:\n%s\nTell him how it went.</approval>", p.id, p.tool, oneLine(out, 1500)))
	return fmt.Sprintf("✅ #%d выполнено.", p.id)
}

func (a *Agent) pendingText() string { return a.approvals.pendingText() }

// wakeLater starts a turn of hers in a chat about an event, in the background.
func (a *Agent) wakeLater(chat int64, text string) {
	a.spawn("wake", func() {
		if err := a.Wake(a.life, chat, text); err != nil {
			log.Printf("agent: wake chat %d: %v", chat, err)
		}
	})
}
