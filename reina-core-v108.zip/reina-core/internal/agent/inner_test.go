package agent

import (
	"orvi/internal/llm"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestThoughtsPersistTrimAndCount(t *testing.T) {
	p := filepath.Join(t.TempDir(), "inner_monologue.md")
	ts := loadThoughts(p)
	now := time.Now()
	for i := 0; i < thoughtKeep+5; i++ {
		ts.Add(now, "мысль номер "+strings.Repeat("я", i%3)+" "+string(rune('a'+i%26)))
	}
	ts.Add(now, "   ")
	if got := len(ts.Last(100)); got != thoughtKeep {
		t.Fatalf("kept %d, want %d", got, thoughtKeep)
	}
	again := loadThoughts(p)
	if len(again.Last(100)) != thoughtKeep || again.Last(1)[0].Text != ts.Last(1)[0].Text {
		t.Fatalf("not restored from the file")
	}
	if ts.Today(now) != thoughtKeep || ts.Today(now.AddDate(0, 0, -1)) != 0 {
		t.Fatalf("day count wrong: %d", ts.Today(now))
	}
	ts.Add(now, strings.Repeat("ы", 1000))
	if r := []rune(ts.Last(1)[0].Text); len(r) != thoughtMaxLen {
		t.Fatalf("long thought not cut: %d", len(r))
	}
}

func TestSplitThoughtMarks(t *testing.T) {
	th, rem, wish := splitThoughtMarks("Думаю про дождь.\nМне спокойно.\n**Запомнить:** он любит чай с лимоном\nХочу написать: Дане про сервер")
	if th != "Думаю про дождь.\nМне спокойно." || rem != "он любит чай с лимоном" || wish != "Дане про сервер" {
		t.Fatalf("got %q | %q | %q", th, rem, wish)
	}
	th, rem, wish = splitThoughtMarks("Просто мысль.")
	if th != "Просто мысль." || rem != "" || wish != "" {
		t.Fatalf("plain thought changed: %q %q %q", th, rem, wish)
	}
	_, rem, _ = splitThoughtMarks("x\nЗапомнить: " + strings.Repeat("я", 900))
	if len([]rune(rem)) != noteMaxLen {
		t.Fatalf("note not cut: %d", len([]rune(rem)))
	}
	for _, s := range []string{"", "нет", "Нет.", "—", "ничего"} {
		if !isNone(s) {
			t.Fatalf("%q should be none", s)
		}
	}
	if isNone("позвонить маме") {
		t.Fatal("real text is none")
	}
}

func TestInnerPauseInRange(t *testing.T) {
	for i := 0; i < 200; i++ {
		d := innerPause(8, 15)
		if d < 8*time.Minute || d > 15*time.Minute {
			t.Fatalf("pause %v out of range", d)
		}
	}
	if d := innerPause(5, 1); d != 5*time.Minute {
		t.Fatalf("hi<lo: %v", d)
	}
}

func TestWishIsGivenOnceAndExpires(t *testing.T) {
	ts := loadThoughts(filepath.Join(t.TempDir(), "m.md"))
	now := time.Now()
	ts.SetWish(now, "Дане про сервер")
	if ts.TakeWish(now.Add(time.Hour)) != "Дане про сервер" {
		t.Fatal("fresh wish lost")
	}
	if ts.TakeWish(now.Add(time.Hour)) != "" {
		t.Fatal("wish given twice")
	}
	ts.SetWish(now, "старое")
	if ts.TakeWish(now.Add(wishLife+time.Minute)) != "" {
		t.Fatal("old wish not dropped")
	}
}

func TestCompactionKeepsTailAndDayCount(t *testing.T) {
	p := filepath.Join(t.TempDir(), "m.md")
	ts := loadThoughts(p)
	now := time.Now()
	for i := 0; i < 20; i++ {
		ts.Add(now, "мысль "+string(rune('a'+i)))
	}
	old := ts.TakeOld(6)
	if len(old) != 14 || old[0].Text != "мысль a" || ts.Len() != 6 {
		t.Fatalf("old %d, left %d", len(old), ts.Len())
	}
	if ts.Taken(now) != 20 {
		t.Fatalf("day count forgot the folded thoughts: %d", ts.Taken(now))
	}
	if again := loadThoughts(p); again.Len() != 6 {
		t.Fatalf("file not rewritten: %d", again.Len())
	}
	if ts.TakeOld(6) != nil {
		t.Fatal("nothing should be taken twice")
	}
	if got := loadThoughts(p).Taken(now); got != 6 {
		t.Fatalf("after restart the count falls back to what is on disk: %d", got)
	}
}

func TestNoDailyCapByDefault(t *testing.T) {
	if got := loadThoughts(filepath.Join(t.TempDir(), "m.md")).Taken(time.Now()); got != 0 {
		t.Fatalf("fresh store: %d", got)
	}
}

func TestPromptSizesNamesTheBiggest(t *testing.T) {
	out := promptSizes(strings.Repeat("с", 3000), []llm.Message{
		{Role: "user", Content: "коротко"},
		{Role: "user", Content: strings.Repeat("ж", 9000)},
		{Role: "assistant", Content: "ответ"},
	})
	if !strings.Contains(out, "total 12012") || !strings.Contains(out, "system 3000") || !strings.Contains(out, "user 9007") {
		t.Fatalf("sizes: %s", out)
	}
	if !strings.Contains(strings.Split(out, "biggest messages:\n")[1], "user 9000 chars") {
		t.Fatalf("the biggest must come first: %s", out)
	}
}
