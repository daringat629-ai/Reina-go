package agent

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"strings"
	"sync"
	"time"

	"orvi/internal/autonomy"
	"orvi/internal/live"
	"orvi/internal/llm"
	"orvi/internal/telegram"
	"orvi/internal/tools"
)

// Everything that happens around one tool call, in order:
//
//  1. guards that answer instead of the tool: the same call twice in one turn ("you already have the result"), the
//     memory subagent twice, and in her autonomous sessions the daily cap and the per-chat cooldown of messages she
//     starts herself (these limits are the program's, not the prompt's);
//  2. a risky action (rm -rf, kill, git push, a letter...) waits for the owner's /yes instead of running;
//  3. otherwise the tool runs (independent read-only calls of the round already ran side by side);
//  4. afterwards: the result goes into the history, the deed into the journal, a sent initiative is counted, the
//     panel's feed and the metrics are told.
//
// The autonomy limits of step 1 existed before as functions with their own tests, but nothing called them during a
// turn: in her free time she could write to as many people as she liked.

// execute carries out the calls of one round. It reports whether the round did nothing but wait (wait, pause, skip,
// possibly with a mood change), which ends the turn.
func (t *turn) execute(ctx context.Context, calls []llm.ToolCall) (idleOnly bool) {
	s := t.s
	idle, other := false, false
	t.afterBrowser = false
	t.afterWork = len(calls) > 0
	for _, c := range calls {
		if !workTools[c.Function.Name] {
			t.afterWork = false
		}
	}
	for _, c := range calls {
		tool, _ := s.tools.Get(c.Function.Name)
		if c.Function.Name == "browser" {
			t.afterBrowser = true
			if !t.browsing { // a browsing job needs many rounds: they are paid for by browser.max_steps, not by max_tool_rounds
				t.browsing = true
				t.maxRounds += t.cfg.BrowserSteps + 2
			}
		}
		switch {
		case tool.Idle:
			idle = true
		case c.Function.Name == "change_mood": // bookkeeping only, does not count as an action
		default:
			other = true
		}
	}
	pre := t.a.runParallel(ctx, s, calls, t.seen)
	for i, c := range calls {
		start := time.Now()
		name, args := c.Function.Name, c.Function.Arguments
		target, typing := liveTarget(name, args, s.chat.ID)
		t.a.feed(live.Event{Kind: "tool", Chat: t.label, Text: name + " " + args, ChatID: target, Typing: typing})
		res, ok := pre[i]
		if !ok {
			res = t.call(ctx, c)
		}
		t.after(c, res, start)
	}
	return idle && !other
}

// call runs one call through the guards (step 1-3).
func (t *turn) call(ctx context.Context, c llm.ToolCall) tools.Result {
	s := t.s
	name, args := c.Function.Name, c.Function.Arguments
	tool, known := s.tools.Get(name)
	key := name + "|" + args
	switch {
	case name == "ask" && t.askDone:
		return tools.Result{Text: "You already consulted memory this turn. Answer now with send_telegram_message.", Tool: tool}
	case t.seen[key] && known && !tool.Repeatable:
		return tools.Result{Text: "You already called this with the same arguments and have the result above. Do not repeat it: answer now with send_telegram_message.", Tool: tool}
	}
	if name == "send_telegram_message" {
		if why := t.newArrivals(ctx); why != "" {
			return tools.Result{Text: why, Failed: true, Tool: tool}
		}
		if why := t.voiceGuard(ctx, guardText(args)); why != "" {
			return tools.Result{Text: why, Failed: true, Tool: tool}
		}
	}
	if known && tool.Sends {
		if why := t.a.autoDenied(s, c); why != "" {
			return tools.Result{Text: "Error: not sent: " + why + ".", Failed: true, Tool: tool}
		}
	}
	if why := t.a.riskOf(name, args); why != "" {
		reg := s.tools
		thread := s.thread
		text := t.a.requestApproval(ctx, s, name, args, why, func(rc context.Context) string {
			return reg.Invoke(telegram.WithThread(rc, thread), name, args).Text
		})
		return tools.Result{Text: text, Tool: tool}
	}
	return s.tools.Invoke(telegram.WithThread(ctx, s.thread), name, args)
}

// after files the outcome of a call (step 4).
func (t *turn) after(c llm.ToolCall, res tools.Result, start time.Time) {
	s, a := t.s, t.a
	name, args := c.Function.Name, c.Function.Arguments
	a.feed(live.Event{Kind: "result", Chat: t.label, Text: res.Text})
	log.Printf("agent: chat %d: %s -> %s", s.id, name, oneLine(res.Text, 120))
	t.seen[name+"|"+args] = true
	if !res.Failed {
		t.did[name] = true
	}
	if name == "ask" {
		t.askDone = true
	}
	meta := res.Tool.Meta
	if res.Tool.Name == "" {
		meta = tools.MetaOf(name)
	}
	a.noteCall(s, name, meta, args, res.Text, res.Failed)
	if res.Failed && !strings.HasPrefix(res.Text, "Error: no such tool") {
		a.failures.Add(time.Now(), name, args, res.Text)
	}
	if meta.Sends && !res.Failed {
		a.autoRecord(s, c, res.Text)
	}
	s.msgs = append(s.msgs, llm.Message{Role: "tool", ToolCallID: c.ID, Content: res.Text})
	a.Metrics.Inc("reina_tool_calls_total", 1, map[string]string{"tool": name})
	switch {
	case name == "send_telegram_message" || name == "sticker_send": // an answer in this chat
		if !res.Failed {
			t.reported = true
		}
	case !meta.Quiet:
		t.worked, t.reported = true, false
	}
	// names used by the bundled Grafana dashboard
	d := time.Since(start).Seconds()
	labels := map[string]string{"tool": name, "function": name, "chat": t.label}
	a.Metrics.Inc("tool_call_total", 1, labels)
	a.Metrics.Set("tool_call_response_time_seconds_gauge", d, labels)
	a.Metrics.Observe("tool_call_response_time_seconds", d, map[string]string{"tool": name, "chat": t.label})
}

// runParallel executes the independent read-only calls of one round at the same time and returns their results
// by call index. Everything else (sends, browser steps, shell...) stays in order in the caller's loop.
func (a *Agent) runParallel(ctx context.Context, s *session, calls []llm.ToolCall, seen map[string]bool) map[int]tools.Result {
	if !a.cfg().ParallelTools {
		return nil
	}
	var idx []int
	keys := map[string]bool{}
	for i, c := range calls {
		key := c.Function.Name + "|" + c.Function.Arguments
		tool, ok := s.tools.Get(c.Function.Name)
		if !ok || !tool.ReadOnly || seen[key] || keys[key] {
			continue
		}
		keys[key] = true
		idx = append(idx, i)
	}
	if len(idx) < 2 {
		return nil
	}
	out := make(map[int]tools.Result, len(idx))
	var mu sync.Mutex
	var wg sync.WaitGroup
	for _, i := range idx {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			c := calls[i]
			r := s.tools.Invoke(telegram.WithThread(ctx, s.thread), c.Function.Name, c.Function.Arguments)
			mu.Lock()
			out[i] = r
			mu.Unlock()
		}(i)
	}
	wg.Wait()
	return out
}

// --- her autonomy limits ---

func (a *Agent) limits() autonomy.Limits {
	c := a.cfg()
	return autonomy.Limits{MaxPerDay: c.AutonomyMaxPerDay, ChatCooldown: time.Duration(c.AutonomyChatCooldown) * time.Minute}
}

// autoDenied enforces the limits in code for messages started in the autonomous (id 0) session.
// It returns the reason when the call must not run.
func (a *Agent) autoDenied(s *session, c llm.ToolCall) string {
	cfg := a.cfg()
	if s.id != 0 || a.Auto == nil || !cfg.AutonomyEnabled || !tools.MetaOf(c.Function.Name).Sends {
		return ""
	}
	if s.chat.ID == 0 {
		return "open a chat with open_chat first"
	}
	if ok, why := a.Auto.Allow(s.chat.ID, a.limits(), cfg.IsOwner(s.chat.ID) || a.owed().keeps(s.chat.ID, time.Now())); !ok {
		return why
	}
	return ""
}

// autoRecord counts a successful autonomous message and journals it.
func (a *Agent) autoRecord(s *session, c llm.ToolCall, out string) {
	cfg := a.cfg()
	if s.id != 0 || a.Auto == nil || !cfg.AutonomyEnabled || !tools.MetaOf(c.Function.Name).Sends || strings.HasPrefix(out, "Error") {
		return
	}
	var args struct {
		Text string `json:"text"`
	}
	_ = json.Unmarshal([]byte(c.Function.Arguments), &args)
	text := args.Text
	if text == "" {
		text = fmt.Sprintf("(%s)", c.Function.Name)
	}
	a.Auto.RecordSend(s.chat.ID, s.chat.Title, text, cfg.IsOwner(s.chat.ID))
}
