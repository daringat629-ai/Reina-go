package agent

import (
	"context"
	"strings"
	"time"

	"orvi/internal/telegram"
	"orvi/internal/tools"
)

// aboutMeEvery is how long the card of herself is reused: the account and the laptop change slowly.
const aboutMeEvery = 10 * time.Minute

// aboutMe is the short card of herself that a new session starts with: her Telegram account, how many chats she is
// in, and the laptop she lives on. A person does not look these up, she just knows them. Tools (my_profile_view,
// my_chats, my_laptop) give the details. The card has no secrets and no names of other people.
func (a *Agent) aboutMe(ctx context.Context) string {
	a.aboutMu.Lock()
	defer a.aboutMu.Unlock()
	if a.aboutText != "" && time.Since(a.aboutAt) < aboutMeEvery {
		return a.aboutText
	}
	ctx, cancel := context.WithTimeout(ctx, 3*time.Second)
	defer cancel()
	var lines []string
	if pe, ok := a.TG.(telegram.ProfileEditor); ok {
		if p, err := pe.MyProfile(ctx); err == nil {
			acc := strings.TrimSpace(p.FirstName + " " + p.LastName)
			if p.Username != "" {
				acc += " (@" + p.Username + ")"
			}
			if p.Bio != "" {
				acc += ", био: " + p.Bio
			}
			if p.PersonalChannel != "" {
				acc += ", личный канал в профиле: " + p.PersonalChannel
			}
			lines = append(lines, "Мой аккаунт в Telegram: "+acc+".")
		}
	}
	if chats, err := a.TG.Chats(ctx, 200); err == nil && len(chats) > 0 {
		lines = append(lines, "Мои чаты: "+tools.ChatCounts(chats)+".")
	}
	if m := tools.MachineLine(); m != "" {
		lines = append(lines, "Мой ноутбук, на котором я живу: "+m+".")
	}
	if len(lines) == 0 {
		return ""
	}
	a.aboutText = "<about_me>\n" + strings.Join(lines, "\n") + "\nЭто моё, я это знаю без подсказок. Подробности: my_profile_view, my_chats, my_laptop, my_settings_view.\n</about_me>\n\n"
	a.aboutAt = time.Now()
	return a.aboutText
}
