package agent

import (
	"path/filepath"
	"strings"
	"testing"
	"time"

	"orvi/internal/config"
	"orvi/internal/letters"
	"orvi/internal/telegram"
	"orvi/internal/tools"
)

func TestLetterBlockShowsOpenedLettersOnlyToHerAndHim(t *testing.T) {
	st := letters.Open(filepath.Join(t.TempDir(), "l.json"))
	past := time.Now().Add(-5 * 24 * time.Hour)
	if _, err := st.Write("Дорогая я. Надеюсь, ты всё ещё любишь тишину по ночам.", past.Add(48*time.Hour), past); err != nil {
		t.Fatal(err)
	}
	c := &config.Config{PapikChatID: 77, OwnerTools: true}
	a := &Agent{Cfg: config.NewStaticHolder(c), Deps: tools.Deps{Letters: st}}
	if g := a.letterBlock(telegram.Chat{ID: 77}); !strings.Contains(g, "letters_to_me") || !strings.Contains(g, "тишину") {
		t.Fatal("his chat must show the opened letter:", g)
	}
	if a.letterBlock(telegram.Chat{}) == "" {
		t.Fatal("her free time must show it")
	}
	if a.letterBlock(telegram.Chat{ID: 5}) != "" {
		t.Fatal("never in a stranger's chat")
	}
}
