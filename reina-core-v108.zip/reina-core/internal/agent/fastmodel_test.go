package agent

import (
	"context"
	"strings"
	"testing"
	"time"

	"orvi/internal/telegram"
)

func modelsOfChatRounds(f *fakeLLM) []string {
	f.mu.Lock()
	defer f.mu.Unlock()
	var out []string
	for _, c := range f.calls {
		if _, ok := c["tools"]; ok {
			out = append(out, c["model"].(string))
		}
	}
	return out
}

func fastRig(t *testing.T, fast string) (*rig, *fakeLLM, func()) {
	f := newFakeLLM(t, sendCall)
	r := newRig(t, f)
	cfg := r.ag.Cfg.Get()
	cfg.FastModel, cfg.FastRounds, cfg.FastGroups, cfg.FastShortChars = fast, true, true, 220
	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan struct{})
	go func() { r.ag.Run(ctx); close(done) }()
	return r, f, func() { cancel(); <-done }
}

func TestFastModelAnswersTheQuickRoundsAndTheMainOneTheHardFirstRound(t *testing.T) {
	r, f, stop := fastRig(t, "quick-m")
	defer stop()
	long := strings.Repeat("объясни мне подробно как устроен планировщик в ядре линукса ", 6) // not a short message
	r.tg.Incoming(alex, 100, "Alex", long)
	waitFor(t, "an answer", func() bool { return len(r.tg.SentTexts()) == 1 })
	waitFor(t, "the follow-up round", func() bool { return len(modelsOfChatRounds(f)) >= 2 })
	got := modelsOfChatRounds(f)
	if got[0] != "m" || got[1] != "quick-m" {
		t.Fatalf("a long private message must start on the main model and continue on the fast one: %v", got)
	}
}

func TestFastModelTakesShortMessagesAndGroupBanterFromTheFirstRound(t *testing.T) {
	r, f, stop := fastRig(t, "quick-m")
	defer stop()
	r.tg.Incoming(alex, 100, "Alex", "как дела")
	waitFor(t, "an answer", func() bool { return len(r.tg.SentTexts()) == 1 })
	r.tg.Incoming(telegram.Chat{ID: -900, Title: "Club", Kind: telegram.ChatGroup, IsMember: true}, 301, "Ann", "Reina, ты тут?")
	waitFor(t, "a group answer", func() bool { return len(r.tg.SentTexts()) == 2 })
	time.Sleep(100 * time.Millisecond)
	for _, m := range modelsOfChatRounds(f) {
		if m != "quick-m" {
			t.Fatalf("the main model was used where the fast one should: %v", modelsOfChatRounds(f))
		}
	}
}

func TestWithoutAFastModelNothingChanges(t *testing.T) {
	r, f, stop := fastRig(t, "")
	defer stop()
	r.tg.Incoming(alex, 100, "Alex", "как дела")
	waitFor(t, "an answer", func() bool { return len(r.tg.SentTexts()) == 1 })
	time.Sleep(100 * time.Millisecond)
	for _, m := range modelsOfChatRounds(f) {
		if m != "m" {
			t.Fatalf("%v", modelsOfChatRounds(f))
		}
	}
}
