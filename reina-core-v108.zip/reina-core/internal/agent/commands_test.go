package agent

import (
	"context"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"orvi/internal/allow"
	"orvi/internal/maint"
	"orvi/internal/telegram"
	"orvi/internal/work"
)

func TestSlashCommandsNeverReachTheModel(t *testing.T) {
	f := newFakeLLM(t, sendCall)
	r := newRig(t, f)
	cfg := r.ag.Cfg.Get()
	cfg.PapikChatID = 100
	r.ag.Deps.Work = work.New("")
	r.ag.Deps.Work.Add("Перевод", "", 0)
	r.ag.Started = time.Now().Add(-90 * time.Minute)
	ctx := context.Background()
	chat := telegram.Chat{ID: 100, Title: "Alex", Kind: telegram.ChatPrivate, IsMember: true}

	say := func(id int64, from int64, text string) bool {
		m := telegram.Message{ID: id, ChatID: 100, SenderID: from, SenderName: "Alex", Date: time.Now(), Text: text}
		r.tg.S.Put(m, &chat)
		return r.ag.command(ctx, m)
	}
	lastText := func(n int) string {
		waitFor(t, "a reply", func() bool { return len(r.tg.SentTexts()) >= n })
		return r.tg.SentTexts()[n-1]
	}

	if !say(1, 100, "/status") {
		t.Fatal("/status must be a command")
	}
	st := lastText(1)
	if !strings.Contains(st, "работает") || !strings.Contains(st, "1 ч 30 мин") || !strings.Contains(st, "Заданий открыто: 1") || !strings.Contains(st, "Бэкапов ещё не было") {
		t.Fatalf("status: %q", st)
	}
	if !say(2, 100, "/pause") {
		t.Fatal("/pause must be a command")
	}
	waitFor(t, "pause", r.ag.Paused)
	lastText(2)
	// a paused agent still answers commands, and an ordinary message is not a command
	if !say(3, 100, "/Status@reina_bot") {
		t.Fatal("case and @bot suffix must be accepted")
	}
	if !strings.Contains(lastText(3), "НА ПАУЗЕ") {
		t.Fatal("status must show the pause")
	}
	if say(4, 100, "привет") || say(5, 100, "/нечто") || say(6, 100, "/status") == false {
		t.Fatal("only known commands are commands")
	}
	lastText(4)
	if !say(7, 100, "/resume") {
		t.Fatal()
	}
	waitFor(t, "resume", func() bool { return !r.ag.Paused() })
	// strangers and the owner's own lines are not obeyed
	if say(8, 777, "/stop") {
		t.Fatal("a stranger must not control her")
	}
	time.Sleep(100 * time.Millisecond)
	if r.ag.Paused() {
		t.Fatal("a stranger paused her")
	}
	if r.ag.command(ctx, telegram.Message{ChatID: 100, SenderID: 100, Outgoing: true, Text: "/stop"}) {
		t.Fatal("her own message is not a command")
	}
	// work commands
	if out := r.ag.runCommand(ctx, "work", "", true); !strings.Contains(out, "#1") || !strings.Contains(out, "Перевод") {
		t.Fatal(out)
	}
	r.ag.Deps.Work.Block(1, "платить?")
	if out := r.ag.runCommand(ctx, "work", "answer 1 да, плати 500", true); !strings.Contains(out, "вернулось") {
		t.Fatal(out)
	}
	if j, _ := r.ag.Deps.Work.Get(1); !strings.Contains(j.Notes[0].Text, "плати 500") {
		t.Fatalf("%+v", j)
	}
	if out := r.ag.runCommand(ctx, "work", "cancel 1", true); !strings.Contains(out, "отменено") {
		t.Fatal(out)
	}
	if out := r.ag.runCommand(ctx, "usage", "", true); !strings.Contains(out, "Лимит не задан") {
		t.Fatal(out)
	}
	if len(f.calls) != 0 {
		t.Fatalf("commands made %d model calls", len(f.calls))
	}
}

func TestCommandsAreDroppedFromWhatTheModelReads(t *testing.T) {
	f := newFakeLLM(t, sendCall)
	r := newRig(t, f)
	r.ag.Cfg.Get().PapikChatID = 100
	chat := telegram.Chat{ID: 100, Title: "Alex", Kind: telegram.ChatPrivate, IsMember: true}
	r.tg.S.Put(telegram.Message{ID: 1, ChatID: 100, SenderID: 100, SenderName: "Alex", Date: time.Now(), Text: "/stop"}, &chat)
	if err := r.ag.HandleChat(context.Background(), 100); err != nil {
		t.Fatal(err)
	}
	if len(f.calls) != 0 || len(r.tg.SentTexts()) != 0 {
		t.Fatal("an old command must not be shown to the model or answered late")
	}
	if u, _ := r.tg.Unread(context.Background(), 100); len(u) != 0 {
		t.Fatal("the command must be marked read")
	}
}

func TestBackupCommandSendsACopyWithoutTheConfig(t *testing.T) {
	f := newFakeLLM(t, sendCall)
	r := newRig(t, f)
	cfg := r.ag.Cfg.Get()
	cfg.PapikChatID, cfg.BackupEnabled, cfg.BackupSend, cfg.BackupKeep = 100, true, true, 3
	os.MkdirAll(cfg.DiaryDir, 0o755)
	os.WriteFile(filepath.Join(cfg.DiaryDir, "d.md"), []byte("дневник"), 0o644)
	os.MkdirAll(cfg.DataDir, 0o755)
	os.WriteFile(filepath.Join(cfg.DataDir, "work.json"), []byte("{}"), 0o644)
	cp := filepath.Join(r.dir, "config.toml")
	os.WriteFile(cp, []byte("api_key = SECRET"), 0o644)
	r.ag.ConfigPath = cp

	out := r.ag.runCommand(context.Background(), "backup", "", true)
	if !strings.Contains(out, "Бэкап на диске готов") || !strings.Contains(out, "отправлена") {
		t.Fatal(out)
	}
	if len(maint.Backups(maint.BackupDirOf(cfg))) != 1 {
		t.Fatal("the disk backup is missing")
	}
	sent := r.tg.Docs()
	if len(sent) != 1 || !strings.HasPrefix(sent[0].Name, "reina-") {
		t.Fatalf("copy not sent: %+v", sent)
	}
	if strings.Contains(string(sent[0].Data), "SECRET") || len(sent[0].Data) == 0 {
		t.Fatal("the sent copy must not carry the config")
	}
	if r.ag.lastBackupSent().IsZero() {
		t.Fatal("the send must be remembered, so the loop does not repeat it")
	}
}

func TestWhiteListedPeopleMayUseSafeCommandsOnly(t *testing.T) {
	r := newRig(t, newFakeLLM(t, sendCall))
	cfg := r.ag.Cfg.Get()
	cfg.PapikChatID = 100
	r.ag.Deps.Allow = allow.New(filepath.Join(r.dir, "allow.json"))
	ctx := context.Background()
	put := func(id, chatID, from int64, text string) bool {
		chat := telegram.Chat{ID: chatID, Title: "X", Kind: telegram.ChatPrivate, IsMember: true}
		if chatID < 0 {
			chat.Kind = telegram.ChatGroup
		}
		m := telegram.Message{ID: id, ChatID: chatID, SenderID: from, SenderName: "X", Date: time.Now(), Text: text}
		r.tg.S.Put(m, &chat)
		return r.ag.command(ctx, m)
	}
	// nobody but the owner at first
	if put(1, 77, 77, "/status") {
		t.Fatal("a stranger ran a command")
	}
	r.ag.Deps.Allow.Add(77, "Friend")
	if !put(2, 77, 77, "/status") {
		t.Fatal("a listed person must be able to run /status")
	}
	waitFor(t, "the reply", func() bool { return len(r.tg.SentTexts()) == 1 })
	if !strings.Contains(r.tg.SentTexts()[0], "работает") {
		t.Fatal(r.tg.SentTexts()[0])
	}
	// the owner's own commands stay the owner's
	if put(3, 77, 77, "/backup") || put(4, 77, 77, "/work") {
		t.Fatal("a listed person ran an owner-only command")
	}
	// not in a group, not for somebody else's chat
	if put(5, -9, 77, "/status") {
		t.Fatal("commands from a group")
	}
	// config.toml ids count as well
	cfg.CommandUsers = "5, 88;abc"
	if !put(6, 88, 88, "/usage") {
		t.Fatal("an id from config.toml must be allowed")
	}
	if put(7, 99, 99, "/usage") {
		t.Fatal("an unlisted id ran a command")
	}
	if out := r.ag.runCommand(ctx, "help", "", false); strings.Contains(out, "/backup") || strings.Contains(out, "/work") {
		t.Fatal(out)
	}
	// /pause by a listed person really pauses
	if !put(8, 77, 77, "/pause") {
		t.Fatal("pause")
	}
	waitFor(t, "paused", func() bool { return r.ag.Paused() })
}
