package agent

import (
	"context"
	"sync/atomic"
	"testing"
	"time"

	"orvi/internal/config"
)

func TestOwnerDaytimeIsNotInstantButQuick(t *testing.T) {
	in := baseIn()
	in.Owner, in.OwnerReadMax = true, 6*time.Second
	if p := planPresence(in, fixed(0)); p.Read < time.Second {
		t.Fatalf("owner read at once: %+v", p)
	}
	if p := planPresence(in, fixed(0.99)); p.Read > 6*time.Second || p.Late != 0 || p.Seen != 0 {
		t.Fatalf("owner plan %+v", p)
	}
	in.SinceLast = 20 * time.Second // a live talk: phone in hand
	if p := planPresence(in, fixed(0.99)); p.Read > 1500*time.Millisecond {
		t.Fatalf("live talk with the owner is quick: %+v", p)
	}
}

func TestOwnerAtNightIsSleepyButCappedAndNeverLate(t *testing.T) {
	in := baseIn()
	in.Owner, in.OwnerNightMax, in.SleepLeft = true, 4*time.Minute, 6*time.Hour
	for _, r := range []float64{0, 0.5, 0.99} {
		p := planPresence(in, fixed(r))
		if p.Late != 0 || p.Seen != 0 || p.Read < 30*time.Second || p.Read > 4*time.Minute {
			t.Fatalf("roll %v: owner at night %+v", r, p)
		}
	}
	in.SleepLeft, in.Asleep = 0, true // asleep by go_to_sleep: the same
	if p := planPresence(in, fixed(0.99)); p.Read > 4*time.Minute || p.Late != 0 {
		t.Fatalf("%+v", p)
	}
}

func TestStrangerWhileAsleepIsAnsweredAfterWaking(t *testing.T) {
	in := baseIn()
	in.SleepLeft, in.MorningMin, in.MorningMax = 5*time.Hour, 5*time.Minute, 50*time.Minute
	p := planPresence(in, fixed(0.5))
	if p.Late < 5*time.Hour+5*time.Minute || p.Late > 5*time.Hour+50*time.Minute {
		t.Fatalf("not in the morning: %+v", p)
	}
}

func TestUrgentHasNoArtificialDelay(t *testing.T) {
	in := baseIn()
	in.Urgent, in.SleepLeft, in.Night, in.Asleep, in.SeenChance, in.SlowChance = true, 5*time.Hour, true, true, 1, 1
	in.SinceLast = time.Hour
	p := planPresence(in, fixed(0.99))
	if p.Late != 0 || p.Seen != 0 || p.Read > 1500*time.Millisecond {
		t.Fatalf("someone not okay was kept waiting: %+v", p)
	}
	in.Owner, in.OwnerNightMax = true, 4*time.Minute
	if p := planPresence(in, fixed(0.99)); p.Read > 1500*time.Millisecond {
		t.Fatalf("owner not okay at night: %+v", p)
	}
}

func TestSeenLaterOnlyForCalmPrivateChats(t *testing.T) {
	in := baseIn()
	in.SeenChance, in.SeenMin, in.SeenMax = 1, 3*time.Minute, 25*time.Minute
	if p := planPresence(in, fixed(0.5)); p.Seen < 3*time.Minute || p.Seen > 25*time.Minute || p.Late != 0 {
		t.Fatalf("%+v", p)
	}
	for name, mod := range map[string]func(*presenceIn){
		"owner": func(i *presenceIn) { i.Owner = true },
		"group": func(i *presenceIn) { i.Group = true },
		"live":  func(i *presenceIn) { i.SinceLast = 30 * time.Second },
	} {
		c := in
		mod(&c)
		if p := planPresence(c, fixed(0.5)); p.Seen != 0 {
			t.Fatalf("%s: left on read: %+v", name, p)
		}
	}
}

func TestBusyStretchSlowsNotice(t *testing.T) {
	in := baseIn()
	in.Busy = true
	if p := planPresence(in, fixed(0.5)); p.Read != 12*time.Second {
		t.Fatalf("busy reads later: %+v", p)
	}
	in.SlowChance, in.SinceLast = 0.2, time.Hour // x4 while busy: a roll of 0.5 is now late
	if p := planPresence(in, fixed(0.5)); p.Late == 0 {
		t.Fatalf("busy and slow: %+v", p)
	}
}

func TestSleepWindow(t *testing.T) {
	loc := time.UTC
	at := func(d, h, m int) time.Time { return time.Date(2026, 11, d, h, m, 0, 0, loc) } // 2026-11-02 is a Monday
	// no jitter: Monday night 01:30 .. 10:00 on Tuesday
	if a, w := sleepWindow(at(3, 3, 0), "01:30", "10:00", 0, 60); !a || !w.Equal(at(3, 10, 0)) {
		t.Fatalf("3 am: %v %v", a, w)
	}
	if a, _ := sleepWindow(at(3, 1, 0), "01:30", "10:00", 0, 60); a {
		t.Fatal("01:00 is before bedtime")
	}
	if a, _ := sleepWindow(at(3, 12, 0), "01:30", "10:00", 0, 60); a {
		t.Fatal("noon")
	}
	// Friday night: an hour later both ways (06.11 is a Friday, the night into Saturday)
	if a, _ := sleepWindow(at(7, 2, 0), "01:30", "10:00", 0, 60); a {
		t.Fatal("Friday night she is up until 02:30")
	}
	if a, w := sleepWindow(at(7, 10, 30), "01:30", "10:00", 0, 60); !a || !w.Equal(at(7, 11, 0)) {
		t.Fatalf("Saturday morning: %v %v", a, w)
	}
	// a bedtime before midnight
	if a, _ := sleepWindow(at(3, 23, 30), "23:00", "07:00", 0, 0); !a {
		t.Fatal("23:30 with bedtime 23:00")
	}
	// jitter: stable within a night, within bounds, not the same every night
	_, w1 := sleepWindow(at(3, 4, 0), "01:30", "10:00", 45, 0)
	_, w2 := sleepWindow(at(3, 6, 0), "01:30", "10:00", 45, 0)
	if !w1.Equal(w2) {
		t.Fatalf("the same night has two wake times: %v %v", w1, w2)
	}
	seen := map[time.Duration]bool{}
	for d := 2; d < 16; d++ {
		_, w := sleepWindow(time.Date(2026, 11, d, 5, 0, 0, 0, loc), "01:30", "10:00", 45, 0)
		off := w.Sub(time.Date(2026, 11, d, 10, 0, 0, 0, loc))
		if off < -45*time.Minute || off > 45*time.Minute {
			t.Fatalf("jitter out of bounds: %v", off)
		}
		seen[off] = true
	}
	if len(seen) < 3 {
		t.Fatalf("wake time hardly changes from night to night: %v", seen)
	}
	if a, _ := sleepWindow(at(3, 3, 0), "bad", "10:00", 0, 0); a {
		t.Fatal("a broken bedtime means no schedule")
	}
}

func TestSeenLaterIsCutShortByADoubleText(t *testing.T) {
	old := seenBreak
	seenBreak = func() bool { return true }
	defer func() { seenBreak = old }()
	var handled atomic.Int32
	c := &config.Config{DebounceWindow: 10 * time.Millisecond}
	in := &inbox{chats: map[int64]*chatState{}, cfg: func() *config.Config { return c }, isGroup: func(context.Context, int64) bool { return false },
		handle: func(context.Context, int64) { handled.Add(1) }, title: func(int64) string { return "" }}
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	in.postpone(ctx, 7, time.Hour, true)
	in.schedule(ctx, 7) // "??"
	deadline := time.Now().Add(5 * time.Second)
	for handled.Load() == 0 && time.Now().Before(deadline) {
		time.Sleep(20 * time.Millisecond)
	}
	if handled.Load() != 1 {
		t.Fatalf("the double text did not bring the answer: %d", handled.Load())
	}
	// a plain late reply (unread, she did not look) is not cut short
	in.postpone(ctx, 8, time.Hour, false)
	in.schedule(ctx, 8)
	time.Sleep(3 * time.Second)
	if handled.Load() != 1 {
		t.Fatal("an unread late reply was cut short")
	}
}
