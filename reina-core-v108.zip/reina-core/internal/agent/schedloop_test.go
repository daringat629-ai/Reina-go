package agent

import (
	"path/filepath"
	"strings"
	"testing"
	"time"

	"orvi/internal/sched"
	"orvi/internal/telegram"
)

func TestDueScheduledTaskWakesHerWithItsText(t *testing.T) {
	f := newFakeLLM(t, sendCall)
	r := newRig(t, f)
	r.ag.Cfg.Get().PapikChatID = 100
	r.ag.Deps.Sched = sched.New(filepath.Join(r.dir, "s.json"), time.UTC)
	now := time.Now()
	chat := telegram.Chat{ID: 100, Title: "Alex", Kind: telegram.ChatPrivate, IsMember: true}
	r.tg.S.Put(telegram.Message{ID: 1, ChatID: 100, SenderID: 100, SenderName: "Alex", Date: now, Text: "hi", Read: true}, &chat)
	if _, err := r.ag.Deps.Sched.AddEvery(100, "узнай курс биткоина", time.Minute, now.Add(-2*time.Minute)); err != nil {
		t.Fatal(err)
	}
	r.ag.runSched(t.Context(), now.Add(time.Second))
	waitFor(t, "her message after the task", func() bool { return len(r.tg.SentTexts()) == 1 })
	if p := lastUserPrompt(f); !strings.Contains(p, "узнай курс биткоина") || !strings.Contains(p, "due") {
		t.Fatalf("the task is missing from her prompt (%d bytes)", len(p))
	}
	r.ag.runSched(t.Context(), now.Add(2*time.Second))
	time.Sleep(100 * time.Millisecond)
	if len(r.tg.SentTexts()) != 1 {
		t.Fatal("the task fired twice")
	}
}

func TestMonitorAlertReachesTheOwner(t *testing.T) {
	f := newFakeLLM(t, sendCall)
	r := newRig(t, f)
	r.ag.Cfg.Get().PapikChatID = 100
	r.ag.Deps.Sched = sched.New("", time.UTC)
	now := time.Now()
	chat := telegram.Chat{ID: 100, Title: "Alex", Kind: telegram.ChatPrivate, IsMember: true}
	r.tg.S.Put(telegram.Message{ID: 1, ChatID: 100, SenderID: 100, SenderName: "Alex", Date: now, Text: "hi", Read: true}, &chat)
	// a port nobody listens on is bad right away
	if _, err := r.ag.Deps.Sched.AddMonitor(sched.Monitor{Chat: 100, Kind: "port", Arg: "127.0.0.1:1"}, now); err != nil {
		t.Fatal(err)
	}
	r.ag.runSched(t.Context(), now)
	waitFor(t, "alert", func() bool { return len(r.tg.SentTexts()) == 1 })
	if p := lastUserPrompt(f); !strings.Contains(p, "ALERT") || !strings.Contains(p, "127.0.0.1:1") {
		t.Fatalf("the alert is missing from her prompt (%d bytes)", len(p))
	}
}
