package agent

import (
	"context"
	"path/filepath"
	"testing"

	"orvi/internal/llm"
	"orvi/internal/telegram"
	"orvi/internal/usage"
)

func TestDialogListShowsWhatEachChatSpent(t *testing.T) {
	r := newRig(t, newFakeLLM(t, sendCall))
	tr := usage.New(filepath.Join(r.dir, "u.json"))
	r.ag.Usage = tr
	r.ag.Price = func(string) usage.Prices { return usage.Prices{In: 1, Out: 10} }
	r.ag.LLM.Observer = llm.ObserverFunc(func(ctx context.Context, e llm.Event) {
		if e.HasChat && e.Usage != nil {
			tr.AddChat(e.Chat, e.Model, e.Usage.Prompt, e.Usage.Completion)
		}
	})
	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan struct{})
	go func() { r.ag.Run(ctx); close(done) }()
	defer func() { cancel(); <-done }()

	r.tg.Incoming(telegram.Chat{ID: 100, Title: "Alex", Kind: telegram.ChatPrivate, IsMember: true}, 100, "Alex", "hello")
	waitFor(t, "an answer", func() bool { return len(r.tg.SentTexts()) == 1 })

	var list []DialogInfo
	waitFor(t, "the turn to finish", func() bool {
		list, _ = r.ag.DialogList().([]DialogInfo)
		return len(list) == 1 && !list[0].Busy
	})
	if len(list) != 1 {
		t.Fatalf("dialogs: %+v", list)
	}
	d := list[0]
	if d.ID != 100 || d.In < 100 || d.Out < 10 || !d.HasPrice || d.USD <= 0 {
		t.Fatalf("the chat's spend is missing: %+v", d)
	}
}
