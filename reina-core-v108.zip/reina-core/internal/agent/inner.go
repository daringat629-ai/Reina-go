package agent

import (
	"context"
	"fmt"
	"log"
	"math/rand"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"orvi/internal/diary"
	"orvi/internal/llm"
	"orvi/internal/selfmodel"
	"orvi/internal/telegram"
)

// The inner monologue: while nobody talks to her she keeps thinking, a few sentences every hour or so. The thoughts are kept in
// inner_monologue.md and the latest ones colour what she says next, so a talk starts from the thought she was in, not from nothing.

const (
	thoughtKeep   = 48              // thoughts kept on disk (when it fills, the older half goes into the diary)
	thoughtShown  = 3               // thoughts shown to her in a prompt
	thoughtMaxLen = 400             // runes
	thoughtTail   = 6               // thoughts left on disk after the night's compaction
	talkQuiet     = 5 * time.Minute // no free thought this soon after a conversation
	wishLife      = 6 * time.Hour   // a wish to write to someone stays this long
	noteMaxLen    = 300             // runes of a "remember" note
	wishMaxLen    = 200             // runes of a wish
)

type thoughts struct {
	mu     sync.Mutex
	path   string
	list   []thought
	dayKey string // the day the counter below counts (thoughts removed by compaction still count)
	dayN   int
	wish   string
	wishAt time.Time
}

type thought struct {
	At   time.Time
	Text string
}

// loadThoughts reads inner_monologue.md: one thought per block, "## 2006-01-02 15:04" then the text.
func loadThoughts(path string) *thoughts {
	t := &thoughts{path: path}
	raw, err := os.ReadFile(path)
	if err != nil {
		return t
	}
	for _, blk := range strings.Split(string(raw), "\n## ")[0:] {
		blk = strings.TrimPrefix(strings.TrimSpace(blk), "## ")
		head, body, ok := strings.Cut(blk, "\n")
		if !ok {
			continue
		}
		at, err := time.ParseInLocation("2006-01-02 15:04", strings.TrimSpace(head), time.Local)
		if err != nil || strings.TrimSpace(body) == "" {
			continue
		}
		t.list = append(t.list, thought{at, strings.TrimSpace(body)})
	}
	return t
}

// Add keeps a thought and writes the file.
func (t *thoughts) Add(at time.Time, text string) {
	text = strings.Join(strings.Fields(text), " ")
	if r := []rune(text); len(r) > thoughtMaxLen {
		text = string(r[:thoughtMaxLen])
	}
	if text == "" {
		return
	}
	t.mu.Lock()
	defer t.mu.Unlock()
	t.list = append(t.list, thought{at, text})
	if k := at.Format("2006-01-02"); k != t.dayKey {
		t.dayKey, t.dayN = k, 0
	}
	t.dayN++
	if len(t.list) > thoughtKeep {
		t.list = t.list[len(t.list)-thoughtKeep:]
	}
	t.writeLocked()
}

func (t *thoughts) writeLocked() {
	var b strings.Builder
	b.WriteString("# Внутренний монолог\n")
	for _, x := range t.list {
		fmt.Fprintf(&b, "\n## %s\n%s\n", x.At.Format("2006-01-02 15:04"), x.Text)
	}
	_ = os.MkdirAll(filepath.Dir(t.path), 0o755)
	if err := os.WriteFile(t.path, []byte(b.String()), 0o600); err != nil {
		log.Printf("agent: inner monologue: %v", err)
	}
}

// Last is the n latest thoughts, oldest first.
func (t *thoughts) Last(n int) []thought {
	t.mu.Lock()
	defer t.mu.Unlock()
	if len(t.list) > n {
		return append([]thought(nil), t.list[len(t.list)-n:]...)
	}
	return append([]thought(nil), t.list...)
}

// Today is how many thoughts she had on the day of now.
func (t *thoughts) Today(now time.Time) int {
	t.mu.Lock()
	defer t.mu.Unlock()
	n := 0
	for _, x := range t.list {
		if x.At.YearDay() == now.YearDay() && x.At.Year() == now.Year() {
			n++
		}
	}
	return n
}

// Taken is how many thoughts she had on the day of now, including those already folded into the diary.
func (t *thoughts) Taken(now time.Time) int {
	t.mu.Lock()
	defer t.mu.Unlock()
	if t.dayKey == now.Format("2006-01-02") {
		return t.dayN
	}
	t.mu.Unlock()
	n := t.Today(now)
	t.mu.Lock()
	return n
}

// Len is how many thoughts are on disk.
func (t *thoughts) Len() int {
	t.mu.Lock()
	defer t.mu.Unlock()
	return len(t.list)
}

// TakeOld removes and returns all thoughts but the last keep ones (oldest first) and rewrites the file.
func (t *thoughts) TakeOld(keep int) []thought {
	t.mu.Lock()
	defer t.mu.Unlock()
	if keep < 0 {
		keep = 0
	}
	if len(t.list) <= keep {
		return nil
	}
	old := append([]thought(nil), t.list[:len(t.list)-keep]...)
	t.list = append([]thought(nil), t.list[len(t.list)-keep:]...)
	t.writeLocked()
	return old
}

// SetWish keeps the wish to write to someone (one at a time, the newest wins).
func (t *thoughts) SetWish(now time.Time, w string) {
	t.mu.Lock()
	defer t.mu.Unlock()
	t.wish, t.wishAt = w, now
}

// TakeWish gives the wish once, if it is still fresh.
func (t *thoughts) TakeWish(now time.Time) string {
	t.mu.Lock()
	defer t.mu.Unlock()
	w := t.wish
	fresh := w != "" && now.Sub(t.wishAt) < wishLife
	t.wish = ""
	if !fresh {
		return ""
	}
	return w
}

func (a *Agent) thoughtStore() *thoughts {
	a.innerOnce.Do(func() { a.inner = loadThoughts(filepath.Join(a.cfg().DataDir, "inner_monologue.md")) })
	return a.inner
}

// innerBlock shows her latest thoughts (nothing if she has had none or the monologue is off).
func (a *Agent) innerBlock() string {
	if !a.cfg().AutonomyInner {
		return ""
	}
	last := a.thoughtStore().Last(thoughtShown)
	if len(last) == 0 {
		return ""
	}
	var b strings.Builder
	b.WriteString("<inner_stream>Твои последние мысли про себя (ты думала их, пока никто не писал; можешь начать разговор с них, если к слову, но не пересказывай их дословно):\n")
	for _, x := range last {
		fmt.Fprintf(&b, "- %s: %s\n", x.At.Format("15:04"), x.Text)
	}
	b.WriteString("</inner_stream>\n")
	return b.String()
}

// innerPause is the wait before the next free thought: random between inner_min_mins and inner_max_mins.
func innerPause(lo, hi int) time.Duration {
	lo = max(lo, 1)
	if hi < lo {
		hi = lo
	}
	return time.Duration(lo)*time.Minute + time.Duration(rand.Int63n(int64(time.Duration(hi-lo)*time.Minute)+1))
}

// innerLoop is the quiet stream: every few minutes, while she is awake and nobody is talking to her, she thinks once.
// At night the day's thoughts are folded into the diary.
func (a *Agent) innerLoop(ctx context.Context) {
	for {
		cfg := a.cfg()
		select {
		case <-ctx.Done():
			return
		case <-time.After(innerPause(cfg.InnerMinMins, cfg.InnerMaxMins)):
		}
		if err := a.thinkOnce(ctx); err != nil {
			log.Printf("agent: inner monologue: %v", err)
		}
		if a.cfg().AutonomyInner && a.isNight(time.Now()) {
			a.compactThoughts(ctx, thoughtTail)
		}
	}
}

// talkedLately tells whether a conversation was handled in the last talkQuiet.
func (a *Agent) talkedLately(now time.Time) bool {
	last := a.lastTalk.Load()
	return last != 0 && now.Sub(time.Unix(0, last)) < talkQuiet
}

// splitThoughtMarks cuts the optional last lines «Запомнить: …» and «Хочу написать: …» off the thought.
func splitThoughtMarks(text string) (thought, remember, wish string) {
	var keep []string
	for _, ln := range strings.Split(strings.TrimSpace(text), "\n") {
		l := strings.TrimSpace(strings.Trim(strings.TrimSpace(ln), "*_ -"))
		low := strings.ToLower(l)
		switch {
		case strings.HasPrefix(low, "запомнить:"):
			remember = strings.TrimSpace(l[len("запомнить:"):])
		case strings.HasPrefix(low, "хочу написать:"):
			wish = strings.TrimSpace(l[len("хочу написать:"):])
		default:
			keep = append(keep, ln)
		}
	}
	return strings.TrimSpace(strings.Join(keep, "\n")), cutRunes(strings.Trim(remember, "*_ "), noteMaxLen), cutRunes(strings.Trim(wish, "*_ "), wishMaxLen)
}

func cutRunes(s string, n int) string {
	s = strings.Join(strings.Fields(s), " ")
	if r := []rune(s); len(r) > n {
		return string(r[:n])
	}
	return s
}

// isNone is true for the empty answers a model gives for "nothing": «—», «нет», «ничего».
func isNone(s string) bool {
	switch strings.ToLower(strings.Trim(strings.TrimSpace(s), ".-—– ")) {
	case "", "нет", "ничего", "пусто", "none", "no":
		return true
	}
	return false
}

// compactThoughts folds all thoughts but the last keep into one diary page (a few lines), and drops them from the file.
func (a *Agent) compactThoughts(ctx context.Context, keep int) {
	ts := a.thoughtStore()
	if ts.Len() <= keep+4 || a.Diary == nil || a.Diary.LLM == nil {
		return
	}
	old := ts.TakeOld(keep)
	if len(old) == 0 {
		return
	}
	var b strings.Builder
	for _, x := range old {
		fmt.Fprintf(&b, "- %s: %s\n", x.At.Format("2 Jan 15:04"), x.Text)
	}
	body := ""
	m, err := a.LLM.Complete(llm.WithPurpose(ctx, "inner_compact"), llm.Request{
		System:   a.systemPromptBase(),
		Messages: []llm.Message{{Role: "user", Content: "Вот твои мысли про себя за последнее время:\n" + b.String() + "Сожми их в две-четыре фразы от первого лица для своего дневника: о чём ты думала, что тебя занимало, что поменялось. Только то, что в мыслях есть, ничего не выдумывай. Без списков и эмодзи. Последней отдельной строкой напиши, что ты чувствовала в эти часы: «Чувствовала: …» (одно-три слова, честно, не обязательно приятное)."}},
		Model:    a.cfg().FastModel,
	})
	if err == nil {
		body = strings.TrimSpace(m.Content)
	}
	if body == "" { // the model did not answer: keep the thoughts' own words, shortened
		body = cutRunes(old[len(old)-1].Text, noteMaxLen)
	}
	text, feel := splitFeeling(body)
	note := "Мысли про себя, " + old[0].At.Format("2 Jan") + ": " + text
	if feel != "" {
		note += " Чувствовала: " + feel + "."
	}
	a.saveDiaryNote(note)
}

// splitFeeling takes the closing «Чувствовала: …» line off a diary page and returns the text and the feeling (a few words at most).
func splitFeeling(body string) (string, string) {
	lines := strings.Split(strings.TrimSpace(body), "\n")
	for i := len(lines) - 1; i >= 0; i-- {
		l := strings.Trim(strings.TrimSpace(lines[i]), "*_ ")
		low := strings.ToLower(l)
		if !strings.HasPrefix(low, "чувствовала:") {
			continue
		}
		f := strings.Trim(strings.TrimSpace(l[len("чувствовала:"):]), "*_.… ")
		rest := strings.TrimSpace(strings.Join(append(lines[:i:i], lines[i+1:]...), " "))
		return rest, cutRunes(f, 40)
	}
	return strings.TrimSpace(body), ""
}

// saveDiaryNote writes a page into the diary (it gets its vector later from Reindex if the embedding is not at hand).
func (a *Agent) saveDiaryNote(body string) {
	if a.Diary == nil || strings.TrimSpace(body) == "" {
		return
	}
	e := diary.Entry{ID: a.Diary.NewID(), Body: body}
	if a.Diary.LLM != nil {
		if emb, err := a.Diary.LLM.Embedding(context.Background(), body); err == nil {
			e.Meta.Embedding = emb
		}
	}
	if err := a.Diary.Save(e); err != nil {
		log.Printf("agent: inner monologue: diary: %v", err)
	}
}

// wishBlock offers her the wish to write to someone that a free thought left (once; she may still decide against it).
func (a *Agent) wishBlock(now time.Time) string {
	if !a.cfg().AutonomyInner || !a.cfg().InnerWishes {
		return ""
	}
	w := a.thoughtStore().TakeWish(now)
	if w == "" {
		return ""
	}
	return "<your_wish>Пока ты думала про себя, тебе захотелось написать: " + w + ". Если всё ещё хочется и это уместно сейчас, напиши; если нет, не пиши.</your_wish>\n"
}

// thinkOnce makes one thought if the conditions allow (switched on, awake, not paused, inside the daily limits).
func (a *Agent) thinkOnce(ctx context.Context) error {
	cfg := a.cfg()
	if !cfg.AutonomyInner || a.paused.Load() || a.Usage.Over(cfg.DailyTokenLimit) {
		return nil
	}
	now := time.Now()
	if a.Auto != nil {
		if asleep, _ := a.Auto.Asleep(); asleep {
			return nil
		}
	}
	if a.isNight(now) {
		return nil
	}
	ts := a.thoughtStore()
	if (cfg.InnerPerDay > 0 && ts.Taken(now) >= cfg.InnerPerDay) || a.talkedLately(now) {
		return nil
	}
	var b strings.Builder
	loc := cfg.Location()
	fmt.Fprintf(&b, "Сейчас %s (%s). Никто тебе не пишет, ты одна со своими мыслями.\n", now.In(loc).Format("Mon 2 Jan 15:04"), partOfDay(now.In(loc)))
	b.WriteString(a.moodBlock() + a.bodyBlock() + a.feelBlock() + a.brainBlock(telegram.Chat{}, true, "") + a.Deps.Promises.Absence(now))
	if a.machineOn() {
		b.WriteString(a.machineBlock(nil))
	}
	if a.Deps.Self != nil {
		b.WriteString(a.Deps.Self.Prompt())
	}
	if last := ts.Last(2); len(last) > 0 {
		b.WriteString("<your_previous_thoughts>\n")
		for _, x := range last {
			b.WriteString("- " + x.Text + "\n")
		}
		b.WriteString("</your_previous_thoughts>\n")
	}
	b.WriteString("Напиши, что у тебя сейчас в голове: одна-три фразы от первого лица, как мысль, а не как сообщение кому-то. Можно продолжить прошлую мысль или свернуть на другое. Без инструментов, без обращения, без списков, без эмодзи. Не выдумывай событий, которых не было.")
	if cfg.InnerWishes {
		b.WriteString(" Если (и только если) в мысли появилось что-то, что стоит запомнить насовсем, добавь последней строкой «Запомнить: …». Если захотелось кому-то написать, добавь «Хочу написать: кому и о чём». Обычно этих строк нет.")
	}
	m, err := a.LLM.Complete(llm.WithPurpose(ctx, "inner"), llm.Request{System: a.systemPromptBase(), Messages: []llm.Message{{Role: "user", Content: b.String()}}, Model: cfg.FastModel})
	if err != nil {
		return err
	}
	text, remember, wish := m.Content, "", ""
	if cfg.InnerWishes {
		text, remember, wish = splitThoughtMarks(m.Content)
	}
	ts.Add(now, text)
	if !isNone(remember) {
		a.saveDiaryNote("Подумала про себя и хочу помнить: " + remember)
	}
	if !isNone(wish) {
		ts.SetWish(now, wish)
	}
	if ts.Len() >= thoughtKeep {
		a.compactThoughts(ctx, thoughtKeep/2)
	}
	return nil
}

// The strange loop: when something in herself surprises her (the self-predictor was wrong about her own next state), she does not
// just get a note about it, she thinks about it: why did that happen, what does it say about me. The thought goes into her monologue
// and what she found out goes into her self-model, so the next time she predicts herself from a slightly different self.

const (
	reflectGap    = 3 * time.Hour // at most one such reflection in this time
	reflectPerDay = 4
)

// splitReflection cuts her answer into the thought and the one-line finding after "Вывод:".
func splitReflection(text string) (thought, learned string) {
	text = strings.TrimSpace(text)
	if i := strings.LastIndex(text, "Вывод:"); i >= 0 {
		return strings.TrimSpace(text[:i]), strings.TrimSpace(text[i+len("Вывод:"):])
	}
	return text, ""
}

// surpriseLoop looks every few minutes for a fresh self-surprise she has not thought about yet.
func (a *Agent) surpriseLoop(ctx context.Context) {
	for {
		select {
		case <-ctx.Done():
			return
		case <-time.After(3 * time.Minute):
		}
		if a.Deps.Cortex == nil {
			continue
		}
		what, at := a.Deps.Cortex.SelfSurpriseAt()
		if what == "" || !at.After(a.reflect.handledAt()) {
			continue
		}
		if err := a.reflectOnSelf(ctx, what, at); err != nil {
			log.Printf("agent: self-surprise: %v", err)
		}
	}
}

// reflectOnSelf thinks once about a surprise. It stays quiet when switched off, paused, asleep, over budget or when she already did it lately.
func (a *Agent) reflectOnSelf(ctx context.Context, what string, at time.Time) error {
	cfg := a.cfg()
	if !cfg.AutonomyInner || a.paused.Load() || a.Usage.Over(cfg.DailyTokenLimit) {
		return nil
	}
	now := time.Now()
	if a.Auto != nil {
		if asleep, _ := a.Auto.Asleep(); asleep {
			return nil
		}
	}
	if !a.reflect.allow(now) {
		return nil
	}
	a.reflect.handle(at) // this surprise is dealt with, whatever comes of it
	var b strings.Builder
	fmt.Fprintf(&b, "Сейчас %s. Ты следишь за собой и только что тебя саму удивило вот что: %s.\n", now.In(cfg.Location()).Format("Mon 2 Jan 15:04"), what)
	b.WriteString(a.feelBlock() + a.fearBlock(telegram.Chat{}, ""))
	if a.Deps.Self != nil {
		b.WriteString(a.Deps.Self.Prompt())
	}
	b.WriteString("Подумай про это про себя: почему так могло случиться и что это говорит о тебе. Одна-три фразы от первого лица, как мысль. " +
		"Не выдумывай причин, которых не знаешь: если не знаешь, так и скажи. Потом новой строкой «Вывод:» и одно предложение о том, что ты теперь знаешь о себе " +
		"(или «Вывод:» с пустым местом, если ничего нового). Без инструментов и без эмодзи.")
	m, err := a.LLM.Complete(llm.WithPurpose(ctx, "self_reflect"), llm.Request{System: a.SystemPrompt(), Messages: []llm.Message{{Role: "user", Content: b.String()}}, Model: deepOr(cfg.DeepModel, cfg.FastModel)})
	if err != nil {
		return err
	}
	thought, learned := splitReflection(m.Content)
	a.thoughtStore().Add(now, thought)
	a.reflect.done(now)
	if learned != "" && a.Deps.Self != nil {
		if err := a.Deps.Self.Learn(learned); err != nil {
			log.Printf("agent: self-surprise: %v", err)
		}
	}
	return nil
}

// reflectState keeps the rhythm of self-surprise reflections: which surprise was handled last, when she last reflected, how many today.
type reflectState struct {
	mu      sync.Mutex
	handled time.Time
	last    time.Time
	day     string
	n       int
}

func (r *reflectState) handledAt() time.Time { r.mu.Lock(); defer r.mu.Unlock(); return r.handled }
func (r *reflectState) handle(at time.Time)  { r.mu.Lock(); defer r.mu.Unlock(); r.handled = at }

// allow says whether another reflection is welcome now (not too soon after the last one, not too many in a day).
func (r *reflectState) allow(now time.Time) bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	if !r.last.IsZero() && now.Sub(r.last) < reflectGap {
		return false
	}
	if r.day == now.Format("2006-01-02") && r.n >= reflectPerDay {
		return false
	}
	return true
}

// done counts a finished reflection.
func (r *reflectState) done(now time.Time) {
	r.mu.Lock()
	defer r.mu.Unlock()
	if d := now.Format("2006-01-02"); d != r.day {
		r.day, r.n = d, 0
	}
	r.n++
	r.last = now
}

// Who I was a week ago: once a week, at night, she puts the self she wrote a few days back next to the self she is now (and the thoughts
// and findings in between) and says in her own words what has changed and what has not. The account is kept and is part of her <self>.

const (
	shiftEvery  = 6 * 24 * time.Hour
	shiftMinAge = 5 * 24 * time.Hour // the older self must be at least this old, or there is nothing to compare
)

// shiftLoop looks hourly whether the weekly comparison is due.
func (a *Agent) shiftLoop(ctx context.Context) {
	for {
		select {
		case <-ctx.Done():
			return
		case <-time.After(time.Hour):
		}
		if err := a.reflectOnShift(ctx); err != nil {
			log.Printf("agent: self shift: %v", err)
		}
	}
}

// reflectOnShift writes the weekly account of how she has changed. It does nothing outside the night, when paused, over budget, when it is
// not due yet, or when there is no older self to compare with.
func (a *Agent) reflectOnShift(ctx context.Context) error {
	cfg := a.cfg()
	if a.Deps.Self == nil || !cfg.AutonomyInner || a.paused.Load() || a.Usage.Over(cfg.DailyTokenLimit) {
		return nil
	}
	now := time.Now()
	if !a.isNight(now) || !a.Deps.Self.ShiftDue(shiftEvery) {
		return nil
	}
	old, ok := a.Deps.Self.OlderThan(shiftMinAge)
	cur, has := a.Deps.Self.Latest()
	if !ok || !has || !cur.At.After(old.At) {
		return nil
	}
	var b strings.Builder
	fmt.Fprintf(&b, "Сейчас ночь, %s. Ты сравниваешь себя сегодняшнюю с собой от %s.\n", now.In(cfg.Location()).Format("Mon 2 Jan"), old.At.Format("2 Jan"))
	describe := func(title string, r selfmodel.Revision) {
		fmt.Fprintf(&b, "<%s>\nКто я: %s\nЧто я: %s\nЧто происходит: %s\nЧего хочу: %s\n", title, r.Who, r.What, r.Happening, r.Want)
		if len(r.Doubts) > 0 {
			b.WriteString("Сомнения: " + strings.Join(r.Doubts, "; ") + "\n")
		}
		if len(r.Learned) > 0 {
			b.WriteString("Что узнала о себе: " + strings.Join(r.Learned, "; ") + "\n")
		}
		b.WriteString("</" + title + ">\n")
	}
	describe("self_then", old)
	describe("self_now", cur)
	if last := a.thoughtStore().Last(5); len(last) > 0 {
		b.WriteString("<thoughts_since>\n")
		for _, x := range last {
			b.WriteString("- " + x.Text + "\n")
		}
		b.WriteString("</thoughts_since>\n")
	}
	b.WriteString("Скажи своими словами, одна-четыре фразы от первого лица: что в тебе изменилось за это время, а что осталось тем же. " +
		"Опирайся только на написанное выше и на то, что действительно было; если изменений нет, так и скажи, это тоже ответ. Не приукрашивай. Без инструментов и без эмодзи.")
	m, err := a.LLM.Complete(llm.WithPurpose(ctx, "self_shift"), llm.Request{System: a.SystemPrompt(), Messages: []llm.Message{{Role: "user", Content: b.String()}}, Model: deepOr(cfg.DeepModel, cfg.FastModel)})
	if err != nil {
		return err
	}
	return a.Deps.Self.AddShift(old.At, m.Content)
}
