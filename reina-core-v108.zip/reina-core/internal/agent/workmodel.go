package agent

import (
	"orvi/internal/llm"
	"orvi/internal/tools"
)

// workTools are the tools of a job: looking things up, reading, the browser and the desktop, the shell, files, code. The round that
// follows their results only plans the next step, so it can be answered by the quick work model (llm.work_model).
var workTools = map[string]bool{
	"web_search": true, "read_link": true, "read_file": true, "read_document": true, "http_request": true, "lookup": true,
	"browser": true, "desktop": true, "shell": true, "shell_bg": true, "jobs": true, "run_code": true, "vibe_code": true,
	"files": true, "grep": true, "git": true, "sqlite": true, "ssh": true, "tail_log": true, "sysinfo": true, "rss": true,
	"textutil": true, "calc": true, "archive": true, "see_image": true, "transcribe": true, "convert_doc": true, "netcheck": true,
}

// speaks tells whether a model answer would reach people: plain text, or a tool that sends something to a chat.
// That is the voice, and the voice is always the main model's.
func speaks(m llm.Message) bool {
	if len(m.ToolCalls) == 0 {
		return true
	}
	for _, c := range m.ToolCalls {
		if tools.MetaOf(c.Function.Name).Sends {
			return true
		}
	}
	return false
}

// deepOr is the deep model when there is one, else the fallback.
func deepOr(deep, fallback string) string {
	if deep != "" {
		return deep
	}
	return fallback
}
