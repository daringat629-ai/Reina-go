package agent

import (
	"context"
	"path/filepath"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"orvi/internal/ignore"
	"orvi/internal/llm"
	"orvi/internal/telegram"
)

func ignoreRig(t *testing.T) (*rig, *fakeLLM, func()) {
	f := newFakeLLM(t, sendCall)
	r := newRig(t, f)
	r.ag.Deps.Ignore = ignore.New(filepath.Join(r.dir, "ignore.json"))
	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan struct{})
	go func() { r.ag.Run(ctx); close(done) }()
	return r, f, func() { cancel(); <-done }
}

func TestIgnoredPersonAndChatGetNoAnswer(t *testing.T) {
	r, _, stop := ignoreRig(t)
	defer stop()
	r.ag.Deps.Ignore.Add("user", 555, "Spammer", "", 0)
	r.ag.Deps.Ignore.Add("chat", 777, "Muted", "", 0)
	r.tg.Incoming(telegram.Chat{ID: 555, Title: "Spammer", Kind: telegram.ChatPrivate, IsMember: true}, 555, "Spammer", "hey")
	r.tg.Incoming(telegram.Chat{ID: 777, Title: "Muted", Kind: telegram.ChatPrivate, IsMember: true}, 777, "Muted", "hello")
	time.Sleep(500 * time.Millisecond)
	if n := len(r.tg.SentTexts()); n != 0 {
		t.Fatalf("answered an ignored chat: %v", r.tg.SentTexts())
	}
	if r.ag.Metrics.Get("reina_ignored_total", nil) != 2 {
		t.Fatal("ignored messages were not counted")
	}
	// somebody else is still answered
	r.tg.Incoming(telegram.Chat{ID: 888, Title: "Friend", Kind: telegram.ChatPrivate, IsMember: true}, 888, "Friend", "hi")
	waitFor(t, "an answer for a friend", func() bool { return len(r.tg.SentTexts()) == 1 })
}

func TestOwnerCannotBeShutOutByTheList(t *testing.T) {
	r, _, stop := ignoreRig(t)
	defer stop()
	r.ag.Deps.Ignore.Add("user", 100, "Alex", "", 0) // the owner's id in the test rig
	r.ag.Deps.Ignore.Add("chat", 100, "Alex", "", 0)
	r.tg.Incoming(telegram.Chat{ID: 100, Title: "Alex", Kind: telegram.ChatPrivate, IsMember: true}, 100, "Alex", "hello Reina")
	waitFor(t, "an answer for the owner", func() bool { return len(r.tg.SentTexts()) == 1 })
}

func TestIgnoredPersonIsLeftOutOfAGroupBatch(t *testing.T) {
	r, f, stop := ignoreRig(t)
	defer stop()
	r.ag.Deps.Ignore.Add("user", 201, "Troll", "", 0)
	g := telegram.Chat{ID: -600, Title: "Club", Kind: telegram.ChatGroup, IsMember: true}
	r.tg.Incoming(g, 201, "Troll", "troll words")
	r.tg.Incoming(g, 202, "Ann", "normal words")
	waitFor(t, "an answer", func() bool { return len(r.tg.SentTexts()) == 1 })
	p := lastUserPrompt(f)
	if !strings.Contains(p, "normal words") || strings.Contains(p, "troll words") {
		t.Fatal(p)
	}
}

func TestSheCanMuteASpammer(t *testing.T) {
	var n atomic.Int32
	f := newFakeLLM(t, func(int64) llm.ToolCall {
		if n.Add(1) == 1 {
			return llm.ToolCall{ID: "m1", Type: "function", Function: llm.FunctionCall{Name: "mute_person", Arguments: `{"user_id":301,"hours":2,"reason":"flood"}`}}
		}
		return sendCall(0)
	})
	r := newRig(t, f)
	r.ag.Deps.Ignore = ignore.New(filepath.Join(r.dir, "ignore.json"))
	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan struct{})
	go func() { r.ag.Run(ctx); close(done) }()
	defer func() { cancel(); <-done }()

	g := telegram.Chat{ID: -800, Title: "Club", Kind: telegram.ChatGroup, IsMember: true}
	r.tg.Incoming(g, 301, "Spammer", "buy buy buy")
	waitFor(t, "the mute", func() bool { return r.ag.Deps.Ignore.User(301) })
	calls := n.Load()
	r.tg.Incoming(g, 301, "Spammer", "buy more")
	time.Sleep(500 * time.Millisecond)
	if n.Load() != calls {
		t.Fatal("the muted spammer woke the model again")
	}
	if es := r.ag.Deps.Ignore.List(); len(es) != 1 || es[0].Note != "muted by her: flood" {
		t.Fatalf("%+v", es)
	}
}
