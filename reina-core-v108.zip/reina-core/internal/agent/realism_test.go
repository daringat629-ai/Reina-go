package agent

import (
	"context"
	"fmt"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"orvi/internal/llm"
	"orvi/internal/telegram"
)

func sends(texts ...string) []llm.Message {
	var out []llm.Message
	for i, t := range texts {
		out = append(out,
			llm.Message{Role: "user", Content: "msg"},
			llm.Message{Role: "assistant", ToolCalls: []llm.ToolCall{{ID: fmt.Sprint(i), Type: "function", Function: llm.FunctionCall{
				Name: "send_telegram_message", Arguments: fmt.Sprintf(`{"text":%q}`, t)}}}},
			llm.Message{Role: "tool", Content: "sent"})
	}
	return out
}

func TestSentTextsReadsHerMessages(t *testing.T) {
	msgs := append(sends("первое", "второе"), llm.Message{Role: "assistant", ToolCalls: []llm.ToolCall{{Function: llm.FunctionCall{Name: "wait", Arguments: `{}`}}}})
	got := sentTexts(msgs)
	if len(got) != 2 || got[0] != "первое" || got[1] != "второе" {
		t.Fatalf("%q", got)
	}
}

func TestTicHintCatchesHabits(t *testing.T) {
	if ticHint(sentTexts(sends("привет", "как дела"))) != "" {
		t.Fatal("two messages are too few to call a habit")
	}
	varied := sentTexts(sends("привет", "ну и что дальше", "бля, серьёзно?", "ладно, пусть будет", "хз, посмотрим"))
	if h := ticHint(varied); h != "" {
		t.Fatalf("a varied voice must not be nagged: %s", h)
	}
	// "папик" in every line, the same opener, a question at the end of everything, emoji
	bad := sentTexts(sends("Чего ржёшь, папик?", "Чего хочешь, папик? 😅", "Чего молчишь, папик?", "Чего там, папик? 😅", "Опять ты? 😅"))
	h := ticHint(bad)
	for _, want := range []string{"«чего»", "«папик»", "question", "emoji", "<style_check>"} {
		if !strings.Contains(h, want) {
			t.Errorf("hint lacks %q:\n%s", want, h)
		}
	}
	frame := sentTexts(sends("Я про диск, а не про смех", "Я про дело, а не про шутки", "Тебе работа, а не болтовня", "ну ладно"))
	if h := ticHint(frame); !strings.Contains(h, "а не Y") {
		t.Fatalf("the «X, а не Y» frame must be caught: %s", h)
	}
	// only the last eight count: an old habit is history
	old := sends("Чего, папик?", "Чего, папик?", "Чего, папик?")
	old = append(old, sends("а", "б", "в", "г", "д", "е", "ж", "з")...)
	if h := ticHint(sentTexts(old)); h != "" {
		t.Fatalf("old habits must be forgiven: %s", h)
	}
}

func TestCasualHintDice(t *testing.T) {
	var intn func(int) int
	roll := func(n int) int { return intn(n) }
	laugh := []telegram.Message{{Text: "Хахахаха"}}
	long := []telegram.Message{{Text: "расскажи мне подробно как устроена память у тебя"}}
	intn = func(int) int { return 0 } // the lucky roll
	if h := casualHint(30, 15, laugh, roll); !strings.Contains(h, "#wait") {
		t.Fatalf("a bare laugh may be left without an answer: %q", h)
	}
	if h := casualHint(0, 15, laugh, roll); !strings.Contains(h, "one to three words") {
		t.Fatalf("with ignoring off a short message gets the brief hint: %q", h)
	}
	if casualHint(30, 15, long, roll) != "" {
		t.Fatal("a real question is always answered properly")
	}
	if casualHint(30, 15, []telegram.Message{{Text: "ха", Media: telegram.MediaVoice}}, roll) != "" {
		t.Fatal("voice and media are not 'a bare laugh'")
	}
	if casualHint(30, 15, []telegram.Message{{Text: "ха", Outgoing: true}}, roll) != "" {
		t.Fatal("her own message is not something to answer")
	}
	intn = func(int) int { return 99 } // the unlucky roll
	if casualHint(30, 15, laugh, roll) != "" {
		t.Fatal("no luck, no hint")
	}
	if casualHint(0, 0, laugh, roll) != "" {
		t.Fatal("both switched off: never")
	}
}

func TestLifeLineIsConsistentWithinAPartOfTheDay(t *testing.T) {
	day := time.Date(2026, 10, 20, 0, 0, 0, 0, time.UTC)
	for h := 0; h < 24; h++ {
		if lifeLine(day.Add(time.Duration(h)*time.Hour)) == "" {
			t.Fatalf("hour %d has no routine", h)
		}
	}
	body := func(h, m int) string {
		s := lifeLine(day.Add(time.Duration(h)*time.Hour + time.Duration(m)*time.Minute))
		return s[strings.Index(s, "you are: "):strings.Index(s, ". Say it")]
	}
	if body(10, 5) != body(12, 50) {
		t.Fatal("within one part of the day she must not change her story")
	}
	if !strings.Contains(lifeLine(day.Add(3*time.Hour)), "03:00") {
		t.Fatal("the line names the hour")
	}
	if first, again := lifeLine(day.Add(10*time.Hour)), lifeLine(day.Add(10*time.Hour)); first != again {
		t.Fatal("deterministic")
	}
}

func TestPresenceSlowMoments(t *testing.T) {
	in := baseIn()
	in.SlowChance, in.SinceLast = 0.06, 10*time.Minute
	if p := planPresence(in, fixed(0.01)); p.Late < 2*time.Minute || p.Late > 12*time.Minute {
		t.Fatalf("a busy moment must delay a stranger by minutes: %+v", p)
	}
	if p := planPresence(in, fixed(0.9)); p.Late != 0 {
		t.Fatalf("usually she is not busy: %+v", p)
	}
	live := in
	live.SinceLast = 20 * time.Second
	if p := planPresence(live, fixed(0.01)); p.Late != 0 {
		t.Fatalf("in a live conversation she does not vanish: %+v", p)
	}
	own := baseIn()
	own.Owner, own.SlowChance, own.SinceLast = true, 0.06, 10*time.Minute
	if p := planPresence(own, fixed(0.01)); p.Late != 0 || p.Read < 15*time.Second || p.Read > time.Minute {
		t.Fatalf("with the owner a busy moment is seconds, never a postponement: %+v", p)
	}
	own.SinceLast = 20 * time.Second
	if p := planPresence(own, fixed(0.01)); p.Read > 1500*time.Millisecond {
		t.Fatalf("mid-conversation with the owner: no delay: %+v", p)
	}
}

func TestTurnCarriesRealismBlocksOnlyOnce(t *testing.T) {
	var n int32
	f := newFakeLLM(t, func(int64) llm.ToolCall { // different texts: identical consecutive sends are swallowed by the anti-repeat guard
		return llm.ToolCall{ID: "c1", Type: "function", Function: llm.FunctionCall{
			Name: "send_telegram_message", Arguments: fmt.Sprintf(`{"text":"answer number %d","photo_filename":null,"audio_filename":null,"reply_to_message_id":null}`, atomic.AddInt32(&n, 1))}}
	})
	r := newRig(t, f)
	cfg := r.ag.Cfg.Get()
	cfg.LifeEnabled, cfg.TicGuard = true, true
	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan struct{})
	go func() { r.ag.Run(ctx); close(done) }()
	defer func() { cancel(); <-done }()

	alex := telegram.Chat{ID: 100, Title: "Alex", Kind: telegram.ChatPrivate, IsMember: true}
	r.tg.Incoming(alex, 100, "Alex", "hello Reina")
	waitFor(t, "first answer", func() bool { return len(r.tg.SentTexts()) == 1 })
	time.Sleep(100 * time.Millisecond)
	r.tg.Incoming(alex, 100, "Alex", "and again")
	waitFor(t, "second answer", func() bool { return len(r.tg.SentTexts()) == 2 })

	f.mu.Lock()
	defer f.mu.Unlock()
	var last map[string]any
	for _, c := range f.calls {
		if _, ok := c["tools"]; ok {
			last = c
		}
	}
	msgs, _ := last["messages"].([]any)
	lives := 0
	for _, m := range msgs {
		if s, _ := m.(map[string]any)["content"].(string); strings.Contains(s, "<life>") || strings.Contains(s, "\\u003clife\\u003e") {
			lives++
		}
	}
	if lives != 1 {
		t.Fatalf("<life> must appear in the newest message only, found it in %d", lives)
	}
}
