package agent

import (
	"strings"
	"testing"
	"time"

	"orvi/internal/telegram"
)

func TestDayDigest(t *testing.T) {
	now := time.Date(2026, 11, 2, 18, 0, 0, 0, time.UTC)
	at := func(h, m int) time.Time { return time.Date(2026, 11, 2, h, m, 0, 0, time.UTC) }
	older := []telegram.Message{
		{Date: now.Add(-30 * time.Hour), SenderName: "Рома", Text: "вчерашнее, не должно попасть"},
		{Date: at(9, 5), SenderName: "Рома", Text: "поздравь её сегодня"},
		{Date: at(9, 6), Outgoing: true, Text: "ок, поздравила\n\nи написала ей"},
		{Date: at(9, 7), SenderName: "Рома", Media: telegram.MediaPhoto},
		{Date: at(9, 8), SenderName: "Рома"},
	}
	got := dayDigest(older, now)
	for _, want := range []string{"<earlier_today>", "09:05 Рома: поздравь её сегодня", "09:06 ты: ок, поздравила и написала ей", "[photo]"} {
		if !strings.Contains(got, want) {
			t.Errorf("missing %q in\n%s", want, got)
		}
	}
	if strings.Contains(got, "вчерашнее") {
		t.Errorf("an old message leaked in:\n%s", got)
	}
	if dayDigest(nil, now) != "" || dayDigest(older[:1], now) != "" {
		t.Error("nothing recent: no block")
	}
	// a long talk keeps the newest lines within the budget
	var many []telegram.Message
	for i := 0; i < 200; i++ {
		many = append(many, telegram.Message{Date: at(10, i%60), SenderName: "Рома", Text: strings.Repeat("я", 140)})
	}
	if g := dayDigest(many, now); len(g) > digestChars+400 {
		t.Errorf("block too long: %d", len(g))
	}
}
