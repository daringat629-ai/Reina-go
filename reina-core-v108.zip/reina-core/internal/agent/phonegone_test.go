package agent

import (
	"strings"
	"testing"
	"time"

	"orvi/internal/config"
	"orvi/internal/tools"
)

func TestSelfBlockSaysPhoneGoneOnlyAfterARealLoss(t *testing.T) {
	a := &Agent{Cfg: config.NewStaticHolder(&config.Config{PhoneADB: "192.168.1.50:5555"})}
	defer func(w *tools.PhoneWatch) { tools.Phone = w }(tools.Phone)
	tools.Phone = &tools.PhoneWatch{}
	if strings.Contains(a.selfBlock(), "phone_gone") {
		t.Fatal("nothing lost yet")
	}
	now := time.Now()
	tools.Phone.Set(true, now.Add(-30*time.Minute))
	tools.Phone.Set(false, now.Add(-20*time.Minute))
	if b := a.selfBlock(); !strings.Contains(b, "phone_gone") || !strings.Contains(b, "не делай из этого вину") {
		t.Fatal("must feel the loss calmly:", b)
	}
	a.Cfg = config.NewStaticHolder(&config.Config{})
	if strings.Contains(a.selfBlock(), "phone_gone") {
		t.Fatal("no phone configured: no phantom")
	}
}
