package agent

import (
	"context"
	"fmt"
	"strings"
	"time"

	"orvi/internal/llmui"
	"orvi/internal/telegram"
	"orvi/internal/util"
)

type note struct {
	at   time.Time
	text string
}

const (
	maxNotes = 8
	noteTTL  = 12 * time.Hour
)

var (
	happyReactions = map[string]bool{"❤": true, "🔥": true, "👍": true, "😍": true, "🥰": true, "👏": true, "😁": true, "🤩": true, "💯": true,
		"🎉": true, "😂": true, "🤗": true, "😘": true, "💋": true, "🥳": true, "🏆": true, "🤝": true}
	angryReactions = map[string]bool{"👎": true, "🤮": true, "💩": true, "😡": true, "🤬": true, "🖕": true, "😴": true}
)

func snippet(s string, n int) string {
	s = strings.Join(strings.Fields(llmui.Sanitize(s)), " ")
	if r := []rune(s); len(r) > n {
		return string(r[:n]) + "…"
	}
	return s
}

// onEvent turns a reaction or an edit into a note for the chat's next turn. Reactions also nudge the mood a little.
// It never starts a turn: that would cost a paid model call for every like.
func (a *Agent) onEvent(ctx context.Context, ev telegram.Event) {
	if !a.Deps.Accessible(ev.ChatID) {
		return
	}
	actor := ev.Actor
	if actor == "" {
		actor = "someone"
	}
	var text string
	switch ev.Kind {
	case telegram.EventReaction:
		what := ""
		if m, err := a.TG.Message(ctx, ev.ChatID, ev.MsgID); err == nil {
			what = m.Text
			if what == "" && m.Media != telegram.MediaNone {
				what = "[" + string(m.Media) + "]"
			}
		}
		text = fmt.Sprintf("%s reacted %s to your message #%d %q", actor, ev.Emoji, ev.MsgID, snippet(what, 80))
		a.reactionMood(ev)
		a.Metrics.Inc("reina_telegram_reactions_received_total", 1, nil)
	case telegram.EventEdit:
		if strings.TrimSpace(ev.New) == "" {
			text = fmt.Sprintf("%s edited message #%d and removed its text (was %q)", actor, ev.MsgID, snippet(ev.Old, 100))
		} else {
			text = fmt.Sprintf("%s edited message #%d: was %q, now %q", actor, ev.MsgID, snippet(ev.Old, 100), snippet(ev.New, 120))
		}
		a.Metrics.Inc("reina_telegram_edits_received_total", 1, nil)
	default:
		return
	}
	s := a.getSession(ev.ChatID)
	s.nmu.Lock()
	s.notes = append(s.notes, note{time.Now(), text})
	if len(s.notes) > maxNotes {
		s.notes = s.notes[len(s.notes)-maxNotes:]
	}
	s.nmu.Unlock()
}

func (a *Agent) reactionMood(ev telegram.Event) {
	cfg := a.cfg()
	if !cfg.MoodEnabled || a.Deps.Mood == nil {
		return
	}
	d := 0
	switch {
	case happyReactions[ev.Emoji]:
		d = 1
	case angryReactions[ev.Emoji]:
		d = -2
	}
	if d != 0 && cfg.IsOwner(ev.ActorID) {
		d *= 2 // what the owner thinks matters more
	}
	if d != 0 {
		a.Deps.Mood.Add(d)
	}
}

// takeNotes returns the pending notes of the session as a prompt block and forgets them.
func (a *Agent) takeNotes(s *session, now time.Time) string {
	s.nmu.Lock()
	notes := s.notes
	s.notes = nil
	s.nmu.Unlock()
	var lines []string
	for _, n := range notes {
		if now.Sub(n.at) < noteTTL {
			lines = append(lines, fmt.Sprintf("- %s (%s)", n.text, util.TimeAgo(n.at, now)))
		}
	}
	if len(lines) == 0 {
		return ""
	}
	return "<while_you_were_away>\n" + strings.Join(lines, "\n") + "\n</while_you_were_away>\n"
}

// NoteOwnerAction tells her, in the chat's next turn, that the owner did something from the panel with her account
// (take-over mode), so she does not take his message for her own and does not repeat it.
func (a *Agent) NoteOwnerAction(chatID int64, text string) {
	s := a.getSession(chatID)
	s.nmu.Lock()
	s.notes = append(s.notes, note{time.Now(), "the owner did this himself from the panel with your account: " + text})
	if len(s.notes) > maxNotes {
		s.notes = s.notes[len(s.notes)-maxNotes:]
	}
	s.nmu.Unlock()
}
