package agent

import (
	"fmt"
	"strings"
	"time"

	"orvi/internal/telegram"
)

// How much of today's older talk a private chat carries along in short.
const (
	digestFetch  = 80             // messages looked at beyond the ones she sees in full
	digestWindow = 14 * time.Hour // "today": the talk of the last stretch of waking hours
	digestChars  = 2400           // the whole block; the newest lines are kept when it does not fit
	digestMine   = 110            // runes kept of her own line
	digestTheirs = 150            // runes kept of the other person's line
)

// dayDigest is a short, cheap (no model call) record of what was said earlier today in a private chat, older than
// the messages she sees in full: one line each, long ones cut. Without it, a talk that runs for hours is cut to the
// last few messages, and she asks again about what was settled in the morning ("did you congratulate her?").
func dayDigest(older []telegram.Message, now time.Time) string {
	var lines []string
	size := 0
	for i := len(older) - 1; i >= 0; i-- {
		m := older[i]
		if m.Date.Before(now.Add(-digestWindow)) {
			break
		}
		line := digestLine(m)
		if line == "" {
			continue
		}
		if size+len(line) > digestChars {
			break
		}
		size += len(line) + 1
		lines = append(lines, line)
	}
	if len(lines) == 0 {
		return ""
	}
	for i, j := 0, len(lines)-1; i < j; i, j = i+1, j-1 {
		lines[i], lines[j] = lines[j], lines[i]
	}
	return "<earlier_today>\nКратко, что уже было сегодня в этом чате до последних сообщений. Это было на самом деле: не переспрашивай то, что тут уже сказано, и не делай вид, что этого не было.\n" +
		strings.Join(lines, "\n") + "\n</earlier_today>\n"
}

func digestLine(m telegram.Message) string {
	text := strings.Join(strings.Fields(m.Text), " ")
	if text == "" && m.Media != "" {
		text = "[" + string(m.Media) + "]"
	}
	if text == "" {
		return ""
	}
	who, limit := safeName(m.SenderName), digestTheirs
	if m.Outgoing {
		who, limit = "ты", digestMine
	}
	if r := []rune(text); len(r) > limit {
		text = string(r[:limit]) + "…"
	}
	return fmt.Sprintf("%s %s: %s", m.Date.Format("15:04"), who, text)
}

// digestSize is how many bytes of a history view are the "earlier today" block.
func digestSize(history string) int {
	i := strings.Index(history, "<earlier_today>")
	j := strings.Index(history, "</earlier_today>")
	if i < 0 || j < i {
		return 0
	}
	return j - i
}
