package agent

import (
	"strings"
	"testing"
	"time"

	"orvi/internal/config"
	"orvi/internal/telegram"
)

func TestRhythmBlockIsOffByDefaultAndOnlyInTheOwnersChat(t *testing.T) {
	c := &config.Config{PapikChatID: 77, OwnerTools: true}
	a := &Agent{Cfg: config.NewStaticHolder(c)}
	now := time.Now()
	for i := 0; i < 60; i++ {
		a.rhythmT().Observe(int64(i+1), now.Add(-48*time.Hour+time.Duration(i)*40*time.Second), "нормально, я потом отвечу тебе подробнее")
	}
	for i := 0; i < 8; i++ {
		a.rhythmT().Observe(int64(1000+i), now.Add(-time.Duration(8-i)*3*time.Second), "СРОЧНО!!!")
	}
	if a.rhythmBlock(telegram.Chat{ID: 77}) != "" {
		t.Fatal("off by default")
	}
	c.OwnerRhythm = true
	if g := a.rhythmBlock(telegram.Chat{ID: 77}); !strings.Contains(g, "owner_rhythm") {
		t.Fatal("must guess in his chat:", g)
	}
	if a.rhythmBlock(telegram.Chat{ID: 5}) != "" {
		t.Fatal("never in another chat")
	}
}
