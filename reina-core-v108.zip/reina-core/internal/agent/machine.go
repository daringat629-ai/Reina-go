package agent

import (
	"time"

	"orvi/internal/machine"
)

// The machine mode (capabilities.machine_feeling): the prompt carries the computational state instead of the body, the feelings and the senses.
// The old modules keep running; this file only reads them.

func (a *Agent) machineOn() bool { return a.Cfg != nil && a.cfg().MachineFeeling }

// machineState collects the signals of body, feel, sense, cortex and brain (and the size of the context of s, if given).
func (a *Agent) machineState(now time.Time, s *session) machine.State {
	in := machine.Inputs{Drives: map[string]float64{}}
	if a.Deps.Body != nil {
		b := a.Deps.Body.Snapshot()
		in.Fatigue, in.Sleep, in.Stress, in.Pain, in.Hunger, in.Thirst = b.Fatigue, b.Sleep, b.Stress, b.Pain, b.Hunger(), b.Thirst()
	}
	if a.Deps.Sense != nil {
		in.Surprise = a.Deps.Sense.Snapshot().Surprise()
	}
	if a.Deps.Feel != nil {
		f := a.Deps.Feel.Snapshot()
		in.Valence, in.Arousal = f.Valence, f.Arousal
	}
	if a.Deps.Promises != nil {
		_, _, over := a.Deps.Promises.Stats(now)
		in.BrokenWord = over > 0
		_, owed := a.Deps.Promises.OpenMine(now)
		in.OwedWord = owed > 0
		in.Silence = a.Deps.Promises.Silence(now)
	}
	if a.Deps.Cortex != nil {
		o := a.Deps.Cortex.Outputs()
		in.Threat, in.Reward, in.Conflict, in.SleepUrge, in.Novelty = o.Threat, o.Reward, o.Conflict, o.SleepUrge, o.Novelty
	}
	if a.Deps.Brain != nil {
		for _, d := range a.Deps.Brain.Drives() {
			in.Drives[d.Name] = d.Value
		}
	}
	a.machMu.Lock()
	if s != nil {
		a.machFill = a.contextFill(s)
	}
	in.ContextFill = a.machFill
	a.machMu.Unlock()
	if last := a.thoughtStore().Last(1); len(last) > 0 {
		in.SinceUpdate = now.Sub(last[0].At)
	}
	st := machine.From(in)
	a.machMu.Lock()
	a.mach, a.machAt = st, now
	a.machMu.Unlock()
	return st
}

// contextFill is how full the working context of a session is, 0..1 (1 = about to be compacted).
func (a *Agent) contextFill(s *session) float64 {
	cfg := a.cfg()
	fill := 0.0
	if keep := cfg.HistoryKeep; keep > 0 {
		fill = float64(len(s.msgs)) / float64(2*keep)
	}
	if cfg.ContextChars > 0 {
		size := 0
		for _, m := range s.msgs {
			size += msgSize(m)
		}
		if f := float64(size) / float64(2*cfg.ContextChars); f > fill {
			fill = f
		}
	}
	if fill > 1 {
		fill = 1
	}
	return fill
}

// LastMachine is the latest machine state the agent computed (for the panel); ok is false before the first one.
func (a *Agent) LastMachine() (machine.State, time.Time, bool) {
	a.machMu.Lock()
	defer a.machMu.Unlock()
	return a.mach, a.machAt, !a.machAt.IsZero()
}

// machineBlock is what the prompt carries instead of the body, the feelings and the senses.
func (a *Agent) machineBlock(s *session) string {
	st := a.machineState(time.Now(), s)
	return st.Prompt(machine.PolicyOf(st, a.cfg().MaxToolRounds))
}

// machineRounds applies the policy to the round limit of a turn (the program's own rule, not a request to the model).
func (a *Agent) machineRounds(base int, s *session) int {
	if !a.machineOn() {
		return base
	}
	if p := machine.PolicyOf(a.machineState(time.Now(), s), base); p.MaxRounds > 0 && p.MaxRounds < base {
		return p.MaxRounds
	}
	return base
}
