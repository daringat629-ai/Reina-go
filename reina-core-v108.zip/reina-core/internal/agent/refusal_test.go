package agent

import (
	"context"
	"encoding/json"
	"strings"
	"sync"
	"testing"
	"time"

	"orvi/internal/config"
	"orvi/internal/llm"
	"orvi/internal/telegram"
)

func sendText(id, text string) llm.ToolCall {
	args, _ := json.Marshal(map[string]any{"text": text, "photo_filename": nil, "audio_filename": nil, "reply_to_message_id": nil})
	return llm.ToolCall{ID: id, Type: "function", Function: llm.FunctionCall{Name: "send_telegram_message", Arguments: string(args)}}
}

// A refusal given without any tool call is never sent: the model is asked again with a hint, and the second answer goes out.
func TestRefusalWithoutToolIsHeldBack(t *testing.T) {
	var mu sync.Mutex
	n := 0
	f := newFakeLLM(t, func(int64) llm.ToolCall {
		mu.Lock()
		defer mu.Unlock()
		n++
		if n == 1 {
			return sendText("c1", "блять, не могу — у меня нет пальцев, жми сам")
		}
		return sendText("c2", "отправила /start, жду ответ")
	})
	r := newRig(t, f)
	cfg := *r.ag.Cfg.Get()
	cfg.RefusalGuard = true
	r.ag.Cfg = config.NewStaticHolder(&cfg)

	chat := telegram.Chat{ID: 100, Title: "Alex", Kind: telegram.ChatPrivate, IsMember: true}
	r.tg.S.Put(telegram.Message{ID: 1, ChatID: 100, SenderID: 100, SenderName: "Alex", Date: time.Now(), Text: "проверь бота и нажми старт"}, &chat)
	if err := r.ag.HandleChat(context.Background(), 100); err != nil {
		t.Fatal(err)
	}

	for _, s := range r.tg.SentTexts() {
		if strings.Contains(s, "нет пальцев") {
			t.Fatalf("the refusal must not reach the chat: %q", s)
		}
	}
	got := r.tg.SentTexts()
	if len(got) == 0 || got[0] != "отправила /start, жду ответ" {
		t.Fatalf("the second answer must go out, sent %q", got)
	}
	if v := r.ag.Metrics.Get("reina_agent_refusal_guard_total", nil); v != 1 {
		t.Fatalf("guard metric = %v, want 1", v)
	}
	// the second request carried the hint
	f.mu.Lock()
	defer f.mu.Unlock()
	hinted := false
	for _, c := range f.calls {
		if b, _ := json.Marshal(c["messages"]); strings.Contains(string(b), "Never say you tried") {
			hinted = true
		}
	}
	if !hinted {
		t.Fatal("the retry must carry the refusal hint")
	}
}

// The guard works once per turn: if she still refuses after the hint, the refusal goes through.
func TestRealRefusalGoesThroughOnSecondTry(t *testing.T) {
	f := newFakeLLM(t, func(int64) llm.ToolCall {
		return sendText("c1", "не могу, у меня нет доступа к этому")
	})
	r := newRig(t, f)
	cfg := *r.ag.Cfg.Get()
	cfg.RefusalGuard = true
	r.ag.Cfg = config.NewStaticHolder(&cfg)

	chat := telegram.Chat{ID: 100, Title: "Alex", Kind: telegram.ChatPrivate, IsMember: true}
	r.tg.S.Put(telegram.Message{ID: 1, ChatID: 100, SenderID: 100, SenderName: "Alex", Date: time.Now(), Text: "купи мне билет"}, &chat)
	if err := r.ag.HandleChat(context.Background(), 100); err != nil {
		t.Fatal(err)
	}
	if got := r.tg.SentTexts(); len(got) != 1 || !strings.Contains(got[0], "не могу") {
		t.Fatalf("the real refusal must be delivered once, sent %q", got)
	}
}

// Off by config: nothing is held back.
func TestRefusalGuardCanBeSwitchedOff(t *testing.T) {
	f := newFakeLLM(t, func(int64) llm.ToolCall { return sendText("c1", "не могу, нет пальцев") })
	r := newRig(t, f)
	chat := telegram.Chat{ID: 100, Title: "Alex", Kind: telegram.ChatPrivate, IsMember: true}
	r.tg.S.Put(telegram.Message{ID: 1, ChatID: 100, SenderID: 100, SenderName: "Alex", Date: time.Now(), Text: "нажми старт"}, &chat)
	if err := r.ag.HandleChat(context.Background(), 100); err != nil {
		t.Fatal(err)
	}
	if got := r.tg.SentTexts(); len(got) != 1 {
		t.Fatalf("guard off: the answer goes out as is, sent %q", got)
	}
}

func TestRefusesWorkDetector(t *testing.T) {
	yes := []string{"не могу, у меня нет пальцев", "START может нажать только человек", "я пробовала — он не отвечает", "sorry, I can't do that", "пыталась, не вышло"}
	no := []string{"привет, как дела?", "отправила /start, жду ответ", "сегодня хорошо погуляли", "ок, посмотрю"}
	for _, s := range yes {
		if !refusesWork([]llm.ToolCall{sendText("x", s)}) {
			t.Errorf("must detect a refusal: %q", s)
		}
	}
	for _, s := range no {
		if refusesWork([]llm.ToolCall{sendText("x", s)}) {
			t.Errorf("must not flag: %q", s)
		}
	}
	if refusesWork([]llm.ToolCall{sendText("x", "не могу"), {ID: "y", Type: "function", Function: llm.FunctionCall{Name: "tg_api", Arguments: "{}"}}}) {
		t.Error("a round that also calls a real tool is not a refusal")
	}
}
