package tgui

import (
	"context"
	"errors"
	"fmt"
	"strconv"
	"strings"
	"time"

	"orvi/internal/telegram"
)

// target finds the message a number on screen stands for (or, failing that, a message id).
func (u *UI) target(ctx context.Context, p Params) (telegram.Message, error) {
	n := p.N
	if n <= 0 {
		return telegram.Message{}, errors.New("which message? pass n = its number on screen")
	}
	// a message id plus chat works without opening the chat first (the ids she reads in a normal chat view)
	if strings.TrimSpace(p.Chat) != "" {
		c, err := u.resolve(ctx, p.Chat, 0)
		if err != nil {
			return telegram.Message{}, err
		}
		if u.screen == "chat" && u.chat.ID == c.ID && n <= len(u.msgs) {
			return u.msgs[n-1], nil
		}
		return u.TG.Message(ctx, c.ID, int64(n))
	}
	if u.screen == "search" && n <= len(u.found) {
		return u.found[n-1], nil
	}
	if u.screen != "chat" {
		return telegram.Message{}, errors.New("open a chat first")
	}
	if n <= len(u.msgs) {
		return u.msgs[n-1], nil
	}
	for _, m := range u.msgs {
		if m.ID == int64(n) {
			return m, nil
		}
	}
	return telegram.Message{}, fmt.Errorf("no message #%d on this screen (there are %d)", n, len(u.msgs))
}

// whenToSend reads "+30m", "2026-10-21 09:00" (her zone) or RFC3339.
func (u *UI) whenToSend(s string) (time.Time, error) {
	s = strings.TrimSpace(s)
	if s == "" {
		return time.Time{}, nil
	}
	if strings.HasPrefix(s, "+") {
		d, err := time.ParseDuration(s[1:])
		if err != nil {
			return time.Time{}, fmt.Errorf("bad delay %q (like +30m or +2h)", s)
		}
		return u.Now().Add(d), nil
	}
	if t, err := time.Parse(time.RFC3339, s); err == nil {
		return t, nil
	}
	if t, err := time.ParseInLocation("2006-01-02 15:04", s, u.Loc); err == nil {
		return t, nil
	}
	return time.Time{}, fmt.Errorf("bad time %q (RFC3339, 2006-01-02 15:04, or +30m)", s)
}

func (u *UI) sendTo(ctx context.Context, p Params) (telegram.Chat, error) {
	if strings.TrimSpace(p.Chat) != "" {
		return u.resolve(ctx, p.Chat, 0)
	}
	if u.chat.ID == 0 || u.screen == "list" {
		return telegram.Chat{}, errors.New("open a chat first or say chat = ...")
	}
	return u.chat, nil
}

// refresh reloads the newest page of the open chat so the screen shows what the action did.
func (u *UI) refresh(ctx context.Context, chatID int64) {
	if u.screen == "chat" && u.chat.ID == chatID {
		if msgs, err := u.TG.History(ctx, chatID, 0, pageSize, 0); err == nil {
			u.msgs = msgs
		}
	}
}

func (u *UI) done(ctx context.Context, chatID int64, note string) string {
	u.refresh(ctx, chatID)
	if u.screen == "chat" && u.chat.ID == chatID {
		tail := 8
		start := len(u.msgs) - tail
		if start < 0 {
			start = 0
		}
		return note + "\n\n" + u.renderChatFrom(ctx, start)
	}
	return note
}

func (u *UI) findButton(m telegram.Message, sel string) (telegram.Button, error) {
	sel = strings.TrimSpace(sel)
	if sel == "" {
		return telegram.Button{}, errors.New("which button? button = \"1.2\" (row.column), a number in order, or its text")
	}
	var flat []telegram.Button
	for ri, row := range m.Buttons {
		for ci, b := range row {
			flat = append(flat, b)
			if sel == fmt.Sprintf("%d.%d", ri+1, ci+1) {
				return b, nil
			}
		}
	}
	if v, err := strconv.Atoi(sel); err == nil && v >= 1 && v <= len(flat) {
		return flat[v-1], nil
	}
	for _, b := range flat {
		if strings.EqualFold(b.Text, sel) {
			return b, nil
		}
	}
	for _, b := range flat {
		if strings.Contains(strings.ToLower(b.Text), strings.ToLower(sel)) {
			return b, nil
		}
	}
	return telegram.Button{}, fmt.Errorf("no button %q under this message", sel)
}

func (u *UI) send(ctx context.Context, chatID int64, text string, p Params, reply int64) (telegram.Message, error) {
	at, err := u.whenToSend(p.At)
	if err != nil {
		return telegram.Message{}, err
	}
	if r, ok := u.TG.(telegram.Rich); ok {
		return r.SendWith(telegram.NoThread(ctx), chatID, text, telegram.SendOptions{ReplyTo: reply, Silent: p.Silent, Markdown: p.Markdown, At: at})
	}
	if !at.IsZero() || p.Silent || p.Markdown {
		return telegram.Message{}, errors.New("silent, scheduled and formatted messages need the user account")
	}
	return u.TG.SendText(telegram.NoThread(ctx), chatID, text, reply)
}

func (u *UI) act(ctx context.Context, act string, p Params) (string, error) {
	switch act {
	case "send", "reply":
		text := strings.TrimSpace(p.Text)
		if text == "" {
			return "", errors.New("empty text")
		}
		var reply int64
		var c telegram.Chat
		var err error
		if act == "reply" {
			m, err := u.target(ctx, p)
			if err != nil {
				return "", err
			}
			reply = m.ID
			if c, err = u.TG.Chat(ctx, m.ChatID); err != nil {
				return "", err
			}
		} else if c, err = u.sendTo(ctx, p); err != nil {
			return "", err
		}
		u.emitTyping(act, c.ID, reply, "пишет в «"+c.Title+"»", text)
		sent, err := u.send(ctx, c.ID, text, p, reply)
		if err != nil {
			return "", err
		}
		u.emit("sent", c.ID, sent.ID, "отправила в «"+c.Title+"»: "+clip(text, 120))
		note := "Отправлено в «" + c.Title + "»."
		if p.At != "" {
			note = "Запланировано в «" + c.Title + "» на " + p.At + "."
		}
		return u.done(ctx, c.ID, note), nil

	case "edit":
		m, err := u.target(ctx, p)
		if err != nil {
			return "", err
		}
		if !m.Outgoing {
			return "", errors.New("only your own messages can be edited")
		}
		if strings.TrimSpace(p.Text) == "" {
			return "", errors.New("empty text")
		}
		if r, ok := u.TG.(telegram.Rich); ok {
			err = r.EditFormatted(ctx, m.ChatID, m.ID, p.Text, p.Markdown)
		} else {
			err = u.TG.Edit(ctx, m.ChatID, m.ID, p.Text)
		}
		if err != nil {
			return "", err
		}
		u.emit("edit", m.ChatID, m.ID, "исправила своё сообщение")
		return u.done(ctx, m.ChatID, fmt.Sprintf("Сообщение #%d исправлено.", p.N)), nil

	case "delete":
		m, err := u.target(ctx, p)
		if err != nil {
			return "", err
		}
		if err := u.TG.Delete(ctx, m.ChatID, m.ID); err != nil {
			return "", err
		}
		u.emit("delete", m.ChatID, m.ID, "удалила сообщение")
		return u.done(ctx, m.ChatID, fmt.Sprintf("Сообщение #%d удалено.", p.N)), nil

	case "react":
		m, err := u.target(ctx, p)
		if err != nil {
			return "", err
		}
		e := strings.TrimSpace(p.Emoji)
		if e == "" {
			return "", errors.New("which emoji?")
		}
		if err := u.TG.React(ctx, m.ChatID, m.ID, e); err != nil {
			return "", err
		}
		u.emit("react", m.ChatID, m.ID, "поставила "+e)
		return u.done(ctx, m.ChatID, fmt.Sprintf("Реакция %s на #%d.", e, p.N)), nil

	case "press":
		m, err := u.target(ctx, p)
		if err != nil {
			return "", err
		}
		b, err := u.findButton(m, p.Button)
		if err != nil {
			return "", err
		}
		switch b.Kind {
		case "url", "webapp":
			u.emit("press", m.ChatID, m.ID, "открывает ссылку кнопки «"+b.Text+"»")
			return "Кнопка «" + b.Text + "» — это ссылка: " + b.URL + "\nОткрой её через web/browser, если нужно.", nil
		case "copy":
			return "Кнопка «" + b.Text + "» копирует текст: " + b.URL, nil
		case "callback":
		default:
			return "", fmt.Errorf("button «%s» is of a kind that cannot be pressed from here", b.Text)
		}
		r, err := u.rich()
		if err != nil {
			return "", err
		}
		u.emit("press", m.ChatID, m.ID, "нажала «"+b.Text+"»")
		ans, err := r.PressButton(ctx, m.ChatID, m.ID, b.Data)
		if err != nil {
			return "", err
		}
		note := "Нажата «" + b.Text + "»."
		if ans.Text != "" {
			kind := "ответ бота"
			if ans.Alert {
				kind = "бот показал окно"
			}
			note += " " + kind + ": " + ans.Text
		}
		if ans.URL != "" {
			note += " Ссылка от бота: " + ans.URL
		}
		time.Sleep(600 * time.Millisecond) // bots edit their message or answer a moment later
		return u.done(ctx, m.ChatID, note), nil

	case "forward":
		m, err := u.target(ctx, p)
		if err != nil {
			return "", err
		}
		to, err := u.resolve(ctx, p.To, 0)
		if err != nil {
			return "", err
		}
		if err := u.TG.Forward(ctx, m.ChatID, m.ID, to.ID); err != nil {
			return "", err
		}
		u.emit("forward", m.ChatID, m.ID, "переслала в «"+to.Title+"»")
		return "Переслано в «" + to.Title + "».", nil

	case "pin", "unpin":
		m, err := u.target(ctx, p)
		if err != nil {
			return "", err
		}
		if act == "pin" {
			err = u.TG.Pin(ctx, m.ChatID, m.ID, p.Silent)
		} else {
			err = u.TG.Unpin(ctx, m.ChatID, m.ID)
		}
		if err != nil {
			return "", err
		}
		u.emit(act, m.ChatID, m.ID, map[string]string{"pin": "закрепила", "unpin": "открепила"}[act]+" сообщение")
		return u.done(ctx, m.ChatID, "Готово: "+act+" #"+strconv.Itoa(p.N)+"."), nil

	case "vote":
		m, err := u.target(ctx, p)
		if err != nil {
			return "", err
		}
		if m.Poll == nil {
			return "", errors.New("that message is not a poll")
		}
		var idx []int
		for _, part := range strings.FieldsFunc(p.Options, func(r rune) bool { return r == ',' || r == ' ' || r == ';' }) {
			v, err := strconv.Atoi(part)
			if err != nil || v < 1 || v > len(m.Poll.Options) {
				return "", fmt.Errorf("option %q is not 1..%d", part, len(m.Poll.Options))
			}
			idx = append(idx, v-1)
		}
		if err := u.TG.VotePoll(ctx, m.ChatID, m.ID, idx); err != nil {
			return "", err
		}
		u.emit("vote", m.ChatID, m.ID, "проголосовала")
		return u.done(ctx, m.ChatID, "Голос учтён."), nil

	case "view":
		m, err := u.target(ctx, p)
		if err != nil {
			return "", err
		}
		var b strings.Builder
		desc := func(telegram.Message) string { return "" }
		if u.Body != nil {
			desc = func(x telegram.Message) string { return u.Body(ctx, x) }
		}
		u.emit("view", m.ChatID, m.ID, "рассматривает сообщение")
		b.WriteString(MessageBlock(p.N, m, u.find, desc, u.TG.MyID(), u.Loc, 1))
		if m.Media == telegram.MediaDocument || m.Media == telegram.MediaAudio {
			fmt.Fprintf(&b, "\n(файл %s, %s; сохранить: download_telegram_file с message_id=%d)", m.FileName, human(m.FileSize), m.ID)
		}
		return b.String(), nil

	case "read":
		c, err := u.sendTo(ctx, p)
		if err != nil {
			return "", err
		}
		if err := u.TG.MarkRead(ctx, c.ID); err != nil {
			return "", err
		}
		u.emit("read", c.ID, 0, "прочитала «"+c.Title+"»")
		return "Чат «" + c.Title + "» отмечен прочитанным.", nil

	case "mute", "unmute":
		r, err := u.rich()
		if err != nil {
			return "", err
		}
		c, err := u.sendTo(ctx, p)
		if err != nil {
			return "", err
		}
		if err := r.SetMuted(ctx, c.ID, act == "mute"); err != nil {
			return "", err
		}
		u.emit(act, c.ID, 0, map[string]string{"mute": "выключила звук", "unmute": "включила звук"}[act]+" в «"+c.Title+"»")
		return "Готово: " + act + " «" + c.Title + "».", nil

	case "dice", "location":
		r, err := u.rich()
		if err != nil {
			return "", err
		}
		c, err := u.sendTo(ctx, p)
		if err != nil {
			return "", err
		}
		if act == "dice" {
			_, err = r.SendDice(telegram.NoThread(ctx), c.ID, p.Emoji, 0)
		} else {
			if p.Lat == 0 && p.Lon == 0 {
				return "", errors.New("pass lat and lon")
			}
			_, err = r.SendLocation(telegram.NoThread(ctx), c.ID, p.Lat, p.Lon, 0)
		}
		if err != nil {
			return "", err
		}
		u.emit("sent", c.ID, 0, "отправила "+act+" в «"+c.Title+"»")
		return u.done(ctx, c.ID, "Отправлено."), nil
	}
	return "", fmt.Errorf("unknown action %q", act)
}
