// Package tgui is the Telegram app as she sees it: a screen of text (chat list, open chat) with numbered chats, messages and
// buttons, and actions on those numbers. The panel shows the same chats, so the owner watches her use the app.
package tgui

import (
	"fmt"
	"sort"
	"strings"
	"time"
	"unicode/utf16"

	"orvi/internal/telegram"
)

func clip(s string, n int) string {
	s = strings.Join(strings.Fields(s), " ")
	if r := []rune(s); len(r) > n {
		return string(r[:n]) + "…"
	}
	return s
}

// withLinks puts the address of every link entity after the words it hides, so the text shows where it leads.
func withLinks(text string, ents []telegram.Entity) string {
	var links []telegram.Entity
	for _, e := range ents {
		if e.Type == "link" && e.URL != "" {
			links = append(links, e)
		}
	}
	if len(links) == 0 {
		return text
	}
	sort.Slice(links, func(i, j int) bool { return links[i].Offset+links[i].Length > links[j].Offset+links[j].Length })
	u := utf16.Encode([]rune(text))
	for _, e := range links {
		end := e.Offset + e.Length
		if end > len(u) || e.Offset < 0 {
			continue
		}
		ins := utf16.Encode([]rune(" ⟨" + e.URL + "⟩"))
		u = append(u[:end:end], append(ins, u[end:]...)...)
	}
	return string(utf16.Decode(u))
}

func human(n int64) string {
	switch {
	case n >= 1<<20:
		return fmt.Sprintf("%.1f МБ", float64(n)/(1<<20))
	case n >= 1<<10:
		return fmt.Sprintf("%d КБ", n>>10)
	}
	return fmt.Sprintf("%d Б", n)
}

func clock(d int) string { return fmt.Sprintf("%d:%02d", d/60, d%60) }

func typingText(kind, by string) string {
	var what string
	switch kind {
	case "typing":
		what = "печатает…"
	case "voice":
		what = "записывает голосовое…"
	case "photo":
		what = "отправляет фото…"
	case "video":
		what = "отправляет видео…"
	case "file":
		what = "отправляет файл…"
	case "sticker":
		what = "выбирает стикер…"
	default:
		return ""
	}
	if by != "" {
		return by + " " + what
	}
	return what
}

func presenceText(c telegram.Chat, loc *time.Location) string {
	switch c.Presence {
	case "online":
		return "в сети"
	case "recently":
		return "был(а) недавно"
	case "week":
		return "был(а) на этой неделе"
	case "month":
		return "был(а) в этом месяце"
	case "offline":
		if !c.LastSeen.IsZero() {
			return "был(а) " + c.LastSeen.In(loc).Format("02.01 15:04")
		}
		return "был(а) давно"
	}
	return ""
}

// ChatLine is one row of the chat list.
func ChatLine(n int, c telegram.Chat, now time.Time, loc *time.Location) string {
	var b strings.Builder
	fmt.Fprintf(&b, "%2d. ", n)
	if c.Pinned {
		b.WriteString("📌")
	}
	if c.Muted {
		b.WriteString("🔕")
	}
	switch c.Kind {
	case telegram.ChatGroup:
		b.WriteString("👥")
	case telegram.ChatChannel:
		b.WriteString("📢")
	default:
		b.WriteString("👤")
	}
	fmt.Fprintf(&b, " %s", c.Title)
	if c.Unread > 0 {
		fmt.Fprintf(&b, " ●%d", c.Unread)
	}
	if c.UnreadMentions > 0 {
		fmt.Fprintf(&b, " @%d", c.UnreadMentions)
	}
	if t := typingText(c.Typing, c.TypingBy); t != "" {
		b.WriteString(" ✍ " + t)
	} else if p := presenceText(c, loc); c.Kind == telegram.ChatPrivate && c.Presence == "online" {
		b.WriteString(" · " + p)
	}
	if c.LastText != "" {
		b.WriteString(" — «" + clip(c.LastText, 50) + "»")
	}
	if !c.LastDate.IsZero() {
		b.WriteString(" · " + c.LastDate.In(loc).Format(dayOrClock(c.LastDate, now, loc)))
	}
	return b.String()
}

func dayOrClock(t, now time.Time, loc *time.Location) string {
	a, b := t.In(loc), now.In(loc)
	if a.Year() == b.Year() && a.YearDay() == b.YearDay() {
		return "15:04"
	}
	return "02.01"
}

var months = []string{"", "янв", "фев", "мар", "апр", "мая", "июн", "июл", "авг", "сен", "окт", "ноя", "дек"}

func dayLabel(t time.Time, loc *time.Location) string {
	t = t.In(loc)
	return fmt.Sprintf("%d %s", t.Day(), months[t.Month()])
}

// Describer turns a message with media into the words a person would see in it (nil = placeholders only).
type Describer func(m telegram.Message) string

func placeholder(m telegram.Message) string {
	switch m.Media {
	case telegram.MediaPhoto:
		return "🖼 фото"
	case telegram.MediaVoice:
		return "🎤 голосовое " + clock(m.Duration)
	case telegram.MediaAudio:
		return "🎵 " + strings.TrimSpace(m.Title+" "+clock(m.Duration))
	case telegram.MediaVideo:
		switch m.MediaDetail {
		case "round":
			return "⭕ кружок " + clock(m.Duration)
		case "gif":
			return "🎞 GIF"
		}
		return "🎬 видео " + clock(m.Duration)
	case telegram.MediaSticker:
		return "🙂 стикер " + m.Text
	case telegram.MediaDocument:
		return "📎 " + m.FileName + " (" + human(m.FileSize) + ")"
	}
	return ""
}

// MessageBlock renders one message (or an album) as the app shows it. n is its number on screen, find looks up the message a reply points to.
func MessageBlock(n int, m telegram.Message, find func(id int64) (telegram.Message, bool), desc Describer, me int64, loc *time.Location, albumN int) string {
	var b strings.Builder
	if m.Service != "" {
		return "      — " + m.Service + " —"
	}
	who := m.SenderName
	if m.Outgoing || (me != 0 && m.SenderID == me) {
		who = "вы"
	}
	if who == "" {
		who = "?"
	}
	num := fmt.Sprintf("#%d", n)
	if albumN > 1 {
		num = fmt.Sprintf("#%d–#%d", n, n+albumN-1)
	}
	fmt.Fprintf(&b, "%s %s %s", num, m.Date.In(loc).Format("15:04"), who)
	if m.ViaBot != "" {
		b.WriteString(" via " + m.ViaBot)
	}
	if m.Author != "" {
		b.WriteString(" (" + m.Author + ")")
	}
	if m.ForwardFrom != "" {
		b.WriteString(" ⤳ от " + m.ForwardFrom)
	}
	if m.ReplyTo != 0 {
		if q, ok := find(m.ReplyTo); ok {
			t := q.Text
			if t == "" {
				t = placeholder(q)
			}
			qn := q.SenderName
			if q.Outgoing {
				qn = "вы"
			}
			fmt.Fprintf(&b, " ↩ %s: «%s»", qn, clip(t, 50))
		} else {
			fmt.Fprintf(&b, " ↩ (сообщение %d)", m.ReplyTo)
		}
	}
	if m.Edited {
		b.WriteString(" (изм.)")
	}
	if m.Outgoing {
		if m.Read {
			b.WriteString(" ✓✓")
		} else {
			b.WriteString(" ✓")
		}
	}
	b.WriteString("\n")
	if m.Quote != "" {
		b.WriteString("      ❝ " + clip(m.Quote, 120) + "\n")
	}
	ind := "      "
	if ph := placeholder(m); ph != "" {
		line := ph
		if desc != nil {
			if d := strings.TrimSpace(desc(m)); d != "" {
				line = ph + ": " + clip(d, 400)
			}
		}
		b.WriteString(ind + line + "\n")
	}
	if m.Animated {
		b.WriteString(ind + "(анимированный стикер)\n")
	}
	if m.Poll != nil {
		p := m.Poll
		kind := "опрос"
		if p.Anonymous {
			kind += " анонимный"
		}
		if p.Multiple {
			kind += ", несколько ответов"
		}
		if p.Closed {
			kind += ", закрыт"
		}
		fmt.Fprintf(&b, "%s📊 %s: %s\n", ind, kind, p.Question)
		for i, o := range p.Options {
			mark := "○"
			if o.Chosen {
				mark = "●"
			}
			fmt.Fprintf(&b, "%s  %s %d) %s — %d\n", ind, mark, i+1, o.Text, o.Votes)
		}
	} else if m.Text != "" && m.Media != telegram.MediaSticker && m.Place == nil && m.Contact == "" && m.Dice == "" {
		for _, l := range strings.Split(withLinks(m.Text, m.Entities), "\n") {
			b.WriteString(ind + l + "\n")
		}
	} else if m.Text != "" && (m.Contact != "" || m.Dice != "") {
		b.WriteString(ind + m.Text + "\n")
	}
	if m.Place != nil {
		p := m.Place
		name := p.Title
		if p.Address != "" {
			name += ", " + p.Address
		}
		fmt.Fprintf(&b, "%s📍 %s(%.5f, %.5f)%s\n", ind, strings.TrimSuffix(name+" ", " ")+" ", p.Lat, p.Lon, map[bool]string{true: " · трансляция", false: ""}[p.Live])
	}
	if pr := m.Preview; pr != nil {
		fmt.Fprintf(&b, "%s🔗 %s — %s %s\n", ind, strings.Trim(pr.Site+" "+pr.Title, " "), clip(pr.Description, 100), pr.URL)
	}
	for ri, row := range m.Buttons {
		var parts []string
		for ci, bt := range row {
			label := fmt.Sprintf("[%d.%d %s]", ri+1, ci+1, bt.Text)
			switch bt.Kind {
			case "url":
				label = fmt.Sprintf("[%d.%d %s ↗ %s]", ri+1, ci+1, bt.Text, bt.URL)
			case "webapp":
				label = fmt.Sprintf("[%d.%d %s (мини-апп)]", ri+1, ci+1, bt.Text)
			}
			parts = append(parts, label)
		}
		b.WriteString(ind + strings.Join(parts, " ") + "\n")
	}
	var meta []string
	if len(m.Counts) > 0 {
		var r []string
		for _, c := range m.Counts {
			s := c.Emoji
			if c.Count > 1 {
				s += fmt.Sprint(c.Count)
			}
			if c.Mine {
				s += "(вы)"
			}
			r = append(r, s)
		}
		meta = append(meta, strings.Join(r, " "))
	} else if len(m.Reactions) > 0 {
		meta = append(meta, strings.Join(m.Reactions, ""))
	}
	if m.Views > 0 {
		meta = append(meta, fmt.Sprintf("👁 %d", m.Views))
	}
	if m.Forwards > 0 {
		meta = append(meta, fmt.Sprintf("↪ %d", m.Forwards))
	}
	if m.Replies > 0 {
		meta = append(meta, fmt.Sprintf("💬 %d", m.Replies))
	}
	if len(meta) > 0 {
		b.WriteString(ind + strings.Join(meta, " · ") + "\n")
	}
	return strings.TrimRight(b.String(), "\n")
}
