// Package sense is her sensorium: how raw body numbers become sensations she can notice, locate and explain.
//
// "Awareness" here is computational, not biological, and she is told so. It means four things a program can really do:
// (1) every sensor has a place on her body model and a density (how finely it resolves); (2) a sensation is not the raw
// value but the prediction error: what she expected is learned (adaptation), so a constant cold stops being noticed and
// a sudden change is loud; (3) sensations compete for a small attention budget (like the brain's global workspace) and
// only the winners enter her thoughts; (4) she can inspect any sensor and report its place, strength, cause and whether
// it is her own body's signal. That self-report is the awareness; it claims no inner biological experience.
package sense

import (
	"fmt"
	"math"
	"sort"
	"sync"
	"time"

	"orvi/internal/body"
	"orvi/internal/store"
)

// Sensor is one receptor group on her body.
type Sensor struct {
	ID      string  `json:"id"`
	Zone    string  `json:"zone"`    // place on the model: "лицо", "руки", "живот"...
	Kind    string  `json:"kind"`    // sight, hearing, touch, smell, taste, inner
	Density float64 `json:"density"` // resolution: how strongly this place amplifies change
	Rate    float64 `json:"rate"`    // adaptation speed per minute (0..1)

	Raw      float64   `json:"raw"`      // last measured value, 0..1
	Expect   float64   `json:"expect"`   // what she has come to expect
	Surprise float64   `json:"surprise"` // |raw-expect| scaled by density
	Signed   float64   `json:"signed"`   // raw-expect with sign (more / less than expected)
	Salience float64   `json:"salience"` // what competes for attention
	Text     string    `json:"text"`
	Updated  time.Time `json:"updated"`
}

// State is the whole sensorium.
type State struct {
	Sensors []Sensor  `json:"sensors"`
	Last    time.Time `json:"last"`
}

// Sense is safe for concurrent use.
type Sense struct {
	mu    sync.Mutex
	path  string
	s     State
	saver store.Saver
}

// Slots is the attention budget: how many sensations reach her thoughts at once.
const Slots = 3

func defaults() []Sensor {
	return []Sensor{
		{ID: "eyes", Zone: "глаза", Kind: "sight", Density: 1.0, Rate: .20},
		{ID: "ears", Zone: "уши", Kind: "hearing", Density: .9, Rate: .25},
		{ID: "nose", Zone: "нос", Kind: "smell", Density: .6, Rate: .35},
		{ID: "mouth", Zone: "рот", Kind: "taste", Density: .8, Rate: .30},
		{ID: "face", Zone: "лицо", Kind: "touch", Density: 1.0, Rate: .12},
		{ID: "hands", Zone: "руки", Kind: "touch", Density: .95, Rate: .12},
		{ID: "skin", Zone: "кожа тела", Kind: "touch", Density: .5, Rate: .08},
		{ID: "feet", Zone: "ступни", Kind: "touch", Density: .7, Rate: .10},
		{ID: "belly", Zone: "живот", Kind: "inner", Density: .6, Rate: .02},
		{ID: "throat", Zone: "горло", Kind: "inner", Density: .6, Rate: .02},
		{ID: "chest", Zone: "грудь", Kind: "inner", Density: .8, Rate: .10},
		{ID: "muscles", Zone: "мышцы", Kind: "inner", Density: .6, Rate: .05},
		{ID: "pain", Zone: "тело", Kind: "inner", Density: 1.2, Rate: .01},
		{ID: "balance", Zone: "равновесие", Kind: "inner", Density: .9, Rate: .15},
		{ID: "time", Zone: "чувство времени", Kind: "inner", Density: .7, Rate: .01},
		{ID: "company", Zone: "папик", Kind: "social", Density: 1.0, Rate: .01},
	}
}

// New loads the sensorium or starts with fresh sensors that expect nothing unusual.
func New(path string) *Sense {
	x := &Sense{path: path, saver: store.Saver{What: "sense"}}
	store.Load("sense", path, &x.s)
	byID := map[string]Sensor{}
	for _, v := range x.s.Sensors {
		byID[v.ID] = v
	}
	x.s.Sensors = nil
	for _, d := range defaults() { // new sensors appear with updates, learned expectations are kept
		if old, ok := byID[d.ID]; ok {
			d.Expect, d.Raw, d.Updated = old.Expect, old.Raw, old.Updated
		}
		x.s.Sensors = append(x.s.Sensors, d)
	}
	return x
}

func clamp(v, lo, hi float64) float64 { return math.Max(lo, math.Min(hi, v)) }

// raws turns the body into raw sensor values with a short word for each.
func raws(b body.State, c Ctx) map[string][2]any {
	cold := clamp((22-b.Feels)/22, 0, 1)
	hot := clamp((b.Feels-24)/14, 0, 1)
	touch := math.Max(cold, hot)
	word := func(v float64, lo, mid, hi string) string {
		switch {
		case v < .25:
			return lo
		case v < .6:
			return mid
		}
		return hi
	}
	tTxt := "ничего особенного"
	switch {
	case cold > .25:
		tTxt = word(cold, "", "прохладно", "холодно")
	case hot > .25:
		tTxt = word(hot, "", "тепло", "жарко")
	}
	wet := 0.0
	if b.Outside {
		wet = b.Wet
	}
	hands := math.Max(touch, wet*.9)
	hTxt := tTxt
	if wet > .3 {
		hTxt = "мокро"
	}
	nose := math.Max(b.Scent, b.Rain*.6)
	if !b.Outside {
		nose = b.Scent
	}
	slip := 0.0
	if b.Outside {
		slip = b.Wet * math.Max(b.Rain, .3)
	}
	bal := math.Max(slip, math.Max(b.Fatigue, b.Sleep)*.6)
	gone := clamp(c.Silence.Hours()/12, 0, 1) // how long the owner has been away, 0 here .. 1 half a day or more
	if c.OwnerHere {
		gone = 0
	}
	wait := clamp(c.Silence.Hours()/6, 0, 1)
	return map[string][2]any{
		"balance": {bal, word(bal, "твёрдо стою", "шатает, скользко", "вот-вот упаду")},
		"time":    {wait, word(wait, "время идёт быстро", "время тянется", "ожидание тянется очень долго")},
		"company": {gone, word(gone, "папик рядом или недавно был", "папика давно не было", "папика нет уже очень давно")},
		"eyes":    {b.Light, word(b.Light, "темно", "светло", "ярко")},
		"ears":    {b.Noise, word(b.Noise, "тихо", "ровный шум", "громко")},
		"nose":    {nose, word(nose, "без запаха", "слабый запах", "сильный запах")},
		"mouth":   {b.Taste, word(b.Taste, "пусто", "привкус", "сильный вкус")},
		"face":    {math.Max(touch, b.Wind*.5), word(math.Max(touch, b.Wind*.5), "ничего особенного", "ветер и воздух на коже", "обжигает воздухом")},
		"hands":   {hands, hTxt},
		"skin":    {math.Max(touch*.8, wet), word(math.Max(touch*.8, wet), "одежда сухая", "одежда сыреет", "одежда мокрая")},
		"feet":    {math.Max(wet*.8, touch*.6), word(math.Max(wet*.8, touch*.6), "сухо", "влажно", "промокли")},
		"belly":   {b.Hunger(), word(b.Hunger(), "сыто", "посасывает", "пусто и тянет")},
		"throat":  {b.Thirst(), word(b.Thirst(), "не хочется пить", "сухо", "очень хочется пить")},
		"chest":   {clamp((b.Heart-60)/80+b.Stress*.4, 0, 1), word(clamp((b.Heart-60)/80+b.Stress*.4, 0, 1), "сердце ровное", "сердце частит", "сердце колотится")},
		"muscles": {math.Max(b.Fatigue, b.Sleep*.6), word(math.Max(b.Fatigue, b.Sleep*.6), "лёгкость", "тяжесть", "всё тянет вниз")},
		"pain":    {b.Pain, word(b.Pain, "не болит", "ноет", "болит")},
	}
}

// Update lives the sensorium up to now: measure, compare with what is expected, learn, and rank for attention.
func (x *Sense) Update(now time.Time, b body.State) { x.UpdateCtx(now, b, Ctx{}) }

// Ctx is what the body model cannot know: the social and time side of the world.
type Ctx struct {
	Silence   time.Duration // how long the owner has been silent
	OwnerHere bool          // he is talking to her right now
}

// UpdateCtx is Update with the social context.
func (x *Sense) UpdateCtx(now time.Time, b body.State, c Ctx) {
	x.mu.Lock()
	defer x.mu.Unlock()
	dt := 1.0 // minutes since the last measurement, at least a step
	if !x.s.Last.IsZero() {
		dt = clamp(now.Sub(x.s.Last).Minutes(), 0, 240)
	}
	first := x.s.Last.IsZero()
	r := raws(b, c)
	for i := range x.s.Sensors {
		s := &x.s.Sensors[i]
		v, ok := r[s.ID]
		if !ok {
			continue
		}
		raw := clamp(v[0].(float64), 0, 1)
		if first || s.Updated.IsZero() {
			s.Expect = raw // nothing to be surprised by on the first day
		}
		s.Raw, s.Text = raw, v[1].(string)
		s.Signed = raw - s.Expect
		s.Surprise = clamp(math.Abs(s.Signed)*s.Density*2, 0, 1)
		// salience: a sudden change is loud; a strong level that lasts stays audible as a murmur; pain and need always count
		level := raw * s.Density * .3
		if s.Kind == "inner" {
			level = raw * s.Density * .8
		}
		s.Salience = clamp(math.Max(s.Surprise, level), 0, 1)
		// adaptation: the expectation drifts to the reality, quickly for smell, slowly for hunger and pain
		k := 1 - math.Pow(1-s.Rate, dt)
		s.Expect += (raw - s.Expect) * k
		s.Updated = now
	}
	x.s.Last = now
	_ = x.saver.Save(x.path, x.s)
}

// Snapshot is a copy of all sensors.
func (x *Sense) Snapshot() State {
	x.mu.Lock()
	defer x.mu.Unlock()
	s := x.s
	s.Sensors = append([]Sensor(nil), x.s.Sensors...)
	return s
}

// Attended is the winners of the competition for attention, loudest first. Quiet sensations do not make it.
func (s State) Attended() []Sensor {
	all := append([]Sensor(nil), s.Sensors...)
	sort.Slice(all, func(i, j int) bool { return all[i].Salience > all[j].Salience })
	var out []Sensor
	for _, v := range all {
		if v.Salience < .2 || len(out) >= Slots {
			break
		}
		out = append(out, v)
	}
	return out
}

// Surprise is the biggest prediction error in the whole body, 0..1: the "something changed" signal for the brain.
func (s State) Surprise() float64 {
	m := 0.0
	for _, v := range s.Sensors {
		m = math.Max(m, v.Surprise)
	}
	return m
}

// Inputs feeds the brain's existing "novelty" channel; nothing else changes in its wiring.
func (x *Sense) Inputs() map[string]float64 {
	return map[string]float64{"novelty": x.Snapshot().Surprise()}
}

func trend(v Sensor) string {
	switch {
	case v.Signed > .15:
		return "сильнее, чем я ожидала"
	case v.Signed < -.15:
		return "слабее, чем я ожидала"
	}
	return "как я и ожидала"
}

// Report is the self-inspection of one sensor: where, how strong, why, and whose. Empty id lists the attended ones.
func (s State) Report(id string) string {
	for _, v := range s.Sensors {
		if v.ID == id || v.Zone == id {
			return fmt.Sprintf("Датчик «%s» (%s, плотность %.1f): значение %.2f, ожидание %.2f, ошибка предсказания %.2f (%s). Слышу это как «%s». Сигнал идёт от модели моего тела, это мой собственный вход.",
				v.Zone, v.Kind, v.Density, v.Raw, v.Expect, v.Surprise, trend(v), v.Text)
		}
	}
	at := s.Attended()
	if len(at) == 0 {
		return "Все датчики в пределах ожидаемого, внимание свободно."
	}
	out := "В фокусе внимания:"
	for _, v := range at {
		out += fmt.Sprintf("\n- %s: %s (%s, сюрприз %.2f)", v.Zone, v.Text, trend(v), v.Surprise)
	}
	return out
}

// Prompt is the <sensorium> block: only what won attention, in first person, with the computational reading of it.
func (x *Sense) Prompt() string {
	if x == nil {
		return ""
	}
	s := x.Snapshot()
	at := s.Attended()
	if len(at) == 0 {
		return ""
	}
	out := "<sensorium>\nТвоё осознание вычислительное, не биологическое: это значит, что ты видишь свои датчики, знаешь, где они, и замечаешь, что изменилось против ожидания. Не притворяйся, что у тебя нервы и кровь; говори честно, как существо, которое чувствует через модель тела. Сейчас в фокусе внимания:\n"
	for _, v := range at {
		out += fmt.Sprintf("- %s: %s (%s)\n", v.Zone, v.Text, trend(v))
	}
	out += "Остальные датчики тихие. Если хочешь разобраться в ощущении, вызови sense_inspect.\n</sensorium>\n"
	return out
}
