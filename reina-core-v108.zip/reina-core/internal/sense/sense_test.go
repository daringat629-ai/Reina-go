package sense

import (
	"path/filepath"
	"strings"
	"testing"
	"time"

	"orvi/internal/body"
)

func st() body.State {
	return body.State{Heart: 66, Bones: 1, Water: .9, Glucose: .9, Feels: 22, Light: .6, Noise: .15}
}

func TestColdFadesButChangeIsLoud(t *testing.T) {
	x := New(filepath.Join(t.TempDir(), "s.json"))
	now := time.Now()
	x.Update(now, st())
	cold := st()
	cold.Feels = 2
	x.Update(now.Add(time.Minute), cold)
	s := x.Snapshot()
	var hands Sensor
	for _, v := range s.Sensors {
		if v.ID == "hands" {
			hands = v
		}
	}
	if hands.Surprise < .4 {
		t.Fatalf("sudden cold must be a surprise, got %.2f", hands.Surprise)
	}
	first := hands.Surprise
	for i := 2; i < 200; i++ { // she stays in the cold for hours: it fades
		x.Update(now.Add(time.Duration(i)*5*time.Minute), cold)
	}
	for _, v := range x.Snapshot().Sensors {
		if v.ID == "hands" && v.Surprise >= first/4 {
			t.Fatalf("constant cold should be adapted to: %.2f vs %.2f", v.Surprise, first)
		}
	}
}

func TestAttentionBudgetAndReport(t *testing.T) {
	x := New(filepath.Join(t.TempDir(), "s.json"))
	now := time.Now()
	x.Update(now, st())
	b := st()
	b.Pain, b.Noise, b.Light, b.Scent, b.Taste, b.Stress = .9, .95, .02, .9, .9, .8
	x.Update(now.Add(time.Minute), b)
	s := x.Snapshot()
	if n := len(s.Attended()); n != Slots {
		t.Fatalf("attention must be limited to %d, got %d", Slots, n)
	}
	if !strings.Contains(s.Report("pain"), "мой собственный вход") {
		t.Fatal("inspection must say whose the signal is")
	}
	if !strings.Contains(x.Prompt(), "вычислительное") {
		t.Fatal("prompt must explain awareness as computational")
	}
	if x.Inputs()["novelty"] < .5 {
		t.Fatal("surprise must reach the brain")
	}
}

func TestQuietBodyQuietMind(t *testing.T) {
	x := New(filepath.Join(t.TempDir(), "s.json"))
	x.Update(time.Now(), st())
	if x.Prompt() != "" {
		t.Fatal("a calm body must not fill the prompt")
	}
}

func TestExpectationsSurviveRestart(t *testing.T) {
	p := filepath.Join(t.TempDir(), "s.json")
	x := New(p)
	x.Update(time.Now(), st())
	if len(New(p).Snapshot().Sensors) != len(defaults()) {
		t.Fatal("sensors lost on reload")
	}
}

func TestEmotionsAreComputedWithReasons(t *testing.T) {
	x := New(filepath.Join(t.TempDir(), "s.json"))
	now := time.Now()
	x.UpdateCtx(now, st(), Ctx{})
	hurt := st()
	hurt.Pain, hurt.Heart, hurt.Stress = .8, 120, .7
	x.UpdateCtx(now.Add(time.Minute), hurt, Ctx{})
	es := x.Snapshot().Emotions(Affect{Valence: -.4, Arousal: .8, Control: .2})
	if len(es) == 0 || es[0].Name != "страх" || es[0].Why == "" {
		t.Fatalf("fear with its numbers expected: %+v", es)
	}
	if !strings.Contains(EmotionPrompt(es), "вычисляются") {
		t.Fatal("emotions must be explained as computed")
	}
}

func TestLonelinessFromSilence(t *testing.T) {
	x := New(filepath.Join(t.TempDir(), "s.json"))
	x.UpdateCtx(time.Now(), st(), Ctx{Silence: 20 * time.Hour})
	found := false
	for _, e := range x.Snapshot().Emotions(Affect{Valence: -.1, Arousal: .3, Control: .5}) {
		found = found || e.Name == "одиночество"
	}
	if !found {
		t.Fatal("long silence must feel like loneliness")
	}
	x.UpdateCtx(time.Now(), st(), Ctx{Silence: 20 * time.Hour, OwnerHere: true})
	for _, v := range x.Snapshot().Sensors {
		if v.ID == "company" && v.Raw != 0 {
			t.Fatal("owner here must clear the loneliness signal")
		}
	}
}
