package telegram

import "testing"

func TestSendMediaUsesTheRightContentType(t *testing.T) {
	f := newFakeTD(func(req obj) obj {
		if str(req, "@type") == "sendMessage" {
			return obj{"@type": "message", "id": 5, "chat_id": req["chat_id"], "date": 1, "content": obj{"@type": "messageText", "text": obj{"text": "x"}}}
		}
		return nil
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	cases := map[string]string{KindVideo: "inputMessageVideo", KindAnimation: "inputMessageAnimation", KindAudio: "inputMessageAudio", KindPhoto: "inputMessagePhoto", KindDocument: "inputMessageDocument"}
	i := 0
	for kind, want := range cases {
		if _, err := c.SendMedia(ctx, 5, kind, "clip.bin", []byte("data"), "подпись", 3); err != nil {
			t.Fatal(kind, err)
		}
		r := f.requests("sendMessage")[i]
		i++
		content := sub(r, "input_message_content")
		if str(content, "@type") != want || str(sub(content, "caption"), "text") != "подпись" || num(sub(r, "reply_to")["message_id"]) != 3 {
			t.Fatalf("%s: %v", kind, r)
		}
	}
	v := sub(f.requests("sendMessage")[0], "input_message_content")
	if str(v, "@type") == "inputMessageVideo" && sub(v, "video")["supports_streaming"] != true {
		t.Fatal("video must stream")
	}
	if _, err := c.SendMedia(ctx, 5, "hologram", "x", []byte("d"), "", 0); err == nil {
		t.Fatal("unknown kind accepted")
	}
	if _, err := c.SendMedia(ctx, 5, KindVideo, "x.mp4", nil, "", 0); err == nil {
		t.Fatal("empty file accepted")
	}
}

func TestProfileReadAndChange(t *testing.T) {
	f := newFakeTD(func(req obj) obj {
		switch str(req, "@type") {
		case "getMe":
			return obj{"@type": "user", "id": 4242, "first_name": "Reina", "last_name": "Veil", "usernames": obj{"active_usernames": []any{"reina_v"}}}
		case "getUserFullInfo":
			return obj{"@type": "userFullInfo", "bio": obj{"@type": "formattedText", "text": "ядовитая"}}
		case "setName", "setBio", "setProfilePhoto":
			return obj{"@type": "ok"}
		}
		return nil
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	p, err := c.MyProfile(ctx)
	if err != nil || p.FirstName != "Reina" || p.LastName != "Veil" || p.Username != "reina_v" || p.Bio != "ядовитая" {
		t.Fatalf("%+v %v", p, err)
	}
	if err := c.SetName(ctx, "", "x"); err == nil {
		t.Fatal("empty first name accepted")
	}
	if err := c.SetName(ctx, "Рейна", ""); err != nil {
		t.Fatal(err)
	}
	if err := c.SetBio(ctx, "новое био"); err != nil {
		t.Fatal(err)
	}
	if err := c.SetProfilePhoto(ctx, []byte("jpegdata")); err != nil {
		t.Fatal(err)
	}
	if r := f.requests("setName")[0]; str(r, "first_name") != "Рейна" {
		t.Fatal(r)
	}
	if r := f.requests("setBio")[0]; str(r, "bio") != "новое био" {
		t.Fatal(r)
	}
	r := f.requests("setProfilePhoto")[0]
	ph := sub(r, "photo")
	if str(ph, "@type") != "inputChatPhotoStatic" || str(sub(ph, "photo"), "@type") != "inputFileLocal" {
		t.Fatal(r)
	}
}

func TestFindStickersSkipsMasksAndMarksPremium(t *testing.T) {
	f := newFakeTD(func(req obj) obj {
		if str(req, "@type") != "searchStickers" {
			return nil
		}
		st := func(id int, emoji string, ft obj) obj {
			return obj{"@type": "sticker", "id": id, "set_id": 7, "emoji": emoji, "full_type": ft, "sticker": obj{"@type": "file", "id": id, "size": 100}}
		}
		return obj{"@type": "stickers", "stickers": []any{
			st(11, "😂", obj{"@type": "stickerFullTypeRegular"}),
			st(12, "😂", obj{"@type": "stickerFullTypeRegular", "premium_animation": obj{"@type": "file", "id": 99}}),
			st(13, "😂", obj{"@type": "stickerFullTypeMask"}),
			st(14, "😂", obj{"@type": "stickerFullTypeCustomEmoji", "custom_emoji_id": 5}),
		}}
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	got, err := c.FindStickers(ctx, "😂", 5)
	if err != nil || len(got) != 2 || got[0].FileID != "11" || got[0].Premium || got[1].FileID != "12" || !got[1].Premium {
		t.Fatalf("%+v %v", got, err)
	}
	if _, err := c.FindStickers(ctx, "  ", 5); err == nil {
		t.Fatal("an empty emoji was searched")
	}
}

func TestCustomEmojisAreResolvedWithTheirStill(t *testing.T) {
	f := newFakeTD(func(req obj) obj {
		if str(req, "@type") != "getCustomEmojiStickers" {
			return nil
		}
		return obj{"@type": "stickers", "stickers": []any{obj{"@type": "sticker", "id": 1, "emoji": "😿",
			"full_type": obj{"@type": "stickerFullTypeCustomEmoji", "custom_emoji_id": "5368324170671202286"},
			"thumbnail": obj{"@type": "thumbnail", "file": obj{"@type": "file", "id": 41}},
			"sticker":   obj{"@type": "file", "id": 40}}}}
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	got, err := c.CustomEmojis(ctx, []int64{5368324170671202286})
	if err != nil || len(got) != 1 || got[0].ID != 5368324170671202286 || got[0].ThumbID != "41" || got[0].FileID != "40" || got[0].Emoji != "😿" {
		t.Fatalf("%+v %v", got, err)
	}
	if got, err := c.CustomEmojis(ctx, nil); err != nil || got != nil {
		t.Fatalf("nothing to resolve: %+v %v", got, err)
	}
}
