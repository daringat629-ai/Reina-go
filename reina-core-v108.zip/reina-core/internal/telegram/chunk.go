package telegram

import (
	"errors"
	"strings"
	"unicode/utf8"
)

// maxTextUnits is Telegram's limit for one text message, counted in UTF-16 units (an emoji outside the BMP is 2).
const maxTextUnits = 4096

var errEmptyText = errors.New("telegram: refusing to send an empty message")

// chunkText cuts text into pieces of at most max UTF-16 units, preferring a paragraph, line or space boundary and never
// splitting a character (or a surrogate pair). Short text comes back as is.
func chunkText(text string, max int) []string {
	if u16len(text) <= max {
		return []string{text}
	}
	var out []string
	for u16len(text) > max {
		cut, units := 0, 0
		for i, r := range text {
			n := 1
			if r >= 0x10000 {
				n = 2
			}
			if units+n > max {
				break
			}
			units += n
			cut = i + utf8.RuneLen(r)
		}
		if cut == 0 { // cannot happen for max >= 2, but never loop forever
			cut = utf8.RuneLen([]rune(text)[0])
		}
		piece := text[:cut]
		if i := strings.LastIndex(piece, "\n\n"); i > cut/2 {
			cut = i + 2
		} else if i := strings.LastIndexAny(piece, "\n "); i > cut/2 {
			cut = i + 1
		}
		if p := strings.TrimSpace(text[:cut]); p != "" {
			out = append(out, p)
		}
		text = text[cut:]
	}
	if p := strings.TrimSpace(text); p != "" {
		out = append(out, p)
	}
	return out
}
