package telegram

import (
	"context"
	"fmt"
	"path/filepath"
	"strconv"
	"strings"
)

func (c *TDClient) SendMedia(ctx context.Context, chatID int64, kind, name string, data []byte, caption string, reply int64) (Message, error) {
	p, err := c.outboxFile(filepath.Base(name), data)
	if err != nil {
		return Message{}, err
	}
	file := localFile(p)
	cap := withMentions(caption)
	switch kind {
	case KindVideo:
		return c.send(ctx, chatID, reply, c.mediaContent("video", file, cap, obj{"supports_streaming": true}))
	case KindAnimation:
		return c.send(ctx, chatID, reply, c.mediaContent("animation", file, cap, nil))
	case KindAudio:
		title := strings.TrimSuffix(filepath.Base(name), filepath.Ext(name))
		return c.send(ctx, chatID, reply, c.mediaContent("audio", file, cap, obj{"title": title}))
	case KindPhoto:
		return c.send(ctx, chatID, reply, c.mediaContent("photo", file, cap, nil))
	case KindDocument, "":
		return c.send(ctx, chatID, reply, c.mediaContent("document", file, cap, nil))
	}
	return Message{}, fmt.Errorf("unknown media kind %q", kind)
}

// CustomEmojis resolves Premium emoji ids (at most 20 at once).
func (c *TDClient) CustomEmojis(ctx context.Context, ids []int64) ([]CustomEmoji, error) {
	if len(ids) == 0 {
		return nil, nil
	}
	if len(ids) > 20 {
		ids = ids[:20]
	}
	strs := make([]string, len(ids)) // int64 ids travel as strings in tdlib's JSON
	for i, id := range ids {
		strs[i] = strconv.FormatInt(id, 10)
	}
	res, err := c.api(ctx, obj{"@type": "getCustomEmojiStickers", "custom_emoji_ids": strs})
	if err != nil {
		return nil, err
	}
	var out []CustomEmoji
	for _, v := range arr(res, "stickers") {
		st, _ := v.(map[string]any)
		id := num(sub(st, "full_type")["custom_emoji_id"])
		fileID, _ := fileRef(sub(st, "sticker"))
		thumb, _ := fileRef(sub(sub(st, "thumbnail"), "file"))
		if id != 0 {
			out = append(out, CustomEmoji{ID: id, Emoji: str(st, "emoji"), FileID: fileID, ThumbID: thumb})
		}
	}
	return out, nil
}

// FindStickers looks stickers up by emoji. Masks and custom emoji are skipped: they are not sent as stickers.
func (c *TDClient) FindStickers(ctx context.Context, emojis string, limit int) ([]StickerInfo, error) {
	emojis = strings.TrimSpace(emojis)
	if emojis == "" {
		return nil, fmt.Errorf("give an emoji to search for")
	}
	if limit <= 0 || limit > 30 {
		limit = 12
	}
	res, err := c.api(ctx, obj{"@type": "searchStickers", "sticker_type": obj{"@type": "stickerTypeRegular"}, "emojis": emojis,
		"query": "", "input_language_codes": []string{"ru", "en"}, "offset": 0, "limit": limit})
	if err != nil {
		return nil, err
	}
	var out []StickerInfo
	for _, v := range arr(res, "stickers") {
		st, _ := v.(map[string]any)
		ft := sub(st, "full_type")
		if t := str(ft, "@type"); t != "" && t != "stickerFullTypeRegular" {
			continue
		}
		id, _ := fileRef(sub(st, "sticker"))
		if id == "" || id == "0" {
			continue
		}
		out = append(out, StickerInfo{FileID: id, Emoji: str(st, "emoji"), SetID: num(st["set_id"]), Premium: sub(ft, "premium_animation") != nil})
	}
	return out, nil
}

func (c *TDClient) MyProfile(ctx context.Context) (Profile, error) {
	me, err := c.api(ctx, obj{"@type": "getMe"})
	if err != nil {
		return Profile{}, err
	}
	p := Profile{FirstName: str(me, "first_name"), LastName: str(me, "last_name"), Username: str(me, "username")}
	if names := arr(sub(me, "usernames"), "active_usernames"); len(names) > 0 {
		p.Username, _ = names[0].(string)
	}
	if full, err := c.api(ctx, obj{"@type": "getUserFullInfo", "user_id": c.MyID()}); err == nil {
		if b := sub(full, "bio"); b != nil { // newer tdlib: formattedText; older: a plain string
			p.Bio = str(b, "text")
		}
		if p.Bio == "" {
			p.Bio = str(full, "bio")
		}
		if id := num(full["personal_chat_id"]); id != 0 {
			if ch, err := c.api(ctx, obj{"@type": "getChat", "chat_id": id}); err == nil {
				p.PersonalChannel = str(ch, "title")
				if last := str(sub(sub(sub(ch, "last_message"), "content"), "text"), "text"); last != "" {
					p.PersonalChannel += ", last post: " + last
				}
			}
		}
	}
	return p, nil
}

func (c *TDClient) SetName(ctx context.Context, first, last string) error {
	if strings.TrimSpace(first) == "" {
		return fmt.Errorf("the first name cannot be empty")
	}
	_, err := c.call(ctx, obj{"@type": "setName", "first_name": first, "last_name": last})
	return err
}

func (c *TDClient) SetBio(ctx context.Context, bio string) error {
	_, err := c.call(ctx, obj{"@type": "setBio", "bio": bio})
	return err
}

func (c *TDClient) SetProfilePhoto(ctx context.Context, data []byte) error {
	p, err := c.outboxFile("avatar.jpg", data)
	if err != nil {
		return err
	}
	_, err = c.call(ctx, obj{"@type": "setProfilePhoto", "photo": obj{"@type": "inputChatPhotoStatic", "photo": localFile(p)}, "is_public": false})
	return err
}
