package telegram

import (
	"strings"
	"testing"
	"time"
)

func TestChunkTextLimitsAndUnicode(t *testing.T) {
	if got := chunkText("hi", 10); len(got) != 1 || got[0] != "hi" {
		t.Fatalf("short: %q", got)
	}
	long := strings.Repeat("😀", 3000) // 6000 units
	parts := chunkText(long, maxTextUnits)
	if len(parts) != 2 {
		t.Fatalf("parts=%d", len(parts))
	}
	for _, p := range parts {
		if u16len(p) > maxTextUnits || strings.ContainsRune(p, '�') {
			t.Fatalf("bad part: %d units", u16len(p))
		}
	}
	if strings.Join(parts, "") != long {
		t.Fatal("text lost")
	}
	words := strings.Repeat("слово ", 1500)
	for _, p := range chunkText(words, maxTextUnits) {
		if u16len(p) > maxTextUnits || strings.HasPrefix(p, " ") || strings.HasSuffix(p, "сл") {
			t.Fatalf("word cut: ...%q", p[len(p)-6:])
		}
	}
}

func TestSendTextEmptyAndLong(t *testing.T) {
	n := 0
	f := newFakeTD(func(req obj) obj {
		if str(req, "@type") == "sendMessage" {
			n++
			return obj{"@type": "message", "id": 900 + n, "chat_id": req["chat_id"], "date": 1, "is_outgoing": true,
				"sender_id": obj{"@type": "messageSenderUser", "user_id": 4242},
				"content":   obj{"@type": "messageText", "text": obj{"text": "x"}}}
		}
		return nil
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	if _, err := c.SendText(ctx, 5, "  \n", 0); err == nil {
		t.Fatal("empty must fail")
	}
	if len(f.requests("sendMessage")) != 0 {
		t.Fatal("nothing must be sent")
	}
	if _, err := c.SendText(ctx, 5, strings.Repeat("a", 5000), 33); err != nil {
		t.Fatal(err)
	}
	reqs := f.requests("sendMessage")
	if len(reqs) != 2 || reqs[1]["reply_to"] != nil || reqs[0]["reply_to"] == nil {
		t.Fatalf("reqs=%d", len(reqs))
	}
}

func TestIncomingDedupesReplayedMessage(t *testing.T) {
	f := newFakeTD(func(req obj) obj { return nil })
	c, ctx := loggedIn(t, f, TDConfig{})
	m := textMsg(77, 5, 55, "once")
	f.Push(obj{"@type": "updateNewMessage", "message": m})
	f.Push(obj{"@type": "updateNewMessage", "message": m})
	f.Push(obj{"@type": "updateNewMessage", "message": textMsg(78, 5, 55, "next")})
	var got []int64
	for len(got) < 2 {
		select {
		case u := <-c.Updates():
			got = append(got, u.ID)
		case <-time.After(3 * time.Second):
			t.Fatalf("got %v", got)
		}
	}
	select {
	case u := <-c.Updates():
		t.Fatalf("duplicate delivered: %d", u.ID)
	case <-time.After(200 * time.Millisecond):
	}
	_ = ctx
	if got[0] != 77 || got[1] != 78 {
		t.Fatalf("order %v", got)
	}
}
