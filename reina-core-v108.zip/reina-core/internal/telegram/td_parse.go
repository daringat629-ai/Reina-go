package telegram

import (
	"context"
	"regexp"
	"strconv"
	"strings"
	"time"
)

func userDisplay(u obj) string {
	name := strings.TrimSpace(str(u, "first_name") + " " + str(u, "last_name"))
	if name == "" {
		if un := sub(u, "usernames"); un != nil {
			if a := arr(un, "active_usernames"); len(a) > 0 {
				name, _ = a[0].(string)
			}
		}
	}
	return name
}

func (c *TDClient) userName(ctx context.Context, id int64) string {
	c.cmu.Lock()
	n, ok := c.users[id]
	c.cmu.Unlock()
	if ok {
		return n
	}
	u, err := c.call(ctx, obj{"@type": "getUser", "user_id": id})
	if err != nil {
		return "user " + strconv.FormatInt(id, 10)
	}
	n = userDisplay(u)
	c.cmu.Lock()
	c.users[id] = n
	c.cmu.Unlock()
	return n
}

func (c *TDClient) storeChat(ch obj) *tdChat {
	if ch == nil {
		return nil
	}
	t := &tdChat{ID: num(ch["id"]), Title: str(ch, "title"), Unread: int(num(ch["unread_count"])), LastReadIn: num(ch["last_read_inbox_message_id"]),
		InChatList: len(arr(ch, "chat_lists")) > 0}
	ty := sub(ch, "type")
	switch typ(ty) {
	case "chatTypePrivate", "chatTypeSecret":
		t.Kind = ChatPrivate
	case "chatTypeBasicGroup":
		t.Kind, t.superOrBasic, t.basic, t.groupID = ChatGroup, true, true, num(ty["basic_group_id"])
	case "chatTypeSupergroup":
		t.superOrBasic, t.groupID = true, num(ty["supergroup_id"])
		if ty["is_channel"] == true {
			t.Kind = ChatChannel
		} else {
			t.Kind = ChatGroup
		}
	}
	applyFlags(t, ch)
	if lm := sub(ch, "last_message"); lm != nil {
		t.LastMsgID, t.LastDate, t.LastText = num(lm["id"]), time.Unix(num(lm["date"]), 0), contentPreview(sub(lm, "content"))
	}
	if p := sub(ch, "photo"); p != nil {
		t.PhotoFileID = num(sub(p, "big")["id"])
	}
	c.cmu.Lock()
	c.chats[t.ID] = t
	c.cmu.Unlock()
	return t
}

func (c *TDClient) chatInfo(ctx context.Context, id int64) (*tdChat, error) {
	c.cmu.Lock()
	t := c.chats[id]
	c.cmu.Unlock()
	if t != nil {
		return t, nil
	}
	ch, err := c.api(ctx, obj{"@type": "getChat", "chat_id": id})
	if err != nil {
		return nil, err
	}
	return c.storeChat(ch), nil
}

func contentPreview(content obj) string {
	switch typ(content) {
	case "messageText":
		return str(sub(content, "text"), "text")
	case "messagePhoto":
		return "[photo] " + str(sub(content, "caption"), "text")
	case "messageVoiceNote":
		return "[voice message]"
	case "messageVideo", "messageVideoNote", "messageAnimation":
		return "[video]"
	case "messageDocument":
		return "[file] " + str(sub(content, "document"), "file_name")
	case "messagePoll":
		return "[poll] " + ftext(sub(content, "poll")["question"])
	case "messageSticker":
		return "[sticker] " + str(sub(content, "sticker"), "emoji")
	case "messageAudio":
		return "[audio] " + str(sub(content, "audio"), "title")
	case "messageLocation", "messageVenue":
		return "[location]"
	case "messageContact":
		return "[contact]"
	case "messageDice":
		return "[dice] " + str(content, "emoji")
	case "messageCall":
		return "[call]"
	case "messagePinMessage":
		return "[pinned a message]"
	case "messageChatAddMembers", "messageChatJoinByLink", "messageChatJoinByRequest":
		return "[joined the chat]"
	case "messageChatDeleteMember":
		return "[left the chat]"
	case "messageChatChangeTitle":
		return "[chat renamed]"
	}
	return "[" + typ(content) + "]"
}

// fileRef returns the id and size of a tdlib "file" object.
func fileRef(f obj) (string, int64) {
	if f == nil {
		return "", 0
	}
	return strconv.FormatInt(num(f["id"]), 10), num(f["size"])
}

// ftext reads a tdlib text that is a plain string in old versions and a formattedText in new ones.
func ftext(v any) string {
	switch t := v.(type) {
	case string:
		return t
	case map[string]any:
		return str(t, "text")
	}
	return ""
}

func parsePoll(p obj) *Poll {
	out := &Poll{Question: ftext(p["question"]), Total: int(num(p["total_voter_count"])), Anonymous: p["is_anonymous"] == true, Closed: p["is_closed"] == true}
	out.Multiple = p["allows_multiple_answers"] == true // tdlib 1.8.62+: on the poll itself
	if t := sub(p, "type"); typ(t) == "pollTypeRegular" && t["allow_multiple_answers"] == true {
		out.Multiple = true // older tdlib: on the poll type
	}
	for _, o := range arr(p, "options") {
		oo := toObj(o)
		out.Options = append(out.Options, PollOption{Text: ftext(oo["text"]), Votes: int(num(oo["voter_count"])), Chosen: oo["is_chosen"] == true})
	}
	return out
}

// threadOf reads the forum topic / thread of a message; tdlib moved it from message_thread_id to topic_id.
func threadOf(m obj) int64 {
	if t := num(m["message_thread_id"]); t != 0 {
		return t
	}
	if tp := sub(m, "topic_id"); tp != nil {
		if t := num(tp["forum_topic_id"]); t != 0 {
			return t
		}
		return num(tp["message_thread_id"])
	}
	return 0
}

func (c *TDClient) parseMessage(ctx context.Context, m obj) Message {
	out := Message{ID: num(m["id"]), ChatID: num(m["chat_id"]), Date: time.Unix(num(m["date"]), 0), Outgoing: m["is_outgoing"] == true,
		Edited: num(m["edit_date"]) > 0}
	snd := sub(m, "sender_id")
	switch typ(snd) {
	case "messageSenderUser":
		out.SenderID = num(snd["user_id"])
		out.SenderName = c.userName(ctx, out.SenderID)
	case "messageSenderChat":
		out.SenderID = num(snd["chat_id"])
		c.cmu.Lock()
		if ch := c.chats[out.SenderID]; ch != nil {
			out.SenderName = ch.Title
		}
		c.cmu.Unlock()
	}
	content := sub(m, "content")
	out.Text = contentPreview(content)
	switch typ(content) {
	case "messageText":
		out.Text = str(sub(content, "text"), "text")
	case "messagePhoto":
		out.Media, out.Text = MediaPhoto, str(sub(content, "caption"), "text")
		if sizes := arr(sub(content, "photo"), "sizes"); len(sizes) > 0 {
			f := sub(toObj(sizes[len(sizes)-1]), "photo")
			out.FileID, out.FileSize = strconv.FormatInt(num(f["id"]), 10), num(f["size"])
		}
	case "messageVoiceNote":
		out.Media, out.Text = MediaVoice, str(sub(content, "caption"), "text")
		out.FileID, out.FileSize = fileRef(sub(sub(content, "voice_note"), "voice"))
	case "messageVideo":
		out.Media, out.Text = MediaVideo, str(sub(content, "caption"), "text")
		out.FileID, out.FileSize = fileRef(sub(sub(content, "video"), "video"))
	case "messageVideoNote":
		out.Media, out.Text, out.MediaDetail = MediaVideo, "", "round"
		out.FileID, out.FileSize = fileRef(sub(sub(content, "video_note"), "video"))
	case "messageAnimation":
		out.Media, out.Text, out.MediaDetail = MediaVideo, str(sub(content, "caption"), "text"), "gif"
		out.FileID, out.FileSize = fileRef(sub(sub(content, "animation"), "animation"))
	case "messageSticker":
		st := sub(content, "sticker")
		out.Media, out.Text = MediaSticker, str(st, "emoji")
		out.FileID, out.FileSize = fileRef(sub(st, "sticker"))
		out.ThumbID, _ = fileRef(sub(sub(st, "thumbnail"), "file"))
	case "messagePoll":
		out.Media = MediaPoll
		out.Poll = parsePoll(sub(content, "poll"))
		out.Text = out.Poll.Question
	case "messageDocument":
		d := sub(content, "document")
		out.Text = str(sub(content, "caption"), "text")
		out.FileName = str(d, "file_name")
		out.FileID, out.FileSize = fileRef(sub(d, "document"))
		out.Media = MediaDocument
		if strings.HasPrefix(str(d, "mime_type"), "image/") { // a photo sent "as a file": see it like a photo
			out.Media = MediaPhoto
		}
	}
	if rt := sub(m, "reply_to"); typ(rt) == "messageReplyToMessage" {
		out.ReplyTo = num(rt["message_id"])
	}
	c.enrich(ctx, m, content, &out)
	out.Text = redactLoginCode(out.ChatID, out.Text)
	out.ThreadID = threadOf(m)
	if out.ThreadID != 0 {
		c.threads.Store(evKey(out.ChatID, out.ID), out.ThreadID)
	}
	if fi := sub(m, "forward_info"); fi != nil {
		o := sub(fi, "origin")
		switch typ(o) {
		case "messageOriginUser":
			out.ForwardFrom = c.userName(ctx, num(o["sender_user_id"]))
		case "messageOriginHiddenUser":
			out.ForwardFrom = str(o, "sender_name")
		case "messageOriginChannel", "messageOriginChat":
			out.ForwardFrom = str(o, "author_signature")
			if out.ForwardFrom == "" {
				out.ForwardFrom = "chat"
			}
		}
	}
	if ii := sub(m, "interaction_info"); ii != nil {
		for _, r := range arr(sub(ii, "reactions"), "reactions") {
			if t := sub(toObj(r), "type"); typ(t) == "reactionTypeEmoji" {
				out.Reactions = append(out.Reactions, str(t, "emoji"))
			}
		}
	}
	if out.Outgoing {
		out.Read = true
	} else {
		c.cmu.Lock()
		if ch := c.chats[out.ChatID]; ch != nil {
			out.Read = out.ID <= ch.LastReadIn
		}
		c.cmu.Unlock()
	}
	return out
}

func (c *TDClient) toChat(t *tdChat) Chat {
	ch := Chat{ID: t.ID, Title: t.Title, Kind: t.Kind, Unread: t.Unread, IsMember: true, LastText: redactLoginCode(t.ID, t.LastText), LastDate: t.LastDate}
	c.cmu.Lock()
	c.decorate(&ch, t)
	c.cmu.Unlock()
	return ch
}

// parseList converts tdlib's newest-first list; reverse makes it oldest-first.
func (c *TDClient) parseList(ctx context.Context, list []any, reverse bool) []Message {
	out := make([]Message, 0, len(list))
	for _, v := range list {
		if m := toObj(v); m != nil {
			out = append(out, c.parseMessage(ctx, m))
		}
	}
	if reverse {
		for i, j := 0, len(out)-1; i < j; i, j = i+1, j-1 {
			out[i], out[j] = out[j], out[i]
		}
	}
	return out
}

// telegramServiceChat is the "Telegram" chat that delivers login codes.
const telegramServiceChat = 777000

var loginCodeRe = regexp.MustCompile(`\b\d{5,6}\b`)

// redactLoginCode hides login codes in the service chat: a code in her context could be read out or sent to anyone
// who talks her into it (it is the key to the account).
func redactLoginCode(chatID int64, text string) string {
	if chatID != telegramServiceChat {
		return text
	}
	return loginCodeRe.ReplaceAllString(text, "•••••")
}
