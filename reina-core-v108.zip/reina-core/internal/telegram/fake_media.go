package telegram

import (
	"context"
	"fmt"
	"strings"
)

// MediaSent is what the fake saw sent as a typed file.
type MediaSent struct {
	Kind, Name, Caption string
	Size                int
}

// FakeMedia records typed sends and profile changes for tests.
type FakeMedia struct {
	Sent     []MediaSent
	Profile  Profile
	Photo    int                   // bytes of the last avatar
	Stickers []StickerInfo         // what FindStickers returns
	Custom   map[int64]CustomEmoji // what CustomEmojis knows
}

func (f *Fake) SendMedia(_ context.Context, chatID int64, kind, name string, data []byte, caption string, replyTo int64) (Message, error) {
	f.mu.Lock()
	f.Media.Sent = append(f.Media.Sent, MediaSent{kind, name, caption, len(data)})
	f.mu.Unlock()
	return f.send(chatID, Message{Text: caption + "[" + kind + ":" + name + "]", ReplyTo: replyTo}), nil
}

func (f *Fake) MyProfile(context.Context) (Profile, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	return f.Media.Profile, nil
}

func (f *Fake) SetName(_ context.Context, first, last string) error {
	if strings.TrimSpace(first) == "" {
		return fmt.Errorf("the first name cannot be empty")
	}
	f.mu.Lock()
	f.Media.Profile.FirstName, f.Media.Profile.LastName = first, last
	f.mu.Unlock()
	return nil
}

func (f *Fake) SetBio(_ context.Context, bio string) error {
	f.mu.Lock()
	f.Media.Profile.Bio = bio
	f.mu.Unlock()
	return nil
}

func (f *Fake) SetProfilePhoto(_ context.Context, data []byte) error {
	f.mu.Lock()
	f.Media.Photo = len(data)
	f.mu.Unlock()
	return nil
}

func (f *Fake) FindStickers(_ context.Context, emojis string, limit int) ([]StickerInfo, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	var out []StickerInfo
	for _, s := range f.Media.Stickers {
		if strings.Contains(emojis, s.Emoji) {
			out = append(out, s)
		}
	}
	return out, nil
}

func (f *Fake) CustomEmojis(_ context.Context, ids []int64) ([]CustomEmoji, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	var out []CustomEmoji
	for _, id := range ids {
		if c, ok := f.Media.Custom[id]; ok {
			out = append(out, c)
		}
	}
	return out, nil
}
