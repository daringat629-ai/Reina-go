package telegram

import (
	"context"
	"testing"
)

// Every chat action is a valid sendChatAction for every supported tdlib version.
func TestChatActionsMatchEveryTDLibSchema(t *testing.T) {
	for _, v := range schemaVersions {
		t.Run(v, func(t *testing.T) {
			f := newFakeTD(nil)
			f.version = v
			c, ctx := loggedIn(t, f, TDConfig{})
			for _, a := range []ChatAction{ActTyping, ActVoice, ActPhoto, ActSticker, ActCancel} {
				_ = c.Action(ctx, 5, a)
			}
			_ = c.Typing(ctx, 5)
			// the cleanup registered by loggedIn fails the test if any request broke the schema
		})
	}
}

func TestBotActionNames(t *testing.T) {
	want := map[ChatAction]string{ActTyping: "typing", ActVoice: "record_voice", ActPhoto: "upload_photo", ActSticker: "choose_sticker", ActCancel: ""}
	for a, w := range want {
		if got := botAction(a); got != w {
			t.Errorf("botAction(%s) = %q, want %q", a, got, w)
		}
	}
}

type typingOnly struct {
	Client
	n int
}

func (t *typingOnly) Typing(context.Context, int64) error { t.n++; return nil }

// A client without Actor shows "typing" only for typing: never "typing" before a voice note.
func TestSendActionFallback(t *testing.T) {
	c := &typingOnly{}
	for _, a := range []ChatAction{ActVoice, ActPhoto, ActSticker, ActCancel} {
		_ = SendAction(context.Background(), c, 1, a)
	}
	if c.n != 0 {
		t.Fatalf("typing shown %d times for non-typing actions", c.n)
	}
	_ = SendAction(context.Background(), c, 1, ActTyping)
	if c.n != 1 {
		t.Fatalf("typing not shown")
	}
}
