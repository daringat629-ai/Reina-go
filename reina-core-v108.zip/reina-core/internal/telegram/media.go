package telegram

import "context"

// MediaKinds are the ways a file can be sent so that Telegram shows it as what it is.
const (
	KindVideo     = "video"     // plays in the chat
	KindAnimation = "animation" // a looping gif without sound
	KindAudio     = "audio"     // music with a player
	KindPhoto     = "photo"
	KindDocument  = "document"
)

// MediaSender is what only the user-account client can do: send a file as a video, gif or track, not as a plain file.
// Callers type-assert for it and fall back to SendDocument.
type MediaSender interface {
	SendMedia(ctx context.Context, chatID int64, kind, name string, data []byte, caption string, replyTo int64) (Message, error)
}

// StickerInfo is a sticker found by emoji. Premium ones can be sent only by an account that has Telegram Premium.
type StickerInfo struct {
	FileID  string
	Emoji   string
	SetID   int64
	Premium bool
}

// StickerFinder searches the sticker library by emoji (installed sets, premium sets, the usual suggestions).
// User-account client only.
type StickerFinder interface {
	FindStickers(ctx context.Context, emojis string, limit int) ([]StickerInfo, error)
}

// CustomEmoji is a Telegram Premium emoji (a small sticker used inside a text): the id from the message, the plain
// emoji that stands for it and the files that can be shown to a vision model (ThumbID is a still picture).
type CustomEmoji struct {
	ID      int64
	Emoji   string
	FileID  string
	ThumbID string
}

// CustomEmojiResolver turns the ids of Premium emoji into something she can look at. User-account client only.
type CustomEmojiResolver interface {
	CustomEmojis(ctx context.Context, ids []int64) ([]CustomEmoji, error)
}

// Profile is the account's own card.
type Profile struct {
	FirstName, LastName, Username, Bio string
	PersonalChannel                    string // the channel shown on the profile (not a dialog, so it is not in the chat list)
}

// ProfileEditor changes who she is in Telegram: name, bio, avatar. User-account client only.
type ProfileEditor interface {
	MyProfile(ctx context.Context) (Profile, error)
	SetName(ctx context.Context, first, last string) error
	SetBio(ctx context.Context, bio string) error
	SetProfilePhoto(ctx context.Context, data []byte) error
}
