package telegram

import "context"

// ChatAction is what the other side sees under the chat title while she gets a message ready: "печатает…",
// "записывает аудио…", "отправляет фото…", "выбирает стикер…". Telegram drops an action by itself after ~5 s, so a
// longer one has to be sent again (see tools.typingFor).
type ChatAction string

const (
	ActTyping  ChatAction = "typing"
	ActVoice   ChatAction = "voice"
	ActPhoto   ChatAction = "photo"
	ActSticker ChatAction = "sticker"
	ActCancel  ChatAction = "cancel"
)

// Actor is implemented by clients that can show more than "typing".
type Actor interface {
	Action(ctx context.Context, chatID int64, a ChatAction) error
}

// SendAction shows the action in the chat. A client without Actor shows "typing" for typing and nothing for the
// rest: "печатает…" before a voice note gives a bot away more than no status at all.
func SendAction(ctx context.Context, c Client, chatID int64, a ChatAction) error {
	if x, ok := c.(Actor); ok {
		return x.Action(ctx, chatID, a)
	}
	if a == ActTyping {
		return c.Typing(ctx, chatID)
	}
	return nil
}

// tdAction is the tdlib object of an action (checked against td_api.tl in the tests).
func tdAction(a ChatAction) obj {
	switch a {
	case ActVoice:
		return obj{"@type": "chatActionRecordingVoiceNote"}
	case ActPhoto:
		return obj{"@type": "chatActionUploadingPhoto", "progress": 0}
	case ActSticker:
		return obj{"@type": "chatActionChoosingSticker"}
	case ActCancel:
		return obj{"@type": "chatActionCancel"}
	}
	return obj{"@type": "chatActionTyping"}
}

// botAction is the Bot API name of an action ("" = nothing to send; the Bot API has no cancel).
func botAction(a ChatAction) string {
	switch a {
	case ActVoice:
		return "record_voice"
	case ActPhoto:
		return "upload_photo"
	case ActSticker:
		return "choose_sticker"
	case ActCancel:
		return ""
	}
	return "typing"
}
