package telegram

import (
	"bytes"
	"strconv"
	"strings"
)

// tdlib changes its JSON schema between versions, and reina-core must work with whatever the owner built. The
// shapes that differ are chosen here by the version tdlib reports at start (updateOption "version"):
//
//	1.8.62  inputMessagePoll: options are inputPollOption, type is InputPollType (inputPollTypeRegular),
//	        "allows_multiple_answers" moved from the poll type onto the poll itself.
//	1.8.64  every inputMessage<Media> wraps its file: inputMessagePhoto{photo: inputPhoto{photo: InputFile}}
//	        (inputDocument, inputVideo, inputAudio, inputAnimation, inputVoiceNote, inputSticker likewise).
//
// The oldest supported version is 1.8.61 (setChatMemberTag). An unknown version (not reported yet) is treated as
// the newest one, because the README asks for a fresh master build.

// tdVersion packs "1.8.64" as 1_008_064; 0 = unknown.
func parseTDVersion(s string) int64 {
	parts := strings.SplitN(strings.TrimSpace(s), ".", 3)
	if len(parts) != 3 {
		return 0
	}
	var v int64
	for _, p := range parts {
		n, err := strconv.Atoi(strings.TrimFunc(p, func(r rune) bool { return r < '0' || r > '9' }))
		if err != nil || n < 0 || n > 999 {
			return 0
		}
		v = v*1000 + int64(n)
	}
	return v
}

func tdv(major, minor, patch int64) int64 { return major*1_000_000 + minor*1000 + patch }

// atLeast reports whether the running tdlib is at least major.minor.patch (unknown counts as new).
func (c *TDClient) atLeast(major, minor, patch int64) bool {
	v := c.ver.Load()
	return v == 0 || v >= tdv(major, minor, patch)
}

// TDLibVersion is the version string tdlib reported ("" until it did).
func (c *TDClient) TDLibVersion() string {
	v := c.ver.Load()
	if v == 0 {
		return ""
	}
	return strconv.FormatInt(v/1_000_000, 10) + "." + strconv.FormatInt(v/1000%1000, 10) + "." + strconv.FormatInt(v%1000, 10)
}

// mediaContent builds inputMessage<kind> for a file in the shape this tdlib expects.
// kind is one of photo, document, video, animation, audio, voice_note, sticker.
func (c *TDClient) mediaContent(kind string, file obj, caption obj, extra obj) obj {
	wrapped := c.atLeast(1, 8, 64)
	var content obj
	// field: the inputMessage field; wrapper: the input<Media> object of 1.8.64+; inner: its file field.
	field, wrapper, inner, msgType := kind, "", kind, ""
	switch kind {
	case "photo":
		msgType, wrapper = "inputMessagePhoto", "inputPhoto"
	case "document":
		msgType, wrapper = "inputMessageDocument", "inputDocument"
	case "video":
		msgType, wrapper = "inputMessageVideo", "inputVideo"
	case "animation":
		msgType, wrapper = "inputMessageAnimation", "inputAnimation"
	case "audio":
		msgType, wrapper = "inputMessageAudio", "inputAudio"
	case "voice_note":
		msgType, wrapper = "inputMessageVoiceNote", "inputVoiceNote"
	case "sticker":
		msgType, wrapper = "inputMessageSticker", "inputSticker"
	default:
		return nil
	}
	content = obj{"@type": msgType}
	if wrapped {
		w := obj{"@type": wrapper, inner: file}
		for k, v := range extra { // supports_streaming, title... live on the wrapper now
			w[k] = v
		}
		content[field] = w
	} else {
		content[field] = file
		for k, v := range extra {
			content[k] = v
		}
	}
	if caption != nil && kind != "sticker" {
		content["caption"] = caption
	}
	return content
}

// pollContent builds inputMessagePoll in the shape this tdlib expects.
func (c *TDClient) pollContent(question string, options []string, anonymous, multiple bool) obj {
	if c.atLeast(1, 8, 62) {
		opts := make([]any, len(options))
		for i, o := range options {
			opts[i] = obj{"@type": "inputPollOption", "text": formatted(o)}
		}
		return obj{"@type": "inputMessagePoll", "question": formatted(question), "options": opts, "is_anonymous": anonymous,
			"allows_multiple_answers": multiple, "type": obj{"@type": "inputPollTypeRegular", "allow_adding_options": false}}
	}
	opts := make([]any, len(options))
	for i, o := range options {
		opts[i] = formatted(o)
	}
	return obj{"@type": "inputMessagePoll", "question": formatted(question), "options": opts, "is_anonymous": anonymous,
		"type": obj{"@type": "pollTypeRegular", "allow_multiple_answers": multiple}}
}

// SupportedTDLib reports whether a tdlib version string ("1.8.69") is new enough for reina-core.
func SupportedTDLib(version string) bool { return parseTDVersion(version) >= tdv(1, 8, 61) }

// clientIDOf reads the "@client_id" tdlib adds to every event (false when absent).
func clientIDOf(raw []byte) (int64, bool) {
	i := bytes.LastIndex(raw, []byte(`"@client_id":`))
	if i < 0 {
		return 0, false
	}
	j := i + len(`"@client_id":`)
	k := j
	for k < len(raw) && raw[k] >= '0' && raw[k] <= '9' {
		k++
	}
	n, err := strconv.ParseInt(string(raw[j:k]), 10, 64)
	return n, err == nil
}
