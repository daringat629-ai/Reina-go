// Package telegram is the Telegram layer. Client is the interface the agent and
// tools depend on. BotClient implements it over the Telegram Bot API (stdlib
// only); Fake implements it in memory for tests. The user-account client uses
// tdlib (a full user account) — a tdlib-backed Client can be added later
// without touching the agent or tools.
package telegram

import (
	"context"
	"time"
)

type ChatKind string

const (
	ChatPrivate ChatKind = "private"
	ChatGroup   ChatKind = "group"
	ChatChannel ChatKind = "channel"
)

type MediaKind string

const (
	MediaNone     MediaKind = ""
	MediaPhoto    MediaKind = "photo"
	MediaVoice    MediaKind = "voice"
	MediaVideo    MediaKind = "video"
	MediaSticker  MediaKind = "sticker"
	MediaDocument MediaKind = "document"
	MediaPoll     MediaKind = "poll"
	MediaAudio    MediaKind = "audio" // music and other audio tracks (voice notes are MediaVoice)
)

type Chat struct {
	ID       int64     `json:"id"`
	Title    string    `json:"title"`
	Kind     ChatKind  `json:"kind"`
	Unread   int       `json:"unread"`
	IsMember bool      `json:"is_member"`
	IsAdmin  bool      `json:"is_admin"`
	LastText string    `json:"last_text,omitempty"`
	LastDate time.Time `json:"last_date"`
	// What the chat list of the app shows beyond the basics.
	Pinned         bool      `json:"pinned,omitempty"`
	Muted          bool      `json:"muted,omitempty"`
	Archived       bool      `json:"archived,omitempty"`
	Folders        []int     `json:"folders,omitempty"`         // ids of the chat folders the chat is in
	UnreadMentions int       `json:"unread_mentions,omitempty"` // unread @mentions
	Typing         string    `json:"typing,omitempty"`          // typing, voice, photo, video, file (what someone is doing there now)
	TypingBy       string    `json:"typing_by,omitempty"`
	Presence       string    `json:"presence,omitempty"` // private chats: online, recently, week, month, offline, hidden
	LastSeen       time.Time `json:"last_seen,omitempty"`
}

// Folder is a chat folder (a tab of the chat list).
type Folder struct {
	ID   int    `json:"id"`
	Name string `json:"name"`
}

// Entity is a formatted piece of a text. Offsets and lengths are in UTF-16 code units, as Telegram and JavaScript count them.
type Entity struct {
	Type     string `json:"type"` // bold italic underline strike code pre spoiler quote link url mention mentionname hashtag cashtag command email phone emoji
	Offset   int    `json:"offset"`
	Length   int    `json:"length"`
	URL      string `json:"url,omitempty"`             // link
	UserID   int64  `json:"user_id,omitempty"`         // mentionname
	CustomID int64  `json:"custom_emoji_id,omitempty"` // emoji: the Telegram Premium emoji shown instead of the plain one
}

// Button is one button of an inline keyboard under a message.
type Button struct {
	Text string `json:"text"`
	Kind string `json:"kind"`           // callback, url, webapp, copy, other
	URL  string `json:"url,omitempty"`  // url, webapp
	Data string `json:"data,omitempty"` // callback: the payload as tdlib gives it (base64); pass it to PressButton
}

// LinkPreview is the card Telegram shows under a message with a link.
type LinkPreview struct {
	URL         string `json:"url"`
	Site        string `json:"site,omitempty"`
	Title       string `json:"title,omitempty"`
	Description string `json:"description,omitempty"`
}

// Place is a shared location or venue.
type Place struct {
	Lat     float64 `json:"lat"`
	Lon     float64 `json:"lon"`
	Title   string  `json:"title,omitempty"`
	Address string  `json:"address,omitempty"`
	Live    bool    `json:"live,omitempty"`
}

// ReactionCount is one reaction under a message with how many people chose it.
type ReactionCount struct {
	Emoji string `json:"emoji"`
	Count int    `json:"count"`
	Mine  bool   `json:"mine,omitempty"`
}

type Message struct {
	ID          int64     `json:"id"`
	ChatID      int64     `json:"chat_id"`
	SenderID    int64     `json:"sender_id"`
	SenderName  string    `json:"sender_name"`
	Date        time.Time `json:"date"`
	Text        string    `json:"text"`
	ReplyTo     int64     `json:"reply_to,omitempty"`
	ForwardFrom string    `json:"forward_from,omitempty"`
	Media       MediaKind `json:"media,omitempty"`
	FileID      string    `json:"file_id,omitempty"`
	ThumbID     string    `json:"thumb_id,omitempty"`  // stickers: the still picture of an animated or video sticker
	FileName    string    `json:"file_name,omitempty"` // documents
	FileSize    int64     `json:"file_size,omitempty"` // bytes, 0 = unknown
	ThreadID    int64     `json:"thread_id,omitempty"` // forum topic / comment thread, 0 = none or General
	Poll        *Poll     `json:"poll,omitempty"`
	MediaDetail string    `json:"media_detail,omitempty"` // "round" (video message) or "gif"
	Outgoing    bool      `json:"outgoing,omitempty"`
	Read        bool      `json:"read,omitempty"`
	Edited      bool      `json:"edited,omitempty"`
	Reactions   []string  `json:"reactions,omitempty"`

	// What the app shows of a message beyond the text.
	Entities  []Entity        `json:"entities,omitempty"`   // formatting of Text
	Buttons   [][]Button      `json:"buttons,omitempty"`    // inline keyboard
	Service   string          `json:"service,omitempty"`    // a service message ("Алина вошла в группу"); also put in Text
	Quote     string          `json:"quote,omitempty"`      // the quoted part of the message replied to
	AlbumID   int64           `json:"album_id,omitempty"`   // messages with the same id are one album
	Preview   *LinkPreview    `json:"preview,omitempty"`    // the card of a link
	Place     *Place          `json:"place,omitempty"`      // location or venue
	Contact   string          `json:"contact,omitempty"`    // a shared contact: name and phone
	Dice      string          `json:"dice,omitempty"`       // emoji and value of a dice message
	Duration  int             `json:"duration,omitempty"`   // seconds: voice, video, audio, call
	MimeType  string          `json:"mime_type,omitempty"`  // of the file
	Animated  bool            `json:"animated,omitempty"`   // stickers: .tgs (lottie), which a browser cannot show without a library
	Title     string          `json:"title,omitempty"`      // audio: "artist - title"
	Views     int             `json:"views,omitempty"`      // channel posts
	Forwards  int             `json:"forwards,omitempty"`   // channel posts
	Replies   int             `json:"replies,omitempty"`    // comments under a channel post
	Counts    []ReactionCount `json:"counts,omitempty"`     // reactions with numbers
	ViaBot    string          `json:"via_bot,omitempty"`    // "via @bot"
	Author    string          `json:"author,omitempty"`     // signature of a channel post
	PinnedMsg int64           `json:"pinned_msg,omitempty"` // service "pinned a message": which one
}

// Poll is a poll message as the account sees it.
type Poll struct {
	Question  string       `json:"question"`
	Options   []PollOption `json:"options"`
	Anonymous bool         `json:"anonymous,omitempty"`
	Multiple  bool         `json:"multiple,omitempty"`
	Closed    bool         `json:"closed,omitempty"`
	Total     int          `json:"total,omitempty"`
}

type PollOption struct {
	Text   string `json:"text"`
	Votes  int    `json:"votes,omitempty"`
	Chosen bool   `json:"chosen,omitempty"` // she voted for it
}

type threadKey struct{}

// WithThread makes sends made with the returned context go to this forum topic (thread).
func WithThread(ctx context.Context, thread int64) context.Context {
	if thread == 0 {
		return ctx
	}
	return context.WithValue(ctx, threadKey{}, thread)
}

// NoThread clears any topic set on ctx (for sends into a different chat).
func NoThread(ctx context.Context) context.Context {
	return context.WithValue(ctx, threadKey{}, int64(0))
}

// ThreadFrom is the topic set by WithThread, 0 if none.
func ThreadFrom(ctx context.Context) int64 {
	t, _ := ctx.Value(threadKey{}).(int64)
	return t
}

// EventKind says what happened to an existing message.
type EventKind string

const (
	EventReaction EventKind = "reaction" // someone reacted to one of her messages
	EventEdit     EventKind = "edit"     // someone edited a message
)

// Event is a change to an existing message (not a new message). Only the user-account client reports them.
type Event struct {
	Kind    EventKind
	ChatID  int64
	MsgID   int64
	ActorID int64
	Actor   string
	Emoji   string // EventReaction
	Old     string // EventEdit: the text she saw before
	New     string // EventEdit
}

// EventSource is implemented by clients that report events; the agent type-asserts for it.
type EventSource interface {
	Events() <-chan Event
}

// Member is one participant of a group, as the account sees it.
type Member struct {
	ID       int64  `json:"id"`
	Name     string `json:"name"`
	Username string `json:"username,omitempty"`
	Role     string `json:"role"` // member | admin | owner
	IsBot    bool   `json:"is_bot,omitempty"`
}

// User is a public profile.
type User struct {
	ID        int64  `json:"id"`
	Name      string `json:"name"`
	Username  string `json:"username,omitempty"`
	Bio       string `json:"bio,omitempty"`
	IsBot     bool   `json:"is_bot,omitempty"`
	IsContact bool   `json:"is_contact,omitempty"`
}

type SearchQuery struct {
	Text     string
	ChatID   int64 // 0 = all chats
	SenderID int64 // 0 = anyone
	Since    time.Time
	Limit    int
}

// Client is everything Reina needs from Telegram.
type Client interface {
	// Run blocks, receiving updates into Updates() until ctx ends.
	Run(ctx context.Context) error
	// Updates delivers incoming (non-outgoing) messages.
	Updates() <-chan Message
	MyID() int64

	Chats(ctx context.Context, limit int) ([]Chat, error)
	Chat(ctx context.Context, id int64) (Chat, error)
	SearchChats(ctx context.Context, query string) ([]Chat, error)
	Unread(ctx context.Context, chatID int64) ([]Message, error)
	History(ctx context.Context, chatID, aroundID int64, before, after int) ([]Message, error)
	Message(ctx context.Context, chatID, msgID int64) (Message, error)
	Search(ctx context.Context, q SearchQuery) ([]Message, error)
	MarkRead(ctx context.Context, chatID int64) error

	SendText(ctx context.Context, chatID int64, text string, replyTo int64) (Message, error)
	SendPhoto(ctx context.Context, chatID int64, data []byte, caption string, replyTo int64) (Message, error)
	SendVoice(ctx context.Context, chatID int64, data []byte, replyTo int64) (Message, error)
	SendDocument(ctx context.Context, chatID int64, name string, data []byte, caption string, replyTo int64) (Message, error)
	SendSticker(ctx context.Context, chatID int64, fileID string, replyTo int64) (Message, error)
	Edit(ctx context.Context, chatID, msgID int64, text string) error
	Delete(ctx context.Context, chatID, msgID int64) error
	Forward(ctx context.Context, fromChat, msgID, toChat int64) error
	React(ctx context.Context, chatID, msgID int64, emoji string) error
	Typing(ctx context.Context, chatID int64) error
	// SendPoll posts a poll (2-10 options).
	SendPoll(ctx context.Context, chatID int64, question string, options []string, anonymous, multiple bool, replyTo int64) (Message, error)
	// VotePoll votes for the given option indexes (0-based); an empty list retracts the vote. Bots can't vote.
	VotePoll(ctx context.Context, chatID, msgID int64, options []int) error
	Pin(ctx context.Context, chatID, msgID int64, silent bool) error
	Unpin(ctx context.Context, chatID, msgID int64) error

	Join(ctx context.Context, link string) error
	Leave(ctx context.Context, chatID int64) error
	Ban(ctx context.Context, chatID, userID int64, removeAll bool) error
	SetMemberTag(ctx context.Context, chatID, userID int64, tag string) error
	// Members lists participants of a group (admins first, at most limit). Private chats return the peer.
	Members(ctx context.Context, chatID int64, limit int) ([]Member, error)
	// UserInfo returns the public profile of a user.
	UserInfo(ctx context.Context, userID int64) (User, error)

	Download(ctx context.Context, fileID string) ([]byte, error)
	ChatPhoto(ctx context.Context, chatID int64) ([]byte, error)
}
