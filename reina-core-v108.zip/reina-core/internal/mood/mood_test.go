package mood

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestAddClampDriftPersist(t *testing.T) {
	p := filepath.Join(t.TempDir(), "mood.json")
	now := time.Date(2026, 1, 1, 12, 0, 0, 0, time.UTC)
	m := New(p)
	m.now, m.at = func() time.Time { return now }, now
	if m.Level() != Neutral {
		t.Fatal(m.Level())
	}
	if got := m.Add(-100); got != Neutral-35 {
		t.Fatalf("step is clamped to 35, got %d", got)
	}
	if got := m.Add(-35); got != 0 {
		t.Fatalf("second drop must clamp at 0, got %d", got)
	}
	m.Set(-5)
	if m.Level() != 0 {
		t.Fatal("lower clamp")
	}
	now = now.Add(60 * time.Minute) // 10 points back to the middle
	if got := m.Level(); got != 10 {
		t.Fatalf("drift: want 10 got %d", got)
	}
	m.Set(100)
	if m.Level() != 100 {
		t.Fatal("upper")
	}
	now = now.Add(100 * time.Hour)
	if m.Level() != Neutral {
		t.Fatalf("must settle at Neutral, got %d", m.Level())
	}
	m.Set(15)
	m2 := newWith(p, func() time.Time { return now })
	if m2.Level() != 15 {
		t.Fatalf("not persisted: %d", m2.Level())
	}
}

func TestPromptBands(t *testing.T) {
	for _, c := range []struct {
		lvl  int
		want string
	}{{5, "Your mood is bad"}, {30, "irritated"}, {55, "Normal"}, {70, "Good mood"}, {95, "flirty"}} {
		got := Prompt(c.lvl, "Jaabir")
		if !strings.Contains(got, c.want) || !strings.Contains(got, "#change_mood") {
			t.Fatalf("%d: %s", c.lvl, got)
		}
		if (c.lvl <= 40 || c.lvl > 80) && !strings.Contains(got, "Jaabir") {
			t.Fatalf("%d: the owner must be covered by the extreme bands: %s", c.lvl, got)
		}
	}
	if !strings.Contains(Prompt(100, "J"), "underage") {
		t.Fatal("flirty band needs the age guard")
	}
}

func TestDamagedFileDoesNotPoisonMood(t *testing.T) {
	p := filepath.Join(t.TempDir(), "mood.json")
	now := time.Date(2026, 1, 1, 12, 0, 0, 0, time.UTC)
	if err := os.WriteFile(p, []byte(`{"Value":1e999,"At":"2030-01-01T00:00:00Z"}`), 0o600); err == nil {
		m := newWith(p, func() time.Time { return now })
		if l := m.Level(); l < 0 || l > 100 {
			t.Fatalf("level out of bounds: %d", l)
		}
		if m.at.After(now) {
			t.Fatal("future timestamp must be pulled back")
		}
	}
}
