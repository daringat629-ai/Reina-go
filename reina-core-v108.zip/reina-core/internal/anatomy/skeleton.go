package anatomy

import (
	"fmt"
	"math"
	"strings"

	"orvi/internal/body"
)

// Bone is one bone of her skeleton: a segment on the model with how whole and how loaded it is.
type Bone struct {
	ID     string     `json:"id"`
	Name   string     `json:"name"`
	A      [3]float64 `json:"a"`
	B      [3]float64 `json:"b"`
	Health float64    `json:"health"` // 1 = whole
	Load   float64    `json:"load"`   // strain, 0..1
}

type seg struct {
	id, name string
	a, b     [3]float64
	limb     bool // carries the weight of walking: tired muscles load it
}

type v3 = [3]float64

func lerp(a, b v3, t float64) v3 {
	return v3{a[0] + (b[0]-a[0])*t, a[1] + (b[1]-a[1])*t, a[2] + (b[2]-a[2])*t}
}

// Humans have 206 bones as adults. Every one of them is here, by name, in its place on the model.
const BoneCount = 206

func segs() []seg {
	var s []seg
	add := func(id, name string, a, b v3, limb bool) { s = append(s, seg{id, name, a, b, limb}) }
	// the skull: 8 cranial and 14 facial bones
	cr := []string{"лобная кость", "правая теменная кость", "левая теменная кость", "затылочная кость", "правая височная кость", "левая височная кость", "клиновидная кость", "решётчатая кость"}
	crp := []v3{{0, 87, 5}, {-3, 88, 0}, {3, 88, 0}, {0, 84, -4}, {-5, 82, 0.5}, {5, 82, 0.5}, {0, 83, 3}, {0, 82, 4.5}}
	for i, n := range cr {
		add(fmt.Sprintf("cranium%d", i), n, crp[i], lerp(crp[i], v3{0, 84, 1}, .25), false)
	}
	fc := []string{"правая носовая кость", "левая носовая кость", "правая верхнечелюстная кость", "левая верхнечелюстная кость", "правая скуловая кость", "левая скуловая кость", "нижняя челюсть", "правая нёбная кость", "левая нёбная кость", "правая слёзная кость", "левая слёзная кость", "сошник", "правая нижняя носовая раковина", "левая нижняя носовая раковина"}
	fcp := []v3{{-.8, 82, 6.6}, {.8, 82, 6.6}, {-1.8, 80, 6}, {1.8, 80, 6}, {-4, 81.5, 4}, {4, 81.5, 4}, {0, 77.5, 5}, {-1.2, 79.5, 4}, {1.2, 79.5, 4}, {-2.5, 82.5, 5.5}, {2.5, 82.5, 5.5}, {0, 80, 5.2}, {-1, 81, 5.8}, {1, 81, 5.8}}
	for i, n := range fc {
		b := lerp(fcp[i], v3{0, 80, 3}, .2)
		if n == "нижняя челюсть" {
			b = v3{4, 80, 3}
		}
		add(fmt.Sprintf("face%d", i), n, fcp[i], b, false)
	}
	add("hyoid", "подъязычная кость", v3{-1.5, 76.5, 3}, v3{1.5, 76.5, 3}, false)
	for _, k := range []float64{1, -1} {
		side := map[float64]string{1: "левое", -1: "правое"}[k]
		for i, n := range []string{"молоточек", "наковальня", "стремя"} {
			a := v3{5.2 * k, 82.3 - .25*float64(i), .5 + .3*float64(i)}
			add(fmt.Sprintf("ossicle%d%s", i, sideID(k)), n+" "+side+" уха", a, lerp(a, v3{4.5 * k, 82.3, 0.8}, .5), false)
		}
	}
	// the spine: 7 cervical, 12 thoracic, 5 lumbar, sacrum, coccyx
	vert := func(prefix, name string, n int, a, b v3) {
		for i := 0; i < n; i++ {
			add(fmt.Sprintf("%s%d", prefix, i+1), fmt.Sprintf("%s %d", name, i+1), lerp(a, b, float64(i)/float64(n)), lerp(a, b, float64(i+1)/float64(n)), false)
		}
	}
	vert("C", "шейный позвонок", 7, v3{0, 80, 1.5}, v3{0, 73, .5})
	vert("T", "грудной позвонок", 12, v3{0, 73, .5}, v3{0, 58, -.8})
	vert("L", "поясничный позвонок", 5, v3{0, 58, -.8}, v3{0, 51, .3})
	add("sacrum", "крестец", v3{0, 51, .3}, v3{0, 48.5, -.4}, false)
	add("coccyx", "копчик", v3{0, 48.5, -.4}, v3{0, 46.5, .2}, false)
	// the chest: sternum, 12 pairs of ribs
	add("sternum", "грудина", v3{0, 71.5, 4}, v3{0, 63.5, 4.6}, false)
	for i := 0; i < 12; i++ {
		y := 71.5 - 1.1*float64(i)
		w := 5.5 + math.Sin(float64(i)/11*math.Pi)*2.2
		if i >= 10 {
			w = 5
		}
		for _, k := range []float64{1, -1} {
			add(fmt.Sprintf("rib%d%s", i+1, sideID(k)), fmt.Sprintf("ребро %d %s", i+1, sideWord(k)), v3{0, y, -1}, v3{w * k, y - .6, 3.5}, false)
		}
	}
	for _, k := range []float64{1, -1} {
		n, sw := sideID(k), sideWord(k)
		// the shoulder girdle and the arm
		add("clav"+n, "ключица "+sw, v3{0, 72, 2.5}, v3{8 * k, 71.5, 1}, false)
		add("scap"+n, "лопатка "+sw, v3{5 * k, 70.5, -2}, v3{9.5 * k, 67.5, -2}, false)
		sh, el, wr := v3{8 * k, 71.5, 1}, v3{20 * k, 69, 0}, v3{29 * k, 65.5, 0}
		add("humerus"+n, "плечевая кость "+sw, sh, el, true)
		add("radius"+n, "лучевая кость "+sw, el, lerp(el, wr, 1), true)
		add("ulna"+n, "локтевая кость "+sw, v3{el[0], el[1], el[2] - .8}, v3{wr[0], wr[1], wr[2] - .8}, true)
		// the hand: 8 carpals, 5 metacarpals, 14 phalanges
		cn := []string{"ладьевидная", "полулунная", "трёхгранная", "гороховидная", "кость-трапеция", "трапециевидная", "головчатая", "крючковатая"}
		for i, c := range cn {
			x := 29 + .6*float64(i%4)
			z := -1.2 + .8*float64(i/4)*2 + .5*float64(i%2)
			add(fmt.Sprintf("carpal%d%s", i, n), c+" кость запястья "+sw, v3{x * k, 65.6, z}, v3{(x + .5) * k, 65.5, z}, true)
		}
		zs := []float64{2.8, 1.2, 0, -1.2, -2.4} // thumb .. little finger
		fn := []string{"большого", "указательного", "среднего", "безымянного", "мизинца"}
		for f := 0; f < 5; f++ {
			z := zs[f]
			add(fmt.Sprintf("meta%d%s", f, n), "пястная кость "+fn[f]+" пальца "+sw, v3{31.5 * k, 65.2, z}, v3{34.5 * k, 64.6, z}, true)
			bounds := []float64{34.5, 36.4, 37.6, 38.6}
			names := []string{"проксимальная", "средняя", "дистальная"}
			if f == 0 {
				bounds = []float64{34.5, 36.2, 37.4}
				names = []string{"проксимальная", "дистальная"}
			}
			for j := 0; j < len(names); j++ {
				add(fmt.Sprintf("phh%d_%d%s", f, j, n), names[j]+" фаланга "+fn[f]+" пальца руки "+sw, v3{bounds[j] * k, 64.6 - .6*float64(j), z}, v3{bounds[j+1] * k, 64.0 - .6*float64(j), z}, true)
			}
		}
		// the pelvis and the leg
		add("pelvis"+n, "тазовая кость "+sw, v3{0, 50, .3}, v3{8 * k, 52, 0}, false)
		hp, kn, an := v3{4.5 * k, 48, .5}, v3{4.5 * k, 28, 1}, v3{4.5 * k, 6, 0}
		add("femur"+n, "бедренная кость "+sw, hp, kn, true)
		add("patella"+n, "надколенник "+sw, v3{4.5 * k, 28.6, 2.8}, v3{4.5 * k, 27.4, 2.8}, true)
		add("tibia"+n, "большеберцовая кость "+sw, kn, an, true)
		add("fibula"+n, "малоберцовая кость "+sw, v3{5.7 * k, 27.5, .6}, v3{5.7 * k, 6.5, -.2}, true)
		// the foot: 7 tarsals, 5 metatarsals, 14 phalanges
		tn := []string{"таранная", "пяточная", "ладьевидная", "кубовидная", "медиальная клиновидная", "промежуточная клиновидная", "латеральная клиновидная"}
		tp := []v3{{0, 5.5, .5}, {0, 3, -1.5}, {0, 4, 2}, {1, 3, 2.5}, {-1, 3.6, 3.2}, {0, 3.6, 3.4}, {1, 3.4, 3.2}}
		for i, t := range tn {
			p := v3{(4.5 + tp[i][0]) * k, tp[i][1], tp[i][2]}
			add(fmt.Sprintf("tarsal%d%s", i, n), t+" кость стопы "+sw, p, v3{p[0], p[1] - .6, p[2] + .8}, true)
		}
		for f := 0; f < 5; f++ {
			x := (4.5 - 2 + 1.1*float64(f)) * k
			if k < 0 {
				x = (-4.5 + 2 - 1.1*float64(f))
			}
			add(fmt.Sprintf("mt%d%s", f, n), "плюсневая кость "+fn[f]+" пальца "+sw, v3{x, 2.5, 3.8}, v3{x, 1.5, 6.2}, true)
			ph := []float64{6.2, 7.2, 7.9, 8.4}
			names := []string{"проксимальная", "средняя", "дистальная"}
			if f == 0 {
				ph = []float64{6.2, 7.3, 8.3}
				names = []string{"проксимальная", "дистальная"}
			}
			for j := 0; j < len(names); j++ {
				add(fmt.Sprintf("phf%d_%d%s", f, j, n), names[j]+" фаланга "+fn[f]+" пальца стопы "+sw, v3{x, 1.3, ph[j]}, v3{x, 1.1, ph[j+1]}, true)
			}
		}
	}
	return s
}

func sideID(k float64) string {
	if k > 0 {
		return "L"
	}
	return "R"
}

func sideWord(k float64) string {
	if k > 0 {
		return "слева"
	}
	return "справа"
}

// Skeleton reads her bones: whole or hurt (the body's integrity), loaded by pain everywhere and by tired muscles in the limbs.
func Skeleton(b body.State) []Bone {
	ss := segs()
	out := make([]Bone, 0, len(ss))
	for _, s := range ss {
		load := b.Pain * .6
		if s.limb {
			load = math.Max(load, b.Fatigue*.6)
		}
		out = append(out, Bone{ID: s.id, Name: s.name, A: s.a, B: s.b, Health: clamp(b.Bones, 0, 1), Load: clamp(load, 0, 1)})
	}
	return out
}

// BoneReport is the self-inspection of one bone by id, name or a part of the name ("" if there is none).
func BoneReport(bs []Bone, q string) string {
	q = strings.ToLower(strings.TrimSpace(q))
	if q == "" {
		return ""
	}
	pick := func(match func(Bone) bool) *Bone {
		for i := range bs {
			if match(bs[i]) {
				return &bs[i]
			}
		}
		return nil
	}
	b := pick(func(b Bone) bool { return strings.ToLower(b.ID) == q || strings.ToLower(b.Name) == q })
	if b == nil && len([]rune(q)) >= 4 {
		b = pick(func(b Bone) bool { return strings.Contains(strings.ToLower(b.Name), q) })
	}
	if b == nil {
		return ""
	}
	st := "цела"
	if b.Health < .5 {
		st = "серьёзно повреждена"
	} else if b.Health < .9 {
		st = "ушиблена"
	}
	return fmt.Sprintf("Кость «%s»: %s, нагрузка %.2f, исправность %.2f. В моём скелете %d костей, как у взрослого человека; это одна из них, сигнал мой собственный.", b.Name, st, b.Load, b.Health, len(bs))
}
