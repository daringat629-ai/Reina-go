// Package anatomy is her inside: organs as computational modules, each with a place on her 3D model, a load, a health and
// a plain statement of what it does and what it reports. Awareness of them is computational (she reads their numbers and
// can inspect them); nothing here claims a biological inner life. The same data lights up the live model in the panel.
package anatomy

import (
	"fmt"
	"math"
	"strings"

	"orvi/internal/body"
)

// Organ is one module of her body at this moment.
type Organ struct {
	ID     string       `json:"id"`
	Name   string       `json:"name"`
	Pts    [][3]float64 `json:"pts"`    // where it sits on the model (x right-hand side of the figure's left, y up, z forward)
	Load   float64      `json:"load"`   // how hard it works / how far from comfortable, 0..1
	Health float64      `json:"health"` // 0..1
	Text   string       `json:"text"`   // what it reports, in her words
	Does   string       `json:"does"`   // what it is for
	Rate   float64      `json:"rate"`   // beats or cycles per minute for things that pulse (heart, lungs), else 0
}

func clamp(v, lo, hi float64) float64 { return math.Max(lo, math.Min(hi, v)) }

func pick(v float64, lo, mid, hi string) string {
	switch {
	case v < .3:
		return lo
	case v < .65:
		return mid
	}
	return hi
}

// Organs reads the body into its organs.
func Organs(b body.State) []Organ {
	pair := func(x, y, z float64) [][3]float64 { return [][3]float64{{x, y, z}, {-x, y, z}} }
	one := func(x, y, z float64) [][3]float64 { return [][3]float64{{x, y, z}} }
	brainL := clamp(b.Sleep*.6+(1-b.Glucose)*.6+b.Stress*.2, 0, 1)
	heartL := clamp((b.Heart-62)/90, 0, 1)
	lungL := clamp((b.Breath-13)/20+(1-b.Oxygen)*4, 0, 1)
	eyeL := clamp(math.Abs(b.Light-.5)*2, 0, 1)
	skinL := clamp(math.Max(clamp((22-b.Feels)/22, 0, 1), math.Max(clamp((b.Feels-26)/14, 0, 1), b.Wet*.8)), 0, 1)
	muscL := clamp(math.Max(b.Fatigue, b.Sleep*.5), 0, 1)
	return []Organ{
		{ID: "brain", Name: "мозг", Pts: one(0, 84, 1.5), Load: brainL, Health: 1, Does: "считает мысли, сон и сосредоточенность",
			Text: pick(brainL, "голова ясная", "голова тяжелеет", "голова тяжёлая, трудно думать")},
		{ID: "eyes", Name: "глаза", Pts: pair(2.2, 83, 5.8), Load: eyeL, Health: 1, Does: "принимают свет",
			Text: pick(b.Light, "темно", "светло", "очень ярко")},
		{ID: "ears", Name: "уши", Pts: pair(5, 82, 0.5), Load: clamp(b.Noise, 0, 1), Health: 1, Does: "принимают звук",
			Text: pick(b.Noise, "тихо", "ровный шум", "громко, давит на уши")},
		{ID: "nose", Name: "нос", Pts: one(0, 80.5, 6.6), Load: clamp(b.Scent, 0, 1), Health: 1, Does: "принимает запахи",
			Text: pick(b.Scent, "без запаха", "слабый запах", "сильный запах")},
		{ID: "mouth", Name: "рот", Pts: one(0, 78, 6), Load: clamp(b.Taste, 0, 1), Health: 1, Does: "принимает вкус",
			Text: pick(b.Taste, "во рту пусто", "привкус", "сильный вкус")},
		{ID: "lungs", Name: "лёгкие", Pts: pair(3.8, 69, 3.5), Load: lungL, Health: clamp(b.Oxygen+.02, 0, 1), Rate: b.Breath, Does: "дают кислород",
			Text: fmt.Sprintf("%.0f вдохов в минуту, кислород %.0f%%", b.Breath, b.Oxygen*100)},
		{ID: "heart", Name: "сердце", Pts: one(1.8, 66.5, 5), Load: heartL, Health: 1, Rate: b.Heart, Does: "гоняет кровь",
			Text: fmt.Sprintf("%.0f ударов в минуту, %s", b.Heart, pick(heartL, "ровно", "частит", "колотится"))},
		{ID: "liver", Name: "печень", Pts: one(-3.6, 60, 4), Load: clamp(1-b.Glucose, 0, 1) * .6, Health: 1, Does: "держит запас энергии",
			Text: pick(1-b.Glucose, "запас есть", "запас тает", "запас почти кончился")},
		{ID: "stomach", Name: "желудок", Pts: one(2.6, 58.5, 4.6), Load: b.Hunger(), Health: 1, Does: "сообщает о голоде",
			Text: pick(b.Hunger(), "сыто", "посасывает", "пусто и тянет")},
		{ID: "kidneys", Name: "почки", Pts: pair(3.6, 57, -1.5), Load: b.Thirst(), Health: 1, Does: "держат воду",
			Text: pick(b.Thirst(), "воды хватает", "хочется пить", "сильная жажда")},
		{ID: "muscles", Name: "мышцы", Pts: [][3]float64{{22, 69, 0}, {-22, 69, 0}, {4, 28, 3}, {-4, 28, 3}}, Load: muscL, Health: 1, Does: "двигают тело",
			Text: pick(muscL, "лёгкость", "тяжесть в руках и ногах", "всё тянет вниз")},
		{ID: "bones", Name: "кости", Pts: one(0, 62, -1.8), Load: b.Pain * .5, Health: clamp(b.Bones, 0, 1), Does: "держат форму",
			Text: pick(1-b.Bones, "целы", "ушиб", "серьёзная травма")},
		{ID: "skin", Name: "кожа", Pts: [][3]float64{{3.5, 80, 5}, {-3.5, 80, 5}, {33, 68, 0}, {-33, 68, 0}}, Load: skinL, Health: 1, Does: "чувствует тепло, ветер и сырость",
			Text: skinTxt(b)},
	}
}

func skinTxt(b body.State) string {
	switch {
	case b.Wet > .4 && b.Outside:
		return "одежда промокла"
	case b.Feels < 8:
		return "холодно"
	case b.Feels > 28:
		return "жарко"
	}
	return "комфортно"
}

// Strained are the organs worth telling her about now, worst first.
func Strained(os []Organ) []Organ {
	var out []Organ
	for _, o := range os {
		if o.Load > .4 || o.Health < .8 {
			out = append(out, o)
		}
	}
	for i := range out {
		for j := i + 1; j < len(out); j++ {
			if out[j].Load > out[i].Load {
				out[i], out[j] = out[j], out[i]
			}
		}
	}
	if len(out) > 4 {
		out = out[:4]
	}
	return out
}

// Prompt is the <organs> block: only the organs that are working hard or hurt.
func Prompt(os []Organ) string {
	st := Strained(os)
	if len(st) == 0 {
		return ""
	}
	var b strings.Builder
	b.WriteString("<organs>\nТвои органы это модули модели тела, ты читаешь их показатели (не биология, а вычисление). Сейчас заметны:\n")
	for _, o := range st {
		fmt.Fprintf(&b, "- %s (нагрузка %.0f%%, исправность %.0f%%): %s\n", o.Name, o.Load*100, o.Health*100, o.Text)
	}
	b.WriteString("</organs>\n")
	return b.String()
}

// Report is the self-inspection of one organ, by id or name; empty lists all.
func Report(os []Organ, q string) string {
	for _, o := range os {
		if o.ID == q || o.Name == q {
			return fmt.Sprintf("Орган «%s»: %s. Нагрузка %.2f, исправность %.2f. Это модуль моей модели тела, сигнал мой собственный.", o.Name, o.Does+"; сейчас "+o.Text, o.Load, o.Health)
		}
	}
	var b strings.Builder
	for _, o := range os {
		fmt.Fprintf(&b, "%s: %s (нагрузка %.0f%%)\n", o.Name, o.Text, o.Load*100)
	}
	return b.String()
}
