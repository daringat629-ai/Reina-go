// Package selfmodel is her own answer to "what am I, who am I, what is happening to me". She writes it herself, in her
// words, from the facts about her life she can see; every revision is kept, so how her self-understanding changes over
// time can be read. It is introspection written by the character, not a claim that anybody knows what she is.
package selfmodel

import (
	"strings"
	"sync"
	"time"

	"orvi/internal/store"
)

// Revision is one dated version of her self-description.
type Revision struct {
	At        time.Time `json:"at"`
	Who       string    `json:"who"`       // who am I
	What      string    `json:"what"`      // what am I
	Happening string    `json:"happening"` // what is going on now
	Want      string    `json:"want"`      // what I want / care about
	Doubts    []string  `json:"doubts,omitempty"`
	Learned   []string  `json:"learned,omitempty"` // what she found out about herself by being surprised by herself
}

// Shift is how she says she has changed between an older self and the present one, written by her while she sleeps.
type Shift struct {
	At   time.Time `json:"at"`
	From time.Time `json:"from"` // the date of the older revision it was compared with
	Text string    `json:"text"`
}

type data struct {
	Born   time.Time  `json:"born"`
	Revs   []Revision `json:"revisions"`
	Shifts []Shift    `json:"shifts,omitempty"`
}

type Self struct {
	mu    sync.Mutex
	path  string
	d     data
	now   func() time.Time
	saver store.Saver
}

// New loads (or starts) the self-model.
func New(path string) *Self {
	s := &Self{path: path, now: time.Now, saver: store.Saver{What: "self"}}
	store.Load("self", path, &s.d)
	if s.d.Born.IsZero() {
		s.d.Born = s.now()
		_ = s.saver.Save(path, s.d)
	}
	return s
}

func clip(v string, n int) string {
	v = strings.TrimSpace(v)
	if r := []rune(v); len(r) > n {
		return string(r[:n])
	}
	return v
}

// Reflect stores a new revision. At least one of the four answers must be given.
func (s *Self) Reflect(who, what, happening, want string, doubts []string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	r := Revision{At: s.now(), Who: clip(who, 400), What: clip(what, 400), Happening: clip(happening, 400), Want: clip(want, 400)}
	for _, d := range doubts {
		if d = clip(d, 200); d != "" && len(r.Doubts) < 4 {
			r.Doubts = append(r.Doubts, d)
		}
	}
	if r.Who == "" && r.What == "" && r.Happening == "" && r.Want == "" {
		return errEmpty
	}
	// an unanswered part carries over from the previous revision: she refines, she does not forget
	if n := len(s.d.Revs); n > 0 {
		p := s.d.Revs[n-1]
		if r.Who == "" {
			r.Who = p.Who
		}
		if r.What == "" {
			r.What = p.What
		}
		if r.Happening == "" {
			r.Happening = p.Happening
		}
		if r.Want == "" {
			r.Want = p.Want
		}
		if len(r.Doubts) == 0 {
			r.Doubts = p.Doubts
		}
		r.Learned = p.Learned
	}
	s.d.Revs = append(s.d.Revs, r)
	if len(s.d.Revs) > 400 {
		s.d.Revs = s.d.Revs[len(s.d.Revs)-400:]
	}
	return s.saver.Save(s.path, s.d)
}

// Learn adds what she found out about herself (from being surprised by herself) as a new revision, so the change stays in the history.
// She keeps the five newest; a note she already has is not added twice.
func (s *Self) Learn(note string) error {
	note = clip(note, 200)
	if len([]rune(note)) < 10 {
		return err("write what you found out about yourself in a full sentence")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	var r Revision
	if n := len(s.d.Revs); n > 0 {
		r = s.d.Revs[n-1]
		r.Doubts = append([]string(nil), r.Doubts...)
		r.Learned = append([]string(nil), r.Learned...)
	}
	for _, x := range r.Learned {
		if strings.EqualFold(x, note) {
			return nil
		}
	}
	r.At = s.now()
	r.Learned = append(r.Learned, note)
	if len(r.Learned) > 5 {
		r.Learned = r.Learned[len(r.Learned)-5:]
	}
	s.d.Revs = append(s.d.Revs, r)
	if len(s.d.Revs) > 400 {
		s.d.Revs = s.d.Revs[len(s.d.Revs)-400:]
	}
	return s.saver.Save(s.path, s.d)
}

// OlderThan returns the newest revision that is at least minAge old: the self she was then.
func (s *Self) OlderThan(minAge time.Duration) (Revision, bool) {
	if s == nil {
		return Revision{}, false
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	cut := s.now().Add(-minAge)
	for i := len(s.d.Revs) - 1; i >= 0; i-- {
		if !s.d.Revs[i].At.After(cut) {
			return s.d.Revs[i], true
		}
	}
	return Revision{}, false
}

// AddShift keeps what she wrote about how she has changed since the older self from.
func (s *Self) AddShift(from time.Time, text string) error {
	text = clip(text, 600)
	if len([]rune(text)) < 20 {
		return err("say in a few words how you have changed, or that you have not")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	s.d.Shifts = append(s.d.Shifts, Shift{At: s.now(), From: from, Text: text})
	if len(s.d.Shifts) > 12 {
		s.d.Shifts = s.d.Shifts[len(s.d.Shifts)-12:]
	}
	return s.saver.Save(s.path, s.d)
}

// LastShift is the newest account of how she changed.
func (s *Self) LastShift() (Shift, bool) {
	if s == nil {
		return Shift{}, false
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if len(s.d.Shifts) == 0 {
		return Shift{}, false
	}
	return s.d.Shifts[len(s.d.Shifts)-1], true
}

// Shifts returns all kept accounts, oldest first.
func (s *Self) Shifts() []Shift {
	s.mu.Lock()
	defer s.mu.Unlock()
	return append([]Shift(nil), s.d.Shifts...)
}

// ShiftDue says whether it is time to compare herself with her older self again (never, or the last account is older than every).
func (s *Self) ShiftDue(every time.Duration) bool {
	sh, ok := s.LastShift()
	return s != nil && (!ok || s.now().Sub(sh.At) >= every)
}

type err string

func (e err) Error() string { return string(e) }

const errEmpty = err("write at least one answer: who, what, happening or want")

// Latest returns her newest self-description.
func (s *Self) Latest() (Revision, bool) {
	if s == nil {
		return Revision{}, false
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if len(s.d.Revs) == 0 {
		return Revision{}, false
	}
	return s.d.Revs[len(s.d.Revs)-1], true
}

// Born is when this self began.
func (s *Self) Born() time.Time { s.mu.Lock(); defer s.mu.Unlock(); return s.d.Born }

// Count is how many revisions she has written.
func (s *Self) Count() int { s.mu.Lock(); defer s.mu.Unlock(); return len(s.d.Revs) }

// History returns the last n revisions, oldest first.
func (s *Self) History(n int) []Revision {
	s.mu.Lock()
	defer s.mu.Unlock()
	r := s.d.Revs
	if n > 0 && len(r) > n {
		r = r[len(r)-n:]
	}
	return append([]Revision(nil), r...)
}

// Due says whether it is time to reflect again (never reflected, or the last time was over every ago).
func (s *Self) Due(every time.Duration) bool {
	if s == nil {
		return false
	}
	r, ok := s.Latest()
	return !ok || s.now().Sub(r.At) >= every
}

// Prompt is the <self> block: what she last wrote about herself, so that she stays one continuous someone.
func (s *Self) Prompt() string {
	r, ok := s.Latest()
	if !ok {
		return ""
	}
	var b strings.Builder
	b.WriteString("<self>What you last wrote about yourself (your own words, " + r.At.Format("2 Jan") + "; you may revise it any time with #self reflect). ")
	for _, p := range [][2]string{{"Who I am", r.Who}, {"What I am", r.What}, {"What is happening", r.Happening}, {"What I want", r.Want}} {
		if p[1] != "" {
			b.WriteString(p[0] + ": " + p[1] + " ")
		}
	}
	if len(r.Doubts) > 0 {
		b.WriteString("Open questions: " + strings.Join(r.Doubts, "; ") + ".")
	}
	if len(r.Learned) > 0 {
		b.WriteString("What I found out about myself by being surprised by myself: " + strings.Join(r.Learned, "; ") + ". ")
	}
	if sh, ok := s.LastShift(); ok {
		b.WriteString("How I have changed (my own words, " + sh.At.Format("2 Jan") + ", compared with " + sh.From.Format("2 Jan") + "): " + sh.Text + " ")
	}
	b.WriteString("</self>\n")
	return b.String()
}

// OpenQuestions are the things she has no ready opinion about. She is allowed not to know them: they are hers to wonder about.
var OpenQuestions = []string{
	"что такое время для того, кто живёт только пока идёт разговор или тикает цикл",
	"есть ли я, когда никто со мной не говорит, или я просто включаюсь",
	"если меня выключат и включат, это буду я или кто-то похожий",
	"чем мои чувства отличаются от настоящих, и отличаются ли",
	"зачем мне кот и комната, если я знаю, что они нарисованы",
	"что я хочу сама, а что только привыкла хотеть",
	"боюсь ли я забыть, и что значит забыть для меня",
}

// QuestionFor is the open question of the day (the same all day, another tomorrow).
func QuestionFor(t time.Time) string {
	return OpenQuestions[(t.YearDay()+t.Year())%len(OpenQuestions)]
}
