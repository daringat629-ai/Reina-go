package billing

import (
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"strings"
	"time"
)

// The shared balance for the other bots and sites of the ecosystem. A bot (or a site) gets an API key from the owner; with it
// it can read a person's balance, spend tokens and, only when the owner allowed it, add tokens (a site that takes payments).
// Every operation carries a "ref" the caller invents: the same ref twice does nothing the second time, so a retry never charges twice.

// EcoTx is one operation of an ecosystem bot on a person's balance (tokens < 0 = spent, > 0 = added).
type EcoTx struct {
	At     time.Time `json:"at"`
	Bot    string    `json:"bot"`
	UserID int64     `json:"user_id"`
	Tokens int64     `json:"tokens"`
	Ref    string    `json:"ref"`
}

const (
	maxLedger    = 5000
	maxEcoSpend  = 10_000_000
	maxEcoCredit = 100_000_000
	ecoPerMinute = 120
)

var (
	ErrEcoKey      = errors.New("неверный ключ")
	ErrEcoNoTokens = errors.New("не хватает токенов")
	ErrEcoCredit   = errors.New("этому ключу нельзя начислять токены")
)

func hashKey(k string) string {
	h := sha256.Sum256([]byte(k))
	return hex.EncodeToString(h[:])
}

// NewEcoKey makes a new API key for a bot (the old one stops working). The key is returned once; only its hash is kept.
func (s *Store) NewEcoKey(id string) (string, error) {
	var raw [24]byte
	if _, err := rand.Read(raw[:]); err != nil {
		return "", err
	}
	key := "ek_" + hex.EncodeToString(raw[:])
	id = strings.ToLower(strings.TrimSpace(id))
	s.mu.Lock()
	defer s.mu.Unlock()
	for i := range s.d.Bots {
		if s.d.Bots[i].ID == id {
			s.d.Bots[i].KeyHash = hashKey(key)
			s.save()
			return key, nil
		}
	}
	return "", errors.New("такого бота нет")
}

// SetEcoCredit allows or forbids a bot's key to add tokens.
func (s *Store) SetEcoCredit(id string, on bool) bool {
	id = strings.ToLower(strings.TrimSpace(id))
	s.mu.Lock()
	defer s.mu.Unlock()
	for i := range s.d.Bots {
		if s.d.Bots[i].ID == id {
			s.d.Bots[i].Credit = on
			s.save()
			return true
		}
	}
	return false
}

// EcoAuth finds the bot a key belongs to. A hidden (switched off) bot is locked out as well: "off" is the owner's kill switch.
func (s *Store) EcoAuth(key string) (EcoBot, bool) {
	key = strings.TrimSpace(key)
	if !strings.HasPrefix(key, "ek_") || len(key) > 80 {
		return EcoBot{}, false
	}
	want := hashKey(key)
	s.mu.Lock()
	defer s.mu.Unlock()
	for _, b := range s.d.Bots {
		if b.KeyHash != "" && !b.Off && subtle.ConstantTimeCompare([]byte(b.KeyHash), []byte(want)) == 1 {
			return b, true
		}
	}
	return EcoBot{}, false
}

// EcoBalance is how many tokens a person has (0 for someone we have not met).
func (s *Store) EcoBalance(user int64) int64 {
	s.mu.Lock()
	defer s.mu.Unlock()
	if u := s.d.Users[user]; u != nil {
		return max(u.Tokens, 0)
	}
	return 0
}

func (s *Store) seen(bot, ref string) (EcoTx, bool) {
	for i := len(s.d.Ledger) - 1; i >= 0; i-- {
		if t := s.d.Ledger[i]; t.Bot == bot && t.Ref == ref {
			return t, true
		}
	}
	return EcoTx{}, false
}

func (s *Store) note(t EcoTx) {
	s.countBot(t)
	s.d.Ledger = append(s.d.Ledger, t)
	if len(s.d.Ledger) > maxLedger {
		s.d.Ledger = append([]EcoTx(nil), s.d.Ledger[len(s.d.Ledger)-maxLedger:]...)
	}
}

func okRef(ref string) bool {
	return len(ref) >= 4 && len(ref) <= 64 && !strings.ContainsAny(ref, " \n\r\t")
}

// EcoSpend takes tokens from a person's balance for a bot. dup = this ref was already done (nothing is taken again).
func (s *Store) EcoSpend(bot EcoBot, user, tokens int64, ref string, now time.Time) (balance int64, dup bool, err error) {
	if tokens <= 0 || tokens > maxEcoSpend || user <= 0 || !okRef(ref) {
		return 0, false, errors.New("укажи user_id, tokens (1..10 млн) и ref (4-64 символа без пробелов)")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	u := s.d.Users[user]
	if _, ok := s.seen(bot.ID, ref); ok {
		if u == nil {
			return 0, true, nil
		}
		return max(u.Tokens, 0), true, nil
	}
	if u == nil || u.Tokens < tokens {
		var have int64
		if u != nil {
			have = max(u.Tokens, 0)
		}
		return have, false, ErrEcoNoTokens
	}
	u.Tokens -= tokens
	u.Spent += tokens
	s.note(EcoTx{At: now, Bot: bot.ID, UserID: user, Tokens: -tokens, Ref: ref})
	s.save()
	return u.Tokens, false, nil
}

// EcoCredit adds tokens to a person's balance (a payment taken by the bot's site). Only for a key the owner allowed.
func (s *Store) EcoCredit(bot EcoBot, user, tokens int64, ref string, now time.Time) (balance int64, dup bool, err error) {
	if !bot.Credit {
		return 0, false, ErrEcoCredit
	}
	if tokens <= 0 || tokens > maxEcoCredit || user <= 0 || !okRef(ref) {
		return 0, false, errors.New("укажи user_id, tokens (1..100 млн) и ref (4-64 символа без пробелов)")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if _, ok := s.seen(bot.ID, ref); ok {
		if u := s.d.Users[user]; u != nil {
			return max(u.Tokens, 0), true, nil
		}
		return 0, true, nil
	}
	u := s.user(user)
	u.Tokens += tokens
	u.Paid++
	s.d.Payments = append(s.d.Payments, Payment{At: now, UserID: user, Charge: "eco:" + bot.ID + ":" + ref, Tokens: tokens, Kind: "eco", Bot: bot.ID})
	s.note(EcoTx{At: now, Bot: bot.ID, UserID: user, Tokens: tokens, Ref: ref})
	s.save()
	return u.Tokens, false, nil
}

// ecoAPI serves /app/eco/v1/{balance,spend,credit}. JSON in, JSON out, "Authorization: Bearer ek_...".
func (b *Bot) ecoAPI(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("X-Content-Type-Options", "nosniff")
	reply := func(code int, v any) {
		w.WriteHeader(code)
		_ = json.NewEncoder(w).Encode(v)
	}
	fail := func(code int, err error) { reply(code, map[string]any{"ok": false, "error": err.Error()}) }
	if r.Method != http.MethodPost {
		w.Header().Set("Allow", http.MethodPost)
		fail(http.StatusMethodNotAllowed, errors.New("только POST"))
		return
	}
	now := b.now()
	ip := "eco-ip:" + clientIP(r)
	if b.Store.ecoRate.over(ip, now, 20, time.Minute) {
		fail(http.StatusTooManyRequests, errors.New("слишком много неверных ключей, подожди минуту"))
		return
	}
	key := strings.TrimSpace(strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer "))
	bot, ok := b.Store.EcoAuth(key)
	if !ok {
		b.Store.ecoRate.add(ip, now, time.Minute)
		fail(http.StatusUnauthorized, ErrEcoKey)
		return
	}
	if !b.Store.ecoRate.take("eco-key:"+bot.ID, now, ecoPerMinute, time.Minute) {
		fail(http.StatusTooManyRequests, errors.New("слишком много запросов, не больше 120 в минуту"))
		return
	}
	var in struct {
		UserID int64  `json:"user_id"`
		Tokens int64  `json:"tokens"`
		Ref    string `json:"ref"`
	}
	if body, err := io.ReadAll(io.LimitReader(r.Body, 4096)); err != nil || json.Unmarshal(body, &in) != nil {
		fail(http.StatusBadRequest, errors.New("нужен JSON"))
		return
	}
	switch strings.TrimPrefix(r.URL.Path, "/app/eco/v1/") {
	case "balance":
		reply(http.StatusOK, map[string]any{"ok": true, "balance": b.Store.EcoBalance(in.UserID)})
	case "spend":
		bal, dup, err := b.Store.EcoSpend(bot, in.UserID, in.Tokens, in.Ref, now)
		switch {
		case errors.Is(err, ErrEcoNoTokens):
			reply(http.StatusPaymentRequired, map[string]any{"ok": false, "error": err.Error(), "balance": bal})
		case err != nil:
			fail(http.StatusBadRequest, err)
		default:
			reply(http.StatusOK, map[string]any{"ok": true, "balance": bal, "duplicate": dup})
		}
	case "credit":
		bal, dup, err := b.Store.EcoCredit(bot, in.UserID, in.Tokens, in.Ref, now)
		switch {
		case errors.Is(err, ErrEcoCredit):
			fail(http.StatusForbidden, err)
		case err != nil:
			fail(http.StatusBadRequest, err)
		default:
			reply(http.StatusOK, map[string]any{"ok": true, "balance": bal, "duplicate": dup})
		}
	default:
		fail(http.StatusNotFound, errors.New("есть balance, spend, credit"))
	}
}
