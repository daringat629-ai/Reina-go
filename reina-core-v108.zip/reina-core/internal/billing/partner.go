package billing

import (
	"context"
	"fmt"
	"sort"
	"strconv"
	"strings"
	"time"
)

// Partners: someone who runs bots in the ecosystem gets a login of their own. They see only their bots (what people spent through
// them, what was credited, their share) and nothing about other bots, people or the owner's money.

// SetPartner links a partner name to a Telegram id (id 0 removes the link).
func (s *Store) SetPartner(name string, id int64) {
	s.mu.Lock()
	defer s.mu.Unlock()
	name = strings.ToLower(strings.TrimSpace(name))
	if s.d.Partners == nil {
		s.d.Partners = map[string]int64{}
	}
	if id == 0 {
		delete(s.d.Partners, name)
	} else {
		s.d.Partners[name] = id
	}
	s.save()
}

// PartnerOf is the partner name behind a Telegram id ("" = not a partner).
func (s *Store) PartnerOf(id int64) string {
	s.mu.Lock()
	defer s.mu.Unlock()
	for n, v := range s.d.Partners {
		if v == id && id != 0 {
			return n
		}
	}
	return ""
}

// PartnersList is "name: id" lines for the owner.
func (s *Store) PartnersList() string {
	s.mu.Lock()
	defer s.mu.Unlock()
	var l []string
	for n, id := range s.d.Partners {
		l = append(l, fmt.Sprintf("%s: %d", n, id))
	}
	sort.Strings(l)
	return strings.Join(l, "\n")
}

// PartnerReport is what a partner may see: only the bots whose owner field is their name.
func (s *Store) PartnerReport(name string, now time.Time) string {
	s.mu.Lock()
	defer s.mu.Unlock()
	var ids []string
	for _, b := range s.d.Bots {
		if b.Owner == name {
			ids = append(ids, b.ID)
		}
	}
	sort.Strings(ids)
	if len(ids) == 0 {
		return "За тобой пока не закреплено ни одного бота."
	}
	month, prev := now.Format("2006-01"), now.AddDate(0, -1, 0).Format("2006-01")
	var sb strings.Builder
	sb.WriteString("Твои боты в Orvi (токены):\n")
	for _, id := range ids {
		share := 0
		for _, b := range s.d.Bots {
			if b.ID == id {
				share = b.Share
			}
		}
		t := s.d.BotTotals[id]
		if t == nil {
			t = &BotTotals{}
		}
		fmt.Fprintf(&sb, "\n%s: потрачено за всё время %s, в этом месяце %s, в прошлом %s, операций %d, твоя доля %d%%", id, Short(t.Spent), Short(t.ByMonth[month]), Short(t.ByMonth[prev]), t.Ops, share)
	}
	sb.WriteString("\n\nВыплаты по договорённости с Орви: считаются по потраченным токенам за месяц.")
	return sb.String()
}

// BotDetail is the numbers of one bot for the owner's bot switcher: its totals and the Stars and tokens its payments brought.
func (s *Store) BotDetail(id string, now time.Time) string {
	s.mu.Lock()
	defer s.mu.Unlock()
	t := s.d.BotTotals[id]
	var stars int
	var n int
	for _, p := range s.d.Payments {
		if p.Bot == id && !p.Refunded {
			stars += p.Stars
			n++
		}
	}
	if t == nil && n == 0 {
		return ""
	}
	if t == nil {
		t = &BotTotals{}
	}
	return fmt.Sprintf("🤖 %s\n\nПотрачено токенов: %s (в этом месяце %s)\nНачислено: %s\nОпераций: %d\nОплат через него: %d, ⭐ %d", id, Short(t.Spent), Short(t.ByMonth[now.Format("2006-01")]), Short(t.Credited), t.Ops, n, stars)
}

// BotIDs lists the ecosystem bots the owner can switch between.
func (s *Store) BotIDs() []string {
	s.mu.Lock()
	defer s.mu.Unlock()
	seen := map[string]bool{}
	for id := range s.d.BotTotals {
		seen[id] = true
	}
	for _, b := range s.d.Bots {
		seen[b.ID] = true
	}
	var out []string
	for id := range seen {
		out = append(out, id)
	}
	sort.Strings(out)
	return out
}

func (a *Admin) sayTo(ctx context.Context, chat int64, text string, markup any) {
	in := map[string]any{"chat_id": chat, "text": text}
	if markup != nil {
		in["reply_markup"] = markup
	}
	_ = a.client().call(ctx, "sendMessage", in, nil)
}

// partner answers someone who is not the owner but has a partner login. It is silent about everything else.
func (a *Admin) partner(ctx context.Context, name string, chat int64, text string) {
	switch strings.ToLower(strings.TrimSpace(text)) {
	case "/start", "/mine", "/stats":
		a.sayTo(ctx, chat, a.Store.PartnerReport(name, a.now()), nil)
	}
}

// botSwitcher shows the bots as buttons, or the numbers of one of them.
func (a *Admin) botSwitcher(ctx context.Context, arg string) {
	arg = strings.ToLower(strings.TrimSpace(arg))
	if arg != "" {
		if d := a.Store.BotDetail(arg, a.now()); d != "" {
			a.say(ctx, d+a.botButtons(), nil)
			return
		}
		a.say(ctx, "Такого бота нет. /bot без слов покажет список.", nil)
		return
	}
	ids := a.Store.BotIDs()
	if len(ids) == 0 {
		a.say(ctx, "Ботов экосистемы пока нет.", nil)
		return
	}
	a.say(ctx, "Выбери бота, чтобы увидеть только его цифры.", a.botKeyboard(ids))
}

func (a *Admin) botButtons() string { return "\n\n/bot — выбрать другого" }

func (a *Admin) botKeyboard(ids []string) any {
	var rows [][]map[string]any
	for _, id := range ids {
		rows = append(rows, []map[string]any{{"text": id, "callback_data": "bot:" + id}})
	}
	return map[string]any{"inline_keyboard": rows}
}

func parseTG(s string) (int64, bool) {
	n, err := strconv.ParseInt(strings.TrimSpace(s), 10, 64)
	return n, err == nil && n >= 0
}
