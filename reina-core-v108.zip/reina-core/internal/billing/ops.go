package billing

import (
	"bytes"
	"context"
	"encoding/csv"
	"fmt"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

// The owner's tools for running the money side: per-bot totals that are never trimmed (the ledger keeps only the last 5000
// operations, payouts need all of them), an audit log of what the owner did in the admin bot, CSV for the accountant and for
// payouts, and a broadcast with a confirmation step.

// BotTotals is what one ecosystem bot has spent from and credited to the shared balance, in all time and by month.
type BotTotals struct {
	Spent    int64            `json:"spent,omitempty"`    // tokens people spent through this bot
	Credited int64            `json:"credited,omitempty"` // tokens its site added (payments it took)
	Ops      int              `json:"ops,omitempty"`
	ByMonth  map[string]int64 `json:"by_month,omitempty"` // "2006-01" -> tokens spent
}

// AuditEntry is one thing the owner did.
type AuditEntry struct {
	At     time.Time `json:"at"`
	Action string    `json:"action"`
	Detail string    `json:"detail,omitempty"`
}

const maxAudit = 500

// countBot adds one ledger operation to the totals of its bot (s.mu held).
func (s *Store) countBot(t EcoTx) {
	if s.d.BotTotals == nil {
		s.d.BotTotals = map[string]*BotTotals{}
	}
	b := s.d.BotTotals[t.Bot]
	if b == nil {
		b = &BotTotals{}
		s.d.BotTotals[t.Bot] = b
	}
	b.Ops++
	if t.Tokens < 0 {
		b.Spent += -t.Tokens
		if b.ByMonth == nil {
			b.ByMonth = map[string]int64{}
		}
		b.ByMonth[t.At.Format("2006-01")] += -t.Tokens
	} else {
		b.Credited += t.Tokens
	}
}

// Audit records an action of the owner.
func (s *Store) Audit(now time.Time, action, detail string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if r := []rune(detail); len(r) > 200 {
		detail = string(r[:200])
	}
	s.d.Audit = append(s.d.Audit, AuditEntry{now, action, detail})
	if len(s.d.Audit) > maxAudit {
		s.d.Audit = append([]AuditEntry(nil), s.d.Audit[len(s.d.Audit)-maxAudit:]...)
	}
	s.save()
}

// AuditLast is the last n entries, newest first.
func (s *Store) AuditLast(n int) []AuditEntry {
	s.mu.Lock()
	defer s.mu.Unlock()
	var out []AuditEntry
	for i := len(s.d.Audit) - 1; i >= 0 && len(out) < n; i-- {
		out = append(out, s.d.Audit[i])
	}
	return out
}

// PaymentsCSV is every payment as CSV (for the accountant).
func (s *Store) PaymentsCSV(loc *time.Location) []byte {
	s.mu.Lock()
	defer s.mu.Unlock()
	var buf bytes.Buffer
	w := csv.NewWriter(&buf)
	_ = w.Write([]string{"date", "user_id", "kind", "bot", "plan", "stars", "som", "tokens", "days", "refunded", "charge"})
	for _, p := range s.d.Payments {
		bot := p.Bot
		if bot == "" {
			bot = "orvi"
		}
		_ = w.Write([]string{p.At.In(loc).Format("2006-01-02 15:04"), strconv.FormatInt(p.UserID, 10), p.Kind, bot, p.Plan,
			strconv.Itoa(p.Stars), strconv.Itoa(p.Som), strconv.FormatInt(p.Tokens, 10), strconv.Itoa(p.Days), strconv.FormatBool(p.Refunded), p.Charge})
	}
	w.Flush()
	return buf.Bytes()
}

// BotsCSV is what each ecosystem bot used in all time and in the given months, with the partner's share (for payouts).
func (s *Store) BotsCSV(months []string) []byte {
	s.mu.Lock()
	defer s.mu.Unlock()
	var buf bytes.Buffer
	w := csv.NewWriter(&buf)
	head := []string{"bot", "owner", "share_percent", "tokens_spent_total", "tokens_credited_total", "operations"}
	for _, m := range months {
		head = append(head, "spent_"+m)
	}
	_ = w.Write(head)
	ids := map[string]bool{}
	for id := range s.d.BotTotals {
		ids[id] = true
	}
	owners, shares := map[string]string{}, map[string]int{}
	for _, b := range s.d.Bots {
		ids[b.ID], owners[b.ID], shares[b.ID] = true, b.Owner, b.Share
	}
	var list []string
	for id := range ids {
		list = append(list, id)
	}
	sort.Strings(list)
	for _, id := range list {
		t := s.d.BotTotals[id]
		if t == nil {
			t = &BotTotals{}
		}
		row := []string{id, owners[id], strconv.Itoa(shares[id]), strconv.FormatInt(t.Spent, 10), strconv.FormatInt(t.Credited, 10), strconv.Itoa(t.Ops)}
		for _, m := range months {
			row = append(row, strconv.FormatInt(t.ByMonth[m], 10))
		}
		_ = w.Write(row)
	}
	w.Flush()
	return buf.Bytes()
}

// BotLines is a few lines per bot for the owner's /stats ("" if no bot has been used).
func (s *Store) BotLines() string {
	s.mu.Lock()
	defer s.mu.Unlock()
	var ids []string
	for id := range s.d.BotTotals {
		ids = append(ids, id)
	}
	sort.Strings(ids)
	var sb strings.Builder
	for _, id := range ids {
		t := s.d.BotTotals[id]
		fmt.Fprintf(&sb, "\n%s: потрачено %s, начислено %s, операций %d", id, Short(t.Spent), Short(t.Credited), t.Ops)
	}
	if sb.Len() == 0 {
		return ""
	}
	return "\n\nБоты экосистемы:" + sb.String()
}

// Recipients are the people the pay bot can write to (everyone it has a record of).
func (s *Store) Recipients() []int64 {
	s.mu.Lock()
	defer s.mu.Unlock()
	var out []int64
	for id := range s.d.Users {
		if id > 0 {
			out = append(out, id)
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i] < out[j] })
	return out
}

// broadcast is a message the owner prepared and has not yet confirmed.
type broadcast struct {
	mu   sync.Mutex
	text string
	at   time.Time
}

const broadcastWait = 10 * time.Minute

func (a *Admin) prepareBroadcast(ctx context.Context, text string) {
	text = strings.TrimSpace(text)
	if r := []rune(text); len(r) < 3 || len(r) > 1500 {
		a.say(ctx, "Формат: /broadcast текст (от 3 до 1500 символов). Потом /broadcast_yes отправит всем, /broadcast_no отменит.", nil)
		return
	}
	a.bc.mu.Lock()
	a.bc.text, a.bc.at = text, a.now()
	a.bc.mu.Unlock()
	a.say(ctx, fmt.Sprintf("Получателей: %d. Вот текст:\n\n%s\n\nОтправить: /broadcast_yes (в течение 10 минут). Отменить: /broadcast_no.", len(a.Store.Recipients()), text), nil)
}

func (a *Admin) confirmBroadcast(ctx context.Context, yes bool) {
	a.bc.mu.Lock()
	text, at := a.bc.text, a.bc.at
	a.bc.text = ""
	a.bc.mu.Unlock()
	if text == "" || a.now().Sub(at) > broadcastWait {
		a.say(ctx, "Нет подготовленной рассылки (или прошло больше 10 минут). Начни с /broadcast текст.", nil)
		return
	}
	if !yes {
		a.say(ctx, "Рассылка отменена.", nil)
		return
	}
	if a.Pay == nil {
		a.say(ctx, "Платёжный бот не подключён.", nil)
		return
	}
	ids := a.Store.Recipients()
	a.Store.Audit(a.now(), "broadcast", fmt.Sprintf("%d получателей: %s", len(ids), text))
	a.say(ctx, fmt.Sprintf("Отправляю %d людям, около %d сек.", len(ids), len(ids)/20+1), nil)
	go func() {
		sent := 0
		for _, id := range ids {
			if ctx.Err() != nil {
				break
			}
			if a.Pay.trySend(ctx, id, text) {
				sent++
			}
			time.Sleep(50 * time.Millisecond) // 20 per second: well under Telegram's limit
		}
		a.say(ctx, fmt.Sprintf("Рассылка закончена: дошло %d из %d.", sent, len(ids)), nil)
	}()
}

func (a *Admin) sendCSV(ctx context.Context) {
	loc := a.loc()
	now := a.now()
	months := []string{now.AddDate(0, -2, 0).Format("2006-01"), now.AddDate(0, -1, 0).Format("2006-01"), now.Format("2006-01")}
	cl := a.client()
	for _, f := range []struct {
		name string
		data []byte
	}{{"payments.csv", a.Store.PaymentsCSV(loc)}, {"bots.csv", a.Store.BotsCSV(months)}} {
		if err := cl.sendDocument(ctx, a.Owner(), f.name, f.data, ""); err != nil {
			a.say(ctx, "Не вышло отправить "+f.name+": "+err.Error(), nil)
			return
		}
	}
}

func (a *Admin) showAudit(ctx context.Context) {
	list := a.Store.AuditLast(20)
	if len(list) == 0 {
		a.say(ctx, "Журнал пуст.", nil)
		return
	}
	var sb strings.Builder
	sb.WriteString("Журнал действий (последние):\n")
	for _, e := range list {
		fmt.Fprintf(&sb, "\n%s · %s %s", e.At.In(a.loc()).Format("02.01 15:04"), e.Action, e.Detail)
	}
	a.say(ctx, sb.String(), nil)
}

// auditable are the owner's commands that change something; the command and its arguments go to the log (never a key: /botkey logs only the id).
var auditable = map[string]bool{"/give": true, "/addbot": true, "/delbot": true, "/botoff": true, "/boton": true, "/botkey": true, "/botcredit": true, "/update": true}

func (a *Admin) auditCommand(text string) {
	f := strings.Fields(text)
	if len(f) == 0 || !auditable[f[0]] {
		return
	}
	if f[0] == "/botkey" && len(f) > 2 {
		f = f[:2]
	}
	a.Store.Audit(a.now(), f[0], strings.Join(f[1:], " "))
}

// sendDocument sends a file to a chat.
func (b *Bot) sendDocument(ctx context.Context, chat int64, name string, data []byte, caption string) error {
	fields := map[string]string{"chat_id": fmt.Sprint(chat)}
	if caption != "" {
		fields["caption"] = caption
	}
	return b.form(ctx, "sendDocument", fields, map[string]formFile{"document": {name, data}}, nil)
}

// trySend sends text with the menu and says whether it arrived (people who blocked the bot do not count).
func (b *Bot) trySend(ctx context.Context, chat int64, text string) bool {
	return b.call(ctx, "sendMessage", map[string]any{"chat_id": chat, "text": text, "reply_markup": b.menu()}, nil) == nil
}
