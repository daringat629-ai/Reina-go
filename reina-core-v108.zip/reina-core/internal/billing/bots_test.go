package billing

import (
	"context"
	"fmt"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestEcoBots(t *testing.T) {
	s := Open(filepath.Join(t.TempDir(), "b.json"))
	now := time.Now()
	b, err := ParseAddBot("sperma_one spermadev @SpermaOneBot Sperma One | тестовый бот")
	if err != nil || b.About != " тестовый бот" && b.About != "тестовый бот" {
		t.Fatalf("parse: %+v %v", b, err)
	}
	if err := s.AddEcoBot(b, now); err != nil {
		t.Fatal(err)
	}
	got, ok := s.EcoBotByID("SPERMA_ONE")
	if !ok || got.Username != "SpermaOneBot" || got.Kind != "character" || got.About != "тестовый бот" {
		t.Fatalf("stored: %+v %v", got, ok)
	}
	// repeat replaces, keeps the order and the added time
	b.Name = "Sperma 1"
	if err := s.AddEcoBot(b, now.Add(time.Hour)); err != nil || len(s.Ecosystem()) != 1 {
		t.Fatalf("replace: %v %d", err, len(s.Ecosystem()))
	}
	if g, _ := s.EcoBotByID("sperma_one"); g.Name != "Sperma 1" || !g.Added.Equal(now) {
		t.Fatalf("replace kept: %+v", g)
	}
	if !s.SetEcoBotOff("sperma_one", true) {
		t.Fatal("off")
	}
	if g, _ := s.EcoBotByID("sperma_one"); !g.Off {
		t.Fatal("not off")
	}
	// survives a reload
	s2 := Open(s.path)
	if len(s2.Ecosystem()) != 1 {
		t.Fatal("not saved")
	}
	if !s.DelEcoBot("sperma_one") || s.DelEcoBot("sperma_one") {
		t.Fatal("delete")
	}
}

func TestEcoBotsRejects(t *testing.T) {
	s := Open(filepath.Join(t.TempDir(), "b.json"))
	for _, c := range []EcoBot{
		{ID: "reina", Owner: "orvi", Username: "SomeBot", Name: "x"},
		{ID: "Bad Id", Owner: "orvi", Username: "SomeBot", Name: "x"},
		{ID: "ok_id", Owner: "orvi", Username: "ab", Name: "x"},
		{ID: "ok_id", Owner: "orvi", Username: "SomeBot", Name: ""},
		{ID: "ok_id", Owner: "", Username: "SomeBot", Name: "x"},
		{ID: "ok_id", Owner: "orvi", Username: "SomeBot", Name: "x", Share: 95},
		{ID: "ok_id", Owner: "orvi", Username: "SomeBot", Name: "x", Kind: "weird"},
	} {
		if err := s.AddEcoBot(c, time.Now()); err == nil {
			t.Errorf("accepted %+v", c)
		}
	}
	if _, err := ParseAddBot("only two"); err == nil {
		t.Error("short command accepted")
	}
}

func TestEcosystemInTheAppsAndTheCatalogue(t *testing.T) {
	srv, calls := fakeAPI(t)
	st := Open(filepath.Join(t.TempDir(), "b.json"))
	pay := newBot(srv, st)
	pay.Her = func() string { return "@ReinaVeil" }
	adm := &Admin{Token: "A", BaseURL: srv.URL, Store: st, Pay: pay, Owner: func() int64 { return 1 }, Now: func() time.Time { return t0 }, Loc: time.UTC}
	own := adm.WebApp()
	owner := signInit("A", `{"id":1}`, t0)
	stranger := signInit("A", `{"id":7}`, t0)

	if w := postJSON(own, "/app/admin/api/ecosystem/save", `{"id":"sp1","name":"Sperma One","username":"@SpermaOneBot","owner":"spermadev","share":30,"about":"тест"}`, stranger); w.Code == 200 {
		t.Fatal("only the owner manages the list")
	}
	if w := postJSON(own, "/app/admin/api/ecosystem/save", `{"id":"sp1","name":"Sperma One","username":"@SpermaOneBot","owner":"spermadev","share":30,"about":"тест"}`, owner); w.Code != 200 {
		t.Fatalf("save: %d %s", w.Code, w.Body.String())
	}
	if w := postJSON(own, "/app/admin/api/ecosystem/save", `{"id":"reina","name":"x","username":"SomeBot","owner":"orvi"}`, owner); w.Code == 200 {
		t.Fatal("reina is not a list item")
	}
	if w := postJSON(own, "/app/admin/api/ecosystem", `{}`, owner); !strings.Contains(w.Body.String(), "SpermaOneBot") {
		t.Fatalf("list: %s", w.Body.String())
	}

	pay.handle(context.Background(), msg(t, `{"update_id":1,"message":{"from":{"id":7},"chat":{"id":7},"text":"🤖 Боты"}}`))
	waitCalls(t, calls, "sendMessage", 1)
	got := fmt.Sprint(calls("sendMessage")[0])
	for _, want := range []string{"Рейна", "Sperma One", "https://t.me/SpermaOneBot", "https://t.me/ReinaVeil"} {
		if !strings.Contains(got, want) {
			t.Fatalf("catalogue is missing %q: %s", want, got)
		}
	}

	if w := postJSON(own, "/app/admin/api/ecosystem/off", `{"id":"sp1","off":true}`, owner); w.Code != 200 {
		t.Fatal("hide")
	}
	pay.handle(context.Background(), msg(t, `{"update_id":2,"message":{"from":{"id":8},"chat":{"id":8},"text":"/bots"}}`))
	waitCalls(t, calls, "sendMessage", 2)
	if strings.Contains(fmt.Sprint(calls("sendMessage")[1]), "SpermaOneBot") {
		t.Fatal("a hidden bot is not shown to people")
	}
}
