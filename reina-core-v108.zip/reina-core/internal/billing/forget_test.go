package billing

import (
	"context"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestAgeGateHoldsEverythingUntilConfirmedAndKeepsTheLink(t *testing.T) {
	ageGateOn = true
	defer func() { ageGateOn = false }()
	srv, calls := fakeAPI(t)
	st := Open(filepath.Join(t.TempDir(), "b.json"))
	b := newBot(srv, st)
	ctx := context.Background()
	b.handle(ctx, msg(t, `{"update_id":1,"message":{"from":{"id":5},"chat":{"id":5},"text":"/start ref77"}}`))
	if st.IsAdult(5) || len(calls("sendMessage")) != 1 {
		t.Fatal("only the question is sent, nothing is confirmed")
	}
	if b.pend[5] != "ref77" {
		t.Fatalf("the link waits for the confirmation: %v", b.pend)
	}
	b.handle(ctx, msg(t, `{"update_id":2,"callback_query":{"id":"c","from":{"id":5},"data":"adult:yes","message":{"chat":{"id":5}}}}`))
	if !st.IsAdult(5) || b.pend[5] != "" {
		t.Fatal("confirmed, and the waiting link was used")
	}
}

func TestForgetErasesTheProfileKeepsPaymentsWithoutTheLink(t *testing.T) {
	st := Open(t.TempDir() + "/b.json")
	now := time.Now()
	st.Activate(9, Plus, 7, 20, "ch1", now)
	st.mu.Lock()
	st.user(9).Tokens = 700
	st.mu.Unlock()
	left := st.Forget(9)
	if left != 700 {
		t.Fatalf("burnt tokens: %d", left)
	}
	if st.IsAdult(9) || st.Get(9, now).Tokens != 0 {
		t.Fatal("the profile is gone")
	}
	_, pays := st.All(now)
	if len(pays) != 1 || pays[0].UserID != 0 || strings.TrimSpace(pays[0].Charge) == "" {
		t.Fatalf("the accounting record stays, unlinked: %+v", pays)
	}
	if _, _, ok := st.Refund("ch1", now); !ok {
		t.Fatal("a refund of an unlinked payment is still recorded")
	}
	if _, ok := st.d.Users[0]; ok {
		t.Fatal("no phantom user 0")
	}
}
