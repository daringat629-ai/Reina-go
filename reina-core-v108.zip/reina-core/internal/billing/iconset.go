package billing

import (
	"bytes"
	"context"
	"embed"
	"encoding/json"
	"errors"
	"fmt"
	"mime/multipart"
	"net/http"
	"strings"
	"time"
)

// Vector icons for the buttons. Telegram has no pictures in buttons except custom emoji, and those work for a bot whose owner has
// Premium. So the owner runs /icons in the admin bot: it draws no emoji, it uploads the line icons below (iconpng, white strokes
// on a transparent ground, made from the same 24×24 line art as the cards) as a custom emoji set that Telegram repaints in the text
// colour, and remembers the id of each icon. Until that is done (or without Premium) the buttons keep their ordinary emoji.

//go:embed iconpng/*.png
var iconFS embed.FS

// iconList is every icon, in the order of the set, with the ordinary emoji it replaces (Telegram wants one emoji per sticker).
var iconList = []struct{ key, emoji string }{
	{"topup", "💳"}, {"profile", "👤"}, {"reina", "🌙"}, {"gift", "🎁"}, {"friends", "🤝"}, {"help", "💬"}, {"bots", "🤖"}, {"worlds", "🌍"},
	{"stats", "📊"}, {"requests", "🧾"}, {"people", "👥"}, {"qr", "🖼"}, {"history", "📜"}, {"bell", "🔔"}, {"bellmute", "🔕"}, {"check", "✅"}, {"cross", "❌"}, {"play", "▶"}, {"stop", "⏹"}, {"star", "⭐"},
}

// IconID is the custom emoji id of an icon ("" = not made yet).
func (s *Store) IconID(key string) string {
	if s == nil {
		return ""
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.d.Icons[key]
}

// SetIcons replaces the remembered icon ids.
func (s *Store) SetIcons(m map[string]string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.d.Icons = m
	s.save()
}

// Btn makes a button: with the icon of key it is the vector icon and the bare label, without it the ordinary emoji and the label.
func (s *Store) Btn(key, emoji, label string, extra map[string]any) map[string]any {
	m := map[string]any{}
	for k, v := range extra {
		m[k] = v
	}
	if id := s.IconID(key); id != "" {
		m["text"], m["icon_custom_emoji_id"] = label, id
	} else if emoji != "" {
		m["text"] = emoji + " " + label
	} else {
		m["text"] = label
	}
	return m
}

// form sends a multipart request to the Bot API (the token never goes into an error text).
// formFile is a file part of a multipart request.
type formFile struct {
	name string
	data []byte
}

func (b *Bot) form(ctx context.Context, method string, fields map[string]string, files map[string]formFile, out any) error {
	var body bytes.Buffer
	w := multipart.NewWriter(&body)
	for k, v := range fields {
		_ = w.WriteField(k, v)
	}
	for k, v := range files {
		fw, _ := w.CreateFormFile(k, v.name)
		_, _ = fw.Write(v.data)
	}
	_ = w.Close()
	base := b.BaseURL
	if base == "" {
		base = "https://api.telegram.org"
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, base+"/bot"+b.tok()+"/"+method, &body)
	if err != nil {
		return fmt.Errorf("billing bot: %s: bad request (check the bot token in the config)", method)
	}
	req.Header.Set("Content-Type", w.FormDataContentType())
	hc := b.HTTP
	if hc == nil {
		hc = &http.Client{Timeout: 70 * time.Second}
	}
	resp, err := hc.Do(req)
	if err != nil {
		return fmt.Errorf("billing bot: %s: %w", method, unwrapped(err))
	}
	defer resp.Body.Close()
	var r struct {
		OK          bool            `json:"ok"`
		Result      json.RawMessage `json:"result"`
		Description string          `json:"description"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&r); err != nil {
		return fmt.Errorf("billing bot: %s: bad answer", method)
	}
	if !r.OK {
		return fmt.Errorf("billing bot: %s: %s", method, r.Description)
	}
	if out != nil {
		return json.Unmarshal(r.Result, out)
	}
	return nil
}

// MakeIcons uploads the icons as a custom emoji set owned by this bot (for the Premium user owner), reads the ids and remembers them.
// A set from an earlier run is deleted first, so running it again after a change replaces the icons.
func (b *Bot) MakeIcons(ctx context.Context, owner int64) (int, error) {
	var me struct {
		Username string `json:"username"`
	}
	if err := b.call(ctx, "getMe", map[string]any{}, &me); err != nil || me.Username == "" {
		return 0, errors.New("не удалось узнать имя бота")
	}
	name := "orvi_icons_by_" + strings.ToLower(me.Username)
	_ = b.call(ctx, "deleteStickerSet", map[string]any{"name": name}, nil) // none yet is fine
	type sticker struct {
		Sticker   string   `json:"sticker"`
		Format    string   `json:"format"`
		EmojiList []string `json:"emoji_list"`
	}
	var list []sticker
	files := map[string]formFile{}
	for i, ic := range iconList {
		png, err := iconFS.ReadFile("iconpng/" + ic.key + ".png")
		if err != nil {
			return 0, err
		}
		f := fmt.Sprintf("s%d", i)
		files[f] = formFile{f + ".png", png}
		list = append(list, sticker{"attach://" + f, "static", []string{ic.emoji}})
	}
	js, _ := json.Marshal(list)
	err := b.form(ctx, "createNewStickerSet", map[string]string{
		"user_id": fmt.Sprint(owner), "name": name, "title": "Orvi icons", "sticker_type": "custom_emoji",
		"needs_repainting": "true", "stickers": string(js),
	}, files, nil)
	if err != nil {
		return 0, err
	}
	var set struct {
		Stickers []struct {
			ID string `json:"custom_emoji_id"`
		} `json:"stickers"`
	}
	if err := b.call(ctx, "getStickerSet", map[string]any{"name": name}, &set); err != nil {
		return 0, err
	}
	if len(set.Stickers) != len(iconList) {
		return 0, fmt.Errorf("в наборе %d иконок вместо %d", len(set.Stickers), len(iconList))
	}
	ids := map[string]string{}
	for i, st := range set.Stickers {
		if st.ID == "" {
			return 0, errors.New("Telegram не дал id иконки")
		}
		ids[iconList[i].key] = st.ID
	}
	b.Store.SetIcons(ids)
	return len(ids), nil
}
