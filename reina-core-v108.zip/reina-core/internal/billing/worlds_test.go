package billing

import (
	"context"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestWorldAddrRules(t *testing.T) {
	for _, bad := range []string{"localhost", "127.0.0.1", "10.0.0.5", "192.168.1.2", "169.254.169.254", "0.0.0.0", "::1", "box.local", "svc.internal", "nodots", "a b.com"} {
		if CheckWorldAddr(bad, 25565) == nil {
			t.Errorf("%q must be refused", bad)
		}
	}
	for _, ok := range []string{"play.example.com", "8.8.8.8"} {
		if err := CheckWorldAddr(ok, 25565); err != nil {
			t.Errorf("%q: %v", ok, err)
		}
	}
	if CheckWorldAddr("play.example.com", 80) == nil || CheckWorldAddr("play.example.com", 70000) == nil {
		t.Error("ports out of range must be refused")
	}
}

func TestWorldsAreYoursAlone(t *testing.T) {
	s := Open(filepath.Join(t.TempDir(), "b.json"))
	now := time.Now()
	w, err := s.AddWorld(1, "", "Play.Example.com", 25565, now)
	if err != nil || w.Name != "Мой мир" || w.Host != "play.example.com" {
		t.Fatalf("%+v %v", w, err)
	}
	if _, err := s.AddWorld(1, "x", "play.example.com", 25565, now); err == nil {
		t.Fatal("duplicate")
	}
	s.AddWorld(1, "b", "b.example.com", 25565, now)
	s.AddWorld(1, "c", "c.example.com", 25565, now)
	if _, err := s.AddWorld(1, "d", "d.example.com", 25565, now); err == nil {
		t.Fatal("limit per person")
	}
	if s.DelWorld(2, w.ID) {
		t.Fatal("someone else removed my world")
	}
	if !s.DelWorld(1, w.ID) || len(s.WorldsOf(1)) != 2 {
		t.Fatal("own removal")
	}
	s2 := Open(s.path)
	if len(s2.WorldsOf(1)) != 2 {
		t.Fatal("not kept after reload")
	}
	h, p, n, err := ParseWorld("play.example.com Моя база")
	if err != nil || h != "play.example.com" || p != 25565 || n != "Моя база" {
		t.Fatalf("%s %d %s %v", h, p, n, err)
	}
	if _, _, _, err := ParseWorld("play.example.com:abc"); err == nil {
		t.Fatal("bad port")
	}
}

func TestVisitFeeIsTakenAndReturned(t *testing.T) {
	s := Open(filepath.Join(t.TempDir(), "b.json"))
	now := time.Now()
	if err := s.TakeTokens(5, 100); err == nil {
		t.Fatal("a stranger has no balance")
	}
	s.AddTokens(5, 1000, 0, 0, "x1", "pack", now)
	if err := s.TakeTokens(5, 400); err != nil || s.Get(5, now).Tokens != 600 {
		t.Fatalf("take: %v %d", err, s.Get(5, now).Tokens)
	}
	if s.TakeTokens(5, 601) == nil {
		t.Fatal("more than the balance")
	}
	s.GiveBackTokens(5, 400)
	if u := s.Get(5, now); u.Tokens != 1000 || u.Spent != 0 {
		t.Fatalf("give back: %+v", u)
	}
}

func TestIconsMakeAndUseThem(t *testing.T) {
	var made, sets int
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case strings.HasSuffix(r.URL.Path, "/getMe"):
			_, _ = w.Write([]byte(`{"ok":true,"result":{"username":"OrviPayBot"}}`))
		case strings.HasSuffix(r.URL.Path, "/deleteStickerSet"):
			_, _ = w.Write([]byte(`{"ok":false,"description":"not found"}`))
		case strings.HasSuffix(r.URL.Path, "/createNewStickerSet"):
			if err := r.ParseMultipartForm(1 << 20); err != nil {
				t.Errorf("not multipart: %v", err)
			}
			if r.FormValue("name") != "orvi_icons_by_orvipaybot" || r.FormValue("sticker_type") != "custom_emoji" || r.FormValue("needs_repainting") != "true" || r.FormValue("user_id") != "42" {
				t.Errorf("bad set fields: %v", r.MultipartForm.Value)
			}
			made = len(r.MultipartForm.File)
			_, _ = w.Write([]byte(`{"ok":true,"result":true}`))
		case strings.HasSuffix(r.URL.Path, "/getStickerSet"):
			sets++
			var sb strings.Builder
			sb.WriteString(`{"ok":true,"result":{"stickers":[`)
			for i := range iconList {
				if i > 0 {
					sb.WriteString(",")
				}
				fmt.Fprintf(&sb, `{"custom_emoji_id":"id%d"}`, i)
			}
			sb.WriteString(`]}}`)
			_, _ = w.Write([]byte(sb.String()))
		default:
			_, _ = w.Write([]byte(`{"ok":true,"result":true}`))
		}
	}))
	defer ts.Close()
	st := Open(filepath.Join(t.TempDir(), "b.json"))
	b := &Bot{Token: "x", BaseURL: ts.URL, Store: st}
	m := b.menu()["keyboard"].([][]map[string]any)
	if m[0][0]["text"] != "💳 Пополнить" || m[0][0]["icon_custom_emoji_id"] != nil {
		t.Fatalf("before the icons the emoji stays: %v", m[0][0])
	}
	n, err := b.MakeIcons(context.Background(), 42)
	if err != nil || n != len(iconList) || made != len(iconList) || sets != 1 {
		t.Fatalf("n=%d err=%v made=%d", n, err, made)
	}
	m = b.menu()["keyboard"].([][]map[string]any)
	if m[0][0]["text"] != "Пополнить" || m[0][0]["icon_custom_emoji_id"] != "id0" || m[0][0]["style"] != "primary" {
		t.Fatalf("icon not used: %v", m[0][0])
	}
	a := &Admin{Store: st}
	am := a.menu()["keyboard"].([][]map[string]any)
	if am[0][0]["text"] != "Статистика" || am[0][0]["icon_custom_emoji_id"] != "id8" || am[1][1]["text"] != "Мой QR" {
		t.Fatalf("admin menu: %v", am)
	}
	if adminBare["Статистика"] != aStats || adminBare["Мой QR"] != aQR {
		t.Fatal("bare labels not understood")
	}
	if (*Store)(nil).Btn("x", "🔔", "Т", nil)["text"] != "🔔 Т" {
		t.Fatal("no store: emoji expected")
	}
}

func TestBotTotalsAuditCSVAndBroadcast(t *testing.T) {
	var sent []string
	var docs int
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case strings.HasSuffix(r.URL.Path, "/sendDocument"):
			docs++
		case strings.HasSuffix(r.URL.Path, "/sendMessage"):
			b, _ := io.ReadAll(r.Body)
			sent = append(sent, string(b))
		}
		_, _ = w.Write([]byte(`{"ok":true,"result":true}`))
	}))
	defer ts.Close()
	now := time.Date(2026, 11, 5, 12, 0, 0, 0, time.UTC)
	st := Open(filepath.Join(t.TempDir(), "b.json"))
	st.AddTokens(7, 1000, 10, 0, "c1", "pack", now)
	bot := EcoBot{ID: "spermabot", Owner: "spermadev", Share: 30, Credit: true}
	if _, _, err := st.EcoSpend(bot, 7, 400, "ref-1", now); err != nil {
		t.Fatal(err)
	}
	if _, _, err := st.EcoCredit(bot, 8, 500, "ref-2", now); err != nil {
		t.Fatal(err)
	}
	st.mu.Lock()
	st.d.Bots = append(st.d.Bots, bot)
	bot.Owner, bot.Share = "spermadev", 30
	st.d.Bots[0] = bot
	for i := 0; i < maxLedger+10; i++ { // the ledger is trimmed, the totals are not
		st.note(EcoTx{At: now, Bot: "spermabot", UserID: 8, Tokens: 1, Ref: fmt.Sprintf("many-%d", i)})
	}
	if len(st.d.Ledger) != maxLedger {
		t.Fatalf("ledger not trimmed: %d", len(st.d.Ledger))
	}
	st.mu.Unlock()
	if t0 := st.d.BotTotals["spermabot"]; t0.Spent != 400 || t0.Ops != 2+maxLedger+10 || t0.ByMonth["2026-11"] != 400 {
		t.Fatalf("totals: %+v", t0)
	}
	csvB := string(st.BotsCSV([]string{"2026-11"}))
	if !strings.Contains(csvB, "spermabot,spermadev,30,400,") || !strings.Contains(csvB, "spent_2026-11") {
		t.Fatalf("bots csv: %s", csvB)
	}
	if p := string(st.PaymentsCSV(time.UTC)); !strings.Contains(p, "eco,spermabot") || !strings.Contains(p, "pack,orvi") {
		t.Fatalf("payments csv: %s", p[:200])
	}
	pay := &Bot{Token: "x", BaseURL: ts.URL, Store: st}
	a := &Admin{Token: "y", BaseURL: ts.URL, Store: st, Pay: pay, Owner: func() int64 { return 1 }, Now: func() time.Time { return now }}
	a.command(context.Background(), "/give 7 100")
	a.command(context.Background(), "/botkey spermabot extra-secret")
	log := st.AuditLast(5)
	if len(log) != 2 || log[0].Action != "/botkey" || strings.Contains(log[0].Detail, "extra-secret") || log[1].Detail != "7 100" {
		t.Fatalf("audit: %+v", log)
	}
	a.command(context.Background(), "/csv")
	if docs != 2 {
		t.Fatalf("csv documents sent: %d", docs)
	}
	sent = nil
	a.command(context.Background(), "/broadcast_yes")
	if len(sent) != 1 || !strings.Contains(sent[0], "Нет подготовленной") {
		t.Fatalf("yes without a draft must do nothing: %v", sent)
	}
	a.command(context.Background(), "/broadcast Привет, это проверка")
	sent = nil
	a.command(context.Background(), "/broadcast_no")
	a.command(context.Background(), "/broadcast_yes")
	if !strings.Contains(strings.Join(sent, " "), "Нет подготовленной") {
		t.Fatalf("a cancelled broadcast must not be sent: %v", sent)
	}
}
