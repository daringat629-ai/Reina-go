// Package billing is what people other than the owner pay for. Everyone gets a number of free conversations a day (one conversation =
// one time she answers a batch of new messages in a chat). Beyond that a person spends tokens from a balance they top up in a small
// separate bot (Telegram Stars or a bank QR): every model request in their chat takes its real cost, counted in tokens of the main
// model, so a pack always costs more than it costs to serve. The old day plans (Plus, Max) are no longer sold; a plan someone already
// paid for keeps its daily limit until it ends. The owner is never limited and never billed.
package billing

import (
	"errors"
	"fmt"
	"sort"
	"sync"
	"time"

	"orvi/internal/store"
)

// Plans.
const (
	Free = "start"
	Plus = "plus"
	Max  = "max"
)

// Merge: conversations this close to the previous counted one are counted as the same one (spam taps, a burst of messages).
const Merge = 20 * time.Second

// Limits are the daily conversation limits per plan (0 = no cap).
type Limits struct {
	Free, Plus, Max int
	FreeTokens      int64 // on Start, the free conversations also stop once this many tokens are spent in a day (0 = no token cap)
	GlobalFree      int   // free conversations per day across ALL free accounts (0 = no global cap)
}

func (l Limits) of(plan string) int {
	switch plan {
	case Plus:
		return l.Plus
	case Max:
		return l.Max
	}
	return l.Free
}

// User is one person's account.
type User struct {
	ID       int64     `json:"id"`
	Plan     string    `json:"plan"`
	Until    time.Time `json:"until,omitempty"`
	Day      string    `json:"day"`
	Used     int       `json:"used"`
	Told     string    `json:"told,omitempty"` // the day she last said that the limit is over (said once a day)
	Joined   time.Time `json:"joined,omitempty"`
	Referrer int64     `json:"referrer,omitempty"` // who invited this person (0 = nobody)
	Paid     int       `json:"paid,omitempty"`     // how many payments
	Total    int       `json:"total,omitempty"`    // conversations in all time
	Last     time.Time `json:"last,omitempty"`     // when a conversation was last counted
	Reminded time.Time `json:"reminded,omitempty"` // the end date we already reminded about

	Tokens    int64  `json:"tokens,omitempty"`     // balance: tokens of the main model they can still spend (may dip a little below 0 at the end of a conversation)
	Spent     int64  `json:"spent,omitempty"`      // tokens taken from the balance in all time
	AllTokens int64  `json:"all_tokens,omitempty"` // tokens all their conversations cost, free ones included
	DayTokens int64  `json:"day_tokens,omitempty"` // tokens their conversations cost today
	PaidToday int    `json:"paid_today,omitempty"` // conversations paid from the balance today
	Charging  bool   `json:"charging,omitempty"`   // the current conversation is paid from the balance
	Watch     bool   `json:"watch,omitempty"`      // wants a message when she comes online
	Promo     string `json:"promo,omitempty"`      // the first promo code they used (where they came from)
	Adult     bool   `json:"adult,omitempty"`      // confirmed that they are 18 or older
}

// Payment is one successful payment, kept so that the same charge is never counted twice.
type Payment struct {
	At       time.Time `json:"at"`
	UserID   int64     `json:"user_id"`
	Plan     string    `json:"plan"`
	Stars    int       `json:"stars"`
	Charge   string    `json:"charge"`
	Days     int       `json:"days"`
	Som      int       `json:"som,omitempty"` // paid by QR, in som
	Tokens   int64     `json:"tokens,omitempty"`
	Refunded bool      `json:"refunded,omitempty"` // Stars were returned: what this payment gave has been taken back
	Bot      string    `json:"bot,omitempty"`      // the ecosystem bot that took this payment ("" = the Orvi pay bot)
	Kind     string    `json:"kind,omitempty"`     // "" = an old day plan, pack, qr (a pack paid by QR), gift (bought for someone), gift_in (a gift received), bonus
}

type data struct {
	Users      map[int64]*User       `json:"users"`
	Payments   []Payment             `json:"payments"`
	Requests   []Request             `json:"requests,omitempty"`
	NextReq    int                   `json:"next_req,omitempty"`
	Gifts      []Gift                `json:"gifts,omitempty"`
	Promos     []Promo               `json:"promos,omitempty"`
	ConvN      int64                 `json:"conv_n,omitempty"`      // conversations counted in all time
	GlobalDay  string                `json:"global_day,omitempty"`  // the day GlobalUsed counts
	GlobalUsed int                   `json:"global_used,omitempty"` // free conversations of free accounts counted that day
	ConvSum    int64                 `json:"conv_sum,omitempty"`    // tokens they cost in all time (for the "≈ N messages" estimate)
	Worlds     []World               `json:"worlds,omitempty"`      // game servers people connected their bots to
	Ledger     []EcoTx               `json:"ledger,omitempty"`      // the last operations of the ecosystem bots on the shared balance
	BotTotals  map[string]*BotTotals `json:"bot_totals,omitempty"`  // what each ecosystem bot used, never trimmed (ops.go)
	Partners   map[string]int64      `json:"partners,omitempty"`    // partner name (the bot owner field) -> Telegram id that may look at their own bots
	Audit      []AuditEntry          `json:"audit,omitempty"`       // what the owner did in the admin bot
	Icons      map[string]string     `json:"icons,omitempty"`       // custom emoji ids of the vector button icons (see iconset.go)
	Bots       []EcoBot              `json:"bots,omitempty"`        // the other bots of the ecosystem shown in the pay bot
}

// Request is a QR payment someone is making: they transfer Som with Code in the comment and send a receipt; the owner confirms.
type Request struct {
	ID      int       `json:"id"`
	UserID  int64     `json:"user_id"`
	Name    string    `json:"name,omitempty"`
	Plan    string    `json:"plan"`
	Days    int       `json:"days"`
	Som     int       `json:"som"`
	Tokens  int64     `json:"tokens,omitempty"` // a token pack (0 = an old day plan request)
	Code    string    `json:"code"`
	At      time.Time `json:"at"`
	Status  string    `json:"status"` // waiting (for a receipt), sent (receipt is with the owner), ok, no
	Decided time.Time `json:"decided,omitempty"`
}

// Store keeps accounts in one JSON file. Safe for concurrent use.
type Store struct {
	mu    sync.Mutex
	path  string
	saver store.Saver
	d     data

	codeFails guard // wrong promo/gift codes, in memory
	ecoRate   guard // requests per bot key and wrong keys per address, in memory
}

// Open loads the accounts (or starts empty).
func Open(path string) *Store {
	s := &Store{path: path, saver: store.Saver{What: "billing"}}
	store.Load("billing", path, &s.d)
	if s.d.Users == nil {
		s.d.Users = map[int64]*User{}
	}
	return s
}

func (s *Store) save() { _ = s.saver.Save(s.path, s.d) }

func (s *Store) user(id int64) *User {
	u := s.d.Users[id]
	if u == nil {
		u = &User{ID: id, Plan: Free, Joined: time.Now()}
		s.d.Users[id] = u
	}
	return u
}

// planAt is the plan in force at now (a paid plan that ran out falls back to Start).
func planAt(u *User, now time.Time) string {
	if u.Plan != Free && now.Before(u.Until) {
		return u.Plan
	}
	return Free
}

// Decision is the answer to "may she answer this person now".
type Decision struct {
	OK          bool
	Plan        string
	Left        int   // free conversations left today after this one (-1 = no cap)
	TellOnce    bool  // nothing is left and she has not said so today yet
	FromBalance bool  // this conversation is paid from the token balance
	Balance     int64 // tokens on the balance
}

// Take counts one conversation for the person and says whether it is allowed. The day's free conversations go first (or the daily
// limit of an old paid plan); after them the conversation is paid from the token balance; with neither, she does not answer.
func (s *Store) Take(id int64, now time.Time, l Limits) Decision {
	s.mu.Lock()
	defer s.mu.Unlock()
	u := s.user(id)
	day := now.Format("2006-01-02")
	if u.Day != day {
		u.Day, u.Used, u.DayTokens, u.PaidToday = day, 0, 0, 0
	}
	plan := planAt(u, now)
	limit := l.of(plan)
	free := limit <= 0 || u.Used < limit
	if free && plan == Free && l.FreeTokens > 0 && u.DayTokens >= l.FreeTokens {
		free = false
	}
	if s.d.GlobalDay != day {
		s.d.GlobalDay, s.d.GlobalUsed = day, 0
	}
	if free && plan == Free && l.GlobalFree > 0 && s.d.GlobalUsed >= l.GlobalFree {
		free = false // the shared daily budget of free conversations is spent
	}
	left := func() int {
		if limit <= 0 {
			return -1
		}
		return max(limit-u.Used, 0)
	}
	if !free && u.Tokens <= 0 {
		d := Decision{Plan: plan, TellOnce: u.Told != day, Balance: u.Tokens}
		u.Told = day
		u.Charging = false
		s.save()
		return d
	}
	if !u.Last.IsZero() && now.Sub(u.Last) >= 0 && now.Sub(u.Last) < Merge {
		s.save() // a burst of messages within a few seconds is one conversation
		return Decision{OK: true, Plan: plan, Left: left(), FromBalance: u.Charging, Balance: u.Tokens}
	}
	if free {
		u.Used++
		if plan == Free {
			s.d.GlobalUsed++
		}
		u.Charging = false
	} else {
		u.PaidToday++
		u.Charging = true
	}
	u.Total++
	u.Last = now
	s.d.ConvN++
	s.save()
	return Decision{OK: true, Plan: plan, Left: left(), FromBalance: u.Charging, Balance: u.Tokens}
}

// Activate records a payment and moves the person to the plan for days more (added to what is left of the same plan).
func (s *Store) Activate(id int64, plan string, days, stars int, charge string, now time.Time) (User, error) {
	if plan != Plus && plan != Max {
		return User{}, fmt.Errorf("billing: unknown plan %q", plan)
	}
	if days <= 0 {
		return User{}, errors.New("billing: days must be positive")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	for _, p := range s.d.Payments {
		if charge != "" && p.Charge == charge {
			return *s.user(id), nil // the same payment again: already counted
		}
	}
	u := s.user(id)
	start := now
	if planAt(u, now) == plan && u.Until.After(now) {
		start = u.Until
	}
	u.Plan, u.Until = plan, start.Add(time.Duration(days)*24*time.Hour)
	u.Paid++
	s.d.Payments = append(s.d.Payments, Payment{At: now, UserID: id, Plan: plan, Stars: stars, Charge: charge, Days: days})
	s.save()
	return *u, nil
}

// Get returns a person's account as of now.
func (s *Store) Get(id int64, now time.Time) User {
	s.mu.Lock()
	defer s.mu.Unlock()
	u := *s.user(id)
	u.Plan = planAt(&u, now)
	return u
}

// All lists every account (paid first) and every payment, for the panel.
func (s *Store) All(now time.Time) ([]User, []Payment) {
	s.mu.Lock()
	defer s.mu.Unlock()
	var us []User
	for _, u := range s.d.Users {
		x := *u
		x.Plan = planAt(&x, now)
		us = append(us, x)
	}
	sort.Slice(us, func(i, j int) bool {
		if (us[i].Plan == Free) != (us[j].Plan == Free) {
			return us[j].Plan == Free
		}
		return us[i].ID < us[j].ID
	})
	return us, append([]Payment(nil), s.d.Payments...)
}

// Refer remembers who invited a person. Only a person who is new (has never paid and has no inviter yet) can be referred, and never by themselves.
func (s *Store) Refer(id, by int64) bool {
	if id == by || by == 0 {
		return false
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	u := s.user(id)
	if u.Referrer != 0 || u.Paid > 0 {
		return false
	}
	u.Referrer = by
	s.save()
	return true
}

// Invited counts the people a person has invited and how many of them paid.
func (s *Store) Invited(by int64) (all, paid int) {
	s.mu.Lock()
	defer s.mu.Unlock()
	for _, u := range s.d.Users {
		if u.Referrer == by {
			all++
			if u.Paid > 0 {
				paid++
			}
		}
	}
	return
}

// Bonus adds free days of a plan (an invite reward) without a payment record.
func (s *Store) Bonus(id int64, plan string, days int, now time.Time) User {
	s.mu.Lock()
	defer s.mu.Unlock()
	u := s.user(id)
	start := now
	if planAt(u, now) != Free && u.Until.After(now) {
		start, plan = u.Until, planAt(u, now) // extend what they already have
	}
	u.Plan, u.Until = plan, start.Add(time.Duration(days)*24*time.Hour)
	s.save()
	return *u
}

// NewRequest opens a QR payment request (an earlier one of the same person that is still waiting for a receipt is closed; one with a receipt sent is left for the owner).
func (s *Store) NewRequest(user int64, name string, tokens int64, som int, now time.Time) Request {
	s.mu.Lock()
	defer s.mu.Unlock()
	for i := range s.d.Requests {
		if r := &s.d.Requests[i]; r.UserID == user && r.Status == "waiting" { // a request with a receipt already sent stays open: the owner may still be checking that transfer
			r.Status, r.Decided = "no", now
		}
	}
	s.d.NextReq++
	r := Request{ID: s.d.NextReq, UserID: user, Name: name, Tokens: tokens, Som: som, Code: fmt.Sprintf("R%d", s.d.NextReq), At: now, Status: "waiting"}
	s.d.Requests = append(s.d.Requests, r)
	if len(s.d.Requests) > 500 {
		s.d.Requests = s.d.Requests[len(s.d.Requests)-500:]
	}
	s.save()
	return r
}

// Waiting is the person's request that still needs a receipt.
func (s *Store) Waiting(user int64) (Request, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	for i := len(s.d.Requests) - 1; i >= 0; i-- {
		if r := s.d.Requests[i]; r.UserID == user && r.Status == "waiting" {
			return r, true
		}
	}
	return Request{}, false
}

// Mark moves a request to status; deciding (ok/no) is only possible once.
func (s *Store) Mark(id int, status string, now time.Time) (Request, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	for i := range s.d.Requests {
		r := &s.d.Requests[i]
		if r.ID != id {
			continue
		}
		if r.Status == "ok" || r.Status == "no" {
			return *r, fmt.Errorf("billing: request %s is already decided (%s)", r.Code, r.Status)
		}
		r.Status = status
		if status == "ok" || status == "no" {
			r.Decided = now
		}
		s.save()
		return *r, nil
	}
	return Request{}, fmt.Errorf("billing: no request %d", id)
}

// Approve confirms a QR request: the tokens are added (or, for an old request, the plan turns on) and the payment is recorded in som.
func (s *Store) Approve(id int, now time.Time) (Request, User, error) {
	r, err := s.Mark(id, "ok", now)
	if err != nil {
		return r, User{}, err
	}
	if r.Tokens > 0 {
		u, err := s.AddTokens(r.UserID, r.Tokens, 0, r.Som, "qr:"+r.Code, "qr", now)
		return r, u, err
	}
	u, err := s.Activate(r.UserID, r.Plan, r.Days, 0, "qr:"+r.Code, now)
	if err != nil {
		return r, u, err
	}
	s.mu.Lock()
	if n := len(s.d.Payments); n > 0 {
		s.d.Payments[n-1].Som = r.Som
	}
	s.save()
	s.mu.Unlock()
	return r, u, nil
}

// Open lists requests still waiting for the owner, oldest first.
func (s *Store) Open() []Request {
	s.mu.Lock()
	defer s.mu.Unlock()
	var out []Request
	for _, r := range s.d.Requests {
		if r.Status == "sent" || r.Status == "waiting" {
			out = append(out, r)
		}
	}
	return out
}

// Stats is the owner's summary.
type Stats struct {
	People, Paying, Today            int
	TokensSold, TokensLeft           int64
	Stars, Som, StarsToday, SomToday int
	Payments, Open                   int
}

func (s *Store) Stats(now time.Time, loc *time.Location) Stats {
	s.mu.Lock()
	defer s.mu.Unlock()
	day := now.In(loc).Format("2006-01-02")
	var st Stats
	for _, u := range s.d.Users {
		st.People++
		if planAt(u, now) != Free || u.Tokens > 0 {
			st.Paying++
		}
		if u.Tokens > 0 {
			st.TokensLeft += u.Tokens
		}
		if u.Day == now.Format("2006-01-02") {
			st.Today += u.Used
		}
	}
	for _, p := range s.d.Payments {
		if p.Kind == "gift_in" || p.Kind == "bonus" || p.Kind == "promo" {
			continue // not money
		}
		st.Payments++
		st.TokensSold += p.Tokens
		st.Stars += p.Stars
		st.Som += p.Som
		if p.At.In(loc).Format("2006-01-02") == day {
			st.StarsToday += p.Stars
			st.SomToday += p.Som
		}
	}
	for _, r := range s.d.Requests {
		if r.Status == "sent" || r.Status == "waiting" {
			st.Open++
		}
	}
	return st
}

// Ending lists people whose paid plan ends within the next window and who were not reminded about this end yet; it marks them reminded.
func (s *Store) Ending(now time.Time, window time.Duration) []User {
	s.mu.Lock()
	defer s.mu.Unlock()
	var out []User
	for _, u := range s.d.Users {
		if planAt(u, now) == Free || u.Until.Sub(now) > window || u.Reminded.Equal(u.Until) {
			continue
		}
		u.Reminded = u.Until
		out = append(out, *u)
	}
	if len(out) > 0 {
		s.save()
	}
	return out
}

// Request returns a QR request by id.
func (s *Store) Request(id int) (Request, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	for _, r := range s.d.Requests {
		if r.ID == id {
			return r, true
		}
	}
	return Request{}, false
}

// Refund takes back what the payment with this charge id gave (Stars were returned): tokens leave the balance (not below 0),
// plan days are cut, an unopened gift is voided. It reports false when the charge is unknown or was already refunded.
func (s *Store) Refund(charge string, now time.Time) (Payment, User, bool) {
	if charge == "" {
		return Payment{}, User{}, false
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	for i := range s.d.Payments {
		p := &s.d.Payments[i]
		if p.Charge != charge || p.Refunded {
			continue
		}
		p.Refunded = true
		if p.UserID == 0 { // the person asked to be forgotten: nobody's balance is left to correct
			s.save()
			return *p, User{}, true
		}
		u := s.user(p.UserID)
		switch {
		case p.Kind == "gift":
			for j := range s.d.Gifts {
				g := &s.d.Gifts[j]
				if g.Charge != charge {
					continue
				}
				if g.To > 0 {
					t := s.user(g.To)
					t.Tokens = max(t.Tokens-g.Tokens, 0)
				}
				g.To = -1
			}
		case p.Tokens > 0:
			u.Tokens = max(u.Tokens-p.Tokens, 0)
		case p.Days > 0:
			u.Until = u.Until.Add(-time.Duration(p.Days) * 24 * time.Hour)
			if !u.Until.After(now) {
				u.Plan, u.Until = Free, time.Time{}
			}
		}
		if u.Paid > 0 && (p.Kind == "pack" || p.Kind == "qr" || p.Kind == "gift" || p.Kind == "") {
			u.Paid--
			if u.Paid == 0 { // the first purchase is gone: the invite bonus that it earned goes back too (for both sides)
				s.clawInviteBonus(p.UserID)
			}
		}
		s.save()
		return *p, *u, true
	}
	return Payment{}, User{}, false
}

// clawInviteBonus takes back the invite bonus of a person whose first purchase was refunded (s.mu held). The bonus records stay, marked as
// refunded, so buying again does not pay the same bonus twice (the bonus is keyed by the person: "ref:<id>:in" and "ref:<id>:by").
func (s *Store) clawInviteBonus(id int64) {
	for i := range s.d.Payments {
		b := &s.d.Payments[i]
		if b.Kind != "bonus" || b.Refunded || b.Tokens <= 0 {
			continue
		}
		var who int64
		switch b.Charge {
		case fmt.Sprintf("ref:%d:in", id):
			who = id
		case fmt.Sprintf("ref:%d:by", id):
			who = b.UserID
		default:
			continue
		}
		b.Refunded = true
		if t := s.user(who); t != nil {
			t.Tokens = max(t.Tokens-b.Tokens, 0)
		}
	}
}
