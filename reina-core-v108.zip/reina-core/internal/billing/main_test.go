package billing

import (
	"os"
	"testing"
)

func TestMain(m *testing.M) {
	ageGateOn = false
	os.Exit(m.Run())
}
