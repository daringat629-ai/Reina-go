package billing

import (
	"context"
	"fmt"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestPartnerSeesOnlyOwnBotsAndOwnerSwitchesBots(t *testing.T) {
	srv, calls := fakeAPI(t)
	st := Open(filepath.Join(t.TempDir(), "b.json"))
	adm := &Admin{Token: "A", BaseURL: srv.URL, Store: st, Pay: newBot(srv, st), Owner: func() int64 { return 1 }, Now: func() time.Time { return t0 }, Loc: time.UTC}
	for _, c := range []string{"sp1 spermadev @SpermaOneBot Sperma One | тест", "ot1 other @OtherBot Other | тест"} {
		b, err := ParseAddBot(c)
		if err != nil {
			t.Fatal(err)
		}
		b.Share = 30
		if err := st.AddEcoBot(b, t0); err != nil {
			t.Fatal(err)
		}
	}
	st.mu.Lock()
	st.countBot(EcoTx{Bot: "sp1", Tokens: -1000, At: t0})
	st.countBot(EcoTx{Bot: "ot1", Tokens: -999000, At: t0})
	st.mu.Unlock()
	ctx := context.Background()
	say := func(from int, text string) {
		adm.handle(ctx, msg(t, fmt.Sprintf(`{"update_id":1,"message":{"from":{"id":%d},"chat":{"id":%d},"text":%q}}`, from, from, text)))
	}

	say(1, "/partner spermadev 55")
	if st.PartnerOf(55) != "spermadev" {
		t.Fatal("partner is linked")
	}
	n := len(calls("sendMessage"))
	say(77, "/mine") // a stranger gets silence
	if len(calls("sendMessage")) != n {
		t.Fatal("strangers get nothing")
	}
	say(55, "/mine")
	got := fmt.Sprint(calls("sendMessage")[len(calls("sendMessage"))-1])
	if !strings.Contains(got, "sp1") || strings.Contains(got, "ot1") || strings.Contains(got, "999") || !strings.Contains(got, "30%") {
		t.Fatalf("the partner sees only his own bot: %s", got)
	}
	say(55, "/csv") // a partner cannot use owner commands
	if g := fmt.Sprint(calls("sendDocument")); strings.Contains(g, "payments") {
		t.Fatal("owner commands stay closed")
	}
	say(1, "/bot ot1")
	got = fmt.Sprint(calls("sendMessage")[len(calls("sendMessage"))-1])
	if !strings.Contains(got, "ot1") || !strings.Contains(got, "999") || strings.Contains(got, "sp1") {
		t.Fatalf("switcher shows one bot: %s", got)
	}
	say(1, "/partner spermadev 0")
	if st.PartnerOf(55) != "" {
		t.Fatal("partner removed")
	}
}
