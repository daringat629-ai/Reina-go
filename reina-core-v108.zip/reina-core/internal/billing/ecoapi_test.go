package billing

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func ecoSetup(t *testing.T) (*Store, EcoBot, string) {
	t.Helper()
	s := Open(filepath.Join(t.TempDir(), "b.json"))
	if err := s.AddEcoBot(EcoBot{ID: "site", Name: "Site", Owner: "danya", Username: "SiteBot"}, t0); err != nil {
		t.Fatal(err)
	}
	key, err := s.NewEcoKey("site")
	if err != nil || !strings.HasPrefix(key, "ek_") {
		t.Fatalf("key: %q %v", key, err)
	}
	bot, ok := s.EcoAuth(key)
	if !ok {
		t.Fatal("the new key must work")
	}
	return s, bot, key
}

func TestEcoKeyAndKillSwitch(t *testing.T) {
	s, _, key := ecoSetup(t)
	if _, ok := s.EcoAuth("ek_wrong"); ok {
		t.Fatal("a wrong key works")
	}
	if _, ok := s.EcoAuth(""); ok {
		t.Fatal("an empty key works")
	}
	if raw, _ := json.Marshal(s.d); strings.Contains(string(raw), key) {
		t.Fatal("the key itself must never be stored")
	}
	s.SetEcoBotOff("site", true)
	if _, ok := s.EcoAuth(key); ok {
		t.Fatal("a switched-off bot is locked out")
	}
	s.SetEcoBotOff("site", false)
	k2, _ := s.NewEcoKey("site")
	if _, ok := s.EcoAuth(key); ok {
		t.Fatal("a new key kills the old one")
	}
	if _, ok := s.EcoAuth(k2); !ok {
		t.Fatal("the new key works")
	}
	// editing the bot in the app keeps its key and its rights
	s.SetEcoCredit("site", true)
	_ = s.AddEcoBot(EcoBot{ID: "site", Name: "Site 2", Owner: "danya", Username: "SiteBot"}, t0)
	if b, ok := s.EcoAuth(k2); !ok || !b.Credit {
		t.Fatalf("an edit must not drop the key or the right: %+v %v", b, ok)
	}
	// and it survives a restart
	if b, ok := Open(s.path).EcoAuth(k2); !ok || !b.Credit {
		t.Fatal("not saved")
	}
}

func TestEcoSpendCreditAreIdempotent(t *testing.T) {
	s, bot, _ := ecoSetup(t)
	now := t0
	if _, _, err := s.EcoSpend(bot, 7, 100, "order-1", now); err != ErrEcoNoTokens {
		t.Fatalf("a stranger has nothing: %v", err)
	}
	if _, _, err := s.EcoCredit(bot, 7, 500, "pay-1", now); err != ErrEcoCredit {
		t.Fatalf("without the right nobody adds tokens: %v", err)
	}
	s.SetEcoCredit("site", true)
	bot, _ = s.EcoBotByID("site")
	bal, dup, err := s.EcoCredit(bot, 7, 500, "pay-1", now)
	if err != nil || dup || bal != 500 {
		t.Fatalf("credit: %d %v %v", bal, dup, err)
	}
	if bal, dup, _ := s.EcoCredit(bot, 7, 500, "pay-1", now); !dup || bal != 500 {
		t.Fatalf("the same ref must not add twice: %d %v", bal, dup)
	}
	bal, dup, err = s.EcoSpend(bot, 7, 200, "order-1", now)
	if err != nil || dup || bal != 300 {
		t.Fatalf("spend: %d %v %v", bal, dup, err)
	}
	if bal, dup, _ := s.EcoSpend(bot, 7, 200, "order-1", now); !dup || bal != 300 {
		t.Fatalf("the same ref must not charge twice: %d %v", bal, dup)
	}
	if bal, _, err := s.EcoSpend(bot, 7, 1000, "order-2", now); err != ErrEcoNoTokens || bal != 300 {
		t.Fatalf("not enough: %d %v", bal, err)
	}
	if s.EcoBalance(7) != 300 || s.EcoBalance(999) != 0 {
		t.Fatal("balance")
	}
	// the same ref of ANOTHER bot is a different operation
	_ = s.AddEcoBot(EcoBot{ID: "other", Name: "O", Owner: "x", Username: "OtherBot"}, now)
	other, _ := s.EcoBotByID("other")
	if _, dup, err := s.EcoSpend(other, 7, 50, "order-1", now); dup || err != nil {
		t.Fatalf("refs belong to a bot: %v %v", dup, err)
	}
	for _, bad := range []struct {
		tok int64
		ref string
	}{{0, "order-9"}, {-5, "order-9"}, {maxEcoSpend + 1, "order-9"}, {10, "x"}, {10, "has space"}} {
		if _, _, err := s.EcoSpend(bot, 7, bad.tok, bad.ref, now); err == nil || err == ErrEcoNoTokens {
			t.Fatalf("accepted %+v: %v", bad, err)
		}
	}
	if len(s.d.Payments) != 1 || s.d.Payments[0].Kind != "eco" {
		t.Fatal("a credit is kept as a payment, once")
	}
}

func ecoCall(h http.Handler, path, key, body string) (int, map[string]any) {
	r := httptest.NewRequest("POST", path, strings.NewReader(body))
	if key != "" {
		r.Header.Set("Authorization", "Bearer "+key)
	}
	r.RemoteAddr = "203.0.113.5:4000"
	w := httptest.NewRecorder()
	h.ServeHTTP(w, r)
	var out map[string]any
	_ = json.Unmarshal(w.Body.Bytes(), &out)
	return w.Code, out
}

func TestEcoHTTP(t *testing.T) {
	srv, _ := fakeAPI(t)
	s, _, key := ecoSetup(t)
	pay := newBot(srv, s)
	pay.Now = func() time.Time { return t0 }
	app := pay.WebApp()
	s.SetEcoCredit("site", true)

	if code, _ := ecoCall(app, "/app/eco/v1/balance", "", `{"user_id":7}`); code != 401 {
		t.Fatalf("no key: %d", code)
	}
	if code, out := ecoCall(app, "/app/eco/v1/credit", key, `{"user_id":7,"tokens":1000,"ref":"pay-77"}`); code != 200 || out["balance"] != float64(1000) {
		t.Fatalf("credit: %d %v", code, out)
	}
	if code, out := ecoCall(app, "/app/eco/v1/balance", key, `{"user_id":7}`); code != 200 || out["balance"] != float64(1000) {
		t.Fatalf("balance: %d %v", code, out)
	}
	if code, out := ecoCall(app, "/app/eco/v1/spend", key, `{"user_id":7,"tokens":400,"ref":"chat-1"}`); code != 200 || out["balance"] != float64(600) || out["duplicate"] != false {
		t.Fatalf("spend: %d %v", code, out)
	}
	if code, out := ecoCall(app, "/app/eco/v1/spend", key, `{"user_id":7,"tokens":400,"ref":"chat-1"}`); code != 200 || out["duplicate"] != true || out["balance"] != float64(600) {
		t.Fatalf("a retry: %d %v", code, out)
	}
	if code, out := ecoCall(app, "/app/eco/v1/spend", key, `{"user_id":7,"tokens":9000,"ref":"chat-2"}`); code != 402 || out["balance"] != float64(600) {
		t.Fatalf("not enough must be 402 with the balance: %d %v", code, out)
	}
	if code, _ := ecoCall(app, "/app/eco/v1/spend", key, `not json`); code != 400 {
		t.Fatalf("bad json: %d", code)
	}
	if code, _ := ecoCall(app, "/app/eco/v1/nope", key, `{}`); code != 404 {
		t.Fatalf("unknown path: %d", code)
	}
	r := httptest.NewRequest("GET", "/app/eco/v1/balance", nil)
	w := httptest.NewRecorder()
	app.ServeHTTP(w, r)
	if w.Code != http.StatusMethodNotAllowed {
		t.Fatalf("GET: %d", w.Code)
	}
	// no right to add: 403
	s.SetEcoCredit("site", false)
	if code, _ := ecoCall(app, "/app/eco/v1/credit", key, `{"user_id":7,"tokens":5,"ref":"pay-78"}`); code != 403 {
		t.Fatalf("credit without the right: %d", code)
	}
	// guessing keys is slowed down per address
	for i := 0; i < 25; i++ {
		ecoCall(app, "/app/eco/v1/balance", "ek_guess", `{}`)
	}
	if code, _ := ecoCall(app, "/app/eco/v1/balance", key, `{"user_id":7}`); code != 429 {
		t.Fatalf("after many wrong keys the address waits: %d", code)
	}
}
