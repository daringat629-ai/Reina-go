'use strict';
const test = require('node:test');
const assert = require('node:assert');
const { badIP, resolvePublic, splitChat, shouldReply, authAction, derivePass, wantsLeave } = require('./lib');

test('closed addresses', async () => {
  for (const ip of ['127.0.0.1', '10.1.2.3', '192.168.0.9', '172.16.0.1', '169.254.169.254', '0.0.0.0', '::1', 'fe80::1', 'fd00::1', '::ffff:127.0.0.1', '100.64.0.1']) assert.ok(badIP(ip), ip);
  for (const ip of ['8.8.8.8', '1.1.1.1', '2606:4700:4700::1111']) assert.ok(!badIP(ip), ip);
  await assert.rejects(resolvePublic('127.0.0.1', 25565));
  await assert.rejects(resolvePublic('8.8.8.8', 80));
  assert.strictEqual(await resolvePublic('8.8.8.8', 25565), '8.8.8.8');
  assert.strictEqual(await resolvePublic('127.0.0.1', 25565, true), '127.0.0.1');
  await assert.rejects(resolvePublic('127.0.0.1', 80, true));
});
test('chat is cut into short pieces', () => {
  const p = splitChat('слово '.repeat(100));
  assert.ok(p.length <= 3 && p.every((x) => x.length <= 200));
  assert.deepStrictEqual(splitChat('привет\nмир'), ['привет мир']);
});
test('replies only when called by name and not too often', () => {
  assert.ok(shouldReply('Reina', 'Danya', 'Reina, привет', 0, 10000));
  assert.ok(!shouldReply('Reina', 'Danya', 'привет всем', 0, 10000));
  assert.ok(!shouldReply('Reina', 'Reina', 'Reina', 0, 10000));
  assert.ok(!shouldReply('Reina', 'Danya', 'Reina', 9000, 10000));
});

test('sign-in prompts, passwords and leaving', () => {
  assert.strictEqual(authAction('Please register with /register <password> <confirmPassword>'), 'register');
  assert.strictEqual(authAction('Авторизуйтесь: /login <пароль>'), 'login');
  assert.strictEqual(authAction('привет всем'), null);
  const a = derivePass('s', 'play.example.com', 25565), b = derivePass('s', 'other.example.com', 25565);
  assert.ok(a.length === 16 && a !== b && a === derivePass('s', 'PLAY.example.com', 25565));
  assert.ok(wantsLeave('Reina, выйди') && wantsLeave('Reina bye!') && !wantsLeave('Reina, привет'));
});
