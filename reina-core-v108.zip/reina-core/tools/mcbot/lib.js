'use strict';
const dns = require('node:dns').promises;
const net = require('node:net');

// Addresses that must never be reachable from this machine: itself, home/office networks, link-local and cloud metadata.
function badIP(ip) {
  const v = net.isIP(ip);
  if (v === 4) {
    const [a, b] = ip.split('.').map(Number);
    return a === 0 || a === 10 || a === 127 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127) || a >= 224;
  }
  if (v === 6) {
    const s = ip.toLowerCase();
    if (s === '::' || s === '::1' || s.startsWith('fe8') || s.startsWith('fe9') || s.startsWith('fea') || s.startsWith('feb') ||
        s.startsWith('fc') || s.startsWith('fd') || s.startsWith('ff')) return true;
    const m = s.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/);
    return m ? badIP(m[1]) : false;
  }
  return true;
}

// Resolves the host NOW and refuses anything that points at a closed address. Returns the address to connect to.
async function resolvePublic(host, port, allowLocal = false) {
  if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error('port out of range');
  const h = String(host || '').trim().toLowerCase();
  if (!h || h.length > 253) throw new Error('bad host');
  const list = net.isIP(h) ? [{ address: h }] : await dns.lookup(h, { all: true });
  if (!list.length) throw new Error('host does not resolve');
  if (!allowLocal) for (const x of list) if (badIP(x.address)) throw new Error('address is closed');
  return list[0].address;
}

// Minecraft chat is limited to 256 characters; keep messages short and in a few pieces.
function splitChat(text, max = 200, maxParts = 3) {
  const clean = String(text || '').replace(/[\r\n\t]+/g, ' ').replace(/\s+/g, ' ').trim();
  const out = [];
  let rest = clean;
  while (rest && out.length < maxParts) {
    if (rest.length <= max) { out.push(rest); rest = ''; break; }
    let cut = rest.lastIndexOf(' ', max);
    if (cut < max / 2) cut = max;
    out.push(rest.slice(0, cut).trim());
    rest = rest.slice(cut).trim();
  }
  return out.filter(Boolean);
}

// Answer only when somebody speaks to the bot (by name), never to itself, never faster than the gap.
function shouldReply(name, from, text, lastAt, now, gapMs = 4000) {
  if (!from || from.toLowerCase() === name.toLowerCase()) return false;
  if (now - lastAt < gapMs) return false;
  return String(text).toLowerCase().includes(name.toLowerCase());
}

const crypto = require('node:crypto');

// Sign-in plugins (AuthMe and alike) ask in the chat to /register or /login. Returns what the server asks for.
function authAction(text) {
  const t = String(text || '').toLowerCase();
  if (/(\/register|\/reg\b|зарегистрируйтесь|зарегистрируйся|register yourself|please register)/.test(t)) return 'register';
  if (/(\/login|\/l\b|авторизуйтесь|авторизуйся|войдите|please log ?in|please login)/.test(t)) return 'login';
  return null;
}

// One password per server, derived from one secret, so a password seen by one server tells nothing about the others.
function derivePass(secret, host, port) {
  return crypto.createHmac('sha256', String(secret)).update(String(host).toLowerCase() + ':' + port).digest('base64url').slice(0, 16);
}

// "Reina, выйди" / "Reina leave": the bot goes away when someone asks.
function wantsLeave(text) {
  return /(^|\s)(выйди|уходи|уйди|пока|leave|bye|go away)(\s|$|[!.,])/i.test(String(text || ''));
}

module.exports = { badIP, resolvePublic, splitChat, shouldReply, authAction, derivePass, wantsLeave };
