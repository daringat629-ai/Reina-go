package main

import (
	"fmt"
	"io"
	"os"
	"strings"

	"orvi/internal/config"
	"orvi/internal/store"
)

// maxPreset: everything that trades tokens for ability, turned up. `reina max` writes it into config.toml.
var maxPreset = [][2]string{
	{"llm.reasoning", "high"},     // always thinks at full effort
	{"llm.fast_rounds", "false"},  // reasoning is never switched off in fast rounds
	{"llm.fast_short_chars", "0"}, // short messages are thought through too
	{"llm.request_timeout_secs", "600"},
	{"llm.parallel_tools", "true"},
	{"telegram.max_tool_rounds", "40"},       // long chains of actions in one turn
	{"memory.context_chars", "200000"},       // ~50k tokens of history per request
	{"memory.old_tool_result_chars", "4000"}, // remembers earlier tool results
	{"memory.history_keep", "100"},           // keeps the conversation verbatim longer
	{"memory.max_related_entries", "20"},     // more diary memories in the prompt
	{"memory.diary_token_count_trigger", "12000"},
	{"capabilities.owner_all_tools", "true"},
	{"capabilities.link_max_chars", "30000"},     // reads whole pages
	{"capabilities.document_max_chars", "60000"}, // reads whole documents
	{"capabilities.document_max_mb", "50"},
	{"capabilities.media_max_mb", "50"},
	{"misc.lazy_tools", "false"}, // every tool visible from the start
	{"misc.desk_overview", "true"},
	{"browser.max_steps", "60"},
	{"desktop.max_steps", "60"},
	{"work.enabled", "true"}, // background jobs from the #work queue
	{"work.max_runs_per_day", "48"},
}

// runSet writes one "section.key" = value into the config file.
func runSet(path, dotted, raw string, w io.Writer) error {
	section, key, ok := strings.Cut(dotted, ".")
	if !ok {
		return fmt.Errorf("%q: нужно раздел.ключ, например llm.reasoning", dotted)
	}
	if err := config.SetKey(path, section, key, raw); err != nil {
		return fmt.Errorf("%s: %w", dotted, err)
	}
	shown := raw
	if config.IsSecret(key) {
		shown = "<скрыто>" // the echo ends up in a terminal log or a pasted report
	}
	fmt.Fprintf(w, "✔ %s = %s\n", dotted, shown)
	return nil
}

// runMax applies maxPreset to the config file.
func runMax(path string, w io.Writer) error {
	orig, rerr := os.ReadFile(path)
	for _, kv := range maxPreset {
		if err := runSet(path, kv[0], kv[1], w); err != nil {
			return err
		}
	}
	if rerr == nil { // every set keeps only the previous state in .bak; after the preset .bak must be the file as it was before
		if err := store.WriteFile(path+".bak", orig, store.Private); err != nil {
			return err
		}
	}
	fmt.Fprintln(w, "Готово: всё на максимум (старый конфиг — в config.toml.bak). Перезапусти её, чтобы всё точно применилось.")
	return nil
}
