'use strict';
const test = require('node:test');
const assert = require('node:assert');
const { badIP, resolvePublic, splitChat, shouldReply, authAction, derivePass, wantsLeave } = require('./lib');

test('closed addresses', async () => {
  for (const ip of ['127.0.0.1', '10.1.2.3', '192.168.0.9', '172.16.0.1', '169.254.169.254', '0.0.0.0', '::1', 'fe80::1', 'fd00::1', '::ffff:127.0.0.1', '100.64.0.1']) assert.ok(badIP(ip), ip);
  for (const ip of ['8.8.8.8', '1.1.1.1', '2606:4700:4700::1111']) assert.ok(!badIP(ip), ip);
  await assert.rejects(resolvePublic('127.0.0.1', 25565));
  await assert.rejects(resolvePublic('8.8.8.8', 80));
  assert.strictEqual(await resolvePublic('8.8.8.8', 25565), '8.8.8.8');
  assert.strictEqual(await resolvePublic('127.0.0.1', 25565, true), '127.0.0.1');
  await assert.rejects(resolvePublic('127.0.0.1', 80, true));
});
test('chat is cut into short pieces', () => {
  const p = splitChat('слово '.repeat(100));
  assert.ok(p.length <= 3 && p.every((x) => x.length <= 200));
  assert.deepStrictEqual(splitChat('привет\nмир'), ['привет мир']);
});
test('replies only when called by name and not too often', () => {
  assert.ok(shouldReply('Reina', 'Danya', 'Reina, привет', 0, 10000));
  assert.ok(!shouldReply('Reina', 'Danya', 'привет всем', 0, 10000));
  assert.ok(!shouldReply('Reina', 'Reina', 'Reina', 0, 10000));
  assert.ok(!shouldReply('Reina', 'Danya', 'Reina', 9000, 10000));
});

test('sign-in prompts, passwords and leaving', () => {
  assert.strictEqual(authAction('Please register with /register <password> <confirmPassword>'), 'register');
  assert.strictEqual(authAction('Авторизуйтесь: /login <пароль>'), 'login');
  assert.strictEqual(authAction('привет всем'), null);
  const a = derivePass('s', 'play.example.com', 25565), b = derivePass('s', 'other.example.com', 25565);
  assert.ok(a.length === 16 && a !== b && a === derivePass('s', 'PLAY.example.com', 25565));
  assert.ok(wantsLeave('Reina, выйди') && wantsLeave('Reina bye!') && !wantsLeave('Reina, привет'));
});

const L = require('./lib');
test('status line, version choice, reasons', () => {
  assert.strictEqual(L.statusLine({ state: 'joined', version: '1.21.4', x: undefined }), 'MCBOT_STATUS {"state":"joined","version":"1.21.4"}');
  const c = [{ v: '1.8.8', p: 47 }, { v: '1.16.5', p: 754 }, { v: '1.21.4', p: 769 }, { v: '1.21.11', p: 774 }];
  assert.deepStrictEqual(L.pickVersion(754, c), { version: '1.16.5', exact: true });
  assert.deepStrictEqual(L.pickVersion(800, c), { version: '1.21.11', exact: false });
  assert.strictEqual(L.classifyError({ code: 'ENOTFOUND' }), 'dns');
  assert.strictEqual(L.classifyError({ code: 'ECONNREFUSED' }), 'refused');
  assert.strictEqual(L.classifyError(new Error('address is closed')), 'blocked');
  assert.strictEqual(L.classifyKick('{"text":"You are not whitelisted on this server!"}'), 'whitelist');
  assert.strictEqual(L.classifyKick({ translate: 'multiplayer.disconnect.banned' }), 'banned');
  assert.strictEqual(L.classifyKick('The server is full!'), 'full');
  assert.strictEqual(L.classifyKick('Failed to verify username!'), 'auth_required');
  assert.strictEqual(L.classifyKick('Outdated client! Please use 1.21.4'), 'version');
  assert.strictEqual(L.classifyKick('§cНеверный пароль!'), 'authme_failed');
  assert.strictEqual(L.classifyKick('Kicked by an operator'), 'kicked');
});
test('chat formats and names', () => {
  assert.deepStrictEqual(L.parseChat('<Danya> Reina, hi'), { from: 'Danya', text: 'Reina, hi' });
  assert.deepStrictEqual(L.parseChat('§7[§6VIP§7] Danya §8» §fрейна привет'), { from: 'Danya', text: 'рейна привет' });
  assert.deepStrictEqual(L.parseChat('[G] [Admin] Danya: hello'), { from: 'Danya', text: 'hello' });
  assert.deepStrictEqual(L.parseChat('Игрок Danya_2 > yo'), { from: 'Danya_2', text: 'yo' });
  const n = L.nameVariants('Reina', ['Рей']);
  assert.ok(n.includes('рейна') && n.includes('reina') && n.includes('рей'));
  for (const t of ['Reina, привет', 'REINA come here', 'рейна, как дела', 'Позови Рейну', 'эй рэйна']) assert.ok(L.isAddressed(t, n), t);
  for (const t of ['привет всем', 'reinactor', 'рейнджер']) assert.ok(!L.isAddressed(t, L.nameVariants('Reina')), t);
});
test('sign-in commands', () => {
  assert.strictEqual(L.authCommand('Please register with /register <password> <confirmPassword>', 'P'), '/register P P');
  assert.strictEqual(L.authCommand('Зарегистрируйтесь: /reg <пароль>', 'P'), '/reg P');
  assert.strictEqual(L.authCommand('Войдите: /l <пароль>', 'P'), '/l P');
  assert.strictEqual(L.authCommand('Авторизуйтесь /login <пароль>', 'P'), '/login P');
  assert.strictEqual(L.authCommand('привет', 'P'), null);
});

// ---- End to end against a fake local server (no internet needed) ----
const { spawn } = require('node:child_process');
const http = require('node:http');
const mc = require('minecraft-protocol');

function fakeLLM() {
  return new Promise((res) => {
    const s = http.createServer((req, rsp) => { req.resume(); req.on('end', () => { rsp.setHeader('content-type', 'application/json'); rsp.end(JSON.stringify({ choices: [{ message: { content: 'Привет, Danya!' } }] })); }); });
    s.listen(0, '127.0.0.1', () => res(s));
  });
}
function runBot(port, llmPort, extra = {}) {
  const p = spawn(process.execPath, [require('node:path').join(__dirname, 'mcbot.js')], {
    env: { ...process.env, MC_HOST: '127.0.0.1', MC_PORT: String(port), MC_VERSION: 'auto', MC_ALLOW_LOCAL: '1', MC_USER: 'Reina', MC_PASS_FILE: '/nonexistent',
      LLM_URL: `http://127.0.0.1:${llmPort}/v1/chat/completions`, LLM_KEY: 'test', LLM_MODEL: 'm', MC_CONNECT_TIMEOUT_MS: '8000', ...extra },
  });
  const statuses = []; let out = '';
  p.stdout.on('data', (d) => { out += d; for (const l of String(d).split('\n')) if (l.startsWith('MCBOT_STATUS ')) statuses.push(JSON.parse(l.slice(13))); });
  p.stderr.on('data', (d) => { out += d; });
  const done = new Promise((r) => p.on('exit', (code) => r(code)));
  return { p, statuses, done, out: () => out };
}
function fakeServer(opts, onJoin) {
  return new Promise((res) => {
    const server = mc.createServer({ 'online-mode': false, host: '127.0.0.1', port: 0, version: '1.16.5', motd: 'test', ...opts });
    server.on('listening', () => res(server));
    if (onJoin) server.on('playerJoin', (c) => onJoin(c, server));
  });
}
function sendWorld(client, server) {
  const loginPacket = require('minecraft-data')(server.version).loginPacket;
  client.write('login', { entityId: client.id, isHardcore: false, gameMode: 0, previousGameMode: 1, worldNames: loginPacket.worldNames, dimensionCodec: loginPacket.dimensionCodec,
    dimension: loginPacket.dimension, worldName: 'minecraft:overworld', hashedSeed: [0, 0], maxPlayers: 20, viewDistance: 10, reducedDebugInfo: false, enableRespawnScreen: true, isDebug: false, isFlat: false });
  client.write('position', { x: 0, y: 64, z: 0, yaw: 0, pitch: 0, flags: 0, teleportId: 1 });
  client.write('update_health', { health: 20, food: 20, foodSaturation: 5 });
}

test('e2e: joins (auto version), answers a plugin-formatted chat line, reports kick', { timeout: 40000 }, async () => {
  const llm = await fakeLLM();
  const got = [];
  const server = await fakeServer({}, (client, srv) => {
    sendWorld(client, srv);
    client.on('chat', (p) => {
      got.push(p.message);
      if (p.message === 'Привет, Danya!') setTimeout(() => client.end('Kicked by an operator'), 300);
    });
    setTimeout(() => client.write('chat', { message: JSON.stringify({ text: '§7[§6VIP§7] Danya §8» §fРейна, привет!' }), position: 1, sender: '00000000-0000-0000-0000-000000000000' }), 1500);
  });
  const b = runBot(server.socketServer.address().port, llm.address().port);
  const code = await b.done;
  server.close(); llm.close();
  const states = b.statuses.map((s) => s.state);
  assert.deepStrictEqual(states, ['connecting', 'joined', 'left'], b.out());
  assert.strictEqual(b.statuses[1].version, '1.16.5');
  assert.strictEqual(b.statuses[2].reason, 'kicked');
  assert.ok(got.includes('Привет, Danya!'), 'reply sent: ' + JSON.stringify(got));
  assert.strictEqual(code, 0);
});

test('e2e: whitelist kick before join, refused port', { timeout: 30000 }, async () => {
  const llm = await fakeLLM();
  const server = await fakeServer({});
  server.on('login', (c) => c.end('You are not whitelisted on this server!'));
  const b = runBot(server.socketServer.address().port, llm.address().port);
  assert.strictEqual(await b.done, 1);
  server.close();
  assert.deepStrictEqual(b.statuses.at(-1), { state: 'failed', reason: 'whitelist', detail: 'You are not whitelisted on this server!' }, b.out());
  const free = await new Promise((r) => { const s = require('node:net').createServer().listen(0, '127.0.0.1', () => { const p = s.address().port; s.close(() => r(p)); }); });
  const c = runBot(free, llm.address().port);
  assert.strictEqual(await c.done, 1);
  llm.close();
  assert.strictEqual(c.statuses.at(-1).state, 'failed');
  assert.strictEqual(c.statuses.at(-1).reason, 'refused', c.out());
});

test('e2e: online-mode server reports auth_required', { timeout: 30000 }, async () => {
  const llm = await fakeLLM();
  const server = await fakeServer({ 'online-mode': true });
  const b = runBot(server.socketServer.address().port, llm.address().port);
  assert.strictEqual(await b.done, 1);
  server.close(); llm.close();
  assert.strictEqual(b.statuses.at(-1).reason, 'auth_required', b.out());
});

test('skin command for SkinsRestorer', () => {
  const L = require('./lib');
  assert.strictEqual(L.skinCommand('https://i.imgur.com/abc.png', false), '/skin url https://i.imgur.com/abc.png');
  assert.strictEqual(L.skinCommand('https://x.ru/s.png', true), '/skin url https://x.ru/s.png slim');
  assert.strictEqual(L.skinCommand('http://x.ru/s.png'), '');
  assert.strictEqual(L.skinCommand('https://x.ru/a b.png'), '');
  assert.strictEqual(L.skinCommand('https://x.ru/a.png;/op me'), '');
  assert.strictEqual(L.skinCommand(''), '');
});
