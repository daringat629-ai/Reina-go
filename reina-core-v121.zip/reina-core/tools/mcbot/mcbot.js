'use strict';
// A small Minecraft (Java) client for Reina and other characters: joins a server by address and port, hears the chat and answers in it.
// It never runs code a model wrote. Keys come from the environment, never from files in the repo.
// Progress for the Go side goes to stdout as single lines `MCBOT_STATUS {json}` (see README / lib.statusLine).
const mineflayer = require('mineflayer');
const mc = require('minecraft-protocol');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const dns = require('node:dns').promises;
const L = require('./lib');
const F = require('./forge');

const env = process.env;
const cfg = {
  host: env.MC_HOST, port: parseInt(env.MC_PORT || '25565', 10), version: (env.MC_VERSION || 'auto').trim(),
  username: env.MC_USER || 'Reina', auth: env.MC_AUTH || 'offline', name: env.BOT_NAME || env.MC_USER || 'Reina',
  aliases: env.BOT_ALIASES || '',
  llmURL: env.LLM_URL, llmKey: env.LLM_KEY, model: env.LLM_MODEL,
  persona: env.PERSONA || 'Ты ИИ-персонаж, которого игроки видят в чате Minecraft. Ты не человек и честно говоришь об этом, если спросят. Отвечай коротко, по-дружески, одной-двумя фразами.',
  allowLocal: env.MC_ALLOW_LOCAL === '1', // only for a hand-started test on your own machine, never set by a service
  maxMinutes: parseInt(env.MAX_MINUTES || '120', 10),
  connectTimeout: parseInt(env.MC_CONNECT_TIMEOUT_MS || '30000', 10),
  spawnTimeout: parseInt(env.MC_SPAWN_TIMEOUT_MS || '60000', 10),
  greeting: env.MC_GREETING ?? 'Привет! Я ИИ-персонаж. Позови меня по имени.',
};

function secret() {
  try { return fs.readFileSync(env.MC_PASS_FILE || path.join(__dirname, 'pass.secret'), 'utf8').trim(); } catch { return ''; }
}
function log(...a) { console.log(new Date().toISOString(), ...a); }

let finished = false;
function status(obj) { console.log(L.statusLine(obj)); }
function finish(obj, code) {
  if (finished) return;
  finished = true;
  status(obj);
  setTimeout(() => process.exit(code), 300);
}
const fail = (reason, detail) => finish({ state: 'failed', reason, detail }, 1);

async function ask(history, context) {
  const r = await fetch(cfg.llmURL, {
    method: 'POST',
    headers: { 'content-type': 'application/json', authorization: 'Bearer ' + cfg.llmKey },
    body: JSON.stringify({ model: cfg.model, max_tokens: 150, messages: [{ role: 'system', content: cfg.persona + '\n\n' + context }, ...history] }),
    signal: AbortSignal.timeout(20000),
  });
  if (!r.ok) throw new Error('llm http ' + r.status);
  const j = await r.json();
  return j.choices?.[0]?.message?.content || '';
}

// What mineflayer can speak, as [{v, p}] ascending by protocol.
function candidates() {
  const data = require('minecraft-data');
  const { testedVersions } = require('mineflayer/lib/version');
  const first = data.versionsByMinecraftVersion.pc[testedVersions[0]]?.version ?? 47;
  const out = [];
  for (const v of mc.supportedVersions) {
    const p = data.versionsByMinecraftVersion.pc[v]?.version;
    if (Number.isInteger(p) && p >= first) out.push({ v, p });
  }
  return out.sort((a, b) => a.p - b.p);
}

// SRV record (_minecraft._tcp.host) like the real client does, but only when no port was given and the host is a name.
async function srv(host, port) {
  if (port !== 25565 || net.isIP(host) || env.MC_PORT) return { host, port };
  try {
    const r = await dns.resolveSrv('_minecraft._tcp.' + host);
    if (r && r[0]) return { host: r[0].name, port: r[0].port };
  } catch {}
  return { host, port };
}

async function main() {
  for (const k of ['host', 'llmURL', 'llmKey', 'model']) if (!cfg[k]) { log('missing setting:', k); return fail('config', 'missing ' + k); }
  const target = await srv(cfg.host, cfg.port);
  let ip;
  try { ip = await L.resolvePublic(target.host, target.port, cfg.allowLocal); } // checked on every start
  catch (e) { return fail(L.classifyError(e), e.message); }
  if (cfg.allowLocal) log('WARNING: MC_ALLOW_LOCAL=1, closed addresses are allowed');
  // Connect to the address we just checked (so a DNS trick cannot point us at a closed network), but tell the server the NAME in the handshake:
  // tunnel services such as playit route a Minecraft connection by that name and silently drop one that only carries a bare IP.
  const connect = (client) => {
    const sock = net.connect(target.port, ip);
    sock.setTimeout(cfg.connectTimeout, () => sock.destroy(Object.assign(new Error('connect timeout'), { code: 'ETIMEDOUT' })));
    sock.once('connect', () => sock.setTimeout(0));
    client.setSocket(sock); // setSocket already announces 'connect' itself
  };

  let version = cfg.version, serverVersion, info;
  if (!version || version === 'auto' || version === 'false') {
    try {
      const latest = require('mineflayer/lib/version').latestSupportedVersion;
      info = await mc.ping({ host: cfg.host, port: target.port, version: latest, connect, closeTimeout: cfg.connectTimeout });
    } catch (e) { return fail(L.classifyError(e), 'ping: ' + (e.code || e.message)); }
    serverVersion = info?.version?.name;
    const pick = L.pickVersion(info?.version?.protocol, candidates());
    if (!pick) return fail('version', 'server protocol ' + info?.version?.protocol + ' unknown');
    version = pick.version;
    if (!pick.exact) log(`server speaks "${serverVersion}" (protocol ${info?.version?.protocol}), not supported; trying closest ${version}`);
    log('server version', serverVersion, '-> client', version);
  }
  // Forge servers (experimental): MC_FORGE=off disables, 2/3 forces that handshake when the ping says nothing.
  const forgeEnv = String(process.env.MC_FORGE || '').trim().toLowerCase();
  const forgeV = forgeEnv === 'off' || forgeEnv === '0' ? 0 : (F.detect(info) || (forgeEnv === '2' || forgeEnv === '3' ? Number(forgeEnv) : 0));
  if (forgeV) log('forge server (FML' + forgeV + '): joining without the mods; modded blocks count as stone');
  status({ state: 'connecting', version, server_version: serverVersion, ...(forgeV ? { forge: forgeV } : {}) });
  log('connecting', cfg.host + ':' + target.port, 'version', version);

  let bot;
  try {
    bot = mineflayer.createBot({ host: cfg.host, port: target.port, version, username: cfg.username, auth: cfg.auth, connect, hideErrors: true, checkTimeoutInterval: 60000,
      ...(forgeV ? { fakeHost: F.hostTag(cfg.host, forgeV) } : {}) });
  } catch (e) { return fail('version', e.message); }
  if (forgeV) {
    F.attachLogin(bot._client, log);
    bot.once('login', () => F.maskUnknownBlocks(bot.registry));
  }

  const names = L.nameVariants(cfg.name, [cfg.username, ...cfg.aliases.split(',')]);
  const aliasList = cfg.aliases.split(',').map((s) => s.trim()).filter(Boolean);
  const history = [];
  let last = 0, busy = false, joined = false, loggedAt = 0, kickReason = null, lastErr = null, play = null, playHandle = null;
  const say = (text) => { for (const part of L.splitChat(text)) bot.chat(part); };

  const stop = (why) => {
    log('stop:', why);
    try { playHandle?.stop?.(); } catch {}
    finish({ state: 'left', reason: why }, 0);
    try { bot.quit(); } catch {}
  };
  setTimeout(() => stop('time_limit'), cfg.maxMinutes * 60000).unref();
  process.on('SIGTERM', () => stop('sigterm'));
  process.on('SIGINT', () => stop('sigint'));

  const connectTimer = setTimeout(() => { if (!loggedAt) { fail('timeout', 'no login in ' + cfg.connectTimeout / 1000 + 's'); try { bot.end(); } catch {} } }, cfg.connectTimeout);
  let spawnTimer = null;

  const sec = secret();
  const pass = sec ? L.derivePass(sec, cfg.host, cfg.port) : '';
  const tries = { register: 0, login: 0 };

  bot.on('login', () => {
    loggedAt = Date.now(); clearTimeout(connectTimer);
    log('logged in, waiting for the world');
    spawnTimer = setTimeout(() => { if (!joined) { fail('timeout', 'no spawn in ' + cfg.spawnTimeout / 1000 + 's'); try { bot.end(); } catch {} } }, cfg.spawnTimeout);
  });
  bot.once('spawn', () => {
    joined = true; clearTimeout(spawnTimer);
    log('in the world');
    status({ state: 'joined', version, server_version: serverVersion });
    if (cfg.greeting) bot.chat(cfg.greeting);
    // Her skin: offline servers can't take it from an account; SkinsRestorer sets it from a public PNG link.
    const skin = L.skinCommand(process.env.MC_SKIN_URL, process.env.MC_SKIN_SLIM === 'true');
    if (skin) setTimeout(() => { try { bot.chat(skin); log('skin: asked SkinsRestorer'); } catch {} }, 3000);
    try { play = require('./play'); } catch (e) { if (e.code !== 'MODULE_NOT_FOUND') log('play.js failed to load:', e.message); }
    if (play?.attach) {
      try { playHandle = play.attach(bot, { name: cfg.name, aliases: aliasList, say, llm: (messages) => ask(messages, ''), log }); }
      catch (e) { log('play.attach failed:', e.message); play = null; }
    }
  });
  // Dead: come back by itself.
  bot.on('death', () => { log('died, respawning'); setTimeout(() => { try { bot.respawn(); } catch {} }, 1500); });
  // Resource packs: accept so servers that require one do not hold or kick us (nothing is downloaded).
  bot.on('resourcePack', () => { log('resource pack offered, accepting'); try { bot.acceptResourcePack(); } catch {} });

  bot.on('kicked', (r) => { kickReason = L.stripColors(L.flattenText(r)).trim(); log('kicked:', kickReason.slice(0, 300)); });
  bot.on('error', (e) => { lastErr = e; log('error', e.code || e.message); });
  bot.on('end', (why) => {
    clearTimeout(connectTimer); clearTimeout(spawnTimer);
    log('disconnected', why ? '(' + why + ')' : '');
    try { playHandle?.stop?.(); } catch {}
    if (joined) finish({ state: 'left', reason: kickReason ? L.classifyKick(kickReason) : 'disconnected', detail: kickReason || String(why || '') }, 0);
    else if (kickReason) fail(L.classifyKick(kickReason), kickReason);
    else if (lastErr) fail(L.classifyError(lastErr), lastErr.code || lastErr.message);
    else fail('unknown', String(why || 'connection closed'));
  });

  // One handler for all chat: 'messagestr' sees vanilla, 1.19+ signed chat and plugin-formatted system lines alike.
  bot.on('messagestr', async (str, position, _msg, sender) => {
    if (position === 'game_info') return; // action bar
    const text0 = L.stripColors(str);
    // Sign-in plugins: only in the first minute after login, at most 3 times each, and only the bot's own password goes out.
    if (pass && loggedAt && Date.now() - loggedAt < 60000) {
      const what = L.authAction(text0);
      if (what && tries[what] < 3) {
        tries[what]++;
        log('server asks to', what);
        const cmd = L.authCommand(text0, pass);
        setTimeout(() => bot.chat(cmd), 800);
        return;
      }
    }
    let from = null, text = null;
    if (sender) {
      const p = Object.values(bot.players || {}).find((x) => x.uuid === sender);
      if (p) from = p.username;
    }
    const parsed = L.parseChat(text0);
    if (parsed) { text = parsed.text; from = from || parsed.from; }
    if (!from || !text) return;
    if (from.toLowerCase() === String(bot.username).toLowerCase()) return;
    if (!L.isAddressed(text, names)) return;
    if (play && typeof play.isCommand === 'function') {
      try { if (play.isCommand(text, cfg.name, aliasList)) return; } catch {}
    }
    if (busy || Date.now() - last < 4000) return;
    busy = true; last = Date.now();
    if (L.wantsLeave(text)) { bot.chat('Хорошо, ухожу. Пока!'); setTimeout(() => stop('asked_to_leave'), 1500); return; }
    try {
      history.push({ role: 'user', content: from + ': ' + text.slice(0, 300) });
      while (history.length > 16) history.shift();
      const near = Object.keys(bot.players).filter((n) => n !== bot.username).slice(0, 8).join(', ') || 'никого';
      const ctx = `Сейчас в мире: ${near}. Здоровье ${Math.round(bot.health ?? 20)}/20. Время суток: ${bot.time?.isDay ? 'день' : 'ночь'}.`;
      const reply = await ask(history, ctx);
      history.push({ role: 'assistant', content: reply });
      for (const part of L.splitChat(reply)) { bot.chat(part); await new Promise((r) => setTimeout(r, 1200)); }
    } catch (e) { log('reply failed:', e.message); }
    busy = false;
  });
}
main().catch((e) => { log('fatal:', e.message); fail(L.classifyError(e), e.message); });
