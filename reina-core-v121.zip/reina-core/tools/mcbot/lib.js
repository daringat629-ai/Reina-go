'use strict';
const dns = require('node:dns').promises;
const net = require('node:net');

// Addresses that must never be reachable from this machine: itself, home/office networks, link-local and cloud metadata.
function badIP(ip) {
  const v = net.isIP(ip);
  if (v === 4) {
    const [a, b] = ip.split('.').map(Number);
    return a === 0 || a === 10 || a === 127 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127) || a >= 224;
  }
  if (v === 6) {
    const s = ip.toLowerCase();
    if (s === '::' || s === '::1' || s.startsWith('fe8') || s.startsWith('fe9') || s.startsWith('fea') || s.startsWith('feb') ||
        s.startsWith('fc') || s.startsWith('fd') || s.startsWith('ff')) return true;
    const m = s.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/);
    return m ? badIP(m[1]) : false;
  }
  return true;
}

// Resolves the host NOW and refuses anything that points at a closed address. Returns the address to connect to.
async function resolvePublic(host, port, allowLocal = false) {
  if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error('port out of range');
  const h = String(host || '').trim().toLowerCase();
  if (!h || h.length > 253) throw new Error('bad host');
  const list = net.isIP(h) ? [{ address: h }] : await dns.lookup(h, { all: true });
  if (!list.length) throw new Error('host does not resolve');
  if (!allowLocal) for (const x of list) if (badIP(x.address)) throw new Error('address is closed');
  return list[0].address;
}

// Minecraft chat is limited to 256 characters; keep messages short and in a few pieces.
function splitChat(text, max = 200, maxParts = 3) {
  const clean = String(text || '').replace(/[\r\n\t]+/g, ' ').replace(/\s+/g, ' ').trim();
  const out = [];
  let rest = clean;
  while (rest && out.length < maxParts) {
    if (rest.length <= max) { out.push(rest); rest = ''; break; }
    let cut = rest.lastIndexOf(' ', max);
    if (cut < max / 2) cut = max;
    out.push(rest.slice(0, cut).trim());
    rest = rest.slice(cut).trim();
  }
  return out.filter(Boolean);
}

// Answer only when somebody speaks to the bot (by name), never to itself, never faster than the gap.
function shouldReply(name, from, text, lastAt, now, gapMs = 4000) {
  if (!from || from.toLowerCase() === name.toLowerCase()) return false;
  if (now - lastAt < gapMs) return false;
  return String(text).toLowerCase().includes(name.toLowerCase());
}

const crypto = require('node:crypto');

// Sign-in plugins (AuthMe and alike) ask in the chat to /register or /login. Returns what the server asks for.
function authAction(text) {
  const t = String(text || '').toLowerCase();
  if (/(\/register|\/reg\b|зарегистрируйтесь|зарегистрируйся|register yourself|please register)/.test(t)) return 'register';
  if (/(\/login|\/l\b|авторизуйтесь|авторизуйся|войдите|please log ?in|please login)/.test(t)) return 'login';
  return null;
}

// One password per server, derived from one secret, so a password seen by one server tells nothing about the others.
function derivePass(secret, host, port) {
  return crypto.createHmac('sha256', String(secret)).update(String(host).toLowerCase() + ':' + port).digest('base64url').slice(0, 16);
}

// "Reina, выйди" / "Reina leave": the bot goes away when someone asks.
function wantsLeave(text) {
  return /(^|\s)(выйди|уходи|уйди|пока|leave|bye|go away)(\s|$|[!.,])/i.test(String(text || ''));
}

module.exports = { badIP, resolvePublic, splitChat, shouldReply, authAction, derivePass, wantsLeave };

// ---- Joining real servers: version choice, failure reasons, chat formats ----

// The one line the Go side reads: `MCBOT_STATUS {json}`. Keep this format stable.
function statusLine(obj) {
  const o = {};
  for (const [k, v] of Object.entries(obj)) if (v !== undefined && v !== '') o[k] = typeof v === 'string' ? v.slice(0, 300) : v;
  return 'MCBOT_STATUS ' + JSON.stringify(o);
}

// Picks the client version for a server that answered a ping with this protocol number.
// candidates: [{v:'1.21.4', p:769}, ...] in ascending order (what mineflayer can speak).
// Returns {version, exact}; exact=false means the server's version is not supported and the closest one was taken.
function pickVersion(protocol, candidates) {
  const list = candidates.filter((c) => Number.isInteger(c.p) && c.p < 0x40000000); // snapshots use huge numbers
  if (!list.length) return null;
  const same = list.filter((c) => c.p === protocol);
  if (same.length) return { version: same[same.length - 1].v, exact: true };
  let best = list[0];
  for (const c of list) if (Math.abs(c.p - protocol) < Math.abs(best.p - protocol)) best = c;
  return { version: best.v, exact: false };
}

// Plain text out of a chat component: a JSON string, an object (text/extra/translate/with) or NBT-like {value:...}.
function flattenText(x, depth = 0) {
  if (x == null || depth > 20) return '';
  if (typeof x === 'string') {
    const s = x.trim();
    if ((s.startsWith('{') || s.startsWith('[') || s.startsWith('"')) && s.length > 1) {
      try { return flattenText(JSON.parse(s), depth + 1); } catch {}
    }
    return x;
  }
  if (typeof x !== 'object') return String(x);
  if (Array.isArray(x)) return x.map((y) => flattenText(y, depth + 1)).join('');
  if (x.type && 'value' in x && Object.keys(x).length <= 2) return flattenText(x.value, depth + 1); // prismarine-nbt
  let out = '';
  if (x.text != null) out += flattenText(x.text, depth + 1);
  if (x[''] != null) out += flattenText(x[''], depth + 1);
  if (x.translate) {
    const args = (x.with?.value?.value || x.with || []).map((y) => flattenText(y, depth + 1));
    out += args.length ? x.translate + ' ' + args.join(' ') : x.translate;
  }
  if (x.extra) out += flattenText(x.extra?.value?.value || x.extra, depth + 1);
  return out;
}

function stripColors(s) { return String(s || '').replace(/§[0-9a-fk-orx]/gi, ''); }

// Why a connection failed, from a Node/minecraft-protocol error.
function classifyError(err) {
  const code = String(err?.code || '');
  const msg = String(err?.message || err || '');
  const m = (code + ' ' + msg).toLowerCase();
  if (/enotfound|eai_again|does not resolve|eai_nodata|enodata/.test(m)) return 'dns';
  if (/econnrefused/.test(m)) return 'refused';
  if (/address is closed|bad host|port out of range/.test(m)) return 'blocked';
  if (/etimedout|ehostunreach|enetunreach|timeout|timed out/.test(m)) return 'timeout';
  if (/econnreset|epipe|socket closed|closed before/.test(m)) return 'reset';
  if (/session|authserver|invalid credentials|not authenticated|microsoft|xbox|auth/.test(m)) return 'auth_required';
  if (/unsupported protocol|version/.test(m)) return 'version';
  return 'unknown';
}

// Why the server kicked us, from the kick text (English and Russian, vanilla and common plugins).
function classifyKick(text) {
  const t = stripColors(flattenText(text)).toLowerCase();
  if (/white-?list|not whitelisted|вайтлист|белом списке|белый список/.test(t)) return 'whitelist';
  if (/banned|ban(ned)? from|забанен|заблокирован|бан\b/.test(t)) return 'banned';
  if (/server is full|full server|сервер (пере)?полон|нет свободных мест/.test(t)) return 'full';
  if (/failed to verify username|failed to log in|invalid session|not authenticated with|online-?mode|premium|лицензи|authservers/.test(t)) return 'auth_required';
  if (/outdated (client|server)|incompatible|unsupported (client|version)|please use|версия|version/.test(t)) return 'version';
  if (/wrong password|incorrect password|неверный пароль|неправильный пароль|too many (login )?(attempts|tries)|login timeout|время на (авторизацию|вход)|авторизац/.test(t)) return 'authme_failed';
  return 'kicked';
}

// Latin and Cyrillic spellings of a name so «Reina» is heard as «рейна» too (and back).
const LAT2CYR = [['sch', 'щ'], ['sh', 'ш'], ['ch', 'ч'], ['zh', 'ж'], ['kh', 'х'], ['ya', 'я'], ['yu', 'ю'], ['yo', 'ё'], ['ei', 'ей'], ['ey', 'ей'], ['ai', 'ай'], ['ay', 'ай'], ['oi', 'ой'],
  ['a', 'а'], ['b', 'б'], ['c', 'к'], ['d', 'д'], ['e', 'е'], ['f', 'ф'], ['g', 'г'], ['h', 'х'], ['i', 'и'], ['j', 'дж'], ['k', 'к'], ['l', 'л'], ['m', 'м'], ['n', 'н'], ['o', 'о'], ['p', 'п'],
  ['q', 'к'], ['r', 'р'], ['s', 'с'], ['t', 'т'], ['u', 'у'], ['v', 'в'], ['w', 'в'], ['x', 'кс'], ['y', 'й'], ['z', 'з']];
const CYR2LAT = { а: 'a', б: 'b', в: 'v', г: 'g', д: 'd', е: 'e', ё: 'yo', ж: 'zh', з: 'z', и: 'i', й: 'y', к: 'k', л: 'l', м: 'm', н: 'n', о: 'o', п: 'p', р: 'r', с: 's', т: 't', у: 'u', ф: 'f', х: 'kh', ц: 'ts', ч: 'ch', ш: 'sh', щ: 'sch', ъ: '', ы: 'y', ь: '', э: 'e', ю: 'yu', я: 'ya' };
function translit(s) {
  s = String(s || '').toLowerCase();
  if (/[а-яё]/.test(s)) return s.split('').map((c) => CYR2LAT[c] ?? c).join('');
  let out = '', i = 0;
  outer: while (i < s.length) {
    for (const [l, c] of LAT2CYR) if (s.startsWith(l, i)) { out += c; i += l.length; continue outer; }
    out += s[i++];
  }
  return out;
}

// All the names she answers to: BOT_NAME, MC_USER, BOT_ALIASES (comma list) and their other-alphabet spellings.
function nameVariants(name, aliases = []) {
  const set = new Set();
  for (const raw of [name, ...(Array.isArray(aliases) ? aliases : String(aliases || '').split(','))]) {
    const n = String(raw || '').trim().toLowerCase();
    if (n.length < 2) continue;
    set.add(n); set.add(translit(n));
    if (n === 'reina' || n === 'рейна') { set.add('рейна'); set.add('рэйна'); set.add('reina'); set.add('рейночка'); }
  }
  return [...set].filter((x) => x.length >= 2);
}

// Is she being called? A whole word that is one of the names, or (for 4+ letters) a Russian case form of it («Рейну», «Рейной»).
function isAddressed(text, names) {
  const words = String(text || '').toLowerCase().split(/[^\p{L}\p{N}_]+/u).filter(Boolean);
  for (const w of words) for (const n of names) {
    if (w === n) return true;
    if (n.length >= 4 && /[а-яё]/.test(n)) {
      const stem = /[аяоеуюы]$/.test(n) ? n.slice(0, -1) : n;
      if (w.startsWith(stem) && w.length - stem.length <= 3 && /^(а|у|ы|е|ой|ою|и|ушка|очка|)$/.test(w.slice(stem.length))) return true;
    }
  }
  return false;
}

// Splits a chat line into who said it and what, across vanilla and plugin formats:
// "<Danya> hi", "[VIP] Danya: hi", "Danya » hi", "[G] [Admin] Danya > hi", "Danya -> hi", "Danya: hi".
function parseChat(line) {
  const s = stripColors(line).replace(/\s+/g, ' ').trim();
  let m = s.match(/^(?:\[[^\]]{0,32}\]\s*)*<\s*(?:\[[^\]]{0,32}\]\s*)*([A-Za-z0-9_]{1,16})\s*>\s?(.*)$/);
  if (m) return { from: m[1], text: m[2] };
  m = s.match(/^(?:[\[(][^\])]{0,32}[\])]\s*|[^\sA-Za-z0-9_]{1,3}\s*)*(?:[\p{L}\p{N}_\-.]{1,24}\s+){0,2}?([A-Za-z0-9_]{1,16})\s*(?::|»|>>|>|->|→|\||⋙|➥|➤)\s*(.+)$/u);
  if (m) return { from: m[1], text: m[2] };
  return null;
}

// Sign-in command for a sign-in prompt: the command word the server shows (/register, /reg, /login, /l), one or two passwords.
function authCommand(text, pass) {
  const what = authAction(text);
  if (!what || !pass) return null;
  const t = String(text || '').toLowerCase();
  if (what === 'register') {
    const cmd = /\/register\b/.test(t) ? '/register' : /\/reg\b/.test(t) ? '/reg' : '/register';
    const after = t.slice(Math.max(0, t.indexOf(cmd)) + cmd.length);
    const holes = (after.match(/<[^>]{1,40}>|\[[^\]]{1,40}\]/g) || []).length;
    return holes === 1 ? `${cmd} ${pass}` : `${cmd} ${pass} ${pass}`;
  }
  const cmd = /\/login\b/.test(t) ? '/login' : /\/l\b/.test(t) ? '/l' : '/login';
  return `${cmd} ${pass}`;
}

// "/skin url <link> [slim]" for SkinsRestorer, or '' when the link is not a plain public https URL.
function skinCommand(url, slim) {
  url = String(url || '').trim();
  if (!/^https:\/\/[A-Za-z0-9.-]+(:\d+)?\/[A-Za-z0-9._~%\/?=&+-]*$/.test(url) || url.length > 200) return '';
  return '/skin url ' + url + (slim ? ' slim' : '');
}

module.exports = Object.assign(module.exports, { skinCommand, statusLine, pickVersion, flattenText, stripColors, classifyError, classifyKick, translit, nameVariants, isAddressed, parseChat, authCommand });
