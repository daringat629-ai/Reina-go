package app

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"orvi/internal/billing"
	"orvi/internal/config"
)

// mcRunner sends her into people's Minecraft servers: one node process (tools/mcbot) per visit, with a time limit and a cap on how many
// run at once. The process gets only the settings it needs, not our environment, so no key of ours can leak through it.
// The connector prints "MCBOT_STATUS {json}" lines (joined, failed, left); the runner turns them into one clear story per visit:
// joined at most once, then exactly one final event (failed when she never got in, left when she did).
type mcRunner struct {
	cfg func() *config.Config

	mu      sync.Mutex
	running map[int]*mcVisit
	closed  bool
	wg      sync.WaitGroup

	// alert tells the owner about a broken setup (node or the script missing); nil = log only. At most once an hour.
	alert     func(string)
	alertMu   sync.Mutex
	lastAlert time.Time

	// command builds the process; tests replace it.
	command func(ctx context.Context, w billing.World, c *config.Config) (*exec.Cmd, error)
}

type mcVisit struct {
	cancel context.CancelFunc
	owner  int64
	mu     sync.Mutex
	why    string // why we ended it: stopped, shutdown, timeout ("" = time is up after a good visit)
}

func (v *mcVisit) end(why string) {
	v.mu.Lock()
	if v.why == "" {
		v.why = why
	}
	v.mu.Unlock()
	v.cancel()
}

func (v *mcVisit) reason() string {
	v.mu.Lock()
	defer v.mu.Unlock()
	return v.why
}

func newMCRunner(cfg func() *config.Config) *mcRunner {
	r := &mcRunner{cfg: cfg, running: map[int]*mcVisit{}}
	r.command = realMCCommand
	return r
}

// wireMinecraft connects the runner to the pay bot and stops every visit when ctx ends (shutdown). alert may be nil.
func wireMinecraft(ctx context.Context, bot *billing.Bot, cfg func() *config.Config, alert func(string)) *mcRunner {
	mc := newMCRunner(cfg)
	mc.alert = alert
	bot.WorldStart, bot.WorldStop, bot.WorldRunning = mc.Start, mc.Stop, mc.Running
	bot.WorldFee = func() int64 { return cfg().MCFee }
	bot.UseWorlds(billing.WorldHooks{
		Start: mc.StartVisit,
		IsOwner: func(user int64) bool {
			o := cfg().PapikChatID
			return o != 0 && user == o
		},
		Player: func() string { return cfg().MCName },
	})
	go func() {
		<-ctx.Done()
		mc.Close()
	}()
	return mc
}

var errNoNode = errors.New("node not found")

// findNode finds the node binary: minecraft.node when set (an executable file without arguments: node itself or a wrapper
// script such as /work/node/bin/node-run, run as "<node> <script>"), otherwise node in PATH,
// then the usual places (Alpine's apk puts it in /usr/bin, the official tarballs in /usr/local/bin or /opt/node*/bin).
func findNode(c *config.Config) (string, error) {
	if p := strings.TrimSpace(c.MCNode); p != "" {
		if isExecFile(p) {
			return p, nil
		}
		return "", fmt.Errorf("%w: minecraft.node=%q is not an executable file", errNoNode, p)
	}
	if p, err := exec.LookPath("node"); err == nil {
		return p, nil
	}
	cands := []string{"/usr/local/bin/node", "/usr/bin/node", "/bin/node", "/usr/lib/nodejs/bin/node"}
	if g, _ := filepath.Glob("/opt/node*/bin/node"); len(g) > 0 {
		cands = append(cands, g...)
	}
	for _, p := range cands {
		if isExecFile(p) {
			return p, nil
		}
	}
	return "", fmt.Errorf("%w in PATH or the usual places: install Node.js or set minecraft.node", errNoNode)
}

func isExecFile(p string) bool {
	st, err := os.Stat(p)
	return err == nil && st.Mode().IsRegular() && st.Mode().Perm()&0o111 != 0
}

// checkScript makes sure the connector is there and its packages are installed.
func checkScript(p string) error {
	if strings.TrimSpace(p) == "" {
		return errors.New("minecraft.script is empty")
	}
	if st, err := os.Stat(p); err != nil || !st.Mode().IsRegular() {
		return fmt.Errorf("minecraft.script %q not found", p)
	}
	if st, err := os.Stat(filepath.Join(filepath.Dir(p), "node_modules")); err != nil || !st.IsDir() {
		return fmt.Errorf("no node_modules next to %q: run npm install in that folder", p)
	}
	return nil
}

func realMCCommand(ctx context.Context, w billing.World, c *config.Config) (*exec.Cmd, error) {
	node, err := findNode(c)
	if err != nil {
		return nil, err
	}
	if err := checkScript(c.MCScript); err != nil {
		return nil, err
	}
	cmd := exec.CommandContext(ctx, node, c.MCScript)
	cmd.Dir = filepath.Dir(c.MCScript)
	cmd.Env = mcEnv(w, c)
	return cmd, nil
}

// mcEnv is everything the connector gets. Nothing else of our environment goes in.
func mcEnv(w billing.World, c *config.Config) []string {
	ver := strings.TrimSpace(c.MCVersion)
	if ver == "" {
		ver = "auto"
	}
	name := strings.TrimSpace(c.MCName)
	if name == "" {
		name = "Reina"
	}
	env := []string{
		"PATH=" + os.Getenv("PATH"),
		"HOME=" + os.TempDir(), // read-only root: node must not try to write into a home it has not got
		"MC_HOST=" + w.Host, fmt.Sprintf("MC_PORT=%d", w.Port), "MC_VERSION=" + ver,
		"MC_USER=" + name, "BOT_NAME=" + name, "BOT_ALIASES=" + strings.Join(uniq([]string{name, "Reina", "Рейна"}), ","), "MC_AUTH=offline",
		"MC_SKIN_URL=" + c.MCSkinURL, fmt.Sprintf("MC_SKIN_SLIM=%t", c.MCSkinSlim),
		"LLM_URL=" + strings.TrimRight(c.LLMBaseURL, "/") + "/chat/completions", "LLM_KEY=" + c.LLMAPIKey, "LLM_MODEL=" + c.LLMModel,
		fmt.Sprintf("MAX_MINUTES=%d", max(c.MCMinutes, 1)),
	}
	if c.DataDir != "" {
		if p := filepath.Join(c.DataDir, "mc_pass.secret"); isFile(p) {
			env = append(env, "MC_PASS_FILE="+p)
		}
	}
	return env
}

func isFile(p string) bool {
	st, err := os.Stat(p)
	return err == nil && st.Mode().IsRegular()
}

func uniq(xs []string) []string {
	seen := map[string]bool{}
	var out []string
	for _, x := range xs {
		if k := strings.ToLower(x); x != "" && !seen[k] {
			seen[k] = true
			out = append(out, x)
		}
	}
	return out
}

// Running says whether she is in this world now.
func (r *mcRunner) Running(id int) bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	_, ok := r.running[id]
	return ok
}

// Start sends her in without reports (the old way).
func (r *mcRunner) Start(w billing.World) error { return r.StartVisit(w, nil) }

// StartVisit sends her in. It fails at once when the feature is off, the address is closed, the connector is missing or too many
// visits are going; otherwise report gets joined (maybe), then exactly one failed or left.
func (r *mcRunner) StartVisit(w billing.World, report func(billing.VisitEvent)) error {
	c := r.cfg()
	if !c.MCEnabled {
		return errors.New("эта функция пока выключена")
	}
	if err := billing.CheckWorldAddr(w.Host, w.Port); err != nil {
		return err
	}
	if !mcAllowed(c.MCAllow, w.Host) {
		return errors.New("этот сервер не в списке разрешённых")
	}
	isOwner := c.PapikChatID != 0 && w.Owner == c.PapikChatID
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.closed {
		return errors.New("Рейна сейчас перезапускается, попробуй через минуту")
	}
	if _, ok := r.running[w.ID]; ok {
		return errors.New("она уже там")
	}
	if !isOwner && w.Owner != 0 {
		for _, v := range r.running {
			if v.owner == w.Owner {
				return errors.New("она уже в другом твоём мире: сначала выведи её оттуда")
			}
		}
	}
	if len(r.running) >= max(c.MCMax, 1) {
		return errors.New("сейчас все места заняты, попробуй чуть позже")
	}
	ctx, cancel := context.WithCancel(context.Background())
	cmd, err := r.command(ctx, w, c)
	if err != nil {
		cancel()
		r.alertOwner(fmt.Sprintf("Папик, Рейна не может ходить в Minecraft: %v", err))
		return errors.New("коннектор к Minecraft сейчас не установлен, хозяин уже знает")
	}
	v := &mcVisit{cancel: cancel, owner: w.Owner}
	events := make(chan billing.VisitEvent, 16)
	tag := fmt.Sprintf("minecraft #%d", w.ID)
	secrets := []string{c.LLMAPIKey, c.LLMBaseURL}
	cmd.Stdout = &lineWriter{fn: func(line string) {
		if e, ok := parseMCStatus(line); ok {
			log.Printf("%s: %s", tag, redactMC(strings.TrimSpace(line), secrets)) // kept whole: grep MCBOT_STATUS works on the log
			if e.State != "connecting" {
				events <- e
			}
			return
		}
		log.Printf("%s: %s", tag, redactMC(line, secrets))
	}}
	cmd.Stderr = &lineWriter{fn: func(line string) { log.Printf("%s stderr: %s", tag, redactMC(line, secrets)) }}
	ownGroupMC(cmd)
	var exited atomic.Bool
	cmd.Cancel = func() error { stopGroupMC(cmd.Process, 3*time.Second, exited.Load); return nil }
	cmd.WaitDelay = 6 * time.Second
	if err := cmd.Start(); err != nil {
		cancel()
		r.alertOwner(fmt.Sprintf("Папик, коннектор Minecraft не запустился: %v", redactMC(err.Error(), secrets)))
		return errors.New("коннектор не запустился, хозяин уже знает")
	}
	r.running[w.ID] = v
	r.wg.Add(1)
	go r.watch(v, cmd, &exited, events, w, c, report)
	return nil
}

// watch follows one visit until the process is gone, and makes the story clean whatever the connector printed.
func (r *mcRunner) watch(v *mcVisit, cmd *exec.Cmd, exited *atomic.Bool, events chan billing.VisitEvent, w billing.World, c *config.Config, report func(billing.VisitEvent)) {
	defer r.wg.Done()
	done := make(chan error, 1)
	go func() {
		err := cmd.Wait()
		exited.Store(true)
		done <- err
	}()
	joinT := time.NewTimer(time.Duration(max(c.MCJoinSecs, 1)) * time.Second)
	if c.MCJoinSecs <= 0 {
		joinT.Reset(90 * time.Second)
	}
	limitT := time.NewTimer(time.Duration(max(c.MCMinutes, 1)+1) * time.Minute)
	defer joinT.Stop()
	defer limitT.Stop()
	joined, final := false, false
	emit := func(e billing.VisitEvent) {
		if report != nil {
			report(e)
		}
	}
	handle := func(e billing.VisitEvent) {
		if final {
			return
		}
		switch e.State {
		case "joined":
			if !joined {
				joined = true
				joinT.Stop()
				emit(e)
			}
		case "failed", "left":
			final = true
			if joined {
				e.State = "left"
			} else {
				e.State = "failed"
				if e.Reason == "" {
					e.Reason = "unknown"
				}
			}
			emit(e)
		}
	}
	var werr error
loop:
	for {
		select {
		case e := <-events:
			handle(e)
		case <-joinT.C:
			if !joined {
				v.end("timeout")
			}
		case <-limitT.C:
			if joined {
				v.end("")
			} else {
				v.end("timeout")
			}
		case werr = <-done:
			break loop
		}
	}
	for drained := false; !drained; {
		select {
		case e := <-events:
			handle(e)
		default:
			drained = true
		}
	}
	if !final {
		why := v.reason()
		if joined {
			handle(billing.VisitEvent{State: "left", Reason: why})
		} else {
			if why == "" {
				why = "unknown"
			}
			handle(billing.VisitEvent{State: "failed", Reason: why})
		}
	}
	v.cancel()
	r.mu.Lock()
	delete(r.running, w.ID)
	r.mu.Unlock()
	log.Printf("minecraft #%d: visit ended (joined=%v, %v)", w.ID, joined, exitText(werr))
}

func exitText(err error) string {
	if err == nil {
		return "exit 0"
	}
	var ee *exec.ExitError
	if errors.As(err, &ee) {
		return ee.ProcessState.String()
	}
	return "wait failed"
}

// Stop takes her out.
func (r *mcRunner) Stop(id int) {
	r.mu.Lock()
	v := r.running[id]
	r.mu.Unlock()
	if v != nil {
		v.end("stopped")
	}
}

// Close ends every visit (the whole process group of each) and waits a little for them to go.
func (r *mcRunner) Close() {
	r.mu.Lock()
	r.closed = true
	for _, v := range r.running {
		v.end("shutdown")
	}
	r.mu.Unlock()
	ch := make(chan struct{})
	go func() { r.wg.Wait(); close(ch) }()
	select {
	case <-ch:
	case <-time.After(8 * time.Second):
		log.Printf("minecraft: some visits did not end in time")
	}
}

func (r *mcRunner) alertOwner(msg string) {
	log.Printf("minecraft: %s", msg)
	r.alertMu.Lock()
	defer r.alertMu.Unlock()
	if r.alert == nil || time.Since(r.lastAlert) < time.Hour {
		return
	}
	r.lastAlert = time.Now()
	go r.alert(msg)
}

// parseMCStatus reads "MCBOT_STATUS {json}".
func parseMCStatus(line string) (billing.VisitEvent, bool) {
	line = strings.TrimSpace(line)
	rest, ok := strings.CutPrefix(line, "MCBOT_STATUS")
	if !ok {
		return billing.VisitEvent{}, false
	}
	var j struct {
		State   string `json:"state"`
		Reason  string `json:"reason"`
		Detail  string `json:"detail"`
		Version string `json:"version"`
		Server  string `json:"server_version"`
	}
	if json.Unmarshal([]byte(strings.TrimSpace(rest)), &j) != nil {
		return billing.VisitEvent{}, false
	}
	switch j.State {
	case "joined", "failed", "left", "connecting":
	default:
		return billing.VisitEvent{}, false
	}
	return billing.VisitEvent{State: j.State, Reason: strings.ToLower(strings.TrimSpace(j.Reason)), Detail: j.Detail, Version: firstNonEmpty(j.Server, j.Version)}, true
}

var (
	mcURL    = regexp.MustCompile(`(?i)\b[a-z][a-z0-9+.-]*://\S+`)
	mcBotTok = regexp.MustCompile(`\b\d{5,}:[A-Za-z0-9_-]{30,}\b`)
	mcKV     = regexp.MustCompile(`(?i)\b(api[_-]?key|key|token|secret|password|pass|authorization|bearer)(\s*[=:]\s*|\s+)\S+`)
	mcLong   = regexp.MustCompile(`\b(sk|ghp|gho|xox[abp])[-_][A-Za-z0-9_-]{10,}`)
)

// redactMC makes a connector line safe for the log: no key of ours, no URL (they may carry tokens), no token-looking words.
func redactMC(line string, secrets []string) string {
	for _, s := range secrets {
		if s = strings.TrimSpace(s); len(s) >= 4 {
			line = strings.ReplaceAll(line, s, "***")
		}
	}
	line = mcURL.ReplaceAllString(line, "[url]")
	line = mcBotTok.ReplaceAllString(line, "[token]")
	line = mcLong.ReplaceAllString(line, "[token]")
	line = mcKV.ReplaceAllString(line, "$1=***")
	if r := []rune(line); len(r) > 400 {
		line = string(r[:400]) + "…"
	}
	return line
}

// lineWriter cuts a stream into lines (a line longer than 64 KB is cut too).
type lineWriter struct {
	mu  sync.Mutex
	buf []byte
	fn  func(string)
}

func (l *lineWriter) Write(p []byte) (int, error) {
	l.mu.Lock()
	defer l.mu.Unlock()
	l.buf = append(l.buf, p...)
	for {
		i := bytes.IndexByte(l.buf, '\n')
		if i < 0 {
			if len(l.buf) > 64<<10 {
				l.fn(string(l.buf))
				l.buf = l.buf[:0]
			}
			return len(p), nil
		}
		line := strings.TrimRight(string(l.buf[:i]), "\r")
		l.buf = l.buf[i+1:]
		if line != "" {
			l.fn(line)
		}
	}
}

// mcAllowed: an empty list lets any public server in; otherwise the host must equal an item, or end with it when the item starts with a dot.
func mcAllowed(list, host string) bool {
	list = strings.TrimSpace(list)
	if list == "" {
		return true
	}
	host = strings.ToLower(host)
	for _, it := range strings.Split(list, ",") {
		it = strings.ToLower(strings.TrimSpace(it))
		if it == "" {
			continue
		}
		if host == it || strings.HasPrefix(it, ".") && strings.HasSuffix(host, it) {
			return true
		}
	}
	return false
}

func firstNonEmpty(xs ...string) string {
	for _, x := range xs {
		if x = strings.TrimSpace(x); x != "" {
			return x
		}
	}
	return ""
}
