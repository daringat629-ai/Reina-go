package agent

import (
	"context"
	"fmt"
	"sync/atomic"
	"testing"
	"time"

	"kuni/internal/llm"
	"kuni/internal/telegram"
)

func fixed(v float64) func() float64 { return func() float64 { return v } }

func baseIn() presenceIn {
	return presenceIn{ReadMin: 2 * time.Second, ReadMax: 10 * time.Second, LateChance: 0.35, LateMin: 5 * time.Minute, LateMax: 40 * time.Minute}
}

func TestPlanPresenceOwnerIsQuickAndNeverLate(t *testing.T) {
	in := baseIn()
	in.Owner, in.Asleep, in.Night = true, true, true
	p := planPresence(in, fixed(0.99))
	if p.Late != 0 || p.Read > 1500*time.Millisecond {
		t.Fatalf("owner plan %+v", p)
	}
}

func TestPlanPresenceDayReadsAfterPause(t *testing.T) {
	p := planPresence(baseIn(), fixed(0.5))
	if p.Late != 0 || p.Read != 6*time.Second {
		t.Fatalf("plan %+v", p)
	}
	g := baseIn()
	g.Group = true
	if pg := planPresence(g, fixed(0.5)); pg.Read != 12*time.Second {
		t.Fatalf("group should notice later: %+v", pg)
	}
	live := baseIn()
	live.SinceLast = 20 * time.Second
	if pl := planPresence(live, fixed(0.5)); pl.Read >= 3*time.Second {
		t.Fatalf("live conversation needs no warm-up: %+v", pl)
	}
}

func TestPlanPresenceNightAndSleep(t *testing.T) {
	n := baseIn()
	n.Night = true
	if p := planPresence(n, fixed(0.1)); p.Late < 5*time.Minute || p.Late > 40*time.Minute {
		t.Fatalf("lucky roll at night should postpone: %+v", p)
	}
	if p := planPresence(n, fixed(0.9)); p.Late != 0 {
		t.Fatalf("unlucky roll must answer normally: %+v", p)
	}
	s := baseIn()
	s.Asleep = true
	if p := planPresence(s, fixed(0.99)); p.Late == 0 {
		t.Fatalf("asleep is always late: %+v", p)
	}
}

func TestLateReplyHoldsBackNewMessagesThenAnswersOnce(t *testing.T) {
	var n atomic.Int32
	r := newRig(t, newFakeLLM(t, func(int64) llm.ToolCall { // distinct texts: the anti-repeat check would swallow a second "hi~"
		c := sendCall(0)
		c.Function.Arguments = fmt.Sprintf(`{"text":"answer number %d"}`, n.Add(1))
		return c
	}))
	ctx, cancel := context.WithCancel(context.Background())
	r.start(t, ctx, cancel)
	chat := telegram.Chat{ID: 7, Title: "Bob", Kind: telegram.ChatPrivate, IsMember: true}
	r.tg.Incoming(chat, 7, "Bob", "hey")
	waitFor(t, "initial turn", func() bool { return len(r.tg.SentTexts()) == 1 }) // presence off: answers at once

	r.ag.inbox.postpone(ctx, 7, 150*time.Millisecond)
	r.tg.Incoming(chat, 7, "Bob", "are you there?")
	time.Sleep(60 * time.Millisecond) // debounce is 10ms: without the hold she would have answered already
	if n := len(r.tg.SentTexts()); n != 1 {
		t.Fatalf("answered during the hold: %v", r.tg.SentTexts())
	}
	waitFor(t, "late answer", func() bool { return len(r.tg.SentTexts()) == 2 })
}

func TestReadPauseIsInterruptible(t *testing.T) {
	r := newRig(t, newFakeLLM(t, sendCall))
	ctx, cancel := context.WithCancel(context.Background())
	go func() { time.Sleep(20 * time.Millisecond); cancel() }()
	start := time.Now()
	if r.ag.readPause(ctx, 5*time.Second) {
		t.Fatal("should report interruption")
	}
	if time.Since(start) > time.Second {
		t.Fatal("did not stop")
	}
}

func TestLinksAndDocumentsUnlockReadTools(t *testing.T) {
	f := newFakeLLM(t, sendCall)
	r := newRig(t, f)
	r.ag.Cfg.Get().LazyTools, r.ag.Cfg.Get().ReadLinks = true, true
	ctx, cancel := context.WithCancel(context.Background())
	r.start(t, ctx, cancel)
	chat := telegram.Chat{ID: 55, Title: "Bob", Kind: telegram.ChatPrivate, IsMember: true}
	r.tg.Incoming(chat, 55, "Bob", "привет")
	waitFor(t, "first reply", func() bool { return len(r.tg.SentTexts()) == 1 })
	f.mu.Lock()
	first := toolNames(f.calls[len(f.calls)-1])
	f.mu.Unlock()
	if first["read_link"] || first["read_document"] {
		t.Fatalf("read tools must stay hidden for plain talk: %v", first)
	}
	r.tg.Incoming(chat, 55, "Bob", "глянь https://example.com/a")
	waitFor(t, "llm saw the link", func() bool {
		f.mu.Lock()
		defer f.mu.Unlock()
		return toolNames(f.calls[len(f.calls)-1])["read_link"]
	})
}

func TestAnswersInAForumGoToTheTopicOfTheLastMessage(t *testing.T) {
	var n atomic.Int32
	f := newFakeLLM(t, func(int64) llm.ToolCall {
		c := sendCall(0)
		c.Function.Arguments = fmt.Sprintf(`{"text":"answer %d"}`, n.Add(1))
		return c
	})
	r := newRig(t, f)
	chat := telegram.Chat{ID: -300, Title: "Forum", Kind: telegram.ChatGroup, IsMember: true}
	var seen atomic.Int64
	r.tg.OnSend = func(ctx context.Context, chatID int64) { seen.Store(telegram.ThreadFrom(ctx)) }
	ctx, cancel := context.WithCancel(context.Background())
	r.start(t, ctx, cancel)
	r.tg.Incoming(chat, 7, "Bob", "Reina, ты тут?") // no topic: the answer carries no thread
	waitFor(t, "answer", func() bool { return len(r.tg.SentTexts()) >= 1 })
	if seen.Load() != 0 {
		t.Fatalf("unexpected thread %d", seen.Load())
	}
	time.Sleep(200 * time.Millisecond)
	r.tg.IncomingIn(chat, 7, "Bob", "а теперь здесь", 43)
	waitFor(t, "second answer", func() bool { return seen.Load() == 43 })
}
