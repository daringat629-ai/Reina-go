package tools

import (
	"context"
	"fmt"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"

	"kuni/internal/browser"
	"kuni/internal/desktop"
	"kuni/internal/live"
	"kuni/internal/telegram"
	"kuni/internal/tgui"
	"kuni/internal/web"
)

// Runtime is the state the tools share between chats and turns: the one browser, the one desktop, her background
// shell jobs, her Telegram screen, the pages she read a moment ago and the locks of the small files tools write.
// It used to be package variables (one browser for the whole process, test or not); now the program makes one in
// app and every test makes its own.
type Runtime struct {
	Browser *browser.Browser
	Desktop *desktop.Desktop
	Feed    *live.Feed // what she does, for the panel (nil = nobody watches)

	jobs  jobList
	pages pageCache

	tguiMu sync.Mutex
	tgui   *tgui.UI

	stickers sync.Mutex // stickers.json
	notes    sync.Mutex // notes.json
	mail     sync.Mutex // the daily count of sent letters

	ctx    context.Context // background jobs run in it; Close ends them
	cancel context.CancelFunc
}

// NewRuntime makes the shared state (nothing starts until a tool needs it).
func NewRuntime(feed *live.Feed) *Runtime {
	ctx, cancel := context.WithCancel(context.Background())
	return &Runtime{Browser: browser.New(), Desktop: desktop.New(), Feed: feed, ctx: ctx, cancel: cancel}
}

// Close stops everything the tools started: background jobs, the browser and the desktop.
func (rt *Runtime) Close() {
	if rt == nil {
		return
	}
	rt.cancel()
	rt.StopScreens()
}

// StopScreens closes the browser and the desktop with everything started on them (for /stop).
func (rt *Runtime) StopScreens() {
	rt.Browser.Close()
	rt.Desktop.Close()
}

// Screens tells whether the browser and the desktop are up (for /status and the panel).
func (rt *Runtime) Screens() (browserUp, desktopUp bool) {
	return rt.Browser.Live(), rt.Desktop.Live()
}

// Frame is the current picture of what she works on, for the panel: src is "desktop" or "browser". ok is false when
// that screen is not running; meta is "x,y" of the mouse pointer on the desktop (empty otherwise).
func (rt *Runtime) Frame(ctx context.Context, src string) (data []byte, meta string, ok bool, err error) {
	switch src {
	case "desktop":
		data, ok, err = rt.Desktop.Frame()
		if x, y, set := rt.Desktop.Pointer(); ok && set {
			meta = fmt.Sprintf("%d,%d", x, y)
		}
		return
	case "browser":
		data, ok, err = rt.Browser.Frame(ctx)
		return
	}
	return nil, "", false, fmt.Errorf("unknown screen %q", src)
}

// screen is her Telegram screen (one per program: she keeps her place, the open chat and the scroll, between turns).
func (rt *Runtime) screen(tg telegram.Client) *tgui.UI {
	rt.tguiMu.Lock()
	defer rt.tguiMu.Unlock()
	if rt.tgui == nil {
		rt.tgui = tgui.New(tg)
		rt.tgui.Feed = rt.Feed
	}
	return rt.tgui
}

// --- background shell jobs ---

// bgJob is a shell command that runs in the background; when it ends she is woken in the chat that started it.
type bgJob struct {
	ID    int
	Cmd   string
	Chat  int64
	Start time.Time
	Done  bool
	Code  int
	Log   string
	End   time.Time
}

type jobList struct {
	sync.Mutex
	list []*bgJob
	next int
}

const maxRunningJobs = 3

// runningLocked counts the jobs still running (the caller holds the lock).
func (j *jobList) runningLocked() (n int) {
	for _, x := range j.list {
		if !x.Done {
			n++
		}
	}
	return n
}

// nextIDLocked is the number of a new job: past every log already in dir, so a restart never overwrites the output
// of an earlier job (the numbers used to start at 1 again).
func (j *jobList) nextIDLocked(dir string) int {
	if j.next == 0 {
		j.next = 1
		if ents, err := os.ReadDir(dir); err == nil {
			for _, e := range ents {
				if n, err := strconv.Atoi(strings.TrimSuffix(e.Name(), ".log")); err == nil && n >= j.next {
					j.next = n + 1
				}
			}
		}
	}
	id := j.next
	j.next++
	return id
}

// --- pages read a moment ago ---

type cachedPage struct {
	page web.Page
	at   time.Time
}

// pageCache keeps the pages read in the last minutes: reading on through a long page must not download it again.
type pageCache struct {
	mu    sync.Mutex
	pages map[string]cachedPage
}

const (
	pageTTL   = 10 * time.Minute
	pageLimit = 30
)

func (c *pageCache) get(link string) (web.Page, bool) {
	c.mu.Lock()
	defer c.mu.Unlock()
	p, ok := c.pages[link]
	if !ok || time.Since(p.at) >= pageTTL {
		return web.Page{}, false
	}
	return p.page, true
}

func (c *pageCache) put(link string, p web.Page) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.pages == nil {
		c.pages = map[string]cachedPage{}
	}
	if len(c.pages) >= pageLimit { // drop the oldest
		var oldest string
		for k, v := range c.pages {
			if oldest == "" || v.at.Before(c.pages[oldest].at) {
				oldest = k
			}
		}
		delete(c.pages, oldest)
	}
	c.pages[link] = cachedPage{p, time.Now()}
}
