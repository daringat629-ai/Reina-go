package telegram

import (
	"context"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"
)

func formatted(text string) obj { return obj{"@type": "formattedText", "text": text} }

func localFile(path string) obj { return obj{"@type": "inputFileLocal", "path": path} }

func replyTo(id int64) any {
	if id == 0 {
		return nil
	}
	return obj{"@type": "inputMessageReplyToMessage", "message_id": id}
}

func (c *TDClient) send(ctx context.Context, chatID, reply int64, content obj) (Message, error) {
	return c.sendWith(ctx, chatID, reply, content, nil)
}

func (c *TDClient) sendWith(ctx context.Context, chatID, reply int64, content, options obj) (Message, error) {
	req := obj{"@type": "sendMessage", "chat_id": chatID, "reply_to": replyTo(reply), "input_message_content": content}
	if options != nil {
		req["options"] = options
	}
	c.addThread(ctx, req, chatID, reply)
	r, err := c.api(ctx, req)
	if err != nil {
		return Message{}, err
	}
	if r, err = c.settle(ctx, r, sendWait(content)); err != nil {
		return Message{}, err
	}
	return c.parseMessage(ctx, r), nil
}

// addThread routes a send into a forum topic: the topic of the message replied to, else the one on ctx.
// Both field names are set (older tdlib: message_thread_id, newer: topic_id); the unknown one is ignored.
func (c *TDClient) addThread(ctx context.Context, req obj, chatID, reply int64) {
	var t int64
	if reply != 0 { // the topic of the message being answered is the right one, whatever the session last looked at
		if v, ok := c.threads.Load(evKey(chatID, reply)); ok {
			t = v.(int64)
		}
	}
	if t == 0 {
		t = ThreadFrom(ctx)
	}
	if t != 0 {
		req["message_thread_id"] = t
		req["topic_id"] = obj{"@type": "messageTopicForum", "forum_topic_id": t}
	}
}

func (c *TDClient) SendText(ctx context.Context, chatID int64, text string, reply int64) (Message, error) {
	return c.send(ctx, chatID, reply, obj{"@type": "inputMessageText", "text": withMentions(text)})
}

func (c *TDClient) SendPoll(ctx context.Context, chatID int64, question string, options []string, anonymous, multiple bool, reply int64) (Message, error) {
	if len(options) < 2 || len(options) > 10 {
		return Message{}, errors.New("a poll needs 2-10 options")
	}
	return c.send(ctx, chatID, reply, c.pollContent(question, options, anonymous, multiple))
}

func (c *TDClient) VotePoll(ctx context.Context, chatID, msgID int64, options []int) error {
	ids := make([]int, 0, len(options))
	ids = append(ids, options...)
	_, err := c.api(ctx, obj{"@type": "setPollAnswer", "chat_id": chatID, "message_id": msgID, "option_ids": ids})
	return err
}

func (c *TDClient) Pin(ctx context.Context, chatID, msgID int64, silent bool) error {
	_, err := c.api(ctx, obj{"@type": "pinChatMessage", "chat_id": chatID, "message_id": msgID, "disable_notification": silent, "only_for_self": false})
	return err
}

func (c *TDClient) Unpin(ctx context.Context, chatID, msgID int64) error {
	_, err := c.api(ctx, obj{"@type": "unpinChatMessage", "chat_id": chatID, "message_id": msgID})
	return err
}

func (c *TDClient) outboxFile(name string, data []byte) (string, error) {
	if len(data) == 0 { // telegram answers such a send with "InputFile is not specified"
		return "", fmt.Errorf("file %q is empty, nothing to send", name)
	}
	dir, err := filepath.Abs(filepath.Join(c.cfg.DBDir, "outbox"))
	if err != nil {
		return "", err
	}
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return "", err
	}
	p := filepath.Join(dir, fmt.Sprintf("%d_%s", time.Now().UnixNano(), name))
	return p, os.WriteFile(p, data, 0o644)
}

func (c *TDClient) SendPhoto(ctx context.Context, chatID int64, data []byte, caption string, reply int64) (Message, error) {
	p, err := c.outboxFile("photo.jpg", data)
	if err != nil {
		return Message{}, err
	}
	return c.send(ctx, chatID, reply, c.mediaContent("photo", localFile(p), withMentions(caption), nil))
}

func (c *TDClient) SendDocument(ctx context.Context, chatID int64, name string, data []byte, caption string, reply int64) (Message, error) {
	p, err := c.outboxFile(filepath.Base(name), data)
	if err != nil {
		return Message{}, err
	}
	return c.send(ctx, chatID, reply, c.mediaContent("document", localFile(p), withMentions(caption), nil))
}

func (c *TDClient) SendVoice(ctx context.Context, chatID int64, data []byte, reply int64) (Message, error) {
	p, err := c.outboxFile("voice.ogg", data)
	if err != nil {
		return Message{}, err
	}
	return c.send(ctx, chatID, reply, c.mediaContent("voice_note", localFile(p), nil, nil))
}

func (c *TDClient) SendSticker(ctx context.Context, chatID int64, fileID string, reply int64) (Message, error) {
	id, err := strconv.ParseInt(fileID, 10, 64)
	if err != nil || id <= 0 {
		return Message{}, fmt.Errorf("bad sticker file id %q", fileID)
	}
	return c.send(ctx, chatID, reply, c.mediaContent("sticker", obj{"@type": "inputFileId", "id": id}, nil, nil))
}

// Edit changes text; for media messages it edits the caption (see the C++ fix "caption editing for media messages").
func (c *TDClient) Edit(ctx context.Context, chatID, msgID int64, text string) error {
	m, err := c.api(ctx, obj{"@type": "getMessage", "chat_id": chatID, "message_id": msgID})
	if err != nil {
		return err
	}
	if typ(sub(m, "content")) == "messageText" {
		_, err = c.call(ctx, obj{"@type": "editMessageText", "chat_id": chatID, "message_id": msgID,
			"input_message_content": obj{"@type": "inputMessageText", "text": formatted(text)}})
	} else {
		_, err = c.call(ctx, obj{"@type": "editMessageCaption", "chat_id": chatID, "message_id": msgID, "caption": formatted(text)})
	}
	return err
}

func (c *TDClient) Delete(ctx context.Context, chatID, msgID int64) error {
	_, err := c.api(ctx, obj{"@type": "deleteMessages", "chat_id": chatID, "message_ids": []int64{msgID}, "revoke": true})
	return err
}

func (c *TDClient) Forward(ctx context.Context, from, msgID, to int64) error {
	r, err := c.api(ctx, obj{"@type": "forwardMessages", "chat_id": to, "from_chat_id": from, "message_ids": []int64{msgID}})
	if err != nil {
		return err
	}
	list := arr(r, "messages")
	if len(list) == 0 {
		return nil // an older tdlib answered "ok"
	}
	m := toObj(list[0])
	if m == nil { // tdlib puts null in place of a message it cannot forward (protected content, deleted...)
		return errors.New("this message cannot be forwarded")
	}
	_, err = c.settle(ctx, m, sendWaitText)
	return err
}

func (c *TDClient) React(ctx context.Context, chatID, msgID int64, emoji string) error {
	emoji = strings.ReplaceAll(emoji, "️", "") // the chat's reaction list is stored without the variation selector
	_, err := c.api(ctx, obj{"@type": "addMessageReaction", "chat_id": chatID, "message_id": msgID,
		"reaction_type": obj{"@type": "reactionTypeEmoji", "emoji": emoji}, "is_big": false, "update_recent_reactions": true})
	return err
}

func (c *TDClient) Typing(ctx context.Context, chatID int64) error {
	_, err := c.api(ctx, obj{"@type": "sendChatAction", "chat_id": chatID, "action": obj{"@type": "chatActionTyping"}})
	return err
}
