// Package admin is the password-protected web panel at /admin: status, live log, pause/resume,
// settings, prompts, memory and the log of shell commands. It is a single embedded page plus a small JSON API.
package admin

import (
	"crypto/sha256"
	"crypto/subtle"
	_ "embed"
	"encoding/json"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"

	"kuni/internal/config"
	"kuni/internal/diary"
	"kuni/internal/memory"
	"kuni/internal/metrics"
	"kuni/internal/mood"
	"kuni/internal/prompts"
	"kuni/internal/util"
)

//go:embed page.html
var page []byte

// Controller is what the panel needs from the agent.
type Controller interface {
	Paused() bool
	SetPaused(bool)
	SessionSummaries() []string
}

type Panel struct {
	Cfg        func() *config.Config
	ConfigPath string
	Prompts    *prompts.Store
	Diary      *diary.Diary
	Metrics    *metrics.Registry
	Log        *util.LogBuf
	Mood       *mood.Mood // nil when the scale is not available
	Ctl        Controller // nil when Telegram is off
	Started    time.Time

	mu    sync.Mutex
	fails map[string][]time.Time
}

const cookieName = "kuni_admin"

// MinTokenLen is the shortest accepted admin_token.
const MinTokenLen = 12

// Enabled reports whether the configured token is long enough to switch the panel on.
func Enabled(c *config.Config) bool { return len(c.AdminToken) >= MinTokenLen }

// Mount registers /admin and /admin/api/*.
func (p *Panel) Mount(mux *http.ServeMux) {
	p.fails = map[string][]time.Time{}
	mux.HandleFunc("/admin", p.index)
	mux.HandleFunc("/admin/", p.index)
	api := func(path string, h http.HandlerFunc) { mux.HandleFunc("/admin/api/"+path, p.guard(h)) }
	api("status", p.status)
	api("mood", p.moodAPI)
	api("pause", p.pause)
	api("log", p.logTail)
	api("config", p.configAPI)
	api("prompts", p.promptsAPI)
	api("memory", p.memoryAPI)
	api("diary", p.diaryAPI)
	api("shell", p.shellLog)
}

// --- auth ---------------------------------------------------------------

func clientIP(r *http.Request) string {
	h, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		return r.RemoteAddr
	}
	return h
}

func (p *Panel) blocked(ip string) bool {
	p.mu.Lock()
	defer p.mu.Unlock()
	cut := time.Now().Add(-10 * time.Minute)
	kept := p.fails[ip][:0]
	for _, t := range p.fails[ip] {
		if t.After(cut) {
			kept = append(kept, t)
		}
	}
	p.fails[ip] = kept
	return len(kept) >= 8
}

func (p *Panel) fail(ip string) {
	p.mu.Lock()
	p.fails[ip] = append(p.fails[ip], time.Now())
	p.mu.Unlock()
	time.Sleep(400 * time.Millisecond) // slow brute force down
}

func same(a, b string) bool {
	ha, hb := sha256.Sum256([]byte(a)), sha256.Sum256([]byte(b))
	return subtle.ConstantTimeCompare(ha[:], hb[:]) == 1
}

// authed checks the bearer header or the cookie (never a query string, except on the index page).
func (p *Panel) authed(r *http.Request) bool {
	tok := p.Cfg().AdminToken
	if len(tok) < MinTokenLen {
		return false
	}
	if h := r.Header.Get("Authorization"); strings.HasPrefix(h, "Bearer ") && same(strings.TrimPrefix(h, "Bearer "), tok) {
		return true
	}
	if c, err := r.Cookie(cookieName); err == nil && same(c.Value, tok) {
		return true
	}
	return false
}

func (p *Panel) guard(h http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if !Enabled(p.Cfg()) {
			http.NotFound(w, r)
			return
		}
		ip := clientIP(r)
		if p.blocked(ip) {
			http.Error(w, "too many attempts, try later", http.StatusTooManyRequests)
			return
		}
		if !p.authed(r) {
			p.fail(ip)
			http.Error(w, "unauthorized", http.StatusUnauthorized)
			return
		}
		if r.Method != http.MethodGet && r.Header.Get("X-Admin") != "1" {
			http.Error(w, "missing X-Admin header", http.StatusForbidden)
			return
		}
		h(w, r)
	}
}

func (p *Panel) index(w http.ResponseWriter, r *http.Request) {
	if (r.URL.Path != "/admin" && r.URL.Path != "/admin/") || !Enabled(p.Cfg()) {
		http.NotFound(w, r)
		return
	}
	ip := clientIP(r)
	if t := r.URL.Query().Get("token"); t != "" {
		if p.blocked(ip) {
			http.Error(w, "too many attempts, try later", http.StatusTooManyRequests)
			return
		}
		if len(p.Cfg().AdminToken) >= MinTokenLen && same(t, p.Cfg().AdminToken) {
			http.SetCookie(w, &http.Cookie{Name: cookieName, Value: t, Path: "/admin", HttpOnly: true, SameSite: http.SameSiteStrictMode, MaxAge: 30 * 24 * 3600})
			http.Redirect(w, r, "/admin", http.StatusSeeOther)
			return
		}
		p.fail(ip)
	}
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("X-Frame-Options", "DENY")
	w.Header().Set("Referrer-Policy", "no-referrer")
	_, _ = w.Write(page)
}

// --- helpers ------------------------------------------------------------

func writeJSON(w http.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	_ = json.NewEncoder(w).Encode(v)
}

func fail(w http.ResponseWriter, code int, msg string) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(map[string]string{"error": msg})
}

func readBody(r *http.Request, v any) error {
	r.Body = http.MaxBytesReader(nil, r.Body, 1<<20)
	return json.NewDecoder(r.Body).Decode(v)
}

// --- endpoints ----------------------------------------------------------

func (p *Panel) status(w http.ResponseWriter, r *http.Request) {
	c := p.Cfg()
	tokens := map[string]map[string]float64{}
	if p.Metrics != nil {
		for _, purpose := range []string{"reply", "ask", "compact", "diary", "sleep", "image", "other"} {
			var in, out float64
			models := []string{c.LLMModel}
			if c.LightModel != "" && c.LightModel != c.LLMModel {
				models = append(models, c.LightModel)
			}
			for _, m := range models {
				in += p.Metrics.Get("kuni_llm_tokens_total", map[string]string{"model": m, "purpose": purpose, "direction": "input"})
				out += p.Metrics.Get("kuni_llm_tokens_total", map[string]string{"model": m, "purpose": purpose, "direction": "output"})
			}
			if in > 0 || out > 0 {
				tokens[purpose] = map[string]float64{"in": in, "out": out}
			}
		}
	}
	st := map[string]any{
		"character": c.CharacterName, "model": c.LLMModel, "light_model": c.LightModel, "base_url": c.LLMBaseURL, "lockdown": c.Lockdown,
		"mode": c.Mode, "telegram": c.TelegramEnabled, "owner_tools": c.OwnerTools && c.PapikChatID != 0,
		"uptime_secs": int(time.Since(p.Started).Seconds()), "tokens": tokens, "paused": false, "sessions": []string{},
	}
	if p.Mood != nil && c.MoodEnabled {
		lvl := p.Mood.Level()
		st["mood"] = map[string]any{"level": lvl, "name": mood.Name(lvl)}
	}
	if p.Ctl != nil {
		st["paused"] = p.Ctl.Paused()
		s := p.Ctl.SessionSummaries()
		sort.Strings(s)
		st["sessions"] = s
	}
	writeJSON(w, st)
}

func (p *Panel) pause(w http.ResponseWriter, r *http.Request) {
	if p.Ctl == nil {
		fail(w, 400, "Telegram выключен, паузить нечего")
		return
	}
	var in struct {
		Paused bool `json:"paused"`
	}
	if err := readBody(r, &in); err != nil {
		fail(w, 400, "bad json")
		return
	}
	p.Ctl.SetPaused(in.Paused)
	writeJSON(w, map[string]bool{"paused": p.Ctl.Paused()})
}

func (p *Panel) logTail(w http.ResponseWriter, r *http.Request) {
	lines := []string{}
	if p.Log != nil {
		lines = p.Log.Tail(300)
	}
	writeJSON(w, map[string]any{"lines": lines})
}

type keyView struct {
	Section string `json:"section"`
	Name    string `json:"name"`
	Comment string `json:"comment"`
	Kind    string `json:"kind"`
	Secret  bool   `json:"secret"`
	Value   string `json:"value"`
	Set     bool   `json:"set"`
}

func (p *Panel) configAPI(w http.ResponseWriter, r *http.Request) {
	switch r.Method {
	case http.MethodGet:
		c := p.Cfg()
		var out []keyView
		for _, k := range config.Keys() {
			v := c.Value(k.Section, k.Name)
			kv := keyView{Section: k.Section, Name: k.Name, Comment: k.Comment, Kind: k.Kind, Secret: k.Secret, Value: v}
			if k.Secret {
				kv.Set, kv.Value = v != "", "" // secrets are write-only
			}
			out = append(out, kv)
		}
		writeJSON(w, out)
	case http.MethodPost:
		var in struct{ Section, Key, Value string }
		if err := readBody(r, &in); err != nil {
			fail(w, 400, "bad json")
			return
		}
		if err := config.SetKey(p.ConfigPath, in.Section, in.Key, in.Value); err != nil {
			fail(w, 400, err.Error())
			return
		}
		writeJSON(w, map[string]string{"ok": "сохранено, применится за пару секунд"})
	default:
		fail(w, 405, "method not allowed")
	}
}

func (p *Panel) promptsAPI(w http.ResponseWriter, r *http.Request) {
	name := r.URL.Query().Get("name")
	switch r.Method {
	case http.MethodGet:
		if name == "" {
			writeJSON(w, p.Prompts.Names())
			return
		}
		raw, err := p.Prompts.Raw(name)
		if err != nil {
			fail(w, 404, "no such prompt")
			return
		}
		def, _ := p.Prompts.Default(name)
		writeJSON(w, map[string]any{"name": name, "content": raw, "is_default": raw == def})
	case http.MethodPost:
		var in struct {
			Name, Content string
			Reset         bool
		}
		if err := readBody(r, &in); err != nil {
			fail(w, 400, "bad json")
			return
		}
		content := in.Content
		if in.Reset {
			def, err := p.Prompts.Default(in.Name)
			if err != nil {
				fail(w, 404, "no such prompt")
				return
			}
			content = def
		}
		if strings.TrimSpace(content) == "" {
			fail(w, 400, "empty prompt")
			return
		}
		if err := p.Prompts.Write(in.Name, content); err != nil {
			fail(w, 400, err.Error())
			return
		}
		writeJSON(w, map[string]string{"ok": "сохранено (старая версия лежит рядом как .bak)"})
	default:
		fail(w, 405, "method not allowed")
	}
}

func (p *Panel) memoryAPI(w http.ResponseWriter, r *http.Request) {
	wm := memory.WorkingMemory{Path: p.Cfg().WorkingMemoryFile}
	switch r.Method {
	case http.MethodGet:
		s, _ := wm.Load()
		writeJSON(w, map[string]string{"content": s})
	case http.MethodPost:
		var in struct{ Content string }
		if err := readBody(r, &in); err != nil {
			fail(w, 400, "bad json")
			return
		}
		if err := wm.Save(in.Content); err != nil {
			fail(w, 500, err.Error())
			return
		}
		writeJSON(w, map[string]string{"ok": "сохранено"})
	default:
		fail(w, 405, "method not allowed")
	}
}

func (p *Panel) diaryAPI(w http.ResponseWriter, r *http.Request) {
	switch r.Method {
	case http.MethodGet:
		es, err := p.Diary.Load()
		if err != nil {
			fail(w, 500, err.Error())
			return
		}
		sort.Slice(es, func(i, j int) bool { return es[i].ID > es[j].ID })
		type row struct {
			ID   string  `json:"id"`
			Body string  `json:"body"`
			Conf float64 `json:"confidence"`
		}
		out := []row{}
		for i, e := range es {
			if i >= 60 {
				break
			}
			out = append(out, row{e.ID, e.Body, e.Meta.Confidence})
		}
		writeJSON(w, map[string]any{"total": len(es), "entries": out})
	case http.MethodPost:
		var in struct{ Delete string }
		if err := readBody(r, &in); err != nil || in.Delete == "" {
			fail(w, 400, "bad json")
			return
		}
		if strings.ContainsAny(in.Delete, `/\.`) {
			fail(w, 400, "bad id")
			return
		}
		if err := p.Diary.Remove(in.Delete); err != nil {
			fail(w, 400, err.Error())
			return
		}
		writeJSON(w, map[string]string{"ok": "удалено"})
	default:
		fail(w, 405, "method not allowed")
	}
}

func (p *Panel) shellLog(w http.ResponseWriter, r *http.Request) {
	b, _ := os.ReadFile(filepath.Join(p.Cfg().DataDir, "shell.log"))
	lines := strings.Split(strings.TrimRight(string(b), "\n"), "\n")
	if len(lines) == 1 && lines[0] == "" {
		lines = []string{}
	}
	if len(lines) > 100 {
		lines = lines[len(lines)-100:]
	}
	writeJSON(w, map[string]any{"lines": lines})
}

func (p *Panel) moodAPI(w http.ResponseWriter, r *http.Request) {
	if p.Mood == nil {
		fail(w, 400, "шкала настроения недоступна")
		return
	}
	var in struct{ Value int }
	if err := readBody(r, &in); err != nil || in.Value < 0 || in.Value > 100 {
		fail(w, 400, "нужно число от 0 до 100")
		return
	}
	lvl := p.Mood.Set(in.Value)
	writeJSON(w, map[string]any{"level": lvl, "name": mood.Name(lvl)})
}
