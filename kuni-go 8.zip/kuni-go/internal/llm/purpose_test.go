package llm

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
)

func TestUsageCarriesPurpose(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		json.NewEncoder(w).Encode(map[string]any{
			"choices": []any{map[string]any{"message": map[string]any{"role": "assistant", "content": "ok"}}},
			"usage":   map[string]any{"prompt_tokens": 123, "completion_tokens": 7},
		})
	}))
	defer srv.Close()
	c := New(srv.URL+"/", srv.URL+"/", "", "m", "e", 5*time.Second)
	var got []string
	var in int
	c.OnUsage = func(model, purpose string, p, o int) { got = append(got, purpose); in += p }
	if _, err := c.Chat(WithPurpose(context.Background(), "ask"), "s", []Message{{Role: "user", Content: "x"}}); err != nil {
		t.Fatal(err)
	}
	if _, err := c.Chat(context.Background(), "s", []Message{{Role: "user", Content: "x"}}); err != nil {
		t.Fatal(err)
	}
	if len(got) != 2 || got[0] != "ask" || got[1] != "other" || in != 246 {
		t.Fatalf("got %v in=%d", got, in)
	}
}

func TestReasoningControl(t *testing.T) {
	var body map[string]any
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_ = json.NewDecoder(r.Body).Decode(&body)
		json.NewEncoder(w).Encode(map[string]any{"choices": []any{map[string]any{"message": map[string]any{"role": "assistant", "content": "ok"}}}})
	}))
	defer srv.Close()
	c := New(srv.URL+"/", srv.URL+"/", "", "m", "e", 5*time.Second)
	for _, tc := range []struct{ set, key, val string }{{"", "", ""}, {"off", "enabled", "false"}, {"low", "effort", "low"}} {
		s := c.settings()
		s.Reasoning = tc.set
		c.Update(s)
		if _, err := c.Chat(context.Background(), "s", []Message{{Role: "user", Content: "x"}}); err != nil {
			t.Fatal(err)
		}
		r, has := body["reasoning"].(map[string]any)
		if tc.set == "" {
			if has {
				t.Fatal("reasoning must be absent by default")
			}
			continue
		}
		if !has || (tc.key == "enabled" && r["enabled"] != false) || (tc.key == "effort" && r["effort"] != "low") {
			t.Fatalf("%s: %v", tc.set, body["reasoning"])
		}
	}
}
