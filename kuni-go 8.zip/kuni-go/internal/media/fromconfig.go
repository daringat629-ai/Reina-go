package media

import "kuni/internal/config"

// FromConfig builds the services enabled in config.toml; the rest stay Disabled.
func FromConfig(c *config.Config) Services {
	s := NewDisabled()
	if c.SDEnabled {
		s.Images = StableDiffusion{BaseURL: c.SDURL}
	}
	if c.STTEnabled {
		s.STT = Whisper{BaseURL: c.STTURL, Model: c.STTModel}
	}
	switch c.TTSBackend {
	case "openai":
		s.TTS = OpenAITTS{BaseURL: c.TTSURL, Key: c.TTSKey, Model: c.TTSModel, Voice: c.TTSVoice}
	case "elevenlabs":
		s.TTS = ElevenLabs{Key: c.TTSKey, VoiceID: c.TTSVoice, Model: c.TTSModel}
	}
	if c.WebSearchEnabled {
		s.Web = WebSearch{URL: c.WebSearchURL, Key: c.WebSearchKey}
	}
	s.Video = FFmpeg{Path: c.FFmpegPath}
	return s
}
