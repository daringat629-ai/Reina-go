package tools

import (
	"context"
	"reflect"
	"testing"

	"kuni/internal/config"
	"kuni/internal/metrics"
	"kuni/internal/prompts"
	"kuni/internal/telegram"
)

func TestSendSplitsLines(t *testing.T) {
	ps, err := prompts.NewStore(t.TempDir(), prompts.Vars{})
	if err != nil {
		t.Fatal(err)
	}
	tg := telegram.NewFake()
	d := Deps{TG: tg, Prompts: ps, Metrics: metrics.New(), Cfg: func() *config.Config { return &config.Config{} }}
	chat := telegram.Chat{ID: 7, Title: "A", Kind: telegram.ChatPrivate, IsMember: true}
	tool := sendTool(d, chat)

	if _, err := tool.Run(context.Background(), Args{"text": "hi\n\ni'm here~\nwhat's up?"}); err != nil {
		t.Fatal(err)
	}
	if got, want := tg.SentTexts(), []string{"hi", "i'm here~", "what's up?"}; !reflect.DeepEqual(got, want) {
		t.Fatalf("got %q want %q", got, want)
	}
	// more than 5 lines: tail merged into the 5th message
	tg2 := telegram.NewFake()
	d.TG = tg2
	if _, err := sendTool(d, chat).Run(context.Background(), Args{"text": "1\n2\n3\n4\n5\n6\n7"}); err != nil {
		t.Fatal(err)
	}
	if got := tg2.SentTexts(); len(got) != 5 || got[4] != "5 6 7" {
		t.Fatalf("got %q", got)
	}
	// code is never split
	tg3 := telegram.NewFake()
	d.TG = tg3
	code := "```\na\nb\n```"
	if _, err := sendTool(d, chat).Run(context.Background(), Args{"text": code}); err != nil {
		t.Fatal(err)
	}
	if got := tg3.SentTexts(); len(got) != 1 || got[0] != code {
		t.Fatalf("got %q", got)
	}
}
