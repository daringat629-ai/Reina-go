package tools

import (
	"context"
	"strings"
	"testing"
)

func names(r *Registry) string {
	var out []string
	for _, d := range r.Defs() {
		out = append(out, d.Function.Name)
	}
	return strings.Join(out, ",")
}

func mk(name string) Tool {
	return Tool{Name: name, Run: func(context.Context, Args) (string, error) { return name + " ran", nil }}
}

func TestLazyGroups(t *testing.T) {
	r := NewRegistry(mk("send"), mk("photo"), mk("sticker"), mk("ban"))
	var fired []string
	r.OnUnlock = func(g string) { fired = append(fired, g) }
	r.Lazy(map[string][]string{"media": {"photo", "sticker", "missing"}, "admin": {"ban"}, "empty": {"nope"}},
		map[string]string{"media": "photos", "admin": "moderation"})
	if got := names(r); got != "more_tools,send" {
		t.Fatalf("locked defs: %s", got)
	}
	var moreDesc string
	for _, d := range r.Defs() {
		if d.Function.Name == "more_tools" {
			moreDesc = d.Function.Description
		}
	}
	if !strings.Contains(moreDesc, "media (photos)") || strings.Contains(moreDesc, "empty") {
		t.Fatalf("description: %q", moreDesc)
	}
	if out := r.Call(context.Background(), "more_tools", `{"group":"media"}`); !strings.Contains(out, "photo, sticker") {
		t.Fatal(out)
	}
	if got := names(r); got != "more_tools,photo,send,sticker" {
		t.Fatalf("after unlock: %s", got)
	}
	if out := r.Call(context.Background(), "more_tools", `{"group":"bogus"}`); !strings.HasPrefix(out, "Error:") {
		t.Fatal(out)
	}
	// calling a hidden tool by name works and unlocks its group
	if out := r.Call(context.Background(), "ban", `{}`); out != "ban ran" {
		t.Fatal(out)
	}
	if got := names(r); !strings.Contains(got, "ban") {
		t.Fatalf("ban not unlocked: %s", got)
	}
	if len(fired) != 2 {
		t.Fatalf("OnUnlock fired %v", fired)
	}
	// nothing to hide -> no more_tools, no change
	r2 := NewRegistry(mk("a"))
	r2.Lazy(map[string][]string{"g": {"zzz"}}, nil)
	if names(r2) != "a" {
		t.Fatal(names(r2))
	}
}
