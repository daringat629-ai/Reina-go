package tools

import (
	"context"
	"os"
	"path/filepath"
	"strings"

	"kuni/internal/config"
	"kuni/internal/diary"
	"kuni/internal/imagegen"
	"kuni/internal/llm"
	"kuni/internal/llmui"
	"kuni/internal/media"
	"kuni/internal/metrics"
	"kuni/internal/prompts"
	"kuni/internal/telegram"
)

// Deps is everything tools need; shared between the agent and the proxy.
type Deps struct {
	TG      telegram.Client
	LLM     *llm.Client
	Diary   *diary.Diary
	Prompts *prompts.Store
	Media   func() media.Services
	Cfg     func() *config.Config
	UI      *llmui.Env
	Metrics *metrics.Registry
	Images  *imagegen.Generator
	// OpenChat is supplied by the agent: it switches the session to a chat and returns the rendered view.
	OpenChat func(ctx context.Context, chatID int64) (string, error)
}

func (d Deps) dataPath(sub ...string) string {
	return filepath.Join(append([]string{d.Cfg().DataDir}, sub...)...)
}

// safeJoin resolves a model-supplied filename inside dir and rejects path traversal.
func safeJoin(dir, name string) (string, error) {
	clean := filepath.Base(strings.TrimSpace(name))
	if clean == "." || clean == ".." || clean == string(filepath.Separator) || clean != strings.TrimSpace(name) {
		return "", os.ErrInvalid
	}
	return filepath.Join(dir, clean), nil
}

// Contacts reports whether a user is in the account's contact list (set by main in user mode).
var Contacts func(userID int64) bool

// Accessible implements util::isAccessibleFromLockdown: may Kuni touch this chat?
func Accessible(c *config.Config, chatID int64) bool {
	switch c.Lockdown {
	case "papik_only":
		return chatID == c.PapikChatID
	case "contacts_only":
		// groups (negative IDs) and the owner are allowed; private chats need to be contacts
		// (Contacts is set in user mode; the Bot API has no contact list).
		return chatID < 0 || chatID == c.PapikChatID || (Contacts != nil && Contacts(chatID))
	}
	return true
}
