// Package memory implements the working memory file (data/working_memory.md),
// the "middle layer" between the context window and the diary.
package memory

import (
	"errors"
	"io/fs"
	"os"
	"path/filepath"
)

type WorkingMemory struct {
	Path string
}

// Load returns the current contents, or "" if the file does not exist yet.
func (w WorkingMemory) Load() (string, error) {
	b, err := os.ReadFile(w.Path)
	if errors.Is(err, fs.ErrNotExist) {
		return "", nil
	}
	return string(b), err
}

// Save overwrites the working memory atomically.
func (w WorkingMemory) Save(content string) error {
	if err := os.MkdirAll(filepath.Dir(w.Path), 0o755); err != nil {
		return err
	}
	tmp := w.Path + ".tmp"
	if err := os.WriteFile(tmp, []byte(content), 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, w.Path)
}
