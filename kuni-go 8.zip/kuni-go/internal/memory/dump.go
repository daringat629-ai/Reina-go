package memory

import (
	"context"
	"fmt"
	"log"
	"strconv"
	"strings"
	"sync/atomic"
	"time"

	"kuni/internal/diary"
	"kuni/internal/llm"
	"kuni/internal/prompts"
	"kuni/internal/util"
)

// PlagiarismThreshold: entries at least this similar to an existing one are not stored again.
const PlagiarismThreshold = 0.97

var idCounter atomic.Int64

func nextID() string {
	for {
		now := time.Now().Unix()
		old := idCounter.Load()
		next := now
		if old >= now {
			next = old + 1
		}
		if idCounter.CompareAndSwap(old, next) {
			return strconv.FormatInt(next, 10)
		}
	}
}

// Dumper persists a finished conversation: diary entries (diary_save prompt) and
// the refreshed working memory (port of diaryDumpMessages / importantThingsToRemember).
type Dumper struct {
	LLM           *llm.Client
	Diary         *diary.Diary
	WM            WorkingMemory
	Prompts       *prompts.Store
	CharacterName func() string
}

// SaveEntries splits an LLM diary summary on "---", drops plagiarised/short pieces and stores the rest.
func (d *Dumper) SaveEntries(ctx context.Context, summary string) ([]diary.Entry, error) {
	// models sometimes mangle separators
	summary = strings.NewReplacer("- --", "---", "-- -", "---").Replace(summary)
	var saved []diary.Entry
	existing, err := d.Diary.Load()
	if err != nil {
		return nil, err
	}
	for _, piece := range strings.Split(summary, "---") {
		piece = strings.TrimSpace(piece)
		if len(piece) < 20 {
			continue
		}
		emb, err := d.LLM.Embedding(ctx, piece)
		if err != nil {
			return saved, err
		}
		dup := false
		for _, e := range existing {
			if len(e.Meta.Embedding) != len(emb) {
				continue
			}
			if cos, _ := util.CosineSimilarity(emb, e.Meta.Embedding); (cos+1)/2 > PlagiarismThreshold {
				dup = true
				break
			}
		}
		if dup {
			log.Printf("memory: skipping plagiarised diary piece")
			continue
		}
		e := diary.Entry{ID: nextID(), Meta: diary.Metadata{Embedding: emb}, Body: piece}
		if err := d.Diary.Save(e); err != nil {
			return saved, err
		}
		existing = append(existing, e)
		saved = append(saved, e)
	}
	return saved, nil
}

// DumpSession writes the session to the diary and refreshes working memory.
// system is the system prompt the session ran with; session is its message history.
func (d *Dumper) DumpSession(ctx context.Context, system string, session []llm.Message) error {
	if len(session) == 0 {
		return nil
	}
	// work on a copy; tools are not offered here.
	ctxMsgs := append([]llm.Message(nil), session...)

	diaryMsgs := append(ctxMsgs, llm.Message{Role: "user", Content: d.Prompts.Get(prompts.DiarySave)})
	var summary string
	for attempt := 0; attempt < 3; attempt++ {
		out, err := d.LLM.Chat(llm.WithPurpose(ctx, "diary"), system, diaryMsgs)
		if err != nil {
			return fmt.Errorf("diary summary: %w", err)
		}
		if strings.TrimSpace(out) != "" {
			summary = out
			break
		}
		diaryMsgs = append(diaryMsgs, llm.Message{Role: "assistant", Content: out},
			llm.Message{Role: "user", Content: "Tools are not available; write the summary without tools."})
	}
	if _, err := d.SaveEntries(ctx, summary); err != nil {
		return fmt.Errorf("saving diary: %w", err)
	}

	prev, err := d.WM.Load()
	if err != nil {
		return err
	}
	wm, err := d.UpdateWorkingMemory(ctx, system, ctxMsgs, prev)
	if err != nil {
		return fmt.Errorf("working memory: %w", err)
	}
	return d.WM.Save(wm)
}

// UpdateWorkingMemory asks the LLM for the new <things_to_remember> (importantThingsToRemember).
func (d *Dumper) UpdateWorkingMemory(ctx context.Context, system string, session []llm.Message, previous string) (string, error) {
	name := d.CharacterName()
	prompt := "What are important things in timespan " + util.FormatPastHours(24*3*time.Hour) + " (3 days) you should remember?\n" +
		"Do not attempt to make tool_calls or #ask. Your job is to summarize your current tasks and revisit tasks from previous session.\n"
	if previous != "" {
		prompt += "\nHere is the PREVIOUS <things_to_remember> from the last session. You MUST preserve ALL items verbatim from it, except:\n" +
			"1. Completed tasks — mark them as done or remove\n" +
			"2. Items that have NOT been updated for more than 3 days — you may forget them\n" +
			"\nPrevious working memory:\n<previous_things_to_remember>\n" + previous +
			"\n</previous_things_to_remember>\n" +
			"Important: the content of previous_things_to_remember will be overwritten by your next response. Make sure to preserve:" +
			"- unfinished tasks (not older than 3 days);" +
			"- reminders (not older that 3 days or without a deadline)\n"
	}
	prompt += "\nYou must include:\n- promises\n- reminders\n- unfinished tasks\n- responsibilities\n" +
		"- " + name + "'s current emotional state: sad, arousal, betrayed, grief, sorrow, pensiveness, anger, annoyed, fear, amazement, surprise, distracted, love, trust, accepted, joy, serenity, embarrassed, proud, envious, jealous, grateful, disappointed, hopeful, lonely, nostalgic, relieved, resentful\n" +
		"- " + name + "'s current physical state: energetic, tired, exhausted, sleepy, restless, tense, relaxed, hungry, thirsty, sore, dizzy, nauseous, feverish, cold, warm, comfortable, uncomfortable, in_pain, injured, healthy, sick, weak, stiff, trembling, numb, wet, dry, stimulated\n" +
		"- other important details\n" +
		"In your response, you must include previous <things_to_remember></things_to_remember>. DO NOT ALTER THEIR DESCRIPTION, thought you can expand them. You should not include older, outdated items and completed tasks.\n" +
		"You must write briefly (100-500 words), structurize output, INCLUDE DATES.\n" +
		"Each item MUST have a \"last updated\" date. Example format:\n" +
		"- Remind Alex about hosting payment before May 15 — last updated: Apr 28\n" +
		"- Waiting for Maria's answer about Friday's meeting — last updated: Apr 29\n"

	msgs := append(append([]llm.Message(nil), session...), llm.Message{Role: "user", Content: prompt})
	for attempt := 0; attempt < 4; attempt++ {
		out, err := d.LLM.Chat(llm.WithPurpose(ctx, "diary"), system, msgs)
		if err != nil {
			return "", err
		}
		if (strings.Contains(out, "tool_calls") || strings.Contains(out, "DSML")) && attempt == 0 {
			continue // some models try to emit a tool call here; retry once
		}
		out = strings.NewReplacer("<things_to_remember>", "", "</things_to_remember>", "").Replace(out)
		out = strings.TrimLeft(out, " \t\r")
		if strings.TrimSpace(out) == "" {
			continue
		}
		return out, nil
	}
	return "", fmt.Errorf("model returned no working memory")
}
