// Package metrics is a tiny Prometheus text-format exporter (counters, gauges and
// summary-style sum/count), enough for the Grafana dashboard of the C++ project.
package metrics

import (
	"fmt"
	"net/http"
	"sort"
	"strings"
	"sync"
)

type Registry struct {
	mu       sync.Mutex
	counters map[string]float64
	gauges   map[string]float64
	help     map[string]string
}

func New() *Registry {
	return &Registry{counters: map[string]float64{}, gauges: map[string]float64{}, help: map[string]string{}}
}

// key renders name{k="v",...} with labels sorted.
func key(name string, labels map[string]string) string {
	if len(labels) == 0 {
		return name
	}
	ks := make([]string, 0, len(labels))
	for k := range labels {
		ks = append(ks, k)
	}
	sort.Strings(ks)
	parts := make([]string, len(ks))
	for i, k := range ks {
		parts[i] = fmt.Sprintf("%s=%q", k, labels[k])
	}
	return name + "{" + strings.Join(parts, ",") + "}"
}

func (r *Registry) Help(name, text string) {
	r.mu.Lock()
	r.help[name] = text
	r.mu.Unlock()
}

// Inc adds v to a counter.
func (r *Registry) Inc(name string, v float64, labels map[string]string) {
	if r == nil {
		return
	}
	r.mu.Lock()
	r.counters[key(name, labels)] += v
	r.mu.Unlock()
}

// Set sets a gauge.
func (r *Registry) Set(name string, v float64, labels map[string]string) {
	if r == nil {
		return
	}
	r.mu.Lock()
	r.gauges[key(name, labels)] = v
	r.mu.Unlock()
}

// Observe records a duration-like value as <name>_sum and <name>_count.
func (r *Registry) Observe(name string, v float64, labels map[string]string) {
	r.Inc(name+"_sum", v, labels)
	r.Inc(name+"_count", 1, labels)
}

// Get returns a counter value (tests).
func (r *Registry) Get(name string, labels map[string]string) float64 {
	r.mu.Lock()
	defer r.mu.Unlock()
	return r.counters[key(name, labels)]
}

// Handler serves the Prometheus text exposition format.
func (r *Registry) Handler() http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		r.mu.Lock()
		var lines []string
		for k, v := range r.counters {
			lines = append(lines, fmt.Sprintf("%s %g", k, v))
		}
		for k, v := range r.gauges {
			lines = append(lines, fmt.Sprintf("%s %g", k, v))
		}
		helps := map[string]string{}
		for k, v := range r.help {
			helps[k] = v
		}
		r.mu.Unlock()
		sort.Strings(lines)
		w.Header().Set("Content-Type", "text/plain; version=0.0.4")
		written := map[string]bool{}
		for _, l := range lines {
			name := l
			if i := strings.IndexAny(name, "{ "); i >= 0 {
				name = name[:i]
			}
			if h, ok := helps[name]; ok && !written[name] {
				fmt.Fprintf(w, "# HELP %s %s\n", name, h)
				written[name] = true
			}
			fmt.Fprintln(w, l)
		}
	})
}
