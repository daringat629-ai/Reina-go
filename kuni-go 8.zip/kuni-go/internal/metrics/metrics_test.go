package metrics

import (
	"net/http/httptest"
	"strings"
	"testing"
)

func TestExposition(t *testing.T) {
	r := New()
	r.Help("kuni_llm_requests_total", "LLM requests")
	r.Inc("kuni_llm_requests_total", 1, map[string]string{"kind": "chat"})
	r.Inc("kuni_llm_requests_total", 2, map[string]string{"kind": "chat"})
	r.Set("kuni_sessions_active", 3, nil)
	r.Observe("kuni_llm_seconds", 1.5, nil)
	rec := httptest.NewRecorder()
	r.Handler().ServeHTTP(rec, httptest.NewRequest("GET", "/metrics", nil))
	body := rec.Body.String()
	for _, want := range []string{`kuni_llm_requests_total{kind="chat"} 3`, "kuni_sessions_active 3", "kuni_llm_seconds_sum 1.5", "kuni_llm_seconds_count 1", "# HELP kuni_llm_requests_total"} {
		if !strings.Contains(body, want) {
			t.Errorf("missing %q in:\n%s", want, body)
		}
	}
}
