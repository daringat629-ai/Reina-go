package config

import (
	"errors"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestFirstRunWritesDefaults(t *testing.T) {
	p := filepath.Join(t.TempDir(), "config.toml")
	if _, err := Load(p); !errors.Is(err, ErrNeedsSetup) {
		t.Fatalf("want ErrNeedsSetup, got %v", err)
	}
	c, err := Load(p)
	if err != nil {
		t.Fatalf("reload defaults: %v", err)
	}
	if c.LLMBaseURL != "http://localhost:11434/v1/" || c.ProxyPort != 10434 {
		t.Fatalf("unexpected defaults: %+v", c)
	}
	if c.DebounceWindow != 1500*time.Millisecond || c.SessionIdle != 900*time.Second {
		t.Fatalf("durations: %v %v", c.DebounceWindow, c.SessionIdle)
	}
}

func TestParseOverridesAndComments(t *testing.T) {
	src := `
# top comment
[general]
character_name = "Mika" # inline comment
papik_chat_id = 625207005

[llm]
base_url = "http://example.com/v1"
request_timeout_secs = 12
temperature = 0.7
[proxy]
port = 9999
`
	p := filepath.Join(t.TempDir(), "config.toml")
	if err := os.WriteFile(p, []byte(src), 0o644); err != nil {
		t.Fatal(err)
	}
	c, err := Load(p)
	if err != nil {
		t.Fatal(err)
	}
	if c.CharacterName != "Mika" || c.LLMBaseURL != "http://example.com/v1/" || c.ProxyPort != 9999 || c.Temperature != 0.7 {
		t.Fatalf("got %+v", c)
	}
	if c.EmbeddingBaseURL != c.LLMBaseURL {
		t.Fatalf("embedding base should default to llm base")
	}
}

func TestBadTypeIsAnError(t *testing.T) {
	p := filepath.Join(t.TempDir(), "config.toml")
	os.WriteFile(p, []byte("[proxy]\nport = \"x\"\n"), 0o644)
	if _, err := Load(p); err == nil {
		t.Fatal("expected type error")
	}
}
