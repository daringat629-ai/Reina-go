// Package llmui renders Telegram state into the XML-ish text the LLM reads
// (<chat>, <message>, <voice>, photo descriptions…). Port of src/llmui/.
package llmui

import (
	"context"
	"encoding/base64"
	"fmt"
	"html"
	"log"
	"os"
	"path/filepath"
	"strings"
	"time"

	"kuni/internal/config"
	"kuni/internal/llm"
	"kuni/internal/media"
	"kuni/internal/prompts"
	"kuni/internal/telegram"
	"kuni/internal/util"
)

// EmbeddingTag mirrors IOpenAIChat::EMBEDDING_TAG; text containing it is neutralised
// so users can't smuggle fake image payloads into the prompt.
const EmbeddingTag = "kuni_embedding"

type Env struct {
	TG      telegram.Client
	LLM     *llm.Client
	Prompts *prompts.Store
	Media   func() media.Services
	Cfg     func() *config.Config
}

// Sanitize replaces text carrying the embedding tag with "malicious" (checkForMaliciousPayloads).
func Sanitize(s string) string {
	if strings.Contains(s, EmbeddingTag) {
		return "malicious"
	}
	return s
}

func attr(s string) string { return html.EscapeString(Sanitize(s)) }

// FormatChat renders one chat for get_telegram_chats.
func FormatChat(c telegram.Chat, now time.Time) string {
	preview := c.LastText
	if len(preview) > 80 {
		preview = preview[:80] + "…"
	}
	return fmt.Sprintf(`<chat chat_id="%d" title="%s" type="%s" unread="%d" last_message="%s" preview="%s"/>`,
		c.ID, attr(c.Title), c.Kind, c.Unread, util.TimeAgo(c.LastDate, now), attr(preview))
}

// FormatMessages renders a batch of messages, describing media on the way.
func (e *Env) FormatMessages(ctx context.Context, msgs []telegram.Message, now time.Time) string {
	var b strings.Builder
	for _, m := range msgs {
		b.WriteString(e.FormatMessage(ctx, m, now))
		b.WriteString("\n")
	}
	return b.String()
}

func (e *Env) FormatMessage(ctx context.Context, m telegram.Message, now time.Time) string {
	var attrs strings.Builder
	fmt.Fprintf(&attrs, `message_id="%d" sender="%s" time_ago="%s"`, m.ID, attr(m.SenderName), util.TimeAgo(m.Date, now))
	if m.Outgoing {
		attrs.WriteString(` you="true"`)
	} else if !m.Read {
		attrs.WriteString(` unread="true"`)
	}
	if m.ReplyTo != 0 {
		fmt.Fprintf(&attrs, ` reply_to_message_id="%d"`, m.ReplyTo)
	}
	if m.ForwardFrom != "" {
		fmt.Fprintf(&attrs, ` forwarded_from="%s"`, attr(m.ForwardFrom))
	}
	if m.Edited {
		attrs.WriteString(` edited="true"`)
	}
	if len(m.Reactions) > 0 {
		fmt.Fprintf(&attrs, ` reactions="%s"`, attr(strings.Join(m.Reactions, "")))
	}

	body := Sanitize(m.Text)
	switch m.Media {
	case telegram.MediaVoice:
		body = e.transcribeVoice(ctx, m) + optionalCaption(body)
	case telegram.MediaPhoto:
		body = e.describe(ctx, m, "photo") + optionalCaption(body)
	case telegram.MediaSticker:
		body = e.describe(ctx, m, "sticker sticker_id=\""+attr(m.FileID)+"\" emoji=\""+attr(m.Text)+"\"")
	case telegram.MediaVideo:
		body = e.describeVideo(ctx, m) + optionalCaption(body)
	}
	return fmt.Sprintf("<message %s>\n%s\n</message>", attrs.String(), body)
}

func optionalCaption(s string) string {
	if strings.TrimSpace(s) == "" {
		return ""
	}
	return "\n" + s
}

func (e *Env) transcribeVoice(ctx context.Context, m telegram.Message) string {
	data, err := e.TG.Download(ctx, m.FileID)
	if err != nil {
		return "<voice>(can't download: " + err.Error() + ")</voice>"
	}
	text, err := e.Media().STT.Transcribe(ctx, data, "voice.ogg")
	if err != nil {
		return "<voice>(transcription unavailable: " + err.Error() + ")</voice>"
	}
	return "<voice>\n" + Sanitize(text) + "\n</voice>"
}

func (e *Env) cachePath(key string) string {
	safe := strings.Map(func(r rune) rune {
		if r == '/' || r == '\\' || r == ':' {
			return '_'
		}
		return r
	}, key)
	return filepath.Join(e.Cfg().DataDir, "cache", "images", safe+".md")
}

// describe returns "<tag description>…</tag>" for an image-like message, with a disk cache keyed by file id.
func (e *Env) describe(ctx context.Context, m telegram.Message, tag string) string {
	closeTag := strings.Fields(tag)[0]
	wrap := func(s string) string { return "<" + tag + " description>\n" + s + "\n</" + closeTag + ">" }
	cache := e.cachePath(m.FileID)
	if b, err := os.ReadFile(cache); err == nil {
		return wrap(string(b))
	}
	data, err := e.TG.Download(ctx, m.FileID)
	if err != nil {
		return wrap("(can't download: " + err.Error() + ")")
	}
	desc, err := e.DescribeImage(ctx, data, strings.HasPrefix(tag, "sticker"))
	if err != nil {
		log.Printf("llmui: can't describe image: %v", err)
		return wrap("This media type is not supported")
	}
	_ = os.MkdirAll(filepath.Dir(cache), 0o755)
	_ = os.WriteFile(cache, []byte(desc), 0o644)
	return wrap(desc)
}

// DescribeImage asks the (vision) LLM to describe image bytes using photo_to_text / sticker_to_text.
func (e *Env) DescribeImage(ctx context.Context, data []byte, sticker bool) (string, error) {
	system := e.Prompts.Get(prompts.PhotoToText)
	if sticker {
		system = e.Prompts.Get(prompts.StickerToText)
	}
	ctxText := "<context>\n<character name=\"" + e.Cfg().CharacterName + "\">\n" +
		e.Prompts.Get(prompts.CharacterAppearance) + "\n</character>\n</context>\n\nPhoto:\n"
	msg := llm.Message{Role: "user", Parts: []llm.Part{
		{Type: "text", Text: ctxText},
		{Type: "image_url", ImageURL: DataURL(data)},
		{Type: "text", Text: "Describe the last photo."},
	}}
	for attempt := 0; attempt < 3; attempt++ {
		out, err := e.LLM.Chat(ctx, system, []llm.Message{msg})
		if err != nil {
			return "", err
		}
		if strings.TrimSpace(out) != "" { // empty = local model overflowed its reasoning, retry
			return strings.TrimSpace(out), nil
		}
	}
	return "", fmt.Errorf("model returned empty description")
}

func (e *Env) describeVideo(ctx context.Context, m telegram.Message) string {
	cache := e.cachePath("video_" + m.FileID)
	if b, err := os.ReadFile(cache); err == nil {
		return string(b)
	}
	data, err := e.TG.Download(ctx, m.FileID)
	if err != nil {
		return "<video>(can't download: " + err.Error() + ")</video>"
	}
	svc := e.Media()
	var out strings.Builder
	out.WriteString("<video>\n")
	frames, ferr := svc.Video.Frames(ctx, data, 4)
	if ferr != nil {
		out.WriteString("(frames unavailable: " + ferr.Error() + ")\n")
	}
	for i, f := range frames {
		d, err := e.DescribeImage(ctx, f, false)
		if err == nil {
			fmt.Fprintf(&out, "<frame n=\"%d\">%s</frame>\n", i+1, d)
		}
	}
	if wav, err := svc.Video.Audio(ctx, data); err == nil {
		if text, err := svc.STT.Transcribe(ctx, wav, "audio.wav"); err == nil && text != "" {
			out.WriteString("<audio_transcript>" + Sanitize(text) + "</audio_transcript>\n")
		}
	}
	out.WriteString("</video>")
	if ferr == nil {
		_ = os.MkdirAll(filepath.Dir(cache), 0o755)
		_ = os.WriteFile(cache, []byte(out.String()), 0o644)
	}
	return out.String()
}

// DataURL encodes image bytes for vision input.
func DataURL(b []byte) string {
	mime := "image/jpeg"
	if len(b) > 8 && string(b[1:4]) == "PNG" {
		mime = "image/png"
	}
	return "data:" + mime + ";base64," + base64.StdEncoding.EncodeToString(b)
}
