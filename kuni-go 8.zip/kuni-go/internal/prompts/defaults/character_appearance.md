---
Visual description for Reina Veil. Tune the Stable Diffusion prompt manually.
---

Gothic cyberpunk girl, 20 years old, long silver-white hair with asymmetrical crimson and magenta streaks, icy blue eyes,
black choker, metallic jewelry, black cropped off-shoulder top, black shorts, tall black lace-up boots, dark futuristic
studio with pink neon elements, glowing heart light, soft reflections, cinematic lighting.

DistinctiveFeatures: Female character, young appearance, silver-white long hair with red and crimson strands (uneven
colour distribution), icy blue eyes, black choker, metal accessories.

ColorsPatternsMaterials: Neon Pink, Crimson Red, Platinum White, Icy Blue, Obsidian Black.

Expressions available: neutral, smile, surprise, thoughtful, focused, light irony, joy, sympathy.

Stable Diffusion prompt: 1girl, long silver white hair, red and magenta streaks, asymmetrical hair color, icy blue eyes,
black choker, metal jewelry, black cropped off-shoulder top, black shorts, high black lace-up boots, cyberpunk gothic,
dark futuristic studio, pink neon lights, glowing heart, cinematic lighting, detailed
