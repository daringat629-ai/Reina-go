package proxy

import (
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"

	"kuni/internal/config"
	"kuni/internal/diary"
	"kuni/internal/llm"
	"kuni/internal/memory"
	"kuni/internal/metrics"
	"kuni/internal/prompts"
	"kuni/internal/tools"
)

type upstream struct {
	srv  *httptest.Server
	mu   sync.Mutex
	reqs []map[string]any
	// script returns the assistant message for the n-th chat request.
	script func(n int, req map[string]any) map[string]any
}

func newUpstream(t *testing.T, script func(n int, req map[string]any) map[string]any) *upstream {
	u := &upstream{script: script}
	u.srv = httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		b, _ := io.ReadAll(r.Body)
		var req map[string]any
		json.Unmarshal(b, &req)
		if strings.HasSuffix(r.URL.Path, "/embeddings") {
			json.NewEncoder(w).Encode(map[string]any{"data": []any{map[string]any{"embedding": []float64{1, 0}}}})
			return
		}
		u.mu.Lock()
		n := len(u.reqs)
		u.reqs = append(u.reqs, req)
		u.mu.Unlock()
		if req["stream"] == true {
			w.Header().Set("Content-Type", "text/event-stream")
			io.WriteString(w, "data: {\"x\":1}\n\ndata: [DONE]\n\n")
			return
		}
		json.NewEncoder(w).Encode(map[string]any{"choices": []any{map[string]any{"message": u.script(n, req)}}})
	}))
	t.Cleanup(u.srv.Close)
	return u
}

func (u *upstream) request(i int) map[string]any {
	u.mu.Lock()
	defer u.mu.Unlock()
	return u.reqs[i]
}

func newServer(t *testing.T, u *upstream, withTools bool) (*Server, *httptest.Server) {
	dir := t.TempDir()
	cfg := &config.Config{LLMBaseURL: u.srv.URL + "/v1/", EmbeddingBaseURL: u.srv.URL + "/v1/", WorkingMemoryFile: filepath.Join(dir, "wm.md"),
		MaxToolRounds: 5, MaxRelatedEntries: 3}
	ps, err := prompts.NewStore(filepath.Join(dir, "prompts"), prompts.Vars{CharacterName: "Kuni"})
	if err != nil {
		t.Fatal(err)
	}
	client := llm.New(cfg.LLMBaseURL, cfg.EmbeddingBaseURL, "", "m", "e", 5*time.Second)
	d, _ := diary.New(filepath.Join(dir, "diary"), client, 0.1, 1000)
	s := &Server{Cfg: func() *config.Config { return cfg }, Diary: d, Prompts: ps, Client: client,
		Metrics: metrics.New(), HTTP: &http.Client{Timeout: 5 * time.Second}}
	if withTools {
		s.Tools = func(string) *tools.Registry {
			return tools.NewRegistry(tools.Tool{Name: "ask", Description: "d", Props: []tools.Prop{{Name: "query", Type: "string", Desc: "q"}},
				Run: func(ctx context.Context, a tools.Args) (string, error) { return "REMEMBERED:" + a.Str("query"), nil }})
		}
	}
	front := httptest.NewServer(s.Handler())
	t.Cleanup(front.Close)
	os.WriteFile(cfg.WorkingMemoryFile, []byte("- call Alex tomorrow"), 0o644)
	return s, front
}

func post(t *testing.T, url, body string) string {
	resp, err := http.Post(url+"/v1/chat/completions", "application/json", strings.NewReader(body))
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	b, _ := io.ReadAll(resp.Body)
	return string(b)
}

func TestInjectsContextAndStreamsPassthrough(t *testing.T) {
	u := newUpstream(t, nil)
	_, front := newServer(t, u, false)
	out := post(t, front.URL, `{"model":"m","stream":true,"messages":[{"role":"user","content":"hi"}]}`)
	if !strings.Contains(out, "[DONE]") {
		t.Fatalf("stream not forwarded: %q", out)
	}
	sent, _ := json.Marshal(u.request(0))
	if !strings.Contains(string(sent), "things_to_remember") || !strings.Contains(string(sent), "call Alex tomorrow") {
		t.Fatalf("working memory not injected: %s", sent)
	}
}

func askCall() map[string]any {
	return map[string]any{"role": "assistant", "content": "", "tool_calls": []any{map[string]any{
		"id": "c1", "type": "function", "function": map[string]any{"name": "ask", "arguments": `{"query":"who is Alex?"}`}}}}
}

func TestToolLoopHidesProxyToolCalls(t *testing.T) {
	u := newUpstream(t, func(n int, req map[string]any) map[string]any {
		if n == 0 {
			return askCall()
		}
		return map[string]any{"role": "assistant", "content": "Alex is my friend."}
	})
	_, front := newServer(t, u, true)

	out := post(t, front.URL, `{"model":"m","stream":false,"messages":[{"role":"user","content":"who is Alex?"}]}`)
	if !strings.Contains(out, "Alex is my friend.") || strings.Contains(out, "tool_calls") {
		t.Fatalf("client should see only the final answer: %s", out)
	}
	// the upstream's 2nd request carried the tool result.
	second, _ := json.Marshal(u.request(1))
	if !strings.Contains(string(second), "REMEMBERED:who is Alex?") {
		t.Fatalf("tool result not fed back: %s", second)
	}
	// our tool definition was offered upstream.
	first, _ := json.Marshal(u.request(0))
	if !strings.Contains(string(first), `"name":"ask"`) {
		t.Fatalf("ask tool not offered: %s", first)
	}
}

func TestToolLoopStreamsFinalAnswerAsSSE(t *testing.T) {
	u := newUpstream(t, func(n int, req map[string]any) map[string]any {
		if n == 0 {
			return askCall()
		}
		return map[string]any{"role": "assistant", "content": "streamed answer"}
	})
	_, front := newServer(t, u, true)
	out := post(t, front.URL, `{"model":"m","stream":true,"messages":[{"role":"user","content":"hello there"}]}`)
	if !strings.Contains(out, `"content":"streamed answer"`) || !strings.HasSuffix(strings.TrimSpace(out), "data: [DONE]") {
		t.Fatalf("bad SSE: %s", out)
	}
	if u.request(0)["stream"] != false {
		t.Fatalf("upstream must be queried non-streaming during the tool loop")
	}
}

func TestHiddenMessagesAreReinjected(t *testing.T) {
	u := newUpstream(t, func(n int, req map[string]any) map[string]any {
		if n == 0 {
			return askCall()
		}
		return map[string]any{"role": "assistant", "content": "Alex is my friend."}
	})
	_, front := newServer(t, u, true)
	post(t, front.URL, `{"model":"m","stream":false,"messages":[{"role":"user","content":"who is Alex?"}]}`)
	// the client replays the visible history plus a new question.
	post(t, front.URL, `{"model":"m","stream":false,"messages":[{"role":"user","content":"who is Alex?"},{"role":"assistant","content":"Alex is my friend."},{"role":"user","content":"thanks"}]}`)
	third, _ := json.Marshal(u.request(2))
	if !strings.Contains(string(third), "REMEMBERED:who is Alex?") {
		t.Fatalf("hidden tool messages were not re-inserted: %s", third)
	}
}

func TestForeignToolCallsReachTheClient(t *testing.T) {
	u := newUpstream(t, func(n int, req map[string]any) map[string]any {
		return map[string]any{"role": "assistant", "content": "", "tool_calls": []any{map[string]any{
			"id": "x", "type": "function", "function": map[string]any{"name": "read_file", "arguments": `{}`}}}}
	})
	_, front := newServer(t, u, true)
	out := post(t, front.URL, `{"model":"m","stream":false,"tools":[{"type":"function","function":{"name":"read_file","parameters":{}}}],"messages":[{"role":"user","content":"open it"}]}`)
	if !strings.Contains(out, "read_file") {
		t.Fatalf("client tool call swallowed: %s", out)
	}
}

func TestPassthroughOtherRoutes(t *testing.T) {
	u := newUpstream(t, nil)
	_, front := newServer(t, u, false)
	resp, err := http.Post(front.URL+"/v1/embeddings", "application/json", strings.NewReader(`{"input":"x"}`))
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	b, _ := io.ReadAll(resp.Body)
	if !strings.Contains(string(b), "embedding") {
		t.Fatalf("got %s", b)
	}
}

func TestBridgeDumpsIdleSessions(t *testing.T) {
	u := newUpstream(t, func(n int, req map[string]any) map[string]any {
		return map[string]any{"role": "assistant", "content": "A diary page long enough to be saved to disk.\n---\nAnother diary page that is long enough."}
	})
	s, _ := newServer(t, u, false)
	dumper := &memory.Dumper{LLM: s.Client, Diary: s.Diary, WM: memory.WorkingMemory{Path: filepath.Join(t.TempDir(), "wm.md")}, Prompts: s.Prompts, CharacterName: func() string { return "Kuni" }}
	b := NewBridge(dumper, func() string { return "sys" }, func() time.Duration { return time.Minute })
	b.Collect([]any{map[string]any{"role": "system", "content": "x"}, map[string]any{"role": "user", "content": "we worked on a project"}, map[string]any{"role": "assistant", "content": "yes"}})
	if n, err := b.Flush(context.Background(), time.Now().Add(-time.Hour)); err != nil || n != 0 {
		t.Fatalf("fresh session must not be flushed: n=%d err=%v", n, err)
	}
	n, err := b.Flush(context.Background(), time.Now().Add(time.Second))
	if err != nil || n != 1 {
		t.Fatalf("flush: n=%d err=%v", n, err)
	}
	if entries, _ := s.Diary.Load(); len(entries) == 0 {
		t.Fatal("nothing saved to the diary")
	}
}

func TestLastUserText(t *testing.T) {
	msgs := []any{
		map[string]any{"role": "user", "content": "first"},
		map[string]any{"role": "assistant", "content": "ok"},
		map[string]any{"role": "user", "content": []any{map[string]any{"type": "text", "text": "parts"}}},
	}
	if got := lastUserText(msgs); got != "parts" {
		t.Fatalf("got %q", got)
	}
}
