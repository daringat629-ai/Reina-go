package telegram

import (
	"context"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"
)

// fakeTD scripts tdlib: handle(req) returns the response object for a request
// (nil = {"@type":"ok"}); Push injects unsolicited updates.
type fakeTD struct {
	mu     sync.Mutex
	out    chan []byte
	reqs   []obj
	handle func(req obj) obj
}

func newFakeTD(handle func(req obj) obj) *fakeTD {
	return &fakeTD{out: make(chan []byte, 256), handle: handle}
}

func (f *fakeTD) Send(raw []byte) {
	req, _ := decode(raw)
	f.mu.Lock()
	f.reqs = append(f.reqs, req)
	f.mu.Unlock()
	if str(req, "@type") == "getOption" && req["@extra"] == nil {
		f.Push(obj{"@type": "updateAuthorizationState", "authorization_state": obj{"@type": "authorizationStateWaitTdlibParameters"}})
		return
	}
	var resp obj
	if f.handle != nil {
		resp = f.handle(req)
	}
	if resp == nil {
		resp = obj{"@type": "ok"}
	}
	if extra, ok := req["@extra"]; ok {
		resp["@extra"] = extra
		f.Push(resp)
	}
}

func (f *fakeTD) Push(m obj) {
	b, _ := json.Marshal(m)
	f.out <- b
}

func (f *fakeTD) Receive(timeout time.Duration) []byte {
	select {
	case b := <-f.out:
		return b
	case <-time.After(timeout):
		return nil
	}
}

func (f *fakeTD) requests(typ string) []obj {
	f.mu.Lock()
	defer f.mu.Unlock()
	var out []obj
	for _, r := range f.reqs {
		if str(r, "@type") == typ {
			out = append(out, r)
		}
	}
	return out
}

// loggedIn starts a client against fake and walks the real authorization sequence.
func loggedIn(t *testing.T, f *fakeTD, cfg TDConfig) (*TDClient, context.Context) {
	t.Helper()
	prompts := []string{}
	cfg.Prompt = func(what string) string {
		prompts = append(prompts, what)
		return map[string]string{"phone number": "+79990001122", "verification code": "12345", "cloud password": "pw"}[what]
	}
	if cfg.APIID == 0 {
		cfg.APIID, cfg.APIHash = 777, "hash"
	}
	cfg.DBDir = t.TempDir()
	inner := f.handle
	f.handle = func(req obj) obj {
		switch str(req, "@type") {
		case "setTdlibParameters":
			f.Push(obj{"@type": "updateAuthorizationState", "authorization_state": obj{"@type": "authorizationStateWaitPhoneNumber"}})
		case "setAuthenticationPhoneNumber":
			f.Push(obj{"@type": "updateAuthorizationState", "authorization_state": obj{"@type": "authorizationStateWaitCode"}})
		case "checkAuthenticationCode":
			f.Push(obj{"@type": "updateAuthorizationState", "authorization_state": obj{"@type": "authorizationStateWaitPassword"}})
		case "checkAuthenticationPassword":
			f.Push(obj{"@type": "updateOption", "name": "my_id", "value": obj{"@type": "optionValueInteger", "value": "4242"}})
			f.Push(obj{"@type": "updateAuthorizationState", "authorization_state": obj{"@type": "authorizationStateReady"}})
		default:
			if inner != nil {
				return inner(req)
			}
		}
		return nil
	}
	c := NewTD(f, cfg)
	ctx, cancel := context.WithCancel(context.Background())
	t.Cleanup(cancel)
	go c.Run(ctx)
	select {
	case <-c.ready:
	case <-time.After(3 * time.Second):
		t.Fatalf("never became ready; prompts=%v", prompts)
	}
	if want := []string{"verification code", "cloud password"}; len(prompts) != 2 {
		_ = want
	}
	return c, ctx
}

func TestAuthorizationFlow(t *testing.T) {
	f := newFakeTD(nil)
	c, _ := loggedIn(t, f, TDConfig{AppVersion: "1.2.3"})
	params := f.requests("setTdlibParameters")
	if len(params) != 1 || num(params[0]["api_id"]) != 777 || str(params[0], "api_hash") != "hash" ||
		params[0]["use_message_database"] != true || str(params[0], "application_version") != "1.2.3" {
		t.Fatalf("bad setTdlibParameters: %v", params)
	}
	if ph := f.requests("setAuthenticationPhoneNumber"); len(ph) != 1 || str(ph[0], "phone_number") != "+79990001122" {
		t.Fatalf("phone: %v", ph)
	}
	if code := f.requests("checkAuthenticationCode"); len(code) != 1 || str(code[0], "code") != "12345" {
		t.Fatalf("code: %v", code)
	}
	if c.MyID() != 4242 {
		t.Fatalf("my id = %d", c.MyID())
	}
}

func textMsg(id, chat, user int64, text string) obj {
	return obj{"@type": "message", "id": id, "chat_id": chat, "date": 1700000000 + id, "is_outgoing": false,
		"sender_id": obj{"@type": "messageSenderUser", "user_id": user},
		"content":   obj{"@type": "messageText", "text": obj{"@type": "formattedText", "text": text}}}
}

func TestIncomingMessageResolvesNameAndPreservesBigIDs(t *testing.T) {
	f := newFakeTD(func(req obj) obj {
		if str(req, "@type") == "getUser" {
			return obj{"@type": "user", "id": req["user_id"], "first_name": "Alex", "last_name": "K"}
		}
		return nil
	})
	c, _ := loggedIn(t, f, TDConfig{})
	const bigID = int64(1<<53 + 1) // not representable as float64
	raw, _ := json.Marshal(obj{"@type": "updateNewMessage", "message": textMsg(bigID, -1001234567890, 55, "hello")})
	f.out <- raw
	select {
	case m := <-c.Updates():
		if m.ID != bigID || m.ChatID != -1001234567890 || m.SenderName != "Alex K" || m.Text != "hello" || m.Outgoing {
			t.Fatalf("bad message: %+v", m)
		}
	case <-time.After(3 * time.Second):
		t.Fatal("no update")
	}
}

func TestOutgoingMessagesAreNotDelivered(t *testing.T) {
	f := newFakeTD(nil)
	c, _ := loggedIn(t, f, TDConfig{})
	m := textMsg(1, 5, 4242, "mine")
	m["is_outgoing"] = true
	f.Push(obj{"@type": "updateNewMessage", "message": m})
	select {
	case got := <-c.Updates():
		t.Fatalf("own message echoed: %+v", got)
	case <-time.After(300 * time.Millisecond):
	}
}

func TestSendTextShapeAndErrors(t *testing.T) {
	f := newFakeTD(func(req obj) obj {
		switch str(req, "@type") {
		case "sendMessage":
			if strings.Contains(str(sub(sub(req, "input_message_content"), "text"), "text"), "boom") {
				return obj{"@type": "error", "code": 400, "message": "CHAT_WRITE_FORBIDDEN"}
			}
			return obj{"@type": "message", "id": 900, "chat_id": req["chat_id"], "date": 1, "is_outgoing": true,
				"sender_id": obj{"@type": "messageSenderUser", "user_id": 4242},
				"content":   obj{"@type": "messageText", "text": obj{"text": "hi~"}}}
		}
		return nil
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	m, err := c.SendText(ctx, 5, "hi~", 33)
	if err != nil || m.ID != 900 || !m.Outgoing {
		t.Fatalf("send: %+v err=%v", m, err)
	}
	req := f.requests("sendMessage")[0]
	if str(sub(req, "reply_to"), "@type") != "inputMessageReplyToMessage" || num(sub(req, "reply_to")["message_id"]) != 33 ||
		str(sub(req, "input_message_content"), "@type") != "inputMessageText" {
		t.Fatalf("request shape: %v", req)
	}
	if _, err := c.SendText(ctx, 5, "boom", 0); err == nil || !strings.Contains(err.Error(), "CHAT_WRITE_FORBIDDEN") {
		t.Fatalf("tdlib error must surface to the model, got %v", err)
	}
	if r := f.requests("sendMessage")[1]; r["reply_to"] != nil {
		t.Fatalf("no reply expected: %v", r["reply_to"])
	}
}

func TestHistoryOffsetsAndOrder(t *testing.T) {
	f := newFakeTD(func(req obj) obj {
		if str(req, "@type") == "getChatHistory" {
			// newest first, like tdlib
			return obj{"@type": "messages", "messages": []any{textMsg(30, 5, 1, "c"), textMsg(20, 5, 1, "b"), textMsg(10, 5, 1, "a")}}
		}
		if str(req, "@type") == "getUser" {
			return obj{"@type": "user", "id": 1, "first_name": "U"}
		}
		return nil
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	msgs, err := c.History(ctx, 5, 20, 1, 1)
	if err != nil || len(msgs) != 3 || msgs[0].ID != 10 || msgs[2].ID != 30 {
		t.Fatalf("order: %+v err=%v", msgs, err)
	}
	r := f.requests("getChatHistory")[0]
	if num(r["from_message_id"]) != 20 || num(r["offset"]) != -1 || num(r["limit"]) != 3 {
		t.Fatalf("around request: %v", r)
	}
}

func TestUnreadUsesLastReadInbox(t *testing.T) {
	f := newFakeTD(func(req obj) obj {
		switch str(req, "@type") {
		case "getChat":
			return obj{"@type": "chat", "id": 5, "title": "Alex", "type": obj{"@type": "chatTypePrivate", "user_id": 1},
				"unread_count": 2, "last_read_inbox_message_id": 10}
		case "getChatHistory":
			return obj{"@type": "messages", "messages": []any{textMsg(30, 5, 1, "new2"), textMsg(20, 5, 1, "new1"), textMsg(10, 5, 1, "old")}}
		case "getUser":
			return obj{"@type": "user", "id": 1, "first_name": "Alex"}
		}
		return nil
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	un, err := c.Unread(ctx, 5)
	if err != nil || len(un) != 2 || un[0].Text != "new1" || un[1].Text != "new2" || un[0].Read {
		t.Fatalf("unread: %+v err=%v", un, err)
	}
}

func TestEditPicksTextOrCaption(t *testing.T) {
	f := newFakeTD(func(req obj) obj {
		if str(req, "@type") == "getMessage" {
			if num(req["message_id"]) == 1 {
				return textMsg(1, 5, 1, "t")
			}
			return obj{"@type": "message", "id": 2, "chat_id": 5, "content": obj{"@type": "messagePhoto"}}
		}
		return nil
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	if err := c.Edit(ctx, 5, 1, "x"); err != nil {
		t.Fatal(err)
	}
	if err := c.Edit(ctx, 5, 2, "y"); err != nil {
		t.Fatal(err)
	}
	if len(f.requests("editMessageText")) != 1 || len(f.requests("editMessageCaption")) != 1 {
		t.Fatalf("text edits=%d caption edits=%d", len(f.requests("editMessageText")), len(f.requests("editMessageCaption")))
	}
}

func TestReactionStripsVariationSelectorAndModerationShapes(t *testing.T) {
	f := newFakeTD(nil)
	c, ctx := loggedIn(t, f, TDConfig{})
	if err := c.React(ctx, 5, 9, "⚡️"); err != nil {
		t.Fatal(err)
	}
	if e := str(sub(f.requests("addMessageReaction")[0], "reaction_type"), "emoji"); e != "⚡" {
		t.Fatalf("emoji sent as %q", e)
	}
	if err := c.Ban(ctx, -100, 77, true); err != nil {
		t.Fatal(err)
	}
	ban := f.requests("banChatMember")[0]
	if num(sub(ban, "member_id")["user_id"]) != 77 || ban["revoke_messages"] != true {
		t.Fatalf("ban: %v", ban)
	}
	if err := c.SetMemberTag(ctx, -100, 77, "mod"); err != nil {
		t.Fatal(err)
	}
	if tag := f.requests("setChatMemberTag")[0]; str(tag, "tag") != "mod" || num(tag["user_id"]) != 77 {
		t.Fatalf("tag: %v", tag)
	}
}

func TestChatMembershipAndAdmin(t *testing.T) {
	status := "chatMemberStatusAdministrator"
	f := newFakeTD(func(req obj) obj {
		switch str(req, "@type") {
		case "getChat":
			return obj{"@type": "chat", "id": -100, "title": "Club", "type": obj{"@type": "chatTypeSupergroup", "is_channel": false}, "chat_lists": []any{obj{}}}
		case "getChatMember":
			if status == "ERR" {
				return obj{"@type": "error", "code": 400, "message": "USER_NOT_PARTICIPANT"}
			}
			return obj{"@type": "chatMember", "status": obj{"@type": status}}
		}
		return nil
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	ch, err := c.Chat(ctx, -100)
	if err != nil || !ch.IsAdmin || !ch.IsMember || ch.Kind != ChatGroup {
		t.Fatalf("admin chat: %+v err=%v", ch, err)
	}
	c.cmu.Lock()
	delete(c.chats, -100)
	c.cmu.Unlock()
	status = "chatMemberStatusLeft"
	if ch, _ := c.Chat(ctx, -100); ch.IsMember {
		t.Fatalf("left chat reported as member")
	}
	c.cmu.Lock()
	delete(c.chats, -100)
	c.cmu.Unlock()
	status = "ERR" // fallback: member iff in the chat list
	if ch, _ := c.Chat(ctx, -100); !ch.IsMember {
		t.Fatalf("fallback to chat_lists failed")
	}
}

func TestDownloadAndSendPhotoUsesLocalFile(t *testing.T) {
	dir := t.TempDir()
	file := filepath.Join(dir, "a.jpg")
	os.WriteFile(file, []byte("JPEG"), 0o644)
	f := newFakeTD(func(req obj) obj {
		switch str(req, "@type") {
		case "downloadFile":
			return obj{"@type": "file", "id": req["file_id"], "local": obj{"path": file}}
		case "sendMessage":
			return obj{"@type": "message", "id": 1, "chat_id": 5, "is_outgoing": true, "content": obj{"@type": "messagePhoto"}}
		}
		return nil
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	data, err := c.Download(ctx, "123")
	if err != nil || string(data) != "JPEG" {
		t.Fatalf("download: %q %v", data, err)
	}
	if d := f.requests("downloadFile")[0]; d["synchronous"] != true || num(d["file_id"]) != 123 {
		t.Fatalf("download request: %v", d)
	}
	if _, err := c.SendPhoto(ctx, 5, []byte("PNG"), "cap", 0); err != nil {
		t.Fatal(err)
	}
	in := sub(f.requests("sendMessage")[0], "input_message_content")
	path := str(sub(in, "photo"), "path")
	if b, err := os.ReadFile(path); err != nil || string(b) != "PNG" || !filepath.IsAbs(path) {
		t.Fatalf("photo file %q: %q %v", path, b, err)
	}
}

func TestThrottleLimitsRequestRate(t *testing.T) {
	f := newFakeTD(nil)
	c, ctx := loggedIn(t, f, TDConfig{MaxQPS: 5})
	start := time.Now()
	for i := 0; i < 8; i++ {
		if err := c.Typing(ctx, 5); err != nil {
			t.Fatal(err)
		}
	}
	// setup already used some of the first second's budget, so 8 more calls cannot finish instantly
	if time.Since(start) < 500*time.Millisecond {
		t.Fatalf("not throttled: %v", time.Since(start))
	}
}

func TestSearchRoutesByScope(t *testing.T) {
	f := newFakeTD(func(req obj) obj {
		if strings.HasPrefix(str(req, "@type"), "search") {
			return obj{"@type": "foundMessages", "messages": []any{}}
		}
		return nil
	})
	c, ctx := loggedIn(t, f, TDConfig{})
	c.Search(ctx, SearchQuery{Text: "pizza", ChatID: 5, SenderID: 9})
	c.Search(ctx, SearchQuery{Text: "pizza", Since: time.Unix(1700000000, 0)})
	in := f.requests("searchChatMessages")
	gl := f.requests("searchMessages")
	if len(in) != 1 || num(sub(in[0], "sender_id")["user_id"]) != 9 {
		t.Fatalf("scoped search: %v", in)
	}
	if len(gl) != 1 || num(gl[0]["min_date"]) != 1700000000 {
		t.Fatalf("global search: %v", gl)
	}
}
