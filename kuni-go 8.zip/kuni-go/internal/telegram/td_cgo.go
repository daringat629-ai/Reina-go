//go:build tdlib && cgo

package telegram

/*
#cgo LDFLAGS: -ltdjson
#include <stdlib.h>

// tdlib JSON interface (td/telegram/td_json_client.h)
int td_create_client_id(void);
void td_send(int client_id, const char *request);
const char *td_receive(double timeout);
const char *td_execute(const char *request);
*/
import "C"

import (
	"time"
	"unsafe"
)

type jsonTransport struct{ id C.int }

// NewTDJSONTransport creates a libtdjson client. Build with `-tags tdlib` and libtdjson installed.
func NewTDJSONTransport() (Transport, error) {
	q := C.CString(`{"@type":"setLogVerbosityLevel","new_verbosity_level":1}`)
	C.td_execute(q)
	C.free(unsafe.Pointer(q))
	return &jsonTransport{id: C.td_create_client_id()}, nil
}

func (t *jsonTransport) Send(req []byte) {
	s := C.CString(string(req))
	defer C.free(unsafe.Pointer(s))
	C.td_send(t.id, s)
}

func (t *jsonTransport) Receive(timeout time.Duration) []byte {
	p := C.td_receive(C.double(timeout.Seconds()))
	if p == nil {
		return nil
	}
	return []byte(C.GoString(p)) // copy: tdlib reuses the buffer on the next call
}
