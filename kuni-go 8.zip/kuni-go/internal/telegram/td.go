package telegram

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

// Transport moves raw tdlib JSON requests/updates. The real one is a thin cgo
// wrapper over libtdjson (build tag "tdlib", see td_cgo.go); tests use a fake.
type Transport interface {
	// Send submits one request (a JSON object). Safe for concurrent use.
	Send(req []byte)
	// Receive waits up to timeout for the next response/update; nil on timeout.
	// It is called from a single goroutine.
	Receive(timeout time.Duration) []byte
}

// TDConfig configures the user-account client.
type TDConfig struct {
	APIID      int64
	APIHash    string
	Phone      string // optional; asked on stdin when empty
	DBDir      string // tdlib database directory (login is kept here)
	AppVersion string
	// Prompt asks the operator for "phone number", "verification code" or "cloud password".
	// Default: print to stdout and read a line from stdin.
	Prompt func(what string) string
	// MaxQPS throttles requests: Telegram bans accounts of aggressive 3rd party clients. Default 20.
	MaxQPS int
}

type obj = map[string]any

// TDClient implements Client for a *user account* through tdlib's JSON interface,
// exactly what the C++ project does (TelegramClientImpl + td_api).
type TDClient struct {
	tr  Transport
	cfg TDConfig

	seq     atomic.Int64
	mu      sync.Mutex
	pending map[string]chan obj
	updates chan Message
	ready   chan struct{}
	readyOK sync.Once
	closed  chan struct{}
	myID    atomic.Int64

	cmu   sync.Mutex
	users map[int64]string
	chats map[int64]*tdChat

	tmu      sync.Mutex
	callTime []time.Time

	contactsMu sync.Mutex
	contacts   map[int64]bool
	contactsAt time.Time
}

type tdChat struct {
	ID           int64
	Title        string
	Kind         ChatKind
	Unread       int
	LastReadIn   int64
	LastMsgID    int64
	LastText     string
	LastDate     time.Time
	PhotoFileID  int64
	InChatList   bool
	superOrBasic bool
}

func NewTD(tr Transport, cfg TDConfig) *TDClient {
	if cfg.MaxQPS <= 0 {
		cfg.MaxQPS = 20
	}
	if cfg.DBDir == "" {
		cfg.DBDir = "tdlib"
	}
	if cfg.Prompt == nil {
		cfg.Prompt = stdinPrompt
	}
	return &TDClient{tr: tr, cfg: cfg, pending: map[string]chan obj{}, updates: make(chan Message, 256),
		ready: make(chan struct{}), closed: make(chan struct{}), users: map[int64]string{}, chats: map[int64]*tdChat{}}
}

func stdinPrompt(what string) string {
	fmt.Printf("[Authentication] required. Please supply %s: ", what)
	var s string
	fmt.Scanln(&s)
	return strings.TrimSpace(s)
}

func (c *TDClient) Updates() <-chan Message { return c.updates }
func (c *TDClient) MyID() int64             { return c.myID.Load() }

// ---- JSON helpers ----

func decode(raw []byte) (obj, error) {
	var m obj
	d := json.NewDecoder(bytes.NewReader(raw))
	d.UseNumber() // ids exceed 2^53 in the wild; keep them exact
	if err := d.Decode(&m); err != nil {
		return nil, err
	}
	return m, nil
}

func str(m obj, k string) string { s, _ := m[k].(string); return s }
func sub(m obj, k string) obj    { s, _ := m[k].(map[string]any); return s }
func arr(m obj, k string) []any  { s, _ := m[k].([]any); return s }
func typ(m obj) string           { return str(m, "@type") }

func num(v any) int64 {
	switch t := v.(type) {
	case json.Number:
		if n, err := t.Int64(); err == nil {
			return n
		}
		f, _ := t.Float64()
		return int64(f)
	case string: // tdlib's JSON interface encodes int64 fields (e.g. my_id) as strings
		n, _ := strconv.ParseInt(t, 10, 64)
		return n
	case float64:
		return int64(t)
	case int64:
		return t
	case int:
		return int64(t)
	}
	return 0
}

func toObj(v any) obj { m, _ := v.(map[string]any); return m }

// ---- request plumbing ----

func (c *TDClient) throttle(ctx context.Context) error {
	for {
		c.tmu.Lock()
		now := time.Now()
		cut := now.Add(-time.Second)
		i := 0
		for i < len(c.callTime) && c.callTime[i].Before(cut) {
			i++
		}
		c.callTime = c.callTime[i:]
		if len(c.callTime) < c.cfg.MaxQPS {
			c.callTime = append(c.callTime, now)
			c.tmu.Unlock()
			return nil
		}
		wait := c.callTime[0].Add(time.Second).Sub(now)
		c.tmu.Unlock()
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-time.After(wait):
		}
	}
}

// call sends a request and waits for its response; tdlib "error" objects become Go errors.
func (c *TDClient) call(ctx context.Context, req obj) (obj, error) {
	if err := c.throttle(ctx); err != nil {
		return nil, err
	}
	id := strconv.FormatInt(c.seq.Add(1), 10)
	req["@extra"] = id
	raw, err := json.Marshal(req)
	if err != nil {
		return nil, err
	}
	ch := make(chan obj, 1)
	c.mu.Lock()
	c.pending[id] = ch
	c.mu.Unlock()
	defer func() { c.mu.Lock(); delete(c.pending, id); c.mu.Unlock() }()
	c.tr.Send(raw)
	select {
	case <-ctx.Done():
		return nil, ctx.Err()
	case <-c.closed:
		return nil, errors.New("tdlib closed")
	case resp := <-ch:
		if typ(resp) == "error" {
			return nil, fmt.Errorf("telegram %v: %s", resp["code"], str(resp, "message"))
		}
		return resp, nil
	}
}

func (c *TDClient) waitReady(ctx context.Context) error {
	select {
	case <-c.ready:
		return nil
	case <-ctx.Done():
		return ctx.Err()
	}
}

// api waits for login and then calls.
func (c *TDClient) api(ctx context.Context, req obj) (obj, error) {
	if err := c.waitReady(ctx); err != nil {
		return nil, err
	}
	return c.call(ctx, req)
}

// Run drives tdlib (authorization, updates) until ctx ends.
func (c *TDClient) Run(ctx context.Context) error {
	c.tr.Send([]byte(`{"@type":"getOption","name":"version"}`)) // starts the client
	done := make(chan struct{})
	go func() {
		defer close(done)
		for ctx.Err() == nil {
			raw := c.tr.Receive(time.Second)
			if raw == nil {
				continue
			}
			m, err := decode(raw)
			if err != nil {
				continue
			}
			c.dispatch(ctx, m)
		}
	}()
	<-ctx.Done()
	// graceful close so tdlib flushes its database.
	c.tr.Send([]byte(`{"@type":"close"}`))
	select {
	case <-c.closed:
	case <-time.After(5 * time.Second):
	}
	<-done
	return nil
}

func (c *TDClient) dispatch(ctx context.Context, m obj) {
	if extra := str(m, "@extra"); extra != "" {
		c.mu.Lock()
		ch := c.pending[extra]
		c.mu.Unlock()
		if ch != nil {
			ch <- m
		}
		return
	}
	switch typ(m) {
	case "updateAuthorizationState":
		c.onAuthState(ctx, sub(m, "authorization_state"))
	case "updateOption":
		if str(m, "name") == "my_id" {
			c.myID.Store(num(sub(m, "value")["value"]))
		}
	case "updateUser":
		u := sub(m, "user")
		c.cmu.Lock()
		c.users[num(u["id"])] = userDisplay(u)
		c.cmu.Unlock()
	case "updateNewChat":
		c.storeChat(sub(m, "chat"))
	case "updateChatLastMessage":
		c.cmu.Lock()
		if ch := c.chats[num(m["chat_id"])]; ch != nil {
			if lm := sub(m, "last_message"); lm != nil {
				ch.LastMsgID, ch.LastDate, ch.LastText = num(lm["id"]), time.Unix(num(lm["date"]), 0), contentPreview(sub(lm, "content"))
			}
		}
		c.cmu.Unlock()
	case "updateChatReadInbox":
		c.cmu.Lock()
		if ch := c.chats[num(m["chat_id"])]; ch != nil {
			ch.LastReadIn, ch.Unread = num(m["last_read_inbox_message_id"]), int(num(m["unread_count"]))
		}
		c.cmu.Unlock()
	case "updateChatTitle":
		c.cmu.Lock()
		if ch := c.chats[num(m["chat_id"])]; ch != nil {
			ch.Title = str(m, "title")
		}
		c.cmu.Unlock()
	case "updateNewMessage":
		msg := sub(m, "message")
		if msg == nil || msg["is_outgoing"] == true {
			return
		}
		go func() { // resolving names may need a round trip; never block the receive loop
			out := c.parseMessage(ctx, msg)
			select {
			case c.updates <- out:
			default:
			}
		}()
	}
}

func (c *TDClient) onAuthState(ctx context.Context, st obj) {
	go func() {
		var err error
		switch typ(st) {
		case "authorizationStateWaitTdlibParameters":
			_, err = c.call(ctx, obj{"@type": "setTdlibParameters", "database_directory": c.cfg.DBDir, "use_message_database": true,
				"use_secret_chats": true, "api_id": c.cfg.APIID, "api_hash": c.cfg.APIHash, "system_language_code": "en",
				"device_model": "Desktop", "application_version": c.cfg.AppVersion})
		case "authorizationStateWaitPhoneNumber":
			phone := c.cfg.Phone
			if phone == "" {
				phone = c.cfg.Prompt("phone number")
			}
			_, err = c.call(ctx, obj{"@type": "setAuthenticationPhoneNumber", "phone_number": phone})
		case "authorizationStateWaitCode":
			_, err = c.call(ctx, obj{"@type": "checkAuthenticationCode", "code": c.cfg.Prompt("verification code")})
		case "authorizationStateWaitPassword":
			_, err = c.call(ctx, obj{"@type": "checkAuthenticationPassword", "password": c.cfg.Prompt("cloud password")})
		case "authorizationStateReady":
			c.readyOK.Do(func() { close(c.ready) })
		case "authorizationStateClosed":
			select {
			case <-c.closed:
			default:
				close(c.closed)
			}
		}
		if err != nil && ctx.Err() == nil {
			fmt.Fprintf(os.Stderr, "telegram auth (%s): %v\n", typ(st), err)
		}
	}()
}

// ---- caches / conversion ----

func userDisplay(u obj) string {
	name := strings.TrimSpace(str(u, "first_name") + " " + str(u, "last_name"))
	if name == "" {
		if un := sub(u, "usernames"); un != nil {
			if a := arr(un, "active_usernames"); len(a) > 0 {
				name, _ = a[0].(string)
			}
		}
	}
	return name
}

func (c *TDClient) userName(ctx context.Context, id int64) string {
	c.cmu.Lock()
	n, ok := c.users[id]
	c.cmu.Unlock()
	if ok {
		return n
	}
	u, err := c.call(ctx, obj{"@type": "getUser", "user_id": id})
	if err != nil {
		return "user " + strconv.FormatInt(id, 10)
	}
	n = userDisplay(u)
	c.cmu.Lock()
	c.users[id] = n
	c.cmu.Unlock()
	return n
}

func (c *TDClient) storeChat(ch obj) *tdChat {
	if ch == nil {
		return nil
	}
	t := &tdChat{ID: num(ch["id"]), Title: str(ch, "title"), Unread: int(num(ch["unread_count"])), LastReadIn: num(ch["last_read_inbox_message_id"]),
		InChatList: len(arr(ch, "chat_lists")) > 0}
	ty := sub(ch, "type")
	switch typ(ty) {
	case "chatTypePrivate", "chatTypeSecret":
		t.Kind = ChatPrivate
	case "chatTypeBasicGroup":
		t.Kind, t.superOrBasic = ChatGroup, true
	case "chatTypeSupergroup":
		t.superOrBasic = true
		if ty["is_channel"] == true {
			t.Kind = ChatChannel
		} else {
			t.Kind = ChatGroup
		}
	}
	if lm := sub(ch, "last_message"); lm != nil {
		t.LastMsgID, t.LastDate, t.LastText = num(lm["id"]), time.Unix(num(lm["date"]), 0), contentPreview(sub(lm, "content"))
	}
	if p := sub(ch, "photo"); p != nil {
		t.PhotoFileID = num(sub(p, "big")["id"])
	}
	c.cmu.Lock()
	c.chats[t.ID] = t
	c.cmu.Unlock()
	return t
}

func (c *TDClient) chatInfo(ctx context.Context, id int64) (*tdChat, error) {
	c.cmu.Lock()
	t := c.chats[id]
	c.cmu.Unlock()
	if t != nil {
		return t, nil
	}
	ch, err := c.api(ctx, obj{"@type": "getChat", "chat_id": id})
	if err != nil {
		return nil, err
	}
	return c.storeChat(ch), nil
}

func contentPreview(content obj) string {
	switch typ(content) {
	case "messageText":
		return str(sub(content, "text"), "text")
	case "messagePhoto":
		return "[photo] " + str(sub(content, "caption"), "text")
	case "messageVoiceNote":
		return "[voice message]"
	case "messageVideo", "messageVideoNote", "messageAnimation":
		return "[video]"
	case "messageSticker":
		return "[sticker] " + str(sub(content, "sticker"), "emoji")
	}
	return "[" + typ(content) + "]"
}

func (c *TDClient) parseMessage(ctx context.Context, m obj) Message {
	out := Message{ID: num(m["id"]), ChatID: num(m["chat_id"]), Date: time.Unix(num(m["date"]), 0), Outgoing: m["is_outgoing"] == true,
		Edited: num(m["edit_date"]) > 0}
	snd := sub(m, "sender_id")
	switch typ(snd) {
	case "messageSenderUser":
		out.SenderID = num(snd["user_id"])
		out.SenderName = c.userName(ctx, out.SenderID)
	case "messageSenderChat":
		out.SenderID = num(snd["chat_id"])
		c.cmu.Lock()
		if ch := c.chats[out.SenderID]; ch != nil {
			out.SenderName = ch.Title
		}
		c.cmu.Unlock()
	}
	content := sub(m, "content")
	out.Text = contentPreview(content)
	switch typ(content) {
	case "messageText":
		out.Text = str(sub(content, "text"), "text")
	case "messagePhoto":
		out.Media, out.Text = MediaPhoto, str(sub(content, "caption"), "text")
		if sizes := arr(sub(content, "photo"), "sizes"); len(sizes) > 0 {
			out.FileID = strconv.FormatInt(num(sub(toObj(sizes[len(sizes)-1]), "photo")["id"]), 10)
		}
	case "messageVoiceNote":
		out.Media, out.Text = MediaVoice, str(sub(content, "caption"), "text")
		out.FileID = strconv.FormatInt(num(sub(sub(content, "voice_note"), "voice")["id"]), 10)
	case "messageVideo":
		out.Media, out.Text = MediaVideo, str(sub(content, "caption"), "text")
		out.FileID = strconv.FormatInt(num(sub(sub(content, "video"), "video")["id"]), 10)
	case "messageVideoNote":
		out.Media, out.Text = MediaVideo, ""
		out.FileID = strconv.FormatInt(num(sub(sub(content, "video_note"), "video")["id"]), 10)
	case "messageAnimation":
		out.Media, out.Text = MediaVideo, str(sub(content, "caption"), "text")
		out.FileID = strconv.FormatInt(num(sub(sub(content, "animation"), "animation")["id"]), 10)
	case "messageSticker":
		st := sub(content, "sticker")
		out.Media, out.Text = MediaSticker, str(st, "emoji")
		out.FileID = strconv.FormatInt(num(sub(st, "sticker")["id"]), 10)
	}
	if rt := sub(m, "reply_to"); typ(rt) == "messageReplyToMessage" {
		out.ReplyTo = num(rt["message_id"])
	}
	if fi := sub(m, "forward_info"); fi != nil {
		o := sub(fi, "origin")
		switch typ(o) {
		case "messageOriginUser":
			out.ForwardFrom = c.userName(ctx, num(o["sender_user_id"]))
		case "messageOriginHiddenUser":
			out.ForwardFrom = str(o, "sender_name")
		case "messageOriginChannel", "messageOriginChat":
			out.ForwardFrom = str(o, "author_signature")
			if out.ForwardFrom == "" {
				out.ForwardFrom = "chat"
			}
		}
	}
	if ii := sub(m, "interaction_info"); ii != nil {
		for _, r := range arr(sub(ii, "reactions"), "reactions") {
			if t := sub(toObj(r), "type"); typ(t) == "reactionTypeEmoji" {
				out.Reactions = append(out.Reactions, str(t, "emoji"))
			}
		}
	}
	if out.Outgoing {
		out.Read = true
	} else {
		c.cmu.Lock()
		if ch := c.chats[out.ChatID]; ch != nil {
			out.Read = out.ID <= ch.LastReadIn
		}
		c.cmu.Unlock()
	}
	return out
}

func (c *TDClient) toChat(t *tdChat) Chat {
	return Chat{ID: t.ID, Title: t.Title, Kind: t.Kind, Unread: t.Unread, IsMember: true, LastText: t.LastText, LastDate: t.LastDate}
}

// ---- Client: reading ----

func (c *TDClient) Chats(ctx context.Context, limit int) ([]Chat, error) {
	if limit <= 0 {
		limit = 50
	}
	r, err := c.api(ctx, obj{"@type": "getChats", "chat_list": obj{"@type": "chatListMain"}, "limit": limit})
	if err != nil {
		return nil, err
	}
	var out []Chat
	for _, idv := range arr(r, "chat_ids") {
		t, err := c.chatInfo(ctx, num(idv))
		if err != nil {
			continue
		}
		out = append(out, c.toChat(t))
	}
	return out, nil
}

func (c *TDClient) Chat(ctx context.Context, id int64) (Chat, error) {
	t, err := c.chatInfo(ctx, id)
	if err != nil {
		return Chat{}, err
	}
	ch := c.toChat(t)
	if t.superOrBasic {
		// membership / admin status, like the C++ getChatMember(myId) check
		r, err := c.call(ctx, obj{"@type": "getChatMember", "chat_id": id, "member_id": obj{"@type": "messageSenderUser", "user_id": c.MyID()}})
		if err != nil {
			ch.IsMember = t.InChatList // large channels hide the member list
		} else {
			switch typ(sub(r, "status")) {
			case "chatMemberStatusLeft", "chatMemberStatusBanned":
				ch.IsMember = false
			case "chatMemberStatusCreator", "chatMemberStatusAdministrator":
				ch.IsAdmin = true
			}
		}
	}
	return ch, nil
}

func (c *TDClient) SearchChats(ctx context.Context, q string) ([]Chat, error) {
	var ids []int64
	if strings.HasPrefix(q, "@") {
		r, err := c.api(ctx, obj{"@type": "searchPublicChat", "username": strings.TrimPrefix(q, "@")})
		if err == nil {
			ids = append(ids, num(r["id"]))
			c.storeChat(r)
		}
	}
	r, err := c.api(ctx, obj{"@type": "searchChats", "query": strings.TrimPrefix(q, "@"), "limit": 20})
	if err != nil {
		return nil, err
	}
	for _, v := range arr(r, "chat_ids") {
		ids = append(ids, num(v))
	}
	var out []Chat
	seen := map[int64]bool{}
	for _, id := range ids {
		if seen[id] {
			continue
		}
		seen[id] = true
		if t, err := c.chatInfo(ctx, id); err == nil {
			out = append(out, c.toChat(t))
		}
	}
	return out, nil
}

func (c *TDClient) history(ctx context.Context, chatID, from int64, offset, limit int) ([]Message, error) {
	r, err := c.api(ctx, obj{"@type": "getChatHistory", "chat_id": chatID, "from_message_id": from, "offset": offset, "limit": limit})
	if err != nil {
		return nil, err
	}
	return c.parseList(ctx, arr(r, "messages"), true), nil
}

// parseList converts tdlib's newest-first list; reverse makes it oldest-first.
func (c *TDClient) parseList(ctx context.Context, list []any, reverse bool) []Message {
	out := make([]Message, 0, len(list))
	for _, v := range list {
		if m := toObj(v); m != nil {
			out = append(out, c.parseMessage(ctx, m))
		}
	}
	if reverse {
		for i, j := 0, len(out)-1; i < j; i, j = i+1, j-1 {
			out[i], out[j] = out[j], out[i]
		}
	}
	return out
}

func (c *TDClient) Unread(ctx context.Context, chatID int64) ([]Message, error) {
	t, err := c.chatInfo(ctx, chatID)
	if err != nil {
		return nil, err
	}
	if t.Unread <= 0 {
		return nil, nil
	}
	n := t.Unread
	if n > 100 {
		n = 100
	}
	msgs, err := c.history(ctx, chatID, 0, 0, n)
	if err != nil {
		return nil, err
	}
	var out []Message
	for _, m := range msgs {
		if !m.Outgoing && m.ID > t.LastReadIn {
			out = append(out, m)
		}
	}
	return out, nil
}

func (c *TDClient) History(ctx context.Context, chatID, aroundID int64, before, after int) ([]Message, error) {
	if aroundID == 0 {
		return c.history(ctx, chatID, 0, 0, before+1)
	}
	// a negative offset returns `after` newer messages, the anchor, and older ones.
	return c.history(ctx, chatID, aroundID, -after, before+after+1)
}

func (c *TDClient) Message(ctx context.Context, chatID, msgID int64) (Message, error) {
	r, err := c.api(ctx, obj{"@type": "getMessage", "chat_id": chatID, "message_id": msgID})
	if err != nil {
		return Message{}, err
	}
	return c.parseMessage(ctx, r), nil
}

func (c *TDClient) Search(ctx context.Context, q SearchQuery) ([]Message, error) {
	limit := q.Limit
	if limit <= 0 {
		limit = 20
	}
	var req obj
	if q.ChatID != 0 {
		req = obj{"@type": "searchChatMessages", "chat_id": q.ChatID, "query": q.Text, "from_message_id": 0, "offset": 0, "limit": limit}
		if q.SenderID != 0 {
			req["sender_id"] = obj{"@type": "messageSenderUser", "user_id": q.SenderID}
		}
	} else {
		req = obj{"@type": "searchMessages", "chat_list": obj{"@type": "chatListMain"}, "query": q.Text, "offset": "", "limit": limit}
		if !q.Since.IsZero() {
			req["min_date"] = q.Since.Unix()
		}
	}
	r, err := c.api(ctx, req)
	if err != nil {
		return nil, err
	}
	msgs := c.parseList(ctx, arr(r, "messages"), false)
	var out []Message
	for _, m := range msgs {
		if q.SenderID != 0 && m.SenderID != q.SenderID {
			continue
		}
		if !q.Since.IsZero() && m.Date.Before(q.Since) {
			continue
		}
		out = append(out, m)
	}
	return out, nil
}

// MarkRead opens the chat and views its latest message with force_read, like a human opening it.
func (c *TDClient) MarkRead(ctx context.Context, chatID int64) error {
	t, err := c.chatInfo(ctx, chatID)
	if err != nil {
		return err
	}
	if t.LastMsgID == 0 {
		return nil
	}
	if _, err := c.call(ctx, obj{"@type": "viewMessages", "chat_id": chatID, "message_ids": []int64{t.LastMsgID}, "force_read": true}); err != nil {
		return err
	}
	c.cmu.Lock()
	t.Unread, t.LastReadIn = 0, t.LastMsgID
	c.cmu.Unlock()
	return nil
}

// SetOnline toggles the account's online status (the C++ bot only appears online while active).
func (c *TDClient) SetOnline(ctx context.Context, online bool) {
	_, _ = c.api(ctx, obj{"@type": "setOption", "name": "online", "value": obj{"@type": "optionValueBoolean", "value": online}})
}

// Contacts returns the user's contact ids (cached 5 minutes); used by lockdown=contacts_only.
func (c *TDClient) Contacts(ctx context.Context) map[int64]bool {
	c.contactsMu.Lock()
	defer c.contactsMu.Unlock()
	if c.contacts != nil && time.Since(c.contactsAt) < 5*time.Minute {
		return c.contacts
	}
	r, err := c.api(ctx, obj{"@type": "getContacts"})
	if err != nil {
		return c.contacts
	}
	m := map[int64]bool{}
	for _, v := range arr(r, "user_ids") {
		m[num(v)] = true
	}
	c.contacts, c.contactsAt = m, time.Now()
	return m
}

// ---- Client: acting ----

func formatted(text string) obj { return obj{"@type": "formattedText", "text": text} }

func replyTo(id int64) any {
	if id == 0 {
		return nil
	}
	return obj{"@type": "inputMessageReplyToMessage", "message_id": id}
}

func (c *TDClient) send(ctx context.Context, chatID, reply int64, content obj) (Message, error) {
	r, err := c.api(ctx, obj{"@type": "sendMessage", "chat_id": chatID, "reply_to": replyTo(reply), "input_message_content": content})
	if err != nil {
		return Message{}, err
	}
	return c.parseMessage(ctx, r), nil
}

func (c *TDClient) SendText(ctx context.Context, chatID int64, text string, reply int64) (Message, error) {
	return c.send(ctx, chatID, reply, obj{"@type": "inputMessageText", "text": formatted(text)})
}

func (c *TDClient) outboxFile(name string, data []byte) (string, error) {
	dir, err := filepath.Abs(filepath.Join(c.cfg.DBDir, "outbox"))
	if err != nil {
		return "", err
	}
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return "", err
	}
	p := filepath.Join(dir, fmt.Sprintf("%d_%s", time.Now().UnixNano(), name))
	return p, os.WriteFile(p, data, 0o644)
}

func (c *TDClient) SendPhoto(ctx context.Context, chatID int64, data []byte, caption string, reply int64) (Message, error) {
	p, err := c.outboxFile("photo.jpg", data)
	if err != nil {
		return Message{}, err
	}
	return c.send(ctx, chatID, reply, obj{"@type": "inputMessagePhoto", "photo": obj{"@type": "inputFileLocal", "path": p}, "caption": formatted(caption)})
}

func (c *TDClient) SendVoice(ctx context.Context, chatID int64, data []byte, reply int64) (Message, error) {
	p, err := c.outboxFile("voice.ogg", data)
	if err != nil {
		return Message{}, err
	}
	return c.send(ctx, chatID, reply, obj{"@type": "inputMessageVoiceNote", "voice_note": obj{"@type": "inputFileLocal", "path": p}})
}

func (c *TDClient) SendSticker(ctx context.Context, chatID int64, fileID string, reply int64) (Message, error) {
	id, err := strconv.ParseInt(fileID, 10, 64)
	if err != nil {
		return Message{}, fmt.Errorf("bad sticker file id %q", fileID)
	}
	return c.send(ctx, chatID, reply, obj{"@type": "inputMessageSticker", "sticker": obj{"@type": "inputFileId", "id": id}})
}

// Edit changes text; for media messages it edits the caption (see the C++ fix "caption editing for media messages").
func (c *TDClient) Edit(ctx context.Context, chatID, msgID int64, text string) error {
	m, err := c.api(ctx, obj{"@type": "getMessage", "chat_id": chatID, "message_id": msgID})
	if err != nil {
		return err
	}
	if typ(sub(m, "content")) == "messageText" {
		_, err = c.call(ctx, obj{"@type": "editMessageText", "chat_id": chatID, "message_id": msgID,
			"input_message_content": obj{"@type": "inputMessageText", "text": formatted(text)}})
	} else {
		_, err = c.call(ctx, obj{"@type": "editMessageCaption", "chat_id": chatID, "message_id": msgID, "caption": formatted(text)})
	}
	return err
}

func (c *TDClient) Delete(ctx context.Context, chatID, msgID int64) error {
	_, err := c.api(ctx, obj{"@type": "deleteMessages", "chat_id": chatID, "message_ids": []int64{msgID}, "revoke": true})
	return err
}

func (c *TDClient) Forward(ctx context.Context, from, msgID, to int64) error {
	_, err := c.api(ctx, obj{"@type": "forwardMessages", "chat_id": to, "from_chat_id": from, "message_ids": []int64{msgID}})
	return err
}

func (c *TDClient) React(ctx context.Context, chatID, msgID int64, emoji string) error {
	emoji = strings.ReplaceAll(emoji, "️", "") // the chat's reaction list is stored without the variation selector
	_, err := c.api(ctx, obj{"@type": "addMessageReaction", "chat_id": chatID, "message_id": msgID,
		"reaction_type": obj{"@type": "reactionTypeEmoji", "emoji": emoji}, "is_big": false, "update_recent_reactions": true})
	return err
}

func (c *TDClient) Typing(ctx context.Context, chatID int64) error {
	_, err := c.api(ctx, obj{"@type": "sendChatAction", "chat_id": chatID, "action": obj{"@type": "chatActionTyping"}})
	return err
}

func (c *TDClient) Join(ctx context.Context, link string) error {
	link = strings.TrimSpace(link)
	switch {
	case strings.HasPrefix(link, "@"):
		r, err := c.api(ctx, obj{"@type": "searchPublicChat", "username": strings.TrimPrefix(link, "@")})
		if err != nil {
			return err
		}
		_, err = c.call(ctx, obj{"@type": "joinChat", "chat_id": num(r["id"])})
		return err
	case strings.Contains(link, "t.me/") || strings.HasPrefix(link, "http"):
		_, err := c.api(ctx, obj{"@type": "joinChatByInviteLink", "invite_link": link})
		return err
	}
	id, err := strconv.ParseInt(link, 10, 64)
	if err != nil {
		return fmt.Errorf("don't know how to join %q: pass an invite link, @username or chat id", link)
	}
	_, err = c.api(ctx, obj{"@type": "joinChat", "chat_id": id})
	return err
}

func (c *TDClient) Leave(ctx context.Context, chatID int64) error {
	_, err := c.api(ctx, obj{"@type": "leaveChat", "chat_id": chatID})
	return err
}

func (c *TDClient) Ban(ctx context.Context, chatID, userID int64, removeAll bool) error {
	_, err := c.api(ctx, obj{"@type": "banChatMember", "chat_id": chatID,
		"member_id": obj{"@type": "messageSenderUser", "user_id": userID}, "banned_until_date": 0, "revoke_messages": removeAll})
	return err
}

func (c *TDClient) SetMemberTag(ctx context.Context, chatID, userID int64, tag string) error {
	_, err := c.api(ctx, obj{"@type": "setChatMemberTag", "chat_id": chatID, "user_id": userID, "tag": tag})
	return err
}

// Block removes the private chat's history and blocks the user (remove_and_ban_chat for private chats).
func (c *TDClient) Block(ctx context.Context, chatID int64) error {
	if _, err := c.api(ctx, obj{"@type": "setMessageSenderBlockList", "sender_id": obj{"@type": "messageSenderUser", "user_id": chatID},
		"block_list": obj{"@type": "blockListMain"}}); err != nil {
		return err
	}
	_, err := c.call(ctx, obj{"@type": "deleteChatHistory", "chat_id": chatID, "remove_from_chat_list": true, "revoke": true})
	return err
}

func (c *TDClient) Download(ctx context.Context, fileID string) ([]byte, error) {
	id, err := strconv.ParseInt(fileID, 10, 64)
	if err != nil {
		return nil, fmt.Errorf("bad file id %q", fileID)
	}
	r, err := c.api(ctx, obj{"@type": "downloadFile", "file_id": id, "priority": 1, "offset": 0, "limit": 0, "synchronous": true})
	if err != nil {
		return nil, err
	}
	path := str(sub(r, "local"), "path")
	if path == "" {
		return nil, errors.New("tdlib returned no local path")
	}
	return os.ReadFile(path)
}

func (c *TDClient) ChatPhoto(ctx context.Context, chatID int64) ([]byte, error) {
	t, err := c.chatInfo(ctx, chatID)
	if err != nil {
		return nil, err
	}
	if t.PhotoFileID == 0 {
		return nil, errors.New("chat has no photo")
	}
	return c.Download(ctx, strconv.FormatInt(t.PhotoFileID, 10))
}

var _ Client = (*TDClient)(nil)
