// Package telegram is the Telegram layer. Client is the interface the agent and
// tools depend on. BotClient implements it over the Telegram Bot API (stdlib
// only); Fake implements it in memory for tests. The original C++ project uses
// tdlib (a full user account) — a tdlib-backed Client can be added later
// without touching the agent or tools.
package telegram

import (
	"context"
	"time"
)

type ChatKind string

const (
	ChatPrivate ChatKind = "private"
	ChatGroup   ChatKind = "group"
	ChatChannel ChatKind = "channel"
)

type MediaKind string

const (
	MediaNone    MediaKind = ""
	MediaPhoto   MediaKind = "photo"
	MediaVoice   MediaKind = "voice"
	MediaVideo   MediaKind = "video"
	MediaSticker MediaKind = "sticker"
)

type Chat struct {
	ID       int64     `json:"id"`
	Title    string    `json:"title"`
	Kind     ChatKind  `json:"kind"`
	Unread   int       `json:"unread"`
	IsMember bool      `json:"is_member"`
	IsAdmin  bool      `json:"is_admin"`
	LastText string    `json:"last_text,omitempty"`
	LastDate time.Time `json:"last_date"`
}

type Message struct {
	ID          int64     `json:"id"`
	ChatID      int64     `json:"chat_id"`
	SenderID    int64     `json:"sender_id"`
	SenderName  string    `json:"sender_name"`
	Date        time.Time `json:"date"`
	Text        string    `json:"text"`
	ReplyTo     int64     `json:"reply_to,omitempty"`
	ForwardFrom string    `json:"forward_from,omitempty"`
	Media       MediaKind `json:"media,omitempty"`
	FileID      string    `json:"file_id,omitempty"`
	Outgoing    bool      `json:"outgoing,omitempty"`
	Read        bool      `json:"read,omitempty"`
	Edited      bool      `json:"edited,omitempty"`
	Reactions   []string  `json:"reactions,omitempty"`
}

type SearchQuery struct {
	Text     string
	ChatID   int64 // 0 = all chats
	SenderID int64 // 0 = anyone
	Since    time.Time
	Limit    int
}

// Client is everything Kuni needs from Telegram.
type Client interface {
	// Run blocks, receiving updates into Updates() until ctx ends.
	Run(ctx context.Context) error
	// Updates delivers incoming (non-outgoing) messages.
	Updates() <-chan Message
	MyID() int64

	Chats(ctx context.Context, limit int) ([]Chat, error)
	Chat(ctx context.Context, id int64) (Chat, error)
	SearchChats(ctx context.Context, query string) ([]Chat, error)
	Unread(ctx context.Context, chatID int64) ([]Message, error)
	History(ctx context.Context, chatID, aroundID int64, before, after int) ([]Message, error)
	Message(ctx context.Context, chatID, msgID int64) (Message, error)
	Search(ctx context.Context, q SearchQuery) ([]Message, error)
	MarkRead(ctx context.Context, chatID int64) error

	SendText(ctx context.Context, chatID int64, text string, replyTo int64) (Message, error)
	SendPhoto(ctx context.Context, chatID int64, data []byte, caption string, replyTo int64) (Message, error)
	SendVoice(ctx context.Context, chatID int64, data []byte, replyTo int64) (Message, error)
	SendSticker(ctx context.Context, chatID int64, fileID string, replyTo int64) (Message, error)
	Edit(ctx context.Context, chatID, msgID int64, text string) error
	Delete(ctx context.Context, chatID, msgID int64) error
	Forward(ctx context.Context, fromChat, msgID, toChat int64) error
	React(ctx context.Context, chatID, msgID int64, emoji string) error
	Typing(ctx context.Context, chatID int64) error

	Join(ctx context.Context, link string) error
	Leave(ctx context.Context, chatID int64) error
	Ban(ctx context.Context, chatID, userID int64, removeAll bool) error
	SetMemberTag(ctx context.Context, chatID, userID int64, tag string) error

	Download(ctx context.Context, fileID string) ([]byte, error)
	ChatPhoto(ctx context.Context, chatID int64) ([]byte, error)
}
