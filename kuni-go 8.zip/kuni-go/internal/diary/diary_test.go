package diary

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"kuni/internal/llm"
)

func TestParseFormatRoundTrip(t *testing.T) {
	in := Entry{ID: "1700000000", Meta: Metadata{Confidence: 0.5, Embedding: []float64{0.1, 0.2}}, Body: "Alex got a raise."}
	s, err := Format(in)
	if err != nil {
		t.Fatal(err)
	}
	out := Parse(in.ID, s)
	if out.Body != in.Body || out.Meta.Confidence != 0.5 || len(out.Meta.Embedding) != 2 {
		t.Fatalf("round trip mismatch: %+v", out)
	}
}

func TestParseWithoutPrologue(t *testing.T) {
	e := Parse("42", "just text\n")
	if e.Body != "just text" || e.Meta.Confidence != 0 {
		t.Fatalf("got %+v", e)
	}
}

func TestParseBrokenJSONKeepsBody(t *testing.T) {
	e := Parse("42", "---\n{not json}\n---\nbody")
	if !strings.Contains(e.Body, "not json") {
		t.Fatalf("broken prologue should fall back to whole text, got %q", e.Body)
	}
}

// fakeLLM serves /embeddings with a vector derived from the input length, and
// /chat/completions with a fixed consolidation answer.
func fakeLLM(t *testing.T, answer string) *httptest.Server {
	return httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		var req map[string]any
		_ = json.NewDecoder(r.Body).Decode(&req)
		switch {
		case strings.HasSuffix(r.URL.Path, "/embeddings"):
			input, _ := req["input"].(string)
			v := []float64{1, float64(len(input) % 3)}
			_ = json.NewEncoder(w).Encode(map[string]any{"data": []any{map[string]any{"embedding": v}}})
		case strings.HasSuffix(r.URL.Path, "/chat/completions"):
			_ = json.NewEncoder(w).Encode(map[string]any{"choices": []any{map[string]any{"message": map[string]any{"role": "assistant", "content": answer}}}})
		default:
			http.NotFound(w, r)
		}
	}))
}

func TestQueryRanksByCosine(t *testing.T) {
	srv := fakeLLM(t, "")
	defer srv.Close()
	dir := t.TempDir()
	c := llm.New(srv.URL+"/", srv.URL+"/", "", "m", "e", 5*time.Second)
	d, err := New(dir, c, 0, 1000)
	if err != nil {
		t.Fatal(err)
	}
	entries := []Entry{
		{ID: "1", Body: "aaaa", Meta: Metadata{Embedding: []float64{1, 0}}},
		{ID: "2", Body: "bb", Meta: Metadata{Embedding: []float64{0, 1}}},
	}
	got, err := d.Query(context.Background(), entries, []float64{1, 0}, 1)
	if err != nil {
		t.Fatal(err)
	}
	if len(got) != 1 || got[0].Entry.ID != "1" {
		t.Fatalf("expected entry 1 as best match, got %+v", got)
	}
}

func TestConsolidateReplacesLowConfidenceFiles(t *testing.T) {
	answer := `{"confidence": 0.7}
Merged memory about the raise.
---
{"confidence": -1}
trash that should be dropped`
	srv := fakeLLM(t, answer)
	defer srv.Close()
	dir := t.TempDir()
	c := llm.New(srv.URL+"/", srv.URL+"/", "", "m", "e", 5*time.Second)
	d, _ := New(dir, c, 0, 1000)

	mustSave := func(e Entry) {
		if err := d.Save(e); err != nil {
			t.Fatal(err)
		}
	}
	mustSave(Entry{ID: "1000", Body: "Alex got a raise and was happy."})
	mustSave(Entry{ID: "2000", Body: "Alex mentioned the raise again.", Meta: Metadata{Confidence: 0.9999999}})

	if err := d.Consolidate(context.Background(), 3*time.Second); err != nil {
		t.Fatal(err)
	}
	files, _ := filepath.Glob(filepath.Join(dir, "*.md"))
	var bodies []string
	for _, f := range files {
		raw, _ := os.ReadFile(f)
		bodies = append(bodies, Parse(strings.TrimSuffix(filepath.Base(f), ".md"), string(raw)).Body)
	}
	joined := strings.Join(bodies, "|")
	if !strings.Contains(joined, "Merged memory about the raise.") {
		t.Fatalf("consolidated entry missing: %v", bodies)
	}
	if strings.Contains(joined, "trash") {
		t.Fatalf("dropped block was saved: %v", bodies)
	}
	if _, err := os.Stat(filepath.Join(dir, "1000.md")); !os.IsNotExist(err) {
		t.Fatalf("low-confidence source entry should be removed (whether it was the target or a related entry)")
	}
	if _, err := os.Stat(filepath.Join(dir, "2000.md")); err != nil {
		t.Fatalf("entry with confidence=1 is a pinned fact and must never be deleted: %v", err)
	}
}
