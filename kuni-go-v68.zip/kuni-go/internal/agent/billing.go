package agent

import (
	"context"
	"fmt"
	"log"
	"time"

	"kuni/internal/billing"
	"kuni/internal/telegram"
)

// billingAllows counts one conversation for a person in a private chat and says whether she may answer. The owner, groups and a
// switched-off billing are never limited. When the limit is over, the person is told once a day (a fixed text, no paid model call)
// where to get more, and the messages are marked read.
func (a *Agent) billingAllows(ctx context.Context, chat telegram.Chat) bool {
	cfg := a.cfg()
	if !cfg.BillingEnabled || a.Deps.Billing == nil || chat.Kind != telegram.ChatPrivate || cfg.IsOwner(chat.ID) {
		return true
	}
	d := a.Deps.Billing.Take(chat.ID, time.Now(), billing.Limits{Free: int(cfg.BillingFreePerDay), Plus: int(cfg.BillingPlusPerDay), Max: int(cfg.BillingMaxPerDay)})
	if d.OK {
		return true
	}
	if d.TellOnce {
		msg := "На сегодня наши разговоры закончились, завтра лимит обновится."
		if cfg.BillingBotName != "" {
			msg += fmt.Sprintf(" Если хочешь говорить больше, тарифы тут: @%s", cfg.BillingBotName)
		}
		if _, err := a.TG.SendText(ctx, chat.ID, msg, 0); err != nil {
			log.Printf("agent: billing: %v", err)
		}
	}
	_ = a.TG.MarkRead(ctx, chat.ID)
	a.Metrics.Inc("kuni_billing_limited_total", 1, map[string]string{"plan": d.Plan})
	return false
}
