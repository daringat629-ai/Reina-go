package billing

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"net/http"
	"strconv"
	"strings"
	"time"
)

// Bot is the small payment bot: it shows a person their plan and sends invoices in Telegram Stars (currency XTR). Her own Telegram
// account is a user account and cannot send invoices, so payment lives in a separate bot from @BotFather.
type Bot struct {
	Token   string
	BaseURL string // https://api.telegram.org by default (tests point it elsewhere)
	Store   *Store
	Offers  func() []Offer // what can be bought now
	Limits  func() Limits
	Name    string        // the bot's @username (for invite links)
	RefDays func() int    // invite bonus in days (0 = off)
	Support func() string // where to ask about payments
	Loc     *time.Location
	HTTP    *http.Client
	Now     func() time.Time
	OnPaid  func(userID int64, plan string, until time.Time)      // e.g. tell the owner
	Render  func(ctx context.Context, svg string) ([]byte, error) // SVG to PNG for the profile picture (nil = text only)
	Icons   func() []string                                       // custom emoji ids for the menu buttons (plans, profile, friends, help); "" = an ordinary emoji
	offset  int64
}

func (b *Bot) now() time.Time {
	if b.Now != nil {
		return b.Now()
	}
	return time.Now()
}

func (b *Bot) call(ctx context.Context, method string, in, out any) error {
	base := b.BaseURL
	if base == "" {
		base = "https://api.telegram.org"
	}
	body, _ := json.Marshal(in)
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, base+"/bot"+b.Token+"/"+method, bytes.NewReader(body))
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/json")
	hc := b.HTTP
	if hc == nil {
		hc = &http.Client{Timeout: 70 * time.Second}
	}
	resp, err := hc.Do(req)
	if err != nil {
		return fmt.Errorf("billing bot: %s: %w", method, errors.Unwrap(err)) // never put the token (it is in the URL) into a log line
	}
	defer resp.Body.Close()
	var r struct {
		OK          bool            `json:"ok"`
		Result      json.RawMessage `json:"result"`
		Description string          `json:"description"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&r); err != nil {
		return fmt.Errorf("billing bot: %s: bad answer", method)
	}
	if !r.OK {
		return fmt.Errorf("billing bot: %s: %s", method, r.Description)
	}
	if out != nil {
		return json.Unmarshal(r.Result, out)
	}
	return nil
}

type update struct {
	UpdateID int64 `json:"update_id"`
	Message  *struct {
		From struct {
			ID        int64  `json:"id"`
			FirstName string `json:"first_name"`
		} `json:"from"`
		Chat struct {
			ID int64 `json:"id"`
		} `json:"chat"`
		Text              string `json:"text"`
		SuccessfulPayment *struct {
			Currency    string `json:"currency"`
			TotalAmount int    `json:"total_amount"`
			Payload     string `json:"invoice_payload"`
			ChargeID    string `json:"telegram_payment_charge_id"`
		} `json:"successful_payment"`
	} `json:"message"`
	PreCheckout *struct {
		ID       string `json:"id"`
		Currency string `json:"currency"`
		Total    int    `json:"total_amount"`
		Payload  string `json:"invoice_payload"`
	} `json:"pre_checkout_query"`
}

// Run polls the Bot API until ctx ends.
func (b *Bot) Run(ctx context.Context) {
	for ctx.Err() == nil {
		var ups []update
		err := b.call(ctx, "getUpdates", map[string]any{"offset": b.offset, "timeout": 50, "allowed_updates": []string{"message", "pre_checkout_query"}}, &ups)
		if err != nil {
			if ctx.Err() == nil {
				log.Printf("%v", err)
				select {
				case <-ctx.Done():
				case <-time.After(10 * time.Second):
				}
			}
			continue
		}
		for _, u := range ups {
			b.offset = u.UpdateID + 1
			b.handle(ctx, u)
		}
	}
}

// Offer is one thing that can be bought: a plan for a number of days at a price in Stars.
type Offer struct {
	Plan  string
	Days  int
	Stars int
}

// Payload is how an offer travels through an invoice: "plus:7".
func (o Offer) Payload() string { return fmt.Sprintf("%s:%d", o.Plan, o.Days) }

// offer finds the offer behind a payload, if it is still on sale.
func (b *Bot) offer(payload string) (Offer, bool) {
	for _, o := range b.Offers() {
		if o.Payload() == payload && o.Stars > 0 {
			return o, true
		}
	}
	return Offer{}, false
}

func days(n int) string {
	w := "дней"
	switch m10, m100 := n%10, n%100; {
	case m10 == 1 && m100 != 11:
		w = "день"
	case m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14):
		w = "дня"
	}
	return fmt.Sprintf("%d %s", n, w)
}

// Menu buttons: the label people see, an ordinary emoji in front of it when no vector icon is set, and the colour of the button.
type button struct{ label, emoji, style string }

var buttons = []button{{"Подписка", "💳", "primary"}, {"Профиль", "👤", ""}, {"Друзьям", "🤝", "success"}, {"Поддержка", "💬", ""}}

const (
	btnPlans   = "Подписка"
	btnProfile = "Профиль"
	btnFriends = "Друзьям"
	btnHelp    = "Поддержка"
)

// pressed says which menu button a text is, with or without the emoji in front (Telegram sends back only the text).
func pressed(text string) string {
	t := strings.TrimSpace(text)
	for _, b := range buttons {
		if t == b.label || t == b.emoji+" "+b.label {
			return b.label
		}
	}
	return ""
}

func (b *Bot) menu() map[string]any {
	var icons []string
	if b != nil && b.Icons != nil {
		icons = b.Icons()
	}
	row := func(i int) map[string]any {
		x := buttons[i]
		k := map[string]any{"text": x.emoji + " " + x.label}
		if i < len(icons) && strings.TrimSpace(icons[i]) != "" {
			k["text"], k["icon_custom_emoji_id"] = x.label, strings.TrimSpace(icons[i])
		}
		if x.style != "" {
			k["style"] = x.style
		}
		return k
	}
	return map[string]any{"keyboard": [][]map[string]any{{row(0), row(1)}, {row(2), row(3)}}, "resize_keyboard": true, "is_persistent": true}
}

func (b *Bot) handle(ctx context.Context, u update) {
	switch {
	case u.PreCheckout != nil:
		q := u.PreCheckout
		o, on := b.offer(q.Payload)
		ok := q.Currency == "XTR" && on && q.Total == o.Stars
		in := map[string]any{"pre_checkout_query_id": q.ID, "ok": ok}
		if !ok {
			in["error_message"] = "Цена изменилась. Откройте /plans ещё раз."
		}
		if err := b.call(ctx, "answerPreCheckoutQuery", in, nil); err != nil {
			log.Printf("%v", err)
		}
	case u.Message != nil && u.Message.SuccessfulPayment != nil:
		m, p := u.Message, u.Message.SuccessfulPayment
		plan, d, ok := parsePayload(p.Payload)
		if p.Currency != "XTR" || !ok {
			log.Printf("billing bot: an unexpected payment (%s %d %q) from %d, not applied", p.Currency, p.TotalAmount, p.Payload, m.From.ID)
			return
		}
		first := b.Store.Get(m.From.ID, b.now()).Paid == 0
		ref := b.Store.Get(m.From.ID, b.now()).Referrer
		bonus := 0
		if first && ref != 0 && b.RefDays != nil {
			bonus = b.RefDays()
		}
		acc, err := b.Store.Activate(m.From.ID, plan, d+bonus, p.TotalAmount, p.ChargeID, b.now())
		if err != nil {
			log.Printf("%v", err)
			return
		}
		msg := fmt.Sprintf("Спасибо! Тариф %s действует до %s. Можно возвращаться к Рейне.", title(acc.Plan), acc.Until.In(b.loc()).Format("02.01.2006 15:04"))
		if bonus > 0 {
			msg += fmt.Sprintf("\nПлюс %s в подарок по приглашению друга.", days(bonus))
			r := b.Store.Bonus(ref, Plus, bonus, b.now())
			b.send(ctx, ref, fmt.Sprintf("Твой друг оплатил тариф. Тебе %s Plus в подарок, теперь до %s.", days(bonus), r.Until.In(b.loc()).Format("02.01.2006")))
		}
		b.send(ctx, m.Chat.ID, msg)
		if b.OnPaid != nil {
			b.OnPaid(m.From.ID, acc.Plan, acc.Until)
		}
	case u.Message != nil:
		m := u.Message
		text := strings.TrimSpace(m.Text)
		low := strings.ToLower(text)
		switch {
		case strings.HasPrefix(low, "/start"):
			if arg := strings.TrimSpace(strings.TrimPrefix(text, "/start")); strings.HasPrefix(arg, "ref") {
				if by, err := strconv.ParseInt(strings.TrimPrefix(arg, "ref"), 10, 64); err == nil && b.RefDays != nil && b.RefDays() > 0 && b.Store.Refer(m.From.ID, by) {
					b.send(ctx, m.Chat.ID, fmt.Sprintf("Тебя пригласил друг: к первой оплате добавим %s в подарок.", days(b.RefDays())))
				}
			}
			b.sendMenu(ctx, m.Chat.ID, "Здесь можно посмотреть свой тариф и оплатить разговоры с Рейной.\n\n"+b.profile(m.From.ID))
		case low == "/plans" || pressed(text) == btnPlans:
			b.plans(ctx, m.Chat.ID)
		case low == "/status" || low == "/profile" || pressed(text) == btnProfile:
			b.sendCard(ctx, m.Chat.ID, m.From.ID, m.From.FirstName)
		case pressed(text) == btnFriends || low == "/invite":
			b.sendMenu(ctx, m.Chat.ID, b.invite(m.From.ID))
		case pressed(text) == btnHelp || low == "/help":
			sup := ""
			if b.Support != nil {
				sup = b.Support()
			}
			if sup == "" {
				sup = "напиши сюда же, тебе ответят"
			}
			b.sendMenu(ctx, m.Chat.ID, "Вопрос по оплате или тарифу: "+sup+".\nОплата в Telegram Stars, без автопродления: тариф просто заканчивается в срок.")
		default:
			b.sendMenu(ctx, m.Chat.ID, "Выбери в меню ниже: подписка, профиль, друзьям или поддержка.")
		}
	}
}

func title(plan string) string {
	switch plan {
	case Plus:
		return "Plus"
	case Max:
		return "Max"
	}
	return "Старт"
}

func (b *Bot) loc() *time.Location {
	if b.Loc != nil {
		return b.Loc
	}
	return time.Local
}

func parsePayload(p string) (string, int, bool) {
	plan, d, ok := strings.Cut(p, ":")
	n, err := strconv.Atoi(d)
	if !ok || err != nil || n <= 0 || (plan != Plus && plan != Max) {
		return "", 0, false
	}
	return plan, n, true
}

func perDay(n int) string {
	if n <= 0 {
		return "без лимита"
	}
	return fmt.Sprintf("%d в день", n)
}

// bar draws how much of today's limit is used: ▰▰▰▱▱▱▱▱▱▱ 30%.
func bar(used, limit int) string {
	if limit <= 0 {
		return "без лимита"
	}
	f := float64(used) / float64(limit)
	if f > 1 {
		f = 1
	}
	n := int(f*10 + .5)
	return strings.Repeat("▰", n) + strings.Repeat("▱", 10-n) + fmt.Sprintf(" %d%%", int(f*100+.5))
}

// profile is the person's card: plan, today's limit with a bar and the moment it resets, and plain numbers. No rankings, no streaks.
func (b *Bot) profile(id int64) string {
	now := b.now().In(b.loc())
	u := b.Store.Get(id, now)
	limit := b.Limits().of(u.Plan)
	used := 0
	if u.Day == now.Format("2006-01-02") {
		used = u.Used
	}
	reset := time.Date(now.Year(), now.Month(), now.Day()+1, 0, 0, 0, 0, b.loc())
	var sb strings.Builder
	fmt.Fprintf(&sb, "👤 Профиль\n\nТариф: %s (%s)", title(u.Plan), perDay(limit))
	if u.Plan != Free {
		fmt.Fprintf(&sb, ", до %s", u.Until.In(b.loc()).Format("02.01.2006"))
	}
	fmt.Fprintf(&sb, "\n\nСегодня: %d", used)
	if limit > 0 {
		fmt.Fprintf(&sb, " из %d\n%s\nОбновится в %s", limit, bar(used, limit), reset.Format("00:00, 02.01"))
	}
	fmt.Fprintf(&sb, "\n\nРазговоров всего: %d", u.Total)
	if !u.Joined.IsZero() {
		fmt.Fprintf(&sb, "\nС нами с %s", u.Joined.In(b.loc()).Format("02.01.2006"))
	}
	if u.Paid > 0 {
		fmt.Fprintf(&sb, "\nОплат: %d", u.Paid)
	}
	return sb.String()
}

func (b *Bot) invite(id int64) string {
	d := 0
	if b.RefDays != nil {
		d = b.RefDays()
	}
	if d <= 0 || b.Name == "" {
		return "Приглашения сейчас выключены."
	}
	all, paid := b.Store.Invited(id)
	return fmt.Sprintf("🤝 Позови друга\n\nКогда друг впервые оплатит тариф, ему %s в подарок, а тебе %s Plus.\n\nТвоя ссылка:\nhttps://t.me/%s?start=ref%d\n\nПриглашено: %d, оплатили: %d.", days(d), days(d), b.Name, id, all, paid)
}

// plans sends the plans and one invoice per offer that is on sale.
func (b *Bot) plans(ctx context.Context, chat int64) {
	l := b.Limits()
	b.sendMenu(ctx, chat, fmt.Sprintf("💳 Тарифы\n\nСтарт: %s, бесплатно.\nPlus: %s.\nMax: %s.\n\nОплата в Telegram Stars, без автопродления. Можно взять на день, неделю или месяц.", perDay(l.Free), perDay(l.Plus), perDay(l.Max)))
	for _, o := range b.Offers() {
		if o.Stars <= 0 {
			continue
		}
		desc := fmt.Sprintf("%s разговоров с Рейной, %s.", days(o.Days), perDay(l.of(o.Plan)))
		err := b.call(ctx, "sendInvoice", map[string]any{"chat_id": chat, "title": fmt.Sprintf("Рейна · %s · %s", title(o.Plan), days(o.Days)), "description": desc, "payload": o.Payload(),
			"provider_token": "", "currency": "XTR", "prices": []map[string]any{{"label": title(o.Plan) + " · " + days(o.Days), "amount": o.Stars}}}, nil)
		if err != nil {
			log.Printf("%v", err)
		}
	}
}

func (b *Bot) sendMenu(ctx context.Context, chat int64, text string) {
	if err := b.call(ctx, "sendMessage", map[string]any{"chat_id": chat, "text": text, "reply_markup": b.menu()}, nil); err != nil {
		log.Printf("%v", err)
	}
}

func (b *Bot) send(ctx context.Context, chat int64, text string) {
	if err := b.call(ctx, "sendMessage", map[string]any{"chat_id": chat, "text": text}, nil); err != nil {
		log.Printf("%v", err)
	}
}
