package billing

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"html"
	"io"
	"log"
	"mime/multipart"
	"net/http"
	"strings"
	"time"
)

// cardSVG draws the profile card: name, plan, today's limit as a bar with the reset time, plain numbers and the invite strip.
// Like the text profile, it has no rankings and no streaks.
func (b *Bot) cardSVG(id int64, name string) string {
	now := b.now().In(b.loc())
	u := b.Store.Get(id, now)
	limit := b.Limits().of(u.Plan)
	used := 0
	if u.Day == now.Format("2006-01-02") {
		used = u.Used
	}
	if strings.TrimSpace(name) == "" {
		name = "Профиль"
	}
	if r := []rune(name); len(r) > 22 {
		name = string(r[:22]) + "…"
	}
	e := html.EscapeString
	planLine := title(u.Plan) + " · " + perDay(limit)
	if u.Plan != Free {
		planLine += " · до " + u.Until.In(b.loc()).Format("02.01.2006")
	}
	frac, today := 0.0, fmt.Sprintf("%d", used)
	if limit > 0 {
		frac = float64(used) / float64(limit)
		if frac > 1 {
			frac = 1
		}
		today = fmt.Sprintf("%d из %d", used, limit)
	}
	barColor := "#B4A5FF"
	if frac >= .9 {
		barColor = "#FF7A8A"
	}
	reset := time.Date(now.Year(), now.Month(), now.Day()+1, 0, 0, 0, 0, b.loc()).Format("02.01 в 00:00")
	joined := "—"
	if !u.Joined.IsZero() {
		joined = u.Joined.In(b.loc()).Format("02.01.2006")
	}
	var s strings.Builder
	fmt.Fprintf(&s, `<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="620" viewBox="0 0 1000 620">
<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#17142E"/><stop offset="1" stop-color="#0B0A16"/></linearGradient>
<clipPath id="c"><rect width="1000" height="620" rx="36"/></clipPath><radialGradient id="glow" cx=".85" cy=".1" r=".6"><stop offset="0" stop-color="#6B55E6" stop-opacity=".45"/><stop offset="1" stop-color="#6B55E6" stop-opacity="0"/></radialGradient></defs>
<rect width="1000" height="620" rx="36" fill="url(#g)"/><rect width="1000" height="620" rx="36" fill="url(#glow)"/>
<g clip-path="url(#c)" font-family="Inter, 'DejaVu Sans', sans-serif" fill="#EEEBFA">
<text x="56" y="70" font-size="18" letter-spacing="3" fill="#9C97BC">ORVI · ПРОФИЛЬ</text>
<text x="944" y="70" font-size="18" text-anchor="end" fill="#9C97BC">%s</text>
<text x="56" y="150" font-size="56" font-weight="700">%s</text>
<text x="56" y="196" font-size="24" fill="#B4A5FF">%s</text>
<text x="56" y="272" font-size="18" letter-spacing="2" fill="#9C97BC">СЕГОДНЯ</text>
<text x="944" y="272" font-size="22" text-anchor="end">%s</text>
<rect x="56" y="292" width="888" height="14" rx="7" fill="#26243F"/><rect x="56" y="292" width="%.0f" height="14" rx="7" fill="%s"/>
<text x="56" y="336" font-size="18" fill="#9C97BC">%s</text>`,
		now.Format("02.01.2006"), e(name), e(planLine), e(today), 888*frac, barColor, e(map[bool]string{true: "без лимита", false: "обновится " + reset}[limit <= 0]))
	stats := [][2]string{{fmt.Sprintf("%d", u.Total), "разговоров всего"}, {joined, "с нами с"}, {fmt.Sprintf("%d", u.Paid), "оплат"}}
	for i, st := range stats {
		x := 56 + i*300
		fmt.Fprintf(&s, `<text x="%d" y="420" font-size="44" font-weight="700">%s</text><text x="%d" y="454" font-size="18" fill="#9C97BC">%s</text>`, x, e(st[0]), x, e(st[1]))
	}
	if b.RefDays != nil && b.RefDays() > 0 {
		fmt.Fprintf(&s, `<rect x="0" y="500" width="1000" height="120" fill="#B4A5FF"/>
<text x="56" y="550" font-size="28" font-weight="700" fill="#16152A">Позови друга</text>
<text x="56" y="586" font-size="19" fill="#16152A">Когда друг впервые оплатит, вам обоим %s в подарок</text>`, e(days(b.RefDays())))
	}
	s.WriteString(`</g></svg>`)
	return s.String()
}

// sendCard sends the profile as a picture with the menu; if the picture cannot be drawn here, it sends the text profile instead.
func (b *Bot) sendCard(ctx context.Context, chat, id int64, name string) {
	if b.Render != nil {
		png, err := b.Render(ctx, b.cardSVG(id, name))
		if err == nil && len(png) > 0 {
			if err = b.sendPhoto(ctx, chat, png, ""); err == nil {
				return
			}
		}
		log.Printf("billing bot: profile picture: %v (sending text)", err)
	}
	b.sendMenu(ctx, chat, b.profile(id))
}

func (b *Bot) sendPhoto(ctx context.Context, chat int64, png []byte, caption string) error {
	var body bytes.Buffer
	w := multipart.NewWriter(&body)
	_ = w.WriteField("chat_id", fmt.Sprint(chat))
	if caption != "" {
		_ = w.WriteField("caption", caption)
	}
	kb, _ := json.Marshal(b.menu())
	_ = w.WriteField("reply_markup", string(kb))
	fw, _ := w.CreateFormFile("photo", "profile.png")
	_, _ = fw.Write(png)
	_ = w.Close()
	base := b.BaseURL
	if base == "" {
		base = "https://api.telegram.org"
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, base+"/bot"+b.Token+"/sendPhoto", &body)
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", w.FormDataContentType())
	hc := b.HTTP
	if hc == nil {
		hc = &http.Client{Timeout: 70 * time.Second}
	}
	resp, err := hc.Do(req)
	if err != nil {
		return fmt.Errorf("sendPhoto failed") // the URL holds the token: never log it
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(resp.Body)
	var r struct {
		OK          bool   `json:"ok"`
		Description string `json:"description"`
	}
	if json.Unmarshal(raw, &r) != nil || !r.OK {
		return fmt.Errorf("sendPhoto: %s", r.Description)
	}
	return nil
}
