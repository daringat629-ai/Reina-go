package billing

import (
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"
)

var t0 = time.Date(2026, 10, 30, 12, 0, 0, 0, time.UTC)
var lim = Limits{Free: 2, Plus: 5, Max: 0}

func TestFreeLimitResetsDailyAndIsToldOnce(t *testing.T) {
	s := Open(filepath.Join(t.TempDir(), "b.json"))
	for i := 0; i < 2; i++ {
		if d := s.Take(7, t0, lim); !d.OK || d.Plan != Free {
			t.Fatalf("conversation %d must be allowed: %+v", i, d)
		}
	}
	d := s.Take(7, t0, lim)
	if d.OK || !d.TellOnce {
		t.Fatalf("over the limit, told once: %+v", d)
	}
	if d := s.Take(7, t0.Add(time.Minute), lim); d.OK || d.TellOnce {
		t.Fatalf("not told twice in a day: %+v", d)
	}
	if d := s.Take(7, t0.Add(24*time.Hour), lim); !d.OK || d.Left != 1 {
		t.Fatalf("a new day resets the count: %+v", d)
	}
}

func TestActivateExtendsAndIgnoresTheSameChargeTwice(t *testing.T) {
	path := filepath.Join(t.TempDir(), "b.json")
	s := Open(path)
	if _, err := s.Activate(7, "gold", 30, 1, "x", t0); err == nil {
		t.Fatal("unknown plan")
	}
	u, err := s.Activate(7, Plus, 30, 250, "c1", t0)
	if err != nil || u.Plan != Plus || !u.Until.Equal(t0.Add(30*24*time.Hour)) {
		t.Fatalf("%+v %v", u, err)
	}
	if u, _ := s.Activate(7, Plus, 30, 250, "c1", t0); !u.Until.Equal(t0.Add(30 * 24 * time.Hour)) {
		t.Fatal("the same charge must not be counted twice")
	}
	if u, _ := s.Activate(7, Plus, 30, 250, "c2", t0.Add(24*time.Hour)); !u.Until.Equal(t0.Add(60 * 24 * time.Hour)) {
		t.Fatalf("a second payment adds to what is left: %v", u.Until)
	}
	for i := 0; i < 5; i++ {
		s.Take(7, t0, lim)
	}
	if d := s.Take(7, t0, lim); d.OK {
		t.Fatal("Plus has its own limit")
	}
	if g := Open(path).Get(7, t0.Add(61*24*time.Hour)); g.Plan != Free {
		t.Fatalf("an expired plan falls back to Start (and survives a restart): %+v", g)
	}
	if _, pays := Open(path).All(t0); len(pays) != 2 {
		t.Fatalf("payments are kept: %d", len(pays))
	}
}

func TestMaxHasNoCap(t *testing.T) {
	s := Open(filepath.Join(t.TempDir(), "b.json"))
	_, _ = s.Activate(9, Max, 30, 600, "m", t0)
	for i := 0; i < 100; i++ {
		if d := s.Take(9, t0, lim); !d.OK || d.Left != -1 {
			t.Fatalf("Max without a cap: %+v", d)
		}
	}
}

func fakeAPI(t *testing.T) (*httptest.Server, func(string) []map[string]any) {
	var mu sync.Mutex
	calls := map[string][]map[string]any{}
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		raw, _ := io.ReadAll(r.Body)
		var in map[string]any
		_ = json.Unmarshal(raw, &in)
		m := r.URL.Path[strings.LastIndex(r.URL.Path, "/")+1:]
		mu.Lock()
		calls[m] = append(calls[m], in)
		mu.Unlock()
		w.Write([]byte(`{"ok":true,"result":true}`))
	}))
	t.Cleanup(srv.Close)
	return srv, func(m string) []map[string]any { mu.Lock(); defer mu.Unlock(); return calls[m] }
}

func newBot(srv *httptest.Server, st *Store) *Bot {
	return &Bot{Token: "T", BaseURL: srv.URL, Store: st, Now: func() time.Time { return t0 }, Loc: time.UTC, Name: "OrviPayBot",
		Offers: func() []Offer {
			return []Offer{{Plus, 1, 15}, {Plus, 7, 80}, {Plus, 30, 250}, {Max, 1, 0}, {Max, 30, 600}}
		},
		Limits: func() Limits { return lim }, RefDays: func() int { return 3 }, Support: func() string { return "@orvi_help" }}
}

func msg(t *testing.T, s string) update {
	var u update
	if err := json.Unmarshal([]byte(s), &u); err != nil {
		t.Fatal(err)
	}
	return u
}

func TestBotChecksPriceAndAppliesPayment(t *testing.T) {
	srv, calls := fakeAPI(t)
	st := Open(filepath.Join(t.TempDir(), "b.json"))
	b := newBot(srv, st)
	var paid int64
	b.OnPaid = func(id int64, plan string, until time.Time) { paid = id }
	ctx := context.Background()
	b.handle(ctx, msg(t, `{"update_id":1,"message":{"from":{"id":7},"chat":{"id":7},"text":"💳 Подписка"}}`))
	inv := calls("sendInvoice")
	if len(inv) != 4 || inv[0]["currency"] != "XTR" || inv[0]["provider_token"] != "" || inv[0]["payload"] != "plus:1" {
		t.Fatalf("one Stars invoice per offer on sale (the 0-star one is hidden): %d %+v", len(inv), inv)
	}
	b.handle(ctx, msg(t, `{"update_id":2,"pre_checkout_query":{"id":"q1","currency":"XTR","total_amount":1,"invoice_payload":"plus:7"}}`))
	b.handle(ctx, msg(t, `{"update_id":3,"pre_checkout_query":{"id":"q2","currency":"XTR","total_amount":15,"invoice_payload":"max:1"}}`))
	b.handle(ctx, msg(t, `{"update_id":4,"pre_checkout_query":{"id":"q3","currency":"XTR","total_amount":80,"invoice_payload":"plus:7"}}`))
	if a := calls("answerPreCheckoutQuery"); a[0]["ok"] != false || a[1]["ok"] != false || a[2]["ok"] != true {
		t.Fatalf("wrong price and an offer not on sale are refused, the right one passes: %+v", a)
	}
	b.handle(ctx, msg(t, `{"update_id":5,"message":{"from":{"id":7},"chat":{"id":7},"successful_payment":{"currency":"XTR","total_amount":80,"invoice_payload":"plus:7","telegram_payment_charge_id":"ch1"}}}`))
	if g := st.Get(7, t0); g.Plan != Plus || !g.Until.Equal(t0.Add(7*24*time.Hour)) || paid != 7 {
		t.Fatalf("a week of Plus, and the owner is told: %+v %d", g, paid)
	}
}

func TestInviteGivesBothADayBonusOnTheFirstPaymentOnly(t *testing.T) {
	srv, calls := fakeAPI(t)
	st := Open(filepath.Join(t.TempDir(), "b.json"))
	b := newBot(srv, st)
	ctx := context.Background()
	b.handle(ctx, msg(t, `{"update_id":1,"message":{"from":{"id":8},"chat":{"id":8},"text":"/start ref8"}}`))
	if st.Get(8, t0).Referrer != 0 {
		t.Fatal("nobody invites themselves")
	}
	b.handle(ctx, msg(t, `{"update_id":2,"message":{"from":{"id":9},"chat":{"id":9},"text":"/start ref8"}}`))
	if st.Get(9, t0).Referrer != 8 {
		t.Fatal("the inviter is remembered")
	}
	b.handle(ctx, msg(t, `{"update_id":3,"message":{"from":{"id":9},"chat":{"id":9},"successful_payment":{"currency":"XTR","total_amount":15,"invoice_payload":"plus:1","telegram_payment_charge_id":"a"}}}`))
	if g := st.Get(9, t0); !g.Until.Equal(t0.Add(4 * 24 * time.Hour)) {
		t.Fatalf("the friend gets 1 day + 3 days bonus: %v", g.Until)
	}
	if g := st.Get(8, t0); g.Plan != Plus || !g.Until.Equal(t0.Add(3*24*time.Hour)) {
		t.Fatalf("the inviter gets 3 days of Plus: %+v", g)
	}
	b.handle(ctx, msg(t, `{"update_id":4,"message":{"from":{"id":9},"chat":{"id":9},"successful_payment":{"currency":"XTR","total_amount":15,"invoice_payload":"plus:1","telegram_payment_charge_id":"b"}}}`))
	if g := st.Get(8, t0); !g.Until.Equal(t0.Add(3 * 24 * time.Hour)) {
		t.Fatal("only the first payment brings a bonus")
	}
	if all, paid := st.Invited(8); all != 1 || paid != 1 {
		t.Fatalf("invites counted: %d %d", all, paid)
	}
	b.handle(ctx, msg(t, `{"update_id":5,"message":{"from":{"id":8},"chat":{"id":8},"text":"🤝 Друзьям"}}`))
	sent := calls("sendMessage")
	if last := sent[len(sent)-1]["text"].(string); !strings.Contains(last, "https://t.me/OrviPayBot?start=ref8") || !strings.Contains(last, "оплатили: 1") {
		t.Fatalf("the invite card: %s", last)
	}
}

func TestProfileShowsLimitBarAndResetWithoutRankings(t *testing.T) {
	srv, calls := fakeAPI(t)
	st := Open(filepath.Join(t.TempDir(), "b.json"))
	st.Take(7, t0, lim)
	b := newBot(srv, st)
	b.handle(context.Background(), msg(t, `{"update_id":1,"message":{"from":{"id":7},"chat":{"id":7},"text":"👤 Профиль"}}`))
	sent := calls("sendMessage")
	p := sent[0]["text"].(string)
	for _, w := range []string{"Тариф: Старт", "Сегодня: 1 из 2", "▰▰▰▰▰▱▱▱▱▱ 50%", "Обновится в 00:00, 31.10", "Разговоров всего: 1"} {
		if !strings.Contains(p, w) {
			t.Fatalf("missing %q in:\n%s", w, p)
		}
	}
	for _, w := range []string{"Топ", "%% собеседников", "рейтинг"} {
		if strings.Contains(p, w) {
			t.Fatalf("no rankings that press on people: %s", p)
		}
	}
	if sent[0]["reply_markup"] == nil {
		t.Fatal("the menu keyboard comes with every answer")
	}
}

func TestDaysPlural(t *testing.T) {
	for n, w := range map[int]string{1: "1 день", 3: "3 дня", 7: "7 дней", 11: "11 дней", 21: "21 день", 30: "30 дней"} {
		if days(n) != w {
			t.Fatalf("%d: %q", n, days(n))
		}
	}
}

func TestProfileCardIsAPictureWithTextFallback(t *testing.T) {
	srv, calls := fakeAPI(t)
	st := Open(filepath.Join(t.TempDir(), "b.json"))
	st.Take(7, t0, lim)
	b := newBot(srv, st)
	var svg string
	b.Render = func(ctx context.Context, s string) ([]byte, error) { svg = s; return []byte("\x89PNG fake"), nil }
	b.handle(context.Background(), msg(t, `{"update_id":1,"message":{"from":{"id":7,"first_name":"Jaabir <3"},"chat":{"id":7},"text":"👤 Профиль"}}`))
	if len(calls("sendPhoto")) != 1 || len(calls("sendMessage")) != 0 {
		t.Fatalf("the profile goes as a picture: photo %d, text %d", len(calls("sendPhoto")), len(calls("sendMessage")))
	}
	for _, w := range []string{"Jaabir &lt;3", "1 из 2", "Позови друга", "3 дня"} {
		if !strings.Contains(svg, w) {
			t.Fatalf("card is missing %q", w)
		}
	}
	b.Render = func(ctx context.Context, s string) ([]byte, error) { return nil, context.DeadlineExceeded }
	b.handle(context.Background(), msg(t, `{"update_id":2,"message":{"from":{"id":7},"chat":{"id":7},"text":"👤 Профиль"}}`))
	if len(calls("sendMessage")) != 1 {
		t.Fatal("no renderer here: the text profile is sent instead")
	}
}

func TestMenuButtonsGetVectorIconsAndColours(t *testing.T) {
	b := &Bot{}
	kb := b.menu()["keyboard"].([][]map[string]any)
	if kb[0][0]["text"] != "💳 Подписка" || kb[0][0]["style"] != "primary" || kb[1][0]["style"] != "success" {
		t.Fatalf("without icons: ordinary emoji and colours: %+v", kb)
	}
	if _, has := kb[0][1]["style"]; has {
		t.Fatal("Профиль keeps the app's own colour")
	}
	b.Icons = func() []string { return []string{"5368324170671202286", "", " 777 ", ""} }
	kb = b.menu()["keyboard"].([][]map[string]any)
	if kb[0][0]["text"] != "Подписка" || kb[0][0]["icon_custom_emoji_id"] != "5368324170671202286" || kb[1][0]["icon_custom_emoji_id"] != "777" {
		t.Fatalf("with an icon the emoji goes away: %+v", kb)
	}
	if kb[0][1]["text"] != "👤 Профиль" {
		t.Fatal("an empty place keeps the ordinary emoji")
	}
	for _, in := range []string{"Подписка", "💳 Подписка", " Подписка "} {
		if pressed(in) != btnPlans {
			t.Fatalf("%q must be recognised", in)
		}
	}
	if pressed("подписка на канал") != "" {
		t.Fatal("ordinary text is not a button")
	}
}
