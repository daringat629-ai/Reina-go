// Package people keeps a short card per person she talks to: durable facts, preferences, promises. Cards are
// cheap to show (a few lines, only for the people in the current conversation) and she writes them herself.
// Facts learned in a private chat are marked private and never shown in groups.
package people

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

const (
	MaxFacts   = 14  // oldest facts are dropped beyond this
	MaxFactLen = 220 // characters
)

// Fact is one remembered line.
type Fact struct {
	Text    string    `json:"text"`
	Private bool      `json:"private,omitempty"`
	At      time.Time `json:"at"`
}

// Card is everything she knows about one person.
type Card struct {
	ID    int64  `json:"id"`
	Name  string `json:"name"`
	Facts []Fact `json:"facts"`
}

type Store struct {
	mu  sync.Mutex
	dir string
}

func New(dir string) *Store { return &Store{dir: dir} }

func (s *Store) path(id int64) string { return filepath.Join(s.dir, strconv.FormatInt(id, 10)+".json") }

func (s *Store) load(id int64) Card {
	c := Card{ID: id}
	if b, err := os.ReadFile(s.path(id)); err == nil {
		_ = json.Unmarshal(b, &c)
		c.ID = id
	}
	return c
}

func (s *Store) save(c Card) error {
	if len(c.Facts) == 0 {
		err := os.Remove(s.path(c.ID))
		if os.IsNotExist(err) {
			return nil
		}
		return err
	}
	if err := os.MkdirAll(s.dir, 0o755); err != nil {
		return err
	}
	b, _ := json.MarshalIndent(c, "", " ")
	tmp := s.path(c.ID) + ".tmp"
	if err := os.WriteFile(tmp, b, 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, s.path(c.ID))
}

// Get returns the card (empty when nobody wrote one yet).
func (s *Store) Get(id int64) Card {
	if s == nil {
		return Card{ID: id}
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.load(id)
}

func norm(s string) string { return strings.ToLower(strings.Join(strings.Fields(s), " ")) }

// Add remembers a fact; a fact that is already known is not repeated.
func (s *Store) Add(id int64, name, fact string, private bool, now time.Time) error {
	fact = strings.TrimSpace(strings.ReplaceAll(fact, "\n", " "))
	if id == 0 || fact == "" {
		return fmt.Errorf("need a user id and a fact")
	}
	if r := []rune(fact); len(r) > MaxFactLen {
		fact = string(r[:MaxFactLen]) + "…"
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	c := s.load(id)
	if name = strings.TrimSpace(name); name != "" {
		c.Name = name
	}
	for i, f := range c.Facts {
		if norm(f.Text) == norm(fact) {
			c.Facts[i].Private = f.Private && private // known in public: stays public
			return s.save(c)
		}
	}
	c.Facts = append(c.Facts, Fact{Text: fact, Private: private, At: now})
	if n := len(c.Facts); n > MaxFacts {
		c.Facts = c.Facts[n-MaxFacts:]
	}
	return s.save(c)
}

// Forget removes the facts containing the text (case-insensitive) and returns how many it removed.
func (s *Store) Forget(id int64, contains string) int {
	contains = norm(contains)
	if contains == "" {
		return 0
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	c := s.load(id)
	var keep []Fact
	for _, f := range c.Facts {
		if !strings.Contains(norm(f.Text), contains) {
			keep = append(keep, f)
		}
	}
	n := len(c.Facts) - len(keep)
	if n > 0 {
		c.Facts = keep
		_ = s.save(c)
	}
	return n
}

// Replace overwrites a card (the panel editor). Empty facts delete the card.
func (s *Store) Replace(id int64, name string, facts []Fact) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	var clean []Fact
	for _, f := range facts {
		f.Text = strings.TrimSpace(f.Text)
		if f.Text == "" {
			continue
		}
		if r := []rune(f.Text); len(r) > MaxFactLen {
			f.Text = string(r[:MaxFactLen]) + "…"
		}
		clean = append(clean, f)
	}
	if len(clean) > MaxFacts {
		clean = clean[len(clean)-MaxFacts:]
	}
	return s.save(Card{ID: id, Name: strings.TrimSpace(name), Facts: clean})
}

// All lists every card, by name.
func (s *Store) All() []Card {
	if s == nil {
		return nil
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	ents, _ := os.ReadDir(s.dir)
	var out []Card
	for _, e := range ents {
		id, err := strconv.ParseInt(strings.TrimSuffix(e.Name(), ".json"), 10, 64)
		if err != nil || !strings.HasSuffix(e.Name(), ".json") {
			continue
		}
		if c := s.load(id); len(c.Facts) > 0 {
			out = append(out, c)
		}
	}
	sort.Slice(out, func(i, j int) bool { return strings.ToLower(out[i].Name) < strings.ToLower(out[j].Name) })
	return out
}

// Render is the card as shown to the model. Private facts are left out unless includePrivate.
func (c Card) Render(includePrivate bool) string {
	var lines []string
	for _, f := range c.Facts {
		if f.Private && !includePrivate {
			continue
		}
		lines = append(lines, "- "+f.Text)
	}
	if len(lines) == 0 {
		return ""
	}
	name := strings.ReplaceAll(c.Name, `"`, "'")
	return fmt.Sprintf("<person_card user_id=\"%d\" name=\"%s\">\n%s\n</person_card>\n", c.ID, name, strings.Join(lines, "\n"))
}
