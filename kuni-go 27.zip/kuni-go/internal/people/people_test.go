package people

import (
	"strings"
	"testing"
	"time"
)

func TestCardsStoreDedupeCapAndPrivacy(t *testing.T) {
	s := New(t.TempDir())
	now := time.Now()
	if err := s.Add(7, "Joe", "works as a welder", true, now); err != nil {
		t.Fatal(err)
	}
	_ = s.Add(7, "Joe", "  Works as a   WELDER ", false, now) // same fact, learned publicly: stays one line, now public
	_ = s.Add(7, "Joe", "loves old cars", true, now)
	c := s.Get(7)
	if len(c.Facts) != 2 || c.Name != "Joe" || c.Facts[0].Private {
		t.Fatalf("%+v", c)
	}
	pub := c.Render(false)
	if !strings.Contains(pub, "welder") || strings.Contains(pub, "old cars") || !strings.Contains(pub, `user_id="7"`) {
		t.Fatalf("private facts leaked into a group view: %s", pub)
	}
	if !strings.Contains(c.Render(true), "old cars") {
		t.Fatal("private chat sees everything")
	}
	for i := 0; i < 30; i++ {
		_ = s.Add(7, "", strings.Repeat("x", i+1), false, now)
	}
	if n := len(s.Get(7).Facts); n != MaxFacts {
		t.Fatalf("not capped: %d", n)
	}
	_ = s.Add(8, "Ann", strings.Repeat("я", 500), false, now)
	if r := []rune(s.Get(8).Facts[0].Text); len(r) > MaxFactLen+1 {
		t.Fatalf("long fact not cut: %d", len(r))
	}
	if n := s.Forget(8, "ЯЯЯ"); n != 1 || len(s.Get(8).Facts) != 0 {
		t.Fatalf("forget: %d", n)
	}
	if all := s.All(); len(all) != 1 || all[0].ID != 7 {
		t.Fatalf("all: %+v", all)
	}
	if err := s.Add(0, "", "x", false, now); err == nil {
		t.Fatal("needs an id")
	}
	if err := s.Replace(7, "Joseph", []Fact{{Text: "new fact"}}); err != nil || s.Get(7).Name != "Joseph" || len(s.Get(7).Facts) != 1 {
		t.Fatal("replace")
	}
	_ = s.Replace(7, "", nil)
	if len(s.All()) != 0 {
		t.Fatal("empty card must be deleted")
	}
}
