// Package metrics wraps github.com/prometheus/client_golang behind the small
// Inc/Set/Observe API used across the project. Metric vectors are created lazily
// on first use; the label names of the first call fix the metric's label set.
package metrics

import (
	"log"
	"net/http"
	"sort"
	"sync"

	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/collectors"
	"github.com/prometheus/client_golang/prometheus/promhttp"
	dto "github.com/prometheus/client_model/go"
)

type Registry struct {
	reg *prometheus.Registry

	mu        sync.Mutex
	help      map[string]string
	counters  map[string]*prometheus.CounterVec
	gauges    map[string]*prometheus.GaugeVec
	summaries map[string]*prometheus.SummaryVec
	labels    map[string][]string
}

// New creates a registry with Go runtime and process collectors attached.
func New() *Registry {
	r := &Registry{
		reg:       prometheus.NewRegistry(),
		help:      map[string]string{},
		counters:  map[string]*prometheus.CounterVec{},
		gauges:    map[string]*prometheus.GaugeVec{},
		summaries: map[string]*prometheus.SummaryVec{},
		labels:    map[string][]string{},
	}
	r.reg.MustRegister(collectors.NewGoCollector(), collectors.NewProcessCollector(collectors.ProcessCollectorOpts{}))
	return r
}

// Help sets the HELP text for a metric. Call it before the metric is first used.
func (r *Registry) Help(name, text string) {
	if r == nil {
		return
	}
	r.mu.Lock()
	r.help[name] = text
	r.mu.Unlock()
}

func labelNames(labels map[string]string) []string {
	ks := make([]string, 0, len(labels))
	for k := range labels {
		ks = append(ks, k)
	}
	sort.Strings(ks)
	return ks
}

func sameLabels(a, b []string) bool {
	if len(a) != len(b) {
		return false
	}
	for i := range a {
		if a[i] != b[i] {
			return false
		}
	}
	return true
}

// prepare checks/records the label set of name. Caller holds r.mu.
func (r *Registry) prepare(name string, labels map[string]string) ([]string, bool) {
	names := labelNames(labels)
	if prev, ok := r.labels[name]; ok {
		if !sameLabels(prev, names) {
			log.Printf("metrics: %s used with labels %v, registered with %v; dropped", name, names, prev)
			return nil, false
		}
		return names, true
	}
	r.labels[name] = names
	return names, true
}

func (r *Registry) helpFor(name string) string {
	if h := r.help[name]; h != "" {
		return h
	}
	return name
}

func (r *Registry) register(name string, c prometheus.Collector) bool {
	if err := r.reg.Register(c); err != nil {
		log.Printf("metrics: register %s: %v", name, err)
		return false
	}
	return true
}

// Inc adds v to a counter.
func (r *Registry) Inc(name string, v float64, labels map[string]string) {
	if r == nil {
		return
	}
	r.mu.Lock()
	c, ok := r.counters[name]
	if !ok {
		names, good := r.prepare(name, labels)
		if !good {
			r.mu.Unlock()
			return
		}
		c = prometheus.NewCounterVec(prometheus.CounterOpts{Name: name, Help: r.helpFor(name)}, names)
		if !r.register(name, c) {
			r.mu.Unlock()
			return
		}
		r.counters[name] = c
	} else if _, good := r.prepare(name, labels); !good {
		r.mu.Unlock()
		return
	}
	r.mu.Unlock()
	c.With(labels).Add(v)
}

// Set sets a gauge.
func (r *Registry) Set(name string, v float64, labels map[string]string) {
	if r == nil {
		return
	}
	r.mu.Lock()
	g, ok := r.gauges[name]
	if !ok {
		names, good := r.prepare(name, labels)
		if !good {
			r.mu.Unlock()
			return
		}
		g = prometheus.NewGaugeVec(prometheus.GaugeOpts{Name: name, Help: r.helpFor(name)}, names)
		if !r.register(name, g) {
			r.mu.Unlock()
			return
		}
		r.gauges[name] = g
	} else if _, good := r.prepare(name, labels); !good {
		r.mu.Unlock()
		return
	}
	r.mu.Unlock()
	g.With(labels).Set(v)
}

// Observe records a value in a summary (exported as <name>_sum and <name>_count).
func (r *Registry) Observe(name string, v float64, labels map[string]string) {
	if r == nil {
		return
	}
	r.mu.Lock()
	s, ok := r.summaries[name]
	if !ok {
		names, good := r.prepare(name, labels)
		if !good {
			r.mu.Unlock()
			return
		}
		s = prometheus.NewSummaryVec(prometheus.SummaryOpts{Name: name, Help: r.helpFor(name)}, names)
		if !r.register(name, s) {
			r.mu.Unlock()
			return
		}
		r.summaries[name] = s
	} else if _, good := r.prepare(name, labels); !good {
		r.mu.Unlock()
		return
	}
	r.mu.Unlock()
	s.With(labels).Observe(v)
}

// Get returns a counter value (tests).
func (r *Registry) Get(name string, labels map[string]string) float64 {
	r.mu.Lock()
	c, ok := r.counters[name]
	r.mu.Unlock()
	if !ok {
		return 0
	}
	ctr, err := c.GetMetricWith(labels)
	if err != nil {
		return 0
	}
	var m dto.Metric
	if err := ctr.Write(&m); err != nil {
		return 0
	}
	return m.GetCounter().GetValue()
}

// Handler serves the Prometheus exposition format.
func (r *Registry) Handler() http.Handler {
	return promhttp.HandlerFor(r.reg, promhttp.HandlerOpts{Registry: r.reg})
}
