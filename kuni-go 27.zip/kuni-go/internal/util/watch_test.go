package util

import (
	"context"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestWatchFiresOnWrite(t *testing.T) {
	dir := t.TempDir()
	f := filepath.Join(dir, "a.md")
	other := filepath.Join(dir, "b.md")
	os.WriteFile(f, []byte("1"), 0o644)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	got := make(chan string, 4)
	go Watch(ctx, 50*time.Millisecond, func() []string { return []string{f} }, func(p string) { got <- p })
	time.Sleep(150 * time.Millisecond)
	os.WriteFile(other, []byte("x"), 0o644) // not watched
	os.WriteFile(f, []byte("2"), 0o644)
	os.WriteFile(f, []byte("3"), 0o644) // coalesced
	select {
	case p := <-got:
		if filepath.Base(p) != "a.md" {
			t.Fatalf("got %s", p)
		}
	case <-time.After(3 * time.Second):
		t.Fatal("no change event")
	}
	select {
	case p := <-got:
		t.Fatalf("unexpected second event %s", p)
	case <-time.After(400 * time.Millisecond):
	}
}
