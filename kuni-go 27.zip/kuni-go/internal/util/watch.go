package util

import (
	"context"
	"log"
	"os"
	"path/filepath"
	"time"

	"github.com/fsnotify/fsnotify"
)

// Watch calls onChange when any of the given files changes. It uses fsnotify
// (inotify/kqueue/ReadDirectoryChangesW), like FileWatcher_linux/macos.cpp in the
// original. Parent directories are watched so editors that replace files on save
// are handled. files() is re-evaluated every interval to pick up new paths; events
// for the same file within debounce are coalesced. If fsnotify is unavailable it
// falls back to polling modification times.
func Watch(ctx context.Context, interval time.Duration, files func() []string, onChange func(path string)) {
	w, err := fsnotify.NewWatcher()
	if err != nil {
		log.Printf("watch: fsnotify unavailable (%v), polling", err)
		poll(ctx, interval, files, onChange)
		return
	}
	defer w.Close()

	const debounce = 200 * time.Millisecond
	wanted := map[string]bool{}
	dirs := map[string]bool{}
	refresh := func() {
		next := map[string]bool{}
		for _, f := range files() {
			abs, err := filepath.Abs(f)
			if err != nil {
				continue
			}
			next[abs] = true
			d := filepath.Dir(abs)
			if !dirs[d] {
				if err := w.Add(d); err == nil {
					dirs[d] = true
				}
			}
		}
		wanted = next
	}
	refresh()

	pending := map[string]*time.Timer{}
	fire := make(chan string, 16)
	t := time.NewTicker(interval)
	defer t.Stop()
	defer func() {
		for _, tm := range pending {
			tm.Stop()
		}
	}()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
			refresh()
		case ev, ok := <-w.Events:
			if !ok {
				return
			}
			if !ev.Has(fsnotify.Write) && !ev.Has(fsnotify.Create) && !ev.Has(fsnotify.Rename) {
				continue
			}
			p, _ := filepath.Abs(ev.Name)
			if !wanted[p] {
				continue
			}
			if tm, ok := pending[p]; ok {
				tm.Reset(debounce)
				continue
			}
			pending[p] = time.AfterFunc(debounce, func() {
				select {
				case fire <- p:
				case <-ctx.Done():
				}
			})
		case p := <-fire:
			delete(pending, p)
			onChange(p)
		case err, ok := <-w.Errors:
			if !ok {
				return
			}
			log.Printf("watch: %v", err)
		}
	}
}

// poll is the portable fallback: it compares modification times every interval.
func poll(ctx context.Context, interval time.Duration, files func() []string, onChange func(path string)) {
	last := map[string]time.Time{}
	scan := func(fire bool) {
		for _, f := range files() {
			st, err := statMod(f)
			if err != nil {
				continue
			}
			prev, seen := last[f]
			last[f] = st
			if fire && seen && !st.Equal(prev) {
				onChange(f)
			}
		}
	}
	scan(false)
	t := time.NewTicker(interval)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
			scan(true)
		}
	}
}

func statMod(f string) (time.Time, error) {
	st, err := os.Stat(f)
	if err != nil {
		return time.Time{}, err
	}
	return st.ModTime(), nil
}
