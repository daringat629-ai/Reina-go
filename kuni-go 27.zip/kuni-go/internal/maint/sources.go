package maint

import (
	"path/filepath"

	"kuni/internal/config"
)

// Sources are the paths a backup contains.
func Sources(c *config.Config, configPath string) []string {
	return []string{
		c.DiaryDir, c.WorkingMemoryFile, c.PromptsDir, configPath,
		filepath.Join(c.DataDir, "mood.json"), filepath.Join(c.DataDir, "autonomy.json"), filepath.Join(c.DataDir, "autonomy.log"),
		filepath.Join(c.DataDir, "usage.json"),
	}
}

// BackupDirOf resolves where backups are stored.
func BackupDirOf(c *config.Config) string {
	if c.BackupDir != "" {
		return c.BackupDir
	}
	return filepath.Join(c.DataDir, "backups")
}
