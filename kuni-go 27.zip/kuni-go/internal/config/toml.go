// Package config loads config.toml. Parsing is done by github.com/BurntSushi/toml;
// the default file (with comments) is still rendered here, since encoders drop comments.
package config

import (
	"fmt"
	"strconv"
	"strings"

	"github.com/BurntSushi/toml"
)

// parseTOML parses a TOML document into map["section.key"] = value.
// Nested tables are flattened with dots. Values are string, int64, float64 or bool
// (other TOML types are passed through and rejected later by assign()).
func parseTOML(src string) (map[string]any, error) {
	var raw map[string]any
	if _, err := toml.Decode(src, &raw); err != nil {
		return nil, err
	}
	out := map[string]any{}
	flatten("", raw, out)
	return out, nil
}

func flatten(prefix string, in map[string]any, out map[string]any) {
	for k, v := range in {
		full := k
		if prefix != "" {
			full = prefix + "." + k
		}
		if sub, ok := v.(map[string]any); ok {
			flatten(full, sub, out)
			continue
		}
		out[full] = v
	}
}

// formatTOML renders the default config with comments, grouped by section.
func formatTOML(sections []tomlSection) string {
	var b strings.Builder
	for i, s := range sections {
		if i > 0 {
			b.WriteString("\n")
		}
		fmt.Fprintf(&b, "[%s]\n", s.name)
		for _, kv := range s.items {
			if kv.comment != "" {
				fmt.Fprintf(&b, "# %s\n", kv.comment)
			}
			fmt.Fprintf(&b, "%s = %s\n", kv.key, formatScalar(kv.value))
		}
	}
	return b.String()
}

func formatScalar(v any) string {
	switch t := v.(type) {
	case string:
		return strconv.Quote(t)
	case float64:
		return strconv.FormatFloat(t, 'f', -1, 64)
	default:
		return fmt.Sprint(t)
	}
}

type tomlItem struct {
	key     string
	value   any
	comment string
}

type tomlSection struct {
	name  string
	items []tomlItem
}
