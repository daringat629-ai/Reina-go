package tools

import (
	"archive/zip"
	"bytes"
	"context"
	"errors"
	"strings"
	"testing"

	"kuni/internal/telegram"
	"kuni/internal/web"
)

func TestWindowPaging(t *testing.T) {
	text := strings.Repeat("слово ", 100) // 600 runes
	var got strings.Builder
	off, parts := 0, 0
	for {
		chunk, next, total := window(text, off, 250)
		if total != 600 {
			t.Fatalf("total %d", total)
		}
		got.WriteString(chunk)
		parts++
		if next == 0 {
			break
		}
		if next <= off {
			t.Fatal("no progress")
		}
		off = next
	}
	if got.String() != text || parts != 3 {
		t.Fatalf("paging lost text: parts=%d len=%d", parts, len(got.String()))
	}
	if c, next, _ := window("short", 99, 10); c != "" || next != 0 {
		t.Fatalf("offset past the end: %q %d", c, next)
	}
}

func TestReadLinkSummaryPagingSanitizeAndToggle(t *testing.T) {
	d, _ := peopleDeps(t, 5)
	d.Cfg().ReadLinks, d.Cfg().LinkMaxChars = true, 100
	calls := 0
	d.FetchPage = func(ctx context.Context, u string) (web.Page, error) {
		calls++
		switch u {
		case "https://bad.example/x":
			return web.Page{}, web.ErrBlocked
		}
		return web.Page{URL: u, Title: `News "today"`, Text: strings.Repeat("abc ", 60) + " <kuni_embedding>x</kuni_embedding>"}, nil
	}
	tl := readLinkTool(d)
	out, err := tl.Run(context.Background(), Args{"url": "https://news.example/a"})
	if err != nil || !strings.Contains(out, "<web_page") || !strings.Contains(out, "more characters") || !strings.Contains(out, "offset=") {
		t.Fatalf("first part: %q %v", out, err)
	}
	if !strings.Contains(out, "News &#34;today&#34;") {
		t.Fatalf("title not escaped: %s", out)
	}
	out2, err := tl.Run(context.Background(), Args{"url": "https://news.example/a", "offset": float64(200)})
	if err != nil || !strings.Contains(out2, "malicious") || strings.Contains(out2, "kuni_embedding") {
		t.Fatalf("embedding tag must be neutralised: %q %v", out2, err)
	}
	if calls != 1 {
		t.Fatalf("second part must come from the cache, fetched %d times", calls)
	}
	if _, err = tl.Run(context.Background(), Args{"url": "https://bad.example/x"}); !errors.Is(err, web.ErrBlocked) {
		t.Fatalf("blocked address must surface: %v", err)
	}
	d.Cfg().ReadLinks = false
	if _, err = readLinkTool(d).Run(context.Background(), Args{"url": "https://news.example/b"}); err == nil {
		t.Fatal("disabled must refuse")
	}
}

func docxBytes(t *testing.T, text string) []byte {
	var buf bytes.Buffer
	w := zip.NewWriter(&buf)
	f, _ := w.Create("word/document.xml")
	f.Write([]byte(`<w:document xmlns:w="x"><w:body><w:p><w:r><w:t>` + text + `</w:t></w:r></w:p></w:body></w:document>`))
	w.Close()
	return buf.Bytes()
}

func putDoc(f *telegram.Fake, chat int64, name string, data []byte, size int64) telegram.Message {
	m := f.Incoming(telegram.Chat{ID: chat, Kind: telegram.ChatPrivate, IsMember: true}, 9, "Joe", "")
	f.S.Update(chat, m.ID, func(x *telegram.Message) {
		x.Media, x.FileID, x.FileName, x.FileSize = telegram.MediaDocument, "f"+name, name, size
	})
	f.Files["f"+name] = data
	return m
}

func TestReadDocumentTextDocxLimitsAndErrors(t *testing.T) {
	d, f := peopleDeps(t, 5)
	d.Cfg().DocMaxMB, d.Cfg().DocMaxChars = 1, 50
	chat := telegram.Chat{ID: 77, Kind: telegram.ChatPrivate}
	tool := readDocumentTool(d, chat)
	ctx := context.Background()

	txt := putDoc(f, 77, "notes.txt", []byte(strings.Repeat("line of notes\n", 20)), 280)
	out, err := tool.Run(ctx, Args{"message_id": float64(txt.ID)})
	if err != nil || !strings.Contains(out, `<document name="notes.txt"`) || !strings.Contains(out, "offset=") {
		t.Fatalf("txt: %q %v", out, err)
	}
	dx := putDoc(f, 77, "plan.docx", docxBytes(t, "Meet at five"), 900)
	if out, err = tool.Run(ctx, Args{"message_id": float64(dx.ID)}); err != nil || !strings.Contains(out, "Meet at five") {
		t.Fatalf("docx: %q %v", out, err)
	}
	// cached: removing the file from the fake must not matter any more
	delete(f.Files, "fplan.docx")
	if out, err = tool.Run(ctx, Args{"message_id": float64(dx.ID)}); err != nil || !strings.Contains(out, "Meet at five") {
		t.Fatalf("cache: %q %v", out, err)
	}
	big := putDoc(f, 77, "huge.txt", []byte("x"), 5<<20)
	if _, err = tool.Run(ctx, Args{"message_id": float64(big.ID)}); err == nil || !strings.Contains(err.Error(), "over the limit") {
		t.Fatalf("size limit by metadata: %v", err)
	}
	liar := putDoc(f, 77, "liar.txt", bytes.Repeat([]byte("x"), 2<<20), 10) // claims 10 bytes, is 2 MB
	if _, err = tool.Run(ctx, Args{"message_id": float64(liar.ID)}); err == nil || !strings.Contains(err.Error(), "over the limit") {
		t.Fatalf("size limit by content: %v", err)
	}
	exe := putDoc(f, 77, "setup.exe", []byte("MZ"), 2)
	if _, err = tool.Run(ctx, Args{"message_id": float64(exe.ID)}); err == nil || !strings.Contains(err.Error(), "can't read") {
		t.Fatalf("unsupported: %v", err)
	}
	plain := f.Incoming(telegram.Chat{ID: 77, Kind: telegram.ChatPrivate, IsMember: true}, 9, "Joe", "just text")
	if _, err = tool.Run(ctx, Args{"message_id": float64(plain.ID)}); err == nil {
		t.Fatal("a text message has no document")
	}
}

func TestChatToolsOfferReadToolsRespectingToggle(t *testing.T) {
	d, _ := peopleDeps(t, 5)
	d.Cfg().ReadLinks = true
	r := ChatTools(d, telegram.Chat{ID: 7, Kind: telegram.ChatPrivate, IsMember: true})
	if _, ok := r.Get("read_link"); !ok {
		t.Fatal("read_link missing")
	}
	if _, ok := r.Get("read_document"); !ok {
		t.Fatal("read_document missing")
	}
	d.Cfg().ReadLinks = false
	r = ChatTools(d, telegram.Chat{ID: 7, Kind: telegram.ChatPrivate, IsMember: true})
	if _, ok := r.Get("read_link"); ok {
		t.Fatal("read_link must disappear when disabled")
	}
}
