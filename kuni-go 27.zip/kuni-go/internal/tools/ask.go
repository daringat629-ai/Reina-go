package tools

import (
	"context"
	"fmt"
	"strings"

	"kuni/internal/llm"
	"kuni/internal/prompts"
)

const askSystem = `
You are a database searcher and summarizer.

The user asks you a question. Your job is to retrieve data solely from #query tool. Your job is to output data that
fully satisfies user's query and would be helpful.

Also, please include additional details that does not necessarily address the question (i.e., dates, names, events) but
might be helpful to improve quality of subsequent processing of your response.

Do not alter facts.

Do not make up facts. Rely exclusively on provided context.
`

// AskTool is the "ask" subagent: an LLM that answers by calling a "query" tool over
// the diary (embedding RAG) and, optionally, the web.
func AskTool(d Deps) Tool {
	return Tool{
		Name:        "ask",
		Description: "Look up your memory (diary) and the web via a slow subagent (20-60 s). Only when you truly need to recall something about a person/past event or check a public fact; NOT for ordinary chat, greetings or things in the visible conversation. At most once per turn.",
		Props:       []Prop{{Name: "query", Type: "string", Desc: "Freeform question to the subagent. Provide as much context as possible — include sender name, topic, and what you want to know."}},
		Run: func(ctx context.Context, a Args) (string, error) {
			q := strings.TrimSpace(a.Str("query"))
			if len(q) < 10 {
				return "Query is too short. Provide more context: who, what, and what you want to know.", nil
			}
			return runAsk(ctx, d, q)
		},
	}
}

func runAsk(ctx context.Context, d Deps, query string) (string, error) {
	included := map[string]bool{}
	sub := NewRegistry(Tool{
		Name:        "query",
		Description: "Perform embedding-based search on RAG database",
		Props: []Prop{
			{Name: "text", Type: "string", Desc: "Retrieval cue that is likely to appear in memory pieces. Transformed to an embedding as is. Include as many keywords as possible; maintain meaning of the request."},
			{Name: "include_web_search_results", Type: "boolean", Desc: "Also append web search results. True for public or recent information."},
		},
		Run: func(ctx context.Context, a Args) (string, error) {
			cue := a.Str("text")
			out := QueryDiary(ctx, d, included, cue)
			if a.Bool("include_web_search_results") {
				out = "<local_db_results>\n" + out + "\n</local_db_results>\n<web_search_results>\n" + queryWeb(ctx, d, cue) + "\n</web_search_results>\n"
			}
			return out, nil
		},
	})

	msgs := []llm.Message{{Role: "user", Content: "<character>\n" + d.Prompts.Get(prompts.CharacterBase) + "\n</character>\n\n" + query}}
	called := false
	for round := 0; round < 5; round++ {
		reply, err := d.LLM.Complete(llm.WithPurpose(ctx, "ask"), askSystem, msgs, sub.Defs())
		if err != nil {
			return "", err
		}
		msgs = append(msgs, reply)
		if len(reply.ToolCalls) == 0 {
			if !called {
				msgs = append(msgs, llm.Message{Role: "user", Content: "you must perform at least one call to #query"})
				continue
			}
			return reply.Content, nil
		}
		called = true
		msgs = append(msgs, sub.HandleToolCalls(ctx, reply.ToolCalls)...)
	}
	return "", fmt.Errorf("ask: subagent did not finish")
}

// QueryDiary returns <memory_piece> blocks for entries related to cue, skipping already-shown ones.
func QueryDiary(ctx context.Context, d Deps, included map[string]bool, cue string) string {
	if d.Diary == nil {
		return "No data was found"
	}
	vec, err := d.LLM.Embedding(ctx, cue)
	if err != nil {
		return "Error: " + err.Error()
	}
	entries, err := d.Diary.Load()
	if err != nil {
		return "Error: " + err.Error()
	}
	max := d.Cfg().MaxRelatedEntries
	related, err := d.Diary.Query(ctx, entries, vec, max+len(included))
	if err != nil {
		return "Error: " + err.Error()
	}
	var b strings.Builder
	n, skipped := 0, 0
	for _, r := range related {
		if included[r.Entry.ID] {
			skipped++
			continue
		}
		if n >= max {
			break
		}
		included[r.Entry.ID] = true
		n++
		fmt.Fprintf(&b, "<memory_piece relatedness=\"%.3f\">\n%s\n</memory_piece>\n", r.Relevance, r.Entry.Body)
	}
	if b.Len() == 0 {
		if skipped > 0 {
			return "All memory pieces conforming your query were provided already. Use other query."
		}
		return "No data was found"
	}
	return b.String()
}

func queryWeb(ctx context.Context, d Deps, cue string) string {
	if !d.Cfg().WebSearchEnabled {
		return "No web search available"
	}
	res, err := d.Media().Web.Search(ctx, cue, 5)
	if err != nil {
		return "Error: " + err.Error()
	}
	var b strings.Builder
	for _, r := range res {
		fmt.Fprintf(&b, "<web_search_result title=%q url=%q>\n%s\n</web_search_result>\n", r.Title, r.URL, r.Content)
	}
	return b.String()
}
