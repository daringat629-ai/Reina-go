package telegram

import (
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"testing"
	"time"
)

// fakeBotAPI is a minimal Telegram Bot API server.
type fakeBotAPI struct {
	mu      sync.Mutex
	calls   []string
	bodies  map[string]string
	updates []string // JSON updates to deliver once
}

func (f *fakeBotAPI) handler(t *testing.T) http.Handler {
	f.bodies = map[string]string{}
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if strings.HasPrefix(r.URL.Path, "/file/bot") {
			io.WriteString(w, "FILEDATA")
			return
		}
		method := r.URL.Path[strings.LastIndex(r.URL.Path, "/")+1:]
		b, _ := io.ReadAll(r.Body)
		f.mu.Lock()
		f.calls = append(f.calls, method)
		f.bodies[method] = string(b)
		f.mu.Unlock()
		ok := func(res string) { io.WriteString(w, `{"ok":true,"result":`+res+`}`) }
		switch method {
		case "getMe":
			ok(`{"id":999,"first_name":"Kuni","username":"kuni_bot"}`)
		case "getUpdates":
			f.mu.Lock()
			ups := f.updates
			f.updates = nil
			f.mu.Unlock()
			if len(ups) == 0 {
				time.Sleep(50 * time.Millisecond)
				ok(`[]`)
				return
			}
			ok("[" + strings.Join(ups, ",") + "]")
		case "sendMessage":
			ok(`{"message_id":77,"date":1700000000,"chat":{"id":42,"type":"private","first_name":"Alex"},"from":{"id":999,"first_name":"Kuni"},"text":"echo"}`)
		case "getFile":
			ok(`{"file_path":"voice/file_1.oga"}`)
		case "getChatMember":
			ok(`{"status":"administrator"}`)
		case "sendPoll":
			ok(`{"message_id":78,"date":1700000000,"chat":{"id":-7,"type":"supergroup","title":"Club"},"from":{"id":999,"first_name":"Kuni"},"message_thread_id":4,"poll":{"question":"Pizza?","options":[{"text":"yes","voter_count":0},{"text":"no","voter_count":0}],"total_voter_count":0,"is_anonymous":false,"allows_multiple_answers":true}}`)
		case "pinChatMessage", "unpinChatMessage":
			ok(`true`)
		case "setMessageReaction", "deleteMessage", "editMessageText", "sendChatAction", "banChatMember", "leaveChat":
			ok(`true`)
		default:
			io.WriteString(w, `{"ok":false,"description":"unknown method `+method+`"}`)
		}
	})
}

func TestBotReceivesAndSends(t *testing.T) {
	f := &fakeBotAPI{updates: []string{
		`{"update_id":10,"message":{"message_id":5,"date":1700000000,"chat":{"id":42,"type":"private","first_name":"Alex"},"from":{"id":42,"first_name":"Alex"},"text":"hello"}}`,
		`{"update_id":11,"message":{"message_id":6,"date":1700000001,"chat":{"id":-7,"type":"supergroup","title":"Club"},"from":{"id":42,"first_name":"Alex"},"voice":{"file_id":"VOICE1"},"reply_to_message":{"message_id":3}}}`,
	}}
	srv := httptest.NewServer(f.handler(t))
	defer srv.Close()
	b := NewBot("TOKEN", srv.URL)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go b.Run(ctx)

	var got []Message
	for len(got) < 2 {
		select {
		case m := <-b.Updates():
			got = append(got, m)
		case <-time.After(3 * time.Second):
			t.Fatalf("timeout; got %d updates", len(got))
		}
	}
	if got[0].Text != "hello" || got[0].SenderName != "Alex" || got[0].Outgoing {
		t.Fatalf("bad text message: %+v", got[0])
	}
	if got[1].Media != MediaVoice || got[1].FileID != "VOICE1" || got[1].ReplyTo != 3 {
		t.Fatalf("bad voice message: %+v", got[1])
	}
	if b.MyID() != 999 {
		t.Fatalf("my id = %d", b.MyID())
	}

	chats, _ := b.Chats(ctx, 10)
	if len(chats) != 2 {
		t.Fatalf("chats: %+v", chats)
	}
	if un, _ := b.Unread(ctx, 42); len(un) != 1 {
		t.Fatalf("unread: %+v", un)
	}

	// group membership comes from getChatMember
	ch, err := b.Chat(ctx, -7)
	if err != nil || !ch.IsAdmin || ch.Kind != ChatGroup {
		t.Fatalf("group chat: %+v err=%v", ch, err)
	}

	sent, err := b.SendText(ctx, 42, "echo", 5)
	if err != nil || sent.ID != 77 || !sent.Outgoing {
		t.Fatalf("send: %+v err=%v", sent, err)
	}
	f.mu.Lock()
	body := f.bodies["sendMessage"]
	f.mu.Unlock()
	var parsed map[string]any
	json.Unmarshal([]byte(body), &parsed)
	if parsed["text"] != "echo" || parsed["reply_parameters"] == nil {
		t.Fatalf("sendMessage body: %s", body)
	}

	// reactions: variation selector must be stripped before hitting the API
	if err := b.React(ctx, 42, 5, "❤️"); err != nil {
		t.Fatal(err)
	}
	f.mu.Lock()
	rb := f.bodies["setMessageReaction"]
	f.mu.Unlock()
	if strings.Contains(rb, "\\ufe0f") || strings.Contains(rb, "️") {
		t.Fatalf("U+FE0F sent to Telegram: %s", rb)
	}

	data, err := b.Download(ctx, "VOICE1")
	if err != nil || string(data) != "FILEDATA" {
		t.Fatalf("download: %q err=%v", data, err)
	}

	if err := b.Join(ctx, "https://t.me/+abc"); err == nil {
		t.Fatal("bots can't join; expected an explanatory error")
	}
	if err := b.Delete(ctx, 42, 77); err != nil {
		t.Fatal(err)
	}
	if _, err := b.Message(ctx, 42, 77); err == nil {
		t.Fatal("deleted message still in store")
	}
}

func TestAPIErrorsSurface(t *testing.T) {
	f := &fakeBotAPI{}
	srv := httptest.NewServer(f.handler(t))
	defer srv.Close()
	b := NewBot("T", srv.URL)
	if err := b.Typing(context.Background(), 1); err != nil {
		t.Fatal(err)
	}
	err := b.SetMemberTag(context.Background(), 1, 2, "x")
	if err == nil || !strings.Contains(err.Error(), "unknown method") {
		t.Fatalf("API error should surface to the model, got %v", err)
	}
}

func TestStoreHistorySearchPersistence(t *testing.T) {
	s := NewStore()
	chat := &Chat{ID: 1, Title: "A", Kind: ChatPrivate}
	for i := int64(1); i <= 10; i++ {
		s.Put(Message{ID: i, ChatID: 1, SenderID: 5, Text: "msg " + string(rune('a'+i)), Date: time.Unix(1700000000+i, 0)}, chat)
	}
	c := Core{S: s}
	h, _ := c.History(context.Background(), 1, 5, 2, 2)
	if len(h) != 5 || h[0].ID != 3 || h[4].ID != 7 {
		t.Fatalf("history around 5: %+v", h)
	}
	res, _ := c.Search(context.Background(), SearchQuery{Text: "MSG f", Limit: 5})
	if len(res) != 1 || res[0].ID != 5 {
		t.Fatalf("search: %+v", res)
	}
	path := t.TempDir() + "/state.json"
	if err := s.Save(path); err != nil {
		t.Fatal(err)
	}
	s2 := NewStore()
	if err := s2.Load(path); err != nil {
		t.Fatal(err)
	}
	if m, err := (Core{S: s2}).Message(context.Background(), 1, 10); err != nil || m.ID != 10 {
		t.Fatalf("reloaded store: %+v err=%v", m, err)
	}
}

func TestBotPollsPinTopicsAndNoVoting(t *testing.T) {
	f := &fakeBotAPI{updates: []string{
		`{"update_id":10,"message":{"message_id":5,"message_thread_id":4,"date":1700000000,"chat":{"id":-7,"type":"supergroup","title":"Club"},"from":{"id":42,"first_name":"Alex"},"text":"in topic"}}`,
	}}
	srv := httptest.NewServer(f.handler(t))
	defer srv.Close()
	b := NewBot("TOKEN", srv.URL)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go b.Run(ctx)
	select {
	case m := <-b.Updates():
		if m.ThreadID != 4 {
			t.Fatalf("thread: %+v", m)
		}
	case <-time.After(3 * time.Second):
		t.Fatal("no update")
	}
	pm, err := b.SendPoll(ctx, -7, "Pizza?", []string{"yes", "no"}, false, true, 5)
	if err != nil || pm.Media != MediaPoll || pm.Poll == nil || len(pm.Poll.Options) != 2 || !pm.Poll.Multiple || pm.ThreadID != 4 {
		t.Fatalf("poll: %+v err=%v", pm, err)
	}
	var sent map[string]any
	f.mu.Lock()
	json.Unmarshal([]byte(f.bodies["sendPoll"]), &sent)
	f.mu.Unlock()
	if sent["message_thread_id"] != float64(4) || sent["allows_multiple_answers"] != true || sent["is_anonymous"] != false {
		t.Fatalf("sendPoll body: %v", sent)
	}
	if err := b.Pin(ctx, -7, 5, true); err != nil {
		t.Fatal(err)
	}
	if err := b.Unpin(ctx, -7, 5); err != nil {
		t.Fatal(err)
	}
	if err := b.VotePoll(ctx, -7, 78, []int{0}); err == nil {
		t.Fatal("a bot cannot vote")
	}
}

func TestBotMentionMarkupBecomesHTMLLink(t *testing.T) {
	html, ok := mentionHTML("hi [Joe <x>](tg://user?id=9) & co")
	if !ok || html != `hi <a href="tg://user?id=9">Joe &lt;x&gt;</a> &amp; co` {
		t.Fatalf("%q %v", html, ok)
	}
	if _, ok := mentionHTML("plain @joe"); ok {
		t.Fatal("plain text must stay plain")
	}
}
