package admin

import (
	"net/http"
	"strconv"

	"kuni/internal/people"
)

// DialogSource is implemented by a Controller that can show her open conversations.
type DialogSource interface {
	DialogList() any
	DialogMessages(id int64) (any, error)
}

// GET /admin/api/dialogs lists her open sessions; ?id=N returns what is in one of them.
func (p *Panel) dialogsAPI(w http.ResponseWriter, r *http.Request) {
	src, ok := p.Ctl.(DialogSource)
	if !ok {
		fail(w, 400, "диалоги недоступны (Telegram выключен)")
		return
	}
	if q := r.URL.Query().Get("id"); q != "" {
		id, err := strconv.ParseInt(q, 10, 64)
		if err != nil {
			fail(w, 400, "bad id")
			return
		}
		msgs, err := src.DialogMessages(id)
		if err != nil {
			fail(w, 409, err.Error())
			return
		}
		writeJSON(w, map[string]any{"messages": msgs})
		return
	}
	writeJSON(w, map[string]any{"dialogs": src.DialogList()})
}

// /admin/api/people: GET lists the cards; POST {id, name, facts:[{text, private}]} replaces one (no facts = delete).
func (p *Panel) peopleAPI(w http.ResponseWriter, r *http.Request) {
	if p.People == nil {
		fail(w, 400, "карточки людей недоступны")
		return
	}
	if r.Method == http.MethodPost {
		var in struct {
			ID    int64         `json:"id"`
			Name  string        `json:"name"`
			Facts []people.Fact `json:"facts"`
		}
		if err := readBody(r, &in); err != nil || in.ID == 0 {
			fail(w, 400, "нужен id человека")
			return
		}
		if err := p.People.Replace(in.ID, in.Name, in.Facts); err != nil {
			fail(w, 500, err.Error())
			return
		}
	}
	cards := p.People.All()
	if cards == nil {
		cards = []people.Card{}
	}
	writeJSON(w, map[string]any{"cards": cards})
}
