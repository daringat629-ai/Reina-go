package agent

import (
	"context"
	"log"
	"math/rand"
	"regexp"
	"strings"
	"time"

	"kuni/internal/llm"
	"kuni/internal/telegram"
	"kuni/internal/util"
)

// Every user view carries blocks that only matter in the turn they were written for (instructions, mood,
// recalled memories, the member roster...). Left in the history they are paid for again on every request.
var staleBlocks = func() []*regexp.Regexp {
	var out []*regexp.Regexp
	for _, tag := range []string{"memories_that_popped_up_in_mind", "earlier_messages", "instructions", "chat_info",
		"while_you_were_away", "things_to_remember", "state", "mood", "person_card", "event"} {
		out = append(out, regexp.MustCompile(`(?s)\s*<`+tag+`[ >].*?</`+tag+`>[ \t]*\n?`))
	}
	return out
}()

// slimUser removes the stale blocks from one user view.
func slimUser(s string) string {
	for _, re := range staleBlocks {
		s = re.ReplaceAllString(s, "\n")
	}
	return strings.TrimSpace(s)
}

// slimHistory returns msgs ready to be sent: everything before the latest user view loses its stale blocks,
// and old tool results / thoughts are cut. The stored session is not modified.
func slimHistory(msgs []llm.Message, toolChars int) []llm.Message {
	last := -1
	for i := len(msgs) - 1; i >= 0; i-- {
		if msgs[i].Role == "user" {
			last = i
			break
		}
	}
	if last <= 0 {
		return msgs
	}
	if toolChars <= 0 {
		toolChars = 300
	}
	out := make([]llm.Message, len(msgs))
	copy(out, msgs)
	for i := 0; i < last; i++ {
		switch out[i].Role {
		case "user":
			if !strings.HasPrefix(out[i].Content, "<conversation_so_far>") {
				out[i].Content = slimUser(out[i].Content)
			}
		case "tool":
			out[i].Content = util.Trunc(out[i].Content, toolChars)
		case "assistant":
			out[i].Content = util.Trunc(out[i].Content, 300)
		}
	}
	return out
}

func msgSize(m llm.Message) int {
	n := len(m.Content)
	for _, c := range m.ToolCalls {
		n += len(c.Function.Name) + len(c.Function.Arguments) + 20
	}
	return n
}

// fitBudget drops the oldest messages (in whole user-turns) until the history is at most chars characters.
// The latest user turn is always kept, whatever its size.
func fitBudget(msgs []llm.Message, chars int) []llm.Message {
	if chars <= 0 {
		return msgs
	}
	total := 0
	for _, m := range msgs {
		total += msgSize(m)
	}
	start := 0
	for total > chars {
		next := start + 1
		for next < len(msgs) && msgs[next].Role != "user" {
			next++
		}
		if next >= len(msgs) {
			break // only the latest turn is left
		}
		for i := start; i < next; i++ {
			total -= msgSize(msgs[i])
		}
		start = next
	}
	return msgs[start:]
}

// outgoing is what is actually sent to the model for this session.
func (a *Agent) outgoing(s *session) []llm.Message {
	cfg := a.Cfg.Get()
	return fitBudget(slimHistory(trim(s.msgs, 80), cfg.ToolResultChars), cfg.ContextChars)
}

// worthWaking decides, for a group, whether the unread messages deserve a (paid) model call at all.
func (a *Agent) worthWaking(ctx context.Context, chat telegram.Chat, unread []telegram.Message) bool {
	cfg := a.Cfg.Get()
	if chat.Kind == telegram.ChatPrivate || cfg.GroupReplyMode == "all" {
		return true
	}
	for _, m := range unread {
		if m.Outgoing {
			continue
		}
		if cfg.PapikChatID != 0 && m.SenderID == cfg.PapikChatID {
			return true
		}
		if a.UI.AddressedToMe(ctx, m) {
			return true
		}
	}
	if cfg.GroupChime > 0 && rand.Intn(100) < cfg.GroupChime {
		return true
	}
	return false
}

// compactNow summarises the old part of the session. It must not die together with the turn that triggered it
// (a new message cancels that turn), so it runs on a detached context; the light model is tried first, the main
// one second, and if both fail the old part is simply dropped so the history cannot grow without bound.
func (a *Agent) compactSummary(ctx context.Context, old []llm.Message) string {
	c, cancel := context.WithTimeout(context.WithoutCancel(ctx), 90*time.Second)
	defer cancel()
	sum, err := a.LLM.Chat(llm.WithPurpose(c, "compact"), compactSystem, old)
	if err == nil && strings.TrimSpace(sum) != "" {
		return strings.TrimSpace(sum)
	}
	log.Printf("agent: compact (light): %v; trying the main model", err)
	sum, err = a.LLM.Chat(llm.WithPurpose(c, "compact_main"), compactSystem, old)
	if err == nil && strings.TrimSpace(sum) != "" {
		return strings.TrimSpace(sum)
	}
	log.Printf("agent: compact (main): %v", err)
	return ""
}
