package agent

import (
	"context"
	"fmt"
	"strings"
	"testing"
	"time"

	"kuni/internal/llm"
	"kuni/internal/telegram"
)

func TestSlimHistoryStripsStaleBlocksButKeepsTheLatestView(t *testing.T) {
	view := func(text string) string {
		return `<mood level="55/100" state="нормально">be normal</mood>` + "\n<state>night</state>\n" +
			"<memories_that_popped_up_in_mind>\nold diary\n</memories_that_popped_up_in_mind>\n" +
			`<chat_info type="group" title="X">roster</chat_info>` + "\n" +
			"<earlier_messages>\nfoo\n</earlier_messages>\n" +
			`<message message_id="1" sender="Bob">` + text + "</message>\n" +
			"<instructions>\nGROUP RULES lots of text\n</instructions>\n"
	}
	msgs := []llm.Message{
		{Role: "user", Content: view("first")},
		{Role: "assistant", Content: "thinking"},
		{Role: "tool", ToolCallID: "c", Content: strings.Repeat("x", 2000)},
		{Role: "user", Content: view("second")},
	}
	out := slimHistory(msgs, 100)
	old := out[0].Content
	for _, bad := range []string{"<mood", "<state>", "popped_up", "chat_info", "earlier_messages", "GROUP RULES"} {
		if strings.Contains(old, bad) {
			t.Fatalf("old view still has %q: %s", bad, old)
		}
	}
	if !strings.Contains(old, "first") {
		t.Fatalf("message text lost: %s", old)
	}
	if len(out[2].Content) > 130 {
		t.Fatalf("old tool result not cut: %d", len(out[2].Content))
	}
	if out[3].Content != msgs[3].Content {
		t.Fatal("the latest view must stay intact")
	}
	if !strings.Contains(msgs[0].Content, "GROUP RULES") {
		t.Fatal("the stored session must not be modified")
	}
}

func TestFitBudgetDropsWholeTurnsAndKeepsTheLast(t *testing.T) {
	var msgs []llm.Message
	for i := 0; i < 10; i++ {
		msgs = append(msgs,
			llm.Message{Role: "user", Content: strings.Repeat("u", 1000)},
			llm.Message{Role: "assistant", Content: "a", ToolCalls: []llm.ToolCall{{ID: fmt.Sprint(i)}}},
			llm.Message{Role: "tool", ToolCallID: fmt.Sprint(i), Content: "ok"})
	}
	out := fitBudget(msgs, 3500)
	if out[0].Role != "user" {
		t.Fatalf("must start at a user message, got %s", out[0].Role)
	}
	if len(out) != 9 { // three turns of three
		t.Fatalf("kept %d messages", len(out))
	}
	if got := fitBudget(msgs[:3], 10); len(got) != 3 {
		t.Fatalf("the latest turn must survive any budget, got %d", len(got))
	}
	if len(fitBudget(msgs, 0)) != len(msgs) {
		t.Fatal("0 = unlimited")
	}
}

func TestGroupMessagesNotForHerCostNothing(t *testing.T) {
	f := newFakeLLM(t, sendCall)
	r := newRig(t, f)
	cfg := r.ag.Cfg.Get()
	cfg.GroupReplyMode, cfg.GroupChime = "addressed", 0
	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan struct{})
	go func() { r.ag.Run(ctx); close(done) }()
	defer func() { cancel(); <-done }()

	group := telegram.Chat{ID: -40, Title: "Club", Kind: telegram.ChatGroup, IsMember: true}
	r.tg.Incoming(group, 9, "Joe", "lol did you see the game")
	waitFor(t, "message to be read", func() bool { un, _ := r.tg.Unread(ctx, -40); return len(un) == 0 })
	time.Sleep(300 * time.Millisecond)
	f.mu.Lock()
	n := len(f.calls)
	f.mu.Unlock()
	if n != 0 || len(r.tg.SentTexts()) != 0 {
		t.Fatalf("a message for somebody else woke the model (%d calls)", n)
	}
	// the owner always counts
	r.tg.Incoming(group, cfg.PapikChatID, "Alex", "ok everyone")
	waitFor(t, "answer to the owner", func() bool { return len(r.tg.SentTexts()) == 1 })
	// a mention of her name counts as well
	r.tg.Incoming(group, 9, "Joe", "Kuni what do you think?")
	waitFor(t, "answer to a mention", func() bool {
		return len(r.tg.SentTexts()) >= 2 || r.ag.Metrics.Get("kuni_tool_calls_total", map[string]string{"tool": "send_telegram_message"}) >= 2
	})
}

func TestCompactFallsBackToMainModelAndDropsWhenItKeepsFailing(t *testing.T) {
	f := newFakeLLM(t, sendCall)
	r := newRig(t, f)
	r.ag.Cfg.Get().HistoryKeep = 2
	s := r.ag.getSession(7)
	for i := 0; i < 8; i++ {
		s.msgs = append(s.msgs, llm.Message{Role: "user", Content: fmt.Sprintf("message %d", i)}, llm.Message{Role: "assistant", Content: "ok"})
	}
	// an already canceled caller must not break the summary: it runs detached
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	r.ag.compact(ctx, s)
	if len(s.msgs) >= 16 || !strings.HasPrefix(s.msgs[0].Content, "<conversation_so_far>") {
		t.Fatalf("history not compacted: %d msgs, head %q", len(s.msgs), s.msgs[0].Content)
	}
	// the model is gone: old part is dropped anyway
	f.srv.Close()
	for i := 0; i < 8; i++ {
		s.msgs = append(s.msgs, llm.Message{Role: "user", Content: fmt.Sprintf("later %d", i)}, llm.Message{Role: "assistant", Content: "ok"})
	}
	before := len(s.msgs)
	r.ag.compact(context.Background(), s)
	if len(s.msgs) >= before || !strings.Contains(s.msgs[0].Content, "dropped") {
		t.Fatalf("failing summariser must not leave the history growing: %d -> %d", before, len(s.msgs))
	}
}

func TestToneDependsOnAudience(t *testing.T) {
	r := newRig(t, newFakeLLM(t, sendCall))
	r.ag.Cfg.Get().PapikChatID = 5
	for chat, want := range map[telegram.Chat]string{
		{ID: 5, Kind: telegram.ChatPrivate, IsMember: true}:  "папик",
		{ID: -9, Kind: telegram.ChatGroup, IsMember: true}:   "group audience",
		{ID: 77, Kind: telegram.ChatPrivate, IsMember: true}: "stranger",
	} {
		if got := r.ag.chatInstructions(chat); !strings.Contains(got, "TONE:") || !strings.Contains(got, want) {
			t.Fatalf("chat %d: want %q in %q", chat.ID, want, got)
		}
	}
}
