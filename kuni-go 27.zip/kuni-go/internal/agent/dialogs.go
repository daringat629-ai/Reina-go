package agent

import (
	"encoding/json"
	"errors"
	"fmt"
	"sort"
	"strings"
	"time"

	"kuni/internal/llm"
	"kuni/internal/util"
)

// DialogInfo / DialogMsg are the panel's view of an open session.
type DialogInfo struct {
	ID       int64     `json:"id"`
	Title    string    `json:"title"`
	Messages int       `json:"messages"`
	Last     time.Time `json:"last"`
}

type DialogMsg struct {
	Role string `json:"role"` // user | she | tool
	Text string `json:"text"`
}

// DialogList lists the open sessions, the most recent first.
func (a *Agent) DialogList() any {
	a.mu.Lock()
	defer a.mu.Unlock()
	out := []DialogInfo{}
	for id, s := range a.sessions {
		title := s.chat.Title
		switch {
		case id == 0:
			title = "её собственные мысли (автономность)"
		case title == "":
			title = fmt.Sprintf("чат %d", id)
		}
		out = append(out, DialogInfo{ID: id, Title: title, Messages: len(s.msgs), Last: s.last})
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Last.After(out[j].Last) })
	return out
}

// DialogMessages renders what the session holds: what she saw (without the service blocks), what she thought and
// wrote. A turn in progress holds the session, then the caller is asked to try again.
func (a *Agent) DialogMessages(id int64) (any, error) {
	a.mu.Lock()
	s := a.sessions[id]
	a.mu.Unlock()
	if s == nil {
		return nil, errors.New("сессия закрыта (она уже в дневнике)")
	}
	if !s.mu.TryLock() {
		return nil, errors.New("она сейчас думает, обнови через пару секунд")
	}
	defer s.mu.Unlock()
	return renderDialog(s.msgs), nil
}

func renderDialog(msgs []llm.Message) []DialogMsg {
	out := []DialogMsg{}
	for _, m := range msgs {
		switch m.Role {
		case "user":
			out = append(out, DialogMsg{Role: "user", Text: util.Trunc(slimUser(m.Content), 900)})
		case "assistant":
			var parts []string
			if t := strings.TrimSpace(m.Content); t != "" {
				parts = append(parts, "💭 "+util.Trunc(t, 300))
			}
			for _, c := range m.ToolCalls {
				parts = append(parts, toolLine(c))
			}
			out = append(out, DialogMsg{Role: "she", Text: strings.Join(parts, "\n")})
		case "tool":
			out = append(out, DialogMsg{Role: "tool", Text: "↳ " + util.Trunc(strings.Join(strings.Fields(m.Content), " "), 160)})
		}
	}
	return out
}

func toolLine(c llm.ToolCall) string {
	if c.Function.Name == "send_telegram_message" {
		var a struct {
			Text string `json:"text"`
		}
		if json.Unmarshal([]byte(c.Function.Arguments), &a) == nil && a.Text != "" {
			return "➜ " + a.Text
		}
	}
	return "#" + c.Function.Name + " " + util.Trunc(string(c.Function.Arguments), 120)
}
