package agent

import (
	"context"
	"fmt"
	"log"
	"strings"
	"time"

	"kuni/internal/llm"
	"kuni/internal/telegram"
	"kuni/internal/tools"
)

// wakeCtx is the context for turns started by outside events; it ends when the agent stops.
func (a *Agent) wakeCtx() context.Context {
	if a.runCtx != nil {
		return a.runCtx
	}
	return context.Background()
}

// Wake lets an outside event (a reminder that is due, a finished background job) start a turn of hers in a chat:
// she sees the event and decides what to write.
func (a *Agent) Wake(ctx context.Context, chatID int64, text string) error {
	if a.paused.Load() {
		return nil
	}
	cfg := a.Cfg.Get()
	if chatID != cfg.PapikChatID && !tools.Accessible(cfg, chatID) {
		log.Printf("agent: wake chat %d ignored by lockdown=%q", chatID, cfg.Lockdown)
		return nil
	}
	chat, err := a.TG.Chat(ctx, chatID)
	if err != nil {
		return err
	}
	s := a.getSession(chatID)
	s.mu.Lock()
	defer s.mu.Unlock()
	defer a.goOnline(ctx)()
	a.setPhase(chatID, "thinking", time.Time{})
	defer a.endPhase(chatID)

	d := a.depsFor(s)
	s.chat, s.thread = chat, 0
	s.tools = a.newRegistry(s, d, chat, false, nil)
	var b strings.Builder
	b.WriteString(a.moodBlock())
	b.WriteString(a.sleepBlock())
	fmt.Fprintf(&b, "You switched to the chat %q in Telegram.\n", chat.Title)
	b.WriteString(a.personCards(chat, nil))
	b.WriteString("<event>\n" + strings.TrimSpace(text) + "\n</event>\n")
	b.WriteString(a.chatInstructions(chat))
	s.msgs = append(s.msgs, llm.Message{Role: "user", Content: b.String()})
	return a.runTurn(ctx, s)
}

// reminderLoop fires reminders when their time has come.
func (a *Agent) reminderLoop(ctx context.Context) {
	t := time.NewTicker(20 * time.Second)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
		}
		a.fireDue(ctx)
	}
}

// fireDue wakes her for every reminder whose time has come (paused: they wait and fire after the resume).
func (a *Agent) fireDue(ctx context.Context) {
	if a.Deps.Reminders == nil || a.paused.Load() {
		return
	}
	for _, it := range a.Deps.Reminders.Due(time.Now()) {
		it := it
		go func() {
			text := fmt.Sprintf("A reminder you set %s has come due: %q. Write to the person about it now, in your own words and your usual tone. If it is clearly no longer relevant, you may stay silent.",
				fmtAgo(it.Created), it.Text)
			if err := a.Wake(ctx, it.Chat, text); err != nil {
				log.Printf("agent: reminder #%d for chat %d: %v", it.ID, it.Chat, err)
			}
		}()
	}
}

func fmtAgo(t time.Time) string {
	d := time.Since(t)
	switch {
	case d < time.Minute:
		return "just now"
	case d < time.Hour:
		return fmt.Sprintf("%d min ago", int(d.Minutes()))
	case d < 48*time.Hour:
		return fmt.Sprintf("%d h ago", int(d.Hours()))
	}
	return fmt.Sprintf("%d days ago", int(d.Hours()/24))
}

// personCards shows the cards of the people in the current conversation (cheap: a few lines each). Facts
// learned in private chats are left out in groups.
func (a *Agent) personCards(chat telegram.Chat, unread []telegram.Message) string {
	if a.Deps.People == nil {
		return ""
	}
	if chat.Kind == telegram.ChatPrivate {
		return a.Deps.People.Get(chat.ID).Render(true)
	}
	var b strings.Builder
	seen := map[int64]bool{}
	for _, m := range unread {
		if m.Outgoing || m.SenderID == 0 || seen[m.SenderID] || len(seen) >= 4 {
			continue
		}
		seen[m.SenderID] = true
		b.WriteString(a.Deps.People.Get(m.SenderID).Render(false))
	}
	return b.String()
}
