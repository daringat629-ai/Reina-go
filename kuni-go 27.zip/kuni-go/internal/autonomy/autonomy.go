// Package autonomy keeps the state of the character's own initiative: when she is asleep, how much she has
// written on her own today, which chats she wrote to recently, and a human-readable journal of it all.
// The limits are enforced in code (the model is only told about them), so a prompt cannot talk its way past them.
package autonomy

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

// Limits are the user-configurable bounds of autonomous behaviour.
type Limits struct {
	MaxPerDay    int           // initiated messages per day; 0 = none allowed
	ChatCooldown time.Duration // minimum gap between initiated messages to the same chat
}

type data struct {
	SleepUntil time.Time        `json:"sleep_until"`
	SleepNote  string           `json:"sleep_note,omitempty"`
	Day        string           `json:"day"`
	Sent       int              `json:"sent"`
	LastRun    time.Time        `json:"last_run"`
	LastAction string           `json:"last_action,omitempty"`
	ChatLast   map[int64]string `json:"chat_last,omitempty"` // chat id -> RFC3339 time of the last initiated message
}

// State is safe for concurrent use. A nil *State is a valid "autonomy off" value.
type State struct {
	mu      sync.Mutex
	path    string
	logPath string
	d       data
	now     func() time.Time
	n       int // journal entries written by this process
}

// New loads (or starts) the state stored in path; the journal is appended to logPath.
func New(path, logPath string) *State {
	s := &State{path: path, logPath: logPath, now: time.Now}
	if b, err := os.ReadFile(path); err == nil {
		_ = json.Unmarshal(b, &s.d)
	}
	return s
}

func (s *State) save() {
	if s.path == "" {
		return
	}
	_ = os.MkdirAll(filepath.Dir(s.path), 0o755)
	b, _ := json.MarshalIndent(s.d, "", "  ")
	tmp := s.path + ".tmp"
	if os.WriteFile(tmp, b, 0o644) == nil {
		_ = os.Rename(tmp, s.path)
	}
}

func (s *State) rollDay(now time.Time) {
	if day := now.Format("2006-01-02"); s.d.Day != day {
		s.d.Day, s.d.Sent = day, 0
	}
}

// Asleep reports whether the character decided to sleep and until when.
func (s *State) Asleep() (bool, time.Time) {
	if s == nil {
		return false, time.Time{}
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.d.SleepUntil.After(s.now()) {
		return true, s.d.SleepUntil
	}
	return false, time.Time{}
}

// Sleep puts the character to sleep for d (clamped to 20 min .. 12 h).
func (s *State) Sleep(d time.Duration, note string) time.Time {
	if s == nil {
		return time.Time{}
	}
	if d < 20*time.Minute {
		d = 20 * time.Minute
	}
	if d > 12*time.Hour {
		d = 12 * time.Hour
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	s.d.SleepUntil, s.d.SleepNote = s.now().Add(d), note
	s.save()
	return s.d.SleepUntil
}

// Wake ends a sleep early.
func (s *State) Wake() {
	if s == nil {
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	s.d.SleepUntil, s.d.SleepNote = time.Time{}, ""
	s.save()
}

// Allow says whether an initiated message to chatID may be sent now. exempt chats (the owner) are never limited.
func (s *State) Allow(chatID int64, lim Limits, exempt bool) (bool, string) {
	if s == nil || exempt {
		return true, ""
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	now := s.now()
	s.rollDay(now)
	if s.d.Sent >= lim.MaxPerDay {
		return false, fmt.Sprintf("the daily limit of %d messages written on your own initiative is reached; try again tomorrow", lim.MaxPerDay)
	}
	if t, err := time.Parse(time.RFC3339, s.d.ChatLast[chatID]); err == nil && now.Sub(t) < lim.ChatCooldown {
		return false, fmt.Sprintf("you already wrote to this chat %d minutes ago; wait until they answer or until %d minutes have passed",
			int(now.Sub(t).Minutes()), int(lim.ChatCooldown.Minutes()))
	}
	return true, ""
}

// RecordSend counts an initiated message and journals it. Exempt sends are journaled but not counted.
func (s *State) RecordSend(chatID int64, title, text string, exempt bool) {
	if s == nil {
		return
	}
	s.mu.Lock()
	now := s.now()
	s.rollDay(now)
	if !exempt {
		s.d.Sent++
		if s.d.ChatLast == nil {
			s.d.ChatLast = map[int64]string{}
		}
		s.d.ChatLast[chatID] = now.Format(time.RFC3339)
	}
	s.d.LastAction = "wrote to " + title
	s.save()
	s.mu.Unlock()
	s.Log(fmt.Sprintf("wrote to %s: %s", title, oneLine(text, 160)))
}

// Ran marks the start of an autonomous round.
func (s *State) Ran() {
	if s == nil {
		return
	}
	s.mu.Lock()
	s.d.LastRun = s.now()
	s.save()
	s.mu.Unlock()
}

// SentToday is the number of counted initiated messages today.
func (s *State) SentToday() int {
	if s == nil {
		return 0
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	s.rollDay(s.now())
	return s.d.Sent
}

// Snapshot is what the panel shows.
type Snapshot struct {
	Asleep     bool      `json:"asleep"`
	SleepUntil time.Time `json:"sleep_until,omitempty"`
	SleepNote  string    `json:"sleep_note,omitempty"`
	SentToday  int       `json:"sent_today"`
	LastRun    time.Time `json:"last_run,omitempty"`
	LastAction string    `json:"last_action,omitempty"`
}

func (s *State) Snapshot() Snapshot {
	if s == nil {
		return Snapshot{}
	}
	asleep, until := s.Asleep()
	s.mu.Lock()
	defer s.mu.Unlock()
	s.rollDay(s.now())
	return Snapshot{Asleep: asleep, SleepUntil: until, SleepNote: s.d.SleepNote, SentToday: s.d.Sent, LastRun: s.d.LastRun, LastAction: s.d.LastAction}
}

// Log appends one line to the journal.
func (s *State) Log(line string) {
	if s == nil || s.logPath == "" {
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	s.d.LastAction = oneLine(line, 120)
	s.n++
	_ = os.MkdirAll(filepath.Dir(s.logPath), 0o755)
	if f, err := os.OpenFile(s.logPath, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o644); err == nil {
		fmt.Fprintf(f, "%s | %s\n", s.now().Format("2006-01-02 15:04"), oneLine(line, 400))
		_ = f.Close()
	}
}

// Entries counts journal lines written since start (to tell whether a round did anything).
func (s *State) Entries() int {
	if s == nil {
		return 0
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.n
}

// Recent returns the last n journal lines, newest last.
func (s *State) Recent(n int) []string {
	if s == nil || s.logPath == "" {
		return nil
	}
	f, err := os.Open(s.logPath)
	if err != nil {
		return nil
	}
	defer f.Close()
	var lines []string
	sc := bufio.NewScanner(f)
	sc.Buffer(make([]byte, 1<<16), 1<<20)
	for sc.Scan() {
		if t := strings.TrimSpace(sc.Text()); t != "" {
			lines = append(lines, t)
		}
	}
	if len(lines) > n {
		lines = lines[len(lines)-n:]
	}
	return lines
}

func oneLine(s string, max int) string {
	s = strings.Join(strings.Fields(s), " ")
	if r := []rune(s); len(r) > max {
		return string(r[:max]) + "…"
	}
	return s
}

// InQuietHours reports whether now (in loc) falls in [from, to) given as "HH:MM"; the window may wrap past
// midnight. Empty or malformed bounds mean "never quiet".
func InQuietHours(now time.Time, from, to string, loc *time.Location) bool {
	f, ok1 := minutes(from)
	t, ok2 := minutes(to)
	if !ok1 || !ok2 || f == t {
		return false
	}
	if loc != nil {
		now = now.In(loc)
	}
	m := now.Hour()*60 + now.Minute()
	if f < t {
		return m >= f && m < t
	}
	return m >= f || m < t
}

func minutes(hhmm string) (int, bool) {
	var h, m int
	if _, err := fmt.Sscanf(strings.TrimSpace(hhmm), "%d:%d", &h, &m); err != nil || h < 0 || h > 23 || m < 0 || m > 59 {
		return 0, false
	}
	return h*60 + m, true
}

// Location resolves an IANA zone name; empty or unknown falls back to the local zone.
func Location(name string) *time.Location {
	if name != "" {
		if l, err := time.LoadLocation(name); err == nil {
			return l
		}
	}
	return time.Local
}
