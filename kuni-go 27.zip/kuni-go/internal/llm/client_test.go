package llm

import (
	"context"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"
)

func TestSystemPromptIsMarkedCacheableOnlyForClaude(t *testing.T) {
	var bodies []string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		b, _ := io.ReadAll(r.Body)
		bodies = append(bodies, string(b))
		_, _ = w.Write([]byte(`{"choices":[{"message":{"role":"assistant","content":"ok"}}],"usage":{"prompt_tokens":100,"completion_tokens":5,"prompt_tokens_details":{"cached_tokens":80}}}`))
	}))
	defer srv.Close()
	c := New(srv.URL+"/", srv.URL+"/", "k", "anthropic/claude-sonnet", "e", 5*time.Second)
	c.Update(Settings{BaseURL: srv.URL + "/", APIKey: "k", Model: "anthropic/claude-sonnet", CachePrompt: true})
	cached := 0
	c.OnCached = func(_, _ string, n int) { cached = n }
	if _, err := c.Complete(context.Background(), "SYS", []Message{{Role: "user", Content: "hi"}}, nil); err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(bodies[0], `"cache_control":{"type":"ephemeral"}`) || cached != 80 {
		t.Fatalf("claude: cached=%d body=%s", cached, bodies[0])
	}
	c.Update(Settings{BaseURL: srv.URL + "/", APIKey: "k", Model: "deepseek/deepseek-v4-flash", CachePrompt: true})
	if _, err := c.Complete(context.Background(), "SYS", []Message{{Role: "user", Content: "hi"}}, nil); err != nil {
		t.Fatal(err)
	}
	if strings.Contains(bodies[1], "cache_control") || !strings.Contains(bodies[1], `"content":"SYS"`) {
		t.Fatalf("deepseek must get a plain system message: %s", bodies[1])
	}
}
