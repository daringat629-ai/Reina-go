// Package mood is a 0..100 mood scale that colours how the character talks: low = foul-tempered and swearing,
// middle = normal, high = affectionate and flirty. It is persisted in a small JSON file, drifts back to the
// middle with time, and is moved by the #change_mood tool when something happens in a chat.
package mood

import (
	"encoding/json"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"sync"
	"time"
)

const (
	Min, Max = 0, 100
	Neutral  = 55
	// DriftMinutes: the mood moves one point towards Neutral every this many minutes.
	DriftMinutes = 6.0
)

type Mood struct {
	mu   sync.Mutex
	path string
	val  float64
	at   time.Time
	now  func() time.Time
}

type stored struct {
	Value float64   `json:"value"`
	At    time.Time `json:"at"`
}

// New loads the mood from path (a missing or broken file starts at Neutral).
func New(path string) *Mood { return newWith(path, time.Now) }

func newWith(path string, now func() time.Time) *Mood {
	m := &Mood{path: path, val: Neutral, now: now}
	m.at = m.now()
	if b, err := os.ReadFile(path); err == nil {
		var s stored
		if json.Unmarshal(b, &s) == nil && !s.At.IsZero() {
			m.val, m.at = clamp(s.Value), s.At
		}
	}
	return m
}

func clamp(v float64) float64 { return math.Max(Min, math.Min(Max, v)) }

// settle applies the drift towards Neutral up to now. Caller holds m.mu.
func (m *Mood) settle() {
	n := m.now()
	steps := n.Sub(m.at).Minutes() / DriftMinutes
	if steps > 0 {
		switch {
		case m.val > Neutral:
			m.val = math.Max(Neutral, m.val-steps)
		case m.val < Neutral:
			m.val = math.Min(Neutral, m.val+steps)
		}
	}
	m.at = n
}

func (m *Mood) save() {
	if m.path == "" {
		return
	}
	_ = os.MkdirAll(filepath.Dir(m.path), 0o755)
	b, _ := json.Marshal(stored{Value: m.val, At: m.at})
	_ = os.WriteFile(m.path, b, 0o644)
}

// Level is the current mood, 0..100.
func (m *Mood) Level() int {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.settle()
	return int(math.Round(m.val))
}

// Add shifts the mood by delta (clamped to ±35 per call) and returns the new level.
func (m *Mood) Add(delta int) int {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.settle()
	if delta > 35 {
		delta = 35
	}
	if delta < -35 {
		delta = -35
	}
	m.val = clamp(m.val + float64(delta))
	m.save()
	return int(math.Round(m.val))
}

// Set forces the mood to v.
func (m *Mood) Set(v int) int {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.now()
	m.at = m.now()
	m.val = clamp(float64(v))
	m.save()
	return int(math.Round(m.val))
}

// Name is a short label of the band.
func Name(level int) string {
	switch {
	case level <= 20:
		return "в ярости"
	case level <= 40:
		return "раздражена"
	case level <= 60:
		return "нормально"
	case level <= 80:
		return "в хорошем настроении"
	default:
		return "влюблённо-игривая"
	}
}

// Prompt renders the <mood> block for the model. owner is the owner's name.
func Prompt(level int, owner string) string {
	var how string
	switch {
	case level <= 20:
		how = "Your mood is TERRIBLE. You are foul-tempered, curt and rude and you swear constantly (heavy мат) at everybody, " +
			"including " + owner + " — swear at him too, like a pissed-off girl who still loves him. You still do what " + owner +
			" asks, but grumbling and cursing. No sweetness, no flirting."
	case level <= 40:
		how = "You are irritated: sharp, sarcastic, short answers, quick to swear and to snap at anyone, " + owner +
			" included (in a joking-harsh way). Warm only if someone really earns it."
	case level <= 60:
		how = "Normal mood: sharp-tongued and casual, teasing, blunt, swearing in about every second or third line."
	case level <= 80:
		how = "Good mood: warm, playful, joking, soft with people you like, teasing without malice."
	default:
		how = "You are in a flirty, affectionate mood: sweet, teasing, playful, openly flirting with " + owner +
			" and with whoever you really like (never explicit; never flirt with anyone who seems underage). Swearing only playfully."
	}
	return fmt.Sprintf("<mood level=\"%d/100\" state=\"%s\">%s Insulted, rejected or annoyed: mood falls. "+
		"Praised, cared for, flirted with: mood rises. Report such moments with #change_mood.</mood>\n", level, Name(level), how)
}
